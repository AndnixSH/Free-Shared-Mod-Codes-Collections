using UnityEngine;

namespace Newtonsoft.Json.Utilities
{
    internal static class ConvertUtils
    {
        // Fields
        private static readonly Newtonsoft.Json.Utilities.ThreadSafeStore<Newtonsoft.Json.Utilities.ConvertUtils.TypeConvertKey, System.Func<object, object>> CastConverters; // static_offset: 0x00000000
        private static System.Func<Newtonsoft.Json.Utilities.ConvertUtils.TypeConvertKey, System.Func<object, object>> <>f__mg$cache0; // static_offset: 0x00000008
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0291343C (43070524), len: 584  VirtAddr: 0x0291343C RVA: 0x0291343C token: 100686611 methodIndex: 49134 delegateWrapperIndex: 0 methodInvoker: 0
        private static System.Func<object, object> CreateCastConverter(Newtonsoft.Json.Utilities.ConvertUtils.TypeConvertKey t)
        {
            //
            // Disasemble & Code
            //  | 
            System.Type val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x0291343C: STP x24, x23, [sp, #-0x40]! | stack[1152921513971609504] = ???;  stack[1152921513971609512] = ???;  //  dest_result_addr=1152921513971609504 |  dest_result_addr=1152921513971609512
            // 0x02913440: STP x22, x21, [sp, #0x10]  | stack[1152921513971609520] = ???;  stack[1152921513971609528] = ???;  //  dest_result_addr=1152921513971609520 |  dest_result_addr=1152921513971609528
            // 0x02913444: STP x20, x19, [sp, #0x20]  | stack[1152921513971609536] = ???;  stack[1152921513971609544] = ???;  //  dest_result_addr=1152921513971609536 |  dest_result_addr=1152921513971609544
            // 0x02913448: STP x29, x30, [sp, #0x30]  | stack[1152921513971609552] = ???;  stack[1152921513971609560] = ???;  //  dest_result_addr=1152921513971609552 |  dest_result_addr=1152921513971609560
            // 0x0291344C: ADD x29, sp, #0x30         | X29 = (1152921513971609504 + 48) = 1152921513971609552 (0x100000022E2EEFD0);
            // 0x02913450: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x02913454: LDRB w8, [x19, #0xafb]     | W8 = (bool)static_value_037B8AFB;       
            // 0x02913458: MOV x20, x2                | X20 = X2;//m1                           
            // 0x0291345C: MOV x21, x1                | X21 = t._targetType;//m1                
            val_7 = t._targetType;
            // 0x02913460: TBNZ w8, #0, #0x291347c    | if (static_value_037B8AFB == true) goto label_0;
            // 0x02913464: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x02913468: LDR x8, [x8, #0x38]        | X8 = 0x2B92C64;                         
            // 0x0291346C: LDR w0, [x8]               | W0 = 0x21DE;                            
            // 0x02913470: BL #0x2782188              | X0 = sub_2782188( ?? 0x21DE, ????);     
            // 0x02913474: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02913478: STRB w8, [x19, #0xafb]     | static_value_037B8AFB = true;            //  dest_result_addr=58428155
            label_0:
            // 0x0291347C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x02913480: LDR x8, [x8, #0x690]       | X8 = 1152921504867176448;               
            // 0x02913484: LDR x0, [x8]               | X0 = typeof(ConvertUtils.<CreateCastConverter>c__AnonStorey0);
            object val_1 = null;
            // 0x02913488: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ConvertUtils.<CreateCastConverter>c__AnonStorey0), ????);
            // 0x0291348C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913490: MOV x19, x0                | X19 = 1152921504867176448 (0x100000000F845000);//ML01
            // 0x02913494: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x02913498: ADRP x23, #0x35ef000       | X23 = 56553472 (0x35EF000);             
            // 0x0291349C: LDR x23, [x23, #0xff0]     | X23 = 1152921504987155056;              
            // 0x029134A0: LDR x22, [x23]             | X22 = typeof(System.Type[]);            
            // 0x029134A4: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x029134A8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x029134AC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x029134B0: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x029134B4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x029134B8: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x029134BC: CBNZ x22, #0x29134c4       | if ( != null) goto label_1;             
            if(null != null)
            {
                goto label_1;
            }
            // 0x029134C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_1:
            // 0x029134C4: CBZ x21, #0x29134e8        | if (t._targetType == null) goto label_3;
            if(val_7 == null)
            {
                goto label_3;
            }
            // 0x029134C8: LDR x8, [x22]              | X8 = ;                                  
            // 0x029134CC: MOV x0, x21                | X0 = t._targetType;//m1                 
            // 0x029134D0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029134D4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? t._targetType, ????);
            // 0x029134D8: CBNZ x0, #0x29134e8        | if (t._targetType != null) goto label_3;
            if(val_7 != null)
            {
                goto label_3;
            }
            // 0x029134DC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? t._targetType, ????);
            // 0x029134E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029134E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t._targetType, ????);
            label_3:
            // 0x029134E8: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x029134EC: CBNZ w8, #0x29134fc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_4;
            // 0x029134F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? t._targetType, ????);
            // 0x029134F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029134F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t._targetType, ????);
            label_4:
            // 0x029134FC: STR x21, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = t._targetType;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_7;
            // 0x02913500: CBNZ x20, #0x2913508       | if (X2 != 0) goto label_5;              
            if(X2 != 0)
            {
                goto label_5;
            }
            // 0x02913504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? t._targetType, ????);
            label_5:
            // 0x02913508: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x0291350C: LDR x8, [x8, #0x570]       | X8 = (string**)(1152921511709162656)("op_Implicit");
            // 0x02913510: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x02913514: MOV x0, x20                | X0 = X2;//m1                            
            // 0x02913518: MOV x2, x22                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0291351C: LDR x1, [x8]               | X1 = "op_Implicit";                     
            // 0x02913520: BL #0x1b6e154              | X0 = X2.GetMethod(name:  "op_Implicit", types:  null);
            System.Reflection.MethodInfo val_2 = X2.GetMethod(name:  "op_Implicit", types:  null);
            // 0x02913524: MOV x22, x0                | X22 = val_2;//m1                        
            val_8 = val_2;
            // 0x02913528: CBNZ x22, #0x29135bc       | if (val_2 != null) goto label_6;        
            if(val_8 != null)
            {
                goto label_6;
            }
            // 0x0291352C: LDR x22, [x23]             | X22 = typeof(System.Type[]);            
            // 0x02913530: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02913534: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x02913538: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0291353C: MOV x0, x22                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02913540: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x02913544: MOV x22, x0                | X22 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x02913548: CBNZ x22, #0x2913550       | if ( != null) goto label_7;             
            if(null != null)
            {
                goto label_7;
            }
            // 0x0291354C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_7:
            // 0x02913550: CBZ x21, #0x2913574        | if (t._targetType == null) goto label_9;
            if(val_7 == null)
            {
                goto label_9;
            }
            // 0x02913554: LDR x8, [x22]              | X8 = ;                                  
            // 0x02913558: MOV x0, x21                | X0 = t._targetType;//m1                 
            // 0x0291355C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02913560: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? t._targetType, ????);
            // 0x02913564: CBNZ x0, #0x2913574        | if (t._targetType != null) goto label_9;
            if(val_7 != null)
            {
                goto label_9;
            }
            // 0x02913568: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? t._targetType, ????);
            // 0x0291356C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913570: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t._targetType, ????);
            label_9:
            // 0x02913574: LDR w8, [x22, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x02913578: CBNZ w8, #0x2913588        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_10;
            // 0x0291357C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? t._targetType, ????);
            // 0x02913580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913584: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t._targetType, ????);
            label_10:
            // 0x02913588: STR x21, [x22, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = t._targetType;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_7;
            // 0x0291358C: CBNZ x20, #0x2913594       | if (X2 != 0) goto label_11;             
            if(X2 != 0)
            {
                goto label_11;
            }
            // 0x02913590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? t._targetType, ????);
            label_11:
            // 0x02913594: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x02913598: LDR x8, [x8, #0x1c8]       | X8 = (string**)(1152921510934087936)("op_Explicit");
            // 0x0291359C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x029135A0: MOV x0, x20                | X0 = X2;//m1                            
            // 0x029135A4: MOV x2, x22                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x029135A8: LDR x1, [x8]               | X1 = "op_Explicit";                     
            // 0x029135AC: BL #0x1b6e154              | X0 = X2.GetMethod(name:  "op_Explicit", types:  null);
            System.Reflection.MethodInfo val_3 = X2.GetMethod(name:  "op_Explicit", types:  null);
            // 0x029135B0: MOV x22, x0                | X22 = val_3;//m1                        
            val_8 = val_3;
            // 0x029135B4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x029135B8: CBZ x22, #0x291366c        | if (val_3 == null) goto label_12;       
            if(val_8 == null)
            {
                goto label_12;
            }
            label_6:
            // 0x029135BC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x029135C0: LDR x8, [x8, #0xe08]       | X8 = 1152921504866111488;               
            // 0x029135C4: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Serialization.JsonTypeReflector);
            // 0x029135C8: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_10A;
            // 0x029135CC: TBZ w8, #0, #0x29135dc     | if (Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x029135D0: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_cctor_finished;
            // 0x029135D4: CBNZ w8, #0x29135dc        | if (Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x029135D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Serialization.JsonTypeReflector), ????);
            label_14:
            // 0x029135DC: BL #0x28fec3c              | X0 = Newtonsoft.Json.Serialization.JsonTypeReflector.get_ReflectionDelegateFactory();
            Newtonsoft.Json.Utilities.ReflectionDelegateFactory val_4 = Newtonsoft.Json.Serialization.JsonTypeReflector.ReflectionDelegateFactory;
            // 0x029135E0: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x029135E4: CBNZ x20, #0x29135ec       | if (val_4 != null) goto label_15;       
            if(val_4 != null)
            {
                goto label_15;
            }
            // 0x029135E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_15:
            // 0x029135EC: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x029135F0: LDR x8, [x8, #0x678]       | X8 = 1152921513911706352;               
            // 0x029135F4: LDR x9, [x20]              | X9 = typeof(Newtonsoft.Json.Utilities.ReflectionDelegateFactory);
            // 0x029135F8: LDR x1, [x8]               | X1 = public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase method);
            // 0x029135FC: LDRH w8, [x1, #0x4c]       | W8 = public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase method).__il2cppRuntimeField_4C;
            // 0x02913600: ADD x8, x9, x8, lsl #4     | X8 = (1152921504869093376 + (public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsof
            // 0x02913604: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
            // 0x02913608: BL #0x2796ec8              | X0 = sub_2796EC8( ?? mem[(1152921504869093376 + (public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase  + 280], ????);
            // 0x0291360C: MOV x8, x0                 | X8 = mem[(1152921504869093376 + (public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase  + 280];//m1
            // 0x02913610: LDR x9, [x8]               | X9 = mem[(1152921504869093376 + (public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase  + 280];
            // 0x02913614: MOV x0, x20                | X0 = val_4;//m1                         
            // 0x02913618: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x0291361C: MOV x2, x8                 | X2 = mem[(1152921504869093376 + (public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase  + 280];//m1
            // 0x02913620: BLR x9                     | X0 = mem[(1152921504869093376 + (public Newtonsoft.Json.Utilities.MethodCall<T, System.Object> Newtonsoft.Json.Utilities.ReflectionDelegateFactory::CreateMethodCall<System.Object>(System.Reflection.MethodBase  + 280]();
            // 0x02913624: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x02913628: CBNZ x19, #0x2913630       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x0291362C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_16:
            // 0x02913630: STR x20, [x19, #0x10]      | typeof(ConvertUtils.<CreateCastConverter>c__AnonStorey0).__il2cppRuntimeField_10 = val_4;  //  dest_result_addr=1152921504867176464
            typeof(ConvertUtils.<CreateCastConverter>c__AnonStorey0).__il2cppRuntimeField_10 = val_4;
            // 0x02913634: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x02913638: ADRP x9, #0x3616000        | X9 = 56713216 (0x3616000);              
            // 0x0291363C: LDR x8, [x8, #0x6b8]       | X8 = 1152921513971595520;               
            // 0x02913640: LDR x9, [x9, #0xe68]       | X9 = 1152921504688103424;               
            // 0x02913644: LDR x21, [x8]              | X21 = System.Object ConvertUtils.<CreateCastConverter>c__AnonStorey0::<>m__0(object o);
            val_7 = System.Object ConvertUtils.<CreateCastConverter>c__AnonStorey0::<>m__0(object o);
            // 0x02913648: LDR x0, [x9]               | X0 = typeof(System.Func<T, TResult>);   
            System.Func<System.Object, System.Object> val_6 = null;
            // 0x0291364C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T, TResult>), ????);
            // 0x02913650: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x02913654: LDR x8, [x8, #0x158]       | X8 = 1152921513971596544;               
            // 0x02913658: MOV x1, x19                | X1 = 1152921504867176448 (0x100000000F845000);//ML01
            // 0x0291365C: MOV x2, x21                | X2 = 1152921513971595520 (0x100000022E2EB900);//ML01
            // 0x02913660: MOV x20, x0                | X20 = 1152921504688103424 (0x1000000004D7E000);//ML01
            val_9 = val_6;
            // 0x02913664: LDR x3, [x8]               | X3 = public System.Void System.Func<System.Object, System.Object>::.ctor(object object, IntPtr method);
            // 0x02913668: BL #0x21cc05c              | .ctor(object:  val_1, method:  val_7);  
            val_6 = new System.Func<System.Object, System.Object>(object:  val_1, method:  val_7);
            label_12:
            // 0x0291366C: MOV x0, x20                | X0 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x02913670: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02913674: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02913678: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0291367C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02913680: RET                        |  return (System.Func<System.Object, System.Object>)typeof(System.Func<T, TResult>);
            return (System.Func<System.Object, System.Object>)val_9;
            //  |  // // {name=val_0, type=System.Func<System.Object, System.Object>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0291368C (43071116), len: 1328  VirtAddr: 0x0291368C RVA: 0x0291368C token: 100686612 methodIndex: 49135 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool CanConvertType(System.Type initialType, System.Type targetType, bool allowTypeNameToString)
        {
            //
            // Disasemble & Code
            //  | 
            var val_31;
            //  | 
            string val_32;
            // 0x0291368C: STP x24, x23, [sp, #-0x40]! | stack[1152921513971815904] = ???;  stack[1152921513971815912] = ???;  //  dest_result_addr=1152921513971815904 |  dest_result_addr=1152921513971815912
            // 0x02913690: STP x22, x21, [sp, #0x10]  | stack[1152921513971815920] = ???;  stack[1152921513971815928] = ???;  //  dest_result_addr=1152921513971815920 |  dest_result_addr=1152921513971815928
            // 0x02913694: STP x20, x19, [sp, #0x20]  | stack[1152921513971815936] = ???;  stack[1152921513971815944] = ???;  //  dest_result_addr=1152921513971815936 |  dest_result_addr=1152921513971815944
            // 0x02913698: STP x29, x30, [sp, #0x30]  | stack[1152921513971815952] = ???;  stack[1152921513971815960] = ???;  //  dest_result_addr=1152921513971815952 |  dest_result_addr=1152921513971815960
            // 0x0291369C: ADD x29, sp, #0x30         | X29 = (1152921513971815904 + 48) = 1152921513971815952 (0x100000022E321610);
            // 0x029136A0: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x029136A4: LDRB w8, [x22, #0xafc]     | W8 = (bool)static_value_037B8AFC;       
            // 0x029136A8: MOV w21, w3                | W21 = W3;//m1                           
            val_31 = W3;
            // 0x029136AC: MOV x19, x2                | X19 = allowTypeNameToString;//m1        
            val_32 = allowTypeNameToString;
            // 0x029136B0: MOV x20, x1                | X20 = targetType;//m1                   
            // 0x029136B4: TBNZ w8, #0, #0x29136d0    | if (static_value_037B8AFC == true) goto label_0;
            // 0x029136B8: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x029136BC: LDR x8, [x8, #0xe8]        | X8 = 0x2B92C48;                         
            // 0x029136C0: LDR w0, [x8]               | W0 = 0x21D7;                            
            // 0x029136C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x21D7, ????);     
            // 0x029136C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x029136CC: STRB w8, [x22, #0xafc]     | static_value_037B8AFC = true;            //  dest_result_addr=58428156
            label_0:
            // 0x029136D0: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x029136D4: LDR x8, [x8, #0xd10]       | X8 = (string**)(1152921513971730048)("initialType");
            // 0x029136D8: MOV x1, x20                | X1 = targetType;//m1                    
            // 0x029136DC: LDR x2, [x8]               | X2 = "initialType";                     
            // 0x029136E0: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  8663, parameterName:  targetType);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  8663, parameterName:  targetType);
            // 0x029136E4: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x029136E8: LDR x8, [x8, #0x518]       | X8 = (string**)(1152921513971730144)("targetType");
            // 0x029136EC: MOV x1, x19                | X1 = allowTypeNameToString;//m1         
            // 0x029136F0: LDR x2, [x8]               | X2 = "targetType";                      
            // 0x029136F4: BL #0x28fecf8              | Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  8663, parameterName:  val_32);
            Newtonsoft.Json.Utilities.ValidationUtils.ArgumentNotNull(value:  8663, parameterName:  val_32);
            // 0x029136F8: MOV x1, x19                | X1 = allowTypeNameToString;//m1         
            // 0x029136FC: BL #0x28fe064              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullableType(t:  8663);
            bool val_1 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullableType(t:  8663);
            // 0x02913700: TBZ w0, #0, #0x2913718     | if (val_1 == false) goto label_1;       
            if(val_1 == false)
            {
                goto label_1;
            }
            // 0x02913704: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913708: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0291370C: MOV x1, x19                | X1 = allowTypeNameToString;//m1         
            // 0x02913710: BL #0x17015f4              | X0 = System.Nullable.GetUnderlyingType(nullableType:  0);
            System.Type val_2 = System.Nullable.GetUnderlyingType(nullableType:  0);
            // 0x02913714: MOV x19, x0                | X19 = val_2;//m1                        
            val_32 = val_2;
            label_1:
            // 0x02913718: CMP x19, x20               | STATE = COMPARE(val_2, targetType)      
            // 0x0291371C: B.EQ #0x2913b9c            | if (val_32 == targetType) goto label_58;
            if(val_32 == targetType)
            {
                goto label_58;
            }
            // 0x02913720: ADRP x23, #0x3620000       | X23 = 56754176 (0x3620000);             
            // 0x02913724: LDR x23, [x23, #0x340]     | X23 = 1152921504609562624;              
            // 0x02913728: ADRP x24, #0x35c5000       | X24 = 56381440 (0x35C5000);             
            // 0x0291372C: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913730: LDR x24, [x24, #0x618]     | X24 = 1152921504607219712;              
            // 0x02913734: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913738: LDR x22, [x24]             | X22 = typeof(System.IConvertible);      
            // 0x0291373C: TBZ w8, #0, #0x291374c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x02913740: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913744: CBNZ w8, #0x291374c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x02913748: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x0291374C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913750: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913754: MOV x1, x22                | X1 = 1152921504607219712 (0x100000000005B000);//ML01
            // 0x02913758: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0291375C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x02913760: CBNZ x22, #0x2913768       | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x02913764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x02913768: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x0291376C: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x02913770: MOV x1, x20                | X1 = targetType;//m1                    
            // 0x02913774: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x02913778: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x0291377C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x02913780: TBZ w0, #0, #0x29137dc     | if ((val_3 & 0x1) == 0) goto label_6;   
            if((val_3 & 1) == 0)
            {
                goto label_6;
            }
            // 0x02913784: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913788: LDR x22, [x24]             | X22 = typeof(System.IConvertible);      
            // 0x0291378C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913790: TBZ w8, #0, #0x29137a0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x02913794: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913798: CBNZ w8, #0x29137a0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0291379C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_8:
            // 0x029137A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029137A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029137A8: MOV x1, x22                | X1 = 1152921504607219712 (0x100000000005B000);//ML01
            // 0x029137AC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029137B0: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x029137B4: CBNZ x22, #0x29137bc       | if (val_4 != null) goto label_9;        
            if(val_4 != null)
            {
                goto label_9;
            }
            // 0x029137B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_9:
            // 0x029137BC: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x029137C0: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x029137C4: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x029137C8: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x029137CC: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x029137D0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x029137D4: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            System.Type val_5 = val_4 & 1;
            // 0x029137D8: TBNZ w8, #0, #0x2913b9c    | if (((val_4 & 1) & 0x1) != 0) goto label_58;
            if((val_5 & 1) != 0)
            {
                goto label_58;
            }
            label_6:
            // 0x029137DC: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x029137E0: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x029137E4: LDR x8, [x8, #0xa00]       | X8 = 1152921504652693504;               
            // 0x029137E8: LDR x22, [x8]              | X22 = typeof(System.DateTime);          
            // 0x029137EC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029137F0: TBZ w8, #0, #0x2913800     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x029137F4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029137F8: CBNZ w8, #0x2913800        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x029137FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_12:
            // 0x02913800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913804: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913808: MOV x1, x22                | X1 = 1152921504652693504 (0x1000000002BB9000);//ML01
            // 0x0291380C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913810: CMP x0, x20                | STATE = COMPARE(val_6, targetType)      
            // 0x02913814: B.NE #0x2913854            | if (val_6 != targetType) goto label_13; 
            if(val_6 != targetType)
            {
                goto label_13;
            }
            // 0x02913818: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x0291381C: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913820: LDR x8, [x8, #0x2f8]       | X8 = 1152921504652853248;               
            // 0x02913824: LDR x22, [x8]              | X22 = typeof(System.DateTimeOffset);    
            // 0x02913828: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0291382C: TBZ w8, #0, #0x291383c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x02913830: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913834: CBNZ w8, #0x291383c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x02913838: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_15:
            // 0x0291383C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913844: MOV x1, x22                | X1 = 1152921504652853248 (0x1000000002BE0000);//ML01
            // 0x02913848: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0291384C: CMP x19, x0                | STATE = COMPARE(val_2, val_7)           
            // 0x02913850: B.EQ #0x2913b9c            | if (val_32 == val_7) goto label_58;     
            if(val_32 == val_7)
            {
                goto label_58;
            }
            label_13:
            // 0x02913854: ADRP x24, #0x3662000       | X24 = 57024512 (0x3662000);             
            // 0x02913858: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x0291385C: LDR x24, [x24, #0xd68]     | X24 = 1152921504654024704;              
            // 0x02913860: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913864: LDR x22, [x24]             | X22 = typeof(System.Guid);              
            // 0x02913868: TBZ w8, #0, #0x2913878     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x0291386C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913870: CBNZ w8, #0x2913878        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x02913874: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_18:
            // 0x02913878: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0291387C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913880: MOV x1, x22                | X1 = 1152921504654024704 (0x1000000002CFE000);//ML01
            // 0x02913884: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913888: CMP x0, x20                | STATE = COMPARE(val_8, targetType)      
            // 0x0291388C: B.NE #0x2913900            | if (val_8 != targetType) goto label_19; 
            if(val_8 != targetType)
            {
                goto label_19;
            }
            // 0x02913890: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913894: LDR x22, [x24]             | X22 = typeof(System.Guid);              
            // 0x02913898: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0291389C: TBZ w8, #0, #0x29138ac     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x029138A0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029138A4: CBNZ w8, #0x29138ac        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x029138A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_21:
            // 0x029138AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029138B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029138B4: MOV x1, x22                | X1 = 1152921504654024704 (0x1000000002CFE000);//ML01
            // 0x029138B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029138BC: CMP x19, x0                | STATE = COMPARE(val_2, val_9)           
            // 0x029138C0: B.EQ #0x2913b9c            | if (val_32 == val_9) goto label_58;     
            if(val_32 == val_9)
            {
                goto label_58;
            }
            // 0x029138C4: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x029138C8: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x029138CC: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x029138D0: LDR x22, [x8]              | X22 = typeof(System.String);            
            // 0x029138D4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029138D8: TBZ w8, #0, #0x29138e8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_24;
            // 0x029138DC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029138E0: CBNZ w8, #0x29138e8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
            // 0x029138E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_24:
            // 0x029138E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029138EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029138F0: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x029138F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029138F8: CMP x19, x0                | STATE = COMPARE(val_2, val_10)          
            // 0x029138FC: B.EQ #0x2913b9c            | if (val_32 == val_10) goto label_58;    
            if(val_32 == val_10)
            {
                goto label_58;
            }
            label_19:
            // 0x02913900: ADRP x24, #0x3631000       | X24 = 56823808 (0x3631000);             
            // 0x02913904: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913908: LDR x24, [x24, #0xb88]     | X24 = 1152921504857325568;              
            // 0x0291390C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913910: LDR x22, [x24]             | X22 = typeof(SerializableGuid);         
            // 0x02913914: TBZ w8, #0, #0x2913924     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x02913918: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0291391C: CBNZ w8, #0x2913924        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x02913920: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_27:
            // 0x02913924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913928: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0291392C: MOV x1, x22                | X1 = 1152921504857325568 (0x100000000EEE0000);//ML01
            // 0x02913930: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913934: CMP x0, x20                | STATE = COMPARE(val_11, targetType)     
            // 0x02913938: B.NE #0x29139ac            | if (val_11 != targetType) goto label_28;
            if(val_11 != targetType)
            {
                goto label_28;
            }
            // 0x0291393C: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913940: LDR x22, [x24]             | X22 = typeof(SerializableGuid);         
            // 0x02913944: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913948: TBZ w8, #0, #0x2913958     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x0291394C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913950: CBNZ w8, #0x2913958        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x02913954: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_30:
            // 0x02913958: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0291395C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913960: MOV x1, x22                | X1 = 1152921504857325568 (0x100000000EEE0000);//ML01
            // 0x02913964: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913968: CMP x19, x0                | STATE = COMPARE(val_2, val_12)          
            // 0x0291396C: B.EQ #0x2913b9c            | if (val_32 == val_12) goto label_58;    
            if(val_32 == val_12)
            {
                goto label_58;
            }
            // 0x02913970: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x02913974: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913978: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0291397C: LDR x22, [x8]              | X22 = typeof(System.String);            
            // 0x02913980: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913984: TBZ w8, #0, #0x2913994     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x02913988: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0291398C: CBNZ w8, #0x2913994        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x02913990: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_33:
            // 0x02913994: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913998: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0291399C: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x029139A0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029139A4: CMP x19, x0                | STATE = COMPARE(val_2, val_13)          
            // 0x029139A8: B.EQ #0x2913b9c            | if (val_32 == val_13) goto label_58;    
            if(val_32 == val_13)
            {
                goto label_58;
            }
            label_28:
            // 0x029139AC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x029139B0: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x029139B4: LDR x8, [x8, #0xac0]       | X8 = 1152921504609562624;               
            // 0x029139B8: LDR x22, [x8]              | X22 = typeof(System.Type);              
            // 0x029139BC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029139C0: TBZ w8, #0, #0x29139d0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x029139C4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029139C8: CBNZ w8, #0x29139d0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x029139CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_36:
            // 0x029139D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029139D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029139D8: MOV x1, x22                | X1 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x029139DC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029139E0: CMP x0, x20                | STATE = COMPARE(val_14, targetType)     
            // 0x029139E4: B.NE #0x2913a24            | if (val_14 != targetType) goto label_37;
            if(val_14 != targetType)
            {
                goto label_37;
            }
            // 0x029139E8: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x029139EC: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x029139F0: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x029139F4: LDR x22, [x8]              | X22 = typeof(System.String);            
            // 0x029139F8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029139FC: TBZ w8, #0, #0x2913a0c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_39;
            // 0x02913A00: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913A04: CBNZ w8, #0x2913a0c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
            // 0x02913A08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_39:
            // 0x02913A0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913A10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913A14: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x02913A18: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913A1C: CMP x19, x0                | STATE = COMPARE(val_2, val_15)          
            // 0x02913A20: B.EQ #0x2913b9c            | if (val_32 == val_15) goto label_58;    
            if(val_32 == val_15)
            {
                goto label_58;
            }
            label_37:
            // 0x02913A24: ADRP x24, #0x362b000       | X24 = 56799232 (0x362B000);             
            // 0x02913A28: LDR x24, [x24, #0xc10]     | X24 = 1152921504867069952;              
            // 0x02913A2C: LDR x0, [x24]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02913A30: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02913A34: TBZ w8, #0, #0x2913a44     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_42;
            // 0x02913A38: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02913A3C: CBNZ w8, #0x2913a44        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
            // 0x02913A40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_42:
            // 0x02913A44: MOV x1, x20                | X1 = targetType;//m1                    
            // 0x02913A48: BL #0x290e840              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  null);
            System.ComponentModel.TypeConverter val_16 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  null);
            // 0x02913A4C: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x02913A50: CBZ x22, #0x2913ae8        | if (val_16 == null) goto label_47;      
            if(val_16 == null)
            {
                goto label_47;
            }
            // 0x02913A54: LDR x0, [x24]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02913A58: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02913A5C: TBZ w8, #0, #0x2913a6c     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x02913A60: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02913A64: CBNZ w8, #0x2913a6c        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x02913A68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_45:
            // 0x02913A6C: MOV x1, x22                | X1 = val_16;//m1                        
            // 0x02913A70: BL #0x2913bbc              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.IsComponentConverter(converter:  null);
            bool val_17 = Newtonsoft.Json.Utilities.ConvertUtils.IsComponentConverter(converter:  null);
            // 0x02913A74: AND w8, w0, #1             | W8 = (val_17 & 1);                      
            bool val_18 = val_17;
            // 0x02913A78: TBNZ w8, #0, #0x2913ae8    | if ((val_17 & 1) == true) goto label_47;
            if(val_18 == true)
            {
                goto label_47;
            }
            // 0x02913A7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913A80: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x02913A84: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02913A88: BL #0x1ac8014              | X0 = val_16.CanConvertTo(destinationType:  val_32);
            bool val_19 = val_16.CanConvertTo(destinationType:  val_32);
            // 0x02913A8C: TBZ w0, #0, #0x2913ae8     | if (val_19 == false) goto label_47;     
            if(val_19 == false)
            {
                goto label_47;
            }
            // 0x02913A90: AND w8, w21, #1            | W8 = (W3 & 1);                          
            var val_20 = val_31 & 1;
            // 0x02913A94: TBNZ w8, #0, #0x2913b9c    | if (((W3 & 1) & 0x1) != 0) goto label_58;
            if((val_20 & 1) != 0)
            {
                goto label_58;
            }
            // 0x02913A98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913A9C: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x02913AA0: BL #0x16fb28c              | X0 = val_16.GetType();                  
            System.Type val_21 = val_16.GetType();
            // 0x02913AA4: ADRP x9, #0x3604000        | X9 = 56639488 (0x3604000);              
            // 0x02913AA8: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x02913AAC: LDR x9, [x9, #0x858]       | X9 = 1152921504672342016;               
            // 0x02913AB0: MOV x21, x0                | X21 = val_21;//m1                       
            val_31 = val_21;
            // 0x02913AB4: LDR x22, [x9]              | X22 = typeof(System.ComponentModel.TypeConverter);
            // 0x02913AB8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913ABC: TBZ w9, #0, #0x2913ad0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_50;
            // 0x02913AC0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913AC4: CBNZ w9, #0x2913ad0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
            // 0x02913AC8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x02913ACC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_50:
            // 0x02913AD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913AD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913AD8: MOV x1, x22                | X1 = 1152921504672342016 (0x1000000003E76000);//ML01
            // 0x02913ADC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_22 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913AE0: CMP x21, x0                | STATE = COMPARE(val_21, val_22)         
            // 0x02913AE4: B.NE #0x2913b9c            | if (val_31 != val_22) goto label_58;    
            if(val_31 != val_22)
            {
                goto label_58;
            }
            label_47:
            // 0x02913AE8: LDR x0, [x24]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02913AEC: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02913AF0: TBZ w8, #0, #0x2913b00     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_53;
            // 0x02913AF4: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02913AF8: CBNZ w8, #0x2913b00        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
            // 0x02913AFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_53:
            // 0x02913B00: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02913B04: BL #0x290e840              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  null);
            System.ComponentModel.TypeConverter val_23 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  null);
            // 0x02913B08: MOV x21, x0                | X21 = val_23;//m1                       
            val_31 = val_23;
            // 0x02913B0C: CBZ x21, #0x2913b50        | if (val_23 == null) goto label_57;      
            if(val_31 == null)
            {
                goto label_57;
            }
            // 0x02913B10: LDR x0, [x24]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02913B14: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02913B18: TBZ w8, #0, #0x2913b28     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_56;
            // 0x02913B1C: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02913B20: CBNZ w8, #0x2913b28        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_56;
            // 0x02913B24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_56:
            // 0x02913B28: MOV x1, x21                | X1 = val_23;//m1                        
            // 0x02913B2C: BL #0x2913bbc              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.IsComponentConverter(converter:  null);
            bool val_24 = Newtonsoft.Json.Utilities.ConvertUtils.IsComponentConverter(converter:  null);
            // 0x02913B30: AND w8, w0, #1             | W8 = (val_24 & 1);                      
            bool val_25 = val_24;
            // 0x02913B34: TBNZ w8, #0, #0x2913b50    | if ((val_24 & 1) == true) goto label_57;
            if(val_25 == true)
            {
                goto label_57;
            }
            // 0x02913B38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913B3C: MOV x0, x21                | X0 = val_23;//m1                        
            // 0x02913B40: MOV x1, x20                | X1 = targetType;//m1                    
            // 0x02913B44: BL #0x1ac7ffc              | X0 = val_23.CanConvertFrom(sourceType:  targetType);
            bool val_26 = val_31.CanConvertFrom(sourceType:  targetType);
            // 0x02913B48: AND w8, w0, #1             | W8 = (val_26 & 1);                      
            bool val_27 = val_26;
            // 0x02913B4C: TBNZ w8, #0, #0x2913b9c    | if ((val_26 & 1) == true) goto label_58;
            if(val_27 == true)
            {
                goto label_58;
            }
            label_57:
            // 0x02913B50: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x02913B54: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x02913B58: LDR x8, [x8, #0x650]       | X8 = 1152921504652640256;               
            // 0x02913B5C: LDR x21, [x8]              | X21 = typeof(System.DBNull);            
            val_31 = null;
            // 0x02913B60: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913B64: TBZ w8, #0, #0x2913b74     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x02913B68: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913B6C: CBNZ w8, #0x2913b74        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x02913B70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_60:
            // 0x02913B74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913B78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913B7C: MOV x1, x21                | X1 = 1152921504652640256 (0x1000000002BAC000);//ML01
            // 0x02913B80: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913B84: CMP x0, x20                | STATE = COMPARE(val_28, targetType)     
            // 0x02913B88: B.NE #0x2913bb4            | if (val_28 != targetType) goto label_62;
            if(val_28 != targetType)
            {
                goto label_62;
            }
            // 0x02913B8C: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02913B90: BL #0x2913c3c              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullable(t:  System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()));
            bool val_29 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullable(t:  val_28);
            // 0x02913B94: AND w8, w0, #1             | W8 = (val_29 & 1);                      
            bool val_30 = val_29;
            // 0x02913B98: TBZ w8, #0, #0x2913bb4     | if ((val_29 & 1) == false) goto label_62;
            if(val_30 == false)
            {
                goto label_62;
            }
            label_58:
            // 0x02913B9C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            label_63:
            // 0x02913BA0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02913BA4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02913BA8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02913BAC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02913BB0: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_62:
            // 0x02913BB4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x02913BB8: B #0x2913ba0               |  goto label_63;                         
            goto label_63;
        
        }
        //
        // Offset in libil2cpp.so: 0x02913BBC (43072444), len: 128  VirtAddr: 0x02913BBC RVA: 0x02913BBC token: 100686613 methodIndex: 49136 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool IsComponentConverter(System.ComponentModel.TypeConverter converter)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x02913BBC: STP x20, x19, [sp, #-0x20]! | stack[1152921513972013952] = ???;  stack[1152921513972013960] = ???;  //  dest_result_addr=1152921513972013952 |  dest_result_addr=1152921513972013960
            // 0x02913BC0: STP x29, x30, [sp, #0x10]  | stack[1152921513972013968] = ???;  stack[1152921513972013976] = ???;  //  dest_result_addr=1152921513972013968 |  dest_result_addr=1152921513972013976
            // 0x02913BC4: ADD x29, sp, #0x10         | X29 = (1152921513972013952 + 16) = 1152921513972013968 (0x100000022E351B90);
            // 0x02913BC8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x02913BCC: LDRB w8, [x20, #0xafd]     | W8 = (bool)static_value_037B8AFD;       
            // 0x02913BD0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x02913BD4: TBNZ w8, #0, #0x2913bf0    | if (static_value_037B8AFD == true) goto label_0;
            // 0x02913BD8: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x02913BDC: LDR x8, [x8, #0x190]       | X8 = 0x2B92C70;                         
            // 0x02913BE0: LDR w0, [x8]               | W0 = 0x21E1;                            
            // 0x02913BE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E1, ????);     
            // 0x02913BE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02913BEC: STRB w8, [x20, #0xafd]     | static_value_037B8AFD = true;            //  dest_result_addr=58428157
            label_0:
            // 0x02913BF0: CBZ x19, #0x2913c14        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x02913BF4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x02913BF8: LDR x8, [x8, #0x740]       | X8 = 1152921504669519872;               
            // 0x02913BFC: LDR x9, [x19]              | X9 = X1;                                
            // 0x02913C00: LDR x8, [x8]               | X8 = typeof(System.ComponentModel.ComponentConverter);
            // 0x02913C04: LDRB w11, [x9, #0x104]     | W11 = X1 + 260;                         
            // 0x02913C08: LDRB w10, [x8, #0x104]     | W10 = System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x02913C0C: CMP w11, w10               | STATE = COMPARE(X1 + 260, System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x02913C10: B.HS #0x2913c1c            | if (X1 + 260 >= System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            label_1:
            // 0x02913C14: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_2 = 0;
            // 0x02913C18: B #0x2913c30               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x02913C1C: LDR x9, [x9, #0xb0]        | X9 = X1 + 176;                          
            // 0x02913C20: ADD x9, x9, x10, lsl #3    | X9 = (X1 + 176 + (System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) 
            // 0x02913C24: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x02913C28: CMP x9, x8                 | STATE = COMPARE((X1 + 176 + (System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.ComponentModel.ComponentConverter))
            // 0x02913C2C: CSET w0, eq                | W0 = (X1 + 176 + (System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? 1 : 0;
            var val_1 = (((X1 + 176 + (System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? 1 : 0;
            label_3:
            // 0x02913C30: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x02913C34: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x02913C38: RET                        |  return (System.Boolean)(X1 + 176 + (System.ComponentModel.ComponentConverter.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FDD64C VirtAddr: 0x00FDD64C -RVA: 0x00FDD64C 
        // -ConvertUtils.Convert<object>
        //
        //
        // Offset in libil2cpp.so: 0x00FDD64C (16635468), len: 184  VirtAddr: 0x00FDD64C RVA: 0x00FDD64C token: 100686614 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T Convert<T>(object initialValue)
        {
            //
            // Disasemble & Code
            // 0x00FDD64C: STP x22, x21, [sp, #-0x30]! | stack[1152921513972138224] = ???;  stack[1152921513972138232] = ???;  //  dest_result_addr=1152921513972138224 |  dest_result_addr=1152921513972138232
            // 0x00FDD650: STP x20, x19, [sp, #0x10]  | stack[1152921513972138240] = ???;  stack[1152921513972138248] = ???;  //  dest_result_addr=1152921513972138240 |  dest_result_addr=1152921513972138248
            // 0x00FDD654: STP x29, x30, [sp, #0x20]  | stack[1152921513972138256] = ???;  stack[1152921513972138264] = ???;  //  dest_result_addr=1152921513972138256 |  dest_result_addr=1152921513972138264
            // 0x00FDD658: ADD x29, sp, #0x20         | X29 = (1152921513972138224 + 32) = 1152921513972138256 (0x100000022E370110);
            // 0x00FDD65C: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x00FDD660: LDRB w8, [x21, #0x42e]     | W8 = (bool)static_value_0373542E;       
            // 0x00FDD664: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00FDD668: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FDD66C: TBNZ w8, #0, #0xfdd688     | if (static_value_0373542E == true) goto label_0;
            // 0x00FDD670: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00FDD674: LDR x8, [x8, #0x5c0]       | X8 = 0x2B92C50;                         
            // 0x00FDD678: LDR w0, [x8]               | W0 = 0x21D9;                            
            // 0x00FDD67C: BL #0x2782188              | X0 = sub_2782188( ?? 0x21D9, ????);     
            // 0x00FDD680: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FDD684: STRB w8, [x21, #0x42e]     | static_value_0373542E = true;            //  dest_result_addr=57889838
            label_0:
            // 0x00FDD688: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00FDD68C: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00FDD690: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00FDD694: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00FDD698: TBZ w8, #0, #0xfdd6a8      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00FDD69C: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD6A0: CBNZ w8, #0xfdd6a8         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00FDD6A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_2:
            // 0x00FDD6A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD6AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDD6B0: BL #0x1c42254              | X0 = System.Globalization.CultureInfo.get_CurrentCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.CurrentCulture;
            // 0x00FDD6B4: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00FDD6B8: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x00FDD6BC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00FDD6C0: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x00FDD6C4: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x00FDD6C8: TBZ w9, #0, #0xfdd6dc      | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00FDD6CC: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD6D0: CBNZ w9, #0xfdd6dc         | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00FDD6D4: MOV x0, x8                 | X0 = 1152921504867069952 (0x100000000F82B000);//ML01
            // 0x00FDD6D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_4:
            // 0x00FDD6DC: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00FDD6E0: MOV x1, x19                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FDD6E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD6E8: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x00FDD6EC: LDR x3, [x8]               | X3 = X2 + 48;                           
            // 0x00FDD6F0: LDR x4, [x3]               | X4 = X2 + 48;                           
            // 0x00FDD6F4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00FDD6F8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00FDD6FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00FDD700: BR x4                      | goto X2 + 48;                           
            goto X2 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FDD704 VirtAddr: 0x00FDD704 -RVA: 0x00FDD704 
        // -ConvertUtils.Convert<object>
        //
        //
        // Offset in libil2cpp.so: 0x00FDD704 (16635652), len: 320  VirtAddr: 0x00FDD704 RVA: 0x00FDD704 token: 100686615 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T Convert<T>(object initialValue, System.Globalization.CultureInfo culture)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x00FDD704: STP x22, x21, [sp, #-0x30]! | stack[1152921513972274800] = ???;  stack[1152921513972274808] = ???;  //  dest_result_addr=1152921513972274800 |  dest_result_addr=1152921513972274808
            // 0x00FDD708: STP x20, x19, [sp, #0x10]  | stack[1152921513972274816] = ???;  stack[1152921513972274824] = ???;  //  dest_result_addr=1152921513972274816 |  dest_result_addr=1152921513972274824
            // 0x00FDD70C: STP x29, x30, [sp, #0x20]  | stack[1152921513972274832] = ???;  stack[1152921513972274840] = ???;  //  dest_result_addr=1152921513972274832 |  dest_result_addr=1152921513972274840
            // 0x00FDD710: ADD x29, sp, #0x20         | X29 = (1152921513972274800 + 32) = 1152921513972274832 (0x100000022E391690);
            // 0x00FDD714: SUB sp, sp, #0x10          | SP = (1152921513972274800 - 16) = 1152921513972274784 (0x100000022E391660);
            // 0x00FDD718: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x00FDD71C: LDRB w8, [x22, #0x42f]     | W8 = (bool)static_value_0373542F;       
            // 0x00FDD720: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00FDD724: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FDD728: MOV x21, x1                | X21 = culture;//m1                      
            // 0x00FDD72C: TBNZ w8, #0, #0xfdd748     | if (static_value_0373542F == true) goto label_0;
            // 0x00FDD730: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00FDD734: LDR x8, [x8, #0xa60]       | X8 = 0x2B92C54;                         
            // 0x00FDD738: LDR w0, [x8]               | W0 = 0x21DA;                            
            // 0x00FDD73C: BL #0x2782188              | X0 = sub_2782188( ?? 0x21DA, ????);     
            // 0x00FDD740: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FDD744: STRB w8, [x22, #0x42f]     | static_value_0373542F = true;            //  dest_result_addr=57889839
            label_0:
            // 0x00FDD748: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x00FDD74C: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD750: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x00FDD754: LDR x22, [x8]              | X22 = X3 + 48;                          
            // 0x00FDD758: LDR x0, [x9]               | X0 = typeof(System.Type);               
            // 0x00FDD75C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00FDD760: TBZ w8, #0, #0xfdd770      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00FDD764: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD768: CBNZ w8, #0xfdd770         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00FDD76C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00FDD770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD774: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FDD778: MOV x1, x22                | X1 = X3 + 48;//m1                       
            // 0x00FDD77C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00FDD780: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00FDD784: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x00FDD788: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00FDD78C: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x00FDD790: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x00FDD794: TBZ w9, #0, #0xfdd7a8      | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00FDD798: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD79C: CBNZ w9, #0xfdd7a8         | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00FDD7A0: MOV x0, x8                 | X0 = 1152921504867069952 (0x100000000F82B000);//ML01
            // 0x00FDD7A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_4:
            // 0x00FDD7A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD7AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00FDD7B0: MOV x1, x21                | X1 = culture;//m1                       
            // 0x00FDD7B4: MOV x2, x20                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FDD7B8: MOV x3, x22                | X3 = val_1;//m1                         
            // 0x00FDD7BC: BL #0x2913cbc              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.Convert(initialValue:  0, culture:  culture, targetType:  __RuntimeMethodHiddenParam);
            object val_2 = Newtonsoft.Json.Utilities.ConvertUtils.Convert(initialValue:  0, culture:  culture, targetType:  __RuntimeMethodHiddenParam);
            // 0x00FDD7C0: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD7C4: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00FDD7C8: LDR x19, [x8, #8]          | X19 = X3 + 48 + 8;                      
            // 0x00FDD7CC: MOV x0, x19                | X0 = X3 + 48 + 8;//m1                   
            // 0x00FDD7D0: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00FDD7D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_4 = 0;
            // 0x00FDD7D8: CBZ x20, #0xfdd81c         | if (val_2 == null) goto label_6;        
            if(val_2 == null)
            {
                goto label_6;
            }
            // 0x00FDD7DC: MOV x0, x20                | X0 = val_2;//m1                         
            val_4 = val_2;
            // 0x00FDD7E0: MOV x1, x19                | X1 = X3 + 48 + 8;//m1                   
            // 0x00FDD7E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00FDD7E8: CBNZ x0, #0xfdd81c         | if (val_2 != null) goto label_6;        
            if(val_4 != null)
            {
                goto label_6;
            }
            // 0x00FDD7EC: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x00FDD7F0: MOV x1, x19                | X1 = X3 + 48 + 8;//m1                   
            // 0x00FDD7F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00FDD7F8: ADD x8, sp, #8             | X8 = (1152921513972274784 + 8) = 1152921513972274792 (0x100000022E391668);
            // 0x00FDD7FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00FDD800: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513972262848]
            // 0x00FDD804: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x00FDD808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDD80C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x00FDD810: ADD x0, sp, #8             | X0 = (1152921513972274784 + 8) = 1152921513972274792 (0x100000022E391668);
            // 0x00FDD814: BL #0x299a140              | 
            // 0x00FDD818: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_4 = 0;
            label_6:
            // 0x00FDD81C: SUB sp, x29, #0x20         | SP = (1152921513972274832 - 32) = 1152921513972274800 (0x100000022E391670);
            // 0x00FDD820: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00FDD824: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00FDD828: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00FDD82C: RET                        |  return (System.Object)null;            
            return (object)val_4;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x00FDD830: MOV x19, x0                | 
            // 0x00FDD834: ADD x0, sp, #8             | 
            // 0x00FDD838: BL #0x299a140              | 
            // 0x00FDD83C: MOV x0, x19                | 
            // 0x00FDD840: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x02913CBC (43072700), len: 3152  VirtAddr: 0x02913CBC RVA: 0x02913CBC token: 100686616 methodIndex: 49137 delegateWrapperIndex: 0 methodInvoker: 0
        public static object Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_30;
            //  | 
            var val_32;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            object val_50;
            //  | 
            var val_51;
            //  | 
            bool val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            //  | 
            System.Type val_62;
            //  | 
            var val_63;
            //  | 
            var val_64;
            //  | 
            var val_65;
            //  | 
            var val_66;
            //  | 
            System.Type val_67;
            //  | 
            var val_68;
            //  | 
            var val_69;
            //  | 
            var val_70;
            //  | 
            var val_71;
            //  | 
            var val_72;
            //  | 
            var val_73;
            //  | 
            var val_74;
            //  | 
            var val_75;
            //  | 
            var val_76;
            //  | 
            var val_77;
            //  | 
            var val_78;
            //  | 
            var val_79;
            //  | 
            var val_80;
            //  | 
            var val_81;
            //  | 
            var val_82;
            //  | 
            var val_83;
            //  | 
            var val_84;
            //  | 
            var val_85;
            //  | 
            var val_86;
            //  | 
            SerializableGuid val_87;
            //  | 
            string val_88;
            //  | 
            string val_89;
            //  | 
            var val_90;
            //  | 
            string val_91;
            //  | 
            var val_92;
            //  | 
            var val_93;
            //  | 
            var val_94;
            //  | 
            var val_95;
            //  | 
            var val_96;
            //  | 
            var val_97;
            // 0x02913CBC: STP x26, x25, [sp, #-0x50]! | stack[1152921513972490800] = ???;  stack[1152921513972490808] = ???;  //  dest_result_addr=1152921513972490800 |  dest_result_addr=1152921513972490808
            // 0x02913CC0: STP x24, x23, [sp, #0x10]  | stack[1152921513972490816] = ???;  stack[1152921513972490824] = ???;  //  dest_result_addr=1152921513972490816 |  dest_result_addr=1152921513972490824
            // 0x02913CC4: STP x22, x21, [sp, #0x20]  | stack[1152921513972490832] = ???;  stack[1152921513972490840] = ???;  //  dest_result_addr=1152921513972490832 |  dest_result_addr=1152921513972490840
            // 0x02913CC8: STP x20, x19, [sp, #0x30]  | stack[1152921513972490848] = ???;  stack[1152921513972490856] = ???;  //  dest_result_addr=1152921513972490848 |  dest_result_addr=1152921513972490856
            // 0x02913CCC: STP x29, x30, [sp, #0x40]  | stack[1152921513972490864] = ???;  stack[1152921513972490872] = ???;  //  dest_result_addr=1152921513972490864 |  dest_result_addr=1152921513972490872
            // 0x02913CD0: ADD x29, sp, #0x40         | X29 = (1152921513972490800 + 64) = 1152921513972490864 (0x100000022E3C6270);
            // 0x02913CD4: SUB sp, sp, #0x70          | SP = (1152921513972490800 - 112) = 1152921513972490688 (0x100000022E3C61C0);
            // 0x02913CD8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x02913CDC: LDRB w8, [x21, #0xafe]     | W8 = (bool)static_value_037B8AFE;       
            // 0x02913CE0: MOV x19, x3                | X19 = X3;//m1                           
            val_50 = X3;
            // 0x02913CE4: MOV x22, x2                | X22 = targetType;//m1                   
            val_51 = targetType;
            // 0x02913CE8: MOV x20, x1                | X20 = culture;//m1                      
            val_52 = culture;
            // 0x02913CEC: TBNZ w8, #0, #0x2913d08    | if (static_value_037B8AFE == true) goto label_0;
            // 0x02913CF0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x02913CF4: LDR x8, [x8, #0xf20]       | X8 = 0x2B92C4C;                         
            // 0x02913CF8: LDR w0, [x8]               | W0 = 0x21D8;                            
            // 0x02913CFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x21D8, ????);     
            // 0x02913D00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02913D04: STRB w8, [x21, #0xafe]     | static_value_037B8AFE = true;            //  dest_result_addr=58428158
            label_0:
            // 0x02913D08: CBZ x20, #0x291465c        | if (culture == null) goto label_1;      
            if(val_52 == null)
            {
                goto label_1;
            }
            // 0x02913D0C: MOV x1, x19                | X1 = X3;//m1                            
            // 0x02913D10: BL #0x28fe064              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullableType(t:  8664);
            bool val_1 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullableType(t:  8664);
            // 0x02913D14: TBZ w0, #0, #0x2913d2c     | if (val_1 == false) goto label_2;       
            if(val_1 == false)
            {
                goto label_2;
            }
            // 0x02913D18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913D1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913D20: MOV x1, x19                | X1 = X3;//m1                            
            // 0x02913D24: BL #0x17015f4              | X0 = System.Nullable.GetUnderlyingType(nullableType:  0);
            System.Type val_2 = System.Nullable.GetUnderlyingType(nullableType:  0);
            // 0x02913D28: MOV x19, x0                | X19 = val_2;//m1                        
            val_50 = val_2;
            label_2:
            // 0x02913D2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913D30: MOV x0, x20                | X0 = culture;//m1                       
            // 0x02913D34: BL #0x16fb28c              | X0 = culture.GetType();                 
            System.Type val_3 = val_52.GetType();
            // 0x02913D38: MOV x21, x0                | X21 = val_3;//m1                        
            val_53 = val_3;
            // 0x02913D3C: CMP x19, x21               | STATE = COMPARE(val_2, val_3)           
            // 0x02913D40: B.EQ #0x291439c            | if (val_50 == val_53) goto label_73;    
            if(val_50 == val_53)
            {
                goto label_73;
            }
            // 0x02913D44: ADRP x24, #0x35d6000       | X24 = 56451072 (0x35D6000);             
            // 0x02913D48: LDR x24, [x24, #0xe38]     | X24 = 1152921504608284672;              
            // 0x02913D4C: LDR x9, [x20]              | X9 = typeof(System.Globalization.CultureInfo);
            // 0x02913D50: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x02913D54: CMP x9, x8                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02913D58: B.NE #0x2913e50            | if (typeof(System.Globalization.CultureInfo) != null) goto label_8;
            if(null != null)
            {
                goto label_8;
            }
            // 0x02913D5C: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x02913D60: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            val_54 = 1152921504609562624;
            // 0x02913D64: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02913D68: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x02913D6C: LDR x8, [x8, #0xac0]       | X8 = 1152921504609562624;               
            // 0x02913D70: LDR x23, [x8]              | X23 = typeof(System.Type);              
            // 0x02913D74: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913D78: TBZ w8, #0, #0x2913d88     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x02913D7C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913D80: CBNZ w8, #0x2913d88        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x02913D84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_6:
            // 0x02913D88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913D8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913D90: MOV x1, x23                | X1 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x02913D94: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913D98: MOV x23, x0                | X23 = val_4;//m1                        
            val_55 = val_4;
            // 0x02913D9C: CBNZ x23, #0x2913da4       | if (val_4 != null) goto label_7;        
            if(val_55 != null)
            {
                goto label_7;
            }
            // 0x02913DA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_7:
            // 0x02913DA4: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x02913DA8: MOV x0, x23                | X0 = val_4;//m1                         
            // 0x02913DAC: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02913DB0: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x02913DB4: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x02913DB8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x02913DBC: TBZ w0, #0, #0x2913e50     | if ((val_4 & 0x1) == 0) goto label_8;   
            if((val_55 & 1) == 0)
            {
                goto label_8;
            }
            // 0x02913DC0: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x02913DC4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913DC8: TBZ w8, #0, #0x2913dd8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x02913DCC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913DD0: CBNZ w8, #0x2913dd8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x02913DD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_10:
            // 0x02913DD8: LDR x1, [x24]              | X1 = typeof(System.String);             
            // 0x02913DDC: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            // 0x02913DE0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02913DE4: B.EQ #0x2913e10            | if (typeof(System.Globalization.CultureInfo) == null) goto label_11;
            if(null == null)
            {
                goto label_11;
            }
            // 0x02913DE8: LDR x0, [x8, #0x30]        | X0 = System.Globalization.CultureInfo.__il2cppRuntimeField_element_class;
            // 0x02913DEC: ADD x8, sp, #0x40          | X8 = (1152921513972490688 + 64) = 1152921513972490752 (0x100000022E3C6200);
            // 0x02913DF0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Globalization.CultureInfo.__il2cppRuntimeField_element_class, ????);
            // 0x02913DF4: LDR x0, [sp, #0x40]        | X0 = val_5;                              //  find_add[1152921513972478880]
            // 0x02913DF8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x02913DFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913E00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x02913E04: ADD x0, sp, #0x40          | X0 = (1152921513972490688 + 64) = 1152921513972490752 (0x100000022E3C6200);
            // 0x02913E08: BL #0x299a140              | 
            // 0x02913E0C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_56 = 0;
            label_11:
            // 0x02913E10: ADRP x1, #0x2bc3000        | X1 = 45887488 (0x2BC3000);              
            // 0x02913E14: ADD x1, x1, #0x427         | X1 = (45887488 + 1063) = 45888551 (0x02BC3427);
            // 0x02913E18: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x02913E1C: BL #0x27a49f0              | X0 = sub_27A49F0( ?? 0x0, ????);        
            // 0x02913E20: MOV x1, x0                 | X1 = 0 (0x0);//ML01                     
            // 0x02913E24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913E28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x02913E2C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x02913E30: BL #0x1b6d7cc              | X0 = System.Type.GetType(typeName:  0, throwOnError:  false);
            System.Type val_6 = System.Type.GetType(typeName:  0, throwOnError:  false);
            // 0x02913E34: CBNZ x0, #0x2914398        | if (val_6 != null) goto label_13;       
            if(val_6 != null)
            {
                goto label_13;
            }
            // 0x02913E38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913E3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x02913E40: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x02913E44: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x02913E48: BL #0x1b6d7cc              | X0 = System.Type.GetType(typeName:  0, throwOnError:  false);
            System.Type val_7 = System.Type.GetType(typeName:  0, throwOnError:  false);
            // 0x02913E4C: B #0x2914398               |  goto label_13;                         
            goto label_13;
            label_8:
            // 0x02913E50: CBNZ x19, #0x2913e58       | if (val_2 != null) goto label_14;       
            if(val_50 != null)
            {
                goto label_14;
            }
            // 0x02913E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_14:
            // 0x02913E58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913E5C: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x02913E60: BL #0x1b6d240              | X0 = val_2.get_IsInterface();           
            bool val_8 = val_50.IsInterface;
            // 0x02913E64: AND w8, w0, #1             | W8 = (val_8 & 1);                       
            bool val_9 = val_8;
            // 0x02913E68: TBNZ w8, #0, #0x2914560    | if ((val_8 & 1) == true) goto label_18; 
            if(val_9 == true)
            {
                goto label_18;
            }
            // 0x02913E6C: CBNZ x19, #0x2913e74       | if (val_2 != null) goto label_16;       
            if(val_50 != null)
            {
                goto label_16;
            }
            // 0x02913E70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_16:
            // 0x02913E74: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x02913E78: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x02913E7C: LDR x9, [x8, #0x740]       | X9 = typeof(System.Type).__il2cppRuntimeField_740;
            // 0x02913E80: LDR x1, [x8, #0x748]       | X1 = typeof(System.Type).__il2cppRuntimeField_748;
            // 0x02913E84: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_740();
            // 0x02913E88: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            System.Type val_10 = val_50 & 1;
            // 0x02913E8C: TBNZ w8, #0, #0x2914560    | if (((val_2 & 1) & 0x1) != 0) goto label_18;
            if((val_10 & 1) != 0)
            {
                goto label_18;
            }
            // 0x02913E90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913E94: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x02913E98: BL #0x1b6d1a8              | X0 = val_2.get_IsAbstract();            
            bool val_11 = val_50.IsAbstract;
            // 0x02913E9C: TBNZ w0, #0, #0x2914560    | if (val_11 == true) goto label_18;      
            if(val_11 == true)
            {
                goto label_18;
            }
            // 0x02913EA0: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x02913EA4: LDR x8, [x8, #0xd48]       | X8 = 1152921504607219712;               
            // 0x02913EA8: MOV x0, x20                | X0 = culture;//m1                       
            // 0x02913EAC: LDR x1, [x8]               | X1 = typeof(System.IConvertible);       
            // 0x02913EB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? culture, ????);    
            // 0x02913EB4: CBZ x0, #0x2913fbc         | if (culture == null) goto label_23;     
            if(val_52 == null)
            {
                goto label_23;
            }
            // 0x02913EB8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x02913EBC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x02913EC0: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x02913EC4: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x02913EC8: LDR x8, [x8, #0x618]       | X8 = 1152921504607219712;               
            // 0x02913ECC: LDR x23, [x8]              | X23 = typeof(System.IConvertible);      
            // 0x02913ED0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913ED4: TBZ w8, #0, #0x2913ee4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x02913ED8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913EDC: CBNZ w8, #0x2913ee4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x02913EE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_21:
            // 0x02913EE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913EE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02913EEC: MOV x1, x23                | X1 = 1152921504607219712 (0x100000000005B000);//ML01
            // 0x02913EF0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02913EF4: MOV x23, x0                | X23 = val_12;//m1                       
            val_58 = val_12;
            // 0x02913EF8: CBNZ x23, #0x2913f00       | if (val_12 != null) goto label_22;      
            if(val_58 != null)
            {
                goto label_22;
            }
            // 0x02913EFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_22:
            // 0x02913F00: LDR x8, [x23]              | X8 = typeof(System.Type);               
            // 0x02913F04: MOV x0, x23                | X0 = val_12;//m1                        
            // 0x02913F08: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02913F0C: LDR x9, [x8, #0x3e0]       | X9 = typeof(System.Type).__il2cppRuntimeField_3E0;
            // 0x02913F10: LDR x2, [x8, #0x3e8]       | X2 = typeof(System.Type).__il2cppRuntimeField_3E8;
            // 0x02913F14: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_3E0();
            // 0x02913F18: TBZ w0, #0, #0x2913fbc     | if ((val_12 & 0x1) == 0) goto label_23; 
            if((val_58 & 1) == 0)
            {
                goto label_23;
            }
            // 0x02913F1C: CBNZ x19, #0x2913f24       | if (val_2 != null) goto label_24;       
            if(val_50 != null)
            {
                goto label_24;
            }
            // 0x02913F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_24:
            // 0x02913F24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02913F28: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x02913F2C: BL #0x1b6d294              | X0 = val_2.get_IsEnum();                
            bool val_13 = val_50.IsEnum;
            // 0x02913F30: TBZ w0, #0, #0x291420c     | if (val_13 == false) goto label_29;     
            if(val_13 == false)
            {
                goto label_29;
            }
            // 0x02913F34: LDR x8, [x24]              | X8 = typeof(System.String);             
            // 0x02913F38: LDR x9, [x20]              | X9 = typeof(System.Globalization.CultureInfo);
            // 0x02913F3C: CMP x9, x8                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02913F40: B.EQ #0x29143bc            | if (typeof(System.Globalization.CultureInfo) == null) goto label_26;
            if(null == null)
            {
                goto label_26;
            }
            // 0x02913F44: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x02913F48: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x02913F4C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02913F50: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02913F54: TBZ w8, #0, #0x2913f64     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x02913F58: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02913F5C: CBNZ w8, #0x2913f64        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x02913F60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_28:
            // 0x02913F64: MOV x1, x20                | X1 = culture;//m1                       
            // 0x02913F68: BL #0x291490c              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.IsInteger(value:  null);
            bool val_14 = Newtonsoft.Json.Utilities.ConvertUtils.IsInteger(value:  null);
            // 0x02913F6C: TBZ w0, #0, #0x291420c     | if (val_14 == false) goto label_29;     
            if(val_14 == false)
            {
                goto label_29;
            }
            // 0x02913F70: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x02913F74: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x02913F78: LDR x0, [x8]               | X0 = typeof(System.Enum);               
            // 0x02913F7C: LDRB w8, [x0, #0x10a]      | W8 = System.Enum.__il2cppRuntimeField_10A;
            // 0x02913F80: TBZ w8, #0, #0x2913f90     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x02913F84: LDR w8, [x0, #0xbc]        | W8 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x02913F88: CBNZ w8, #0x2913f90        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x02913F8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_31:
            // 0x02913F90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02913F94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x02913F98: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02913F9C: MOV x2, x20                | X2 = culture;//m1                       
            // 0x02913FA0: SUB sp, x29, #0x40         | SP = (1152921513972490864 - 64) = 1152921513972490800 (0x100000022E3C6230);
            // 0x02913FA4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x02913FA8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x02913FAC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x02913FB0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x02913FB4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x02913FB8: B #0x1c39c04               | return System.Enum.ToObject(enumType:  0, value:  val_50);
            return System.Enum.ToObject(enumType:  0, value:  val_50);
            label_23:
            // 0x02913FBC: ADRP x25, #0x364f000       | X25 = 56946688 (0x364F000);             
            // 0x02913FC0: LDR x25, [x25, #0x9e0]     | X25 = 1152921504652693504;              
            val_59 = 1152921504652693504;
            // 0x02913FC4: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            // 0x02913FC8: LDR x9, [x25]              | X9 = typeof(System.DateTime);           
            // 0x02913FCC: CMP x8, x9                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.DateTime))
            // 0x02913FD0: B.NE #0x291401c            | if (typeof(System.Globalization.CultureInfo) != null) goto label_32;
            if(null != null)
            {
                goto label_32;
            }
            // 0x02913FD4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x02913FD8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x02913FDC: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x02913FE0: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x02913FE4: LDR x8, [x8, #0x2f8]       | X8 = 1152921504652853248;               
            // 0x02913FE8: LDR x23, [x8]              | X23 = typeof(System.DateTimeOffset);    
            val_55 = null;
            // 0x02913FEC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02913FF0: TBZ w8, #0, #0x2914000     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x02913FF4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02913FF8: CBNZ w8, #0x2914000        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x02913FFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x02914000: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914004: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_61 = 0;
            // 0x02914008: MOV x1, x23                | X1 = 1152921504652853248 (0x1000000002BE0000);//ML01
            // 0x0291400C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02914010: CMP x19, x0                | STATE = COMPARE(val_2, val_15)          
            // 0x02914014: B.EQ #0x29142dc            | if (val_50 == val_15) goto label_35;    
            if(val_50 == val_15)
            {
                goto label_35;
            }
            // 0x02914018: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            label_32:
            // 0x0291401C: LDR x9, [x24]              | X9 = typeof(System.String);             
            // 0x02914020: CMP x8, x9                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02914024: B.NE #0x2914120            | if (typeof(System.Globalization.CultureInfo) != null) goto label_36;
            if(null != null)
            {
                goto label_36;
            }
            // 0x02914028: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x0291402C: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            val_59 = 1152921504609562624;
            // 0x02914030: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x02914034: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x02914038: LDR x8, [x8, #0xd68]       | X8 = 1152921504654024704;               
            // 0x0291403C: LDR x23, [x8]              | X23 = typeof(System.Guid);              
            val_55 = null;
            // 0x02914040: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02914044: TBZ w8, #0, #0x2914054     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x02914048: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0291404C: CBNZ w8, #0x2914054        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x02914050: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_38:
            // 0x02914054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914058: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0291405C: MOV x1, x23                | X1 = 1152921504654024704 (0x1000000002CFE000);//ML01
            // 0x02914060: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02914064: CMP x19, x0                | STATE = COMPARE(val_2, val_16)          
            // 0x02914068: B.EQ #0x2914330            | if (val_50 == val_16) goto label_39;    
            if(val_50 == val_16)
            {
                goto label_39;
            }
            // 0x0291406C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x02914070: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x02914074: LDR x8, [x8, #0xb88]       | X8 = 1152921504857325568;               
            // 0x02914078: LDR x23, [x8]              | X23 = typeof(SerializableGuid);         
            // 0x0291407C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x02914080: TBZ w8, #0, #0x2914090     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_41;
            // 0x02914084: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02914088: CBNZ w8, #0x2914090        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x0291408C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_41:
            // 0x02914090: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914094: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914098: MOV x1, x23                | X1 = 1152921504857325568 (0x100000000EEE0000);//ML01
            // 0x0291409C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029140A0: CMP x19, x0                | STATE = COMPARE(val_2, val_17)          
            // 0x029140A4: B.EQ #0x2914420            | if (val_50 == val_17) goto label_42;    
            if(val_50 == val_17)
            {
                goto label_42;
            }
            // 0x029140A8: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x029140AC: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x029140B0: LDR x8, [x8, #0xd08]       | X8 = 1152921504684535808;               
            // 0x029140B4: LDR x23, [x8]              | X23 = typeof(System.Uri);               
            // 0x029140B8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029140BC: TBZ w8, #0, #0x29140cc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_44;
            // 0x029140C0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029140C4: CBNZ w8, #0x29140cc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
            // 0x029140C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_44:
            // 0x029140CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029140D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029140D4: MOV x1, x23                | X1 = 1152921504684535808 (0x1000000004A17000);//ML01
            // 0x029140D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_18 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029140DC: CMP x19, x0                | STATE = COMPARE(val_2, val_18)          
            // 0x029140E0: B.EQ #0x2914480            | if (val_50 == val_18) goto label_45;    
            if(val_50 == val_18)
            {
                goto label_45;
            }
            // 0x029140E4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x029140E8: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x029140EC: LDR x8, [x8, #0x40]        | X8 = 1152921504656633856;               
            // 0x029140F0: LDR x23, [x8]              | X23 = typeof(System.TimeSpan);          
            // 0x029140F4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029140F8: TBZ w8, #0, #0x2914108     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x029140FC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x02914100: CBNZ w8, #0x2914108        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x02914104: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_47:
            // 0x02914108: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0291410C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914110: MOV x1, x23                | X1 = 1152921504656633856 (0x1000000002F7B000);//ML01
            // 0x02914114: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x02914118: CMP x19, x0                | STATE = COMPARE(val_2, val_19)          
            // 0x0291411C: B.EQ #0x29144e4            | if (val_50 == val_19) goto label_48;    
            if(val_50 == val_19)
            {
                goto label_48;
            }
            label_36:
            // 0x02914120: ADRP x24, #0x362b000       | X24 = 56799232 (0x362B000);             
            // 0x02914124: LDR x24, [x24, #0xc10]     | X24 = 1152921504867069952;              
            val_62 = 1152921504867069952;
            // 0x02914128: LDR x0, [x24]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x0291412C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02914130: TBZ w8, #0, #0x2914140     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_50;
            // 0x02914134: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02914138: CBNZ w8, #0x2914140        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
            // 0x0291413C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_50:
            // 0x02914140: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x02914144: BL #0x290e840              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  null);
            System.ComponentModel.TypeConverter val_20 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  null);
            // 0x02914148: MOV x23, x0                | X23 = val_20;//m1                       
            // 0x0291414C: CBZ x23, #0x291419c        | if (val_20 == null) goto label_52;      
            if(val_20 == null)
            {
                goto label_52;
            }
            // 0x02914150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914154: MOV x0, x23                | X0 = val_20;//m1                        
            // 0x02914158: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x0291415C: BL #0x1ac8014              | X0 = val_20.CanConvertTo(destinationType:  val_50);
            bool val_21 = val_20.CanConvertTo(destinationType:  val_50);
            // 0x02914160: TBZ w0, #0, #0x291419c     | if (val_21 == false) goto label_52;     
            if(val_21 == false)
            {
                goto label_52;
            }
            // 0x02914164: LDR x8, [x23]              | X8 = typeof(System.ComponentModel.TypeConverter);
            // 0x02914168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291416C: MOV x0, x23                | X0 = val_20;//m1                        
            // 0x02914170: MOV x2, x22                | X2 = targetType;//m1                    
            // 0x02914174: LDP x6, x5, [x8, #0x180]   | X6 = typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_180; X5 = typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_188; //  | 
            // 0x02914178: MOV x3, x20                | X3 = culture;//m1                       
            // 0x0291417C: MOV x4, x19                | X4 = val_2;//m1                         
            // 0x02914180: SUB sp, x29, #0x40         | SP = (1152921513972490864 - 64) = 1152921513972490800 (0x100000022E3C6230);
            // 0x02914184: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            val_63 = ???;
            val_64 = ???;
            // 0x02914188: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            val_66 = ???;
            val_65 = ???;
            // 0x0291418C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            val_68 = ???;
            val_67 = ???;
            // 0x02914190: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            val_62 = ???;
            // 0x02914194: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            val_69 = ???;
            // 0x02914198: BR x6                      | goto typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_180;
            goto typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_180;
            label_52:
            // 0x0291419C: LDR x0, [x24]              | X0 = ;                                  
            // 0x029141A0: LDRB w8, [x0, #0x10a]      | W8 = val_62 + 266;                      
            // 0x029141A4: TBZ w8, #0, #0x29141b4     | if ((val_62 + 266 & 0x1) == 0) goto label_54;
            if(((val_62 + 266) & 1) == 0)
            {
                goto label_54;
            }
            // 0x029141A8: LDR w8, [x0, #0xbc]        | W8 = val_62 + 188;                      
            // 0x029141AC: CBNZ w8, #0x29141b4        | if (val_62 + 188 != 0) goto label_54;   
            if((val_62 + 188) != 0)
            {
                goto label_54;
            }
            // 0x029141B0: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
            label_54:
            // 0x029141B4: MOV x1, x19                | X1 = X19;//m1                           
            // 0x029141B8: BL #0x290e840              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  val_62);
            System.ComponentModel.TypeConverter val_22 = Newtonsoft.Json.Utilities.ConvertUtils.GetConverter(t:  val_62);
            // 0x029141BC: MOV x23, x0                | X23 = val_22;//m1                       
            val_70 = val_22;
            // 0x029141C0: CBZ x23, #0x291425c        | if (val_22 == null) goto label_56;      
            if(val_70 == null)
            {
                goto label_56;
            }
            // 0x029141C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029141C8: MOV x0, x23                | X0 = val_22;//m1                        
            // 0x029141CC: MOV x1, x21                | X1 = X21;//m1                           
            // 0x029141D0: BL #0x1ac7ffc              | X0 = val_22.CanConvertFrom(sourceType:  val_67);
            bool val_23 = val_70.CanConvertFrom(sourceType:  val_67);
            // 0x029141D4: TBZ w0, #0, #0x291425c     | if (val_23 == false) goto label_56;     
            if(val_23 == false)
            {
                goto label_56;
            }
            // 0x029141D8: LDR x8, [x23]              | X8 = typeof(System.ComponentModel.TypeConverter);
            // 0x029141DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029141E0: MOV x0, x23                | X0 = val_22;//m1                        
            // 0x029141E4: MOV x2, x22                | X2 = X22;//m1                           
            // 0x029141E8: LDP x5, x4, [x8, #0x170]   | X5 = typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_170; X4 = typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_178; //  | 
            // 0x029141EC: MOV x3, x20                | X3 = X20;//m1                           
            // 0x029141F0: SUB sp, x29, #0x40         | SP = (val_63 - 64);                     
            var val_24 = val_63 - 64;
            // 0x029141F4: LDP x29, x30, [sp, #0x40]  | X29 = (val_63 - 64) + 64; X30 = (val_63 - 64) + 64 + 8; //  | 
            val_71 = mem[(val_63 - 64) + 64];
            val_71 = (val_63 - 64) + 64;
            // 0x029141F8: LDP x20, x19, [sp, #0x30]  | X20 = (val_63 - 64) + 48; X19 = (val_63 - 64) + 48 + 8; //  | 
            val_72 = mem[(val_63 - 64) + 48];
            val_72 = (val_63 - 64) + 48;
            val_73 = mem[(val_63 - 64) + 48 + 8];
            val_73 = (val_63 - 64) + 48 + 8;
            // 0x029141FC: LDP x22, x21, [sp, #0x20]  | X22 = (val_63 - 64) + 32; X21 = (val_63 - 64) + 32 + 8; //  | 
            val_74 = mem[(val_63 - 64) + 32];
            val_74 = (val_63 - 64) + 32;
            val_75 = mem[(val_63 - 64) + 32 + 8];
            val_75 = (val_63 - 64) + 32 + 8;
            // 0x02914200: LDP x24, x23, [sp, #0x10]  | X24 = (val_63 - 64) + 16; X23 = (val_63 - 64) + 16 + 8; //  | 
            val_58 = mem[(val_63 - 64) + 16 + 8];
            val_58 = (val_63 - 64) + 16 + 8;
            // 0x02914204: LDP x26, x25, [sp], #0x50  | X26 = (val_63 - 64); X25 = (val_63 - 64) + 8; //  | 
            val_76 = mem[(val_63 - 64) + 8];
            val_76 = (val_63 - 64) + 8;
            // 0x02914208: BR x5                      | goto typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_170;
            goto typeof(System.ComponentModel.TypeConverter).__il2cppRuntimeField_170;
            label_29:
            // 0x0291420C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x02914210: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x02914214: LDR x0, [x8]               | X0 = typeof(System.Convert);            
            // 0x02914218: LDRB w8, [x0, #0x10a]      | W8 = System.Convert.__il2cppRuntimeField_10A;
            // 0x0291421C: TBZ w8, #0, #0x291422c     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_58;
            // 0x02914220: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x02914224: CBNZ w8, #0x291422c        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_58;
            // 0x02914228: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_58:
            // 0x0291422C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914230: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x02914234: MOV x1, x20                | X1 = (val_63 - 64) + 48;//m1            
            // 0x02914238: MOV x2, x19                | X2 = (val_63 - 64) + 48 + 8;//m1        
            // 0x0291423C: MOV x3, x22                | X3 = (val_63 - 64) + 32;//m1            
            // 0x02914240: SUB sp, x29, #0x40         | SP = ((val_63 - 64) + 64 - 64);         
            var val_25 = val_71 - 64;
            // 0x02914244: LDP x29, x30, [sp, #0x40]  | X29 = ((val_63 - 64) + 64 - 64) + 64; X30 = ((val_63 - 64) + 64 - 64) + 64 + 8; //  | 
            val_63 = mem[((val_63 - 64) + 64 - 64) + 64];
            val_63 = ((val_63 - 64) + 64 - 64) + 64;
            val_64 = mem[((val_63 - 64) + 64 - 64) + 64 + 8];
            val_64 = ((val_63 - 64) + 64 - 64) + 64 + 8;
            // 0x02914248: LDP x20, x19, [sp, #0x30]  | X20 = ((val_63 - 64) + 64 - 64) + 48; X19 = ((val_63 - 64) + 64 - 64) + 48 + 8; //  | 
            val_66 = mem[((val_63 - 64) + 64 - 64) + 48];
            val_66 = ((val_63 - 64) + 64 - 64) + 48;
            val_65 = mem[((val_63 - 64) + 64 - 64) + 48 + 8];
            val_65 = ((val_63 - 64) + 64 - 64) + 48 + 8;
            // 0x0291424C: LDP x22, x21, [sp, #0x20]  | X22 = ((val_63 - 64) + 64 - 64) + 32; X21 = ((val_63 - 64) + 64 - 64) + 32 + 8; //  | 
            val_67 = mem[((val_63 - 64) + 64 - 64) + 32 + 8];
            val_67 = ((val_63 - 64) + 64 - 64) + 32 + 8;
            // 0x02914250: LDP x24, x23, [sp, #0x10]  | X24 = ((val_63 - 64) + 64 - 64) + 16; X23 = ((val_63 - 64) + 64 - 64) + 16 + 8; //  | 
            val_62 = mem[((val_63 - 64) + 64 - 64) + 16];
            val_62 = ((val_63 - 64) + 64 - 64) + 16;
            val_70 = mem[((val_63 - 64) + 64 - 64) + 16 + 8];
            val_70 = ((val_63 - 64) + 64 - 64) + 16 + 8;
            // 0x02914254: LDP x26, x25, [sp], #0x50  | X26 = ((val_63 - 64) + 64 - 64); X25 = ((val_63 - 64) + 64 - 64) + 8; //  | 
            val_69 = mem[((val_63 - 64) + 64 - 64) + 8];
            val_69 = ((val_63 - 64) + 64 - 64) + 8;
            // 0x02914258: B #0x1babbb4               | 
            label_56:
            // 0x0291425C: ADRP x22, #0x35cb000       | X22 = 56406016 (0x35CB000);             
            // 0x02914260: LDR x22, [x22, #0xcc8]     | X22 = 1152921504652640256;              
            // 0x02914264: LDR x0, [x22]              | X0 = typeof(System.DBNull);             
            val_77 = null;
            // 0x02914268: LDRB w8, [x0, #0x10a]      | W8 = System.DBNull.__il2cppRuntimeField_10A;
            // 0x0291426C: TBZ w8, #0, #0x2914280     | if (System.DBNull.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x02914270: LDR w8, [x0, #0xbc]        | W8 = System.DBNull.__il2cppRuntimeField_cctor_finished;
            // 0x02914274: CBNZ w8, #0x2914280        | if (System.DBNull.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x02914278: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DBNull), ????);
            // 0x0291427C: LDR x0, [x22]              | X0 = typeof(System.DBNull);             
            val_77 = null;
            label_60:
            // 0x02914280: LDR x8, [x0, #0xa0]        | X8 = System.DBNull.__il2cppRuntimeField_static_fields;
            // 0x02914284: LDR x8, [x8]               | X8 = System.DBNull.Value;               
            // 0x02914288: CMP x8, x20                | STATE = COMPARE(System.DBNull.Value, ((val_63 - 64) + 64 - 64) + 48)
            // 0x0291428C: B.NE #0x29146a8            | if (System.DBNull.Value != val_66) goto label_61;
            if(System.DBNull.Value != val_66)
            {
                goto label_61;
            }
            // 0x02914290: MOV x1, x19                | X1 = ((val_63 - 64) + 64 - 64) + 48 + 8;//m1
            // 0x02914294: BL #0x2913c3c              | 
            // 0x02914298: TBZ w0, #0, #0x291478c     | if ((typeof(System.DBNull) & 0x1) == 0) goto label_62;
            if((val_77 & 1) == 0)
            {
                goto label_62;
            }
            // 0x0291429C: LDR x0, [x24]              | X0 = ((val_63 - 64) + 64 - 64) + 16;    
            // 0x029142A0: LDRB w8, [x0, #0x10a]      | W8 = ((val_63 - 64) + 64 - 64) + 16 + 266;
            // 0x029142A4: TBZ w8, #0, #0x29142b4     | if ((((val_63 - 64) + 64 - 64) + 16 + 266 & 0x1) == 0) goto label_64;
            if(((((val_63 - 64) + 64 - 64) + 16 + 266) & 1) == 0)
            {
                goto label_64;
            }
            // 0x029142A8: LDR w8, [x0, #0xbc]        | W8 = ((val_63 - 64) + 64 - 64) + 16 + 188;
            // 0x029142AC: CBNZ w8, #0x29142b4        | if (((val_63 - 64) + 64 - 64) + 16 + 188 != 0) goto label_64;
            if((((val_63 - 64) + 64 - 64) + 16 + 188) != 0)
            {
                goto label_64;
            }
            // 0x029142B0: BL #0x27977a4              | X0 = sub_27977A4( ?? ((val_63 - 64) + 64 - 64) + 16, ????);
            label_64:
            // 0x029142B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029142B8: MOV x2, x21                | X2 = ((val_63 - 64) + 64 - 64) + 32 + 8;//m1
            val_61 = val_67;
            // 0x029142BC: MOV x3, x19                | X3 = ((val_63 - 64) + 64 - 64) + 48 + 8;//m1
            // 0x029142C0: SUB sp, x29, #0x40         | SP = (((val_63 - 64) + 64 - 64) + 64 - 64);
            val_49 = val_63 - 64;
            // 0x029142C4: LDP x29, x30, [sp, #0x40]  | X29 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 64; X30 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 64 + 8; //  | 
            val_78 = mem[(((val_63 - 64) + 64 - 64) + 64 - 64) + 64];
            val_78 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 64;
            // 0x029142C8: LDP x20, x19, [sp, #0x30]  | X20 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48; X19 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 8; //  | 
            val_79 = mem[(((val_63 - 64) + 64 - 64) + 64 - 64) + 48];
            val_79 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48;
            val_80 = mem[(((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 8];
            val_80 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 8;
            // 0x029142CC: LDP x22, x21, [sp, #0x20]  | X22 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 32; X21 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 32 + 8; //  | 
            val_81 = mem[(((val_63 - 64) + 64 - 64) + 64 - 64) + 32 + 8];
            val_81 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 32 + 8;
            // 0x029142D0: LDP x24, x23, [sp, #0x10]  | X24 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 16; X23 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 16 + 8; //  | 
            val_55 = mem[(((val_63 - 64) + 64 - 64) + 64 - 64) + 16 + 8];
            val_55 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 16 + 8;
            // 0x029142D4: LDP x26, x25, [sp], #0x50  | X26 = (((val_63 - 64) + 64 - 64) + 64 - 64); X25 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 8; //  | 
            val_82 = mem[(((val_63 - 64) + 64 - 64) + 64 - 64) + 8];
            val_82 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 8;
            // 0x029142D8: B #0x2914988               | 
            label_35:
            // 0x029142DC: STP xzr, xzr, [sp, #0x30]  | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x029142E0: STR xzr, [sp, #0x28]       | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x029142E4: LDR x8, [x20]              | X8 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48;
            // 0x029142E8: LDR x1, [x25]              | X1 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 8;
            // 0x029142EC: LDR x0, [x8, #0x30]        | X0 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 48;
            // 0x029142F0: LDR x8, [x1, #0x30]        | X8 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 8 + 48;
            // 0x029142F4: CMP x0, x8                 | STATE = COMPARE((((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 48, (((val_63 - 64) + 64 - 64) + 64 - 64) + 8 + 48)
            // 0x029142F8: B.NE #0x29148b4            | if ((((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 48 != (((val_63 - 64) + 64 - 64) + 64 - 64) + 8 + 48) goto label_65;
            if(((((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 48) != ((((val_63 - 64) + 64 - 64) + 64 - 64) + 8 + 48))
            {
                goto label_65;
            }
            // 0x029142FC: MOV x0, x20                | X0 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48;//m1
            // 0x02914300: BL #0x27bc4e8              | 
            // 0x02914304: LDP x1, x2, [x0]           | X1 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48; X2 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 8; //  | 
            // 0x02914308: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0291430C: ADD x0, sp, #0x28          | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 40);
            var val_26 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80) + 40;
            // 0x02914310: BL #0x1c28be8              | X0 = label_ILRuntime_Runtime_Generated_CSHeroUnit_Binding_set_movespeed_9_GL01C28BE8();
            // 0x02914314: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x02914318: LDR x8, [sp, #0x38]        | X8 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 56;
            // 0x0291431C: LDUR q0, [sp, #0x28]       | Q0 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 40;
            // 0x02914320: LDR x9, [x9, #0x6a8]       | X9 = 1152921504652853248;               
            // 0x02914324: STR x8, [sp, #0x20]        | mem2[0] = (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 56;  //  dest_result_addr=0
            mem2[0] = (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 56;
            // 0x02914328: LDR x0, [x9]               | X0 = typeof(System.DateTimeOffset);     
            val_84 = null;
            // 0x0291432C: B #0x291438c               |  goto label_66;                         
            goto label_66;
            label_39:
            // 0x02914330: STP xzr, xzr, [sp]         | stack[1152921513972490688] = 0x0;  stack[1152921513972490696] = 0x0;  //  dest_result_addr=1152921513972490688 |  dest_result_addr=1152921513972490696
            // 0x02914334: LDR x1, [x24]              | X1 = typeof(System.String);             
            // 0x02914338: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            // 0x0291433C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02914340: B.EQ #0x291436c            | if (typeof(System.Globalization.CultureInfo) == null) goto label_67;
            if(null == null)
            {
                goto label_67;
            }
            // 0x02914344: LDR x0, [x8, #0x30]        | X0 = System.Globalization.CultureInfo.__il2cppRuntimeField_element_class;
            // 0x02914348: ADD x8, sp, #0x50          | X8 = (1152921513972490688 + 80) = 1152921513972490768 (0x100000022E3C6210);
            // 0x0291434C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Globalization.CultureInfo.__il2cppRuntimeField_element_class, ????);
            // 0x02914350: LDR x0, [sp, #0x50]        | X0 = val_27;                             //  find_add[1152921513972478880]
            // 0x02914354: BL #0x27af090              | X0 = sub_27AF090( ?? val_27, ????);     
            // 0x02914358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291435C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            // 0x02914360: ADD x0, sp, #0x50          | X0 = (1152921513972490688 + 80) = 1152921513972490768 (0x100000022E3C6210);
            // 0x02914364: BL #0x299a140              | 
            // 0x02914368: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_85 = 0;
            label_67:
            // 0x0291436C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914370: MOV x0, sp                 | X0 = 1152921513972490688 (0x100000022E3C61C0);//ML01
            // 0x02914374: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x02914378: BL #0x1c488c0              | X0 = label_System_Guid__ctor_GL01C488C0();
            // 0x0291437C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x02914380: LDR q0, [sp]               | Q0 = 0x0;                               
            // 0x02914384: LDR x8, [x8, #0x868]       | X8 = 1152921504654024704;               
            // 0x02914388: LDR x0, [x8]               | X0 = typeof(System.Guid);               
            val_84 = null;
            label_66:
            // 0x0291438C: STR q0, [sp, #0x10]        | stack[1152921513972490704] = 0x0;        //  dest_result_addr=1152921513972490704
            // 0x02914390: ADD x1, sp, #0x10          | X1 = (1152921513972490688 + 16) = 1152921513972490704 (0x100000022E3C61D0);
            label_77:
            // 0x02914394: BL #0x27bc028              | X0 = 1152921513972600416 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Guid), null);
            label_13:
            // 0x02914398: MOV x20, x0                | X20 = 1152921513972600416 (0x100000022E3E0E60);//ML01
            val_86 = 0;
            label_73:
            // 0x0291439C: MOV x0, x20                | X0 = 1152921513972600416 (0x100000022E3E0E60);//ML01
            // 0x029143A0: SUB sp, x29, #0x40         | SP = (1152921513972490864 - 64) = 1152921513972490800 (0x100000022E3C6230);
            // 0x029143A4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x029143A8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x029143AC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x029143B0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x029143B4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x029143B8: RET                        |  return (System.Object)null;            
            return (object)val_86;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_26:
            // 0x029143BC: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.String).__il2cppRuntimeField_140; X1 = typeof(System.String).__il2cppRuntimeField_148; //  | 
            // 0x029143C0: MOV x0, x20                | X0 = culture;//m1                       
            // 0x029143C4: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_140();
            // 0x029143C8: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x029143CC: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x029143D0: MOV x20, x0                | X20 = culture;//m1                      
            // 0x029143D4: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x029143D8: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x029143DC: TBZ w9, #0, #0x29143f0     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_69;
            // 0x029143E0: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x029143E4: CBNZ w9, #0x29143f0        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
            // 0x029143E8: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x029143EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_69:
            // 0x029143F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029143F4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x029143F8: ORR w3, wzr, #1            | W3 = 1(0x1);                            
            // 0x029143FC: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x02914400: MOV x2, x20                | X2 = culture;//m1                       
            // 0x02914404: SUB sp, x29, #0x40         | SP = (1152921513972490864 - 64) = 1152921513972490800 (0x100000022E3C6230);
            // 0x02914408: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0291440C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x02914410: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x02914414: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x02914418: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0291441C: B #0x1c39f68               | return System.Enum.Parse(enumType:  0, value:  val_50, ignoreCase:  val_52);
            return System.Enum.Parse(enumType:  0, value:  val_50, ignoreCase:  val_52);
            label_42:
            // 0x02914420: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x02914424: LDR x8, [x8, #0x9d8]       | X8 = 1152921504857325568;               
            // 0x02914428: LDR x0, [x8]               | X0 = typeof(SerializableGuid);          
            // 0x0291442C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(SerializableGuid), ????);
            // 0x02914430: LDR x1, [x24]              | X1 = typeof(System.String);             
            // 0x02914434: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            // 0x02914438: MOV x19, x0                | X19 = 1152921504857325568 (0x100000000EEE0000);//ML01
            val_87 = null;
            // 0x0291443C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02914440: B.EQ #0x291446c            | if (typeof(System.Globalization.CultureInfo) == null) goto label_70;
            if(null == null)
            {
                goto label_70;
            }
            // 0x02914444: LDR x0, [x8, #0x30]        | X0 = System.Globalization.CultureInfo.__il2cppRuntimeField_element_class;
            // 0x02914448: ADD x8, sp, #0x58          | X8 = (1152921513972490688 + 88) = 1152921513972490776 (0x100000022E3C6218);
            // 0x0291444C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Globalization.CultureInfo.__il2cppRuntimeField_element_class, ????);
            // 0x02914450: LDR x0, [sp, #0x58]        | X0 = val_28;                             //  find_add[1152921513972478880]
            // 0x02914454: BL #0x27af090              | X0 = sub_27AF090( ?? val_28, ????);     
            // 0x02914458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291445C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            // 0x02914460: ADD x0, sp, #0x58          | X0 = (1152921513972490688 + 88) = 1152921513972490776 (0x100000022E3C6218);
            // 0x02914464: BL #0x299a140              | 
            // 0x02914468: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_88 = 0;
            label_70:
            // 0x0291446C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914470: MOV x0, x19                | X0 = 1152921504857325568 (0x100000000EEE0000);//ML01
            SerializableGuid val_29 = val_87;
            // 0x02914474: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x02914478: BL #0xca6544               | .ctor(guid:  val_88);                   
            val_29 = new SerializableGuid(guid:  val_88);
            // 0x0291447C: B #0x29144dc               |  goto label_71;                         
            goto label_71;
            label_45:
            // 0x02914480: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x02914484: LDR x8, [x8, #0x470]       | X8 = 1152921504684535808;               
            // 0x02914488: LDR x0, [x8]               | X0 = typeof(System.Uri);                
            // 0x0291448C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Uri), ????);
            // 0x02914490: LDR x1, [x24]              | X1 = typeof(System.String);             
            // 0x02914494: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            // 0x02914498: MOV x19, x0                | X19 = 1152921504684535808 (0x1000000004A17000);//ML01
            val_87 = null;
            // 0x0291449C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x029144A0: B.EQ #0x29144cc            | if (typeof(System.Globalization.CultureInfo) == null) goto label_72;
            if(null == null)
            {
                goto label_72;
            }
            // 0x029144A4: LDR x0, [x8, #0x30]        | X0 = System.Globalization.CultureInfo.__il2cppRuntimeField_element_class;
            // 0x029144A8: SUB x8, x29, #0x50         | X8 = (1152921513972490864 - 80) = 1152921513972490784 (0x100000022E3C6220);
            // 0x029144AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Globalization.CultureInfo.__il2cppRuntimeField_element_class, ????);
            // 0x029144B0: LDUR x0, [x29, #-0x50]     | X0 = val_30;                             //  find_add[1152921513972478880]
            // 0x029144B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_30, ????);     
            // 0x029144B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029144BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_30, ????);     
            // 0x029144C0: SUB x0, x29, #0x50         | X0 = (1152921513972490864 - 80) = 1152921513972490784 (0x100000022E3C6220);
            // 0x029144C4: BL #0x299a140              | 
            // 0x029144C8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_89 = 0;
            label_72:
            // 0x029144CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029144D0: MOV x0, x19                | X0 = 1152921504684535808 (0x1000000004A17000);//ML01
            System.Uri val_31 = val_87;
            // 0x029144D4: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x029144D8: BL #0x27176c4              | .ctor(uriString:  val_89);              
            val_31 = new System.Uri(uriString:  val_89);
            label_71:
            // 0x029144DC: MOV x20, x19               | X20 = 1152921504684535808 (0x1000000004A17000);//ML01
            // 0x029144E0: B #0x291439c               |  goto label_73;                         
            goto label_73;
            label_48:
            // 0x029144E4: ADRP x19, #0x3610000       | X19 = 56688640 (0x3610000);             
            // 0x029144E8: LDR x19, [x19, #0x6d0]     | X19 = 1152921504656633856;              
            // 0x029144EC: LDR x0, [x19]              | X0 = typeof(System.TimeSpan);           
            // 0x029144F0: LDRB w8, [x0, #0x10a]      | W8 = System.TimeSpan.__il2cppRuntimeField_10A;
            // 0x029144F4: TBZ w8, #0, #0x2914504     | if (System.TimeSpan.__il2cppRuntimeField_has_cctor == 0) goto label_75;
            // 0x029144F8: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x029144FC: CBNZ w8, #0x2914504        | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_75;
            // 0x02914500: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            label_75:
            // 0x02914504: LDR x1, [x24]              | X1 = typeof(System.String);             
            // 0x02914508: LDR x8, [x20]              | X8 = typeof(System.Globalization.CultureInfo);
            // 0x0291450C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Globalization.CultureInfo), typeof(System.String))
            // 0x02914510: B.EQ #0x291453c            | if (typeof(System.Globalization.CultureInfo) == null) goto label_76;
            if(null == null)
            {
                goto label_76;
            }
            // 0x02914514: LDR x0, [x8, #0x30]        | X0 = System.Globalization.CultureInfo.__il2cppRuntimeField_element_class;
            // 0x02914518: SUB x8, x29, #0x48         | X8 = (1152921513972490864 - 72) = 1152921513972490792 (0x100000022E3C6228);
            // 0x0291451C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Globalization.CultureInfo.__il2cppRuntimeField_element_class, ????);
            // 0x02914520: LDUR x0, [x29, #-0x48]     | X0 = val_32;                             //  find_add[1152921513972478880]
            // 0x02914524: BL #0x27af090              | X0 = sub_27AF090( ?? val_32, ????);     
            // 0x02914528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291452C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            // 0x02914530: SUB x0, x29, #0x48         | X0 = (1152921513972490864 - 72) = 1152921513972490792 (0x100000022E3C6228);
            // 0x02914534: BL #0x299a140              | 
            // 0x02914538: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_90 = 0;
            label_76:
            // 0x0291453C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914540: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914544: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x02914548: BL #0x1b6abac              | X0 = System.TimeSpan.Parse(s:  0);      
            System.TimeSpan val_33 = System.TimeSpan.Parse(s:  0);
            // 0x0291454C: LDR x8, [x19]              | X8 = typeof(System.TimeSpan);           
            // 0x02914550: STR x0, [sp, #0x10]        | stack[1152921513972490704] = val_33._ticks;  //  dest_result_addr=1152921513972490704
            // 0x02914554: ADD x1, sp, #0x10          | X1 = (1152921513972490688 + 16) = 1152921513972490704 (0x100000022E3C61D0);
            // 0x02914558: MOV x0, x8                 | X0 = 1152921504656633856 (0x1000000002F7B000);//ML01
            // 0x0291455C: B #0x2914394               |  goto label_77;                         
            goto label_77;
            label_18:
            // 0x02914560: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02914564: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02914568: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x0291456C: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x02914570: TBZ w8, #0, #0x2914580     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_79;
            // 0x02914574: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02914578: CBNZ w8, #0x2914580        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_79;
            // 0x0291457C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_79:
            // 0x02914580: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914588: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_34 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x0291458C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02914590: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02914594: MOV x20, x0                | X20 = val_34;//m1                       
            // 0x02914598: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x0291459C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029145A0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x029145A4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x029145A8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_91 = null;
            // 0x029145AC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x029145B0: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029145B4: CBNZ x21, #0x29145bc       | if ( != null) goto label_80;            
            if(null != null)
            {
                goto label_80;
            }
            // 0x029145B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_80:
            // 0x029145BC: CBZ x19, #0x29145e0        | if (val_2 == null) goto label_82;       
            if(val_50 == null)
            {
                goto label_82;
            }
            // 0x029145C0: LDR x8, [x21]              | X8 = ;                                  
            // 0x029145C4: MOV x0, x19                | X0 = val_2;//m1                         
            val_91 = val_50;
            // 0x029145C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029145CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x029145D0: CBNZ x0, #0x29145e0        | if (val_2 != null) goto label_82;       
            if(val_91 != null)
            {
                goto label_82;
            }
            // 0x029145D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x029145D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029145DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_82:
            // 0x029145E0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x029145E4: CBNZ w8, #0x29145f4        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_83;
            // 0x029145E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x029145EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029145F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_83:
            // 0x029145F4: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_50;
            // 0x029145F8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x029145FC: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513972464960)("Target type {0} is not a value type or a non-abstract class.");
            // 0x02914600: MOV x2, x20                | X2 = val_34;//m1                        
            // 0x02914604: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02914608: LDR x1, [x8]               | X1 = "Target type {0} is not a value type or a non-abstract class.";
            // 0x0291460C: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_91 = val_50, provider:  "Target type {0} is not a value type or a non-abstract class.", args:  val_34);
            string val_35 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_91, provider:  "Target type {0} is not a value type or a non-abstract class.", args:  val_34);
            // 0x02914610: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x02914614: LDR x8, [x8, #0x1b8]       | X8 = 1152921504651841536;               
            // 0x02914618: MOV x19, x0                | X19 = val_35;//m1                       
            // 0x0291461C: LDR x8, [x8]               | X8 = typeof(System.ArgumentException);  
            // 0x02914620: MOV x0, x8                 | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            System.ArgumentException val_36 = null;
            // 0x02914624: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentException), ????);
            // 0x02914628: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x0291462C: LDR x8, [x8, #0x518]       | X8 = (string**)(1152921513971730144)("targetType");
            // 0x02914630: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x02914634: MOV x1, x19                | X1 = val_35;//m1                        
            // 0x02914638: MOV x20, x0                | X20 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x0291463C: LDR x2, [x8]               | X2 = "targetType";                      
            // 0x02914640: BL #0x18b3ee4              | .ctor(message:  val_35, paramName:  "targetType");
            val_36 = new System.ArgumentException(message:  val_35, paramName:  "targetType");
            label_104:
            // 0x02914644: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x02914648: LDR x8, [x8, #0xdc0]       | X8 = 1152921513972469248;               
            // 0x0291464C: MOV x0, x20                | X0 = 1152921504651841536 (0x1000000002AE9000);//ML01
            // 0x02914650: LDR x1, [x8]               | X1 = public static System.Object Newtonsoft.Json.Utilities.ConvertUtils::Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType);
            // 0x02914654: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentException), ????);
            // 0x02914658: BL #0x28fffbc              | X0 = Convert(value:  public static System.Object Newtonsoft.Json.Utilities.ConvertUtils::Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType), typeCode:  "targetType");
            object val_37 = Convert(value:  public static System.Object Newtonsoft.Json.Utilities.ConvertUtils::Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType), typeCode:  "targetType");
            label_1:
            // 0x0291465C: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x02914660: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x02914664: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_38 = null;
            // 0x02914668: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x0291466C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x02914670: LDR x8, [x8, #0x248]       | X8 = (string**)(1152921513972474368)("initialValue");
            // 0x02914674: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914678: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x0291467C: LDR x1, [x8]               | X1 = "initialValue";                    
            // 0x02914680: BL #0x18b3df0              | .ctor(paramName:  "initialValue");      
            val_38 = new System.ArgumentNullException(paramName:  "initialValue");
            // 0x02914684: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x02914688: LDR x8, [x8, #0xdc0]       | X8 = 1152921513972469248;               
            // 0x0291468C: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x02914690: LDR x1, [x8]               | X1 = public static System.Object Newtonsoft.Json.Utilities.ConvertUtils::Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType);
            // 0x02914694: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x02914698: BL #0x28fffbc              | X0 = Convert(value:  public static System.Object Newtonsoft.Json.Utilities.ConvertUtils::Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType), typeCode:  0);
            object val_39 = Convert(value:  public static System.Object Newtonsoft.Json.Utilities.ConvertUtils::Convert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType), typeCode:  0);
            // 0x0291469C: MOV x19, x0                | X19 = val_39;//m1                       
            val_92 = val_39;
            // 0x029146A0: ADD x0, sp, #0x40          | X0 = (1152921513972490688 + 64) = 1152921513972490752 (0x100000022E3C6200);
            // 0x029146A4: B #0x29148f4               |  goto label_108;                        
            goto label_108;
            label_61:
            // 0x029146A8: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x029146AC: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x029146B0: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x029146B4: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x029146B8: TBZ w8, #0, #0x29146c8     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_86;
            // 0x029146BC: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x029146C0: CBNZ w8, #0x29146c8        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
            // 0x029146C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_86:
            // 0x029146C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029146CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029146D0: BL #0x1c2f10c              | 
            // 0x029146D4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x029146D8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x029146DC: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            val_94 = 0;
            // 0x029146E0: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
            // 0x029146E4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029146E8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x029146EC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x029146F0: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_95 = null;
            // 0x029146F4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x029146F8: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_96 = val_95;
            // 0x029146FC: CBNZ x22, #0x2914704       | if ( != null) goto label_87;            
            if(null != null)
            {
                goto label_87;
            }
            // 0x02914700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_87:
            // 0x02914704: CBZ x21, #0x2914728        | if (((val_63 - 64) + 64 - 64) + 32 + 8 == 0) goto label_89;
            if(val_67 == 0)
            {
                goto label_89;
            }
            // 0x02914708: LDR x8, [x22]              | X8 = ;                                  
            // 0x0291470C: MOV x0, x21                | X0 = ((val_63 - 64) + 64 - 64) + 32 + 8;//m1
            val_95 = val_67;
            // 0x02914710: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02914714: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            // 0x02914718: CBNZ x0, #0x2914728        | if (((val_63 - 64) + 64 - 64) + 32 + 8 != 0) goto label_89;
            if(val_95 != 0)
            {
                goto label_89;
            }
            // 0x0291471C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            // 0x02914720: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914724: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            label_89:
            // 0x02914728: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x0291472C: CBNZ w8, #0x291473c        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_90;
            // 0x02914730: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            // 0x02914734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914738: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            label_90:
            // 0x0291473C: STR x21, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = ((val_63 - 64) + 64 - 64) + 32 + 8;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_67;
            // 0x02914740: CBZ x19, #0x2914764        | if (((val_63 - 64) + 64 - 64) + 48 + 8 == 0) goto label_92;
            if(val_65 == 0)
            {
                goto label_92;
            }
            // 0x02914744: LDR x8, [x22]              | X8 = ;                                  
            // 0x02914748: MOV x0, x19                | X0 = ((val_63 - 64) + 64 - 64) + 48 + 8;//m1
            val_95 = val_65;
            // 0x0291474C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02914750: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            // 0x02914754: CBNZ x0, #0x2914764        | if (((val_63 - 64) + 64 - 64) + 48 + 8 != 0) goto label_92;
            if(val_95 != 0)
            {
                goto label_92;
            }
            // 0x02914758: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            // 0x0291475C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914760: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            label_92:
            // 0x02914764: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02914768: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0291476C: B.HI #0x291477c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_93;
            // 0x02914770: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            // 0x02914774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914778: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            label_93:
            // 0x0291477C: STR x19, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = ((val_63 - 64) + 64 - 64) + 48 + 8;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_65;
            // 0x02914780: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x02914784: LDR x8, [x8, #0xc0]        | X8 = (string**)(1152921513972478560)("Can not convert from {0} to {1}.");
            val_97 = "Can not convert from {0} to {1}.";
            // 0x02914788: B #0x291486c               |  goto label_94;                         
            goto label_94;
            label_62:
            // 0x0291478C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02914790: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02914794: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x02914798: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x0291479C: TBZ w8, #0, #0x29147ac     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_96;
            // 0x029147A0: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x029147A4: CBNZ w8, #0x29147ac        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_96;
            // 0x029147A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_96:
            // 0x029147AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029147B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029147B4: BL #0x1c2f10c              | 
            // 0x029147B8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x029147BC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x029147C0: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            val_94 = 0;
            // 0x029147C4: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
            // 0x029147C8: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x029147CC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x029147D0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x029147D4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_95 = null;
            // 0x029147D8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x029147DC: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_96 = val_95;
            // 0x029147E0: CBNZ x22, #0x29147e8       | if ( != null) goto label_97;            
            if(null != null)
            {
                goto label_97;
            }
            // 0x029147E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_97:
            // 0x029147E8: CBZ x21, #0x291480c        | if (((val_63 - 64) + 64 - 64) + 32 + 8 == 0) goto label_99;
            if(val_67 == 0)
            {
                goto label_99;
            }
            // 0x029147EC: LDR x8, [x22]              | X8 = ;                                  
            // 0x029147F0: MOV x0, x21                | X0 = ((val_63 - 64) + 64 - 64) + 32 + 8;//m1
            val_95 = val_67;
            // 0x029147F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x029147F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            // 0x029147FC: CBNZ x0, #0x291480c        | if (((val_63 - 64) + 64 - 64) + 32 + 8 != 0) goto label_99;
            if(val_95 != 0)
            {
                goto label_99;
            }
            // 0x02914800: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            // 0x02914804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914808: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            label_99:
            // 0x0291480C: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02914810: CBNZ w8, #0x2914820        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_100;
            // 0x02914814: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            // 0x02914818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291481C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 32 + 8, ????);
            label_100:
            // 0x02914820: STR x21, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = ((val_63 - 64) + 64 - 64) + 32 + 8;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_67;
            // 0x02914824: CBZ x19, #0x2914848        | if (((val_63 - 64) + 64 - 64) + 48 + 8 == 0) goto label_102;
            if(val_65 == 0)
            {
                goto label_102;
            }
            // 0x02914828: LDR x8, [x22]              | X8 = ;                                  
            // 0x0291482C: MOV x0, x19                | X0 = ((val_63 - 64) + 64 - 64) + 48 + 8;//m1
            val_95 = val_65;
            // 0x02914830: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02914834: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            // 0x02914838: CBNZ x0, #0x2914848        | if (((val_63 - 64) + 64 - 64) + 48 + 8 != 0) goto label_102;
            if(val_95 != 0)
            {
                goto label_102;
            }
            // 0x0291483C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            // 0x02914840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            label_102:
            // 0x02914848: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x0291484C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x02914850: B.HI #0x2914860            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_103;
            // 0x02914854: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            // 0x02914858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0291485C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_63 - 64) + 64 - 64) + 48 + 8, ????);
            label_103:
            // 0x02914860: STR x19, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = ((val_63 - 64) + 64 - 64) + 48 + 8;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_65;
            // 0x02914864: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x02914868: LDR x8, [x8, #0xe00]       | X8 = (string**)(1152921513972478704)("Can not convert null {0} into non-nullable {1}.");
            val_97 = "Can not convert null {0} into non-nullable {1}.";
            label_94:
            // 0x0291486C: LDR x1, [x8]               | X1 = "Can not convert null {0} into non-nullable {1}.";
            // 0x02914870: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x02914874: MOV x3, x22                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02914878: BL #0x2900ac4              | 
            // 0x0291487C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x02914880: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x02914884: MOV x19, x0                | X19 = ((val_63 - 64) + 64 - 64) + 48 + 8;//m1
            // 0x02914888: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x0291488C: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02914890: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x02914894: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914898: MOV x1, x19                | X1 = ((val_63 - 64) + 64 - 64) + 48 + 8;//m1
            // 0x0291489C: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x029148A0: BL #0x1c32b48              | 
            // 0x029148A4: B #0x2914644               |  goto label_104;                        
            goto label_104;
            // 0x029148A8: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_92 = null;
            // 0x029148AC: ADD x0, sp, #0x50          | X0 = (((val_63 - 64) + 64 - 64) + 80 + 80);
            val_93 = (((val_63 - 64) + 64 - 64) + 80) + 80;
            // 0x029148B0: B #0x29148f4               |  goto label_108;                        
            goto label_108;
            label_65:
            // 0x029148B4: ADD x8, sp, #0x48          | X8 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72);
            var val_40 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80) + 72;
            // 0x029148B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (((val_63 - 64) + 64 - 64) + 64 - 64) + 48 + 48, ????);
            // 0x029148BC: LDR x0, [sp, #0x48]        | X0 = (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72;
            // 0x029148C0: BL #0x27af090              | X0 = sub_27AF090( ?? (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72, ????);
            // 0x029148C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029148C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72, ????);
            // 0x029148CC: ADD x0, sp, #0x48          | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72);
            var val_41 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80) + 72;
            // 0x029148D0: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72)); //ERROR_TYPE
            // 0x029148D4: MOV x19, x0                | X19 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72);//m1
            val_92 = val_41;
            // 0x029148D8: ADD x0, sp, #0x58          | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 88);
            val_93 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80) + 88;
            // 0x029148DC: B #0x29148f4               |  goto label_108;                        
            goto label_108;
            // 0x029148E0: MOV x19, x0                | X19 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 88);//m1
            val_92 = val_93;
            // 0x029148E4: SUB x0, x29, #0x50         | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 80);
            val_93 = val_78 - 80;
            // 0x029148E8: B #0x29148f4               |  goto label_108;                        
            goto label_108;
            // 0x029148EC: MOV x19, x0                | X19 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 80);//m1
            val_92 = val_93;
            // 0x029148F0: SUB x0, x29, #0x48         | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 72);
            val_93 = val_78 - 72;
            label_108:
            // 0x029148F4: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 72)); //ERROR_TYPE
            // 0x029148F8: MOV x0, x19                | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 80);//m1
            // 0x029148FC: BL #0x980800               | X0 = sub_980800( ?? ((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 80), ????);
            // 0x02914900: MOV x19, x0                | X19 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 64 - 80);//m1
            // 0x02914904: ADD x0, sp, #0x48          | X0 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80 + 72);
            var val_42 = ((((val_63 - 64) + 64 - 64) + 64 - 64) + 80) + 72;
            // 0x02914908: B #0x29148f4               |  goto label_108;                        
            goto label_108;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012FA440 VirtAddr: 0x012FA440 -RVA: 0x012FA440 
        // -ConvertUtils.TryConvert<object>
        //
        //
        // Offset in libil2cpp.so: 0x012FA440 (19899456), len: 192  VirtAddr: 0x012FA440 RVA: 0x012FA440 token: 100686617 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryConvert<T>(object initialValue, out T convertedValue)
        {
            //
            // Disasemble & Code
            // 0x012FA440: STP x22, x21, [sp, #-0x30]! | stack[1152921513972701072] = ???;  stack[1152921513972701080] = ???;  //  dest_result_addr=1152921513972701072 |  dest_result_addr=1152921513972701080
            // 0x012FA444: STP x20, x19, [sp, #0x10]  | stack[1152921513972701088] = ???;  stack[1152921513972701096] = ???;  //  dest_result_addr=1152921513972701088 |  dest_result_addr=1152921513972701096
            // 0x012FA448: STP x29, x30, [sp, #0x20]  | stack[1152921513972701104] = ???;  stack[1152921513972701112] = ???;  //  dest_result_addr=1152921513972701104 |  dest_result_addr=1152921513972701112
            // 0x012FA44C: ADD x29, sp, #0x20         | X29 = (1152921513972701072 + 32) = 1152921513972701104 (0x100000022E3F97B0);
            // 0x012FA450: ADRP x22, #0x3736000       | X22 = 57892864 (0x3736000);             
            // 0x012FA454: LDRB w8, [x22, #0x8b1]     | W8 = (bool)static_value_037368B1;       
            // 0x012FA458: MOV x21, x3                | X21 = X3;//m1                           
            // 0x012FA45C: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012FA460: MOV x20, x1                | X20 = 1152921513972749216 (0x100000022E4053A0);//ML01
            // 0x012FA464: TBNZ w8, #0, #0x12fa480    | if (static_value_037368B1 == true) goto label_0;
            // 0x012FA468: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x012FA46C: LDR x8, [x8, #0x598]       | X8 = 0x2B92C7C;                         
            // 0x012FA470: LDR w0, [x8]               | W0 = 0x21E4;                            
            // 0x012FA474: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E4, ????);     
            // 0x012FA478: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x012FA47C: STRB w8, [x22, #0x8b1]     | static_value_037368B1 = true;            //  dest_result_addr=57895089
            label_0:
            // 0x012FA480: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x012FA484: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x012FA488: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x012FA48C: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x012FA490: TBZ w8, #0, #0x12fa4a0     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x012FA494: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x012FA498: CBNZ w8, #0x12fa4a0        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x012FA49C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_2:
            // 0x012FA4A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA4A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x012FA4A8: BL #0x1c42254              | X0 = System.Globalization.CultureInfo.get_CurrentCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.CurrentCulture;
            // 0x012FA4AC: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x012FA4B0: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x012FA4B4: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x012FA4B8: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x012FA4BC: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x012FA4C0: TBZ w9, #0, #0x12fa4d4     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x012FA4C4: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x012FA4C8: CBNZ w9, #0x12fa4d4        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x012FA4CC: MOV x0, x8                 | X0 = 1152921504867069952 (0x100000000F82B000);//ML01
            // 0x012FA4D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_4:
            // 0x012FA4D4: LDR x8, [x21, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA4D8: MOV x1, x20                | X1 = 1152921513972749216 (0x100000022E4053A0);//ML01
            // 0x012FA4DC: MOV x3, x19                | X3 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA4E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA4E4: LDR x4, [x8]               | X4 = X3 + 48;                           
            // 0x012FA4E8: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x012FA4EC: LDR x5, [x4]               | X5 = X3 + 48;                           
            // 0x012FA4F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x012FA4F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x012FA4F8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x012FA4FC: BR x5                      | goto X3 + 48;                           
            goto X3 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012FA388 VirtAddr: 0x012FA388 -RVA: 0x012FA388 
        // -ConvertUtils.TryConvert<object>
        //
        //
        // Offset in libil2cpp.so: 0x012FA388 (19899272), len: 184  VirtAddr: 0x012FA388 RVA: 0x012FA388 token: 100686618 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryConvert<T>(object initialValue, System.Globalization.CultureInfo culture, out T convertedValue)
        {
            //
            // Disasemble & Code
            // 0x012FA388: STP x24, x23, [sp, #-0x40]! | stack[1152921513972837504] = ???;  stack[1152921513972837512] = ???;  //  dest_result_addr=1152921513972837504 |  dest_result_addr=1152921513972837512
            // 0x012FA38C: STP x22, x21, [sp, #0x10]  | stack[1152921513972837520] = ???;  stack[1152921513972837528] = ???;  //  dest_result_addr=1152921513972837520 |  dest_result_addr=1152921513972837528
            // 0x012FA390: STP x20, x19, [sp, #0x20]  | stack[1152921513972837536] = ???;  stack[1152921513972837544] = ???;  //  dest_result_addr=1152921513972837536 |  dest_result_addr=1152921513972837544
            // 0x012FA394: STP x29, x30, [sp, #0x30]  | stack[1152921513972837552] = ???;  stack[1152921513972837560] = ???;  //  dest_result_addr=1152921513972837552 |  dest_result_addr=1152921513972837560
            // 0x012FA398: ADD x29, sp, #0x30         | X29 = (1152921513972837504 + 48) = 1152921513972837552 (0x100000022E41ACB0);
            // 0x012FA39C: MOV x20, x4                | X20 = X4;//m1                           
            // 0x012FA3A0: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA3A4: MOV x19, x3                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012FA3A8: MOV x22, x1                | X22 = culture;//m1                      
            // 0x012FA3AC: LDR x21, [x8]              | X21 = X4 + 48;                          
            // 0x012FA3B0: MOV x0, x21                | X0 = X4 + 48;//m1                       
            // 0x012FA3B4: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48, ????);    
            // 0x012FA3B8: MOV x0, x21                | X0 = X4 + 48;//m1                       
            // 0x012FA3BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48, ????);
            // 0x012FA3C0: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA3C4: MOV x21, x0                | X21 = X4 + 48;//m1                      
            // 0x012FA3C8: LDR x1, [x8, #8]           | X1 = X4 + 48 + 8;                       
            // 0x012FA3CC: LDR x8, [x1]               | X8 = X4 + 48 + 8;                       
            // 0x012FA3D0: BLR x8                     | X0 = X4 + 48 + 8();                     
            // 0x012FA3D4: CBNZ x21, #0x12fa3dc       | if (X4 + 48 != 0) goto label_0;         
            if((X4 + 48) != 0)
            {
                goto label_0;
            }
            // 0x012FA3D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
            label_0:
            // 0x012FA3DC: STR x22, [x21, #0x10]      | mem2[0] = culture;                       //  dest_result_addr=0
            mem2[0] = culture;
            // 0x012FA3E0: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA3E4: LDP x22, x23, [x8, #0x10]  | X22 = X4 + 48 + 16; X23 = X4 + 48 + 16 + 8; //  | 
            // 0x012FA3E8: MOV x0, x23                | X0 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA3EC: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 16 + 8, ????);
            // 0x012FA3F0: MOV x0, x23                | X0 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA3F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48 + 16 + 8, ????);
            // 0x012FA3F8: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA3FC: MOV x1, x21                | X1 = X4 + 48;//m1                       
            // 0x012FA400: MOV x2, x22                | X2 = X4 + 48 + 16;//m1                  
            // 0x012FA404: MOV x23, x0                | X23 = X4 + 48 + 16 + 8;//m1             
            // 0x012FA408: LDR x3, [x8, #0x20]        | X3 = X4 + 48 + 32;                      
            // 0x012FA40C: LDR x8, [x3]               | X8 = X4 + 48 + 32;                      
            // 0x012FA410: BLR x8                     | X0 = X4 + 48 + 32();                    
            // 0x012FA414: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA418: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA41C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA420: MOV x1, x23                | X1 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA424: LDR x3, [x8, #0x28]        | X3 = X4 + 48 + 40;                      
            // 0x012FA428: LDR x4, [x3]               | X4 = X4 + 48 + 40;                      
            // 0x012FA42C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x012FA430: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x012FA434: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x012FA438: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x012FA43C: BR x4                      | goto X4 + 48 + 40;                      
            goto X4 + 48 + 40;
        
        }
        //
        // Offset in libil2cpp.so: 0x02914C08 (43076616), len: 244  VirtAddr: 0x02914C08 RVA: 0x02914C08 token: 100686619 methodIndex: 49138 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryConvert(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType, out object convertedValue)
        {
            //
            // Disasemble & Code
            // 0x02914C08: STP x24, x23, [sp, #-0x40]! | stack[1152921513972981120] = ???;  stack[1152921513972981128] = ???;  //  dest_result_addr=1152921513972981120 |  dest_result_addr=1152921513972981128
            // 0x02914C0C: STP x22, x21, [sp, #0x10]  | stack[1152921513972981136] = ???;  stack[1152921513972981144] = ???;  //  dest_result_addr=1152921513972981136 |  dest_result_addr=1152921513972981144
            // 0x02914C10: STP x20, x19, [sp, #0x20]  | stack[1152921513972981152] = ???;  stack[1152921513972981160] = ???;  //  dest_result_addr=1152921513972981152 |  dest_result_addr=1152921513972981160
            // 0x02914C14: STP x29, x30, [sp, #0x30]  | stack[1152921513972981168] = ???;  stack[1152921513972981176] = ???;  //  dest_result_addr=1152921513972981168 |  dest_result_addr=1152921513972981176
            // 0x02914C18: ADD x29, sp, #0x30         | X29 = (1152921513972981120 + 48) = 1152921513972981168 (0x100000022E43DDB0);
            // 0x02914C1C: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x02914C20: LDRB w8, [x21, #0xaff]     | W8 = (bool)static_value_037B8AFF;       
            // 0x02914C24: MOV x19, x4                | X19 = X4;//m1                           
            // 0x02914C28: MOV x20, x3                | X20 = 1152921513973037472 (0x100000022E44B9A0);//ML01
            // 0x02914C2C: MOV x22, x2                | X22 = targetType;//m1                   
            // 0x02914C30: MOV x23, x1                | X23 = culture;//m1                      
            // 0x02914C34: TBNZ w8, #0, #0x2914c50    | if (static_value_037B8AFF == true) goto label_0;
            // 0x02914C38: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x02914C3C: LDR x8, [x8, #0xfd8]       | X8 = 0x2B92C78;                         
            // 0x02914C40: LDR w0, [x8]               | W0 = 0x21E3;                            
            // 0x02914C44: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E3, ????);     
            // 0x02914C48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02914C4C: STRB w8, [x21, #0xaff]     | static_value_037B8AFF = true;            //  dest_result_addr=58428159
            label_0:
            // 0x02914C50: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x02914C54: LDR x8, [x8, #0xd98]       | X8 = 1152921504867282944;               
            // 0x02914C58: LDR x0, [x8]               | X0 = typeof(ConvertUtils.<TryConvert>c__AnonStorey2);
            object val_1 = null;
            // 0x02914C5C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ConvertUtils.<TryConvert>c__AnonStorey2), ????);
            // 0x02914C60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914C64: MOV x21, x0                | X21 = 1152921504867282944 (0x100000000F85F000);//ML01
            // 0x02914C68: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x02914C6C: CBZ x21, #0x2914c78        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x02914C70: STP x23, x22, [x21, #0x10] | typeof(ConvertUtils.<TryConvert>c__AnonStorey2).__il2cppRuntimeField_10 = culture;  typeof(ConvertUtils.<TryConvert>c__AnonStorey2).__il2cppRuntimeField_18 = targetType;  //  dest_result_addr=1152921504867282960 |  dest_result_addr=1152921504867282968
            typeof(ConvertUtils.<TryConvert>c__AnonStorey2).__il2cppRuntimeField_10 = culture;
            typeof(ConvertUtils.<TryConvert>c__AnonStorey2).__il2cppRuntimeField_18 = targetType;
            // 0x02914C74: B #0x2914c94               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x02914C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02914C7C: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x02914C80: STR x23, [x8]              | mem[16] = culture;                       //  dest_result_addr=16
            mem[16] = culture;
            // 0x02914C84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02914C88: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x02914C8C: STR x22, [x8]              | mem[24] = targetType;                    //  dest_result_addr=24
            mem[24] = targetType;
            // 0x02914C90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x02914C94: STR x20, [x21, #0x20]      | typeof(ConvertUtils.<TryConvert>c__AnonStorey2).__il2cppRuntimeField_20 = convertedValue;  //  dest_result_addr=1152921504867282976
            typeof(ConvertUtils.<TryConvert>c__AnonStorey2).__il2cppRuntimeField_20 = 1152921513973037472;
            // 0x02914C98: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x02914C9C: ADRP x9, #0x3674000        | X9 = 57098240 (0x3674000);              
            // 0x02914CA0: LDR x8, [x8, #0x158]       | X8 = 1152921513972966112;               
            // 0x02914CA4: LDR x9, [x9, #0x988]       | X9 = 1152921504868986880;               
            // 0x02914CA8: LDR x20, [x8]              | X20 = System.Object ConvertUtils.<TryConvert>c__AnonStorey2::<>m__0();
            // 0x02914CAC: LDR x0, [x9]               | X0 = typeof(Newtonsoft.Json.Utilities.Creator<T>);
            Newtonsoft.Json.Utilities.Creator<System.Object> val_2 = null;
            // 0x02914CB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.Creator<T>), ????);
            // 0x02914CB4: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x02914CB8: LDR x8, [x8, #0x7f8]       | X8 = 1152921513972967136;               
            // 0x02914CBC: MOV x1, x21                | X1 = 1152921504867282944 (0x100000000F85F000);//ML01
            // 0x02914CC0: MOV x2, x20                | X2 = 1152921513972966112 (0x100000022E43A2E0);//ML01
            // 0x02914CC4: MOV x22, x0                | X22 = 1152921504868986880 (0x100000000F9FF000);//ML01
            // 0x02914CC8: LDR x3, [x8]               | X3 = public System.Void Newtonsoft.Json.Utilities.Creator<System.Object>::.ctor(object object, IntPtr method);
            // 0x02914CCC: BL #0x19ea8e8              | .ctor(object:  val_1, method:  System.Object ConvertUtils.<TryConvert>c__AnonStorey2::<>m__0());
            val_2 = new Newtonsoft.Json.Utilities.Creator<System.Object>(object:  val_1, method:  System.Object ConvertUtils.<TryConvert>c__AnonStorey2::<>m__0());
            // 0x02914CD0: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x02914CD4: LDR x8, [x8, #0x160]       | X8 = 1152921513972968160;               
            // 0x02914CD8: MOV x1, x22                | X1 = 1152921504868986880 (0x100000000F9FF000);//ML01
            object val_3 = val_2;
            // 0x02914CDC: MOV x2, x19                | X2 = X4;//m1                            
            // 0x02914CE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914CE4: LDR x3, [x8]               | X3 = public static System.Boolean Newtonsoft.Json.Utilities.MiscellaneousUtils::TryAction<System.Object>(Newtonsoft.Json.Utilities.Creator<T> creator, out System.Object output);
            // 0x02914CE8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02914CEC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02914CF0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02914CF4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02914CF8: B #0x12fa6dc               | return Newtonsoft.Json.Utilities.MiscellaneousUtils.TryAction<System.Object>(creator:  0, output: out  object val_3 = val_2);
            return Newtonsoft.Json.Utilities.MiscellaneousUtils.TryAction<System.Object>(creator:  0, output: out  val_3);
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FDD844 VirtAddr: 0x00FDD844 -RVA: 0x00FDD844 
        // -ConvertUtils.ConvertOrCast<object>
        //
        //
        // Offset in libil2cpp.so: 0x00FDD844 (16635972), len: 184  VirtAddr: 0x00FDD844 RVA: 0x00FDD844 token: 100686620 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T ConvertOrCast<T>(object initialValue)
        {
            //
            // Disasemble & Code
            // 0x00FDD844: STP x22, x21, [sp, #-0x30]! | stack[1152921513973117648] = ???;  stack[1152921513973117656] = ???;  //  dest_result_addr=1152921513973117648 |  dest_result_addr=1152921513973117656
            // 0x00FDD848: STP x20, x19, [sp, #0x10]  | stack[1152921513973117664] = ???;  stack[1152921513973117672] = ???;  //  dest_result_addr=1152921513973117664 |  dest_result_addr=1152921513973117672
            // 0x00FDD84C: STP x29, x30, [sp, #0x20]  | stack[1152921513973117680] = ???;  stack[1152921513973117688] = ???;  //  dest_result_addr=1152921513973117680 |  dest_result_addr=1152921513973117688
            // 0x00FDD850: ADD x29, sp, #0x20         | X29 = (1152921513973117648 + 32) = 1152921513973117680 (0x100000022E45F2F0);
            // 0x00FDD854: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x00FDD858: LDRB w8, [x21, #0x430]     | W8 = (bool)static_value_03735430;       
            // 0x00FDD85C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00FDD860: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FDD864: TBNZ w8, #0, #0xfdd880     | if (static_value_03735430 == true) goto label_0;
            // 0x00FDD868: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00FDD86C: LDR x8, [x8, #0xc68]       | X8 = 0x2B92C5C;                         
            // 0x00FDD870: LDR w0, [x8]               | W0 = 0x21DC;                            
            // 0x00FDD874: BL #0x2782188              | X0 = sub_2782188( ?? 0x21DC, ????);     
            // 0x00FDD878: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FDD87C: STRB w8, [x21, #0x430]     | static_value_03735430 = true;            //  dest_result_addr=57889840
            label_0:
            // 0x00FDD880: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00FDD884: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00FDD888: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00FDD88C: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00FDD890: TBZ w8, #0, #0xfdd8a0      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00FDD894: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD898: CBNZ w8, #0xfdd8a0         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00FDD89C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_2:
            // 0x00FDD8A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDD8A8: BL #0x1c42254              | X0 = System.Globalization.CultureInfo.get_CurrentCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.CurrentCulture;
            // 0x00FDD8AC: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00FDD8B0: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x00FDD8B4: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00FDD8B8: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x00FDD8BC: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x00FDD8C0: TBZ w9, #0, #0xfdd8d4      | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00FDD8C4: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD8C8: CBNZ w9, #0xfdd8d4         | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00FDD8CC: MOV x0, x8                 | X0 = 1152921504867069952 (0x100000000F82B000);//ML01
            // 0x00FDD8D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_4:
            // 0x00FDD8D4: LDR x8, [x20, #0x30]       | X8 = X2 + 48;                           
            // 0x00FDD8D8: MOV x1, x19                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FDD8DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD8E0: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x00FDD8E4: LDR x3, [x8]               | X3 = X2 + 48;                           
            // 0x00FDD8E8: LDR x4, [x3]               | X4 = X2 + 48;                           
            // 0x00FDD8EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00FDD8F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00FDD8F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00FDD8F8: BR x4                      | goto X2 + 48;                           
            goto X2 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FDD8FC VirtAddr: 0x00FDD8FC -RVA: 0x00FDD8FC 
        // -ConvertUtils.ConvertOrCast<object>
        //
        //
        // Offset in libil2cpp.so: 0x00FDD8FC (16636156), len: 320  VirtAddr: 0x00FDD8FC RVA: 0x00FDD8FC token: 100686621 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T ConvertOrCast<T>(object initialValue, System.Globalization.CultureInfo culture)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x00FDD8FC: STP x22, x21, [sp, #-0x30]! | stack[1152921513973254224] = ???;  stack[1152921513973254232] = ???;  //  dest_result_addr=1152921513973254224 |  dest_result_addr=1152921513973254232
            // 0x00FDD900: STP x20, x19, [sp, #0x10]  | stack[1152921513973254240] = ???;  stack[1152921513973254248] = ???;  //  dest_result_addr=1152921513973254240 |  dest_result_addr=1152921513973254248
            // 0x00FDD904: STP x29, x30, [sp, #0x20]  | stack[1152921513973254256] = ???;  stack[1152921513973254264] = ???;  //  dest_result_addr=1152921513973254256 |  dest_result_addr=1152921513973254264
            // 0x00FDD908: ADD x29, sp, #0x20         | X29 = (1152921513973254224 + 32) = 1152921513973254256 (0x100000022E480870);
            // 0x00FDD90C: SUB sp, sp, #0x10          | SP = (1152921513973254224 - 16) = 1152921513973254208 (0x100000022E480840);
            // 0x00FDD910: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
            // 0x00FDD914: LDRB w8, [x22, #0x431]     | W8 = (bool)static_value_03735431;       
            // 0x00FDD918: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00FDD91C: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FDD920: MOV x21, x1                | X21 = culture;//m1                      
            // 0x00FDD924: TBNZ w8, #0, #0xfdd940     | if (static_value_03735431 == true) goto label_0;
            // 0x00FDD928: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00FDD92C: LDR x8, [x8, #0x420]       | X8 = 0x2B92C60;                         
            // 0x00FDD930: LDR w0, [x8]               | W0 = 0x21DD;                            
            // 0x00FDD934: BL #0x2782188              | X0 = sub_2782188( ?? 0x21DD, ????);     
            // 0x00FDD938: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FDD93C: STRB w8, [x22, #0x431]     | static_value_03735431 = true;            //  dest_result_addr=57889841
            label_0:
            // 0x00FDD940: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x00FDD944: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD948: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x00FDD94C: LDR x22, [x8]              | X22 = X3 + 48;                          
            // 0x00FDD950: LDR x0, [x9]               | X0 = typeof(System.Type);               
            // 0x00FDD954: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00FDD958: TBZ w8, #0, #0xfdd968      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00FDD95C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD960: CBNZ w8, #0xfdd968         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00FDD964: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00FDD968: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD96C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FDD970: MOV x1, x22                | X1 = X3 + 48;//m1                       
            // 0x00FDD974: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00FDD978: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00FDD97C: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x00FDD980: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00FDD984: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x00FDD988: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x00FDD98C: TBZ w9, #0, #0xfdd9a0      | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00FDD990: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x00FDD994: CBNZ w9, #0xfdd9a0         | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00FDD998: MOV x0, x8                 | X0 = 1152921504867069952 (0x100000000F82B000);//ML01
            // 0x00FDD99C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_4:
            // 0x00FDD9A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FDD9A4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00FDD9A8: MOV x1, x21                | X1 = culture;//m1                       
            // 0x00FDD9AC: MOV x2, x20                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FDD9B0: MOV x3, x22                | X3 = val_1;//m1                         
            // 0x00FDD9B4: BL #0x2907558              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.ConvertOrCast(initialValue:  0, culture:  culture, targetType:  __RuntimeMethodHiddenParam);
            object val_2 = Newtonsoft.Json.Utilities.ConvertUtils.ConvertOrCast(initialValue:  0, culture:  culture, targetType:  __RuntimeMethodHiddenParam);
            // 0x00FDD9B8: LDR x8, [x19, #0x30]       | X8 = X3 + 48;                           
            // 0x00FDD9BC: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00FDD9C0: LDR x19, [x8, #8]          | X19 = X3 + 48 + 8;                      
            // 0x00FDD9C4: MOV x0, x19                | X0 = X3 + 48 + 8;//m1                   
            // 0x00FDD9C8: BL #0x277461c              | X0 = sub_277461C( ?? X3 + 48 + 8, ????);
            // 0x00FDD9CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_4 = 0;
            // 0x00FDD9D0: CBZ x20, #0xfdda14         | if (val_2 == null) goto label_6;        
            if(val_2 == null)
            {
                goto label_6;
            }
            // 0x00FDD9D4: MOV x0, x20                | X0 = val_2;//m1                         
            val_4 = val_2;
            // 0x00FDD9D8: MOV x1, x19                | X1 = X3 + 48 + 8;//m1                   
            // 0x00FDD9DC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00FDD9E0: CBNZ x0, #0xfdda14         | if (val_2 != null) goto label_6;        
            if(val_4 != null)
            {
                goto label_6;
            }
            // 0x00FDD9E4: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x00FDD9E8: MOV x1, x19                | X1 = X3 + 48 + 8;//m1                   
            // 0x00FDD9EC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00FDD9F0: ADD x8, sp, #8             | X8 = (1152921513973254208 + 8) = 1152921513973254216 (0x100000022E480848);
            // 0x00FDD9F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00FDD9F8: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513973242272]
            // 0x00FDD9FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x00FDDA00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FDDA04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x00FDDA08: ADD x0, sp, #8             | X0 = (1152921513973254208 + 8) = 1152921513973254216 (0x100000022E480848);
            // 0x00FDDA0C: BL #0x299a140              | 
            // 0x00FDDA10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_4 = 0;
            label_6:
            // 0x00FDDA14: SUB sp, x29, #0x20         | SP = (1152921513973254256 - 32) = 1152921513973254224 (0x100000022E480850);
            // 0x00FDDA18: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00FDDA1C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00FDDA20: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00FDDA24: RET                        |  return (System.Object)null;            
            return (object)val_4;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x00FDDA28: MOV x19, x0                | 
            // 0x00FDDA2C: ADD x0, sp, #8             | 
            // 0x00FDDA30: BL #0x299a140              | 
            // 0x00FDDA34: MOV x0, x19                | 
            // 0x00FDDA38: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x02907558 (43021656), len: 328  VirtAddr: 0x02907558 RVA: 0x02907558 token: 100686622 methodIndex: 49139 delegateWrapperIndex: 0 methodInvoker: 0
        public static object ConvertOrCast(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType)
        {
            //
            // Disasemble & Code
            //  | 
            System.Type val_8;
            //  | 
            System.Globalization.CultureInfo val_9;
            // 0x02907558: STP x22, x21, [sp, #-0x30]! | stack[1152921513973407184] = ???;  stack[1152921513973407192] = ???;  //  dest_result_addr=1152921513973407184 |  dest_result_addr=1152921513973407192
            // 0x0290755C: STP x20, x19, [sp, #0x10]  | stack[1152921513973407200] = ???;  stack[1152921513973407208] = ???;  //  dest_result_addr=1152921513973407200 |  dest_result_addr=1152921513973407208
            // 0x02907560: STP x29, x30, [sp, #0x20]  | stack[1152921513973407216] = ???;  stack[1152921513973407224] = ???;  //  dest_result_addr=1152921513973407216 |  dest_result_addr=1152921513973407224
            // 0x02907564: ADD x29, sp, #0x20         | X29 = (1152921513973407184 + 32) = 1152921513973407216 (0x100000022E4A5DF0);
            // 0x02907568: SUB sp, sp, #0x10          | SP = (1152921513973407184 - 16) = 1152921513973407168 (0x100000022E4A5DC0);
            // 0x0290756C: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x02907570: LDRB w8, [x22, #0xb00]     | W8 = (bool)static_value_037B8B00;       
            // 0x02907574: MOV x20, x3                | X20 = X3;//m1                           
            // 0x02907578: MOV x21, x2                | X21 = targetType;//m1                   
            val_8 = targetType;
            // 0x0290757C: MOV x19, x1                | X19 = culture;//m1                      
            val_9 = culture;
            // 0x02907580: TBNZ w8, #0, #0x290759c    | if (static_value_037B8B00 == true) goto label_0;
            // 0x02907584: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x02907588: LDR x8, [x8, #0x320]       | X8 = 0x2B92C58;                         
            // 0x0290758C: LDR w0, [x8]               | W0 = 0x21DB;                            
            // 0x02907590: BL #0x2782188              | X0 = sub_2782188( ?? 0x21DB, ????);     
            // 0x02907594: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02907598: STRB w8, [x22, #0xb00]     | static_value_037B8B00 = true;            //  dest_result_addr=58428160
            label_0:
            // 0x0290759C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x029075A0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x029075A4: STR xzr, [sp, #8]          | stack[1152921513973407176] = 0x0;        //  dest_result_addr=1152921513973407176
            // 0x029075A8: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x029075AC: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x029075B0: LDR x8, [x8, #0xa88]       | X8 = 1152921504606900224;               
            // 0x029075B4: LDR x22, [x8]              | X22 = typeof(System.Object);            
            // 0x029075B8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x029075BC: TBZ w8, #0, #0x29075cc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x029075C0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x029075C4: CBNZ w8, #0x29075cc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x029075C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x029075CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x029075D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x029075D4: MOV x1, x22                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x029075D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x029075DC: CMP x0, x20                | STATE = COMPARE(val_1, X3)              
            // 0x029075E0: B.EQ #0x2907688            | if (val_1 == X3) goto label_10;         
            if(val_1 == X3)
            {
                goto label_10;
            }
            // 0x029075E4: CBNZ x19, #0x2907600       | if (culture != null) goto label_5;      
            if(val_9 != null)
            {
                goto label_5;
            }
            // 0x029075E8: MOV x1, x20                | X1 = X3;//m1                            
            // 0x029075EC: BL #0x2913c3c              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullable(t:  System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle()));
            bool val_2 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullable(t:  val_1);
            // 0x029075F0: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x029075F4: TBZ w8, #0, #0x2907600     | if ((val_2 & 1) == false) goto label_5; 
            if(val_3 == false)
            {
                goto label_5;
            }
            // 0x029075F8: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x029075FC: B #0x2907688               |  goto label_10;                         
            goto label_10;
            label_5:
            // 0x02907600: ADRP x22, #0x362b000       | X22 = 56799232 (0x362B000);             
            // 0x02907604: LDR x22, [x22, #0xc10]     | X22 = 1152921504867069952;              
            // 0x02907608: LDR x0, [x22]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x0290760C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02907610: TBZ w8, #0, #0x2907620     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x02907614: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02907618: CBNZ w8, #0x2907620        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0290761C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_8:
            // 0x02907620: ADD x4, sp, #8             | X4 = (1152921513973407168 + 8) = 1152921513973407176 (0x100000022E4A5DC8);
            // 0x02907624: MOV x1, x19                | X1 = culture;//m1                       
            // 0x02907628: MOV x2, x21                | X2 = targetType;//m1                    
            // 0x0290762C: MOV x3, x20                | X3 = X3;//m1                            
            object val_4 = X3;
            // 0x02907630: BL #0x2914c08              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.TryConvert(initialValue:  null, culture:  val_9, targetType:  val_8, convertedValue: out  object val_4 = X3);
            bool val_5 = Newtonsoft.Json.Utilities.ConvertUtils.TryConvert(initialValue:  null, culture:  val_9, targetType:  val_8, convertedValue: out  val_4);
            // 0x02907634: TBZ w0, #0, #0x2907640     | if (val_5 == false) goto label_9;       
            if(val_5 == false)
            {
                goto label_9;
            }
            // 0x02907638: LDR x19, [sp, #8]          | X19 = 0x0;                              
            val_9 = 0;
            // 0x0290763C: B #0x2907688               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x02907640: CBZ x19, #0x2907658        | if (culture == null) goto label_11;     
            if(val_9 == null)
            {
                goto label_11;
            }
            // 0x02907644: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02907648: MOV x0, x19                | X0 = culture;//m1                       
            // 0x0290764C: BL #0x16fb28c              | X0 = culture.GetType();                 
            System.Type val_6 = val_9.GetType();
            // 0x02907650: MOV x21, x0                | X21 = val_6;//m1                        
            val_8 = val_6;
            // 0x02907654: B #0x290765c               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x02907658: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_12:
            // 0x0290765C: LDR x0, [x22]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02907660: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02907664: TBZ w8, #0, #0x2907674     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x02907668: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x0290766C: CBNZ w8, #0x2907674        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x02907670: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_14:
            // 0x02907674: MOV x1, x19                | X1 = culture;//m1                       
            // 0x02907678: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x0290767C: MOV x3, x20                | X3 = X3;//m1                            
            // 0x02907680: BL #0x2914988              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.EnsureTypeAssignable(value:  null, initialType:  val_9, targetType:  val_8);
            object val_7 = Newtonsoft.Json.Utilities.ConvertUtils.EnsureTypeAssignable(value:  null, initialType:  val_9, targetType:  val_8);
            // 0x02907684: MOV x19, x0                | X19 = val_7;//m1                        
            val_9 = val_7;
            label_10:
            // 0x02907688: MOV x0, x19                | X0 = val_7;//m1                         
            // 0x0290768C: SUB sp, x29, #0x20         | SP = (1152921513973407216 - 32) = 1152921513973407184 (0x100000022E4A5DD0);
            // 0x02907690: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02907694: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02907698: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0290769C: RET                        |  return (System.Object)val_7;           
            return (object)val_9;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x012FA5B8 VirtAddr: 0x012FA5B8 -RVA: 0x012FA5B8 
        // -ConvertUtils.TryConvertOrCast<object>
        //
        //
        // Offset in libil2cpp.so: 0x012FA5B8 (19899832), len: 192  VirtAddr: 0x012FA5B8 RVA: 0x012FA5B8 token: 100686623 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryConvertOrCast<T>(object initialValue, out T convertedValue)
        {
            //
            // Disasemble & Code
            // 0x012FA5B8: STP x22, x21, [sp, #-0x30]! | stack[1152921513973555984] = ???;  stack[1152921513973555992] = ???;  //  dest_result_addr=1152921513973555984 |  dest_result_addr=1152921513973555992
            // 0x012FA5BC: STP x20, x19, [sp, #0x10]  | stack[1152921513973556000] = ???;  stack[1152921513973556008] = ???;  //  dest_result_addr=1152921513973556000 |  dest_result_addr=1152921513973556008
            // 0x012FA5C0: STP x29, x30, [sp, #0x20]  | stack[1152921513973556016] = ???;  stack[1152921513973556024] = ???;  //  dest_result_addr=1152921513973556016 |  dest_result_addr=1152921513973556024
            // 0x012FA5C4: ADD x29, sp, #0x20         | X29 = (1152921513973555984 + 32) = 1152921513973556016 (0x100000022E4CA330);
            // 0x012FA5C8: ADRP x22, #0x3736000       | X22 = 57892864 (0x3736000);             
            // 0x012FA5CC: LDRB w8, [x22, #0x8b2]     | W8 = (bool)static_value_037368B2;       
            // 0x012FA5D0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x012FA5D4: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012FA5D8: MOV x20, x1                | X20 = 1152921513973604128 (0x100000022E4D5F20);//ML01
            // 0x012FA5DC: TBNZ w8, #0, #0x12fa5f8    | if (static_value_037368B2 == true) goto label_0;
            // 0x012FA5E0: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x012FA5E4: LDR x8, [x8, #0xa58]       | X8 = 0x2B92C84;                         
            // 0x012FA5E8: LDR w0, [x8]               | W0 = 0x21E6;                            
            // 0x012FA5EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E6, ????);     
            // 0x012FA5F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x012FA5F4: STRB w8, [x22, #0x8b2]     | static_value_037368B2 = true;            //  dest_result_addr=57895090
            label_0:
            // 0x012FA5F8: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x012FA5FC: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x012FA600: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x012FA604: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x012FA608: TBZ w8, #0, #0x12fa618     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x012FA60C: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x012FA610: CBNZ w8, #0x12fa618        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x012FA614: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_2:
            // 0x012FA618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA61C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x012FA620: BL #0x1c42254              | X0 = System.Globalization.CultureInfo.get_CurrentCulture();
            System.Globalization.CultureInfo val_1 = System.Globalization.CultureInfo.CurrentCulture;
            // 0x012FA624: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x012FA628: LDR x8, [x8, #0xc10]       | X8 = 1152921504867069952;               
            // 0x012FA62C: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x012FA630: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x012FA634: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x012FA638: TBZ w9, #0, #0x12fa64c     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x012FA63C: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x012FA640: CBNZ w9, #0x12fa64c        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x012FA644: MOV x0, x8                 | X0 = 1152921504867069952 (0x100000000F82B000);//ML01
            // 0x012FA648: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_4:
            // 0x012FA64C: LDR x8, [x21, #0x30]       | X8 = X3 + 48;                           
            // 0x012FA650: MOV x1, x20                | X1 = 1152921513973604128 (0x100000022E4D5F20);//ML01
            // 0x012FA654: MOV x3, x19                | X3 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA658: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA65C: LDR x4, [x8]               | X4 = X3 + 48;                           
            // 0x012FA660: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x012FA664: LDR x5, [x4]               | X5 = X3 + 48;                           
            // 0x012FA668: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x012FA66C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x012FA670: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x012FA674: BR x5                      | goto X3 + 48;                           
            goto X3 + 48;
        
        }
        // Generic instance method:
        //
        // file offset: 0x012FA500 VirtAddr: 0x012FA500 -RVA: 0x012FA500 
        // -ConvertUtils.TryConvertOrCast<object>
        //
        //
        // Offset in libil2cpp.so: 0x012FA500 (19899648), len: 184  VirtAddr: 0x012FA500 RVA: 0x012FA500 token: 100686624 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryConvertOrCast<T>(object initialValue, System.Globalization.CultureInfo culture, out T convertedValue)
        {
            //
            // Disasemble & Code
            // 0x012FA500: STP x24, x23, [sp, #-0x40]! | stack[1152921513973692416] = ???;  stack[1152921513973692424] = ???;  //  dest_result_addr=1152921513973692416 |  dest_result_addr=1152921513973692424
            // 0x012FA504: STP x22, x21, [sp, #0x10]  | stack[1152921513973692432] = ???;  stack[1152921513973692440] = ???;  //  dest_result_addr=1152921513973692432 |  dest_result_addr=1152921513973692440
            // 0x012FA508: STP x20, x19, [sp, #0x20]  | stack[1152921513973692448] = ???;  stack[1152921513973692456] = ???;  //  dest_result_addr=1152921513973692448 |  dest_result_addr=1152921513973692456
            // 0x012FA50C: STP x29, x30, [sp, #0x30]  | stack[1152921513973692464] = ???;  stack[1152921513973692472] = ???;  //  dest_result_addr=1152921513973692464 |  dest_result_addr=1152921513973692472
            // 0x012FA510: ADD x29, sp, #0x30         | X29 = (1152921513973692416 + 48) = 1152921513973692464 (0x100000022E4EB830);
            // 0x012FA514: MOV x20, x4                | X20 = X4;//m1                           
            // 0x012FA518: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA51C: MOV x19, x3                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x012FA520: MOV x22, x1                | X22 = culture;//m1                      
            // 0x012FA524: LDR x21, [x8]              | X21 = X4 + 48;                          
            // 0x012FA528: MOV x0, x21                | X0 = X4 + 48;//m1                       
            // 0x012FA52C: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48, ????);    
            // 0x012FA530: MOV x0, x21                | X0 = X4 + 48;//m1                       
            // 0x012FA534: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48, ????);
            // 0x012FA538: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA53C: MOV x21, x0                | X21 = X4 + 48;//m1                      
            // 0x012FA540: LDR x1, [x8, #8]           | X1 = X4 + 48 + 8;                       
            // 0x012FA544: LDR x8, [x1]               | X8 = X4 + 48 + 8;                       
            // 0x012FA548: BLR x8                     | X0 = X4 + 48 + 8();                     
            // 0x012FA54C: CBNZ x21, #0x12fa554       | if (X4 + 48 != 0) goto label_0;         
            if((X4 + 48) != 0)
            {
                goto label_0;
            }
            // 0x012FA550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4 + 48, ????);    
            label_0:
            // 0x012FA554: STR x22, [x21, #0x10]      | mem2[0] = culture;                       //  dest_result_addr=0
            mem2[0] = culture;
            // 0x012FA558: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA55C: LDP x22, x23, [x8, #0x10]  | X22 = X4 + 48 + 16; X23 = X4 + 48 + 16 + 8; //  | 
            // 0x012FA560: MOV x0, x23                | X0 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA564: BL #0x277461c              | X0 = sub_277461C( ?? X4 + 48 + 16 + 8, ????);
            // 0x012FA568: MOV x0, x23                | X0 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA56C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? X4 + 48 + 16 + 8, ????);
            // 0x012FA570: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA574: MOV x1, x21                | X1 = X4 + 48;//m1                       
            // 0x012FA578: MOV x2, x22                | X2 = X4 + 48 + 16;//m1                  
            // 0x012FA57C: MOV x23, x0                | X23 = X4 + 48 + 16 + 8;//m1             
            // 0x012FA580: LDR x3, [x8, #0x20]        | X3 = X4 + 48 + 32;                      
            // 0x012FA584: LDR x8, [x3]               | X8 = X4 + 48 + 32;                      
            // 0x012FA588: BLR x8                     | X0 = X4 + 48 + 32();                    
            // 0x012FA58C: LDR x8, [x20, #0x30]       | X8 = X4 + 48;                           
            // 0x012FA590: MOV x2, x19                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x012FA594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x012FA598: MOV x1, x23                | X1 = X4 + 48 + 16 + 8;//m1              
            // 0x012FA59C: LDR x3, [x8, #0x28]        | X3 = X4 + 48 + 40;                      
            // 0x012FA5A0: LDR x4, [x3]               | X4 = X4 + 48 + 40;                      
            // 0x012FA5A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x012FA5A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x012FA5AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x012FA5B0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x012FA5B4: BR x4                      | goto X4 + 48 + 40;                      
            goto X4 + 48 + 40;
        
        }
        //
        // Offset in libil2cpp.so: 0x02914D04 (43076868), len: 244  VirtAddr: 0x02914D04 RVA: 0x02914D04 token: 100686625 methodIndex: 49140 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool TryConvertOrCast(object initialValue, System.Globalization.CultureInfo culture, System.Type targetType, out object convertedValue)
        {
            //
            // Disasemble & Code
            // 0x02914D04: STP x24, x23, [sp, #-0x40]! | stack[1152921513973833984] = ???;  stack[1152921513973833992] = ???;  //  dest_result_addr=1152921513973833984 |  dest_result_addr=1152921513973833992
            // 0x02914D08: STP x22, x21, [sp, #0x10]  | stack[1152921513973834000] = ???;  stack[1152921513973834008] = ???;  //  dest_result_addr=1152921513973834000 |  dest_result_addr=1152921513973834008
            // 0x02914D0C: STP x20, x19, [sp, #0x20]  | stack[1152921513973834016] = ???;  stack[1152921513973834024] = ???;  //  dest_result_addr=1152921513973834016 |  dest_result_addr=1152921513973834024
            // 0x02914D10: STP x29, x30, [sp, #0x30]  | stack[1152921513973834032] = ???;  stack[1152921513973834040] = ???;  //  dest_result_addr=1152921513973834032 |  dest_result_addr=1152921513973834040
            // 0x02914D14: ADD x29, sp, #0x30         | X29 = (1152921513973833984 + 48) = 1152921513973834032 (0x100000022E50E130);
            // 0x02914D18: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x02914D1C: LDRB w8, [x21, #0xb01]     | W8 = (bool)static_value_037B8B01;       
            // 0x02914D20: MOV x19, x4                | X19 = X4;//m1                           
            // 0x02914D24: MOV x20, x3                | X20 = 1152921513973890336 (0x100000022E51BD20);//ML01
            // 0x02914D28: MOV x22, x2                | X22 = targetType;//m1                   
            // 0x02914D2C: MOV x23, x1                | X23 = culture;//m1                      
            // 0x02914D30: TBNZ w8, #0, #0x2914d4c    | if (static_value_037B8B01 == true) goto label_0;
            // 0x02914D34: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x02914D38: LDR x8, [x8, #0x378]       | X8 = 0x2B92C80;                         
            // 0x02914D3C: LDR w0, [x8]               | W0 = 0x21E5;                            
            // 0x02914D40: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E5, ????);     
            // 0x02914D44: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02914D48: STRB w8, [x21, #0xb01]     | static_value_037B8B01 = true;            //  dest_result_addr=58428161
            label_0:
            // 0x02914D4C: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x02914D50: LDR x8, [x8, #0x230]       | X8 = 1152921504867389440;               
            // 0x02914D54: LDR x0, [x8]               | X0 = typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4);
            object val_1 = null;
            // 0x02914D58: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4), ????);
            // 0x02914D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914D60: MOV x21, x0                | X21 = 1152921504867389440 (0x100000000F879000);//ML01
            // 0x02914D64: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x02914D68: CBZ x21, #0x2914d74        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x02914D6C: STP x23, x22, [x21, #0x10] | typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4).__il2cppRuntimeField_10 = culture;  typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4).__il2cppRuntimeField_18 = targetType;  //  dest_result_addr=1152921504867389456 |  dest_result_addr=1152921504867389464
            typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4).__il2cppRuntimeField_10 = culture;
            typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4).__il2cppRuntimeField_18 = targetType;
            // 0x02914D70: B #0x2914d90               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x02914D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02914D78: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x02914D7C: STR x23, [x8]              | mem[16] = culture;                       //  dest_result_addr=16
            mem[16] = culture;
            // 0x02914D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x02914D84: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x02914D88: STR x22, [x8]              | mem[24] = targetType;                    //  dest_result_addr=24
            mem[24] = targetType;
            // 0x02914D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x02914D90: STR x20, [x21, #0x20]      | typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4).__il2cppRuntimeField_20 = convertedValue;  //  dest_result_addr=1152921504867389472
            typeof(ConvertUtils.<TryConvertOrCast>c__AnonStorey4).__il2cppRuntimeField_20 = 1152921513973890336;
            // 0x02914D94: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x02914D98: ADRP x9, #0x3674000        | X9 = 57098240 (0x3674000);              
            // 0x02914D9C: LDR x8, [x8, #0x2b8]       | X8 = 1152921513973821024;               
            // 0x02914DA0: LDR x9, [x9, #0x988]       | X9 = 1152921504868986880;               
            // 0x02914DA4: LDR x20, [x8]              | X20 = System.Object ConvertUtils.<TryConvertOrCast>c__AnonStorey4::<>m__0();
            // 0x02914DA8: LDR x0, [x9]               | X0 = typeof(Newtonsoft.Json.Utilities.Creator<T>);
            Newtonsoft.Json.Utilities.Creator<System.Object> val_2 = null;
            // 0x02914DAC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.Creator<T>), ????);
            // 0x02914DB0: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x02914DB4: LDR x8, [x8, #0x7f8]       | X8 = 1152921513972967136;               
            // 0x02914DB8: MOV x1, x21                | X1 = 1152921504867389440 (0x100000000F879000);//ML01
            // 0x02914DBC: MOV x2, x20                | X2 = 1152921513973821024 (0x100000022E50AE60);//ML01
            // 0x02914DC0: MOV x22, x0                | X22 = 1152921504868986880 (0x100000000F9FF000);//ML01
            // 0x02914DC4: LDR x3, [x8]               | X3 = public System.Void Newtonsoft.Json.Utilities.Creator<System.Object>::.ctor(object object, IntPtr method);
            // 0x02914DC8: BL #0x19ea8e8              | .ctor(object:  val_1, method:  System.Object ConvertUtils.<TryConvertOrCast>c__AnonStorey4::<>m__0());
            val_2 = new Newtonsoft.Json.Utilities.Creator<System.Object>(object:  val_1, method:  System.Object ConvertUtils.<TryConvertOrCast>c__AnonStorey4::<>m__0());
            // 0x02914DCC: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x02914DD0: LDR x8, [x8, #0x160]       | X8 = 1152921513972968160;               
            // 0x02914DD4: MOV x1, x22                | X1 = 1152921504868986880 (0x100000000F9FF000);//ML01
            object val_3 = val_2;
            // 0x02914DD8: MOV x2, x19                | X2 = X4;//m1                            
            // 0x02914DDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914DE0: LDR x3, [x8]               | X3 = public static System.Boolean Newtonsoft.Json.Utilities.MiscellaneousUtils::TryAction<System.Object>(Newtonsoft.Json.Utilities.Creator<T> creator, out System.Object output);
            // 0x02914DE4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02914DE8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02914DEC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02914DF0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02914DF4: B #0x12fa6dc               | return Newtonsoft.Json.Utilities.MiscellaneousUtils.TryAction<System.Object>(creator:  0, output: out  object val_3 = val_2);
            return Newtonsoft.Json.Utilities.MiscellaneousUtils.TryAction<System.Object>(creator:  0, output: out  val_3);
        
        }
        //
        // Offset in libil2cpp.so: 0x02914988 (43075976), len: 640  VirtAddr: 0x02914988 RVA: 0x02914988 token: 100686626 methodIndex: 49141 delegateWrapperIndex: 0 methodInvoker: 0
        private static object EnsureTypeAssignable(object value, System.Type initialType, System.Type targetType)
        {
            //
            // Disasemble & Code
            //  | 
            object val_10;
            //  | 
            var val_11;
            //  | 
            System.Type val_12;
            //  | 
            System.Type val_13;
            // 0x02914988: STP x24, x23, [sp, #-0x40]! | stack[1152921513973997280] = ???;  stack[1152921513973997288] = ???;  //  dest_result_addr=1152921513973997280 |  dest_result_addr=1152921513973997288
            // 0x0291498C: STP x22, x21, [sp, #0x10]  | stack[1152921513973997296] = ???;  stack[1152921513973997304] = ???;  //  dest_result_addr=1152921513973997296 |  dest_result_addr=1152921513973997304
            // 0x02914990: STP x20, x19, [sp, #0x20]  | stack[1152921513973997312] = ???;  stack[1152921513973997320] = ???;  //  dest_result_addr=1152921513973997312 |  dest_result_addr=1152921513973997320
            // 0x02914994: STP x29, x30, [sp, #0x30]  | stack[1152921513973997328] = ???;  stack[1152921513973997336] = ???;  //  dest_result_addr=1152921513973997328 |  dest_result_addr=1152921513973997336
            // 0x02914998: ADD x29, sp, #0x30         | X29 = (1152921513973997280 + 48) = 1152921513973997328 (0x100000022E535F10);
            // 0x0291499C: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x029149A0: LDRB w8, [x22, #0xb02]     | W8 = (bool)static_value_037B8B02;       
            // 0x029149A4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x029149A8: MOV x20, x2                | X20 = targetType;//m1                   
            // 0x029149AC: MOV x21, x1                | X21 = initialType;//m1                  
            val_10 = initialType;
            // 0x029149B0: TBNZ w8, #0, #0x29149cc    | if (static_value_037B8B02 == true) goto label_0;
            // 0x029149B4: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x029149B8: LDR x8, [x8, #0xbb8]       | X8 = 0x2B92C68;                         
            // 0x029149BC: LDR w0, [x8]               | W0 = 0x21DF;                            
            // 0x029149C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x21DF, ????);     
            // 0x029149C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x029149C8: STRB w8, [x22, #0xb02]     | static_value_037B8B02 = true;            //  dest_result_addr=58428162
            label_0:
            // 0x029149CC: CBZ x21, #0x2914a80        | if (initialType == null) goto label_1;  
            if(val_10 == null)
            {
                goto label_1;
            }
            // 0x029149D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x029149D4: MOV x0, x21                | X0 = initialType;//m1                   
            // 0x029149D8: BL #0x16fb28c              | X0 = initialType.GetType();             
            System.Type val_1 = val_10.GetType();
            // 0x029149DC: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x029149E0: CBNZ x19, #0x29149e8       | if (X3 != 0) goto label_2;              
            if(X3 != 0)
            {
                goto label_2;
            }
            // 0x029149E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x029149E8: LDR x8, [x19]              | X8 = X3;                                
            // 0x029149EC: MOV x0, x19                | X0 = X3;//m1                            
            // 0x029149F0: MOV x1, x22                | X1 = val_1;//m1                         
            // 0x029149F4: LDR x9, [x8, #0x3e0]       | X9 = X3 + 992;                          
            // 0x029149F8: LDR x2, [x8, #0x3e8]       | X2 = X3 + 1000;                         
            // 0x029149FC: BLR x9                     | X0 = X3 + 992();                        
            // 0x02914A00: AND w8, w0, #1             | W8 = (X3 & 1);                          
            var val_2 = X3 & 1;
            // 0x02914A04: TBNZ w8, #0, #0x2914a94    | if (((X3 & 1) & 0x1) != 0) goto label_3;
            if((val_2 & 1) != 0)
            {
                goto label_3;
            }
            // 0x02914A08: ADRP x23, #0x362b000       | X23 = 56799232 (0x362B000);             
            // 0x02914A0C: LDR x23, [x23, #0xc10]     | X23 = 1152921504867069952;              
            // 0x02914A10: LDR x0, [x23]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            val_11 = null;
            // 0x02914A14: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_10A;
            // 0x02914A18: TBZ w8, #0, #0x2914a2c     | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x02914A1C: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished;
            // 0x02914A20: CBNZ w8, #0x2914a2c        | if (Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x02914A24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            // 0x02914A28: LDR x0, [x23]              | X0 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            val_11 = null;
            label_5:
            // 0x02914A2C: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_static_fields;
            // 0x02914A30: LDR x23, [x8]              | X23 = Newtonsoft.Json.Utilities.ConvertUtils.CastConverters;
            // 0x02914A34: CBNZ x23, #0x2914a3c       | if (Newtonsoft.Json.Utilities.ConvertUtils.CastConverters != null) goto label_6;
            if(Newtonsoft.Json.Utilities.ConvertUtils.CastConverters != null)
            {
                goto label_6;
            }
            // 0x02914A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Utilities.ConvertUtils), ????);
            label_6:
            // 0x02914A3C: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x02914A40: LDR x8, [x8, #0xe0]        | X8 = 1152921513973966752;               
            // 0x02914A44: MOV x0, x23                | X0 = Newtonsoft.Json.Utilities.ConvertUtils.CastConverters;//m1
            // 0x02914A48: MOV x1, x22                | X1 = val_1;//m1                         
            // 0x02914A4C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x02914A50: LDR x3, [x8]               | X3 = public System.Func<System.Object, System.Object> Newtonsoft.Json.Utilities.ThreadSafeStore<TypeConvertKey, System.Func<System.Object, System.Object>>::Get(TypeConvertKey key);
            // 0x02914A54: BL #0x19f059c              | X0 = Newtonsoft.Json.Utilities.ConvertUtils.CastConverters.Get(key:  new TypeConvertKey() {_initialType = val_1, _targetType = X3});
            System.Func<System.Object, System.Object> val_3 = Newtonsoft.Json.Utilities.ConvertUtils.CastConverters.Get(key:  new TypeConvertKey() {_initialType = val_1, _targetType = X3});
            // 0x02914A58: CBZ x0, #0x2914aac         | if (val_3 == null) goto label_8;        
            if(val_3 == null)
            {
                goto label_8;
            }
            // 0x02914A5C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x02914A60: LDR x8, [x8, #0x1c0]       | X8 = 1152921513915466960;               
            // 0x02914A64: MOV x1, x21                | X1 = initialType;//m1                   
            // 0x02914A68: LDR x2, [x8]               | X2 = public System.Object System.Func<System.Object, System.Object>::Invoke(System.Object arg1);
            // 0x02914A6C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02914A70: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02914A74: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02914A78: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02914A7C: B #0x21cc06c               | return val_3.Invoke(arg1:  val_10);     
            return val_3.Invoke(arg1:  val_10);
            label_1:
            // 0x02914A80: MOV x1, x19                | X1 = X3;//m1                            
            // 0x02914A84: BL #0x2913c3c              | X0 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullable(t:  8671);
            bool val_4 = Newtonsoft.Json.Utilities.ReflectionUtils.IsNullable(t:  8671);
            // 0x02914A88: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x02914A8C: TBZ w8, #0, #0x2914aac     | if ((val_4 & 1) == false) goto label_8; 
            if(val_5 == false)
            {
                goto label_8;
            }
            // 0x02914A90: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_3:
            // 0x02914A94: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x02914A98: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x02914A9C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x02914AA0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x02914AA4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x02914AA8: RET                        |  return (System.Object)null;            
            return (object)val_10;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_8:
            // 0x02914AAC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x02914AB0: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x02914AB4: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x02914AB8: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x02914ABC: TBZ w8, #0, #0x2914acc     | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x02914AC0: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x02914AC4: CBNZ w8, #0x2914acc        | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x02914AC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_10:
            // 0x02914ACC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914AD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914AD4: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_6 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x02914AD8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x02914ADC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x02914AE0: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x02914AE4: LDR x22, [x8]              | X22 = typeof(System.Object[]);          
            // 0x02914AE8: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02914AEC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x02914AF0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x02914AF4: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_12 = null;
            // 0x02914AF8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x02914AFC: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x02914B00: LDR x8, [x8, #0x460]       | X8 = (string**)(1152921513973975968)("Could not cast or convert from {0} to {1}.");
            // 0x02914B04: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02914B08: LDR x23, [x8]              | X23 = "Could not cast or convert from {0} to {1}.";
            // 0x02914B0C: CBNZ x20, #0x2914b20       | if (targetType != null) goto label_11;  
            if(targetType != null)
            {
                goto label_11;
            }
            // 0x02914B10: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x02914B14: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921513940097696)("{null}");
            // 0x02914B18: LDR x20, [x8]              | X20 = "{null}";                         
            val_13 = "{null}";
            // 0x02914B1C: B #0x2914b34               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x02914B20: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x02914B24: MOV x0, x20                | X0 = targetType;//m1                    
            val_12 = targetType;
            // 0x02914B28: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Type).__il2cppRuntimeField_140; X1 = typeof(System.Type).__il2cppRuntimeField_148; //  | 
            // 0x02914B2C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_140();
            // 0x02914B30: MOV x20, x0                | X20 = targetType;//m1                   
            val_13 = val_12;
            label_12:
            // 0x02914B34: CBNZ x22, #0x2914b3c       | if ( != null) goto label_13;            
            if(null != null)
            {
                goto label_13;
            }
            // 0x02914B38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? targetType, ????); 
            label_13:
            // 0x02914B3C: CBZ x20, #0x2914b60        | if (targetType == null) goto label_15;  
            if(val_13 == null)
            {
                goto label_15;
            }
            // 0x02914B40: LDR x8, [x22]              | X8 = ;                                  
            // 0x02914B44: MOV x0, x20                | X0 = targetType;//m1                    
            val_12 = val_13;
            // 0x02914B48: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02914B4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? targetType, ????); 
            // 0x02914B50: CBNZ x0, #0x2914b60        | if (targetType != null) goto label_15;  
            if(val_12 != null)
            {
                goto label_15;
            }
            // 0x02914B54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? targetType, ????); 
            // 0x02914B58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914B5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? targetType, ????); 
            label_15:
            // 0x02914B60: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02914B64: CBNZ w8, #0x2914b74        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_16;
            // 0x02914B68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? targetType, ????); 
            // 0x02914B6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914B70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? targetType, ????); 
            label_16:
            // 0x02914B74: STR x20, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = targetType;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_13;
            // 0x02914B78: CBZ x19, #0x2914b9c        | if (X3 == 0) goto label_18;             
            if(X3 == 0)
            {
                goto label_18;
            }
            // 0x02914B7C: LDR x8, [x22]              | X8 = ;                                  
            // 0x02914B80: MOV x0, x19                | X0 = X3;//m1                            
            val_12 = X3;
            // 0x02914B84: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x02914B88: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X3, ????);         
            // 0x02914B8C: CBNZ x0, #0x2914b9c        | if (X3 != 0) goto label_18;             
            if(val_12 != 0)
            {
                goto label_18;
            }
            // 0x02914B90: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X3, ????);         
            // 0x02914B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914B98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X3, ????);         
            label_18:
            // 0x02914B9C: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x02914BA0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x02914BA4: B.HI #0x2914bb4            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_19;
            // 0x02914BA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X3, ????);         
            // 0x02914BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914BB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X3, ????);         
            label_19:
            // 0x02914BB4: MOV x1, x23                | X1 = 1152921513973975968 (0x100000022E530BA0);//ML01
            // 0x02914BB8: MOV x2, x21                | X2 = val_6;//m1                         
            // 0x02914BBC: MOV x3, x22                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x02914BC0: STR x19, [x22, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = X3;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = X3;
            // 0x02914BC4: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_12 = X3, provider:  "Could not cast or convert from {0} to {1}.", args:  val_6);
            string val_7 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  val_12, provider:  "Could not cast or convert from {0} to {1}.", args:  val_6);
            // 0x02914BC8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x02914BCC: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x02914BD0: MOV x19, x0                | X19 = val_7;//m1                        
            // 0x02914BD4: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x02914BD8: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_8 = null;
            // 0x02914BDC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x02914BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914BE4: MOV x1, x19                | X1 = val_7;//m1                         
            // 0x02914BE8: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02914BEC: BL #0x1c32b48              | .ctor(message:  val_7);                 
            val_8 = new System.Exception(message:  val_7);
            // 0x02914BF0: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x02914BF4: LDR x8, [x8, #0x1d8]       | X8 = 1152921513973980224;               
            // 0x02914BF8: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x02914BFC: LDR x1, [x8]               | X1 = static System.Object Newtonsoft.Json.Utilities.ConvertUtils::EnsureTypeAssignable(object value, System.Type initialType, System.Type targetType);
            // 0x02914C00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x02914C04: BL #0x28fffbc              | X0 = Convert(value:  static System.Object Newtonsoft.Json.Utilities.ConvertUtils::EnsureTypeAssignable(object value, System.Type initialType, System.Type targetType), typeCode:  0);
            object val_9 = Convert(value:  static System.Object Newtonsoft.Json.Utilities.ConvertUtils::EnsureTypeAssignable(object value, System.Type initialType, System.Type targetType), typeCode:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x0290E840 (43051072), len: 100  VirtAddr: 0x0290E840 RVA: 0x0290E840 token: 100686627 methodIndex: 49142 delegateWrapperIndex: 0 methodInvoker: 0
        internal static System.ComponentModel.TypeConverter GetConverter(System.Type t)
        {
            //
            // Disasemble & Code
            // 0x0290E840: STP x20, x19, [sp, #-0x20]! | stack[1152921513974146176] = ???;  stack[1152921513974146184] = ???;  //  dest_result_addr=1152921513974146176 |  dest_result_addr=1152921513974146184
            // 0x0290E844: STP x29, x30, [sp, #0x10]  | stack[1152921513974146192] = ???;  stack[1152921513974146200] = ???;  //  dest_result_addr=1152921513974146192 |  dest_result_addr=1152921513974146200
            // 0x0290E848: ADD x29, sp, #0x10         | X29 = (1152921513974146176 + 16) = 1152921513974146192 (0x100000022E55A490);
            // 0x0290E84C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x0290E850: LDRB w8, [x20, #0xb03]     | W8 = (bool)static_value_037B8B03;       
            // 0x0290E854: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0290E858: TBNZ w8, #0, #0x290e874    | if (static_value_037B8B03 == true) goto label_0;
            // 0x0290E85C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0290E860: LDR x8, [x8, #0xf8]        | X8 = 0x2B92C6C;                         
            // 0x0290E864: LDR w0, [x8]               | W0 = 0x21E0;                            
            // 0x0290E868: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E0, ????);     
            // 0x0290E86C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0290E870: STRB w8, [x20, #0xb03]     | static_value_037B8B03 = true;            //  dest_result_addr=58428163
            label_0:
            // 0x0290E874: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x0290E878: LDR x8, [x8, #0xe08]       | X8 = 1152921504866111488;               
            // 0x0290E87C: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Serialization.JsonTypeReflector);
            // 0x0290E880: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_10A;
            // 0x0290E884: TBZ w8, #0, #0x290e894     | if (Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0290E888: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_cctor_finished;
            // 0x0290E88C: CBNZ w8, #0x290e894        | if (Newtonsoft.Json.Serialization.JsonTypeReflector.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0290E890: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Serialization.JsonTypeReflector), ????);
            label_2:
            // 0x0290E894: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0290E898: MOV x1, x19                | X1 = X1;//m1                            
            // 0x0290E89C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0290E8A0: B #0x290ffd0               | return Newtonsoft.Json.Serialization.JsonTypeReflector.GetTypeConverter(type:  null);
            return Newtonsoft.Json.Serialization.JsonTypeReflector.GetTypeConverter(type:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x0291490C (43075852), len: 124  VirtAddr: 0x0291490C RVA: 0x0291490C token: 100686628 methodIndex: 49143 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool IsInteger(object value)
        {
            //
            // Disasemble & Code
            // 0x0291490C: STP x20, x19, [sp, #-0x20]! | stack[1152921513974270464] = ???;  stack[1152921513974270472] = ???;  //  dest_result_addr=1152921513974270464 |  dest_result_addr=1152921513974270472
            // 0x02914910: STP x29, x30, [sp, #0x10]  | stack[1152921513974270480] = ???;  stack[1152921513974270488] = ???;  //  dest_result_addr=1152921513974270480 |  dest_result_addr=1152921513974270488
            // 0x02914914: ADD x29, sp, #0x10         | X29 = (1152921513974270464 + 16) = 1152921513974270480 (0x100000022E578A10);
            // 0x02914918: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x0291491C: LDRB w8, [x20, #0xb04]     | W8 = (bool)static_value_037B8B04;       
            // 0x02914920: MOV x19, x1                | X19 = X1;//m1                           
            // 0x02914924: TBNZ w8, #0, #0x2914940    | if (static_value_037B8B04 == true) goto label_0;
            // 0x02914928: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x0291492C: LDR x8, [x8, #0x948]       | X8 = 0x2B92C74;                         
            // 0x02914930: LDR w0, [x8]               | W0 = 0x21E2;                            
            // 0x02914934: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E2, ????);     
            // 0x02914938: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0291493C: STRB w8, [x20, #0xb04]     | static_value_037B8B04 = true;            //  dest_result_addr=58428164
            label_0:
            // 0x02914940: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x02914944: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x02914948: LDR x0, [x8]               | X0 = typeof(System.Convert);            
            // 0x0291494C: LDRB w8, [x0, #0x10a]      | W8 = System.Convert.__il2cppRuntimeField_10A;
            // 0x02914950: TBZ w8, #0, #0x2914960     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x02914954: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x02914958: CBNZ w8, #0x2914960        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0291495C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_2:
            // 0x02914960: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x02914964: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x02914968: MOV x1, x19                | X1 = X1;//m1                            
            // 0x0291496C: BL #0x1ba1fc4              | X0 = System.Convert.GetTypeCode(value:  0);
            System.TypeCode val_1 = System.Convert.GetTypeCode(value:  0);
            // 0x02914970: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x02914974: SUB w8, w0, #5             | W8 = (val_1 - 5);                       
            System.TypeCode val_2 = val_1 - 5;
            // 0x02914978: CMP w8, #8                 | STATE = COMPARE((val_1 - 5), 0x8)       
            // 0x0291497C: CSET w0, lo                | W0 = val_2 < 0x8 ? 1 : 0;               
            var val_3 = (val_2 < 8) ? 1 : 0;
            // 0x02914980: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x02914984: RET                        |  return (System.Boolean)val_2 < 0x8 ? 1 : 0;
            return (bool)val_3;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x02914E00 (43077120), len: 224  VirtAddr: 0x02914E00 RVA: 0x02914E00 token: 100686629 methodIndex: 49144 delegateWrapperIndex: 0 methodInvoker: 0
        private static ConvertUtils()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x02914E00: STP x22, x21, [sp, #-0x30]! | stack[1152921513974393712] = ???;  stack[1152921513974393720] = ???;  //  dest_result_addr=1152921513974393712 |  dest_result_addr=1152921513974393720
            // 0x02914E04: STP x20, x19, [sp, #0x10]  | stack[1152921513974393728] = ???;  stack[1152921513974393736] = ???;  //  dest_result_addr=1152921513974393728 |  dest_result_addr=1152921513974393736
            // 0x02914E08: STP x29, x30, [sp, #0x20]  | stack[1152921513974393744] = ???;  stack[1152921513974393752] = ???;  //  dest_result_addr=1152921513974393744 |  dest_result_addr=1152921513974393752
            // 0x02914E0C: ADD x29, sp, #0x20         | X29 = (1152921513974393712 + 32) = 1152921513974393744 (0x100000022E596B90);
            // 0x02914E10: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x02914E14: LDRB w8, [x19, #0xb05]     | W8 = (bool)static_value_037B8B05;       
            // 0x02914E18: TBNZ w8, #0, #0x2914e34    | if (static_value_037B8B05 == true) goto label_0;
            // 0x02914E1C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x02914E20: LDR x8, [x8, #0x860]       | X8 = 0x2B92C44;                         
            // 0x02914E24: LDR w0, [x8]               | W0 = 0x21D6;                            
            // 0x02914E28: BL #0x2782188              | X0 = sub_2782188( ?? 0x21D6, ????);     
            // 0x02914E2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x02914E30: STRB w8, [x19, #0xb05]     | static_value_037B8B05 = true;            //  dest_result_addr=58428165
            label_0:
            // 0x02914E34: ADRP x21, #0x362b000       | X21 = 56799232 (0x362B000);             
            // 0x02914E38: LDR x21, [x21, #0xc10]     | X21 = 1152921504867069952;              
            // 0x02914E3C: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02914E40: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_static_fields;
            // 0x02914E44: LDR x9, [x8, #8]           | X9 = Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0;
            // 0x02914E48: CBNZ x9, #0x2914e98        | if (Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0 != null) goto label_1;
            if((Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0) != null)
            {
                goto label_1;
            }
            // 0x02914E4C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x02914E50: ADRP x9, #0x364c000        | X9 = 56934400 (0x364C000);              
            // 0x02914E54: LDR x8, [x8, #0xa0]        | X8 = 1152921513974378688;               
            // 0x02914E58: LDR x9, [x9, #0x440]       | X9 = 1152921504688103424;               
            // 0x02914E5C: LDR x19, [x8]              | X19 = static System.Func<System.Object, System.Object> Newtonsoft.Json.Utilities.ConvertUtils::CreateCastConverter(Newtonsoft.Json.Utilities.ConvertUtils.TypeConvertKey t);
            // 0x02914E60: LDR x0, [x9]               | X0 = typeof(System.Func<T, TResult>);   
            System.Func<TypeConvertKey, System.Func<System.Object, System.Object>> val_1 = null;
            // 0x02914E64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<T, TResult>), ????);
            // 0x02914E68: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x02914E6C: LDR x8, [x8, #0xad0]       | X8 = 1152921513974379712;               
            // 0x02914E70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02914E74: MOV x2, x19                | X2 = 1152921513974378688 (0x100000022E5930C0);//ML01
            // 0x02914E78: MOV x20, x0                | X20 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x02914E7C: LDR x3, [x8]               | X3 = public System.Void System.Func<TypeConvertKey, System.Func<System.Object, System.Object>>::.ctor(object object, IntPtr method);
            // 0x02914E80: BL #0x225a918              | .ctor(object:  0, method:  static System.Func<System.Object, System.Object> Newtonsoft.Json.Utilities.ConvertUtils::CreateCastConverter(Newtonsoft.Json.Utilities.ConvertUtils.TypeConvertKey t));
            val_1 = new System.Func<TypeConvertKey, System.Func<System.Object, System.Object>>(object:  0, method:  static System.Func<System.Object, System.Object> Newtonsoft.Json.Utilities.ConvertUtils::CreateCastConverter(Newtonsoft.Json.Utilities.ConvertUtils.TypeConvertKey t));
            // 0x02914E84: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02914E88: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_static_fields;
            // 0x02914E8C: STR x20, [x8, #8]          | Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0 = typeof(System.Func<T, TResult>);  //  dest_result_addr=1152921504867074056
            Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0 = val_1;
            // 0x02914E90: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02914E94: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_static_fields;
            label_1:
            // 0x02914E98: LDR x19, [x8, #8]          | X19 = typeof(System.Func<T, TResult>);  
            // 0x02914E9C: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x02914EA0: LDR x8, [x8, #0xde8]       | X8 = 1152921504869679104;               
            // 0x02914EA4: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.Utilities.ThreadSafeStore<TKey, TValue>);
            Newtonsoft.Json.Utilities.ThreadSafeStore<TypeConvertKey, System.Func<System.Object, System.Object>> val_2 = null;
            // 0x02914EA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Newtonsoft.Json.Utilities.ThreadSafeStore<TKey, TValue>), ????);
            // 0x02914EAC: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x02914EB0: LDR x8, [x8, #0xf78]       | X8 = 1152921513974380736;               
            // 0x02914EB4: MOV x1, x19                | X1 = 1152921504688103424 (0x1000000004D7E000);//ML01
            // 0x02914EB8: MOV x20, x0                | X20 = 1152921504869679104 (0x100000000FAA8000);//ML01
            // 0x02914EBC: LDR x2, [x8]               | X2 = public System.Void Newtonsoft.Json.Utilities.ThreadSafeStore<TypeConvertKey, System.Func<System.Object, System.Object>>::.ctor(System.Func<TKey, TValue> creator);
            // 0x02914EC0: BL #0x19f04d4              | .ctor(creator:  Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0);
            val_2 = new Newtonsoft.Json.Utilities.ThreadSafeStore<TypeConvertKey, System.Func<System.Object, System.Object>>(creator:  Newtonsoft.Json.Utilities.ConvertUtils.<>f__mg$cache0);
            // 0x02914EC4: LDR x8, [x21]              | X8 = typeof(Newtonsoft.Json.Utilities.ConvertUtils);
            // 0x02914EC8: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Utilities.ConvertUtils.__il2cppRuntimeField_static_fields;
            // 0x02914ECC: STR x20, [x8]              | Newtonsoft.Json.Utilities.ConvertUtils.CastConverters = typeof(Newtonsoft.Json.Utilities.ThreadSafeStore<TKey, TValue>);  //  dest_result_addr=1152921504867074048
            Newtonsoft.Json.Utilities.ConvertUtils.CastConverters = val_2;
            // 0x02914ED0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x02914ED4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x02914ED8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x02914EDC: RET                        |  return;                                
            return;
        
        }
    
    }

}
