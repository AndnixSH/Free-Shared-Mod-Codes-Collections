using UnityEngine;

namespace ProtoBuf.Serializers
{
    internal sealed class BooleanSerializer : IProtoSerializer
    {
        // Fields
        private static readonly System.Type expectedType; // static_offset: 0x00000000
        
        // Properties
        private bool ProtoBuf.Serializers.IProtoSerializer.RequiresOldValue { get; }
        private bool ProtoBuf.Serializers.IProtoSerializer.ReturnsValue { get; }
        public System.Type ExpectedType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x02983800 (43530240), len: 8  VirtAddr: 0x02983800 RVA: 0x02983800 token: 100689807 methodIndex: 54006 delegateWrapperIndex: 0 methodInvoker: 0
        public BooleanSerializer(ProtoBuf.Meta.TypeModel model)
        {
            //
            // Disasemble & Code
            // 0x02983800: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x02983804: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B61C (43562524), len: 104  VirtAddr: 0x0298B61C RVA: 0x0298B61C token: 100689808 methodIndex: 54007 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_ExpectedType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298B61C: STP x20, x19, [sp, #-0x20]! | stack[1152921514434471424] = ???;  stack[1152921514434471432] = ???;  //  dest_result_addr=1152921514434471424 |  dest_result_addr=1152921514434471432
            // 0x0298B620: STP x29, x30, [sp, #0x10]  | stack[1152921514434471440] = ???;  stack[1152921514434471448] = ???;  //  dest_result_addr=1152921514434471440 |  dest_result_addr=1152921514434471448
            // 0x0298B624: ADD x29, sp, #0x10         | X29 = (1152921514434471424 + 16) = 1152921514434471440 (0x1000000249C5A610);
            // 0x0298B628: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298B62C: LDRB w8, [x19, #0xf17]     | W8 = (bool)static_value_037B8F17;       
            // 0x0298B630: TBNZ w8, #0, #0x298b64c    | if (static_value_037B8F17 == true) goto label_0;
            // 0x0298B634: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x0298B638: LDR x8, [x8, #0x4c0]       | X8 = 0x2B8F87C;                         
            // 0x0298B63C: LDR w0, [x8]               | W0 = 0x14E3;                            
            // 0x0298B640: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E3, ????);     
            // 0x0298B644: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B648: STRB w8, [x19, #0xf17]     | static_value_037B8F17 = true;            //  dest_result_addr=58429207
            label_0:
            // 0x0298B64C: ADRP x19, #0x35c4000       | X19 = 56377344 (0x35C4000);             
            // 0x0298B650: LDR x19, [x19, #0xa28]     | X19 = 1152921504884854784;              
            // 0x0298B654: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.BooleanSerializer);
            val_1 = null;
            // 0x0298B658: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.Serializers.BooleanSerializer.__il2cppRuntimeField_10A;
            // 0x0298B65C: TBZ w8, #0, #0x298b670     | if (ProtoBuf.Serializers.BooleanSerializer.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B660: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.Serializers.BooleanSerializer.__il2cppRuntimeField_cctor_finished;
            // 0x0298B664: CBNZ w8, #0x298b670        | if (ProtoBuf.Serializers.BooleanSerializer.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B668: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.Serializers.BooleanSerializer), ????);
            // 0x0298B66C: LDR x0, [x19]              | X0 = typeof(ProtoBuf.Serializers.BooleanSerializer);
            val_1 = null;
            label_2:
            // 0x0298B670: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.Serializers.BooleanSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298B674: LDR x0, [x8]               | X0 = ProtoBuf.Serializers.BooleanSerializer.expectedType;
            // 0x0298B678: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B67C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298B680: RET                        |  return (System.Type)ProtoBuf.Serializers.BooleanSerializer.expectedType;
            return ProtoBuf.Serializers.BooleanSerializer.expectedType;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B684 (43562628), len: 228  VirtAddr: 0x0298B684 RVA: 0x0298B684 token: 100689809 methodIndex: 54008 delegateWrapperIndex: 0 methodInvoker: 0
        public void Write(object value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0298B684: STP x22, x21, [sp, #-0x30]! | stack[1152921514434591600] = ???;  stack[1152921514434591608] = ???;  //  dest_result_addr=1152921514434591600 |  dest_result_addr=1152921514434591608
            // 0x0298B688: STP x20, x19, [sp, #0x10]  | stack[1152921514434591616] = ???;  stack[1152921514434591624] = ???;  //  dest_result_addr=1152921514434591616 |  dest_result_addr=1152921514434591624
            // 0x0298B68C: STP x29, x30, [sp, #0x20]  | stack[1152921514434591632] = ???;  stack[1152921514434591640] = ???;  //  dest_result_addr=1152921514434591632 |  dest_result_addr=1152921514434591640
            // 0x0298B690: ADD x29, sp, #0x20         | X29 = (1152921514434591600 + 32) = 1152921514434591632 (0x1000000249C77B90);
            // 0x0298B694: SUB sp, sp, #0x10          | SP = (1152921514434591600 - 16) = 1152921514434591584 (0x1000000249C77B60);
            // 0x0298B698: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x0298B69C: LDRB w8, [x21, #0xf18]     | W8 = (bool)static_value_037B8F18;       
            // 0x0298B6A0: MOV x19, x2                | X19 = dest;//m1                         
            // 0x0298B6A4: MOV x20, x1                | X20 = value;//m1                        
            // 0x0298B6A8: TBNZ w8, #0, #0x298b6c4    | if (static_value_037B8F18 == true) goto label_0;
            // 0x0298B6AC: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x0298B6B0: LDR x8, [x8, #0xa70]       | X8 = 0x2B8F884;                         
            // 0x0298B6B4: LDR w0, [x8]               | W0 = 0x14E5;                            
            // 0x0298B6B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E5, ????);     
            // 0x0298B6BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B6C0: STRB w8, [x21, #0xf18]     | static_value_037B8F18 = true;            //  dest_result_addr=58429208
            label_0:
            // 0x0298B6C4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x0298B6C8: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x0298B6CC: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x0298B6D0: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x0298B6D4: TBZ w8, #0, #0x298b6e4     | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B6D8: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x0298B6DC: CBNZ w8, #0x298b6e4        | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B6E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_2:
            // 0x0298B6E4: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0298B6E8: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x0298B6EC: LDR x21, [x8]              | X21 = typeof(System.Boolean);           
            // 0x0298B6F0: CBNZ x20, #0x298b6f8       | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x0298B6F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_3:
            // 0x0298B6F8: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x0298B6FC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0298B700: LDR x8, [x21, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x0298B704: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Boolean.__il2cppRuntimeField_element_class)
            // 0x0298B708: B.NE #0x298b730            | if (System.Object.__il2cppRuntimeField_element_class != System.Boolean.__il2cppRuntimeField_element_class) goto label_4;
            // 0x0298B70C: MOV x0, x20                | X0 = value;//m1                         
            // 0x0298B710: BL #0x27bc4e8              | value.System.IDisposable.Dispose();     
            value.System.IDisposable.Dispose();
            // 0x0298B714: LDRB w1, [x0]              | W1 = typeof(System.Object);             
            // 0x0298B718: MOV x2, x19                | X2 = dest;//m1                          
            // 0x0298B71C: SUB sp, x29, #0x20         | SP = (1152921514434591632 - 32) = 1152921514434591600 (0x1000000249C77B70);
            // 0x0298B720: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B724: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0298B728: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0298B72C: B #0x2978f94               | ProtoBuf.ProtoWriter.WriteBoolean(value:  value, writer:  null); return;
            ProtoBuf.ProtoWriter.WriteBoolean(value:  value, writer:  null);
            return;
            label_4:
            // 0x0298B730: ADD x8, sp, #8             | X8 = (1152921514434591584 + 8) = 1152921514434591592 (0x1000000249C77B68);
            // 0x0298B734: MOV x1, x21                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0298B738: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0298B73C: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921514434579648]
            // 0x0298B740: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0298B744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0298B748: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0298B74C: ADD x0, sp, #8             | X0 = (1152921514434591584 + 8) = 1152921514434591592 (0x1000000249C77B68);
            // 0x0298B750: BL #0x299a140              | 
            // 0x0298B754: MOV x19, x0                | X19 = 1152921514434591592 (0x1000000249C77B68);//ML01
            // 0x0298B758: ADD x0, sp, #8             | X0 = (1152921514434591584 + 8) = 1152921514434591592 (0x1000000249C77B68);
            // 0x0298B75C: BL #0x299a140              | 
            // 0x0298B760: MOV x0, x19                | X0 = 1152921514434591592 (0x1000000249C77B68);//ML01
            // 0x0298B764: BL #0x980800               | X0 = sub_980800( ?? 0x1000000249C77B68, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B768 (43562856), len: 120  VirtAddr: 0x0298B768 RVA: 0x0298B768 token: 100689810 methodIndex: 54009 delegateWrapperIndex: 0 methodInvoker: 0
        public object Read(object value, ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            // 0x0298B768: STP x20, x19, [sp, #-0x20]! | stack[1152921514434724096] = ???;  stack[1152921514434724104] = ???;  //  dest_result_addr=1152921514434724096 |  dest_result_addr=1152921514434724104
            // 0x0298B76C: STP x29, x30, [sp, #0x10]  | stack[1152921514434724112] = ???;  stack[1152921514434724120] = ???;  //  dest_result_addr=1152921514434724112 |  dest_result_addr=1152921514434724120
            // 0x0298B770: ADD x29, sp, #0x10         | X29 = (1152921514434724096 + 16) = 1152921514434724112 (0x1000000249C98110);
            // 0x0298B774: SUB sp, sp, #0x10          | SP = (1152921514434724096 - 16) = 1152921514434724080 (0x1000000249C980F0);
            // 0x0298B778: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x0298B77C: LDRB w8, [x20, #0xf19]     | W8 = (bool)static_value_037B8F19;       
            // 0x0298B780: MOV x19, x2                | X19 = source;//m1                       
            // 0x0298B784: TBNZ w8, #0, #0x298b7a0    | if (static_value_037B8F19 == true) goto label_0;
            // 0x0298B788: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0298B78C: LDR x8, [x8, #0x910]       | X8 = 0x2B8F880;                         
            // 0x0298B790: LDR w0, [x8]               | W0 = 0x14E4;                            
            // 0x0298B794: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E4, ????);     
            // 0x0298B798: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B79C: STRB w8, [x20, #0xf19]     | static_value_037B8F19 = true;            //  dest_result_addr=58429209
            label_0:
            // 0x0298B7A0: CBNZ x19, #0x298b7a8       | if (source != null) goto label_1;       
            if(source != null)
            {
                goto label_1;
            }
            // 0x0298B7A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14E4, ????);     
            label_1:
            // 0x0298B7A8: MOV x0, x19                | X0 = source;//m1                        
            // 0x0298B7AC: BL #0x297efc8              | X0 = source.ReadBoolean();              
            bool val_1 = source.ReadBoolean();
            // 0x0298B7B0: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0298B7B4: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x0298B7B8: AND w9, w0, #1             | W9 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x0298B7BC: ADD x1, sp, #0xf           | X1 = (1152921514434724080 + 15) = 1152921514434724095 (0x1000000249C980FF);
            // 0x0298B7C0: STRB w9, [sp, #0xf]        | stack[1152921514434724095] = (val_1 & 1);  //  dest_result_addr=1152921514434724095
            // 0x0298B7C4: LDR x8, [x8]               | X8 = typeof(System.Boolean);            
            // 0x0298B7C8: MOV x0, x8                 | X0 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0298B7CC: BL #0x27bc028              | X0 = 1152921514434776320 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (val_1 & 1));
            // 0x0298B7D0: SUB sp, x29, #0x10         | SP = (1152921514434724112 - 16) = 1152921514434724096 (0x1000000249C98100);
            // 0x0298B7D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B7D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298B7DC: RET                        |  return (System.Object)(val_1 & 1);     
            return (object)val_2;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B7E0 (43562976), len: 8  VirtAddr: 0x0298B7E0 RVA: 0x0298B7E0 token: 100689811 methodIndex: 54010 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ProtoBuf.Serializers.IProtoSerializer.get_RequiresOldValue()
        {
            //
            // Disasemble & Code
            // 0x0298B7E0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x0298B7E4: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B7E8 (43562984), len: 8  VirtAddr: 0x0298B7E8 RVA: 0x0298B7E8 token: 100689812 methodIndex: 54011 delegateWrapperIndex: 0 methodInvoker: 0
        private bool ProtoBuf.Serializers.IProtoSerializer.get_ReturnsValue()
        {
            //
            // Disasemble & Code
            // 0x0298B7E8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x0298B7EC: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0298B7F0 (43562992), len: 140  VirtAddr: 0x0298B7F0 RVA: 0x0298B7F0 token: 100689813 methodIndex: 54012 delegateWrapperIndex: 0 methodInvoker: 0
        private static BooleanSerializer()
        {
            //
            // Disasemble & Code
            // 0x0298B7F0: STP x20, x19, [sp, #-0x20]! | stack[1152921514435076480] = ???;  stack[1152921514435076488] = ???;  //  dest_result_addr=1152921514435076480 |  dest_result_addr=1152921514435076488
            // 0x0298B7F4: STP x29, x30, [sp, #0x10]  | stack[1152921514435076496] = ???;  stack[1152921514435076504] = ???;  //  dest_result_addr=1152921514435076496 |  dest_result_addr=1152921514435076504
            // 0x0298B7F8: ADD x29, sp, #0x10         | X29 = (1152921514435076480 + 16) = 1152921514435076496 (0x1000000249CEE190);
            // 0x0298B7FC: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x0298B800: LDRB w8, [x19, #0xf1a]     | W8 = (bool)static_value_037B8F1A;       
            // 0x0298B804: TBNZ w8, #0, #0x298b820    | if (static_value_037B8F1A == true) goto label_0;
            // 0x0298B808: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x0298B80C: LDR x8, [x8, #0xe48]       | X8 = 0x2B8F878;                         
            // 0x0298B810: LDR w0, [x8]               | W0 = 0x14E2;                            
            // 0x0298B814: BL #0x2782188              | X0 = sub_2782188( ?? 0x14E2, ????);     
            // 0x0298B818: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0298B81C: STRB w8, [x19, #0xf1a]     | static_value_037B8F1A = true;            //  dest_result_addr=58429210
            label_0:
            // 0x0298B820: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0298B824: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0298B828: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0298B82C: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x0298B830: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x0298B834: LDR x19, [x8]              | X19 = typeof(System.Boolean);           
            // 0x0298B838: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0298B83C: TBZ w8, #0, #0x298b84c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0298B840: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0298B844: CBNZ w8, #0x298b84c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0298B848: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0298B84C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0298B850: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0298B854: MOV x1, x19                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0298B858: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0298B85C: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x0298B860: LDR x8, [x8, #0xa28]       | X8 = 1152921504884854784;               
            // 0x0298B864: LDR x8, [x8]               | X8 = typeof(ProtoBuf.Serializers.BooleanSerializer);
            // 0x0298B868: LDR x8, [x8, #0xa0]        | X8 = ProtoBuf.Serializers.BooleanSerializer.__il2cppRuntimeField_static_fields;
            // 0x0298B86C: STR x0, [x8]               | ProtoBuf.Serializers.BooleanSerializer.expectedType = val_1;  //  dest_result_addr=1152921504884858880
            ProtoBuf.Serializers.BooleanSerializer.expectedType = val_1;
            // 0x0298B870: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0298B874: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0298B878: RET                        |  return;                                
            return;
        
        }
    
    }

}
