using UnityEngine;

namespace Entity.Behavior
{
    public class AIMoveBvr : IBehavior
    {
        // Fields
        private float curTime; //  0x0000001C
        private bool isFollowCap; //  0x00000020
        private UnityEngine.Vector3 lastForward; //  0x00000024
        private UnityEngine.Vector3 lastpos; //  0x00000030
        private UnityEngine.Vector3 marshalPos; //  0x0000003C
        
        // Properties
        public override Entity.Behavior.EBehaviorID id { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00B68470 (11961456), len: 8  VirtAddr: 0x00B68470 RVA: 0x00B68470 token: 100691418 methodIndex: 27215 delegateWrapperIndex: 0 methodInvoker: 0
        public AIMoveBvr()
        {
            //
            // Disasemble & Code
            // 0x00B68470: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68474: B #0xeb3a54                | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68478 (11961464), len: 8  VirtAddr: 0x00B68478 RVA: 0x00B68478 token: 100691419 methodIndex: 27216 delegateWrapperIndex: 0 methodInvoker: 0
        public override Entity.Behavior.EBehaviorID get_id()
        {
            //
            // Disasemble & Code
            // 0x00B68478: MOVZ w0, #0x9              | W0 = 9 (0x9);//ML01                     
            // 0x00B6847C: RET                        |  return (Entity.Behavior.EBehaviorID)0x9;
            return 9;
            //  |  // // {name=val_0, type=Entity.Behavior.EBehaviorID, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68480 (11961472), len: 456  VirtAddr: 0x00B68480 RVA: 0x00B68480 token: 100691420 methodIndex: 27217 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Reason()
        {
            //
            // Disasemble & Code
            // 0x00B68480: STP d13, d12, [sp, #-0x60]! | stack[1152921514657913760] = ???;  stack[1152921514657913768] = ???;  //  dest_result_addr=1152921514657913760 |  dest_result_addr=1152921514657913768
            // 0x00B68484: STP d11, d10, [sp, #0x10]  | stack[1152921514657913776] = ???;  stack[1152921514657913784] = ???;  //  dest_result_addr=1152921514657913776 |  dest_result_addr=1152921514657913784
            // 0x00B68488: STP d9, d8, [sp, #0x20]    | stack[1152921514657913792] = ???;  stack[1152921514657913800] = ???;  //  dest_result_addr=1152921514657913792 |  dest_result_addr=1152921514657913800
            // 0x00B6848C: STP x22, x21, [sp, #0x30]  | stack[1152921514657913808] = ???;  stack[1152921514657913816] = ???;  //  dest_result_addr=1152921514657913808 |  dest_result_addr=1152921514657913816
            // 0x00B68490: STP x20, x19, [sp, #0x40]  | stack[1152921514657913824] = ???;  stack[1152921514657913832] = ???;  //  dest_result_addr=1152921514657913824 |  dest_result_addr=1152921514657913832
            // 0x00B68494: STP x29, x30, [sp, #0x50]  | stack[1152921514657913840] = ???;  stack[1152921514657913848] = ???;  //  dest_result_addr=1152921514657913840 |  dest_result_addr=1152921514657913848
            // 0x00B68498: ADD x29, sp, #0x50         | X29 = (1152921514657913760 + 80) = 1152921514657913840 (0x1000000257171BF0);
            // 0x00B6849C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B684A0: LDRB w8, [x20, #0x966]     | W8 = (bool)static_value_03733966;       
            // 0x00B684A4: MOV x19, x0                | X19 = 1152921514657925856 (0x1000000257174AE0);//ML01
            // 0x00B684A8: TBNZ w8, #0, #0xb684c4     | if (static_value_03733966 == true) goto label_0;
            // 0x00B684AC: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00B684B0: LDR x8, [x8, #0xc98]       | X8 = 0x2B8AB10;                         
            // 0x00B684B4: LDR w0, [x8]               | W0 = 0x182;                             
            // 0x00B684B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x182, ????);      
            // 0x00B684BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B684C0: STRB w8, [x20, #0x966]     | static_value_03733966 = true;            //  dest_result_addr=57882982
            label_0:
            // 0x00B684C4: LDRB w8, [x19, #0x18]      | 
            // 0x00B684C8: CBNZ w8, #0xb685ac         | if (0x1 != 0) goto label_5;             
            if(true != 0)
            {
                goto label_5;
            }
            // 0x00B684CC: ADRP x21, #0x35f7000       | X21 = 56586240 (0x35F7000);             
            // 0x00B684D0: LDR x21, [x21, #0xb20]     | X21 = 1152921504901574656;              
            // 0x00B684D4: LDR x8, [x21]              | X8 = typeof(GameMgr);                   
            // 0x00B684D8: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
            // 0x00B684DC: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
            // 0x00B684E0: CBNZ x20, #0xb684e8        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
            if(GameMgr.UPDATEOnOffEffect != null)
            {
                goto label_2;
            }
            // 0x00B684E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x182, ????);      
            label_2:
            // 0x00B684E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B684EC: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
            // 0x00B684F0: BL #0xc148b8               | X0 = GameMgr.UPDATEOnOffEffect.get_isBattleStart();
            bool val_1 = GameMgr.UPDATEOnOffEffect.isBattleStart;
            // 0x00B684F4: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00B684F8: TBNZ w8, #0, #0xb685ac     | if ((val_1 & 1) == true) goto label_5;  
            if(val_2 == true)
            {
                goto label_5;
            }
            // 0x00B684FC: LDR x8, [x21]              | X8 = typeof(GameMgr);                   
            // 0x00B68500: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
            // 0x00B68504: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
            // 0x00B68508: CBNZ x20, #0xb68510        | if (GameMgr.UPDATEOnOffEffect != null) goto label_4;
            if(GameMgr.UPDATEOnOffEffect != null)
            {
                goto label_4;
            }
            // 0x00B6850C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00B68510: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68514: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
            // 0x00B68518: BL #0xc14854               | X0 = GameMgr.UPDATEOnOffEffect.get_isAuto();
            bool val_3 = GameMgr.UPDATEOnOffEffect.isAuto;
            // 0x00B6851C: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x00B68520: TBNZ w8, #0, #0xb685ac     | if ((val_3 & 1) == true) goto label_5;  
            if(val_4 == true)
            {
                goto label_5;
            }
            // 0x00B68524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68528: MOV x0, x19                | X0 = 1152921514657925856 (0x1000000257174AE0);//ML01
            // 0x00B6852C: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_5 = this.entity;
            // 0x00B68530: MOV x20, x0                | X20 = val_5;//m1                        
            // 0x00B68534: CBNZ x20, #0xb6853c        | if (val_5 != null) goto label_6;        
            if(val_5 != null)
            {
                goto label_6;
            }
            // 0x00B68538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_6:
            // 0x00B6853C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68540: MOV x0, x20                | X0 = val_5;//m1                         
            // 0x00B68544: BL #0xd89310               | X0 = val_5.get_position();              
            UnityEngine.Vector3 val_6 = val_5.position;
            // 0x00B68548: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x00B6854C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x00B68550: MOV v8.16b, v0.16b         | V8 = val_6.x;//m1                       
            // 0x00B68554: MOV v9.16b, v1.16b         | V9 = val_6.y;//m1                       
            // 0x00B68558: MOV v13.16b, v2.16b        | V13 = val_6.z;//m1                      
            // 0x00B6855C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x00B68560: LDP s12, s11, [x19, #0x3c] | S12 = this.marshalPos; //P2              //  | 
            // 0x00B68564: LDR s10, [x19, #0x44]      | 
            // 0x00B68568: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x00B6856C: TBZ w8, #0, #0xb6857c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00B68570: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x00B68574: CBNZ w8, #0xb6857c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00B68578: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_8:
            // 0x00B6857C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68584: MOV v0.16b, v8.16b         | V0 = val_6.x;//m1                       
            // 0x00B68588: MOV v1.16b, v9.16b         | V1 = val_6.y;//m1                       
            // 0x00B6858C: MOV v2.16b, v13.16b        | V2 = val_6.z;//m1                       
            // 0x00B68590: MOV v3.16b, v12.16b        | V3 = this.marshalPos;//m1               
            // 0x00B68594: MOV v4.16b, v11.16b        | V4 = V11.16B;//m1                       
            // 0x00B68598: MOV v5.16b, v10.16b        | V5 = V10.16B;//m1                       
            // 0x00B6859C: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = this.marshalPos, y = V11.16B, z = V10.16B});
            float val_7 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, b:  new UnityEngine.Vector3() {x = this.marshalPos, y = V11.16B, z = V10.16B});
            // 0x00B685A0: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x00B685A4: FCMP s0, s1                | STATE = COMPARE(val_7, 0.5)             
            // 0x00B685A8: B.LS #0xb685c8             | if (val_7 <= 0.5f) goto label_9;        
            if(val_7 <= 0.5f)
            {
                goto label_9;
            }
            label_5:
            // 0x00B685AC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00B685B0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00B685B4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00B685B8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00B685BC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00B685C0: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
            // 0x00B685C4: RET                        |  return;                                
            return;
            label_9:
            // 0x00B685C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B685CC: MOV x0, x19                | X0 = 1152921514657925856 (0x1000000257174AE0);//ML01
            // 0x00B685D0: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_8 = this.entity;
            // 0x00B685D4: MOV x19, x0                | X19 = val_8;//m1                        
            // 0x00B685D8: CBNZ x19, #0xb685e0        | if (val_8 != null) goto label_10;       
            if(val_8 != null)
            {
                goto label_10;
            }
            // 0x00B685DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_10:
            // 0x00B685E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B685E4: MOV x0, x19                | X0 = val_8;//m1                         
            // 0x00B685E8: BL #0xd7dd80               | X0 = val_8.get_bvrCtrl();               
            Entity.Behavior.IBehaviorCtrl val_9 = val_8.bvrCtrl;
            // 0x00B685EC: MOV x19, x0                | X19 = val_9;//m1                        
            // 0x00B685F0: CBNZ x19, #0xb685f8        | if (val_9 != null) goto label_11;       
            if(val_9 != null)
            {
                goto label_11;
            }
            // 0x00B685F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_11:
            // 0x00B685F8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00B685FC: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00B68600: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x00B68604: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68608: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00B6860C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68610: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68614: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00B68618: LDR x8, [x19]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
            // 0x00B6861C: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68620: MOV x0, x19                | X0 = val_9;//m1                         
            // 0x00B68624: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00B68628: LDP x4, x3, [x8, #0x180]   | X4 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
            // 0x00B6862C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68630: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00B68634: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00B68638: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x00B6863C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x00B68640: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
            // 0x00B68644: BR x4                      | goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
            goto typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68648 (11961928), len: 4  VirtAddr: 0x00B68648 RVA: 0x00B68648 token: 100691421 methodIndex: 27218 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Action()
        {
            //
            // Disasemble & Code
            // 0x00B68648: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B6864C (11961932), len: 660  VirtAddr: 0x00B6864C RVA: 0x00B6864C token: 100691422 methodIndex: 27219 delegateWrapperIndex: 0 methodInvoker: 0
        public override void SetParams(object[] args)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            bool val_6;
            //  | 
            object val_7;
            // 0x00B6864C: STP x24, x23, [sp, #-0x40]! | stack[1152921514658215712] = ???;  stack[1152921514658215720] = ???;  //  dest_result_addr=1152921514658215712 |  dest_result_addr=1152921514658215720
            // 0x00B68650: STP x22, x21, [sp, #0x10]  | stack[1152921514658215728] = ???;  stack[1152921514658215736] = ???;  //  dest_result_addr=1152921514658215728 |  dest_result_addr=1152921514658215736
            // 0x00B68654: STP x20, x19, [sp, #0x20]  | stack[1152921514658215744] = ???;  stack[1152921514658215752] = ???;  //  dest_result_addr=1152921514658215744 |  dest_result_addr=1152921514658215752
            // 0x00B68658: STP x29, x30, [sp, #0x30]  | stack[1152921514658215760] = ???;  stack[1152921514658215768] = ???;  //  dest_result_addr=1152921514658215760 |  dest_result_addr=1152921514658215768
            // 0x00B6865C: ADD x29, sp, #0x30         | X29 = (1152921514658215712 + 48) = 1152921514658215760 (0x10000002571BB750);
            // 0x00B68660: SUB sp, sp, #0x10          | SP = (1152921514658215712 - 16) = 1152921514658215696 (0x10000002571BB710);
            // 0x00B68664: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00B68668: LDRB w8, [x21, #0x967]     | W8 = (bool)static_value_03733967;       
            // 0x00B6866C: MOV x19, x1                | X19 = args;//m1                         
            val_6 = args;
            // 0x00B68670: MOV x20, x0                | X20 = 1152921514658227776 (0x10000002571BE640);//ML01
            // 0x00B68674: TBNZ w8, #0, #0xb68690     | if (static_value_03733967 == true) goto label_0;
            // 0x00B68678: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00B6867C: LDR x8, [x8, #0xb50]       | X8 = 0x2B8AB14;                         
            // 0x00B68680: LDR w0, [x8]               | W0 = 0x183;                             
            // 0x00B68684: BL #0x2782188              | X0 = sub_2782188( ?? 0x183, ????);      
            // 0x00B68688: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B6868C: STRB w8, [x21, #0x967]     | static_value_03733967 = true;            //  dest_result_addr=57882983
            label_0:
            // 0x00B68690: CBZ x19, #0xb68890         | if (args == null) goto label_2;         
            if(val_6 == null)
            {
                goto label_2;
            }
            // 0x00B68694: LDR w8, [x19, #0x18]       | W8 = args.Length; //P2                  
            // 0x00B68698: CMP w8, #1                 | STATE = COMPARE(args.Length, 0x1)       
            // 0x00B6869C: B.LT #0xb68890             | if (args.Length < 1) goto label_2;      
            if(args.Length < 1)
            {
                goto label_2;
            }
            // 0x00B686A0: ADRP x23, #0x3673000       | X23 = 57094144 (0x3673000);             
            // 0x00B686A4: LDR x21, [x19, #0x20]      | X21 = args[0]                           
            object val_5 = val_6[0];
            // 0x00B686A8: LDR x23, [x23, #0x488]     | X23 = 1152921504695078912;              
            // 0x00B686AC: LDR x19, [x23]             | X19 = typeof(UnityEngine.Vector3);      
            // 0x00B686B0: CBNZ x21, #0xb686b8        | if (args[0] != null) goto label_3;      
            if(val_5 != null)
            {
                goto label_3;
            }
            // 0x00B686B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x183, ????);      
            label_3:
            // 0x00B686B8: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x00B686BC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00B686C0: LDR x8, [x19, #0x30]       | X8 = UnityEngine.Vector3.__il2cppRuntimeField_element_class;
            // 0x00B686C4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, UnityEngine.Vector3.__il2cppRuntimeField_element_class)
            // 0x00B686C8: B.NE #0xb688a8             | if (System.Object.__il2cppRuntimeField_element_class != UnityEngine.Vector3.__il2cppRuntimeField_element_class) goto label_4;
            // 0x00B686CC: MOV x0, x21                | X0 = args[0];//m1                       
            // 0x00B686D0: BL #0x27bc4e8              | args[0].System.IDisposable.Dispose();   
            val_5.System.IDisposable.Dispose();
            // 0x00B686D4: LDP w8, w9, [x0]           | W8 = typeof(System.Object);              //  | 
            // 0x00B686D8: LDR w10, [x0, #8]          | 
            // 0x00B686DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B686E0: MOV x0, x20                | X0 = 1152921514658227776 (0x10000002571BE640);//ML01
            // 0x00B686E4: STP w8, w9, [x20, #0x3c]   | this.marshalPos = typeof(System.Object);  mem[1152921514658227840] = ???;  //  dest_result_addr=1152921514658227836 |  dest_result_addr=1152921514658227840
            this.marshalPos = new UnityEngine.Vector3();
            mem[1152921514658227840] = ???;
            // 0x00B686E8: STR w10, [x20, #0x44]      | mem[1152921514658227844] = ???;          //  dest_result_addr=1152921514658227844
            mem[1152921514658227844] = ???;
            // 0x00B686EC: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B686F0: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00B686F4: CBNZ x19, #0xb686fc        | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x00B686F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00B686FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68700: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00B68704: BL #0x1b759fc              | X0 = val_1.get_name();                  
            string val_2 = val_1.name;
            // 0x00B68708: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00B6870C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00B68710: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00B68714: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00B68718: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B6871C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00B68720: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00B68724: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68728: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00B6872C: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.AIMoveBvr); 
            // 0x00B68730: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_5 = null;
            // 0x00B68734: MOV x0, x20                | X0 = 1152921514658227776 (0x10000002571BE640);//ML01
            // 0x00B68738: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Entity.Behavior.AIMoveBvr).__il2cppRuntimeField_150; X1 = typeof(Entity.Behavior.AIMoveBvr).__il2cppRuntimeField_158; //  | 
            // 0x00B6873C: BLR x9                     | X0 = typeof(Entity.Behavior.AIMoveBvr).__il2cppRuntimeField_150();
            // 0x00B68740: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00B68744: LDR x8, [x8, #0x8c8]       | X8 = 1152921504892149760;               
            // 0x00B68748: STRB w0, [sp, #0xf]        | stack[1152921514658215711] = this;       //  dest_result_addr=1152921514658215711
            // 0x00B6874C: ADD x1, sp, #0xf           | X1 = (1152921514658215696 + 15) = 1152921514658215711 (0x10000002571BB71F);
            // 0x00B68750: LDR x8, [x8]               | X8 = typeof(Entity.Behavior.EBehaviorID);
            // 0x00B68754: MOV x0, x8                 | X0 = 1152921504892149760 (0x1000000011016000);//ML01
            // 0x00B68758: BL #0x27bc028              | X0 = 1152921514658308928 = (Il2CppObject*)Box((RuntimeClass*)typeof(Entity.Behavior.EBehaviorID), this);
            // 0x00B6875C: MOV x22, x0                | X22 = 1152921514658308928 (0x10000002571D2340);//ML01
            // 0x00B68760: CBNZ x21, #0xb68768        | if ( != null) goto label_6;             
            if(null != null)
            {
                goto label_6;
            }
            // 0x00B68764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x00B68768: CBZ x22, #0xb6878c         | if (this == 0) goto label_8;            
            if(this == 0)
            {
                goto label_8;
            }
            // 0x00B6876C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00B68770: MOV x0, x22                | X0 = 1152921514658308928 (0x10000002571D2340);//ML01
            // 0x00B68774: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00B68778: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this, ????);       
            // 0x00B6877C: CBNZ x0, #0xb6878c         | if (this != 0) goto label_8;            
            if(this != 0)
            {
                goto label_8;
            }
            // 0x00B68780: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this, ????);       
            // 0x00B68784: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68788: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_8:
            // 0x00B6878C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00B68790: CBNZ w8, #0xb687a0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_9;
            // 0x00B68794: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00B68798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B6879C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_9:
            // 0x00B687A0: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = this;
            // 0x00B687A4: LDUR x8, [x20, #0x3c]      | X8 = this.marshalPos; //P2              
            // 0x00B687A8: LDR w9, [x20, #0x44]       | 
            // 0x00B687AC: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x00B687B0: MOV x1, sp                 | X1 = 1152921514658215696 (0x10000002571BB710);//ML01
            // 0x00B687B4: STR x8, [sp]               | stack[1152921514658215696] = this.marshalPos;  //  dest_result_addr=1152921514658215696
            // 0x00B687B8: STR w9, [sp, #8]           | stack[1152921514658215704] = typeof(Entity.Behavior.AIMoveBvr).__il2cppRuntimeField_150;  //  dest_result_addr=1152921514658215704
            // 0x00B687BC: BL #0x27bc028              | X0 = 1152921514658313024 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), this.marshalPos);
            // 0x00B687C0: MOV x20, x0                | X20 = 1152921514658313024 (0x10000002571D3340);//ML01
            // 0x00B687C4: CBZ x20, #0xb687e8         | if (this.marshalPos == 0) goto label_11;
            if(this.marshalPos == 0)
            {
                goto label_11;
            }
            // 0x00B687C8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00B687CC: MOV x0, x20                | X0 = 1152921514658313024 (0x10000002571D3340);//ML01
            // 0x00B687D0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00B687D4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.marshalPos, ????);
            // 0x00B687D8: CBNZ x0, #0xb687e8         | if (this.marshalPos != 0) goto label_11;
            if(this.marshalPos != 0)
            {
                goto label_11;
            }
            // 0x00B687DC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.marshalPos, ????);
            // 0x00B687E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B687E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.marshalPos, ????);
            label_11:
            // 0x00B687E8: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00B687EC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00B687F0: B.HI #0xb68800             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_12;
            // 0x00B687F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.marshalPos, ????);
            // 0x00B687F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B687FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.marshalPos, ????);
            label_12:
            // 0x00B68800: STR x20, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = this.marshalPos;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = this.marshalPos;
            // 0x00B68804: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00B68808: LDR x8, [x8, #0x1b0]       | X8 = (string**)(1152921514658195488)("{0}->pos{1}");
            // 0x00B6880C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68810: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B68814: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00B68818: LDR x1, [x8]               | X1 = "{0}->pos{1}";                     
            // 0x00B6881C: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}->pos{1}");
            string val_3 = EString.EFormat(format:  0, args:  "{0}->pos{1}");
            // 0x00B68820: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00B68824: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00B68828: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00B6882C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00B68830: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00B68834: TBZ w9, #0, #0xb68848      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00B68838: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00B6883C: CBNZ w9, #0xb68848         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00B68840: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00B68844: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_14:
            // 0x00B68848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B6884C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B68850: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x00B68854: MOV x2, x20                | X2 = val_3;//m1                         
            // 0x00B68858: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_2);
            string val_4 = System.String.Concat(str0:  0, str1:  val_2);
            // 0x00B6885C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00B68860: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00B68864: MOV x19, x0                | X19 = val_4;//m1                        
            val_6 = val_4;
            // 0x00B68868: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00B6886C: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00B68870: TBZ w9, #0, #0xb68884      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00B68874: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00B68878: CBNZ w9, #0xb68884         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00B6887C: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            val_7 = null;
            // 0x00B68880: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_16:
            // 0x00B68884: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00B68888: MOV x1, x19                | X1 = val_4;//m1                         
            // 0x00B6888C: BL #0xb45c10               | EDebug.Log(message:  val_7 = null, isShowStack:  val_6);
            EDebug.Log(message:  val_7, isShowStack:  val_6);
            label_2:
            // 0x00B68890: SUB sp, x29, #0x30         | SP = (1152921514658215760 - 48) = 1152921514658215712 (0x10000002571BB720);
            // 0x00B68894: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68898: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B6889C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00B688A0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00B688A4: RET                        |  return;                                
            return;
            label_4:
            // 0x00B688A8: MOV x8, sp                 | X8 = 1152921514658215696 (0x10000002571BB710);//ML01
            // 0x00B688AC: MOV x1, x19                | X1 = 1152921504695078912 (0x1000000005425000);//ML01
            // 0x00B688B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00B688B4: LDR x0, [sp]               | X0 = this.marshalPos;                   
            // 0x00B688B8: BL #0x27af090              | X0 = sub_27AF090( ?? this.marshalPos, ????);
            // 0x00B688BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B688C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.marshalPos, ????);
            // 0x00B688C4: MOV x0, sp                 | X0 = 1152921514658215696 (0x10000002571BB710);//ML01
            // 0x00B688C8: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000002571BB710); //ERROR_TYPE
            // 0x00B688CC: MOV x19, x0                | X19 = 1152921514658215696 (0x10000002571BB710);//ML01
            // 0x00B688D0: MOV x0, sp                 | X0 = 1152921514658215696 (0x10000002571BB710);//ML01
            // 0x00B688D4: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000002571BB710); //ERROR_TYPE
            // 0x00B688D8: MOV x0, x19                | X0 = 1152921514658215696 (0x10000002571BB710);//ML01
            // 0x00B688DC: BL #0x980800               | X0 = sub_980800( ?? 0x10000002571BB710, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00B688E0 (11962592), len: 144  VirtAddr: 0x00B688E0 RVA: 0x00B688E0 token: 100691423 methodIndex: 27220 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoEntering()
        {
            //
            // Disasemble & Code
            // 0x00B688E0: STP d11, d10, [sp, #-0x40]! | stack[1152921514658401440] = ???;  stack[1152921514658401448] = ???;  //  dest_result_addr=1152921514658401440 |  dest_result_addr=1152921514658401448
            // 0x00B688E4: STP d9, d8, [sp, #0x10]    | stack[1152921514658401456] = ???;  stack[1152921514658401464] = ???;  //  dest_result_addr=1152921514658401456 |  dest_result_addr=1152921514658401464
            // 0x00B688E8: STP x20, x19, [sp, #0x20]  | stack[1152921514658401472] = ???;  stack[1152921514658401480] = ???;  //  dest_result_addr=1152921514658401472 |  dest_result_addr=1152921514658401480
            // 0x00B688EC: STP x29, x30, [sp, #0x30]  | stack[1152921514658401488] = ???;  stack[1152921514658401496] = ???;  //  dest_result_addr=1152921514658401488 |  dest_result_addr=1152921514658401496
            // 0x00B688F0: ADD x29, sp, #0x30         | X29 = (1152921514658401440 + 48) = 1152921514658401488 (0x10000002571E8CD0);
            // 0x00B688F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B688F8: MOV x19, x0                | X19 = 1152921514658413504 (0x10000002571EBBC0);//ML01
            // 0x00B688FC: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B68900: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00B68904: CBNZ x20, #0xb6890c        | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x00B68908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x00B6890C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B68910: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00B68914: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00B68918: BL #0xd89da4               | val_1.set_IsAutoMove(value:  true);     
            val_1.IsAutoMove = true;
            // 0x00B6891C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68920: MOV x0, x19                | X0 = 1152921514658413504 (0x10000002571EBBC0);//ML01
            // 0x00B68924: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_2 = this.entity;
            // 0x00B68928: LDP s8, s9, [x19, #0x3c]   | S8 = this.marshalPos; //P2               //  | 
            // 0x00B6892C: LDR s10, [x19, #0x44]      | 
            // 0x00B68930: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00B68934: CBNZ x19, #0xb6893c        | if (val_2 != null) goto label_1;        
            if(val_2 != null)
            {
                goto label_1;
            }
            // 0x00B68938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_1:
            // 0x00B6893C: LDR x8, [x19]              | X8 = typeof(CombatEntity);              
            // 0x00B68940: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00B68944: MOV v0.16b, v8.16b         | V0 = this.marshalPos;//m1               
            // 0x00B68948: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
            // 0x00B6894C: LDR x3, [x8, #0x270]       | X3 = typeof(CombatEntity).__il2cppRuntimeField_270;
            // 0x00B68950: LDR x2, [x8, #0x278]       | X2 = typeof(CombatEntity).__il2cppRuntimeField_278;
            // 0x00B68954: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68958: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00B6895C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x00B68960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68964: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
            // 0x00B68968: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x00B6896C: BR x3                      | goto typeof(CombatEntity).__il2cppRuntimeField_270;
            goto typeof(CombatEntity).__il2cppRuntimeField_270;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68970 (11962736), len: 56  VirtAddr: 0x00B68970 RVA: 0x00B68970 token: 100691424 methodIndex: 27221 delegateWrapperIndex: 0 methodInvoker: 0
        public override void DoLeaving()
        {
            //
            // Disasemble & Code
            // 0x00B68970: STP x20, x19, [sp, #-0x20]! | stack[1152921514658525760] = ???;  stack[1152921514658525768] = ???;  //  dest_result_addr=1152921514658525760 |  dest_result_addr=1152921514658525768
            // 0x00B68974: STP x29, x30, [sp, #0x10]  | stack[1152921514658525776] = ???;  stack[1152921514658525784] = ???;  //  dest_result_addr=1152921514658525776 |  dest_result_addr=1152921514658525784
            // 0x00B68978: ADD x29, sp, #0x10         | X29 = (1152921514658525760 + 16) = 1152921514658525776 (0x1000000257207250);
            // 0x00B6897C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68980: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B68984: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00B68988: CBNZ x19, #0xb68990        | if (val_1 != null) goto label_0;        
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x00B6898C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_0:
            // 0x00B68990: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68994: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00B68998: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B6899C: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00B689A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00B689A4: B #0xd89da4                | val_1.set_IsAutoMove(value:  false); return;
            val_1.IsAutoMove = false;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B689A8 (11962792), len: 208  VirtAddr: 0x00B689A8 RVA: 0x00B689A8 token: 100691425 methodIndex: 27222 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Pause()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00B689A8: STP x20, x19, [sp, #-0x20]! | stack[1152921514658650048] = ???;  stack[1152921514658650056] = ???;  //  dest_result_addr=1152921514658650048 |  dest_result_addr=1152921514658650056
            // 0x00B689AC: STP x29, x30, [sp, #0x10]  | stack[1152921514658650064] = ???;  stack[1152921514658650072] = ???;  //  dest_result_addr=1152921514658650064 |  dest_result_addr=1152921514658650072
            // 0x00B689B0: ADD x29, sp, #0x10         | X29 = (1152921514658650048 + 16) = 1152921514658650064 (0x10000002572257D0);
            // 0x00B689B4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B689B8: LDRB w8, [x20, #0x968]     | W8 = (bool)static_value_03733968;       
            // 0x00B689BC: MOV x19, x0                | X19 = 1152921514658662080 (0x10000002572286C0);//ML01
            val_8 = this;
            // 0x00B689C0: TBNZ w8, #0, #0xb689dc     | if (static_value_03733968 == true) goto label_0;
            // 0x00B689C4: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x00B689C8: LDR x8, [x8, #0x718]       | X8 = 0x2B8AB08;                         
            // 0x00B689CC: LDR w0, [x8]               | W0 = 0x180;                             
            // 0x00B689D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x180, ????);      
            // 0x00B689D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B689D8: STRB w8, [x20, #0x968]     | static_value_03733968 = true;            //  dest_result_addr=57882984
            label_0:
            // 0x00B689DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B689E0: MOV x0, x19                | X0 = 1152921514658662080 (0x10000002572286C0);//ML01
            // 0x00B689E4: BL #0xeb5564               | this.Pause();                           
            this.Pause();
            // 0x00B689E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B689EC: MOV x0, x19                | X0 = 1152921514658662080 (0x10000002572286C0);//ML01
            // 0x00B689F0: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B689F4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00B689F8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x00B689FC: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00B68A00: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
            // 0x00B68A04: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00B68A08: TBZ w9, #0, #0xb68a1c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00B68A0C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00B68A10: CBNZ w9, #0xb68a1c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00B68A14: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
            // 0x00B68A18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_2:
            // 0x00B68A1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B68A24: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00B68A28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B68A2C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
            bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
            // 0x00B68A30: TBZ w0, #0, #0xb68a6c      | if (val_2 == false) goto label_3;       
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x00B68A34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68A38: MOV x0, x19                | X0 = 1152921514658662080 (0x10000002572286C0);//ML01
            // 0x00B68A3C: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_3 = this.entity;
            // 0x00B68A40: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00B68A44: CBNZ x19, #0xb68a4c        | if (val_3 != null) goto label_4;        
            if(val_3 != null)
            {
                goto label_4;
            }
            // 0x00B68A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_4:
            // 0x00B68A4C: LDR x8, [x19]              | X8 = typeof(CombatEntity);              
            // 0x00B68A50: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00B68A54: MOV x0, x19                | X0 = val_3;//m1                         
            // 0x00B68A58: LDR x3, [x8, #0x280]       | X3 = typeof(CombatEntity).__il2cppRuntimeField_280;
            // 0x00B68A5C: LDR x2, [x8, #0x288]       | X2 = typeof(CombatEntity).__il2cppRuntimeField_288;
            // 0x00B68A60: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68A64: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            val_8 = ???;
            // 0x00B68A68: BR x3                      | goto typeof(CombatEntity).__il2cppRuntimeField_280;
            goto typeof(CombatEntity).__il2cppRuntimeField_280;
            label_3:
            // 0x00B68A6C: LDP x29, x30, [sp, #0x10]  | X29 = val_4; X30 = val_5;                //  find_add[1152921514658638080] |  find_add[1152921514658638080]
            // 0x00B68A70: LDP x20, x19, [sp], #0x20  | X20 = val_6; X19 = val_7;                //  find_add[1152921514658638080] |  find_add[1152921514658638080]
            // 0x00B68A74: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00B68A78 (11963000), len: 304  VirtAddr: 0x00B68A78 RVA: 0x00B68A78 token: 100691426 methodIndex: 27223 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Play()
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x00B68A78: STP d11, d10, [sp, #-0x40]! | stack[1152921514658782496] = ???;  stack[1152921514658782504] = ???;  //  dest_result_addr=1152921514658782496 |  dest_result_addr=1152921514658782504
            // 0x00B68A7C: STP d9, d8, [sp, #0x10]    | stack[1152921514658782512] = ???;  stack[1152921514658782520] = ???;  //  dest_result_addr=1152921514658782512 |  dest_result_addr=1152921514658782520
            // 0x00B68A80: STP x20, x19, [sp, #0x20]  | stack[1152921514658782528] = ???;  stack[1152921514658782536] = ???;  //  dest_result_addr=1152921514658782528 |  dest_result_addr=1152921514658782536
            // 0x00B68A84: STP x29, x30, [sp, #0x30]  | stack[1152921514658782544] = ???;  stack[1152921514658782552] = ???;  //  dest_result_addr=1152921514658782544 |  dest_result_addr=1152921514658782552
            // 0x00B68A88: ADD x29, sp, #0x30         | X29 = (1152921514658782496 + 48) = 1152921514658782544 (0x1000000257245D50);
            // 0x00B68A8C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00B68A90: LDRB w8, [x20, #0x969]     | W8 = (bool)static_value_03733969;       
            // 0x00B68A94: MOV x19, x0                | X19 = 1152921514658794560 (0x1000000257248C40);//ML01
            val_14 = this;
            // 0x00B68A98: TBNZ w8, #0, #0xb68ab4     | if (static_value_03733969 == true) goto label_0;
            // 0x00B68A9C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00B68AA0: LDR x8, [x8, #0xf48]       | X8 = 0x2B8AB0C;                         
            // 0x00B68AA4: LDR w0, [x8]               | W0 = 0x181;                             
            // 0x00B68AA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x181, ????);      
            // 0x00B68AAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00B68AB0: STRB w8, [x20, #0x969]     | static_value_03733969 = true;            //  dest_result_addr=57882985
            label_0:
            // 0x00B68AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68AB8: MOV x0, x19                | X0 = 1152921514658794560 (0x1000000257248C40);//ML01
            // 0x00B68ABC: BL #0xeb5634               | this.Play();                            
            this.Play();
            // 0x00B68AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68AC4: MOV x0, x19                | X0 = 1152921514658794560 (0x1000000257248C40);//ML01
            // 0x00B68AC8: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_1 = this.entity;
            // 0x00B68ACC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00B68AD0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x00B68AD4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00B68AD8: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
            // 0x00B68ADC: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00B68AE0: TBZ w9, #0, #0xb68af4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00B68AE4: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00B68AE8: CBNZ w9, #0xb68af4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00B68AEC: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
            // 0x00B68AF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_2:
            // 0x00B68AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00B68AF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00B68AFC: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00B68B00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00B68B04: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
            bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
            // 0x00B68B08: TBZ w0, #0, #0xb68b94      | if (val_2 == false) goto label_3;       
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x00B68B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68B10: MOV x0, x19                | X0 = 1152921514658794560 (0x1000000257248C40);//ML01
            // 0x00B68B14: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_3 = this.entity;
            // 0x00B68B18: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00B68B1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68B20: MOV x0, x19                | X0 = 1152921514658794560 (0x1000000257248C40);//ML01
            // 0x00B68B24: BL #0xeb3e0c               | X0 = this.get_entity();                 
            CombatEntity val_4 = this.entity;
            // 0x00B68B28: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00B68B2C: CBNZ x19, #0xb68b34        | if (val_4 != null) goto label_4;        
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x00B68B30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_4:
            // 0x00B68B34: LDR x19, [x19, #0x20]      | 
            // 0x00B68B38: CBNZ x19, #0xb68b40        | if (val_4 != null) goto label_5;        
            if(val_4 != null)
            {
                goto label_5;
            }
            // 0x00B68B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_5:
            // 0x00B68B40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68B44: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x00B68B48: BL #0x2693510              | X0 = val_4.get_position();              
            UnityEngine.Vector3 val_5 = val_4.position;
            // 0x00B68B4C: MOV v8.16b, v0.16b         | V8 = val_5.x;//m1                       
            // 0x00B68B50: MOV v9.16b, v1.16b         | V9 = val_5.y;//m1                       
            // 0x00B68B54: MOV v10.16b, v2.16b        | V10 = val_5.z;//m1                      
            // 0x00B68B58: CBNZ x20, #0xb68b60        | if (val_3 != null) goto label_6;        
            if(val_3 != null)
            {
                goto label_6;
            }
            // 0x00B68B5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x00B68B60: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
            // 0x00B68B64: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x00B68B68: MOV v0.16b, v8.16b         | V0 = val_5.x;//m1                       
            // 0x00B68B6C: MOV v1.16b, v9.16b         | V1 = val_5.y;//m1                       
            // 0x00B68B70: LDR x3, [x8, #0x270]       | X3 = typeof(CombatEntity).__il2cppRuntimeField_270;
            // 0x00B68B74: LDR x2, [x8, #0x278]       | X2 = typeof(CombatEntity).__il2cppRuntimeField_278;
            // 0x00B68B78: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00B68B7C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            val_14 = ???;
            // 0x00B68B80: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x00B68B84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00B68B88: MOV v2.16b, v10.16b        | V2 = val_5.z;//m1                       
            // 0x00B68B8C: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x00B68B90: BR x3                      | goto typeof(CombatEntity).__il2cppRuntimeField_270;
            goto typeof(CombatEntity).__il2cppRuntimeField_270;
            label_3:
            // 0x00B68B94: LDP x29, x30, [sp, #0x30]  | X29 = val_6; X30 = val_7;                //  find_add[1152921514658770560] |  find_add[1152921514658770560]
            // 0x00B68B98: LDP x20, x19, [sp, #0x20]  | X20 = val_8; X19 = val_9;                //  find_add[1152921514658770560] |  find_add[1152921514658770560]
            // 0x00B68B9C: LDP d9, d8, [sp, #0x10]    | D9 = val_10; D8 = val_11;                //  find_add[1152921514658770560] |  find_add[1152921514658770560]
            // 0x00B68BA0: LDP d11, d10, [sp], #0x40  | D11 = val_12; D10 = val_13;              //  find_add[1152921514658770560] |  find_add[1152921514658770560]
            // 0x00B68BA4: RET                        |  return;                                
            return;
        
        }
    
    }

}
