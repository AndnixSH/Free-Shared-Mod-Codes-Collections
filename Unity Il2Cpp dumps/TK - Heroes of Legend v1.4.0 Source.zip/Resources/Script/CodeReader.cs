using UnityEngine;

namespace ILRuntime.Mono.Cecil.Cil
{
    internal sealed class CodeReader : BinaryStreamReader
    {
        // Fields
        internal readonly ILRuntime.Mono.Cecil.MetadataReader reader; //  0x00000040
        private int start; //  0x00000048
        private ILRuntime.Mono.Cecil.MethodDefinition method; //  0x00000050
        private ILRuntime.Mono.Cecil.Cil.MethodBody body; //  0x00000058
        
        // Properties
        private int Offset { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E590D8 (15044824), len: 44  VirtAddr: 0x00E590D8 RVA: 0x00E590D8 token: 100664610 methodIndex: 19362 delegateWrapperIndex: 0 methodInvoker: 0
        private int get_Offset()
        {
            //
            // Disasemble & Code
            // 0x00E590D8: STP x20, x19, [sp, #-0x20]! | stack[1152921509574139296] = ???;  stack[1152921509574139304] = ???;  //  dest_result_addr=1152921509574139296 |  dest_result_addr=1152921509574139304
            // 0x00E590DC: STP x29, x30, [sp, #0x10]  | stack[1152921509574139312] = ???;  stack[1152921509574139320] = ???;  //  dest_result_addr=1152921509574139312 |  dest_result_addr=1152921509574139320
            // 0x00E590E0: ADD x29, sp, #0x10         | X29 = (1152921509574139296 + 16) = 1152921509574139312 (0x100000012812DDB0);
            // 0x00E590E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E590E8: MOV x19, x0                | X19 = 1152921509574151328 (0x1000000128130CA0);//ML01
            // 0x00E590EC: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_1 = this.Position;
            // 0x00E590F0: LDR w8, [x19, #0x48]       | W8 = this.start; //P2                   
            // 0x00E590F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E590F8: SUB w0, w0, w8             | W0 = (val_1 - this.start);              
            val_1 = val_1 - this.start;
            // 0x00E590FC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E59100: RET                        |  return (System.Int32)(val_1 - this.start);
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59104 (15044868), len: 80  VirtAddr: 0x00E59104 RVA: 0x00E59104 token: 100664611 methodIndex: 19363 delegateWrapperIndex: 0 methodInvoker: 0
        public CodeReader(ILRuntime.Mono.Cecil.MetadataReader reader)
        {
            //
            // Disasemble & Code
            // 0x00E59104: STP x22, x21, [sp, #-0x30]! | stack[1152921509574259472] = ???;  stack[1152921509574259480] = ???;  //  dest_result_addr=1152921509574259472 |  dest_result_addr=1152921509574259480
            // 0x00E59108: STP x20, x19, [sp, #0x10]  | stack[1152921509574259488] = ???;  stack[1152921509574259496] = ???;  //  dest_result_addr=1152921509574259488 |  dest_result_addr=1152921509574259496
            // 0x00E5910C: STP x29, x30, [sp, #0x20]  | stack[1152921509574259504] = ???;  stack[1152921509574259512] = ???;  //  dest_result_addr=1152921509574259504 |  dest_result_addr=1152921509574259512
            // 0x00E59110: ADD x29, sp, #0x20         | X29 = (1152921509574259472 + 32) = 1152921509574259504 (0x100000012814B330);
            // 0x00E59114: MOV x19, x1                | X19 = reader;//m1                       
            // 0x00E59118: MOV x20, x0                | X20 = 1152921509574271520 (0x100000012814E220);//ML01
            // 0x00E5911C: CBNZ x19, #0xe59124        | if (reader != null) goto label_0;       
            if(reader != null)
            {
                goto label_0;
            }
            // 0x00E59120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E59124: LDR x21, [x19, #0x20]      | X21 = reader.image; //P2                
            // 0x00E59128: CBNZ x21, #0xe59130        | if (reader.image != null) goto label_1; 
            if(reader.image != null)
            {
                goto label_1;
            }
            // 0x00E5912C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00E59130: LDR x1, [x21, #0x10]       | X1 = reader.image.Stream; //P2          
            // 0x00E59134: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E59138: MOV x0, x20                | X0 = 1152921509574271520 (0x100000012814E220);//ML01
            // 0x00E5913C: BL #0x11e06b8              | this..ctor(stream:  reader.image.Stream);
            // 0x00E59140: STR x19, [x20, #0x40]      | this.reader = reader;                    //  dest_result_addr=1152921509574271584
            this.reader = reader;
            // 0x00E59144: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59148: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5914C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E59150: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59154 (15044948), len: 160  VirtAddr: 0x00E59154 RVA: 0x00E59154 token: 100664612 methodIndex: 19364 delegateWrapperIndex: 0 methodInvoker: 0
        public int MoveTo(ILRuntime.Mono.Cecil.MethodDefinition method)
        {
            //
            // Disasemble & Code
            // 0x00E59154: STP x22, x21, [sp, #-0x30]! | stack[1152921509574396048] = ???;  stack[1152921509574396056] = ???;  //  dest_result_addr=1152921509574396048 |  dest_result_addr=1152921509574396056
            // 0x00E59158: STP x20, x19, [sp, #0x10]  | stack[1152921509574396064] = ???;  stack[1152921509574396072] = ???;  //  dest_result_addr=1152921509574396064 |  dest_result_addr=1152921509574396072
            // 0x00E5915C: STP x29, x30, [sp, #0x20]  | stack[1152921509574396080] = ???;  stack[1152921509574396088] = ???;  //  dest_result_addr=1152921509574396080 |  dest_result_addr=1152921509574396088
            // 0x00E59160: ADD x29, sp, #0x20         | X29 = (1152921509574396048 + 32) = 1152921509574396080 (0x100000012816C8B0);
            // 0x00E59164: MOV x19, x0                | X19 = 1152921509574408096 (0x100000012816F7A0);//ML01
            // 0x00E59168: LDR x20, [x19, #0x40]      | X20 = this.reader; //P2                 
            // 0x00E5916C: MOV x21, x1                | X21 = method;//m1                       
            // 0x00E59170: STR x21, [x19, #0x50]      | this.method = method;                    //  dest_result_addr=1152921509574408176
            this.method = method;
            // 0x00E59174: CBNZ x20, #0xe5917c        | if (this.reader != null) goto label_0;  
            if(this.reader != null)
            {
                goto label_0;
            }
            // 0x00E59178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E5917C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59180: MOV x0, x19                | X0 = 1152921509574408096 (0x100000012816F7A0);//ML01
            // 0x00E59184: STR x21, [x20, #0x40]      | this.reader.context = method;            //  dest_result_addr=0
            this.reader.context = method;
            // 0x00E59188: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_1 = this.Position;
            // 0x00E5918C: LDR x22, [x19, #0x40]      | X22 = this.reader; //P2                 
            // 0x00E59190: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x00E59194: CBNZ x22, #0xe5919c        | if (this.reader != null) goto label_1;  
            if(this.reader != null)
            {
                goto label_1;
            }
            // 0x00E59198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00E5919C: LDR x22, [x22, #0x20]      | X22 = this.reader.image; //P2           
            // 0x00E591A0: CBNZ x21, #0xe591a8        | if (method != null) goto label_2;       
            if(method != null)
            {
                goto label_2;
            }
            // 0x00E591A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00E591A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E591AC: MOV x0, x21                | X0 = method;//m1                        
            // 0x00E591B0: BL #0x11d65a4              | X0 = method.get_RVA();                  
            int val_2 = method.RVA;
            // 0x00E591B4: MOV w21, w0                | W21 = val_2;//m1                        
            // 0x00E591B8: CBNZ x22, #0xe591c0        | if (this.reader.image != null) goto label_3;
            if(this.reader.image != null)
            {
                goto label_3;
            }
            // 0x00E591BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00E591C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E591C4: MOV x0, x22                | X0 = this.reader.image;//m1             
            // 0x00E591C8: MOV w1, w21                | W1 = val_2;//m1                         
            // 0x00E591CC: BL #0x11e10e0              | X0 = this.reader.image.ResolveVirtualAddress(rva:  val_2);
            uint val_3 = this.reader.image.ResolveVirtualAddress(rva:  val_2);
            // 0x00E591D0: MOV w1, w0                 | W1 = val_3;//m1                         
            // 0x00E591D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E591D8: MOV x0, x19                | X0 = 1152921509574408096 (0x100000012816F7A0);//ML01
            // 0x00E591DC: BL #0x11e0630              | this.set_Position(value:  val_3);       
            this.Position = val_3;
            // 0x00E591E0: MOV w0, w20                | W0 = val_1;//m1                         
            // 0x00E591E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E591E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E591EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E591F0: RET                        |  return (System.Int32)val_1;            
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E591F4 (15045108), len: 68  VirtAddr: 0x00E591F4 RVA: 0x00E591F4 token: 100664613 methodIndex: 19365 delegateWrapperIndex: 0 methodInvoker: 0
        public void MoveBackTo(int position)
        {
            //
            // Disasemble & Code
            // 0x00E591F4: STP x22, x21, [sp, #-0x30]! | stack[1152921509574528528] = ???;  stack[1152921509574528536] = ???;  //  dest_result_addr=1152921509574528528 |  dest_result_addr=1152921509574528536
            // 0x00E591F8: STP x20, x19, [sp, #0x10]  | stack[1152921509574528544] = ???;  stack[1152921509574528552] = ???;  //  dest_result_addr=1152921509574528544 |  dest_result_addr=1152921509574528552
            // 0x00E591FC: STP x29, x30, [sp, #0x20]  | stack[1152921509574528560] = ???;  stack[1152921509574528568] = ???;  //  dest_result_addr=1152921509574528560 |  dest_result_addr=1152921509574528568
            // 0x00E59200: ADD x29, sp, #0x20         | X29 = (1152921509574528528 + 32) = 1152921509574528560 (0x100000012818CE30);
            // 0x00E59204: MOV x19, x0                | X19 = 1152921509574540576 (0x100000012818FD20);//ML01
            // 0x00E59208: LDR x21, [x19, #0x40]      | X21 = this.reader; //P2                 
            // 0x00E5920C: MOV w20, w1                | W20 = position;//m1                     
            // 0x00E59210: CBNZ x21, #0xe59218        | if (this.reader != null) goto label_0;  
            if(this.reader != null)
            {
                goto label_0;
            }
            // 0x00E59214: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E59218: STR xzr, [x21, #0x40]      | this.reader.context = null;              //  dest_result_addr=0
            this.reader.context = 0;
            // 0x00E5921C: MOV x0, x19                | X0 = 1152921509574540576 (0x100000012818FD20);//ML01
            // 0x00E59220: MOV w1, w20                | W1 = position;//m1                      
            // 0x00E59224: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59228: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5922C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E59230: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E59234: B #0x11e0630               | this.set_Position(value:  position); return;
            this.Position = position;
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59238 (15045176), len: 156  VirtAddr: 0x00E59238 RVA: 0x00E59238 token: 100664614 methodIndex: 19366 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.Cil.MethodBody ReadMethodBody(ILRuntime.Mono.Cecil.MethodDefinition method)
        {
            //
            // Disasemble & Code
            // 0x00E59238: STP x22, x21, [sp, #-0x30]! | stack[1152921509574652816] = ???;  stack[1152921509574652824] = ???;  //  dest_result_addr=1152921509574652816 |  dest_result_addr=1152921509574652824
            // 0x00E5923C: STP x20, x19, [sp, #0x10]  | stack[1152921509574652832] = ???;  stack[1152921509574652840] = ???;  //  dest_result_addr=1152921509574652832 |  dest_result_addr=1152921509574652840
            // 0x00E59240: STP x29, x30, [sp, #0x20]  | stack[1152921509574652848] = ???;  stack[1152921509574652856] = ???;  //  dest_result_addr=1152921509574652848 |  dest_result_addr=1152921509574652856
            // 0x00E59244: ADD x29, sp, #0x20         | X29 = (1152921509574652816 + 32) = 1152921509574652848 (0x10000001281AB3B0);
            // 0x00E59248: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5924C: LDRB w8, [x21, #0xadb]     | W8 = (bool)static_value_03734ADB;       
            // 0x00E59250: MOV x20, x1                | X20 = method;//m1                       
            // 0x00E59254: MOV x19, x0                | X19 = 1152921509574664864 (0x10000001281AE2A0);//ML01
            // 0x00E59258: TBNZ w8, #0, #0xe59274     | if (static_value_03734ADB == true) goto label_0;
            // 0x00E5925C: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x00E59260: LDR x8, [x8, #0x68]        | X8 = 0x2B90DB8;                         
            // 0x00E59264: LDR w0, [x8]               | W0 = 0x1A32;                            
            // 0x00E59268: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A32, ????);     
            // 0x00E5926C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E59270: STRB w8, [x21, #0xadb]     | static_value_03734ADB = true;            //  dest_result_addr=57887451
            label_0:
            // 0x00E59274: MOV x0, x19                | X0 = 1152921509574664864 (0x10000001281AE2A0);//ML01
            // 0x00E59278: MOV x1, x20                | X1 = method;//m1                        
            // 0x00E5927C: BL #0xe59154               | X0 = this.MoveTo(method:  method);      
            int val_1 = this.MoveTo(method:  method);
            // 0x00E59280: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00E59284: LDR x8, [x8, #0x9f0]       | X8 = 1152921504746516480;               
            // 0x00E59288: MOV w21, w0                | W21 = val_1;//m1                        
            // 0x00E5928C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Mono.Cecil.Cil.MethodBody);
            // 0x00E59290: MOV x0, x8                 | X0 = 1152921504746516480 (0x1000000008533000);//ML01
            object val_2 = null;
            // 0x00E59294: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.Cil.MethodBody), ????);
            // 0x00E59298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5929C: MOV x22, x0                | X22 = 1152921504746516480 (0x1000000008533000);//ML01
            // 0x00E592A0: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x00E592A4: MOV x0, x19                | X0 = 1152921509574664864 (0x10000001281AE2A0);//ML01
            // 0x00E592A8: STR x20, [x22, #0x10]      | typeof(ILRuntime.Mono.Cecil.Cil.MethodBody).__il2cppRuntimeField_10 = method;  //  dest_result_addr=1152921504746516496
            typeof(ILRuntime.Mono.Cecil.Cil.MethodBody).__il2cppRuntimeField_10 = method;
            // 0x00E592AC: STR x22, [x19, #0x58]      | this.body = typeof(ILRuntime.Mono.Cecil.Cil.MethodBody);  //  dest_result_addr=1152921509574664952
            this.body = val_2;
            // 0x00E592B0: BL #0xe59300               | this.ReadMethodBody();                  
            this.ReadMethodBody();
            // 0x00E592B4: MOV x0, x19                | X0 = 1152921509574664864 (0x10000001281AE2A0);//ML01
            // 0x00E592B8: MOV w1, w21                | W1 = val_1;//m1                         
            // 0x00E592BC: BL #0xe591f4               | this.MoveBackTo(position:  val_1);      
            this.MoveBackTo(position:  val_1);
            // 0x00E592C0: LDR x0, [x19, #0x58]       | X0 = this.body; //P2                    
            // 0x00E592C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E592C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E592CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E592D0: RET                        |  return (ILRuntime.Mono.Cecil.Cil.MethodBody)this.body;
            return this.body;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.Cil.MethodBody, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59300 (15045376), len: 464  VirtAddr: 0x00E59300 RVA: 0x00E59300 token: 100664615 methodIndex: 19367 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadMethodBody()
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Cecil.MethodDefinition val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00E59300: STP x22, x21, [sp, #-0x30]! | stack[1152921509574814992] = ???;  stack[1152921509574815000] = ???;  //  dest_result_addr=1152921509574814992 |  dest_result_addr=1152921509574815000
            // 0x00E59304: STP x20, x19, [sp, #0x10]  | stack[1152921509574815008] = ???;  stack[1152921509574815016] = ???;  //  dest_result_addr=1152921509574815008 |  dest_result_addr=1152921509574815016
            // 0x00E59308: STP x29, x30, [sp, #0x20]  | stack[1152921509574815024] = ???;  stack[1152921509574815032] = ???;  //  dest_result_addr=1152921509574815024 |  dest_result_addr=1152921509574815032
            // 0x00E5930C: ADD x29, sp, #0x20         | X29 = (1152921509574814992 + 32) = 1152921509574815024 (0x10000001281D2D30);
            // 0x00E59310: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E59314: LDRB w8, [x20, #0xadc]     | W8 = (bool)static_value_03734ADC;       
            // 0x00E59318: MOV x19, x0                | X19 = 1152921509574827040 (0x10000001281D5C20);//ML01
            // 0x00E5931C: TBNZ w8, #0, #0xe59338     | if (static_value_03734ADC == true) goto label_0;
            // 0x00E59320: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E59324: LDR x8, [x8, #0xfd0]       | X8 = 0x2B90DB4;                         
            // 0x00E59328: LDR w0, [x8]               | W0 = 0x1A31;                            
            // 0x00E5932C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A31, ????);     
            // 0x00E59330: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E59334: STRB w8, [x20, #0xadc]     | static_value_03734ADC = true;            //  dest_result_addr=57887452
            label_0:
            // 0x00E59338: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5933C: MOV x0, x19                | X0 = 1152921509574827040 (0x10000001281D5C20);//ML01
            // 0x00E59340: LDP x9, x1, [x8, #0x1e0]   | X9 = public System.Byte System.IO.BinaryReader::ReadByte(); X1 = public System.Byte System.IO.BinaryReader::ReadByte(); //  | 
            // 0x00E59344: BLR x9                     | X0 = this.ReadByte();                   
            byte val_1 = this.ReadByte();
            // 0x00E59348: AND w8, w0, #3             | W8 = (val_1 & 3);                       
            byte val_2 = val_1 & 3;
            // 0x00E5934C: CMP w8, #3                 | STATE = COMPARE((val_1 & 3), 0x3)       
            // 0x00E59350: B.EQ #0xe59394             | if (val_2 == 3) goto label_1;           
            if(val_2 == 3)
            {
                goto label_1;
            }
            // 0x00E59354: CMP w8, #2                 | STATE = COMPARE((val_1 & 3), 0x2)       
            // 0x00E59358: B.NE #0xe5949c             | if (val_2 != 2) goto label_2;           
            if(val_2 != 2)
            {
                goto label_2;
            }
            // 0x00E5935C: LDR x20, [x19, #0x58]      | X20 = this.body; //P2                   
            // 0x00E59360: AND w21, w0, #0xff         | W21 = (val_1 & 255);                    
            val_7 = val_1 & 255;
            // 0x00E59364: CBNZ x20, #0xe5936c        | if (this.body != null) goto label_3;    
            if(this.body != null)
            {
                goto label_3;
            }
            // 0x00E59368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00E5936C: LSR w8, w21, #2            | W8 = ((val_1 & 255) >> 2);              
            byte val_3 = val_7 >> 2;
            // 0x00E59370: STR w8, [x20, #0x24]       | this.body.code_size = ((val_1 & 255) >> 2);  //  dest_result_addr=0
            this.body.code_size = val_3;
            // 0x00E59374: LDR x20, [x19, #0x58]      | X20 = this.body; //P2                   
            // 0x00E59378: CBNZ x20, #0xe59380        | if (this.body != null) goto label_4;    
            if(this.body != null)
            {
                goto label_4;
            }
            // 0x00E5937C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00E59380: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            // 0x00E59384: MOV x0, x19                | X0 = 1152921509574827040 (0x10000001281D5C20);//ML01
            // 0x00E59388: STR w8, [x20, #0x20]       | this.body.max_stack_size = 8;            //  dest_result_addr=0
            this.body.max_stack_size = 8;
            // 0x00E5938C: BL #0xe594d8               | this.ReadCode();                        
            this.ReadCode();
            // 0x00E59390: B #0xe593ac                |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x00E59394: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_8 = 0;
            // 0x00E59398: MOVN w1, #0                | W1 = 0 (0x0);//ML01                     
            // 0x00E5939C: MOV x0, x19                | X0 = 1152921509574827040 (0x10000001281D5C20);//ML01
            // 0x00E593A0: BL #0x11e06c0              | this.Advance(bytes:  0);                
            this.Advance(bytes:  0);
            // 0x00E593A4: MOV x0, x19                | X0 = 1152921509574827040 (0x10000001281D5C20);//ML01
            // 0x00E593A8: BL #0xe5969c               | this.ReadFatMethod();                   
            this.ReadFatMethod();
            label_5:
            // 0x00E593AC: LDR x20, [x19, #0x40]      | X20 = this.reader; //P2                 
            // 0x00E593B0: CBNZ x20, #0xe593b8        | if (this.reader != null) goto label_6;  
            if(this.reader != null)
            {
                goto label_6;
            }
            // 0x00E593B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x00E593B8: LDR x20, [x20, #0x28]      | X20 = this.reader.module; //P2          
            // 0x00E593BC: CBNZ x20, #0xe593c4        | if (this.reader.module != null) goto label_7;
            if(this.reader.module != null)
            {
                goto label_7;
            }
            // 0x00E593C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x00E593C4: LDR x20, [x20, #0x40]      | X20 = this.reader.module.symbol_reader; //P2 
            // 0x00E593C8: CBZ x20, #0xe59464         | if (this.reader.module.symbol_reader == null) goto label_10;
            if(this.reader.module.symbol_reader == null)
            {
                goto label_10;
            }
            // 0x00E593CC: LDR x21, [x19, #0x50]      | X21 = this.method; //P2                 
            val_7 = this.method;
            // 0x00E593D0: CBNZ x21, #0xe593d8        | if (this.method != null) goto label_9;  
            if(val_7 != null)
            {
                goto label_9;
            }
            // 0x00E593D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_9:
            // 0x00E593D8: LDR x8, [x21, #0x90]       | X8 = this.method.debug_info; //P2       
            // 0x00E593DC: CBNZ x8, #0xe59464         | if (this.method.debug_info != null) goto label_10;
            if(this.method.debug_info != null)
            {
                goto label_10;
            }
            // 0x00E593E0: ADRP x9, #0x3641000        | X9 = 56889344 (0x3641000);              
            // 0x00E593E4: LDR x8, [x20]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.ISymbolReader);
            // 0x00E593E8: LDR x21, [x19, #0x50]      | X21 = this.method; //P2                 
            val_7 = this.method;
            // 0x00E593EC: LDR x9, [x9, #0x568]       | X9 = 1152921504748433408;               
            // 0x00E593F0: LDR x1, [x9]               | X1 = typeof(ILRuntime.Mono.Cecil.Cil.ISymbolReader);
            // 0x00E593F4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.Mono.Cecil.Cil.ISymbolReader.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E593F8: CBZ x9, #0xe59424          | if (ILRuntime.Mono.Cecil.Cil.ISymbolReader.__il2cppRuntimeField_interface_offsets_count == 0) goto label_11;
            // 0x00E593FC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.Mono.Cecil.Cil.ISymbolReader.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E59400: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x00E59404: ADD x10, x10, #8           | X10 = (ILRuntime.Mono.Cecil.Cil.ISymbolReader.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504748470280 (0x1000000008710008);
            label_13:
            // 0x00E59408: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E5940C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.Mono.Cecil.Cil.ISymbolReader))
            // 0x00E59410: B.EQ #0xe59434             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_12;
            // 0x00E59414: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x00E59418: ADD x10, x10, #0x10        | X10 = (1152921504748470280 + 16) = 1152921504748470296 (0x1000000008710018);
            // 0x00E5941C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.Mono.Cecil.Cil.ISymbolReader.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E59420: B.LO #0xe59408             | if (0 < ILRuntime.Mono.Cecil.Cil.ISymbolReader.__il2cppRuntimeField_interface_offsets_count) goto label_13;
            label_11:
            // 0x00E59424: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            val_8 = 1;
            // 0x00E59428: MOV x0, x20                | X0 = this.reader.module.symbol_reader;//m1
            val_9 = this.reader.module.symbol_reader;
            // 0x00E5942C: BL #0x2776c24              | X0 = sub_2776C24( ?? this.reader.module.symbol_reader, ????);
            // 0x00E59430: B #0xe59444                |  goto label_14;                         
            goto label_14;
            label_12:
            // 0x00E59434: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E59438: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00E5943C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504748433408 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00E59440: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504748433408 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_14:
            // 0x00E59444: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);  //  | 
            // 0x00E59448: MOV x0, x20                | X0 = this.reader.module.symbol_reader;//m1
            // 0x00E5944C: MOV x1, x21                | X1 = this.method;//m1                   
            // 0x00E59450: BLR x8                     | X0 = sub_10000000084F2000( ?? this.reader.module.symbol_reader, ????);
            // 0x00E59454: MOV x20, x0                | X20 = this.reader.module.symbol_reader;//m1
            // 0x00E59458: CBNZ x21, #0xe59460        | if (this.method != null) goto label_15; 
            if(val_7 != null)
            {
                goto label_15;
            }
            // 0x00E5945C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.reader.module.symbol_reader, ????);
            label_15:
            // 0x00E59460: STR x20, [x21, #0x90]      | this.method.debug_info = this.reader.module.symbol_reader;  //  dest_result_addr=0
            this.method.debug_info = this.reader.module.symbol_reader;
            label_10:
            // 0x00E59464: LDR x20, [x19, #0x50]      | X20 = this.method; //P2                 
            // 0x00E59468: CBNZ x20, #0xe59470        | if (this.method != null) goto label_16; 
            if(this.method != null)
            {
                goto label_16;
            }
            // 0x00E5946C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.reader.module.symbol_reader, ????);
            label_16:
            // 0x00E59470: LDR x8, [x20, #0x90]       | X8 = this.method.debug_info; //P2       
            // 0x00E59474: CBZ x8, #0xe5948c          | if (this.method.debug_info == null) goto label_17;
            if(this.method.debug_info == null)
            {
                goto label_17;
            }
            // 0x00E59478: MOV x0, x19                | X0 = 1152921509574827040 (0x10000001281D5C20);//ML01
            // 0x00E5947C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59480: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E59484: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E59488: B #0xe597dc                | this.ReadDebugInfo(); return;           
            this.ReadDebugInfo();
            return;
            label_17:
            // 0x00E5948C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59490: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E59494: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E59498: RET                        |  return;                                
            return;
            label_2:
            // 0x00E5949C: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00E594A0: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x00E594A4: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_5 = null;
            // 0x00E594A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x00E594AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E594B0: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00E594B4: BL #0x1e66414              | .ctor();                                
            val_5 = new System.InvalidOperationException();
            // 0x00E594B8: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E594BC: LDR x8, [x8, #0xd90]       | X8 = 1152921509574802016;               
            // 0x00E594C0: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00E594C4: LDR x1, [x8]               | X1 = System.Void ILRuntime.Mono.Cecil.Cil.CodeReader::ReadMethodBody();
            // 0x00E594C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x00E594CC: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.InvalidOperationException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5969C (15046300), len: 320  VirtAddr: 0x00E5969C RVA: 0x00E5969C token: 100664616 methodIndex: 19368 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadFatMethod()
        {
            //
            // Disasemble & Code
            // 0x00E5969C: STP x22, x21, [sp, #-0x30]! | stack[1152921509574996624] = ???;  stack[1152921509574996632] = ???;  //  dest_result_addr=1152921509574996624 |  dest_result_addr=1152921509574996632
            // 0x00E596A0: STP x20, x19, [sp, #0x10]  | stack[1152921509574996640] = ???;  stack[1152921509574996648] = ???;  //  dest_result_addr=1152921509574996640 |  dest_result_addr=1152921509574996648
            // 0x00E596A4: STP x29, x30, [sp, #0x20]  | stack[1152921509574996656] = ???;  stack[1152921509574996664] = ???;  //  dest_result_addr=1152921509574996656 |  dest_result_addr=1152921509574996664
            // 0x00E596A8: ADD x29, sp, #0x20         | X29 = (1152921509574996624 + 32) = 1152921509574996656 (0x10000001281FF2B0);
            // 0x00E596AC: SUB sp, sp, #0x10          | SP = (1152921509574996624 - 16) = 1152921509574996608 (0x10000001281FF280);
            // 0x00E596B0: MOV x19, x0                | X19 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E596B4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E596B8: LDR x9, [x8, #0x290]       | X9 = public System.UInt16 System.IO.BinaryReader::ReadUInt16();
            // 0x00E596BC: LDR x1, [x8, #0x298]       | X1 = public System.UInt16 System.IO.BinaryReader::ReadUInt16();
            // 0x00E596C0: BLR x9                     | X0 = this.ReadUInt16();                 
            ushort val_1 = this.ReadUInt16();
            // 0x00E596C4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E596C8: LDR x22, [x19, #0x58]      | X22 = this.body; //P2                   
            // 0x00E596CC: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x00E596D0: MOV x0, x19                | X0 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E596D4: LDR x9, [x8, #0x290]       | X9 = public System.UInt16 System.IO.BinaryReader::ReadUInt16();
            // 0x00E596D8: LDR x1, [x8, #0x298]       | X1 = public System.UInt16 System.IO.BinaryReader::ReadUInt16();
            // 0x00E596DC: BLR x9                     | X0 = this.ReadUInt16();                 
            ushort val_2 = this.ReadUInt16();
            // 0x00E596E0: MOV w21, w0                | W21 = val_2;//m1                        
            // 0x00E596E4: CBNZ x22, #0xe596ec        | if (this.body != null) goto label_0;    
            if(this.body != null)
            {
                goto label_0;
            }
            // 0x00E596E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_0:
            // 0x00E596EC: AND w8, w21, #0xffff       | W8 = (val_2 & 65535);                   
            ushort val_3 = val_2 & 65535;
            // 0x00E596F0: STR w8, [x22, #0x20]       | this.body.max_stack_size = (val_2 & 65535);  //  dest_result_addr=0
            this.body.max_stack_size = val_3;
            // 0x00E596F4: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E596F8: LDR x22, [x19, #0x58]      | X22 = this.body; //P2                   
            // 0x00E596FC: MOV x0, x19                | X0 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E59700: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E59704: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E59708: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_4 = this.ReadUInt32();
            // 0x00E5970C: MOV w21, w0                | W21 = val_4;//m1                        
            // 0x00E59710: CBNZ x22, #0xe59718        | if (this.body != null) goto label_1;    
            if(this.body != null)
            {
                goto label_1;
            }
            // 0x00E59714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_1:
            // 0x00E59718: STR w21, [x22, #0x24]      | this.body.code_size = val_4;             //  dest_result_addr=0
            this.body.code_size = val_4;
            // 0x00E5971C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E59720: LDR x21, [x19, #0x58]      | X21 = this.body; //P2                   
            // 0x00E59724: MOV x0, x19                | X0 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E59728: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E5972C: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E59730: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_5 = this.ReadUInt32();
            // 0x00E59734: MOV w1, w0                 | W1 = val_5;//m1                         
            // 0x00E59738: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5973C: ADD x0, sp, #8             | X0 = (1152921509574996608 + 8) = 1152921509574996616 (0x10000001281FF288);
            // 0x00E59740: STR wzr, [sp, #8]          | stack[1152921509574996616] = 0x0;        //  dest_result_addr=1152921509574996616
            // 0x00E59744: BL #0x11d58d4              | null..ctor(value:  val_5);              
            ProtoBuf.SubItemToken val_6 = new ProtoBuf.SubItemToken(value:  val_5);
            // 0x00E59748: CBNZ x21, #0xe59750        | if (this.body != null) goto label_2;    
            if(this.body != null)
            {
                goto label_2;
            }
            // 0x00E5974C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(value:  val_5), ????);
            label_2:
            // 0x00E59750: LDR w8, [sp, #8]           | W8 = val_6.value;                       
            // 0x00E59754: STR w8, [x21, #0x2c]       | this.body.local_var_token = val_6.value;  //  dest_result_addr=0
            this.body.local_var_token = val_6.value;
            // 0x00E59758: LDR x22, [x19, #0x58]      | X22 = this.body; //P2                   
            // 0x00E5975C: CBNZ x22, #0xe59764        | if (this.body != null) goto label_3;    
            if(this.body != null)
            {
                goto label_3;
            }
            // 0x00E59760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(value:  val_5), ????);
            label_3:
            // 0x00E59764: AND w21, w20, #0xffff      | W21 = (val_1 & 65535);                  
            ushort val_7 = val_1 & 65535;
            // 0x00E59768: UBFX w8, w21, #4, #1       | W8 = (uint)(((val_1 & 65535)>>4) & 0x1);
            // 0x00E5976C: STRB w8, [x22, #0x28]      | this.body.init_locals = (uint)(((val_1 & 65535)>>4) & 0x1);  //  dest_result_addr=0
            this.body.init_locals = (uint)(val_7 >> 4) & 1;
            // 0x00E59770: LDR x20, [x19, #0x58]      | X20 = this.body; //P2                   
            // 0x00E59774: CBNZ x20, #0xe5977c        | if (this.body != null) goto label_4;    
            if(this.body != null)
            {
                goto label_4;
            }
            // 0x00E59778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(value:  val_5), ????);
            label_4:
            // 0x00E5977C: ADD x0, x20, #0x2c         | X0 = this.body.local_var_token;//AP2 res_addr=43
            // 0x00E59780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59784: BL #0x11d4138              | X0 = label_ILRuntime_Mono_Cecil_MetadataSystem_AddTypeDefinition_GL011D4138();
            // 0x00E59788: CBZ w0, #0xe597b4          | if (this.body.local_var_token == 0) goto label_5;
            if(this.body.local_var_token == 0)
            {
                goto label_5;
            }
            // 0x00E5978C: LDR x22, [x19, #0x58]      | X22 = this.body; //P2                   
            // 0x00E59790: CBNZ x22, #0xe59798        | if (this.body != null) goto label_6;    
            if(this.body != null)
            {
                goto label_6;
            }
            // 0x00E59794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.body.local_var_token, ????);
            label_6:
            // 0x00E59798: LDR w1, [x22, #0x2c]       | W1 = this.body.local_var_token; //P2    
            // 0x00E5979C: MOV x0, x19                | X0 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E597A0: BL #0xe5988c               | X0 = this.ReadVariables(local_var_token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = this.body.local_var_token});
            ILRuntime.Mono.Cecil.Cil.VariableDefinitionCollection val_8 = this.ReadVariables(local_var_token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = this.body.local_var_token});
            // 0x00E597A4: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00E597A8: CBNZ x22, #0xe597b0        | if (this.body != null) goto label_7;    
            if(this.body != null)
            {
                goto label_7;
            }
            // 0x00E597AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_7:
            // 0x00E597B0: STR x20, [x22, #0x40]      | this.body.variables = val_8;             //  dest_result_addr=0
            this.body.variables = val_8;
            label_5:
            // 0x00E597B4: MOV x0, x19                | X0 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E597B8: BL #0xe594d8               | this.ReadCode();                        
            this.ReadCode();
            // 0x00E597BC: TBZ w21, #3, #0xe597c8     | if (((val_1 & 65535) & 0x8) == 0) goto label_8;
            if((val_7 & 8) == 0)
            {
                goto label_8;
            }
            // 0x00E597C0: MOV x0, x19                | X0 = 1152921509575008672 (0x10000001282021A0);//ML01
            // 0x00E597C4: BL #0xe59908               | this.ReadSection();                     
            this.ReadSection();
            label_8:
            // 0x00E597C8: SUB sp, x29, #0x20         | SP = (1152921509574996656 - 32) = 1152921509574996624 (0x10000001281FF290);
            // 0x00E597CC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E597D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E597D4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E597D8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5988C (15046796), len: 124  VirtAddr: 0x00E5988C RVA: 0x00E5988C token: 100664617 methodIndex: 19369 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.Cil.VariableDefinitionCollection ReadVariables(ILRuntime.Mono.Cecil.MetadataToken local_var_token)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Cecil.MetadataReader val_2;
            //  | 
            var val_3;
            // 0x00E5988C: STP x22, x21, [sp, #-0x30]! | stack[1152921509575153680] = ???;  stack[1152921509575153688] = ???;  //  dest_result_addr=1152921509575153680 |  dest_result_addr=1152921509575153688
            // 0x00E59890: STP x20, x19, [sp, #0x10]  | stack[1152921509575153696] = ???;  stack[1152921509575153704] = ???;  //  dest_result_addr=1152921509575153696 |  dest_result_addr=1152921509575153704
            // 0x00E59894: STP x29, x30, [sp, #0x20]  | stack[1152921509575153712] = ???;  stack[1152921509575153720] = ???;  //  dest_result_addr=1152921509575153712 |  dest_result_addr=1152921509575153720
            // 0x00E59898: ADD x29, sp, #0x20         | X29 = (1152921509575153680 + 32) = 1152921509575153712 (0x1000000128225830);
            // 0x00E5989C: MOV x19, x0                | X19 = 1152921509575165728 (0x1000000128228720);//ML01
            // 0x00E598A0: LDR x21, [x19, #0x40]      | X21 = this.reader; //P2                 
            val_2 = this.reader;
            // 0x00E598A4: MOV x20, x1                | X20 = local_var_token.token;//m1        
            // 0x00E598A8: CBZ x21, #0xe598b4         | if (this.reader == null) goto label_0;  
            if(val_2 == null)
            {
                goto label_0;
            }
            // 0x00E598AC: LDR w22, [x21, #0x1c]      | 
            // 0x00E598B0: B #0xe598d4                |  goto label_3;                          
            goto label_3;
            label_0:
            // 0x00E598B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00E598B8: LDR x8, [x19, #0x40]       | X8 = this.reader; //P2                  
            // 0x00E598BC: LDR w22, [x21, #0x1c]      | 
            // 0x00E598C0: CBZ x8, #0xe598cc          | if (this.reader == null) goto label_2;  
            if(this.reader == null)
            {
                goto label_2;
            }
            // 0x00E598C4: MOV x21, x8                | X21 = this.reader;//m1                  
            val_2 = this.reader;
            // 0x00E598C8: B #0xe598d4                |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x00E598CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00E598D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_2 = 0;
            label_3:
            // 0x00E598D4: AND x1, x20, #0xffffffff   | X1 = (local_var_token.token & 4294967295);
            local_var_token.token = local_var_token.token & 4294967295;
            // 0x00E598D8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00E598DC: BL #0xe59964               | X0 = val_2.ReadVariables(local_var_token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = local_var_token.token});
            ILRuntime.Mono.Cecil.Cil.VariableDefinitionCollection val_1 = val_2.ReadVariables(local_var_token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = local_var_token.token});
            // 0x00E598E0: LDR x20, [x19, #0x40]      | X20 = this.reader; //P2                 
            // 0x00E598E4: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E598E8: CBNZ x20, #0xe598f0        | if (this.reader != null) goto label_4;  
            if(this.reader != null)
            {
                goto label_4;
            }
            // 0x00E598EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00E598F0: STR w22, [x20, #0x1c]      | mem2[0] = ???;                           //  dest_result_addr=0
            mem2[0] = ???;
            // 0x00E598F4: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00E598F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E598FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E59900: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E59904: RET                        |  return (ILRuntime.Mono.Cecil.Cil.VariableDefinitionCollection)val_1;
            return (ILRuntime.Mono.Cecil.Cil.VariableDefinitionCollection)val_1;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.Cil.VariableDefinitionCollection, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E594D8 (15045848), len: 452  VirtAddr: 0x00E594D8 RVA: 0x00E594D8 token: 100664618 methodIndex: 19370 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadCode()
        {
            //
            // Disasemble & Code
            //  | 
            int val_16;
            //  | 
            ILRuntime.Mono.Cecil.MethodDefinition val_17;
            //  | 
            ILRuntime.Mono.Cecil.Cil.MethodBody val_18;
            // 0x00E594D8: STP x28, x27, [sp, #-0x60]! | stack[1152921509575299424] = ???;  stack[1152921509575299432] = ???;  //  dest_result_addr=1152921509575299424 |  dest_result_addr=1152921509575299432
            // 0x00E594DC: STP x26, x25, [sp, #0x10]  | stack[1152921509575299440] = ???;  stack[1152921509575299448] = ???;  //  dest_result_addr=1152921509575299440 |  dest_result_addr=1152921509575299448
            // 0x00E594E0: STP x24, x23, [sp, #0x20]  | stack[1152921509575299456] = ???;  stack[1152921509575299464] = ???;  //  dest_result_addr=1152921509575299456 |  dest_result_addr=1152921509575299464
            // 0x00E594E4: STP x22, x21, [sp, #0x30]  | stack[1152921509575299472] = ???;  stack[1152921509575299480] = ???;  //  dest_result_addr=1152921509575299472 |  dest_result_addr=1152921509575299480
            // 0x00E594E8: STP x20, x19, [sp, #0x40]  | stack[1152921509575299488] = ???;  stack[1152921509575299496] = ???;  //  dest_result_addr=1152921509575299488 |  dest_result_addr=1152921509575299496
            // 0x00E594EC: STP x29, x30, [sp, #0x50]  | stack[1152921509575299504] = ???;  stack[1152921509575299512] = ???;  //  dest_result_addr=1152921509575299504 |  dest_result_addr=1152921509575299512
            // 0x00E594F0: ADD x29, sp, #0x50         | X29 = (1152921509575299424 + 80) = 1152921509575299504 (0x10000001282491B0);
            // 0x00E594F4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E594F8: LDRB w8, [x20, #0xadd]     | W8 = (bool)static_value_03734ADD;       
            // 0x00E594FC: MOV x19, x0                | X19 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E59500: TBNZ w8, #0, #0xe5951c     | if (static_value_03734ADD == true) goto label_0;
            // 0x00E59504: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00E59508: LDR x8, [x8, #0xf68]       | X8 = 0x2B90DA0;                         
            // 0x00E5950C: LDR w0, [x8]               | W0 = 0x1A2C;                            
            // 0x00E59510: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2C, ????);     
            // 0x00E59514: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E59518: STRB w8, [x20, #0xadd]     | static_value_03734ADD = true;            //  dest_result_addr=57887453
            label_0:
            // 0x00E5951C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59520: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E59524: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_1 = this.Position;
            // 0x00E59528: LDR x20, [x19, #0x58]      | X20 = this.body; //P2                   
            // 0x00E5952C: STR w0, [x19, #0x48]       | this.start = val_1;                      //  dest_result_addr=1152921509575311592
            this.start = val_1;
            // 0x00E59530: CBNZ x20, #0xe59538        | if (this.body != null) goto label_1;    
            if(this.body != null)
            {
                goto label_1;
            }
            // 0x00E59534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00E59538: LDR w22, [x20, #0x24]      | W22 = this.body.code_size; //P2         
            val_16 = this.body.code_size;
            // 0x00E5953C: TBNZ w22, #0x1f, #0xe5956c | if ((this.body.code_size & 0x80000000) != 0) goto label_2;
            if((val_16 & 2147483648) != 0)
            {
                goto label_2;
            }
            // 0x00E59540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59544: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E59548: BL #0x11e0678              | X0 = this.get_Length();                 
            int val_2 = this.Length;
            // 0x00E5954C: MOV w20, w0                | W20 = val_2;//m1                        
            // 0x00E59550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59554: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E59558: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_3 = this.Position;
            // 0x00E5955C: SXTW x8, w20               | X8 = (long)(int)(val_2);                
            // 0x00E59560: ADD w9, w0, w22            | W9 = (val_3 + this.body.code_size);     
            int val_4 = val_3 + val_16;
            // 0x00E59564: CMP x8, w9, uxtw           | STATE = COMPARE((long)(int)(val_2), (val_3 + this.body.code_size))
            // 0x00E59568: B.GT #0xe59570             | if ((long)val_2 > val_4) goto label_3;  
            if((long)val_2 > val_4)
            {
                goto label_3;
            }
            label_2:
            // 0x00E5956C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_3:
            // 0x00E59570: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00E59574: LDR w8, [x19, #0x48]       | W8 = this.start; //P2                   
            // 0x00E59578: LDR x9, [x9, #0x978]       | X9 = 1152921504746622976;               
            // 0x00E5957C: LDP x21, x23, [x19, #0x50] | X21 = this.method; //P2  X23 = this.body; //P2  //  | 
            val_17 = this.method;
            val_18 = this.body;
            // 0x00E59580: ADD w24, w8, w22           | W24 = (this.start + val_16);            
            int val_5 = this.start + val_16;
            // 0x00E59584: LDR x0, [x9]               | X0 = typeof(ILRuntime.Mono.Cecil.Cil.InstructionCollection);
            ILRuntime.Mono.Cecil.Cil.InstructionCollection val_10 = null;
            // 0x00E59588: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.Cil.InstructionCollection), ????);
            // 0x00E5958C: ADD w8, w22, #1            | W8 = (val_16 + 1);                      
            var val_6 = val_16 + 1;
            // 0x00E59590: MOV x20, x0                | X20 = 1152921504746622976 (0x100000000854D000);//ML01
            // 0x00E59594: ADD w9, w22, #2            | W9 = (val_16 + 2);                      
            var val_7 = val_16 + 2;
            // 0x00E59598: CMP w8, #0                 | STATE = COMPARE((val_16 + 1), 0x0)      
            // 0x00E5959C: CSINC w8, w9, w22, lt      | W8 = val_6 < 0x0 ? (val_16 + 2) : (val_16 + 1);
            var val_8 = (val_6 < 0) ? (val_7) : (val_16 + 1);
            // 0x00E595A0: ASR w2, w8, #1             | W2 = (val_6 < 0x0 ? (val_16 + 2) : (val_16 + 1) >> 1);
            int val_9 = val_8 >> 1;
            // 0x00E595A4: MOV x1, x21                | X1 = this.method;//m1                   
            // 0x00E595A8: BL #0xe59b1c               | .ctor(method:  val_17, capacity:  int val_9 = val_8 >> 1);
            val_10 = new ILRuntime.Mono.Cecil.Cil.InstructionCollection(method:  val_17, capacity:  val_9);
            // 0x00E595AC: CBNZ x23, #0xe595b4        | if (this.body != null) goto label_4;    
            if(val_18 != null)
            {
                goto label_4;
            }
            // 0x00E595B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(method:  val_17, capacity:  int val_9 = val_8 >> 1), ????);
            label_4:
            // 0x00E595B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E595B8: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E595BC: STR x20, [x23, #0x30]      | this.body.instructions = typeof(ILRuntime.Mono.Cecil.Cil.InstructionCollection);  //  dest_result_addr=0
            this.body.instructions = val_10;
            // 0x00E595C0: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_11 = this.Position;
            // 0x00E595C4: CMP w0, w24                | STATE = COMPARE(val_11, (this.start + val_16))
            // 0x00E595C8: B.GE #0xe59678             | if (val_11 >= val_5) goto label_5;      
            if(val_11 >= val_5)
            {
                goto label_5;
            }
            // 0x00E595CC: ADRP x25, #0x35c9000       | X25 = 56397824 (0x35C9000);             
            // 0x00E595D0: ADRP x27, #0x35bf000       | X27 = 56356864 (0x35BF000);             
            // 0x00E595D4: LDR x25, [x25, #0xf68]     | X25 = 1152921504746463232;              
            // 0x00E595D8: LDR x27, [x27, #0xe58]     | X27 = 1152921509575282400;              
            // 0x00E595DC: MOVZ x26, #0x500, lsl #32  | X26 = 5497558138880 (0x50000000000);//ML01
            label_9:
            // 0x00E595E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E595E4: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E595E8: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_12 = this.Position;
            // 0x00E595EC: LDR w28, [x19, #0x48]      | W28 = this.start; //P2                  
            // 0x00E595F0: MOV w22, w0                | W22 = val_12;//m1                       
            int val_18 = val_12;
            // 0x00E595F4: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E595F8: BL #0xe59b88               | X0 = this.ReadOpCode();                 
            ILRuntime.Mono.Cecil.Cil.OpCode val_13 = this.ReadOpCode();
            // 0x00E595FC: LDR x8, [x25]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.Instruction);
            // 0x00E59600: MOV x23, x0                | X23 = val_13.op1;//m1                   
            val_18 = val_13.op1;
            // 0x00E59604: MOV x0, x8                 | X0 = 1152921504746463232 (0x1000000008526000);//ML01
            object val_14 = null;
            // 0x00E59608: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.Cil.Instruction), ????);
            // 0x00E5960C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59610: MOV x21, x0                | X21 = 1152921504746463232 (0x1000000008526000);//ML01
            val_17 = val_14;
            // 0x00E59614: SUB w22, w22, w28          | W22 = (val_12 - this.start);            
            val_18 = val_18 - this.start;
            // 0x00E59618: BL #0x16f59f0              | .ctor();                                
            val_14 = new System.Object();
            // 0x00E5961C: AND x8, x23, #0xff0000000000 | X8 = (val_13.op1 & 280375465082880);    
            byte val_15 = val_18 & 280375465082880;
            // 0x00E59620: STR w22, [x21, #0x10]      | typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_10 = (val_12 - this.start);  //  dest_result_addr=1152921504746463248
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_10 = val_18;
            // 0x00E59624: STUR x23, [x21, #0x14]     | typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_14 = val_13.op1; typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_15 = val_13.op2; typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_16 = val_13.code; typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_17 = val_13.flow_control; typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_18 = val_13.opcode_type; typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_1 //  dest_result_addr=1152921504746463252 dest_result_addr=1152921504746463253 dest_result_addr=1152921504746463254 dest_result_addr=1152921504746463255 dest_result_addr=1152921504746463256 dest_result_addr=1152921504746463257 dest_result_addr=1152921504746463258 dest_result_addr=1152921504746463259
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_14 = val_18;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_15 = val_13.op2;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_16 = val_13.code;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_17 = val_13.flow_control;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_18 = val_13.opcode_type;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_19 = val_13.operand_type;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_1A = val_13.stack_behavior_pop;
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_1B = val_13.stack_behavior_push;
            // 0x00E59628: CMP x8, x26                | STATE = COMPARE((val_13.op1 & 280375465082880), 0x50000000000)
            // 0x00E5962C: B.EQ #0xe5964c             | if (val_15 == 0) goto label_6;          
            if(val_15 == 0)
            {
                goto label_6;
            }
            // 0x00E59630: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E59634: MOV x1, x21                | X1 = 1152921504746463232 (0x1000000008526000);//ML01
            // 0x00E59638: BL #0xe59cf0               | X0 = this.ReadOperand(instruction:  val_17);
            object val_16 = this.ReadOperand(instruction:  val_17);
            // 0x00E5963C: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x00E59640: CBNZ x21, #0xe59648        | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x00E59644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_7:
            // 0x00E59648: STR x22, [x21, #0x20]      | typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_20 = val_16;  //  dest_result_addr=1152921504746463264
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction).__il2cppRuntimeField_20 = val_16;
            label_6:
            // 0x00E5964C: CBNZ x20, #0xe59654        | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x00E59650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_8:
            // 0x00E59654: LDR x2, [x27]              | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.Instruction>::Add(ILRuntime.Mono.Cecil.Cil.Instruction item);
            // 0x00E59658: MOV x0, x20                | X0 = 1152921504746622976 (0x100000000854D000);//ML01
            // 0x00E5965C: MOV x1, x21                | X1 = 1152921504746463232 (0x1000000008526000);//ML01
            // 0x00E59660: BL #0x1d47324              | Add(item:  val_17);                     
            Add(item:  val_17);
            // 0x00E59664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59668: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E5966C: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_17 = this.Position;
            // 0x00E59670: CMP w0, w24                | STATE = COMPARE(val_17, (this.start + val_16))
            // 0x00E59674: B.LT #0xe595e0             | if (val_17 < val_5) goto label_9;       
            if(val_17 < val_5)
            {
                goto label_9;
            }
            label_5:
            // 0x00E59678: MOV x0, x19                | X0 = 1152921509575311520 (0x100000012824C0A0);//ML01
            // 0x00E5967C: MOV x1, x20                | X1 = 1152921504746622976 (0x100000000854D000);//ML01
            // 0x00E59680: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59684: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E59688: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5968C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E59690: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E59694: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E59698: B #0xe5a174                | this.ResolveBranches(instructions:  val_10); return;
            this.ResolveBranches(instructions:  val_10);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59B88 (15047560), len: 300  VirtAddr: 0x00E59B88 RVA: 0x00E59B88 token: 100664619 methodIndex: 19371 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.Cil.OpCode ReadOpCode()
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            ILRuntime.Mono.Cecil.Cil.OpCode[] val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00E59B88: STP x22, x21, [sp, #-0x30]! | stack[1152921509575427856] = ???;  stack[1152921509575427864] = ???;  //  dest_result_addr=1152921509575427856 |  dest_result_addr=1152921509575427864
            // 0x00E59B8C: STP x20, x19, [sp, #0x10]  | stack[1152921509575427872] = ???;  stack[1152921509575427880] = ???;  //  dest_result_addr=1152921509575427872 |  dest_result_addr=1152921509575427880
            // 0x00E59B90: STP x29, x30, [sp, #0x20]  | stack[1152921509575427888] = ???;  stack[1152921509575427896] = ???;  //  dest_result_addr=1152921509575427888 |  dest_result_addr=1152921509575427896
            // 0x00E59B94: ADD x29, sp, #0x20         | X29 = (1152921509575427856 + 32) = 1152921509575427888 (0x1000000128268730);
            // 0x00E59B98: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E59B9C: LDRB w8, [x20, #0xade]     | W8 = (bool)static_value_03734ADE;       
            // 0x00E59BA0: MOV x19, x0                | X19 = 1152921509575439904 (0x100000012826B620);//ML01
            // 0x00E59BA4: TBNZ w8, #0, #0xe59bc0     | if (static_value_03734ADE == true) goto label_0;
            // 0x00E59BA8: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00E59BAC: LDR x8, [x8, #0x280]       | X8 = 0x2B90DBC;                         
            // 0x00E59BB0: LDR w0, [x8]               | W0 = 0x1A33;                            
            // 0x00E59BB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A33, ????);     
            // 0x00E59BB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E59BBC: STRB w8, [x20, #0xade]     | static_value_03734ADE = true;            //  dest_result_addr=57887454
            label_0:
            // 0x00E59BC0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E59BC4: MOV x0, x19                | X0 = 1152921509575439904 (0x100000012826B620);//ML01
            // 0x00E59BC8: LDP x9, x1, [x8, #0x1e0]   | X9 = public System.Byte System.IO.BinaryReader::ReadByte(); X1 = public System.Byte System.IO.BinaryReader::ReadByte(); //  | 
            // 0x00E59BCC: BLR x9                     | X0 = this.ReadByte();                   
            byte val_1 = this.ReadByte();
            // 0x00E59BD0: ADRP x21, #0x35f6000       | X21 = 56582144 (0x35F6000);             
            // 0x00E59BD4: LDR x21, [x21, #0xf38]     | X21 = 1152921504746835968;              
            // 0x00E59BD8: MOV w20, w0                | W20 = val_1;//m1                        
            var val_6 = val_1;
            // 0x00E59BDC: AND w9, w20, #0xff         | W9 = (val_1 & 255);                     
            byte val_2 = val_6 & 255;
            // 0x00E59BE0: CMP w9, #0xfe              | STATE = COMPARE((val_1 & 255), 0xFE)    
            // 0x00E59BE4: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.OpCodes);
            val_8 = null;
            // 0x00E59BE8: ADD x8, x0, #0x109         | X8 = (val_8 + 265) = 1152921504746836233 (0x1000000008581109);
            // 0x00E59BEC: LDRH w8, [x8]              | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_109;
            // 0x00E59BF0: AND w8, w8, #0x100         | W8 = (ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_109 & 256);
            // 0x00E59BF4: AND w8, w8, #0xffff        | W8 = ((ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00E59BF8: B.NE #0xe59c58             | if (val_2 != 254) goto label_1;         
            if(val_2 != 254)
            {
                goto label_1;
            }
            // 0x00E59BFC: CBZ w8, #0xe59c10          | if (((ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_3;
            // 0x00E59C00: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_cctor_finished;
            // 0x00E59C04: CBNZ w8, #0xe59c10         | if (ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E59C08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Cil.OpCodes), ????);
            // 0x00E59C0C: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.OpCodes);
            val_9 = null;
            label_3:
            // 0x00E59C10: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_static_fields;
            // 0x00E59C14: LDR x9, [x19]              | X9 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E59C18: MOV x0, x19                | X0 = 1152921509575439904 (0x100000012826B620);//ML01
            // 0x00E59C1C: LDR x20, [x8, #8]          | X20 = ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode;
            // 0x00E59C20: LDP x8, x1, [x9, #0x1e0]   | X8 = public System.Byte System.IO.BinaryReader::ReadByte(); X1 = public System.Byte System.IO.BinaryReader::ReadByte(); //  | 
            // 0x00E59C24: BLR x8                     | X0 = this.ReadByte();                   
            byte val_5 = this.ReadByte();
            // 0x00E59C28: MOV w19, w0                | W19 = val_5;//m1                        
            // 0x00E59C2C: CBNZ x20, #0xe59c34        | if (ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode != null) goto label_4;
            if(ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode != null)
            {
                goto label_4;
            }
            // 0x00E59C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x00E59C34: LDR w8, [x20, #0x18]       | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode.Length;
            // 0x00E59C38: AND w19, w19, #0xff        | W19 = (val_5 & 255);                    
            val_10 = val_5 & 255;
            // 0x00E59C3C: CMP w19, w8                | STATE = COMPARE((val_5 & 255), ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode.Length)
            // 0x00E59C40: B.LO #0xe59c50             | if (val_10 < ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode.Length) goto label_5;
            if(val_10 < ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode.Length)
            {
                goto label_5;
            }
            // 0x00E59C44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00E59C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59C4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_5:
            // 0x00E59C50: ADD x8, x20, x19, lsl #3   | X8 = (ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode + ((val_5 & 255)) << 3);
            val_11 = ILRuntime.Mono.Cecil.Cil.OpCodes.TwoBytesOpCode + (((val_5 & 255)) << 3);
            // 0x00E59C54: B #0xe59c9c                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00E59C58: CBZ w8, #0xe59c6c          | if (((ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_8;
            // 0x00E59C5C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_cctor_finished;
            // 0x00E59C60: CBNZ w8, #0xe59c6c         | if (ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E59C64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Cil.OpCodes), ????);
            // 0x00E59C68: LDR x0, [x21]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.OpCodes);
            val_12 = null;
            label_8:
            // 0x00E59C6C: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_static_fields;
            // 0x00E59C70: LDR x19, [x8]              | X19 = ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode;
            val_10 = ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode;
            // 0x00E59C74: CBNZ x19, #0xe59c7c        | if (ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode != null) goto label_9;
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x00E59C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Cecil.Cil.OpCodes), ????);
            label_9:
            // 0x00E59C7C: LDR w8, [x19, #0x18]       | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode.Length;
            // 0x00E59C80: AND w20, w20, #0xff        | W20 = (val_1 & 255);                    
            val_6 = val_6 & 255;
            // 0x00E59C84: CMP w20, w8                | STATE = COMPARE((val_1 & 255), ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode.Length)
            // 0x00E59C88: B.LO #0xe59c98             | if (val_1 < ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode.Length) goto label_10;
            if(val_6 < ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode.Length)
            {
                goto label_10;
            }
            // 0x00E59C8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ILRuntime.Mono.Cecil.Cil.OpCodes), ????);
            // 0x00E59C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59C94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ILRuntime.Mono.Cecil.Cil.OpCodes), ????);
            label_10:
            // 0x00E59C98: ADD x8, x19, x20, lsl #3   | X8 = (ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode + ((val_1 & 255)) << 3);
            val_11 = val_10 + (((val_1 & 255)) << 3);
            label_6:
            // 0x00E59C9C: ADD x8, x8, #0x20          |  //  not_find_field:ILRuntime.Mono.Cecil.Cil.OpCodes.OneByteOpCode.32
            // 0x00E59CA0: LDR x0, [x8]               | X0 =  typeof(ILRuntime.Mono.Cecil.Cil.OpCode[]);
            // 0x00E59CA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59CA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E59CAC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E59CB0: RET                        |  return new ILRuntime.Mono.Cecil.Cil.OpCode() {op1 = 240, op2 = 213, code = 53, flow_control = 91, stack_behavior_push = 16};
            return new ILRuntime.Mono.Cecil.Cil.OpCode() {op1 = 240, op2 = 213, code = 53, flow_control = 91, stack_behavior_push = 16};
            //  |  // // {name=val_0.op1, type=System.Byte, size=1, nGRN=0 offset=0 }
            //  |  // // {name=val_0.op2, type=System.Byte, size=1, nGRN=0 offset=1 }
            //  |  // // {name=val_0.code, type=System.Byte, size=1, nGRN=0 offset=2 }
            //  |  // // {name=val_0.flow_control, type=System.Byte, size=1, nGRN=0 offset=3 }
            //  |  // // {name=val_0.opcode_type, type=System.Byte, size=1, nGRN=0 offset=4 }
            //  |  // // {name=val_0.operand_type, type=System.Byte, size=1, nGRN=0 offset=5 }
            //  |  // // {name=val_0.stack_behavior_pop, type=System.Byte, size=1, nGRN=0 offset=6 }
            //  |  // // {name=val_0.stack_behavior_push, type=System.Byte, size=1, nGRN=0 offset=7 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59CF0 (15047920), len: 1156  VirtAddr: 0x00E59CF0 RVA: 0x00E59CF0 token: 100664620 methodIndex: 19372 delegateWrapperIndex: 0 methodInvoker: 0
        private object ReadOperand(ILRuntime.Mono.Cecil.Cil.Instruction instruction)
        {
            //
            // Disasemble & Code
            //  | 
            var val_23;
            //  | 
            int val_24;
            //  | 
            int val_25;
            //  | 
            int val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            int val_31;
            //  | 
            int val_32;
            //  | 
            var val_33;
            //  | 
            int val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            // 0x00E59CF0: STP x26, x25, [sp, #-0x50]! | stack[1152921509575573616] = ???;  stack[1152921509575573624] = ???;  //  dest_result_addr=1152921509575573616 |  dest_result_addr=1152921509575573624
            // 0x00E59CF4: STP x24, x23, [sp, #0x10]  | stack[1152921509575573632] = ???;  stack[1152921509575573640] = ???;  //  dest_result_addr=1152921509575573632 |  dest_result_addr=1152921509575573640
            // 0x00E59CF8: STP x22, x21, [sp, #0x20]  | stack[1152921509575573648] = ???;  stack[1152921509575573656] = ???;  //  dest_result_addr=1152921509575573648 |  dest_result_addr=1152921509575573656
            // 0x00E59CFC: STP x20, x19, [sp, #0x30]  | stack[1152921509575573664] = ???;  stack[1152921509575573672] = ???;  //  dest_result_addr=1152921509575573664 |  dest_result_addr=1152921509575573672
            // 0x00E59D00: STP x29, x30, [sp, #0x40]  | stack[1152921509575573680] = ???;  stack[1152921509575573688] = ???;  //  dest_result_addr=1152921509575573680 |  dest_result_addr=1152921509575573688
            // 0x00E59D04: ADD x29, sp, #0x40         | X29 = (1152921509575573616 + 64) = 1152921509575573680 (0x100000012828C0B0);
            // 0x00E59D08: SUB sp, sp, #0x10          | SP = (1152921509575573616 - 16) = 1152921509575573600 (0x100000012828C060);
            // 0x00E59D0C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E59D10: LDRB w8, [x20, #0xadf]     | W8 = (bool)static_value_03734ADF;       
            // 0x00E59D14: MOV x21, x1                | X21 = instruction;//m1                  
            val_24 = instruction;
            // 0x00E59D18: MOV x19, x0                | X19 = 1152921509575585696 (0x100000012828EFA0);//ML01
            val_25 = this;
            // 0x00E59D1C: TBNZ w8, #0, #0xe59d38     | if (static_value_03734ADF == true) goto label_0;
            // 0x00E59D20: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00E59D24: LDR x8, [x8, #0x428]       | X8 = 0x2B90DC0;                         
            // 0x00E59D28: LDR w0, [x8]               | W0 = 0x1A34;                            
            // 0x00E59D2C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A34, ????);     
            // 0x00E59D30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E59D34: STRB w8, [x20, #0xadf]     | static_value_03734ADF = true;            //  dest_result_addr=57887455
            label_0:
            // 0x00E59D38: CBNZ x21, #0xe59d40        | if (instruction != null) goto label_1;  
            if(val_24 != null)
            {
                goto label_1;
            }
            // 0x00E59D3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A34, ????);     
            label_1:
            // 0x00E59D40: LDRB w8, [x21, #0x19]      | 
            // 0x00E59D44: CMP x8, #0x13              | STATE = COMPARE(0x1, 0x13)              
            // 0x00E59D48: B.HI #0xe5a140             | if (true > 0x13) goto label_2;          
            if(true > 19)
            {
                goto label_2;
            }
            // 0x00E59D4C: ADRP x9, #0x2a98000        | X9 = 44662784 (0x2A98000);              
            // 0x00E59D50: ADD x9, x9, #0x6b0         | X9 = (44662784 + 1712) = 44664496 (0x02A986B0);
            // 0x00E59D54: LDR w8, [x9, x8, lsl #2]   | W8 = 0x4;                               
            // 0x00E59D58: CMP w8, #0x12              | STATE = COMPARE(0x4, 0x12)              
            // 0x00E59D5C: B.HI #0xe5a120             | if (4 > 0x12) goto label_16;            
            if(4 > 18)
            {
                goto label_16;
            }
            // 0x00E59D60: ADRP x9, #0x2a98000        | X9 = 44662784 (0x2A98000);              
            // 0x00E59D64: ADD x9, x9, #0x3b0         | X9 = (44662784 + 944) = 44663728 (0x02A983B0);
            // 0x00E59D68: LDRSW x8, [x9, x8, lsl #2] | X8 = 0xFFFFFFFFFE3C1A00;                
            // 0x00E59D6C: ADD x8, x8, x9             | X8 = (-29615616 + 44663728) = 15048112 (0x00E59DB0);
            // 0x00E59D70: BR x8                      | goto label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadOperand_GL00E59DB0;
            // 0x00E59D74: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E59D78: MOV x0, x19                | X0 = 1152921509575585696 (0x100000012828EFA0);//ML01
            // 0x00E59D7C: LDR x9, [x8, #0x240]       | X9 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E59D80: LDR x1, [x8, #0x248]       | X1 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E59D84: BLR x9                     | X0 = this.ReadInt32();                  
            int val_1 = this.ReadInt32();
            // 0x00E59D88: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x00E59D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59D90: MOV x0, x19                | X0 = 1152921509575585696 (0x100000012828EFA0);//ML01
            // 0x00E59D94: BL #0x11e05f0              | X0 = this.get_Position();               
            int val_2 = this.Position;
            // 0x00E59D98: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00E59D9C: LDR w9, [x19, #0x48]       | W9 = this.start; //P2                   
            val_26 = this.start;
            // 0x00E59DA0: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00E59DA4: ADD w10, w0, w20           | W10 = (val_2 + val_1);                  
            val_27 = val_2 + val_1;
            // 0x00E59DA8: LDR x8, [x8]               | X8 = typeof(System.Int32);              
            val_28 = null;
            // 0x00E59DAC: B #0xe5a00c                |  goto label_4;                          
            goto label_4;
            label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadOperand_GL00E59DB0:
            // 0x00E59DB0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E59DB4: LDR x20, [x19, #0x40]      | X20 = this.reader; //P2                 
            // 0x00E59DB8: MOV x0, x19                | X0 = 1152921509575585696 (0x100000012828EFA0);//ML01
            // 0x00E59DBC: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E59DC0: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E59DC4: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_3 = this.ReadUInt32();
            // 0x00E59DC8: MOV w1, w0                 | W1 = val_3;//m1                         
            // 0x00E59DCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E59DD0: ADD x0, sp, #8             | X0 = (1152921509575573600 + 8) = 1152921509575573608 (0x100000012828C068);
            // 0x00E59DD4: STR wzr, [sp, #8]          | stack[1152921509575573608] = 0x0;        //  dest_result_addr=1152921509575573608
            // 0x00E59DD8: BL #0x11d58d4              | null..ctor(value:  val_3);              
            ProtoBuf.SubItemToken val_4 = new ProtoBuf.SubItemToken(value:  val_3);
            // 0x00E59DDC: LDR w19, [sp, #8]          | W19 = val_4.value;                      
            val_25 = val_4.value;
            // 0x00E59DE0: CBNZ x20, #0xe59de8        | if (this.reader != null) goto label_5;  
            if(this.reader != null)
            {
                goto label_5;
            }
            // 0x00E59DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(value:  val_3), ????);
            label_5:
            // 0x00E59DE8: MOV x0, x20                | X0 = this.reader;//m1                   
            // 0x00E59DEC: MOV x1, x19                | X1 = val_4.value;//m1                   
            // 0x00E59DF0: BL #0xe5a60c               | X0 = this.reader.LookupToken(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_25});
            ILRuntime.Mono.Cecil.IMetadataTokenProvider val_5 = this.reader.LookupToken(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_25});
            // 0x00E59DF4: B #0xe5a11c                |  goto label_27;                         
            goto label_27;
            // 0x00E59DF8: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59DFC: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59E00: LDR x9, [x8, #0x240]       | X9 = val_4.value + 576;                 
            // 0x00E59E04: LDR x1, [x8, #0x248]       | X1 = val_4.value + 584;                 
            // 0x00E59E08: BLR x9                     | X0 = val_4.value + 576();               
            // 0x00E59E0C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00E59E10: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00E59E14: STR w0, [sp, #8]           | stack[1152921509575573608] = val_4.value;  //  dest_result_addr=1152921509575573608
            // 0x00E59E18: LDR x8, [x8]               | X8 = typeof(System.Int32);              
            val_28 = null;
            // 0x00E59E1C: B #0xe5a110                |  goto label_19;                         
            goto label_19;
            // 0x00E59E20: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59E24: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59E28: LDR x9, [x8, #0x250]       | X9 = val_4.value + 592;                 
            // 0x00E59E2C: LDR x1, [x8, #0x258]       | X1 = val_4.value + 600;                 
            // 0x00E59E30: BLR x9                     | X0 = val_4.value + 592();               
            // 0x00E59E34: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00E59E38: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
            // 0x00E59E3C: STR x0, [sp, #8]           | stack[1152921509575573608] = val_4.value;  //  dest_result_addr=1152921509575573608
            // 0x00E59E40: LDR x8, [x8]               | X8 = typeof(System.Int64);              
            val_28 = null;
            // 0x00E59E44: B #0xe5a110                |  goto label_19;                         
            goto label_19;
            // 0x00E59E48: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59E4C: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59E50: LDR x9, [x8, #0x220]       | X9 = val_4.value + 544;                 
            // 0x00E59E54: LDR x1, [x8, #0x228]       | X1 = val_4.value + 552;                 
            // 0x00E59E58: BLR x9                     | X0 = val_4.value + 544();               
            // 0x00E59E5C: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00E59E60: LDR x8, [x8, #0x900]       | X8 = 1152921504608497664;               
            // 0x00E59E64: STR d0, [sp, #8]           | stack[1152921509575573608] = ???;        //  dest_result_addr=1152921509575573608
            // 0x00E59E68: LDR x0, [x8]               | X0 = typeof(System.Double);             
            val_30 = null;
            // 0x00E59E6C: B #0xe5a0a8                |  goto label_9;                          
            goto label_9;
            // 0x00E59E70: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59E74: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59E78: LDR x9, [x8, #0x2a0]       | X9 = val_4.value + 672;                 
            // 0x00E59E7C: LDR x1, [x8, #0x2a8]       | X1 = val_4.value + 680;                 
            // 0x00E59E80: BLR x9                     | X0 = val_4.value + 672();               
            // 0x00E59E84: MOV w1, w0                 | W1 = val_4.value;//m1                   
            // 0x00E59E88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E59E8C: ADD x0, sp, #8             | X0 = (1152921509575573600 + 8) = 1152921509575573608 (0x100000012828C068);
            // 0x00E59E90: STR wzr, [sp, #8]          | stack[1152921509575573608] = 0x0;        //  dest_result_addr=1152921509575573608
            // 0x00E59E94: BL #0x11d58d4              | null..ctor(value:  val_25);             
            ProtoBuf.SubItemToken val_6 = new ProtoBuf.SubItemToken(value:  val_25);
            // 0x00E59E98: LDR w1, [sp, #8]           | W1 = val_6.value;                       
            // 0x00E59E9C: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59EA0: BL #0xe5a578               | X0 = val_4.value.GetCallSite(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_6.value});
            ILRuntime.Mono.Cecil.CallSite val_7 = val_25.GetCallSite(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_6.value});
            // 0x00E59EA4: B #0xe5a11c                |  goto label_27;                         
            goto label_27;
            // 0x00E59EA8: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59EAC: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59EB0: LDR x9, [x8, #0x2a0]       | X9 = val_4.value + 672;                 
            // 0x00E59EB4: LDR x1, [x8, #0x2a8]       | X1 = val_4.value + 680;                 
            // 0x00E59EB8: BLR x9                     | X0 = val_4.value + 672();               
            // 0x00E59EBC: MOV w1, w0                 | W1 = val_4.value;//m1                   
            // 0x00E59EC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E59EC4: ADD x0, sp, #8             | X0 = (1152921509575573600 + 8) = 1152921509575573608 (0x100000012828C068);
            // 0x00E59EC8: STR wzr, [sp, #8]          | stack[1152921509575573608] = 0x0;        //  dest_result_addr=1152921509575573608
            // 0x00E59ECC: BL #0x11d58d4              | null..ctor(value:  val_25);             
            ProtoBuf.SubItemToken val_8 = new ProtoBuf.SubItemToken(value:  val_25);
            // 0x00E59ED0: LDR w1, [sp, #8]           | W1 = val_8.value;                       
            // 0x00E59ED4: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59ED8: BL #0xe5a5a8               | X0 = val_4.value.GetString(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_8.value});
            string val_9 = val_25.GetString(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_8.value});
            // 0x00E59EDC: B #0xe5a11c                |  goto label_27;                         
            goto label_27;
            // 0x00E59EE0: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59EE4: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59EE8: LDR x9, [x8, #0x240]       | X9 = val_4.value + 576;                 
            // 0x00E59EEC: LDR x1, [x8, #0x248]       | X1 = val_4.value + 584;                 
            // 0x00E59EF0: BLR x9                     | X0 = val_4.value + 576();               
            // 0x00E59EF4: MOV w21, w0                | W21 = val_4.value;//m1                  
            val_24 = val_25;
            // 0x00E59EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59EFC: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59F00: BL #0x11e05f0              | X0 = val_4.value.get_Position();        
            int val_10 = val_25.Position;
            // 0x00E59F04: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E59F08: LDR w24, [x19, #0x48]      | W24 = val_4.value + 72;                 
            var val_17 = val_4.value + 72;
            // 0x00E59F0C: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x00E59F10: MOV w22, w0                | W22 = val_10;//m1                       
            // 0x00E59F14: LDR x20, [x8]              | X20 = typeof(System.Int32[]);           
            // 0x00E59F18: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x00E59F1C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
            // 0x00E59F20: MOV w1, w21                | W1 = val_4.value;//m1                   
            // 0x00E59F24: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x00E59F28: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
            // 0x00E59F2C: MOV x20, x0                | X20 = 1152921504962510832 (0x100000001532FFF0);//ML01
            val_23 = null;
            // 0x00E59F30: CMP w21, #1                | STATE = COMPARE(val_4.value, 0x1)       
            // 0x00E59F34: B.LT #0xe5a120             | if (val_24 < 1) goto label_16;          
            if(val_24 < 1)
            {
                goto label_16;
            }
            // 0x00E59F38: ADD w8, w22, w21, lsl #2   | W8 = (val_10 + (val_4.value) << 2);     
            int val_11 = val_10 + (val_24 << 2);
            // 0x00E59F3C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            var val_18 = 0;
            // 0x00E59F40: ADD x22, x20, #0x20        | X22 = (val_23 + 32) = 1152921504962510864 (0x1000000015330010);
            // 0x00E59F44: SUB w24, w8, w24           | W24 = ((val_10 + (val_4.value) << 2) - val_4.value + 72);
            val_17 = val_11 - val_17;
            // 0x00E59F48: MOV w25, w21               | W25 = val_4.value;//m1                  
            label_15:
            // 0x00E59F4C: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59F50: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59F54: LDR x9, [x8, #0x240]       | X9 = val_4.value + 576;                 
            // 0x00E59F58: LDR x1, [x8, #0x248]       | X1 = val_4.value + 584;                 
            // 0x00E59F5C: BLR x9                     | X0 = val_4.value + 576();               
            // 0x00E59F60: MOV w21, w0                | W21 = val_4.value;//m1                  
            // 0x00E59F64: CBNZ x20, #0xe59f6c        | if ( != null) goto label_13;            
            if(null != null)
            {
                goto label_13;
            }
            // 0x00E59F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4.value, ????);
            label_13:
            // 0x00E59F6C: LDR w8, [x20, #0x18]       | W8 = System.Int32[].__il2cppRuntimeField_namespaze;
            // 0x00E59F70: ADD w21, w24, w21          | W21 = (((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value);
            val_24 = val_17 + val_25;
            // 0x00E59F74: CMP x23, x8                | STATE = COMPARE(0x0, System.Int32[].__il2cppRuntimeField_namespaze)
            // 0x00E59F78: B.LO #0xe59f88             | if (0 < System.Int32[].__il2cppRuntimeField_namespaze) goto label_14;
            // 0x00E59F7C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4.value, ????);
            // 0x00E59F80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59F84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4.value, ????);
            label_14:
            // 0x00E59F88: STR w21, [x22, x23, lsl #2] | System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = (((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value);  //  dest_result_addr=1152921504962510864
            System.Int32[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_24;
            // 0x00E59F8C: ADD x23, x23, #1           | X23 = (0 + 1);                          
            val_18 = val_18 + 1;
            // 0x00E59F90: CMP w25, w23               | STATE = COMPARE(val_4.value, (0 + 1))   
            // 0x00E59F94: B.NE #0xe59f4c             | if (val_24 != 0) goto label_15;         
            if(val_24 != val_18)
            {
                goto label_15;
            }
            // 0x00E59F98: B #0xe5a120                |  goto label_16;                         
            goto label_16;
            // 0x00E59F9C: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59FA0: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59FA4: LDR x9, [x8, #0x290]       | X9 = val_4.value + 656;                 
            // 0x00E59FA8: LDR x1, [x8, #0x298]       | X1 = val_4.value + 664;                 
            // 0x00E59FAC: BLR x9                     | X0 = val_4.value + 656();               
            // 0x00E59FB0: AND w1, w0, #0xffff        | W1 = (val_4.value & 65535);             
            val_31 = val_25 & 65535;
            // 0x00E59FB4: B #0xe5a0c4                |  goto label_17;                         
            goto label_17;
            // 0x00E59FB8: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59FBC: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59FC0: LDR x9, [x8, #0x290]       | X9 = val_4.value + 656;                 
            // 0x00E59FC4: LDR x1, [x8, #0x298]       | X1 = val_4.value + 664;                 
            // 0x00E59FC8: BLR x9                     | X0 = val_4.value + 656();               
            // 0x00E59FCC: AND w1, w0, #0xffff        | W1 = (val_4.value & 65535);             
            val_32 = val_25 & 65535;
            // 0x00E59FD0: B #0xe5a0e4                |  goto label_18;                         
            goto label_18;
            // 0x00E59FD4: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E59FD8: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59FDC: LDR x9, [x8, #0x260]       | X9 = val_4.value + 608;                 
            // 0x00E59FE0: LDR x1, [x8, #0x268]       | X1 = val_4.value + 616;                 
            // 0x00E59FE4: BLR x9                     | X0 = val_4.value + 608();               
            // 0x00E59FE8: MOV w20, w0                | W20 = val_4.value;//m1                  
            // 0x00E59FEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E59FF0: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E59FF4: BL #0x11e05f0              | X0 = val_4.value.get_Position();        
            int val_12 = val_25.Position;
            // 0x00E59FF8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00E59FFC: LDR w9, [x19, #0x48]       | W9 = val_4.value + 72;                  
            val_26 = mem[val_4.value + 72];
            val_26 = val_4.value + 72;
            // 0x00E5A000: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x00E5A004: ADD w10, w0, w20, sxtb     | W10 = (val_12 + val_4.value);           
            val_27 = val_12 + val_25;
            // 0x00E5A008: LDR x8, [x8]               | X8 = typeof(System.Int32);              
            val_28 = null;
            label_4:
            // 0x00E5A00C: SUB w9, w10, w9            | W9 = ((val_12 + val_4.value) - val_4.value + 72);
            val_26 = val_27 - val_26;
            // 0x00E5A010: STR w9, [sp, #8]           | stack[1152921509575573608] = ((val_12 + val_4.value) - val_4.value + 72);  //  dest_result_addr=1152921509575573608
            // 0x00E5A014: B #0xe5a110                |  goto label_19;                         
            goto label_19;
            // 0x00E5A018: ADRP x22, #0x35f6000       | X22 = 56582144 (0x35F6000);             
            // 0x00E5A01C: LDR x22, [x22, #0xf38]     | X22 = 1152921504746835968;              
            // 0x00E5A020: LDUR x20, [x21, #0x14]     | X20 = (((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20;
            // 0x00E5A024: LDR x0, [x22]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.OpCodes);
            val_33 = null;
            // 0x00E5A028: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_10A;
            // 0x00E5A02C: TBZ w8, #0, #0xe5a040      | if (ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00E5A030: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_cctor_finished;
            // 0x00E5A034: CBNZ w8, #0xe5a040         | if (ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00E5A038: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Cil.OpCodes), ????);
            // 0x00E5A03C: LDR x0, [x22]              | X0 = typeof(ILRuntime.Mono.Cecil.Cil.OpCodes);
            val_33 = null;
            label_21:
            // 0x00E5A040: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Cil.OpCodes.__il2cppRuntimeField_static_fields;
            // 0x00E5A044: AND w9, w20, #0xff         | W9 = ((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20 & 255);
            var val_13 = ((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20) & 255;
            // 0x00E5A048: LDR x8, [x8, #0x108]       | X8 = ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S;
            // 0x00E5A04C: CMP w9, w8, uxtb           | STATE = COMPARE(((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20 & 255), ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S)
            // 0x00E5A050: B.NE #0xe5a0f0             | if (val_13 != ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S) goto label_23;
            if(val_13 != ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S)
            {
                goto label_23;
            }
            // 0x00E5A054: UBFX w9, w20, #8, #8       | W9 = (uint)(((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20>>8) & 0xFF);
            // 0x00E5A058: UBFX x8, x8, #8, #0x18     | X8 = (ulong)((ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S>>8) & 0xFFFFFF);
            // 0x00E5A05C: CMP w9, w8, uxtb           | STATE = COMPARE((uint)(((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20>>8) & 0xFF), (ulong)((ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S>>8) & 0xFFFFFF))
            // 0x00E5A060: B.NE #0xe5a0f0             | if ((uint)(((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20) >> 8) & 255 != (ulong)(ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S >> 8) & 16777215) goto label_23;
            if(((uint)(((((val_10 + (val_4.value) << 2) - val_4.value + 72) + val_4.value) + 20) >> 8) & 255) != ((ulong)(ILRuntime.Mono.Cecil.Cil.OpCodes.Ldc_I4_S >> 8) & 16777215))
            {
                goto label_23;
            }
            // 0x00E5A064: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E5A068: MOV x0, x19                | X0 = val_4.value;//m1                   
            val_34 = val_25;
            // 0x00E5A06C: LDR x9, [x8, #0x260]       | X9 = val_4.value + 608;                 
            // 0x00E5A070: LDR x1, [x8, #0x268]       | X1 = val_4.value + 616;                 
            // 0x00E5A074: BLR x9                     | X0 = val_4.value + 608();               
            // 0x00E5A078: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x00E5A07C: LDR x8, [x8, #0x100]       | X8 = 1152921504607858688;               
            val_35 = 1152921504607858688;
            // 0x00E5A080: B #0xe5a108                |  goto label_24;                         
            goto label_24;
            // 0x00E5A084: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E5A088: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E5A08C: LDR x9, [x8, #0x280]       | X9 = val_4.value + 640;                 
            // 0x00E5A090: LDR x1, [x8, #0x288]       | X1 = val_4.value + 648;                 
            // 0x00E5A094: BLR x9                     | X0 = val_4.value + 640();               
            // 0x00E5A098: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00E5A09C: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00E5A0A0: STR s0, [sp, #8]           | stack[1152921509575573608] = ???;        //  dest_result_addr=1152921509575573608
            // 0x00E5A0A4: LDR x0, [x8]               | X0 = typeof(System.Single);             
            val_30 = null;
            label_9:
            // 0x00E5A0A8: ADD x1, sp, #8             | X1 = (1152921509575573600 + 8) = 1152921509575573608 (0x100000012828C068);
            // 0x00E5A0AC: B #0xe5a118                |  goto label_25;                         
            goto label_25;
            // 0x00E5A0B0: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E5A0B4: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E5A0B8: LDP x9, x1, [x8, #0x1e0]   | X9 = val_4.value + 480; X1 = val_4.value + 480 + 8; //  | 
            // 0x00E5A0BC: BLR x9                     | X0 = val_4.value + 480();               
            // 0x00E5A0C0: AND w1, w0, #0xff          | W1 = (val_4.value & 255);               
            val_31 = val_25 & 255;
            label_17:
            // 0x00E5A0C4: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E5A0C8: BL #0xe5a438               | X0 = val_4.value.GetVariable(index:  val_31 = val_25 & 255);
            ILRuntime.Mono.Cecil.Cil.VariableDefinition val_14 = val_25.GetVariable(index:  val_31);
            // 0x00E5A0CC: B #0xe5a11c                |  goto label_27;                         
            goto label_27;
            // 0x00E5A0D0: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E5A0D4: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E5A0D8: LDP x9, x1, [x8, #0x1e0]   | X9 = val_4.value + 480; X1 = val_4.value + 480 + 8; //  | 
            // 0x00E5A0DC: BLR x9                     | X0 = val_4.value + 480();               
            // 0x00E5A0E0: AND w1, w0, #0xff          | W1 = (val_4.value & 255);               
            val_32 = val_25 & 255;
            label_18:
            // 0x00E5A0E4: MOV x0, x19                | X0 = val_4.value;//m1                   
            // 0x00E5A0E8: BL #0xe5a4b8               | X0 = val_4.value.GetParameter(index:  val_32 = val_25 & 255);
            ILRuntime.Mono.Cecil.ParameterDefinition val_15 = val_25.GetParameter(index:  val_32);
            // 0x00E5A0EC: B #0xe5a11c                |  goto label_27;                         
            goto label_27;
            label_23:
            // 0x00E5A0F0: LDR x8, [x19]              | X8 = val_4.value;                       
            // 0x00E5A0F4: MOV x0, x19                | X0 = val_4.value;//m1                   
            val_34 = val_25;
            // 0x00E5A0F8: LDP x9, x1, [x8, #0x1e0]   | X9 = val_4.value + 480; X1 = val_4.value + 480 + 8; //  | 
            // 0x00E5A0FC: BLR x9                     | X0 = val_4.value + 480();               
            // 0x00E5A100: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00E5A104: LDR x8, [x8, #0xf90]       | X8 = 1152921504607805440;               
            val_35 = 1152921504607805440;
            label_24:
            // 0x00E5A108: LDR x8, [x8]               | X8 = typeof(System.Byte);               
            // 0x00E5A10C: STRB w0, [sp, #8]          | stack[1152921509575573608] = val_4.value;  //  dest_result_addr=1152921509575573608
            label_19:
            // 0x00E5A110: ADD x1, sp, #8             | X1 = (1152921509575573600 + 8) = 1152921509575573608 (0x100000012828C068);
            // 0x00E5A114: MOV x0, x8                 | X0 = 1152921504607805440 (0x10000000000EA000);//ML01
            val_30 = val_35;
            label_25:
            // 0x00E5A118: BL #0x27bc028              | X0 = 1152921509575646368 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Byte), val_4.value);
            label_27:
            // 0x00E5A11C: MOV x20, x0                | X20 = 1152921509575646368 (0x100000012829DCA0);//ML01
            val_23 = val_34;
            label_16:
            // 0x00E5A120: MOV x0, x20                | X0 = 1152921509575646368 (0x100000012829DCA0);//ML01
            // 0x00E5A124: SUB sp, x29, #0x40         | SP = (1152921509575573680 - 64) = 1152921509575573616 (0x100000012828C070);
            // 0x00E5A128: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A12C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A130: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5A134: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5A138: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E5A13C: RET                        |  return (System.Object)val_4.value;     
            return (object)val_23;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_2:
            // 0x00E5A140: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00E5A144: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x00E5A148: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_16 = null;
            // 0x00E5A14C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x00E5A150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A154: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00E5A158: BL #0x1701574              | .ctor();                                
            val_16 = new System.NotSupportedException();
            // 0x00E5A15C: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00E5A160: LDR x8, [x8, #0xf88]       | X8 = 1152921509575560672;               
            // 0x00E5A164: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00E5A168: LDR x1, [x8]               | X1 = System.Object ILRuntime.Mono.Cecil.Cil.CodeReader::ReadOperand(ILRuntime.Mono.Cecil.Cil.Instruction instruction);
            // 0x00E5A16C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x00E5A170: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.NotSupportedException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A5A8 (15050152), len: 100  VirtAddr: 0x00E5A5A8 RVA: 0x00E5A5A8 token: 100664621 methodIndex: 19373 delegateWrapperIndex: 0 methodInvoker: 0
        public string GetString(ILRuntime.Mono.Cecil.MetadataToken token)
        {
            //
            // Disasemble & Code
            // 0x00E5A5A8: STP x20, x19, [sp, #-0x20]! | stack[1152921509575734816] = ???;  stack[1152921509575734824] = ???;  //  dest_result_addr=1152921509575734816 |  dest_result_addr=1152921509575734824
            // 0x00E5A5AC: STP x29, x30, [sp, #0x10]  | stack[1152921509575734832] = ???;  stack[1152921509575734840] = ???;  //  dest_result_addr=1152921509575734832 |  dest_result_addr=1152921509575734840
            // 0x00E5A5B0: ADD x29, sp, #0x10         | X29 = (1152921509575734816 + 16) = 1152921509575734832 (0x10000001282B3630);
            // 0x00E5A5B4: SUB sp, sp, #0x10          | SP = (1152921509575734816 - 16) = 1152921509575734800 (0x10000001282B3610);
            // 0x00E5A5B8: STR w1, [sp, #8]           | stack[1152921509575734808] = token.token;  //  dest_result_addr=1152921509575734808
            // 0x00E5A5BC: LDR x19, [x0, #0x40]       | X19 = this.reader; //P2                 
            // 0x00E5A5C0: CBNZ x19, #0xe5a5c8        | if (this.reader != null) goto label_0;  
            if(this.reader != null)
            {
                goto label_0;
            }
            // 0x00E5A5C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E5A5C8: LDR x19, [x19, #0x20]      | X19 = this.reader.image; //P2           
            // 0x00E5A5CC: CBNZ x19, #0xe5a5d4        | if (this.reader.image != null) goto label_1;
            if(this.reader.image != null)
            {
                goto label_1;
            }
            // 0x00E5A5D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00E5A5D4: LDR x19, [x19, #0xa0]      | X19 = this.reader.image.UserStringHeap; //P2 
            // 0x00E5A5D8: ADD x0, sp, #8             | X0 = (1152921509575734800 + 8) = 1152921509575734808 (0x10000001282B3618);
            // 0x00E5A5DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A5E0: BL #0x11d4138              | X0 = label_ILRuntime_Mono_Cecil_MetadataSystem_AddTypeDefinition_GL011D4138();
            // 0x00E5A5E4: MOV w20, w0                | W20 = 1152921509575734808 (0x10000001282B3618);//ML01
            // 0x00E5A5E8: CBNZ x19, #0xe5a5f0        | if (this.reader.image.UserStringHeap != null) goto label_2;
            if(this.reader.image.UserStringHeap != null)
            {
                goto label_2;
            }
            // 0x00E5A5EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001282B3618, ????);
            label_2:
            // 0x00E5A5F0: MOV x0, x19                | X0 = this.reader.image.UserStringHeap;//m1
            // 0x00E5A5F4: MOV w1, w20                | W1 = 1152921509575734808 (0x10000001282B3618);//ML01
            // 0x00E5A5F8: BL #0xe5a76c               | X0 = this.reader.image.UserStringHeap.Read(index:  673920536);
            string val_1 = this.reader.image.UserStringHeap.Read(index:  673920536);
            // 0x00E5A5FC: SUB sp, x29, #0x10         | SP = (1152921509575734832 - 16) = 1152921509575734816 (0x10000001282B3620);
            // 0x00E5A600: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A604: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A608: RET                        |  return (System.String)val_1;           
            return val_1;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A4B8 (15049912), len: 128  VirtAddr: 0x00E5A4B8 RVA: 0x00E5A4B8 token: 100664622 methodIndex: 19374 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.ParameterDefinition GetParameter(int index)
        {
            //
            // Disasemble & Code
            // 0x00E5A4B8: STP x22, x21, [sp, #-0x30]! | stack[1152921509575867280] = ???;  stack[1152921509575867288] = ???;  //  dest_result_addr=1152921509575867280 |  dest_result_addr=1152921509575867288
            // 0x00E5A4BC: STP x20, x19, [sp, #0x10]  | stack[1152921509575867296] = ???;  stack[1152921509575867304] = ???;  //  dest_result_addr=1152921509575867296 |  dest_result_addr=1152921509575867304
            // 0x00E5A4C0: STP x29, x30, [sp, #0x20]  | stack[1152921509575867312] = ???;  stack[1152921509575867320] = ???;  //  dest_result_addr=1152921509575867312 |  dest_result_addr=1152921509575867320
            // 0x00E5A4C4: ADD x29, sp, #0x20         | X29 = (1152921509575867280 + 32) = 1152921509575867312 (0x10000001282D3BB0);
            // 0x00E5A4C8: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5A4CC: LDRB w8, [x21, #0xae0]     | W8 = (bool)static_value_03734AE0;       
            // 0x00E5A4D0: MOV w19, w1                | W19 = index;//m1                        
            // 0x00E5A4D4: MOV x20, x0                | X20 = 1152921509575879328 (0x10000001282D6AA0);//ML01
            // 0x00E5A4D8: TBNZ w8, #0, #0xe5a4f4     | if (static_value_03734AE0 == true) goto label_0;
            // 0x00E5A4DC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E5A4E0: LDR x8, [x8, #0x10]        | X8 = 0x2B90D94;                         
            // 0x00E5A4E4: LDR w0, [x8]               | W0 = 0x1A29;                            
            // 0x00E5A4E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A29, ????);     
            // 0x00E5A4EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5A4F0: STRB w8, [x21, #0xae0]     | static_value_03734AE0 = true;            //  dest_result_addr=57887456
            label_0:
            // 0x00E5A4F4: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E5A4F8: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E5A4FC: LDR x20, [x20, #0x58]      | X20 = this.body; //P2                   
            // 0x00E5A500: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5A504: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5A508: TBZ w8, #0, #0xe5a518      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E5A50C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5A510: CBNZ w8, #0xe5a518         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E5A514: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E5A518: MOV x1, x20                | X1 = this.body;//m1                     
            // 0x00E5A51C: MOV w2, w19                | W2 = index;//m1                         
            // 0x00E5A520: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A524: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A528: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5A52C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5A530: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5A534: B #0x11d9b94               | return ILRuntime.Mono.Cecil.Mixin.GetParameter(self:  0, index:  this.body);
            return ILRuntime.Mono.Cecil.Mixin.GetParameter(self:  0, index:  this.body);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A438 (15049784), len: 128  VirtAddr: 0x00E5A438 RVA: 0x00E5A438 token: 100664623 methodIndex: 19375 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.Cil.VariableDefinition GetVariable(int index)
        {
            //
            // Disasemble & Code
            // 0x00E5A438: STP x22, x21, [sp, #-0x30]! | stack[1152921509575987472] = ???;  stack[1152921509575987480] = ???;  //  dest_result_addr=1152921509575987472 |  dest_result_addr=1152921509575987480
            // 0x00E5A43C: STP x20, x19, [sp, #0x10]  | stack[1152921509575987488] = ???;  stack[1152921509575987496] = ???;  //  dest_result_addr=1152921509575987488 |  dest_result_addr=1152921509575987496
            // 0x00E5A440: STP x29, x30, [sp, #0x20]  | stack[1152921509575987504] = ???;  stack[1152921509575987512] = ???;  //  dest_result_addr=1152921509575987504 |  dest_result_addr=1152921509575987512
            // 0x00E5A444: ADD x29, sp, #0x20         | X29 = (1152921509575987472 + 32) = 1152921509575987504 (0x10000001282F1130);
            // 0x00E5A448: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5A44C: LDRB w8, [x21, #0xae1]     | W8 = (bool)static_value_03734AE1;       
            // 0x00E5A450: MOV w19, w1                | W19 = index;//m1                        
            // 0x00E5A454: MOV x20, x0                | X20 = 1152921509575999520 (0x10000001282F4020);//ML01
            // 0x00E5A458: TBNZ w8, #0, #0xe5a474     | if (static_value_03734AE1 == true) goto label_0;
            // 0x00E5A45C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00E5A460: LDR x8, [x8, #0x438]       | X8 = 0x2B90D98;                         
            // 0x00E5A464: LDR w0, [x8]               | W0 = 0x1A2A;                            
            // 0x00E5A468: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2A, ????);     
            // 0x00E5A46C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5A470: STRB w8, [x21, #0xae1]     | static_value_03734AE1 = true;            //  dest_result_addr=57887457
            label_0:
            // 0x00E5A474: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E5A478: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E5A47C: LDR x20, [x20, #0x58]      | X20 = this.body; //P2                   
            // 0x00E5A480: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5A484: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5A488: TBZ w8, #0, #0xe5a498      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E5A48C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5A490: CBNZ w8, #0xe5a498         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E5A494: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E5A498: MOV x1, x20                | X1 = this.body;//m1                     
            // 0x00E5A49C: MOV w2, w19                | W2 = index;//m1                         
            // 0x00E5A4A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A4A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A4A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5A4AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5A4B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5A4B4: B #0x11d9c88               | return ILRuntime.Mono.Cecil.Mixin.GetVariable(self:  0, index:  this.body);
            return ILRuntime.Mono.Cecil.Mixin.GetVariable(self:  0, index:  this.body);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A578 (15050104), len: 48  VirtAddr: 0x00E5A578 RVA: 0x00E5A578 token: 100664624 methodIndex: 19376 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.CallSite GetCallSite(ILRuntime.Mono.Cecil.MetadataToken token)
        {
            //
            // Disasemble & Code
            // 0x00E5A578: STP x20, x19, [sp, #-0x20]! | stack[1152921509576107680] = ???;  stack[1152921509576107688] = ???;  //  dest_result_addr=1152921509576107680 |  dest_result_addr=1152921509576107688
            // 0x00E5A57C: STP x29, x30, [sp, #0x10]  | stack[1152921509576107696] = ???;  stack[1152921509576107704] = ???;  //  dest_result_addr=1152921509576107696 |  dest_result_addr=1152921509576107704
            // 0x00E5A580: ADD x29, sp, #0x10         | X29 = (1152921509576107680 + 16) = 1152921509576107696 (0x100000012830E6B0);
            // 0x00E5A584: LDR x19, [x0, #0x40]       | X19 = this.reader; //P2                 
            // 0x00E5A588: MOV x20, x1                | X20 = token.token;//m1                  
            // 0x00E5A58C: CBNZ x19, #0xe5a594        | if (this.reader != null) goto label_0;  
            if(this.reader != null)
            {
                goto label_0;
            }
            // 0x00E5A590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E5A594: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A598: AND x1, x20, #0xffffffff   | X1 = (token.token & 4294967295);        
            token.token = token.token & 4294967295;
            // 0x00E5A59C: MOV x0, x19                | X0 = this.reader;//m1                   
            // 0x00E5A5A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A5A4: B #0xe5a8b4                | return this.reader.ReadCallSite(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = token.token});
            return this.reader.ReadCallSite(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = token.token});
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A174 (15049076), len: 668  VirtAddr: 0x00E5A174 RVA: 0x00E5A174 token: 100664625 methodIndex: 19377 delegateWrapperIndex: 0 methodInvoker: 0
        private void ResolveBranches(ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.Instruction> instructions)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            int val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00E5A174: STP x28, x27, [sp, #-0x60]! | stack[1152921509576240096] = ???;  stack[1152921509576240104] = ???;  //  dest_result_addr=1152921509576240096 |  dest_result_addr=1152921509576240104
            // 0x00E5A178: STP x26, x25, [sp, #0x10]  | stack[1152921509576240112] = ???;  stack[1152921509576240120] = ???;  //  dest_result_addr=1152921509576240112 |  dest_result_addr=1152921509576240120
            // 0x00E5A17C: STP x24, x23, [sp, #0x20]  | stack[1152921509576240128] = ???;  stack[1152921509576240136] = ???;  //  dest_result_addr=1152921509576240128 |  dest_result_addr=1152921509576240136
            // 0x00E5A180: STP x22, x21, [sp, #0x30]  | stack[1152921509576240144] = ???;  stack[1152921509576240152] = ???;  //  dest_result_addr=1152921509576240144 |  dest_result_addr=1152921509576240152
            // 0x00E5A184: STP x20, x19, [sp, #0x40]  | stack[1152921509576240160] = ???;  stack[1152921509576240168] = ???;  //  dest_result_addr=1152921509576240160 |  dest_result_addr=1152921509576240168
            // 0x00E5A188: STP x29, x30, [sp, #0x50]  | stack[1152921509576240176] = ???;  stack[1152921509576240184] = ???;  //  dest_result_addr=1152921509576240176 |  dest_result_addr=1152921509576240184
            // 0x00E5A18C: ADD x29, sp, #0x50         | X29 = (1152921509576240096 + 80) = 1152921509576240176 (0x100000012832EC30);
            // 0x00E5A190: SUB sp, sp, #0x10          | SP = (1152921509576240096 - 16) = 1152921509576240080 (0x100000012832EBD0);
            // 0x00E5A194: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5A198: LDRB w8, [x21, #0xae2]     | W8 = (bool)static_value_03734AE2;       
            // 0x00E5A19C: MOV x20, x1                | X20 = instructions;//m1                 
            // 0x00E5A1A0: MOV x19, x0                | X19 = 1152921509576252192 (0x1000000128331B20);//ML01
            // 0x00E5A1A4: TBNZ w8, #0, #0xe5a1c0     | if (static_value_03734AE2 == true) goto label_0;
            // 0x00E5A1A8: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00E5A1AC: LDR x8, [x8, #0x140]       | X8 = 0x2B90DD8;                         
            // 0x00E5A1B0: LDR w0, [x8]               | W0 = 0x1A3A;                            
            val_7 = 6714;
            // 0x00E5A1B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A3A, ????);     
            // 0x00E5A1B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5A1BC: STRB w8, [x21, #0xae2]     | static_value_03734AE2 = true;            //  dest_result_addr=57887458
            label_0:
            // 0x00E5A1C0: CBZ x20, #0xe5a1cc         | if (instructions == null) goto label_1; 
            if(instructions == null)
            {
                goto label_1;
            }
            // 0x00E5A1C4: LDR x23, [x20, #0x10]      | 
            // 0x00E5A1C8: B #0xe5a1dc                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00E5A1CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3A, ????);     
            // 0x00E5A1D0: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x00E5A1D4: LDR x23, [x8]              | X23 = 0x100B70003;                      
            val_8 = 11993091;
            // 0x00E5A1D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3A, ????);     
            label_2:
            // 0x00E5A1DC: LDRSW x24, [x20, #0x18]    | 
            // 0x00E5A1E0: CMP w24, #1                | STATE = COMPARE(W24, 0x1)               
            // 0x00E5A1E4: B.LT #0xe5a37c             | if (W24 < 0x1) goto label_3;            
            if(W24 < 1)
            {
                goto label_3;
            }
            // 0x00E5A1E8: ADRP x26, #0x3652000       | X26 = 56958976 (0x3652000);             
            // 0x00E5A1EC: LDR x26, [x26, #0x140]     | X26 = 1152921504607113216;              
            // 0x00E5A1F0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            var val_8 = 0;
            label_23:
            // 0x00E5A1F4: CBNZ x23, #0xe5a1fc        | if (0x100B70003 != 0) goto label_4;     
            if(val_8 != 0)
            {
                goto label_4;
            }
            // 0x00E5A1F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3A, ????);     
            label_4:
            // 0x00E5A1FC: LDR w8, [x23, #0x18]       | W8 = mem[4306960411];                   
            // 0x00E5A200: CMP x25, x8                | STATE = COMPARE(0x0, mem[4306960411])   
            // 0x00E5A204: B.LO #0xe5a214             | if (0 < mem[4306960411]) goto label_5;  
            if(val_8 < mem[4306960411])
            {
                goto label_5;
            }
            // 0x00E5A208: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1A3A, ????);     
            // 0x00E5A20C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A210: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1A3A, ????);     
            label_5:
            // 0x00E5A214: ADD x8, x23, x25, lsl #3   | X8 = (val_8 + 0);                       
            var val_1 = val_8 + 0;
            // 0x00E5A218: LDR x27, [x8, #0x20]       | X27 = (val_8 + 0) + 32;                 
            // 0x00E5A21C: CBNZ x27, #0xe5a224        | if ((val_8 + 0) + 32 != 0) goto label_6;
            if(((val_8 + 0) + 32) != 0)
            {
                goto label_6;
            }
            // 0x00E5A220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3A, ????);     
            label_6:
            // 0x00E5A224: LDRB w8, [x27, #0x19]      | W8 = (val_8 + 0) + 32 + 25;             
            // 0x00E5A228: CMP w8, #0xf               | STATE = COMPARE((val_8 + 0) + 32 + 25, 0xF)
            // 0x00E5A22C: B.EQ #0xe5a23c             | if ((val_8 + 0) + 32 + 25 == 0xF) goto label_7;
            if(((val_8 + 0) + 32 + 25) == 15)
            {
                goto label_7;
            }
            // 0x00E5A230: CMP w8, #0xa               | STATE = COMPARE((val_8 + 0) + 32 + 25, 0xA)
            // 0x00E5A234: B.EQ #0xe5a27c             | if ((val_8 + 0) + 32 + 25 == 0xA) goto label_8;
            if(((val_8 + 0) + 32 + 25) == 10)
            {
                goto label_8;
            }
            // 0x00E5A238: CBNZ w8, #0xe5a370         | if ((val_8 + 0) + 32 + 25 != 0) goto label_12;
            if(((val_8 + 0) + 32 + 25) != 0)
            {
                goto label_12;
            }
            label_7:
            // 0x00E5A23C: LDR x21, [x27, #0x20]      | X21 = (val_8 + 0) + 32 + 32;            
            val_9 = mem[(val_8 + 0) + 32 + 32];
            val_9 = (val_8 + 0) + 32 + 32;
            // 0x00E5A240: LDR x20, [x26]             | X20 = typeof(System.Int32);             
            // 0x00E5A244: CBNZ x21, #0xe5a24c        | if ((val_8 + 0) + 32 + 32 != 0) goto label_10;
            if(val_9 != 0)
            {
                goto label_10;
            }
            // 0x00E5A248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A3A, ????);     
            label_10:
            // 0x00E5A24C: LDR x8, [x21]              | X8 = (val_8 + 0) + 32 + 32;             
            // 0x00E5A250: LDR x0, [x8, #0x30]        | X0 = (val_8 + 0) + 32 + 32 + 48;        
            // 0x00E5A254: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x00E5A258: CMP x0, x8                 | STATE = COMPARE((val_8 + 0) + 32 + 32 + 48, System.Int32.__il2cppRuntimeField_element_class)
            // 0x00E5A25C: B.NE #0xe5a39c             | if ((val_8 + 0) + 32 + 32 + 48 != System.Int32.__il2cppRuntimeField_element_class) goto label_11;
            // 0x00E5A260: MOV x0, x21                | X0 = (val_8 + 0) + 32 + 32;//m1         
            // 0x00E5A264: BL #0x27bc4e8              | (val_8 + 0) + 32 + 32.System.IDisposable.Dispose();
            val_9.System.IDisposable.Dispose();
            // 0x00E5A268: LDR w1, [x0]               | W1 = (val_8 + 0) + 32 + 32;             
            // 0x00E5A26C: MOV x0, x19                | X0 = 1152921509576252192 (0x1000000128331B20);//ML01
            // 0x00E5A270: BL #0xe5a984               | X0 = this.GetInstruction(offset:  val_9);
            ILRuntime.Mono.Cecil.Cil.Instruction val_2 = this.GetInstruction(offset:  val_9);
            // 0x00E5A274: STR x0, [x27, #0x20]       | mem2[0] = val_2;                         //  dest_result_addr=0
            mem2[0] = val_2;
            // 0x00E5A278: B #0xe5a370                |  goto label_12;                         
            goto label_12;
            label_8:
            // 0x00E5A27C: LDR x22, [x27, #0x20]      | X22 = (val_8 + 0) + 32 + 32;            
            // 0x00E5A280: CBZ x22, #0xe5a3ec         | if ((val_8 + 0) + 32 + 32 == 0) goto label_13;
            if(((val_8 + 0) + 32 + 32) == 0)
            {
                goto label_13;
            }
            // 0x00E5A284: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E5A288: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x00E5A28C: MOV x0, x22                | X0 = (val_8 + 0) + 32 + 32;//m1         
            // 0x00E5A290: LDR x21, [x8]              | X21 = typeof(System.Int32[]);           
            val_10 = null;
            // 0x00E5A294: MOV x1, x21                | X1 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x00E5A298: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (val_8 + 0) + 32 + 32, ????);
            // 0x00E5A29C: MOV x20, x0                | X20 = (val_8 + 0) + 32 + 32;//m1        
            // 0x00E5A2A0: CBZ x20, #0xe5a3c0         | if ((val_8 + 0) + 32 + 32 == 0) goto label_14;
            if(((val_8 + 0) + 32 + 32) == 0)
            {
                goto label_14;
            }
            // 0x00E5A2A4: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x00E5A2A8: LDR x8, [x8, #0xb78]       | X8 = 1152921509576220000;               
            // 0x00E5A2AC: LDR w22, [x20, #0x18]      | W22 = (val_8 + 0) + 32 + 32 + 24;       
            // 0x00E5A2B0: LDR x21, [x8]              | X21 = typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]);
            // 0x00E5A2B4: MOV x0, x21                | X0 = 1152921509576220000 (0x1000000128329D60);//ML01
            // 0x00E5A2B8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]), ????);
            // 0x00E5A2BC: MOV x0, x21                | X0 = 1152921509576220000 (0x1000000128329D60);//ML01
            // 0x00E5A2C0: MOV x1, x22                | X1 = (val_8 + 0) + 32 + 32 + 24;//m1    
            // 0x00E5A2C4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]), ????);
            // 0x00E5A2C8: LDR w8, [x20, #0x18]       | W8 = (val_8 + 0) + 32 + 32 + 24;        
            // 0x00E5A2CC: MOV x21, x0                | X21 = 1152921509576220000 (0x1000000128329D60);//ML01
            val_6 = null;
            // 0x00E5A2D0: CMP w8, #0                 | STATE = COMPARE((val_8 + 0) + 32 + 32 + 24, 0x0)
            // 0x00E5A2D4: B.LE #0xe5a364             | if ((val_8 + 0) + 32 + 32 + 24 <= 0x0) goto label_15;
            if(((val_8 + 0) + 32 + 32 + 24) <= 0)
            {
                goto label_15;
            }
            // 0x00E5A2D8: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            label_21:
            // 0x00E5A2DC: SXTW x28, w9               | X28 = 0 (0x00000000);                   
            // 0x00E5A2E0: CMP w9, w8                 | STATE = COMPARE(0x0, (val_8 + 0) + 32 + 32 + 24)
            // 0x00E5A2E4: B.LO #0xe5a2f4             | if (0 < (val_8 + 0) + 32 + 32 + 24) goto label_16;
            if(0 < ((val_8 + 0) + 32 + 32 + 24))
            {
                goto label_16;
            }
            // 0x00E5A2E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]), ????);
            // 0x00E5A2EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A2F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]), ????);
            label_16:
            // 0x00E5A2F4: ADD x8, x20, x28, lsl #2   | X8 = ((val_8 + 0) + 32 + 32 + 0);       
            var val_3 = ((val_8 + 0) + 32 + 32) + 0;
            // 0x00E5A2F8: LDR w1, [x8, #0x20]        | W1 = ((val_8 + 0) + 32 + 32 + 0) + 32;  
            // 0x00E5A2FC: MOV x0, x19                | X0 = 1152921509576252192 (0x1000000128331B20);//ML01
            // 0x00E5A300: BL #0xe5a984               | X0 = this.GetInstruction(offset:  ((val_8 + 0) + 32 + 32 + 0) + 32);
            ILRuntime.Mono.Cecil.Cil.Instruction val_4 = this.GetInstruction(offset:  ((val_8 + 0) + 32 + 32 + 0) + 32);
            // 0x00E5A304: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00E5A308: CBNZ x21, #0xe5a310        | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x00E5A30C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_17:
            // 0x00E5A310: CBZ x22, #0xe5a334         | if (val_4 == null) goto label_19;       
            if(val_4 == null)
            {
                goto label_19;
            }
            // 0x00E5A314: LDR x8, [x21]              | X8 = ;                                  
            // 0x00E5A318: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00E5A31C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E5A320: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00E5A324: CBNZ x0, #0xe5a334         | if (val_4 != null) goto label_19;       
            if(val_4 != null)
            {
                goto label_19;
            }
            // 0x00E5A328: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00E5A32C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A330: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_19:
            // 0x00E5A334: LDR w8, [x21, #0x18]       | W8 = ILRuntime.Mono.Cecil.Cil.Instruction[].__il2cppRuntimeField_namespaze;
            // 0x00E5A338: CMP w28, w8                | STATE = COMPARE(0x0, ILRuntime.Mono.Cecil.Cil.Instruction[].__il2cppRuntimeField_namespaze)
            // 0x00E5A33C: B.LO #0xe5a34c             | if (0 < ILRuntime.Mono.Cecil.Cil.Instruction[].__il2cppRuntimeField_namespaze) goto label_20;
            // 0x00E5A340: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00E5A344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A348: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_20:
            // 0x00E5A34C: ADD x8, x21, x28, lsl #3   | X8 = (val_6 + 0) = 1152921509576220000 (0x1000000128329D60);
            // 0x00E5A350: STR x22, [x8, #0x20]       | typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921509576220032
            typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]).__il2cppRuntimeField_20 = val_4;
            // 0x00E5A354: LDR w8, [x20, #0x18]       | W8 = (val_8 + 0) + 32 + 32 + 24;        
            // 0x00E5A358: ADD w9, w28, #1            | W9 = (0 + 1);                           
            var val_5 = 0 + 1;
            // 0x00E5A35C: CMP w9, w8                 | STATE = COMPARE((0 + 1), (val_8 + 0) + 32 + 32 + 24)
            // 0x00E5A360: B.LT #0xe5a2dc             | if (val_5 < (val_8 + 0) + 32 + 32 + 24) goto label_21;
            if(val_5 < ((val_8 + 0) + 32 + 32 + 24))
            {
                goto label_21;
            }
            label_15:
            // 0x00E5A364: CBNZ x27, #0xe5a36c        | if ((val_8 + 0) + 32 != 0) goto label_22;
            if(((val_8 + 0) + 32) != 0)
            {
                goto label_22;
            }
            // 0x00E5A368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_22:
            // 0x00E5A36C: STR x21, [x27, #0x20]      | mem2[0] = typeof(ILRuntime.Mono.Cecil.Cil.Instruction[]);  //  dest_result_addr=0
            mem2[0] = val_6;
            label_12:
            // 0x00E5A370: ADD x25, x25, #1           | X25 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00E5A374: CMP x25, x24               | STATE = COMPARE((0 + 1), X24)           
            // 0x00E5A378: B.LT #0xe5a1f4             | if (0 < X24) goto label_23;             
            if(val_8 < X24)
            {
                goto label_23;
            }
            label_3:
            // 0x00E5A37C: SUB sp, x29, #0x50         | SP = (1152921509576240176 - 80) = 1152921509576240096 (0x100000012832EBE0);
            // 0x00E5A380: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A384: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A388: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5A38C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5A390: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E5A394: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E5A398: RET                        |  return;                                
            return;
            label_11:
            // 0x00E5A39C: MOV x8, sp                 | X8 = 1152921509576240080 (0x100000012832EBD0);//ML01
            // 0x00E5A3A0: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00E5A3A4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? (val_8 + 0) + 32 + 32 + 48, ????);
            // 0x00E5A3A8: LDR x0, [sp]               | X0 = val_6;                              //  find_add[1152921509576228192]
            // 0x00E5A3AC: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00E5A3B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A3B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00E5A3B8: MOV x0, sp                 | X0 = 1152921509576240080 (0x100000012832EBD0);//ML01
            // 0x00E5A3BC: BL #0x299a140              | 
            label_14:
            // 0x00E5A3C0: LDR x8, [x22]              | X8 = X22;                               
            // 0x00E5A3C4: MOV x1, x21                | X1 = (val_8 + 0) + 32 + 32;//m1         
            // 0x00E5A3C8: LDR x0, [x8, #0x30]        | X0 = X22 + 48;                          
            // 0x00E5A3CC: ADD x8, sp, #8             | X8 = (1152921509576240080 + 8) = 1152921509576240088 (0x100000012832EBD8);
            // 0x00E5A3D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X22 + 48, ????);   
            // 0x00E5A3D4: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921509576228192]
            // 0x00E5A3D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00E5A3DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5A3E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00E5A3E4: ADD x0, sp, #8             | X0 = (1152921509576240080 + 8) = 1152921509576240088 (0x100000012832EBD8);
            // 0x00E5A3E8: BL #0x299a140              | 
            label_13:
            // 0x00E5A3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000012832EBD8, ????);
            // 0x00E5A3F0: MOV x19, x0                | X19 = 1152921509576240088 (0x100000012832EBD8);//ML01
            val_11;
            // 0x00E5A3F4: MOV x0, sp                 | X0 = 1152921509576240080 (0x100000012832EBD0);//ML01
            val_12;
            // 0x00E5A3F8: B #0xe5a404                |  goto label_24;                         
            goto label_24;
            // 0x00E5A3FC: MOV x19, x0                | X19 = 1152921509576240080 (0x100000012832EBD0);//ML01
            val_11 = val_12;
            // 0x00E5A400: ADD x0, sp, #8             | X0 = (1152921509576240080 + 8) = 1152921509576240088 (0x100000012832EBD8);
            label_24:
            // 0x00E5A404: BL #0x299a140              | 
            // 0x00E5A408: MOV x0, x19                | X0 = 1152921509576240080 (0x100000012832EBD0);//ML01
            // 0x00E5A40C: BL #0x980800               | X0 = sub_980800( ?? 0x100000012832EBD0, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A984 (15051140), len: 56  VirtAddr: 0x00E5A984 RVA: 0x00E5A984 token: 100664626 methodIndex: 19378 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.Cil.Instruction GetInstruction(int offset)
        {
            //
            // Disasemble & Code
            // 0x00E5A984: STP x20, x19, [sp, #-0x20]! | stack[1152921509576372640] = ???;  stack[1152921509576372648] = ???;  //  dest_result_addr=1152921509576372640 |  dest_result_addr=1152921509576372648
            // 0x00E5A988: STP x29, x30, [sp, #0x10]  | stack[1152921509576372656] = ???;  stack[1152921509576372664] = ???;  //  dest_result_addr=1152921509576372656 |  dest_result_addr=1152921509576372664
            // 0x00E5A98C: ADD x29, sp, #0x10         | X29 = (1152921509576372640 + 16) = 1152921509576372656 (0x100000012834F1B0);
            // 0x00E5A990: LDR x20, [x0, #0x58]       | X20 = this.body; //P2                   
            // 0x00E5A994: MOV w19, w1                | W19 = offset;//m1                       
            // 0x00E5A998: CBNZ x20, #0xe5a9a0        | if (this.body != null) goto label_0;    
            if(this.body != null)
            {
                goto label_0;
            }
            // 0x00E5A99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E5A9A0: MOV x0, x20                | X0 = this.body;//m1                     
            // 0x00E5A9A4: BL #0xe5a9bc               | X0 = this.body.get_Instructions();      
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.Instruction> val_1 = this.body.Instructions;
            // 0x00E5A9A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A9AC: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00E5A9B0: MOV w2, w19                | W2 = offset;//m1                        
            // 0x00E5A9B4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5A9B8: B #0xe5aa34                | return ILRuntime.Mono.Cecil.Cil.CodeReader.GetInstruction(instructions:  ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.Instruction> val_1 = this.body.Instructions, offset:  val_1);
            return ILRuntime.Mono.Cecil.Cil.CodeReader.GetInstruction(instructions:  val_1, offset:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5AA34 (15051316), len: 296  VirtAddr: 0x00E5AA34 RVA: 0x00E5AA34 token: 100664627 methodIndex: 19379 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Mono.Cecil.Cil.Instruction GetInstruction(ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.Instruction> instructions, int offset)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00E5AA34: STP x24, x23, [sp, #-0x40]! | stack[1152921509576496896] = ???;  stack[1152921509576496904] = ???;  //  dest_result_addr=1152921509576496896 |  dest_result_addr=1152921509576496904
            // 0x00E5AA38: STP x22, x21, [sp, #0x10]  | stack[1152921509576496912] = ???;  stack[1152921509576496920] = ???;  //  dest_result_addr=1152921509576496912 |  dest_result_addr=1152921509576496920
            // 0x00E5AA3C: STP x20, x19, [sp, #0x20]  | stack[1152921509576496928] = ???;  stack[1152921509576496936] = ???;  //  dest_result_addr=1152921509576496928 |  dest_result_addr=1152921509576496936
            // 0x00E5AA40: STP x29, x30, [sp, #0x30]  | stack[1152921509576496944] = ???;  stack[1152921509576496952] = ???;  //  dest_result_addr=1152921509576496944 |  dest_result_addr=1152921509576496952
            // 0x00E5AA44: ADD x29, sp, #0x30         | X29 = (1152921509576496896 + 48) = 1152921509576496944 (0x100000012836D730);
            // 0x00E5AA48: MOV w19, w2                | W19 = W2;//m1                           
            // 0x00E5AA4C: MOV x20, x1                | X20 = offset;//m1                       
            // 0x00E5AA50: CBZ x20, #0xe5aa5c         | if (offset == 0) goto label_0;          
            if(offset == 0)
            {
                goto label_0;
            }
            // 0x00E5AA54: LDR w22, [x20, #0x18]      | W22 = offset + 24;                      
            val_7 = mem[offset + 24];
            val_7 = offset + 24;
            // 0x00E5AA58: B #0xe5aa6c                |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x00E5AA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? instructions, ????);
            // 0x00E5AA60: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x00E5AA64: LDR w22, [x8]              | W22 = 0x9814C0;                         
            val_7 = 9966784;
            // 0x00E5AA68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? instructions, ????);
            label_1:
            // 0x00E5AA6C: LSR w8, w19, #0x1e         | W8 = (W2 >> 30);                        
            var val_1 = W2 >> 30;
            // 0x00E5AA70: TBNZ w8, #1, #0xe5ab40     | if (((W2 >> 30) & 0x2) != 0) goto label_14;
            if((val_1 & 2) != 0)
            {
                goto label_14;
            }
            // 0x00E5AA74: LDR x21, [x20, #0x10]      | X21 = offset + 16;                      
            // 0x00E5AA78: CBNZ x21, #0xe5aa80        | if (offset + 16 != 0) goto label_3;     
            if((offset + 16) != 0)
            {
                goto label_3;
            }
            // 0x00E5AA7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? instructions, ????);
            label_3:
            // 0x00E5AA80: LDR w8, [x21, #0x18]       | W8 = offset + 16 + 24;                  
            // 0x00E5AA84: SUB w22, w22, #1           | W22 = (val_7 - 1);                      
            val_7 = val_7 - 1;
            // 0x00E5AA88: SXTW x20, w22              | X20 = (long)(int)((val_7 - 1));         
            // 0x00E5AA8C: CMP w22, w8                | STATE = COMPARE((val_7 - 1), offset + 16 + 24)
            // 0x00E5AA90: B.LO #0xe5aaa0             | if (val_7 < offset + 16 + 24) goto label_4;
            if(val_7 < (offset + 16 + 24))
            {
                goto label_4;
            }
            // 0x00E5AA94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? instructions, ????);
            // 0x00E5AA98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5AA9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? instructions, ????);
            label_4:
            // 0x00E5AAA0: ADD x8, x21, x20, lsl #3   | X8 = (offset + 16 + ((long)(int)((val_7 - 1))) << 3);
            var val_2 = (offset + 16) + (((long)(int)((val_7 - 1))) << 3);
            // 0x00E5AAA4: LDR x20, [x8, #0x20]       | X20 = (offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32;
            // 0x00E5AAA8: CBNZ x20, #0xe5aab0        | if ((offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32 != 0) goto label_5;
            if(((offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32) != 0)
            {
                goto label_5;
            }
            // 0x00E5AAAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? instructions, ????);
            label_5:
            // 0x00E5AAB0: LDR w8, [x20, #0x10]       | W8 = (offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32 + 16;
            // 0x00E5AAB4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00E5AAB8: CMP w8, w19                | STATE = COMPARE((offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32 + 16, W2)
            // 0x00E5AABC: B.LT #0xe5ab44             | if ((offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32 + 16 < W2) goto label_16;
            if(((offset + 16 + ((long)(int)((val_7 - 1))) << 3) + 32 + 16) < W2)
            {
                goto label_16;
            }
            // 0x00E5AAC0: TBNZ w22, #0x1f, #0xe5ab44 | if (((val_7 - 1) & 0x80000000) != 0) goto label_16;
            if((val_7 & 2147483648) != 0)
            {
                goto label_16;
            }
            // 0x00E5AAC4: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_15:
            // 0x00E5AAC8: SUB w8, w22, w23           | W8 = ((val_7 - 1) - val_9);             
            var val_3 = val_7 - val_9;
            // 0x00E5AACC: CMP w8, #0                 | STATE = COMPARE(((val_7 - 1) - val_9), 0x0)
            // 0x00E5AAD0: CINC w8, w8, lt            | W8 = val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9);
            var val_4 = (val_3 < 0) ? (val_3 + 1) : (val_3);
            // 0x00E5AAD4: ADD w24, w23, w8, asr #1   | W24 = (val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1);
            var val_5 = val_9 + (val_4 >> 1);
            // 0x00E5AAD8: CBNZ x21, #0xe5aae0        | if (offset + 16 != 0) goto label_8;     
            if((offset + 16) != 0)
            {
                goto label_8;
            }
            // 0x00E5AADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? instructions, ????);
            label_8:
            // 0x00E5AAE0: LDR w8, [x21, #0x18]       | W8 = offset + 16 + 24;                  
            // 0x00E5AAE4: SXTW x20, w24              | X20 = (long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1));
            // 0x00E5AAE8: CMP w24, w8                | STATE = COMPARE((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1), offset + 16 + 24)
            // 0x00E5AAEC: B.LO #0xe5aafc             | if (val_5 < offset + 16 + 24) goto label_9;
            if(val_5 < (offset + 16 + 24))
            {
                goto label_9;
            }
            // 0x00E5AAF0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? instructions, ????);
            // 0x00E5AAF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5AAF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? instructions, ????);
            label_9:
            // 0x00E5AAFC: ADD x8, x21, x20, lsl #3   | X8 = (offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 
            var val_6 = (offset + 16) + (((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3);
            // 0x00E5AB00: LDR x20, [x8, #0x20]       | X20 = (offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32;
            val_8 = mem[(offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32];
            val_8 = (offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32;
            // 0x00E5AB04: CBNZ x20, #0xe5ab0c        | if ((offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 != 0) goto label_10;
            if(val_8 != 0)
            {
                goto label_10;
            }
            // 0x00E5AB08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? instructions, ????);
            label_10:
            // 0x00E5AB0C: LDR w8, [x20, #0x10]       | W8 = (offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 + 16;
            // 0x00E5AB10: CMP w8, w19                | STATE = COMPARE((offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 + 16, W2)
            // 0x00E5AB14: B.EQ #0xe5ab44             | if ((offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 + 16 == W2) goto label_16;
            if(((offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 + 16) == W2)
            {
                goto label_16;
            }
            // 0x00E5AB18: B.GT #0xe5ab2c             | if ((offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 + 16 > W2) goto label_12;
            if(((offset + 16 + ((long)(int)((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1))) << 3) + 32 + 16) > W2)
            {
                goto label_12;
            }
            // 0x00E5AB1C: ADD w23, w24, #1           | W23 = ((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1) + 1);
            val_9 = val_5 + 1;
            // 0x00E5AB20: CMP w22, w23               | STATE = COMPARE((val_7 - 1), ((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1) + 1))
            // 0x00E5AB24: B.GE #0xe5aac8             | if (val_7 >= val_9) goto label_15;      
            if(val_7 >= val_9)
            {
                goto label_15;
            }
            // 0x00E5AB28: B #0xe5ab40                |  goto label_14;                         
            goto label_14;
            label_12:
            // 0x00E5AB2C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00E5AB30: SUB w22, w24, #1           | W22 = ((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1) - 1);
            val_7 = val_5 - 1;
            // 0x00E5AB34: CMP w22, w23               | STATE = COMPARE(((val_9 + ((int)val_3 < 0x0 ? (((val_7 - 1) - val_9) + 1) : ((val_7 - 1) - val_9)) >> 1) - 1), 0x0)
            // 0x00E5AB38: B.GE #0xe5aac8             | if (val_7 >= val_9) goto label_15;      
            if(val_7 >= val_9)
            {
                goto label_15;
            }
            // 0x00E5AB3C: B #0xe5ab44                |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x00E5AB40: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_16:
            // 0x00E5AB44: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00E5AB48: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5AB4C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5AB50: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5AB54: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5AB58: RET                        |  return (ILRuntime.Mono.Cecil.Cil.Instruction)null;
            return (ILRuntime.Mono.Cecil.Cil.Instruction)val_8;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.Cil.Instruction, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E59908 (15046920), len: 92  VirtAddr: 0x00E59908 RVA: 0x00E59908 token: 100664628 methodIndex: 19380 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadSection()
        {
            //
            // Disasemble & Code
            // 0x00E59908: STP x20, x19, [sp, #-0x20]! | stack[1152921509576613024] = ???;  stack[1152921509576613032] = ???;  //  dest_result_addr=1152921509576613024 |  dest_result_addr=1152921509576613032
            // 0x00E5990C: STP x29, x30, [sp, #0x10]  | stack[1152921509576613040] = ???;  stack[1152921509576613048] = ???;  //  dest_result_addr=1152921509576613040 |  dest_result_addr=1152921509576613048
            // 0x00E59910: ADD x29, sp, #0x10         | X29 = (1152921509576613024 + 16) = 1152921509576613040 (0x1000000128389CB0);
            // 0x00E59914: MOV x19, x0                | X19 = 1152921509576625056 (0x100000012838CBA0);//ML01
            label_2:
            // 0x00E59918: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5991C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00E59920: MOV x0, x19                | X0 = 1152921509576625056 (0x100000012838CBA0);//ML01
            // 0x00E59924: BL #0x11e0760              | this.Align(align:  4);                  
            this.Align(align:  4);
            // 0x00E59928: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5992C: MOV x0, x19                | X0 = 1152921509576625056 (0x100000012838CBA0);//ML01
            // 0x00E59930: LDP x9, x1, [x8, #0x1e0]   | X9 = public System.Byte System.IO.BinaryReader::ReadByte(); X1 = public System.Byte System.IO.BinaryReader::ReadByte(); //  | 
            // 0x00E59934: BLR x9                     | X0 = this.ReadByte();                   
            byte val_1 = this.ReadByte();
            // 0x00E59938: SXTB w20, w0               | W20 = (int)(sbyte)((val_1) & 0xFF);     
            // 0x00E5993C: TBNZ w0, #6, #0xe5994c     | if ((val_1 & 0x40) != 0) goto label_0;  
            if((val_1 & 64) != 0)
            {
                goto label_0;
            }
            // 0x00E59940: MOV x0, x19                | X0 = 1152921509576625056 (0x100000012838CBA0);//ML01
            // 0x00E59944: BL #0xe5ab5c               | this.ReadSmallSection();                
            this.ReadSmallSection();
            // 0x00E59948: B #0xe59954                |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x00E5994C: MOV x0, x19                | X0 = 1152921509576625056 (0x100000012838CBA0);//ML01
            // 0x00E59950: BL #0xe5ac50               | this.ReadFatSection();                  
            this.ReadFatSection();
            label_1:
            // 0x00E59954: TBNZ w20, #0x1f, #0xe59918 | if (((int)(sbyte)((val_1) & 0xFF) & 0x80000000) != 0) goto label_2;
            if((((int)val_1 & 255) & 2147483648) != 0)
            {
                goto label_2;
            }
            // 0x00E59958: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5995C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E59960: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5AB5C (15051612), len: 244  VirtAddr: 0x00E5AB5C RVA: 0x00E5AB5C token: 100664629 methodIndex: 19381 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadSmallSection()
        {
            //
            // Disasemble & Code
            // 0x00E5AB5C: STP x24, x23, [sp, #-0x40]! | stack[1152921509576728064] = ???;  stack[1152921509576728072] = ???;  //  dest_result_addr=1152921509576728064 |  dest_result_addr=1152921509576728072
            // 0x00E5AB60: STP x22, x21, [sp, #0x10]  | stack[1152921509576728080] = ???;  stack[1152921509576728088] = ???;  //  dest_result_addr=1152921509576728080 |  dest_result_addr=1152921509576728088
            // 0x00E5AB64: STP x20, x19, [sp, #0x20]  | stack[1152921509576728096] = ???;  stack[1152921509576728104] = ???;  //  dest_result_addr=1152921509576728096 |  dest_result_addr=1152921509576728104
            // 0x00E5AB68: STP x29, x30, [sp, #0x30]  | stack[1152921509576728112] = ???;  stack[1152921509576728120] = ???;  //  dest_result_addr=1152921509576728112 |  dest_result_addr=1152921509576728120
            // 0x00E5AB6C: ADD x29, sp, #0x30         | X29 = (1152921509576728064 + 48) = 1152921509576728112 (0x10000001283A5E30);
            // 0x00E5AB70: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E5AB74: LDRB w8, [x20, #0xae3]     | W8 = (bool)static_value_03734AE3;       
            // 0x00E5AB78: MOV x19, x0                | X19 = 1152921509576740128 (0x10000001283A8D20);//ML01
            // 0x00E5AB7C: TBNZ w8, #0, #0xe5ab98     | if (static_value_03734AE3 == true) goto label_0;
            // 0x00E5AB80: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E5AB84: LDR x8, [x8, #0x6f8]       | X8 = 0x2B90DD0;                         
            // 0x00E5AB88: LDR w0, [x8]               | W0 = 0x1A38;                            
            // 0x00E5AB8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A38, ????);     
            // 0x00E5AB90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5AB94: STRB w8, [x20, #0xae3]     | static_value_03734AE3 = true;            //  dest_result_addr=57887459
            label_0:
            // 0x00E5AB98: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5AB9C: MOV x0, x19                | X0 = 1152921509576740128 (0x10000001283A8D20);//ML01
            // 0x00E5ABA0: LDP x9, x1, [x8, #0x1e0]   | X9 = public System.Byte System.IO.BinaryReader::ReadByte(); X1 = public System.Byte System.IO.BinaryReader::ReadByte(); //  | 
            // 0x00E5ABA4: BLR x9                     | X0 = this.ReadByte();                   
            byte val_1 = this.ReadByte();
            // 0x00E5ABA8: MOVZ w9, #0xaaaa, lsl #16  | W9 = 2863267840 (0xAAAA0000);//ML01     
            // 0x00E5ABAC: AND w8, w0, #0xff          | W8 = (val_1 & 255);                     
            byte val_2 = val_1 & 255;
            // 0x00E5ABB0: MOVK w9, #0xaaab           | W9 = 2863311531 (0xAAAAAAAB);           
            // 0x00E5ABB4: MUL x8, x8, x9             | X8 = ((val_1 & 255) * 2863311531);      
            val_2 = val_2 * 2863311531;
            // 0x00E5ABB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5ABBC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00E5ABC0: MOV x0, x19                | X0 = 1152921509576740128 (0x10000001283A8D20);//ML01
            // 0x00E5ABC4: LSR x20, x8, #0x23         | X20 = (((val_1 & 255) * 2863311531) >> 35);
            byte val_3 = val_2 >> 35;
            // 0x00E5ABC8: BL #0x11e06c0              | this.Advance(bytes:  2);                
            this.Advance(bytes:  2);
            // 0x00E5ABCC: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00E5ABD0: ADRP x23, #0x360d000       | X23 = 56676352 (0x360D000);             
            // 0x00E5ABD4: LDR x8, [x8, #0x9e8]       | X8 = 1152921509576713056;               
            // 0x00E5ABD8: LDR x23, [x23, #0x7f0]     | X23 = 1152921504688050176;              
            // 0x00E5ABDC: LDR x21, [x8]              | X21 = System.Int32 ILRuntime.Mono.Cecil.Cil.CodeReader::<ReadSmallSection>b__26_0();
            // 0x00E5ABE0: LDR x0, [x23]              | X0 = typeof(System.Func<TResult>);      
            System.Func<System.Int32> val_4 = null;
            // 0x00E5ABE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
            // 0x00E5ABE8: ADRP x24, #0x35bd000       | X24 = 56348672 (0x35BD000);             
            // 0x00E5ABEC: LDR x24, [x24, #0x6c8]     | X24 = 1152921509576714080;              
            // 0x00E5ABF0: MOV x1, x19                | X1 = 1152921509576740128 (0x10000001283A8D20);//ML01
            // 0x00E5ABF4: MOV x2, x21                | X2 = 1152921509576713056 (0x10000001283A2360);//ML01
            // 0x00E5ABF8: MOV x22, x0                | X22 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5ABFC: LDR x3, [x24]              | X3 = public System.Void System.Func<System.Int32>::.ctor(object object, IntPtr method);
            // 0x00E5AC00: BL #0x2258fe8              | .ctor(object:  this, method:  System.Int32 ILRuntime.Mono.Cecil.Cil.CodeReader::<ReadSmallSection>b__26_0());
            val_4 = new System.Func<System.Int32>(object:  this, method:  System.Int32 ILRuntime.Mono.Cecil.Cil.CodeReader::<ReadSmallSection>b__26_0());
            // 0x00E5AC04: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00E5AC08: LDR x8, [x8, #0x690]       | X8 = 1152921509576715104;               
            // 0x00E5AC0C: LDR x0, [x23]              | X0 = typeof(System.Func<TResult>);      
            System.Func<System.Int32> val_5 = null;
            // 0x00E5AC10: LDR x21, [x8]              | X21 = System.Int32 ILRuntime.Mono.Cecil.Cil.CodeReader::<ReadSmallSection>b__26_1();
            // 0x00E5AC14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
            // 0x00E5AC18: LDR x3, [x24]              | X3 = public System.Void System.Func<System.Int32>::.ctor(object object, IntPtr method);
            // 0x00E5AC1C: MOV x1, x19                | X1 = 1152921509576740128 (0x10000001283A8D20);//ML01
            // 0x00E5AC20: MOV x2, x21                | X2 = 1152921509576715104 (0x10000001283A2B60);//ML01
            // 0x00E5AC24: MOV x23, x0                | X23 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AC28: BL #0x2258fe8              | .ctor(object:  this, method:  System.Int32 ILRuntime.Mono.Cecil.Cil.CodeReader::<ReadSmallSection>b__26_1());
            val_5 = new System.Func<System.Int32>(object:  this, method:  System.Int32 ILRuntime.Mono.Cecil.Cil.CodeReader::<ReadSmallSection>b__26_1());
            // 0x00E5AC2C: MOV x0, x19                | X0 = 1152921509576740128 (0x10000001283A8D20);//ML01
            // 0x00E5AC30: MOV w1, w20                | W1 = (((val_1 & 255) * 2863311531) >> 35);//m1
            // 0x00E5AC34: MOV x2, x22                | X2 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AC38: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5AC3C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5AC40: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5AC44: MOV x3, x23                | X3 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AC48: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5AC4C: B #0xe5ad5c                | this.ReadExceptionHandlers(count:  val_3, read_entry:  val_4, read_length:  val_5); return;
            this.ReadExceptionHandlers(count:  val_3, read_entry:  val_4, read_length:  val_5);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5AC50 (15051856), len: 268  VirtAddr: 0x00E5AC50 RVA: 0x00E5AC50 token: 100664630 methodIndex: 19382 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadFatSection()
        {
            //
            // Disasemble & Code
            // 0x00E5AC50: STP x24, x23, [sp, #-0x40]! | stack[1152921509576840064] = ???;  stack[1152921509576840072] = ???;  //  dest_result_addr=1152921509576840064 |  dest_result_addr=1152921509576840072
            // 0x00E5AC54: STP x22, x21, [sp, #0x10]  | stack[1152921509576840080] = ???;  stack[1152921509576840088] = ???;  //  dest_result_addr=1152921509576840080 |  dest_result_addr=1152921509576840088
            // 0x00E5AC58: STP x20, x19, [sp, #0x20]  | stack[1152921509576840096] = ???;  stack[1152921509576840104] = ???;  //  dest_result_addr=1152921509576840096 |  dest_result_addr=1152921509576840104
            // 0x00E5AC5C: STP x29, x30, [sp, #0x30]  | stack[1152921509576840112] = ???;  stack[1152921509576840120] = ???;  //  dest_result_addr=1152921509576840112 |  dest_result_addr=1152921509576840120
            // 0x00E5AC60: ADD x29, sp, #0x30         | X29 = (1152921509576840064 + 48) = 1152921509576840112 (0x10000001283C13B0);
            // 0x00E5AC64: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E5AC68: LDRB w8, [x20, #0xae4]     | W8 = (bool)static_value_03734AE4;       
            // 0x00E5AC6C: MOV x19, x0                | X19 = 1152921509576852128 (0x10000001283C42A0);//ML01
            // 0x00E5AC70: TBNZ w8, #0, #0xe5ac8c     | if (static_value_03734AE4 == true) goto label_0;
            // 0x00E5AC74: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x00E5AC78: LDR x8, [x8, #0x410]       | X8 = 0x2B90DB0;                         
            // 0x00E5AC7C: LDR w0, [x8]               | W0 = 0x1A30;                            
            // 0x00E5AC80: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A30, ????);     
            // 0x00E5AC84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5AC88: STRB w8, [x20, #0xae4]     | static_value_03734AE4 = true;            //  dest_result_addr=57887460
            label_0:
            // 0x00E5AC8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5AC90: MOVN w1, #0                | W1 = 0 (0x0);//ML01                     
            // 0x00E5AC94: MOV x0, x19                | X0 = 1152921509576852128 (0x10000001283C42A0);//ML01
            // 0x00E5AC98: BL #0x11e06c0              | this.Advance(bytes:  0);                
            this.Advance(bytes:  0);
            // 0x00E5AC9C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5ACA0: MOV x0, x19                | X0 = 1152921509576852128 (0x10000001283C42A0);//ML01
            // 0x00E5ACA4: LDR x9, [x8, #0x240]       | X9 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E5ACA8: LDR x1, [x8, #0x248]       | X1 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E5ACAC: BLR x9                     | X0 = this.ReadInt32();                  
            int val_1 = this.ReadInt32();
            // 0x00E5ACB0: ASR w8, w0, #8             | W8 = (val_1 >> 8);                      
            int val_2 = val_1 >> 8;
            // 0x00E5ACB4: MOVZ w9, #0x2aaa, lsl #16  | W9 = 715784192 (0x2AAA0000);//ML01      
            // 0x00E5ACB8: MOVK w9, #0xaaab           | W9 = 715827883 (0x2AAAAAAB);            
            // 0x00E5ACBC: SXTW x8, w8                | X8 = (long)(int)((val_1 >> 8));         
            var val_7 = (long)val_2;
            // 0x00E5ACC0: MUL x8, x8, x9             | X8 = ((long)(int)((val_1 >> 8)) * 715827883);
            val_7 = val_7 * 715827883;
            // 0x00E5ACC4: LSR x9, x8, #0x3f          | X9 = (((long)(int)((val_1 >> 8)) * 715827883) >> 63);
            var val_3 = val_7 >> 63;
            // 0x00E5ACC8: ASR x8, x8, #0x22          | X8 = (((long)(int)((val_1 >> 8)) * 715827883) >> 34);
            val_7 = val_7 >> 34;
            // 0x00E5ACCC: ADD w20, w8, w9            | W20 = ((((long)(int)((val_1 >> 8)) * 715827883) >> 34) + (((long)(int)((val_1 >> 8)) * 715827883) >>
            int val_4 = val_7 + val_3;
            // 0x00E5ACD0: CBNZ x19, #0xe5acd8        | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x00E5ACD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00E5ACD8: ADRP x23, #0x360d000       | X23 = 56676352 (0x360D000);             
            // 0x00E5ACDC: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5ACE0: LDR x23, [x23, #0x7f0]     | X23 = 1152921504688050176;              
            // 0x00E5ACE4: LDR x22, [x8, #0x248]      | X22 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E5ACE8: LDR x0, [x23]              | X0 = typeof(System.Func<TResult>);      
            System.Func<System.Int32> val_5 = null;
            // 0x00E5ACEC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
            // 0x00E5ACF0: ADRP x24, #0x35bd000       | X24 = 56348672 (0x35BD000);             
            // 0x00E5ACF4: LDR x24, [x24, #0x6c8]     | X24 = 1152921509576714080;              
            // 0x00E5ACF8: MOV x1, x19                | X1 = 1152921509576852128 (0x10000001283C42A0);//ML01
            // 0x00E5ACFC: MOV x2, x22                | X2 = 31880840 (0x1E67688);//ML01        
            // 0x00E5AD00: MOV x21, x0                | X21 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AD04: LDR x3, [x24]              | X3 = public System.Void System.Func<System.Int32>::.ctor(object object, IntPtr method);
            // 0x00E5AD08: BL #0x2258fe8              | .ctor(object:  this, method:  public System.Int32 System.IO.BinaryReader::ReadInt32());
            val_5 = new System.Func<System.Int32>(object:  this, method:  public System.Int32 System.IO.BinaryReader::ReadInt32());
            // 0x00E5AD0C: CBNZ x19, #0xe5ad14        | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x00E5AD10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  public System.Int32 System.IO.BinaryReader::ReadInt32()), ????);
            label_2:
            // 0x00E5AD14: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5AD18: LDR x0, [x23]              | X0 = typeof(System.Func<TResult>);      
            System.Func<System.Int32> val_6 = null;
            // 0x00E5AD1C: LDR x22, [x8, #0x248]      | X22 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E5AD20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Func<TResult>), ????);
            // 0x00E5AD24: LDR x3, [x24]              | X3 = public System.Void System.Func<System.Int32>::.ctor(object object, IntPtr method);
            // 0x00E5AD28: MOV x1, x19                | X1 = 1152921509576852128 (0x10000001283C42A0);//ML01
            // 0x00E5AD2C: MOV x2, x22                | X2 = 31880840 (0x1E67688);//ML01        
            // 0x00E5AD30: MOV x23, x0                | X23 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AD34: BL #0x2258fe8              | .ctor(object:  this, method:  public System.Int32 System.IO.BinaryReader::ReadInt32());
            val_6 = new System.Func<System.Int32>(object:  this, method:  public System.Int32 System.IO.BinaryReader::ReadInt32());
            // 0x00E5AD38: MOV x0, x19                | X0 = 1152921509576852128 (0x10000001283C42A0);//ML01
            // 0x00E5AD3C: MOV w1, w20                | W1 = ((((long)(int)((val_1 >> 8)) * 715827883) >> 34) + (((long)(int)((val_1 >> 8)) * 715827883) >> 63));//m1
            // 0x00E5AD40: MOV x2, x21                | X2 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AD44: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5AD48: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5AD4C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5AD50: MOV x3, x23                | X3 = 1152921504688050176 (0x1000000004D71000);//ML01
            // 0x00E5AD54: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5AD58: B #0xe5ad5c                | this.ReadExceptionHandlers(count:  val_4, read_entry:  val_5, read_length:  val_6); return;
            this.ReadExceptionHandlers(count:  val_4, read_entry:  val_5, read_length:  val_6);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5AD5C (15052124), len: 492  VirtAddr: 0x00E5AD5C RVA: 0x00E5AD5C token: 100664631 methodIndex: 19383 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadExceptionHandlers(int count, System.Func<int> read_entry, System.Func<int> read_length)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Cecil.Cil.ExceptionHandler val_14;
            //  | 
            var val_15;
            //  | 
            ILRuntime.Mono.Cecil.Cil.Instruction val_16;
            // 0x00E5AD5C: STP x28, x27, [sp, #-0x60]! | stack[1152921509576986848] = ???;  stack[1152921509576986856] = ???;  //  dest_result_addr=1152921509576986848 |  dest_result_addr=1152921509576986856
            // 0x00E5AD60: STP x26, x25, [sp, #0x10]  | stack[1152921509576986864] = ???;  stack[1152921509576986872] = ???;  //  dest_result_addr=1152921509576986864 |  dest_result_addr=1152921509576986872
            // 0x00E5AD64: STP x24, x23, [sp, #0x20]  | stack[1152921509576986880] = ???;  stack[1152921509576986888] = ???;  //  dest_result_addr=1152921509576986880 |  dest_result_addr=1152921509576986888
            // 0x00E5AD68: STP x22, x21, [sp, #0x30]  | stack[1152921509576986896] = ???;  stack[1152921509576986904] = ???;  //  dest_result_addr=1152921509576986896 |  dest_result_addr=1152921509576986904
            // 0x00E5AD6C: STP x20, x19, [sp, #0x40]  | stack[1152921509576986912] = ???;  stack[1152921509576986920] = ???;  //  dest_result_addr=1152921509576986912 |  dest_result_addr=1152921509576986920
            // 0x00E5AD70: STP x29, x30, [sp, #0x50]  | stack[1152921509576986928] = ???;  stack[1152921509576986936] = ???;  //  dest_result_addr=1152921509576986928 |  dest_result_addr=1152921509576986936
            // 0x00E5AD74: ADD x29, sp, #0x50         | X29 = (1152921509576986848 + 80) = 1152921509576986928 (0x10000001283E5130);
            // 0x00E5AD78: ADRP x23, #0x3734000       | X23 = 57884672 (0x3734000);             
            // 0x00E5AD7C: LDRB w8, [x23, #0xae5]     | W8 = (bool)static_value_03734AE5;       
            // 0x00E5AD80: MOV x19, x3                | X19 = read_length;//m1                  
            // 0x00E5AD84: MOV x20, x2                | X20 = read_entry;//m1                   
            // 0x00E5AD88: MOV w21, w1                | W21 = count;//m1                        
            val_15 = count;
            // 0x00E5AD8C: MOV x22, x0                | X22 = 1152921509576998944 (0x10000001283E8020);//ML01
            // 0x00E5AD90: TBNZ w8, #0, #0xe5adac     | if (static_value_03734AE5 == true) goto label_0;
            // 0x00E5AD94: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00E5AD98: LDR x8, [x8, #0x878]       | X8 = 0x2B90DA8;                         
            // 0x00E5AD9C: LDR w0, [x8]               | W0 = 0x1A2E;                            
            // 0x00E5ADA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2E, ????);     
            // 0x00E5ADA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5ADA8: STRB w8, [x23, #0xae5]     | static_value_03734AE5 = true;            //  dest_result_addr=57887461
            label_0:
            // 0x00E5ADAC: CMP w21, #1                | STATE = COMPARE(count, 0x1)             
            // 0x00E5ADB0: B.LT #0xe5af2c             | if (val_15 < 1) goto label_1;           
            if(val_15 < 1)
            {
                goto label_1;
            }
            // 0x00E5ADB4: ADRP x25, #0x3664000       | X25 = 57032704 (0x3664000);             
            // 0x00E5ADB8: ADRP x26, #0x3653000       | X26 = 56963072 (0x3653000);             
            // 0x00E5ADBC: ADRP x28, #0x367f000       | X28 = 57143296 (0x367F000);             
            // 0x00E5ADC0: LDR x25, [x25, #0x678]     | X25 = 1152921509576948320;              
            // 0x00E5ADC4: LDR x26, [x26, #0x3e0]     | X26 = 1152921504746409984;              
            // 0x00E5ADC8: LDR x28, [x28, #0x2a0]     | X28 = 1152921509576949344;              
            // 0x00E5ADCC: ORR w27, wzr, #0x10        | W27 = 16(0x10);                         
            label_15:
            // 0x00E5ADD0: CBNZ x20, #0xe5add8        | if (read_entry != null) goto label_2;   
            if(read_entry != null)
            {
                goto label_2;
            }
            // 0x00E5ADD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2E, ????);     
            label_2:
            // 0x00E5ADD8: LDR x1, [x25]              | X1 = public System.Int32 System.Func<System.Int32>::Invoke();
            // 0x00E5ADDC: MOV x0, x20                | X0 = read_entry;//m1                    
            // 0x00E5ADE0: BL #0x2258ff8              | X0 = read_entry.Invoke();               
            int val_1 = read_entry.Invoke();
            // 0x00E5ADE4: LDR x8, [x26]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler);
            // 0x00E5ADE8: MOV w24, w0                | W24 = val_1;//m1                        
            int val_14 = val_1;
            // 0x00E5ADEC: MOV x0, x8                 | X0 = 1152921504746409984 (0x1000000008519000);//ML01
            object val_2 = null;
            // 0x00E5ADF0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler), ????);
            // 0x00E5ADF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5ADF8: MOV x23, x0                | X23 = 1152921504746409984 (0x1000000008519000);//ML01
            val_14 = val_2;
            // 0x00E5ADFC: AND w24, w24, #7           | W24 = (val_1 & 7);                      
            val_14 = val_14 & 7;
            // 0x00E5AE00: BL #0x16f59f0              | .ctor();                                
            val_2 = new System.Object();
            // 0x00E5AE04: STR w24, [x23, #0x40]      | typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_40 = (val_1 & 7);  //  dest_result_addr=1152921504746410048
            typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_40 = val_14;
            // 0x00E5AE08: CBNZ x20, #0xe5ae10        | if (read_entry != null) goto label_3;   
            if(read_entry != null)
            {
                goto label_3;
            }
            // 0x00E5AE0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x00E5AE10: LDR x1, [x25]              | X1 = public System.Int32 System.Func<System.Int32>::Invoke();
            // 0x00E5AE14: MOV x0, x20                | X0 = read_entry;//m1                    
            // 0x00E5AE18: BL #0x2258ff8              | X0 = read_entry.Invoke();               
            int val_3 = read_entry.Invoke();
            // 0x00E5AE1C: MOV w1, w0                 | W1 = val_3;//m1                         
            // 0x00E5AE20: MOV x0, x22                | X0 = 1152921509576998944 (0x10000001283E8020);//ML01
            // 0x00E5AE24: BL #0xe5a984               | X0 = this.GetInstruction(offset:  val_3);
            ILRuntime.Mono.Cecil.Cil.Instruction val_4 = this.GetInstruction(offset:  val_3);
            // 0x00E5AE28: MOV x24, x0                | X24 = val_4;//m1                        
            val_16 = val_4;
            // 0x00E5AE2C: CBZ x23, #0xe5ae38         | if ( == 0) goto label_4;                
            if(null == 0)
            {
                goto label_4;
            }
            // 0x00E5AE30: STR x24, [x23, #0x10]      | typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_10 = val_4;  //  dest_result_addr=1152921504746410000
            typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_10 = val_16;
            // 0x00E5AE34: B #0xe5ae48                |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x00E5AE38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00E5AE3C: STR x24, [x27]             | mem[16] = val_4;                         //  dest_result_addr=16
            mem[16] = val_16;
            // 0x00E5AE40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00E5AE44: LDR x24, [x27]             | X24 = val_4;                            
            val_16 = mem[16];
            label_5:
            // 0x00E5AE48: CBNZ x24, #0xe5ae50        | if (val_4 != 0) goto label_6;           
            if(val_16 != 0)
            {
                goto label_6;
            }
            // 0x00E5AE4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x00E5AE50: LDR w24, [x24, #0x10]      | W24 = val_4 + 16;                       
            // 0x00E5AE54: CBNZ x19, #0xe5ae5c        | if (read_length != null) goto label_7;  
            if(read_length != null)
            {
                goto label_7;
            }
            // 0x00E5AE58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_7:
            // 0x00E5AE5C: LDR x1, [x25]              | X1 = public System.Int32 System.Func<System.Int32>::Invoke();
            // 0x00E5AE60: MOV x0, x19                | X0 = read_length;//m1                   
            // 0x00E5AE64: BL #0x2258ff8              | X0 = read_length.Invoke();              
            int val_5 = read_length.Invoke();
            // 0x00E5AE68: ADD w1, w0, w24            | W1 = (val_5 + val_4 + 16);              
            int val_6 = val_5 + (val_4 + 16);
            // 0x00E5AE6C: MOV x0, x22                | X0 = 1152921509576998944 (0x10000001283E8020);//ML01
            // 0x00E5AE70: BL #0xe5a984               | X0 = this.GetInstruction(offset:  int val_6 = val_5 + (val_4 + 16));
            ILRuntime.Mono.Cecil.Cil.Instruction val_7 = this.GetInstruction(offset:  val_6);
            // 0x00E5AE74: MOV x24, x0                | X24 = val_7;//m1                        
            // 0x00E5AE78: CBNZ x23, #0xe5ae80        | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x00E5AE7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_8:
            // 0x00E5AE80: STR x24, [x23, #0x18]      | typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_18 = val_7;  //  dest_result_addr=1152921504746410008
            typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_18 = val_7;
            // 0x00E5AE84: CBNZ x20, #0xe5ae8c        | if (read_entry != null) goto label_9;   
            if(read_entry != null)
            {
                goto label_9;
            }
            // 0x00E5AE88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_9:
            // 0x00E5AE8C: LDR x1, [x25]              | X1 = public System.Int32 System.Func<System.Int32>::Invoke();
            // 0x00E5AE90: MOV x0, x20                | X0 = read_entry;//m1                    
            // 0x00E5AE94: BL #0x2258ff8              | X0 = read_entry.Invoke();               
            int val_8 = read_entry.Invoke();
            // 0x00E5AE98: MOV w1, w0                 | W1 = val_8;//m1                         
            // 0x00E5AE9C: MOV x0, x22                | X0 = 1152921509576998944 (0x10000001283E8020);//ML01
            // 0x00E5AEA0: BL #0xe5a984               | X0 = this.GetInstruction(offset:  val_8);
            ILRuntime.Mono.Cecil.Cil.Instruction val_9 = this.GetInstruction(offset:  val_8);
            // 0x00E5AEA4: MOV x24, x0                | X24 = val_9;//m1                        
            // 0x00E5AEA8: STR x24, [x23, #0x28]      | typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_28 = val_9;  //  dest_result_addr=1152921504746410024
            typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_28 = val_9;
            // 0x00E5AEAC: CBNZ x24, #0xe5aeb4        | if (val_9 != null) goto label_10;       
            if(val_9 != null)
            {
                goto label_10;
            }
            // 0x00E5AEB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_10:
            // 0x00E5AEB4: LDR w24, [x24, #0x10]      | W24 = val_9.offset; //P2                
            // 0x00E5AEB8: CBNZ x19, #0xe5aec0        | if (read_length != null) goto label_11; 
            if(read_length != null)
            {
                goto label_11;
            }
            // 0x00E5AEBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_11:
            // 0x00E5AEC0: LDR x1, [x25]              | X1 = public System.Int32 System.Func<System.Int32>::Invoke();
            // 0x00E5AEC4: MOV x0, x19                | X0 = read_length;//m1                   
            // 0x00E5AEC8: BL #0x2258ff8              | X0 = read_length.Invoke();              
            int val_10 = read_length.Invoke();
            // 0x00E5AECC: ADD w1, w0, w24            | W1 = (val_10 + val_9.offset);           
            int val_11 = val_10 + val_9.offset;
            // 0x00E5AED0: MOV x0, x22                | X0 = 1152921509576998944 (0x10000001283E8020);//ML01
            // 0x00E5AED4: BL #0xe5a984               | X0 = this.GetInstruction(offset:  int val_11 = val_10 + val_9.offset);
            ILRuntime.Mono.Cecil.Cil.Instruction val_12 = this.GetInstruction(offset:  val_11);
            // 0x00E5AED8: MOV x24, x0                | X24 = val_12;//m1                       
            // 0x00E5AEDC: CBNZ x23, #0xe5aee4        | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x00E5AEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_12:
            // 0x00E5AEE4: MOV x0, x22                | X0 = 1152921509576998944 (0x10000001283E8020);//ML01
            // 0x00E5AEE8: MOV x1, x23                | X1 = 1152921504746409984 (0x1000000008519000);//ML01
            // 0x00E5AEEC: STR x24, [x23, #0x30]      | typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_30 = val_12;  //  dest_result_addr=1152921504746410032
            typeof(ILRuntime.Mono.Cecil.Cil.ExceptionHandler).__il2cppRuntimeField_30 = val_12;
            // 0x00E5AEF0: BL #0xe5afac               | this.ReadExceptionHandlerSpecific(handler:  val_14);
            this.ReadExceptionHandlerSpecific(handler:  val_14);
            // 0x00E5AEF4: LDR x24, [x22, #0x58]      | X24 = this.body; //P2                   
            // 0x00E5AEF8: CBNZ x24, #0xe5af00        | if (this.body != null) goto label_13;   
            if(this.body != null)
            {
                goto label_13;
            }
            // 0x00E5AEFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_13:
            // 0x00E5AF00: MOV x0, x24                | X0 = this.body;//m1                     
            // 0x00E5AF04: BL #0xe5b11c               | X0 = this.body.get_ExceptionHandlers(); 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.ExceptionHandler> val_13 = this.body.ExceptionHandlers;
            // 0x00E5AF08: MOV x24, x0                | X24 = val_13;//m1                       
            // 0x00E5AF0C: CBNZ x24, #0xe5af14        | if (val_13 != null) goto label_14;      
            if(val_13 != null)
            {
                goto label_14;
            }
            // 0x00E5AF10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_14:
            // 0x00E5AF14: LDR x2, [x28]              | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.ExceptionHandler>::Add(ILRuntime.Mono.Cecil.Cil.ExceptionHandler item);
            // 0x00E5AF18: MOV x0, x24                | X0 = val_13;//m1                        
            // 0x00E5AF1C: MOV x1, x23                | X1 = 1152921504746409984 (0x1000000008519000);//ML01
            // 0x00E5AF20: BL #0x1d47324              | val_13.Add(item:  val_14);              
            val_13.Add(item:  val_14);
            // 0x00E5AF24: SUB w21, w21, #1           | W21 = (count - 1);                      
            val_15 = val_15 - 1;
            // 0x00E5AF28: CBNZ w21, #0xe5add0        | if ((count - 1) != 0) goto label_15;    
            if(val_15 != 0)
            {
                goto label_15;
            }
            label_1:
            // 0x00E5AF2C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5AF30: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5AF34: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5AF38: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5AF3C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E5AF40: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E5AF44: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5AFAC (15052716), len: 368  VirtAddr: 0x00E5AFAC RVA: 0x00E5AFAC token: 100664632 methodIndex: 19384 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadExceptionHandlerSpecific(ILRuntime.Mono.Cecil.Cil.ExceptionHandler handler)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            ILRuntime.Mono.Cecil.MetadataReader val_8;
            //  | 
            ILRuntime.Mono.Cecil.TypeReference val_9;
            // 0x00E5AFAC: STP x22, x21, [sp, #-0x30]! | stack[1152921509577152144] = ???;  stack[1152921509577152152] = ???;  //  dest_result_addr=1152921509577152144 |  dest_result_addr=1152921509577152152
            // 0x00E5AFB0: STP x20, x19, [sp, #0x10]  | stack[1152921509577152160] = ???;  stack[1152921509577152168] = ???;  //  dest_result_addr=1152921509577152160 |  dest_result_addr=1152921509577152168
            // 0x00E5AFB4: STP x29, x30, [sp, #0x20]  | stack[1152921509577152176] = ???;  stack[1152921509577152184] = ???;  //  dest_result_addr=1152921509577152176 |  dest_result_addr=1152921509577152184
            // 0x00E5AFB8: ADD x29, sp, #0x20         | X29 = (1152921509577152144 + 32) = 1152921509577152176 (0x100000012840D6B0);
            // 0x00E5AFBC: SUB sp, sp, #0x10          | SP = (1152921509577152144 - 16) = 1152921509577152128 (0x100000012840D680);
            // 0x00E5AFC0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5AFC4: LDRB w8, [x21, #0xae6]     | W8 = (bool)static_value_03734AE6;       
            // 0x00E5AFC8: MOV x19, x1                | X19 = handler;//m1                      
            // 0x00E5AFCC: MOV x20, x0                | X20 = 1152921509577164192 (0x10000001284105A0);//ML01
            // 0x00E5AFD0: TBNZ w8, #0, #0xe5afec     | if (static_value_03734AE6 == true) goto label_0;
            // 0x00E5AFD4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E5AFD8: LDR x8, [x8, #0x5a8]       | X8 = 0x2B90DAC;                         
            // 0x00E5AFDC: LDR w0, [x8]               | W0 = 0x1A2F;                            
            // 0x00E5AFE0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2F, ????);     
            // 0x00E5AFE4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5AFE8: STRB w8, [x21, #0xae6]     | static_value_03734AE6 = true;            //  dest_result_addr=57887462
            label_0:
            // 0x00E5AFEC: CBNZ x19, #0xe5aff4        | if (handler != null) goto label_1;      
            if(handler != null)
            {
                goto label_1;
            }
            // 0x00E5AFF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2F, ????);     
            label_1:
            // 0x00E5AFF4: LDR w8, [x19, #0x40]       | W8 = handler.handler_type; //P2         
            // 0x00E5AFF8: CMP w8, #1                 | STATE = COMPARE(handler.handler_type, 0x1)
            // 0x00E5AFFC: B.EQ #0xe5b0b0             | if (handler.handler_type == 0x1) goto label_2;
            if(handler.handler_type == 1)
            {
                goto label_2;
            }
            // 0x00E5B000: CBNZ w8, #0xe5b0e8         | if (handler.handler_type != 0) goto label_3;
            if(handler.handler_type != 0)
            {
                goto label_3;
            }
            // 0x00E5B004: LDR x8, [x20]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5B008: LDR x21, [x20, #0x40]      | X21 = this.reader; //P2                 
            val_8 = this.reader;
            // 0x00E5B00C: MOV x0, x20                | X0 = 1152921509577164192 (0x10000001284105A0);//ML01
            // 0x00E5B010: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E5B014: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E5B018: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_1 = this.ReadUInt32();
            // 0x00E5B01C: MOV w1, w0                 | W1 = val_1;//m1                         
            // 0x00E5B020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5B024: MOV x0, sp                 | X0 = 1152921509577152128 (0x100000012840D680);//ML01
            ProtoBuf.SubItemToken val_2;
            // 0x00E5B028: STR wzr, [sp]              | stack[1152921509577152128] = 0x0;        //  dest_result_addr=1152921509577152128
            // 0x00E5B02C: BL #0x11d58d4              | null..ctor(value:  val_1);              
            val_2 = new ProtoBuf.SubItemToken(value:  val_1);
            // 0x00E5B030: LDR w20, [sp]              | W20 = val_2.value;                      
            // 0x00E5B034: CBNZ x21, #0xe5b03c        | if (this.reader != null) goto label_4;  
            if(val_8 != null)
            {
                goto label_4;
            }
            // 0x00E5B038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(value:  val_1), ????);
            label_4:
            // 0x00E5B03C: MOV x0, x21                | X0 = this.reader;//m1                   
            // 0x00E5B040: MOV x1, x20                | X1 = val_2.value;//m1                   
            // 0x00E5B044: BL #0xe5a60c               | X0 = this.reader.LookupToken(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_2.value});
            ILRuntime.Mono.Cecil.IMetadataTokenProvider val_3 = val_8.LookupToken(token:  new ILRuntime.Mono.Cecil.MetadataToken() {token = val_2.value});
            // 0x00E5B048: CBZ x0, #0xe5b0a4          | if (val_3 == null) goto label_5;        
            if(val_3 == null)
            {
                goto label_5;
            }
            // 0x00E5B04C: ADRP x9, #0x363d000        | X9 = 56872960 (0x363D000);              
            // 0x00E5B050: LDR x9, [x9, #0x490]       | X9 = 1152921504744173568;               
            // 0x00E5B054: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.IMetadataTokenProvider);
            // 0x00E5B058: LDR x1, [x9]               | X1 = typeof(ILRuntime.Mono.Cecil.TypeReference);
            // 0x00E5B05C: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00E5B060: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Mono.Cecil.TypeReference.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00E5B064: CMP w10, w9                | STATE = COMPARE(ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Mono.Cecil.TypeReference.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00E5B068: B.LO #0xe5b080             | if (ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Mono.Cecil.TypeReference.__il2cppRuntimeField_typeHierarchyDepth) goto label_6;
            // 0x00E5B06C: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchy;
            // 0x00E5B070: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mo
            // 0x00E5B074: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.TypeReference.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00E5B078: CMP x9, x1                 | STATE = COMPARE((ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.TypeReference.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Mono.Cecil.TypeReference))
            // 0x00E5B07C: B.EQ #0xe5b0a8             | if ((ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Mono.Cecil.TypeReference.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_7;
            label_6:
            // 0x00E5B080: LDR x0, [x8, #0x30]        | X0 = ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_element_class;
            // 0x00E5B084: ADD x8, sp, #8             | X8 = (1152921509577152128 + 8) = 1152921509577152136 (0x100000012840D688);
            // 0x00E5B088: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.Mono.Cecil.IMetadataTokenProvider.__il2cppRuntimeField_element_class, ????);
            // 0x00E5B08C: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921509577140192]
            // 0x00E5B090: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00E5B094: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5B098: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00E5B09C: ADD x0, sp, #8             | X0 = (1152921509577152128 + 8) = 1152921509577152136 (0x100000012840D688);
            // 0x00E5B0A0: BL #0x299a140              | 
            label_5:
            // 0x00E5B0A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_9 = 0;
            label_7:
            // 0x00E5B0A8: STR x0, [x19, #0x38]       | handler.catch_type = null;               //  dest_result_addr=0
            handler.catch_type = val_9;
            // 0x00E5B0AC: B #0xe5b0d4                |  goto label_8;                          
            goto label_8;
            label_2:
            // 0x00E5B0B0: LDR x8, [x20]              | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5B0B4: MOV x0, x20                | X0 = 1152921509577164192 (0x10000001284105A0);//ML01
            // 0x00E5B0B8: LDR x9, [x8, #0x240]       | X9 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E5B0BC: LDR x1, [x8, #0x248]       | X1 = public System.Int32 System.IO.BinaryReader::ReadInt32();
            // 0x00E5B0C0: BLR x9                     | X0 = this.ReadInt32();                  
            int val_6 = this.ReadInt32();
            // 0x00E5B0C4: MOV w1, w0                 | W1 = val_6;//m1                         
            // 0x00E5B0C8: MOV x0, x20                | X0 = 1152921509577164192 (0x10000001284105A0);//ML01
            // 0x00E5B0CC: BL #0xe5a984               | X0 = this.GetInstruction(offset:  val_6);
            ILRuntime.Mono.Cecil.Cil.Instruction val_7 = this.GetInstruction(offset:  val_6);
            // 0x00E5B0D0: STR x0, [x19, #0x20]       | handler.filter_start = val_7;            //  dest_result_addr=0
            handler.filter_start = val_7;
            label_8:
            // 0x00E5B0D4: SUB sp, x29, #0x20         | SP = (1152921509577152176 - 32) = 1152921509577152144 (0x100000012840D690);
            // 0x00E5B0D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5B0DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5B0E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5B0E4: RET                        |  return;                                
            return;
            label_3:
            // 0x00E5B0E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5B0EC: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00E5B0F0: MOV x0, x20                | X0 = 1152921509577164192 (0x10000001284105A0);//ML01
            // 0x00E5B0F4: SUB sp, x29, #0x20         | SP = (1152921509577152176 - 32) = 1152921509577152144 (0x100000012840D690);
            // 0x00E5B0F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5B0FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5B100: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5B104: B #0x11e06c0               | this.Advance(bytes:  4); return;        
            this.Advance(bytes:  4);
            return;
            // 0x00E5B108: MOV x19, x0                | 
            // 0x00E5B10C: ADD x0, sp, #8             | 
            // 0x00E5B110: BL #0x299a140              | 
            // 0x00E5B114: MOV x0, x19                | 
            // 0x00E5B118: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5A538 (15050040), len: 64  VirtAddr: 0x00E5A538 RVA: 0x00E5A538 token: 100664633 methodIndex: 19385 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Cecil.MetadataToken ReadToken()
        {
            //
            // Disasemble & Code
            // 0x00E5A538: STP x29, x30, [sp, #-0x10]! | stack[1152921509577284656] = ???;  stack[1152921509577284664] = ???;  //  dest_result_addr=1152921509577284656 |  dest_result_addr=1152921509577284664
            // 0x00E5A53C: MOV x29, sp                | X29 = 1152921509577284656 (0x100000012842DC30);//ML01
            // 0x00E5A540: SUB sp, sp, #0x10          | SP = (1152921509577284656 - 16) = 1152921509577284640 (0x100000012842DC20);
            // 0x00E5A544: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5A548: LDR x9, [x8, #0x2a0]       | X9 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E5A54C: LDR x1, [x8, #0x2a8]       | X1 = public System.UInt32 System.IO.BinaryReader::ReadUInt32();
            // 0x00E5A550: BLR x9                     | X0 = this.ReadUInt32();                 
            uint val_1 = this.ReadUInt32();
            // 0x00E5A554: MOV w1, w0                 | W1 = val_1;//m1                         
            // 0x00E5A558: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5A55C: ADD x0, sp, #8             | X0 = (1152921509577284640 + 8) = 1152921509577284648 (0x100000012842DC28);
            // 0x00E5A560: STR wzr, [sp, #8]          | stack[1152921509577284648] = 0x0;        //  dest_result_addr=1152921509577284648
            // 0x00E5A564: BL #0x11d58d4              | null..ctor(value:  val_1);              
            ProtoBuf.SubItemToken val_2 = new ProtoBuf.SubItemToken(value:  val_1);
            // 0x00E5A568: LDR w0, [sp, #8]           | W0 = val_2.value;                       
            // 0x00E5A56C: MOV sp, x29                | SP = 1152921509577284656 (0x100000012842DC30);//ML01
            // 0x00E5A570: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00E5A574: RET                        |  return (ILRuntime.Mono.Cecil.MetadataToken)val_2.value;
            return (ILRuntime.Mono.Cecil.MetadataToken)val_2.value;
            //  |  // // {name=val_0.token, type=System.UInt32, size=4, nGRN=0 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E597DC (15046620), len: 176  VirtAddr: 0x00E597DC RVA: 0x00E597DC token: 100664634 methodIndex: 19386 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadDebugInfo()
        {
            //
            // Disasemble & Code
            // 0x00E597DC: STP x20, x19, [sp, #-0x20]! | stack[1152921509577445792] = ???;  stack[1152921509577445800] = ???;  //  dest_result_addr=1152921509577445792 |  dest_result_addr=1152921509577445800
            // 0x00E597E0: STP x29, x30, [sp, #0x10]  | stack[1152921509577445808] = ???;  stack[1152921509577445816] = ???;  //  dest_result_addr=1152921509577445808 |  dest_result_addr=1152921509577445816
            // 0x00E597E4: ADD x29, sp, #0x10         | X29 = (1152921509577445792 + 16) = 1152921509577445808 (0x10000001284551B0);
            // 0x00E597E8: MOV x19, x0                | X19 = 1152921509577457824 (0x10000001284580A0);//ML01
            // 0x00E597EC: LDR x20, [x19, #0x50]      | X20 = this.method; //P2                 
            // 0x00E597F0: CBNZ x20, #0xe597f8        | if (this.method != null) goto label_0;  
            if(this.method != null)
            {
                goto label_0;
            }
            // 0x00E597F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E597F8: LDR x20, [x20, #0x90]      | X20 = this.method.debug_info; //P2      
            // 0x00E597FC: CBNZ x20, #0xe59804        | if (this.method.debug_info != null) goto label_1;
            if(this.method.debug_info != null)
            {
                goto label_1;
            }
            // 0x00E59800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00E59804: LDR x8, [x20, #0x28]       | X8 = this.method.debug_info.sequence_points; //P2 
            // 0x00E59808: CBZ x8, #0xe59814          | if (this.method.debug_info.sequence_points == null) goto label_2;
            if(this.method.debug_info.sequence_points == null)
            {
                goto label_2;
            }
            // 0x00E5980C: MOV x0, x19                | X0 = 1152921509577457824 (0x10000001284580A0);//ML01
            // 0x00E59810: BL #0xe5b1a8               | this.ReadSequencePoints();              
            this.ReadSequencePoints();
            label_2:
            // 0x00E59814: LDR x20, [x19, #0x50]      | X20 = this.method; //P2                 
            // 0x00E59818: CBNZ x20, #0xe59820        | if (this.method != null) goto label_3;  
            if(this.method != null)
            {
                goto label_3;
            }
            // 0x00E5981C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x00E59820: LDR x20, [x20, #0x90]      | X20 = this.method.debug_info; //P2      
            // 0x00E59824: CBNZ x20, #0xe5982c        | if (this.method.debug_info != null) goto label_4;
            if(this.method.debug_info != null)
            {
                goto label_4;
            }
            // 0x00E59828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x00E5982C: LDR x8, [x20, #0x30]       | X8 = this.method.debug_info.scope; //P2 
            // 0x00E59830: CBZ x8, #0xe59858          | if (this.method.debug_info.scope == null) goto label_5;
            if(this.method.debug_info.scope == null)
            {
                goto label_5;
            }
            // 0x00E59834: LDR x20, [x19, #0x50]      | X20 = this.method; //P2                 
            // 0x00E59838: CBNZ x20, #0xe59840        | if (this.method != null) goto label_6;  
            if(this.method != null)
            {
                goto label_6;
            }
            // 0x00E5983C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x00E59840: LDR x20, [x20, #0x90]      | X20 = this.method.debug_info; //P2      
            // 0x00E59844: CBNZ x20, #0xe5984c        | if (this.method.debug_info != null) goto label_7;
            if(this.method.debug_info != null)
            {
                goto label_7;
            }
            // 0x00E59848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x00E5984C: LDR x1, [x20, #0x30]       | X1 = this.method.debug_info.scope; //P2 
            // 0x00E59850: MOV x0, x19                | X0 = 1152921509577457824 (0x10000001284580A0);//ML01
            // 0x00E59854: BL #0xe5b2c4               | this.ReadScope(scope:  this.method.debug_info.scope);
            this.ReadScope(scope:  this.method.debug_info.scope);
            label_5:
            // 0x00E59858: LDR x20, [x19, #0x50]      | X20 = this.method; //P2                 
            // 0x00E5985C: CBNZ x20, #0xe59864        | if (this.method != null) goto label_8;  
            if(this.method != null)
            {
                goto label_8;
            }
            // 0x00E59860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x00E59864: LDR x8, [x20, #0x98]       | X8 = this.method.custom_infos; //P2     
            // 0x00E59868: CBZ x8, #0xe59880          | if (this.method.custom_infos == null) goto label_9;
            if(this.method.custom_infos == null)
            {
                goto label_9;
            }
            // 0x00E5986C: LDR x1, [x19, #0x50]       | X1 = this.method; //P2                  
            // 0x00E59870: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59874: MOV x0, x19                | X0 = 1152921509577457824 (0x10000001284580A0);//ML01
            // 0x00E59878: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5987C: B #0xe5b50c                | this.ReadCustomDebugInformations(method:  this.method); return;
            this.ReadCustomDebugInformations(method:  this.method);
            return;
            label_9:
            // 0x00E59880: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E59884: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E59888: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5B50C (15054092), len: 300  VirtAddr: 0x00E5B50C RVA: 0x00E5B50C token: 100664635 methodIndex: 19387 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadCustomDebugInformations(ILRuntime.Mono.Cecil.MethodDefinition method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00E5B50C: STP x26, x25, [sp, #-0x50]! | stack[1152921509577624304] = ???;  stack[1152921509577624312] = ???;  //  dest_result_addr=1152921509577624304 |  dest_result_addr=1152921509577624312
            // 0x00E5B510: STP x24, x23, [sp, #0x10]  | stack[1152921509577624320] = ???;  stack[1152921509577624328] = ???;  //  dest_result_addr=1152921509577624320 |  dest_result_addr=1152921509577624328
            // 0x00E5B514: STP x22, x21, [sp, #0x20]  | stack[1152921509577624336] = ???;  stack[1152921509577624344] = ???;  //  dest_result_addr=1152921509577624336 |  dest_result_addr=1152921509577624344
            // 0x00E5B518: STP x20, x19, [sp, #0x30]  | stack[1152921509577624352] = ???;  stack[1152921509577624360] = ???;  //  dest_result_addr=1152921509577624352 |  dest_result_addr=1152921509577624360
            // 0x00E5B51C: STP x29, x30, [sp, #0x40]  | stack[1152921509577624368] = ???;  stack[1152921509577624376] = ???;  //  dest_result_addr=1152921509577624368 |  dest_result_addr=1152921509577624376
            // 0x00E5B520: ADD x29, sp, #0x40         | X29 = (1152921509577624304 + 64) = 1152921509577624368 (0x1000000128480B30);
            // 0x00E5B524: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E5B528: LDRB w8, [x20, #0xae7]     | W8 = (bool)static_value_03734AE7;       
            // 0x00E5B52C: MOV x21, x1                | X21 = method;//m1                       
            // 0x00E5B530: MOV x19, x0                | X19 = 1152921509577636384 (0x1000000128483A20);//ML01
            // 0x00E5B534: TBNZ w8, #0, #0xe5b550     | if (static_value_03734AE7 == true) goto label_0;
            // 0x00E5B538: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00E5B53C: LDR x8, [x8, #0x1a0]       | X8 = 0x2B90DA4;                         
            // 0x00E5B540: LDR w0, [x8]               | W0 = 0x1A2D;                            
            // 0x00E5B544: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2D, ????);     
            // 0x00E5B548: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5B54C: STRB w8, [x20, #0xae7]     | static_value_03734AE7 = true;            //  dest_result_addr=57887463
            label_0:
            // 0x00E5B550: CBNZ x21, #0xe5b558        | if (method != null) goto label_1;       
            if(method != null)
            {
                goto label_1;
            }
            // 0x00E5B554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2D, ????);     
            label_1:
            // 0x00E5B558: ADRP x22, #0x35f6000       | X22 = 56582144 (0x35F6000);             
            // 0x00E5B55C: ADRP x23, #0x360c000       | X23 = 56672256 (0x360C000);             
            // 0x00E5B560: ADRP x24, #0x366b000       | X24 = 57061376 (0x366B000);             
            // 0x00E5B564: ADRP x25, #0x3622000       | X25 = 56762368 (0x3622000);             
            // 0x00E5B568: LDR x21, [x21, #0x98]      | X21 = method.custom_infos; //P2         
            // 0x00E5B56C: LDR x22, [x22, #0x48]      | X22 = 1152921509577603168;              
            // 0x00E5B570: LDR x23, [x23, #0x100]     | X23 = 1152921509455473968;              
            // 0x00E5B574: LDR x24, [x24, #0x290]     | X24 = 1152921504748060672;              
            // 0x00E5B578: LDR x25, [x25, #0xac8]     | X25 = 1152921504748167168;              
            // 0x00E5B57C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_4 = 0;
            // 0x00E5B580: B #0xe5b588                |  goto label_2;                          
            goto label_2;
            label_11:
            // 0x00E5B584: ADD w20, w20, #1           | W20 = (val_4 + 1) = val_4 (0x00000001); 
            val_4 = 1;
            label_2:
            // 0x00E5B588: CBNZ x21, #0xe5b590        | if (method.custom_infos != null) goto label_3;
            if(method.custom_infos != null)
            {
                goto label_3;
            }
            // 0x00E5B58C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2D, ????);     
            label_3:
            // 0x00E5B590: LDR x1, [x22]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>::get_Count();
            // 0x00E5B594: MOV x0, x21                | X0 = method.custom_infos;//m1           
            // 0x00E5B598: BL #0x1d46b60              | X0 = method.custom_infos.get_Count();   
            int val_1 = method.custom_infos.Count;
            // 0x00E5B59C: CMP w20, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00E5B5A0: B.GE #0xe5b620             | if (val_4 >= val_1) goto label_4;       
            if(val_4 >= val_1)
            {
                goto label_4;
            }
            // 0x00E5B5A4: CBNZ x21, #0xe5b5ac        | if (method.custom_infos != null) goto label_5;
            if(method.custom_infos != null)
            {
                goto label_5;
            }
            // 0x00E5B5A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00E5B5AC: LDR x2, [x23]              | X2 = public ILRuntime.Mono.Cecil.Cil.CustomDebugInformation ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>::get_Item(int index);
            // 0x00E5B5B0: MOV x0, x21                | X0 = method.custom_infos;//m1           
            // 0x00E5B5B4: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00E5B5B8: BL #0x1d46b68              | X0 = method.custom_infos.get_Item(index:  1);
            ILRuntime.Mono.Cecil.Cil.CustomDebugInformation val_2 = method.custom_infos.Item[1];
            // 0x00E5B5BC: MOV x8, x0                 | X8 = val_2;//m1                         
            // 0x00E5B5C0: CBZ x8, #0xe5b5e0          | if (val_2 == null) goto label_7;        
            if(val_2 == null)
            {
                goto label_7;
            }
            // 0x00E5B5C4: LDR x9, [x25]              | X9 = typeof(ILRuntime.Mono.Cecil.Cil.StateMachineScopeDebugInformation);
            // 0x00E5B5C8: LDR x10, [x8]              | X10 = typeof(ILRuntime.Mono.Cecil.Cil.CustomDebugInformation);
            // 0x00E5B5CC: CMP x10, x9                | STATE = COMPARE(typeof(ILRuntime.Mono.Cecil.Cil.CustomDebugInformation), typeof(ILRuntime.Mono.Cecil.Cil.StateMachineScopeDebugInformation))
            // 0x00E5B5D0: B.NE #0xe5b5e0             | if (typeof(ILRuntime.Mono.Cecil.Cil.CustomDebugInformation) != null) goto label_7;
            if(null != null)
            {
                goto label_7;
            }
            // 0x00E5B5D4: MOV x0, x19                | X0 = 1152921509577636384 (0x1000000128483A20);//ML01
            // 0x00E5B5D8: MOV x1, x8                 | X1 = val_2;//m1                         
            // 0x00E5B5DC: BL #0xe5b638               | this.ReadStateMachineScope(state_machine_scope:  val_2);
            this.ReadStateMachineScope(state_machine_scope:  val_2);
            label_7:
            // 0x00E5B5E0: CBNZ x21, #0xe5b5e8        | if (method.custom_infos != null) goto label_8;
            if(method.custom_infos != null)
            {
                goto label_8;
            }
            // 0x00E5B5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x00E5B5E8: LDR x2, [x23]              | X2 = public ILRuntime.Mono.Cecil.Cil.CustomDebugInformation ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>::get_Item(int index);
            // 0x00E5B5EC: MOV x0, x21                | X0 = method.custom_infos;//m1           
            // 0x00E5B5F0: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00E5B5F4: BL #0x1d46b68              | X0 = method.custom_infos.get_Item(index:  1);
            ILRuntime.Mono.Cecil.Cil.CustomDebugInformation val_3 = method.custom_infos.Item[1];
            // 0x00E5B5F8: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x00E5B5FC: CBZ x8, #0xe5b584          | if (val_3 == null) goto label_11;       
            if(val_3 == null)
            {
                goto label_11;
            }
            // 0x00E5B600: LDR x9, [x24]              | X9 = typeof(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation);
            // 0x00E5B604: LDR x10, [x8]              | X10 = typeof(ILRuntime.Mono.Cecil.Cil.CustomDebugInformation);
            // 0x00E5B608: CMP x10, x9                | STATE = COMPARE(typeof(ILRuntime.Mono.Cecil.Cil.CustomDebugInformation), typeof(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation))
            // 0x00E5B60C: B.NE #0xe5b584             | if (typeof(ILRuntime.Mono.Cecil.Cil.CustomDebugInformation) != null) goto label_11;
            if(null != null)
            {
                goto label_11;
            }
            // 0x00E5B610: MOV x0, x19                | X0 = 1152921509577636384 (0x1000000128483A20);//ML01
            // 0x00E5B614: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x00E5B618: BL #0xe5b83c               | this.ReadAsyncMethodBody(async_method:  val_3);
            this.ReadAsyncMethodBody(async_method:  val_3);
            // 0x00E5B61C: B #0xe5b584                |  goto label_11;                         
            goto label_11;
            label_4:
            // 0x00E5B620: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5B624: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5B628: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5B62C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5B630: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E5B634: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5B83C (15054908), len: 1092  VirtAddr: 0x00E5B83C RVA: 0x00E5B83C token: 100664636 methodIndex: 19388 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadAsyncMethodBody(ILRuntime.Mono.Cecil.Cil.AsyncMethodBodyDebugInformation async_method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> val_16;
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> val_17;
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> val_18;
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> val_19;
            //  | 
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset> val_20;
            // 0x00E5B83C: STP x28, x27, [sp, #-0x60]! | stack[1152921509577817280] = ???;  stack[1152921509577817288] = ???;  //  dest_result_addr=1152921509577817280 |  dest_result_addr=1152921509577817288
            // 0x00E5B840: STP x26, x25, [sp, #0x10]  | stack[1152921509577817296] = ???;  stack[1152921509577817304] = ???;  //  dest_result_addr=1152921509577817296 |  dest_result_addr=1152921509577817304
            // 0x00E5B844: STP x24, x23, [sp, #0x20]  | stack[1152921509577817312] = ???;  stack[1152921509577817320] = ???;  //  dest_result_addr=1152921509577817312 |  dest_result_addr=1152921509577817320
            // 0x00E5B848: STP x22, x21, [sp, #0x30]  | stack[1152921509577817328] = ???;  stack[1152921509577817336] = ???;  //  dest_result_addr=1152921509577817328 |  dest_result_addr=1152921509577817336
            // 0x00E5B84C: STP x20, x19, [sp, #0x40]  | stack[1152921509577817344] = ???;  stack[1152921509577817352] = ???;  //  dest_result_addr=1152921509577817344 |  dest_result_addr=1152921509577817352
            // 0x00E5B850: STP x29, x30, [sp, #0x50]  | stack[1152921509577817360] = ???;  stack[1152921509577817368] = ???;  //  dest_result_addr=1152921509577817360 |  dest_result_addr=1152921509577817368
            // 0x00E5B854: ADD x29, sp, #0x50         | X29 = (1152921509577817280 + 80) = 1152921509577817360 (0x10000001284AFD10);
            // 0x00E5B858: SUB sp, sp, #0x20          | SP = (1152921509577817280 - 32) = 1152921509577817248 (0x10000001284AFCA0);
            // 0x00E5B85C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5B860: LDRB w8, [x21, #0xae8]     | W8 = (bool)static_value_03734AE8;       
            // 0x00E5B864: MOV x19, x1                | X19 = async_method;//m1                 
            // 0x00E5B868: MOV x20, x0                | X20 = 1152921509577829376 (0x10000001284B2C00);//ML01
            // 0x00E5B86C: TBNZ w8, #0, #0xe5b888     | if (static_value_03734AE8 == true) goto label_0;
            // 0x00E5B870: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00E5B874: LDR x8, [x8, #0xff8]       | X8 = 0x2B90D9C;                         
            // 0x00E5B878: LDR w0, [x8]               | W0 = 0x1A2B;                            
            // 0x00E5B87C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A2B, ????);     
            // 0x00E5B880: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5B884: STRB w8, [x21, #0xae8]     | static_value_03734AE8 = true;            //  dest_result_addr=57887464
            label_0:
            // 0x00E5B888: STP xzr, xzr, [sp, #0x10]  | stack[1152921509577817264] = 0x0;  stack[1152921509577817272] = 0x0;  //  dest_result_addr=1152921509577817264 |  dest_result_addr=1152921509577817272
            // 0x00E5B88C: CBNZ x19, #0xe5b894        | if (async_method != null) goto label_1; 
            if(async_method != null)
            {
                goto label_1;
            }
            // 0x00E5B890: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A2B, ????);     
            label_1:
            // 0x00E5B894: ADD x21, x19, #0x30        | X21 = async_method.catch_handler;//AP2 res_addr=47
            // 0x00E5B898: MOV x0, x21                | X0 = async_method.catch_handler;//m1    
            // 0x00E5B89C: BL #0xe5bb20               |  R0 = label_34();                       
            // 0x00E5B8A0: TBNZ w0, #0x1f, #0xe5b8e0  | if ((async_method.catch_handler & 0x80000000) != 0) goto label_3;
            if((async_method.catch_handler & 2147483648) != 0)
            {
                goto label_3;
            }
            // 0x00E5B8A4: CBNZ x19, #0xe5b8ac        | if (async_method != null) goto label_4; 
            if(async_method != null)
            {
                goto label_4;
            }
            // 0x00E5B8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? async_method.catch_handler, ????);
            label_4:
            // 0x00E5B8AC: MOV x0, x21                | X0 = async_method.catch_handler;//m1    
            // 0x00E5B8B0: BL #0xe5bb20               |  R0 = label_34();                       
            // 0x00E5B8B4: MOV w1, w0                 | W1 = async_method.catch_handler;//m1    
            // 0x00E5B8B8: MOV x0, x20                | X0 = 1152921509577829376 (0x10000001284B2C00);//ML01
            // 0x00E5B8BC: BL #0xe5a984               | X0 = this.GetInstruction(offset:  async_method.catch_handler);
            ILRuntime.Mono.Cecil.Cil.Instruction val_1 = this.GetInstruction(offset:  async_method.catch_handler);
            // 0x00E5B8C0: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00E5B8C4: MOV x0, sp                 | X0 = 1152921509577817248 (0x10000001284AFCA0);//ML01
            // 0x00E5B8C8: STP xzr, xzr, [sp]         | stack[1152921509577817248] = 0x0;  stack[1152921509577817256] = 0x0;  //  dest_result_addr=1152921509577817248 |  dest_result_addr=1152921509577817256
            // 0x00E5B8CC: BL #0xe5bbec               |  R0 = label_35();                       
            // 0x00E5B8D0: CBNZ x19, #0xe5b8d8        | if (async_method != null) goto label_7; 
            if(async_method != null)
            {
                goto label_7;
            }
            // 0x00E5B8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284AFCA0, ????);
            label_7:
            // 0x00E5B8D8: LDP x8, x9, [sp]           | X8 = 0x0; X9 = 0x0;                      //  | 
            // 0x00E5B8DC: STP x8, x9, [x19, #0x30]   | async_method.catch_handler = new ILRuntime.Mono.Cecil.Cil.InstructionOffset();  mem2[0] = 0x0;  //  dest_result_addr=0 |  dest_result_addr=0
            async_method.catch_handler = 0;
            mem2[0] = 0;
            label_3:
            // 0x00E5B8E0: CBNZ x19, #0xe5b8e8        | if (async_method != null) goto label_8; 
            if(async_method != null)
            {
                goto label_8;
            }
            // 0x00E5B8E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284AFCA0, ????);
            label_8:
            // 0x00E5B8E8: ADRP x24, #0x362e000       | X24 = 56811520 (0x362E000);             
            // 0x00E5B8EC: LDR x24, [x24, #0xa48]     | X24 = 1152921504737091584;              
            // 0x00E5B8F0: LDR x21, [x19, #0x40]      | X21 = async_method.yields; //P2         
            // 0x00E5B8F4: LDR x0, [x24]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5B8F8: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5B8FC: TBZ w8, #0, #0xe5b90c      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00E5B900: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5B904: CBNZ w8, #0xe5b90c         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00E5B908: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_10:
            // 0x00E5B90C: ADRP x25, #0x3628000       | X25 = 56786944 (0x3628000);             
            // 0x00E5B910: LDR x25, [x25, #0xc70]     | X25 = 1152921509577753056;              
            val_14 = 1152921509577753056;
            // 0x00E5B914: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5B918: MOV x1, x21                | X1 = async_method.yields;//m1           
            // 0x00E5B91C: LDR x2, [x25]              | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.InstructionOffset>(ILRuntime.Mono.Collections.Generic.Collection<T> self);
            // 0x00E5B920: BL #0x12f94a4              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.InstructionOffset>(self:  0);
            bool val_2 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.InstructionOffset>(self:  0);
            // 0x00E5B924: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x00E5B928: TBNZ w8, #0, #0xe5b9f8     | if ((val_2 & 1) == true) goto label_15; 
            if(val_3 == true)
            {
                goto label_15;
            }
            // 0x00E5B92C: ADRP x26, #0x3658000       | X26 = 56983552 (0x3658000);             
            // 0x00E5B930: ADRP x27, #0x35fe000       | X27 = 56614912 (0x35FE000);             
            // 0x00E5B934: ADRP x28, #0x35d9000       | X28 = 56463360 (0x35D9000);             
            // 0x00E5B938: LDR x26, [x26, #0x890]     | X26 = 1152921509577754080;              
            // 0x00E5B93C: LDR x27, [x27, #0x728]     | X27 = 1152921509577755104;              
            // 0x00E5B940: LDR x28, [x28, #0xac0]     | X28 = 1152921509577756128;              
            // 0x00E5B944: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00E5B948: B #0xe5b964                |  goto label_12;                         
            goto label_12;
            label_22:
            // 0x00E5B94C: LDP x2, x3, [sp]           | X2 = 0x0; X3 = 0x0;                      //  | 
            // 0x00E5B950: LDR x4, [x28]              | X4 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>::set_Item(int index, ILRuntime.Mono.Cecil.Cil.InstructionOffset value);
            // 0x00E5B954: MOV x0, x22                | X0 = X22;//m1                           
            // 0x00E5B958: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x00E5B95C: BL #0x19d5b04              | X22.set_Item(index:  0, value:  new ILRuntime.Mono.Cecil.Cil.InstructionOffset() {offset = new System.Nullable<System.Int32>() {HasValue = false}});
            X22.set_Item(index:  0, value:  new ILRuntime.Mono.Cecil.Cil.InstructionOffset() {offset = new System.Nullable<System.Int32>() {HasValue = false}});
            // 0x00E5B960: ADD w21, w21, #1           | W21 = (val_15 + 1) = val_15 (0x00000001);
            val_15 = 1;
            label_12:
            // 0x00E5B964: CBNZ x19, #0xe5b96c        | if (async_method != null) goto label_13;
            if(async_method != null)
            {
                goto label_13;
            }
            // 0x00E5B968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22, ????);        
            label_13:
            // 0x00E5B96C: LDR x22, [x19, #0x40]      | X22 = async_method.yields; //P2         
            // 0x00E5B970: CBNZ x22, #0xe5b978        | if (async_method.yields != null) goto label_14;
            if(async_method.yields != null)
            {
                goto label_14;
            }
            // 0x00E5B974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22, ????);        
            label_14:
            // 0x00E5B978: LDR x1, [x26]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>::get_Count();
            // 0x00E5B97C: MOV x0, x22                | X0 = async_method.yields;//m1           
            // 0x00E5B980: BL #0x19d5a40              | X0 = async_method.yields.get_Count();   
            int val_4 = async_method.yields.Count;
            // 0x00E5B984: CMP w21, w0                | STATE = COMPARE(0x1, val_4)             
            // 0x00E5B988: B.GE #0xe5b9f8             | if (val_15 >= val_4) goto label_15;     
            if(val_15 >= val_4)
            {
                goto label_15;
            }
            // 0x00E5B98C: CBZ x19, #0xe5b99c         | if (async_method == null) goto label_16;
            if(async_method == null)
            {
                goto label_16;
            }
            // 0x00E5B990: LDR x23, [x19, #0x40]      | X23 = async_method.yields; //P2         
            val_16 = async_method.yields;
            // 0x00E5B994: MOV x22, x23               | X22 = async_method.yields;//m1          
            val_17 = val_16;
            // 0x00E5B998: B #0xe5b9ac                |  goto label_17;                         
            goto label_17;
            label_16:
            // 0x00E5B99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00E5B9A0: LDR x22, [x19, #0x40]      | X22 = async_method.yields; //P2         
            val_17 = async_method.yields;
            // 0x00E5B9A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00E5B9A8: LDR x23, [x19, #0x40]      | X23 = async_method.yields; //P2         
            val_16 = async_method.yields;
            label_17:
            // 0x00E5B9AC: CBNZ x23, #0xe5b9b4        | if (async_method.yields != null) goto label_18;
            if(val_16 != null)
            {
                goto label_18;
            }
            // 0x00E5B9B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_18:
            // 0x00E5B9B4: LDR x2, [x27]              | X2 = public ILRuntime.Mono.Cecil.Cil.InstructionOffset ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>::get_Item(int index);
            // 0x00E5B9B8: MOV x0, x23                | X0 = async_method.yields;//m1           
            // 0x00E5B9BC: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00E5B9C0: BL #0x19d5a48              | X0 = async_method.yields.get_Item(index:  1);
            ILRuntime.Mono.Cecil.Cil.InstructionOffset val_5 = val_16.Item[1];
            // 0x00E5B9C4: STP x0, x1, [sp, #0x10]    | stack[1152921509577817264] = val_5.instruction;  stack[1152921509577817272] = val_5.offset.HasValue;  //  dest_result_addr=1152921509577817264 |  dest_result_addr=1152921509577817272
            // 0x00E5B9C8: ADD x0, sp, #0x10          | X0 = (1152921509577817248 + 16) = 1152921509577817264 (0x10000001284AFCB0);
            // 0x00E5B9CC: BL #0xe5bb20               |  R0 = label_34();                       
            // 0x00E5B9D0: MOV w1, w0                 | W1 = 1152921509577817264 (0x10000001284AFCB0);//ML01
            // 0x00E5B9D4: MOV x0, x20                | X0 = 1152921509577829376 (0x10000001284B2C00);//ML01
            // 0x00E5B9D8: BL #0xe5a984               | X0 = this.GetInstruction(offset:  676002992);
            ILRuntime.Mono.Cecil.Cil.Instruction val_6 = this.GetInstruction(offset:  676002992);
            // 0x00E5B9DC: MOV x1, x0                 | X1 = val_6;//m1                         
            // 0x00E5B9E0: MOV x0, sp                 | X0 = 1152921509577817248 (0x10000001284AFCA0);//ML01
            // 0x00E5B9E4: STP xzr, xzr, [sp]         | stack[1152921509577817248] = 0x0;  stack[1152921509577817256] = 0x0;  //  dest_result_addr=1152921509577817248 |  dest_result_addr=1152921509577817256
            // 0x00E5B9E8: BL #0xe5bbec               |  R0 = label_35();                       
            // 0x00E5B9EC: CBNZ x22, #0xe5b94c        | if (async_method.yields != null) goto label_22;
            if(val_17 != null)
            {
                goto label_22;
            }
            // 0x00E5B9F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284AFCA0, ????);
            // 0x00E5B9F4: B #0xe5b94c                |  goto label_22;                         
            goto label_22;
            label_15:
            // 0x00E5B9F8: CBNZ x19, #0xe5ba00        | if (async_method != null) goto label_23;
            if(async_method != null)
            {
                goto label_23;
            }
            // 0x00E5B9FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_23:
            // 0x00E5BA00: LDR x0, [x24]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5BA04: LDR x21, [x19, #0x48]      | X21 = async_method.resumes; //P2        
            val_18 = async_method.resumes;
            // 0x00E5BA08: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5BA0C: TBZ w8, #0, #0xe5ba1c      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x00E5BA10: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5BA14: CBNZ w8, #0xe5ba1c         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x00E5BA18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_25:
            // 0x00E5BA1C: LDR x2, [x25]              | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.InstructionOffset>(ILRuntime.Mono.Collections.Generic.Collection<T> self);
            // 0x00E5BA20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5BA24: MOV x1, x21                | X1 = async_method.resumes;//m1          
            // 0x00E5BA28: BL #0x12f94a4              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.InstructionOffset>(self:  0);
            bool val_7 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.InstructionOffset>(self:  0);
            // 0x00E5BA2C: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x00E5BA30: TBNZ w8, #0, #0xe5bb00     | if ((val_7 & 1) == true) goto label_30; 
            if(val_8 == true)
            {
                goto label_30;
            }
            // 0x00E5BA34: ADRP x24, #0x3658000       | X24 = 56983552 (0x3658000);             
            // 0x00E5BA38: ADRP x25, #0x35fe000       | X25 = 56614912 (0x35FE000);             
            // 0x00E5BA3C: ADRP x26, #0x35d9000       | X26 = 56463360 (0x35D9000);             
            // 0x00E5BA40: LDR x24, [x24, #0x890]     | X24 = 1152921509577754080;              
            // 0x00E5BA44: LDR x25, [x25, #0x728]     | X25 = 1152921509577755104;              
            val_14 = 1152921509577755104;
            // 0x00E5BA48: LDR x26, [x26, #0xac0]     | X26 = 1152921509577756128;              
            // 0x00E5BA4C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00E5BA50: B #0xe5ba6c                |  goto label_27;                         
            goto label_27;
            label_37:
            // 0x00E5BA54: LDP x2, x3, [sp]           | X2 = 0x0; X3 = 0x0;                      //  | 
            // 0x00E5BA58: LDR x4, [x26]              | X4 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>::set_Item(int index, ILRuntime.Mono.Cecil.Cil.InstructionOffset value);
            // 0x00E5BA5C: MOV x0, x22                | X0 = X22;//m1                           
            // 0x00E5BA60: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x00E5BA64: BL #0x19d5b04              | X22.set_Item(index:  0, value:  new ILRuntime.Mono.Cecil.Cil.InstructionOffset() {offset = new System.Nullable<System.Int32>() {HasValue = false}});
            X22.set_Item(index:  0, value:  new ILRuntime.Mono.Cecil.Cil.InstructionOffset() {offset = new System.Nullable<System.Int32>() {HasValue = false}});
            // 0x00E5BA68: ADD w21, w21, #1           | W21 = (val_18 + 1) = val_18 (0x00000001);
            val_18 = 1;
            label_27:
            // 0x00E5BA6C: CBNZ x19, #0xe5ba74        | if (async_method != null) goto label_28;
            if(async_method != null)
            {
                goto label_28;
            }
            // 0x00E5BA70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22, ????);        
            label_28:
            // 0x00E5BA74: LDR x22, [x19, #0x48]      | X22 = async_method.resumes; //P2        
            // 0x00E5BA78: CBNZ x22, #0xe5ba80        | if (async_method.resumes != null) goto label_29;
            if(async_method.resumes != null)
            {
                goto label_29;
            }
            // 0x00E5BA7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22, ????);        
            label_29:
            // 0x00E5BA80: LDR x1, [x24]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>::get_Count();
            // 0x00E5BA84: MOV x0, x22                | X0 = async_method.resumes;//m1          
            // 0x00E5BA88: BL #0x19d5a40              | X0 = async_method.resumes.get_Count();  
            int val_9 = async_method.resumes.Count;
            // 0x00E5BA8C: CMP w21, w0                | STATE = COMPARE(0x1, val_9)             
            // 0x00E5BA90: B.GE #0xe5bb00             | if (val_18 >= val_9) goto label_30;     
            if(val_18 >= val_9)
            {
                goto label_30;
            }
            // 0x00E5BA94: CBZ x19, #0xe5baa4         | if (async_method == null) goto label_31;
            if(async_method == null)
            {
                goto label_31;
            }
            // 0x00E5BA98: LDR x23, [x19, #0x48]      | X23 = async_method.resumes; //P2        
            val_19 = async_method.resumes;
            // 0x00E5BA9C: MOV x22, x23               | X22 = async_method.resumes;//m1         
            val_20 = val_19;
            // 0x00E5BAA0: B #0xe5bab4                |  goto label_32;                         
            goto label_32;
            label_31:
            // 0x00E5BAA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00E5BAA8: LDR x22, [x19, #0x48]      | X22 = async_method.resumes; //P2        
            val_20 = async_method.resumes;
            // 0x00E5BAAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x00E5BAB0: LDR x23, [x19, #0x48]      | X23 = async_method.resumes; //P2        
            val_19 = async_method.resumes;
            label_32:
            // 0x00E5BAB4: CBNZ x23, #0xe5babc        | if (async_method.resumes != null) goto label_33;
            if(val_19 != null)
            {
                goto label_33;
            }
            // 0x00E5BAB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_33:
            // 0x00E5BABC: LDR x2, [x25]              | X2 = public ILRuntime.Mono.Cecil.Cil.InstructionOffset ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>::get_Item(int index);
            // 0x00E5BAC0: MOV x0, x23                | X0 = async_method.resumes;//m1          
            // 0x00E5BAC4: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00E5BAC8: BL #0x19d5a48              | X0 = async_method.resumes.get_Item(index:  1);
            ILRuntime.Mono.Cecil.Cil.InstructionOffset val_10 = val_19.Item[1];
            // 0x00E5BACC: STP x0, x1, [sp, #0x10]    | stack[1152921509577817264] = val_10.instruction;  stack[1152921509577817272] = val_10.offset.HasValue;  //  dest_result_addr=1152921509577817264 |  dest_result_addr=1152921509577817272
            // 0x00E5BAD0: ADD x0, sp, #0x10          | X0 = (1152921509577817248 + 16) = 1152921509577817264 (0x10000001284AFCB0);
            // 0x00E5BAD4: BL #0xe5bb20               |  R0 = label_34();                       
            // 0x00E5BAD8: MOV w1, w0                 | W1 = 1152921509577817264 (0x10000001284AFCB0);//ML01
            // 0x00E5BADC: MOV x0, x20                | X0 = 1152921509577829376 (0x10000001284B2C00);//ML01
            // 0x00E5BAE0: BL #0xe5a984               | X0 = this.GetInstruction(offset:  676002992);
            ILRuntime.Mono.Cecil.Cil.Instruction val_11 = this.GetInstruction(offset:  676002992);
            // 0x00E5BAE4: MOV x1, x0                 | X1 = val_11;//m1                        
            // 0x00E5BAE8: MOV x0, sp                 | X0 = 1152921509577817248 (0x10000001284AFCA0);//ML01
            // 0x00E5BAEC: STP xzr, xzr, [sp]         | stack[1152921509577817248] = 0x0;  stack[1152921509577817256] = 0x0;  //  dest_result_addr=1152921509577817248 |  dest_result_addr=1152921509577817256
            // 0x00E5BAF0: BL #0xe5bbec               |  R0 = label_35();                       
            // 0x00E5BAF4: CBNZ x22, #0xe5ba54        | if (async_method.resumes != null) goto label_37;
            if(val_20 != null)
            {
                goto label_37;
            }
            // 0x00E5BAF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284AFCA0, ????);
            // 0x00E5BAFC: B #0xe5ba54                |  goto label_37;                         
            goto label_37;
            label_30:
            // 0x00E5BB00: SUB sp, x29, #0x50         | SP = (1152921509577817360 - 80) = 1152921509577817280 (0x10000001284AFCC0);
            // 0x00E5BB04: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BB08: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5BB0C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5BB10: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5BB14: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E5BB18: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E5BB1C: RET                        |  return;                                
            return;
            label_34:
            // 0x00E5BB20: STP x20, x19, [sp, #-0x20]! | stack[1152921509577817344] = ;  stack[1152921509577817352] = ;  //  dest_result_addr=1152921509577817344 |  dest_result_addr=1152921509577817352
            // 0x00E5BB24: STP x29, x30, [sp, #0x10]  | stack[1152921509577817360] = ;  stack[1152921509577817368] = ;  //  dest_result_addr=1152921509577817360 |  dest_result_addr=1152921509577817368
            // 0x00E5BB28: ADD x29, sp, #0x10         | X29 = (1152921509577817344 + 16) = 1152921509577817360 (0x10000001284AFD10);
            // 0x00E5BB2C: SUB sp, sp, #0x10          | SP = (1152921509577817344 - 16) = 1152921509577817328 (0x10000001284AFCF0);
            // 0x00E5BB30: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E5BB34: LDRB w8, [x20, #0xb01]     | W8 = (bool)static_value_03734B01;       
            // 0x00E5BB38: MOV x19, x0                | X19 = val_7;//m1                        
            // 0x00E5BB3C: TBNZ w8, #0, #0xe5bb58     | if (static_value_03734B01 == true) goto label_38;
            // 0x00E5BB40: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00E5BB44: LDR x8, [x8, #0x4a8]       | X8 = 0x2B9B8D4;                         
            // 0x00E5BB48: LDR w0, [x8]               | W0 = 0x4500;                            
            // 0x00E5BB4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x4500, ????);     
            // 0x00E5BB50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5BB54: STRB w8, [x20, #0xb01]     | static_value_03734B01 = true;            //  dest_result_addr=57887489
            label_38:
            // 0x00E5BB58: STR xzr, [sp, #8]          | stack[1152921509577817336] = 0x0;        //  dest_result_addr=1152921509577817336
            // 0x00E5BB5C: LDR x8, [x19]              | X8 = val_7;                             
            // 0x00E5BB60: CBZ x8, #0xe5bb6c          | if (val_7 == false) goto label_39;      
            if(val_7 == false)
            {
                goto label_39;
            }
            // 0x00E5BB64: LDR w0, [x8, #0x10]        | W0 = val_7 + 16;                        
            // 0x00E5BB68: B #0xe5bba8                |  goto label_40;                         
            goto label_40;
            label_39:
            // 0x00E5BB6C: ADRP x9, #0x367f000        | X9 = 57143296 (0x367F000);              
            // 0x00E5BB70: LDR x8, [x19, #8]          | X8 = val_7 + 8;                         
            // 0x00E5BB74: LDR x9, [x9, #0x908]       | X9 = 1152921509457529392;               
            // 0x00E5BB78: ADD x0, sp, #8             | X0 = (1152921509577817328 + 8) = 1152921509577817336 (0x10000001284AFCF8);
            // 0x00E5BB7C: STR x8, [sp, #8]           | stack[1152921509577817336] = val_7 + 8;  //  dest_result_addr=1152921509577817336
            // 0x00E5BB80: LDR x1, [x9]               | X1 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            // 0x00E5BB84: BL #0x1d6c184              | X0 = sub_1D6C184( ?? 0x10000001284AFCF8, ????);
            // 0x00E5BB88: TBZ w0, #0, #0xe5bbb8      | if ((0x10000001284AFCF8 & 0x1) == 0) goto label_41;
            if((676003064 & 1) == 0)
            {
                goto label_41;
            }
            // 0x00E5BB8C: ADRP x9, #0x363e000        | X9 = 56877056 (0x363E000);              
            // 0x00E5BB90: LDR x8, [x19, #8]          | X8 = val_7 + 8;                         
            // 0x00E5BB94: LDR x9, [x9, #0x3b8]       | X9 = 1152921509577802208;               
            // 0x00E5BB98: ADD x0, sp, #8             | X0 = (1152921509577817328 + 8) = 1152921509577817336 (0x10000001284AFCF8);
            // 0x00E5BB9C: STR x8, [sp, #8]           | stack[1152921509577817336] = val_7 + 8;  //  dest_result_addr=1152921509577817336
            // 0x00E5BBA0: LDR x1, [x9]               | X1 = public System.Int32 System.Nullable<System.Int32>::get_Value();
            // 0x00E5BBA4: BL #0x1d6c1b0              | X0 = sub_1D6C1B0( ?? 0x10000001284AFCF8, ????);
            label_40:
            // 0x00E5BBA8: SUB sp, x29, #0x10         | SP = (1152921509577817360 - 16) = 1152921509577817344 (0x10000001284AFD00);
            // 0x00E5BBAC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BBB0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5BBB4: RET                        |  return;                                
            return;
            label_41:
            // 0x00E5BBB8: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00E5BBBC: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x00E5BBC0: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_12 = null;
            // 0x00E5BBC4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x00E5BBC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5BBCC: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00E5BBD0: BL #0x1701574              | .ctor();                                
            val_12 = new System.NotSupportedException();
            // 0x00E5BBD4: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E5BBD8: LDR x8, [x8, #0x108]       | X8 = 1152921509577803232;               
            // 0x00E5BBDC: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00E5BBE0: LDR x1, [x8]               | X1 = public System.Int32 ILRuntime.Mono.Cecil.Cil.InstructionOffset::get_Offset();
            // 0x00E5BBE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x00E5BBE8: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.NotSupportedException), ????);
            label_35:
            // 0x00E5BBEC: STP x22, x21, [sp, #-0x30]! | stack[1152921509577817280] = ;  stack[1152921509577817288] = ;  //  dest_result_addr=1152921509577817280 |  dest_result_addr=1152921509577817288
            // 0x00E5BBF0: STP x20, x19, [sp, #0x10]  | stack[1152921509577817296] = 0x3734000;  stack[1152921509577817304] = typeof(System.NotSupportedException);  //  dest_result_addr=1152921509577817296 |  dest_result_addr=1152921509577817304
            // 0x00E5BBF4: STP x29, x30, [sp, #0x20]  | stack[1152921509577817312] = ;  stack[1152921509577817320] = ;  //  dest_result_addr=1152921509577817312 |  dest_result_addr=1152921509577817320
            // 0x00E5BBF8: ADD x29, sp, #0x20         | X29 = (1152921509577817280 + 32) = 1152921509577817312 (0x10000001284AFCE0);
            // 0x00E5BBFC: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5BC00: LDRB w8, [x21, #0xb02]     | W8 = (bool)static_value_03734B02;       
            // 0x00E5BC04: MOV x19, x1                | X19 = 1152921509577803232 (0x10000001284AC5E0);//ML01
            // 0x00E5BC08: MOV x20, x0                | X20 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00E5BC0C: TBNZ w8, #0, #0xe5bc28     | if (static_value_03734B02 == true) goto label_42;
            // 0x00E5BC10: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00E5BC14: LDR x8, [x8, #0xf0]        | X8 = 0x2B9B8D0;                         
            // 0x00E5BC18: LDR w0, [x8]               | W0 = 0x44FF;                            
            // 0x00E5BC1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x44FF, ????);     
            // 0x00E5BC20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5BC24: STRB w8, [x21, #0xb02]     | static_value_03734B02 = true;            //  dest_result_addr=57887490
            label_42:
            // 0x00E5BC28: CBZ x19, #0xe5bc40         | if (public System.Int32 ILRuntime.Mono.Cecil.Cil.InstructionOffset::get_Offset() == 0) goto label_43;
            if((public System.Int32 ILRuntime.Mono.Cecil.Cil.InstructionOffset::get_Offset()) == 0)
            {
                goto label_43;
            }
            // 0x00E5BC2C: STP x19, xzr, [x20]        | System.NotSupportedException.__error = public System.Int32 ILRuntime.Mono.Cecil.Cil.InstructionOffset::get_Offset();  typeof(System.NotSupportedException).__il2cppRuntimeField_8 = 0x0;  //  dest_result_addr=1152921504655409152 |  dest_result_addr=1152921504655409160
            System.NotSupportedException.__error = public System.Int32 ILRuntime.Mono.Cecil.Cil.InstructionOffset::get_Offset();
            typeof(System.NotSupportedException).__il2cppRuntimeField_8 = 0;
            // 0x00E5BC30: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BC34: LDP x20, x19, [sp, #0x10]  | X20 = 0x3734000; X19 = typeof(System.NotSupportedException); //  | 
            // 0x00E5BC38: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5BC3C: RET                        |  return;                                
            return;
            label_43:
            // 0x00E5BC40: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E5BC44: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00E5BC48: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_13 = null;
            // 0x00E5BC4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00E5BC50: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00E5BC54: LDR x8, [x8, #0xd8]        | X8 = (string**)(1152921509577804256)("instruction");
            // 0x00E5BC58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5BC5C: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00E5BC60: LDR x1, [x8]               | X1 = "instruction";                     
            // 0x00E5BC64: BL #0x18b3df0              | .ctor(paramName:  "instruction");       
            val_13 = new System.ArgumentNullException(paramName:  "instruction");
            // 0x00E5BC68: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00E5BC6C: LDR x8, [x8, #0x248]       | X8 = 1152921509577804352;               
            // 0x00E5BC70: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00E5BC74: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Cecil.Cil.InstructionOffset::.ctor(ILRuntime.Mono.Cecil.Cil.Instruction instruction);
            // 0x00E5BC78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00E5BC7C: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.ArgumentNullException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5B638 (15054392), len: 516  VirtAddr: 0x00E5B638 RVA: 0x00E5B638 token: 100664637 methodIndex: 19389 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadStateMachineScope(ILRuntime.Mono.Cecil.Cil.StateMachineScopeDebugInformation state_machine_scope)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            // 0x00E5B638: STP x26, x25, [sp, #-0x50]! | stack[1152921509578012240] = ???;  stack[1152921509578012248] = ???;  //  dest_result_addr=1152921509578012240 |  dest_result_addr=1152921509578012248
            // 0x00E5B63C: STP x24, x23, [sp, #0x10]  | stack[1152921509578012256] = ???;  stack[1152921509578012264] = ???;  //  dest_result_addr=1152921509578012256 |  dest_result_addr=1152921509578012264
            // 0x00E5B640: STP x22, x21, [sp, #0x20]  | stack[1152921509578012272] = ???;  stack[1152921509578012280] = ???;  //  dest_result_addr=1152921509578012272 |  dest_result_addr=1152921509578012280
            // 0x00E5B644: STP x20, x19, [sp, #0x30]  | stack[1152921509578012288] = ???;  stack[1152921509578012296] = ???;  //  dest_result_addr=1152921509578012288 |  dest_result_addr=1152921509578012296
            // 0x00E5B648: STP x29, x30, [sp, #0x40]  | stack[1152921509578012304] = ???;  stack[1152921509578012312] = ???;  //  dest_result_addr=1152921509578012304 |  dest_result_addr=1152921509578012312
            // 0x00E5B64C: ADD x29, sp, #0x40         | X29 = (1152921509578012240 + 64) = 1152921509578012304 (0x10000001284DF690);
            // 0x00E5B650: SUB sp, sp, #0x40          | SP = (1152921509578012240 - 64) = 1152921509578012176 (0x10000001284DF610);
            // 0x00E5B654: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5B658: LDRB w8, [x21, #0xae9]     | W8 = (bool)static_value_03734AE9;       
            // 0x00E5B65C: MOV x20, x1                | X20 = state_machine_scope;//m1          
            // 0x00E5B660: MOV x19, x0                | X19 = 1152921509578024320 (0x10000001284E2580);//ML01
            val_6 = this;
            // 0x00E5B664: TBNZ w8, #0, #0xe5b680     | if (static_value_03734AE9 == true) goto label_0;
            // 0x00E5B668: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E5B66C: LDR x8, [x8, #0x948]       | X8 = 0x2B90DD4;                         
            // 0x00E5B670: LDR w0, [x8]               | W0 = 0x1A39;                            
            // 0x00E5B674: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A39, ????);     
            // 0x00E5B678: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5B67C: STRB w8, [x21, #0xae9]     | static_value_03734AE9 = true;            //  dest_result_addr=57887465
            label_0:
            // 0x00E5B680: STP xzr, xzr, [sp, #0x30]  | stack[1152921509578012224] = 0x0;  stack[1152921509578012232] = 0x0;  //  dest_result_addr=1152921509578012224 |  dest_result_addr=1152921509578012232
            // 0x00E5B684: STR xzr, [sp, #0x28]       | stack[1152921509578012216] = 0x0;        //  dest_result_addr=1152921509578012216
            // 0x00E5B688: CBNZ x20, #0xe5b690        | if (state_machine_scope != null) goto label_1;
            if(state_machine_scope != null)
            {
                goto label_1;
            }
            // 0x00E5B68C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A39, ????);     
            label_1:
            // 0x00E5B690: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E5B694: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E5B698: LDR x21, [x20, #0x30]      | X21 = state_machine_scope.scopes; //P2  
            // 0x00E5B69C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5B6A0: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5B6A4: TBZ w8, #0, #0xe5b6b4      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E5B6A8: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5B6AC: CBNZ w8, #0xe5b6b4         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E5B6B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_3:
            // 0x00E5B6B4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00E5B6B8: LDR x8, [x8, #0x6e0]       | X8 = 1152921509577982912;               
            // 0x00E5B6BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5B6C0: MOV x1, x21                | X1 = state_machine_scope.scopes;//m1    
            // 0x00E5B6C4: LDR x2, [x8]               | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.StateMachineScope>(ILRuntime.Mono.Collections.Generic.Collection<T> self);
            // 0x00E5B6C8: BL #0x12f9530              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.GenericParameter>(self:  0);
            bool val_1 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.GenericParameter>(self:  0);
            // 0x00E5B6CC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00E5B6D0: TBNZ w8, #0, #0xe5b814     | if ((val_1 & 1) == true) goto label_17; 
            if(val_2 == true)
            {
                goto label_17;
            }
            // 0x00E5B6D4: CBNZ x20, #0xe5b6dc        | if (state_machine_scope != null) goto label_5;
            if(state_machine_scope != null)
            {
                goto label_5;
            }
            // 0x00E5B6D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00E5B6DC: LDR x20, [x20, #0x30]      | X20 = state_machine_scope.scopes; //P2  
            // 0x00E5B6E0: CBNZ x20, #0xe5b6e8        | if (state_machine_scope.scopes != null) goto label_6;
            if(state_machine_scope.scopes != null)
            {
                goto label_6;
            }
            // 0x00E5B6E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00E5B6E8: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x00E5B6EC: LDR x8, [x8, #0xd90]       | X8 = 1152921509577988032;               
            // 0x00E5B6F0: MOV x0, x20                | X0 = state_machine_scope.scopes;//m1    
            // 0x00E5B6F4: LDR x1, [x8]               | X1 = public Collection.Enumerator<T> ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.StateMachineScope>::GetEnumerator();
            // 0x00E5B6F8: ADD x8, sp, #0x28          | X8 = (1152921509578012176 + 40) = 1152921509578012216 (0x10000001284DF638);
            // 0x00E5B6FC: BL #0x1d482e0              | X0 = state_machine_scope.scopes.GetEnumerator();
            Collection.Enumerator<T> val_3 = state_machine_scope.scopes.GetEnumerator();
            // 0x00E5B700: ADRP x22, #0x3641000       | X22 = 56889344 (0x3641000);             
            // 0x00E5B704: ADRP x23, #0x3634000       | X23 = 56836096 (0x3634000);             
            // 0x00E5B708: LDR x22, [x22, #0xd50]     | X22 = 1152921509577989056;              
            // 0x00E5B70C: LDR x23, [x23, #0x8a0]     | X23 = 1152921509577990080;              
            // 0x00E5B710: ORR w24, wzr, #0x18        | W24 = 24(0x18);                         
            // 0x00E5B714: B #0xe5b71c                |  goto label_7;                          
            goto label_7;
            label_15:
            // 0x00E5B718: STP x21, x25, [x20, #0x20] | mem2[0] = state_machine_scope.scopes;  mem2[0] = ???;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = state_machine_scope.scopes;
            mem2[0] = ???;
            label_7:
            // 0x00E5B71C: LDR x1, [x22]              | X1 = public System.Boolean Collection.Enumerator<ILRuntime.Mono.Cecil.Cil.StateMachineScope>::MoveNext();
            // 0x00E5B720: ADD x0, sp, #0x28          | X0 = (1152921509578012176 + 40) = 1152921509578012216 (0x10000001284DF638);
            // 0x00E5B724: BL #0x19d1af8              | X0 = label_ILRuntime_Mono_Cecil_MemberDefinitionCollection<System_Object>_OnClear_GL019D1AF8();
            // 0x00E5B728: AND w8, w0, #1             | W8 = (1152921509578012216 & 1) = 0 (0x00000000);
            // 0x00E5B72C: TBZ w8, #0, #0xe5b830      | if ((0x0 & 0x1) == 0) goto label_8;     
            if((0 & 1) == 0)
            {
                goto label_8;
            }
            // 0x00E5B730: LDR x1, [x23]              | X1 = public ILRuntime.Mono.Cecil.Cil.StateMachineScope Collection.Enumerator<ILRuntime.Mono.Cecil.Cil.StateMachineScope>::get_Current();
            // 0x00E5B734: ADD x0, sp, #0x28          | X0 = (1152921509578012176 + 40) = 1152921509578012216 (0x10000001284DF638);
            // 0x00E5B738: BL #0x19d1af0              | X0 = label_ILRuntime_Mono_Cecil_MemberDefinitionCollection<System_Object>_OnClear_GL019D1AF0();
            // 0x00E5B73C: MOV x20, x0                | X20 = 1152921509578012216 (0x10000001284DF638);//ML01
            // 0x00E5B740: CBNZ x20, #0xe5b748        | if (0x0 != 0) goto label_9;             
            if(0 != 0)
            {
                goto label_9;
            }
            // 0x00E5B744: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284DF638, ????);
            label_9:
            // 0x00E5B748: ADD x21, x20, #0x10        | X21 = ( + 16) = 1152921509578012232 (0x10000001284DF648);
            // 0x00E5B74C: MOV x0, x21                | X0 = 1152921509578012232 (0x10000001284DF648);//ML01
            // 0x00E5B750: BL #0xe5bb20               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BB20();
            // 0x00E5B754: MOV w1, w0                 | W1 = 1152921509578012232 (0x10000001284DF648);//ML01
            // 0x00E5B758: MOV x0, x19                | X0 = 1152921509578024320 (0x10000001284E2580);//ML01
            // 0x00E5B75C: BL #0xe5a984               | X0 = this.GetInstruction(offset:  676197960);
            ILRuntime.Mono.Cecil.Cil.Instruction val_4 = this.GetInstruction(offset:  676197960);
            // 0x00E5B760: MOV x1, x0                 | X1 = val_4;//m1                         
            // 0x00E5B764: STP xzr, xzr, [sp, #0x18]  | stack[1152921509578012200] = 0x0;  stack[1152921509578012208] = 0x0;  //  dest_result_addr=1152921509578012200 |  dest_result_addr=1152921509578012208
            // 0x00E5B768: ADD x0, sp, #0x18          | X0 = (1152921509578012176 + 24) = 1152921509578012200 (0x10000001284DF628);
            // 0x00E5B76C: BL #0xe5bbec               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BBEC();
            // 0x00E5B770: CBZ x20, #0xe5b780         | if (0x0 == 0) goto label_10;            
            if(0 == 0)
            {
                goto label_10;
            }
            // 0x00E5B774: LDP x8, x9, [sp, #0x18]    | X8 = 0x0; X9 = 0x0;                      //  | 
            // 0x00E5B778: STP x8, x9, [x20, #0x10]   | stack[1152921509578012232] = 0x0;  stack[1152921509578012240] = 0x0;  //  dest_result_addr=1152921509578012232 |  dest_result_addr=1152921509578012240
            // 0x00E5B77C: B #0xe5b794                |  goto label_11;                         
            goto label_11;
            label_10:
            // 0x00E5B780: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284DF628, ????);
            // 0x00E5B784: LDP x8, x9, [sp, #0x18]    | X8 = 0x0; X9 = 0x0;                      //  | 
            // 0x00E5B788: STR x8, [x21]              | stack[1152921509578012232] = 0x0;        //  dest_result_addr=1152921509578012232
            // 0x00E5B78C: STR x9, [x24]              | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = 0;
            // 0x00E5B790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001284DF628, ????);
            label_11:
            // 0x00E5B794: ADD x0, x20, #0x20         | X0 = ( + 32) = 1152921509578012248 (0x10000001284DF658);
            // 0x00E5B798: BL #0xe5bb20               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BB20();
            // 0x00E5B79C: MOV w1, w0                 | W1 = 1152921509578012248 (0x10000001284DF658);//ML01
            // 0x00E5B7A0: MOV x0, x19                | X0 = 1152921509578024320 (0x10000001284E2580);//ML01
            // 0x00E5B7A4: BL #0xe5a984               | X0 = this.GetInstruction(offset:  676197976);
            ILRuntime.Mono.Cecil.Cil.Instruction val_5 = this.GetInstruction(offset:  676197976);
            // 0x00E5B7A8: MOV x8, x0                 | X8 = val_5;//m1                         
            // 0x00E5B7AC: CBZ x8, #0xe5b7c8          | if (val_5 == null) goto label_12;       
            if(val_5 == null)
            {
                goto label_12;
            }
            // 0x00E5B7B0: STP xzr, xzr, [sp, #8]     | stack[1152921509578012184] = 0x0;  stack[1152921509578012192] = 0x0;  //  dest_result_addr=1152921509578012184 |  dest_result_addr=1152921509578012192
            // 0x00E5B7B4: ADD x0, sp, #8             | X0 = (1152921509578012176 + 8) = 1152921509578012184 (0x10000001284DF618);
            // 0x00E5B7B8: MOV x1, x8                 | X1 = val_5;//m1                         
            // 0x00E5B7BC: BL #0xe5bbec               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BBEC();
            // 0x00E5B7C0: LDP x21, x25, [sp, #8]     | X21 = 0x0; X25 = 0x0;                    //  | 
            // 0x00E5B7C4: B #0xe5b7d0                |  goto label_13;                         
            goto label_13;
            label_12:
            // 0x00E5B7C8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x00E5B7CC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            label_13:
            // 0x00E5B7D0: CBNZ x20, #0xe5b718        | if (0x0 != 0) goto label_15;            
            if(0 != 0)
            {
                goto label_15;
            }
            // 0x00E5B7D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x00E5B7D8: B #0xe5b718                |  goto label_15;                         
            goto label_15;
            // 0x00E5B7DC: BL #0x981060               | X0 = sub_981060( ?? val_5, ????);       
            // 0x00E5B7E0: LDR x19, [x0]              | X19 = typeof(ILRuntime.Mono.Cecil.Cil.Instruction);
            // 0x00E5B7E4: BL #0x980920               | X0 = sub_980920( ?? val_5, ????);       
            // 0x00E5B7E8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            label_18:
            // 0x00E5B7EC: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00E5B7F0: LDR x8, [x8, #0x6d0]       | X8 = 1152921509577999296;               
            // 0x00E5B7F4: ADD x0, sp, #0x28          | X0 = (1152921509578012176 + 40) = 1152921509578012216 (0x10000001284DF638);
            // 0x00E5B7F8: LDR x1, [x8]               | X1 = public System.Void Collection.Enumerator<ILRuntime.Mono.Cecil.Cil.StateMachineScope>::Dispose();
            // 0x00E5B7FC: BL #0x19d3d28              | null.Dispose();                         
            0.Dispose();
            // 0x00E5B800: TBNZ w20, #0, #0xe5b814    | if ((0x0 & 0x1) != 0) goto label_17;    
            if((0 & 1) != 0)
            {
                goto label_17;
            }
            // 0x00E5B804: CBZ x19, #0xe5b814         | if (typeof(ILRuntime.Mono.Cecil.Cil.Instruction) == null) goto label_17;
            if(null == null)
            {
                goto label_17;
            }
            // 0x00E5B808: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5B80C: MOV x0, x19                | X0 = 1152921504746463232 (0x1000000008526000);//ML01
            // 0x00E5B810: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ILRuntime.Mono.Cecil.Cil.Instruction), ????);
            label_17:
            // 0x00E5B814: SUB sp, x29, #0x40         | SP = (1152921509578012304 - 64) = 1152921509578012240 (0x10000001284DF650);
            // 0x00E5B818: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5B81C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5B820: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5B824: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5B828: LDP x26, x25, [sp], #0x50  | X26 = 0x0; X25 = ;                       //  | 
            // 0x00E5B82C: RET                        |  return;                                
            return;
            label_8:
            // 0x00E5B830: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x00E5B834: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            // 0x00E5B838: B #0xe5b7ec                |  goto label_18;                         
            goto label_18;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5B1A8 (15053224), len: 284  VirtAddr: 0x00E5B1A8 RVA: 0x00E5B1A8 token: 100664638 methodIndex: 19390 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadSequencePoints()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00E5B1A8: STP x24, x23, [sp, #-0x40]! | stack[1152921509578171360] = ???;  stack[1152921509578171368] = ???;  //  dest_result_addr=1152921509578171360 |  dest_result_addr=1152921509578171368
            // 0x00E5B1AC: STP x22, x21, [sp, #0x10]  | stack[1152921509578171376] = ???;  stack[1152921509578171384] = ???;  //  dest_result_addr=1152921509578171376 |  dest_result_addr=1152921509578171384
            // 0x00E5B1B0: STP x20, x19, [sp, #0x20]  | stack[1152921509578171392] = ???;  stack[1152921509578171400] = ???;  //  dest_result_addr=1152921509578171392 |  dest_result_addr=1152921509578171400
            // 0x00E5B1B4: STP x29, x30, [sp, #0x30]  | stack[1152921509578171408] = ???;  stack[1152921509578171416] = ???;  //  dest_result_addr=1152921509578171408 |  dest_result_addr=1152921509578171416
            // 0x00E5B1B8: ADD x29, sp, #0x30         | X29 = (1152921509578171360 + 48) = 1152921509578171408 (0x1000000128506410);
            // 0x00E5B1BC: SUB sp, sp, #0x10          | SP = (1152921509578171360 - 16) = 1152921509578171344 (0x10000001285063D0);
            // 0x00E5B1C0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E5B1C4: LDRB w8, [x20, #0xaea]     | W8 = (bool)static_value_03734AEA;       
            // 0x00E5B1C8: MOV x19, x0                | X19 = 1152921509578183424 (0x1000000128509300);//ML01
            // 0x00E5B1CC: TBNZ w8, #0, #0xe5b1e8     | if (static_value_03734AEA == true) goto label_0;
            // 0x00E5B1D0: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00E5B1D4: LDR x8, [x8, #0x770]       | X8 = 0x2B90DCC;                         
            // 0x00E5B1D8: LDR w0, [x8]               | W0 = 0x1A37;                            
            // 0x00E5B1DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A37, ????);     
            // 0x00E5B1E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5B1E4: STRB w8, [x20, #0xaea]     | static_value_03734AEA = true;            //  dest_result_addr=57887466
            label_0:
            // 0x00E5B1E8: LDR x20, [x19, #0x50]      | X20 = this.method; //P2                 
            // 0x00E5B1EC: CBNZ x20, #0xe5b1f4        | if (this.method != null) goto label_1;  
            if(this.method != null)
            {
                goto label_1;
            }
            // 0x00E5B1F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A37, ????);     
            label_1:
            // 0x00E5B1F4: ADRP x23, #0x35f3000       | X23 = 56569856 (0x35F3000);             
            // 0x00E5B1F8: ADRP x24, #0x362c000       | X24 = 56803328 (0x362C000);             
            // 0x00E5B1FC: LDR x22, [x20, #0x90]      | X22 = this.method.debug_info; //P2      
            // 0x00E5B200: LDR x23, [x23, #0xdf8]     | X23 = 1152921509578140992;              
            // 0x00E5B204: LDR x24, [x24, #0x760]     | X24 = 1152921509578142016;              
            // 0x00E5B208: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_4 = 0;
            // 0x00E5B20C: B #0xe5b214                |  goto label_2;                          
            goto label_2;
            label_11:
            // 0x00E5B210: ADD w20, w20, #1           | W20 = (val_4 + 1) = val_4 (0x00000001); 
            val_4 = 1;
            label_2:
            // 0x00E5B214: CBNZ x22, #0xe5b21c        | if (this.method.debug_info != null) goto label_3;
            if(this.method.debug_info != null)
            {
                goto label_3;
            }
            // 0x00E5B218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A37, ????);     
            label_3:
            // 0x00E5B21C: LDR x21, [x22, #0x28]      | X21 = this.method.debug_info.sequence_points; //P2 
            // 0x00E5B220: CBNZ x21, #0xe5b228        | if (this.method.debug_info.sequence_points != null) goto label_4;
            if(this.method.debug_info.sequence_points != null)
            {
                goto label_4;
            }
            // 0x00E5B224: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A37, ????);     
            label_4:
            // 0x00E5B228: LDR x1, [x23]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>::get_Count();
            // 0x00E5B22C: MOV x0, x21                | X0 = this.method.debug_info.sequence_points;//m1
            // 0x00E5B230: BL #0x1d46b60              | X0 = this.method.debug_info.sequence_points.get_Count();
            int val_1 = this.method.debug_info.sequence_points.Count;
            // 0x00E5B234: CMP w20, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00E5B238: B.GE #0xe5b2ac             | if (val_4 >= val_1) goto label_5;       
            if(val_4 >= val_1)
            {
                goto label_5;
            }
            // 0x00E5B23C: CBNZ x22, #0xe5b244        | if (this.method.debug_info != null) goto label_6;
            if(this.method.debug_info != null)
            {
                goto label_6;
            }
            // 0x00E5B240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00E5B244: LDR x21, [x22, #0x28]      | X21 = this.method.debug_info.sequence_points; //P2 
            // 0x00E5B248: CBNZ x21, #0xe5b250        | if (this.method.debug_info.sequence_points != null) goto label_7;
            if(this.method.debug_info.sequence_points != null)
            {
                goto label_7;
            }
            // 0x00E5B24C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_7:
            // 0x00E5B250: LDR x2, [x24]              | X2 = public ILRuntime.Mono.Cecil.Cil.SequencePoint ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>::get_Item(int index);
            // 0x00E5B254: MOV x0, x21                | X0 = this.method.debug_info.sequence_points;//m1
            // 0x00E5B258: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00E5B25C: BL #0x1d46b68              | X0 = this.method.debug_info.sequence_points.get_Item(index:  1);
            ILRuntime.Mono.Cecil.Cil.SequencePoint val_2 = this.method.debug_info.sequence_points.Item[1];
            // 0x00E5B260: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00E5B264: CBNZ x21, #0xe5b26c        | if (val_2 != null) goto label_8;        
            if(val_2 != null)
            {
                goto label_8;
            }
            // 0x00E5B268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x00E5B26C: ADD x0, x21, #0x10         | X0 = val_2.offset;//AP2 res_addr=15     
            // 0x00E5B270: BL #0xe5bb20               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BB20();
            // 0x00E5B274: MOV w1, w0                 | W1 = val_2.offset;//m1                  
            // 0x00E5B278: MOV x0, x19                | X0 = 1152921509578183424 (0x1000000128509300);//ML01
            // 0x00E5B27C: BL #0xe5a984               | X0 = this.GetInstruction(offset:  val_2.offset);
            ILRuntime.Mono.Cecil.Cil.Instruction val_3 = this.GetInstruction(offset:  val_2.offset);
            // 0x00E5B280: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x00E5B284: CBZ x8, #0xe5b210          | if (val_3 == null) goto label_11;       
            if(val_3 == null)
            {
                goto label_11;
            }
            // 0x00E5B288: MOV x0, sp                 | X0 = 1152921509578171344 (0x10000001285063D0);//ML01
            // 0x00E5B28C: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x00E5B290: STP xzr, xzr, [sp]         | stack[1152921509578171344] = 0x0;  stack[1152921509578171352] = 0x0;  //  dest_result_addr=1152921509578171344 |  dest_result_addr=1152921509578171352
            // 0x00E5B294: BL #0xe5bbec               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BBEC();
            // 0x00E5B298: CBNZ x21, #0xe5b2a0        | if (val_2 != null) goto label_10;       
            if(val_2 != null)
            {
                goto label_10;
            }
            // 0x00E5B29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001285063D0, ????);
            label_10:
            // 0x00E5B2A0: LDP x8, x9, [sp]           | X8 = 0x0; X9 = 0x0;                      //  | 
            // 0x00E5B2A4: STP x8, x9, [x21, #0x10]   | val_2.offset = new ILRuntime.Mono.Cecil.Cil.InstructionOffset();  mem2[0] = 0x0;  //  dest_result_addr=0 |  dest_result_addr=0
            val_2.offset = 0;
            mem2[0] = 0;
            // 0x00E5B2A8: B #0xe5b210                |  goto label_11;                         
            goto label_11;
            label_5:
            // 0x00E5B2AC: SUB sp, x29, #0x30         | SP = (1152921509578171408 - 48) = 1152921509578171360 (0x10000001285063E0);
            // 0x00E5B2B0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5B2B4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5B2B8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5B2BC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5B2C0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5BC88 (15056008), len: 180  VirtAddr: 0x00E5BC88 RVA: 0x00E5BC88 token: 100664639 methodIndex: 19391 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadScopes(ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation> scopes)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00E5BC88: STP x24, x23, [sp, #-0x40]! | stack[1152921509578318176] = ???;  stack[1152921509578318184] = ???;  //  dest_result_addr=1152921509578318176 |  dest_result_addr=1152921509578318184
            // 0x00E5BC8C: STP x22, x21, [sp, #0x10]  | stack[1152921509578318192] = ???;  stack[1152921509578318200] = ???;  //  dest_result_addr=1152921509578318192 |  dest_result_addr=1152921509578318200
            // 0x00E5BC90: STP x20, x19, [sp, #0x20]  | stack[1152921509578318208] = ???;  stack[1152921509578318216] = ???;  //  dest_result_addr=1152921509578318208 |  dest_result_addr=1152921509578318216
            // 0x00E5BC94: STP x29, x30, [sp, #0x30]  | stack[1152921509578318224] = ???;  stack[1152921509578318232] = ???;  //  dest_result_addr=1152921509578318224 |  dest_result_addr=1152921509578318232
            // 0x00E5BC98: ADD x29, sp, #0x30         | X29 = (1152921509578318176 + 48) = 1152921509578318224 (0x100000012852A190);
            // 0x00E5BC9C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5BCA0: LDRB w8, [x21, #0xaeb]     | W8 = (bool)static_value_03734AEB;       
            // 0x00E5BCA4: MOV x19, x1                | X19 = scopes;//m1                       
            // 0x00E5BCA8: MOV x20, x0                | X20 = 1152921509578330240 (0x100000012852D080);//ML01
            // 0x00E5BCAC: TBNZ w8, #0, #0xe5bcc8     | if (static_value_03734AEB == true) goto label_0;
            // 0x00E5BCB0: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00E5BCB4: LDR x8, [x8, #0xff0]       | X8 = 0x2B90DC8;                         
            // 0x00E5BCB8: LDR w0, [x8]               | W0 = 0x1A36;                            
            // 0x00E5BCBC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A36, ????);     
            // 0x00E5BCC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5BCC4: STRB w8, [x21, #0xaeb]     | static_value_03734AEB = true;            //  dest_result_addr=57887467
            label_0:
            // 0x00E5BCC8: ADRP x22, #0x3617000       | X22 = 56717312 (0x3617000);             
            // 0x00E5BCCC: ADRP x23, #0x3655000       | X23 = 56971264 (0x3655000);             
            // 0x00E5BCD0: LDR x22, [x22, #0x958]     | X22 = 1152921509578300096;              
            // 0x00E5BCD4: LDR x23, [x23, #0xe38]     | X23 = 1152921509578301120;              
            // 0x00E5BCD8: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x00E5BCDC: B #0xe5bd00                |  goto label_1;                          
            goto label_1;
            label_5:
            // 0x00E5BCE0: LDR x2, [x23]              | X2 = public ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>::get_Item(int index);
            // 0x00E5BCE4: MOV x0, x19                | X0 = scopes;//m1                        
            // 0x00E5BCE8: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x00E5BCEC: BL #0x1d46b68              | X0 = scopes.get_Item(index:  0);        
            ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation val_1 = scopes.Item[0];
            // 0x00E5BCF0: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x00E5BCF4: MOV x0, x20                | X0 = 1152921509578330240 (0x100000012852D080);//ML01
            // 0x00E5BCF8: BL #0xe5b2c4               | this.ReadScope(scope:  val_1);          
            this.ReadScope(scope:  val_1);
            // 0x00E5BCFC: ADD w21, w21, #1           | W21 = (val_3 + 1) = val_3 (0x00000001); 
            val_3 = 1;
            label_1:
            // 0x00E5BD00: CBNZ x19, #0xe5bd08        | if (scopes != null) goto label_2;       
            if(scopes != null)
            {
                goto label_2;
            }
            // 0x00E5BD04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x00E5BD08: LDR x1, [x22]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>::get_Count();
            // 0x00E5BD0C: MOV x0, x19                | X0 = scopes;//m1                        
            // 0x00E5BD10: BL #0x1d46b60              | X0 = scopes.get_Count();                
            int val_2 = scopes.Count;
            // 0x00E5BD14: CMP w21, w0                | STATE = COMPARE(0x1, val_2)             
            // 0x00E5BD18: B.GE #0xe5bd28             | if (val_3 >= val_2) goto label_3;       
            if(val_3 >= val_2)
            {
                goto label_3;
            }
            // 0x00E5BD1C: CBNZ x19, #0xe5bce0        | if (scopes != null) goto label_5;       
            if(scopes != null)
            {
                goto label_5;
            }
            // 0x00E5BD20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00E5BD24: B #0xe5bce0                |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x00E5BD28: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BD2C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5BD30: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5BD34: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E5BD38: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5B2C4 (15053508), len: 584  VirtAddr: 0x00E5B2C4 RVA: 0x00E5B2C4 token: 100664640 methodIndex: 19392 delegateWrapperIndex: 0 methodInvoker: 0
        private void ReadScope(ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation scope)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            //  | 
            ILRuntime.Mono.Cecil.Cil.InstructionOffset val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x00E5B2C4: STP x26, x25, [sp, #-0x50]! | stack[1152921509578482384] = ???;  stack[1152921509578482392] = ???;  //  dest_result_addr=1152921509578482384 |  dest_result_addr=1152921509578482392
            // 0x00E5B2C8: STP x24, x23, [sp, #0x10]  | stack[1152921509578482400] = ???;  stack[1152921509578482408] = ???;  //  dest_result_addr=1152921509578482400 |  dest_result_addr=1152921509578482408
            // 0x00E5B2CC: STP x22, x21, [sp, #0x20]  | stack[1152921509578482416] = ???;  stack[1152921509578482424] = ???;  //  dest_result_addr=1152921509578482416 |  dest_result_addr=1152921509578482424
            // 0x00E5B2D0: STP x20, x19, [sp, #0x30]  | stack[1152921509578482432] = ???;  stack[1152921509578482440] = ???;  //  dest_result_addr=1152921509578482432 |  dest_result_addr=1152921509578482440
            // 0x00E5B2D4: STP x29, x30, [sp, #0x40]  | stack[1152921509578482448] = ???;  stack[1152921509578482456] = ???;  //  dest_result_addr=1152921509578482448 |  dest_result_addr=1152921509578482456
            // 0x00E5B2D8: ADD x29, sp, #0x40         | X29 = (1152921509578482384 + 64) = 1152921509578482448 (0x1000000128552310);
            // 0x00E5B2DC: SUB sp, sp, #0x20          | SP = (1152921509578482384 - 32) = 1152921509578482352 (0x10000001285522B0);
            // 0x00E5B2E0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E5B2E4: LDRB w8, [x21, #0xaec]     | W8 = (bool)static_value_03734AEC;       
            // 0x00E5B2E8: MOV x19, x1                | X19 = scope;//m1                        
            // 0x00E5B2EC: MOV x20, x0                | X20 = 1152921509578494464 (0x1000000128555200);//ML01
            // 0x00E5B2F0: TBNZ w8, #0, #0xe5b30c     | if (static_value_03734AEC == true) goto label_0;
            // 0x00E5B2F4: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00E5B2F8: LDR x8, [x8, #0x2d8]       | X8 = 0x2B90DC4;                         
            // 0x00E5B2FC: LDR w0, [x8]               | W0 = 0x1A35;                            
            // 0x00E5B300: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A35, ????);     
            // 0x00E5B304: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5B308: STRB w8, [x21, #0xaec]     | static_value_03734AEC = true;            //  dest_result_addr=57887468
            label_0:
            // 0x00E5B30C: STP xzr, xzr, [sp, #0x10]  | stack[1152921509578482368] = 0x0;  stack[1152921509578482376] = 0x0;  //  dest_result_addr=1152921509578482368 |  dest_result_addr=1152921509578482376
            // 0x00E5B310: CBNZ x19, #0xe5b318        | if (scope != null) goto label_1;        
            if(scope != null)
            {
                goto label_1;
            }
            // 0x00E5B314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A35, ????);     
            label_1:
            // 0x00E5B318: LDP x8, x9, [x19, #0x20]   | X8 = scope.start; //P2                   //  | 
            // 0x00E5B31C: ADD x0, sp, #0x10          | X0 = (1152921509578482352 + 16) = 1152921509578482368 (0x10000001285522C0);
            // 0x00E5B320: STP x8, x9, [sp, #0x10]    | stack[1152921509578482368] = scope.start;  stack[1152921509578482376] = ???;  //  dest_result_addr=1152921509578482368 |  dest_result_addr=1152921509578482376
            // 0x00E5B324: BL #0xe5bb20               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BB20();
            // 0x00E5B328: MOV w1, w0                 | W1 = 1152921509578482368 (0x10000001285522C0);//ML01
            // 0x00E5B32C: MOV x0, x20                | X0 = 1152921509578494464 (0x1000000128555200);//ML01
            // 0x00E5B330: BL #0xe5a984               | X0 = this.GetInstruction(offset:  676668096);
            ILRuntime.Mono.Cecil.Cil.Instruction val_1 = this.GetInstruction(offset:  676668096);
            // 0x00E5B334: MOV x8, x0                 | X8 = val_1;//m1                         
            // 0x00E5B338: CBZ x8, #0xe5b354          | if (val_1 == null) goto label_2;        
            if(val_1 == null)
            {
                goto label_2;
            }
            // 0x00E5B33C: MOV x0, sp                 | X0 = 1152921509578482352 (0x10000001285522B0);//ML01
            // 0x00E5B340: MOV x1, x8                 | X1 = val_1;//m1                         
            // 0x00E5B344: STP xzr, xzr, [sp]         | stack[1152921509578482352] = 0x0;  stack[1152921509578482360] = 0x0;  //  dest_result_addr=1152921509578482352 |  dest_result_addr=1152921509578482360
            // 0x00E5B348: BL #0xe5bbec               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BBEC();
            // 0x00E5B34C: LDP x8, x9, [sp]           | X8 = 0x0; X9 = 0x0;                      //  | 
            val_10 = 0;
            // 0x00E5B350: STP x8, x9, [x19, #0x20]   | scope.start = new ILRuntime.Mono.Cecil.Cil.InstructionOffset();  mem2[0] = 0x0;  //  dest_result_addr=0 |  dest_result_addr=0
            scope.start = 0;
            mem2[0] = val_10;
            label_2:
            // 0x00E5B354: LDP x8, x9, [x19, #0x30]   | X8 = scope.end; //P2                     //  | 
            // 0x00E5B358: ADD x0, sp, #0x10          | X0 = (1152921509578482352 + 16) = 1152921509578482368 (0x10000001285522C0);
            // 0x00E5B35C: STP x8, x9, [sp, #0x10]    | stack[1152921509578482368] = scope.end;  stack[1152921509578482376] = 0x0;  //  dest_result_addr=1152921509578482368 |  dest_result_addr=1152921509578482376
            // 0x00E5B360: BL #0xe5bb20               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BB20();
            // 0x00E5B364: MOV w1, w0                 | W1 = 1152921509578482368 (0x10000001285522C0);//ML01
            // 0x00E5B368: MOV x0, x20                | X0 = 1152921509578494464 (0x1000000128555200);//ML01
            // 0x00E5B36C: BL #0xe5a984               | X0 = this.GetInstruction(offset:  676668096);
            ILRuntime.Mono.Cecil.Cil.Instruction val_2 = this.GetInstruction(offset:  676668096);
            // 0x00E5B370: MOV x8, x0                 | X8 = val_2;//m1                         
            // 0x00E5B374: CBZ x8, #0xe5b390          | if (val_2 == null) goto label_3;        
            if(val_2 == null)
            {
                goto label_3;
            }
            // 0x00E5B378: MOV x0, sp                 | X0 = 1152921509578482352 (0x10000001285522B0);//ML01
            // 0x00E5B37C: MOV x1, x8                 | X1 = val_2;//m1                         
            // 0x00E5B380: STP xzr, xzr, [sp]         | stack[1152921509578482352] = 0x0;  stack[1152921509578482360] = 0x0;  //  dest_result_addr=1152921509578482352 |  dest_result_addr=1152921509578482360
            // 0x00E5B384: BL #0xe5bbec               | X0 = label_ILRuntime_Mono_Cecil_Cil_CodeReader_ReadAsyncMethodBody_GL00E5BBEC();
            // 0x00E5B388: LDP x8, x9, [sp]           | X8 = 0x0; X9 = 0x0;                      //  | 
            val_11 = 0;
            val_12 = 0;
            // 0x00E5B38C: B #0xe5b39c                |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x00E5B390: MOV x8, xzr                | X8 = 0 (0x0);//ML01                     
            val_11 = 0;
            // 0x00E5B394: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_12 = 0;
            // 0x00E5B398: STP xzr, xzr, [sp, #0x10]  | stack[1152921509578482368] = 0x0;  stack[1152921509578482376] = 0x0;  //  dest_result_addr=1152921509578482368 |  dest_result_addr=1152921509578482376
            label_4:
            // 0x00E5B39C: STP x8, x9, [x19, #0x30]   | scope.end = new ILRuntime.Mono.Cecil.Cil.InstructionOffset();  mem2[0] = 0x0;  //  dest_result_addr=0 |  dest_result_addr=0
            scope.end = val_11;
            mem2[0] = val_12;
            // 0x00E5B3A0: ADRP x23, #0x362e000       | X23 = 56811520 (0x362E000);             
            // 0x00E5B3A4: LDR x23, [x23, #0xa48]     | X23 = 1152921504737091584;              
            // 0x00E5B3A8: LDR x21, [x19, #0x50]      | X21 = scope.variables; //P2             
            // 0x00E5B3AC: LDR x0, [x23]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5B3B0: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5B3B4: TBZ w8, #0, #0xe5b3c4      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00E5B3B8: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5B3BC: CBNZ w8, #0xe5b3c4         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00E5B3C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_6:
            // 0x00E5B3C4: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E5B3C8: LDR x8, [x8, #0x6d0]       | X8 = 1152921509578442816;               
            // 0x00E5B3CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5B3D0: MOV x1, x21                | X1 = scope.variables;//m1               
            // 0x00E5B3D4: LDR x2, [x8]               | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>(ILRuntime.Mono.Collections.Generic.Collection<T> self);
            // 0x00E5B3D8: BL #0x12f9530              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.GenericParameter>(self:  0);
            bool val_3 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.GenericParameter>(self:  0);
            // 0x00E5B3DC: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x00E5B3E0: TBNZ w8, #0, #0xe5b498     | if ((val_3 & 1) == true) goto label_11; 
            if(val_4 == true)
            {
                goto label_11;
            }
            // 0x00E5B3E4: ADRP x24, #0x3677000       | X24 = 57110528 (0x3677000);             
            // 0x00E5B3E8: ADRP x25, #0x3675000       | X25 = 57102336 (0x3675000);             
            // 0x00E5B3EC: LDR x24, [x24, #0xe08]     | X24 = 1152921509578443840;              
            // 0x00E5B3F0: LDR x25, [x25, #0x9e8]     | X25 = 1152921509578444864;              
            // 0x00E5B3F4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00E5B3F8: B #0xe5b400                |  goto label_8;                          
            goto label_8;
            label_17:
            // 0x00E5B3FC: ADD w21, w21, #1           | W21 = (val_13 + 1) = val_13 (0x00000001);
            val_13 = 1;
            label_8:
            // 0x00E5B400: CBNZ x19, #0xe5b408        | if (scope != null) goto label_9;        
            if(scope != null)
            {
                goto label_9;
            }
            // 0x00E5B404: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x00E5B408: LDR x22, [x19, #0x50]      | X22 = scope.variables; //P2             
            // 0x00E5B40C: CBNZ x22, #0xe5b414        | if (scope.variables != null) goto label_10;
            if(scope.variables != null)
            {
                goto label_10;
            }
            // 0x00E5B410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x00E5B414: LDR x1, [x24]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>::get_Count();
            // 0x00E5B418: MOV x0, x22                | X0 = scope.variables;//m1               
            // 0x00E5B41C: BL #0x1d46b60              | X0 = scope.variables.get_Count();       
            int val_5 = scope.variables.Count;
            // 0x00E5B420: CMP w21, w0                | STATE = COMPARE(0x1, val_5)             
            // 0x00E5B424: B.GE #0xe5b498             | if (val_13 >= val_5) goto label_11;     
            if(val_13 >= val_5)
            {
                goto label_11;
            }
            // 0x00E5B428: CBNZ x19, #0xe5b430        | if (scope != null) goto label_12;       
            if(scope != null)
            {
                goto label_12;
            }
            // 0x00E5B42C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00E5B430: LDR x22, [x19, #0x50]      | X22 = scope.variables; //P2             
            // 0x00E5B434: CBNZ x22, #0xe5b43c        | if (scope.variables != null) goto label_13;
            if(scope.variables != null)
            {
                goto label_13;
            }
            // 0x00E5B438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_13:
            // 0x00E5B43C: LDR x2, [x25]              | X2 = public ILRuntime.Mono.Cecil.Cil.VariableDebugInformation ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>::get_Item(int index);
            // 0x00E5B440: MOV x0, x22                | X0 = scope.variables;//m1               
            // 0x00E5B444: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00E5B448: BL #0x1d46b68              | X0 = scope.variables.get_Item(index:  1);
            ILRuntime.Mono.Cecil.Cil.VariableDebugInformation val_6 = scope.variables.Item[1];
            // 0x00E5B44C: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00E5B450: CBNZ x22, #0xe5b458        | if (val_6 != null) goto label_14;       
            if(val_6 != null)
            {
                goto label_14;
            }
            // 0x00E5B454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_14:
            // 0x00E5B458: ADD x0, x22, #0x30         | X0 = val_6.index;//AP2 res_addr=47      
            // 0x00E5B45C: BL #0xe6452c               | X0 = label_ILRuntime_Mono_Cecil_Cil_SymbolsNotMatchingException__ctor_GL00E6452C();
            // 0x00E5B460: MOV w1, w0                 | W1 = val_6.index;//m1                   
            // 0x00E5B464: MOV x0, x20                | X0 = 1152921509578494464 (0x1000000128555200);//ML01
            // 0x00E5B468: BL #0xe5a438               | X0 = this.GetVariable(index:  val_6.index);
            ILRuntime.Mono.Cecil.Cil.VariableDefinition val_7 = this.GetVariable(index:  val_6.index);
            // 0x00E5B46C: MOV x8, x0                 | X8 = val_7;//m1                         
            // 0x00E5B470: CBZ x8, #0xe5b3fc          | if (val_7 == null) goto label_17;       
            if(val_7 == null)
            {
                goto label_17;
            }
            // 0x00E5B474: MOV x0, sp                 | X0 = 1152921509578482352 (0x10000001285522B0);//ML01
            // 0x00E5B478: MOV x1, x8                 | X1 = val_7;//m1                         
            // 0x00E5B47C: STP xzr, xzr, [sp]         | stack[1152921509578482352] = 0x0;  stack[1152921509578482360] = 0x0;  //  dest_result_addr=1152921509578482352 |  dest_result_addr=1152921509578482360
            // 0x00E5B480: BL #0xe5bd6c               | X0 = label_ILRuntime_Mono_Cecil_Cil_VariableDebugInformation_get_Index_GL00E5BD6C();
            // 0x00E5B484: CBNZ x22, #0xe5b48c        | if (val_6 != null) goto label_16;       
            if(val_6 != null)
            {
                goto label_16;
            }
            // 0x00E5B488: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001285522B0, ????);
            label_16:
            // 0x00E5B48C: LDP x8, x9, [sp]           | X8 = 0x0; X9 = 0x0;                      //  | 
            // 0x00E5B490: STP x8, x9, [x22, #0x30]   | val_6.index = new ILRuntime.Mono.Cecil.Cil.VariableIndex();  mem2[0] = 0x0;  //  dest_result_addr=0 |  dest_result_addr=0
            val_6.index = 0;
            mem2[0] = 0;
            // 0x00E5B494: B #0xe5b3fc                |  goto label_17;                         
            goto label_17;
            label_11:
            // 0x00E5B498: CBNZ x19, #0xe5b4a0        | if (scope != null) goto label_18;       
            if(scope != null)
            {
                goto label_18;
            }
            // 0x00E5B49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_18:
            // 0x00E5B4A0: LDR x0, [x23]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E5B4A4: LDR x21, [x19, #0x48]      | X21 = scope.scopes; //P2                
            // 0x00E5B4A8: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E5B4AC: TBZ w8, #0, #0xe5b4bc      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00E5B4B0: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5B4B4: CBNZ w8, #0xe5b4bc         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00E5B4B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_20:
            // 0x00E5B4BC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00E5B4C0: LDR x8, [x8, #0x3d8]       | X8 = 1152921509453030944;               
            // 0x00E5B4C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5B4C8: MOV x1, x21                | X1 = scope.scopes;//m1                  
            // 0x00E5B4CC: LDR x2, [x8]               | X2 = public static System.Boolean ILRuntime.Mono.Cecil.Mixin::IsNullOrEmpty<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>(ILRuntime.Mono.Collections.Generic.Collection<T> self);
            // 0x00E5B4D0: BL #0x12f9530              | X0 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.GenericParameter>(self:  0);
            bool val_8 = ILRuntime.Mono.Cecil.Mixin.IsNullOrEmpty<ILRuntime.Mono.Cecil.GenericParameter>(self:  0);
            // 0x00E5B4D4: AND w8, w0, #1             | W8 = (val_8 & 1);                       
            bool val_9 = val_8;
            // 0x00E5B4D8: TBNZ w8, #0, #0xe5b4f0     | if ((val_8 & 1) == true) goto label_21; 
            if(val_9 == true)
            {
                goto label_21;
            }
            // 0x00E5B4DC: CBNZ x19, #0xe5b4e4        | if (scope != null) goto label_22;       
            if(scope != null)
            {
                goto label_22;
            }
            // 0x00E5B4E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_22:
            // 0x00E5B4E4: LDR x1, [x19, #0x48]       | X1 = scope.scopes; //P2                 
            // 0x00E5B4E8: MOV x0, x20                | X0 = 1152921509578494464 (0x1000000128555200);//ML01
            // 0x00E5B4EC: BL #0xe5bc88               | this.ReadScopes(scopes:  scope.scopes); 
            this.ReadScopes(scopes:  scope.scopes);
            label_21:
            // 0x00E5B4F0: SUB sp, x29, #0x40         | SP = (1152921509578482448 - 64) = 1152921509578482384 (0x10000001285522D0);
            // 0x00E5B4F4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5B4F8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5B4FC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E5B500: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5B504: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E5B508: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5BE00 (15056384), len: 36  VirtAddr: 0x00E5BE00 RVA: 0x00E5BE00 token: 100664641 methodIndex: 19393 delegateWrapperIndex: 0 methodInvoker: 0
        private int <ReadSmallSection>b__26_0()
        {
            //
            // Disasemble & Code
            // 0x00E5BE00: STP x29, x30, [sp, #-0x10]! | stack[1152921509578635408] = ???;  stack[1152921509578635416] = ???;  //  dest_result_addr=1152921509578635408 |  dest_result_addr=1152921509578635416
            // 0x00E5BE04: MOV x29, sp                | X29 = 1152921509578635408 (0x1000000128577890);//ML01
            // 0x00E5BE08: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5BE0C: LDR x9, [x8, #0x290]       | X9 = public System.UInt16 System.IO.BinaryReader::ReadUInt16();
            // 0x00E5BE10: LDR x1, [x8, #0x298]       | X1 = public System.UInt16 System.IO.BinaryReader::ReadUInt16();
            // 0x00E5BE14: BLR x9                     | X0 = this.ReadUInt16();                 
            ushort val_1 = this.ReadUInt16();
            // 0x00E5BE18: AND w0, w0, #0xffff        | W0 = (val_1 & 65535);                   
            val_1 = val_1 & 65535;
            // 0x00E5BE1C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BE20: RET                        |  return (System.Int32)(val_1 & 65535);  
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5BE24 (15056420), len: 32  VirtAddr: 0x00E5BE24 RVA: 0x00E5BE24 token: 100664642 methodIndex: 19394 delegateWrapperIndex: 0 methodInvoker: 0
        private int <ReadSmallSection>b__26_1()
        {
            //
            // Disasemble & Code
            // 0x00E5BE24: STP x29, x30, [sp, #-0x10]! | stack[1152921509578747408] = ???;  stack[1152921509578747416] = ???;  //  dest_result_addr=1152921509578747408 |  dest_result_addr=1152921509578747416
            // 0x00E5BE28: MOV x29, sp                | X29 = 1152921509578747408 (0x1000000128592E10);//ML01
            // 0x00E5BE2C: LDR x8, [x0]               | X8 = typeof(ILRuntime.Mono.Cecil.Cil.CodeReader);
            // 0x00E5BE30: LDP x9, x1, [x8, #0x1e0]   | X9 = public System.Byte System.IO.BinaryReader::ReadByte(); X1 = public System.Byte System.IO.BinaryReader::ReadByte(); //  | 
            // 0x00E5BE34: BLR x9                     | X0 = this.ReadByte();                   
            byte val_1 = this.ReadByte();
            // 0x00E5BE38: AND w0, w0, #0xff          | W0 = (val_1 & 255);                     
            val_1 = val_1 & 255;
            // 0x00E5BE3C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x00E5BE40: RET                        |  return (System.Int32)(val_1 & 255);    
            return (int)val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
    
    }

}
