using UnityEngine;

namespace Pathfinding.Ionic.Crc
{
    [System.Runtime.InteropServices.GuidAttribute] // 0x28145D4
    [System.Runtime.InteropServices.ComVisibleAttribute] // 0x28145D4
    [System.Runtime.InteropServices.ClassInterfaceAttribute] // 0x28145D4
    public class CRC32
    {
        // Fields
        private uint dwPolynomial; //  0x00000010
        private long _TotalBytesRead; //  0x00000018
        private bool reverseBits; //  0x00000020
        private uint[] crc32Table; //  0x00000028
        private uint _register; //  0x00000030
        
        // Properties
        public long TotalBytesRead { get; }
        public int Crc32Result { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0196EED0 (26668752), len: 64  VirtAddr: 0x0196EED0 RVA: 0x0196EED0 token: 100663893 methodIndex: 20815 delegateWrapperIndex: 0 methodInvoker: 0
        public CRC32()
        {
            //
            // Disasemble & Code
            // 0x0196EED0: STP x20, x19, [sp, #-0x20]! | stack[1152921509737802896] = ???;  stack[1152921509737802904] = ???;  //  dest_result_addr=1152921509737802896 |  dest_result_addr=1152921509737802904
            // 0x0196EED4: STP x29, x30, [sp, #0x10]  | stack[1152921509737802912] = ???;  stack[1152921509737802920] = ???;  //  dest_result_addr=1152921509737802912 |  dest_result_addr=1152921509737802920
            // 0x0196EED8: ADD x29, sp, #0x10         | X29 = (1152921509737802896 + 16) = 1152921509737802912 (0x1000000131D42CA0);
            // 0x0196EEDC: MOV x19, x0                | X19 = 1152921509737814928 (0x1000000131D45B90);//ML01
            // 0x0196EEE0: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x0196EEE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196EEE8: STR w8, [x19, #0x30]       | this._register = null;                   //  dest_result_addr=1152921509737814976
            this._register = 0;
            // 0x0196EEEC: BL #0x16f59f0              | this..ctor();                           
            // 0x0196EEF0: MOVZ w8, #0xedb8, lsl #16  | W8 = 3988258816 (0xEDB80000);//ML01     
            // 0x0196EEF4: MOVK w8, #0x8320           | W8 = 3988292384 (0xEDB88320);           
            // 0x0196EEF8: STR w8, [x19, #0x10]       | this.dwPolynomial = 0xEDB88320;          //  dest_result_addr=1152921509737814944
            this.dwPolynomial = -306674912;
            // 0x0196EEFC: STRB wzr, [x19, #0x20]     | this.reverseBits = false;                //  dest_result_addr=1152921509737814960
            this.reverseBits = false;
            // 0x0196EF00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196EF04: MOV x0, x19                | X0 = 1152921509737814928 (0x1000000131D45B90);//ML01
            // 0x0196EF08: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196EF0C: B #0x196efa4               | this.GenerateLookupTable(); return;     
            this.GenerateLookupTable();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196EF10 (26668816), len: 72  VirtAddr: 0x0196EF10 RVA: 0x0196EF10 token: 100663894 methodIndex: 20816 delegateWrapperIndex: 0 methodInvoker: 0
        public CRC32(bool reverseBits)
        {
            //
            // Disasemble & Code
            // 0x0196EF10: STP x20, x19, [sp, #-0x20]! | stack[1152921509737914896] = ???;  stack[1152921509737914904] = ???;  //  dest_result_addr=1152921509737914896 |  dest_result_addr=1152921509737914904
            // 0x0196EF14: STP x29, x30, [sp, #0x10]  | stack[1152921509737914912] = ???;  stack[1152921509737914920] = ???;  //  dest_result_addr=1152921509737914912 |  dest_result_addr=1152921509737914920
            // 0x0196EF18: ADD x29, sp, #0x10         | X29 = (1152921509737914896 + 16) = 1152921509737914912 (0x1000000131D5E220);
            // 0x0196EF1C: MOV w19, w1                | W19 = reverseBits;//m1                  
            // 0x0196EF20: MOV x20, x0                | X20 = 1152921509737926928 (0x1000000131D61110);//ML01
            // 0x0196EF24: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x0196EF28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196EF2C: STR w8, [x20, #0x30]       | this._register = null;                   //  dest_result_addr=1152921509737926976
            this._register = 0;
            // 0x0196EF30: BL #0x16f59f0              | this..ctor();                           
            // 0x0196EF34: MOVZ w9, #0xedb8, lsl #16  | W9 = 3988258816 (0xEDB80000);//ML01     
            // 0x0196EF38: MOVK w9, #0x8320           | W9 = 3988292384 (0xEDB88320);           
            // 0x0196EF3C: AND w8, w19, #1            | W8 = (reverseBits & 1);                 
            bool val_1 = reverseBits;
            // 0x0196EF40: STR w9, [x20, #0x10]       | this.dwPolynomial = 0xEDB88320;          //  dest_result_addr=1152921509737926944
            this.dwPolynomial = -306674912;
            // 0x0196EF44: STRB w8, [x20, #0x20]      | this.reverseBits = (reverseBits & 1);    //  dest_result_addr=1152921509737926960
            this.reverseBits = val_1;
            // 0x0196EF48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0196EF4C: MOV x0, x20                | X0 = 1152921509737926928 (0x1000000131D61110);//ML01
            // 0x0196EF50: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0196EF54: B #0x196efa4               | this.GenerateLookupTable(); return;     
            this.GenerateLookupTable();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196EF58 (26668888), len: 76  VirtAddr: 0x0196EF58 RVA: 0x0196EF58 token: 100663895 methodIndex: 20817 delegateWrapperIndex: 0 methodInvoker: 0
        public CRC32(int polynomial, bool reverseBits)
        {
            //
            // Disasemble & Code
            // 0x0196EF58: STP x22, x21, [sp, #-0x30]! | stack[1152921509738026880] = ???;  stack[1152921509738026888] = ???;  //  dest_result_addr=1152921509738026880 |  dest_result_addr=1152921509738026888
            // 0x0196EF5C: STP x20, x19, [sp, #0x10]  | stack[1152921509738026896] = ???;  stack[1152921509738026904] = ???;  //  dest_result_addr=1152921509738026896 |  dest_result_addr=1152921509738026904
            // 0x0196EF60: STP x29, x30, [sp, #0x20]  | stack[1152921509738026912] = ???;  stack[1152921509738026920] = ???;  //  dest_result_addr=1152921509738026912 |  dest_result_addr=1152921509738026920
            // 0x0196EF64: ADD x29, sp, #0x20         | X29 = (1152921509738026880 + 32) = 1152921509738026912 (0x1000000131D797A0);
            // 0x0196EF68: MOV w20, w1                | W20 = polynomial;//m1                   
            // 0x0196EF6C: MOV x21, x0                | X21 = 1152921509738038928 (0x1000000131D7C690);//ML01
            // 0x0196EF70: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x0196EF74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196EF78: MOV w19, w2                | W19 = reverseBits;//m1                  
            // 0x0196EF7C: STR w8, [x21, #0x30]       | this._register = null;                   //  dest_result_addr=1152921509738038976
            this._register = 0;
            // 0x0196EF80: BL #0x16f59f0              | this..ctor();                           
            // 0x0196EF84: AND w8, w19, #1            | W8 = (reverseBits & 1);                 
            bool val_1 = reverseBits;
            // 0x0196EF88: STR w20, [x21, #0x10]      | this.dwPolynomial = polynomial;          //  dest_result_addr=1152921509738038944
            this.dwPolynomial = polynomial;
            // 0x0196EF8C: STRB w8, [x21, #0x20]      | this.reverseBits = (reverseBits & 1);    //  dest_result_addr=1152921509738038960
            this.reverseBits = val_1;
            // 0x0196EF90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0196EF94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0196EF98: MOV x0, x21                | X0 = 1152921509738038928 (0x1000000131D7C690);//ML01
            // 0x0196EF9C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0196EFA0: B #0x196efa4               | this.GenerateLookupTable(); return;     
            this.GenerateLookupTable();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F254 (26669652), len: 8  VirtAddr: 0x0196F254 RVA: 0x0196F254 token: 100663896 methodIndex: 20818 delegateWrapperIndex: 0 methodInvoker: 0
        public long get_TotalBytesRead()
        {
            //
            // Disasemble & Code
            // 0x0196F254: LDR x0, [x0, #0x18]        | X0 = this._TotalBytesRead; //P2         
            // 0x0196F258: RET                        |  return (System.Int64)this._TotalBytesRead;
            return this._TotalBytesRead;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F25C (26669660), len: 12  VirtAddr: 0x0196F25C RVA: 0x0196F25C token: 100663897 methodIndex: 20819 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Crc32Result()
        {
            //
            // Disasemble & Code
            // 0x0196F25C: LDR w8, [x0, #0x30]        | W8 = this._register; //P2               
            // 0x0196F260: MVN w0, w8                 | W0 = ~(this._register);                 
            // 0x0196F264: RET                        |  return (System.Int32)~(this._register);
            return (int)~this._register;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F268 (26669672), len: 8  VirtAddr: 0x0196F268 RVA: 0x0196F268 token: 100663898 methodIndex: 20820 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetCrc32(System.IO.Stream input)
        {
            //
            // Disasemble & Code
            // 0x0196F268: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0196F26C: B #0x196f270               | return this.GetCrc32AndCopy(input:  input, output:  0);
            return this.GetCrc32AndCopy(input:  input, output:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F270 (26669680), len: 408  VirtAddr: 0x0196F270 RVA: 0x0196F270 token: 100663899 methodIndex: 20821 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetCrc32AndCopy(System.IO.Stream input, System.IO.Stream output)
        {
            //
            // Disasemble & Code
            //  | 
            int val_2;
            // 0x0196F270: STP x24, x23, [sp, #-0x40]! | stack[1152921509738492416] = ???;  stack[1152921509738492424] = ???;  //  dest_result_addr=1152921509738492416 |  dest_result_addr=1152921509738492424
            // 0x0196F274: STP x22, x21, [sp, #0x10]  | stack[1152921509738492432] = ???;  stack[1152921509738492440] = ???;  //  dest_result_addr=1152921509738492432 |  dest_result_addr=1152921509738492440
            // 0x0196F278: STP x20, x19, [sp, #0x20]  | stack[1152921509738492448] = ???;  stack[1152921509738492456] = ???;  //  dest_result_addr=1152921509738492448 |  dest_result_addr=1152921509738492456
            // 0x0196F27C: STP x29, x30, [sp, #0x30]  | stack[1152921509738492464] = ???;  stack[1152921509738492472] = ???;  //  dest_result_addr=1152921509738492464 |  dest_result_addr=1152921509738492472
            // 0x0196F280: ADD x29, sp, #0x30         | X29 = (1152921509738492416 + 48) = 1152921509738492464 (0x1000000131DEB230);
            // 0x0196F284: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x0196F288: LDRB w8, [x22, #0x3d3]     | W8 = (bool)static_value_037393D3;       
            // 0x0196F28C: MOV x19, x2                | X19 = output;//m1                       
            // 0x0196F290: MOV x20, x1                | X20 = input;//m1                        
            // 0x0196F294: MOV x21, x0                | X21 = 1152921509738504480 (0x1000000131DEE120);//ML01
            // 0x0196F298: TBNZ w8, #0, #0x196f2b4    | if (static_value_037393D3 == true) goto label_0;
            // 0x0196F29C: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x0196F2A0: LDR x8, [x8, #0x4a0]       | X8 = 0x2B92D9C;                         
            // 0x0196F2A4: LDR w0, [x8]               | W0 = 0x222C;                            
            // 0x0196F2A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x222C, ????);     
            // 0x0196F2AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196F2B0: STRB w8, [x22, #0x3d3]     | static_value_037393D3 = true;            //  dest_result_addr=57906131
            label_0:
            // 0x0196F2B4: CBZ x20, #0x196f3c8        | if (input == null) goto label_1;        
            if(input == null)
            {
                goto label_1;
            }
            // 0x0196F2B8: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x0196F2BC: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x0196F2C0: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
            // 0x0196F2C4: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F2C8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x0196F2CC: ORR w1, wzr, #0x2000       | W1 = 8192(0x2000);                      
            // 0x0196F2D0: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F2D4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x0196F2D8: STR xzr, [x21, #0x18]      | this._TotalBytesRead = 0;                //  dest_result_addr=1152921509738504504
            this._TotalBytesRead = 0;
            // 0x0196F2DC: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x0196F2E0: MOV x22, x0                | X22 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F2E4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0196F2E8: ORR w3, wzr, #0x2000       | W3 = 8192(0x2000);                      
            // 0x0196F2EC: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x0196F2F0: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x0196F2F4: MOV x0, x20                | X0 = input;//m1                         
            // 0x0196F2F8: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F2FC: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x0196F300: MOV w23, w0                | W23 = input;//m1                        
            val_2 = input;
            // 0x0196F304: CBZ x19, #0x196f328        | if (output == null) goto label_2;       
            if(output == null)
            {
                goto label_2;
            }
            // 0x0196F308: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x0196F30C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0196F310: MOV x0, x19                | X0 = output;//m1                        
            // 0x0196F314: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F318: LDR x9, [x8, #0x260]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_260;
            // 0x0196F31C: LDR x4, [x8, #0x268]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_268;
            // 0x0196F320: MOV w3, w23                | W3 = input;//m1                         
            // 0x0196F324: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_260();
            label_2:
            // 0x0196F328: LDR x8, [x21, #0x18]       | X8 = this._TotalBytesRead; //P2         
            long val_2 = this._TotalBytesRead;
            // 0x0196F32C: CMP w23, #1                | STATE = COMPARE(input, 0x1)             
            // 0x0196F330: ADD x8, x8, w23, sxtw      | X8 = (this._TotalBytesRead + (input) << );
            val_2 = val_2 + (val_2 << );
            // 0x0196F334: STR x8, [x21, #0x18]       | this._TotalBytesRead = (this._TotalBytesRead + (input) << );  //  dest_result_addr=1152921509738504504
            this._TotalBytesRead = val_2;
            // 0x0196F338: B.LT #0x196f3ac            | if (val_2 < 0x1) goto label_3;          
            if(val_2 < 1)
            {
                goto label_3;
            }
            label_5:
            // 0x0196F33C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0196F340: MOV x0, x21                | X0 = 1152921509738504480 (0x1000000131DEE120);//ML01
            // 0x0196F344: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F348: MOV w3, w23                | W3 = input;//m1                         
            // 0x0196F34C: BL #0x196f408              | this.SlurpBlock(block:  null, offset:  0, count:  val_2);
            this.SlurpBlock(block:  null, offset:  0, count:  val_2);
            // 0x0196F350: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x0196F354: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0196F358: ORR w3, wzr, #0x2000       | W3 = 8192(0x2000);                      
            // 0x0196F35C: MOV x0, x20                | X0 = input;//m1                         
            // 0x0196F360: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x0196F364: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x0196F368: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F36C: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x0196F370: MOV w23, w0                | W23 = input;//m1                        
            val_2 = input;
            // 0x0196F374: CBZ x19, #0x196f398        | if (output == null) goto label_4;       
            if(output == null)
            {
                goto label_4;
            }
            // 0x0196F378: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x0196F37C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0196F380: MOV x0, x19                | X0 = output;//m1                        
            // 0x0196F384: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x0196F388: LDR x9, [x8, #0x260]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_260;
            // 0x0196F38C: LDR x4, [x8, #0x268]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_268;
            // 0x0196F390: MOV w3, w23                | W3 = input;//m1                         
            // 0x0196F394: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_260();
            label_4:
            // 0x0196F398: LDR x8, [x21, #0x18]       | X8 = this._TotalBytesRead; //P2         
            long val_3 = this._TotalBytesRead;
            // 0x0196F39C: CMP w23, #0                | STATE = COMPARE(input, 0x0)             
            // 0x0196F3A0: ADD x8, x8, w23, sxtw      | X8 = (this._TotalBytesRead + (input) << );
            val_3 = val_3 + (val_2 << );
            // 0x0196F3A4: STR x8, [x21, #0x18]       | this._TotalBytesRead = (this._TotalBytesRead + (input) << );  //  dest_result_addr=1152921509738504504
            this._TotalBytesRead = val_3;
            // 0x0196F3A8: B.GT #0x196f33c            | if (val_2 > null) goto label_5;         
            if(val_2 > 0)
            {
                goto label_5;
            }
            label_3:
            // 0x0196F3AC: LDR w8, [x21, #0x30]       | W8 = this._register; //P2               
            // 0x0196F3B0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0196F3B4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0196F3B8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0196F3BC: MVN w0, w8                 | W0 = ~(this._register);                 
            // 0x0196F3C0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0196F3C4: RET                        |  return (System.Int32)~(this._register);
            return (int)~this._register;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_1:
            // 0x0196F3C8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0196F3CC: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x0196F3D0: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x0196F3D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x0196F3D8: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0196F3DC: LDR x8, [x8, #0x9b8]       | X8 = (string**)(1152921509738479312)("The input stream must not be null.");
            // 0x0196F3E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0196F3E4: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0196F3E8: LDR x1, [x8]               | X1 = "The input stream must not be null.";
            // 0x0196F3EC: BL #0x1c32b48              | .ctor(message:  "The input stream must not be null.");
            val_1 = new System.Exception(message:  "The input stream must not be null.");
            // 0x0196F3F0: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x0196F3F4: LDR x8, [x8, #0xc68]       | X8 = 1152921509738479456;               
            // 0x0196F3F8: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0196F3FC: LDR x1, [x8]               | X1 = public System.Int32 Pathfinding.Ionic.Crc.CRC32::GetCrc32AndCopy(System.IO.Stream input, System.IO.Stream output);
            // 0x0196F400: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x0196F404: BL #0x196f408              | SlurpBlock(block:  public System.Int32 Pathfinding.Ionic.Crc.CRC32::GetCrc32AndCopy(System.IO.Stream input, System.IO.Stream output), offset:  0, count:  0);
            SlurpBlock(block:  public System.Int32 Pathfinding.Ionic.Crc.CRC32::GetCrc32AndCopy(System.IO.Stream input, System.IO.Stream output), offset:  0, count:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F578 (26670456), len: 4  VirtAddr: 0x0196F578 RVA: 0x0196F578 token: 100663900 methodIndex: 20822 delegateWrapperIndex: 0 methodInvoker: 0
        public int ComputeCrc32(int W, byte B)
        {
            //
            // Disasemble & Code
            // 0x0196F578: B #0x196f57c               | return this._InternalComputeCrc32(W:  W, B:  B);
            return this._InternalComputeCrc32(W:  W, B:  B);
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F57C (26670460), len: 96  VirtAddr: 0x0196F57C RVA: 0x0196F57C token: 100663901 methodIndex: 20823 delegateWrapperIndex: 0 methodInvoker: 0
        internal int _InternalComputeCrc32(uint W, byte B)
        {
            //
            // Disasemble & Code
            // 0x0196F57C: STP x22, x21, [sp, #-0x30]! | stack[1152921509738761488] = ???;  stack[1152921509738761496] = ???;  //  dest_result_addr=1152921509738761488 |  dest_result_addr=1152921509738761496
            // 0x0196F580: STP x20, x19, [sp, #0x10]  | stack[1152921509738761504] = ???;  stack[1152921509738761512] = ???;  //  dest_result_addr=1152921509738761504 |  dest_result_addr=1152921509738761512
            // 0x0196F584: STP x29, x30, [sp, #0x20]  | stack[1152921509738761520] = ???;  stack[1152921509738761528] = ???;  //  dest_result_addr=1152921509738761520 |  dest_result_addr=1152921509738761528
            // 0x0196F588: ADD x29, sp, #0x20         | X29 = (1152921509738761488 + 32) = 1152921509738761520 (0x1000000131E2CD30);
            // 0x0196F58C: LDR x21, [x0, #0x28]       | X21 = this.crc32Table; //P2             
            // 0x0196F590: MOV w20, w2                | W20 = B;//m1                            
            byte val_3 = B;
            // 0x0196F594: MOV w19, w1                | W19 = W;//m1                            
            // 0x0196F598: CBNZ x21, #0x196f5a0       | if (this.crc32Table != null) goto label_0;
            if(this.crc32Table != null)
            {
                goto label_0;
            }
            // 0x0196F59C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196F5A0: LDR w8, [x21, #0x18]       | W8 = this.crc32Table.Length; //P2       
            // 0x0196F5A4: EOR w9, w20, w19           | W9 = (B ^ W);                           
            byte val_1 = val_3 ^ W;
            // 0x0196F5A8: AND w20, w9, #0xff         | W20 = ((B ^ W) & 255);                  
            val_3 = val_1 & 255;
            // 0x0196F5AC: CMP w20, w8                | STATE = COMPARE(((B ^ W) & 255), this.crc32Table.Length)
            // 0x0196F5B0: B.LO #0x196f5c0            | if (B < this.crc32Table.Length) goto label_1;
            if(val_3 < this.crc32Table.Length)
            {
                goto label_1;
            }
            // 0x0196F5B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0196F5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F5BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x0196F5C0: ADD x8, x21, x20, lsl #2   | X8 = this.crc32Table[((B ^ W) & 255)]; //PARR1 
            // 0x0196F5C4: LDR w8, [x8, #0x20]        | W8 = this.crc32Table[((B ^ W) & 255)][0]
            uint val_4 = this.crc32Table[val_3];
            // 0x0196F5C8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0196F5CC: EOR w0, w8, w19, lsr #8    | W0 = (this.crc32Table[((B ^ W) & 255)][0] ^ (W) >> 8);
            uint val_2 = val_4 ^ (W >> 8);
            // 0x0196F5D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0196F5D4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0196F5D8: RET                        |  return (System.Int32)(this.crc32Table[((B ^ W) & 255)][0] ^ (W) >> 8);
            return (int)val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F408 (26670088), len: 368  VirtAddr: 0x0196F408 RVA: 0x0196F408 token: 100663902 methodIndex: 20824 delegateWrapperIndex: 0 methodInvoker: 0
        public void SlurpBlock(byte[] block, int offset, int count)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            System.UInt32[] val_7;
            //  | 
            uint val_8;
            label_11:
            // 0x0196F408: STP x26, x25, [sp, #-0x50]! | stack[1152921509739022080] = ???;  stack[1152921509739022088] = ???;  //  dest_result_addr=1152921509739022080 |  dest_result_addr=1152921509739022088
            // 0x0196F40C: STP x24, x23, [sp, #0x10]  | stack[1152921509739022096] = ???;  stack[1152921509739022104] = ???;  //  dest_result_addr=1152921509739022096 |  dest_result_addr=1152921509739022104
            // 0x0196F410: STP x22, x21, [sp, #0x20]  | stack[1152921509739022112] = ???;  stack[1152921509739022120] = ???;  //  dest_result_addr=1152921509739022112 |  dest_result_addr=1152921509739022120
            // 0x0196F414: STP x20, x19, [sp, #0x30]  | stack[1152921509739022128] = ???;  stack[1152921509739022136] = ???;  //  dest_result_addr=1152921509739022128 |  dest_result_addr=1152921509739022136
            // 0x0196F418: STP x29, x30, [sp, #0x40]  | stack[1152921509739022144] = ???;  stack[1152921509739022152] = ???;  //  dest_result_addr=1152921509739022144 |  dest_result_addr=1152921509739022152
            // 0x0196F41C: ADD x29, sp, #0x40         | X29 = (1152921509739022080 + 64) = 1152921509739022144 (0x1000000131E6C740);
            // 0x0196F420: ADRP x23, #0x3739000       | X23 = 57905152 (0x3739000);             
            // 0x0196F424: LDRB w8, [x23, #0x3d4]     | W8 = (bool)static_value_037393D4;       
            // 0x0196F428: MOV w19, w3                | W19 = count;//m1                        
            // 0x0196F42C: MOV w22, w2                | W22 = offset;//m1                       
            // 0x0196F430: MOV x21, x1                | X21 = block;//m1                        
            // 0x0196F434: MOV x20, x0                | X20 = 1152921509739034160 (0x1000000131E6F630);//ML01
            // 0x0196F438: TBNZ w8, #0, #0x196f454    | if (static_value_037393D4 == true) goto label_0;
            // 0x0196F43C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x0196F440: LDR x8, [x8, #0xb68]       | X8 = 0x2B92DA0;                         
            // 0x0196F444: LDR w0, [x8]               | W0 = 0x222D;                            
            // 0x0196F448: BL #0x2782188              | X0 = sub_2782188( ?? 0x222D, ????);     
            // 0x0196F44C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196F450: STRB w8, [x23, #0x3d4]     | static_value_037393D4 = true;            //  dest_result_addr=57906132
            label_0:
            // 0x0196F454: CBZ x21, #0x196f538        | if (block == null) goto label_1;        
            if(block == null)
            {
                goto label_1;
            }
            // 0x0196F458: CMP w19, #1                | STATE = COMPARE(count, 0x1)             
            // 0x0196F45C: B.LT #0x196f514            | if (count < 1) goto label_2;            
            if(count < 1)
            {
                goto label_2;
            }
            // 0x0196F460: MOV w23, w19               | W23 = count;//m1                        
            label_10:
            // 0x0196F464: LDR w8, [x21, #0x18]       | W8 = block.Length; //P2                 
            // 0x0196F468: SXTW x24, w22              | X24 = (long)(int)(offset);              
            // 0x0196F46C: CMP w22, w8                | STATE = COMPARE(offset, block.Length)   
            // 0x0196F470: B.LO #0x196f480            | if (offset < block.Length) goto label_3;
            if(offset < block.Length)
            {
                goto label_3;
            }
            // 0x0196F474: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x222D, ????);     
            // 0x0196F478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F47C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x222D, ????);     
            label_3:
            // 0x0196F480: ADD x8, x21, x24           | X8 = block[(long)(int)(offset)]; //PARR1 
            // 0x0196F484: LDRB w8, [x8, #0x20]       | W8 = block[(long)(int)(offset)][0]      
            byte val_6 = block[(long)offset];
            // 0x0196F488: LDR w22, [x20, #0x30]      | W22 = this._register; //P2              
            // 0x0196F48C: LDRB w9, [x20, #0x20]      | W9 = this.reverseBits; //P2             
            // 0x0196F490: CBZ w9, #0x196f4cc         | if (this.reverseBits == false) goto label_4;
            if(this.reverseBits == false)
            {
                goto label_4;
            }
            // 0x0196F494: LDR x25, [x20, #0x28]      | X25 = this.crc32Table; //P2             
            val_7 = this.crc32Table;
            // 0x0196F498: EOR w26, w8, w22, lsr #24  | W26 = (block[(long)(int)(offset)][0] ^ (this._register) >> 24);
            byte val_1 = val_6 ^ (this._register >> 24);
            // 0x0196F49C: CBNZ x25, #0x196f4a4       | if (this.crc32Table != null) goto label_5;
            if(val_7 != null)
            {
                goto label_5;
            }
            // 0x0196F4A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x222D, ????);     
            label_5:
            // 0x0196F4A4: LDR w8, [x25, #0x18]       | W8 = this.crc32Table.Length; //P2       
            // 0x0196F4A8: CMP w26, w8                | STATE = COMPARE((block[(long)(int)(offset)][0] ^ (this._register) >> 24), this.crc32Table.Length)
            // 0x0196F4AC: B.LO #0x196f4bc            | if (val_1 < this.crc32Table.Length) goto label_6;
            if(val_1 < this.crc32Table.Length)
            {
                goto label_6;
            }
            // 0x0196F4B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x222D, ????);     
            // 0x0196F4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F4B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x222D, ????);     
            label_6:
            // 0x0196F4BC: ADD x8, x25, x26, lsl #2   | X8 = this.crc32Table[(block[(long)(int)(offset)][0] ^ (this._register) >> 24)]; //PARR1 
            // 0x0196F4C0: LDR w8, [x8, #0x20]        | W8 = this.crc32Table[(block[(long)(int)(offset)][0] ^ (this._register) >> 24)][0]
            uint val_7 = val_7[val_1];
            // 0x0196F4C4: EOR w8, w8, w22, lsl #8    | W8 = (this.crc32Table[(block[(long)(int)(offset)][0] ^ (this._register) >> 24)][0] ^ (this._register
            val_8 = val_7 ^ (this._register << 8);
            // 0x0196F4C8: B #0x196f504               |  goto label_7;                          
            goto label_7;
            label_4:
            // 0x0196F4CC: LDR x25, [x20, #0x28]      | X25 = this.crc32Table; //P2             
            val_7 = this.crc32Table;
            // 0x0196F4D0: AND w9, w22, #0xff         | W9 = (this._register & 255);            
            uint val_2 = this._register & 255;
            // 0x0196F4D4: EOR w26, w9, w8            | W26 = ((this._register & 255) ^ block[(long)(int)(offset)][0]);
            uint val_3 = val_2 ^ val_6;
            // 0x0196F4D8: CBNZ x25, #0x196f4e0       | if (this.crc32Table != null) goto label_8;
            if(val_7 != null)
            {
                goto label_8;
            }
            // 0x0196F4DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x222D, ????);     
            label_8:
            // 0x0196F4E0: LDR w8, [x25, #0x18]       | W8 = this.crc32Table.Length; //P2       
            // 0x0196F4E4: CMP w26, w8                | STATE = COMPARE(((this._register & 255) ^ block[(long)(int)(offset)][0]), this.crc32Table.Length)
            // 0x0196F4E8: B.LO #0x196f4f8            | if (val_3 < this.crc32Table.Length) goto label_9;
            if(val_3 < this.crc32Table.Length)
            {
                goto label_9;
            }
            // 0x0196F4EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x222D, ????);     
            // 0x0196F4F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F4F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x222D, ????);     
            label_9:
            // 0x0196F4F8: ADD x8, x25, x26, lsl #2   | X8 = this.crc32Table[((this._register & 255) ^ block[(long)(int)(offset)][0])]; //PARR1 
            // 0x0196F4FC: LDR w8, [x8, #0x20]        | W8 = this.crc32Table[((this._register & 255) ^ block[(long)(int)(offset)][0])][0]
            uint val_8 = val_7[val_3];
            // 0x0196F500: EOR w8, w8, w22, lsr #8    | W8 = (this.crc32Table[((this._register & 255) ^ block[(long)(int)(offset)][0])][0] ^ (this._register
            val_8 = val_8 ^ (this._register >> 8);
            label_7:
            // 0x0196F504: ADD w22, w24, #1           | W22 = ((long)(int)(offset) + 1);        
            var val_4 = (long)offset + 1;
            // 0x0196F508: SUB w23, w23, #1           | W23 = (count - 1);                      
            val_6 = count - 1;
            // 0x0196F50C: STR w8, [x20, #0x30]       | this._register = (this.crc32Table[((this._register & 255) ^ block[(long)(int)(offset)][0])][0] ^ (this._register) >> 8);  //  dest_result_addr=1152921509739034208
            this._register = val_8;
            // 0x0196F510: CBNZ w23, #0x196f464       | if ((count - 1) != 0) goto label_10;    
            if(val_6 != 0)
            {
                goto label_10;
            }
            label_2:
            // 0x0196F514: LDR x8, [x20, #0x18]       | X8 = this._TotalBytesRead; //P2         
            long val_9 = this._TotalBytesRead;
            // 0x0196F518: ADD x8, x8, w19, sxtw      | X8 = (this._TotalBytesRead + (count) << );
            val_9 = val_9 + (count << );
            // 0x0196F51C: STR x8, [x20, #0x18]       | this._TotalBytesRead = (this._TotalBytesRead + (count) << );  //  dest_result_addr=1152921509739034184
            this._TotalBytesRead = val_9;
            // 0x0196F520: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0196F524: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0196F528: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0196F52C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0196F530: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0196F534: RET                        |  return;                                
            return;
            label_1:
            // 0x0196F538: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0196F53C: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x0196F540: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_5 = null;
            // 0x0196F544: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x0196F548: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x0196F54C: LDR x8, [x8, #0x4c0]       | X8 = (string**)(1152921509739008992)("The data buffer must not be null.");
            // 0x0196F550: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0196F554: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0196F558: LDR x1, [x8]               | X1 = "The data buffer must not be null.";
            // 0x0196F55C: BL #0x1c32b48              | .ctor(message:  "The data buffer must not be null.");
            val_5 = new System.Exception(message:  "The data buffer must not be null.");
            // 0x0196F560: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x0196F564: LDR x8, [x8, #0xaf0]       | X8 = 1152921509739009136;               
            // 0x0196F568: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0196F56C: LDR x1, [x8]               | X1 = public System.Void Pathfinding.Ionic.Crc.CRC32::SlurpBlock(byte[] block, int offset, int count);
            // 0x0196F570: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x0196F574: BL #0x196f408              |  R0 = label_11();                       
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F5DC (26670556), len: 344  VirtAddr: 0x0196F5DC RVA: 0x0196F5DC token: 100663903 methodIndex: 20825 delegateWrapperIndex: 0 methodInvoker: 0
        private static uint ReverseBits(uint data)
        {
            //
            // Disasemble & Code
            // 0x0196F5DC: LSL w12, w1, #0x1d         | W12 = (W1 << 29);                       
            var val_1 = W1 << 29;
            // 0x0196F5E0: AND w12, w12, #0x40000000  | W12 = ((W1 << 29) & 1073741824);        
            val_1 = val_1 & 1073741824;
            // 0x0196F5E4: LSR w11, w1, #2            | W11 = (W1 >> 2);                        
            var val_2 = W1 >> 2;
            // 0x0196F5E8: BFI w12, w1, #0x1f, #1     | W12 = ((W1 << 29) & 1073741824) | W1    
            // 0x0196F5EC: LSR w10, w1, #3            | W10 = (W1 >> 3);                        
            var val_3 = W1 >> 3;
            // 0x0196F5F0: BFI w12, w11, #0x1d, #1    | W12 = ((W1 << 29) & 1073741824) | (W1 >> 2)
            // 0x0196F5F4: LSR w9, w1, #4             | W9 = (W1 >> 4);                         
            var val_4 = W1 >> 4;
            // 0x0196F5F8: BFI w12, w10, #0x1c, #1    | W12 = ((W1 << 29) & 1073741824) | (W1 >> 3)
            // 0x0196F5FC: LSR w8, w1, #5             | W8 = (W1 >> 5);                         
            var val_5 = W1 >> 5;
            // 0x0196F600: LSL w11, w1, #0x13         | W11 = (W1 << 19);                       
            var val_6 = W1 << 19;
            // 0x0196F604: BFI w12, w9, #0x1b, #1     | W12 = ((W1 << 29) & 1073741824) | (W1 >> 4)
            // 0x0196F608: LSL w9, w1, #0x11          | W9 = (W1 << 17);                        
            var val_7 = W1 << 17;
            // 0x0196F60C: AND w11, w11, #0x2000000   | W11 = ((W1 << 19) & 33554432);          
            val_6 = val_6 & 33554432;
            // 0x0196F610: BFI w12, w8, #0x1a, #1     | W12 = ((W1 << 29) & 1073741824) | (W1 >> 5)
            // 0x0196F614: ORR w11, w12, w11          | W11 = (((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432));
            val_6 = val_1 | val_6;
            // 0x0196F618: LSL w12, w1, #0xf          | W12 = (W1 << 15);                       
            var val_8 = W1 << 15;
            // 0x0196F61C: AND w9, w9, #0x1000000     | W9 = ((W1 << 17) & 16777216);           
            val_7 = val_7 & 16777216;
            // 0x0196F620: ORR w9, w11, w9            | W9 = ((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216));
            val_7 = val_6 | val_7;
            // 0x0196F624: LSL w11, w1, #0xd          | W11 = (W1 << 13);                       
            var val_9 = W1 << 13;
            // 0x0196F628: AND w12, w12, #0x800000    | W12 = ((W1 << 15) & 8388608);           
            val_8 = val_8 & 8388608;
            // 0x0196F62C: ORR w9, w9, w12            | W9 = (((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 << 15
            val_7 = val_7 | val_8;
            // 0x0196F630: LSL w12, w1, #0xb          | W12 = (W1 << 11);                       
            var val_10 = W1 << 11;
            // 0x0196F634: AND w11, w11, #0x400000    | W11 = ((W1 << 13) & 4194304);           
            val_9 = val_9 & 4194304;
            // 0x0196F638: ORR w9, w9, w11            | W9 = ((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 << 1
            val_7 = val_7 | val_9;
            // 0x0196F63C: LSL w11, w1, #9            | W11 = (W1 << 9);                        
            var val_11 = W1 << 9;
            // 0x0196F640: AND w12, w12, #0x200000    | W12 = ((W1 << 11) & 2097152);           
            val_10 = val_10 & 2097152;
            // 0x0196F644: ORR w9, w9, w12            | W9 = (((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 << 
            val_7 = val_7 | val_10;
            // 0x0196F648: LSL w12, w1, #7            | W12 = (W1 << 7);                        
            var val_12 = W1 << 7;
            // 0x0196F64C: AND w11, w11, #0x100000    | W11 = ((W1 << 9) & 1048576);            
            val_11 = val_11 & 1048576;
            // 0x0196F650: ORR w9, w9, w11            | W9 = ((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 <<
            val_7 = val_7 | val_11;
            // 0x0196F654: LSL w11, w1, #5            | W11 = (W1 << 5);                        
            var val_13 = W1 << 5;
            // 0x0196F658: AND w12, w12, #0x80000     | W12 = ((W1 << 7) & 524288);             
            val_12 = val_12 & 524288;
            // 0x0196F65C: ORR w9, w9, w12            | W9 = (((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 <
            val_7 = val_7 | val_12;
            // 0x0196F660: LSL w12, w1, #3            | W12 = (W1 << 3);                        
            var val_14 = W1 << 3;
            // 0x0196F664: AND w11, w11, #0x40000     | W11 = ((W1 << 5) & 262144);             
            val_13 = val_13 & 262144;
            // 0x0196F668: ORR w9, w9, w11            | W9 = ((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 
            val_7 = val_7 | val_13;
            // 0x0196F66C: LSL w11, w1, #1            | W11 = (W1 << 1);                        
            var val_15 = W1 << 1;
            // 0x0196F670: AND w12, w12, #0x20000     | W12 = ((W1 << 3) & 131072);             
            val_14 = val_14 & 131072;
            // 0x0196F674: ORR w9, w9, w12            | W9 = (((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1
            val_7 = val_7 | val_14;
            // 0x0196F678: LSR w12, w1, #1            | W12 = (W1 >> 1);                        
            var val_16 = W1 >> 1;
            // 0x0196F67C: AND w11, w11, #0x10000     | W11 = ((W1 << 1) & 65536);              
            val_15 = val_15 & 65536;
            // 0x0196F680: ORR w9, w9, w11            | W9 = ((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W
            val_7 = val_7 | val_15;
            // 0x0196F684: AND w12, w12, #0x8000      | W12 = ((W1 >> 1) & 32768);              
            val_16 = val_16 & 32768;
            // 0x0196F688: ORR w9, w9, w12            | W9 = (((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((
            val_7 = val_7 | val_16;
            // 0x0196F68C: AND w10, w10, #0x4000      | W10 = ((W1 >> 3) & 16384);              
            val_3 = val_3 & 16384;
            // 0x0196F690: LSR w11, w1, #7            | W11 = (W1 >> 7);                        
            var val_17 = W1 >> 7;
            // 0x0196F694: ORR w9, w9, w10            | W9 = ((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | (
            val_7 = val_7 | val_3;
            // 0x0196F698: AND w8, w8, #0x2000        | W8 = ((W1 >> 5) & 8192);                
            val_5 = val_5 & 8192;
            // 0x0196F69C: LSR w12, w1, #9            | W12 = (W1 >> 9);                        
            var val_18 = W1 >> 9;
            // 0x0196F6A0: ORR w8, w9, w8             | W8 = (((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | 
            val_5 = val_7 | val_5;
            // 0x0196F6A4: AND w11, w11, #0x1000      | W11 = ((W1 >> 7) & 4096);               
            val_17 = val_17 & 4096;
            // 0x0196F6A8: LSR w10, w1, #0xb          | W10 = (W1 >> 11);                       
            var val_19 = W1 >> 11;
            // 0x0196F6AC: ORR w8, w8, w11            | W8 = ((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) |
            val_5 = val_5 | val_17;
            // 0x0196F6B0: AND w12, w12, #0x800       | W12 = ((W1 >> 9) & 2048);               
            val_18 = val_18 & 2048;
            // 0x0196F6B4: LSR w9, w1, #0xd           | W9 = (W1 >> 13);                        
            var val_20 = W1 >> 13;
            // 0x0196F6B8: ORR w8, w8, w12            | W8 = (((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) 
            val_5 = val_5 | val_18;
            // 0x0196F6BC: AND w10, w10, #0x400       | W10 = ((W1 >> 11) & 1024);              
            val_19 = val_19 & 1024;
            // 0x0196F6C0: LSR w11, w1, #0xf          | W11 = (W1 >> 15);                       
            var val_21 = W1 >> 15;
            // 0x0196F6C4: ORR w8, w8, w10            | W8 = ((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216))
            val_5 = val_5 | val_19;
            // 0x0196F6C8: AND w9, w9, #0x200         | W9 = ((W1 >> 13) & 512);                
            val_20 = val_20 & 512;
            // 0x0196F6CC: LSR w12, w1, #0x11         | W12 = (W1 >> 17);                       
            var val_22 = W1 >> 17;
            // 0x0196F6D0: ORR w8, w8, w9             | W8 = (((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)
            val_5 = val_5 | val_20;
            // 0x0196F6D4: AND w11, w11, #0x100       | W11 = ((W1 >> 15) & 256);               
            val_21 = val_21 & 256;
            // 0x0196F6D8: LSR w10, w1, #0x13         | W10 = (W1 >> 19);                       
            var val_23 = W1 >> 19;
            // 0x0196F6DC: ORR w8, w8, w11            | W8 = ((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216
            val_5 = val_5 | val_21;
            // 0x0196F6E0: AND w12, w12, #0x80        | W12 = ((W1 >> 17) & 128);               
            val_22 = val_22 & 128;
            // 0x0196F6E4: LSR w9, w1, #0x15          | W9 = (W1 >> 21);                        
            var val_24 = W1 >> 21;
            // 0x0196F6E8: ORR w8, w8, w12            | W8 = (((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 1677721
            val_5 = val_5 | val_22;
            // 0x0196F6EC: AND w10, w10, #0x40        | W10 = ((W1 >> 19) & 64);                
            val_23 = val_23 & 64;
            // 0x0196F6F0: LSR w11, w1, #0x17         | W11 = (W1 >> 23);                       
            var val_25 = W1 >> 23;
            // 0x0196F6F4: ORR w8, w8, w10            | W8 = ((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 167772
            var val_26 = val_5;
            // 0x0196F6F8: AND w9, w9, #0x20          | W9 = ((W1 >> 21) & 32);                 
            val_24 = val_24 & 32;
            // 0x0196F6FC: LSR w12, w1, #0x19         | W12 = (W1 >> 25);                       
            var val_27 = W1 >> 25;
            // 0x0196F700: ORR w8, w8, w9             | W8 = (((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777
            var val_28 = val_26;
            // 0x0196F704: AND w11, w11, #0x10        | W11 = ((W1 >> 23) & 16);                
            val_25 = val_25 & 16;
            // 0x0196F708: LSR w10, w1, #0x1b         | W10 = (W1 >> 27);                       
            var val_29 = W1 >> 27;
            // 0x0196F70C: AND w12, w12, #8           | W12 = ((W1 >> 25) & 8);                 
            val_27 = val_27 & 8;
            // 0x0196F710: ORR w8, w8, w11            | W8 = ((((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 1677
            var val_30 = val_28;
            // 0x0196F714: LSR w9, w1, #0x1d          | W9 = (W1 >> 29);                        
            var val_31 = W1 >> 29;
            // 0x0196F718: AND w10, w10, #4           | W10 = ((W1 >> 27) & 4);                 
            val_29 = val_29 & 4;
            // 0x0196F71C: ORR w8, w8, w12            | W8 = (((((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 167
            var val_32 = val_30;
            // 0x0196F720: ORR w8, w8, w10            | W8 = ((((((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16
            var val_33 = val_32;
            // 0x0196F724: AND w9, w9, #2             | W9 = ((W1 >> 29) & 2);                  
            val_31 = val_31 & 2;
            // 0x0196F728: ORR w8, w8, w9             | W8 = (((((((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 1
            var val_34 = val_33;
            // 0x0196F72C: ORR w0, w8, w1, lsr #31    | W0 = ((((((((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 
            var val_35 = val_34;
            // 0x0196F730: RET                        |  return (System.UInt32)((((((((((((((((((((((((((((W1 << 29) & 1073741824) | ((W1 << 19) & 33554432)) | ((W1 << 17) & 16777216)) | ((W1 << 15) & 8388608)) | ((W1 << 13) & 4194304)) | ((W1 << 11) & 2097152)) | ((W1 << 9) & 1;
            return (uint)val_35;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F734 (26670900), len: 76  VirtAddr: 0x0196F734 RVA: 0x0196F734 token: 100663904 methodIndex: 20826 delegateWrapperIndex: 0 methodInvoker: 0
        private static byte ReverseBits(byte data)
        {
            //
            // Disasemble & Code
            // 0x0196F734: MOVZ w9, #0x2, lsl #16     | W9 = 131072 (0x20000);//ML01            
            // 0x0196F738: MOVZ w10, #0x8, lsl #16    | W10 = 524288 (0x80000);//ML01           
            // 0x0196F73C: AND w8, w1, #0xff          | W8 = (W1 & 255);                        
            var val_1 = W1 & 255;
            // 0x0196F740: MOVK w9, #0x202            | W9 = 131586 (0x20202);                  
            // 0x0196F744: MOVK w10, #0x808           | W10 = 526344 (0x80808);                 
            // 0x0196F748: MUL w9, w8, w9             | W9 = ((W1 & 255) * 131586);             
            var val_2 = val_1 * 131586;
            // 0x0196F74C: MUL w8, w8, w10            | W8 = ((W1 & 255) * 526344);             
            val_1 = val_1 * 526344;
            // 0x0196F750: MOVZ w10, #0x104, lsl #16  | W10 = 17039360 (0x1040000);//ML01       
            // 0x0196F754: MOVK w10, #0x4010          | W10 = 17055760 (0x1044010);             
            // 0x0196F758: AND w9, w9, w10            | W9 = (((W1 & 255) * 131586) & 17055760);
            val_2 = val_2 & 17055760;
            // 0x0196F75C: MOVZ w10, #0x208, lsl #16  | W10 = 34078720 (0x2080000);//ML01       
            // 0x0196F760: MOVK w10, #0x8020          | W10 = 34111520 (0x2088020);             
            // 0x0196F764: AND w8, w8, w10            | W8 = (((W1 & 255) * 526344) & 34111520);
            val_1 = val_1 & 34111520;
            // 0x0196F768: ORR w8, w8, w9             | W8 = ((((W1 & 255) * 526344) & 34111520) | (((W1 & 255) * 131586) & 17055760));
            val_1 = val_1 | val_2;
            // 0x0196F76C: MOVZ w9, #0x100, lsl #16   | W9 = 16777216 (0x1000000);//ML01        
            // 0x0196F770: MOVK w9, #0x1001           | W9 = 16781313 (0x1001001);              
            // 0x0196F774: MUL w8, w8, w9             | W8 = (((((W1 & 255) * 526344) & 34111520) | (((W1 & 255) * 131586) & 17055760)) * 16781313);
            val_1 = val_1 * 16781313;
            // 0x0196F778: LSR w0, w8, #0x18          | W0 = ((((((W1 & 255) * 526344) & 34111520) | (((W1 & 255) * 131586) & 17055760)) * 16781313) >> 24);
            var val_3 = val_1 >> 24;
            // 0x0196F77C: RET                        |  return (System.Byte)((((((W1 & 255) * 526344) & 34111520) | (((W1 & 255) * 131586) & 17055760)) * 16781313) >> 24);
            return (byte)val_3;
            //  |  // // {name=val_0, type=System.Byte, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196EFA4 (26668964), len: 688  VirtAddr: 0x0196EFA4 RVA: 0x0196EFA4 token: 100663905 methodIndex: 20827 delegateWrapperIndex: 0 methodInvoker: 0
        private void GenerateLookupTable()
        {
            //
            // Disasemble & Code
            //  | 
            uint val_36;
            //  | 
            var val_37;
            // 0x0196EFA4: STP x28, x27, [sp, #-0x60]! | stack[1152921509739505520] = ???;  stack[1152921509739505528] = ???;  //  dest_result_addr=1152921509739505520 |  dest_result_addr=1152921509739505528
            // 0x0196EFA8: STP x26, x25, [sp, #0x10]  | stack[1152921509739505536] = ???;  stack[1152921509739505544] = ???;  //  dest_result_addr=1152921509739505536 |  dest_result_addr=1152921509739505544
            // 0x0196EFAC: STP x24, x23, [sp, #0x20]  | stack[1152921509739505552] = ???;  stack[1152921509739505560] = ???;  //  dest_result_addr=1152921509739505552 |  dest_result_addr=1152921509739505560
            // 0x0196EFB0: STP x22, x21, [sp, #0x30]  | stack[1152921509739505568] = ???;  stack[1152921509739505576] = ???;  //  dest_result_addr=1152921509739505568 |  dest_result_addr=1152921509739505576
            // 0x0196EFB4: STP x20, x19, [sp, #0x40]  | stack[1152921509739505584] = ???;  stack[1152921509739505592] = ???;  //  dest_result_addr=1152921509739505584 |  dest_result_addr=1152921509739505592
            // 0x0196EFB8: STP x29, x30, [sp, #0x50]  | stack[1152921509739505600] = ???;  stack[1152921509739505608] = ???;  //  dest_result_addr=1152921509739505600 |  dest_result_addr=1152921509739505608
            // 0x0196EFBC: ADD x29, sp, #0x50         | X29 = (1152921509739505520 + 80) = 1152921509739505600 (0x1000000131EE27C0);
            // 0x0196EFC0: ADRP x20, #0x3739000       | X20 = 57905152 (0x3739000);             
            // 0x0196EFC4: LDRB w8, [x20, #0x3d5]     | W8 = (bool)static_value_037393D5;       
            // 0x0196EFC8: MOV x19, x0                | X19 = 1152921509739517616 (0x1000000131EE56B0);//ML01
            // 0x0196EFCC: TBNZ w8, #0, #0x196efe8    | if (static_value_037393D5 == true) goto label_0;
            // 0x0196EFD0: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x0196EFD4: LDR x8, [x8, #0xe88]       | X8 = 0x2B92D98;                         
            // 0x0196EFD8: LDR w0, [x8]               | W0 = 0x222B;                            
            // 0x0196EFDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x222B, ????);     
            // 0x0196EFE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196EFE4: STRB w8, [x20, #0x3d5]     | static_value_037393D5 = true;            //  dest_result_addr=57906133
            label_0:
            // 0x0196EFE8: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0196EFEC: LDR x8, [x8, #0x1b8]       | X8 = 1152921505007033440;               
            // 0x0196EFF0: LDR x20, [x8]              | X20 = typeof(System.UInt32[]);          
            // 0x0196EFF4: MOV x0, x20                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196EFF8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x0196EFFC: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
            // 0x0196F000: MOV x0, x20                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F004: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x0196F008: MOVZ w22, #0x104, lsl #16  | W22 = 17039360 (0x1040000);//ML01       
            // 0x0196F00C: MOVZ w23, #0x8, lsl #16    | W23 = 524288 (0x80000);//ML01           
            // 0x0196F010: MOVZ w24, #0x208, lsl #16  | W24 = 34078720 (0x2080000);//ML01       
            // 0x0196F014: MOVZ w25, #0x100, lsl #16  | W25 = 16777216 (0x1000000);//ML01       
            // 0x0196F018: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            var val_39 = 0;
            // 0x0196F01C: MOVK w22, #0x4010          | W22 = 17055760 (0x1044010);             
            // 0x0196F020: MOVK w23, #0x808           | W23 = 526344 (0x80808);                 
            // 0x0196F024: MOVK w24, #0x8020          | W24 = 34111520 (0x2088020);             
            // 0x0196F028: MOVK w25, #0x1001          | W25 = 16781313 (0x1001001);             
            // 0x0196F02C: STR x0, [x19, #0x28]       | this.crc32Table = typeof(System.UInt32[]);  //  dest_result_addr=1152921509739517656
            this.crc32Table = null;
            label_10:
            // 0x0196F030: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            var val_38 = 8;
            // 0x0196F034: MOV w26, w20               | W26 = 0 (0x0);//ML01                    
            label_3:
            // 0x0196F038: TBNZ w26, #0, #0x196f044   | if ((0x0 & 0x1) != 0) goto label_1;     
            if((val_39 & 1) != 0)
            {
                goto label_1;
            }
            // 0x0196F03C: LSR w26, w26, #1           | W26 = (0 >> 1) = val_36 (0x00000000);   
            val_36 = 0;
            // 0x0196F040: B #0x196f04c               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x0196F044: LDR w9, [x19, #0x10]       | W9 = this.dwPolynomial; //P2            
            // 0x0196F048: EOR w26, w9, w26, lsr #1   | W26 = (this.dwPolynomial ^ 0);          
            val_36 = this.dwPolynomial ^ 0;
            label_2:
            // 0x0196F04C: ADD w8, w8, #0xff          | W8 = (8 + 255);                         
            val_38 = val_38 + 255;
            // 0x0196F050: AND w8, w8, #0xff          | W8 = ((8 + 255) & 255);                 
            val_38 = val_38 & 255;
            // 0x0196F054: CBNZ w8, #0x196f038        | if (((8 + 255) & 255) != 0) goto label_3;
            if(val_38 != 0)
            {
                goto label_3;
            }
            // 0x0196F058: LDR x27, [x19, #0x28]      | X27 = this.crc32Table; //P2             
            // 0x0196F05C: LDRB w8, [x19, #0x20]      | W8 = this.reverseBits; //P2             
            // 0x0196F060: CBZ w8, #0x196f204         | if (this.reverseBits == false) goto label_4;
            if(this.reverseBits == false)
            {
                goto label_4;
            }
            // 0x0196F064: MOVZ w8, #0x2, lsl #16     | W8 = 131072 (0x20000);//ML01            
            // 0x0196F068: LSL w10, w26, #0x1d        | W10 = ((this.dwPolynomial ^ 0) << 29);  
            uint val_1 = val_36 << 29;
            // 0x0196F06C: MOVK w8, #0x202            | W8 = 131586 (0x20202);                  
            // 0x0196F070: AND w10, w10, #0x40000000  | W10 = (((this.dwPolynomial ^ 0) << 29) & 1073741824);
            val_1 = val_1 & 1073741824;
            // 0x0196F074: MUL w8, w20, w8            | W8 = (0 * 131586);                      
            var val_2 = val_39 * 131586;
            // 0x0196F078: MUL w9, w20, w23           | W9 = (0 * 526344);                      
            var val_3 = val_39 * 526344;
            // 0x0196F07C: LSR w11, w26, #2           | W11 = ((this.dwPolynomial ^ 0) >> 2);   
            uint val_4 = val_36 >> 2;
            // 0x0196F080: BFI w10, w26, #0x1f, #1    | W10 = (((this.dwPolynomial ^ 0) << 29) & 1073741824) | (this.dwPolynomial ^ 0)
            // 0x0196F084: LSR w12, w26, #3           | W12 = ((this.dwPolynomial ^ 0) >> 3);   
            uint val_5 = val_36 >> 3;
            // 0x0196F088: AND w8, w8, w22            | W8 = ((0 * 131586) & 17055760);         
            val_2 = val_2 & 17055760;
            // 0x0196F08C: AND w9, w9, w24            | W9 = ((0 * 526344) & 34111520);         
            val_3 = val_3 & 34111520;
            // 0x0196F090: BFI w10, w11, #0x1d, #1    | W10 = (((this.dwPolynomial ^ 0) << 29) & 1073741824) | ((this.dwPolynomial ^ 0) >> 2)
            // 0x0196F094: ORR w8, w9, w8             | W8 = (((0 * 526344) & 34111520) | ((0 * 131586) & 17055760));
            val_2 = val_3 | val_2;
            // 0x0196F098: LSR w9, w26, #4            | W9 = ((this.dwPolynomial ^ 0) >> 4);    
            uint val_6 = val_36 >> 4;
            // 0x0196F09C: BFI w10, w12, #0x1c, #1    | W10 = (((this.dwPolynomial ^ 0) << 29) & 1073741824) | ((this.dwPolynomial ^ 0) >> 3)
            // 0x0196F0A0: LSR w11, w26, #5           | W11 = ((this.dwPolynomial ^ 0) >> 5);   
            uint val_7 = val_36 >> 5;
            // 0x0196F0A4: BFI w10, w9, #0x1b, #1     | W10 = (((this.dwPolynomial ^ 0) << 29) & 1073741824) | ((this.dwPolynomial ^ 0) >> 4)
            // 0x0196F0A8: LSL w9, w26, #0x13         | W9 = ((this.dwPolynomial ^ 0) << 19);   
            uint val_8 = val_36 << 19;
            // 0x0196F0AC: AND w9, w9, #0x2000000     | W9 = (((this.dwPolynomial ^ 0) << 19) & 33554432);
            val_8 = val_8 & 33554432;
            // 0x0196F0B0: BFI w10, w11, #0x1a, #1    | W10 = (((this.dwPolynomial ^ 0) << 29) & 1073741824) | ((this.dwPolynomial ^ 0) >> 5)
            // 0x0196F0B4: ORR w9, w10, w9            | W9 = ((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 33554432))
            val_8 = val_1 | val_8;
            // 0x0196F0B8: LSL w10, w26, #0x11        | W10 = ((this.dwPolynomial ^ 0) << 17);  
            uint val_9 = val_36 << 17;
            // 0x0196F0BC: AND w10, w10, #0x1000000   | W10 = (((this.dwPolynomial ^ 0) << 17) & 16777216);
            val_9 = val_9 & 16777216;
            // 0x0196F0C0: ORR w9, w9, w10            | W9 = (((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 33554432)
            val_8 = val_8 | val_9;
            // 0x0196F0C4: LSL w10, w26, #0xf         | W10 = ((this.dwPolynomial ^ 0) << 15);  
            uint val_10 = val_36 << 15;
            // 0x0196F0C8: AND w10, w10, #0x800000    | W10 = (((this.dwPolynomial ^ 0) << 15) & 8388608);
            val_10 = val_10 & 8388608;
            // 0x0196F0CC: ORR w9, w9, w10            | W9 = ((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 33554432
            val_8 = val_8 | val_10;
            // 0x0196F0D0: LSL w10, w26, #0xd         | W10 = ((this.dwPolynomial ^ 0) << 13);  
            uint val_11 = val_36 << 13;
            // 0x0196F0D4: AND w10, w10, #0x400000    | W10 = (((this.dwPolynomial ^ 0) << 13) & 4194304);
            val_11 = val_11 & 4194304;
            // 0x0196F0D8: ORR w9, w9, w10            | W9 = (((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 3355443
            val_8 = val_8 | val_11;
            // 0x0196F0DC: LSL w10, w26, #0xb         | W10 = ((this.dwPolynomial ^ 0) << 11);  
            uint val_12 = val_36 << 11;
            // 0x0196F0E0: AND w10, w10, #0x200000    | W10 = (((this.dwPolynomial ^ 0) << 11) & 2097152);
            val_12 = val_12 & 2097152;
            // 0x0196F0E4: ORR w9, w9, w10            | W9 = ((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 335544
            val_8 = val_8 | val_12;
            // 0x0196F0E8: LSL w10, w26, #9           | W10 = ((this.dwPolynomial ^ 0) << 9);   
            uint val_13 = val_36 << 9;
            // 0x0196F0EC: AND w10, w10, #0x100000    | W10 = (((this.dwPolynomial ^ 0) << 9) & 1048576);
            val_13 = val_13 & 1048576;
            // 0x0196F0F0: ORR w9, w9, w10            | W9 = (((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 33554
            val_8 = val_8 | val_13;
            // 0x0196F0F4: LSL w10, w26, #7           | W10 = ((this.dwPolynomial ^ 0) << 7);   
            uint val_14 = val_36 << 7;
            // 0x0196F0F8: AND w10, w10, #0x80000     | W10 = (((this.dwPolynomial ^ 0) << 7) & 524288);
            val_14 = val_14 & 524288;
            // 0x0196F0FC: ORR w9, w9, w10            | W9 = ((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 3355
            val_8 = val_8 | val_14;
            // 0x0196F100: LSL w10, w26, #5           | W10 = ((this.dwPolynomial ^ 0) << 5);   
            uint val_15 = val_36 << 5;
            // 0x0196F104: AND w10, w10, #0x40000     | W10 = (((this.dwPolynomial ^ 0) << 5) & 262144);
            val_15 = val_15 & 262144;
            // 0x0196F108: ORR w9, w9, w10            | W9 = (((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 335
            val_8 = val_8 | val_15;
            // 0x0196F10C: LSL w10, w26, #3           | W10 = ((this.dwPolynomial ^ 0) << 3);   
            uint val_16 = val_36 << 3;
            // 0x0196F110: AND w10, w10, #0x20000     | W10 = (((this.dwPolynomial ^ 0) << 3) & 131072);
            val_16 = val_16 & 131072;
            // 0x0196F114: ORR w9, w9, w10            | W9 = ((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 33
            val_8 = val_8 | val_16;
            // 0x0196F118: LSL w10, w26, #1           | W10 = ((this.dwPolynomial ^ 0) << 1);   
            uint val_17 = val_36 << 1;
            // 0x0196F11C: AND w10, w10, #0x10000     | W10 = (((this.dwPolynomial ^ 0) << 1) & 65536);
            val_17 = val_17 & 65536;
            // 0x0196F120: ORR w9, w9, w10            | W9 = (((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 3
            val_8 = val_8 | val_17;
            // 0x0196F124: LSR w10, w26, #1           | W10 = ((this.dwPolynomial ^ 0) >> 1);   
            uint val_18 = val_36 >> 1;
            // 0x0196F128: AND w10, w10, #0x8000      | W10 = (((this.dwPolynomial ^ 0) >> 1) & 32768);
            val_18 = val_18 & 32768;
            // 0x0196F12C: ORR w9, w9, w10            | W9 = ((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) & 
            val_8 = val_8 | val_18;
            // 0x0196F130: AND w12, w12, #0x4000      | W12 = (((this.dwPolynomial ^ 0) >> 3) & 16384);
            val_5 = val_5 & 16384;
            // 0x0196F134: LSR w10, w26, #7           | W10 = ((this.dwPolynomial ^ 0) >> 7);   
            uint val_19 = val_36 >> 7;
            // 0x0196F138: ORR w9, w9, w12            | W9 = (((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) &
            val_8 = val_8 | val_5;
            // 0x0196F13C: AND w11, w11, #0x2000      | W11 = (((this.dwPolynomial ^ 0) >> 5) & 8192);
            val_7 = val_7 & 8192;
            // 0x0196F140: LSR w12, w26, #9           | W12 = ((this.dwPolynomial ^ 0) >> 9);   
            uint val_20 = val_36 >> 9;
            // 0x0196F144: ORR w9, w9, w11            | W9 = ((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19) 
            val_8 = val_8 | val_7;
            // 0x0196F148: AND w10, w10, #0x1000      | W10 = (((this.dwPolynomial ^ 0) >> 7) & 4096);
            val_19 = val_19 & 4096;
            // 0x0196F14C: LSR w11, w26, #0xb         | W11 = ((this.dwPolynomial ^ 0) >> 11);  
            uint val_21 = val_36 >> 11;
            // 0x0196F150: ORR w9, w9, w10            | W9 = (((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19)
            val_8 = val_8 | val_19;
            // 0x0196F154: AND w12, w12, #0x800       | W12 = (((this.dwPolynomial ^ 0) >> 9) & 2048);
            val_20 = val_20 & 2048;
            // 0x0196F158: LSR w10, w26, #0xd         | W10 = ((this.dwPolynomial ^ 0) >> 13);  
            uint val_22 = val_36 >> 13;
            // 0x0196F15C: ORR w9, w9, w12            | W9 = ((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 19
            val_8 = val_8 | val_20;
            // 0x0196F160: AND w11, w11, #0x400       | W11 = (((this.dwPolynomial ^ 0) >> 11) & 1024);
            val_21 = val_21 & 1024;
            // 0x0196F164: LSR w12, w26, #0xf         | W12 = ((this.dwPolynomial ^ 0) >> 15);  
            uint val_23 = val_36 >> 15;
            // 0x0196F168: ORR w9, w9, w11            | W9 = (((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 1
            val_8 = val_8 | val_21;
            // 0x0196F16C: AND w10, w10, #0x200       | W10 = (((this.dwPolynomial ^ 0) >> 13) & 512);
            val_22 = val_22 & 512;
            // 0x0196F170: LSR w11, w26, #0x11        | W11 = ((this.dwPolynomial ^ 0) >> 17);  
            uint val_24 = val_36 >> 17;
            // 0x0196F174: ORR w9, w9, w10            | W9 = ((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) << 
            val_8 = val_8 | val_22;
            // 0x0196F178: AND w12, w12, #0x100       | W12 = (((this.dwPolynomial ^ 0) >> 15) & 256);
            val_23 = val_23 & 256;
            // 0x0196F17C: LSR w10, w26, #0x13        | W10 = ((this.dwPolynomial ^ 0) >> 19);  
            uint val_25 = val_36 >> 19;
            // 0x0196F180: ORR w9, w9, w12            | W9 = (((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) <<
            val_8 = val_8 | val_23;
            // 0x0196F184: AND w11, w11, #0x80        | W11 = (((this.dwPolynomial ^ 0) >> 17) & 128);
            val_24 = val_24 & 128;
            // 0x0196F188: LSR w12, w26, #0x15        | W12 = ((this.dwPolynomial ^ 0) >> 21);  
            uint val_26 = val_36 >> 21;
            // 0x0196F18C: ORR w9, w9, w11            | W9 = ((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) <
            val_8 = val_8 | val_24;
            // 0x0196F190: AND w10, w10, #0x40        | W10 = (((this.dwPolynomial ^ 0) >> 19) & 64);
            val_25 = val_25 & 64;
            // 0x0196F194: LSR w11, w26, #0x17        | W11 = ((this.dwPolynomial ^ 0) >> 23);  
            uint val_27 = val_36 >> 23;
            // 0x0196F198: ORR w9, w9, w10            | W9 = (((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0) 
            val_8 = val_8 | val_25;
            // 0x0196F19C: AND w12, w12, #0x20        | W12 = (((this.dwPolynomial ^ 0) >> 21) & 32);
            val_26 = val_26 & 32;
            // 0x0196F1A0: LSR w10, w26, #0x19        | W10 = ((this.dwPolynomial ^ 0) >> 25);  
            uint val_28 = val_36 >> 25;
            // 0x0196F1A4: ORR w9, w9, w12            | W9 = ((((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0)
            uint val_29 = val_8;
            // 0x0196F1A8: AND w11, w11, #0x10        | W11 = (((this.dwPolynomial ^ 0) >> 23) & 16);
            val_27 = val_27 & 16;
            // 0x0196F1AC: LSR w12, w26, #0x1b        | W12 = ((this.dwPolynomial ^ 0) >> 27);  
            uint val_30 = val_36 >> 27;
            // 0x0196F1B0: ORR w9, w9, w11            | W9 = (((((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 0
            uint val_31 = val_29;
            // 0x0196F1B4: AND w10, w10, #8           | W10 = (((this.dwPolynomial ^ 0) >> 25) & 8);
            val_28 = val_28 & 8;
            // 0x0196F1B8: MUL w8, w8, w25            | W8 = ((((0 * 526344) & 34111520) | ((0 * 131586) & 17055760)) * 16781313);
            val_2 = val_2 * 16781313;
            // 0x0196F1BC: LSR w11, w26, #0x1d        | W11 = ((this.dwPolynomial ^ 0) >> 29);  
            uint val_32 = val_36 >> 29;
            // 0x0196F1C0: AND w12, w12, #4           | W12 = (((this.dwPolynomial ^ 0) >> 27) & 4);
            val_30 = val_30 & 4;
            // 0x0196F1C4: LSR w28, w8, #0x18         | W28 = (((((0 * 526344) & 34111520) | ((0 * 131586) & 17055760)) * 16781313) >> 24);
            var val_33 = val_2 >> 24;
            // 0x0196F1C8: ORR w8, w9, w10            | W8 = ((((((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^ 
            uint val_34 = val_31;
            // 0x0196F1CC: ORR w8, w8, w12            | W8 = (((((((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial ^
            uint val_35 = val_34;
            // 0x0196F1D0: AND w9, w11, #2            | W9 = (((this.dwPolynomial ^ 0) >> 29) & 2);
            uint val_36 = val_32 & 2;
            // 0x0196F1D4: ORR w21, w8, w9            | W21 = ((((((((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomial
            uint val_37 = val_35;
            // 0x0196F1D8: CBNZ x27, #0x196f1e0       | if (this.crc32Table != null) goto label_5;
            if(this.crc32Table != null)
            {
                goto label_5;
            }
            // 0x0196F1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.UInt32[]), ????);
            label_5:
            // 0x0196F1E0: LDR w8, [x27, #0x18]       | W8 = this.crc32Table.Length; //P2       
            // 0x0196F1E4: ORR w26, w21, w26, lsr #31 | W26 = (((((((((((((((((((((((((((((this.dwPolynomial ^ 0) << 29) & 1073741824) | (((this.dwPolynomia
            val_36 = val_37;
            // 0x0196F1E8: CMP w28, w8                | STATE = COMPARE((((((0 * 526344) & 34111520) | ((0 * 131586) & 17055760)) * 16781313) >> 24), this.crc32Table.Length)
            // 0x0196F1EC: B.LO #0x196f1fc            | if (val_33 < this.crc32Table.Length) goto label_6;
            if(val_33 < this.crc32Table.Length)
            {
                goto label_6;
            }
            // 0x0196F1F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.UInt32[]), ????);
            // 0x0196F1F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F1F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.UInt32[]), ????);
            label_6:
            // 0x0196F1FC: ADD x8, x27, x28, lsl #2   | X8 = this.crc32Table[(((((0 * 526344) & 34111520) | ((0 * 131586) & 17055760)) * 16781313) >> 24)]; //PARR1 
            // 0x0196F200: B #0x196f228               |  goto label_7;                          
            goto label_7;
            label_4:
            // 0x0196F204: CBNZ x27, #0x196f20c       | if (this.crc32Table != null) goto label_8;
            if(this.crc32Table != null)
            {
                goto label_8;
            }
            // 0x0196F208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.UInt32[]), ????);
            label_8:
            // 0x0196F20C: LDR w8, [x27, #0x18]       | W8 = this.crc32Table.Length; //P2       
            // 0x0196F210: CMP w20, w8                | STATE = COMPARE(0x0, this.crc32Table.Length)
            // 0x0196F214: B.LO #0x196f224            | if (0 < this.crc32Table.Length) goto label_9;
            if(val_39 < this.crc32Table.Length)
            {
                goto label_9;
            }
            // 0x0196F218: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.UInt32[]), ????);
            // 0x0196F21C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F220: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.UInt32[]), ????);
            label_9:
            // 0x0196F224: ADD x8, x27, x20, lsl #2   | X8 = this.crc32Table[0x0]; //PARR1      
            label_7:
            // 0x0196F228: ADD x20, x20, #1           | X20 = (0 + 1);                          
            val_39 = val_39 + 1;
            // 0x0196F22C: STR w26, [x8, #0x20]       | this.crc32Table[0x0][0] = (this.dwPolynomial ^ 0);  //  dest_result_addr=0
            this.crc32Table[val_39] = val_36;
            // 0x0196F230: CMP x20, #0x100            | STATE = COMPARE((0 + 1), 0x100)         
            // 0x0196F234: B.NE #0x196f030            | if (0 != 0x100) goto label_10;          
            if(val_39 != 256)
            {
                goto label_10;
            }
            // 0x0196F238: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0196F23C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0196F240: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0196F244: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0196F248: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0196F24C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0196F250: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F780 (26670976), len: 132  VirtAddr: 0x0196F780 RVA: 0x0196F780 token: 100663906 methodIndex: 20828 delegateWrapperIndex: 0 methodInvoker: 0
        private uint gf2_matrix_times(uint[] matrix, uint vec)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            // 0x0196F780: STP x24, x23, [sp, #-0x40]! | stack[1152921509739691280] = ???;  stack[1152921509739691288] = ???;  //  dest_result_addr=1152921509739691280 |  dest_result_addr=1152921509739691288
            // 0x0196F784: STP x22, x21, [sp, #0x10]  | stack[1152921509739691296] = ???;  stack[1152921509739691304] = ???;  //  dest_result_addr=1152921509739691296 |  dest_result_addr=1152921509739691304
            // 0x0196F788: STP x20, x19, [sp, #0x20]  | stack[1152921509739691312] = ???;  stack[1152921509739691320] = ???;  //  dest_result_addr=1152921509739691312 |  dest_result_addr=1152921509739691320
            // 0x0196F78C: STP x29, x30, [sp, #0x30]  | stack[1152921509739691328] = ???;  stack[1152921509739691336] = ???;  //  dest_result_addr=1152921509739691328 |  dest_result_addr=1152921509739691336
            // 0x0196F790: ADD x29, sp, #0x30         | X29 = (1152921509739691280 + 48) = 1152921509739691328 (0x1000000131F0FD40);
            // 0x0196F794: MOV w19, w2                | W19 = vec;//m1                          
            val_1 = vec;
            // 0x0196F798: MOV x20, x1                | X20 = matrix;//m1                       
            // 0x0196F79C: CBZ w19, #0x196f7e8        | if (vec == 0) goto label_0;             
            if(val_1 == 0)
            {
                goto label_0;
            }
            // 0x0196F7A0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            var val_1 = 0;
            // 0x0196F7A4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_2 = 0;
            // 0x0196F7A8: ADD x23, x20, #0x20        | X23 = matrix[0x20]; //PARR1             
            label_4:
            // 0x0196F7AC: TBZ w19, #0, #0x196f7d8    | if ((vec & 0x1) == 0) goto label_1;     
            if((val_1 & 1) == 0)
            {
                goto label_1;
            }
            // 0x0196F7B0: CBNZ x20, #0x196f7b8       | if (matrix != null) goto label_2;       
            if(matrix != null)
            {
                goto label_2;
            }
            // 0x0196F7B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0196F7B8: LDR w8, [x20, #0x18]       | W8 = matrix.Length; //P2                
            // 0x0196F7BC: CMP x22, x8                | STATE = COMPARE(0x0, matrix.Length)     
            // 0x0196F7C0: B.LO #0x196f7d0            | if (0 < matrix.Length) goto label_3;    
            if(val_1 < matrix.Length)
            {
                goto label_3;
            }
            // 0x0196F7C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0196F7C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F7CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_3:
            // 0x0196F7D0: LDR w8, [x23, x22, lsl #2] | W8 = typeof(System.UInt32[]);           
            // 0x0196F7D4: EOR w21, w8, w21           | W21 = (1152921505007033440 ^ val_2);    
            val_2 = 1152921505007033440 ^ val_2;
            label_1:
            // 0x0196F7D8: LSR w19, w19, #1           | W19 = (vec >> 1);                       
            val_1 = val_1 >> 1;
            // 0x0196F7DC: ADD x22, x22, #1           | X22 = (0 + 1);                          
            val_1 = val_1 + 1;
            // 0x0196F7E0: CBNZ w19, #0x196f7ac       | if ((vec >> 1) != 0) goto label_4;      
            if(val_1 != 0)
            {
                goto label_4;
            }
            // 0x0196F7E4: B #0x196f7ec               |  goto label_5;                          
            goto label_5;
            label_0:
            // 0x0196F7E8: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_2 = 0;
            label_5:
            // 0x0196F7EC: MOV w0, w21                | W0 = 0 (0x0);//ML01                     
            // 0x0196F7F0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0196F7F4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0196F7F8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0196F7FC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0196F800: RET                        |  return (System.UInt32)null;            
            return (uint)val_2;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F804 (26671108), len: 156  VirtAddr: 0x0196F804 RVA: 0x0196F804 token: 100663907 methodIndex: 20829 delegateWrapperIndex: 0 methodInvoker: 0
        private void gf2_matrix_square(uint[] square, uint[] mat)
        {
            //
            // Disasemble & Code
            // 0x0196F804: STP x24, x23, [sp, #-0x40]! | stack[1152921509739913872] = ???;  stack[1152921509739913880] = ???;  //  dest_result_addr=1152921509739913872 |  dest_result_addr=1152921509739913880
            // 0x0196F808: STP x22, x21, [sp, #0x10]  | stack[1152921509739913888] = ???;  stack[1152921509739913896] = ???;  //  dest_result_addr=1152921509739913888 |  dest_result_addr=1152921509739913896
            // 0x0196F80C: STP x20, x19, [sp, #0x20]  | stack[1152921509739913904] = ???;  stack[1152921509739913912] = ???;  //  dest_result_addr=1152921509739913904 |  dest_result_addr=1152921509739913912
            // 0x0196F810: STP x29, x30, [sp, #0x30]  | stack[1152921509739913920] = ???;  stack[1152921509739913928] = ???;  //  dest_result_addr=1152921509739913920 |  dest_result_addr=1152921509739913928
            // 0x0196F814: ADD x29, sp, #0x30         | X29 = (1152921509739913872 + 48) = 1152921509739913920 (0x1000000131F462C0);
            // 0x0196F818: MOV x20, x1                | X20 = square;//m1                       
            // 0x0196F81C: MOV x19, x2                | X19 = mat;//m1                          
            // 0x0196F820: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x0196F824: ADD x23, x20, #0x20        | X23 = square[0x20]; //PARR1             
            label_4:
            // 0x0196F828: CBNZ x19, #0x196f830       | if (mat != null) goto label_0;          
            if(mat != null)
            {
                goto label_0;
            }
            // 0x0196F82C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0196F830: LDR w8, [x19, #0x18]       | W8 = mat.Length; //P2                   
            // 0x0196F834: CMP x22, x8                | STATE = COMPARE(0x0, mat.Length)        
            // 0x0196F838: B.LO #0x196f848            | if (0 < mat.Length) goto label_1;       
            if(val_3 < mat.Length)
            {
                goto label_1;
            }
            // 0x0196F83C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0196F840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x0196F848: ADD x8, x19, x22, lsl #2   | X8 = mat[0x0]; //PARR1                  
            // 0x0196F84C: LDR w2, [x8, #0x20]        | W2 = mat[0x0][0]                        
            uint val_2 = mat[val_3];
            // 0x0196F850: MOV x1, x19                | X1 = mat;//m1                           
            // 0x0196F854: BL #0x196f780              | X0 = this.gf2_matrix_times(matrix:  mat, vec:  mat[0]);
            uint val_1 = this.gf2_matrix_times(matrix:  mat, vec:  val_2);
            // 0x0196F858: MOV w21, w0                | W21 = val_1;//m1                        
            // 0x0196F85C: CBNZ x20, #0x196f864       | if (square != null) goto label_2;       
            if(square != null)
            {
                goto label_2;
            }
            // 0x0196F860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x0196F864: LDR w8, [x20, #0x18]       | W8 = square.Length; //P2                
            // 0x0196F868: CMP x22, x8                | STATE = COMPARE(0x0, square.Length)     
            // 0x0196F86C: B.LO #0x196f87c            | if (0 < square.Length) goto label_3;    
            if(val_3 < square.Length)
            {
                goto label_3;
            }
            // 0x0196F870: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x0196F874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F878: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_3:
            // 0x0196F87C: STR w21, [x23, x22, lsl #2] | mem2[0] = val_1;                         //  dest_result_addr=0
            mem2[0] = val_1;
            // 0x0196F880: ADD x22, x22, #1           | X22 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x0196F884: CMP x22, #0x20             | STATE = COMPARE((0 + 1), 0x20)          
            // 0x0196F888: B.NE #0x196f828            | if (0 != 0x20) goto label_4;            
            if(val_3 != 32)
            {
                goto label_4;
            }
            // 0x0196F88C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0196F890: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0196F894: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0196F898: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0196F89C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0196F8A0 (26671264), len: 388  VirtAddr: 0x0196F8A0 RVA: 0x0196F8A0 token: 100663908 methodIndex: 20830 delegateWrapperIndex: 0 methodInvoker: 0
        public void Combine(int crc, int length)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            uint val_5;
            // 0x0196F8A0: STP x28, x27, [sp, #-0x60]! | stack[1152921509740099568] = ???;  stack[1152921509740099576] = ???;  //  dest_result_addr=1152921509740099568 |  dest_result_addr=1152921509740099576
            // 0x0196F8A4: STP x26, x25, [sp, #0x10]  | stack[1152921509740099584] = ???;  stack[1152921509740099592] = ???;  //  dest_result_addr=1152921509740099584 |  dest_result_addr=1152921509740099592
            // 0x0196F8A8: STP x24, x23, [sp, #0x20]  | stack[1152921509740099600] = ???;  stack[1152921509740099608] = ???;  //  dest_result_addr=1152921509740099600 |  dest_result_addr=1152921509740099608
            // 0x0196F8AC: STP x22, x21, [sp, #0x30]  | stack[1152921509740099616] = ???;  stack[1152921509740099624] = ???;  //  dest_result_addr=1152921509740099616 |  dest_result_addr=1152921509740099624
            // 0x0196F8B0: STP x20, x19, [sp, #0x40]  | stack[1152921509740099632] = ???;  stack[1152921509740099640] = ???;  //  dest_result_addr=1152921509740099632 |  dest_result_addr=1152921509740099640
            // 0x0196F8B4: STP x29, x30, [sp, #0x50]  | stack[1152921509740099648] = ???;  stack[1152921509740099656] = ???;  //  dest_result_addr=1152921509740099648 |  dest_result_addr=1152921509740099656
            // 0x0196F8B8: ADD x29, sp, #0x50         | X29 = (1152921509740099568 + 80) = 1152921509740099648 (0x1000000131F73840);
            // 0x0196F8BC: ADRP x22, #0x3739000       | X22 = 57905152 (0x3739000);             
            // 0x0196F8C0: LDRB w8, [x22, #0x3d6]     | W8 = (bool)static_value_037393D6;       
            // 0x0196F8C4: MOV w21, w2                | W21 = length;//m1                       
            val_4 = length;
            // 0x0196F8C8: MOV w19, w1                | W19 = crc;//m1                          
            // 0x0196F8CC: MOV x20, x0                | X20 = 1152921509740111664 (0x1000000131F76730);//ML01
            // 0x0196F8D0: TBNZ w8, #0, #0x196f8ec    | if (static_value_037393D6 == true) goto label_0;
            // 0x0196F8D4: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x0196F8D8: LDR x8, [x8, #0x4b8]       | X8 = 0x2B92D90;                         
            // 0x0196F8DC: LDR w0, [x8]               | W0 = 0x2229;                            
            // 0x0196F8E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2229, ????);     
            // 0x0196F8E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0196F8E8: STRB w8, [x22, #0x3d6]     | static_value_037393D6 = true;            //  dest_result_addr=57906134
            label_0:
            // 0x0196F8EC: ADRP x23, #0x367c000       | X23 = 57131008 (0x367C000);             
            // 0x0196F8F0: LDR x23, [x23, #0x1b8]     | X23 = 1152921505007033440;              
            // 0x0196F8F4: LDR x22, [x23]             | X22 = typeof(System.UInt32[]);          
            // 0x0196F8F8: MOV x0, x22                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F8FC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x0196F900: ORR w1, wzr, #0x20         | W1 = 32(0x20);                          
            // 0x0196F904: MOV x0, x22                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F908: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x0196F90C: LDR x23, [x23]             | X23 = typeof(System.UInt32[]);          
            // 0x0196F910: MOV x22, x0                | X22 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F914: MOV x0, x23                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F918: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x0196F91C: ORR w1, wzr, #0x20         | W1 = 32(0x20);                          
            // 0x0196F920: MOV x0, x23                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F924: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x0196F928: MOV x23, x0                | X23 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F92C: CBZ w21, #0x196fa08        | if (length == 0) goto label_1;          
            if(val_4 == 0)
            {
                goto label_1;
            }
            // 0x0196F930: LDR w8, [x20, #0x30]       | W8 = this._register; //P2               
            // 0x0196F934: LDR w25, [x20, #0x10]      | W25 = this.dwPolynomial; //P2           
            // 0x0196F938: MVN w24, w8                | W24 = ~(this._register);                
            val_5 = this._register;
            val_5 = ~this._register;
            // 0x0196F93C: CBNZ x23, #0x196f944       | if ( != null) goto label_2;             
            if(null != null)
            {
                goto label_2;
            }
            // 0x0196F940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.UInt32[]), ????);
            label_2:
            // 0x0196F944: LDR w8, [x23, #0x18]       | W8 = System.UInt32[].__il2cppRuntimeField_namespaze;
            // 0x0196F948: CBNZ w8, #0x196f958        | if (System.UInt32[].__il2cppRuntimeField_namespaze != 0) goto label_3;
            // 0x0196F94C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.UInt32[]), ????);
            // 0x0196F950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F954: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.UInt32[]), ????);
            label_3:
            // 0x0196F958: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            // 0x0196F95C: STR w25, [x23, #0x20]      | typeof(System.UInt32[]).__il2cppRuntimeField_20 = this.dwPolynomial;  //  dest_result_addr=1152921505007033472
            typeof(System.UInt32[]).__il2cppRuntimeField_20 = this.dwPolynomial;
            // 0x0196F960: ADD x25, x23, #0x24        | X25 = (null + 36) = 1152921505007033476 (0x1000000017DA5C84);
            // 0x0196F964: ORR w27, wzr, #1           | W27 = 1(0x1);                           
            label_5:
            // 0x0196F968: LDR w8, [x23, #0x18]       | W8 = System.UInt32[].__il2cppRuntimeField_namespaze;
            // 0x0196F96C: ADD x28, x26, #1           | X28 = (0 + 1);                          
            var val_1 = 0 + 1;
            // 0x0196F970: CMP x28, x8                | STATE = COMPARE((0 + 1), System.UInt32[].__il2cppRuntimeField_namespaze)
            // 0x0196F974: B.LO #0x196f984            | if (val_1 < System.UInt32[].__il2cppRuntimeField_namespaze) goto label_4;
            // 0x0196F978: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.UInt32[]), ????);
            // 0x0196F97C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0196F980: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.UInt32[]), ????);
            label_4:
            // 0x0196F984: CMP x28, #0x1f             | STATE = COMPARE((0 + 1), 0x1F)          
            // 0x0196F988: STR w27, [x25, x26, lsl #2] | mem[1152921505007033476] = 0x1;          //  dest_result_addr=1152921505007033476
            mem[1152921505007033476] = 1;
            // 0x0196F98C: LSL w27, w27, #1           | W27 = (1 << 1) = 0 (0x00000000);        
            // 0x0196F990: MOV x26, x28               | X26 = (0 + 1);//m1                      
            // 0x0196F994: B.NE #0x196f968            | if (val_1 != 0x1F) goto label_5;        
            if(val_1 != 31)
            {
                goto label_5;
            }
            // 0x0196F998: MOV x1, x22                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F99C: MOV x2, x23                | X2 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9A0: BL #0x196f804              | gf2_matrix_square(square:  null, mat:  null);
            gf2_matrix_square(square:  null, mat:  null);
            // 0x0196F9A4: MOV x1, x23                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9A8: MOV x2, x22                | X2 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9AC: BL #0x196f804              | gf2_matrix_square(square:  null, mat:  null);
            gf2_matrix_square(square:  null, mat:  null);
            label_9:
            // 0x0196F9B0: MOV x1, x22                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9B4: MOV x2, x23                | X2 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9B8: BL #0x196f804              | gf2_matrix_square(square:  null, mat:  null);
            gf2_matrix_square(square:  null, mat:  null);
            // 0x0196F9BC: TBZ w21, #0, #0x196f9d0    | if ((length & 0x1) == 0) goto label_6;  
            if((val_4 & 1) == 0)
            {
                goto label_6;
            }
            // 0x0196F9C0: MOV x1, x22                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9C4: MOV w2, w24                | W2 = ~(this._register);//m1             
            // 0x0196F9C8: BL #0x196f780              | X0 = gf2_matrix_times(matrix:  null, vec:  val_5);
            uint val_2 = gf2_matrix_times(matrix:  null, vec:  val_5);
            // 0x0196F9CC: MOV w24, w0                | W24 = val_2;//m1                        
            val_5 = val_2;
            label_6:
            // 0x0196F9D0: LSR w25, w21, #1           | W25 = (length >> 1);                    
            int val_3 = val_4 >> 1;
            // 0x0196F9D4: CBZ w25, #0x196fa00        | if ((length >> 1) == 0) goto label_7;   
            if(val_3 == 0)
            {
                goto label_7;
            }
            // 0x0196F9D8: MOV x1, x23                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9DC: MOV x2, x22                | X2 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9E0: BL #0x196f804              | val_2.gf2_matrix_square(square:  null, mat:  null);
            val_2.gf2_matrix_square(square:  null, mat:  null);
            // 0x0196F9E4: TBZ w25, #0, #0x196f9f8    | if (((length >> 1) & 0x1) == 0) goto label_8;
            if((val_3 & 1) == 0)
            {
                goto label_8;
            }
            // 0x0196F9E8: MOV x1, x23                | X1 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x0196F9EC: MOV w2, w24                | W2 = val_2;//m1                         
            // 0x0196F9F0: BL #0x196f780              | X0 = val_2.gf2_matrix_times(matrix:  null, vec:  val_5);
            uint val_4 = val_2.gf2_matrix_times(matrix:  null, vec:  val_5);
            // 0x0196F9F4: MOV w24, w0                | W24 = val_4;//m1                        
            val_5 = val_4;
            label_8:
            // 0x0196F9F8: LSR w21, w21, #2           | W21 = (length >> 2);                    
            val_4 = val_4 >> 2;
            // 0x0196F9FC: CBNZ w21, #0x196f9b0       | if ((length >> 2) != 0) goto label_9;   
            if(val_4 != 0)
            {
                goto label_9;
            }
            label_7:
            // 0x0196FA00: EON w8, w19, w24           | 
            // 0x0196FA04: STR w8, [x20, #0x30]       | this._register = System.UInt32[].__il2cppRuntimeField_namespaze;  //  dest_result_addr=1152921509740111712
            this._register = System.UInt32[].__il2cppRuntimeField_namespaze;
            label_1:
            // 0x0196FA08: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0196FA0C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0196FA10: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0196FA14: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0196FA18: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0196FA1C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0196FA20: RET                        |  return;                                
            return;
        
        }
    
    }

}
