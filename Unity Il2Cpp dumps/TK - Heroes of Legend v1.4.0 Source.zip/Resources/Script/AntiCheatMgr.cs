using UnityEngine;
public class AntiCheatMgr
{
    // Fields
    public System.Collections.Generic.Dictionary<string, System.Collections.Generic.Dictionary<string, ACData>> heroAntiCheatCSData; //  0x00000010
    public System.Collections.Generic.Dictionary<string, System.Collections.Generic.Dictionary<string, ACData>> heroAntiCheatData; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B29BA4 (11705252), len: 144  VirtAddr: 0x00B29BA4 RVA: 0x00B29BA4 token: 100693107 methodIndex: 24859 delegateWrapperIndex: 0 methodInvoker: 0
    public AntiCheatMgr()
    {
        //
        // Disasemble & Code
        // 0x00B29BA4: STP x22, x21, [sp, #-0x30]! | stack[1152921514939778384] = ???;  stack[1152921514939778392] = ???;  //  dest_result_addr=1152921514939778384 |  dest_result_addr=1152921514939778392
        // 0x00B29BA8: STP x20, x19, [sp, #0x10]  | stack[1152921514939778400] = ???;  stack[1152921514939778408] = ???;  //  dest_result_addr=1152921514939778400 |  dest_result_addr=1152921514939778408
        // 0x00B29BAC: STP x29, x30, [sp, #0x20]  | stack[1152921514939778416] = ???;  stack[1152921514939778424] = ???;  //  dest_result_addr=1152921514939778416 |  dest_result_addr=1152921514939778424
        // 0x00B29BB0: ADD x29, sp, #0x20         | X29 = (1152921514939778384 + 32) = 1152921514939778416 (0x1000000267E40570);
        // 0x00B29BB4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B29BB8: LDRB w8, [x20, #0x75d]     | W8 = (bool)static_value_0373375D;       
        // 0x00B29BBC: MOV x19, x0                | X19 = 1152921514939790432 (0x1000000267E43460);//ML01
        // 0x00B29BC0: TBNZ w8, #0, #0xb29bdc     | if (static_value_0373375D == true) goto label_0;
        // 0x00B29BC4: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
        // 0x00B29BC8: LDR x8, [x8, #0xf50]       | X8 = 0x2B8AF4C;                         
        // 0x00B29BCC: LDR w0, [x8]               | W0 = 0x291;                             
        // 0x00B29BD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x291, ????);      
        // 0x00B29BD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B29BD8: STRB w8, [x20, #0x75d]     | static_value_0373375D = true;            //  dest_result_addr=57882461
        label_0:
        // 0x00B29BDC: ADRP x21, #0x35dc000       | X21 = 56475648 (0x35DC000);             
        // 0x00B29BE0: LDR x21, [x21, #0xd90]     | X21 = 1152921504615792640;              
        // 0x00B29BE4: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>> val_1 = null;
        // 0x00B29BE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B29BEC: ADRP x22, #0x3678000       | X22 = 57114624 (0x3678000);             
        // 0x00B29BF0: LDR x22, [x22, #0x8a0]     | X22 = 1152921514939765408;              
        // 0x00B29BF4: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B29BF8: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::.ctor();
        // 0x00B29BFC: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>();
        // 0x00B29C00: STR x20, [x19, #0x10]      | this.heroAntiCheatCSData = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921514939790448
        this.heroAntiCheatCSData = val_1;
        // 0x00B29C04: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>> val_2 = null;
        // 0x00B29C08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B29C0C: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::.ctor();
        // 0x00B29C10: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B29C14: BL #0x23fb0c4              | .ctor();                                
        val_2 = new System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>();
        // 0x00B29C18: STR x20, [x19, #0x18]      | this.heroAntiCheatData = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921514939790456
        this.heroAntiCheatData = val_2;
        // 0x00B29C1C: MOV x0, x19                | X0 = 1152921514939790432 (0x1000000267E43460);//ML01
        // 0x00B29C20: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29C24: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29C2C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B29C30: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29C34 (11705396), len: 572  VirtAddr: 0x00B29C34 RVA: 0x00B29C34 token: 100693108 methodIndex: 24860 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetHeroAntiCheatCS(string uuid, string attrName, uint value, uint acValue)
    {
        //
        // Disasemble & Code
        //  | 
        string val_15;
        //  | 
        ACData val_16;
        //  | 
        ACData val_17;
        //  | 
        string val_18;
        //  | 
        ACData val_19;
        //  | 
        var val_20;
        // 0x00B29C34: STP x26, x25, [sp, #-0x50]! | stack[1152921514939934384] = ???;  stack[1152921514939934392] = ???;  //  dest_result_addr=1152921514939934384 |  dest_result_addr=1152921514939934392
        // 0x00B29C38: STP x24, x23, [sp, #0x10]  | stack[1152921514939934400] = ???;  stack[1152921514939934408] = ???;  //  dest_result_addr=1152921514939934400 |  dest_result_addr=1152921514939934408
        // 0x00B29C3C: STP x22, x21, [sp, #0x20]  | stack[1152921514939934416] = ???;  stack[1152921514939934424] = ???;  //  dest_result_addr=1152921514939934416 |  dest_result_addr=1152921514939934424
        // 0x00B29C40: STP x20, x19, [sp, #0x30]  | stack[1152921514939934432] = ???;  stack[1152921514939934440] = ???;  //  dest_result_addr=1152921514939934432 |  dest_result_addr=1152921514939934440
        // 0x00B29C44: STP x29, x30, [sp, #0x40]  | stack[1152921514939934448] = ???;  stack[1152921514939934456] = ???;  //  dest_result_addr=1152921514939934448 |  dest_result_addr=1152921514939934456
        // 0x00B29C48: ADD x29, sp, #0x40         | X29 = (1152921514939934384 + 64) = 1152921514939934448 (0x1000000267E666F0);
        // 0x00B29C4C: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00B29C50: LDRB w8, [x24, #0x75e]     | W8 = (bool)static_value_0373375E;       
        // 0x00B29C54: MOV w20, w4                | W20 = acValue;//m1                      
        // 0x00B29C58: MOV w21, w3                | W21 = value;//m1                        
        // 0x00B29C5C: MOV x19, x2                | X19 = attrName;//m1                     
        val_15 = attrName;
        // 0x00B29C60: MOV x22, x1                | X22 = uuid;//m1                         
        // 0x00B29C64: MOV x23, x0                | X23 = 1152921514939946464 (0x1000000267E695E0);//ML01
        val_16 = this;
        // 0x00B29C68: TBNZ w8, #0, #0xb29c84     | if (static_value_0373375E == true) goto label_0;
        // 0x00B29C6C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B29C70: LDR x8, [x8, #0xa28]       | X8 = 0x2B8AFB4;                         
        // 0x00B29C74: LDR w0, [x8]               | W0 = 0x2AB;                             
        // 0x00B29C78: BL #0x2782188              | X0 = sub_2782188( ?? 0x2AB, ????);      
        // 0x00B29C7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B29C80: STRB w8, [x24, #0x75e]     | static_value_0373375E = true;            //  dest_result_addr=57882462
        label_0:
        // 0x00B29C84: LDR x24, [x23, #0x10]      | X24 = this.heroAntiCheatCSData; //P2    
        // 0x00B29C88: CBNZ x24, #0xb29c90        | if (this.heroAntiCheatCSData != null) goto label_1;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_1;
        }
        // 0x00B29C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2AB, ????);      
        label_1:
        // 0x00B29C90: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B29C94: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B29C98: MOV x0, x24                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29C9C: MOV x1, x22                | X1 = uuid;//m1                          
        // 0x00B29CA0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B29CA4: BL #0x23fd9f0              | X0 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        bool val_1 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        // 0x00B29CA8: TBZ w0, #0, #0xb29d70      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00B29CAC: LDR x24, [x23, #0x10]      | X24 = this.heroAntiCheatCSData; //P2    
        // 0x00B29CB0: CBNZ x24, #0xb29cb8        | if (this.heroAntiCheatCSData != null) goto label_3;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_3;
        }
        // 0x00B29CB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B29CB8: ADRP x25, #0x35e4000       | X25 = 56508416 (0x35E4000);             
        // 0x00B29CBC: LDR x25, [x25, #0xc10]     | X25 = 1152921514939895840;              
        val_17 = 1152921514939895840;
        // 0x00B29CC0: MOV x0, x24                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29CC4: MOV x1, x22                | X1 = uuid;//m1                          
        // 0x00B29CC8: LDR x2, [x25]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B29CCC: BL #0x23fc26c              | X0 = this.heroAntiCheatCSData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_2 = this.heroAntiCheatCSData.Item[uuid];
        // 0x00B29CD0: MOV x24, x0                | X24 = val_2;//m1                        
        // 0x00B29CD4: CBNZ x24, #0xb29cdc        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B29CD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B29CDC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B29CE0: LDR x8, [x8]               | X8 = 1152921514939900960;               
        // 0x00B29CE4: MOV x0, x24                | X0 = val_2;//m1                         
        // 0x00B29CE8: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B29CEC: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ACData>::ContainsKey(System.String key);
        // 0x00B29CF0: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  val_15);   
        bool val_3 = val_2.ContainsKey(key:  val_15);
        // 0x00B29CF4: LDR x24, [x23, #0x10]      | X24 = this.heroAntiCheatCSData; //P2    
        // 0x00B29CF8: MOV w23, w0                | W23 = val_3;//m1                        
        // 0x00B29CFC: CBNZ x24, #0xb29d04        | if (this.heroAntiCheatCSData != null) goto label_5;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_5;
        }
        // 0x00B29D00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B29D04: LDR x2, [x25]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B29D08: MOV x0, x24                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29D0C: MOV x1, x22                | X1 = uuid;//m1                          
        // 0x00B29D10: BL #0x23fc26c              | X0 = this.heroAntiCheatCSData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_4 = this.heroAntiCheatCSData.Item[uuid];
        // 0x00B29D14: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B29D18: TBZ w23, #0, #0xb29e0c     | if (val_3 == false) goto label_6;       
        if(val_3 == false)
        {
            goto label_6;
        }
        // 0x00B29D1C: CBNZ x22, #0xb29d24        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B29D20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B29D24: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B29D28: LDR x8, [x8, #0x530]       | X8 = 1152921514939910176;               
        // 0x00B29D2C: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B29D30: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B29D34: LDR x2, [x8]               | X2 = public ACData System.Collections.Generic.Dictionary<System.String, ACData>::get_Item(System.String key);
        // 0x00B29D38: BL #0x23fc26c              | X0 = val_4.get_Item(key:  val_15);      
        ACData val_5 = val_4.Item[val_15];
        // 0x00B29D3C: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B29D40: CBNZ x19, #0xb29d48        | if (val_5 != null) goto label_8;        
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00B29D44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B29D48: ADD w1, w20, w21           | W1 = (acValue + value);                 
        uint val_6 = acValue + value;
        // 0x00B29D4C: STR w20, [x19, #0x14]      | val_5.acValue = acValue;                 //  dest_result_addr=0
        val_5.acValue = acValue;
        // 0x00B29D50: BL #0xb1be3c               | X0 = val_5.GetValueAdd(uValue:  uint val_6 = acValue + value);
        uint val_7 = val_5.GetValueAdd(uValue:  val_6);
        // 0x00B29D54: STR w0, [x19, #0x10]       | val_5.value = val_7;                     //  dest_result_addr=0
        val_5.value = val_7;
        // 0x00B29D58: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29D5C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29D60: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B29D64: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B29D68: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B29D6C: RET                        |  return;                                
        return;
        label_2:
        // 0x00B29D70: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B29D74: LDR x8, [x8, #0xa68]       | X8 = 1152921504615792640;               
        // 0x00B29D78: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, ACData> val_8 = null;
        // 0x00B29D7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B29D80: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B29D84: LDR x8, [x8, #0xf68]       | X8 = 1152921514939915296;               
        // 0x00B29D88: MOV x24, x0                | X24 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B29D8C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::.ctor();
        // 0x00B29D90: BL #0x23fb0c4              | .ctor();                                
        val_8 = new System.Collections.Generic.Dictionary<System.String, ACData>();
        // 0x00B29D94: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B29D98: LDR x8, [x8, #0xfd8]       | X8 = 1152921504902533120;               
        // 0x00B29D9C: LDR x0, [x8]               | X0 = typeof(ACData);                    
        object val_9 = null;
        // 0x00B29DA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ACData), ????);
        // 0x00B29DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29DA8: MOV x25, x0                | X25 = 1152921504902533120 (0x10000000119FD000);//ML01
        val_17 = val_9;
        // 0x00B29DAC: BL #0x16f59f0              | .ctor();                                
        val_9 = new System.Object();
        // 0x00B29DB0: ADD w1, w20, w21           | W1 = (acValue + value);                 
        uint val_10 = acValue + value;
        // 0x00B29DB4: STR w20, [x25, #0x14]      | typeof(ACData).__il2cppRuntimeField_14 = acValue;  //  dest_result_addr=1152921504902533140
        typeof(ACData).__il2cppRuntimeField_14 = acValue;
        // 0x00B29DB8: BL #0xb1be3c               | X0 = .ctor().GetValueAdd(uValue:  uint val_10 = acValue + value);
        uint val_11 = val_9.GetValueAdd(uValue:  val_10);
        // 0x00B29DBC: STR w0, [x25, #0x10]       | typeof(ACData).__il2cppRuntimeField_10 = val_11;  //  dest_result_addr=1152921504902533136
        typeof(ACData).__il2cppRuntimeField_10 = val_11;
        // 0x00B29DC0: CBNZ x24, #0xb29dc8        | if ( != 0) goto label_9;                
        if(null != 0)
        {
            goto label_9;
        }
        // 0x00B29DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_9:
        // 0x00B29DC8: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B29DCC: LDR x8, [x8, #0x6e0]       | X8 = 1152921514939916320;               
        // 0x00B29DD0: MOV x0, x24                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B29DD4: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B29DD8: MOV x2, x25                | X2 = 1152921504902533120 (0x10000000119FD000);//ML01
        // 0x00B29DDC: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::Add(System.String key, ACData value);
        // 0x00B29DE0: BL #0x23fd44c              | Add(key:  val_15, value:  val_17);      
        Add(key:  val_15, value:  val_17);
        // 0x00B29DE4: LDR x19, [x23, #0x10]      | X19 = this.heroAntiCheatCSData; //P2    
        val_15 = this.heroAntiCheatCSData;
        // 0x00B29DE8: CBNZ x19, #0xb29df0        | if (this.heroAntiCheatCSData != null) goto label_10;
        if(val_15 != null)
        {
            goto label_10;
        }
        // 0x00B29DEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_10:
        // 0x00B29DF0: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00B29DF4: LDR x8, [x8, #0x870]       | X8 = 1152921514939921440;               
        // 0x00B29DF8: MOV x0, x19                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29DFC: MOV x1, x22                | X1 = uuid;//m1                          
        val_18 = uuid;
        // 0x00B29E00: MOV x2, x24                | X2 = 1152921504615792640 (0x1000000000888000);//ML01
        val_19 = val_8;
        // 0x00B29E04: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Add(System.String key, System.Collections.Generic.Dictionary<System.String, ACData> value);
        val_20 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Add(System.String key, System.Collections.Generic.Dictionary<System.String, ACData> value);
        // 0x00B29E08: B #0xb29e58                |  goto label_11;                         
        goto label_11;
        label_6:
        // 0x00B29E0C: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B29E10: LDR x8, [x8, #0xfd8]       | X8 = 1152921504902533120;               
        // 0x00B29E14: LDR x0, [x8]               | X0 = typeof(ACData);                    
        object val_12 = null;
        // 0x00B29E18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ACData), ????);
        // 0x00B29E1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29E20: MOV x23, x0                | X23 = 1152921504902533120 (0x10000000119FD000);//ML01
        val_16 = val_12;
        // 0x00B29E24: BL #0x16f59f0              | .ctor();                                
        val_12 = new System.Object();
        // 0x00B29E28: ADD w1, w20, w21           | W1 = (acValue + value);                 
        uint val_13 = acValue + value;
        // 0x00B29E2C: STR w20, [x23, #0x14]      | typeof(ACData).__il2cppRuntimeField_14 = acValue;  //  dest_result_addr=1152921504902533140
        typeof(ACData).__il2cppRuntimeField_14 = acValue;
        // 0x00B29E30: BL #0xb1be3c               | X0 = .ctor().GetValueAdd(uValue:  uint val_13 = acValue + value);
        uint val_14 = val_12.GetValueAdd(uValue:  val_13);
        // 0x00B29E34: STR w0, [x23, #0x10]       | typeof(ACData).__il2cppRuntimeField_10 = val_14;  //  dest_result_addr=1152921504902533136
        typeof(ACData).__il2cppRuntimeField_10 = val_14;
        // 0x00B29E38: CBNZ x22, #0xb29e40        | if (val_4 != null) goto label_12;       
        if(val_4 != null)
        {
            goto label_12;
        }
        // 0x00B29E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_12:
        // 0x00B29E40: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B29E44: LDR x8, [x8, #0x6e0]       | X8 = 1152921514939916320;               
        // 0x00B29E48: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B29E4C: MOV x1, x19                | X1 = attrName;//m1                      
        val_18 = val_15;
        // 0x00B29E50: MOV x2, x23                | X2 = 1152921504902533120 (0x10000000119FD000);//ML01
        val_19 = val_16;
        // 0x00B29E54: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::Add(System.String key, ACData value);
        val_20 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::Add(System.String key, ACData value);
        label_11:
        // 0x00B29E58: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29E5C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29E60: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B29E64: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B29E68: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B29E6C: B #0x23fd44c               | val_4.Add(key:  val_18 = val_15, value:  val_19 = val_16); return;
        val_4.Add(key:  val_18, value:  val_19);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29E70 (11705968), len: 304  VirtAddr: 0x00B29E70 RVA: 0x00B29E70 token: 100693109 methodIndex: 24861 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetHeroAntiCheatCS(string uuid, string attrName)
    {
        //
        // Disasemble & Code
        //  | 
        string val_7;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>> val_8;
        //  | 
        var val_9;
        // 0x00B29E70: STP x24, x23, [sp, #-0x40]! | stack[1152921514940116032] = ???;  stack[1152921514940116040] = ???;  //  dest_result_addr=1152921514940116032 |  dest_result_addr=1152921514940116040
        // 0x00B29E74: STP x22, x21, [sp, #0x10]  | stack[1152921514940116048] = ???;  stack[1152921514940116056] = ???;  //  dest_result_addr=1152921514940116048 |  dest_result_addr=1152921514940116056
        // 0x00B29E78: STP x20, x19, [sp, #0x20]  | stack[1152921514940116064] = ???;  stack[1152921514940116072] = ???;  //  dest_result_addr=1152921514940116064 |  dest_result_addr=1152921514940116072
        // 0x00B29E7C: STP x29, x30, [sp, #0x30]  | stack[1152921514940116080] = ???;  stack[1152921514940116088] = ???;  //  dest_result_addr=1152921514940116080 |  dest_result_addr=1152921514940116088
        // 0x00B29E80: ADD x29, sp, #0x30         | X29 = (1152921514940116032 + 48) = 1152921514940116080 (0x1000000267E92C70);
        // 0x00B29E84: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B29E88: LDRB w8, [x22, #0x75f]     | W8 = (bool)static_value_0373375F;       
        // 0x00B29E8C: MOV x19, x2                | X19 = attrName;//m1                     
        val_7 = attrName;
        // 0x00B29E90: MOV x20, x1                | X20 = uuid;//m1                         
        // 0x00B29E94: MOV x21, x0                | X21 = 1152921514940128096 (0x1000000267E95B60);//ML01
        val_8 = this;
        // 0x00B29E98: TBNZ w8, #0, #0xb29eb4     | if (static_value_0373375F == true) goto label_0;
        // 0x00B29E9C: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B29EA0: LDR x8, [x8, #0x110]       | X8 = 0x2B8AFA4;                         
        // 0x00B29EA4: LDR w0, [x8]               | W0 = 0x2A7;                             
        // 0x00B29EA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A7, ????);      
        // 0x00B29EAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B29EB0: STRB w8, [x22, #0x75f]     | static_value_0373375F = true;            //  dest_result_addr=57882463
        label_0:
        // 0x00B29EB4: LDR x22, [x21, #0x10]      | X22 = this.heroAntiCheatCSData; //P2    
        // 0x00B29EB8: CBNZ x22, #0xb29ec0        | if (this.heroAntiCheatCSData != null) goto label_1;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_1;
        }
        // 0x00B29EBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A7, ????);      
        label_1:
        // 0x00B29EC0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B29EC4: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B29EC8: MOV x0, x22                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29ECC: MOV x1, x20                | X1 = uuid;//m1                          
        // 0x00B29ED0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B29ED4: BL #0x23fd9f0              | X0 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        bool val_1 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        // 0x00B29ED8: TBZ w0, #0, #0xb29f88      | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x00B29EDC: LDR x22, [x21, #0x10]      | X22 = this.heroAntiCheatCSData; //P2    
        // 0x00B29EE0: CBNZ x22, #0xb29ee8        | if (this.heroAntiCheatCSData != null) goto label_3;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_3;
        }
        // 0x00B29EE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B29EE8: ADRP x23, #0x35e4000       | X23 = 56508416 (0x35E4000);             
        // 0x00B29EEC: LDR x23, [x23, #0xc10]     | X23 = 1152921514939895840;              
        // 0x00B29EF0: MOV x0, x22                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29EF4: MOV x1, x20                | X1 = uuid;//m1                          
        // 0x00B29EF8: LDR x2, [x23]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B29EFC: BL #0x23fc26c              | X0 = this.heroAntiCheatCSData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_2 = this.heroAntiCheatCSData.Item[uuid];
        // 0x00B29F00: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B29F04: CBNZ x22, #0xb29f0c        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B29F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B29F0C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B29F10: LDR x8, [x8]               | X8 = 1152921514939900960;               
        // 0x00B29F14: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00B29F18: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B29F1C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ACData>::ContainsKey(System.String key);
        // 0x00B29F20: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  val_7);    
        bool val_3 = val_2.ContainsKey(key:  val_7);
        // 0x00B29F24: TBZ w0, #0, #0xb29f88      | if (val_3 == false) goto label_5;       
        if(val_3 == false)
        {
            goto label_5;
        }
        // 0x00B29F28: LDR x21, [x21, #0x10]      | X21 = this.heroAntiCheatCSData; //P2    
        val_8 = this.heroAntiCheatCSData;
        // 0x00B29F2C: CBNZ x21, #0xb29f34        | if (this.heroAntiCheatCSData != null) goto label_6;
        if(val_8 != null)
        {
            goto label_6;
        }
        // 0x00B29F30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B29F34: LDR x2, [x23]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B29F38: MOV x0, x21                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B29F3C: MOV x1, x20                | X1 = uuid;//m1                          
        // 0x00B29F40: BL #0x23fc26c              | X0 = this.heroAntiCheatCSData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_4 = val_8.Item[uuid];
        // 0x00B29F44: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B29F48: CBNZ x20, #0xb29f50        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B29F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B29F50: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B29F54: LDR x8, [x8, #0x530]       | X8 = 1152921514939910176;               
        // 0x00B29F58: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B29F5C: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B29F60: LDR x2, [x8]               | X2 = public ACData System.Collections.Generic.Dictionary<System.String, ACData>::get_Item(System.String key);
        // 0x00B29F64: BL #0x23fc26c              | X0 = val_4.get_Item(key:  val_7);       
        ACData val_5 = val_4.Item[val_7];
        // 0x00B29F68: MOV x19, x0                | X19 = val_5;//m1                        
        val_7 = val_5;
        // 0x00B29F6C: CBNZ x19, #0xb29f74        | if (val_5 != null) goto label_8;        
        if(val_7 != null)
        {
            goto label_8;
        }
        // 0x00B29F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B29F74: LDR w1, [x19, #0x10]       | W1 = val_5.value; //P2                  
        // 0x00B29F78: BL #0xb1bfd4               | X0 = val_5.GetValueReduce(uValue:  val_5.value);
        uint val_6 = val_5.GetValueReduce(uValue:  val_5.value);
        // 0x00B29F7C: LDR w8, [x19, #0x14]       | W8 = val_5.acValue; //P2                
        // 0x00B29F80: SUB w0, w0, w8             | W0 = (val_6 - val_5.acValue);           
        val_9 = val_6 - val_5.acValue;
        // 0x00B29F84: B #0xb29f8c                |  goto label_9;                          
        goto label_9;
        label_5:
        // 0x00B29F88: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_9 = 0;
        label_9:
        // 0x00B29F8C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29F90: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B29F94: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B29F98: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B29F9C: RET                        |  return (System.UInt32)null;            
        return (uint)val_9;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29FA0 (11706272), len: 304  VirtAddr: 0x00B29FA0 RVA: 0x00B29FA0 token: 100693110 methodIndex: 24862 delegateWrapperIndex: 0 methodInvoker: 0
    public int GetHeroAntiCheatCS(string uuid, string attrName, int defaultValue)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        string val_8;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>> val_9;
        // 0x00B29FA0: STP x24, x23, [sp, #-0x40]! | stack[1152921514940293568] = ???;  stack[1152921514940293576] = ???;  //  dest_result_addr=1152921514940293568 |  dest_result_addr=1152921514940293576
        // 0x00B29FA4: STP x22, x21, [sp, #0x10]  | stack[1152921514940293584] = ???;  stack[1152921514940293592] = ???;  //  dest_result_addr=1152921514940293584 |  dest_result_addr=1152921514940293592
        // 0x00B29FA8: STP x20, x19, [sp, #0x20]  | stack[1152921514940293600] = ???;  stack[1152921514940293608] = ???;  //  dest_result_addr=1152921514940293600 |  dest_result_addr=1152921514940293608
        // 0x00B29FAC: STP x29, x30, [sp, #0x30]  | stack[1152921514940293616] = ???;  stack[1152921514940293624] = ???;  //  dest_result_addr=1152921514940293616 |  dest_result_addr=1152921514940293624
        // 0x00B29FB0: ADD x29, sp, #0x30         | X29 = (1152921514940293568 + 48) = 1152921514940293616 (0x1000000267EBE1F0);
        // 0x00B29FB4: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B29FB8: LDRB w8, [x23, #0x760]     | W8 = (bool)static_value_03733760;       
        // 0x00B29FBC: MOV w20, w3                | W20 = defaultValue;//m1                 
        val_7 = defaultValue;
        // 0x00B29FC0: MOV x19, x2                | X19 = attrName;//m1                     
        val_8 = attrName;
        // 0x00B29FC4: MOV x21, x1                | X21 = uuid;//m1                         
        // 0x00B29FC8: MOV x22, x0                | X22 = 1152921514940305632 (0x1000000267EC10E0);//ML01
        // 0x00B29FCC: TBNZ w8, #0, #0xb29fe8     | if (static_value_03733760 == true) goto label_0;
        // 0x00B29FD0: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00B29FD4: LDR x8, [x8, #0xd40]       | X8 = 0x2B8AFA0;                         
        // 0x00B29FD8: LDR w0, [x8]               | W0 = 0x2A6;                             
        // 0x00B29FDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A6, ????);      
        // 0x00B29FE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B29FE4: STRB w8, [x23, #0x760]     | static_value_03733760 = true;            //  dest_result_addr=57882464
        label_0:
        // 0x00B29FE8: LDR x23, [x22, #0x10]      | X23 = this.heroAntiCheatCSData; //P2    
        val_9 = this.heroAntiCheatCSData;
        // 0x00B29FEC: CBNZ x23, #0xb29ff4        | if (this.heroAntiCheatCSData != null) goto label_1;
        if(val_9 != null)
        {
            goto label_1;
        }
        // 0x00B29FF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A6, ????);      
        label_1:
        // 0x00B29FF4: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B29FF8: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B29FFC: MOV x0, x23                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B2A000: MOV x1, x21                | X1 = uuid;//m1                          
        // 0x00B2A004: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B2A008: BL #0x23fd9f0              | X0 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        bool val_1 = val_9.ContainsKey(key:  uuid);
        // 0x00B2A00C: TBZ w0, #0, #0xb2a0b8      | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x00B2A010: LDR x23, [x22, #0x10]      | X23 = this.heroAntiCheatCSData; //P2    
        // 0x00B2A014: CBNZ x23, #0xb2a01c        | if (this.heroAntiCheatCSData != null) goto label_3;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_3;
        }
        // 0x00B2A018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B2A01C: ADRP x24, #0x35e4000       | X24 = 56508416 (0x35E4000);             
        // 0x00B2A020: LDR x24, [x24, #0xc10]     | X24 = 1152921514939895840;              
        // 0x00B2A024: MOV x0, x23                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B2A028: MOV x1, x21                | X1 = uuid;//m1                          
        // 0x00B2A02C: LDR x2, [x24]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A030: BL #0x23fc26c              | X0 = this.heroAntiCheatCSData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_2 = this.heroAntiCheatCSData.Item[uuid];
        // 0x00B2A034: MOV x23, x0                | X23 = val_2;//m1                        
        val_9 = val_2;
        // 0x00B2A038: CBNZ x23, #0xb2a040        | if (val_2 != null) goto label_4;        
        if(val_9 != null)
        {
            goto label_4;
        }
        // 0x00B2A03C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B2A040: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A044: LDR x8, [x8]               | X8 = 1152921514939900960;               
        // 0x00B2A048: MOV x0, x23                | X0 = val_2;//m1                         
        // 0x00B2A04C: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A050: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ACData>::ContainsKey(System.String key);
        // 0x00B2A054: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  val_8);    
        bool val_3 = val_9.ContainsKey(key:  val_8);
        // 0x00B2A058: TBZ w0, #0, #0xb2a0b8      | if (val_3 == false) goto label_5;       
        if(val_3 == false)
        {
            goto label_5;
        }
        // 0x00B2A05C: LDR x20, [x22, #0x10]      | X20 = this.heroAntiCheatCSData; //P2    
        // 0x00B2A060: CBNZ x20, #0xb2a068        | if (this.heroAntiCheatCSData != null) goto label_6;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_6;
        }
        // 0x00B2A064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B2A068: LDR x2, [x24]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A06C: MOV x0, x20                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B2A070: MOV x1, x21                | X1 = uuid;//m1                          
        // 0x00B2A074: BL #0x23fc26c              | X0 = this.heroAntiCheatCSData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_4 = this.heroAntiCheatCSData.Item[uuid];
        // 0x00B2A078: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B2A07C: CBNZ x20, #0xb2a084        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B2A080: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B2A084: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A088: LDR x8, [x8, #0x530]       | X8 = 1152921514939910176;               
        // 0x00B2A08C: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B2A090: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A094: LDR x2, [x8]               | X2 = public ACData System.Collections.Generic.Dictionary<System.String, ACData>::get_Item(System.String key);
        // 0x00B2A098: BL #0x23fc26c              | X0 = val_4.get_Item(key:  val_8);       
        ACData val_5 = val_4.Item[val_8];
        // 0x00B2A09C: MOV x19, x0                | X19 = val_5;//m1                        
        val_8 = val_5;
        // 0x00B2A0A0: CBNZ x19, #0xb2a0a8        | if (val_5 != null) goto label_8;        
        if(val_8 != null)
        {
            goto label_8;
        }
        // 0x00B2A0A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B2A0A8: LDR w1, [x19, #0x10]       | W1 = val_5.value; //P2                  
        // 0x00B2A0AC: BL #0xb1bfd4               | X0 = val_5.GetValueReduce(uValue:  val_5.value);
        uint val_6 = val_5.GetValueReduce(uValue:  val_5.value);
        // 0x00B2A0B0: LDR w8, [x19, #0x14]       | W8 = val_5.acValue; //P2                
        // 0x00B2A0B4: SUB w20, w0, w8            | W20 = (val_6 - val_5.acValue);          
        val_7 = val_6 - val_5.acValue;
        label_5:
        // 0x00B2A0B8: MOV w0, w20                | W0 = (val_6 - val_5.acValue);//m1       
        // 0x00B2A0BC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A0C0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A0C4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A0C8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2A0CC: RET                        |  return (System.Int32)(val_6 - val_5.acValue);
        return (int)val_7;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A0D0 (11706576), len: 164  VirtAddr: 0x00B2A0D0 RVA: 0x00B2A0D0 token: 100693111 methodIndex: 24863 delegateWrapperIndex: 0 methodInvoker: 0
    public void RemoveHeroAntiCheatCS(string uuid)
    {
        //
        // Disasemble & Code
        // 0x00B2A0D0: STP x22, x21, [sp, #-0x30]! | stack[1152921514940451664] = ???;  stack[1152921514940451672] = ???;  //  dest_result_addr=1152921514940451664 |  dest_result_addr=1152921514940451672
        // 0x00B2A0D4: STP x20, x19, [sp, #0x10]  | stack[1152921514940451680] = ???;  stack[1152921514940451688] = ???;  //  dest_result_addr=1152921514940451680 |  dest_result_addr=1152921514940451688
        // 0x00B2A0D8: STP x29, x30, [sp, #0x20]  | stack[1152921514940451696] = ???;  stack[1152921514940451704] = ???;  //  dest_result_addr=1152921514940451696 |  dest_result_addr=1152921514940451704
        // 0x00B2A0DC: ADD x29, sp, #0x20         | X29 = (1152921514940451664 + 32) = 1152921514940451696 (0x1000000267EE4B70);
        // 0x00B2A0E0: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B2A0E4: LDRB w8, [x21, #0x761]     | W8 = (bool)static_value_03733761;       
        // 0x00B2A0E8: MOV x19, x1                | X19 = uuid;//m1                         
        // 0x00B2A0EC: MOV x20, x0                | X20 = 1152921514940463712 (0x1000000267EE7A60);//ML01
        // 0x00B2A0F0: TBNZ w8, #0, #0xb2a10c     | if (static_value_03733761 == true) goto label_0;
        // 0x00B2A0F4: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x00B2A0F8: LDR x8, [x8, #0x628]       | X8 = 0x2B8AFAC;                         
        // 0x00B2A0FC: LDR w0, [x8]               | W0 = 0x2A9;                             
        // 0x00B2A100: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A9, ????);      
        // 0x00B2A104: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A108: STRB w8, [x21, #0x761]     | static_value_03733761 = true;            //  dest_result_addr=57882465
        label_0:
        // 0x00B2A10C: LDR x21, [x20, #0x10]      | X21 = this.heroAntiCheatCSData; //P2    
        // 0x00B2A110: CBNZ x21, #0xb2a118        | if (this.heroAntiCheatCSData != null) goto label_1;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_1;
        }
        // 0x00B2A114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A9, ????);      
        label_1:
        // 0x00B2A118: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B2A11C: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B2A120: MOV x0, x21                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B2A124: MOV x1, x19                | X1 = uuid;//m1                          
        // 0x00B2A128: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B2A12C: BL #0x23fd9f0              | X0 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        bool val_1 = this.heroAntiCheatCSData.ContainsKey(key:  uuid);
        // 0x00B2A130: TBZ w0, #0, #0xb2a164      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00B2A134: LDR x20, [x20, #0x10]      | X20 = this.heroAntiCheatCSData; //P2    
        // 0x00B2A138: CBNZ x20, #0xb2a140        | if (this.heroAntiCheatCSData != null) goto label_3;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_3;
        }
        // 0x00B2A13C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B2A140: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B2A144: LDR x8, [x8, #0xa10]       | X8 = 1152921514940438688;               
        // 0x00B2A148: MOV x0, x20                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B2A14C: MOV x1, x19                | X1 = uuid;//m1                          
        // 0x00B2A150: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Remove(System.String key);
        // 0x00B2A154: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A158: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A15C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A160: B #0x23fe354               | X0 = this.heroAntiCheatCSData.Remove(key:  uuid); return;
        bool val_2 = this.heroAntiCheatCSData.Remove(key:  uuid);
        return;
        label_2:
        // 0x00B2A164: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A168: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A16C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A170: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A174 (11706740), len: 92  VirtAddr: 0x00B2A174 RVA: 0x00B2A174 token: 100693112 methodIndex: 24864 delegateWrapperIndex: 0 methodInvoker: 0
    public void ClearHeroAntiCheat()
    {
        //
        // Disasemble & Code
        // 0x00B2A174: STP x20, x19, [sp, #-0x20]! | stack[1152921514940581088] = ???;  stack[1152921514940581096] = ???;  //  dest_result_addr=1152921514940581088 |  dest_result_addr=1152921514940581096
        // 0x00B2A178: STP x29, x30, [sp, #0x10]  | stack[1152921514940581104] = ???;  stack[1152921514940581112] = ???;  //  dest_result_addr=1152921514940581104 |  dest_result_addr=1152921514940581112
        // 0x00B2A17C: ADD x29, sp, #0x10         | X29 = (1152921514940581088 + 16) = 1152921514940581104 (0x1000000267F044F0);
        // 0x00B2A180: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2A184: LDRB w8, [x20, #0x762]     | W8 = (bool)static_value_03733762;       
        // 0x00B2A188: MOV x19, x0                | X19 = 1152921514940593120 (0x1000000267F073E0);//ML01
        // 0x00B2A18C: TBNZ w8, #0, #0xb2a1a8     | if (static_value_03733762 == true) goto label_0;
        // 0x00B2A190: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00B2A194: LDR x8, [x8, #0x6b8]       | X8 = 0x2B8AF90;                         
        // 0x00B2A198: LDR w0, [x8]               | W0 = 0x2A2;                             
        // 0x00B2A19C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A2, ????);      
        // 0x00B2A1A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A1A4: STRB w8, [x20, #0x762]     | static_value_03733762 = true;            //  dest_result_addr=57882466
        label_0:
        // 0x00B2A1A8: LDR x19, [x19, #0x18]      | X19 = this.heroAntiCheatData; //P2      
        // 0x00B2A1AC: CBNZ x19, #0xb2a1b4        | if (this.heroAntiCheatData != null) goto label_1;
        if(this.heroAntiCheatData != null)
        {
            goto label_1;
        }
        // 0x00B2A1B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A2, ????);      
        label_1:
        // 0x00B2A1B4: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00B2A1B8: LDR x8, [x8, #0x2b8]       | X8 = 1152921514940568096;               
        // 0x00B2A1BC: MOV x0, x19                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A1C0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Clear();
        // 0x00B2A1C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A1C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A1CC: B #0x23fd92c               | this.heroAntiCheatData.Clear(); return; 
        this.heroAntiCheatData.Clear();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A1D0 (11706832), len: 92  VirtAddr: 0x00B2A1D0 RVA: 0x00B2A1D0 token: 100693113 methodIndex: 24865 delegateWrapperIndex: 0 methodInvoker: 0
    public void ClearHeroAntiCheatCS()
    {
        //
        // Disasemble & Code
        // 0x00B2A1D0: STP x20, x19, [sp, #-0x20]! | stack[1152921514940701280] = ???;  stack[1152921514940701288] = ???;  //  dest_result_addr=1152921514940701280 |  dest_result_addr=1152921514940701288
        // 0x00B2A1D4: STP x29, x30, [sp, #0x10]  | stack[1152921514940701296] = ???;  stack[1152921514940701304] = ???;  //  dest_result_addr=1152921514940701296 |  dest_result_addr=1152921514940701304
        // 0x00B2A1D8: ADD x29, sp, #0x10         | X29 = (1152921514940701280 + 16) = 1152921514940701296 (0x1000000267F21A70);
        // 0x00B2A1DC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2A1E0: LDRB w8, [x20, #0x763]     | W8 = (bool)static_value_03733763;       
        // 0x00B2A1E4: MOV x19, x0                | X19 = 1152921514940713312 (0x1000000267F24960);//ML01
        // 0x00B2A1E8: TBNZ w8, #0, #0xb2a204     | if (static_value_03733763 == true) goto label_0;
        // 0x00B2A1EC: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00B2A1F0: LDR x8, [x8, #0x3c8]       | X8 = 0x2B8AF94;                         
        // 0x00B2A1F4: LDR w0, [x8]               | W0 = 0x2A3;                             
        // 0x00B2A1F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A3, ????);      
        // 0x00B2A1FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A200: STRB w8, [x20, #0x763]     | static_value_03733763 = true;            //  dest_result_addr=57882467
        label_0:
        // 0x00B2A204: LDR x19, [x19, #0x10]      | X19 = this.heroAntiCheatCSData; //P2    
        // 0x00B2A208: CBNZ x19, #0xb2a210        | if (this.heroAntiCheatCSData != null) goto label_1;
        if(this.heroAntiCheatCSData != null)
        {
            goto label_1;
        }
        // 0x00B2A20C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A3, ????);      
        label_1:
        // 0x00B2A210: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00B2A214: LDR x8, [x8, #0x2b8]       | X8 = 1152921514940568096;               
        // 0x00B2A218: MOV x0, x19                | X0 = this.heroAntiCheatCSData;//m1      
        // 0x00B2A21C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Clear();
        // 0x00B2A220: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A224: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A228: B #0x23fd92c               | this.heroAntiCheatCSData.Clear(); return;
        this.heroAntiCheatCSData.Clear();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A22C (11706924), len: 36  VirtAddr: 0x00B2A22C RVA: 0x00B2A22C token: 100693114 methodIndex: 24866 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B2A22C: STP x20, x19, [sp, #-0x20]! | stack[1152921514940817376] = ???;  stack[1152921514940817384] = ???;  //  dest_result_addr=1152921514940817376 |  dest_result_addr=1152921514940817384
        // 0x00B2A230: STP x29, x30, [sp, #0x10]  | stack[1152921514940817392] = ???;  stack[1152921514940817400] = ???;  //  dest_result_addr=1152921514940817392 |  dest_result_addr=1152921514940817400
        // 0x00B2A234: ADD x29, sp, #0x10         | X29 = (1152921514940817376 + 16) = 1152921514940817392 (0x1000000267F3DFF0);
        // 0x00B2A238: MOV x19, x0                | X19 = 1152921514940829408 (0x1000000267F40EE0);//ML01
        // 0x00B2A23C: BL #0xb2a174               | this.ClearHeroAntiCheat();              
        this.ClearHeroAntiCheat();
        // 0x00B2A240: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A244: MOV x0, x19                | X0 = 1152921514940829408 (0x1000000267F40EE0);//ML01
        // 0x00B2A248: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A24C: B #0xb2a1d0                | this.ClearHeroAntiCheatCS(); return;    
        this.ClearHeroAntiCheatCS();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A250 (11706960), len: 572  VirtAddr: 0x00B2A250 RVA: 0x00B2A250 token: 100693115 methodIndex: 24867 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetHeroAntiCheat(string uuid, string attrName, uint value, uint acValue)
    {
        //
        // Disasemble & Code
        //  | 
        string val_15;
        //  | 
        ACData val_16;
        //  | 
        ACData val_17;
        //  | 
        string val_18;
        //  | 
        ACData val_19;
        //  | 
        var val_20;
        // 0x00B2A250: STP x26, x25, [sp, #-0x50]! | stack[1152921514940966192] = ???;  stack[1152921514940966200] = ???;  //  dest_result_addr=1152921514940966192 |  dest_result_addr=1152921514940966200
        // 0x00B2A254: STP x24, x23, [sp, #0x10]  | stack[1152921514940966208] = ???;  stack[1152921514940966216] = ???;  //  dest_result_addr=1152921514940966208 |  dest_result_addr=1152921514940966216
        // 0x00B2A258: STP x22, x21, [sp, #0x20]  | stack[1152921514940966224] = ???;  stack[1152921514940966232] = ???;  //  dest_result_addr=1152921514940966224 |  dest_result_addr=1152921514940966232
        // 0x00B2A25C: STP x20, x19, [sp, #0x30]  | stack[1152921514940966240] = ???;  stack[1152921514940966248] = ???;  //  dest_result_addr=1152921514940966240 |  dest_result_addr=1152921514940966248
        // 0x00B2A260: STP x29, x30, [sp, #0x40]  | stack[1152921514940966256] = ???;  stack[1152921514940966264] = ???;  //  dest_result_addr=1152921514940966256 |  dest_result_addr=1152921514940966264
        // 0x00B2A264: ADD x29, sp, #0x40         | X29 = (1152921514940966192 + 64) = 1152921514940966256 (0x1000000267F62570);
        // 0x00B2A268: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00B2A26C: LDRB w8, [x24, #0x764]     | W8 = (bool)static_value_03733764;       
        // 0x00B2A270: MOV w20, w4                | W20 = acValue;//m1                      
        // 0x00B2A274: MOV w21, w3                | W21 = value;//m1                        
        // 0x00B2A278: MOV x19, x2                | X19 = attrName;//m1                     
        val_15 = attrName;
        // 0x00B2A27C: MOV x22, x1                | X22 = uuid;//m1                         
        // 0x00B2A280: MOV x23, x0                | X23 = 1152921514940978272 (0x1000000267F65460);//ML01
        val_16 = this;
        // 0x00B2A284: TBNZ w8, #0, #0xb2a2a0     | if (static_value_03733764 == true) goto label_0;
        // 0x00B2A288: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B2A28C: LDR x8, [x8, #0xac0]       | X8 = 0x2B8AFB0;                         
        // 0x00B2A290: LDR w0, [x8]               | W0 = 0x2AA;                             
        // 0x00B2A294: BL #0x2782188              | X0 = sub_2782188( ?? 0x2AA, ????);      
        // 0x00B2A298: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A29C: STRB w8, [x24, #0x764]     | static_value_03733764 = true;            //  dest_result_addr=57882468
        label_0:
        // 0x00B2A2A0: LDR x24, [x23, #0x18]      | X24 = this.heroAntiCheatData; //P2      
        // 0x00B2A2A4: CBNZ x24, #0xb2a2ac        | if (this.heroAntiCheatData != null) goto label_1;
        if(this.heroAntiCheatData != null)
        {
            goto label_1;
        }
        // 0x00B2A2A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2AA, ????);      
        label_1:
        // 0x00B2A2AC: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B2A2B0: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B2A2B4: MOV x0, x24                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A2B8: MOV x1, x22                | X1 = uuid;//m1                          
        // 0x00B2A2BC: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B2A2C0: BL #0x23fd9f0              | X0 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        bool val_1 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        // 0x00B2A2C4: TBZ w0, #0, #0xb2a38c      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00B2A2C8: LDR x24, [x23, #0x18]      | X24 = this.heroAntiCheatData; //P2      
        // 0x00B2A2CC: CBNZ x24, #0xb2a2d4        | if (this.heroAntiCheatData != null) goto label_3;
        if(this.heroAntiCheatData != null)
        {
            goto label_3;
        }
        // 0x00B2A2D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B2A2D4: ADRP x25, #0x35e4000       | X25 = 56508416 (0x35E4000);             
        // 0x00B2A2D8: LDR x25, [x25, #0xc10]     | X25 = 1152921514939895840;              
        val_17 = 1152921514939895840;
        // 0x00B2A2DC: MOV x0, x24                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A2E0: MOV x1, x22                | X1 = uuid;//m1                          
        // 0x00B2A2E4: LDR x2, [x25]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A2E8: BL #0x23fc26c              | X0 = this.heroAntiCheatData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_2 = this.heroAntiCheatData.Item[uuid];
        // 0x00B2A2EC: MOV x24, x0                | X24 = val_2;//m1                        
        // 0x00B2A2F0: CBNZ x24, #0xb2a2f8        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2A2F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B2A2F8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A2FC: LDR x8, [x8]               | X8 = 1152921514939900960;               
        // 0x00B2A300: MOV x0, x24                | X0 = val_2;//m1                         
        // 0x00B2A304: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A308: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ACData>::ContainsKey(System.String key);
        // 0x00B2A30C: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  val_15);   
        bool val_3 = val_2.ContainsKey(key:  val_15);
        // 0x00B2A310: LDR x24, [x23, #0x18]      | X24 = this.heroAntiCheatData; //P2      
        // 0x00B2A314: MOV w23, w0                | W23 = val_3;//m1                        
        // 0x00B2A318: CBNZ x24, #0xb2a320        | if (this.heroAntiCheatData != null) goto label_5;
        if(this.heroAntiCheatData != null)
        {
            goto label_5;
        }
        // 0x00B2A31C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B2A320: LDR x2, [x25]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A324: MOV x0, x24                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A328: MOV x1, x22                | X1 = uuid;//m1                          
        // 0x00B2A32C: BL #0x23fc26c              | X0 = this.heroAntiCheatData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_4 = this.heroAntiCheatData.Item[uuid];
        // 0x00B2A330: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B2A334: TBZ w23, #0, #0xb2a428     | if (val_3 == false) goto label_6;       
        if(val_3 == false)
        {
            goto label_6;
        }
        // 0x00B2A338: CBNZ x22, #0xb2a340        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B2A33C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B2A340: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A344: LDR x8, [x8, #0x530]       | X8 = 1152921514939910176;               
        // 0x00B2A348: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B2A34C: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A350: LDR x2, [x8]               | X2 = public ACData System.Collections.Generic.Dictionary<System.String, ACData>::get_Item(System.String key);
        // 0x00B2A354: BL #0x23fc26c              | X0 = val_4.get_Item(key:  val_15);      
        ACData val_5 = val_4.Item[val_15];
        // 0x00B2A358: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B2A35C: CBNZ x19, #0xb2a364        | if (val_5 != null) goto label_8;        
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00B2A360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B2A364: ADD w1, w20, w21           | W1 = (acValue + value);                 
        uint val_6 = acValue + value;
        // 0x00B2A368: STR w20, [x19, #0x14]      | val_5.acValue = acValue;                 //  dest_result_addr=0
        val_5.acValue = acValue;
        // 0x00B2A36C: BL #0xb1be3c               | X0 = val_5.GetValueAdd(uValue:  uint val_6 = acValue + value);
        uint val_7 = val_5.GetValueAdd(uValue:  val_6);
        // 0x00B2A370: STR w0, [x19, #0x10]       | val_5.value = val_7;                     //  dest_result_addr=0
        val_5.value = val_7;
        // 0x00B2A374: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A378: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A37C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A380: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B2A384: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B2A388: RET                        |  return;                                
        return;
        label_2:
        // 0x00B2A38C: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B2A390: LDR x8, [x8, #0xa68]       | X8 = 1152921504615792640;               
        // 0x00B2A394: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, ACData> val_8 = null;
        // 0x00B2A398: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B2A39C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B2A3A0: LDR x8, [x8, #0xf68]       | X8 = 1152921514939915296;               
        // 0x00B2A3A4: MOV x24, x0                | X24 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B2A3A8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::.ctor();
        // 0x00B2A3AC: BL #0x23fb0c4              | .ctor();                                
        val_8 = new System.Collections.Generic.Dictionary<System.String, ACData>();
        // 0x00B2A3B0: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B2A3B4: LDR x8, [x8, #0xfd8]       | X8 = 1152921504902533120;               
        // 0x00B2A3B8: LDR x0, [x8]               | X0 = typeof(ACData);                    
        object val_9 = null;
        // 0x00B2A3BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ACData), ????);
        // 0x00B2A3C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2A3C4: MOV x25, x0                | X25 = 1152921504902533120 (0x10000000119FD000);//ML01
        val_17 = val_9;
        // 0x00B2A3C8: BL #0x16f59f0              | .ctor();                                
        val_9 = new System.Object();
        // 0x00B2A3CC: ADD w1, w20, w21           | W1 = (acValue + value);                 
        uint val_10 = acValue + value;
        // 0x00B2A3D0: STR w20, [x25, #0x14]      | typeof(ACData).__il2cppRuntimeField_14 = acValue;  //  dest_result_addr=1152921504902533140
        typeof(ACData).__il2cppRuntimeField_14 = acValue;
        // 0x00B2A3D4: BL #0xb1be3c               | X0 = .ctor().GetValueAdd(uValue:  uint val_10 = acValue + value);
        uint val_11 = val_9.GetValueAdd(uValue:  val_10);
        // 0x00B2A3D8: STR w0, [x25, #0x10]       | typeof(ACData).__il2cppRuntimeField_10 = val_11;  //  dest_result_addr=1152921504902533136
        typeof(ACData).__il2cppRuntimeField_10 = val_11;
        // 0x00B2A3DC: CBNZ x24, #0xb2a3e4        | if ( != 0) goto label_9;                
        if(null != 0)
        {
            goto label_9;
        }
        // 0x00B2A3E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_9:
        // 0x00B2A3E4: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B2A3E8: LDR x8, [x8, #0x6e0]       | X8 = 1152921514939916320;               
        // 0x00B2A3EC: MOV x0, x24                | X0 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B2A3F0: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A3F4: MOV x2, x25                | X2 = 1152921504902533120 (0x10000000119FD000);//ML01
        // 0x00B2A3F8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::Add(System.String key, ACData value);
        // 0x00B2A3FC: BL #0x23fd44c              | Add(key:  val_15, value:  val_17);      
        Add(key:  val_15, value:  val_17);
        // 0x00B2A400: LDR x19, [x23, #0x18]      | X19 = this.heroAntiCheatData; //P2      
        val_15 = this.heroAntiCheatData;
        // 0x00B2A404: CBNZ x19, #0xb2a40c        | if (this.heroAntiCheatData != null) goto label_10;
        if(val_15 != null)
        {
            goto label_10;
        }
        // 0x00B2A408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        label_10:
        // 0x00B2A40C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00B2A410: LDR x8, [x8, #0x870]       | X8 = 1152921514939921440;               
        // 0x00B2A414: MOV x0, x19                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A418: MOV x1, x22                | X1 = uuid;//m1                          
        val_18 = uuid;
        // 0x00B2A41C: MOV x2, x24                | X2 = 1152921504615792640 (0x1000000000888000);//ML01
        val_19 = val_8;
        // 0x00B2A420: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Add(System.String key, System.Collections.Generic.Dictionary<System.String, ACData> value);
        val_20 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Add(System.String key, System.Collections.Generic.Dictionary<System.String, ACData> value);
        // 0x00B2A424: B #0xb2a474                |  goto label_11;                         
        goto label_11;
        label_6:
        // 0x00B2A428: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B2A42C: LDR x8, [x8, #0xfd8]       | X8 = 1152921504902533120;               
        // 0x00B2A430: LDR x0, [x8]               | X0 = typeof(ACData);                    
        object val_12 = null;
        // 0x00B2A434: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ACData), ????);
        // 0x00B2A438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2A43C: MOV x23, x0                | X23 = 1152921504902533120 (0x10000000119FD000);//ML01
        val_16 = val_12;
        // 0x00B2A440: BL #0x16f59f0              | .ctor();                                
        val_12 = new System.Object();
        // 0x00B2A444: ADD w1, w20, w21           | W1 = (acValue + value);                 
        uint val_13 = acValue + value;
        // 0x00B2A448: STR w20, [x23, #0x14]      | typeof(ACData).__il2cppRuntimeField_14 = acValue;  //  dest_result_addr=1152921504902533140
        typeof(ACData).__il2cppRuntimeField_14 = acValue;
        // 0x00B2A44C: BL #0xb1be3c               | X0 = .ctor().GetValueAdd(uValue:  uint val_13 = acValue + value);
        uint val_14 = val_12.GetValueAdd(uValue:  val_13);
        // 0x00B2A450: STR w0, [x23, #0x10]       | typeof(ACData).__il2cppRuntimeField_10 = val_14;  //  dest_result_addr=1152921504902533136
        typeof(ACData).__il2cppRuntimeField_10 = val_14;
        // 0x00B2A454: CBNZ x22, #0xb2a45c        | if (val_4 != null) goto label_12;       
        if(val_4 != null)
        {
            goto label_12;
        }
        // 0x00B2A458: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_12:
        // 0x00B2A45C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
        // 0x00B2A460: LDR x8, [x8, #0x6e0]       | X8 = 1152921514939916320;               
        // 0x00B2A464: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B2A468: MOV x1, x19                | X1 = attrName;//m1                      
        val_18 = val_15;
        // 0x00B2A46C: MOV x2, x23                | X2 = 1152921504902533120 (0x10000000119FD000);//ML01
        val_19 = val_16;
        // 0x00B2A470: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::Add(System.String key, ACData value);
        val_20 = public System.Void System.Collections.Generic.Dictionary<System.String, ACData>::Add(System.String key, ACData value);
        label_11:
        // 0x00B2A474: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A478: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A47C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A480: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B2A484: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B2A488: B #0x23fd44c               | val_4.Add(key:  val_18 = val_15, value:  val_19 = val_16); return;
        val_4.Add(key:  val_18, value:  val_19);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A48C (11707532), len: 304  VirtAddr: 0x00B2A48C RVA: 0x00B2A48C token: 100693116 methodIndex: 24868 delegateWrapperIndex: 0 methodInvoker: 0
    public uint GetHeroAntiCheat(string uuid, string attrName)
    {
        //
        // Disasemble & Code
        //  | 
        string val_7;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>> val_8;
        //  | 
        var val_9;
        // 0x00B2A48C: STP x24, x23, [sp, #-0x40]! | stack[1152921514941147840] = ???;  stack[1152921514941147848] = ???;  //  dest_result_addr=1152921514941147840 |  dest_result_addr=1152921514941147848
        // 0x00B2A490: STP x22, x21, [sp, #0x10]  | stack[1152921514941147856] = ???;  stack[1152921514941147864] = ???;  //  dest_result_addr=1152921514941147856 |  dest_result_addr=1152921514941147864
        // 0x00B2A494: STP x20, x19, [sp, #0x20]  | stack[1152921514941147872] = ???;  stack[1152921514941147880] = ???;  //  dest_result_addr=1152921514941147872 |  dest_result_addr=1152921514941147880
        // 0x00B2A498: STP x29, x30, [sp, #0x30]  | stack[1152921514941147888] = ???;  stack[1152921514941147896] = ???;  //  dest_result_addr=1152921514941147888 |  dest_result_addr=1152921514941147896
        // 0x00B2A49C: ADD x29, sp, #0x30         | X29 = (1152921514941147840 + 48) = 1152921514941147888 (0x1000000267F8EAF0);
        // 0x00B2A4A0: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B2A4A4: LDRB w8, [x22, #0x765]     | W8 = (bool)static_value_03733765;       
        // 0x00B2A4A8: MOV x19, x2                | X19 = attrName;//m1                     
        val_7 = attrName;
        // 0x00B2A4AC: MOV x20, x1                | X20 = uuid;//m1                         
        // 0x00B2A4B0: MOV x21, x0                | X21 = 1152921514941159904 (0x1000000267F919E0);//ML01
        val_8 = this;
        // 0x00B2A4B4: TBNZ w8, #0, #0xb2a4d0     | if (static_value_03733765 == true) goto label_0;
        // 0x00B2A4B8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B2A4BC: LDR x8, [x8, #0xe10]       | X8 = 0x2B8AF9C;                         
        // 0x00B2A4C0: LDR w0, [x8]               | W0 = 0x2A5;                             
        // 0x00B2A4C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A5, ????);      
        // 0x00B2A4C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A4CC: STRB w8, [x22, #0x765]     | static_value_03733765 = true;            //  dest_result_addr=57882469
        label_0:
        // 0x00B2A4D0: LDR x22, [x21, #0x18]      | X22 = this.heroAntiCheatData; //P2      
        // 0x00B2A4D4: CBNZ x22, #0xb2a4dc        | if (this.heroAntiCheatData != null) goto label_1;
        if(this.heroAntiCheatData != null)
        {
            goto label_1;
        }
        // 0x00B2A4D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A5, ????);      
        label_1:
        // 0x00B2A4DC: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B2A4E0: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B2A4E4: MOV x0, x22                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A4E8: MOV x1, x20                | X1 = uuid;//m1                          
        // 0x00B2A4EC: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B2A4F0: BL #0x23fd9f0              | X0 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        bool val_1 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        // 0x00B2A4F4: TBZ w0, #0, #0xb2a5a4      | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x00B2A4F8: LDR x22, [x21, #0x18]      | X22 = this.heroAntiCheatData; //P2      
        // 0x00B2A4FC: CBNZ x22, #0xb2a504        | if (this.heroAntiCheatData != null) goto label_3;
        if(this.heroAntiCheatData != null)
        {
            goto label_3;
        }
        // 0x00B2A500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B2A504: ADRP x23, #0x35e4000       | X23 = 56508416 (0x35E4000);             
        // 0x00B2A508: LDR x23, [x23, #0xc10]     | X23 = 1152921514939895840;              
        // 0x00B2A50C: MOV x0, x22                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A510: MOV x1, x20                | X1 = uuid;//m1                          
        // 0x00B2A514: LDR x2, [x23]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A518: BL #0x23fc26c              | X0 = this.heroAntiCheatData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_2 = this.heroAntiCheatData.Item[uuid];
        // 0x00B2A51C: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B2A520: CBNZ x22, #0xb2a528        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00B2A524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B2A528: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A52C: LDR x8, [x8]               | X8 = 1152921514939900960;               
        // 0x00B2A530: MOV x0, x22                | X0 = val_2;//m1                         
        // 0x00B2A534: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A538: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ACData>::ContainsKey(System.String key);
        // 0x00B2A53C: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  val_7);    
        bool val_3 = val_2.ContainsKey(key:  val_7);
        // 0x00B2A540: TBZ w0, #0, #0xb2a5a4      | if (val_3 == false) goto label_5;       
        if(val_3 == false)
        {
            goto label_5;
        }
        // 0x00B2A544: LDR x21, [x21, #0x18]      | X21 = this.heroAntiCheatData; //P2      
        val_8 = this.heroAntiCheatData;
        // 0x00B2A548: CBNZ x21, #0xb2a550        | if (this.heroAntiCheatData != null) goto label_6;
        if(val_8 != null)
        {
            goto label_6;
        }
        // 0x00B2A54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B2A550: LDR x2, [x23]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A554: MOV x0, x21                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A558: MOV x1, x20                | X1 = uuid;//m1                          
        // 0x00B2A55C: BL #0x23fc26c              | X0 = this.heroAntiCheatData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_4 = val_8.Item[uuid];
        // 0x00B2A560: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B2A564: CBNZ x20, #0xb2a56c        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B2A568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B2A56C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A570: LDR x8, [x8, #0x530]       | X8 = 1152921514939910176;               
        // 0x00B2A574: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B2A578: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A57C: LDR x2, [x8]               | X2 = public ACData System.Collections.Generic.Dictionary<System.String, ACData>::get_Item(System.String key);
        // 0x00B2A580: BL #0x23fc26c              | X0 = val_4.get_Item(key:  val_7);       
        ACData val_5 = val_4.Item[val_7];
        // 0x00B2A584: MOV x19, x0                | X19 = val_5;//m1                        
        val_7 = val_5;
        // 0x00B2A588: CBNZ x19, #0xb2a590        | if (val_5 != null) goto label_8;        
        if(val_7 != null)
        {
            goto label_8;
        }
        // 0x00B2A58C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B2A590: LDR w1, [x19, #0x10]       | W1 = val_5.value; //P2                  
        // 0x00B2A594: BL #0xb1bfd4               | X0 = val_5.GetValueReduce(uValue:  val_5.value);
        uint val_6 = val_5.GetValueReduce(uValue:  val_5.value);
        // 0x00B2A598: LDR w8, [x19, #0x14]       | W8 = val_5.acValue; //P2                
        // 0x00B2A59C: SUB w0, w0, w8             | W0 = (val_6 - val_5.acValue);           
        val_9 = val_6 - val_5.acValue;
        // 0x00B2A5A0: B #0xb2a5a8                |  goto label_9;                          
        goto label_9;
        label_5:
        // 0x00B2A5A4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_9 = 0;
        label_9:
        // 0x00B2A5A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A5AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A5B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A5B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2A5B8: RET                        |  return (System.UInt32)null;            
        return (uint)val_9;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A5BC (11707836), len: 304  VirtAddr: 0x00B2A5BC RVA: 0x00B2A5BC token: 100693117 methodIndex: 24869 delegateWrapperIndex: 0 methodInvoker: 0
    public int GetHeroAntiCheat(string uuid, string attrName, int defaultValue)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        string val_8;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>> val_9;
        // 0x00B2A5BC: STP x24, x23, [sp, #-0x40]! | stack[1152921514941325376] = ???;  stack[1152921514941325384] = ???;  //  dest_result_addr=1152921514941325376 |  dest_result_addr=1152921514941325384
        // 0x00B2A5C0: STP x22, x21, [sp, #0x10]  | stack[1152921514941325392] = ???;  stack[1152921514941325400] = ???;  //  dest_result_addr=1152921514941325392 |  dest_result_addr=1152921514941325400
        // 0x00B2A5C4: STP x20, x19, [sp, #0x20]  | stack[1152921514941325408] = ???;  stack[1152921514941325416] = ???;  //  dest_result_addr=1152921514941325408 |  dest_result_addr=1152921514941325416
        // 0x00B2A5C8: STP x29, x30, [sp, #0x30]  | stack[1152921514941325424] = ???;  stack[1152921514941325432] = ???;  //  dest_result_addr=1152921514941325424 |  dest_result_addr=1152921514941325432
        // 0x00B2A5CC: ADD x29, sp, #0x30         | X29 = (1152921514941325376 + 48) = 1152921514941325424 (0x1000000267FBA070);
        // 0x00B2A5D0: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B2A5D4: LDRB w8, [x23, #0x766]     | W8 = (bool)static_value_03733766;       
        // 0x00B2A5D8: MOV w20, w3                | W20 = defaultValue;//m1                 
        val_7 = defaultValue;
        // 0x00B2A5DC: MOV x19, x2                | X19 = attrName;//m1                     
        val_8 = attrName;
        // 0x00B2A5E0: MOV x21, x1                | X21 = uuid;//m1                         
        // 0x00B2A5E4: MOV x22, x0                | X22 = 1152921514941337440 (0x1000000267FBCF60);//ML01
        // 0x00B2A5E8: TBNZ w8, #0, #0xb2a604     | if (static_value_03733766 == true) goto label_0;
        // 0x00B2A5EC: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00B2A5F0: LDR x8, [x8, #0xc0]        | X8 = 0x2B8AF98;                         
        // 0x00B2A5F4: LDR w0, [x8]               | W0 = 0x2A4;                             
        // 0x00B2A5F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A4, ????);      
        // 0x00B2A5FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A600: STRB w8, [x23, #0x766]     | static_value_03733766 = true;            //  dest_result_addr=57882470
        label_0:
        // 0x00B2A604: LDR x23, [x22, #0x18]      | X23 = this.heroAntiCheatData; //P2      
        val_9 = this.heroAntiCheatData;
        // 0x00B2A608: CBNZ x23, #0xb2a610        | if (this.heroAntiCheatData != null) goto label_1;
        if(val_9 != null)
        {
            goto label_1;
        }
        // 0x00B2A60C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A4, ????);      
        label_1:
        // 0x00B2A610: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B2A614: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B2A618: MOV x0, x23                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A61C: MOV x1, x21                | X1 = uuid;//m1                          
        // 0x00B2A620: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B2A624: BL #0x23fd9f0              | X0 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        bool val_1 = val_9.ContainsKey(key:  uuid);
        // 0x00B2A628: TBZ w0, #0, #0xb2a6d4      | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x00B2A62C: LDR x23, [x22, #0x18]      | X23 = this.heroAntiCheatData; //P2      
        // 0x00B2A630: CBNZ x23, #0xb2a638        | if (this.heroAntiCheatData != null) goto label_3;
        if(this.heroAntiCheatData != null)
        {
            goto label_3;
        }
        // 0x00B2A634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B2A638: ADRP x24, #0x35e4000       | X24 = 56508416 (0x35E4000);             
        // 0x00B2A63C: LDR x24, [x24, #0xc10]     | X24 = 1152921514939895840;              
        // 0x00B2A640: MOV x0, x23                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A644: MOV x1, x21                | X1 = uuid;//m1                          
        // 0x00B2A648: LDR x2, [x24]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A64C: BL #0x23fc26c              | X0 = this.heroAntiCheatData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_2 = this.heroAntiCheatData.Item[uuid];
        // 0x00B2A650: MOV x23, x0                | X23 = val_2;//m1                        
        val_9 = val_2;
        // 0x00B2A654: CBNZ x23, #0xb2a65c        | if (val_2 != null) goto label_4;        
        if(val_9 != null)
        {
            goto label_4;
        }
        // 0x00B2A658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B2A65C: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A660: LDR x8, [x8]               | X8 = 1152921514939900960;               
        // 0x00B2A664: MOV x0, x23                | X0 = val_2;//m1                         
        // 0x00B2A668: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A66C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ACData>::ContainsKey(System.String key);
        // 0x00B2A670: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  val_8);    
        bool val_3 = val_9.ContainsKey(key:  val_8);
        // 0x00B2A674: TBZ w0, #0, #0xb2a6d4      | if (val_3 == false) goto label_5;       
        if(val_3 == false)
        {
            goto label_5;
        }
        // 0x00B2A678: LDR x20, [x22, #0x18]      | X20 = this.heroAntiCheatData; //P2      
        // 0x00B2A67C: CBNZ x20, #0xb2a684        | if (this.heroAntiCheatData != null) goto label_6;
        if(this.heroAntiCheatData != null)
        {
            goto label_6;
        }
        // 0x00B2A680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B2A684: LDR x2, [x24]              | X2 = public System.Collections.Generic.Dictionary<System.String, ACData> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::get_Item(System.String key);
        // 0x00B2A688: MOV x0, x20                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A68C: MOV x1, x21                | X1 = uuid;//m1                          
        // 0x00B2A690: BL #0x23fc26c              | X0 = this.heroAntiCheatData.get_Item(key:  uuid);
        System.Collections.Generic.Dictionary<System.String, ACData> val_4 = this.heroAntiCheatData.Item[uuid];
        // 0x00B2A694: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B2A698: CBNZ x20, #0xb2a6a0        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B2A69C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B2A6A0: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
        // 0x00B2A6A4: LDR x8, [x8, #0x530]       | X8 = 1152921514939910176;               
        // 0x00B2A6A8: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B2A6AC: MOV x1, x19                | X1 = attrName;//m1                      
        // 0x00B2A6B0: LDR x2, [x8]               | X2 = public ACData System.Collections.Generic.Dictionary<System.String, ACData>::get_Item(System.String key);
        // 0x00B2A6B4: BL #0x23fc26c              | X0 = val_4.get_Item(key:  val_8);       
        ACData val_5 = val_4.Item[val_8];
        // 0x00B2A6B8: MOV x19, x0                | X19 = val_5;//m1                        
        val_8 = val_5;
        // 0x00B2A6BC: CBNZ x19, #0xb2a6c4        | if (val_5 != null) goto label_8;        
        if(val_8 != null)
        {
            goto label_8;
        }
        // 0x00B2A6C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B2A6C4: LDR w1, [x19, #0x10]       | W1 = val_5.value; //P2                  
        // 0x00B2A6C8: BL #0xb1bfd4               | X0 = val_5.GetValueReduce(uValue:  val_5.value);
        uint val_6 = val_5.GetValueReduce(uValue:  val_5.value);
        // 0x00B2A6CC: LDR w8, [x19, #0x14]       | W8 = val_5.acValue; //P2                
        // 0x00B2A6D0: SUB w20, w0, w8            | W20 = (val_6 - val_5.acValue);          
        val_7 = val_6 - val_5.acValue;
        label_5:
        // 0x00B2A6D4: MOV w0, w20                | W0 = (val_6 - val_5.acValue);//m1       
        // 0x00B2A6D8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A6DC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A6E0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A6E4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B2A6E8: RET                        |  return (System.Int32)(val_6 - val_5.acValue);
        return (int)val_7;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2A6EC (11708140), len: 164  VirtAddr: 0x00B2A6EC RVA: 0x00B2A6EC token: 100693118 methodIndex: 24870 delegateWrapperIndex: 0 methodInvoker: 0
    public void RemoveHeroAntiCheat(string uuid)
    {
        //
        // Disasemble & Code
        // 0x00B2A6EC: STP x22, x21, [sp, #-0x30]! | stack[1152921514941482448] = ???;  stack[1152921514941482456] = ???;  //  dest_result_addr=1152921514941482448 |  dest_result_addr=1152921514941482456
        // 0x00B2A6F0: STP x20, x19, [sp, #0x10]  | stack[1152921514941482464] = ???;  stack[1152921514941482472] = ???;  //  dest_result_addr=1152921514941482464 |  dest_result_addr=1152921514941482472
        // 0x00B2A6F4: STP x29, x30, [sp, #0x20]  | stack[1152921514941482480] = ???;  stack[1152921514941482488] = ???;  //  dest_result_addr=1152921514941482480 |  dest_result_addr=1152921514941482488
        // 0x00B2A6F8: ADD x29, sp, #0x20         | X29 = (1152921514941482448 + 32) = 1152921514941482480 (0x1000000267FE05F0);
        // 0x00B2A6FC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B2A700: LDRB w8, [x21, #0x767]     | W8 = (bool)static_value_03733767;       
        // 0x00B2A704: MOV x19, x1                | X19 = uuid;//m1                         
        // 0x00B2A708: MOV x20, x0                | X20 = 1152921514941494496 (0x1000000267FE34E0);//ML01
        // 0x00B2A70C: TBNZ w8, #0, #0xb2a728     | if (static_value_03733767 == true) goto label_0;
        // 0x00B2A710: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00B2A714: LDR x8, [x8, #0xcd8]       | X8 = 0x2B8AFA8;                         
        // 0x00B2A718: LDR w0, [x8]               | W0 = 0x2A8;                             
        // 0x00B2A71C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A8, ????);      
        // 0x00B2A720: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2A724: STRB w8, [x21, #0x767]     | static_value_03733767 = true;            //  dest_result_addr=57882471
        label_0:
        // 0x00B2A728: LDR x21, [x20, #0x18]      | X21 = this.heroAntiCheatData; //P2      
        // 0x00B2A72C: CBNZ x21, #0xb2a734        | if (this.heroAntiCheatData != null) goto label_1;
        if(this.heroAntiCheatData != null)
        {
            goto label_1;
        }
        // 0x00B2A730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A8, ????);      
        label_1:
        // 0x00B2A734: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x00B2A738: LDR x8, [x8, #0x4f0]       | X8 = 1152921514939890720;               
        // 0x00B2A73C: MOV x0, x21                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A740: MOV x1, x19                | X1 = uuid;//m1                          
        // 0x00B2A744: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::ContainsKey(System.String key);
        // 0x00B2A748: BL #0x23fd9f0              | X0 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        bool val_1 = this.heroAntiCheatData.ContainsKey(key:  uuid);
        // 0x00B2A74C: TBZ w0, #0, #0xb2a780      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00B2A750: LDR x20, [x20, #0x18]      | X20 = this.heroAntiCheatData; //P2      
        // 0x00B2A754: CBNZ x20, #0xb2a75c        | if (this.heroAntiCheatData != null) goto label_3;
        if(this.heroAntiCheatData != null)
        {
            goto label_3;
        }
        // 0x00B2A758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B2A75C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B2A760: LDR x8, [x8, #0xa10]       | X8 = 1152921514940438688;               
        // 0x00B2A764: MOV x0, x20                | X0 = this.heroAntiCheatData;//m1        
        // 0x00B2A768: MOV x1, x19                | X1 = uuid;//m1                          
        // 0x00B2A76C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.Dictionary<System.String, ACData>>::Remove(System.String key);
        // 0x00B2A770: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A774: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A778: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A77C: B #0x23fe354               | X0 = this.heroAntiCheatData.Remove(key:  uuid); return;
        bool val_2 = this.heroAntiCheatData.Remove(key:  uuid);
        return;
        label_2:
        // 0x00B2A780: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2A784: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2A788: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B2A78C: RET                        |  return;                                
        return;
    
    }

}
