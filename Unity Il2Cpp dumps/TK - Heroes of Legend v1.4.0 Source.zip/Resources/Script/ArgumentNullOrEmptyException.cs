using UnityEngine;

namespace ILRuntime.Mono
{
    internal class ArgumentNullOrEmptyException : ArgumentException
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E53DAC (15023532), len: 284  VirtAddr: 0x00E53DAC RVA: 0x00E53DAC token: 100663302 methodIndex: 19257 delegateWrapperIndex: 0 methodInvoker: 0
        public ArgumentNullOrEmptyException(string paramName)
        {
            //
            // Disasemble & Code
            // 0x00E53DAC: STP x22, x21, [sp, #-0x30]! | stack[1152921509401106336] = ???;  stack[1152921509401106344] = ???;  //  dest_result_addr=1152921509401106336 |  dest_result_addr=1152921509401106344
            // 0x00E53DB0: STP x20, x19, [sp, #0x10]  | stack[1152921509401106352] = ???;  stack[1152921509401106360] = ???;  //  dest_result_addr=1152921509401106352 |  dest_result_addr=1152921509401106360
            // 0x00E53DB4: STP x29, x30, [sp, #0x20]  | stack[1152921509401106368] = ???;  stack[1152921509401106376] = ???;  //  dest_result_addr=1152921509401106368 |  dest_result_addr=1152921509401106376
            // 0x00E53DB8: ADD x29, sp, #0x20         | X29 = (1152921509401106336 + 32) = 1152921509401106368 (0x100000011DC297C0);
            // 0x00E53DBC: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E53DC0: LDRB w8, [x21, #0xaa4]     | W8 = (bool)static_value_03734AA4;       
            // 0x00E53DC4: MOV x19, x1                | X19 = paramName;//m1                    
            // 0x00E53DC8: MOV x20, x0                | X20 = 1152921509401118384 (0x100000011DC2C6B0);//ML01
            // 0x00E53DCC: TBNZ w8, #0, #0xe53de8     | if (static_value_03734AA4 == true) goto label_0;
            // 0x00E53DD0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00E53DD4: LDR x8, [x8, #0x568]       | X8 = 0x2B8B174;                         
            // 0x00E53DD8: LDR w0, [x8]               | W0 = 0x31B;                             
            // 0x00E53DDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x31B, ????);      
            // 0x00E53DE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E53DE4: STRB w8, [x21, #0xaa4]     | static_value_03734AA4 = true;            //  dest_result_addr=57887396
            label_0:
            // 0x00E53DE8: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00E53DEC: LDR x8, [x8, #0xbc8]       | X8 = (string**)(1152921509401094272)("Argument null or empty");
            // 0x00E53DF0: MOV x0, x20                | X0 = 1152921509401118384 (0x100000011DC2C6B0);//ML01
            // 0x00E53DF4: MOV x2, x19                | X2 = paramName;//m1                     
            // 0x00E53DF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E53DFC: LDR x1, [x8]               | X1 = "Argument null or empty";          
            // 0x00E53E00: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E53E04: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E53E08: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E53E0C: B #0x18b3ee4               | this..ctor(message:  "Argument null or empty", paramName:  paramName); return;
            return;
        
        }
    
    }

}
