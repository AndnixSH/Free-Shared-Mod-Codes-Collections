using UnityEngine;
public class BloomEffect : PostEffectBase
{
    // Fields
    public int downSample; //  0x00000018
    public int samplerScale; //  0x0000001C
    public UnityEngine.Color colorThreshold; //  0x00000020
    public UnityEngine.Color bloomColor; //  0x00000030
    [UnityEngine.RangeAttribute] // 0x287BEA8
    public float bloomFactor; //  0x00000040
    public UnityEngine.Vector2 blurCenter; //  0x00000044
    [UnityEngine.RangeAttribute] // 0x287BEC0
    public float lerp; //  0x0000004C
    public UnityEngine.Shader curShader; //  0x00000050
    private UnityEngine.Material _Material; //  0x00000058
    
    // Properties
    public UnityEngine.Material material { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B91C48 (12131400), len: 144  VirtAddr: 0x00B91C48 RVA: 0x00B91C48 token: 100696331 methodIndex: 25165 delegateWrapperIndex: 0 methodInvoker: 0
    public BloomEffect()
    {
        //
        // Disasemble & Code
        // 0x00B91C48: STP x20, x19, [sp, #-0x20]! | stack[1152921515515943344] = ???;  stack[1152921515515943352] = ???;  //  dest_result_addr=1152921515515943344 |  dest_result_addr=1152921515515943352
        // 0x00B91C4C: STP x29, x30, [sp, #0x10]  | stack[1152921515515943360] = ???;  stack[1152921515515943368] = ???;  //  dest_result_addr=1152921515515943360 |  dest_result_addr=1152921515515943368
        // 0x00B91C50: ADD x29, sp, #0x10         | X29 = (1152921515515943344 + 16) = 1152921515515943360 (0x100000028A3B99C0);
        // 0x00B91C54: SUB sp, sp, #0x10          | SP = (1152921515515943344 - 16) = 1152921515515943328 (0x100000028A3B99A0);
        // 0x00B91C58: MOV x19, x0                | X19 = 1152921515515955376 (0x100000028A3BC8B0);//ML01
        // 0x00B91C5C: ORR x8, xzr, #0x100000001  | X8 = 4294967297(0x100000001);           
        // 0x00B91C60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91C64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91C68: STR x8, [x19, #0x18]       | this.downSample = 1; this.samplerScale = 1;  //  dest_result_addr=1152921515515955400 dest_result_addr=1152921515515955404
        this.downSample = 4294967297;
        this.samplerScale = 1;
        // 0x00B91C6C: BL #0x20d3c50              | X0 = UnityEngine.Color.get_gray();      
        UnityEngine.Color val_1 = UnityEngine.Color.gray;
        // 0x00B91C70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91C74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91C78: STP s0, s1, [x19, #0x20]   | this.colorThreshold = val_1;  mem[1152921515515955412] = val_1.g;  //  dest_result_addr=1152921515515955408 |  dest_result_addr=1152921515515955412
        this.colorThreshold = val_1;
        mem[1152921515515955412] = val_1.g;
        // 0x00B91C7C: STP s2, s3, [x19, #0x28]   | mem[1152921515515955416] = val_1.b;  mem[1152921515515955420] = val_1.a;  //  dest_result_addr=1152921515515955416 |  dest_result_addr=1152921515515955420
        mem[1152921515515955416] = val_1.b;
        mem[1152921515515955420] = val_1.a;
        // 0x00B91C80: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
        UnityEngine.Color val_2 = UnityEngine.Color.white;
        // 0x00B91C84: STP s0, s1, [x19, #0x30]   | this.bloomColor = val_2;  mem[1152921515515955428] = val_2.g;  //  dest_result_addr=1152921515515955424 |  dest_result_addr=1152921515515955428
        this.bloomColor = val_2;
        mem[1152921515515955428] = val_2.g;
        // 0x00B91C88: FMOV s0, #0.50000000       | S0 = 0.5;                               
        // 0x00B91C8C: ORR w20, wzr, #0x3f000000  | W20 = 1056964608(0x3F000000);           
        // 0x00B91C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91C94: ADD x0, sp, #8             | X0 = (1152921515515943328 + 8) = 1152921515515943336 (0x100000028A3B99A8);
        // 0x00B91C98: MOV v1.16b, v0.16b         | V1 = 0.5;//m1                           
        // 0x00B91C9C: STP s2, s3, [x19, #0x38]   | mem[1152921515515955432] = val_2.b;  mem[1152921515515955436] = val_2.a;  //  dest_result_addr=1152921515515955432 |  dest_result_addr=1152921515515955436
        mem[1152921515515955432] = val_2.b;
        mem[1152921515515955436] = val_2.a;
        // 0x00B91CA0: STR w20, [x19, #0x40]      | this.bloomFactor = 0.5;                  //  dest_result_addr=1152921515515955440
        this.bloomFactor = 0.5f;
        // 0x00B91CA4: STR xzr, [sp, #8]          | stack[1152921515515943336] = 0x0;        //  dest_result_addr=1152921515515943336
        // 0x00B91CA8: BL #0x2697148              | null..ctor(_x:  0.5f, _y:  0.5f);       
        Geometric.Point val_3 = new Geometric.Point(_x:  0.5f, _y:  0.5f);
        // 0x00B91CAC: LDR x8, [sp, #8]           | X8 = val_3.x;                           
        // 0x00B91CB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91CB4: MOV x0, x19                | X0 = 1152921515515955376 (0x100000028A3BC8B0);//ML01
        // 0x00B91CB8: STR w20, [x19, #0x4c]      | this.lerp = 0.5;                         //  dest_result_addr=1152921515515955452
        this.lerp = 0.5f;
        // 0x00B91CBC: LSR x9, x8, #0x20          | X9 = (val_3.x >> 32);                   
        float val_4 = val_3.x >> 32;
        // 0x00B91CC0: STP w8, w9, [x19, #0x44]   | this.blurCenter = val_3.x;  mem[1152921515515955448] = (val_3.x >> 32);  //  dest_result_addr=1152921515515955444 |  dest_result_addr=1152921515515955448
        this.blurCenter = val_3.x;
        mem[1152921515515955448] = val_4;
        // 0x00B91CC4: BL #0xc73454               | this..ctor();                           
        // 0x00B91CC8: SUB sp, x29, #0x10         | SP = (1152921515515943360 - 16) = 1152921515515943344 (0x100000028A3B99B0);
        // 0x00B91CCC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91CD0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B91CD4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B91CD8 (12131544), len: 44  VirtAddr: 0x00B91CD8 RVA: 0x00B91CD8 token: 100696332 methodIndex: 25166 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Material get_material()
    {
        //
        // Disasemble & Code
        // 0x00B91CD8: STP x20, x19, [sp, #-0x20]! | stack[1152921515516067632] = ???;  stack[1152921515516067640] = ???;  //  dest_result_addr=1152921515516067632 |  dest_result_addr=1152921515516067640
        // 0x00B91CDC: STP x29, x30, [sp, #0x10]  | stack[1152921515516067648] = ???;  stack[1152921515516067656] = ???;  //  dest_result_addr=1152921515516067648 |  dest_result_addr=1152921515516067656
        // 0x00B91CE0: ADD x29, sp, #0x10         | X29 = (1152921515516067632 + 16) = 1152921515516067648 (0x100000028A3D7F40);
        // 0x00B91CE4: MOV x19, x0                | X19 = 1152921515516079664 (0x100000028A3DAE30);//ML01
        // 0x00B91CE8: LDP x1, x2, [x19, #0x50]   | X1 = this.curShader; //P2  X2 = this._Material; //P2  //  | 
        // 0x00B91CEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B91CF0: BL #0xc73484               | X0 = this.CheckShaderAndCreateMaterial(shader:  this.curShader, material:  this._Material);
        UnityEngine.Material val_1 = this.CheckShaderAndCreateMaterial(shader:  this.curShader, material:  this._Material);
        // 0x00B91CF4: STR x0, [x19, #0x58]       | this._Material = val_1;                  //  dest_result_addr=1152921515516079752
        this._Material = val_1;
        // 0x00B91CF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91CFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B91D00: RET                        |  return (UnityEngine.Material)val_1;    
        return val_1;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B91D04 (12131588), len: 1224  VirtAddr: 0x00B91D04 RVA: 0x00B91D04 token: 100696333 methodIndex: 25167 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        // 0x00B91D04: STP d11, d10, [sp, #-0x70]! | stack[1152921515516278528] = ???;  stack[1152921515516278536] = ???;  //  dest_result_addr=1152921515516278528 |  dest_result_addr=1152921515516278536
        // 0x00B91D08: STP d9, d8, [sp, #0x10]    | stack[1152921515516278544] = ???;  stack[1152921515516278552] = ???;  //  dest_result_addr=1152921515516278544 |  dest_result_addr=1152921515516278552
        // 0x00B91D0C: STP x26, x25, [sp, #0x20]  | stack[1152921515516278560] = ???;  stack[1152921515516278568] = ???;  //  dest_result_addr=1152921515516278560 |  dest_result_addr=1152921515516278568
        // 0x00B91D10: STP x24, x23, [sp, #0x30]  | stack[1152921515516278576] = ???;  stack[1152921515516278584] = ???;  //  dest_result_addr=1152921515516278576 |  dest_result_addr=1152921515516278584
        // 0x00B91D14: STP x22, x21, [sp, #0x40]  | stack[1152921515516278592] = ???;  stack[1152921515516278600] = ???;  //  dest_result_addr=1152921515516278592 |  dest_result_addr=1152921515516278600
        // 0x00B91D18: STP x20, x19, [sp, #0x50]  | stack[1152921515516278608] = ???;  stack[1152921515516278616] = ???;  //  dest_result_addr=1152921515516278608 |  dest_result_addr=1152921515516278616
        // 0x00B91D1C: STP x29, x30, [sp, #0x60]  | stack[1152921515516278624] = ???;  stack[1152921515516278632] = ???;  //  dest_result_addr=1152921515516278624 |  dest_result_addr=1152921515516278632
        // 0x00B91D20: ADD x29, sp, #0x60         | X29 = (1152921515516278528 + 96) = 1152921515516278624 (0x100000028A40B760);
        // 0x00B91D24: SUB sp, sp, #0x20          | SP = (1152921515516278528 - 32) = 1152921515516278496 (0x100000028A40B6E0);
        // 0x00B91D28: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B91D2C: LDRB w8, [x22, #0xa45]     | W8 = (bool)static_value_03733A45;       
        // 0x00B91D30: MOV x19, x2                | X19 = destination;//m1                  
        // 0x00B91D34: MOV x20, x1                | X20 = source;//m1                       
        // 0x00B91D38: MOV x21, x0                | X21 = 1152921515516290640 (0x100000028A40E650);//ML01
        // 0x00B91D3C: TBNZ w8, #0, #0xb91d58     | if (static_value_03733A45 == true) goto label_0;
        // 0x00B91D40: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B91D44: LDR x8, [x8, #0xad8]       | X8 = 0x2B8F6C8;                         
        // 0x00B91D48: LDR w0, [x8]               | W0 = 0x1476;                            
        // 0x00B91D4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1476, ????);     
        // 0x00B91D50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B91D54: STRB w8, [x22, #0xa45]     | static_value_03733A45 = true;            //  dest_result_addr=57883205
        label_0:
        // 0x00B91D58: LDP x1, x2, [x21, #0x50]   | X1 = this.curShader; //P2  X2 = this._Material; //P2  //  | 
        // 0x00B91D5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B91D60: MOV x0, x21                | X0 = 1152921515516290640 (0x100000028A40E650);//ML01
        // 0x00B91D64: BL #0xc73484               | X0 = this.CheckShaderAndCreateMaterial(shader:  this.curShader, material:  this._Material);
        UnityEngine.Material val_1 = this.CheckShaderAndCreateMaterial(shader:  this.curShader, material:  this._Material);
        // 0x00B91D68: MOV x22, x0                | X22 = val_1;//m1                        
        // 0x00B91D6C: STR x22, [x21, #0x58]      | this._Material = val_1;                  //  dest_result_addr=1152921515516290728
        this._Material = val_1;
        // 0x00B91D70: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B91D74: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B91D78: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B91D7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B91D80: TBZ w8, #0, #0xb91d90      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B91D84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B91D88: CBNZ w8, #0xb91d90         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B91D8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B91D90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91D94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91D98: MOV x1, x22                | X1 = val_1;//m1                         
        // 0x00B91D9C: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_2 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x00B91DA0: TBZ w0, #0, #0xb921a8      | if (val_2 == false) goto label_3;       
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B91DA4: CBNZ x20, #0xb91dac        | if (source != null) goto label_4;       
        if(source != null)
        {
            goto label_4;
        }
        // 0x00B91DA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B91DAC: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x00B91DB0: MOV x0, x20                | X0 = source;//m1                        
        // 0x00B91DB4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x00B91DB8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x00B91DBC: LDR w24, [x21, #0x18]      | W24 = this.downSample; //P2             
        // 0x00B91DC0: MOV w22, w0                | W22 = source;//m1                       
        // 0x00B91DC4: CBNZ x20, #0xb91dcc        | if (source != null) goto label_5;       
        if(source != null)
        {
            goto label_5;
        }
        // 0x00B91DC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_5:
        // 0x00B91DCC: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x00B91DD0: MOV x0, x20                | X0 = source;//m1                        
        // 0x00B91DD4: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x00B91DD8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x00B91DDC: LDR w25, [x21, #0x18]      | W25 = this.downSample; //P2             
        // 0x00B91DE0: MOV w23, w0                | W23 = source;//m1                       
        // 0x00B91DE4: CBNZ x20, #0xb91dec        | if (source != null) goto label_6;       
        if(source != null)
        {
            goto label_6;
        }
        // 0x00B91DE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_6:
        // 0x00B91DEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91DF0: MOV x0, x20                | X0 = source;//m1                        
        // 0x00B91DF4: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_3 = source.format;
        // 0x00B91DF8: AND w8, w24, #0x1f         | W8 = (this.downSample & 31);            
        int val_4 = this.downSample & 31;
        // 0x00B91DFC: AND w9, w25, #0x1f         | W9 = (this.downSample & 31);            
        int val_5 = this.downSample & 31;
        // 0x00B91E00: MOV w4, w0                 | W4 = val_3;//m1                         
        // 0x00B91E04: ASR w1, w22, w8            | W1 = (source >> (this.downSample & 31));
        UnityEngine.RenderTexture val_6 = source >> val_4;
        // 0x00B91E08: ASR w2, w23, w9            | W2 = (source >> (this.downSample & 31));
        UnityEngine.RenderTexture val_7 = source >> val_5;
        // 0x00B91E0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91E10: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B91E14: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B91E18: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  UnityEngine.RenderTexture val_6 = source >> val_4, depthBuffer:  UnityEngine.RenderTexture val_7 = source >> val_5, format:  0);
        UnityEngine.RenderTexture val_8 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_6, depthBuffer:  val_7, format:  0);
        // 0x00B91E1C: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00B91E20: CBNZ x20, #0xb91e28        | if (source != null) goto label_7;       
        if(source != null)
        {
            goto label_7;
        }
        // 0x00B91E24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_7:
        // 0x00B91E28: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x00B91E2C: MOV x0, x20                | X0 = source;//m1                        
        // 0x00B91E30: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x00B91E34: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x00B91E38: LDR w25, [x21, #0x18]      | W25 = this.downSample; //P2             
        // 0x00B91E3C: MOV w23, w0                | W23 = source;//m1                       
        // 0x00B91E40: CBNZ x20, #0xb91e48        | if (source != null) goto label_8;       
        if(source != null)
        {
            goto label_8;
        }
        // 0x00B91E44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_8:
        // 0x00B91E48: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x00B91E4C: MOV x0, x20                | X0 = source;//m1                        
        // 0x00B91E50: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x00B91E54: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x00B91E58: LDR w26, [x21, #0x18]      | W26 = this.downSample; //P2             
        // 0x00B91E5C: MOV w24, w0                | W24 = source;//m1                       
        // 0x00B91E60: CBNZ x20, #0xb91e68        | if (source != null) goto label_9;       
        if(source != null)
        {
            goto label_9;
        }
        // 0x00B91E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_9:
        // 0x00B91E68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91E6C: MOV x0, x20                | X0 = source;//m1                        
        // 0x00B91E70: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_9 = source.format;
        // 0x00B91E74: AND w8, w25, #0x1f         | W8 = (this.downSample & 31);            
        int val_10 = this.downSample & 31;
        // 0x00B91E78: AND w9, w26, #0x1f         | W9 = (this.downSample & 31);            
        int val_11 = this.downSample & 31;
        // 0x00B91E7C: MOV w4, w0                 | W4 = val_9;//m1                         
        // 0x00B91E80: ASR w1, w23, w8            | W1 = (source >> (this.downSample & 31));
        UnityEngine.RenderTexture val_12 = source >> val_10;
        // 0x00B91E84: ASR w2, w24, w9            | W2 = (source >> (this.downSample & 31));
        UnityEngine.RenderTexture val_13 = source >> val_11;
        // 0x00B91E88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91E8C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B91E90: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B91E94: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  UnityEngine.RenderTexture val_12 = source >> val_10, depthBuffer:  UnityEngine.RenderTexture val_13 = source >> val_11, format:  0);
        UnityEngine.RenderTexture val_14 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_12, depthBuffer:  val_13, format:  0);
        // 0x00B91E98: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B91E9C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x00B91EA0: MOV x23, x0                | X23 = val_14;//m1                       
        // 0x00B91EA4: LDR x8, [x8]               | X8 = typeof(UnityEngine.Graphics);      
        // 0x00B91EA8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x00B91EAC: TBZ w9, #0, #0xb91ec0      | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B91EB0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x00B91EB4: CBNZ w9, #0xb91ec0         | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B91EB8: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x00B91EBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_11:
        // 0x00B91EC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91EC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B91EC8: MOV x1, x20                | X1 = source;//m1                        
        // 0x00B91ECC: MOV x2, x22                | X2 = val_8;//m1                         
        // 0x00B91ED0: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  source);
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        // 0x00B91ED4: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B91ED8: LDP s0, s1, [x21, #0x20]   | S0 = this.colorThreshold; //P2           //  | 
        // 0x00B91EDC: LDP s2, s3, [x21, #0x28]   |                                          //  | 
        // 0x00B91EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91EE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91EE8: BL #0x20d37bc              | X0 = UnityEngine.Color.op_Implicit(c:  new UnityEngine.Color() {r = this.colorThreshold});
        UnityEngine.Vector4 val_15 = UnityEngine.Color.op_Implicit(c:  new UnityEngine.Color() {r = this.colorThreshold});
        // 0x00B91EEC: MOV v8.16b, v0.16b         | V8 = val_15.x;//m1                      
        // 0x00B91EF0: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
        // 0x00B91EF4: MOV v10.16b, v2.16b        | V10 = val_15.z;//m1                     
        // 0x00B91EF8: MOV v11.16b, v3.16b        | V11 = val_15.w;//m1                     
        // 0x00B91EFC: CBNZ x24, #0xb91f04        | if (this._Material != null) goto label_12;
        if(this._Material != null)
        {
            goto label_12;
        }
        // 0x00B91F00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_12:
        // 0x00B91F04: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B91F08: LDR x8, [x8, #0x170]       | X8 = (string**)(1152921515516220912)("_colorThreshold");
        // 0x00B91F0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91F10: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B91F14: MOV v0.16b, v8.16b         | V0 = val_15.x;//m1                      
        // 0x00B91F18: LDR x1, [x8]               | X1 = "_colorThreshold";                 
        // 0x00B91F1C: MOV v1.16b, v9.16b         | V1 = val_15.y;//m1                      
        // 0x00B91F20: MOV v2.16b, v10.16b        | V2 = val_15.z;//m1                      
        // 0x00B91F24: MOV v3.16b, v11.16b        | V3 = val_15.w;//m1                      
        // 0x00B91F28: BL #0x1a79fa8              | this._Material.SetVector(name:  "_colorThreshold", value:  new UnityEngine.Vector4() {x = val_15.x, y = val_15.y, z = val_15.z, w = val_15.w});
        this._Material.SetVector(name:  "_colorThreshold", value:  new UnityEngine.Vector4() {x = val_15.x, y = val_15.y, z = val_15.z, w = val_15.w});
        // 0x00B91F2C: LDR x3, [x21, #0x58]       | X3 = this._Material; //P2               
        // 0x00B91F30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91F34: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x00B91F38: MOV x1, x22                | X1 = val_8;//m1                         
        // 0x00B91F3C: MOV x2, x23                | X2 = val_14;//m1                        
        // 0x00B91F40: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B91F44: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_8, mat:  val_14, pass:  this._Material);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_8, mat:  val_14, pass:  this._Material);
        // 0x00B91F48: LDR s0, [x21, #0x1c]       | S0 = this.samplerScale; //P2            
        // 0x00B91F4C: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B91F50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91F54: ADD x0, sp, #0x10          | X0 = (1152921515516278496 + 16) = 1152921515516278512 (0x100000028A40B6F0);
        // 0x00B91F58: SCVTF s1, s0               | S1 = (float)(this.samplerScale);        
        // 0x00B91F5C: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B91F60: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x00B91F64: MOV v3.16b, v0.16b         | V3 = 0;//m1                             
        // 0x00B91F68: STP xzr, xzr, [sp, #0x10]  | stack[1152921515516278512] = 0x0;  stack[1152921515516278520] = 0x0;  //  dest_result_addr=1152921515516278512 |  dest_result_addr=1152921515516278520
        // 0x00B91F6C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x00B91F70: CBNZ x24, #0xb91f78        | if (this._Material != null) goto label_13;
        if(this._Material != null)
        {
            goto label_13;
        }
        // 0x00B91F74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000028A40B6F0, ????);
        label_13:
        // 0x00B91F78: ADRP x25, #0x35fd000       | X25 = 56610816 (0x35FD000);             
        // 0x00B91F7C: LDR x25, [x25, #0x4c0]     | X25 = (string**)(1152921515516229216)("_offsets");
        // 0x00B91F80: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B91F84: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x00B91F88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91F8C: LDR x1, [x25]              | X1 = "_offsets";                        
        // 0x00B91F90: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B91F94: BL #0x1a79fa8              | this._Material.SetVector(name:  "_offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this._Material.SetVector(name:  "_offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x00B91F98: LDR x3, [x21, #0x58]       | X3 = this._Material; //P2               
        // 0x00B91F9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91FA0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B91FA4: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x00B91FA8: MOV x1, x23                | X1 = val_14;//m1                        
        // 0x00B91FAC: MOV x2, x22                | X2 = val_8;//m1                         
        // 0x00B91FB0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_14, mat:  val_8, pass:  this._Material);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_14, mat:  val_8, pass:  this._Material);
        // 0x00B91FB4: LDR s0, [x21, #0x1c]       | S0 = this.samplerScale; //P2            
        // 0x00B91FB8: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B91FBC: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B91FC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91FC4: SCVTF s0, s0               | S0 = (float)(this.samplerScale);        
        // 0x00B91FC8: MOV x0, sp                 | X0 = 1152921515516278496 (0x100000028A40B6E0);//ML01
        // 0x00B91FCC: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
        // 0x00B91FD0: MOV v3.16b, v1.16b         | V3 = 0;//m1                             
        // 0x00B91FD4: STP xzr, xzr, [sp]         | stack[1152921515516278496] = 0x0;  stack[1152921515516278504] = 0x0;  //  dest_result_addr=1152921515516278496 |  dest_result_addr=1152921515516278504
        // 0x00B91FD8: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x00B91FDC: CBNZ x24, #0xb91fe4        | if (this._Material != null) goto label_14;
        if(this._Material != null)
        {
            goto label_14;
        }
        // 0x00B91FE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000028A40B6E0, ????);
        label_14:
        // 0x00B91FE4: LDR x1, [x25]              | X1 = "_offsets";                        
        // 0x00B91FE8: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x00B91FEC: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x00B91FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91FF4: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B91FF8: BL #0x1a79fa8              | this._Material.SetVector(name:  "_offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this._Material.SetVector(name:  "_offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x00B91FFC: LDR x3, [x21, #0x58]       | X3 = this._Material; //P2               
        // 0x00B92000: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92004: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B92008: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x00B9200C: MOV x1, x22                | X1 = val_8;//m1                         
        // 0x00B92010: MOV x2, x23                | X2 = val_14;//m1                        
        // 0x00B92014: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_8, mat:  val_14, pass:  this._Material);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_8, mat:  val_14, pass:  this._Material);
        // 0x00B92018: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B9201C: CBNZ x24, #0xb92024        | if (this._Material != null) goto label_15;
        if(this._Material != null)
        {
            goto label_15;
        }
        // 0x00B92020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_15:
        // 0x00B92024: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B92028: LDR x8, [x8, #0x1e8]       | X8 = (string**)(1152921515516245696)("_BlurTex");
        // 0x00B9202C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B92030: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B92034: MOV x2, x23                | X2 = val_14;//m1                        
        // 0x00B92038: LDR x1, [x8]               | X1 = "_BlurTex";                        
        // 0x00B9203C: BL #0x1a780c4              | this._Material.SetTexture(name:  "_BlurTex", value:  val_14);
        this._Material.SetTexture(name:  "_BlurTex", value:  val_14);
        // 0x00B92040: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B92044: LDP s0, s1, [x21, #0x30]   | S0 = this.bloomColor; //P2               //  | 
        // 0x00B92048: LDP s2, s3, [x21, #0x38]   |                                          //  | 
        // 0x00B9204C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92054: BL #0x20d37bc              | X0 = UnityEngine.Color.op_Implicit(c:  new UnityEngine.Color() {r = this.bloomColor, g = 0f, b = 0f, a = 0f});
        UnityEngine.Vector4 val_16 = UnityEngine.Color.op_Implicit(c:  new UnityEngine.Color() {r = this.bloomColor, g = 0f, b = 0f, a = 0f});
        // 0x00B92058: MOV v8.16b, v0.16b         | V8 = val_16.x;//m1                      
        // 0x00B9205C: MOV v9.16b, v1.16b         | V9 = val_16.y;//m1                      
        // 0x00B92060: MOV v10.16b, v2.16b        | V10 = val_16.z;//m1                     
        // 0x00B92064: MOV v11.16b, v3.16b        | V11 = val_16.w;//m1                     
        // 0x00B92068: CBNZ x24, #0xb92070        | if (this._Material != null) goto label_16;
        if(this._Material != null)
        {
            goto label_16;
        }
        // 0x00B9206C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_16:
        // 0x00B92070: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00B92074: LDR x8, [x8, #0xaa0]       | X8 = (string**)(1152921515516249888)("_bloomColor");
        // 0x00B92078: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9207C: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B92080: MOV v0.16b, v8.16b         | V0 = val_16.x;//m1                      
        // 0x00B92084: LDR x1, [x8]               | X1 = "_bloomColor";                     
        // 0x00B92088: MOV v1.16b, v9.16b         | V1 = val_16.y;//m1                      
        // 0x00B9208C: MOV v2.16b, v10.16b        | V2 = val_16.z;//m1                      
        // 0x00B92090: MOV v3.16b, v11.16b        | V3 = val_16.w;//m1                      
        // 0x00B92094: BL #0x1a79fa8              | this._Material.SetVector(name:  "_bloomColor", value:  new UnityEngine.Vector4() {x = val_16.x, y = val_16.y, z = val_16.z, w = val_16.w});
        this._Material.SetVector(name:  "_bloomColor", value:  new UnityEngine.Vector4() {x = val_16.x, y = val_16.y, z = val_16.z, w = val_16.w});
        // 0x00B92098: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B9209C: LDR s8, [x21, #0x40]       | S8 = this.bloomFactor; //P2             
        // 0x00B920A0: CBNZ x24, #0xb920a8        | if (this._Material != null) goto label_17;
        if(this._Material != null)
        {
            goto label_17;
        }
        // 0x00B920A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._Material, ????);
        label_17:
        // 0x00B920A8: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00B920AC: LDR x8, [x8, #0x38]        | X8 = (string**)(1152921515516254080)("_bloomFactor");
        // 0x00B920B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B920B4: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B920B8: MOV v0.16b, v8.16b         | V0 = this.bloomFactor;//m1              
        // 0x00B920BC: LDR x1, [x8]               | X1 = "_bloomFactor";                    
        // 0x00B920C0: BL #0x1a79ef8              | this._Material.SetFloat(name:  "_bloomFactor", value:  this.bloomFactor);
        this._Material.SetFloat(name:  "_bloomFactor", value:  this.bloomFactor);
        // 0x00B920C4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B920C8: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x00B920CC: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B920D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x00B920D4: LDP s9, s8, [x21, #0x44]   | S9 = this.blurCenter; //P2               //  | 
        // 0x00B920D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x00B920DC: TBZ w8, #0, #0xb920ec      | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B920E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x00B920E4: CBNZ w8, #0xb920ec         | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B920E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_19:
        // 0x00B920EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B920F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B920F4: MOV v0.16b, v9.16b         | V0 = this.blurCenter;//m1               
        // 0x00B920F8: MOV v1.16b, v8.16b         | V1 = this.bloomFactor;//m1              
        // 0x00B920FC: BL #0x269c4a4              | X0 = UnityEngine.Vector4.op_Implicit(v:  new UnityEngine.Vector2() {x = this.blurCenter, y = this.bloomFactor});
        UnityEngine.Vector4 val_17 = UnityEngine.Vector4.op_Implicit(v:  new UnityEngine.Vector2() {x = this.blurCenter, y = this.bloomFactor});
        // 0x00B92100: MOV v8.16b, v0.16b         | V8 = val_17.x;//m1                      
        // 0x00B92104: MOV v9.16b, v1.16b         | V9 = val_17.y;//m1                      
        // 0x00B92108: MOV v10.16b, v2.16b        | V10 = val_17.z;//m1                     
        // 0x00B9210C: MOV v11.16b, v3.16b        | V11 = val_17.w;//m1                     
        // 0x00B92110: CBNZ x24, #0xb92118        | if (this._Material != null) goto label_20;
        if(this._Material != null)
        {
            goto label_20;
        }
        // 0x00B92114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_20:
        // 0x00B92118: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B9211C: LDR x8, [x8, #0xe98]       | X8 = (string**)(1152921515516258272)("_blurCenter");
        // 0x00B92120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92124: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B92128: MOV v0.16b, v8.16b         | V0 = val_17.x;//m1                      
        // 0x00B9212C: LDR x1, [x8]               | X1 = "_blurCenter";                     
        // 0x00B92130: MOV v1.16b, v9.16b         | V1 = val_17.y;//m1                      
        // 0x00B92134: MOV v2.16b, v10.16b        | V2 = val_17.z;//m1                      
        // 0x00B92138: MOV v3.16b, v11.16b        | V3 = val_17.w;//m1                      
        // 0x00B9213C: BL #0x1a79fa8              | this._Material.SetVector(name:  "_blurCenter", value:  new UnityEngine.Vector4() {x = val_17.x, y = val_17.y, z = val_17.z, w = val_17.w});
        this._Material.SetVector(name:  "_blurCenter", value:  new UnityEngine.Vector4() {x = val_17.x, y = val_17.y, z = val_17.z, w = val_17.w});
        // 0x00B92140: LDR x24, [x21, #0x58]      | X24 = this._Material; //P2              
        // 0x00B92144: LDR s8, [x21, #0x4c]       | S8 = this.lerp; //P2                    
        // 0x00B92148: CBNZ x24, #0xb92150        | if (this._Material != null) goto label_21;
        if(this._Material != null)
        {
            goto label_21;
        }
        // 0x00B9214C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._Material, ????);
        label_21:
        // 0x00B92150: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B92154: LDR x8, [x8, #0xc58]       | X8 = (string**)(1152921515516262464)("_lerp");
        // 0x00B92158: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9215C: MOV x0, x24                | X0 = this._Material;//m1                
        // 0x00B92160: MOV v0.16b, v8.16b         | V0 = this.lerp;//m1                     
        // 0x00B92164: LDR x1, [x8]               | X1 = "_lerp";                           
        // 0x00B92168: BL #0x1a79ef8              | this._Material.SetFloat(name:  "_lerp", value:  this.lerp);
        this._Material.SetFloat(name:  "_lerp", value:  this.lerp);
        // 0x00B9216C: LDR x3, [x21, #0x58]       | X3 = this._Material; //P2               
        // 0x00B92170: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92174: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B92178: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x00B9217C: MOV x1, x20                | X1 = source;//m1                        
        // 0x00B92180: MOV x2, x19                | X2 = destination;//m1                   
        // 0x00B92184: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination, pass:  this._Material);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination, pass:  this._Material);
        // 0x00B92188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9218C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92190: MOV x1, x22                | X1 = val_8;//m1                         
        // 0x00B92194: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x00B92198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9219C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B921A0: MOV x1, x23                | X1 = val_14;//m1                        
        // 0x00B921A4: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        label_3:
        // 0x00B921A8: SUB sp, x29, #0x60         | SP = (1152921515516278624 - 96) = 1152921515516278528 (0x100000028A40B700);
        // 0x00B921AC: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B921B0: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B921B4: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B921B8: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B921BC: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B921C0: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B921C4: LDP d11, d10, [sp], #0x70  | D11 = ; D10 = ;                          //  | 
        // 0x00B921C8: RET                        |  return;                                
        return;
    
    }

}
