using UnityEngine;

namespace Mihua.Asset
{
    public class AssetMgr : MonoBehaviour
    {
        // Fields
        public static float maxTime; // static_offset: 0x00000000
        private static Mihua.Asset.AssetMgr.LogMode m_LogMode; // static_offset: 0x00000004
        private static string m_BaseDownloadingURL; // static_offset: 0x00000008
        private static string[] m_ActiveVariants; // static_offset: 0x00000010
        private static UnityEngine.AssetBundleManifest m_AssetBundleManifest; // static_offset: 0x00000018
        private static System.Collections.Generic.List<string> keysToRemove; // static_offset: 0x00000020
        private static System.Collections.Generic.Dictionary<string, asset_sharedCfg> m_assetShared; // static_offset: 0x00000028
        private static System.Collections.Generic.List<string> nextNeedAssetList; // static_offset: 0x00000030
        private static System.Collections.Generic.Dictionary<string, UnityEngine.Object> m_LoadedAssets; // static_offset: 0x00000038
        private static System.Collections.Generic.Dictionary<string, Mihua.Asset.LoadedAssetBundle> m_LoadedAssetBundles; // static_offset: 0x00000040
        private static System.Collections.Generic.Dictionary<string, int> m_RefCountDic; // static_offset: 0x00000048
        private static System.Collections.Generic.Dictionary<string, string> m_DownloadingErrors; // static_offset: 0x00000050
        private static System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation> m_InProgressOperations; // static_offset: 0x00000058
        private static System.Collections.Generic.Dictionary<string, string[]> m_Dependencies; // static_offset: 0x00000060
        private static System.Action clearEndCallBack; // static_offset: 0x00000068
        private static bool isWaitClear; // static_offset: 0x00000070
        private static System.Collections.Generic.List<string> ab2AsstsList; // static_offset: 0x00000078
        private static int maxLoadingCount; // static_offset: 0x00000080
        private static System.Collections.Generic.List<string> m_WaitList; // static_offset: 0x00000088
        private static System.Collections.Generic.List<string> m_LoadingList; // static_offset: 0x00000090
        private static System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest> m_WWWList; // static_offset: 0x00000098
        public static bool isClearAll; // static_offset: 0x000000A0
        
        // Properties
        public static System.Collections.Generic.Dictionary<string, UnityEngine.Object> cacheAssets { get; }
        public static Mihua.Asset.AssetMgr.LogMode logMode { get; set; }
        public static string BaseDownloadingURL { get; set; }
        public static string[] ActiveVariants { get; set; }
        public static UnityEngine.AssetBundleManifest AssetBundleManifestObject { set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AB1D60 (11214176), len: 1080  VirtAddr: 0x00AB1D60 RVA: 0x00AB1D60 token: 100693205 methodIndex: 46961 delegateWrapperIndex: 0 methodInvoker: 0
        private static AssetMgr()
        {
            //
            // Disasemble & Code
            //  | 
            var val_16;
            // 0x00AB1D60: STP x22, x21, [sp, #-0x30]! | stack[1152921514952621648] = ???;  stack[1152921514952621656] = ???;  //  dest_result_addr=1152921514952621648 |  dest_result_addr=1152921514952621656
            // 0x00AB1D64: STP x20, x19, [sp, #0x10]  | stack[1152921514952621664] = ???;  stack[1152921514952621672] = ???;  //  dest_result_addr=1152921514952621664 |  dest_result_addr=1152921514952621672
            // 0x00AB1D68: STP x29, x30, [sp, #0x20]  | stack[1152921514952621680] = ???;  stack[1152921514952621688] = ???;  //  dest_result_addr=1152921514952621680 |  dest_result_addr=1152921514952621688
            // 0x00AB1D6C: ADD x29, sp, #0x20         | X29 = (1152921514952621648 + 32) = 1152921514952621680 (0x1000000268A7FE70);
            // 0x00AB1D70: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB1D74: LDRB w8, [x19, #0x3ed]     | W8 = (bool)static_value_037333ED;       
            // 0x00AB1D78: TBNZ w8, #0, #0xab1d94     | if (static_value_037333ED == true) goto label_0;
            // 0x00AB1D7C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x00AB1D80: LDR x8, [x8, #0x168]       | X8 = 0x2B8EB04;                         
            // 0x00AB1D84: LDR w0, [x8]               | W0 = 0x1181;                            
            // 0x00AB1D88: BL #0x2782188              | X0 = sub_2782188( ?? 0x1181, ????);     
            // 0x00AB1D8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB1D90: STRB w8, [x19, #0x3ed]     | static_value_037333ED = true;            //  dest_result_addr=57881581
            label_0:
            // 0x00AB1D94: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB1D98: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB1D9C: MOVZ w9, #0x3c23, lsl #16  | W9 = 1008926720 (0x3C230000);//ML01     
            // 0x00AB1DA0: MOVK w9, #0xd70a           | W9 = 1008981770 (0x3C23D70A);           
            // 0x00AB1DA4: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
            // 0x00AB1DA8: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1DAC: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1DB0: STR w9, [x8]               | Mihua.Asset.AssetMgr.maxTime = 0.01;     //  dest_result_addr=1152921504903335936
            Mihua.Asset.AssetMgr.maxTime = 0.01f;
            // 0x00AB1DB4: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1DB8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1DBC: STR wzr, [x8, #4]          | Mihua.Asset.AssetMgr.m_LogMode = null;   //  dest_result_addr=1152921504903335940
            Mihua.Asset.AssetMgr.m_LogMode = 0;
            // 0x00AB1DC0: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
            // 0x00AB1DC4: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_16 = null;
            // 0x00AB1DC8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB1DCC: TBZ w8, #0, #0xab1de0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB1DD0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB1DD4: CBNZ w8, #0xab1de0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB1DD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00AB1DDC: LDR x0, [x19]              | X0 = typeof(System.String);             
            val_16 = null;
            label_2:
            // 0x00AB1DE0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00AB1DE4: LDR x9, [x20]              | X9 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1DE8: LDR x8, [x8]               | X8 = System.String.Empty;               
            // 0x00AB1DEC: LDR x9, [x9, #0xa0]        | X9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1DF0: STR x8, [x9, #8]           | Mihua.Asset.AssetMgr.m_BaseDownloadingURL = System.String.Empty;  //  dest_result_addr=1152921504903335944
            Mihua.Asset.AssetMgr.m_BaseDownloadingURL = System.String.Empty;
            // 0x00AB1DF4: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00AB1DF8: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1DFC: LDR x9, [x9, #0x2d0]       | X9 = 1152921504948897168;               
            // 0x00AB1E00: LDR x21, [x8, #0xa0]       | X21 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1E04: LDR x19, [x9]              | X19 = typeof(System.String[]);          
            // 0x00AB1E08: MOV x0, x19                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00AB1E0C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00AB1E10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB1E14: MOV x0, x19                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00AB1E18: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00AB1E1C: STR x0, [x21, #0x10]       | Mihua.Asset.AssetMgr.m_ActiveVariants = typeof(System.String[]);  //  dest_result_addr=1152921504903335952
            Mihua.Asset.AssetMgr.m_ActiveVariants = null;
            // 0x00AB1E20: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1E24: ADRP x21, #0x367b000       | X21 = 57126912 (0x367B000);             
            // 0x00AB1E28: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1E2C: STR xzr, [x8, #0x18]       | Mihua.Asset.AssetMgr.m_AssetBundleManifest = null;  //  dest_result_addr=1152921504903335960
            Mihua.Asset.AssetMgr.m_AssetBundleManifest = 0;
            // 0x00AB1E30: LDR x21, [x21, #0xe00]     | X21 = 1152921504616644608;              
            // 0x00AB1E34: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_1 = null;
            // 0x00AB1E38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1E3C: ADRP x22, #0x35e9000       | X22 = 56528896 (0x35E9000);             
            // 0x00AB1E40: LDR x22, [x22, #0xe88]     | X22 = 1152921510893072720;              
            // 0x00AB1E44: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1E48: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB1E4C: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<System.String>();
            // 0x00AB1E50: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1E54: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1E58: STR x19, [x8, #0x20]       | Mihua.Asset.AssetMgr.keysToRemove = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903335968
            Mihua.Asset.AssetMgr.keysToRemove = val_1;
            // 0x00AB1E5C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x00AB1E60: LDR x8, [x8, #0x1d0]       | X8 = 1152921504615792640;               
            // 0x00AB1E64: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, asset_sharedCfg> val_2 = null;
            // 0x00AB1E68: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB1E6C: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00AB1E70: LDR x8, [x8, #0xf88]       | X8 = 1152921514952600368;               
            // 0x00AB1E74: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB1E78: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::.ctor();
            // 0x00AB1E7C: BL #0x23fb0c4              | .ctor();                                
            val_2 = new System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>();
            // 0x00AB1E80: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1E84: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1E88: STR x19, [x8, #0x28]       | Mihua.Asset.AssetMgr.m_assetShared = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903335976
            Mihua.Asset.AssetMgr.m_assetShared = val_2;
            // 0x00AB1E8C: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_3 = null;
            // 0x00AB1E90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1E94: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB1E98: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1E9C: BL #0x25e9474              | .ctor();                                
            val_3 = new System.Collections.Generic.List<System.String>();
            // 0x00AB1EA0: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1EA4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1EA8: STR x19, [x8, #0x30]       | Mihua.Asset.AssetMgr.nextNeedAssetList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903335984
            Mihua.Asset.AssetMgr.nextNeedAssetList = val_3;
            // 0x00AB1EAC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00AB1EB0: LDR x8, [x8, #0x8b8]       | X8 = 1152921504615792640;               
            // 0x00AB1EB4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, UnityEngine.Object> val_4 = null;
            // 0x00AB1EB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB1EBC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00AB1EC0: LDR x8, [x8, #0x7f0]       | X8 = 1152921514952601392;               
            // 0x00AB1EC4: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB1EC8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::.ctor();
            // 0x00AB1ECC: BL #0x23fb0c4              | .ctor();                                
            val_4 = new System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>();
            // 0x00AB1ED0: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1ED4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1ED8: STR x19, [x8, #0x38]       | Mihua.Asset.AssetMgr.m_LoadedAssets = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903335992
            Mihua.Asset.AssetMgr.m_LoadedAssets = val_4;
            // 0x00AB1EDC: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00AB1EE0: LDR x8, [x8, #0xfb8]       | X8 = 1152921504615792640;               
            // 0x00AB1EE4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle> val_5 = null;
            // 0x00AB1EE8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB1EEC: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AB1EF0: LDR x8, [x8, #0xa00]       | X8 = 1152921514952602416;               
            // 0x00AB1EF4: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB1EF8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::.ctor();
            // 0x00AB1EFC: BL #0x23fb0c4              | .ctor();                                
            val_5 = new System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>();
            // 0x00AB1F00: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1F04: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1F08: STR x19, [x8, #0x40]       | Mihua.Asset.AssetMgr.m_LoadedAssetBundles = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903336000
            Mihua.Asset.AssetMgr.m_LoadedAssetBundles = val_5;
            // 0x00AB1F0C: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00AB1F10: LDR x8, [x8, #0x610]       | X8 = 1152921504615792640;               
            // 0x00AB1F14: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Int32> val_6 = null;
            // 0x00AB1F18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB1F1C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB1F20: LDR x8, [x8, #0x6d8]       | X8 = 1152921510000487872;               
            // 0x00AB1F24: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB1F28: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::.ctor();
            // 0x00AB1F2C: BL #0x23f2edc              | .ctor();                                
            val_6 = new System.Collections.Generic.Dictionary<System.String, System.Int32>();
            // 0x00AB1F30: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1F34: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1F38: STR x19, [x8, #0x48]       | Mihua.Asset.AssetMgr.m_RefCountDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903336008
            Mihua.Asset.AssetMgr.m_RefCountDic = val_6;
            // 0x00AB1F3C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00AB1F40: LDR x8, [x8, #0xf18]       | X8 = 1152921504615792640;               
            // 0x00AB1F44: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.String> val_7 = null;
            // 0x00AB1F48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB1F4C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00AB1F50: LDR x8, [x8, #0x9f8]       | X8 = 1152921509931587600;               
            // 0x00AB1F54: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB1F58: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::.ctor();
            // 0x00AB1F5C: BL #0x23fb0c4              | .ctor();                                
            val_7 = new System.Collections.Generic.Dictionary<System.String, System.String>();
            // 0x00AB1F60: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1F64: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1F68: STR x19, [x8, #0x50]       | Mihua.Asset.AssetMgr.m_DownloadingErrors = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903336016
            Mihua.Asset.AssetMgr.m_DownloadingErrors = val_7;
            // 0x00AB1F6C: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AB1F70: LDR x8, [x8, #0xca8]       | X8 = 1152921504616644608;               
            // 0x00AB1F74: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation> val_8 = null;
            // 0x00AB1F78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1F7C: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AB1F80: LDR x8, [x8, #0xbe8]       | X8 = 1152921514952603440;               
            // 0x00AB1F84: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1F88: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::.ctor();
            // 0x00AB1F8C: BL #0x25e9474              | .ctor();                                
            val_8 = new System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>();
            // 0x00AB1F90: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1F94: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1F98: STR x19, [x8, #0x58]       | Mihua.Asset.AssetMgr.m_InProgressOperations = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903336024
            Mihua.Asset.AssetMgr.m_InProgressOperations = val_8;
            // 0x00AB1F9C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00AB1FA0: LDR x8, [x8, #0x498]       | X8 = 1152921504615792640;               
            // 0x00AB1FA4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.String[]> val_9 = null;
            // 0x00AB1FA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x00AB1FAC: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x00AB1FB0: LDR x8, [x8, #0xeb0]       | X8 = 1152921514172583328;               
            // 0x00AB1FB4: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x00AB1FB8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String[]>::.ctor();
            // 0x00AB1FBC: BL #0x23fb0c4              | .ctor();                                
            val_9 = new System.Collections.Generic.Dictionary<System.String, System.String[]>();
            // 0x00AB1FC0: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1FC4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1FC8: STR x19, [x8, #0x60]       | Mihua.Asset.AssetMgr.m_Dependencies = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504903336032
            Mihua.Asset.AssetMgr.m_Dependencies = val_9;
            // 0x00AB1FCC: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1FD0: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1FD4: STRB wzr, [x8, #0x70]      | Mihua.Asset.AssetMgr.isWaitClear = false;  //  dest_result_addr=1152921504903336048
            Mihua.Asset.AssetMgr.isWaitClear = false;
            // 0x00AB1FD8: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_10 = null;
            // 0x00AB1FDC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB1FE0: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB1FE4: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB1FE8: BL #0x25e9474              | .ctor();                                
            val_10 = new System.Collections.Generic.List<System.String>();
            // 0x00AB1FEC: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB1FF0: ORR w9, wzr, #4            | W9 = 4(0x4);                            
            // 0x00AB1FF4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB1FF8: STR x19, [x8, #0x78]       | Mihua.Asset.AssetMgr.ab2AsstsList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903336056
            Mihua.Asset.AssetMgr.ab2AsstsList = val_10;
            // 0x00AB1FFC: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2000: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2004: STR w9, [x8, #0x80]        | Mihua.Asset.AssetMgr.maxLoadingCount = 4;  //  dest_result_addr=1152921504903336064
            Mihua.Asset.AssetMgr.maxLoadingCount = 4;
            // 0x00AB2008: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_11 = null;
            // 0x00AB200C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB2010: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB2014: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB2018: BL #0x25e9474              | .ctor();                                
            val_11 = new System.Collections.Generic.List<System.String>();
            // 0x00AB201C: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2020: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2024: STR x19, [x8, #0x88]       | Mihua.Asset.AssetMgr.m_WaitList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903336072
            Mihua.Asset.AssetMgr.m_WaitList = val_11;
            // 0x00AB2028: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_12 = null;
            // 0x00AB202C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB2030: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB2034: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB2038: BL #0x25e9474              | .ctor();                                
            val_12 = new System.Collections.Generic.List<System.String>();
            // 0x00AB203C: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2040: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2044: STR x19, [x8, #0x90]       | Mihua.Asset.AssetMgr.m_LoadingList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903336080
            Mihua.Asset.AssetMgr.m_LoadingList = val_12;
            // 0x00AB2048: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB204C: LDR x8, [x8, #0x48]        | X8 = 1152921504616644608;               
            // 0x00AB2050: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest> val_13 = null;
            // 0x00AB2054: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB2058: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x00AB205C: LDR x8, [x8, #0x108]       | X8 = 1152921514952604464;               
            // 0x00AB2060: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB2064: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::.ctor();
            // 0x00AB2068: BL #0x25e9474              | .ctor();                                
            val_13 = new System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>();
            // 0x00AB206C: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2070: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2074: STR x19, [x8, #0x98]       | Mihua.Asset.AssetMgr.m_WWWList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921504903336088
            Mihua.Asset.AssetMgr.m_WWWList = val_13;
            // 0x00AB2078: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB207C: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2080: STRB wzr, [x8, #0xa0]      | Mihua.Asset.AssetMgr.isClearAll = false;  //  dest_result_addr=1152921504903336096
            Mihua.Asset.AssetMgr.isClearAll = false;
            // 0x00AB2084: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00AB2088: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00AB208C: LDR x19, [x8]              | X19 = typeof(System.Type[]);            
            // 0x00AB2090: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB2094: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00AB2098: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AB209C: MOV x0, x19                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB20A0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00AB20A4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00AB20A8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00AB20AC: ADRP x9, #0x35e5000        | X9 = 56512512 (0x35E5000);              
            // 0x00AB20B0: MOV x19, x0                | X19 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB20B4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00AB20B8: LDR x9, [x9, #0xd18]       | X9 = 1152921504903331840;               
            // 0x00AB20BC: LDR x20, [x9]              | X20 = typeof(Mihua.Asset.AssetMgr);     
            // 0x00AB20C0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00AB20C4: TBZ w9, #0, #0xab20d8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00AB20C8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00AB20CC: CBNZ w9, #0xab20d8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00AB20D0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00AB20D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00AB20D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB20DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB20E0: MOV x1, x20                | X1 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB20E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00AB20E8: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x00AB20EC: CBNZ x19, #0xab20f4        | if ( != null) goto label_5;             
            if(null != null)
            {
                goto label_5;
            }
            // 0x00AB20F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_5:
            // 0x00AB20F4: CBZ x20, #0xab2118         | if (val_14 == null) goto label_7;       
            if(val_14 == null)
            {
                goto label_7;
            }
            // 0x00AB20F8: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB20FC: MOV x0, x20                | X0 = val_14;//m1                        
            // 0x00AB2100: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB2104: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x00AB2108: CBNZ x0, #0xab2118         | if (val_14 != null) goto label_7;       
            if(val_14 != null)
            {
                goto label_7;
            }
            // 0x00AB210C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x00AB2110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2114: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_7:
            // 0x00AB2118: LDR w8, [x19, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00AB211C: CBNZ w8, #0xab212c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_8;
            // 0x00AB2120: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x00AB2124: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2128: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_8:
            // 0x00AB212C: STR x20, [x19, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_14;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_14;
            // 0x00AB2130: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00AB2134: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
            // 0x00AB2138: LDR x0, [x8]               | X0 = typeof(UnityEngine.GameObject);    
            UnityEngine.GameObject val_15 = null;
            // 0x00AB213C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.GameObject), ????);
            // 0x00AB2140: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00AB2144: LDR x8, [x8, #0x730]       | X8 = (string**)(1152921514952609584)("AssetBundleManager");
            // 0x00AB2148: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB214C: MOV x2, x19                | X2 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00AB2150: MOV x20, x0                | X20 = 1152921504692629504 (0x10000000051CF000);//ML01
            // 0x00AB2154: LDR x1, [x8]               | X1 = "AssetBundleManager";              
            // 0x00AB2158: BL #0x1a624e4              | .ctor(name:  "AssetBundleManager", components:  null);
            val_15 = new UnityEngine.GameObject(name:  "AssetBundleManager", components:  null);
            // 0x00AB215C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00AB2160: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x00AB2164: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
            // 0x00AB2168: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00AB216C: TBZ w8, #0, #0xab217c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AB2170: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2174: CBNZ w8, #0xab217c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AB2178: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_10:
            // 0x00AB217C: MOV x1, x20                | X1 = 1152921504692629504 (0x10000000051CF000);//ML01
            // 0x00AB2180: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2184: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB218C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB2190: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB2194: B #0x1b78cf4               | UnityEngine.Object.DontDestroyOnLoad(target:  0); return;
            UnityEngine.Object.DontDestroyOnLoad(target:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2198 (11215256), len: 8  VirtAddr: 0x00AB2198 RVA: 0x00AB2198 token: 100693206 methodIndex: 46962 delegateWrapperIndex: 0 methodInvoker: 0
        public AssetMgr()
        {
            //
            // Disasemble & Code
            // 0x00AB2198: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB219C: B #0x1b76fd4               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAFD9C (11206044), len: 104  VirtAddr: 0x00AAFD9C RVA: 0x00AAFD9C token: 100693207 methodIndex: 46963 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Collections.Generic.Dictionary<string, UnityEngine.Object> get_cacheAssets()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AAFD9C: STP x20, x19, [sp, #-0x20]! | stack[1152921514952849760] = ???;  stack[1152921514952849768] = ???;  //  dest_result_addr=1152921514952849760 |  dest_result_addr=1152921514952849768
            // 0x00AAFDA0: STP x29, x30, [sp, #0x10]  | stack[1152921514952849776] = ???;  stack[1152921514952849784] = ???;  //  dest_result_addr=1152921514952849776 |  dest_result_addr=1152921514952849784
            // 0x00AAFDA4: ADD x29, sp, #0x10         | X29 = (1152921514952849760 + 16) = 1152921514952849776 (0x1000000268AB7970);
            // 0x00AAFDA8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AAFDAC: LDRB w8, [x19, #0x3ee]     | W8 = (bool)static_value_037333EE;       
            // 0x00AAFDB0: TBNZ w8, #0, #0xaafdcc     | if (static_value_037333EE == true) goto label_0;
            // 0x00AAFDB4: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AAFDB8: LDR x8, [x8, #0xbf0]       | X8 = 0x2B8EB2C;                         
            // 0x00AAFDBC: LDR w0, [x8]               | W0 = 0x118B;                            
            // 0x00AAFDC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x118B, ????);     
            // 0x00AAFDC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAFDC8: STRB w8, [x19, #0x3ee]     | static_value_037333EE = true;            //  dest_result_addr=57881582
            label_0:
            // 0x00AAFDCC: ADRP x19, #0x35c8000       | X19 = 56393728 (0x35C8000);             
            // 0x00AAFDD0: LDR x19, [x19, #0x270]     | X19 = 1152921504903331840;              
            // 0x00AAFDD4: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AAFDD8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFDDC: TBZ w8, #0, #0xaafdf0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AAFDE0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFDE4: CBNZ w8, #0xaafdf0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AAFDE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAFDEC: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AAFDF0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAFDF4: LDR x0, [x8, #0x38]        | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AAFDF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFDFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFE00: RET                        |  return (System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>)Mihua.Asset.AssetMgr.m_LoadedAssets;
            return Mihua.Asset.AssetMgr.m_LoadedAssets;
            //  |  // // {name=val_0, type=System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB21A0 (11215264), len: 104  VirtAddr: 0x00AB21A0 RVA: 0x00AB21A0 token: 100693208 methodIndex: 46964 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.AssetMgr.LogMode get_logMode()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB21A0: STP x20, x19, [sp, #-0x20]! | stack[1152921514952961760] = ???;  stack[1152921514952961768] = ???;  //  dest_result_addr=1152921514952961760 |  dest_result_addr=1152921514952961768
            // 0x00AB21A4: STP x29, x30, [sp, #0x10]  | stack[1152921514952961776] = ???;  stack[1152921514952961784] = ???;  //  dest_result_addr=1152921514952961776 |  dest_result_addr=1152921514952961784
            // 0x00AB21A8: ADD x29, sp, #0x10         | X29 = (1152921514952961760 + 16) = 1152921514952961776 (0x1000000268AD2EF0);
            // 0x00AB21AC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB21B0: LDRB w8, [x19, #0x3ef]     | W8 = (bool)static_value_037333EF;       
            // 0x00AB21B4: TBNZ w8, #0, #0xab21d0     | if (static_value_037333EF == true) goto label_0;
            // 0x00AB21B8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00AB21BC: LDR x8, [x8, #0x830]       | X8 = 0x2B8EB30;                         
            // 0x00AB21C0: LDR w0, [x8]               | W0 = 0x118C;                            
            // 0x00AB21C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x118C, ????);     
            // 0x00AB21C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB21CC: STRB w8, [x19, #0x3ef]     | static_value_037333EF = true;            //  dest_result_addr=57881583
            label_0:
            // 0x00AB21D0: ADRP x19, #0x35c8000       | X19 = 56393728 (0x35C8000);             
            // 0x00AB21D4: LDR x19, [x19, #0x270]     | X19 = 1152921504903331840;              
            // 0x00AB21D8: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB21DC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB21E0: TBZ w8, #0, #0xab21f4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB21E4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB21E8: CBNZ w8, #0xab21f4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB21EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB21F0: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB21F4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB21F8: LDR w0, [x8, #4]           | W0 = Mihua.Asset.AssetMgr.m_LogMode;    
            // 0x00AB21FC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2200: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2204: RET                        |  return (LogMode)Mihua.Asset.AssetMgr.m_LogMode;
            return Mihua.Asset.AssetMgr.m_LogMode;
            //  |  // // {name=val_0, type=LogMode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2208 (11215368), len: 108  VirtAddr: 0x00AB2208 RVA: 0x00AB2208 token: 100693209 methodIndex: 46965 delegateWrapperIndex: 0 methodInvoker: 0
        public static void set_logMode(Mihua.Asset.AssetMgr.LogMode value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB2208: STP x20, x19, [sp, #-0x20]! | stack[1152921514953077856] = ???;  stack[1152921514953077864] = ???;  //  dest_result_addr=1152921514953077856 |  dest_result_addr=1152921514953077864
            // 0x00AB220C: STP x29, x30, [sp, #0x10]  | stack[1152921514953077872] = ???;  stack[1152921514953077880] = ???;  //  dest_result_addr=1152921514953077872 |  dest_result_addr=1152921514953077880
            // 0x00AB2210: ADD x29, sp, #0x10         | X29 = (1152921514953077856 + 16) = 1152921514953077872 (0x1000000268AEF470);
            // 0x00AB2214: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB2218: LDRB w8, [x20, #0x3f0]     | W8 = (bool)static_value_037333F0;       
            // 0x00AB221C: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00AB2220: TBNZ w8, #0, #0xab223c     | if (static_value_037333F0 == true) goto label_0;
            // 0x00AB2224: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00AB2228: LDR x8, [x8, #0x488]       | X8 = 0x2B8EB84;                         
            // 0x00AB222C: LDR w0, [x8]               | W0 = 0x11A1;                            
            // 0x00AB2230: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A1, ????);     
            // 0x00AB2234: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB2238: STRB w8, [x20, #0x3f0]     | static_value_037333F0 = true;            //  dest_result_addr=57881584
            label_0:
            // 0x00AB223C: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB2240: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB2244: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB2248: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB224C: TBZ w8, #0, #0xab2260      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB2250: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2254: CBNZ w8, #0xab2260         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB2258: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB225C: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB2260: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2264: STR w19, [x8, #4]          | Mihua.Asset.AssetMgr.m_LogMode = W1;     //  dest_result_addr=1152921504903335940
            Mihua.Asset.AssetMgr.m_LogMode = W1;
            // 0x00AB2268: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB226C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2270: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2274 (11215476), len: 104  VirtAddr: 0x00AB2274 RVA: 0x00AB2274 token: 100693210 methodIndex: 46966 delegateWrapperIndex: 0 methodInvoker: 0
        public static string get_BaseDownloadingURL()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB2274: STP x20, x19, [sp, #-0x20]! | stack[1152921514953193952] = ???;  stack[1152921514953193960] = ???;  //  dest_result_addr=1152921514953193952 |  dest_result_addr=1152921514953193960
            // 0x00AB2278: STP x29, x30, [sp, #0x10]  | stack[1152921514953193968] = ???;  stack[1152921514953193976] = ???;  //  dest_result_addr=1152921514953193968 |  dest_result_addr=1152921514953193976
            // 0x00AB227C: ADD x29, sp, #0x10         | X29 = (1152921514953193952 + 16) = 1152921514953193968 (0x1000000268B0B9F0);
            // 0x00AB2280: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB2284: LDRB w8, [x19, #0x3f1]     | W8 = (bool)static_value_037333F1;       
            // 0x00AB2288: TBNZ w8, #0, #0xab22a4     | if (static_value_037333F1 == true) goto label_0;
            // 0x00AB228C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00AB2290: LDR x8, [x8, #0x438]       | X8 = 0x2B8EB28;                         
            // 0x00AB2294: LDR w0, [x8]               | W0 = 0x118A;                            
            // 0x00AB2298: BL #0x2782188              | X0 = sub_2782188( ?? 0x118A, ????);     
            // 0x00AB229C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB22A0: STRB w8, [x19, #0x3f1]     | static_value_037333F1 = true;            //  dest_result_addr=57881585
            label_0:
            // 0x00AB22A4: ADRP x19, #0x35c8000       | X19 = 56393728 (0x35C8000);             
            // 0x00AB22A8: LDR x19, [x19, #0x270]     | X19 = 1152921504903331840;              
            // 0x00AB22AC: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB22B0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB22B4: TBZ w8, #0, #0xab22c8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB22B8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB22BC: CBNZ w8, #0xab22c8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB22C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB22C4: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB22C8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB22CC: LDR x0, [x8, #8]           | X0 = Mihua.Asset.AssetMgr.m_BaseDownloadingURL;
            // 0x00AB22D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB22D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB22D8: RET                        |  return (System.String)Mihua.Asset.AssetMgr.m_BaseDownloadingURL;
            return Mihua.Asset.AssetMgr.m_BaseDownloadingURL;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB22DC (11215580), len: 108  VirtAddr: 0x00AB22DC RVA: 0x00AB22DC token: 100693211 methodIndex: 46967 delegateWrapperIndex: 0 methodInvoker: 0
        public static void set_BaseDownloadingURL(string value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB22DC: STP x20, x19, [sp, #-0x20]! | stack[1152921514953310048] = ???;  stack[1152921514953310056] = ???;  //  dest_result_addr=1152921514953310048 |  dest_result_addr=1152921514953310056
            // 0x00AB22E0: STP x29, x30, [sp, #0x10]  | stack[1152921514953310064] = ???;  stack[1152921514953310072] = ???;  //  dest_result_addr=1152921514953310064 |  dest_result_addr=1152921514953310072
            // 0x00AB22E4: ADD x29, sp, #0x10         | X29 = (1152921514953310048 + 16) = 1152921514953310064 (0x1000000268B27F70);
            // 0x00AB22E8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB22EC: LDRB w8, [x20, #0x3f2]     | W8 = (bool)static_value_037333F2;       
            // 0x00AB22F0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB22F4: TBNZ w8, #0, #0xab2310     | if (static_value_037333F2 == true) goto label_0;
            // 0x00AB22F8: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00AB22FC: LDR x8, [x8, #0x650]       | X8 = 0x2B8EB80;                         
            // 0x00AB2300: LDR w0, [x8]               | W0 = 0x11A0;                            
            // 0x00AB2304: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A0, ????);     
            // 0x00AB2308: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB230C: STRB w8, [x20, #0x3f2]     | static_value_037333F2 = true;            //  dest_result_addr=57881586
            label_0:
            // 0x00AB2310: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB2314: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB2318: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB231C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2320: TBZ w8, #0, #0xab2334      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB2324: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2328: CBNZ w8, #0xab2334         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB232C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2330: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB2334: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2338: STR x19, [x8, #8]          | Mihua.Asset.AssetMgr.m_BaseDownloadingURL = X1;  //  dest_result_addr=1152921504903335944
            Mihua.Asset.AssetMgr.m_BaseDownloadingURL = X1;
            // 0x00AB233C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2340: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2344: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2348 (11215688), len: 104  VirtAddr: 0x00AB2348 RVA: 0x00AB2348 token: 100693212 methodIndex: 46968 delegateWrapperIndex: 0 methodInvoker: 0
        public static string[] get_ActiveVariants()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB2348: STP x20, x19, [sp, #-0x20]! | stack[1152921514953426144] = ???;  stack[1152921514953426152] = ???;  //  dest_result_addr=1152921514953426144 |  dest_result_addr=1152921514953426152
            // 0x00AB234C: STP x29, x30, [sp, #0x10]  | stack[1152921514953426160] = ???;  stack[1152921514953426168] = ???;  //  dest_result_addr=1152921514953426160 |  dest_result_addr=1152921514953426168
            // 0x00AB2350: ADD x29, sp, #0x10         | X29 = (1152921514953426144 + 16) = 1152921514953426160 (0x1000000268B444F0);
            // 0x00AB2354: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB2358: LDRB w8, [x19, #0x3f3]     | W8 = (bool)static_value_037333F3;       
            // 0x00AB235C: TBNZ w8, #0, #0xab2378     | if (static_value_037333F3 == true) goto label_0;
            // 0x00AB2360: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB2364: LDR x8, [x8, #0x7a8]       | X8 = 0x2B8EB24;                         
            // 0x00AB2368: LDR w0, [x8]               | W0 = 0x1189;                            
            // 0x00AB236C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1189, ????);     
            // 0x00AB2370: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB2374: STRB w8, [x19, #0x3f3]     | static_value_037333F3 = true;            //  dest_result_addr=57881587
            label_0:
            // 0x00AB2378: ADRP x19, #0x35c8000       | X19 = 56393728 (0x35C8000);             
            // 0x00AB237C: LDR x19, [x19, #0x270]     | X19 = 1152921504903331840;              
            // 0x00AB2380: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB2384: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2388: TBZ w8, #0, #0xab239c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB238C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2390: CBNZ w8, #0xab239c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB2394: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2398: LDR x0, [x19]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB239C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB23A0: LDR x0, [x8, #0x10]        | X0 = Mihua.Asset.AssetMgr.m_ActiveVariants;
            // 0x00AB23A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB23A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB23AC: RET                        |  return (System.String[])Mihua.Asset.AssetMgr.m_ActiveVariants;
            return Mihua.Asset.AssetMgr.m_ActiveVariants;
            //  |  // // {name=val_0, type=System.String[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB23B0 (11215792), len: 108  VirtAddr: 0x00AB23B0 RVA: 0x00AB23B0 token: 100693213 methodIndex: 46969 delegateWrapperIndex: 0 methodInvoker: 0
        public static void set_ActiveVariants(string[] value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB23B0: STP x20, x19, [sp, #-0x20]! | stack[1152921514953575008] = ???;  stack[1152921514953575016] = ???;  //  dest_result_addr=1152921514953575008 |  dest_result_addr=1152921514953575016
            // 0x00AB23B4: STP x29, x30, [sp, #0x10]  | stack[1152921514953575024] = ???;  stack[1152921514953575032] = ???;  //  dest_result_addr=1152921514953575024 |  dest_result_addr=1152921514953575032
            // 0x00AB23B8: ADD x29, sp, #0x10         | X29 = (1152921514953575008 + 16) = 1152921514953575024 (0x1000000268B68A70);
            // 0x00AB23BC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB23C0: LDRB w8, [x20, #0x3f4]     | W8 = (bool)static_value_037333F4;       
            // 0x00AB23C4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB23C8: TBNZ w8, #0, #0xab23e4     | if (static_value_037333F4 == true) goto label_0;
            // 0x00AB23CC: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00AB23D0: LDR x8, [x8, #0x1d0]       | X8 = 0x2B8EB78;                         
            // 0x00AB23D4: LDR w0, [x8]               | W0 = 0x119E;                            
            // 0x00AB23D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x119E, ????);     
            // 0x00AB23DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB23E0: STRB w8, [x20, #0x3f4]     | static_value_037333F4 = true;            //  dest_result_addr=57881588
            label_0:
            // 0x00AB23E4: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB23E8: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB23EC: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB23F0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB23F4: TBZ w8, #0, #0xab2408      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB23F8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB23FC: CBNZ w8, #0xab2408         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB2400: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2404: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB2408: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB240C: STR x19, [x8, #0x10]       | Mihua.Asset.AssetMgr.m_ActiveVariants = X1;  //  dest_result_addr=1152921504903335952
            Mihua.Asset.AssetMgr.m_ActiveVariants = X1;
            // 0x00AB2410: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2414: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2418: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0A0C (11209228), len: 108  VirtAddr: 0x00AB0A0C RVA: 0x00AB0A0C token: 100693214 methodIndex: 46970 delegateWrapperIndex: 0 methodInvoker: 0
        public static void set_AssetBundleManifestObject(UnityEngine.AssetBundleManifest value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00AB0A0C: STP x20, x19, [sp, #-0x20]! | stack[1152921514953727968] = ???;  stack[1152921514953727976] = ???;  //  dest_result_addr=1152921514953727968 |  dest_result_addr=1152921514953727976
            // 0x00AB0A10: STP x29, x30, [sp, #0x10]  | stack[1152921514953727984] = ???;  stack[1152921514953727992] = ???;  //  dest_result_addr=1152921514953727984 |  dest_result_addr=1152921514953727992
            // 0x00AB0A14: ADD x29, sp, #0x10         | X29 = (1152921514953727968 + 16) = 1152921514953727984 (0x1000000268B8DFF0);
            // 0x00AB0A18: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB0A1C: LDRB w8, [x20, #0x3f5]     | W8 = (bool)static_value_037333F5;       
            // 0x00AB0A20: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB0A24: TBNZ w8, #0, #0xab0a40     | if (static_value_037333F5 == true) goto label_0;
            // 0x00AB0A28: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00AB0A2C: LDR x8, [x8, #0x5c8]       | X8 = 0x2B8EB7C;                         
            // 0x00AB0A30: LDR w0, [x8]               | W0 = 0x119F;                            
            // 0x00AB0A34: BL #0x2782188              | X0 = sub_2782188( ?? 0x119F, ????);     
            // 0x00AB0A38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB0A3C: STRB w8, [x20, #0x3f5]     | static_value_037333F5 = true;            //  dest_result_addr=57881589
            label_0:
            // 0x00AB0A40: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB0A44: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB0A48: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            // 0x00AB0A4C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB0A50: TBZ w8, #0, #0xab0a64      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB0A54: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0A58: CBNZ w8, #0xab0a64         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB0A5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB0A60: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_1 = null;
            label_2:
            // 0x00AB0A64: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB0A68: STR x19, [x8, #0x18]       | Mihua.Asset.AssetMgr.m_AssetBundleManifest = X1;  //  dest_result_addr=1152921504903335960
            Mihua.Asset.AssetMgr.m_AssetBundleManifest = X1;
            // 0x00AB0A6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB0A70: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB0A74: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB241C (11215900), len: 396  VirtAddr: 0x00AB241C RVA: 0x00AB241C token: 100693215 methodIndex: 46971 delegateWrapperIndex: 0 methodInvoker: 0
        private static void Log(Mihua.Asset.AssetMgr.LogType logType, string text)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00AB241C: STP x22, x21, [sp, #-0x30]! | stack[1152921514953860544] = ???;  stack[1152921514953860552] = ???;  //  dest_result_addr=1152921514953860544 |  dest_result_addr=1152921514953860552
            // 0x00AB2420: STP x20, x19, [sp, #0x10]  | stack[1152921514953860560] = ???;  stack[1152921514953860568] = ???;  //  dest_result_addr=1152921514953860560 |  dest_result_addr=1152921514953860568
            // 0x00AB2424: STP x29, x30, [sp, #0x20]  | stack[1152921514953860576] = ???;  stack[1152921514953860584] = ???;  //  dest_result_addr=1152921514953860576 |  dest_result_addr=1152921514953860584
            // 0x00AB2428: ADD x29, sp, #0x20         | X29 = (1152921514953860544 + 32) = 1152921514953860576 (0x1000000268BAE5E0);
            // 0x00AB242C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AB2430: LDRB w8, [x21, #0x3f6]     | W8 = (bool)static_value_037333F6;       
            // 0x00AB2434: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00AB2438: MOV w20, w1                | W20 = text;//m1                         
            // 0x00AB243C: TBNZ w8, #0, #0xab2458     | if (static_value_037333F6 == true) goto label_0;
            // 0x00AB2440: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00AB2444: LDR x8, [x8, #0x218]       | X8 = 0x2B8EB6C;                         
            // 0x00AB2448: LDR w0, [x8]               | W0 = 0x119B;                            
            // 0x00AB244C: BL #0x2782188              | X0 = sub_2782188( ?? 0x119B, ????);     
            // 0x00AB2450: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB2454: STRB w8, [x21, #0x3f6]     | static_value_037333F6 = true;            //  dest_result_addr=57881590
            label_0:
            // 0x00AB2458: CMP w20, #2                | STATE = COMPARE(text, 0x2)              
            // 0x00AB245C: B.NE #0xab24e4             | if (text != 0x2) goto label_1;          
            if(text != 2)
            {
                goto label_1;
            }
            // 0x00AB2460: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB2464: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB2468: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00AB246C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB2470: TBZ w8, #0, #0xab2480      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB2474: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2478: CBNZ w8, #0xab2480         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB247C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_3:
            // 0x00AB2480: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00AB2484: LDR x8, [x8, #0x950]       | X8 = (string**)(1152921514953840288)("[AssetBundleManager] ");
            // 0x00AB2488: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB248C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB2490: MOV x2, x19                | X2 = X2;//m1                            
            // 0x00AB2494: LDR x1, [x8]               | X1 = "[AssetBundleManager] ";           
            // 0x00AB2498: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "[AssetBundleManager] ");
            string val_1 = System.String.Concat(str0:  0, str1:  "[AssetBundleManager] ");
            // 0x00AB249C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB24A0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB24A4: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00AB24A8: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB24AC: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB24B0: TBZ w9, #0, #0xab24c4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00AB24B4: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB24B8: CBNZ w9, #0xab24c4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00AB24BC: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB24C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_5:
            // 0x00AB24C4: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00AB24C8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB24CC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB24D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB24D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB24D8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB24DC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB24E0: B #0xb5b538                | EDebug.LogError(message:  0, isShowStack:  val_1); return;
            EDebug.LogError(message:  0, isShowStack:  val_1);
            return;
            label_1:
            // 0x00AB24E4: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB24E8: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB24EC: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_3 = null;
            // 0x00AB24F0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB24F4: TBZ w8, #0, #0xab2508      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AB24F8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB24FC: CBNZ w8, #0xab2508         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB2500: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2504: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_3 = null;
            label_7:
            // 0x00AB2508: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB250C: LDR w8, [x8, #4]           | W8 = Mihua.Asset.AssetMgr.m_LogMode;    
            // 0x00AB2510: CBZ w8, #0xab2524          | if (Mihua.Asset.AssetMgr.m_LogMode == 0) goto label_8;
            if(Mihua.Asset.AssetMgr.m_LogMode == 0)
            {
                goto label_8;
            }
            // 0x00AB2514: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2518: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB251C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB2520: RET                        |  return;                                
            return;
            label_8:
            // 0x00AB2524: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB2528: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB252C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00AB2530: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB2534: TBZ w8, #0, #0xab2544      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AB2538: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB253C: CBNZ w8, #0xab2544         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AB2540: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_10:
            // 0x00AB2544: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00AB2548: LDR x8, [x8, #0x950]       | X8 = (string**)(1152921514953840288)("[AssetBundleManager] ");
            // 0x00AB254C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2550: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB2554: MOV x2, x19                | X2 = X2;//m1                            
            // 0x00AB2558: LDR x1, [x8]               | X1 = "[AssetBundleManager] ";           
            // 0x00AB255C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "[AssetBundleManager] ");
            string val_2 = System.String.Concat(str0:  0, str1:  "[AssetBundleManager] ");
            // 0x00AB2560: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB2564: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB2568: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00AB256C: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB2570: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB2574: TBZ w9, #0, #0xab2588      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AB2578: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB257C: CBNZ w9, #0xab2588         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AB2580: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB2584: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_12:
            // 0x00AB2588: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x00AB258C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2590: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2598: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB259C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB25A0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB25A4: B #0xb45c10                | EDebug.Log(message:  0, isShowStack:  val_2); return;
            EDebug.Log(message:  0, isShowStack:  val_2);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB032C (11207468), len: 408  VirtAddr: 0x00AB032C RVA: 0x00AB032C token: 100693216 methodIndex: 46972 delegateWrapperIndex: 0 methodInvoker: 0
        public static float GetProgress(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_6;
            //  | 
            var val_7;
            //  | 
            float val_8;
            //  | 
            var val_9;
            // 0x00AB032C: STP d9, d8, [sp, #-0x50]!  | stack[1152921514953992992] = ???;  stack[1152921514953993000] = ???;  //  dest_result_addr=1152921514953992992 |  dest_result_addr=1152921514953993000
            // 0x00AB0330: STP x24, x23, [sp, #0x10]  | stack[1152921514953993008] = ???;  stack[1152921514953993016] = ???;  //  dest_result_addr=1152921514953993008 |  dest_result_addr=1152921514953993016
            // 0x00AB0334: STP x22, x21, [sp, #0x20]  | stack[1152921514953993024] = ???;  stack[1152921514953993032] = ???;  //  dest_result_addr=1152921514953993024 |  dest_result_addr=1152921514953993032
            // 0x00AB0338: STP x20, x19, [sp, #0x30]  | stack[1152921514953993040] = ???;  stack[1152921514953993048] = ???;  //  dest_result_addr=1152921514953993040 |  dest_result_addr=1152921514953993048
            // 0x00AB033C: STP x29, x30, [sp, #0x40]  | stack[1152921514953993056] = ???;  stack[1152921514953993064] = ???;  //  dest_result_addr=1152921514953993056 |  dest_result_addr=1152921514953993064
            // 0x00AB0340: ADD x29, sp, #0x40         | X29 = (1152921514953992992 + 64) = 1152921514953993056 (0x1000000268BCEB60);
            // 0x00AB0344: SUB sp, sp, #0x10          | SP = (1152921514953992992 - 16) = 1152921514953992976 (0x1000000268BCEB10);
            // 0x00AB0348: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB034C: LDRB w8, [x20, #0x3f7]     | W8 = (bool)static_value_037333F7;       
            // 0x00AB0350: MOV x19, x1                | X19 = X1;//m1                           
            val_6 = X1;
            // 0x00AB0354: TBNZ w8, #0, #0xab0370     | if (static_value_037333F7 == true) goto label_0;
            // 0x00AB0358: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00AB035C: LDR x8, [x8, #0x1a0]       | X8 = 0x2B8EB3C;                         
            // 0x00AB0360: LDR w0, [x8]               | W0 = 0x118F;                            
            // 0x00AB0364: BL #0x2782188              | X0 = sub_2782188( ?? 0x118F, ????);     
            // 0x00AB0368: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB036C: STRB w8, [x20, #0x3f7]     | static_value_037333F7 = true;            //  dest_result_addr=57881591
            label_0:
            // 0x00AB0370: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB0374: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AB0378: STR xzr, [sp, #8]          | stack[1152921514953992984] = 0x0;        //  dest_result_addr=1152921514953992984
            System.String[] val_1 = 0;
            // 0x00AB037C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            // 0x00AB0380: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB0384: TBZ w8, #0, #0xab0398      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB0388: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB038C: CBNZ w8, #0xab0398         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB0390: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB0394: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            label_2:
            // 0x00AB0398: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB039C: LDR x20, [x8, #0x60]       | X20 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB03A0: CBNZ x20, #0xab03a8        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_3;
            }
            // 0x00AB03A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB03A8: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00AB03AC: LDR x8, [x8, #0x7f0]       | X8 = 1152921514171482112;               
            // 0x00AB03B0: ADD x2, sp, #8             | X2 = (1152921514953992976 + 8) = 1152921514953992984 (0x1000000268BCEB18);
            // 0x00AB03B4: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB03B8: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB03BC: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String[]>::TryGetValue(System.String key, out System.String[] value);
            // 0x00AB03C0: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_Dependencies.TryGetValue(key:  val_6, value: out  System.String[] val_1 = 0);
            bool val_2 = Mihua.Asset.AssetMgr.m_Dependencies.TryGetValue(key:  val_6, value: out  val_1);
            // 0x00AB03C4: TBZ w0, #0, #0xab0488      | if (val_2 == false) goto label_4;       
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x00AB03C8: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB03CC: CBNZ x20, #0xab03d4        | if (0x0 != 0) goto label_5;             
            if(val_1 != 0)
            {
                goto label_5;
            }
            // 0x00AB03D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_5:
            // 0x00AB03D4: LDR x22, [x20, #0x18]      | X22 = 0x9814C0;                         
            // 0x00AB03D8: FMOV s8, wzr               | S8 = 0f;                                
            val_8 = 0f;
            // 0x00AB03DC: CMP w22, #1                | STATE = COMPARE(0x9814C0, 0x1)          
            // 0x00AB03E0: B.LT #0xab0444             | if (9966784 < 0x1) goto label_6;        
            if(9966784 < 1)
            {
                goto label_6;
            }
            // 0x00AB03E4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            var val_7 = 0;
            label_11:
            // 0x00AB03E8: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB03EC: CBNZ x20, #0xab03f4        | if (0x0 != 0) goto label_7;             
            if(val_1 != 0)
            {
                goto label_7;
            }
            // 0x00AB03F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x00AB03F4: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB03F8: CMP x23, x8                | STATE = COMPARE(0x0, 0x9814C0)          
            // 0x00AB03FC: B.LO #0xab040c             | if (0 < 9966784) goto label_8;          
            if(val_7 < 9966784)
            {
                goto label_8;
            }
            // 0x00AB0400: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB0404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB0408: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_8:
            // 0x00AB040C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB0410: ADD x8, x20, x23, lsl #3   | X8 = (val_1 + 0);                       
            var val_3 = val_1 + 0;
            // 0x00AB0414: LDR x20, [x8, #0x20]       | X20 = (val_1 + 0) + 32;                 
            // 0x00AB0418: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB041C: TBZ w8, #0, #0xab042c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AB0420: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0424: CBNZ w8, #0xab042c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AB0428: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_10:
            // 0x00AB042C: MOV x1, x20                | X1 = (val_1 + 0) + 32;//m1              
            // 0x00AB0430: BL #0xab25a8               | X0 = Mihua.Asset.AssetMgr.GetSingleProgress(assetBundleName:  null);
            float val_4 = Mihua.Asset.AssetMgr.GetSingleProgress(assetBundleName:  null);
            // 0x00AB0434: FADD s8, s8, s0            | S8 = (val_8 + val_4);                   
            val_8 = val_8 + val_4;
            // 0x00AB0438: ADD x23, x23, #1           | X23 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00AB043C: CMP w22, w23               | STATE = COMPARE(0x9814C0, (0 + 1))      
            // 0x00AB0440: B.NE #0xab03e8             | if (9966784 != 0) goto label_11;        
            if(9966784 != val_7)
            {
                goto label_11;
            }
            label_6:
            // 0x00AB0444: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB0448: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB044C: TBZ w8, #0, #0xab045c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00AB0450: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0454: CBNZ w8, #0xab045c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00AB0458: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_13:
            // 0x00AB045C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB0460: BL #0xab25a8               | X0 = Mihua.Asset.AssetMgr.GetSingleProgress(assetBundleName:  null);
            float val_5 = Mihua.Asset.AssetMgr.GetSingleProgress(assetBundleName:  null);
            // 0x00AB0464: LDR x19, [sp, #8]          | X19 = 0x0;                              
            val_6 = val_1;
            // 0x00AB0468: FADD s8, s8, s0            | S8 = ((val_8 + val_4) + val_5);         
            val_8 = val_8 + val_5;
            // 0x00AB046C: CBNZ x19, #0xab0474        | if (0x0 != 0) goto label_14;            
            if(val_6 != 0)
            {
                goto label_14;
            }
            // 0x00AB0470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_14:
            // 0x00AB0474: LDR w8, [x19, #0x18]       | W8 = 0x9814C0;                          
            var val_8 = 9966784;
            // 0x00AB0478: ADD w8, w8, #1             | W8 = (9966784 + 1);                     
            val_8 = val_8 + 1;
            // 0x00AB047C: SCVTF s0, w8               | S0 = (float)((9966784 + 1));            
            float val_9 = (float)val_8;
            // 0x00AB0480: FDIV s0, s8, s0            | S0 = (((val_8 + val_4) + val_5) / (9966784 + 1));
            val_9 = val_8 / val_9;
            // 0x00AB0484: B #0xab04a8                |  goto label_15;                         
            goto label_15;
            label_4:
            // 0x00AB0488: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB048C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB0490: TBZ w8, #0, #0xab04a0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00AB0494: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0498: CBNZ w8, #0xab04a0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00AB049C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_17:
            // 0x00AB04A0: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB04A4: BL #0xab25a8               | X0 = Mihua.Asset.AssetMgr.GetSingleProgress(assetBundleName:  null);
            float val_6 = Mihua.Asset.AssetMgr.GetSingleProgress(assetBundleName:  null);
            label_15:
            // 0x00AB04A8: SUB sp, x29, #0x40         | SP = (1152921514953993056 - 64) = 1152921514953992992 (0x1000000268BCEB20);
            // 0x00AB04AC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB04B0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB04B4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB04B8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB04BC: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
            // 0x00AB04C0: RET                        |  return (System.Single)val_6;           
            return val_6;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB25A8 (11216296), len: 352  VirtAddr: 0x00AB25A8 RVA: 0x00AB25A8 token: 100693217 methodIndex: 46973 delegateWrapperIndex: 0 methodInvoker: 0
        public static float GetSingleProgress(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00AB25A8: STP x22, x21, [sp, #-0x30]! | stack[1152921514954119360] = ???;  stack[1152921514954119368] = ???;  //  dest_result_addr=1152921514954119360 |  dest_result_addr=1152921514954119368
            // 0x00AB25AC: STP x20, x19, [sp, #0x10]  | stack[1152921514954119376] = ???;  stack[1152921514954119384] = ???;  //  dest_result_addr=1152921514954119376 |  dest_result_addr=1152921514954119384
            // 0x00AB25B0: STP x29, x30, [sp, #0x20]  | stack[1152921514954119392] = ???;  stack[1152921514954119400] = ???;  //  dest_result_addr=1152921514954119392 |  dest_result_addr=1152921514954119400
            // 0x00AB25B4: ADD x29, sp, #0x20         | X29 = (1152921514954119360 + 32) = 1152921514954119392 (0x1000000268BED8E0);
            // 0x00AB25B8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB25BC: LDRB w8, [x20, #0x3f8]     | W8 = (bool)static_value_037333F8;       
            // 0x00AB25C0: MOV x19, x1                | X19 = X1;//m1                           
            val_5 = X1;
            // 0x00AB25C4: TBNZ w8, #0, #0xab25e0     | if (static_value_037333F8 == true) goto label_0;
            // 0x00AB25C8: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00AB25CC: LDR x8, [x8, #0x430]       | X8 = 0x2B8EB40;                         
            // 0x00AB25D0: LDR w0, [x8]               | W0 = 0x1190;                            
            // 0x00AB25D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1190, ????);     
            // 0x00AB25D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB25DC: STRB w8, [x20, #0x3f8]     | static_value_037333F8 = true;            //  dest_result_addr=57881592
            label_0:
            // 0x00AB25E0: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB25E4: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AB25E8: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_6 = null;
            // 0x00AB25EC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB25F0: TBZ w8, #0, #0xab2604      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB25F4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB25F8: CBNZ w8, #0xab2604         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB25FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2600: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_6 = null;
            label_2:
            // 0x00AB2604: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2608: LDR x20, [x8, #0x40]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB260C: CBNZ x20, #0xab2614        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_3;
            }
            // 0x00AB2610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB2614: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00AB2618: LDR x8, [x8, #0xfe0]       | X8 = 1152921514954101264;               
            // 0x00AB261C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB2620: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2624: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::ContainsKey(System.String key);
            // 0x00AB2628: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.ContainsKey(key:  val_5);
            bool val_1 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.ContainsKey(key:  val_5);
            // 0x00AB262C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00AB2630: TBZ w8, #0, #0xab263c      | if ((val_1 & 1) == false) goto label_4; 
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x00AB2634: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x00AB2638: B #0xab26f8                |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x00AB263C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            // 0x00AB2640: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2644: TBZ w8, #0, #0xab2658      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AB2648: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB264C: CBNZ w8, #0xab2658         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB2650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2654: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            label_7:
            // 0x00AB2658: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB265C: LDR x20, [x8, #0x90]       | X20 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB2660: CBNZ x20, #0xab2668        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_8;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_8;
            }
            // 0x00AB2664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_8:
            // 0x00AB2668: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00AB266C: LDR x8, [x8, #0x780]       | X8 = 1152921510892731984;               
            // 0x00AB2670: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB2674: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2678: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.List<System.String>::IndexOf(System.String item);
            // 0x00AB267C: BL #0x25ec03c              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.IndexOf(item:  val_5);
            int val_3 = Mihua.Asset.AssetMgr.m_LoadingList.IndexOf(item:  val_5);
            // 0x00AB2680: MOV w19, w0                | W19 = val_3;//m1                        
            val_5 = val_3;
            // 0x00AB2684: CMP w19, #1                | STATE = COMPARE(val_3, 0x1)             
            // 0x00AB2688: B.LT #0xab26f4             | if (val_5 < 1) goto label_9;            
            if(val_5 < 1)
            {
                goto label_9;
            }
            // 0x00AB268C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_8 = null;
            // 0x00AB2690: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2694: TBZ w8, #0, #0xab26a8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00AB2698: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB269C: CBNZ w8, #0xab26a8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00AB26A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB26A4: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_8 = null;
            label_11:
            // 0x00AB26A8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB26AC: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB26B0: CBNZ x20, #0xab26b8        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_12;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_12;
            }
            // 0x00AB26B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_12:
            // 0x00AB26B8: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x00AB26BC: LDR x8, [x8, #0x330]       | X8 = 1152921514954102288;               
            // 0x00AB26C0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB26C4: MOV w1, w19                | W1 = val_3;//m1                         
            // 0x00AB26C8: LDR x2, [x8]               | X2 = public UnityEngine.Networking.UnityWebRequest System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::get_Item(int index);
            // 0x00AB26CC: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_WWWList.get_Item(index:  val_5);
            UnityEngine.Networking.UnityWebRequest val_4 = Mihua.Asset.AssetMgr.m_WWWList.Item[val_5];
            // 0x00AB26D0: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00AB26D4: CBNZ x19, #0xab26dc        | if (val_4 != null) goto label_13;       
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x00AB26D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x00AB26DC: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x00AB26E0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB26E4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB26E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB26EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB26F0: B #0x275702c               | return val_4.get_downloadProgress();    
            return val_4.downloadProgress;
            label_9:
            // 0x00AB26F4: FMOV s0, wzr               | S0 = 0f;                                
            label_5:
            // 0x00AB26F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB26FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2700: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB2704: RET                        |  return (System.Single)0;               
            return (float)0f;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FD8E34 VirtAddr: 0x00FD8E34 -RVA: 0x00FD8E34 
        // -AssetMgr.LoadResource<object>
        // -AssetMgr.LoadResource<VersionTag>
        // -AssetMgr.LoadResource<UnityEngine.GameObject>
        // -AssetMgr.LoadResource<UnityEngine.TextAsset>
        // -AssetMgr.LoadResource<TexturesStaticLoad>
        // -AssetMgr.LoadResource<UIAtlas>
        //
        //
        // Offset in libil2cpp.so: 0x00FD8E34 (16617012), len: 288  VirtAddr: 0x00FD8E34 RVA: 0x00FD8E34 token: 100693218 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T LoadResource<T>(string resPath)
        {
            //
            // Disasemble & Code
            // 0x00FD8E34: STP x22, x21, [sp, #-0x30]! | stack[1152921514954247856] = ???;  stack[1152921514954247864] = ???;  //  dest_result_addr=1152921514954247856 |  dest_result_addr=1152921514954247864
            // 0x00FD8E38: STP x20, x19, [sp, #0x10]  | stack[1152921514954247872] = ???;  stack[1152921514954247880] = ???;  //  dest_result_addr=1152921514954247872 |  dest_result_addr=1152921514954247880
            // 0x00FD8E3C: STP x29, x30, [sp, #0x20]  | stack[1152921514954247888] = ???;  stack[1152921514954247896] = ???;  //  dest_result_addr=1152921514954247888 |  dest_result_addr=1152921514954247896
            // 0x00FD8E40: ADD x29, sp, #0x20         | X29 = (1152921514954247856 + 32) = 1152921514954247888 (0x1000000268C0CED0);
            // 0x00FD8E44: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x00FD8E48: LDRB w8, [x21, #0x3f9]     | W8 = (bool)static_value_037353F9;       
            // 0x00FD8E4C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00FD8E50: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FD8E54: TBNZ w8, #0, #0xfd8e70     | if (static_value_037353F9 == true) goto label_0;
            // 0x00FD8E58: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00FD8E5C: LDR x8, [x8, #0x6a8]       | X8 = 0x2B8EB68;                         
            // 0x00FD8E60: LDR w0, [x8]               | W0 = 0x119A;                            
            // 0x00FD8E64: BL #0x2782188              | X0 = sub_2782188( ?? 0x119A, ????);     
            // 0x00FD8E68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FD8E6C: STRB w8, [x21, #0x3f9]     | static_value_037353F9 = true;            //  dest_result_addr=57889785
            label_0:
            // 0x00FD8E70: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00FD8E74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8E78: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FD8E7C: LDR x2, [x8]               | X2 = X2 + 48;                           
            // 0x00FD8E80: LDR x8, [x2]               | X8 = X2 + 48;                           
            // 0x00FD8E84: BLR x8                     | X0 = X2 + 48();                         
            // 0x00FD8E88: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00FD8E8C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x00FD8E90: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            // 0x00FD8E94: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
            // 0x00FD8E98: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00FD8E9C: TBZ w9, #0, #0xfd8eb0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00FD8EA0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8EA4: CBNZ w9, #0xfd8eb0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00FD8EA8: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
            // 0x00FD8EAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_2:
            // 0x00FD8EB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8EB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FD8EB8: MOV x1, x19                | X1 = 0 (0x0);//ML01                     
            // 0x00FD8EBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00FD8EC0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  0);
            bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  0);
            // 0x00FD8EC4: TBZ w0, #0, #0xfd8f40      | if (val_1 == false) goto label_3;       
            if(val_1 == false)
            {
                goto label_3;
            }
            // 0x00FD8EC8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00FD8ECC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00FD8ED0: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00FD8ED4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00FD8ED8: TBZ w8, #0, #0xfd8ee8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00FD8EDC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8EE0: CBNZ w8, #0xfd8ee8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00FD8EE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_5:
            // 0x00FD8EE8: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00FD8EEC: LDR x8, [x8, #0xfa0]       | X8 = (string**)(1152921514954231696)("加载资源出错,请核实 {0} 资源是否存在");
            // 0x00FD8EF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8EF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00FD8EF8: MOV x2, x20                | X2 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FD8EFC: LDR x1, [x8]               | X1 = "加载资源出错,请核实 {0} 资源是否存在";           
            // 0x00FD8F00: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "加载资源出错,请核实 {0} 资源是否存在");
            string val_2 = System.String.Format(format:  0, arg0:  "加载资源出错,请核实 {0} 资源是否存在");
            // 0x00FD8F04: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00FD8F08: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00FD8F0C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00FD8F10: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00FD8F14: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00FD8F18: TBZ w9, #0, #0xfd8f2c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00FD8F1C: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8F20: CBNZ w9, #0xfd8f2c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00FD8F24: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00FD8F28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_7:
            // 0x00FD8F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8F30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00FD8F34: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00FD8F38: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00FD8F3C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_2);
            EDebug.Log(message:  0, isShowStack:  val_2);
            label_3:
            // 0x00FD8F40: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8F44: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00FD8F48: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00FD8F4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00FD8F50: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x00FD8BEC VirtAddr: 0x00FD8BEC -RVA: 0x00FD8BEC 
        // -AssetMgr.GetLoadedAsset<object>
        // -AssetMgr.GetLoadedAsset<UnityEngine.GameObject>
        // -AssetMgr.GetLoadedAsset<UnityEngine.Object>
        //
        //
        // Offset in libil2cpp.so: 0x00FD8BEC (16616428), len: 584  VirtAddr: 0x00FD8BEC RVA: 0x00FD8BEC token: 100693219 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public static T GetLoadedAsset<T>(string assetName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            System.Collections.Generic.Dictionary<System.String, UnityEngine.Object> val_10;
            //  | 
            var val_11;
            // 0x00FD8BEC: STP x22, x21, [sp, #-0x30]! | stack[1152921514954385696] = ???;  stack[1152921514954385704] = ???;  //  dest_result_addr=1152921514954385696 |  dest_result_addr=1152921514954385704
            // 0x00FD8BF0: STP x20, x19, [sp, #0x10]  | stack[1152921514954385712] = ???;  stack[1152921514954385720] = ???;  //  dest_result_addr=1152921514954385712 |  dest_result_addr=1152921514954385720
            // 0x00FD8BF4: STP x29, x30, [sp, #0x20]  | stack[1152921514954385728] = ???;  stack[1152921514954385736] = ???;  //  dest_result_addr=1152921514954385728 |  dest_result_addr=1152921514954385736
            // 0x00FD8BF8: ADD x29, sp, #0x20         | X29 = (1152921514954385696 + 32) = 1152921514954385728 (0x1000000268C2E940);
            // 0x00FD8BFC: SUB sp, sp, #0x10          | SP = (1152921514954385696 - 16) = 1152921514954385680 (0x1000000268C2E910);
            // 0x00FD8C00: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x00FD8C04: LDRB w8, [x21, #0x3f8]     | W8 = (bool)static_value_037353F8;       
            // 0x00FD8C08: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00FD8C0C: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x00FD8C10: TBNZ w8, #0, #0xfd8c2c     | if (static_value_037353F8 == true) goto label_0;
            // 0x00FD8C14: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x00FD8C18: LDR x8, [x8, #0x6d8]       | X8 = 0x2B8EB34;                         
            // 0x00FD8C1C: LDR w0, [x8]               | W0 = 0x118D;                            
            // 0x00FD8C20: BL #0x2782188              | X0 = sub_2782188( ?? 0x118D, ????);     
            // 0x00FD8C24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00FD8C28: STRB w8, [x21, #0x3f8]     | static_value_037353F8 = true;            //  dest_result_addr=57889784
            label_0:
            // 0x00FD8C2C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00FD8C30: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00FD8C34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8C38: STR xzr, [sp]              | stack[1152921514954385680] = 0x0;        //  dest_result_addr=1152921514954385680
            UnityEngine.Object val_4 = 0;
            // 0x00FD8C3C: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00FD8C40: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_1 = Singleton<ILAssetMgr>.Instance;
            // 0x00FD8C44: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00FD8C48: CBNZ x21, #0xfd8c50        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00FD8C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00FD8C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FD8C54: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00FD8C58: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam;//m1    
            // 0x00FD8C5C: BL #0xb42c68               | X0 = val_1.LoadPathToAssetName(path:  __RuntimeMethodHiddenParam);
            string val_2 = val_1.LoadPathToAssetName(path:  __RuntimeMethodHiddenParam);
            // 0x00FD8C60: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00FD8C64: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00FD8C68: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00FD8C6C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00FD8C70: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00FD8C74: TBZ w9, #0, #0xfd8c88      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00FD8C78: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8C7C: CBNZ w9, #0xfd8c88         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00FD8C80: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00FD8C84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_3:
            // 0x00FD8C88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8C8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00FD8C90: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00FD8C94: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
            bool val_3 = System.String.IsNullOrEmpty(value:  0);
            // 0x00FD8C98: TBZ w0, #0, #0xfd8cd8      | if (val_3 == false) goto label_4;       
            if(val_3 == false)
            {
                goto label_4;
            }
            // 0x00FD8C9C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00FD8CA0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00FD8CA4: LDR x0, [x8]               | X0 = typeof(EDebug);                    
            // 0x00FD8CA8: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00FD8CAC: TBZ w8, #0, #0xfd8cbc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00FD8CB0: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8CB4: CBNZ w8, #0xfd8cbc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00FD8CB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_6:
            // 0x00FD8CBC: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00FD8CC0: LDR x8, [x8, #0x360]       | X8 = (string**)(1152921514954368384)("收集的资源列表里找不到需要的资源： {0} 请核实");
            // 0x00FD8CC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8CC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00FD8CCC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00FD8CD0: LDR x1, [x8]               | X1 = "收集的资源列表里找不到需要的资源： {0} 请核实";       
            // 0x00FD8CD4: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
            EDebug.Log(message:  0, isShowStack:  true);
            label_4:
            // 0x00FD8CD8: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00FD8CDC: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00FD8CE0: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_9 = null;
            // 0x00FD8CE4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00FD8CE8: TBZ w8, #0, #0xfd8cfc      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00FD8CEC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8CF0: CBNZ w8, #0xfd8cfc         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00FD8CF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00FD8CF8: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_9 = null;
            label_8:
            // 0x00FD8CFC: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00FD8D00: LDR x21, [x8, #0x38]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            val_10 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00FD8D04: CBNZ x21, #0xfd8d0c        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_9;
            if(val_10 != null)
            {
                goto label_9;
            }
            // 0x00FD8D08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_9:
            // 0x00FD8D0C: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00FD8D10: LDR x8, [x8, #0x9d8]       | X8 = 1152921514954368512;               
            // 0x00FD8D14: MOV x2, sp                 | X2 = 1152921514954385680 (0x1000000268C2E910);//ML01
            // 0x00FD8D18: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00FD8D1C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00FD8D20: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::TryGetValue(System.String key, out UnityEngine.Object value);
            // 0x00FD8D24: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets.TryGetValue(key:  val_2, value: out  UnityEngine.Object val_4 = 0);
            bool val_5 = val_10.TryGetValue(key:  val_2, value: out  val_4);
            // 0x00FD8D28: TBZ w0, #0, #0xfd8da4      | if (val_5 == false) goto label_10;      
            if(val_5 == false)
            {
                goto label_10;
            }
            // 0x00FD8D2C: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00FD8D30: LDR x20, [sp]              | X20 = 0x0;                              
            // 0x00FD8D34: LDR x21, [x8]              | X21 = X2 + 48;                          
            val_10 = mem[X2 + 48];
            val_10 = X2 + 48;
            // 0x00FD8D38: MOV x0, x21                | X0 = X2 + 48;//m1                       
            // 0x00FD8D3C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00FD8D40: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8D44: MOV x1, x21                | X1 = X2 + 48;//m1                       
            // 0x00FD8D48: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x00FD8D4C: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00FD8D50: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            // 0x00FD8D54: LDR x19, [x8]              | X19 = X2 + 48;                          
            val_8 = mem[X2 + 48];
            val_8 = X2 + 48;
            // 0x00FD8D58: MOV x0, x19                | X0 = X2 + 48;//m1                       
            // 0x00FD8D5C: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            // 0x00FD8D60: CBZ x20, #0xfd8e08         | if (0x0 == 0) goto label_13;            
            if(val_4 == 0)
            {
                goto label_13;
            }
            // 0x00FD8D64: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            val_11 = val_4;
            // 0x00FD8D68: MOV x1, x19                | X1 = X2 + 48;//m1                       
            // 0x00FD8D6C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x00FD8D70: CBNZ x0, #0xfd8e0c         | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00FD8D74: LDR x8, [x20]              | X8 = 0x10102464C457F;                   
            // 0x00FD8D78: MOV x1, x19                | X1 = X2 + 48;//m1                       
            // 0x00FD8D7C: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00FD8D80: ADD x8, sp, #8             | X8 = (1152921514954385680 + 8) = 1152921514954385688 (0x1000000268C2E918);
            // 0x00FD8D84: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00FD8D88: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921514954373744]
            // 0x00FD8D8C: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00FD8D90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00FD8D94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00FD8D98: ADD x0, sp, #8             | X0 = (1152921514954385680 + 8) = 1152921514954385688 (0x1000000268C2E918);
            // 0x00FD8D9C: BL #0x299a140              | 
            // 0x00FD8DA0: B #0xfd8e08                |  goto label_13;                         
            goto label_13;
            label_10:
            // 0x00FD8DA4: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00FD8DA8: LDR x8, [x8, #0xc10]       | X8 = (string**)(1152921514954369536)("获取{0}资源失败，资源未加载");
            // 0x00FD8DAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8DB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00FD8DB4: MOV x2, x20                | X2 = val_2;//m1                         
            // 0x00FD8DB8: LDR x1, [x8]               | X1 = "获取{0}资源失败，资源未加载";                 
            // 0x00FD8DBC: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "获取{0}资源失败，资源未加载");
            string val_7 = EString.EFormat(format:  0, arg0:  "获取{0}资源失败，资源未加载");
            // 0x00FD8DC0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00FD8DC4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00FD8DC8: MOV x20, x0                | X20 = val_7;//m1                        
            // 0x00FD8DCC: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00FD8DD0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00FD8DD4: TBZ w9, #0, #0xfd8de8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00FD8DD8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00FD8DDC: CBNZ w9, #0xfd8de8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00FD8DE0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00FD8DE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_15:
            // 0x00FD8DE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00FD8DEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00FD8DF0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00FD8DF4: MOV x1, x20                | X1 = val_7;//m1                         
            // 0x00FD8DF8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_7);
            EDebug.Log(message:  0, isShowStack:  val_7);
            // 0x00FD8DFC: LDR x8, [x19, #0x30]       | X8 = X2 + 48;                           
            // 0x00FD8E00: LDR x0, [x8]               | X0 = X2 + 48;                           
            // 0x00FD8E04: BL #0x277461c              | X0 = sub_277461C( ?? X2 + 48, ????);    
            label_13:
            // 0x00FD8E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_11 = 0;
            label_12:
            // 0x00FD8E0C: SUB sp, x29, #0x20         | SP = (1152921514954385728 - 32) = 1152921514954385696 (0x1000000268C2E920);
            // 0x00FD8E10: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00FD8E14: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00FD8E18: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00FD8E1C: RET                        |  return (System.Object)null;            
            return (object)val_11;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x00FD8E20: MOV x19, x0                | 
            // 0x00FD8E24: ADD x0, sp, #8             | 
            // 0x00FD8E28: BL #0x299a140              | 
            // 0x00FD8E2C: MOV x0, x19                | 
            // 0x00FD8E30: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF890 (11204752), len: 640  VirtAddr: 0x00AAF890 RVA: 0x00AAF890 token: 100693220 methodIndex: 46974 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.LoadedAssetBundle GetLoadedAssetBundle(string assetBundleName, out string error)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.String> val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00AAF890: STP x26, x25, [sp, #-0x50]! | stack[1152921514954523184] = ???;  stack[1152921514954523192] = ???;  //  dest_result_addr=1152921514954523184 |  dest_result_addr=1152921514954523192
            // 0x00AAF894: STP x24, x23, [sp, #0x10]  | stack[1152921514954523200] = ???;  stack[1152921514954523208] = ???;  //  dest_result_addr=1152921514954523200 |  dest_result_addr=1152921514954523208
            // 0x00AAF898: STP x22, x21, [sp, #0x20]  | stack[1152921514954523216] = ???;  stack[1152921514954523224] = ???;  //  dest_result_addr=1152921514954523216 |  dest_result_addr=1152921514954523224
            // 0x00AAF89C: STP x20, x19, [sp, #0x30]  | stack[1152921514954523232] = ???;  stack[1152921514954523240] = ???;  //  dest_result_addr=1152921514954523232 |  dest_result_addr=1152921514954523240
            // 0x00AAF8A0: STP x29, x30, [sp, #0x40]  | stack[1152921514954523248] = ???;  stack[1152921514954523256] = ???;  //  dest_result_addr=1152921514954523248 |  dest_result_addr=1152921514954523256
            // 0x00AAF8A4: ADD x29, sp, #0x40         | X29 = (1152921514954523184 + 64) = 1152921514954523248 (0x1000000268C50270);
            // 0x00AAF8A8: SUB sp, sp, #0x10          | SP = (1152921514954523184 - 16) = 1152921514954523168 (0x1000000268C50220);
            // 0x00AAF8AC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AAF8B0: LDRB w8, [x21, #0x3f9]     | W8 = (bool)static_value_037333F9;       
            // 0x00AAF8B4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00AAF8B8: MOV x20, x1                | X20 = 1152921514954571360 (0x1000000268C5BE60);//ML01
            // 0x00AAF8BC: TBNZ w8, #0, #0xaaf8d8     | if (static_value_037333F9 == true) goto label_0;
            // 0x00AAF8C0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00AAF8C4: LDR x8, [x8, #0xd68]       | X8 = 0x2B8EB38;                         
            // 0x00AAF8C8: LDR w0, [x8]               | W0 = 0x118E;                            
            // 0x00AAF8CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x118E, ????);     
            // 0x00AAF8D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAF8D4: STRB w8, [x21, #0x3f9]     | static_value_037333F9 = true;            //  dest_result_addr=57881593
            label_0:
            // 0x00AAF8D8: ADRP x22, #0x35c8000       | X22 = 56393728 (0x35C8000);             
            // 0x00AAF8DC: LDR x22, [x22, #0x270]     | X22 = 1152921504903331840;              
            // 0x00AAF8E0: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_11 = null;
            // 0x00AAF8E4: STP xzr, xzr, [sp]         | stack[1152921514954523168] = 0x0;  stack[1152921514954523176] = 0x0;  //  dest_result_addr=1152921514954523168 |  dest_result_addr=1152921514954523176
            // 0x00AAF8E8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAF8EC: TBZ w8, #0, #0xaaf900      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AAF8F0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAF8F4: CBNZ w8, #0xaaf900         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AAF8F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAF8FC: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_11 = null;
            label_2:
            // 0x00AAF900: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAF904: LDR x21, [x8, #0x50]       | X21 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            val_12 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            // 0x00AAF908: CBNZ x21, #0xaaf910        | if (Mihua.Asset.AssetMgr.m_DownloadingErrors != null) goto label_3;
            if(val_12 != null)
            {
                goto label_3;
            }
            // 0x00AAF90C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AAF910: ADRP x23, #0x35b9000       | X23 = 56332288 (0x35B9000);             
            // 0x00AAF914: LDR x23, [x23, #0x218]     | X23 = 1152921510817158768;              
            // 0x00AAF918: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors;//m1
            // 0x00AAF91C: MOV x1, x20                | X1 = 1152921514954571360 (0x1000000268C5BE60);//ML01
            // 0x00AAF920: MOV x2, x19                | X2 = X2;//m1                            
            string val_1 = X2;
            // 0x00AAF924: LDR x3, [x23]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String>::TryGetValue(System.String key, out System.String value);
            // 0x00AAF928: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors.TryGetValue(key:  error, value: out  string val_1 = X2);
            bool val_2 = val_12.TryGetValue(key:  error, value: out  val_1);
            // 0x00AAF92C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x00AAF930: TBNZ w8, #0, #0xaafaf0     | if ((val_2 & 1) == true) goto label_26; 
            if(val_3 == true)
            {
                goto label_26;
            }
            // 0x00AAF934: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_13 = null;
            // 0x00AAF938: STR xzr, [sp, #8]          | stack[1152921514954523176] = 0x0;        //  dest_result_addr=1152921514954523176
            Mihua.Asset.LoadedAssetBundle val_4 = 0;
            // 0x00AAF93C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAF940: TBZ w8, #0, #0xaaf954      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AAF944: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAF948: CBNZ w8, #0xaaf954         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AAF94C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAF950: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_13 = null;
            label_6:
            // 0x00AAF954: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAF958: LDR x21, [x8, #0x40]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            val_12 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AAF95C: CBNZ x21, #0xaaf964        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_7;
            if(val_12 != null)
            {
                goto label_7;
            }
            // 0x00AAF960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_7:
            // 0x00AAF964: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00AAF968: LDR x8, [x8, #0xe20]       | X8 = 1152921514954510240;               
            // 0x00AAF96C: ADD x2, sp, #8             | X2 = (1152921514954523168 + 8) = 1152921514954523176 (0x1000000268C50228);
            // 0x00AAF970: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AAF974: MOV x1, x20                | X1 = 1152921514954571360 (0x1000000268C5BE60);//ML01
            // 0x00AAF978: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::TryGetValue(System.String key, out Mihua.Asset.LoadedAssetBundle value);
            // 0x00AAF97C: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.TryGetValue(key:  error, value: out  Mihua.Asset.LoadedAssetBundle val_4 = 0);
            bool val_5 = val_12.TryGetValue(key:  error, value: out  val_4);
            // 0x00AAF980: LDR x8, [sp, #8]           | X8 = 0x0;                               
            // 0x00AAF984: CBZ x8, #0xaafaf0          | if (0x0 == 0) goto label_26;            
            if(val_4 == 0)
            {
                goto label_26;
            }
            // 0x00AAF988: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_14 = null;
            // 0x00AAF98C: STR xzr, [sp]              | stack[1152921514954523168] = 0x0;        //  dest_result_addr=1152921514954523168
            System.String[] val_6 = 0;
            // 0x00AAF990: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAF994: TBZ w8, #0, #0xaaf9a8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AAF998: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAF99C: CBNZ w8, #0xaaf9a8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AAF9A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAF9A4: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_14 = null;
            label_10:
            // 0x00AAF9A8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAF9AC: LDR x21, [x8, #0x60]       | X21 = Mihua.Asset.AssetMgr.m_Dependencies;
            val_12 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AAF9B0: CBNZ x21, #0xaaf9b8        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_11;
            if(val_12 != null)
            {
                goto label_11;
            }
            // 0x00AAF9B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_11:
            // 0x00AAF9B8: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00AAF9BC: LDR x8, [x8, #0x7f0]       | X8 = 1152921514171482112;               
            // 0x00AAF9C0: MOV x2, sp                 | X2 = 1152921514954523168 (0x1000000268C50220);//ML01
            // 0x00AAF9C4: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AAF9C8: MOV x1, x20                | X1 = 1152921514954571360 (0x1000000268C5BE60);//ML01
            // 0x00AAF9CC: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String[]>::TryGetValue(System.String key, out System.String[] value);
            // 0x00AAF9D0: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_Dependencies.TryGetValue(key:  error, value: out  System.String[] val_6 = 0);
            bool val_7 = val_12.TryGetValue(key:  error, value: out  val_6);
            // 0x00AAF9D4: TBZ w0, #0, #0xaafae8      | if (val_7 == false) goto label_20;      
            if(val_7 == false)
            {
                goto label_20;
            }
            // 0x00AAF9D8: LDR x20, [sp]              | X20 = 0x0;                              
            // 0x00AAF9DC: CBNZ x20, #0xaaf9e4        | if (0x0 != 0) goto label_13;            
            if(val_6 != 0)
            {
                goto label_13;
            }
            // 0x00AAF9E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_13:
            // 0x00AAF9E4: LDR x8, [x20, #0x18]       | X8 = 0x9814C0;                          
            // 0x00AAF9E8: CMP w8, #1                 | STATE = COMPARE(0x9814C0, 0x1)          
            // 0x00AAF9EC: B.LT #0xaafae8             | if (9966784 < 0x1) goto label_20;       
            if(9966784 < 1)
            {
                goto label_20;
            }
            // 0x00AAF9F0: ADRP x26, #0x3644000       | X26 = 56901632 (0x3644000);             
            // 0x00AAF9F4: LDR x26, [x26, #0xfe0]     | X26 = 1152921514954101264;              
            // 0x00AAF9F8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x00AAF9FC: SXTW x25, w8               | X25 = 9966784 (0x009814C0);             
            label_27:
            // 0x00AAFA00: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_15 = null;
            // 0x00AAFA04: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFA08: TBZ w8, #0, #0xaafa1c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00AAFA0C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFA10: CBNZ w8, #0xaafa1c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00AAFA14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAFA18: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_15 = null;
            label_16:
            // 0x00AAFA1C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAFA20: LDR x21, [sp]              | X21 = 0x0;                              
            // 0x00AAFA24: LDR x20, [x8, #0x50]       | X20 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            // 0x00AAFA28: CBNZ x21, #0xaafa30        | if (0x0 != 0) goto label_17;            
            if(val_6 != 0)
            {
                goto label_17;
            }
            // 0x00AAFA2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_17:
            // 0x00AAFA30: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AAFA34: CMP x24, x8                | STATE = COMPARE(0x0, 0x9814C0)          
            // 0x00AAFA38: B.LO #0xaafa48             | if (0 < 9966784) goto label_18;         
            if(val_13 < 9966784)
            {
                goto label_18;
            }
            // 0x00AAFA3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAFA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFA44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_18:
            // 0x00AAFA48: ADD x8, x21, x24, lsl #3   | X8 = (val_6 + 0);                       
            var val_8 = val_6 + 0;
            // 0x00AAFA4C: LDR x21, [x8, #0x20]       | X21 = (val_6 + 0) + 32;                 
            val_12 = mem[(val_6 + 0) + 32];
            val_12 = (val_6 + 0) + 32;
            // 0x00AAFA50: CBNZ x20, #0xaafa58        | if (Mihua.Asset.AssetMgr.m_DownloadingErrors != null) goto label_19;
            if(Mihua.Asset.AssetMgr.m_DownloadingErrors != null)
            {
                goto label_19;
            }
            // 0x00AAFA54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_19:
            // 0x00AAFA58: LDR x3, [x23]              | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String>::TryGetValue(System.String key, out System.String value);
            // 0x00AAFA5C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors;//m1
            // 0x00AAFA60: MOV x1, x21                | X1 = (val_6 + 0) + 32;//m1              
            // 0x00AAFA64: MOV x2, x19                | X2 = X2;//m1                            
            string val_9 = X2;
            // 0x00AAFA68: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors.TryGetValue(key:  val_12, value: out  string val_9 = X2);
            bool val_10 = Mihua.Asset.AssetMgr.m_DownloadingErrors.TryGetValue(key:  val_12, value: out  val_9);
            // 0x00AAFA6C: TBNZ w0, #0, #0xaafae8     | if (val_10 == true) goto label_20;      
            if(val_10 == true)
            {
                goto label_20;
            }
            // 0x00AAFA70: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_16 = null;
            // 0x00AAFA74: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFA78: TBZ w8, #0, #0xaafa8c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00AAFA7C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFA80: CBNZ w8, #0xaafa8c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00AAFA84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAFA88: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_16 = null;
            label_22:
            // 0x00AAFA8C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAFA90: LDR x21, [sp]              | X21 = 0x0;                              
            // 0x00AAFA94: LDR x20, [x8, #0x40]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AAFA98: CBNZ x21, #0xaafaa0        | if (0x0 != 0) goto label_23;            
            if(val_6 != 0)
            {
                goto label_23;
            }
            // 0x00AAFA9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_23:
            // 0x00AAFAA0: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AAFAA4: CMP x24, x8                | STATE = COMPARE(0x0, 0x9814C0)          
            // 0x00AAFAA8: B.LO #0xaafab8             | if (0 < 9966784) goto label_24;         
            if(val_13 < 9966784)
            {
                goto label_24;
            }
            // 0x00AAFAAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAFAB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFAB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_24:
            // 0x00AAFAB8: ADD x8, x21, x24, lsl #3   | X8 = (val_6 + 0);                       
            var val_11 = val_6 + 0;
            // 0x00AAFABC: LDR x21, [x8, #0x20]       | X21 = (val_6 + 0) + 32;                 
            val_12 = mem[(val_6 + 0) + 32];
            val_12 = (val_6 + 0) + 32;
            // 0x00AAFAC0: CBNZ x20, #0xaafac8        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_25;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_25;
            }
            // 0x00AAFAC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_25:
            // 0x00AAFAC8: LDR x2, [x26]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::ContainsKey(System.String key);
            // 0x00AAFACC: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AAFAD0: MOV x1, x21                | X1 = (val_6 + 0) + 32;//m1              
            // 0x00AAFAD4: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.ContainsKey(key:  val_12);
            bool val_12 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.ContainsKey(key:  val_12);
            // 0x00AAFAD8: TBZ w0, #0, #0xaafaf0      | if (val_12 == false) goto label_26;     
            if(val_12 == false)
            {
                goto label_26;
            }
            // 0x00AAFADC: ADD x24, x24, #1           | X24 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x00AAFAE0: CMP x24, x25               | STATE = COMPARE((0 + 1), 0x9814C0)      
            // 0x00AAFAE4: B.LT #0xaafa00             | if (0 < 9966784) goto label_27;         
            if(val_13 < 9966784)
            {
                goto label_27;
            }
            label_20:
            // 0x00AAFAE8: LDR x0, [sp, #8]           | X0 = 0x0;                               
            val_17 = val_4;
            // 0x00AAFAEC: B #0xaafaf4                |  goto label_28;                         
            goto label_28;
            label_26:
            // 0x00AAFAF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_17 = 0;
            label_28:
            // 0x00AAFAF4: SUB sp, x29, #0x40         | SP = (1152921514954523248 - 64) = 1152921514954523184 (0x1000000268C50230);
            // 0x00AAFAF8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFAFC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFB00: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AAFB04: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AAFB08: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AAFB0C: RET                        |  return (Mihua.Asset.LoadedAssetBundle)null;
            return (Mihua.Asset.LoadedAssetBundle)val_17;
            //  |  // // {name=val_0, type=Mihua.Asset.LoadedAssetBundle, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2708 (11216648), len: 92  VirtAddr: 0x00AB2708 RVA: 0x00AB2708 token: 100693221 methodIndex: 46975 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.ABLoadOperation.ManifestOperation Initialize()
        {
            //
            // Disasemble & Code
            // 0x00AB2708: STP x20, x19, [sp, #-0x20]! | stack[1152921514954643344] = ???;  stack[1152921514954643352] = ???;  //  dest_result_addr=1152921514954643344 |  dest_result_addr=1152921514954643352
            // 0x00AB270C: STP x29, x30, [sp, #0x10]  | stack[1152921514954643360] = ???;  stack[1152921514954643368] = ???;  //  dest_result_addr=1152921514954643360 |  dest_result_addr=1152921514954643368
            // 0x00AB2710: ADD x29, sp, #0x10         | X29 = (1152921514954643344 + 16) = 1152921514954643360 (0x1000000268C6D7A0);
            // 0x00AB2714: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB2718: LDRB w8, [x19, #0x3fa]     | W8 = (bool)static_value_037333FA;       
            // 0x00AB271C: TBNZ w8, #0, #0xab2738     | if (static_value_037333FA == true) goto label_0;
            // 0x00AB2720: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00AB2724: LDR x8, [x8, #0x580]       | X8 = 0x2B8EB48;                         
            // 0x00AB2728: LDR w0, [x8]               | W0 = 0x1192;                            
            // 0x00AB272C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1192, ????);     
            // 0x00AB2730: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB2734: STRB w8, [x19, #0x3fa]     | static_value_037333FA = true;            //  dest_result_addr=57881594
            label_0:
            // 0x00AB2738: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB273C: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AB2740: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2744: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2748: TBZ w8, #0, #0xab2758      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB274C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2750: CBNZ w8, #0xab2758         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB2754: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_2:
            // 0x00AB2758: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB275C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2760: B #0xab2764                | return Mihua.Asset.AssetMgr.Initialize(manifestAssetBundleName:  null);
            return Mihua.Asset.AssetMgr.Initialize(manifestAssetBundleName:  null);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2764 (11216740), len: 1528  VirtAddr: 0x00AB2764 RVA: 0x00AB2764 token: 100693222 methodIndex: 46976 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.ABLoadOperation.ManifestOperation Initialize(string manifestAssetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            string val_5;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            // 0x00AB2764: STP d9, d8, [sp, #-0x70]!  | stack[1152921514954792256] = ???;  stack[1152921514954792264] = ???;  //  dest_result_addr=1152921514954792256 |  dest_result_addr=1152921514954792264
            // 0x00AB2768: STP x28, x27, [sp, #0x10]  | stack[1152921514954792272] = ???;  stack[1152921514954792280] = ???;  //  dest_result_addr=1152921514954792272 |  dest_result_addr=1152921514954792280
            // 0x00AB276C: STP x26, x25, [sp, #0x20]  | stack[1152921514954792288] = ???;  stack[1152921514954792296] = ???;  //  dest_result_addr=1152921514954792288 |  dest_result_addr=1152921514954792296
            // 0x00AB2770: STP x24, x23, [sp, #0x30]  | stack[1152921514954792304] = ???;  stack[1152921514954792312] = ???;  //  dest_result_addr=1152921514954792304 |  dest_result_addr=1152921514954792312
            // 0x00AB2774: STP x22, x21, [sp, #0x40]  | stack[1152921514954792320] = ???;  stack[1152921514954792328] = ???;  //  dest_result_addr=1152921514954792320 |  dest_result_addr=1152921514954792328
            // 0x00AB2778: STP x20, x19, [sp, #0x50]  | stack[1152921514954792336] = ???;  stack[1152921514954792344] = ???;  //  dest_result_addr=1152921514954792336 |  dest_result_addr=1152921514954792344
            // 0x00AB277C: STP x29, x30, [sp, #0x60]  | stack[1152921514954792352] = ???;  stack[1152921514954792360] = ???;  //  dest_result_addr=1152921514954792352 |  dest_result_addr=1152921514954792360
            // 0x00AB2780: ADD x29, sp, #0x60         | X29 = (1152921514954792256 + 96) = 1152921514954792352 (0x1000000268C91DA0);
            // 0x00AB2784: SUB sp, sp, #0x70          | SP = (1152921514954792256 - 112) = 1152921514954792144 (0x1000000268C91CD0);
            // 0x00AB2788: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB278C: LDRB w8, [x19, #0x3fb]     | W8 = (bool)static_value_037333FB;       
            // 0x00AB2790: TBNZ w8, #0, #0xab27ac     | if (static_value_037333FB == true) goto label_0;
            // 0x00AB2794: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x00AB2798: LDR x8, [x8, #0xe58]       | X8 = 0x2B8EB44;                         
            // 0x00AB279C: LDR w0, [x8]               | W0 = 0x1191;                            
            // 0x00AB27A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1191, ????);     
            // 0x00AB27A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB27A8: STRB w8, [x19, #0x3fb]     | static_value_037333FB = true;            //  dest_result_addr=57881595
            label_0:
            // 0x00AB27AC: STP xzr, xzr, [sp, #0x60]  | stack[1152921514954792240] = 0x0;  stack[1152921514954792248] = 0x0;  //  dest_result_addr=1152921514954792240 |  dest_result_addr=1152921514954792248
            // 0x00AB27B0: STP xzr, xzr, [sp, #0x50]  | stack[1152921514954792224] = 0x0;  stack[1152921514954792232] = 0x0;  //  dest_result_addr=1152921514954792224 |  dest_result_addr=1152921514954792232
            // 0x00AB27B4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00AB27B8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
            // 0x00AB27BC: LDR x0, [x8]               | X0 = typeof(ZMG);                       
            // 0x00AB27C0: STP xzr, xzr, [sp, #0x40]  | stack[1152921514954792208] = 0x0;  stack[1152921514954792216] = 0x0;  //  dest_result_addr=1152921514954792208 |  dest_result_addr=1152921514954792216
            // 0x00AB27C4: STR xzr, [sp, #0x38]       | stack[1152921514954792200] = 0x0;        //  dest_result_addr=1152921514954792200
            // 0x00AB27C8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
            // 0x00AB27CC: TBZ w8, #0, #0xab27dc      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB27D0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
            // 0x00AB27D4: CBNZ w8, #0xab27dc         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB27D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
            label_2:
            // 0x00AB27DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB27E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB27E4: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
            CSDatacfgManager val_1 = ZMG.CfgDataMgr;
            // 0x00AB27E8: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00AB27EC: CBNZ x19, #0xab27f4        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00AB27F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00AB27F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB27F8: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00AB27FC: BL #0xb46eb8               | X0 = val_1.Getasset_sharedCfgDic();     
            System.Collections.Generic.Dictionary<System.Int32, asset_sharedCfg> val_2 = val_1.Getasset_sharedCfgDic();
            // 0x00AB2800: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00AB2804: CBNZ x19, #0xab280c        | if (val_2 != null) goto label_4;        
            if(val_2 != null)
            {
                goto label_4;
            }
            // 0x00AB2808: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x00AB280C: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00AB2810: LDR x8, [x8, #0xb80]       | X8 = 1152921514954755664;               
            // 0x00AB2814: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00AB2818: STR x19, [sp, #8]          | stack[1152921514954792152] = val_2;      //  dest_result_addr=1152921514954792152
            // 0x00AB281C: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.Int32, asset_sharedCfg>::GetEnumerator();
            // 0x00AB2820: ADD x8, sp, #0x18          | X8 = (1152921514954792144 + 24) = 1152921514954792168 (0x1000000268C91CE8);
            // 0x00AB2824: BL #0x2417220              | X0 = val_2.GetEnumerator();             
            Dictionary.Enumerator<TKey, TValue> val_3 = val_2.GetEnumerator();
            // 0x00AB2828: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00AB282C: LDUR q0, [sp, #0x28]       | Q0 = val_4;                              //  find_add[1152921514954780368]
            // 0x00AB2830: LDUR q1, [sp, #0x18]       | Q1 = val_5;                              //  find_add[1152921514954780368]
            // 0x00AB2834: LDR x8, [x8, #0x20]        | X8 = 1152921514954756688;               
            // 0x00AB2838: ADD x0, sp, #0x50          | X0 = (1152921514954792144 + 80) = 1152921514954792224 (0x1000000268C91D20);
            // 0x00AB283C: LDR x1, [x8]               | X1 = public System.Boolean Dictionary.Enumerator<System.Int32, asset_sharedCfg>::MoveNext();
            // 0x00AB2840: STP q1, q0, [sp, #0x50]    | stack[1152921514954792224] = val_5;  stack[1152921514954792240] = val_4;  //  dest_result_addr=1152921514954792224 |  dest_result_addr=1152921514954792240
            // 0x00AB2844: BL #0xf2afa0               | X0 = sub_F2AFA0( ?? 0x1000000268C91D20, ????);
            // 0x00AB2848: TBZ w0, #0, #0xab2ad4      | if ((0x1000000268C91D20 & 0x1) == 0) goto label_5;
            if((1758010656 & 1) == 0)
            {
                goto label_5;
            }
            // 0x00AB284C: ADRP x27, #0x35c8000       | X27 = 56393728 (0x35C8000);             
            // 0x00AB2850: ADRP x28, #0x35ff000       | X28 = 56619008 (0x35FF000);             
            // 0x00AB2854: ADRP x19, #0x3611000       | X19 = 56692736 (0x3611000);             
            // 0x00AB2858: ADRP x25, #0x3632000       | X25 = 56827904 (0x3632000);             
            // 0x00AB285C: LDR x27, [x27, #0x270]     | X27 = 1152921504903331840;              
            // 0x00AB2860: LDR x28, [x28, #0xe50]     | X28 = 1152921514954757712;              
            // 0x00AB2864: LDR x19, [x19, #0xf08]     | X19 = 1152921514954758736;              
            // 0x00AB2868: LDR x25, [x25, #0x658]     | X25 = 1152921504889380864;              
            label_35:
            // 0x00AB286C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00AB2870: LDR x8, [x8, #0x48]        | X8 = 1152921514954759760;               
            // 0x00AB2874: ADD x0, sp, #0x50          | X0 = (1152921514954792144 + 80) = 1152921514954792224 (0x1000000268C91D20);
            // 0x00AB2878: LDR x1, [x8]               | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.Int32, asset_sharedCfg>::get_Current();
            // 0x00AB287C: BL #0xf2b1d8               | X0 = val_5.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_6 = val_5.GetHandle();
            // 0x00AB2880: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00AB2884: LDR x8, [x8, #0x50]        | X8 = 1152921514954760784;               
            // 0x00AB2888: LDR x8, [x8]               | X8 = public asset_sharedCfg System.Collections.Generic.KeyValuePair<System.Int32, asset_sharedCfg>::get_Value();
            // 0x00AB288C: STP x0, x1, [sp, #0x40]    | stack[1152921514954792208] = val_6.m_Handle;  stack[1152921514954792216] = val_6.m_Version;  //  dest_result_addr=1152921514954792208 |  dest_result_addr=1152921514954792216
            // 0x00AB2890: ADD x0, sp, #0x40          | X0 = (1152921514954792144 + 64) = 1152921514954792208 (0x1000000268C91D10);
            // 0x00AB2894: MOV x1, x8                 | X1 = 1152921514954760784 (0x1000000268C8A250);//ML01
            // 0x00AB2898: BL #0x1dc2208              | X0 = sub_1DC2208( ?? 0x1000000268C91D10, ????);
            // 0x00AB289C: LDR x8, [x27]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_23 = null;
            // 0x00AB28A0: MOV x20, x0                | X20 = 1152921514954792208 (0x1000000268C91D10);//ML01
            // 0x00AB28A4: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB28A8: TBZ w9, #0, #0xab28c0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AB28AC: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB28B0: CBNZ w9, #0xab28c0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB28B4: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB28B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB28BC: LDR x8, [x27]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_23 = null;
            label_7:
            // 0x00AB28C0: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB28C4: LDR x21, [x8, #0x28]       | X21 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AB28C8: CBNZ x20, #0xab28d0        | if (val_6.m_Handle != 0) goto label_8;  
            if(val_6.m_Handle != 0)
            {
                goto label_8;
            }
            // 0x00AB28CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_8:
            // 0x00AB28D0: LDR x22, [x20, #0x18]      | X22 = val_5;                            
            // 0x00AB28D4: CBNZ x21, #0xab28dc        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_9;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_9;
            }
            // 0x00AB28D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_9:
            // 0x00AB28DC: LDR x2, [x28]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::ContainsKey(System.String key);
            // 0x00AB28E0: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AB28E4: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x00AB28E8: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  val_5);
            bool val_7 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  val_5);
            // 0x00AB28EC: TBNZ w0, #0, #0xab2ab8     | if (val_7 == true) goto label_18;       
            if(val_7 == true)
            {
                goto label_18;
            }
            // 0x00AB28F0: LDR x0, [x27]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_24 = null;
            // 0x00AB28F4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB28F8: TBZ w8, #0, #0xab290c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AB28FC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2900: CBNZ w8, #0xab290c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AB2904: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2908: LDR x0, [x27]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_24 = null;
            label_12:
            // 0x00AB290C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2910: LDR x21, [x8, #0x28]       | X21 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AB2914: CBNZ x20, #0xab291c        | if (val_6.m_Handle != 0) goto label_13; 
            if(val_6.m_Handle != 0)
            {
                goto label_13;
            }
            // 0x00AB2918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_13:
            // 0x00AB291C: LDR x22, [x20, #0x18]      | X22 = val_5;                            
            // 0x00AB2920: CBNZ x21, #0xab2928        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_14;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_14;
            }
            // 0x00AB2924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_14:
            // 0x00AB2928: LDR x3, [x19]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::Add(System.String key, asset_sharedCfg value);
            // 0x00AB292C: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AB2930: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x00AB2934: MOV x2, x20                | X2 = 1152921514954792208 (0x1000000268C91D10);//ML01
            // 0x00AB2938: BL #0x23fd44c              | Mihua.Asset.AssetMgr.m_assetShared.Add(key:  val_5, value:  val_6.m_Handle);
            Mihua.Asset.AssetMgr.m_assetShared.Add(key:  val_5, value:  val_6.m_Handle);
            // 0x00AB293C: LDR x1, [x20, #0x18]       | X1 = val_5;                             
            System.String[] val_8 = val_5;
            // 0x00AB2940: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2944: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB2948: ADD x2, sp, #0x38          | X2 = (1152921514954792144 + 56) = 1152921514954792200 (0x1000000268C91D08);
            // 0x00AB294C: BL #0xb1bd48               | X0 = ABDepends.GetDepend(key:  0, depends: out  System.String[] val_8 = val_5);
            bool val_9 = ABDepends.GetDepend(key:  0, depends: out  val_8);
            // 0x00AB2950: TBZ w0, #0, #0xab2ab8      | if (val_9 == false) goto label_18;      
            if(val_9 == false)
            {
                goto label_18;
            }
            // 0x00AB2954: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x00AB2958: B #0xab2960                |  goto label_16;                         
            goto label_16;
            label_34:
            // 0x00AB295C: ADD w26, w26, #1           | W26 = (val_25 + 1) = val_25 (0x00000001);
            val_25 = 1;
            label_16:
            // 0x00AB2960: LDR x21, [sp, #0x38]       | X21 = 0x0;                              
            // 0x00AB2964: CBNZ x21, #0xab296c        | if (0x0 != 0) goto label_17;            
            if(0 != 0)
            {
                goto label_17;
            }
            // 0x00AB2968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_17:
            // 0x00AB296C: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB2970: CMP w26, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB2974: B.GE #0xab2ab8             | if (val_25 >= 9966784) goto label_18;   
            if(val_25 >= 9966784)
            {
                goto label_18;
            }
            // 0x00AB2978: LDR x0, [x27]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_26 = null;
            // 0x00AB297C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2980: TBZ w8, #0, #0xab2994      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00AB2984: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2988: CBNZ w8, #0xab2994         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00AB298C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2990: LDR x0, [x27]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_26 = null;
            label_20:
            // 0x00AB2994: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2998: LDR x22, [sp, #0x38]       | X22 = 0x0;                              
            // 0x00AB299C: LDR x21, [x8, #0x28]       | X21 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AB29A0: CBNZ x22, #0xab29a8        | if (0x0 != 0) goto label_21;            
            if(0 != 0)
            {
                goto label_21;
            }
            // 0x00AB29A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_21:
            // 0x00AB29A8: LDR w8, [x22, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB29AC: SXTW x23, w26              | X23 = 1 (0x00000001);                   
            // 0x00AB29B0: CMP w26, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB29B4: B.LO #0xab29c4             | if (val_25 < 9966784) goto label_22;    
            if(val_25 < 9966784)
            {
                goto label_22;
            }
            // 0x00AB29B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB29BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB29C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_22:
            // 0x00AB29C4: ADD x8, x22, x23, lsl #3   | X8 = (0 + 8);                           
            var val_10 = 0 + 8;
            // 0x00AB29C8: LDR x22, [x8, #0x20]       | X22 = (0 + 8) + 32;                     
            // 0x00AB29CC: CBNZ x21, #0xab29d4        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_23;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_23;
            }
            // 0x00AB29D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_23:
            // 0x00AB29D4: LDR x2, [x28]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::ContainsKey(System.String key);
            // 0x00AB29D8: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AB29DC: MOV x1, x22                | X1 = (0 + 8) + 32;//m1                  
            // 0x00AB29E0: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  (0 + 8) + 32);
            bool val_11 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  (0 + 8) + 32);
            // 0x00AB29E4: AND w8, w0, #1             | W8 = (val_11 & 1);                      
            bool val_12 = val_11;
            // 0x00AB29E8: TBNZ w8, #0, #0xab295c     | if ((val_11 & 1) == true) goto label_34;
            if(val_12 == true)
            {
                goto label_34;
            }
            // 0x00AB29EC: LDR x0, [x25]              | X0 = typeof(asset_sharedCfg);           
            asset_sharedCfg val_13 = null;
            // 0x00AB29F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(asset_sharedCfg), ????);
            // 0x00AB29F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB29F8: MOV x21, x0                | X21 = 1152921504889380864 (0x1000000010D72000);//ML01
            // 0x00AB29FC: BL #0xb2ff1c               | .ctor();                                
            val_13 = new asset_sharedCfg();
            // 0x00AB2A00: LDR x22, [sp, #0x38]       | X22 = 0x0;                              
            // 0x00AB2A04: CBNZ x22, #0xab2a0c        | if (0x0 != 0) goto label_25;            
            if(0 != 0)
            {
                goto label_25;
            }
            // 0x00AB2A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_25:
            // 0x00AB2A0C: LDR w8, [x22, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB2A10: CMP w26, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB2A14: B.LO #0xab2a24             | if (val_25 < 9966784) goto label_26;    
            if(val_25 < 9966784)
            {
                goto label_26;
            }
            // 0x00AB2A18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x00AB2A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2A20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_26:
            // 0x00AB2A24: ADD x8, x22, x23, lsl #3   | X8 = (0 + 8);                           
            var val_14 = 0 + 8;
            // 0x00AB2A28: LDR x22, [x8, #0x20]       | X22 = (0 + 8) + 32;                     
            // 0x00AB2A2C: CBNZ x21, #0xab2a34        | if ( != 0) goto label_27;               
            if(null != 0)
            {
                goto label_27;
            }
            // 0x00AB2A30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_27:
            // 0x00AB2A34: STR x22, [x21, #0x18]      | typeof(asset_sharedCfg).__il2cppRuntimeField_18 = (0 + 8) + 32;  //  dest_result_addr=1152921504889380888
            typeof(asset_sharedCfg).__il2cppRuntimeField_18 = (0 + 8) + 32;
            // 0x00AB2A38: CBNZ x20, #0xab2a40        | if (val_6.m_Handle != 0) goto label_28; 
            if(val_6.m_Handle != 0)
            {
                goto label_28;
            }
            // 0x00AB2A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_28:
            // 0x00AB2A40: LDR w8, [x20, #0x14]       | W8 = val_5;                             
            // 0x00AB2A44: STR w8, [x21, #0x14]       | typeof(asset_sharedCfg).__il2cppRuntimeField_14 = val_5;  //  dest_result_addr=1152921504889380884
            typeof(asset_sharedCfg).__il2cppRuntimeField_14 = val_5;
            // 0x00AB2A48: LDR x0, [x27]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_27 = null;
            // 0x00AB2A4C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2A50: TBZ w8, #0, #0xab2a64      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x00AB2A54: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2A58: CBNZ w8, #0xab2a64         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x00AB2A5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2A60: LDR x0, [x27]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_27 = null;
            label_30:
            // 0x00AB2A64: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2A68: LDR x24, [sp, #0x38]       | X24 = 0x0;                              
            // 0x00AB2A6C: LDR x22, [x8, #0x28]       | X22 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AB2A70: CBNZ x24, #0xab2a78        | if (0x0 != 0) goto label_31;            
            if(0 != 0)
            {
                goto label_31;
            }
            // 0x00AB2A74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_31:
            // 0x00AB2A78: LDR w8, [x24, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB2A7C: CMP w26, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB2A80: B.LO #0xab2a90             | if (val_25 < 9966784) goto label_32;    
            if(val_25 < 9966784)
            {
                goto label_32;
            }
            // 0x00AB2A84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2A88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2A8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_32:
            // 0x00AB2A90: ADD x8, x24, x23, lsl #3   | X8 = (0 + 8);                           
            var val_15 = 0 + 8;
            // 0x00AB2A94: LDR x23, [x8, #0x20]       | X23 = (0 + 8) + 32;                     
            // 0x00AB2A98: CBNZ x22, #0xab2aa0        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_33;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_33;
            }
            // 0x00AB2A9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_33:
            // 0x00AB2AA0: LDR x3, [x19]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::Add(System.String key, asset_sharedCfg value);
            // 0x00AB2AA4: MOV x0, x22                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AB2AA8: MOV x1, x23                | X1 = (0 + 8) + 32;//m1                  
            // 0x00AB2AAC: MOV x2, x21                | X2 = 1152921504889380864 (0x1000000010D72000);//ML01
            // 0x00AB2AB0: BL #0x23fd44c              | Mihua.Asset.AssetMgr.m_assetShared.Add(key:  (0 + 8) + 32, value:  val_13);
            Mihua.Asset.AssetMgr.m_assetShared.Add(key:  (0 + 8) + 32, value:  val_13);
            // 0x00AB2AB4: B #0xab295c                |  goto label_34;                         
            goto label_34;
            label_18:
            // 0x00AB2AB8: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00AB2ABC: LDR x8, [x8, #0x20]        | X8 = 1152921514954756688;               
            // 0x00AB2AC0: ADD x0, sp, #0x50          | X0 = (1152921514954792144 + 80) = 1152921514954792224 (0x1000000268C91D20);
            // 0x00AB2AC4: LDR x1, [x8]               | X1 = public System.Boolean Dictionary.Enumerator<System.Int32, asset_sharedCfg>::MoveNext();
            // 0x00AB2AC8: BL #0xf2afa0               | X0 = sub_F2AFA0( ?? 0x1000000268C91D20, ????);
            // 0x00AB2ACC: AND w8, w0, #1             | W8 = (1152921514954792224 & 1) = 0 (0x00000000);
            // 0x00AB2AD0: TBNZ w8, #0, #0xab286c     | if ((0x0 & 0x1) != 0) goto label_35;    
            if((0 & 1) != 0)
            {
                goto label_35;
            }
            label_5:
            // 0x00AB2AD4: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00AB2AD8: LDR x8, [x8, #0xbd8]       | X8 = 1152921514954761808;               
            // 0x00AB2ADC: ADD x0, sp, #0x50          | X0 = (1152921514954792144 + 80) = 1152921514954792224 (0x1000000268C91D20);
            // 0x00AB2AE0: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.Int32, asset_sharedCfg>::Dispose();
            // 0x00AB2AE4: BL #0xf2b248               | val_5.Dispose();                        
            val_5.Dispose();
            // 0x00AB2AE8: LDR x19, [sp, #8]          | X19 = val_2;                            
            // 0x00AB2AEC: CBNZ x19, #0xab2af4        | if (val_2 != 0) goto label_36;          
            if(val_2 != 0)
            {
                goto label_36;
            }
            // 0x00AB2AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268C91D20, ????);
            label_36:
            // 0x00AB2AF4: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00AB2AF8: LDR x8, [x8, #0x6d8]       | X8 = 1152921514954762832;               
            // 0x00AB2AFC: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00AB2B00: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, asset_sharedCfg>::Clear();
            // 0x00AB2B04: BL #0x2415b18              | val_2.Clear();                          
            val_2.Clear();
            // 0x00AB2B08: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AB2B0C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AB2B10: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
            // 0x00AB2B14: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB2B18: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB2B1C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00AB2B20: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB2B24: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB2B28: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB2B2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2B34: BL #0x20cd200              | X0 = UnityEngine.Caching.get_compressionEnabled();
            bool val_16 = UnityEngine.Caching.compressionEnabled;
            // 0x00AB2B38: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00AB2B3C: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00AB2B40: AND w9, w0, #1             | W9 = (val_16 & 1);                      
            bool val_17 = val_16;
            // 0x00AB2B44: ADD x1, sp, #0x17          | X1 = (1152921514954792144 + 23) = 1152921514954792167 (0x1000000268C91CE7);
            // 0x00AB2B48: STRB w9, [sp, #0x17]       | stack[1152921514954792167] = (val_16 & 1);  //  dest_result_addr=1152921514954792167
            // 0x00AB2B4C: LDR x8, [x8]               | X8 = typeof(System.Boolean);            
            // 0x00AB2B50: MOV x0, x8                 | X0 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x00AB2B54: BL #0x27bc028              | X0 = 1152921514954848656 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Boolean), (val_16 & 1));
            // 0x00AB2B58: MOV x20, x0                | X20 = 1152921514954848656 (0x1000000268C9F990);//ML01
            // 0x00AB2B5C: CBNZ x19, #0xab2b64        | if ( != null) goto label_37;            
            if(null != null)
            {
                goto label_37;
            }
            // 0x00AB2B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_16 & 1), ????);
            label_37:
            // 0x00AB2B64: CBZ x20, #0xab2b88         | if ((val_16 & 1) == false) goto label_39;
            if(val_17 == false)
            {
                goto label_39;
            }
            // 0x00AB2B68: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB2B6C: MOV x0, x20                | X0 = 1152921514954848656 (0x1000000268C9F990);//ML01
            // 0x00AB2B70: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB2B74: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (val_16 & 1), ????);
            // 0x00AB2B78: CBNZ x0, #0xab2b88         | if ((val_16 & 1) == true) goto label_39;
            if(val_17 == true)
            {
                goto label_39;
            }
            // 0x00AB2B7C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (val_16 & 1), ????);
            // 0x00AB2B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2B84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_16 & 1), ????);
            label_39:
            // 0x00AB2B88: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB2B8C: CBNZ w8, #0xab2b9c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_40;
            // 0x00AB2B90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (val_16 & 1), ????);
            // 0x00AB2B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2B98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (val_16 & 1), ????);
            label_40:
            // 0x00AB2B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2BA4: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = (val_16 & 1); typeof(System.Object[]).__il2cppRuntimeField_21 = 0x1000000268C9F9;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501297
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_17;
            typeof(System.Object[]).__il2cppRuntimeField_21 = 40421881;
            // 0x00AB2BA8: BL #0x20cde00              | X0 = UnityEngine.Caching.get_spaceFree();
            long val_18 = UnityEngine.Caching.spaceFree;
            // 0x00AB2BAC: ADRP x21, #0x35e6000       | X21 = 56516608 (0x35E6000);             
            // 0x00AB2BB0: LDR x21, [x21, #0xce8]     | X21 = 1152921504608444416;              
            // 0x00AB2BB4: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AB2BB8: ADD x8, x0, #0x3ff         | X8 = (val_18 + 1023);                   
            long val_19 = val_18 + 1023;
            // 0x00AB2BBC: CMP x0, #0                 | STATE = COMPARE(val_18, 0x0)            
            // 0x00AB2BC0: LDR s8, [x9, #0x4ac]       | S8 = 0.0009765625;                      
            // 0x00AB2BC4: CSEL x8, x8, x0, lt        | X8 = val_18 < 0 ? (val_18 + 1023) : val_18;
            var val_20 = (val_18 < 0) ? (val_19) : (val_18);
            // 0x00AB2BC8: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x00AB2BCC: ASR x8, x8, #0xa           | X8 = (val_18 < 0 ? (val_18 + 1023) : val_18 >> 10);
            val_20 = val_20 >> 10;
            // 0x00AB2BD0: SCVTF s0, x8               | S0 = (float)((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10));
            float val_26 = (float)val_20;
            // 0x00AB2BD4: FMUL s0, s0, s8            | S0 = ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f);
            val_26 = val_26 * 0.0009765625f;
            // 0x00AB2BD8: ADD x1, sp, #0x18          | X1 = (1152921514954792144 + 24) = 1152921514954792168 (0x1000000268C91CE8);
            // 0x00AB2BDC: STR s0, [sp, #0x18]        | val_5 = ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f);  //  dest_result_addr=1152921514954792168
            val_5 = val_26;
            // 0x00AB2BE0: BL #0x27bc028              | X0 = 1152921514954852752 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f));
            // 0x00AB2BE4: MOV x20, x0                | X20 = 1152921514954852752 (0x1000000268CA0990);//ML01
            // 0x00AB2BE8: CBZ x20, #0xab2c0c         | if (((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f) == 0) goto label_42;
            if(val_5 == 0)
            {
                goto label_42;
            }
            // 0x00AB2BEC: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB2BF0: MOV x0, x20                | X0 = 1152921514954852752 (0x1000000268CA0990);//ML01
            // 0x00AB2BF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB2BF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f), ????);
            // 0x00AB2BFC: CBNZ x0, #0xab2c0c         | if (((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f) != 0) goto label_42;
            if(val_5 != 0)
            {
                goto label_42;
            }
            // 0x00AB2C00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f), ????);
            // 0x00AB2C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2C08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f), ????);
            label_42:
            // 0x00AB2C0C: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB2C10: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AB2C14: B.HI #0xab2c24             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_43;
            // 0x00AB2C18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f), ????);
            // 0x00AB2C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2C20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f), ????);
            label_43:
            // 0x00AB2C24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2C2C: STR x20, [x19, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = ((val_18 < 0 ? (val_18 + 1023) : val_18 >> 10) * 0.0009765625f); typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_5;
            typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
            // 0x00AB2C30: BL #0x20cdda4              | X0 = UnityEngine.Caching.get_spaceOccupied();
            long val_21 = UnityEngine.Caching.spaceOccupied;
            // 0x00AB2C34: ADD x8, x0, #0x3ff         | X8 = (val_21 + 1023);                   
            long val_22 = val_21 + 1023;
            // 0x00AB2C38: CMP x0, #0                 | STATE = COMPARE(val_21, 0x0)            
            // 0x00AB2C3C: CSEL x8, x8, x0, lt        | X8 = val_21 < 0 ? (val_21 + 1023) : val_21;
            var val_23 = (val_21 < 0) ? (val_22) : (val_21);
            // 0x00AB2C40: LDR x0, [x21]              | X0 = typeof(System.Single);             
            // 0x00AB2C44: ASR x8, x8, #0xa           | X8 = (val_21 < 0 ? (val_21 + 1023) : val_21 >> 10);
            val_23 = val_23 >> 10;
            // 0x00AB2C48: SCVTF s0, x8               | S0 = (float)((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10));
            float val_27 = (float)val_23;
            // 0x00AB2C4C: FMUL s0, s0, s8            | S0 = ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f);
            val_27 = val_27 * 0.0009765625f;
            // 0x00AB2C50: ADD x1, sp, #0x10          | X1 = (1152921514954792144 + 16) = 1152921514954792160 (0x1000000268C91CE0);
            // 0x00AB2C54: STR s0, [sp, #0x10]        | stack[1152921514954792160] = ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f);  //  dest_result_addr=1152921514954792160
            // 0x00AB2C58: BL #0x27bc028              | X0 = 1152921514954856848 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f));
            // 0x00AB2C5C: MOV x20, x0                | X20 = 1152921514954856848 (0x1000000268CA1990);//ML01
            // 0x00AB2C60: CBZ x20, #0xab2c84         | if (((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f) == 0) goto label_45;
            if(val_27 == 0)
            {
                goto label_45;
            }
            // 0x00AB2C64: LDR x8, [x19]              | X8 = ;                                  
            // 0x00AB2C68: MOV x0, x20                | X0 = 1152921514954856848 (0x1000000268CA1990);//ML01
            // 0x00AB2C6C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB2C70: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f), ????);
            // 0x00AB2C74: CBNZ x0, #0xab2c84         | if (((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f) != 0) goto label_45;
            if(val_27 != 0)
            {
                goto label_45;
            }
            // 0x00AB2C78: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f), ????);
            // 0x00AB2C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2C80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f), ????);
            label_45:
            // 0x00AB2C84: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB2C88: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00AB2C8C: B.HI #0xab2c9c             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_46;
            // 0x00AB2C90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f), ????);
            // 0x00AB2C94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2C98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f), ????);
            label_46:
            // 0x00AB2C9C: STR x20, [x19, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = ((val_21 < 0 ? (val_21 + 1023) : val_21 >> 10) * 0.0009765625f); typeof(System.Object[]).__il2cppRuntimeField_34 = 0x10000002;  //  dest_result_addr=1152921504954501312 dest_result_addr=1152921504954501316
            typeof(System.Object[]).__il2cppRuntimeField_30 = val_27;
            typeof(System.Object[]).__il2cppRuntimeField_34 = 268435458;
            // 0x00AB2CA0: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00AB2CA4: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921514954776144)("缓存开启状态：{0}  未使用{1}M已使用{2}M");
            // 0x00AB2CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2CAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB2CB0: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB2CB4: LDR x1, [x8]               | X1 = "缓存开启状态：{0}  未使用{1}M已使用{2}M";      
            // 0x00AB2CB8: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "缓存开启状态：{0}  未使用{1}M已使用{2}M");
            string val_24 = EString.EFormat(format:  0, args:  "缓存开启状态：{0}  未使用{1}M已使用{2}M");
            // 0x00AB2CBC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB2CC0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB2CC4: MOV x19, x0                | X19 = val_24;//m1                       
            // 0x00AB2CC8: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB2CCC: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB2CD0: TBZ w9, #0, #0xab2ce4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_48;
            // 0x00AB2CD4: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2CD8: CBNZ w9, #0xab2ce4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
            // 0x00AB2CDC: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB2CE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_48:
            // 0x00AB2CE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2CE8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB2CEC: MOV x1, x19                | X1 = val_24;//m1                        
            // 0x00AB2CF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB2CF4: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            // 0x00AB2CF8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_24);
            EDebug.Log(message:  0, isShowStack:  val_24);
            // 0x00AB2CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB2D00: MOVZ w1, #0x640, lsl #16   | W1 = 104857600 (0x6400000);//ML01       
            // 0x00AB2D04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB2D08: BL #0x20cde5c              | UnityEngine.Caching.set_maximumAvailableDiskSpace(value:  0);
            UnityEngine.Caching.maximumAvailableDiskSpace = 0;
            // 0x00AB2D0C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x00AB2D10: LDR x8, [x8]               | X8 = 1152921504903172096;               
            // 0x00AB2D14: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation);
            object val_25 = null;
            // 0x00AB2D18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation), ????);
            // 0x00AB2D1C: MOV x19, x0                | X19 = 1152921504903172096 (0x1000000011A99000);//ML01
            // 0x00AB2D20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB2D24: STRB w20, [x19, #0x11]     | typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_11 = 0x1;  //  dest_result_addr=1152921504903172113
            typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_11 = 1;
            // 0x00AB2D28: BL #0x16f59f0              | .ctor();                                
            val_25 = new System.Object();
            // 0x00AB2D2C: STR xzr, [x19, #0x40]      | typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_40 = 0x0;  //  dest_result_addr=1152921504903172160
            typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_40 = 0;
            // 0x00AB2D30: STP xzr, xzr, [x19, #0x18] | typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_18 = 0x0;  typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_20 = 0x0;  //  dest_result_addr=1152921504903172120 |  dest_result_addr=1152921504903172128
            typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_18 = 0;
            typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation).__il2cppRuntimeField_20 = 0;
            // 0x00AB2D34: MOV x0, x19                | X0 = 1152921504903172096 (0x1000000011A99000);//ML01
            // 0x00AB2D38: SUB sp, x29, #0x60         | SP = (1152921514954792352 - 96) = 1152921514954792256 (0x1000000268C91D40);
            // 0x00AB2D3C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2D40: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2D44: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB2D48: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB2D4C: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB2D50: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00AB2D54: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00AB2D58: RET                        |  return (Mihua.Asset.ABLoadOperation.ManifestOperation)typeof(Mihua.Asset.ABLoadOperation.ManifestOperationSimulation);
            return (Mihua.Asset.ABLoadOperation.ManifestOperation)val_25;
            //  |  // // {name=val_0, type=Mihua.Asset.ABLoadOperation.ManifestOperation, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2D5C (11218268), len: 152  VirtAddr: 0x00AB2D5C RVA: 0x00AB2D5C token: 100693223 methodIndex: 46977 delegateWrapperIndex: 0 methodInvoker: 0
        protected static void LoadAssetBundle(string assetBundleName)
        {
            //
            // Disasemble & Code
            // 0x00AB2D5C: STP x20, x19, [sp, #-0x20]! | stack[1152921514954937104] = ???;  stack[1152921514954937112] = ???;  //  dest_result_addr=1152921514954937104 |  dest_result_addr=1152921514954937112
            // 0x00AB2D60: STP x29, x30, [sp, #0x10]  | stack[1152921514954937120] = ???;  stack[1152921514954937128] = ???;  //  dest_result_addr=1152921514954937120 |  dest_result_addr=1152921514954937128
            // 0x00AB2D64: ADD x29, sp, #0x10         | X29 = (1152921514954937104 + 16) = 1152921514954937120 (0x1000000268CB5320);
            // 0x00AB2D68: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB2D6C: LDRB w8, [x20, #0x3fc]     | W8 = (bool)static_value_037333FC;       
            // 0x00AB2D70: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB2D74: TBNZ w8, #0, #0xab2d90     | if (static_value_037333FC == true) goto label_0;
            // 0x00AB2D78: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00AB2D7C: LDR x8, [x8, #0xa8]        | X8 = 0x2B8EB54;                         
            // 0x00AB2D80: LDR w0, [x8]               | W0 = 0x1195;                            
            // 0x00AB2D84: BL #0x2782188              | X0 = sub_2782188( ?? 0x1195, ????);     
            // 0x00AB2D88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB2D8C: STRB w8, [x20, #0x3fc]     | static_value_037333FC = true;            //  dest_result_addr=57881596
            label_0:
            // 0x00AB2D90: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB2D94: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB2D98: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2D9C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2DA0: TBZ w8, #0, #0xab2db0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB2DA4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2DA8: CBNZ w8, #0xab2db0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB2DAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_2:
            // 0x00AB2DB0: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2DB4: BL #0xab2df4               | X0 = Mihua.Asset.AssetMgr.LoadAssetBundleInternal(assetBundleName:  null);
            bool val_1 = Mihua.Asset.AssetMgr.LoadAssetBundleInternal(assetBundleName:  null);
            // 0x00AB2DB8: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00AB2DBC: TBZ w8, #0, #0xab2dcc      | if ((val_1 & 1) == false) goto label_3; 
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x00AB2DC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2DC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2DC8: RET                        |  return;                                
            return;
            label_3:
            // 0x00AB2DCC: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB2DD0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2DD4: TBZ w8, #0, #0xab2de4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00AB2DD8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2DDC: CBNZ w8, #0xab2de4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00AB2DE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_5:
            // 0x00AB2DE4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB2DE8: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2DEC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB2DF0: B #0xab30d4                | Mihua.Asset.AssetMgr.LoadDependencies(assetBundleName:  null); return;
            Mihua.Asset.AssetMgr.LoadDependencies(assetBundleName:  null);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB2DF4 (11218420), len: 736  VirtAddr: 0x00AB2DF4 RVA: 0x00AB2DF4 token: 100693224 methodIndex: 46978 delegateWrapperIndex: 0 methodInvoker: 0
        protected static bool LoadAssetBundleInternal(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            System.Collections.Generic.Dictionary<System.String, System.Int32> val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            // 0x00AB2DF4: STP x22, x21, [sp, #-0x30]! | stack[1152921514955057280] = ???;  stack[1152921514955057288] = ???;  //  dest_result_addr=1152921514955057280 |  dest_result_addr=1152921514955057288
            // 0x00AB2DF8: STP x20, x19, [sp, #0x10]  | stack[1152921514955057296] = ???;  stack[1152921514955057304] = ???;  //  dest_result_addr=1152921514955057296 |  dest_result_addr=1152921514955057304
            // 0x00AB2DFC: STP x29, x30, [sp, #0x20]  | stack[1152921514955057312] = ???;  stack[1152921514955057320] = ???;  //  dest_result_addr=1152921514955057312 |  dest_result_addr=1152921514955057320
            // 0x00AB2E00: ADD x29, sp, #0x20         | X29 = (1152921514955057280 + 32) = 1152921514955057312 (0x1000000268CD28A0);
            // 0x00AB2E04: SUB sp, sp, #0x10          | SP = (1152921514955057280 - 16) = 1152921514955057264 (0x1000000268CD2870);
            // 0x00AB2E08: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB2E0C: LDRB w8, [x20, #0x3fd]     | W8 = (bool)static_value_037333FD;       
            // 0x00AB2E10: MOV x19, x1                | X19 = X1;//m1                           
            val_13 = X1;
            // 0x00AB2E14: TBNZ w8, #0, #0xab2e30     | if (static_value_037333FD == true) goto label_0;
            // 0x00AB2E18: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00AB2E1C: LDR x8, [x8, #0x378]       | X8 = 0x2B8EB58;                         
            // 0x00AB2E20: LDR w0, [x8]               | W0 = 0x1196;                            
            // 0x00AB2E24: BL #0x2782188              | X0 = sub_2782188( ?? 0x1196, ????);     
            // 0x00AB2E28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB2E2C: STRB w8, [x20, #0x3fd]     | static_value_037333FD = true;            //  dest_result_addr=57881597
            label_0:
            // 0x00AB2E30: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB2E34: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            val_14 = 1152921504903331840;
            // 0x00AB2E38: STR xzr, [sp, #8]          | stack[1152921514955057272] = 0x0;        //  dest_result_addr=1152921514955057272
            Mihua.Asset.LoadedAssetBundle val_1 = 0;
            // 0x00AB2E3C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_15 = null;
            // 0x00AB2E40: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2E44: TBZ w8, #0, #0xab2e58      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB2E48: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2E4C: CBNZ w8, #0xab2e58         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB2E50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2E54: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_15 = null;
            label_2:
            // 0x00AB2E58: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2E5C: LDR x20, [x8, #0x40]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB2E60: CBNZ x20, #0xab2e68        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_3;
            }
            // 0x00AB2E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB2E68: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00AB2E6C: LDR x8, [x8, #0xe20]       | X8 = 1152921514954510240;               
            // 0x00AB2E70: ADD x2, sp, #8             | X2 = (1152921514955057264 + 8) = 1152921514955057272 (0x1000000268CD2878);
            // 0x00AB2E74: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB2E78: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2E7C: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::TryGetValue(System.String key, out Mihua.Asset.LoadedAssetBundle value);
            // 0x00AB2E80: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.TryGetValue(key:  val_13, value: out  Mihua.Asset.LoadedAssetBundle val_1 = 0);
            bool val_2 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.TryGetValue(key:  val_13, value: out  val_1);
            // 0x00AB2E84: TBZ w0, #0, #0xab2e98      | if (val_2 == false) goto label_4;       
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x00AB2E88: LDR x19, [sp, #8]          | X19 = 0x0;                              
            val_13 = val_1;
            // 0x00AB2E8C: CBZ x19, #0xab3058         | if (0x0 == 0) goto label_5;             
            if(val_13 == 0)
            {
                goto label_5;
            }
            // 0x00AB2E90: LDR w20, [x19, #0x18]!     | W20 = 0x9814C0;                         
            val_16 = 9966784;
            // 0x00AB2E94: B #0xab3068                |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x00AB2E98: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_17 = null;
            // 0x00AB2E9C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2EA0: TBZ w8, #0, #0xab2eb4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00AB2EA4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2EA8: CBNZ w8, #0xab2eb4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00AB2EAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2EB0: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_17 = null;
            label_8:
            // 0x00AB2EB4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2EB8: LDR x20, [x8, #0x48]       | X20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB2EBC: CBNZ x20, #0xab2ec4        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_9;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_9;
            }
            // 0x00AB2EC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_9:
            // 0x00AB2EC4: ADRP x22, #0x3653000       | X22 = 56963072 (0x3653000);             
            // 0x00AB2EC8: LDR x22, [x22, #0x10]      | X22 = 1152921510807693968;              
            // 0x00AB2ECC: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB2ED0: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2ED4: LDR x2, [x22]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::ContainsKey(System.String key);
            // 0x00AB2ED8: BL #0x23f582c              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.ContainsKey(key:  val_13);
            bool val_3 = Mihua.Asset.AssetMgr.m_RefCountDic.ContainsKey(key:  val_13);
            // 0x00AB2EDC: LDR x8, [x21]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_18 = null;
            // 0x00AB2EE0: ADD x9, x8, #0x109         | X9 = (val_18 + 265) = 1152921504903332105 (0x1000000011AC0109);
            // 0x00AB2EE4: LDRH w9, [x9]              | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_109;
            // 0x00AB2EE8: AND w9, w9, #0x100         | W9 = (Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256);
            // 0x00AB2EEC: AND w9, w9, #0xffff        | W9 = ((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00AB2EF0: TBZ w0, #0, #0xab2f38      | if (val_3 == false) goto label_10;      
            if(val_3 == false)
            {
                goto label_10;
            }
            // 0x00AB2EF4: CBZ w9, #0xab2f0c          | if (((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_12;
            // 0x00AB2EF8: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2EFC: CBNZ w9, #0xab2f0c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AB2F00: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB2F04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2F08: LDR x8, [x21]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_19 = null;
            label_12:
            // 0x00AB2F0C: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2F10: LDR x20, [x8, #0x48]       | X20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            val_20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB2F14: CBZ x20, #0xab3078         | if (Mihua.Asset.AssetMgr.m_RefCountDic == null) goto label_13;
            if(val_20 == null)
            {
                goto label_13;
            }
            // 0x00AB2F18: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB2F1C: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
            // 0x00AB2F20: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB2F24: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2F28: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
            // 0x00AB2F2C: BL #0x23f40a8              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.get_Item(key:  val_13);
            int val_6 = val_20.Item[val_13];
            // 0x00AB2F30: MOV w21, w0                | W21 = val_6;//m1                        
            val_14 = val_6;
            // 0x00AB2F34: B #0xab30a0                |  goto label_14;                         
            goto label_14;
            label_10:
            // 0x00AB2F38: CBZ w9, #0xab2f50          | if (((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_16;
            // 0x00AB2F3C: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2F40: CBNZ w9, #0xab2f50         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00AB2F44: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB2F48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2F4C: LDR x8, [x21]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_21 = null;
            label_16:
            // 0x00AB2F50: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2F54: LDR x20, [x8, #0x48]       | X20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB2F58: CBNZ x20, #0xab2f60        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_17;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_17;
            }
            // 0x00AB2F5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_17:
            // 0x00AB2F60: LDR x2, [x22]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::ContainsKey(System.String key);
            // 0x00AB2F64: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB2F68: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2F6C: BL #0x23f582c              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.ContainsKey(key:  val_13);
            bool val_7 = Mihua.Asset.AssetMgr.m_RefCountDic.ContainsKey(key:  val_13);
            // 0x00AB2F70: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x00AB2F74: TBNZ w8, #0, #0xab2fc0     | if ((val_7 & 1) == true) goto label_18; 
            if(val_8 == true)
            {
                goto label_18;
            }
            // 0x00AB2F78: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_22 = null;
            // 0x00AB2F7C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2F80: TBZ w8, #0, #0xab2f94      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00AB2F84: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2F88: CBNZ w8, #0xab2f94         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00AB2F8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2F90: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_22 = null;
            label_20:
            // 0x00AB2F94: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2F98: LDR x20, [x8, #0x48]       | X20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB2F9C: CBNZ x20, #0xab2fa4        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_21;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_21;
            }
            // 0x00AB2FA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_21:
            // 0x00AB2FA4: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00AB2FA8: LDR x8, [x8, #0xfb0]       | X8 = 1152921509743365200;               
            // 0x00AB2FAC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB2FB0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB2FB4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2FB8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
            // 0x00AB2FBC: BL #0x23f5288              | Mihua.Asset.AssetMgr.m_RefCountDic.Add(key:  val_13, value:  1);
            Mihua.Asset.AssetMgr.m_RefCountDic.Add(key:  val_13, value:  1);
            label_18:
            // 0x00AB2FC0: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_23 = null;
            // 0x00AB2FC4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB2FC8: TBZ w8, #0, #0xab2fdc      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00AB2FCC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB2FD0: CBNZ w8, #0xab2fdc         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00AB2FD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB2FD8: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_23 = null;
            label_23:
            // 0x00AB2FDC: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB2FE0: LDR x20, [x8, #0x88]       | X20 = Mihua.Asset.AssetMgr.m_WaitList;  
            // 0x00AB2FE4: CBNZ x20, #0xab2fec        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_24;
            if(Mihua.Asset.AssetMgr.m_WaitList != null)
            {
                goto label_24;
            }
            // 0x00AB2FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_24:
            // 0x00AB2FEC: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x00AB2FF0: LDR x8, [x8, #0xf00]       | X8 = 1152921510891359184;               
            // 0x00AB2FF4: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB2FF8: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB2FFC: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
            // 0x00AB3000: BL #0x25ead74              | X0 = Mihua.Asset.AssetMgr.m_WaitList.Contains(item:  val_13);
            bool val_9 = Mihua.Asset.AssetMgr.m_WaitList.Contains(item:  val_13);
            // 0x00AB3004: AND w8, w0, #1             | W8 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x00AB3008: TBNZ w8, #0, #0xab3050     | if ((val_9 & 1) == true) goto label_25; 
            if(val_10 == true)
            {
                goto label_25;
            }
            // 0x00AB300C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_24 = null;
            // 0x00AB3010: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3014: TBZ w8, #0, #0xab3028      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x00AB3018: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB301C: CBNZ w8, #0xab3028         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x00AB3020: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3024: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_24 = null;
            label_27:
            // 0x00AB3028: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB302C: LDR x20, [x8, #0x88]       | X20 = Mihua.Asset.AssetMgr.m_WaitList;  
            // 0x00AB3030: CBNZ x20, #0xab3038        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_28;
            if(Mihua.Asset.AssetMgr.m_WaitList != null)
            {
                goto label_28;
            }
            // 0x00AB3034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_28:
            // 0x00AB3038: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB303C: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x00AB3040: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB3044: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB3048: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB304C: BL #0x25ea480              | Mihua.Asset.AssetMgr.m_WaitList.Add(item:  val_13);
            Mihua.Asset.AssetMgr.m_WaitList.Add(item:  val_13);
            label_25:
            // 0x00AB3050: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_25 = 0;
            // 0x00AB3054: B #0xab30c0                |  goto label_30;                         
            goto label_30;
            label_5:
            // 0x00AB3058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00AB305C: ORR w19, wzr, #0x18        | W19 = 24(0x18);                         
            val_13 = 24;
            // 0x00AB3060: LDR w20, [x19]             | W20 = 0x9814C0;                         
            val_16 = 9966784;
            // 0x00AB3064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00AB3068: ADD w8, w20, #1            | W8 = (val_16 + 1) = 9966785 (0x009814C1);
            // 0x00AB306C: STR w8, [x19]              | mem[24] = 0x9814C1;                      //  dest_result_addr=24
            mem[24] = 9966785;
            // 0x00AB3070: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_25 = 1;
            // 0x00AB3074: B #0xab30c0                |  goto label_30;                         
            goto label_30;
            label_13:
            // 0x00AB3078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB307C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB3080: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
            // 0x00AB3084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3088: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB308C: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
            // 0x00AB3090: BL #0x23f40a8              | X0 = 0.get_Item(key:  val_13);          
            int val_11 = 0.Item[val_13];
            // 0x00AB3094: MOV w21, w0                | W21 = val_11;//m1                       
            val_14 = val_11;
            // 0x00AB3098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x00AB309C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_14:
            // 0x00AB30A0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AB30A4: LDR x8, [x8, #0x6b0]       | X8 = 1152921510000499136;               
            // 0x00AB30A8: ADD w2, w21, #1            | W2 = (val_11 + 1);                      
            int val_12 = val_14 + 1;
            // 0x00AB30AC: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x00AB30B0: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB30B4: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::set_Item(System.String key, System.Int32 value);
            // 0x00AB30B8: BL #0x23f4398              | val_20.set_Item(key:  val_13, value:  int val_12 = val_14 + 1);
            val_20.set_Item(key:  val_13, value:  val_12);
            // 0x00AB30BC: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_25 = 1;
            label_30:
            // 0x00AB30C0: SUB sp, x29, #0x20         | SP = (1152921514955057312 - 32) = 1152921514955057280 (0x1000000268CD2880);
            // 0x00AB30C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB30C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB30CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB30D0: RET                        |  return (System.Boolean)true;           
            return (bool)val_25;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB3258 (11219544), len: 1100  VirtAddr: 0x00AB3258 RVA: 0x00AB3258 token: 100693225 methodIndex: 46979 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool LoadNext()
        {
            //
            // Disasemble & Code
            //  | 
            var val_17;
            //  | 
            System.Collections.Generic.List<System.String> val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            System.Collections.Generic.List<System.String> val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            // 0x00AB3258: STP x24, x23, [sp, #-0x40]! | stack[1152921514955212384] = ???;  stack[1152921514955212392] = ???;  //  dest_result_addr=1152921514955212384 |  dest_result_addr=1152921514955212392
            // 0x00AB325C: STP x22, x21, [sp, #0x10]  | stack[1152921514955212400] = ???;  stack[1152921514955212408] = ???;  //  dest_result_addr=1152921514955212400 |  dest_result_addr=1152921514955212408
            // 0x00AB3260: STP x20, x19, [sp, #0x20]  | stack[1152921514955212416] = ???;  stack[1152921514955212424] = ???;  //  dest_result_addr=1152921514955212416 |  dest_result_addr=1152921514955212424
            // 0x00AB3264: STP x29, x30, [sp, #0x30]  | stack[1152921514955212432] = ???;  stack[1152921514955212440] = ???;  //  dest_result_addr=1152921514955212432 |  dest_result_addr=1152921514955212440
            // 0x00AB3268: ADD x29, sp, #0x30         | X29 = (1152921514955212384 + 48) = 1152921514955212432 (0x1000000268CF8690);
            // 0x00AB326C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB3270: LDRB w8, [x19, #0x3fe]     | W8 = (bool)static_value_037333FE;       
            // 0x00AB3274: TBNZ w8, #0, #0xab3290     | if (static_value_037333FE == true) goto label_0;
            // 0x00AB3278: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x00AB327C: LDR x8, [x8, #0xfb0]       | X8 = 0x2B8EB64;                         
            // 0x00AB3280: LDR w0, [x8]               | W0 = 0x1199;                            
            // 0x00AB3284: BL #0x2782188              | X0 = sub_2782188( ?? 0x1199, ????);     
            // 0x00AB3288: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB328C: STRB w8, [x19, #0x3fe]     | static_value_037333FE = true;            //  dest_result_addr=57881598
            label_0:
            // 0x00AB3290: ADRP x22, #0x35c8000       | X22 = 56393728 (0x35C8000);             
            // 0x00AB3294: LDR x22, [x22, #0x270]     | X22 = 1152921504903331840;              
            // 0x00AB3298: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_17 = null;
            // 0x00AB329C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB32A0: TBZ w8, #0, #0xab32b4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB32A4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB32A8: CBNZ w8, #0xab32b4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB32AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB32B0: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_17 = null;
            label_2:
            // 0x00AB32B4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB32B8: LDR x19, [x8, #0x90]       | X19 = Mihua.Asset.AssetMgr.m_LoadingList;
            val_18 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB32BC: CBNZ x19, #0xab32c4        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_3;
            if(val_18 != null)
            {
                goto label_3;
            }
            // 0x00AB32C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB32C4: ADRP x20, #0x35fc000       | X20 = 56606720 (0x35FC000);             
            // 0x00AB32C8: LDR x20, [x20, #0xb58]     | X20 = 1152921510022759280;              
            // 0x00AB32CC: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB32D0: LDR x1, [x20]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB32D4: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Count();
            int val_1 = val_18.Count;
            // 0x00AB32D8: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB32DC: LDR x9, [x8, #0xa0]        | X9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB32E0: LDR w10, [x9, #0x80]       | W10 = Mihua.Asset.AssetMgr.maxLoadingCount;
            // 0x00AB32E4: CMP w0, w10                | STATE = COMPARE(val_1, Mihua.Asset.AssetMgr.maxLoadingCount)
            // 0x00AB32E8: B.GE #0xab3510             | if (val_1 >= Mihua.Asset.AssetMgr.maxLoadingCount) goto label_8;
            if(val_1 >= Mihua.Asset.AssetMgr.maxLoadingCount)
            {
                goto label_8;
            }
            // 0x00AB32EC: LDRB w10, [x8, #0x10a]     | W10 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB32F0: TBZ w10, #0, #0xab330c     | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB32F4: LDR w10, [x8, #0xbc]       | W10 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB32F8: CBNZ w10, #0xab330c        | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB32FC: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB3300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3304: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3308: LDR x9, [x8, #0xa0]        | X9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            label_6:
            // 0x00AB330C: LDR x19, [x9, #0x88]       | X19 = Mihua.Asset.AssetMgr.m_WaitList;  
            val_18 = Mihua.Asset.AssetMgr.m_WaitList;
            // 0x00AB3310: CBNZ x19, #0xab3318        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_7;
            if(val_18 != null)
            {
                goto label_7;
            }
            // 0x00AB3314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_7:
            // 0x00AB3318: LDR x1, [x20]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB331C: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB3320: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.m_WaitList.get_Count();
            int val_2 = val_18.Count;
            // 0x00AB3324: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
            // 0x00AB3328: B.LT #0xab3510             | if (val_2 < 1) goto label_8;            
            if(val_2 < 1)
            {
                goto label_8;
            }
            // 0x00AB332C: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_20 = null;
            // 0x00AB3330: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3334: TBZ w8, #0, #0xab3348      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AB3338: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB333C: CBNZ w8, #0xab3348         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AB3340: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3344: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_20 = null;
            label_10:
            // 0x00AB3348: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB334C: LDR x19, [x8, #0x88]       | X19 = Mihua.Asset.AssetMgr.m_WaitList;  
            // 0x00AB3350: CBNZ x19, #0xab3358        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_11;
            if(Mihua.Asset.AssetMgr.m_WaitList != null)
            {
                goto label_11;
            }
            // 0x00AB3354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_11:
            // 0x00AB3358: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x00AB335C: LDR x8, [x8, #0xb50]       | X8 = 1152921510890998992;               
            // 0x00AB3360: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3364: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB3368: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB336C: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_WaitList.get_Item(index:  0);
            string val_3 = Mihua.Asset.AssetMgr.m_WaitList.Item[0];
            // 0x00AB3370: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3374: MOV x19, x0                | X19 = val_3;//m1                        
            val_18 = val_3;
            // 0x00AB3378: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB337C: LDR x20, [x8, #0x88]       | X20 = Mihua.Asset.AssetMgr.m_WaitList;  
            // 0x00AB3380: CBNZ x20, #0xab3388        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_12;
            if(Mihua.Asset.AssetMgr.m_WaitList != null)
            {
                goto label_12;
            }
            // 0x00AB3384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_12:
            // 0x00AB3388: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00AB338C: LDR x8, [x8, #0xa30]       | X8 = 1152921510892175824;               
            // 0x00AB3390: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3394: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB3398: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::RemoveAt(int index);
            // 0x00AB339C: BL #0x25ed00c              | Mihua.Asset.AssetMgr.m_WaitList.RemoveAt(index:  0);
            Mihua.Asset.AssetMgr.m_WaitList.RemoveAt(index:  0);
            // 0x00AB33A0: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB33A4: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00AB33A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB33AC: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB33B0: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_4 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB33B4: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x00AB33B8: CBNZ x20, #0xab33c0        | if (val_4 != null) goto label_13;       
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x00AB33BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x00AB33C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB33C4: MOV x0, x20                | X0 = val_4;//m1                         
            // 0x00AB33C8: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB33CC: BL #0xb42cd0               | X0 = val_4.GetIsCompressByABName(abName:  val_18);
            bool val_5 = val_4.GetIsCompressByABName(abName:  val_18);
            // 0x00AB33D0: ADRP x20, #0x35ef000       | X20 = 56553472 (0x35EF000);             
            // 0x00AB33D4: LDR x20, [x20, #0xde8]     | X20 = 1152921504911265792;              
            // 0x00AB33D8: LDR x8, [x20]              | X8 = typeof(Loader.PathUtil);           
            val_21 = null;
            // 0x00AB33DC: ADD x9, x8, #0x109         | X9 = (val_21 + 265) = 1152921504911266057 (0x1000000012251109);
            // 0x00AB33E0: LDRH w9, [x9]              | W9 = Loader.PathUtil.__il2cppRuntimeField_109;
            // 0x00AB33E4: AND w9, w9, #0x100         | W9 = (Loader.PathUtil.__il2cppRuntimeField_109 & 256);
            // 0x00AB33E8: AND w9, w9, #0xffff        | W9 = ((Loader.PathUtil.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00AB33EC: TBZ w0, #0, #0xab3518      | if (val_5 == false) goto label_14;      
            if(val_5 == false)
            {
                goto label_14;
            }
            // 0x00AB33F0: CBZ w9, #0xab3404          | if (((Loader.PathUtil.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_16;
            // 0x00AB33F4: LDR w9, [x8, #0xbc]        | W9 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB33F8: CBNZ w9, #0xab3404         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00AB33FC: MOV x0, x8                 | X0 = 1152921504911265792 (0x1000000012251000);//ML01
            // 0x00AB3400: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
            label_16:
            // 0x00AB3404: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3408: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB340C: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB3410: BL #0xdbca3c               | X0 = Loader.PathUtil.CheckPath(path:  0);
            string val_8 = Loader.PathUtil.CheckPath(path:  0);
            // 0x00AB3414: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AB3418: LDR x8, [x8, #0xbb0]       | X8 = (string**)(1152921514955173712)("start load at path:{0}");
            // 0x00AB341C: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00AB3420: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3424: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3428: LDR x1, [x8]               | X1 = "start load at path:{0}";          
            // 0x00AB342C: MOV x2, x20                | X2 = val_8;//m1                         
            // 0x00AB3430: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "start load at path:{0}");
            string val_9 = EString.EFormat(format:  0, arg0:  "start load at path:{0}");
            // 0x00AB3434: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB3438: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB343C: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x00AB3440: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB3444: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB3448: TBZ w9, #0, #0xab345c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x00AB344C: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3450: CBNZ w9, #0xab345c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x00AB3454: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB3458: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_18:
            // 0x00AB345C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3460: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3464: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB3468: MOV x1, x21                | X1 = val_9;//m1                         
            // 0x00AB346C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_9);
            EDebug.Log(message:  0, isShowStack:  val_9);
            // 0x00AB3470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3474: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB3478: MOV x1, x20                | X1 = val_8;//m1                         
            // 0x00AB347C: BL #0x2757820              | X0 = UnityEngine.Networking.UnityWebRequest.GetAssetBundle(uri:  0);
            UnityEngine.Networking.UnityWebRequest val_10 = UnityEngine.Networking.UnityWebRequest.GetAssetBundle(uri:  0);
            // 0x00AB3480: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_22 = null;
            // 0x00AB3484: MOV x20, x0                | X20 = val_10;//m1                       
            // 0x00AB3488: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB348C: TBZ w9, #0, #0xab34a4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00AB3490: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3494: CBNZ w9, #0xab34a4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00AB3498: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB349C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB34A0: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            val_22 = null;
            label_20:
            // 0x00AB34A4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB34A8: LDR x21, [x8, #0x90]       | X21 = Mihua.Asset.AssetMgr.m_LoadingList;
            val_23 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB34AC: CBNZ x21, #0xab34b4        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_21;
            if(val_23 != null)
            {
                goto label_21;
            }
            // 0x00AB34B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_21:
            // 0x00AB34B4: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB34B8: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x00AB34BC: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB34C0: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB34C4: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB34C8: BL #0x25ea480              | Mihua.Asset.AssetMgr.m_LoadingList.Add(item:  val_18);
            val_23.Add(item:  val_18);
            // 0x00AB34CC: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB34D0: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB34D4: LDR x19, [x8, #0x98]       | X19 = Mihua.Asset.AssetMgr.m_WWWList;   
            val_18 = Mihua.Asset.AssetMgr.m_WWWList;
            // 0x00AB34D8: CBNZ x19, #0xab34e0        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_22;
            if(val_18 != null)
            {
                goto label_22;
            }
            // 0x00AB34DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_LoadingList, ????);
            label_22:
            // 0x00AB34E0: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00AB34E4: LDR x8, [x8, #0xaf8]       | X8 = 1152921514955182016;               
            // 0x00AB34E8: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB34EC: MOV x1, x20                | X1 = val_10;//m1                        
            // 0x00AB34F0: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::Add(UnityEngine.Networking.UnityWebRequest item);
            // 0x00AB34F4: BL #0x25ea480              | Mihua.Asset.AssetMgr.m_WWWList.Add(item:  val_10);
            val_18.Add(item:  val_10);
            // 0x00AB34F8: CBNZ x20, #0xab3500        | if (val_10 != null) goto label_23;      
            if(val_10 != null)
            {
                goto label_23;
            }
            // 0x00AB34FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_WWWList, ????);
            label_23:
            // 0x00AB3500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3504: MOV x0, x20                | X0 = val_10;//m1                        
            // 0x00AB3508: BL #0x2756374              | X0 = val_10.SendWebRequest();           
            UnityEngine.Networking.UnityWebRequestAsyncOperation val_11 = val_10.SendWebRequest();
            // 0x00AB350C: B #0xab368c                |  goto label_24;                         
            goto label_24;
            label_8:
            // 0x00AB3510: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_24 = 0;
            // 0x00AB3514: B #0xab3690                |  goto label_25;                         
            goto label_25;
            label_14:
            // 0x00AB3518: CBZ w9, #0xab3530          | if (((Loader.PathUtil.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_27;
            // 0x00AB351C: LDR w9, [x8, #0xbc]        | W9 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3520: CBNZ w9, #0xab3530         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x00AB3524: MOV x0, x8                 | X0 = 1152921504911265792 (0x1000000012251000);//ML01
            // 0x00AB3528: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
            // 0x00AB352C: LDR x8, [x20]              | X8 = typeof(Loader.PathUtil);           
            val_21 = null;
            label_27:
            // 0x00AB3530: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00AB3534: LDR x8, [x8, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB3538: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x00AB353C: LDR x20, [x8, #0x28]       | X20 = Loader.PathUtil.persistentDataPath;
            // 0x00AB3540: LDR x0, [x9]               | X0 = typeof(System.String);             
            // 0x00AB3544: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB3548: TBZ w8, #0, #0xab3558      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x00AB354C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3550: CBNZ w8, #0xab3558         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x00AB3554: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_29:
            // 0x00AB3558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB355C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3560: MOV x1, x20                | X1 = Loader.PathUtil.persistentDataPath;//m1
            // 0x00AB3564: MOV x2, x19                | X2 = val_3;//m1                         
            // 0x00AB3568: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
            string val_12 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
            // 0x00AB356C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AB3570: LDR x8, [x8, #0xbb0]       | X8 = (string**)(1152921514955173712)("start load at path:{0}");
            // 0x00AB3574: MOV x20, x0                | X20 = val_12;//m1                       
            // 0x00AB3578: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB357C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3580: LDR x1, [x8]               | X1 = "start load at path:{0}";          
            // 0x00AB3584: MOV x2, x20                | X2 = val_12;//m1                        
            // 0x00AB3588: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "start load at path:{0}");
            string val_13 = EString.EFormat(format:  0, arg0:  "start load at path:{0}");
            // 0x00AB358C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB3590: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB3594: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x00AB3598: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB359C: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB35A0: TBZ w9, #0, #0xab35b4      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x00AB35A4: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB35A8: CBNZ w9, #0xab35b4         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x00AB35AC: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB35B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_31:
            // 0x00AB35B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB35B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB35BC: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x00AB35C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB35C4: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            // 0x00AB35C8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_13);
            EDebug.Log(message:  0, isShowStack:  val_13);
            // 0x00AB35CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB35D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB35D4: MOV x1, x20                | X1 = val_12;//m1                        
            // 0x00AB35D8: BL #0x20c9290              | X0 = UnityEngine.AssetBundle.LoadFromFile(path:  0);
            UnityEngine.AssetBundle val_14 = UnityEngine.AssetBundle.LoadFromFile(path:  0);
            // 0x00AB35DC: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00AB35E0: LDR x8, [x8, #0xf40]       | X8 = 1152921504903225344;               
            // 0x00AB35E4: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00AB35E8: LDR x8, [x8]               | X8 = typeof(Mihua.Asset.LoadedAssetBundle);
            // 0x00AB35EC: MOV x0, x8                 | X0 = 1152921504903225344 (0x1000000011AA6000);//ML01
            object val_15 = null;
            // 0x00AB35F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.LoadedAssetBundle), ????);
            // 0x00AB35F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB35F8: MOV x20, x0                | X20 = 1152921504903225344 (0x1000000011AA6000);//ML01
            // 0x00AB35FC: BL #0x16f59f0              | .ctor();                                
            val_15 = new System.Object();
            // 0x00AB3600: STR w23, [x20, #0x18]      | typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = 0x1;  //  dest_result_addr=1152921504903225368
            typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = 1;
            // 0x00AB3604: STR x21, [x20, #0x10]      | typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_10 = val_14;  //  dest_result_addr=1152921504903225360
            typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_10 = val_14;
            // 0x00AB3608: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_25 = null;
            // 0x00AB360C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3610: TBZ w8, #0, #0xab3624      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x00AB3614: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3618: CBNZ w8, #0xab3624         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x00AB361C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3620: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_25 = null;
            label_33:
            // 0x00AB3624: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3628: LDR x21, [x8, #0x48]       | X21 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB362C: CBNZ x21, #0xab3634        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_34;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_34;
            }
            // 0x00AB3630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_34:
            // 0x00AB3634: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB3638: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
            // 0x00AB363C: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB3640: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB3644: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
            // 0x00AB3648: BL #0x23f40a8              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.get_Item(key:  val_18);
            int val_16 = Mihua.Asset.AssetMgr.m_RefCountDic.Item[val_18];
            // 0x00AB364C: MOV w21, w0                | W21 = val_16;//m1                       
            // 0x00AB3650: CBNZ x20, #0xab3658        | if ( != 0) goto label_35;               
            if(null != 0)
            {
                goto label_35;
            }
            // 0x00AB3654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_35:
            // 0x00AB3658: STR w21, [x20, #0x18]      | typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = val_16;  //  dest_result_addr=1152921504903225368
            typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = val_16;
            // 0x00AB365C: LDR x8, [x22]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3660: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3664: LDR x21, [x8, #0x40]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            val_23 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB3668: CBNZ x21, #0xab3670        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_36;
            if(val_23 != null)
            {
                goto label_36;
            }
            // 0x00AB366C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_36:
            // 0x00AB3670: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00AB3674: LDR x8, [x8, #0x4e8]       | X8 = 1152921514955199424;               
            // 0x00AB3678: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB367C: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x00AB3680: MOV x2, x20                | X2 = 1152921504903225344 (0x1000000011AA6000);//ML01
            // 0x00AB3684: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Add(System.String key, Mihua.Asset.LoadedAssetBundle value);
            // 0x00AB3688: BL #0x23fd44c              | Mihua.Asset.AssetMgr.m_LoadedAssetBundles.Add(key:  val_18, value:  val_15);
            val_23.Add(key:  val_18, value:  val_15);
            label_24:
            // 0x00AB368C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_24 = 1;
            label_25:
            // 0x00AB3690: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB3694: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB3698: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB369C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB36A0: RET                        |  return (System.Boolean)true;           
            return (bool)val_24;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB30D4 (11219156), len: 388  VirtAddr: 0x00AB30D4 RVA: 0x00AB30D4 token: 100693226 methodIndex: 46980 delegateWrapperIndex: 0 methodInvoker: 0
        protected static void LoadDependencies(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            System.String[] val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00AB30D4: STP x22, x21, [sp, #-0x30]! | stack[1152921514955365360] = ???;  stack[1152921514955365368] = ???;  //  dest_result_addr=1152921514955365360 |  dest_result_addr=1152921514955365368
            // 0x00AB30D8: STP x20, x19, [sp, #0x10]  | stack[1152921514955365376] = ???;  stack[1152921514955365384] = ???;  //  dest_result_addr=1152921514955365376 |  dest_result_addr=1152921514955365384
            // 0x00AB30DC: STP x29, x30, [sp, #0x20]  | stack[1152921514955365392] = ???;  stack[1152921514955365400] = ???;  //  dest_result_addr=1152921514955365392 |  dest_result_addr=1152921514955365400
            // 0x00AB30E0: ADD x29, sp, #0x20         | X29 = (1152921514955365360 + 32) = 1152921514955365392 (0x1000000268D1DC10);
            // 0x00AB30E4: SUB sp, sp, #0x10          | SP = (1152921514955365360 - 16) = 1152921514955365344 (0x1000000268D1DBE0);
            // 0x00AB30E8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB30EC: LDRB w8, [x20, #0x3ff]     | W8 = (bool)static_value_037333FF;       
            // 0x00AB30F0: MOV x19, x1                | X19 = X1;//m1                           
            val_6 = X1;
            // 0x00AB30F4: TBNZ w8, #0, #0xab3110     | if (static_value_037333FF == true) goto label_0;
            // 0x00AB30F8: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00AB30FC: LDR x8, [x8, #0x708]       | X8 = 0x2B8EB5C;                         
            // 0x00AB3100: LDR w0, [x8]               | W0 = 0x1197;                            
            // 0x00AB3104: BL #0x2782188              | X0 = sub_2782188( ?? 0x1197, ????);     
            // 0x00AB3108: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB310C: STRB w8, [x20, #0x3ff]     | static_value_037333FF = true;            //  dest_result_addr=57881599
            label_0:
            // 0x00AB3110: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3114: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3118: ADD x2, sp, #8             | X2 = (1152921514955365344 + 8) = 1152921514955365352 (0x1000000268D1DBE8);
            // 0x00AB311C: MOV x1, x19                | X1 = X1;//m1                            
            System.String[] val_1 = val_6;
            // 0x00AB3120: STR xzr, [sp, #8]          | stack[1152921514955365352] = 0x0;        //  dest_result_addr=1152921514955365352
            // 0x00AB3124: BL #0xb1bd48               | X0 = ABDepends.GetDepend(key:  0, depends: out  System.String[] val_1 = val_6);
            bool val_2 = ABDepends.GetDepend(key:  0, depends: out  val_1);
            // 0x00AB3128: TBZ w0, #0, #0xab3244      | if (val_2 == false) goto label_11;      
            if(val_2 == false)
            {
                goto label_11;
            }
            // 0x00AB312C: ADRP x22, #0x35c8000       | X22 = 56393728 (0x35C8000);             
            // 0x00AB3130: LDR x22, [x22, #0x270]     | X22 = 1152921504903331840;              
            // 0x00AB3134: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            // 0x00AB3138: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB313C: TBZ w8, #0, #0xab3150      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB3140: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3144: CBNZ w8, #0xab3150         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB3148: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB314C: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            label_3:
            // 0x00AB3150: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3154: LDR x20, [x8, #0x60]       | X20 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB3158: CBNZ x20, #0xab3160        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_4;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_4;
            }
            // 0x00AB315C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_4:
            // 0x00AB3160: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB3164: LDR x8, [x8, #0x7f8]       | X8 = 1152921514171611616;               
            // 0x00AB3168: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB316C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB3170: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String[]>::ContainsKey(System.String key);
            // 0x00AB3174: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_Dependencies.ContainsKey(key:  val_6);
            bool val_3 = Mihua.Asset.AssetMgr.m_Dependencies.ContainsKey(key:  val_6);
            // 0x00AB3178: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x00AB317C: TBNZ w8, #0, #0xab31cc     | if ((val_3 & 1) == true) goto label_5;  
            if(val_4 == true)
            {
                goto label_5;
            }
            // 0x00AB3180: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_8 = null;
            // 0x00AB3184: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3188: TBZ w8, #0, #0xab319c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AB318C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3190: CBNZ w8, #0xab319c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB3194: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3198: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_8 = null;
            label_7:
            // 0x00AB319C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB31A0: LDR x21, [sp, #8]          | X21 = 0x0;                              
            // 0x00AB31A4: LDR x20, [x8, #0x60]       | X20 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB31A8: CBNZ x20, #0xab31b0        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_8;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_8;
            }
            // 0x00AB31AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_8:
            // 0x00AB31B0: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x00AB31B4: LDR x8, [x8, #0x6e0]       | X8 = 1152921514171617984;               
            // 0x00AB31B8: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB31BC: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB31C0: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x00AB31C4: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String[]>::Add(System.String key, System.String[] value);
            // 0x00AB31C8: BL #0x23fd44c              | Mihua.Asset.AssetMgr.m_Dependencies.Add(key:  val_6, value:  0);
            Mihua.Asset.AssetMgr.m_Dependencies.Add(key:  val_6, value:  0);
            label_5:
            // 0x00AB31CC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00AB31D0: B #0xab31e0                |  goto label_9;                          
            goto label_9;
            label_16:
            // 0x00AB31D4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB31D8: BL #0xab2df4               | X0 = Mihua.Asset.AssetMgr.LoadAssetBundleInternal(assetBundleName:  Mihua.Asset.AssetMgr.m_Dependencies);
            bool val_5 = Mihua.Asset.AssetMgr.LoadAssetBundleInternal(assetBundleName:  Mihua.Asset.AssetMgr.m_Dependencies);
            // 0x00AB31DC: ADD w20, w20, #1           | W20 = (val_9 + 1) = val_9 (0x00000001); 
            val_9 = 1;
            label_9:
            // 0x00AB31E0: LDR x19, [sp, #8]          | X19 = 0x0;                              
            val_6 = 0;
            // 0x00AB31E4: CBNZ x19, #0xab31ec        | if (0x0 != 0) goto label_10;            
            if(val_6 != 0)
            {
                goto label_10;
            }
            // 0x00AB31E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_10:
            // 0x00AB31EC: LDR w8, [x19, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB31F0: CMP w20, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB31F4: B.GE #0xab3244             | if (val_9 >= 9966784) goto label_11;    
            if(val_9 >= 9966784)
            {
                goto label_11;
            }
            // 0x00AB31F8: LDR x19, [sp, #8]          | X19 = 0x0;                              
            // 0x00AB31FC: CBNZ x19, #0xab3204        | if (0x0 != 0) goto label_12;            
            if(0 != 0)
            {
                goto label_12;
            }
            // 0x00AB3200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00AB3204: LDR w8, [x19, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB3208: SXTW x21, w20              | X21 = 1 (0x00000001);                   
            // 0x00AB320C: CMP w20, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB3210: B.LO #0xab3220             | if (val_9 < 9966784) goto label_13;     
            if(val_9 < 9966784)
            {
                goto label_13;
            }
            // 0x00AB3214: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00AB3218: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB321C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_13:
            // 0x00AB3220: LDR x0, [x22]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3224: ADD x8, x19, x21, lsl #3   | X8 = (0 + 8);                           
            var val_6 = 0 + 8;
            // 0x00AB3228: LDR x19, [x8, #0x20]       | X19 = (0 + 8) + 32;                     
            // 0x00AB322C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3230: TBZ w8, #0, #0xab31d4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00AB3234: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3238: CBNZ w8, #0xab31d4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00AB323C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3240: B #0xab31d4                |  goto label_16;                         
            goto label_16;
            label_11:
            // 0x00AB3244: SUB sp, x29, #0x20         | SP = (1152921514955365392 - 32) = 1152921514955365360 (0x1000000268D1DBF0);
            // 0x00AB3248: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB324C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB3250: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB3254: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAFE04 (11206148), len: 208  VirtAddr: 0x00AAFE04 RVA: 0x00AAFE04 token: 100693227 methodIndex: 46981 delegateWrapperIndex: 0 methodInvoker: 0
        public static void UnloadAssetBundle(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00AAFE04: STP x22, x21, [sp, #-0x30]! | stack[1152921514955485552] = ???;  stack[1152921514955485560] = ???;  //  dest_result_addr=1152921514955485552 |  dest_result_addr=1152921514955485560
            // 0x00AAFE08: STP x20, x19, [sp, #0x10]  | stack[1152921514955485568] = ???;  stack[1152921514955485576] = ???;  //  dest_result_addr=1152921514955485568 |  dest_result_addr=1152921514955485576
            // 0x00AAFE0C: STP x29, x30, [sp, #0x20]  | stack[1152921514955485584] = ???;  stack[1152921514955485592] = ???;  //  dest_result_addr=1152921514955485584 |  dest_result_addr=1152921514955485592
            // 0x00AAFE10: ADD x29, sp, #0x20         | X29 = (1152921514955485552 + 32) = 1152921514955485584 (0x1000000268D3B190);
            // 0x00AAFE14: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AAFE18: LDRB w8, [x20, #0x400]     | W8 = (bool)static_value_03733400;       
            // 0x00AAFE1C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AAFE20: TBNZ w8, #0, #0xaafe3c     | if (static_value_03733400 == true) goto label_0;
            // 0x00AAFE24: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AAFE28: LDR x8, [x8, #0xe48]       | X8 = 0x2B8EB90;                         
            // 0x00AAFE2C: LDR w0, [x8]               | W0 = 0x11A4;                            
            // 0x00AAFE30: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A4, ????);     
            // 0x00AAFE34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAFE38: STRB w8, [x20, #0x400]     | static_value_03733400 = true;            //  dest_result_addr=57881600
            label_0:
            // 0x00AAFE3C: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AAFE40: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AAFE44: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_3 = null;
            // 0x00AAFE48: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFE4C: TBZ w8, #0, #0xaafe60      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AAFE50: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFE54: CBNZ w8, #0xaafe60         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AAFE58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AAFE5C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_3 = null;
            label_2:
            // 0x00AAFE60: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AAFE64: LDR x20, [x8, #0x28]       | X20 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AAFE68: CBNZ x20, #0xaafe70        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_3;
            }
            // 0x00AAFE6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AAFE70: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00AAFE74: LDR x8, [x8, #0xe50]       | X8 = 1152921514954757712;               
            // 0x00AAFE78: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AAFE7C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AAFE80: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::ContainsKey(System.String key);
            // 0x00AAFE84: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  X1);
            bool val_1 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  X1);
            // 0x00AAFE88: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00AAFE8C: TBZ w8, #0, #0xaafea0      | if ((val_1 & 1) == false) goto label_4; 
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x00AAFE90: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFE94: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFE98: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AAFE9C: RET                        |  return;                                
            return;
            label_4:
            // 0x00AAFEA0: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AAFEA4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFEA8: TBZ w8, #0, #0xaafeb8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AAFEAC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFEB0: CBNZ w8, #0xaafeb8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AAFEB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_6:
            // 0x00AAFEB8: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AAFEBC: BL #0xab36d8               | Mihua.Asset.AssetMgr.UnloadAssetBundleInternal(assetBundleName:  null);
            Mihua.Asset.AssetMgr.UnloadAssetBundleInternal(assetBundleName:  null);
            // 0x00AAFEC0: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AAFEC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFEC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFECC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AAFED0: B #0xab3878                | Mihua.Asset.AssetMgr.UnloadDependencies(assetBundleName:  null); return;
            Mihua.Asset.AssetMgr.UnloadDependencies(assetBundleName:  null);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB3878 (11221112), len: 368  VirtAddr: 0x00AB3878 RVA: 0x00AB3878 token: 100693228 methodIndex: 46982 delegateWrapperIndex: 0 methodInvoker: 0
        protected static void UnloadDependencies(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00AB3878: STP x24, x23, [sp, #-0x40]! | stack[1152921514955606752] = ???;  stack[1152921514955606760] = ???;  //  dest_result_addr=1152921514955606752 |  dest_result_addr=1152921514955606760
            // 0x00AB387C: STP x22, x21, [sp, #0x10]  | stack[1152921514955606768] = ???;  stack[1152921514955606776] = ???;  //  dest_result_addr=1152921514955606768 |  dest_result_addr=1152921514955606776
            // 0x00AB3880: STP x20, x19, [sp, #0x20]  | stack[1152921514955606784] = ???;  stack[1152921514955606792] = ???;  //  dest_result_addr=1152921514955606784 |  dest_result_addr=1152921514955606792
            // 0x00AB3884: STP x29, x30, [sp, #0x30]  | stack[1152921514955606800] = ???;  stack[1152921514955606808] = ???;  //  dest_result_addr=1152921514955606800 |  dest_result_addr=1152921514955606808
            // 0x00AB3888: ADD x29, sp, #0x30         | X29 = (1152921514955606752 + 48) = 1152921514955606800 (0x1000000268D58B10);
            // 0x00AB388C: SUB sp, sp, #0x10          | SP = (1152921514955606752 - 16) = 1152921514955606736 (0x1000000268D58AD0);
            // 0x00AB3890: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB3894: LDRB w8, [x20, #0x401]     | W8 = (bool)static_value_03733401;       
            // 0x00AB3898: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB389C: TBNZ w8, #0, #0xab38b8     | if (static_value_03733401 == true) goto label_0;
            // 0x00AB38A0: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00AB38A4: LDR x8, [x8, #0x468]       | X8 = 0x2B8EB98;                         
            // 0x00AB38A8: LDR w0, [x8]               | W0 = 0x11A6;                            
            // 0x00AB38AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A6, ????);     
            // 0x00AB38B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB38B4: STRB w8, [x20, #0x401]     | static_value_03733401 = true;            //  dest_result_addr=57881601
            label_0:
            // 0x00AB38B8: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB38BC: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AB38C0: STR xzr, [sp, #8]          | stack[1152921514955606744] = 0x0;        //  dest_result_addr=1152921514955606744
            System.String[] val_1 = 0;
            // 0x00AB38C4: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_5 = null;
            // 0x00AB38C8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB38CC: TBZ w8, #0, #0xab38e0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB38D0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB38D4: CBNZ w8, #0xab38e0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB38D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB38DC: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_5 = null;
            label_2:
            // 0x00AB38E0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB38E4: LDR x20, [x8, #0x60]       | X20 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB38E8: CBNZ x20, #0xab38f0        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_3;
            }
            // 0x00AB38EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB38F0: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00AB38F4: LDR x8, [x8, #0x7f0]       | X8 = 1152921514171482112;               
            // 0x00AB38F8: ADD x2, sp, #8             | X2 = (1152921514955606736 + 8) = 1152921514955606744 (0x1000000268D58AD8);
            // 0x00AB38FC: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB3900: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB3904: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String[]>::TryGetValue(System.String key, out System.String[] value);
            // 0x00AB3908: BL #0x23fe7ec              | X0 = Mihua.Asset.AssetMgr.m_Dependencies.TryGetValue(key:  X1, value: out  System.String[] val_1 = 0);
            bool val_2 = Mihua.Asset.AssetMgr.m_Dependencies.TryGetValue(key:  X1, value: out  val_1);
            // 0x00AB390C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x00AB3910: TBZ w8, #0, #0xab39d0      | if ((val_2 & 1) == false) goto label_4; 
            if(val_3 == false)
            {
                goto label_4;
            }
            // 0x00AB3914: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x00AB3918: B #0xab3928                |  goto label_5;                          
            goto label_5;
            label_12:
            // 0x00AB391C: MOV x1, x20                | X1 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB3920: BL #0xab36d8               | Mihua.Asset.AssetMgr.UnloadAssetBundleInternal(assetBundleName:  bool val_2 = Mihua.Asset.AssetMgr.m_Dependencies.TryGetValue(key:  X1, value: out  val_1));
            Mihua.Asset.AssetMgr.UnloadAssetBundleInternal(assetBundleName:  val_2);
            // 0x00AB3924: ADD w22, w22, #1           | W22 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            label_5:
            // 0x00AB3928: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB392C: CBNZ x20, #0xab3934        | if (0x0 != 0) goto label_6;             
            if(val_1 != 0)
            {
                goto label_6;
            }
            // 0x00AB3930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00AB3934: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB3938: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB393C: B.GE #0xab398c             | if (val_6 >= 9966784) goto label_7;     
            if(val_6 >= 9966784)
            {
                goto label_7;
            }
            // 0x00AB3940: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB3944: CBNZ x20, #0xab394c        | if (0x0 != 0) goto label_8;             
            if(val_1 != 0)
            {
                goto label_8;
            }
            // 0x00AB3948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x00AB394C: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB3950: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x00AB3954: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB3958: B.LO #0xab3968             | if (val_6 < 9966784) goto label_9;      
            if(val_6 < 9966784)
            {
                goto label_9;
            }
            // 0x00AB395C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB3960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_9:
            // 0x00AB3968: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB396C: ADD x8, x20, x23, lsl #3   | X8 = (val_1 + 8);                       
            var val_4 = val_1 + 8;
            // 0x00AB3970: LDR x20, [x8, #0x20]       | X20 = (val_1 + 8) + 32;                 
            // 0x00AB3974: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3978: TBZ w8, #0, #0xab391c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AB397C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3980: CBNZ w8, #0xab391c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AB3984: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3988: B #0xab391c                |  goto label_12;                         
            goto label_12;
            label_7:
            // 0x00AB398C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            // 0x00AB3990: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3994: TBZ w8, #0, #0xab39a8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00AB3998: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB399C: CBNZ w8, #0xab39a8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00AB39A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB39A4: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_7 = null;
            label_14:
            // 0x00AB39A8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB39AC: LDR x20, [x8, #0x60]       | X20 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB39B0: CBNZ x20, #0xab39b8        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_15;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_15;
            }
            // 0x00AB39B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_15:
            // 0x00AB39B8: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00AB39BC: LDR x8, [x8, #0xcb8]       | X8 = 1152921514955593792;               
            // 0x00AB39C0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB39C4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB39C8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.String[]>::Remove(System.String key);
            // 0x00AB39CC: BL #0x23fe354              | X0 = Mihua.Asset.AssetMgr.m_Dependencies.Remove(key:  X1);
            bool val_5 = Mihua.Asset.AssetMgr.m_Dependencies.Remove(key:  X1);
            label_4:
            // 0x00AB39D0: SUB sp, x29, #0x30         | SP = (1152921514955606800 - 48) = 1152921514955606752 (0x1000000268D58AE0);
            // 0x00AB39D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB39D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB39DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB39E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB39E4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB36D8 (11220696), len: 416  VirtAddr: 0x00AB36D8 RVA: 0x00AB36D8 token: 100693229 methodIndex: 46983 delegateWrapperIndex: 0 methodInvoker: 0
        protected static void UnloadAssetBundleInternal(string assetBundleName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00AB36D8: STP x22, x21, [sp, #-0x30]! | stack[1152921514955736320] = ???;  stack[1152921514955736328] = ???;  //  dest_result_addr=1152921514955736320 |  dest_result_addr=1152921514955736328
            // 0x00AB36DC: STP x20, x19, [sp, #0x10]  | stack[1152921514955736336] = ???;  stack[1152921514955736344] = ???;  //  dest_result_addr=1152921514955736336 |  dest_result_addr=1152921514955736344
            // 0x00AB36E0: STP x29, x30, [sp, #0x20]  | stack[1152921514955736352] = ???;  stack[1152921514955736360] = ???;  //  dest_result_addr=1152921514955736352 |  dest_result_addr=1152921514955736360
            // 0x00AB36E4: ADD x29, sp, #0x20         | X29 = (1152921514955736320 + 32) = 1152921514955736352 (0x1000000268D78520);
            // 0x00AB36E8: SUB sp, sp, #0x10          | SP = (1152921514955736320 - 16) = 1152921514955736304 (0x1000000268D784F0);
            // 0x00AB36EC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB36F0: LDRB w8, [x20, #0x402]     | W8 = (bool)static_value_03733402;       
            // 0x00AB36F4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB36F8: TBNZ w8, #0, #0xab3714     | if (static_value_03733402 == true) goto label_0;
            // 0x00AB36FC: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x00AB3700: LDR x8, [x8, #0xc08]       | X8 = 0x2B8EB94;                         
            // 0x00AB3704: LDR w0, [x8]               | W0 = 0x11A5;                            
            // 0x00AB3708: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A5, ????);     
            // 0x00AB370C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB3710: STRB w8, [x20, #0x402]     | static_value_03733402 = true;            //  dest_result_addr=57881602
            label_0:
            // 0x00AB3714: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB3718: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AB371C: STR xzr, [sp, #8]          | stack[1152921514955736312] = 0x0;        //  dest_result_addr=1152921514955736312
            // 0x00AB3720: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_8 = null;
            // 0x00AB3724: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3728: TBZ w8, #0, #0xab373c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB372C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3730: CBNZ w8, #0xab373c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB3734: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3738: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_8 = null;
            label_2:
            // 0x00AB373C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3740: LDR x20, [x8, #0x28]       | X20 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AB3744: CBNZ x20, #0xab374c        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_3;
            }
            // 0x00AB3748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB374C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00AB3750: LDR x8, [x8, #0xe50]       | X8 = 1152921514954757712;               
            // 0x00AB3754: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AB3758: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB375C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::ContainsKey(System.String key);
            // 0x00AB3760: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  X1);
            bool val_1 = Mihua.Asset.AssetMgr.m_assetShared.ContainsKey(key:  X1);
            // 0x00AB3764: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00AB3768: TBNZ w8, #0, #0xab3864     | if ((val_1 & 1) == true) goto label_8;  
            if(val_2 == true)
            {
                goto label_8;
            }
            // 0x00AB376C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3770: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3774: TBZ w8, #0, #0xab3784      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB3778: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB377C: CBNZ w8, #0xab3784         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB3780: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_6:
            // 0x00AB3784: ADD x2, sp, #8             | X2 = (1152921514955736304 + 8) = 1152921514955736312 (0x1000000268D784F8);
            // 0x00AB3788: MOV x1, x19                | X1 = X1;//m1                            
            string val_3 = X1;
            // 0x00AB378C: BL #0xaaf890               | X0 = Mihua.Asset.AssetMgr.GetLoadedAssetBundle(assetBundleName:  null, error: out  string val_3 = X1);
            Mihua.Asset.LoadedAssetBundle val_4 = Mihua.Asset.AssetMgr.GetLoadedAssetBundle(assetBundleName:  null, error: out  val_3);
            // 0x00AB3790: CBZ x0, #0xab3864          | if (val_4 == null) goto label_8;        
            if(val_4 == null)
            {
                goto label_8;
            }
            // 0x00AB3794: LDR w8, [x0, #0x18]        | W8 = val_4.m_ReferencedCount; //P2      
            int val_8 = val_4.m_ReferencedCount;
            // 0x00AB3798: SUB w8, w8, #1             | W8 = (val_4.m_ReferencedCount - 1);     
            val_8 = val_8 - 1;
            // 0x00AB379C: STR w8, [x0, #0x18]        | val_4.m_ReferencedCount = (val_4.m_ReferencedCount - 1);  //  dest_result_addr=0
            val_4.m_ReferencedCount = val_8;
            // 0x00AB37A0: CMP w8, #0                 | STATE = COMPARE((val_4.m_ReferencedCount - 1), 0x0)
            // 0x00AB37A4: B.GT #0xab3864             | if (val_4.m_ReferencedCount > 0) goto label_8;
            if(val_8 > 0)
            {
                goto label_8;
            }
            // 0x00AB37A8: BL #0xab39e8               | val_4.Clear();                          
            val_4.Clear();
            // 0x00AB37AC: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_9 = null;
            // 0x00AB37B0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB37B4: TBZ w8, #0, #0xab37c8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00AB37B8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB37BC: CBNZ w8, #0xab37c8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00AB37C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB37C4: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_9 = null;
            label_10:
            // 0x00AB37C8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB37CC: LDR x20, [x8, #0x40]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB37D0: CBNZ x20, #0xab37d8        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_11;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_11;
            }
            // 0x00AB37D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_11:
            // 0x00AB37D8: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00AB37DC: LDR x8, [x8, #0xbe8]       | X8 = 1152921514955719104;               
            // 0x00AB37E0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB37E4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB37E8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Remove(System.String key);
            // 0x00AB37EC: BL #0x23fe354              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.Remove(key:  X1);
            bool val_5 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.Remove(key:  X1);
            // 0x00AB37F0: LDR x8, [x21]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB37F4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB37F8: LDR x20, [x8, #0x48]       | X20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB37FC: CBNZ x20, #0xab3804        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_12;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_12;
            }
            // 0x00AB3800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x00AB3804: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00AB3808: LDR x8, [x8, #0x848]       | X8 = 1152921510808642064;               
            // 0x00AB380C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB3810: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB3814: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::Remove(System.String key);
            // 0x00AB3818: BL #0x23f6190              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.Remove(key:  X1);
            bool val_6 = Mihua.Asset.AssetMgr.m_RefCountDic.Remove(key:  X1);
            // 0x00AB381C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB3820: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB3824: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00AB3828: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB382C: TBZ w8, #0, #0xab383c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00AB3830: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3834: CBNZ w8, #0xab383c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00AB3838: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_14:
            // 0x00AB383C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x00AB3840: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921514955720128)(" has been unloaded successfully");
            // 0x00AB3844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB384C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB3850: LDR x2, [x8]               | X2 = " has been unloaded successfully"; 
            // 0x00AB3854: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  X1);
            string val_7 = System.String.Concat(str0:  0, str1:  X1);
            // 0x00AB3858: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AB385C: MOV x2, x0                 | X2 = val_7;//m1                         
            // 0x00AB3860: BL #0xab241c               | Mihua.Asset.AssetMgr.Log(logType:  string val_7 = System.String.Concat(str0:  0, str1:  X1), text:  0);
            Mihua.Asset.AssetMgr.Log(logType:  val_7, text:  0);
            label_8:
            // 0x00AB3864: SUB sp, x29, #0x20         | SP = (1152921514955736352 - 32) = 1152921514955736320 (0x1000000268D78500);
            // 0x00AB3868: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB386C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB3870: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB3874: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB3A54 (11221588), len: 2888  VirtAddr: 0x00AB3A54 RVA: 0x00AB3A54 token: 100693230 methodIndex: 46984 delegateWrapperIndex: 0 methodInvoker: 0
        private void Update()
        {
            //
            // Disasemble & Code
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            System.Collections.Generic.List<System.String> val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            object val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            //  | 
            string val_62;
            //  | 
            var val_63;
            //  | 
            var val_64;
            //  | 
            var val_65;
            //  | 
            string val_66;
            //  | 
            string val_67;
            //  | 
            var val_68;
            //  | 
            var val_69;
            //  | 
            var val_70;
            //  | 
            var val_71;
            //  | 
            var val_72;
            //  | 
            var val_73;
            //  | 
            var val_74;
            //  | 
            var val_75;
            //  | 
            var val_76;
            // 0x00AB3A54: STP d9, d8, [sp, #-0x70]!  | stack[1152921514955970704] = ???;  stack[1152921514955970712] = ???;  //  dest_result_addr=1152921514955970704 |  dest_result_addr=1152921514955970712
            // 0x00AB3A58: STP x28, x27, [sp, #0x10]  | stack[1152921514955970720] = ???;  stack[1152921514955970728] = ???;  //  dest_result_addr=1152921514955970720 |  dest_result_addr=1152921514955970728
            // 0x00AB3A5C: STP x26, x25, [sp, #0x20]  | stack[1152921514955970736] = ???;  stack[1152921514955970744] = ???;  //  dest_result_addr=1152921514955970736 |  dest_result_addr=1152921514955970744
            // 0x00AB3A60: STP x24, x23, [sp, #0x30]  | stack[1152921514955970752] = ???;  stack[1152921514955970760] = ???;  //  dest_result_addr=1152921514955970752 |  dest_result_addr=1152921514955970760
            // 0x00AB3A64: STP x22, x21, [sp, #0x40]  | stack[1152921514955970768] = ???;  stack[1152921514955970776] = ???;  //  dest_result_addr=1152921514955970768 |  dest_result_addr=1152921514955970776
            // 0x00AB3A68: STP x20, x19, [sp, #0x50]  | stack[1152921514955970784] = ???;  stack[1152921514955970792] = ???;  //  dest_result_addr=1152921514955970784 |  dest_result_addr=1152921514955970792
            // 0x00AB3A6C: STP x29, x30, [sp, #0x60]  | stack[1152921514955970800] = ???;  stack[1152921514955970808] = ???;  //  dest_result_addr=1152921514955970800 |  dest_result_addr=1152921514955970808
            // 0x00AB3A70: ADD x29, sp, #0x60         | X29 = (1152921514955970704 + 96) = 1152921514955970800 (0x1000000268DB18F0);
            // 0x00AB3A74: SUB sp, sp, #0x10          | SP = (1152921514955970704 - 16) = 1152921514955970688 (0x1000000268DB1880);
            // 0x00AB3A78: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB3A7C: LDRB w8, [x19, #0x403]     | W8 = (bool)static_value_03733403;       
            // 0x00AB3A80: TBNZ w8, #0, #0xab3a9c     | if (static_value_03733403 == true) goto label_0;
            // 0x00AB3A84: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00AB3A88: LDR x8, [x8, #0x4e8]       | X8 = 0x2B8EB9C;                         
            // 0x00AB3A8C: LDR w0, [x8]               | W0 = 0x11A7;                            
            // 0x00AB3A90: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A7, ????);     
            // 0x00AB3A94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB3A98: STRB w8, [x19, #0x403]     | static_value_03733403 = true;            //  dest_result_addr=57881603
            label_0:
            // 0x00AB3A9C: ADRP x25, #0x35c8000       | X25 = 56393728 (0x35C8000);             
            // 0x00AB3AA0: LDR x25, [x25, #0x270]     | X25 = 1152921504903331840;              
            // 0x00AB3AA4: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_47 = null;
            // 0x00AB3AA8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3AAC: TBZ w8, #0, #0xab3ac0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB3AB0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3AB4: CBNZ w8, #0xab3ac0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB3AB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3ABC: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_47 = null;
            label_2:
            // 0x00AB3AC0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3AC4: LDRB w9, [x8, #0x70]       | W9 = Mihua.Asset.AssetMgr.isWaitClear;  
            // 0x00AB3AC8: CBZ w9, #0xab3c78          | if (Mihua.Asset.AssetMgr.isWaitClear == false) goto label_3;
            if(Mihua.Asset.AssetMgr.isWaitClear == false)
            {
                goto label_3;
            }
            // 0x00AB3ACC: LDRB w9, [x0, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3AD0: TBZ w9, #0, #0xab3ae8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00AB3AD4: LDR w9, [x0, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3AD8: CBNZ w9, #0xab3ae8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00AB3ADC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3AE0: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3AE4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            label_5:
            // 0x00AB3AE8: LDR x19, [x8, #0x78]       | X19 = Mihua.Asset.AssetMgr.ab2AsstsList;
            System.Collections.Generic.List<System.String> val_45 = Mihua.Asset.AssetMgr.ab2AsstsList;
            // 0x00AB3AEC: CBNZ x19, #0xab3af4        | if (Mihua.Asset.AssetMgr.ab2AsstsList != null) goto label_6;
            if(val_45 != null)
            {
                goto label_6;
            }
            // 0x00AB3AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_6:
            // 0x00AB3AF4: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
            // 0x00AB3AF8: LDR x22, [x22, #0xb58]     | X22 = 1152921510022759280;              
            // 0x00AB3AFC: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.ab2AsstsList;//m1
            // 0x00AB3B00: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB3B04: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.ab2AsstsList.get_Count();
            int val_1 = val_45.Count;
            // 0x00AB3B08: MOV w8, w0                 | W8 = val_1;//m1                         
            // 0x00AB3B0C: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_49 = null;
            // 0x00AB3B10: SUB w19, w8, #1            | W19 = (val_1 - 1);                      
            val_45 = val_1 - 1;
            // 0x00AB3B14: LDRB w9, [x0, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3B18: AND w8, w9, #1             | W8 = (Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A & 1);
            // 0x00AB3B1C: TBNZ w19, #0x1f, #0xab3c08 | if (((val_1 - 1) & 0x80000000) != 0) goto label_7;
            if((val_45 & 2147483648) != 0)
            {
                goto label_7;
            }
            // 0x00AB3B20: ADRP x23, #0x35bd000       | X23 = 56348672 (0x35BD000);             
            // 0x00AB3B24: ADRP x24, #0x35fa000       | X24 = 56598528 (0x35FA000);             
            // 0x00AB3B28: ADRP x26, #0x35e0000       | X26 = 56492032 (0x35E0000);             
            // 0x00AB3B2C: LDR x23, [x23, #0xb50]     | X23 = 1152921510890998992;              
            val_51 = 1152921510890998992;
            // 0x00AB3B30: LDR x24, [x24, #0x250]     | X24 = 1152921514955848656;              
            // 0x00AB3B34: LDR x26, [x26, #0xa30]     | X26 = 1152921510892175824;              
            label_18:
            // 0x00AB3B38: TBZ w8, #0, #0xab3b4c      | if (((Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A & 1) & 0x1) == 0) goto label_9;
            // 0x00AB3B3C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3B40: CBNZ w8, #0xab3b4c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00AB3B44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3B48: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_52 = null;
            label_9:
            // 0x00AB3B4C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3B50: LDR x20, [x8, #0x40]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB3B54: LDR x21, [x8, #0x78]       | X21 = Mihua.Asset.AssetMgr.ab2AsstsList;
            // 0x00AB3B58: CBNZ x21, #0xab3b60        | if (Mihua.Asset.AssetMgr.ab2AsstsList != null) goto label_10;
            if(Mihua.Asset.AssetMgr.ab2AsstsList != null)
            {
                goto label_10;
            }
            // 0x00AB3B5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_10:
            // 0x00AB3B60: LDR x2, [x23]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB3B64: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.ab2AsstsList;//m1
            // 0x00AB3B68: MOV w1, w19                | W1 = (val_1 - 1);//m1                   
            // 0x00AB3B6C: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.ab2AsstsList.get_Item(index:  Mihua.Asset.AssetMgr.ab2AsstsList);
            string val_2 = Mihua.Asset.AssetMgr.ab2AsstsList.Item[val_45];
            // 0x00AB3B70: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AB3B74: CBNZ x20, #0xab3b7c        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_11;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_11;
            }
            // 0x00AB3B78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_11:
            // 0x00AB3B7C: LDR x2, [x24]              | X2 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::get_Item(System.String key);
            // 0x00AB3B80: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB3B84: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00AB3B88: BL #0x23fc26c              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.get_Item(key:  val_2);
            Mihua.Asset.LoadedAssetBundle val_3 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.Item[val_2];
            // 0x00AB3B8C: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00AB3B90: CBNZ x20, #0xab3b98        | if (val_3 != null) goto label_12;       
            if(val_3 != null)
            {
                goto label_12;
            }
            // 0x00AB3B94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_12:
            // 0x00AB3B98: LDR x20, [x20, #0x20]      | X20 = val_3.m_Request; //P2             
            // 0x00AB3B9C: CBNZ x20, #0xab3ba4        | if (val_3.m_Request != null) goto label_13;
            if(val_3.m_Request != null)
            {
                goto label_13;
            }
            // 0x00AB3BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_13:
            // 0x00AB3BA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3BA8: MOV x0, x20                | X0 = val_3.m_Request;//m1               
            // 0x00AB3BAC: BL #0x20ca724              | X0 = val_3.m_Request.get_isDone();      
            bool val_4 = val_3.m_Request.isDone;
            // 0x00AB3BB0: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x00AB3BB4: TBZ w8, #0, #0xab3bf4      | if ((val_4 & 1) == false) goto label_14;
            if(val_5 == false)
            {
                goto label_14;
            }
            // 0x00AB3BB8: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_53 = null;
            // 0x00AB3BBC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3BC0: TBZ w8, #0, #0xab3bd4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00AB3BC4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3BC8: CBNZ w8, #0xab3bd4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00AB3BCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3BD0: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_53 = null;
            label_16:
            // 0x00AB3BD4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3BD8: LDR x20, [x8, #0x78]       | X20 = Mihua.Asset.AssetMgr.ab2AsstsList;
            // 0x00AB3BDC: CBNZ x20, #0xab3be4        | if (Mihua.Asset.AssetMgr.ab2AsstsList != null) goto label_17;
            if(Mihua.Asset.AssetMgr.ab2AsstsList != null)
            {
                goto label_17;
            }
            // 0x00AB3BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_17:
            // 0x00AB3BE4: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<System.String>::RemoveAt(int index);
            // 0x00AB3BE8: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.ab2AsstsList;//m1
            // 0x00AB3BEC: MOV w1, w19                | W1 = (val_1 - 1);//m1                   
            // 0x00AB3BF0: BL #0x25ed00c              | Mihua.Asset.AssetMgr.ab2AsstsList.RemoveAt(index:  Mihua.Asset.AssetMgr.ab2AsstsList);
            Mihua.Asset.AssetMgr.ab2AsstsList.RemoveAt(index:  val_45);
            label_14:
            // 0x00AB3BF4: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_54 = null;
            // 0x00AB3BF8: SUB w19, w19, #1           | W19 = ((val_1 - 1) - 1);                
            val_45 = val_45 - 1;
            // 0x00AB3BFC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3C00: AND w8, w8, #1             | W8 = (Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A & 1);
            // 0x00AB3C04: TBZ w19, #0x1f, #0xab3b38  | if ((((val_1 - 1) - 1) & 0x80000000) == 0) goto label_18;
            if((val_45 & 2147483648) == 0)
            {
                goto label_18;
            }
            label_7:
            // 0x00AB3C08: CBZ w8, #0xab3c1c          | if ((Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A & 1) == 0) goto label_20;
            // 0x00AB3C0C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3C10: CBNZ w8, #0xab3c1c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00AB3C14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3C18: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_54 = null;
            label_20:
            // 0x00AB3C1C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3C20: LDR x19, [x8, #0x78]       | X19 = Mihua.Asset.AssetMgr.ab2AsstsList;
            val_55 = Mihua.Asset.AssetMgr.ab2AsstsList;
            // 0x00AB3C24: CBNZ x19, #0xab3c2c        | if (Mihua.Asset.AssetMgr.ab2AsstsList != null) goto label_21;
            if(val_55 != null)
            {
                goto label_21;
            }
            // 0x00AB3C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_21:
            // 0x00AB3C2C: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB3C30: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.ab2AsstsList;//m1
            // 0x00AB3C34: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.ab2AsstsList.get_Count();
            int val_6 = val_55.Count;
            // 0x00AB3C38: CBNZ w0, #0xab4578         | if (val_6 != 0) goto label_112;         
            if(val_6 != 0)
            {
                goto label_112;
            }
            // 0x00AB3C3C: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3C40: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3C44: TBZ w8, #0, #0xab3c54      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_24;
            // 0x00AB3C48: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3C4C: CBNZ w8, #0xab3c54         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
            // 0x00AB3C50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_24:
            // 0x00AB3C54: SUB sp, x29, #0x60         | SP = (1152921514955970800 - 96) = 1152921514955970704 (0x1000000268DB1890);
            // 0x00AB3C58: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB3C5C: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB3C60: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB3C64: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB3C68: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB3C6C: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00AB3C70: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00AB3C74: B #0xab459c                | Mihua.Asset.AssetMgr.EndClear(); return;
            Mihua.Asset.AssetMgr.EndClear();
            return;
            label_3:
            // 0x00AB3C78: ADRP x26, #0x365c000       | X26 = 56999936 (0x365C000);             
            // 0x00AB3C7C: ADRP x27, #0x367e000       | X27 = 57139200 (0x367E000);             
            // 0x00AB3C80: ADRP x28, #0x35bd000       | X28 = 56348672 (0x35BD000);             
            // 0x00AB3C84: LDR x26, [x26, #0xac8]     | X26 = 1152921514955861968;              
            // 0x00AB3C88: LDR x27, [x27, #0x330]     | X27 = 1152921514954102288;              
            // 0x00AB3C8C: LDR x28, [x28, #0xb50]     | X28 = 1152921510890998992;              
            // 0x00AB3C90: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            var val_46 = 0;
            // 0x00AB3C94: B #0xab3cb0                |  goto label_86;                         
            goto label_86;
            label_85:
            // 0x00AB3C98: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00AB3C9C: LDR x8, [x8, #0xa30]       | X8 = 1152921510892175824;               
            // 0x00AB3CA0: MOV x0, x20                | X0 = X20;//m1                           
            // 0x00AB3CA4: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3CA8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::RemoveAt(int index);
            // 0x00AB3CAC: BL #0x25ed00c              | X20.RemoveAt(index:  0);                
            X20.RemoveAt(index:  0);
            label_86:
            // 0x00AB3CB0: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_56 = null;
            // 0x00AB3CB4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3CB8: TBZ w8, #0, #0xab3ccc      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x00AB3CBC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3CC0: CBNZ w8, #0xab3ccc         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x00AB3CC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3CC8: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_56 = null;
            label_27:
            // 0x00AB3CCC: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3CD0: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB3CD4: CBNZ x20, #0xab3cdc        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_28;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_28;
            }
            // 0x00AB3CD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_28:
            // 0x00AB3CDC: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::get_Count();
            // 0x00AB3CE0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB3CE4: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.m_WWWList.get_Count();
            int val_7 = Mihua.Asset.AssetMgr.m_WWWList.Count;
            // 0x00AB3CE8: CMP w19, w0                | STATE = COMPARE(0x0, val_7)             
            // 0x00AB3CEC: B.GE #0xab433c             | if (0 >= val_7) goto label_29;          
            if(val_46 >= val_7)
            {
                goto label_29;
            }
            // 0x00AB3CF0: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_57 = null;
            // 0x00AB3CF4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3CF8: TBZ w8, #0, #0xab3d0c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x00AB3CFC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3D00: CBNZ w8, #0xab3d0c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x00AB3D04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3D08: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_57 = null;
            label_31:
            // 0x00AB3D0C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3D10: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB3D14: CBNZ x20, #0xab3d1c        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_32;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_32;
            }
            // 0x00AB3D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_32:
            // 0x00AB3D1C: LDR x2, [x27]              | X2 = public UnityEngine.Networking.UnityWebRequest System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::get_Item(int index);
            // 0x00AB3D20: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB3D24: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3D28: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_WWWList.get_Item(index:  0);
            UnityEngine.Networking.UnityWebRequest val_8 = Mihua.Asset.AssetMgr.m_WWWList.Item[0];
            // 0x00AB3D2C: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00AB3D30: CBNZ x20, #0xab3d38        | if (val_8 != null) goto label_33;       
            if(val_8 != null)
            {
                goto label_33;
            }
            // 0x00AB3D34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_33:
            // 0x00AB3D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3D3C: MOV x0, x20                | X0 = val_8;//m1                         
            // 0x00AB3D40: BL #0x275674c              | X0 = val_8.get_error();                 
            string val_9 = val_8.error;
            // 0x00AB3D44: CBZ x0, #0xab3dcc          | if (val_9 == null) goto label_34;       
            if(val_9 == null)
            {
                goto label_34;
            }
            // 0x00AB3D48: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_58 = null;
            // 0x00AB3D4C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3D50: TBZ w8, #0, #0xab3d64      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x00AB3D54: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3D58: CBNZ w8, #0xab3d64         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x00AB3D5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3D60: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_58 = null;
            label_36:
            // 0x00AB3D64: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3D68: LDR x21, [x8, #0x50]       | X21 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            // 0x00AB3D6C: LDR x22, [x8, #0x90]       | X22 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB3D70: CBNZ x22, #0xab3d78        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_37;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_37;
            }
            // 0x00AB3D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_37:
            // 0x00AB3D78: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB3D7C: MOV x0, x22                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB3D80: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3D84: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_10 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB3D88: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3D8C: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x00AB3D90: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3D94: LDR x23, [x8, #0x90]       | X23 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB3D98: CBNZ x23, #0xab3da0        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_38;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_38;
            }
            // 0x00AB3D9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_38:
            // 0x00AB3DA0: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB3DA4: MOV x0, x23                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB3DA8: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3DAC: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_11 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB3DB0: MOV x23, x0                | X23 = val_11;//m1                       
            // 0x00AB3DB4: CBZ x20, #0xab3f10         | if (val_8 == null) goto label_39;       
            if(val_8 == null)
            {
                goto label_39;
            }
            // 0x00AB3DB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3DBC: MOV x0, x20                | X0 = val_8;//m1                         
            // 0x00AB3DC0: BL #0x275686c              | X0 = val_8.get_url();                   
            string val_12 = val_8.url;
            // 0x00AB3DC4: MOV x24, x0                | X24 = val_12;//m1                       
            val_59 = val_12;
            // 0x00AB3DC8: B #0xab3f28                |  goto label_40;                         
            goto label_40;
            label_34:
            // 0x00AB3DCC: CBNZ x20, #0xab3dd4        | if (val_8 != null) goto label_41;       
            if(val_8 != null)
            {
                goto label_41;
            }
            // 0x00AB3DD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_41:
            // 0x00AB3DD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3DD8: MOV x0, x20                | X0 = val_8;//m1                         
            // 0x00AB3DDC: BL #0x2756f5c              | X0 = val_8.get_isDone();                
            bool val_13 = val_8.isDone;
            // 0x00AB3DE0: TBZ w0, #0, #0xab4334      | if (val_13 == false) goto label_42;     
            if(val_13 == false)
            {
                goto label_42;
            }
            // 0x00AB3DE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3DE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB3DEC: MOV x1, x20                | X1 = val_8;//m1                         
            // 0x00AB3DF0: BL #0x275577c              | X0 = UnityEngine.Networking.DownloadHandlerAssetBundle.GetContent(www:  0);
            UnityEngine.AssetBundle val_14 = UnityEngine.Networking.DownloadHandlerAssetBundle.GetContent(www:  0);
            // 0x00AB3DF4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00AB3DF8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x00AB3DFC: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00AB3E00: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
            // 0x00AB3E04: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x00AB3E08: TBZ w9, #0, #0xab3e1c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_44;
            // 0x00AB3E0C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3E10: CBNZ w9, #0xab3e1c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
            // 0x00AB3E14: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
            // 0x00AB3E18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_44:
            // 0x00AB3E1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3E20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB3E24: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x00AB3E28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3E2C: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_14);
            bool val_15 = UnityEngine.Object.op_Equality(x:  0, y:  val_14);
            // 0x00AB3E30: TBZ w0, #0, #0xab3fb4      | if (val_15 == false) goto label_45;     
            if(val_15 == false)
            {
                goto label_45;
            }
            // 0x00AB3E34: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00AB3E38: LDR x8, [x8, #0x638]       | X8 = 1152921504903491584;               
            // 0x00AB3E3C: LDR x0, [x8]               | X0 = typeof(AssetMgr.<Update>c__AnonStorey0);
            object val_16 = null;
            // 0x00AB3E40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetMgr.<Update>c__AnonStorey0), ????);
            // 0x00AB3E44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3E48: MOV x20, x0                | X20 = 1152921504903491584 (0x1000000011AE7000);//ML01
            // 0x00AB3E4C: BL #0x16f59f0              | .ctor();                                
            val_16 = new System.Object();
            // 0x00AB3E50: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00AB3E54: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
            // 0x00AB3E58: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
            val_60 = null;
            // 0x00AB3E5C: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
            // 0x00AB3E60: TBZ w8, #0, #0xab3e7c      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x00AB3E64: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3E68: CBNZ w8, #0xab3e7c         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x00AB3E6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
            // 0x00AB3E70: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00AB3E74: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
            // 0x00AB3E78: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
            val_60 = null;
            label_47:
            // 0x00AB3E7C: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
            // 0x00AB3E80: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_61 = null;
            // 0x00AB3E84: LDR x21, [x8, #0x28]       | X21 = Loader.PathUtil.persistentDataPath;
            // 0x00AB3E88: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3E8C: TBZ w8, #0, #0xab3ea0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_49;
            // 0x00AB3E90: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3E94: CBNZ w8, #0xab3ea0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
            // 0x00AB3E98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3E9C: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_61 = null;
            label_49:
            // 0x00AB3EA0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3EA4: LDR x22, [x8, #0x90]       | X22 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB3EA8: CBNZ x22, #0xab3eb0        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_50;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_50;
            }
            // 0x00AB3EAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_50:
            // 0x00AB3EB0: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB3EB4: MOV x0, x22                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB3EB8: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB3EBC: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_17 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB3EC0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB3EC4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB3EC8: MOV x22, x0                | X22 = val_17;//m1                       
            // 0x00AB3ECC: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00AB3ED0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB3ED4: TBZ w9, #0, #0xab3ee8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_52;
            // 0x00AB3ED8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3EDC: CBNZ w9, #0xab3ee8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
            // 0x00AB3EE0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AB3EE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_52:
            // 0x00AB3EE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3EEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB3EF0: MOV x1, x21                | X1 = Loader.PathUtil.persistentDataPath;//m1
            // 0x00AB3EF4: MOV x2, x22                | X2 = val_17;//m1                        
            // 0x00AB3EF8: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
            string val_18 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
            // 0x00AB3EFC: MOV x21, x0                | X21 = val_18;//m1                       
            val_62 = val_18;
            // 0x00AB3F00: CBZ x20, #0xab40a0         | if ( == 0) goto label_53;               
            if(null == 0)
            {
                goto label_53;
            }
            // 0x00AB3F04: MOV x22, x20               | X22 = 1152921504903491584 (0x1000000011AE7000);//ML01
            val_63 = val_16;
            // 0x00AB3F08: STR x21, [x22, #0x10]!     | typeof(AssetMgr.<Update>c__AnonStorey0).__il2cppRuntimeField_10 = val_18;  //  dest_result_addr=1152921504903491600
            typeof(AssetMgr.<Update>c__AnonStorey0).__il2cppRuntimeField_10 = val_62;
            // 0x00AB3F0C: B #0xab40b8                |  goto label_54;                         
            goto label_54;
            label_39:
            // 0x00AB3F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x00AB3F14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3F18: MOV x0, x20                | X0 = val_8;//m1                         
            // 0x00AB3F1C: BL #0x275686c              | X0 = val_8.get_url();                   
            string val_19 = val_8.url;
            // 0x00AB3F20: MOV x24, x0                | X24 = val_19;//m1                       
            val_59 = val_19;
            // 0x00AB3F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_40:
            // 0x00AB3F28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3F2C: MOV x0, x20                | X0 = val_8;//m1                         
            // 0x00AB3F30: BL #0x275674c              | X0 = val_8.get_error();                 
            string val_20 = val_8.error;
            // 0x00AB3F34: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB3F38: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB3F3C: MOV x20, x0                | X20 = val_20;//m1                       
            // 0x00AB3F40: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00AB3F44: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB3F48: TBZ w9, #0, #0xab3f5c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_56;
            // 0x00AB3F4C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3F50: CBNZ w9, #0xab3f5c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_56;
            // 0x00AB3F54: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AB3F58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_56:
            // 0x00AB3F5C: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB3F60: LDR x8, [x8, #0x668]       | X8 = (string**)(1152921514955903952)("加载资源出错：{0} url: {1} err: {2}");
            // 0x00AB3F64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB3F68: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00AB3F6C: MOV x2, x23                | X2 = val_11;//m1                        
            // 0x00AB3F70: LDR x1, [x8]               | X1 = "加载资源出错：{0} url: {1} err: {2}";    
            // 0x00AB3F74: MOV x3, x24                | X3 = val_19;//m1                        
            // 0x00AB3F78: MOV x4, x20                | X4 = val_20;//m1                        
            // 0x00AB3F7C: BL #0x18af46c              | X0 = System.String.Format(format:  0, arg0:  "加载资源出错：{0} url: {1} err: {2}", arg1:  val_11, arg2:  val_59);
            string val_21 = System.String.Format(format:  0, arg0:  "加载资源出错：{0} url: {1} err: {2}", arg1:  val_11, arg2:  val_59);
            // 0x00AB3F80: MOV x20, x0                | X20 = val_21;//m1                       
            // 0x00AB3F84: CBNZ x21, #0xab3f8c        | if (Mihua.Asset.AssetMgr.m_DownloadingErrors != null) goto label_57;
            if(Mihua.Asset.AssetMgr.m_DownloadingErrors != null)
            {
                goto label_57;
            }
            // 0x00AB3F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_57:
            // 0x00AB3F8C: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00AB3F90: LDR x8, [x8, #0x310]       | X8 = 1152921509931601104;               
            // 0x00AB3F94: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors;//m1
            // 0x00AB3F98: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x00AB3F9C: MOV x2, x20                | X2 = val_21;//m1                        
            // 0x00AB3FA0: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
            // 0x00AB3FA4: BL #0x23fd44c              | Mihua.Asset.AssetMgr.m_DownloadingErrors.Add(key:  val_10, value:  val_21);
            Mihua.Asset.AssetMgr.m_DownloadingErrors.Add(key:  val_10, value:  val_21);
            // 0x00AB3FA8: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB3FAC: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3FB0: B #0xab4270                |  goto label_58;                         
            goto label_58;
            label_45:
            // 0x00AB3FB4: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00AB3FB8: LDR x8, [x8, #0xf40]       | X8 = 1152921504903225344;               
            // 0x00AB3FBC: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.LoadedAssetBundle);
            object val_22 = null;
            // 0x00AB3FC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.LoadedAssetBundle), ????);
            // 0x00AB3FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB3FC8: MOV x20, x0                | X20 = 1152921504903225344 (0x1000000011AA6000);//ML01
            // 0x00AB3FCC: BL #0x16f59f0              | .ctor();                                
            val_22 = new System.Object();
            // 0x00AB3FD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB3FD4: STR w8, [x20, #0x18]       | typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = 0x1;  //  dest_result_addr=1152921504903225368
            typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = 1;
            // 0x00AB3FD8: STR x21, [x20, #0x10]      | typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_10 = val_14;  //  dest_result_addr=1152921504903225360
            typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_10 = val_14;
            // 0x00AB3FDC: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_65 = null;
            // 0x00AB3FE0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB3FE4: TBZ w8, #0, #0xab3ff8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x00AB3FE8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB3FEC: CBNZ w8, #0xab3ff8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x00AB3FF0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB3FF4: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_65 = null;
            label_60:
            // 0x00AB3FF8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB3FFC: LDR x21, [x8, #0x48]       | X21 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB4000: LDR x22, [x8, #0x90]       | X22 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB4004: CBNZ x22, #0xab400c        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_61;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_61;
            }
            // 0x00AB4008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_61:
            // 0x00AB400C: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB4010: MOV x0, x22                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB4014: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4018: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_23 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB401C: MOV x22, x0                | X22 = val_23;//m1                       
            // 0x00AB4020: CBNZ x21, #0xab4028        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_62;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_62;
            }
            // 0x00AB4024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_62:
            // 0x00AB4028: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB402C: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
            // 0x00AB4030: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB4034: MOV x1, x22                | X1 = val_23;//m1                        
            // 0x00AB4038: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
            // 0x00AB403C: BL #0x23f40a8              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.get_Item(key:  val_23);
            int val_24 = Mihua.Asset.AssetMgr.m_RefCountDic.Item[val_23];
            // 0x00AB4040: MOV w21, w0                | W21 = val_24;//m1                       
            // 0x00AB4044: CBNZ x20, #0xab404c        | if ( != 0) goto label_63;               
            if(null != 0)
            {
                goto label_63;
            }
            // 0x00AB4048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_63:
            // 0x00AB404C: STR w21, [x20, #0x18]      | typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = val_24;  //  dest_result_addr=1152921504903225368
            typeof(Mihua.Asset.LoadedAssetBundle).__il2cppRuntimeField_18 = val_24;
            // 0x00AB4050: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB4054: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4058: LDR x21, [x8, #0x40]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB405C: LDR x22, [x8, #0x90]       | X22 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB4060: CBNZ x22, #0xab4068        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_64;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_64;
            }
            // 0x00AB4064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_64:
            // 0x00AB4068: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB406C: MOV x0, x22                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB4070: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4074: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_25 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB4078: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x00AB407C: CBNZ x21, #0xab4084        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_65;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_65;
            }
            // 0x00AB4080: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_65:
            // 0x00AB4084: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00AB4088: LDR x8, [x8, #0x4e8]       | X8 = 1152921514955199424;               
            // 0x00AB408C: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB4090: MOV x1, x22                | X1 = val_25;//m1                        
            val_66 = val_25;
            // 0x00AB4094: MOV x2, x20                | X2 = 1152921504903225344 (0x1000000011AA6000);//ML01
            val_67 = val_22;
            // 0x00AB4098: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Add(System.String key, Mihua.Asset.LoadedAssetBundle value);
            val_68 = public System.Void System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Add(System.String key, Mihua.Asset.LoadedAssetBundle value);
            // 0x00AB409C: B #0xab424c                |  goto label_66;                         
            goto label_66;
            label_53:
            // 0x00AB40A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            // 0x00AB40A4: ORR w22, wzr, #0x10        | W22 = 16(0x10);                         
            // 0x00AB40A8: STR x21, [x22]             | mem[16] = val_18;                        //  dest_result_addr=16
            mem[16] = val_62;
            // 0x00AB40AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            // 0x00AB40B0: LDR x21, [x22]             | X21 = val_18;                           
            val_62 = mem[16];
            // 0x00AB40B4: ORR w22, wzr, #0x10        | W22 = 16(0x10);                         
            val_63 = 16;
            label_54:
            // 0x00AB40B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB40BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB40C0: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x00AB40C4: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_26 = System.IO.File.Exists(path:  0);
            // 0x00AB40C8: TBZ w0, #0, #0xab40e4      | if (val_26 == false) goto label_67;     
            if(val_26 == false)
            {
                goto label_67;
            }
            // 0x00AB40CC: CBNZ x20, #0xab40d4        | if ( != 0) goto label_68;               
            if(null != 0)
            {
                goto label_68;
            }
            // 0x00AB40D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_68:
            // 0x00AB40D4: LDR x1, [x22]              | X1 = val_18;                            
            // 0x00AB40D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB40DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB40E0: BL #0x1e6a550              | System.IO.File.Delete(path:  0);        
            System.IO.File.Delete(path:  0);
            label_67:
            // 0x00AB40E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB40E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB40EC: BL #0x138e268              | X0 = PluginsSdkMgr.get_Instance();      
            PluginsSdkMgr val_27 = PluginsSdkMgr.Instance;
            // 0x00AB40F0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB40F4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB40F8: MOV x21, x0                | X21 = val_27;//m1                       
            // 0x00AB40FC: LDR x8, [x8]               | X8 = typeof(System.String);             
            val_69 = null;
            // 0x00AB4100: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB4104: TBZ w9, #0, #0xab4124      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_70;
            // 0x00AB4108: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB410C: CBNZ w9, #0xab4124         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_70;
            // 0x00AB4110: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AB4114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00AB4118: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AB411C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AB4120: LDR x8, [x8]               | X8 = typeof(System.String);             
            val_69 = null;
            label_70:
            // 0x00AB4124: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00AB4128: ADRP x9, #0x35fe000        | X9 = 56614912 (0x35FE000);              
            // 0x00AB412C: LDR x9, [x9, #0xf18]       | X9 = 1152921514955920464;               
            // 0x00AB4130: LDR x22, [x8]              | X22 = System.String.Empty;              
            // 0x00AB4134: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB4138: LDR x24, [x9]              | X24 = System.Void AssetMgr.<Update>c__AnonStorey0::<>m__0();
            // 0x00AB413C: LDR x8, [x8, #0xbe0]       | X8 = 1152921504687837184;               
            // 0x00AB4140: LDR x0, [x8]               | X0 = typeof(System.Action);             
            System.Action val_28 = null;
            // 0x00AB4144: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
            // 0x00AB4148: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB414C: MOV x1, x20                | X1 = 1152921504903491584 (0x1000000011AE7000);//ML01
            // 0x00AB4150: MOV x2, x24                | X2 = 1152921514955920464 (0x1000000268DA5450);//ML01
            // 0x00AB4154: MOV x23, x0                | X23 = 1152921504687837184 (0x1000000004D3D000);//ML01
            // 0x00AB4158: BL #0x26e30f0              | .ctor(object:  val_16, method:  System.Void AssetMgr.<Update>c__AnonStorey0::<>m__0());
            val_28 = new System.Action(object:  val_16, method:  System.Void AssetMgr.<Update>c__AnonStorey0::<>m__0());
            // 0x00AB415C: CBNZ x21, #0xab4164        | if (val_27 != null) goto label_71;      
            if(val_27 != null)
            {
                goto label_71;
            }
            // 0x00AB4160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  val_16, method:  System.Void AssetMgr.<Update>c__AnonStorey0::<>m__0()), ????);
            label_71:
            // 0x00AB4164: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00AB4168: LDR x8, [x8, #0x718]       | X8 = (string**)(1152921514955921488)("System error");
            // 0x00AB416C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x00AB4170: MOV x0, x21                | X0 = val_27;//m1                        
            // 0x00AB4174: MOV x5, x22                | X5 = System.String.Empty;//m1           
            // 0x00AB4178: LDR x1, [x8]               | X1 = "System error";                    
            // 0x00AB417C: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00AB4180: LDR x8, [x8, #0xeb0]       | X8 = (string**)(1152921514955921584)("Network connection error please restart the game");
            // 0x00AB4184: MOV x6, x23                | X6 = 1152921504687837184 (0x1000000004D3D000);//ML01
            // 0x00AB4188: MOV x7, xzr                | X7 = 0 (0x0);//ML01                     
            // 0x00AB418C: LDR x2, [x8]               | X2 = "Network connection error please restart the game";
            // 0x00AB4190: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x00AB4194: LDR x8, [x8, #0x4d8]       | X8 = (string**)(1152921514955921760)("Confirm");
            // 0x00AB4198: LDR x4, [x8]               | X4 = "Confirm";                         
            // 0x00AB419C: STR xzr, [sp]              | stack[1152921514955970688] = 0x0;        //  dest_result_addr=1152921514955970688
            // 0x00AB41A0: BL #0x13a69fc              | val_27.ShowDialog(title:  "System error", content:  "Network connection error please restart the game", cancelable:  false, okText:  "Confirm", cancelText:  System.String.Empty, OnOK:  val_28, OnCancel:  0);
            val_27.ShowDialog(title:  "System error", content:  "Network connection error please restart the game", cancelable:  false, okText:  "Confirm", cancelText:  System.String.Empty, OnOK:  val_28, OnCancel:  0);
            // 0x00AB41A4: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_70 = null;
            // 0x00AB41A8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB41AC: TBZ w8, #0, #0xab41c0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_73;
            // 0x00AB41B0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB41B4: CBNZ w8, #0xab41c0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
            // 0x00AB41B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB41BC: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_70 = null;
            label_73:
            // 0x00AB41C0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB41C4: LDR x20, [x8, #0x50]       | X20 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            // 0x00AB41C8: LDR x21, [x8, #0x90]       | X21 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB41CC: CBNZ x21, #0xab41d4        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_74;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_74;
            }
            // 0x00AB41D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_74:
            // 0x00AB41D4: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB41D8: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB41DC: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB41E0: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_29 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB41E4: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB41E8: MOV x21, x0                | X21 = val_29;//m1                       
            // 0x00AB41EC: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB41F0: LDR x22, [x8, #0x90]       | X22 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB41F4: CBNZ x22, #0xab41fc        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_75;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_75;
            }
            // 0x00AB41F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_75:
            // 0x00AB41FC: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB4200: MOV x0, x22                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB4204: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4208: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_30 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB420C: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00AB4210: LDR x8, [x8, #0xf10]       | X8 = (string**)(1152921514955930048)("{0} 不是ab包");
            // 0x00AB4214: MOV x2, x0                 | X2 = val_30;//m1                        
            // 0x00AB4218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB421C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB4220: LDR x1, [x8]               | X1 = "{0} 不是ab包";                       
            // 0x00AB4224: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0} 不是ab包");
            string val_31 = System.String.Format(format:  0, arg0:  "{0} 不是ab包");
            // 0x00AB4228: MOV x22, x0                | X22 = val_31;//m1                       
            // 0x00AB422C: CBNZ x20, #0xab4234        | if (Mihua.Asset.AssetMgr.m_DownloadingErrors != null) goto label_76;
            if(Mihua.Asset.AssetMgr.m_DownloadingErrors != null)
            {
                goto label_76;
            }
            // 0x00AB4230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_76:
            // 0x00AB4234: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x00AB4238: LDR x8, [x8, #0x310]       | X8 = 1152921509931601104;               
            // 0x00AB423C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors;//m1
            // 0x00AB4240: MOV x1, x21                | X1 = val_29;//m1                        
            val_66 = val_29;
            // 0x00AB4244: MOV x2, x22                | X2 = val_31;//m1                        
            val_67 = val_31;
            // 0x00AB4248: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
            val_68 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
            label_66:
            // 0x00AB424C: BL #0x23fd44c              | Mihua.Asset.AssetMgr.m_DownloadingErrors.Add(key:  val_66 = val_29, value:  val_67 = val_31);
            Mihua.Asset.AssetMgr.m_DownloadingErrors.Add(key:  val_66, value:  val_67);
            // 0x00AB4250: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_71 = null;
            // 0x00AB4254: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4258: TBZ w8, #0, #0xab426c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_78;
            // 0x00AB425C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4260: CBNZ w8, #0xab426c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_78;
            // 0x00AB4264: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB4268: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_71 = null;
            label_78:
            // 0x00AB426C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            label_58:
            // 0x00AB4270: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB4274: CBNZ x20, #0xab427c        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_79;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_79;
            }
            // 0x00AB4278: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_79:
            // 0x00AB427C: LDR x2, [x27]              | X2 = public UnityEngine.Networking.UnityWebRequest System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::get_Item(int index);
            // 0x00AB4280: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB4284: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4288: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_WWWList.get_Item(index:  0);
            UnityEngine.Networking.UnityWebRequest val_32 = Mihua.Asset.AssetMgr.m_WWWList.Item[0];
            // 0x00AB428C: MOV x20, x0                | X20 = val_32;//m1                       
            // 0x00AB4290: CBNZ x20, #0xab4298        | if (val_32 != null) goto label_80;      
            if(val_32 != null)
            {
                goto label_80;
            }
            // 0x00AB4294: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_80:
            // 0x00AB4298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB429C: MOV x0, x20                | X0 = val_32;//m1                        
            // 0x00AB42A0: BL #0x2756264              | val_32.Dispose();                       
            val_32.Dispose();
            // 0x00AB42A4: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB42A8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB42AC: LDR x20, [x8, #0x48]       | X20 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB42B0: LDR x21, [x8, #0x90]       | X21 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB42B4: CBNZ x21, #0xab42bc        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_81;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_81;
            }
            // 0x00AB42B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_81:
            // 0x00AB42BC: LDR x2, [x28]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB42C0: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB42C4: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB42C8: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_LoadingList.get_Item(index:  0);
            string val_33 = Mihua.Asset.AssetMgr.m_LoadingList.Item[0];
            // 0x00AB42CC: MOV x21, x0                | X21 = val_33;//m1                       
            // 0x00AB42D0: CBNZ x20, #0xab42d8        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_82;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_82;
            }
            // 0x00AB42D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_82:
            // 0x00AB42D8: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00AB42DC: LDR x8, [x8, #0x848]       | X8 = 1152921510808642064;               
            // 0x00AB42E0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB42E4: MOV x1, x21                | X1 = val_33;//m1                        
            // 0x00AB42E8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::Remove(System.String key);
            // 0x00AB42EC: BL #0x23f6190              | X0 = Mihua.Asset.AssetMgr.m_RefCountDic.Remove(key:  val_33);
            bool val_34 = Mihua.Asset.AssetMgr.m_RefCountDic.Remove(key:  val_33);
            // 0x00AB42F0: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB42F4: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB42F8: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB42FC: CBNZ x20, #0xab4304        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_83;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_83;
            }
            // 0x00AB4300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_83:
            // 0x00AB4304: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00AB4308: LDR x8, [x8, #0xdc0]       | X8 = 1152921514955942432;               
            // 0x00AB430C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB4310: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4314: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::RemoveAt(int index);
            // 0x00AB4318: BL #0x25ed00c              | Mihua.Asset.AssetMgr.m_WWWList.RemoveAt(index:  0);
            Mihua.Asset.AssetMgr.m_WWWList.RemoveAt(index:  0);
            // 0x00AB431C: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB4320: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4324: LDR x20, [x8, #0x90]       | X20 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB4328: CBNZ x20, #0xab3c98        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_85;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_85;
            }
            // 0x00AB432C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_WWWList, ????);
            // 0x00AB4330: B #0xab3c98                |  goto label_85;                         
            goto label_85;
            label_42:
            // 0x00AB4334: ADD w19, w19, #1           | W19 = (0 + 1);                          
            val_46 = val_46 + 1;
            // 0x00AB4338: B #0xab3cb0                |  goto label_86;                         
            goto label_86;
            label_29:
            // 0x00AB433C: ADRP x22, #0x362e000       | X22 = 56811520 (0x362E000);             
            // 0x00AB4340: ADRP x23, #0x3617000       | X23 = 56717312 (0x3617000);             
            // 0x00AB4344: ADRP x24, #0x35c7000       | X24 = 56389632 (0x35C7000);             
            // 0x00AB4348: LDR x22, [x22, #0x140]     | X22 = 1152921514955943456;              
            // 0x00AB434C: LDR x23, [x23, #0x260]     | X23 = 1152921514955944480;              
            val_51 = 1152921514955944480;
            // 0x00AB4350: LDR x24, [x24, #0xe80]     | X24 = 1152921514955945504;              
            // 0x00AB4354: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            var val_47 = 0;
            // 0x00AB4358: B #0xab436c                |  goto label_105;                        
            goto label_105;
            label_104:
            // 0x00AB435C: LDR x8, [x20]              | X8 =  typeof(System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>);
            // 0x00AB4360: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB4364: LDP x9, x1, [x8, #0x180]   | X9 = typeof(System.Collections.Generic.List<T>).__il2cppRuntimeField_180; X1 = typeof(System.Collections.Generic.List<T>).__il2cppRuntimeField_188; //  | 
            // 0x00AB4368: BLR x9                     | X0 = typeof(System.Collections.Generic.List<T>).__il2cppRuntimeField_180();
            label_105:
            // 0x00AB436C: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_72 = null;
            // 0x00AB4370: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4374: TBZ w8, #0, #0xab4388      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_89;
            // 0x00AB4378: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB437C: CBNZ w8, #0xab4388         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_89;
            // 0x00AB4380: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB4384: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_72 = null;
            label_89:
            // 0x00AB4388: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB438C: LDR x20, [x8, #0x58]       | X20 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB4390: CBNZ x20, #0xab4398        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_90;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_90;
            }
            // 0x00AB4394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_90:
            // 0x00AB4398: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::get_Count();
            // 0x00AB439C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB43A0: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations.get_Count();
            int val_35 = Mihua.Asset.AssetMgr.m_InProgressOperations.Count;
            // 0x00AB43A4: CMP w19, w0                | STATE = COMPARE(0x0, val_35)            
            // 0x00AB43A8: B.GE #0xab44c0             | if (0 >= val_35) goto label_91;         
            if(val_47 >= val_35)
            {
                goto label_91;
            }
            // 0x00AB43AC: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_73 = null;
            // 0x00AB43B0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB43B4: TBZ w8, #0, #0xab43c8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_93;
            // 0x00AB43B8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB43BC: CBNZ w8, #0xab43c8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_93;
            // 0x00AB43C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB43C4: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_73 = null;
            label_93:
            // 0x00AB43C8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB43CC: LDR x20, [x8, #0x58]       | X20 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB43D0: CBNZ x20, #0xab43d8        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_94;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_94;
            }
            // 0x00AB43D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_94:
            // 0x00AB43D8: LDR x2, [x23]              | X2 = public Mihua.Asset.ABLoadOperation.ABOperation System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::get_Item(int index);
            // 0x00AB43DC: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB43E0: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB43E4: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations.get_Item(index:  0);
            Mihua.Asset.ABLoadOperation.ABOperation val_36 = Mihua.Asset.AssetMgr.m_InProgressOperations.Item[0];
            // 0x00AB43E8: MOV x20, x0                | X20 = val_36;//m1                       
            // 0x00AB43EC: CBNZ x20, #0xab43f4        | if (val_36 != null) goto label_95;      
            if(val_36 != null)
            {
                goto label_95;
            }
            // 0x00AB43F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_95:
            // 0x00AB43F4: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.ABLoadOperation.ABOperation);
            // 0x00AB43F8: MOV x0, x20                | X0 = val_36;//m1                        
            // 0x00AB43FC: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1A0; X1 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1A8; //  | 
            // 0x00AB4400: BLR x9                     | X0 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1A0();
            // 0x00AB4404: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB4408: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB440C: LDR x20, [x8, #0x58]       | X20 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB4410: CBNZ x20, #0xab4418        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_96;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_96;
            }
            // 0x00AB4414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_96:
            // 0x00AB4418: LDR x2, [x23]              | X2 = public Mihua.Asset.ABLoadOperation.ABOperation System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::get_Item(int index);
            // 0x00AB441C: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB4420: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4424: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations.get_Item(index:  0);
            Mihua.Asset.ABLoadOperation.ABOperation val_37 = Mihua.Asset.AssetMgr.m_InProgressOperations.Item[0];
            // 0x00AB4428: MOV x20, x0                | X20 = val_37;//m1                       
            // 0x00AB442C: CBNZ x20, #0xab4434        | if (val_37 != null) goto label_97;      
            if(val_37 != null)
            {
                goto label_97;
            }
            // 0x00AB4430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_97:
            // 0x00AB4434: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.ABLoadOperation.ABOperation);
            // 0x00AB4438: MOV x0, x20                | X0 = val_37;//m1                        
            // 0x00AB443C: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1B0; X1 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1B8; //  | 
            // 0x00AB4440: BLR x9                     | X0 = typeof(Mihua.Asset.ABLoadOperation.ABOperation).__il2cppRuntimeField_1B0();
            // 0x00AB4444: TBZ w0, #0, #0xab44b8      | if ((val_37 & 0x1) == 0) goto label_98; 
            if((val_37 & 1) == 0)
            {
                goto label_98;
            }
            // 0x00AB4448: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_74 = null;
            // 0x00AB444C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4450: TBZ w8, #0, #0xab4464      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_100;
            // 0x00AB4454: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4458: CBNZ w8, #0xab4464         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_100;
            // 0x00AB445C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB4460: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_74 = null;
            label_100:
            // 0x00AB4464: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4468: LDR x20, [x8, #0x58]       | X20 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB446C: CBNZ x20, #0xab4474        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_101;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_101;
            }
            // 0x00AB4470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_101:
            // 0x00AB4474: LDR x2, [x23]              | X2 = public Mihua.Asset.ABLoadOperation.ABOperation System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::get_Item(int index);
            // 0x00AB4478: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB447C: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4480: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations.get_Item(index:  0);
            Mihua.Asset.ABLoadOperation.ABOperation val_38 = Mihua.Asset.AssetMgr.m_InProgressOperations.Item[0];
            // 0x00AB4484: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB4488: MOV x20, x0                | X20 = val_38;//m1                       
            // 0x00AB448C: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4490: LDR x21, [x8, #0x58]       | X21 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB4494: CBNZ x21, #0xab449c        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_102;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_102;
            }
            // 0x00AB4498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_102:
            // 0x00AB449C: LDR x2, [x24]              | X2 = public System.Void System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::RemoveAt(int index);
            // 0x00AB44A0: MOV x0, x21                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB44A4: MOV w1, w19                | W1 = 0 (0x0);//ML01                     
            // 0x00AB44A8: BL #0x25ed00c              | Mihua.Asset.AssetMgr.m_InProgressOperations.RemoveAt(index:  0);
            Mihua.Asset.AssetMgr.m_InProgressOperations.RemoveAt(index:  0);
            // 0x00AB44AC: CBNZ x20, #0xab435c        | if (val_38 != null) goto label_104;     
            if(val_38 != null)
            {
                goto label_104;
            }
            // 0x00AB44B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_InProgressOperations, ????);
            // 0x00AB44B4: B #0xab435c                |  goto label_104;                        
            goto label_104;
            label_98:
            // 0x00AB44B8: ADD w19, w19, #1           | W19 = (0 + 1);                          
            val_47 = val_47 + 1;
            // 0x00AB44BC: B #0xab436c                |  goto label_105;                        
            goto label_105;
            label_91:
            // 0x00AB44C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB44C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB44C8: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
            float val_39 = UnityEngine.Time.realtimeSinceStartup;
            // 0x00AB44CC: ADRP x20, #0x35fc000       | X20 = 56606720 (0x35FC000);             
            // 0x00AB44D0: LDR x20, [x20, #0xb58]     | X20 = 1152921510022759280;              
            // 0x00AB44D4: MOV v8.16b, v0.16b         | V8 = val_39;//m1                        
            label_115:
            // 0x00AB44D8: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_75 = null;
            // 0x00AB44DC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB44E0: TBZ w8, #0, #0xab44f4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_107;
            // 0x00AB44E4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB44E8: CBNZ w8, #0xab44f4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_107;
            // 0x00AB44EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB44F0: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_75 = null;
            label_107:
            // 0x00AB44F4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB44F8: LDR x19, [x8, #0x88]       | X19 = Mihua.Asset.AssetMgr.m_WaitList;  
            val_55 = Mihua.Asset.AssetMgr.m_WaitList;
            // 0x00AB44FC: CBNZ x19, #0xab4504        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_108;
            if(val_55 != null)
            {
                goto label_108;
            }
            // 0x00AB4500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_108:
            // 0x00AB4504: LDR x1, [x20]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB4508: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB450C: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.m_WaitList.get_Count();
            int val_40 = val_55.Count;
            // 0x00AB4510: CMP w0, #1                 | STATE = COMPARE(val_40, 0x1)            
            // 0x00AB4514: B.LT #0xab4578             | if (val_40 < 1) goto label_112;         
            if(val_40 < 1)
            {
                goto label_112;
            }
            // 0x00AB4518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB451C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4520: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
            float val_41 = UnityEngine.Time.realtimeSinceStartup;
            // 0x00AB4524: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_76 = null;
            // 0x00AB4528: MOV v9.16b, v0.16b         | V9 = val_41;//m1                        
            // 0x00AB452C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4530: TBZ w8, #0, #0xab4544      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_111;
            // 0x00AB4534: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4538: CBNZ w8, #0xab4544         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_111;
            // 0x00AB453C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB4540: LDR x0, [x25]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_76 = null;
            label_111:
            // 0x00AB4544: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4548: FSUB s1, s9, s8            | S1 = (val_41 - val_39);                 
            float val_42 = val_41 - val_39;
            // 0x00AB454C: LDR s0, [x8]               | S0 = Mihua.Asset.AssetMgr.maxTime;      
            // 0x00AB4550: FCMP s1, s0                | STATE = COMPARE((val_41 - val_39), Mihua.Asset.AssetMgr.maxTime)
            // 0x00AB4554: B.PL #0xab4578             | if (val_42 >= 0) goto label_112;        
            if(val_42 >= 0)
            {
                goto label_112;
            }
            // 0x00AB4558: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB455C: TBZ w8, #0, #0xab456c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_114;
            // 0x00AB4560: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4564: CBNZ w8, #0xab456c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_114;
            // 0x00AB4568: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_114:
            // 0x00AB456C: BL #0xab3258               | X0 = Mihua.Asset.AssetMgr.LoadNext();   
            bool val_43 = Mihua.Asset.AssetMgr.LoadNext();
            // 0x00AB4570: AND w8, w0, #1             | W8 = (val_43 & 1);                      
            bool val_44 = val_43;
            // 0x00AB4574: TBNZ w8, #0, #0xab44d8     | if ((val_43 & 1) == true) goto label_115;
            if(val_44 == true)
            {
                goto label_115;
            }
            label_112:
            // 0x00AB4578: SUB sp, x29, #0x60         | SP = (1152921514955970800 - 96) = 1152921514955970704 (0x1000000268DB1890);
            // 0x00AB457C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB4580: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB4584: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB4588: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB458C: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB4590: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00AB4594: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00AB4598: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB48F8 (11225336), len: 912  VirtAddr: 0x00AB48F8 RVA: 0x00AB48F8 token: 100693231 methodIndex: 46985 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool Exists(string assetName)
        {
            //
            // Disasemble & Code
            //  | 
            string val_10;
            //  | 
            System.String[] val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            System.Object[] val_14;
            //  | 
            var val_15;
            // 0x00AB48F8: STP x24, x23, [sp, #-0x40]! | stack[1152921514956201840] = ???;  stack[1152921514956201848] = ???;  //  dest_result_addr=1152921514956201840 |  dest_result_addr=1152921514956201848
            // 0x00AB48FC: STP x22, x21, [sp, #0x10]  | stack[1152921514956201856] = ???;  stack[1152921514956201864] = ???;  //  dest_result_addr=1152921514956201856 |  dest_result_addr=1152921514956201864
            // 0x00AB4900: STP x20, x19, [sp, #0x20]  | stack[1152921514956201872] = ???;  stack[1152921514956201880] = ???;  //  dest_result_addr=1152921514956201872 |  dest_result_addr=1152921514956201880
            // 0x00AB4904: STP x29, x30, [sp, #0x30]  | stack[1152921514956201888] = ???;  stack[1152921514956201896] = ???;  //  dest_result_addr=1152921514956201888 |  dest_result_addr=1152921514956201896
            // 0x00AB4908: ADD x29, sp, #0x30         | X29 = (1152921514956201840 + 48) = 1152921514956201888 (0x1000000268DE9FA0);
            // 0x00AB490C: SUB sp, sp, #0x10          | SP = (1152921514956201840 - 16) = 1152921514956201824 (0x1000000268DE9F60);
            // 0x00AB4910: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB4914: LDRB w8, [x19, #0x404]     | W8 = (bool)static_value_03733404;       
            // 0x00AB4918: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00AB491C: TBNZ w8, #0, #0xab4938     | if (static_value_03733404 == true) goto label_0;
            // 0x00AB4920: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x00AB4924: LDR x8, [x8, #0xce8]       | X8 = 0x2B8EB20;                         
            // 0x00AB4928: LDR w0, [x8]               | W0 = 0x1188;                            
            // 0x00AB492C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1188, ????);     
            // 0x00AB4930: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB4934: STRB w8, [x19, #0x404]     | static_value_03733404 = true;            //  dest_result_addr=57881604
            label_0:
            // 0x00AB4938: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB493C: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00AB4940: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4944: STR xzr, [sp, #8]          | stack[1152921514956201832] = 0x0;        //  dest_result_addr=1152921514956201832
            // 0x00AB4948: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB494C: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_1 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB4950: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00AB4954: CBNZ x19, #0xab495c        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00AB4958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00AB495C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB4960: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00AB4964: MOV x1, x20                | X1 = X1;//m1                            
            // 0x00AB4968: BL #0xb42c00               | X0 = val_1.LoadPathToABPath(path:  X1); 
            string val_2 = val_1.LoadPathToABPath(path:  X1);
            // 0x00AB496C: ADRP x24, #0x3671000       | X24 = 57085952 (0x3671000);             
            // 0x00AB4970: LDR x24, [x24, #0xf30]     | X24 = 1152921504903544832;              
            // 0x00AB4974: MOV x19, x0                | X19 = val_2;//m1                        
            val_11 = val_2;
            // 0x00AB4978: LDR x8, [x24]              | X8 = typeof(Mihua.Assets.AssetUtil);    
            string val_12 = null;
            // 0x00AB497C: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB4980: TBZ w9, #0, #0xab4994      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB4984: LDR w9, [x8, #0xbc]        | W9 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4988: CBNZ w9, #0xab4994         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB498C: MOV x0, x8                 | X0 = 1152921504903544832 (0x1000000011AF4000);//ML01
            val_10 = val_12;
            // 0x00AB4990: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_3:
            // 0x00AB4994: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x00AB4998: BL #0xab4c88               | X0 = Mihua.Assets.AssetUtil.Exists(abName:  val_10 = null);
            bool val_3 = Mihua.Assets.AssetUtil.Exists(abName:  val_10);
            // 0x00AB499C: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            val_12 = val_3;
            // 0x00AB49A0: TBZ w8, #0, #0xab4b64      | if ((val_3 & 1) == false) goto label_4; 
            if(val_12 == false)
            {
                goto label_4;
            }
            // 0x00AB49A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB49A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB49AC: ADD x2, sp, #8             | X2 = (1152921514956201824 + 8) = 1152921514956201832 (0x1000000268DE9F68);
            // 0x00AB49B0: MOV x1, x19                | X1 = val_2;//m1                         
            System.String[] val_4 = val_11;
            // 0x00AB49B4: BL #0xb1bd48               | X0 = ABDepends.GetDepend(key:  0, depends: out  System.String[] val_4 = val_11);
            bool val_5 = ABDepends.GetDepend(key:  0, depends: out  val_4);
            // 0x00AB49B8: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x00AB49BC: TBZ w8, #0, #0xab4c6c      | if ((val_5 & 1) == false) goto label_8; 
            if(val_6 == false)
            {
                goto label_8;
            }
            // 0x00AB49C0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_12 = 0;
            // 0x00AB49C4: B #0xab49cc                |  goto label_6;                          
            goto label_6;
            label_13:
            // 0x00AB49C8: ADD w22, w22, #1           | W22 = (val_12 + 1) = val_12 (0x00000001);
            val_12 = 1;
            label_6:
            // 0x00AB49CC: LDR x21, [sp, #8]          | X21 = 0x0;                              
            val_13 = 0;
            // 0x00AB49D0: CBNZ x21, #0xab49d8        | if (0x0 != 0) goto label_7;             
            if(val_13 != 0)
            {
                goto label_7;
            }
            // 0x00AB49D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_7:
            // 0x00AB49D8: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB49DC: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB49E0: B.GE #0xab4c6c             | if (val_12 >= 9966784) goto label_8;    
            if(val_12 >= 9966784)
            {
                goto label_8;
            }
            // 0x00AB49E4: LDR x21, [sp, #8]          | X21 = 0x0;                              
            // 0x00AB49E8: CBNZ x21, #0xab49f0        | if (0x0 != 0) goto label_9;             
            if(0 != 0)
            {
                goto label_9;
            }
            // 0x00AB49EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_9:
            // 0x00AB49F0: LDR w8, [x21, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB49F4: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x00AB49F8: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB49FC: B.LO #0xab4a0c             | if (val_12 < 9966784) goto label_10;    
            if(val_12 < 9966784)
            {
                goto label_10;
            }
            // 0x00AB4A00: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00AB4A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4A08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_10:
            // 0x00AB4A0C: LDR x0, [x24]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB4A10: ADD x8, x21, x23, lsl #3   | X8 = (0 + 8);                           
            var val_7 = 0 + 8;
            // 0x00AB4A14: LDR x21, [x8, #0x20]       | X21 = (0 + 8) + 32;                     
            // 0x00AB4A18: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB4A1C: TBZ w8, #0, #0xab4a2c      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00AB4A20: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4A24: CBNZ w8, #0xab4a2c         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00AB4A28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_12:
            // 0x00AB4A2C: MOV x1, x21                | X1 = (0 + 8) + 32;//m1                  
            // 0x00AB4A30: BL #0xab4c88               | X0 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            bool val_8 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            // 0x00AB4A34: AND w8, w0, #1             | W8 = (val_8 & 1);                       
            bool val_9 = val_8;
            // 0x00AB4A38: TBNZ w8, #0, #0xab49c8     | if ((val_8 & 1) == true) goto label_13; 
            if(val_9 == true)
            {
                goto label_13;
            }
            // 0x00AB4A3C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AB4A40: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AB4A44: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AB4A48: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB4A4C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB4A50: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00AB4A54: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB4A58: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB4A5C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_13 = null;
            // 0x00AB4A60: CBNZ x21, #0xab4a68        | if ( != null) goto label_14;            
            if(null != null)
            {
                goto label_14;
            }
            // 0x00AB4A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_14:
            // 0x00AB4A68: CBZ x20, #0xab4a8c         | if (X1 == 0) goto label_16;             
            if(X1 == 0)
            {
                goto label_16;
            }
            // 0x00AB4A6C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB4A70: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00AB4A74: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB4A78: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x00AB4A7C: CBNZ x0, #0xab4a8c         | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x00AB4A80: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
            // 0x00AB4A84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4A88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_16:
            // 0x00AB4A8C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB4A90: CBNZ w8, #0xab4aa0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_17;
            // 0x00AB4A94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
            // 0x00AB4A98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4A9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_17:
            // 0x00AB4AA0: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
            // 0x00AB4AA4: CBZ x19, #0xab4ac8         | if (val_2 == null) goto label_19;       
            if(val_11 == null)
            {
                goto label_19;
            }
            // 0x00AB4AA8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB4AAC: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00AB4AB0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB4AB4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00AB4AB8: CBNZ x0, #0xab4ac8         | if (val_2 != null) goto label_19;       
            if(val_11 != null)
            {
                goto label_19;
            }
            // 0x00AB4ABC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00AB4AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4AC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_19:
            // 0x00AB4AC8: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB4ACC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AB4AD0: B.HI #0xab4ae0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_20;
            // 0x00AB4AD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB4AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4ADC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_20:
            // 0x00AB4AE0: STR x19, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_11;
            // 0x00AB4AE4: LDR x19, [sp, #8]          | X19 = 0x0;                              
            // 0x00AB4AE8: CBNZ x19, #0xab4af0        | if (0x0 != 0) goto label_21;            
            if(0 != 0)
            {
                goto label_21;
            }
            // 0x00AB4AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_21:
            // 0x00AB4AF0: LDR w8, [x19, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB4AF4: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB4AF8: B.LO #0xab4b08             | if (val_12 < 9966784) goto label_22;    
            if(val_12 < 9966784)
            {
                goto label_22;
            }
            // 0x00AB4AFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB4B00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4B04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_22:
            // 0x00AB4B08: ADD x8, x19, x23, lsl #3   | X8 = (0 + 8);                           
            var val_10 = 0 + 8;
            // 0x00AB4B0C: LDR x19, [x8, #0x20]       | X19 = (0 + 8) + 32;                     
            // 0x00AB4B10: CBNZ x21, #0xab4b18        | if ( != null) goto label_23;            
            if(null != null)
            {
                goto label_23;
            }
            // 0x00AB4B14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_23:
            // 0x00AB4B18: CBZ x19, #0xab4b3c         | if ((0 + 8) + 32 == 0) goto label_25;   
            if(((0 + 8) + 32) == 0)
            {
                goto label_25;
            }
            // 0x00AB4B1C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB4B20: MOV x0, x19                | X0 = (0 + 8) + 32;//m1                  
            // 0x00AB4B24: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB4B28: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? (0 + 8) + 32, ????);
            // 0x00AB4B2C: CBNZ x0, #0xab4b3c         | if ((0 + 8) + 32 != 0) goto label_25;   
            if(((0 + 8) + 32) != 0)
            {
                goto label_25;
            }
            // 0x00AB4B30: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? (0 + 8) + 32, ????);
            // 0x00AB4B34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4B38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (0 + 8) + 32, ????);
            label_25:
            // 0x00AB4B3C: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB4B40: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00AB4B44: B.HI #0xab4b54             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_26;
            // 0x00AB4B48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (0 + 8) + 32, ????);
            // 0x00AB4B4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4B50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (0 + 8) + 32, ????);
            label_26:
            // 0x00AB4B54: STR x19, [x21, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = (0 + 8) + 32;  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = (0 + 8) + 32;
            // 0x00AB4B58: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x00AB4B5C: LDR x8, [x8, #0x3f8]       | X8 = (string**)(1152921514956185504)("资源还未下载 assetname:{0} abname:{1} dep:{2}");
            val_14 = "资源还未下载 assetname:{0} abname:{1} dep:{2}";
            // 0x00AB4B60: B #0xab4c14                |  goto label_27;                         
            goto label_27;
            label_4:
            // 0x00AB4B64: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AB4B68: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AB4B6C: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AB4B70: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB4B74: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AB4B78: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00AB4B7C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB4B80: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AB4B84: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            val_13 = null;
            // 0x00AB4B88: CBNZ x21, #0xab4b90        | if ( != null) goto label_28;            
            if(null != null)
            {
                goto label_28;
            }
            // 0x00AB4B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_28:
            // 0x00AB4B90: CBZ x20, #0xab4bb4         | if (X1 == 0) goto label_30;             
            if(X1 == 0)
            {
                goto label_30;
            }
            // 0x00AB4B94: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB4B98: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00AB4B9C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB4BA0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x00AB4BA4: CBNZ x0, #0xab4bb4         | if (X1 != 0) goto label_30;             
            if(X1 != 0)
            {
                goto label_30;
            }
            // 0x00AB4BA8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? X1, ????);         
            // 0x00AB4BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4BB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_30:
            // 0x00AB4BB4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB4BB8: CBNZ w8, #0xab4bc8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_31;
            // 0x00AB4BBC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
            // 0x00AB4BC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4BC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_31:
            // 0x00AB4BC8: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = X1;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = X1;
            // 0x00AB4BCC: CBZ x19, #0xab4bf0         | if (val_2 == null) goto label_33;       
            if(val_11 == null)
            {
                goto label_33;
            }
            // 0x00AB4BD0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AB4BD4: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00AB4BD8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB4BDC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00AB4BE0: CBNZ x0, #0xab4bf0         | if (val_2 != null) goto label_33;       
            if(val_11 != null)
            {
                goto label_33;
            }
            // 0x00AB4BE4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00AB4BE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4BEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_33:
            // 0x00AB4BF0: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AB4BF4: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AB4BF8: B.HI #0xab4c08             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_34;
            // 0x00AB4BFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB4C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4C04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_34:
            // 0x00AB4C08: STR x19, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_2;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_11;
            // 0x00AB4C0C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00AB4C10: LDR x8, [x8, #0x190]       | X8 = (string**)(1152921514956185664)("资源还未下载 assetname:{0} abname:{1}");
            val_14 = "资源还未下载 assetname:{0} abname:{1}";
            label_27:
            // 0x00AB4C14: LDR x1, [x8]               | X1 = "资源还未下载 assetname:{0} abname:{1}"; 
            // 0x00AB4C18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4C1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB4C20: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AB4C24: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  val_14 = "资源还未下载 assetname:{0} abname:{1}");
            string val_11 = EString.EFormat(format:  0, args:  val_14);
            // 0x00AB4C28: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB4C2C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
            // 0x00AB4C30: MOV x19, x0                | X19 = val_11;//m1                       
            val_11 = val_11;
            // 0x00AB4C34: LDR x8, [x8]               | X8 = typeof(EDebug);                    
            // 0x00AB4C38: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB4C3C: TBZ w9, #0, #0xab4c50      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x00AB4C40: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4C44: CBNZ w9, #0xab4c50         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x00AB4C48: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB4C4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            label_36:
            // 0x00AB4C50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4C54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB4C58: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB4C5C: MOV x1, x19                | X1 = val_11;//m1                        
            // 0x00AB4C60: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_11);
            EDebug.Log(message:  0, isShowStack:  val_11);
            // 0x00AB4C64: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_15 = 0;
            // 0x00AB4C68: B #0xab4c70                |  goto label_37;                         
            goto label_37;
            label_8:
            // 0x00AB4C6C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_15 = 1;
            label_37:
            // 0x00AB4C70: SUB sp, x29, #0x30         | SP = (1152921514956201888 - 48) = 1152921514956201840 (0x1000000268DE9F70);
            // 0x00AB4C74: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB4C78: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB4C7C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB4C80: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB4C84: RET                        |  return (System.Boolean)true;           
            return (bool)val_15;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB4EBC (11226812), len: 220  VirtAddr: 0x00AB4EBC RVA: 0x00AB4EBC token: 100693232 methodIndex: 46986 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool Exists(System.Collections.Generic.List<string> assetNames)
        {
            //
            // Disasemble & Code
            //  | 
            string val_4;
            //  | 
            var val_5;
            // 0x00AB4EBC: STP x24, x23, [sp, #-0x40]! | stack[1152921514956338416] = ???;  stack[1152921514956338424] = ???;  //  dest_result_addr=1152921514956338416 |  dest_result_addr=1152921514956338424
            // 0x00AB4EC0: STP x22, x21, [sp, #0x10]  | stack[1152921514956338432] = ???;  stack[1152921514956338440] = ???;  //  dest_result_addr=1152921514956338432 |  dest_result_addr=1152921514956338440
            // 0x00AB4EC4: STP x20, x19, [sp, #0x20]  | stack[1152921514956338448] = ???;  stack[1152921514956338456] = ???;  //  dest_result_addr=1152921514956338448 |  dest_result_addr=1152921514956338456
            // 0x00AB4EC8: STP x29, x30, [sp, #0x30]  | stack[1152921514956338464] = ???;  stack[1152921514956338472] = ???;  //  dest_result_addr=1152921514956338464 |  dest_result_addr=1152921514956338472
            // 0x00AB4ECC: ADD x29, sp, #0x30         | X29 = (1152921514956338416 + 48) = 1152921514956338464 (0x1000000268E0B520);
            // 0x00AB4ED0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB4ED4: LDRB w8, [x20, #0x405]     | W8 = (bool)static_value_03733405;       
            // 0x00AB4ED8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB4EDC: TBNZ w8, #0, #0xab4ef8     | if (static_value_03733405 == true) goto label_0;
            // 0x00AB4EE0: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00AB4EE4: LDR x8, [x8, #0x420]       | X8 = 0x2B8EB1C;                         
            // 0x00AB4EE8: LDR w0, [x8]               | W0 = 0x1187;                            
            // 0x00AB4EEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1187, ????);     
            // 0x00AB4EF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB4EF4: STRB w8, [x20, #0x405]     | static_value_03733405 = true;            //  dest_result_addr=57881605
            label_0:
            // 0x00AB4EF8: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
            // 0x00AB4EFC: ADRP x23, #0x35bd000       | X23 = 56348672 (0x35BD000);             
            // 0x00AB4F00: ADRP x24, #0x35c8000       | X24 = 56393728 (0x35C8000);             
            // 0x00AB4F04: LDR x22, [x22, #0xb58]     | X22 = 1152921510022759280;              
            // 0x00AB4F08: LDR x23, [x23, #0xb50]     | X23 = 1152921510890998992;              
            // 0x00AB4F0C: LDR x24, [x24, #0x270]     | X24 = 1152921504903331840;              
            // 0x00AB4F10: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            var val_4 = 0;
            label_6:
            // 0x00AB4F14: CBNZ x19, #0xab4f1c        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00AB4F18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1187, ????);     
            label_1:
            // 0x00AB4F1C: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB4F20: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00AB4F24: BL #0x25ed72c              | X0 = X1.get_Count();                    
            int val_1 = X1.Count;
            // 0x00AB4F28: CMP w20, w0                | STATE = COMPARE(0x0, val_1)             
            // 0x00AB4F2C: B.GE #0xab4f80             | if (0 >= val_1) goto label_2;           
            if(val_4 >= val_1)
            {
                goto label_2;
            }
            // 0x00AB4F30: CBNZ x19, #0xab4f38        | if (X1 != 0) goto label_3;              
            if(X1 != 0)
            {
                goto label_3;
            }
            // 0x00AB4F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00AB4F38: LDR x2, [x23]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB4F3C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00AB4F40: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
            // 0x00AB4F44: BL #0x25ed734              | X0 = X1.get_Item(index:  0);            
            string val_2 = X1.Item[0];
            // 0x00AB4F48: LDR x8, [x24]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB4F4C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AB4F50: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4F54: TBZ w9, #0, #0xab4f68      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00AB4F58: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4F5C: CBNZ w9, #0xab4f68         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00AB4F60: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            val_4 = null;
            // 0x00AB4F64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_5:
            // 0x00AB4F68: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00AB4F6C: BL #0xab48f8               | X0 = Mihua.Asset.AssetMgr.Exists(assetName:  val_4 = null);
            bool val_3 = Mihua.Asset.AssetMgr.Exists(assetName:  val_4);
            // 0x00AB4F70: ADD w20, w20, #1           | W20 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x00AB4F74: TBNZ w0, #0, #0xab4f14     | if (val_3 == true) goto label_6;        
            if(val_3 == true)
            {
                goto label_6;
            }
            // 0x00AB4F78: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AB4F7C: B #0xab4f84                |  goto label_7;                          
            goto label_7;
            label_2:
            // 0x00AB4F80: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_5 = 1;
            label_7:
            // 0x00AB4F84: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB4F88: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB4F8C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB4F90: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB4F94: RET                        |  return (System.Boolean)true;           
            return (bool)val_5;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB4F98 (11227032), len: 672  VirtAddr: 0x00AB4F98 RVA: 0x00AB4F98 token: 100693233 methodIndex: 46987 delegateWrapperIndex: 0 methodInvoker: 0
        public static void DownLoad(string assetName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x00AB4F98: STP x26, x25, [sp, #-0x50]! | stack[1152921514956479168] = ???;  stack[1152921514956479176] = ???;  //  dest_result_addr=1152921514956479168 |  dest_result_addr=1152921514956479176
            // 0x00AB4F9C: STP x24, x23, [sp, #0x10]  | stack[1152921514956479184] = ???;  stack[1152921514956479192] = ???;  //  dest_result_addr=1152921514956479184 |  dest_result_addr=1152921514956479192
            // 0x00AB4FA0: STP x22, x21, [sp, #0x20]  | stack[1152921514956479200] = ???;  stack[1152921514956479208] = ???;  //  dest_result_addr=1152921514956479200 |  dest_result_addr=1152921514956479208
            // 0x00AB4FA4: STP x20, x19, [sp, #0x30]  | stack[1152921514956479216] = ???;  stack[1152921514956479224] = ???;  //  dest_result_addr=1152921514956479216 |  dest_result_addr=1152921514956479224
            // 0x00AB4FA8: STP x29, x30, [sp, #0x40]  | stack[1152921514956479232] = ???;  stack[1152921514956479240] = ???;  //  dest_result_addr=1152921514956479232 |  dest_result_addr=1152921514956479240
            // 0x00AB4FAC: ADD x29, sp, #0x40         | X29 = (1152921514956479168 + 64) = 1152921514956479232 (0x1000000268E2DB00);
            // 0x00AB4FB0: SUB sp, sp, #0x10          | SP = (1152921514956479168 - 16) = 1152921514956479152 (0x1000000268E2DAB0);
            // 0x00AB4FB4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB4FB8: LDRB w8, [x20, #0x406]     | W8 = (bool)static_value_03733406;       
            // 0x00AB4FBC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB4FC0: TBNZ w8, #0, #0xab4fdc     | if (static_value_03733406 == true) goto label_0;
            // 0x00AB4FC4: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00AB4FC8: LDR x8, [x8, #0xa48]       | X8 = 0x2B8EB10;                         
            // 0x00AB4FCC: LDR w0, [x8]               | W0 = 0x1184;                            
            // 0x00AB4FD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1184, ????);     
            // 0x00AB4FD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB4FD8: STRB w8, [x20, #0x406]     | static_value_03733406 = true;            //  dest_result_addr=57881606
            label_0:
            // 0x00AB4FDC: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB4FE0: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00AB4FE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4FE8: STR xzr, [sp, #8]          | stack[1152921514956479160] = 0x0;        //  dest_result_addr=1152921514956479160
            // 0x00AB4FEC: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB4FF0: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_1 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB4FF4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AB4FF8: CBNZ x20, #0xab5000        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00AB4FFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00AB5000: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB5004: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00AB5008: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB500C: BL #0xb42c00               | X0 = val_1.LoadPathToABPath(path:  X1); 
            string val_2 = val_1.LoadPathToABPath(path:  X1);
            // 0x00AB5010: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00AB5014: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x00AB5018: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AB501C: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x00AB5020: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_3 = null;
            // 0x00AB5024: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB5028: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00AB502C: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x00AB5030: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB5034: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB5038: BL #0x25e9474              | .ctor();                                
            val_3 = new System.Collections.Generic.List<System.String>();
            // 0x00AB503C: ADRP x21, #0x3671000       | X21 = 57085952 (0x3671000);             
            // 0x00AB5040: LDR x21, [x21, #0xf30]     | X21 = 1152921504903544832;              
            // 0x00AB5044: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB5048: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB504C: TBZ w8, #0, #0xab505c      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB5050: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5054: CBNZ w8, #0xab505c         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB5058: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_3:
            // 0x00AB505C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00AB5060: BL #0xab4c88               | X0 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            bool val_4 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            // 0x00AB5064: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x00AB5068: TBNZ w8, #0, #0xab508c     | if ((val_4 & 1) == true) goto label_4;  
            if(val_5 == true)
            {
                goto label_4;
            }
            // 0x00AB506C: CBNZ x19, #0xab5074        | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x00AB5070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_5:
            // 0x00AB5074: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB5078: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x00AB507C: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB5080: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00AB5084: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB5088: BL #0x25ea480              | Add(item:  val_2);                      
            Add(item:  val_2);
            label_4:
            // 0x00AB508C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5090: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB5094: ADD x2, sp, #8             | X2 = (1152921514956479152 + 8) = 1152921514956479160 (0x1000000268E2DAB8);
            // 0x00AB5098: MOV x1, x20                | X1 = val_2;//m1                         
            System.String[] val_6 = val_2;
            // 0x00AB509C: BL #0xb1bd48               | X0 = ABDepends.GetDepend(key:  0, depends: out  System.String[] val_6 = val_2);
            bool val_7 = ABDepends.GetDepend(key:  0, depends: out  val_6);
            // 0x00AB50A0: TBZ w0, #0, #0xab5170      | if (val_7 == false) goto label_9;       
            if(val_7 == false)
            {
                goto label_9;
            }
            // 0x00AB50A4: ADRP x23, #0x35e6000       | X23 = 56516608 (0x35E6000);             
            // 0x00AB50A8: LDR x23, [x23, #0x500]     | X23 = 1152921510890816336;              
            // 0x00AB50AC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x00AB50B0: B #0xab50b8                |  goto label_7;                          
            goto label_7;
            label_18:
            // 0x00AB50B4: ADD w22, w22, #1           | W22 = (val_13 + 1) = val_13 (0x00000001);
            val_13 = 1;
            label_7:
            // 0x00AB50B8: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB50BC: CBNZ x20, #0xab50c4        | if (0x0 != 0) goto label_8;             
            if(0 != 0)
            {
                goto label_8;
            }
            // 0x00AB50C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_8:
            // 0x00AB50C4: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB50C8: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB50CC: B.GE #0xab5170             | if (val_13 >= 9966784) goto label_9;    
            if(val_13 >= 9966784)
            {
                goto label_9;
            }
            // 0x00AB50D0: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB50D4: CBNZ x20, #0xab50dc        | if (0x0 != 0) goto label_10;            
            if(0 != 0)
            {
                goto label_10;
            }
            // 0x00AB50D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_10:
            // 0x00AB50DC: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB50E0: SXTW x24, w22              | X24 = 1 (0x00000001);                   
            // 0x00AB50E4: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB50E8: B.LO #0xab50f8             | if (val_13 < 9966784) goto label_11;    
            if(val_13 < 9966784)
            {
                goto label_11;
            }
            // 0x00AB50EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x00AB50F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB50F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_11:
            // 0x00AB50F8: LDR x0, [x21]              | X0 = typeof(Mihua.Assets.AssetUtil);    
            // 0x00AB50FC: ADD x8, x20, x24, lsl #3   | X8 = (0 + 8);                           
            var val_8 = 0 + 8;
            // 0x00AB5100: LDR x20, [x8, #0x20]       | X20 = (0 + 8) + 32;                     
            // 0x00AB5104: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_10A;
            // 0x00AB5108: TBZ w8, #0, #0xab5118      | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00AB510C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5110: CBNZ w8, #0xab5118         | if (Mihua.Assets.AssetUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00AB5114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Assets.AssetUtil), ????);
            label_13:
            // 0x00AB5118: MOV x1, x20                | X1 = (0 + 8) + 32;//m1                  
            // 0x00AB511C: BL #0xab4c88               | X0 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            bool val_9 = Mihua.Assets.AssetUtil.Exists(abName:  null);
            // 0x00AB5120: AND w8, w0, #1             | W8 = (val_9 & 1);                       
            bool val_10 = val_9;
            // 0x00AB5124: TBNZ w8, #0, #0xab50b4     | if ((val_9 & 1) == true) goto label_18; 
            if(val_10 == true)
            {
                goto label_18;
            }
            // 0x00AB5128: LDR x20, [sp, #8]          | X20 = 0x0;                              
            // 0x00AB512C: CBNZ x20, #0xab5134        | if (0x0 != 0) goto label_15;            
            if(0 != 0)
            {
                goto label_15;
            }
            // 0x00AB5130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_15:
            // 0x00AB5134: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
            // 0x00AB5138: CMP w22, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x00AB513C: B.LO #0xab514c             | if (val_13 < 9966784) goto label_16;    
            if(val_13 < 9966784)
            {
                goto label_16;
            }
            // 0x00AB5140: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x00AB5144: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5148: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_16:
            // 0x00AB514C: ADD x8, x20, x24, lsl #3   | X8 = (0 + 8);                           
            var val_11 = 0 + 8;
            // 0x00AB5150: LDR x20, [x8, #0x20]       | X20 = (0 + 8) + 32;                     
            // 0x00AB5154: CBNZ x19, #0xab515c        | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x00AB5158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_17:
            // 0x00AB515C: LDR x2, [x23]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB5160: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB5164: MOV x1, x20                | X1 = (0 + 8) + 32;//m1                  
            // 0x00AB5168: BL #0x25ea480              | Add(item:  (0 + 8) + 32);               
            Add(item:  (0 + 8) + 32);
            // 0x00AB516C: B #0xab50b4                |  goto label_18;                         
            goto label_18;
            label_9:
            // 0x00AB5170: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
            // 0x00AB5174: ADRP x23, #0x35bd000       | X23 = 56348672 (0x35BD000);             
            // 0x00AB5178: ADRP x24, #0x363d000       | X24 = 56872960 (0x363D000);             
            // 0x00AB517C: ADRP x25, #0x3618000       | X25 = 56721408 (0x3618000);             
            // 0x00AB5180: LDR x22, [x22, #0xb58]     | X22 = 1152921510022759280;              
            // 0x00AB5184: LDR x23, [x23, #0xb50]     | X23 = 1152921510890998992;              
            // 0x00AB5188: LDR x24, [x24, #0xb70]     | X24 = (string**)(1152921514956458960)("需要下载：{0}");
            // 0x00AB518C: LDR x25, [x25, #0x530]     | X25 = 1152921504924098560;              
            // 0x00AB5190: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x00AB5194: B #0xab51b0                |  goto label_19;                         
            goto label_19;
            label_25:
            // 0x00AB5198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB519C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB51A0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AB51A4: MOV x1, x21                | X1 = 57994000 (0x374EB10);//ML01        
            // 0x00AB51A8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
            EDebug.Log(message:  0, isShowStack:  true);
            // 0x00AB51AC: ADD w20, w20, #1           | W20 = (val_14 + 1) = val_14 (0x00000001);
            val_14 = 1;
            label_19:
            // 0x00AB51B0: CBNZ x19, #0xab51b8        | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x00AB51B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_20:
            // 0x00AB51B8: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB51BC: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB51C0: BL #0x25ed72c              | X0 = get_Count();                       
            int val_12 = Count;
            // 0x00AB51C4: CMP w20, w0                | STATE = COMPARE(0x1, val_12)            
            // 0x00AB51C8: B.GE #0xab521c             | if (val_14 >= val_12) goto label_21;    
            if(val_14 >= val_12)
            {
                goto label_21;
            }
            // 0x00AB51CC: CBNZ x19, #0xab51d4        | if ( != 0) goto label_22;               
            if(null != 0)
            {
                goto label_22;
            }
            // 0x00AB51D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_22:
            // 0x00AB51D4: LDR x2, [x23]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB51D8: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB51DC: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB51E0: BL #0x25ed734              | X0 = get_Item(index:  1);               
            string val_13 = Item[1];
            // 0x00AB51E4: LDR x1, [x24]              | X1 = "需要下载：{0}";                        
            // 0x00AB51E8: MOV x2, x0                 | X2 = val_13;//m1                        
            // 0x00AB51EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB51F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB51F4: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "需要下载：{0}");
            string val_14 = EString.EFormat(format:  0, arg0:  "需要下载：{0}");
            // 0x00AB51F8: LDR x8, [x25]              | X8 = typeof(EDebug);                    
            // 0x00AB51FC: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00AB5200: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
            // 0x00AB5204: TBZ w9, #0, #0xab5198      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x00AB5208: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
            // 0x00AB520C: CBNZ w9, #0xab5198         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x00AB5210: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
            // 0x00AB5214: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
            // 0x00AB5218: B #0xab5198                |  goto label_25;                         
            goto label_25;
            label_21:
            // 0x00AB521C: SUB sp, x29, #0x40         | SP = (1152921514956479232 - 64) = 1152921514956479168 (0x1000000268E2DAC0);
            // 0x00AB5220: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB5224: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5228: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB522C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB5230: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB5234: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB5238 (11227704), len: 212  VirtAddr: 0x00AB5238 RVA: 0x00AB5238 token: 100693234 methodIndex: 46988 delegateWrapperIndex: 0 methodInvoker: 0
        public static void DownLoad(System.Collections.Generic.List<string> assetNames)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00AB5238: STP x24, x23, [sp, #-0x40]! | stack[1152921514956619856] = ???;  stack[1152921514956619864] = ???;  //  dest_result_addr=1152921514956619856 |  dest_result_addr=1152921514956619864
            // 0x00AB523C: STP x22, x21, [sp, #0x10]  | stack[1152921514956619872] = ???;  stack[1152921514956619880] = ???;  //  dest_result_addr=1152921514956619872 |  dest_result_addr=1152921514956619880
            // 0x00AB5240: STP x20, x19, [sp, #0x20]  | stack[1152921514956619888] = ???;  stack[1152921514956619896] = ???;  //  dest_result_addr=1152921514956619888 |  dest_result_addr=1152921514956619896
            // 0x00AB5244: STP x29, x30, [sp, #0x30]  | stack[1152921514956619904] = ???;  stack[1152921514956619912] = ???;  //  dest_result_addr=1152921514956619904 |  dest_result_addr=1152921514956619912
            // 0x00AB5248: ADD x29, sp, #0x30         | X29 = (1152921514956619856 + 48) = 1152921514956619904 (0x1000000268E50080);
            // 0x00AB524C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB5250: LDRB w8, [x20, #0x407]     | W8 = (bool)static_value_03733407;       
            // 0x00AB5254: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB5258: TBNZ w8, #0, #0xab5274     | if (static_value_03733407 == true) goto label_0;
            // 0x00AB525C: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00AB5260: LDR x8, [x8, #0xee8]       | X8 = 0x2B8EB14;                         
            // 0x00AB5264: LDR w0, [x8]               | W0 = 0x1185;                            
            // 0x00AB5268: BL #0x2782188              | X0 = sub_2782188( ?? 0x1185, ????);     
            // 0x00AB526C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB5270: STRB w8, [x20, #0x407]     | static_value_03733407 = true;            //  dest_result_addr=57881607
            label_0:
            // 0x00AB5274: ADRP x22, #0x35fc000       | X22 = 56606720 (0x35FC000);             
            // 0x00AB5278: ADRP x23, #0x35bd000       | X23 = 56348672 (0x35BD000);             
            // 0x00AB527C: ADRP x24, #0x35c8000       | X24 = 56393728 (0x35C8000);             
            // 0x00AB5280: LDR x22, [x22, #0xb58]     | X22 = 1152921510022759280;              
            // 0x00AB5284: LDR x23, [x23, #0xb50]     | X23 = 1152921510890998992;              
            // 0x00AB5288: LDR x24, [x24, #0x270]     | X24 = 1152921504903331840;              
            // 0x00AB528C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x00AB5290: B #0xab52a0                |  goto label_1;                          
            goto label_1;
            label_7:
            // 0x00AB5294: MOV x1, x21                | X1 = X21;//m1                           
            // 0x00AB5298: BL #0xab4f98               | Mihua.Asset.AssetMgr.DownLoad(assetName:  4485);
            Mihua.Asset.AssetMgr.DownLoad(assetName:  4485);
            // 0x00AB529C: ADD w20, w20, #1           | W20 = (val_3 + 1) = val_3 (0x00000001); 
            val_3 = 1;
            label_1:
            // 0x00AB52A0: CBNZ x19, #0xab52a8        | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x00AB52A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1185, ????);     
            label_2:
            // 0x00AB52A8: LDR x1, [x22]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB52AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00AB52B0: BL #0x25ed72c              | X0 = X1.get_Count();                    
            int val_1 = X1.Count;
            // 0x00AB52B4: CMP w20, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00AB52B8: B.GE #0xab52f8             | if (val_3 >= val_1) goto label_3;       
            if(val_3 >= val_1)
            {
                goto label_3;
            }
            // 0x00AB52BC: CBNZ x19, #0xab52c4        | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x00AB52C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00AB52C4: LDR x2, [x23]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB52C8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00AB52CC: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB52D0: BL #0x25ed734              | X0 = X1.get_Item(index:  1);            
            string val_2 = X1.Item[1];
            // 0x00AB52D4: LDR x8, [x24]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB52D8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AB52DC: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB52E0: TBZ w9, #0, #0xab5294      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AB52E4: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB52E8: CBNZ w9, #0xab5294         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB52EC: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AB52F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB52F4: B #0xab5294                |  goto label_7;                          
            goto label_7;
            label_3:
            // 0x00AB52F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB52FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5300: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB5304: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB5308: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB530C (11227916), len: 104  VirtAddr: 0x00AB530C RVA: 0x00AB530C token: 100693235 methodIndex: 46989 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.ABLoadOperation.AssetOperation LoadAssetAsync(string assetName)
        {
            //
            // Disasemble & Code
            // 0x00AB530C: STP x20, x19, [sp, #-0x20]! | stack[1152921514956744176] = ???;  stack[1152921514956744184] = ???;  //  dest_result_addr=1152921514956744176 |  dest_result_addr=1152921514956744184
            // 0x00AB5310: STP x29, x30, [sp, #0x10]  | stack[1152921514956744192] = ???;  stack[1152921514956744200] = ???;  //  dest_result_addr=1152921514956744192 |  dest_result_addr=1152921514956744200
            // 0x00AB5314: ADD x29, sp, #0x10         | X29 = (1152921514956744176 + 16) = 1152921514956744192 (0x1000000268E6E600);
            // 0x00AB5318: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB531C: LDRB w8, [x20, #0x408]     | W8 = (bool)static_value_03733408;       
            // 0x00AB5320: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB5324: TBNZ w8, #0, #0xab5340     | if (static_value_03733408 == true) goto label_0;
            // 0x00AB5328: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00AB532C: LDR x8, [x8, #0x968]       | X8 = 0x2B8EB4C;                         
            // 0x00AB5330: LDR w0, [x8]               | W0 = 0x1193;                            
            // 0x00AB5334: BL #0x2782188              | X0 = sub_2782188( ?? 0x1193, ????);     
            // 0x00AB5338: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB533C: STRB w8, [x20, #0x408]     | static_value_03733408 = true;            //  dest_result_addr=57881608
            label_0:
            // 0x00AB5340: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB5344: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AB5348: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB534C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5350: TBZ w8, #0, #0xab5360      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB5354: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5358: CBNZ w8, #0xab5360         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB535C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_2:
            // 0x00AB5360: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB5364: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB5368: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB536C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5370: B #0xab5374                | return Mihua.Asset.AssetMgr.LoadAssetAsync(assetName:  null, onLoadAsset:  X1);
            return Mihua.Asset.AssetMgr.LoadAssetAsync(assetName:  null, onLoadAsset:  X1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB5374 (11228020), len: 1060  VirtAddr: 0x00AB5374 RVA: 0x00AB5374 token: 100693236 methodIndex: 46990 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.ABLoadOperation.AssetOperation LoadAssetAsync(string assetName, Mihua.Asset.OnLoadAsset onLoadAsset)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation> val_11;
            //  | 
            LogType val_12;
            //  | 
            var val_13;
            //  | 
            System.Collections.Generic.Dictionary<System.String, UnityEngine.Object> val_14;
            //  | 
            Mihua.Asset.ABLoadOperation.AssetOperation val_15;
            //  | 
            LogType val_16;
            // 0x00AB5374: STP x26, x25, [sp, #-0x50]! | stack[1152921514956894400] = ???;  stack[1152921514956894408] = ???;  //  dest_result_addr=1152921514956894400 |  dest_result_addr=1152921514956894408
            // 0x00AB5378: STP x24, x23, [sp, #0x10]  | stack[1152921514956894416] = ???;  stack[1152921514956894424] = ???;  //  dest_result_addr=1152921514956894416 |  dest_result_addr=1152921514956894424
            // 0x00AB537C: STP x22, x21, [sp, #0x20]  | stack[1152921514956894432] = ???;  stack[1152921514956894440] = ???;  //  dest_result_addr=1152921514956894432 |  dest_result_addr=1152921514956894440
            // 0x00AB5380: STP x20, x19, [sp, #0x30]  | stack[1152921514956894448] = ???;  stack[1152921514956894456] = ???;  //  dest_result_addr=1152921514956894448 |  dest_result_addr=1152921514956894456
            // 0x00AB5384: STP x29, x30, [sp, #0x40]  | stack[1152921514956894464] = ???;  stack[1152921514956894472] = ???;  //  dest_result_addr=1152921514956894464 |  dest_result_addr=1152921514956894472
            // 0x00AB5388: ADD x29, sp, #0x40         | X29 = (1152921514956894400 + 64) = 1152921514956894464 (0x1000000268E93100);
            // 0x00AB538C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AB5390: LDRB w8, [x21, #0x409]     | W8 = (bool)static_value_03733409;       
            // 0x00AB5394: MOV x19, x2                | X19 = X2;//m1                           
            val_11 = X2;
            // 0x00AB5398: MOV x20, x1                | X20 = onLoadAsset;//m1                  
            // 0x00AB539C: TBNZ w8, #0, #0xab53b8     | if (static_value_03733409 == true) goto label_0;
            // 0x00AB53A0: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00AB53A4: LDR x8, [x8, #0x668]       | X8 = 0x2B8EB50;                         
            // 0x00AB53A8: LDR w0, [x8]               | W0 = 0x1194;                            
            // 0x00AB53AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1194, ????);     
            // 0x00AB53B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB53B4: STRB w8, [x21, #0x409]     | static_value_03733409 = true;            //  dest_result_addr=57881609
            label_0:
            // 0x00AB53B8: ADRP x22, #0x3679000       | X22 = 57118720 (0x3679000);             
            // 0x00AB53BC: LDR x22, [x22, #0x728]     | X22 = 1152921514868048752;              
            // 0x00AB53C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB53C4: LDR x1, [x22]              | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB53C8: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_1 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB53CC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00AB53D0: CBNZ x21, #0xab53d8        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00AB53D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00AB53D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB53DC: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x00AB53E0: MOV x1, x20                | X1 = onLoadAsset;//m1                   
            // 0x00AB53E4: BL #0xb42c00               | X0 = val_1.LoadPathToABPath(path:  onLoadAsset);
            string val_2 = val_1.LoadPathToABPath(path:  onLoadAsset);
            // 0x00AB53E8: LDR x1, [x22]              | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB53EC: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AB53F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB53F4: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_3 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB53F8: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00AB53FC: CBNZ x22, #0xab5404        | if (val_3 != null) goto label_2;        
            if(val_3 != null)
            {
                goto label_2;
            }
            // 0x00AB5400: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00AB5404: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB5408: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x00AB540C: MOV x1, x20                | X1 = onLoadAsset;//m1                   
            // 0x00AB5410: BL #0xb42c68               | X0 = val_3.LoadPathToAssetName(path:  onLoadAsset);
            string val_4 = val_3.LoadPathToAssetName(path:  onLoadAsset);
            // 0x00AB5414: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
            // 0x00AB5418: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
            // 0x00AB541C: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00AB5420: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x00AB5424: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB5428: TBZ w9, #0, #0xab543c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00AB542C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5430: CBNZ w9, #0xab543c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00AB5434: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AB5438: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_4:
            // 0x00AB543C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB5444: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00AB5448: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
            bool val_5 = System.String.IsNullOrEmpty(value:  0);
            // 0x00AB544C: TBZ w0, #0, #0xab54a0      | if (val_5 == false) goto label_5;       
            if(val_5 == false)
            {
                goto label_5;
            }
            // 0x00AB5450: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x00AB5454: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921514956872880)("加载{0}资源失败,找不到对应的资源名称");
            // 0x00AB5458: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB545C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AB5460: MOV x2, x20                | X2 = onLoadAsset;//m1                   
            // 0x00AB5464: LDR x1, [x8]               | X1 = "加载{0}资源失败,找不到对应的资源名称";            
            // 0x00AB5468: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "加载{0}资源失败,找不到对应的资源名称");
            string val_6 = EString.EFormat(format:  0, arg0:  "加载{0}资源失败,找不到对应的资源名称");
            // 0x00AB546C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB5470: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AB5474: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00AB5478: LDR x8, [x8]               | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB547C: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5480: TBZ w9, #0, #0xab5494      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AB5484: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5488: CBNZ w9, #0xab5494         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AB548C: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            val_12 = null;
            // 0x00AB5490: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_7:
            // 0x00AB5494: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AB5498: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00AB549C: BL #0xab241c               | Mihua.Asset.AssetMgr.Log(logType:  val_12 = null, text:  0);
            Mihua.Asset.AssetMgr.Log(logType:  val_12, text:  0);
            label_5:
            // 0x00AB54A0: ADRP x24, #0x35c8000       | X24 = 56393728 (0x35C8000);             
            // 0x00AB54A4: LDR x24, [x24, #0x270]     | X24 = 1152921504903331840;              
            // 0x00AB54A8: LDR x0, [x24]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_13 = null;
            // 0x00AB54AC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB54B0: TBZ w8, #0, #0xab54c4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00AB54B4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB54B8: CBNZ w8, #0xab54c4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00AB54BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB54C0: LDR x0, [x24]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_13 = null;
            label_9:
            // 0x00AB54C4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB54C8: LDR x23, [x8, #0x38]       | X23 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            val_14 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB54CC: CBNZ x23, #0xab54d4        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_10;
            if(val_14 != null)
            {
                goto label_10;
            }
            // 0x00AB54D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_10:
            // 0x00AB54D4: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00AB54D8: LDR x8, [x8, #0xad8]       | X8 = 1152921514948372656;               
            // 0x00AB54DC: MOV x0, x23                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00AB54E0: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00AB54E4: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::ContainsKey(System.String key);
            // 0x00AB54E8: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets.ContainsKey(key:  val_4);
            bool val_7 = val_14.ContainsKey(key:  val_4);
            // 0x00AB54EC: TBZ w0, #0, #0xab553c      | if (val_7 == false) goto label_11;      
            if(val_7 == false)
            {
                goto label_11;
            }
            // 0x00AB54F0: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00AB54F4: LDR x8, [x8, #0x4a0]       | X8 = 1152921504902905856;               
            // 0x00AB54F8: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded);
            object val_8 = null;
            // 0x00AB54FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded), ????);
            // 0x00AB5500: MOV x22, x0                | X22 = 1152921504902905856 (0x1000000011A58000);//ML01
            val_15 = val_8;
            // 0x00AB5504: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB5508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB550C: STRB w8, [x22, #0x11]      | typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded).__il2cppRuntimeField_11 = 0x1;  //  dest_result_addr=1152921504902905873
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded).__il2cppRuntimeField_11 = 1;
            // 0x00AB5510: BL #0x16f59f0              | .ctor();                                
            val_8 = new System.Object();
            // 0x00AB5514: STR x20, [x22, #0x18]      | typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded).__il2cppRuntimeField_18 = onLoadAsset;  //  dest_result_addr=1152921504902905880
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded).__il2cppRuntimeField_18 = onLoadAsset;
            // 0x00AB5518: CBNZ x22, #0xab5520        | if ( != 0) goto label_12;               
            if(null != 0)
            {
                goto label_12;
            }
            // 0x00AB551C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_12:
            // 0x00AB5520: STRB wzr, [x22, #0x11]     | typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded).__il2cppRuntimeField_11 = 0x0;  //  dest_result_addr=1152921504902905873
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationLoaded).__il2cppRuntimeField_11 = 0;
            // 0x00AB5524: CBZ x19, #0xab577c         | if (X2 == 0) goto label_14;             
            if(val_11 == 0)
            {
                goto label_14;
            }
            // 0x00AB5528: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB552C: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00AB5530: MOV x1, x22                | X1 = 1152921504902905856 (0x1000000011A58000);//ML01
            // 0x00AB5534: BL #0xaafed4               | X2.Invoke(assetOperation:  val_15);     
            val_11.Invoke(assetOperation:  val_15);
            // 0x00AB5538: B #0xab577c                |  goto label_14;                         
            goto label_14;
            label_11:
            // 0x00AB553C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00AB5540: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
            // 0x00AB5544: LDR x22, [x8]              | X22 = typeof(System.String[]);          
            // 0x00AB5548: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00AB554C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00AB5550: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x00AB5554: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00AB5558: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00AB555C: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00AB5560: CBNZ x22, #0xab5568        | if ( != null) goto label_15;            
            if(null != null)
            {
                goto label_15;
            }
            // 0x00AB5564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_15:
            // 0x00AB5568: ADRP x23, #0x35cd000       | X23 = 56414208 (0x35CD000);             
            // 0x00AB556C: LDR x23, [x23, #0xb98]     | X23 = (string**)(1152921514956877088)("Loading ");
            // 0x00AB5570: LDR x0, [x23]              | X0 = "Loading ";                        
            // 0x00AB5574: CBZ x0, #0xab5594          | if ("Loading " == null) goto label_17;  
            // 0x00AB5578: LDR x8, [x22]              | X8 = ;                                  
            // 0x00AB557C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB5580: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "Loading ", ????); 
            // 0x00AB5584: CBNZ x0, #0xab5594         | if ("Loading " != null) goto label_17;  
            if("Loading " != null)
            {
                goto label_17;
            }
            // 0x00AB5588: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "Loading ", ????); 
            // 0x00AB558C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5590: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Loading ", ????); 
            label_17:
            // 0x00AB5594: LDR x23, [x23]             | X23 = "Loading ";                       
            // 0x00AB5598: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00AB559C: CBNZ w8, #0xab55ac         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_18;
            // 0x00AB55A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "Loading ", ????); 
            // 0x00AB55A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB55A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "Loading ", ????); 
            label_18:
            // 0x00AB55AC: STR x23, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "Loading ";  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = "Loading ";
            // 0x00AB55B0: CBZ x20, #0xab55d4         | if (onLoadAsset == null) goto label_20; 
            if(onLoadAsset == null)
            {
                goto label_20;
            }
            // 0x00AB55B4: LDR x8, [x22]              | X8 = ;                                  
            // 0x00AB55B8: MOV x0, x20                | X0 = onLoadAsset;//m1                   
            // 0x00AB55BC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB55C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? onLoadAsset, ????);
            // 0x00AB55C4: CBNZ x0, #0xab55d4         | if (onLoadAsset != null) goto label_20; 
            if(onLoadAsset != null)
            {
                goto label_20;
            }
            // 0x00AB55C8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? onLoadAsset, ????);
            // 0x00AB55CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB55D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? onLoadAsset, ????);
            label_20:
            // 0x00AB55D4: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00AB55D8: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00AB55DC: B.HI #0xab55ec             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_21;
            // 0x00AB55E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? onLoadAsset, ????);
            // 0x00AB55E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB55E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? onLoadAsset, ????);
            label_21:
            // 0x00AB55EC: STR x20, [x22, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = onLoadAsset;  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = onLoadAsset;
            // 0x00AB55F0: ADRP x23, #0x3612000       | X23 = 56696832 (0x3612000);             
            // 0x00AB55F4: LDR x23, [x23, #0xe78]     | X23 = (string**)(1152921514956877184)(" from ");
            // 0x00AB55F8: LDR x0, [x23]              | X0 = " from ";                          
            // 0x00AB55FC: CBZ x0, #0xab561c          | if (" from " == null) goto label_23;    
            // 0x00AB5600: LDR x8, [x22]              | X8 = ;                                  
            // 0x00AB5604: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB5608: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " from ", ????);   
            // 0x00AB560C: CBNZ x0, #0xab561c         | if (" from " != null) goto label_23;    
            if(" from " != null)
            {
                goto label_23;
            }
            // 0x00AB5610: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " from ", ????);   
            // 0x00AB5614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5618: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " from ", ????);   
            label_23:
            // 0x00AB561C: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00AB5620: LDR x23, [x23]             | X23 = " from ";                         
            // 0x00AB5624: CMP w8, #2                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00AB5628: B.HI #0xab5638             | if (System.String[].__il2cppRuntimeField_namespaze > 0x2) goto label_24;
            // 0x00AB562C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " from ", ????);   
            // 0x00AB5630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5634: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " from ", ????);   
            label_24:
            // 0x00AB5638: STR x23, [x22, #0x30]      | typeof(System.String[]).__il2cppRuntimeField_30 = " from ";  //  dest_result_addr=1152921504948897216
            typeof(System.String[]).__il2cppRuntimeField_30 = " from ";
            // 0x00AB563C: CBZ x21, #0xab5660         | if (val_2 == null) goto label_26;       
            if(val_2 == null)
            {
                goto label_26;
            }
            // 0x00AB5640: LDR x8, [x22]              | X8 = ;                                  
            // 0x00AB5644: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00AB5648: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB564C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00AB5650: CBNZ x0, #0xab5660         | if (val_2 != null) goto label_26;       
            if(val_2 != null)
            {
                goto label_26;
            }
            // 0x00AB5654: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00AB5658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB565C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_26:
            // 0x00AB5660: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00AB5664: CMP w8, #3                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00AB5668: B.HI #0xab5678             | if (System.String[].__il2cppRuntimeField_namespaze > 0x3) goto label_27;
            // 0x00AB566C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AB5670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5674: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_27:
            // 0x00AB5678: STR x21, [x22, #0x38]      | typeof(System.String[]).__il2cppRuntimeField_38 = val_2;  //  dest_result_addr=1152921504948897224
            typeof(System.String[]).__il2cppRuntimeField_38 = val_2;
            // 0x00AB567C: ADRP x23, #0x3660000       | X23 = 57016320 (0x3660000);             
            // 0x00AB5680: LDR x23, [x23, #0x5a0]     | X23 = (string**)(1152921514956877264)(" bundle");
            // 0x00AB5684: LDR x0, [x23]              | X0 = " bundle";                         
            // 0x00AB5688: CBZ x0, #0xab56a8          | if (" bundle" == null) goto label_29;   
            // 0x00AB568C: LDR x8, [x22]              | X8 = ;                                  
            // 0x00AB5690: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AB5694: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " bundle", ????);  
            // 0x00AB5698: CBNZ x0, #0xab56a8         | if (" bundle" != null) goto label_29;   
            if(" bundle" != null)
            {
                goto label_29;
            }
            // 0x00AB569C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " bundle", ????);  
            // 0x00AB56A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB56A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " bundle", ????);  
            label_29:
            // 0x00AB56A8: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00AB56AC: LDR x23, [x23]             | X23 = " bundle";                        
            val_14 = " bundle";
            // 0x00AB56B0: CMP w8, #4                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x00AB56B4: B.HI #0xab56c4             | if (System.String[].__il2cppRuntimeField_namespaze > 0x4) goto label_30;
            // 0x00AB56B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " bundle", ????);  
            // 0x00AB56BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB56C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " bundle", ????);  
            label_30:
            // 0x00AB56C4: STR x23, [x22, #0x40]      | typeof(System.String[]).__il2cppRuntimeField_40 = " bundle";  //  dest_result_addr=1152921504948897232
            typeof(System.String[]).__il2cppRuntimeField_40 = val_14;
            // 0x00AB56C8: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x00AB56CC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00AB56D0: TBZ w8, #0, #0xab56e0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x00AB56D4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00AB56D8: CBNZ w8, #0xab56e0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x00AB56DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_32:
            // 0x00AB56E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB56E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB56E8: MOV x1, x22                | X1 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00AB56EC: BL #0x18b0b80              | X0 = System.String.Concat(values:  0);  
            string val_9 = System.String.Concat(values:  0);
            // 0x00AB56F0: LDR x8, [x24]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB56F4: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00AB56F8: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB56FC: TBZ w9, #0, #0xab5710      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x00AB5700: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5704: CBNZ w9, #0xab5710         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x00AB5708: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            val_16 = null;
            // 0x00AB570C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_34:
            // 0x00AB5710: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AB5714: MOV x2, x22                | X2 = val_9;//m1                         
            // 0x00AB5718: BL #0xab241c               | Mihua.Asset.AssetMgr.Log(logType:  val_16 = null, text:  0);
            Mihua.Asset.AssetMgr.Log(logType:  val_16, text:  0);
            // 0x00AB571C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00AB5720: BL #0xab2d5c               | Mihua.Asset.AssetMgr.LoadAssetBundle(assetBundleName:  val_16);
            Mihua.Asset.AssetMgr.LoadAssetBundle(assetBundleName:  val_16);
            // 0x00AB5724: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00AB5728: LDR x8, [x8, #0xff8]       | X8 = 1152921504903065600;               
            // 0x00AB572C: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull);
            object val_10 = null;
            // 0x00AB5730: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull), ????);
            // 0x00AB5734: MOV x22, x0                | X22 = 1152921504903065600 (0x1000000011A7F000);//ML01
            val_15 = val_10;
            // 0x00AB5738: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB573C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5740: STRB w8, [x22, #0x11]      | typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_11 = 0x1;  //  dest_result_addr=1152921504903065617
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_11 = 1;
            // 0x00AB5744: BL #0x16f59f0              | .ctor();                                
            val_10 = new System.Object();
            // 0x00AB5748: STP x21, x20, [x22, #0x18] | typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_18 = val_2;  typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_20 = onLoadAsset;  //  dest_result_addr=1152921504903065624 |  dest_result_addr=1152921504903065632
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_18 = val_2;
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_20 = onLoadAsset;
            // 0x00AB574C: STR x19, [x22, #0x40]      | typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_40 = X2;  //  dest_result_addr=1152921504903065664
            typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_40 = val_11;
            // 0x00AB5750: LDR x8, [x24]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5754: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5758: LDR x19, [x8, #0x58]       | X19 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            val_11 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB575C: CBNZ x19, #0xab5764        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_35;
            if(val_11 != null)
            {
                goto label_35;
            }
            // 0x00AB5760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_35:
            // 0x00AB5764: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB5768: LDR x8, [x8, #0xb8]        | X8 = 1152921514956881456;               
            // 0x00AB576C: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB5770: MOV x1, x22                | X1 = 1152921504903065600 (0x1000000011A7F000);//ML01
            // 0x00AB5774: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::Add(Mihua.Asset.ABLoadOperation.ABOperation item);
            // 0x00AB5778: BL #0x25ea480              | Mihua.Asset.AssetMgr.m_InProgressOperations.Add(item:  val_15);
            val_11.Add(item:  val_15);
            label_14:
            // 0x00AB577C: MOV x0, x22                | X0 = 1152921504903065600 (0x1000000011A7F000);//ML01
            // 0x00AB5780: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB5784: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5788: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB578C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB5790: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB5794: RET                        |  return (Mihua.Asset.ABLoadOperation.AssetOperation)typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull);
            return (Mihua.Asset.ABLoadOperation.AssetOperation)val_15;
            //  |  // // {name=val_0, type=Mihua.Asset.ABLoadOperation.AssetOperation, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB5798 (11229080), len: 272  VirtAddr: 0x00AB5798 RVA: 0x00AB5798 token: 100693237 methodIndex: 46991 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.ABLoadOperation.ABOperation PreloadingAsync(System.Collections.Generic.List<string> resPathList)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            string val_6;
            // 0x00AB5798: STP x26, x25, [sp, #-0x50]! | stack[1152921514957051456] = ???;  stack[1152921514957051464] = ???;  //  dest_result_addr=1152921514957051456 |  dest_result_addr=1152921514957051464
            // 0x00AB579C: STP x24, x23, [sp, #0x10]  | stack[1152921514957051472] = ???;  stack[1152921514957051480] = ???;  //  dest_result_addr=1152921514957051472 |  dest_result_addr=1152921514957051480
            // 0x00AB57A0: STP x22, x21, [sp, #0x20]  | stack[1152921514957051488] = ???;  stack[1152921514957051496] = ???;  //  dest_result_addr=1152921514957051488 |  dest_result_addr=1152921514957051496
            // 0x00AB57A4: STP x20, x19, [sp, #0x30]  | stack[1152921514957051504] = ???;  stack[1152921514957051512] = ???;  //  dest_result_addr=1152921514957051504 |  dest_result_addr=1152921514957051512
            // 0x00AB57A8: STP x29, x30, [sp, #0x40]  | stack[1152921514957051520] = ???;  stack[1152921514957051528] = ???;  //  dest_result_addr=1152921514957051520 |  dest_result_addr=1152921514957051528
            // 0x00AB57AC: ADD x29, sp, #0x40         | X29 = (1152921514957051456 + 64) = 1152921514957051520 (0x1000000268EB9680);
            // 0x00AB57B0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB57B4: LDRB w8, [x20, #0x40a]     | W8 = (bool)static_value_0373340A;       
            // 0x00AB57B8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB57BC: TBNZ w8, #0, #0xab57d8     | if (static_value_0373340A == true) goto label_0;
            // 0x00AB57C0: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00AB57C4: LDR x8, [x8, #0x818]       | X8 = 0x2B8EB74;                         
            // 0x00AB57C8: LDR w0, [x8]               | W0 = 0x119D;                            
            // 0x00AB57CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x119D, ????);     
            // 0x00AB57D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB57D4: STRB w8, [x20, #0x40a]     | static_value_0373340A = true;            //  dest_result_addr=57881610
            label_0:
            // 0x00AB57D8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB57DC: LDR x8, [x8, #0x7f0]       | X8 = 1152921504902799360;               
            // 0x00AB57E0: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.ABLoadOperation.PreloadingOperation);
            Mihua.Asset.ABLoadOperation.PreloadingOperation val_1 = null;
            // 0x00AB57E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.ABLoadOperation.PreloadingOperation), ????);
            // 0x00AB57E8: MOV x20, x0                | X20 = 1152921504902799360 (0x1000000011A3E000);//ML01
            // 0x00AB57EC: BL #0xab0ad0               | .ctor();                                
            val_1 = new Mihua.Asset.ABLoadOperation.PreloadingOperation();
            // 0x00AB57F0: ADRP x23, #0x35fc000       | X23 = 56606720 (0x35FC000);             
            // 0x00AB57F4: ADRP x24, #0x35bd000       | X24 = 56348672 (0x35BD000);             
            // 0x00AB57F8: ADRP x25, #0x35c8000       | X25 = 56393728 (0x35C8000);             
            // 0x00AB57FC: LDR x23, [x23, #0xb58]     | X23 = 1152921510022759280;              
            // 0x00AB5800: LDR x24, [x24, #0xb50]     | X24 = 1152921510890998992;              
            // 0x00AB5804: LDR x25, [x25, #0x270]     | X25 = 1152921504903331840;              
            // 0x00AB5808: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x00AB580C: B #0xab5820                |  goto label_1;                          
            goto label_1;
            label_8:
            // 0x00AB5810: MOV x0, x20                | X0 = 1152921504902799360 (0x1000000011A3E000);//ML01
            // 0x00AB5814: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00AB5818: BL #0xab0b40               | AddAssetOperation(ao:  X22);            
            AddAssetOperation(ao:  X22);
            // 0x00AB581C: ADD w21, w21, #1           | W21 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_1:
            // 0x00AB5820: CBNZ x19, #0xab5828        | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x00AB5824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.ABLoadOperation.PreloadingOperation), ????);
            label_2:
            // 0x00AB5828: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB582C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00AB5830: BL #0x25ed72c              | X0 = X1.get_Count();                    
            int val_2 = X1.Count;
            // 0x00AB5834: CMP w21, w0                | STATE = COMPARE(0x1, val_2)             
            // 0x00AB5838: B.GE #0xab588c             | if (val_5 >= val_2) goto label_3;       
            if(val_5 >= val_2)
            {
                goto label_3;
            }
            // 0x00AB583C: CBNZ x19, #0xab5844        | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x00AB5840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x00AB5844: LDR x2, [x24]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB5848: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00AB584C: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00AB5850: BL #0x25ed734              | X0 = X1.get_Item(index:  1);            
            string val_3 = X1.Item[1];
            // 0x00AB5854: LDR x8, [x25]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5858: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00AB585C: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5860: TBZ w9, #0, #0xab5874      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB5864: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5868: CBNZ w9, #0xab5874         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB586C: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            val_6 = null;
            // 0x00AB5870: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_6:
            // 0x00AB5874: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00AB5878: BL #0xab530c               | X0 = Mihua.Asset.AssetMgr.LoadAssetAsync(assetName:  val_6 = null);
            Mihua.Asset.ABLoadOperation.AssetOperation val_4 = Mihua.Asset.AssetMgr.LoadAssetAsync(assetName:  val_6);
            // 0x00AB587C: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00AB5880: CBNZ x20, #0xab5810        | if ( != 0) goto label_8;                
            if(null != 0)
            {
                goto label_8;
            }
            // 0x00AB5884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00AB5888: B #0xab5810                |  goto label_8;                          
            goto label_8;
            label_3:
            // 0x00AB588C: MOV x0, x20                | X0 = 1152921504902799360 (0x1000000011A3E000);//ML01
            // 0x00AB5890: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB5894: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5898: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB589C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB58A0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB58A4: RET                        |  return (Mihua.Asset.ABLoadOperation.ABOperation)typeof(Mihua.Asset.ABLoadOperation.PreloadingOperation);
            return (Mihua.Asset.ABLoadOperation.ABOperation)val_1;
            //  |  // // {name=val_0, type=Mihua.Asset.ABLoadOperation.ABOperation, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB58A8 (11229352), len: 272  VirtAddr: 0x00AB58A8 RVA: 0x00AB58A8 token: 100693238 methodIndex: 46992 delegateWrapperIndex: 0 methodInvoker: 0
        public static Mihua.Asset.ABLoadOperation.ABOperation LoadLevelAsync(string levelPath, string levelName, bool isAdditive)
        {
            //
            // Disasemble & Code
            //  | 
            string val_5;
            // 0x00AB58A8: STP x24, x23, [sp, #-0x40]! | stack[1152921514957192144] = ???;  stack[1152921514957192152] = ???;  //  dest_result_addr=1152921514957192144 |  dest_result_addr=1152921514957192152
            // 0x00AB58AC: STP x22, x21, [sp, #0x10]  | stack[1152921514957192160] = ???;  stack[1152921514957192168] = ???;  //  dest_result_addr=1152921514957192160 |  dest_result_addr=1152921514957192168
            // 0x00AB58B0: STP x20, x19, [sp, #0x20]  | stack[1152921514957192176] = ???;  stack[1152921514957192184] = ???;  //  dest_result_addr=1152921514957192176 |  dest_result_addr=1152921514957192184
            // 0x00AB58B4: STP x29, x30, [sp, #0x30]  | stack[1152921514957192192] = ???;  stack[1152921514957192200] = ???;  //  dest_result_addr=1152921514957192192 |  dest_result_addr=1152921514957192200
            // 0x00AB58B8: ADD x29, sp, #0x30         | X29 = (1152921514957192144 + 48) = 1152921514957192192 (0x1000000268EDBC00);
            // 0x00AB58BC: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AB58C0: LDRB w8, [x22, #0x40b]     | W8 = (bool)static_value_0373340B;       
            // 0x00AB58C4: MOV w19, w3                | W19 = W3;//m1                           
            // 0x00AB58C8: MOV x20, x2                | X20 = isAdditive;//m1                   
            // 0x00AB58CC: MOV x21, x1                | X21 = levelName;//m1                    
            // 0x00AB58D0: TBNZ w8, #0, #0xab58ec     | if (static_value_0373340B == true) goto label_0;
            // 0x00AB58D4: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00AB58D8: LDR x8, [x8, #0x900]       | X8 = 0x2B8EB60;                         
            // 0x00AB58DC: LDR w0, [x8]               | W0 = 0x1198;                            
            // 0x00AB58E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1198, ????);     
            // 0x00AB58E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB58E8: STRB w8, [x22, #0x40b]     | static_value_0373340B = true;            //  dest_result_addr=57881611
            label_0:
            // 0x00AB58EC: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB58F0: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00AB58F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB58F8: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB58FC: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_1 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB5900: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00AB5904: CBNZ x22, #0xab590c        | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00AB5908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00AB590C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB5910: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x00AB5914: MOV x1, x21                | X1 = levelName;//m1                     
            // 0x00AB5918: BL #0xb42c00               | X0 = val_1.LoadPathToABPath(path:  levelName);
            string val_2 = val_1.LoadPathToABPath(path:  levelName);
            // 0x00AB591C: ADRP x23, #0x35c8000       | X23 = 56393728 (0x35C8000);             
            // 0x00AB5920: LDR x23, [x23, #0x270]     | X23 = 1152921504903331840;              
            // 0x00AB5924: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AB5928: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB592C: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5930: TBZ w9, #0, #0xab5944      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AB5934: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5938: CBNZ w9, #0xab5944         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AB593C: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            val_5 = null;
            // 0x00AB5940: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB5944: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00AB5948: BL #0xab2d5c               | Mihua.Asset.AssetMgr.LoadAssetBundle(assetBundleName:  val_5 = null);
            Mihua.Asset.AssetMgr.LoadAssetBundle(assetBundleName:  val_5);
            // 0x00AB594C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AB5950: LDR x8, [x8, #0x388]       | X8 = 1152921504902746112;               
            // 0x00AB5954: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.ABLoadOperation.LevelOperation);
            object val_3 = null;
            // 0x00AB5958: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Asset.ABLoadOperation.LevelOperation), ????);
            // 0x00AB595C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5960: MOV x22, x0                | X22 = 1152921504902746112 (0x1000000011A31000);//ML01
            // 0x00AB5964: BL #0x16f59f0              | .ctor();                                
            val_3 = new System.Object();
            // 0x00AB5968: AND w8, w19, #1            | W8 = (W3 & 1);                          
            var val_4 = W3 & 1;
            // 0x00AB596C: STP x21, x20, [x22, #0x18] | typeof(Mihua.Asset.ABLoadOperation.LevelOperation).__il2cppRuntimeField_18 = val_2;  typeof(Mihua.Asset.ABLoadOperation.LevelOperation).__il2cppRuntimeField_20 = isAdditive;  //  dest_result_addr=1152921504902746136 |  dest_result_addr=1152921504902746144
            typeof(Mihua.Asset.ABLoadOperation.LevelOperation).__il2cppRuntimeField_18 = val_2;
            typeof(Mihua.Asset.ABLoadOperation.LevelOperation).__il2cppRuntimeField_20 = isAdditive;
            // 0x00AB5970: STRB w8, [x22, #0x28]      | typeof(Mihua.Asset.ABLoadOperation.LevelOperation).__il2cppRuntimeField_28 = (W3 & 1);  //  dest_result_addr=1152921504902746152
            typeof(Mihua.Asset.ABLoadOperation.LevelOperation).__il2cppRuntimeField_28 = val_4;
            // 0x00AB5974: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5978: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB597C: LDR x19, [x8, #0x58]       | X19 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB5980: CBNZ x19, #0xab5988        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_4;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_4;
            }
            // 0x00AB5984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_4:
            // 0x00AB5988: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB598C: LDR x8, [x8, #0xb8]        | X8 = 1152921514956881456;               
            // 0x00AB5990: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB5994: MOV x1, x22                | X1 = 1152921504902746112 (0x1000000011A31000);//ML01
            // 0x00AB5998: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::Add(Mihua.Asset.ABLoadOperation.ABOperation item);
            // 0x00AB599C: BL #0x25ea480              | Mihua.Asset.AssetMgr.m_InProgressOperations.Add(item:  val_3);
            Mihua.Asset.AssetMgr.m_InProgressOperations.Add(item:  val_3);
            // 0x00AB59A0: MOV x0, x22                | X0 = 1152921504902746112 (0x1000000011A31000);//ML01
            // 0x00AB59A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB59A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB59AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB59B0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB59B4: RET                        |  return (Mihua.Asset.ABLoadOperation.ABOperation)typeof(Mihua.Asset.ABLoadOperation.LevelOperation);
            return (Mihua.Asset.ABLoadOperation.ABOperation)val_3;
            //  |  // // {name=val_0, type=Mihua.Asset.ABLoadOperation.ABOperation, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB59B8 (11229624), len: 696  VirtAddr: 0x00AB59B8 RVA: 0x00AB59B8 token: 100693239 methodIndex: 46993 delegateWrapperIndex: 0 methodInvoker: 0
        public static void SetNextNeedAssets(System.Collections.Generic.List<string> needList, bool is3D)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            // 0x00AB59B8: STP x26, x25, [sp, #-0x50]! | stack[1152921514957343040] = ???;  stack[1152921514957343048] = ???;  //  dest_result_addr=1152921514957343040 |  dest_result_addr=1152921514957343048
            // 0x00AB59BC: STP x24, x23, [sp, #0x10]  | stack[1152921514957343056] = ???;  stack[1152921514957343064] = ???;  //  dest_result_addr=1152921514957343056 |  dest_result_addr=1152921514957343064
            // 0x00AB59C0: STP x22, x21, [sp, #0x20]  | stack[1152921514957343072] = ???;  stack[1152921514957343080] = ???;  //  dest_result_addr=1152921514957343072 |  dest_result_addr=1152921514957343080
            // 0x00AB59C4: STP x20, x19, [sp, #0x30]  | stack[1152921514957343088] = ???;  stack[1152921514957343096] = ???;  //  dest_result_addr=1152921514957343088 |  dest_result_addr=1152921514957343096
            // 0x00AB59C8: STP x29, x30, [sp, #0x40]  | stack[1152921514957343104] = ???;  stack[1152921514957343112] = ???;  //  dest_result_addr=1152921514957343104 |  dest_result_addr=1152921514957343112
            // 0x00AB59CC: ADD x29, sp, #0x40         | X29 = (1152921514957343040 + 64) = 1152921514957343104 (0x1000000268F00980);
            // 0x00AB59D0: SUB sp, sp, #0x50          | SP = (1152921514957343040 - 80) = 1152921514957342960 (0x1000000268F008F0);
            // 0x00AB59D4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB59D8: LDRB w8, [x20, #0x40c]     | W8 = (bool)static_value_0373340C;       
            // 0x00AB59DC: MOV w19, w2                | W19 = W2;//m1                           
            val_11 = W2;
            // 0x00AB59E0: TBNZ w8, #0, #0xab59fc     | if (static_value_0373340C == true) goto label_0;
            // 0x00AB59E4: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB59E8: LDR x8, [x8, #0xc68]       | X8 = 0x2B8EB88;                         
            // 0x00AB59EC: LDR w0, [x8]               | W0 = 0x11A2;                            
            // 0x00AB59F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A2, ????);     
            // 0x00AB59F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB59F8: STRB w8, [x20, #0x40c]     | static_value_0373340C = true;            //  dest_result_addr=57881612
            label_0:
            // 0x00AB59FC: STP xzr, xzr, [sp, #0x40]  | stack[1152921514957343024] = 0x0;  stack[1152921514957343032] = 0x0;  //  dest_result_addr=1152921514957343024 |  dest_result_addr=1152921514957343032
            // 0x00AB5A00: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB5A04: STR xzr, [sp, #0x38]       | stack[1152921514957343016] = 0x0;        //  dest_result_addr=1152921514957343016
            // 0x00AB5A08: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AB5A0C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_12 = null;
            // 0x00AB5A10: STP xzr, xzr, [sp, #0x28]  | stack[1152921514957343000] = 0x0;  stack[1152921514957343008] = 0x0;  //  dest_result_addr=1152921514957343000 |  dest_result_addr=1152921514957343008
            // 0x00AB5A14: STR xzr, [sp, #0x20]       | stack[1152921514957342992] = 0x0;        //  dest_result_addr=1152921514957342992
            // 0x00AB5A18: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5A1C: TBZ w8, #0, #0xab5a30      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB5A20: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5A24: CBNZ w8, #0xab5a30         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB5A28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5A2C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_12 = null;
            label_2:
            // 0x00AB5A30: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5A34: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB5A38: CBNZ x20, #0xab5a40        | if (Mihua.Asset.AssetMgr.nextNeedAssetList != null) goto label_3;
            if(Mihua.Asset.AssetMgr.nextNeedAssetList != null)
            {
                goto label_3;
            }
            // 0x00AB5A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB5A40: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB5A44: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB5A48: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB5A4C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB5A50: BL #0x25ead28              | Mihua.Asset.AssetMgr.nextNeedAssetList.Clear();
            Mihua.Asset.AssetMgr.nextNeedAssetList.Clear();
            // 0x00AB5A54: LDR x8, [x21]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5A58: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5A5C: LDR x20, [x8, #0x28]       | X20 = Mihua.Asset.AssetMgr.m_assetShared;
            // 0x00AB5A60: CBNZ x20, #0xab5a68        | if (Mihua.Asset.AssetMgr.m_assetShared != null) goto label_4;
            if(Mihua.Asset.AssetMgr.m_assetShared != null)
            {
                goto label_4;
            }
            // 0x00AB5A64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.nextNeedAssetList, ????);
            label_4:
            // 0x00AB5A68: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00AB5A6C: LDR x8, [x8, #0xc90]       | X8 = 1152921514957312688;               
            // 0x00AB5A70: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_assetShared;//m1
            // 0x00AB5A74: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, asset_sharedCfg>::GetEnumerator();
            // 0x00AB5A78: MOV x8, sp                 | X8 = 1152921514957342960 (0x1000000268F008F0);//ML01
            // 0x00AB5A7C: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_assetShared.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_1 = Mihua.Asset.AssetMgr.m_assetShared.GetEnumerator();
            // 0x00AB5A80: LDP q1, q0, [sp]           | Q1 = val_2; Q0 = val_3;                  //  find_add[1152921514957331120] |  find_add[1152921514957331120]
            // 0x00AB5A84: ADRP x22, #0x3662000       | X22 = 57024512 (0x3662000);             
            // 0x00AB5A88: ADRP x23, #0x366a000       | X23 = 57057280 (0x366A000);             
            // 0x00AB5A8C: ADRP x24, #0x362f000       | X24 = 56815616 (0x362F000);             
            // 0x00AB5A90: ADRP x25, #0x3617000       | X25 = 56717312 (0x3617000);             
            // 0x00AB5A94: LDR x22, [x22, #0x178]     | X22 = 1152921514957313712;              
            // 0x00AB5A98: LDR x23, [x23, #0xf10]     | X23 = 1152921514957314736;              
            // 0x00AB5A9C: LDR x24, [x24, #0x330]     | X24 = 1152921514957315760;              
            // 0x00AB5AA0: LDR x25, [x25, #0xbc0]     | X25 = 1152921514957316784;              
            // 0x00AB5AA4: STP q1, q0, [sp, #0x20]    | stack[1152921514957342992] = val_2;  stack[1152921514957343008] = val_3;  //  dest_result_addr=1152921514957342992 |  dest_result_addr=1152921514957343008
            // 0x00AB5AA8: ADRP x26, #0x3633000       | X26 = 56832000 (0x3633000);             
            // 0x00AB5AAC: LDR x26, [x26, #0xae0]     | X26 = 1152921514943344464;              
            label_23:
            // 0x00AB5AB0: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, asset_sharedCfg>::MoveNext();
            // 0x00AB5AB4: ADD x0, sp, #0x20          | X0 = (1152921514957342960 + 32) = 1152921514957342992 (0x1000000268F00910);
            // 0x00AB5AB8: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB5ABC: AND w8, w0, #1             | W8 = (1152921514957342992 & 1) = 0 (0x00000000);
            // 0x00AB5AC0: TBZ w8, #0, #0xab5c24      | if ((0x0 & 0x1) == 0) goto label_5;     
            if((0 & 1) == 0)
            {
                goto label_5;
            }
            // 0x00AB5AC4: LDR x1, [x23]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, asset_sharedCfg>::get_Current();
            // 0x00AB5AC8: ADD x0, sp, #0x20          | X0 = (1152921514957342960 + 32) = 1152921514957342992 (0x1000000268F00910);
            // 0x00AB5ACC: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_4 = val_2.GetHandle();
            // 0x00AB5AD0: LDR x8, [x24]              | X8 = public asset_sharedCfg System.Collections.Generic.KeyValuePair<System.String, asset_sharedCfg>::get_Value();
            // 0x00AB5AD4: STP x0, x1, [sp, #0x40]    | stack[1152921514957343024] = val_4.m_Handle;  stack[1152921514957343032] = val_4.m_Version;  //  dest_result_addr=1152921514957343024 |  dest_result_addr=1152921514957343032
            // 0x00AB5AD8: ADD x0, sp, #0x40          | X0 = (1152921514957342960 + 64) = 1152921514957343024 (0x1000000268F00930);
            // 0x00AB5ADC: MOV x1, x8                 | X1 = 1152921514957315760 (0x1000000268EF9EB0);//ML01
            // 0x00AB5AE0: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB5AE4: MOV x20, x0                | X20 = 1152921514957343024 (0x1000000268F00930);//ML01
            // 0x00AB5AE8: CBNZ x20, #0xab5af0        | if (val_4.m_Handle != 0) goto label_6;  
            if(val_4.m_Handle != 0)
            {
                goto label_6;
            }
            // 0x00AB5AEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F00930, ????);
            label_6:
            // 0x00AB5AF0: LDR w8, [x20, #0x14]       | W8 = ;                                  
            var val_11 = ???;
            // 0x00AB5AF4: SUB w9, w8, #1             | W9 = (??? - 1);                         
            var val_5 = val_11 - 1;
            // 0x00AB5AF8: ADD w8, w8, #7             | W8 = (??? + 7);                         
            val_11 = val_11 + 7;
            // 0x00AB5AFC: CMP w9, #3                 | STATE = COMPARE((??? - 1), 0x3)         
            // 0x00AB5B00: CSEL w8, w8, wzr, lo       | W8 = val_5 < 0x3 ? (??? + 7) : 0;       
            var val_6 = (val_5 < 3) ? (val_11) : 0;
            // 0x00AB5B04: CMP w8, #7                 | STATE = COMPARE(val_5 < 0x3 ? (??? + 7) : 0, 0x7)
            // 0x00AB5B08: B.GT #0xab5b14             | if (val_6 > 0x7) goto label_7;          
            if(val_6 > 7)
            {
                goto label_7;
            }
            // 0x00AB5B0C: CBZ w8, #0xab5ab0          | if (val_5 < 0x3 ? (??? + 7) : 0 == 0) goto label_23;
            if(val_6 == 0)
            {
                goto label_23;
            }
            // 0x00AB5B10: B #0xab5c54                |  goto label_26;                         
            goto label_26;
            label_7:
            // 0x00AB5B14: CMP w8, #8                 | STATE = COMPARE(val_5 < 0x3 ? (??? + 7) : 0, 0x8)
            // 0x00AB5B18: B.EQ #0xab5b74             | if (val_6 == 0x8) goto label_10;        
            if(val_6 == 8)
            {
                goto label_10;
            }
            // 0x00AB5B1C: CMP w8, #9                 | STATE = COMPARE(val_5 < 0x3 ? (??? + 7) : 0, 0x9)
            // 0x00AB5B20: B.EQ #0xab5bc4             | if (val_6 == 0x9) goto label_11;        
            if(val_6 == 9)
            {
                goto label_11;
            }
            // 0x00AB5B24: CMP w8, #0xa               | STATE = COMPARE(val_5 < 0x3 ? (??? + 7) : 0, 0xA)
            // 0x00AB5B28: B.NE #0xab5c54             | if (val_6 != 0xA) goto label_26;        
            if(val_6 != 10)
            {
                goto label_26;
            }
            // 0x00AB5B2C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_13 = null;
            // 0x00AB5B30: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5B34: TBZ w8, #0, #0xab5b48      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00AB5B38: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5B3C: CBNZ w8, #0xab5b48         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00AB5B40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5B44: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_13 = null;
            label_14:
            // 0x00AB5B48: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5B4C: LDR x1, [x25]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, asset_sharedCfg>::get_Key();
            // 0x00AB5B50: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB5B54: ADD x0, sp, #0x40          | X0 = (1152921514957342960 + 64) = 1152921514957343024 (0x1000000268F00930);
            // 0x00AB5B58: BL #0x1dc9dd4              | X0 = val_4.m_Handle.get_InitialType();  
            System.Type val_7 = val_4.m_Handle.InitialType;
            // 0x00AB5B5C: MOV x2, x0                 | X2 = val_7;//m1                         
            // 0x00AB5B60: LDR x3, [x26]              | X3 = public static System.Void EList::Add<System.String>(System.Collections.Generic.List<T> list, System.String item);
            // 0x00AB5B64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5B68: MOV x1, x20                | X1 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB5B6C: BL #0x10cf778              | EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetMgr.nextNeedAssetList);
            EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetMgr.nextNeedAssetList);
            // 0x00AB5B70: B #0xab5ab0                |  goto label_23;                         
            goto label_23;
            label_10:
            // 0x00AB5B74: AND w8, w19, #1            | W8 = (W2 & 1);                          
            var val_8 = val_11 & 1;
            // 0x00AB5B78: TBNZ w8, #0, #0xab5ab0     | if (((W2 & 1) & 0x1) != 0) goto label_23;
            if((val_8 & 1) != 0)
            {
                goto label_23;
            }
            // 0x00AB5B7C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_14 = null;
            // 0x00AB5B80: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5B84: TBZ w8, #0, #0xab5b98      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x00AB5B88: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5B8C: CBNZ w8, #0xab5b98         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x00AB5B90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5B94: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_14 = null;
            label_18:
            // 0x00AB5B98: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5B9C: LDR x1, [x25]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, asset_sharedCfg>::get_Key();
            // 0x00AB5BA0: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB5BA4: ADD x0, sp, #0x40          | X0 = (1152921514957342960 + 64) = 1152921514957343024 (0x1000000268F00930);
            // 0x00AB5BA8: BL #0x1dc9dd4              | X0 = val_4.m_Handle.get_InitialType();  
            System.Type val_9 = val_4.m_Handle.InitialType;
            // 0x00AB5BAC: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x00AB5BB0: LDR x3, [x26]              | X3 = public static System.Void EList::Add<System.String>(System.Collections.Generic.List<T> list, System.String item);
            // 0x00AB5BB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5BB8: MOV x1, x20                | X1 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB5BBC: BL #0x10cf778              | EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetMgr.nextNeedAssetList);
            EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetMgr.nextNeedAssetList);
            // 0x00AB5BC0: B #0xab5ab0                |  goto label_23;                         
            goto label_23;
            label_11:
            // 0x00AB5BC4: TBZ w19, #0, #0xab5ab0     | if ((W2 & 0x1) == 0) goto label_23;     
            if((val_11 & 1) == 0)
            {
                goto label_23;
            }
            // 0x00AB5BC8: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_15 = null;
            // 0x00AB5BCC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5BD0: TBZ w8, #0, #0xab5be4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00AB5BD4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5BD8: CBNZ w8, #0xab5be4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00AB5BDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5BE0: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_15 = null;
            label_22:
            // 0x00AB5BE4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5BE8: LDR x1, [x25]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, asset_sharedCfg>::get_Key();
            // 0x00AB5BEC: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB5BF0: ADD x0, sp, #0x40          | X0 = (1152921514957342960 + 64) = 1152921514957343024 (0x1000000268F00930);
            // 0x00AB5BF4: BL #0x1dc9dd4              | X0 = val_4.m_Handle.get_InitialType();  
            System.Type val_10 = val_4.m_Handle.InitialType;
            // 0x00AB5BF8: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00AB5BFC: LDR x3, [x26]              | X3 = public static System.Void EList::Add<System.String>(System.Collections.Generic.List<T> list, System.String item);
            // 0x00AB5C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5C04: MOV x1, x20                | X1 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB5C08: BL #0x10cf778              | EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetMgr.nextNeedAssetList);
            EList.Add<System.String>(list:  0, item:  Mihua.Asset.AssetMgr.nextNeedAssetList);
            // 0x00AB5C0C: B #0xab5ab0                |  goto label_23;                         
            goto label_23;
            // 0x00AB5C10: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
            // 0x00AB5C14: LDR x19, [x0]              | X19 = 0x10102464C457F;                  
            val_11 = 1179403647;
            // 0x00AB5C18: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
            // 0x00AB5C1C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00AB5C20: B #0xab5c2c                |  goto label_24;                         
            goto label_24;
            label_5:
            // 0x00AB5C24: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00AB5C28: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            val_16 = 1;
            label_24:
            // 0x00AB5C2C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00AB5C30: LDR x8, [x8, #0x858]       | X8 = 1152921514957330096;               
            // 0x00AB5C34: ADD x0, sp, #0x20          | X0 = (1152921514957342960 + 32) = 1152921514957342992 (0x1000000268F00910);
            // 0x00AB5C38: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, asset_sharedCfg>::Dispose();
            // 0x00AB5C3C: BL #0xf3acac               | val_2.Dispose();                        
            val_2.Dispose();
            // 0x00AB5C40: TBNZ w20, #0, #0xab5c54    | if ((0x1 & 0x1) != 0) goto label_26;    
            if((val_16 & 1) != 0)
            {
                goto label_26;
            }
            // 0x00AB5C44: CBZ x19, #0xab5c54         | if (0x0 == 0) goto label_26;            
            if(val_11 == 0)
            {
                goto label_26;
            }
            // 0x00AB5C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5C4C: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5C50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_26:
            // 0x00AB5C54: SUB sp, x29, #0x40         | SP = (1152921514957343104 - 64) = 1152921514957343040 (0x1000000268F00940);
            // 0x00AB5C58: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB5C5C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5C60: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB5C64: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB5C68: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AB5C6C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB5C70 (11230320), len: 436  VirtAddr: 0x00AB5C70 RVA: 0x00AB5C70 token: 100693240 methodIndex: 46994 delegateWrapperIndex: 0 methodInvoker: 0
        public static void ClearAll()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x00AB5C70: STP x24, x23, [sp, #-0x40]! | stack[1152921514957482704] = ???;  stack[1152921514957482712] = ???;  //  dest_result_addr=1152921514957482704 |  dest_result_addr=1152921514957482712
            // 0x00AB5C74: STP x22, x21, [sp, #0x10]  | stack[1152921514957482720] = ???;  stack[1152921514957482728] = ???;  //  dest_result_addr=1152921514957482720 |  dest_result_addr=1152921514957482728
            // 0x00AB5C78: STP x20, x19, [sp, #0x20]  | stack[1152921514957482736] = ???;  stack[1152921514957482744] = ???;  //  dest_result_addr=1152921514957482736 |  dest_result_addr=1152921514957482744
            // 0x00AB5C7C: STP x29, x30, [sp, #0x30]  | stack[1152921514957482752] = ???;  stack[1152921514957482760] = ???;  //  dest_result_addr=1152921514957482752 |  dest_result_addr=1152921514957482760
            // 0x00AB5C80: ADD x29, sp, #0x30         | X29 = (1152921514957482704 + 48) = 1152921514957482752 (0x1000000268F22B00);
            // 0x00AB5C84: SUB sp, sp, #0x30          | SP = (1152921514957482704 - 48) = 1152921514957482656 (0x1000000268F22AA0);
            // 0x00AB5C88: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB5C8C: LDRB w8, [x19, #0x40d]     | W8 = (bool)static_value_0373340D;       
            // 0x00AB5C90: TBNZ w8, #0, #0xab5cac     | if (static_value_0373340D == true) goto label_0;
            // 0x00AB5C94: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00AB5C98: LDR x8, [x8, #0x968]       | X8 = 0x2B8EB0C;                         
            // 0x00AB5C9C: LDR w0, [x8]               | W0 = 0x1183;                            
            // 0x00AB5CA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1183, ????);     
            // 0x00AB5CA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB5CA8: STRB w8, [x19, #0x40d]     | static_value_0373340D = true;            //  dest_result_addr=57881613
            label_0:
            // 0x00AB5CAC: STP xzr, xzr, [sp, #0x20]  | stack[1152921514957482688] = 0x0;  stack[1152921514957482696] = 0x0;  //  dest_result_addr=1152921514957482688 |  dest_result_addr=1152921514957482696
            // 0x00AB5CB0: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00AB5CB4: STR xzr, [sp, #0x18]       | stack[1152921514957482680] = 0x0;        //  dest_result_addr=1152921514957482680
            // 0x00AB5CB8: LDR x20, [x20, #0x270]     | X20 = 1152921504903331840;              
            // 0x00AB5CBC: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_4 = null;
            // 0x00AB5CC0: STP xzr, xzr, [sp, #8]     | stack[1152921514957482664] = 0x0;  stack[1152921514957482672] = 0x0;  //  dest_result_addr=1152921514957482664 |  dest_result_addr=1152921514957482672
            // 0x00AB5CC4: STR xzr, [sp]              | stack[1152921514957482656] = 0x0;        //  dest_result_addr=1152921514957482656
            // 0x00AB5CC8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5CCC: TBZ w8, #0, #0xab5ce0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB5CD0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5CD4: CBNZ w8, #0xab5ce0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB5CD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5CDC: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_4 = null;
            label_2:
            // 0x00AB5CE0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5CE4: LDR x19, [x8, #0x40]       | X19 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB5CE8: CBNZ x19, #0xab5cf0        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_3;
            }
            // 0x00AB5CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB5CF0: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB5CF4: LDR x8, [x8, #0x8f0]       | X8 = 1152921514957459504;               
            // 0x00AB5CF8: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB5CFC: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::GetEnumerator();
            // 0x00AB5D00: ADD x8, sp, #0x10          | X8 = (1152921514957482656 + 16) = 1152921514957482672 (0x1000000268F22AB0);
            // 0x00AB5D04: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_1 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            // 0x00AB5D08: ADRP x21, #0x363e000       | X21 = 56877056 (0x363E000);             
            // 0x00AB5D0C: LDR x21, [x21, #0x2b0]     | X21 = 1152921514957460528;              
            // 0x00AB5D10: ADD x0, sp, #0x10          | X0 = (1152921514957482656 + 16) = 1152921514957482672 (0x1000000268F22AB0);
            // 0x00AB5D14: LDR x1, [x21]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB5D18: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB5D1C: TBZ w0, #0, #0xab5d78      | if ((0x1000000268F22AB0 & 0x1) == 0) goto label_4;
            if((1760701104 & 1) == 0)
            {
                goto label_4;
            }
            // 0x00AB5D20: ADRP x22, #0x35dc000       | X22 = 56475648 (0x35DC000);             
            // 0x00AB5D24: ADRP x23, #0x3679000       | X23 = 57118720 (0x3679000);             
            // 0x00AB5D28: LDR x22, [x22, #0x4d8]     | X22 = 1152921514957461552;              
            // 0x00AB5D2C: LDR x23, [x23, #0x3b8]     | X23 = 1152921514957462576;              
            label_6:
            // 0x00AB5D30: LDR x1, [x22]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB5D34: ADD x0, sp, #0x10          | X0 = (1152921514957482656 + 16) = 1152921514957482672 (0x1000000268F22AB0);
            // 0x00AB5D38: BL #0xf3ac3c               | X0 = null.GetHandle();                  
            UnityEngine.Playables.PlayableHandle val_2 = 0.GetHandle();
            // 0x00AB5D3C: LDR x8, [x23]              | X8 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Value();
            // 0x00AB5D40: STP x0, x1, [sp]           | stack[1152921514957482656] = val_2.m_Handle;  stack[1152921514957482664] = val_2.m_Version;  //  dest_result_addr=1152921514957482656 |  dest_result_addr=1152921514957482664
            // 0x00AB5D44: MOV x0, sp                 | X0 = 1152921514957482656 (0x1000000268F22AA0);//ML01
            // 0x00AB5D48: MOV x1, x8                 | X1 = 1152921514957462576 (0x1000000268F1DC30);//ML01
            // 0x00AB5D4C: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB5D50: MOV x19, x0                | X19 = 1152921514957482656 (0x1000000268F22AA0);//ML01
            // 0x00AB5D54: CBNZ x19, #0xab5d5c        | if (val_2.m_Handle != 0) goto label_5;  
            if(val_2.m_Handle != 0)
            {
                goto label_5;
            }
            // 0x00AB5D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F22AA0, ????);
            label_5:
            // 0x00AB5D5C: MOV x0, x19                | X0 = 1152921514957482656 (0x1000000268F22AA0);//ML01
            // 0x00AB5D60: BL #0xab39e8               | val_2.m_Handle.Clear();                 
            val_2.m_Handle.Clear();
            // 0x00AB5D64: LDR x1, [x21]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB5D68: ADD x0, sp, #0x10          | X0 = (1152921514957482656 + 16) = 1152921514957482672 (0x1000000268F22AB0);
            // 0x00AB5D6C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB5D70: AND w8, w0, #1             | W8 = (1152921514957482672 & 1) = 0 (0x00000000);
            // 0x00AB5D74: TBNZ w8, #0, #0xab5d30     | if ((0x0 & 0x1) != 0) goto label_6;     
            if((0 & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x00AB5D78: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00AB5D7C: LDR x8, [x8, #0x1c8]       | X8 = 1152921514957463600;               
            // 0x00AB5D80: ADD x0, sp, #0x10          | X0 = (1152921514957482656 + 16) = 1152921514957482672 (0x1000000268F22AB0);
            // 0x00AB5D84: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::Dispose();
            // 0x00AB5D88: BL #0xf3acac               | null.Dispose();                         
            0.Dispose();
            // 0x00AB5D8C: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_5 = null;
            // 0x00AB5D90: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5D94: TBZ w8, #0, #0xab5da8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00AB5D98: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5D9C: CBNZ w8, #0xab5da8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00AB5DA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5DA4: LDR x0, [x20]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_5 = null;
            label_8:
            // 0x00AB5DA8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5DAC: LDR x19, [x8, #0x40]       | X19 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB5DB0: CBNZ x19, #0xab5db8        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_9;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_9;
            }
            // 0x00AB5DB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_9:
            // 0x00AB5DB8: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x00AB5DBC: LDR x8, [x8, #0xaf8]       | X8 = 1152921514957464624;               
            // 0x00AB5DC0: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB5DC4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Clear();
            // 0x00AB5DC8: BL #0x23fd92c              | Mihua.Asset.AssetMgr.m_LoadedAssetBundles.Clear();
            Mihua.Asset.AssetMgr.m_LoadedAssetBundles.Clear();
            // 0x00AB5DCC: LDR x8, [x20]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5DD0: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5DD4: LDR x19, [x8, #0x38]       | X19 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB5DD8: CBNZ x19, #0xab5de0        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_10;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_10;
            }
            // 0x00AB5DDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_LoadedAssetBundles, ????);
            label_10:
            // 0x00AB5DE0: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x00AB5DE4: LDR x8, [x8, #0xaf0]       | X8 = 1152921514957465648;               
            // 0x00AB5DE8: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00AB5DEC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::Clear();
            // 0x00AB5DF0: BL #0x23fd92c              | Mihua.Asset.AssetMgr.m_LoadedAssets.Clear();
            Mihua.Asset.AssetMgr.m_LoadedAssets.Clear();
            // 0x00AB5DF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5DF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5DFC: BL #0x1c3f89c              | System.GC.Collect();                    
            System.GC.Collect();
            // 0x00AB5E00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB5E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5E08: BL #0x1b8b13c              | X0 = UnityEngine.Resources.UnloadUnusedAssets();
            UnityEngine.AsyncOperation val_3 = UnityEngine.Resources.UnloadUnusedAssets();
            // 0x00AB5E0C: SUB sp, x29, #0x30         | SP = (1152921514957482752 - 48) = 1152921514957482704 (0x1000000268F22AD0);
            // 0x00AB5E10: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB5E14: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB5E18: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB5E1C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00AB5E20: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB5E24 (11230756), len: 2260  VirtAddr: 0x00AB5E24 RVA: 0x00AB5E24 token: 100693241 methodIndex: 46995 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Preclear(System.Action _clearEndCallBack)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            string val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            string val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            // 0x00AB5E24: STP x28, x27, [sp, #-0x60]! | stack[1152921514957661232] = ???;  stack[1152921514957661240] = ???;  //  dest_result_addr=1152921514957661232 |  dest_result_addr=1152921514957661240
            // 0x00AB5E28: STP x26, x25, [sp, #0x10]  | stack[1152921514957661248] = ???;  stack[1152921514957661256] = ???;  //  dest_result_addr=1152921514957661248 |  dest_result_addr=1152921514957661256
            // 0x00AB5E2C: STP x24, x23, [sp, #0x20]  | stack[1152921514957661264] = ???;  stack[1152921514957661272] = ???;  //  dest_result_addr=1152921514957661264 |  dest_result_addr=1152921514957661272
            // 0x00AB5E30: STP x22, x21, [sp, #0x30]  | stack[1152921514957661280] = ???;  stack[1152921514957661288] = ???;  //  dest_result_addr=1152921514957661280 |  dest_result_addr=1152921514957661288
            // 0x00AB5E34: STP x20, x19, [sp, #0x40]  | stack[1152921514957661296] = ???;  stack[1152921514957661304] = ???;  //  dest_result_addr=1152921514957661296 |  dest_result_addr=1152921514957661304
            // 0x00AB5E38: STP x29, x30, [sp, #0x50]  | stack[1152921514957661312] = ???;  stack[1152921514957661320] = ???;  //  dest_result_addr=1152921514957661312 |  dest_result_addr=1152921514957661320
            // 0x00AB5E3C: ADD x29, sp, #0x50         | X29 = (1152921514957661232 + 80) = 1152921514957661312 (0x1000000268F4E480);
            // 0x00AB5E40: SUB sp, sp, #0xf0          | SP = (1152921514957661232 - 240) = 1152921514957660992 (0x1000000268F4E340);
            // 0x00AB5E44: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB5E48: LDRB w8, [x19, #0x40e]     | W8 = (bool)static_value_0373340E;       
            // 0x00AB5E4C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00AB5E50: TBNZ w8, #0, #0xab5e6c     | if (static_value_0373340E == true) goto label_0;
            // 0x00AB5E54: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00AB5E58: LDR x8, [x8, #0x208]       | X8 = 0x2B8EB70;                         
            // 0x00AB5E5C: LDR w0, [x8]               | W0 = 0x119C;                            
            // 0x00AB5E60: BL #0x2782188              | X0 = sub_2782188( ?? 0x119C, ????);     
            // 0x00AB5E64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB5E68: STRB w8, [x19, #0x40e]     | static_value_0373340E = true;            //  dest_result_addr=57881614
            label_0:
            // 0x00AB5E6C: STP xzr, xzr, [x29, #-0x60] | stack[1152921514957661216] = 0x0;  stack[1152921514957661224] = 0x0;  //  dest_result_addr=1152921514957661216 |  dest_result_addr=1152921514957661224
            // 0x00AB5E70: STP xzr, xzr, [x29, #-0x70] | stack[1152921514957661200] = 0x0;  stack[1152921514957661208] = 0x0;  //  dest_result_addr=1152921514957661200 |  dest_result_addr=1152921514957661208
            // 0x00AB5E74: STP xzr, xzr, [x29, #-0x80] | stack[1152921514957661184] = 0x0;  stack[1152921514957661192] = 0x0;  //  dest_result_addr=1152921514957661184 |  dest_result_addr=1152921514957661192
            // 0x00AB5E78: STP xzr, xzr, [x29, #-0x90] | stack[1152921514957661168] = 0x0;  stack[1152921514957661176] = 0x0;  //  dest_result_addr=1152921514957661168 |  dest_result_addr=1152921514957661176
            // 0x00AB5E7C: STP xzr, xzr, [sp, #0xa0]  | stack[1152921514957661152] = 0x0;  stack[1152921514957661160] = 0x0;  //  dest_result_addr=1152921514957661152 |  dest_result_addr=1152921514957661160
            // 0x00AB5E80: STP xzr, xzr, [sp, #0x90]  | stack[1152921514957661136] = 0x0;  stack[1152921514957661144] = 0x0;  //  dest_result_addr=1152921514957661136 |  dest_result_addr=1152921514957661144
            // 0x00AB5E84: STP xzr, xzr, [sp, #0x80]  | stack[1152921514957661120] = 0x0;  stack[1152921514957661128] = 0x0;  //  dest_result_addr=1152921514957661120 |  dest_result_addr=1152921514957661128
            // 0x00AB5E88: STP xzr, xzr, [sp, #0x70]  | stack[1152921514957661104] = 0x0;  stack[1152921514957661112] = 0x0;  //  dest_result_addr=1152921514957661104 |  dest_result_addr=1152921514957661112
            // 0x00AB5E8C: STP xzr, xzr, [sp, #0x60]  | stack[1152921514957661088] = 0x0;  stack[1152921514957661096] = 0x0;  //  dest_result_addr=1152921514957661088 |  dest_result_addr=1152921514957661096
            // 0x00AB5E90: STP xzr, xzr, [sp, #0x50]  | stack[1152921514957661072] = 0x0;  stack[1152921514957661080] = 0x0;  //  dest_result_addr=1152921514957661072 |  dest_result_addr=1152921514957661080
            // 0x00AB5E94: ADRP x23, #0x35c8000       | X23 = 56393728 (0x35C8000);             
            // 0x00AB5E98: STR xzr, [sp, #0x48]       | stack[1152921514957661064] = 0x0;        //  dest_result_addr=1152921514957661064
            // 0x00AB5E9C: LDR x23, [x23, #0x270]     | X23 = 1152921504903331840;              
            // 0x00AB5EA0: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_40 = null;
            // 0x00AB5EA4: STP xzr, xzr, [sp, #0x38]  | stack[1152921514957661048] = 0x0;  stack[1152921514957661056] = 0x0;  //  dest_result_addr=1152921514957661048 |  dest_result_addr=1152921514957661056
            // 0x00AB5EA8: STR xzr, [sp, #0x30]       | stack[1152921514957661040] = 0x0;        //  dest_result_addr=1152921514957661040
            // 0x00AB5EAC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5EB0: TBZ w8, #0, #0xab5ec4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB5EB4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5EB8: CBNZ w8, #0xab5ec4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB5EBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5EC0: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_40 = null;
            label_2:
            // 0x00AB5EC4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5EC8: ADRP x21, #0x365c000       | X21 = 56999936 (0x365C000);             
            // 0x00AB5ECC: LDR x21, [x21, #0xac8]     | X21 = 1152921514955861968;              
            // 0x00AB5ED0: ADRP x22, #0x367e000       | X22 = 57139200 (0x367E000);             
            // 0x00AB5ED4: STR x20, [x8, #0x68]       | Mihua.Asset.AssetMgr.clearEndCallBack = X1;  //  dest_result_addr=1152921504903336040
            Mihua.Asset.AssetMgr.clearEndCallBack = X1;
            // 0x00AB5ED8: LDR x22, [x22, #0x330]     | X22 = 1152921514954102288;              
            // 0x00AB5EDC: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_41 = 0;
            // 0x00AB5EE0: B #0xab5ef4                |  goto label_3;                          
            goto label_3;
            label_12:
            // 0x00AB5EE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB5EE8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00AB5EEC: BL #0x2756264              | X1.Dispose();                           
            X1.Dispose();
            // 0x00AB5EF0: ADD w19, w19, #1           | W19 = (val_41 + 1) = val_41 (0x00000001);
            val_41 = 1;
            label_3:
            // 0x00AB5EF4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_42 = null;
            // 0x00AB5EF8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB5EFC: TBZ w8, #0, #0xab5f10      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00AB5F00: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5F04: CBNZ w8, #0xab5f10         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00AB5F08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5F0C: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_42 = null;
            label_5:
            // 0x00AB5F10: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5F14: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB5F18: CBNZ x20, #0xab5f20        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_6;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_6;
            }
            // 0x00AB5F1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_6:
            // 0x00AB5F20: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::get_Count();
            // 0x00AB5F24: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB5F28: BL #0x25ed72c              | X0 = Mihua.Asset.AssetMgr.m_WWWList.get_Count();
            int val_1 = Mihua.Asset.AssetMgr.m_WWWList.Count;
            // 0x00AB5F2C: MOV w8, w0                 | W8 = val_1;//m1                         
            // 0x00AB5F30: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_43 = null;
            // 0x00AB5F34: CMP w19, w8                | STATE = COMPARE(0x1, val_1)             
            // 0x00AB5F38: ADD x9, x0, #0x109         | X9 = (val_43 + 265) = 1152921504903332105 (0x1000000011AC0109);
            // 0x00AB5F3C: LDRH w9, [x9]              | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_109;
            // 0x00AB5F40: AND w9, w9, #0x100         | W9 = (Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256);
            // 0x00AB5F44: B.GE #0xab5f90             | if (val_41 >= val_1) goto label_7;      
            if(val_41 >= val_1)
            {
                goto label_7;
            }
            // 0x00AB5F48: AND w8, w9, #0xffff        | W8 = ((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00AB5F4C: CBZ w8, #0xab5f60          | if (((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_9;
            // 0x00AB5F50: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5F54: CBNZ w8, #0xab5f60         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00AB5F58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5F5C: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_44 = null;
            label_9:
            // 0x00AB5F60: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5F64: LDR x20, [x8, #0x98]       | X20 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB5F68: CBNZ x20, #0xab5f70        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_10;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_10;
            }
            // 0x00AB5F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_10:
            // 0x00AB5F70: LDR x2, [x22]              | X2 = public UnityEngine.Networking.UnityWebRequest System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::get_Item(int index);
            // 0x00AB5F74: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB5F78: MOV w1, w19                | W1 = 1 (0x1);//ML01                     
            // 0x00AB5F7C: BL #0x25ed734              | X0 = Mihua.Asset.AssetMgr.m_WWWList.get_Item(index:  1);
            UnityEngine.Networking.UnityWebRequest val_4 = Mihua.Asset.AssetMgr.m_WWWList.Item[1];
            // 0x00AB5F80: MOV x20, x0                | X20 = val_4;//m1                        
            // 0x00AB5F84: CBNZ x20, #0xab5ee4        | if (val_4 != null) goto label_12;       
            if(val_4 != null)
            {
                goto label_12;
            }
            // 0x00AB5F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            // 0x00AB5F8C: B #0xab5ee4                |  goto label_12;                         
            goto label_12;
            label_7:
            // 0x00AB5F90: AND w8, w9, #0xffff        | W8 = ((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00AB5F94: CBZ w8, #0xab5fa8          | if (((Mihua.Asset.AssetMgr.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_14;
            // 0x00AB5F98: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB5F9C: CBNZ w8, #0xab5fa8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00AB5FA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB5FA4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_45 = null;
            label_14:
            // 0x00AB5FA8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5FAC: LDR x19, [x8, #0x98]       | X19 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB5FB0: CBNZ x19, #0xab5fb8        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_15;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_15;
            }
            // 0x00AB5FB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_15:
            // 0x00AB5FB8: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB5FBC: LDR x8, [x8, #0x430]       | X8 = 1152921514957595056;               
            // 0x00AB5FC0: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB5FC4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::Clear();
            // 0x00AB5FC8: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_WWWList.Clear(); 
            Mihua.Asset.AssetMgr.m_WWWList.Clear();
            // 0x00AB5FCC: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5FD0: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5FD4: LDR x19, [x8, #0x88]       | X19 = Mihua.Asset.AssetMgr.m_WaitList;  
            // 0x00AB5FD8: CBNZ x19, #0xab5fe0        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_16;
            if(Mihua.Asset.AssetMgr.m_WaitList != null)
            {
                goto label_16;
            }
            // 0x00AB5FDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_WWWList, ????);
            label_16:
            // 0x00AB5FE0: ADRP x21, #0x3666000       | X21 = 57040896 (0x3666000);             
            // 0x00AB5FE4: LDR x21, [x21, #0xca8]     | X21 = 1152921510890633680;              
            val_46 = 1152921510890633680;
            // 0x00AB5FE8: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB5FEC: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB5FF0: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_WaitList.Clear();
            Mihua.Asset.AssetMgr.m_WaitList.Clear();
            // 0x00AB5FF4: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB5FF8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB5FFC: LDR x19, [x8, #0x50]       | X19 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            // 0x00AB6000: CBNZ x19, #0xab6008        | if (Mihua.Asset.AssetMgr.m_DownloadingErrors != null) goto label_17;
            if(Mihua.Asset.AssetMgr.m_DownloadingErrors != null)
            {
                goto label_17;
            }
            // 0x00AB6004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_WaitList, ????);
            label_17:
            // 0x00AB6008: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00AB600C: LDR x8, [x8, #0x750]       | X8 = 1152921510817589616;               
            // 0x00AB6010: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors;//m1
            // 0x00AB6014: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Clear();
            // 0x00AB6018: BL #0x23fd92c              | Mihua.Asset.AssetMgr.m_DownloadingErrors.Clear();
            Mihua.Asset.AssetMgr.m_DownloadingErrors.Clear();
            // 0x00AB601C: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6020: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6024: LDR x19, [x8, #0x58]       | X19 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB6028: CBNZ x19, #0xab6030        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_18;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_18;
            }
            // 0x00AB602C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_DownloadingErrors, ????);
            label_18:
            // 0x00AB6030: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00AB6034: LDR x8, [x8, #0x138]       | X8 = 1152921514957596080;               
            // 0x00AB6038: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB603C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::Clear();
            // 0x00AB6040: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_InProgressOperations.Clear();
            Mihua.Asset.AssetMgr.m_InProgressOperations.Clear();
            // 0x00AB6044: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6048: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB604C: LDR x19, [x8, #0x90]       | X19 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB6050: CBNZ x19, #0xab6058        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_19;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_19;
            }
            // 0x00AB6054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_InProgressOperations, ????);
            label_19:
            // 0x00AB6058: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB605C: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB6060: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_LoadingList.Clear();
            Mihua.Asset.AssetMgr.m_LoadingList.Clear();
            // 0x00AB6064: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6068: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB606C: LDR x19, [x8, #0x48]       | X19 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB6070: CBNZ x19, #0xab6078        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_20;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_20;
            }
            // 0x00AB6074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_LoadingList, ????);
            label_20:
            // 0x00AB6078: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x00AB607C: LDR x8, [x8, #0xf98]       | X8 = 1152921510807332752;               
            // 0x00AB6080: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB6084: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Clear();
            // 0x00AB6088: BL #0x23f5768              | Mihua.Asset.AssetMgr.m_RefCountDic.Clear();
            Mihua.Asset.AssetMgr.m_RefCountDic.Clear();
            // 0x00AB608C: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6090: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6094: LDR x19, [x8, #0x60]       | X19 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB6098: CBNZ x19, #0xab60a0        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_21;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_21;
            }
            // 0x00AB609C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_RefCountDic, ????);
            label_21:
            // 0x00AB60A0: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00AB60A4: LDR x8, [x8, #0xb38]       | X8 = 1152921514170421936;               
            // 0x00AB60A8: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB60AC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String[]>::Clear();
            // 0x00AB60B0: BL #0x23fd92c              | Mihua.Asset.AssetMgr.m_Dependencies.Clear();
            Mihua.Asset.AssetMgr.m_Dependencies.Clear();
            // 0x00AB60B4: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB60B8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB60BC: LDR x19, [x8, #0x40]       | X19 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB60C0: CBNZ x19, #0xab60c8        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_22;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_22;
            }
            // 0x00AB60C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_Dependencies, ????);
            label_22:
            // 0x00AB60C8: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB60CC: LDR x8, [x8, #0x8f0]       | X8 = 1152921514957459504;               
            // 0x00AB60D0: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB60D4: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::GetEnumerator();
            // 0x00AB60D8: ADD x8, sp, #0x10          | X8 = (1152921514957660992 + 16) = 1152921514957661008 (0x1000000268F4E350);
            // 0x00AB60DC: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_6 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            // 0x00AB60E0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00AB60E4: LDP q1, q0, [sp, #0x10]    | Q1 = val_7; Q0 = val_8;                  //  find_add[1152921514957649328] |  find_add[1152921514957649328]
            // 0x00AB60E8: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x00AB60EC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_9 = null;
            // 0x00AB60F0: STP q1, q0, [x29, #-0x70]  | stack[1152921514957661200] = val_7;  stack[1152921514957661216] = val_8;  //  dest_result_addr=1152921514957661200 |  dest_result_addr=1152921514957661216
            // 0x00AB60F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB60F8: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00AB60FC: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x00AB6100: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6104: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB6108: BL #0x25e9474              | .ctor();                                
            val_9 = new System.Collections.Generic.List<System.String>();
            // 0x00AB610C: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6110: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00AB6114: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6118: STRB w9, [x8, #0x70]       | Mihua.Asset.AssetMgr.isWaitClear = true;  //  dest_result_addr=1152921504903336048
            Mihua.Asset.AssetMgr.isWaitClear = true;
            // 0x00AB611C: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6120: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6124: LDR x20, [x8, #0x78]       | X20 = Mihua.Asset.AssetMgr.ab2AsstsList;
            // 0x00AB6128: CBNZ x20, #0xab6130        | if (Mihua.Asset.AssetMgr.ab2AsstsList != null) goto label_23;
            if(Mihua.Asset.AssetMgr.ab2AsstsList != null)
            {
                goto label_23;
            }
            // 0x00AB612C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_23:
            // 0x00AB6130: LDR x1, [x21]              | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB6134: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.ab2AsstsList;//m1
            // 0x00AB6138: BL #0x25ead28              | Mihua.Asset.AssetMgr.ab2AsstsList.Clear();
            Mihua.Asset.AssetMgr.ab2AsstsList.Clear();
            // 0x00AB613C: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
            // 0x00AB6140: LDR x22, [x22, #0x2b0]     | X22 = 1152921514957460528;              
            // 0x00AB6144: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB6148: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB614C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6150: TBZ w0, #0, #0xab6348      | if ((0x1000000268F4E410 & 0x1) == 0) goto label_24;
            if((1760879632 & 1) == 0)
            {
                goto label_24;
            }
            // 0x00AB6154: ADRP x25, #0x35dc000       | X25 = 56475648 (0x35DC000);             
            // 0x00AB6158: ADRP x26, #0x3679000       | X26 = 57118720 (0x3679000);             
            // 0x00AB615C: ADRP x27, #0x363e000       | X27 = 56877056 (0x363E000);             
            // 0x00AB6160: ADRP x28, #0x35c7000       | X28 = 56389632 (0x35C7000);             
            // 0x00AB6164: ADRP x24, #0x35e6000       | X24 = 56516608 (0x35E6000);             
            // 0x00AB6168: LDR x25, [x25, #0x4d8]     | X25 = 1152921514957461552;              
            // 0x00AB616C: LDR x26, [x26, #0x3b8]     | X26 = 1152921514957462576;              
            // 0x00AB6170: LDR x27, [x27, #0x9c8]     | X27 = 1152921514957597104;              
            val_47 = 1152921514957597104;
            // 0x00AB6174: LDR x28, [x28, #0xf00]     | X28 = 1152921510891359184;              
            // 0x00AB6178: LDR x24, [x24, #0x500]     | X24 = 1152921510890816336;              
            label_40:
            // 0x00AB617C: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB6180: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB6184: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_10 = val_7.GetHandle();
            // 0x00AB6188: LDR x8, [x26]              | X8 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Value();
            // 0x00AB618C: STP x0, x1, [x29, #-0x80]  | stack[1152921514957661184] = val_10.m_Handle;  stack[1152921514957661192] = val_10.m_Version;  //  dest_result_addr=1152921514957661184 |  dest_result_addr=1152921514957661192
            // 0x00AB6190: SUB x0, x29, #0x80         | X0 = (1152921514957661312 - 128) = 1152921514957661184 (0x1000000268F4E400);
            // 0x00AB6194: MOV x1, x8                 | X1 = 1152921514957462576 (0x1000000268F1DC30);//ML01
            // 0x00AB6198: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB619C: MOV x20, x0                | X20 = 1152921514957661184 (0x1000000268F4E400);//ML01
            // 0x00AB61A0: CBNZ x20, #0xab61a8        | if (val_10.m_Handle != 0) goto label_25;
            if(val_10.m_Handle != 0)
            {
                goto label_25;
            }
            // 0x00AB61A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F4E400, ????);
            label_25:
            // 0x00AB61A8: LDR x8, [x20, #0x20]       | X8 = val_8;                             
            // 0x00AB61AC: CBZ x8, #0xab61fc          | if (val_8 == 0) goto label_26;          
            if(val_8 == 0)
            {
                goto label_26;
            }
            // 0x00AB61B0: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB61B4: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB61B8: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_11 = val_7.GetHandle();
            // 0x00AB61BC: LDR x8, [x26]              | X8 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Value();
            // 0x00AB61C0: STP x0, x1, [x29, #-0x90]  | stack[1152921514957661168] = val_11.m_Handle;  stack[1152921514957661176] = val_11.m_Version;  //  dest_result_addr=1152921514957661168 |  dest_result_addr=1152921514957661176
            // 0x00AB61C4: SUB x0, x29, #0x90         | X0 = (1152921514957661312 - 144) = 1152921514957661168 (0x1000000268F4E3F0);
            // 0x00AB61C8: MOV x1, x8                 | X1 = 1152921514957462576 (0x1000000268F1DC30);//ML01
            // 0x00AB61CC: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB61D0: MOV x20, x0                | X20 = 1152921514957661168 (0x1000000268F4E3F0);//ML01
            // 0x00AB61D4: CBNZ x20, #0xab61dc        | if (val_11.m_Handle != 0) goto label_27;
            if(val_11.m_Handle != 0)
            {
                goto label_27;
            }
            // 0x00AB61D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F4E3F0, ????);
            label_27:
            // 0x00AB61DC: LDR x20, [x20, #0x20]      | X20 = val_7;                            
            // 0x00AB61E0: CBNZ x20, #0xab61e8        | if (val_7 != 0) goto label_28;          
            if(val_7 != 0)
            {
                goto label_28;
            }
            // 0x00AB61E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F4E3F0, ????);
            label_28:
            // 0x00AB61E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB61EC: MOV x0, x20                | X0 = val_7;//m1                         
            // 0x00AB61F0: BL #0x20ca724              | X0 = val_7.get_isDone();                
            bool val_12 = val_7.isDone;
            // 0x00AB61F4: AND w8, w0, #1             | W8 = (val_12 & 1);                      
            bool val_13 = val_12;
            // 0x00AB61F8: TBZ w8, #0, #0xab62d4      | if ((val_12 & 1) == false) goto label_29;
            if(val_13 == false)
            {
                goto label_29;
            }
            label_26:
            // 0x00AB61FC: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_48 = null;
            // 0x00AB6200: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6204: TBZ w8, #0, #0xab6218      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x00AB6208: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB620C: CBNZ w8, #0xab6218         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x00AB6210: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6214: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_48 = null;
            label_31:
            // 0x00AB6218: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB621C: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB6220: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB6224: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB6228: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_14 = val_7.GetHandle();
            // 0x00AB622C: LDR x8, [x27]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB6230: STP x0, x1, [sp, #0x90]    | stack[1152921514957661136] = val_14.m_Handle;  stack[1152921514957661144] = val_14.m_Version;  //  dest_result_addr=1152921514957661136 |  dest_result_addr=1152921514957661144
            // 0x00AB6234: ADD x0, sp, #0x90          | X0 = (1152921514957660992 + 144) = 1152921514957661136 (0x1000000268F4E3D0);
            // 0x00AB6238: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB623C: BL #0x1dc9dd4              | X0 = val_14.m_Handle.get_InitialType(); 
            System.Type val_15 = val_14.m_Handle.InitialType;
            // 0x00AB6240: MOV x21, x0                | X21 = val_15;//m1                       
            val_46 = val_15;
            // 0x00AB6244: CBNZ x20, #0xab624c        | if (Mihua.Asset.AssetMgr.nextNeedAssetList != null) goto label_32;
            if(Mihua.Asset.AssetMgr.nextNeedAssetList != null)
            {
                goto label_32;
            }
            // 0x00AB6248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_32:
            // 0x00AB624C: LDR x2, [x28]              | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
            // 0x00AB6250: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB6254: MOV x1, x21                | X1 = val_15;//m1                        
            // 0x00AB6258: BL #0x25ead74              | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_46);
            bool val_16 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_46);
            // 0x00AB625C: AND w8, w0, #1             | W8 = (val_16 & 1);                      
            bool val_17 = val_16;
            // 0x00AB6260: TBNZ w8, #0, #0xab6334     | if ((val_16 & 1) == true) goto label_33;
            if(val_17 == true)
            {
                goto label_33;
            }
            // 0x00AB6264: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB6268: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB626C: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_18 = val_7.GetHandle();
            // 0x00AB6270: LDR x8, [x26]              | X8 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Value();
            // 0x00AB6274: STP x0, x1, [sp, #0x80]    | stack[1152921514957661120] = val_18.m_Handle;  stack[1152921514957661128] = val_18.m_Version;  //  dest_result_addr=1152921514957661120 |  dest_result_addr=1152921514957661128
            // 0x00AB6278: ADD x0, sp, #0x80          | X0 = (1152921514957660992 + 128) = 1152921514957661120 (0x1000000268F4E3C0);
            // 0x00AB627C: MOV x1, x8                 | X1 = 1152921514957462576 (0x1000000268F1DC30);//ML01
            // 0x00AB6280: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB6284: MOV x20, x0                | X20 = 1152921514957661120 (0x1000000268F4E3C0);//ML01
            // 0x00AB6288: CBNZ x20, #0xab6290        | if (val_18.m_Handle != 0) goto label_34;
            if(val_18.m_Handle != 0)
            {
                goto label_34;
            }
            // 0x00AB628C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F4E3C0, ????);
            label_34:
            // 0x00AB6290: MOV x0, x20                | X0 = 1152921514957661120 (0x1000000268F4E3C0);//ML01
            // 0x00AB6294: BL #0xab39e8               | val_18.m_Handle.Clear();                
            val_18.m_Handle.Clear();
            // 0x00AB6298: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB629C: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB62A0: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_19 = val_7.GetHandle();
            // 0x00AB62A4: LDR x8, [x27]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB62A8: STP x0, x1, [sp, #0x70]    | stack[1152921514957661104] = val_19.m_Handle;  stack[1152921514957661112] = val_19.m_Version;  //  dest_result_addr=1152921514957661104 |  dest_result_addr=1152921514957661112
            // 0x00AB62AC: ADD x0, sp, #0x70          | X0 = (1152921514957660992 + 112) = 1152921514957661104 (0x1000000268F4E3B0);
            // 0x00AB62B0: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB62B4: BL #0x1dc9dd4              | X0 = val_19.m_Handle.get_InitialType(); 
            System.Type val_20 = val_19.m_Handle.InitialType;
            // 0x00AB62B8: MOV x20, x0                | X20 = val_20;//m1                       
            // 0x00AB62BC: CBNZ x19, #0xab62c4        | if ( != 0) goto label_35;               
            if(null != 0)
            {
                goto label_35;
            }
            // 0x00AB62C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_35:
            // 0x00AB62C4: LDR x2, [x24]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            val_49 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB62C8: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB62CC: MOV x1, x20                | X1 = val_20;//m1                        
            val_50 = val_20;
            // 0x00AB62D0: B #0xab6330                |  goto label_36;                         
            goto label_36;
            label_29:
            // 0x00AB62D4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_51 = null;
            // 0x00AB62D8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB62DC: TBZ w8, #0, #0xab62f0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x00AB62E0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB62E4: CBNZ w8, #0xab62f0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x00AB62E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB62EC: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_51 = null;
            label_38:
            // 0x00AB62F0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB62F4: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB62F8: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB62FC: LDR x20, [x8, #0x78]       | X20 = Mihua.Asset.AssetMgr.ab2AsstsList;
            // 0x00AB6300: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_21 = val_7.GetHandle();
            // 0x00AB6304: LDR x8, [x27]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB6308: STP x0, x1, [sp, #0xa0]    | stack[1152921514957661152] = val_21.m_Handle;  stack[1152921514957661160] = val_21.m_Version;  //  dest_result_addr=1152921514957661152 |  dest_result_addr=1152921514957661160
            // 0x00AB630C: ADD x0, sp, #0xa0          | X0 = (1152921514957660992 + 160) = 1152921514957661152 (0x1000000268F4E3E0);
            // 0x00AB6310: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB6314: BL #0x1dc9dd4              | X0 = val_21.m_Handle.get_InitialType(); 
            System.Type val_22 = val_21.m_Handle.InitialType;
            // 0x00AB6318: MOV x21, x0                | X21 = val_22;//m1                       
            val_46 = val_22;
            // 0x00AB631C: CBNZ x20, #0xab6324        | if (Mihua.Asset.AssetMgr.ab2AsstsList != null) goto label_39;
            if(Mihua.Asset.AssetMgr.ab2AsstsList != null)
            {
                goto label_39;
            }
            // 0x00AB6320: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_39:
            // 0x00AB6324: LDR x2, [x24]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            val_49 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB6328: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.ab2AsstsList;//m1
            // 0x00AB632C: MOV x1, x21                | X1 = val_22;//m1                        
            val_50 = val_46;
            label_36:
            // 0x00AB6330: BL #0x25ea480              | Mihua.Asset.AssetMgr.ab2AsstsList.Add(item:  val_50 = val_46);
            Mihua.Asset.AssetMgr.ab2AsstsList.Add(item:  val_50);
            label_33:
            // 0x00AB6334: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB6338: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB633C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6340: AND w8, w0, #1             | W8 = (1152921514957661200 & 1) = 0 (0x00000000);
            // 0x00AB6344: TBNZ w8, #0, #0xab617c     | if ((0x0 & 0x1) != 0) goto label_40;    
            if((0 & 1) != 0)
            {
                goto label_40;
            }
            label_24:
            // 0x00AB6348: ADRP x25, #0x35fc000       | X25 = 56606720 (0x35FC000);             
            // 0x00AB634C: ADRP x26, #0x35bd000       | X26 = 56348672 (0x35BD000);             
            // 0x00AB6350: ADRP x24, #0x35d4000       | X24 = 56442880 (0x35D4000);             
            // 0x00AB6354: LDR x25, [x25, #0xb58]     | X25 = 1152921510022759280;              
            // 0x00AB6358: LDR x26, [x26, #0xb50]     | X26 = 1152921510890998992;              
            // 0x00AB635C: LDR x24, [x24, #0xbe8]     | X24 = 1152921514955719104;              
            // 0x00AB6360: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_52 = 0;
            // 0x00AB6364: B #0xab637c                |  goto label_41;                         
            goto label_41;
            label_48:
            // 0x00AB6368: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Remove(System.String key);
            // 0x00AB636C: MOV x0, x21                | X0 = val_22;//m1                        
            // 0x00AB6370: MOV x1, x22                | X1 = 58195160 (0x377FCD8);//ML01        
            // 0x00AB6374: BL #0x23fe354              | X0 = val_22.Remove(key:  1152921514957460528);
            bool val_23 = val_46.Remove(key:  1152921514957460528);
            // 0x00AB6378: ADD w20, w20, #1           | W20 = (val_52 + 1) = val_52 (0x00000001);
            val_52 = 1;
            label_41:
            // 0x00AB637C: CBNZ x19, #0xab6384        | if ( != 0) goto label_42;               
            if(null != 0)
            {
                goto label_42;
            }
            // 0x00AB6380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_42:
            // 0x00AB6384: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB6388: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB638C: BL #0x25ed72c              | X0 = get_Count();                       
            int val_24 = Count;
            // 0x00AB6390: CMP w20, w0                | STATE = COMPARE(0x1, val_24)            
            // 0x00AB6394: B.GE #0xab63e4             | if (val_52 >= val_24) goto label_43;    
            if(val_52 >= val_24)
            {
                goto label_43;
            }
            // 0x00AB6398: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_53 = null;
            // 0x00AB639C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB63A0: TBZ w8, #0, #0xab63b4      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x00AB63A4: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB63A8: CBNZ w8, #0xab63b4         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x00AB63AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB63B0: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_53 = null;
            label_45:
            // 0x00AB63B4: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB63B8: LDR x21, [x8, #0x40]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB63BC: CBNZ x19, #0xab63c4        | if ( != 0) goto label_46;               
            if(null != 0)
            {
                goto label_46;
            }
            // 0x00AB63C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_46:
            // 0x00AB63C4: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB63C8: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB63CC: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB63D0: BL #0x25ed734              | X0 = get_Item(index:  1);               
            string val_25 = Item[1];
            // 0x00AB63D4: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x00AB63D8: CBNZ x21, #0xab6368        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_48;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_48;
            }
            // 0x00AB63DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            // 0x00AB63E0: B #0xab6368                |  goto label_48;                         
            goto label_48;
            label_43:
            // 0x00AB63E4: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00AB63E8: LDR x8, [x8, #0x1c8]       | X8 = 1152921514957463600;               
            // 0x00AB63EC: SUB x0, x29, #0x70         | X0 = (1152921514957661312 - 112) = 1152921514957661200 (0x1000000268F4E410);
            // 0x00AB63F0: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::Dispose();
            // 0x00AB63F4: BL #0xf3acac               | val_7.Dispose();                        
            val_7.Dispose();
            // 0x00AB63F8: CBNZ x19, #0xab6400        | if ( != 0) goto label_49;               
            if(null != 0)
            {
                goto label_49;
            }
            // 0x00AB63FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F4E410, ????);
            label_49:
            // 0x00AB6400: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB6404: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB6408: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB640C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB6410: BL #0x25ead28              | Clear();                                
            Clear();
            // 0x00AB6414: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_54 = null;
            // 0x00AB6418: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB641C: TBZ w8, #0, #0xab6430      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x00AB6420: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6424: CBNZ w8, #0xab6430         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x00AB6428: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB642C: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_54 = null;
            label_51:
            // 0x00AB6430: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6434: LDR x20, [x8, #0x38]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB6438: CBNZ x20, #0xab6440        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_52;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_52;
            }
            // 0x00AB643C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_52:
            // 0x00AB6440: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00AB6444: LDR x8, [x8, #0xc88]       | X8 = 1152921514957614512;               
            // 0x00AB6448: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00AB644C: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::GetEnumerator();
            // 0x00AB6450: ADD x8, sp, #0x10          | X8 = (1152921514957660992 + 16) = 1152921514957661008 (0x1000000268F4E350);
            // 0x00AB6454: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_26 = Mihua.Asset.AssetMgr.m_LoadedAssets.GetEnumerator();
            // 0x00AB6458: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB645C: LDP q1, q0, [sp, #0x10]    | Q1 = val_7; Q0 = val_8;                  //  find_add[1152921514957649328] |  find_add[1152921514957649328]
            // 0x00AB6460: LDR x8, [x8, #0x460]       | X8 = 1152921514957615536;               
            // 0x00AB6464: ADD x0, sp, #0x50          | X0 = (1152921514957660992 + 80) = 1152921514957661072 (0x1000000268F4E390);
            // 0x00AB6468: LDR x1, [x8]               | X1 = public System.Boolean Dictionary.Enumerator<System.String, UnityEngine.Object>::MoveNext();
            // 0x00AB646C: STP q1, q0, [sp, #0x50]    | stack[1152921514957661072] = val_7;  stack[1152921514957661088] = val_8;  //  dest_result_addr=1152921514957661072 |  dest_result_addr=1152921514957661088
            // 0x00AB6470: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6474: TBZ w0, #0, #0xab6594      | if ((0x1000000268F4E390 & 0x1) == 0) goto label_53;
            if((1760879504 & 1) == 0)
            {
                goto label_53;
            }
            // 0x00AB6478: ADRP x28, #0x3644000       | X28 = 56901632 (0x3644000);             
            // 0x00AB647C: ADRP x27, #0x362f000       | X27 = 56815616 (0x362F000);             
            // 0x00AB6480: ADRP x24, #0x35c7000       | X24 = 56389632 (0x35C7000);             
            // 0x00AB6484: LDR x28, [x28, #0x7c8]     | X28 = 1152921514957616560;              
            // 0x00AB6488: LDR x27, [x27, #0x1b0]     | X27 = 1152921514957617584;              
            val_47 = 1152921514957617584;
            // 0x00AB648C: LDR x24, [x24, #0xf00]     | X24 = 1152921510891359184;              
            label_60:
            // 0x00AB6490: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_55 = null;
            // 0x00AB6494: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6498: TBZ w8, #0, #0xab64ac      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_55;
            // 0x00AB649C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB64A0: CBNZ w8, #0xab64ac         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
            // 0x00AB64A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB64A8: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_55 = null;
            label_55:
            // 0x00AB64AC: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB64B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB64B4: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB64B8: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB64BC: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00AB64C0: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB64C4: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_27 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB64C8: LDR x1, [x28]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, UnityEngine.Object>::get_Current();
            // 0x00AB64CC: MOV x21, x0                | X21 = val_27;//m1                       
            // 0x00AB64D0: ADD x0, sp, #0x50          | X0 = (1152921514957660992 + 80) = 1152921514957661072 (0x1000000268F4E390);
            // 0x00AB64D4: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_28 = val_7.GetHandle();
            // 0x00AB64D8: LDR x8, [x27]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, UnityEngine.Object>::get_Key();
            // 0x00AB64DC: STP x0, x1, [sp, #0x40]    | stack[1152921514957661056] = val_28.m_Handle;  stack[1152921514957661064] = val_28.m_Version;  //  dest_result_addr=1152921514957661056 |  dest_result_addr=1152921514957661064
            // 0x00AB64E0: ADD x0, sp, #0x40          | X0 = (1152921514957660992 + 64) = 1152921514957661056 (0x1000000268F4E380);
            // 0x00AB64E4: MOV x1, x8                 | X1 = 1152921514957617584 (0x1000000268F439B0);//ML01
            // 0x00AB64E8: BL #0x1dc9dd4              | X0 = val_28.m_Handle.get_InitialType(); 
            System.Type val_29 = val_28.m_Handle.InitialType;
            // 0x00AB64EC: MOV x22, x0                | X22 = val_29;//m1                       
            // 0x00AB64F0: CBNZ x21, #0xab64f8        | if (val_27 != null) goto label_56;      
            if(val_27 != null)
            {
                goto label_56;
            }
            // 0x00AB64F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_56:
            // 0x00AB64F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB64FC: MOV x0, x21                | X0 = val_27;//m1                        
            // 0x00AB6500: MOV x1, x22                | X1 = val_29;//m1                        
            // 0x00AB6504: BL #0xb42c9c               | X0 = val_27.AssetNameToABPath(assetName:  val_29);
            string val_30 = val_27.AssetNameToABPath(assetName:  val_29);
            // 0x00AB6508: MOV x21, x0                | X21 = val_30;//m1                       
            val_46 = val_30;
            // 0x00AB650C: CBNZ x20, #0xab6514        | if (Mihua.Asset.AssetMgr.nextNeedAssetList != null) goto label_57;
            if(Mihua.Asset.AssetMgr.nextNeedAssetList != null)
            {
                goto label_57;
            }
            // 0x00AB6510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_57:
            // 0x00AB6514: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
            // 0x00AB6518: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB651C: MOV x1, x21                | X1 = val_30;//m1                        
            // 0x00AB6520: BL #0x25ead74              | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_46);
            bool val_31 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_46);
            // 0x00AB6524: AND w8, w0, #1             | W8 = (val_31 & 1);                      
            bool val_32 = val_31;
            // 0x00AB6528: TBNZ w8, #0, #0xab6570     | if ((val_31 & 1) == true) goto label_58;
            if(val_32 == true)
            {
                goto label_58;
            }
            // 0x00AB652C: LDR x1, [x28]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, UnityEngine.Object>::get_Current();
            // 0x00AB6530: ADD x0, sp, #0x50          | X0 = (1152921514957660992 + 80) = 1152921514957661072 (0x1000000268F4E390);
            // 0x00AB6534: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_33 = val_7.GetHandle();
            // 0x00AB6538: LDR x8, [x27]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, UnityEngine.Object>::get_Key();
            // 0x00AB653C: STP x0, x1, [sp, #0x30]    | stack[1152921514957661040] = val_33.m_Handle;  stack[1152921514957661048] = val_33.m_Version;  //  dest_result_addr=1152921514957661040 |  dest_result_addr=1152921514957661048
            // 0x00AB6540: ADD x0, sp, #0x30          | X0 = (1152921514957660992 + 48) = 1152921514957661040 (0x1000000268F4E370);
            // 0x00AB6544: MOV x1, x8                 | X1 = 1152921514957617584 (0x1000000268F439B0);//ML01
            // 0x00AB6548: BL #0x1dc9dd4              | X0 = val_33.m_Handle.get_InitialType(); 
            System.Type val_34 = val_33.m_Handle.InitialType;
            // 0x00AB654C: MOV x20, x0                | X20 = val_34;//m1                       
            // 0x00AB6550: CBNZ x19, #0xab6558        | if ( != 0) goto label_59;               
            if(null != 0)
            {
                goto label_59;
            }
            // 0x00AB6554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_59:
            // 0x00AB6558: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB655C: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x00AB6560: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6564: MOV x1, x20                | X1 = val_34;//m1                        
            // 0x00AB6568: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB656C: BL #0x25ea480              | Add(item:  val_34);                     
            Add(item:  val_34);
            label_58:
            // 0x00AB6570: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB6574: LDR x8, [x8, #0x460]       | X8 = 1152921514957615536;               
            // 0x00AB6578: ADD x0, sp, #0x50          | X0 = (1152921514957660992 + 80) = 1152921514957661072 (0x1000000268F4E390);
            // 0x00AB657C: LDR x1, [x8]               | X1 = public System.Boolean Dictionary.Enumerator<System.String, UnityEngine.Object>::MoveNext();
            // 0x00AB6580: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6584: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_56 = 0;
            // 0x00AB6588: AND w8, w0, #1             | W8 = (1152921514957661072 & 1) = 0 (0x00000000);
            // 0x00AB658C: TBNZ w8, #0, #0xab6490     | if ((0x0 & 0x1) != 0) goto label_60;    
            if((0 & 1) != 0)
            {
                goto label_60;
            }
            // 0x00AB6590: B #0xab65b8                |  goto label_62;                         
            goto label_62;
            label_53:
            // 0x00AB6594: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_56 = 0;
            // 0x00AB6598: B #0xab65b8                |  goto label_62;                         
            goto label_62;
            label_69:
            // 0x00AB659C: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00AB65A0: LDR x8, [x8, #0x58]        | X8 = 1152921514957634992;               
            // 0x00AB65A4: MOV x0, x21                | X0 = val_22;//m1                        
            // 0x00AB65A8: MOV x1, x22                | X1 = 58195160 (0x377FCD8);//ML01        
            // 0x00AB65AC: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::Remove(System.String key);
            // 0x00AB65B0: BL #0x23fe354              | X0 = val_22.Remove(key:  1152921514957460528);
            bool val_35 = val_46.Remove(key:  1152921514957460528);
            // 0x00AB65B4: ADD w20, w20, #1           | W20 = (val_56 + 1) = val_56 (0x00000001);
            val_56 = 1;
            label_62:
            // 0x00AB65B8: CBNZ x19, #0xab65c0        | if ( != 0) goto label_63;               
            if(null != 0)
            {
                goto label_63;
            }
            // 0x00AB65BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_63:
            // 0x00AB65C0: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB65C4: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB65C8: BL #0x25ed72c              | X0 = get_Count();                       
            int val_36 = Count;
            // 0x00AB65CC: CMP w20, w0                | STATE = COMPARE(0x1, val_36)            
            // 0x00AB65D0: B.GE #0xab6620             | if (val_56 >= val_36) goto label_64;    
            if(val_56 >= val_36)
            {
                goto label_64;
            }
            // 0x00AB65D4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_57 = null;
            // 0x00AB65D8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB65DC: TBZ w8, #0, #0xab65f0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_66;
            // 0x00AB65E0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB65E4: CBNZ w8, #0xab65f0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_66;
            // 0x00AB65E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB65EC: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_57 = null;
            label_66:
            // 0x00AB65F0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB65F4: LDR x21, [x8, #0x38]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB65F8: CBNZ x19, #0xab6600        | if ( != 0) goto label_67;               
            if(null != 0)
            {
                goto label_67;
            }
            // 0x00AB65FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_67:
            // 0x00AB6600: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB6604: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6608: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB660C: BL #0x25ed734              | X0 = get_Item(index:  1);               
            string val_37 = Item[1];
            // 0x00AB6610: MOV x22, x0                | X22 = val_37;//m1                       
            // 0x00AB6614: CBNZ x21, #0xab659c        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_69;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_69;
            }
            // 0x00AB6618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            // 0x00AB661C: B #0xab659c                |  goto label_69;                         
            goto label_69;
            label_64:
            // 0x00AB6620: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB6624: LDR x8, [x8, #0x908]       | X8 = 1152921514957640112;               
            // 0x00AB6628: ADD x0, sp, #0x50          | X0 = (1152921514957660992 + 80) = 1152921514957661072 (0x1000000268F4E390);
            // 0x00AB662C: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, UnityEngine.Object>::Dispose();
            // 0x00AB6630: BL #0xf3acac               | val_7.Dispose();                        
            val_7.Dispose();
            // 0x00AB6634: CBNZ x19, #0xab663c        | if ( != 0) goto label_70;               
            if(null != 0)
            {
                goto label_70;
            }
            // 0x00AB6638: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F4E390, ????);
            label_70:
            // 0x00AB663C: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB6640: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB6644: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6648: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB664C: BL #0x25ead28              | Clear();                                
            Clear();
            // 0x00AB6650: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00AB6654: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
            // 0x00AB6658: LDR x0, [x8]               | X0 = typeof(ZMG);                       
            // 0x00AB665C: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
            // 0x00AB6660: TBZ w8, #0, #0xab6670      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_72;
            // 0x00AB6664: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6668: CBNZ w8, #0xab6670         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x00AB666C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
            label_72:
            // 0x00AB6670: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB6674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6678: BL #0x26a8450              | X0 = ZMG.get_FloatTextMgr();            
            FloatTextMgr val_38 = ZMG.FloatTextMgr;
            // 0x00AB667C: MOV x19, x0                | X19 = val_38;//m1                       
            // 0x00AB6680: CBNZ x19, #0xab6688        | if (val_38 != null) goto label_73;      
            if(val_38 != null)
            {
                goto label_73;
            }
            // 0x00AB6684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_73:
            // 0x00AB6688: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB668C: MOV x0, x19                | X0 = val_38;//m1                        
            // 0x00AB6690: BL #0xc05c1c               | val_38.Clear();                         
            val_38.Clear();
            // 0x00AB6694: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00AB6698: LDR x8, [x8, #0xf80]       | X8 = 1152921504912171008;               
            // 0x00AB669C: LDR x0, [x8]               | X0 = typeof(UIModelDisplayMgr);         
            // 0x00AB66A0: LDRB w8, [x0, #0x10a]      | W8 = UIModelDisplayMgr.__il2cppRuntimeField_10A;
            // 0x00AB66A4: TBZ w8, #0, #0xab66b4      | if (UIModelDisplayMgr.__il2cppRuntimeField_has_cctor == 0) goto label_75;
            // 0x00AB66A8: LDR w8, [x0, #0xbc]        | W8 = UIModelDisplayMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB66AC: CBNZ w8, #0xab66b4         | if (UIModelDisplayMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_75;
            // 0x00AB66B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UIModelDisplayMgr), ????);
            label_75:
            // 0x00AB66B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB66B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB66BC: BL #0xfa1f58               | X0 = UIModelDisplayMgr.get_Instance();  
            UIModelDisplayMgr val_39 = UIModelDisplayMgr.Instance;
            // 0x00AB66C0: MOV x19, x0                | X19 = val_39;//m1                       
            // 0x00AB66C4: CBNZ x19, #0xab66cc        | if (val_39 != null) goto label_76;      
            if(val_39 != null)
            {
                goto label_76;
            }
            // 0x00AB66C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_76:
            // 0x00AB66CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB66D0: MOV x0, x19                | X0 = val_39;//m1                        
            // 0x00AB66D4: BL #0xfb7b18               | val_39.ClearModel();                    
            val_39.ClearModel();
            // 0x00AB66D8: SUB sp, x29, #0x50         | SP = (1152921514957661312 - 80) = 1152921514957661232 (0x1000000268F4E430);
            // 0x00AB66DC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB66E0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB66E4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB66E8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB66EC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB66F0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AB66F4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB459C (11224476), len: 852  VirtAddr: 0x00AB459C RVA: 0x00AB459C token: 100693242 methodIndex: 46996 delegateWrapperIndex: 0 methodInvoker: 0
        public static void EndClear()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x00AB459C: STP x28, x27, [sp, #-0x60]! | stack[1152921514957842864] = ???;  stack[1152921514957842872] = ???;  //  dest_result_addr=1152921514957842864 |  dest_result_addr=1152921514957842872
            // 0x00AB45A0: STP x26, x25, [sp, #0x10]  | stack[1152921514957842880] = ???;  stack[1152921514957842888] = ???;  //  dest_result_addr=1152921514957842880 |  dest_result_addr=1152921514957842888
            // 0x00AB45A4: STP x24, x23, [sp, #0x20]  | stack[1152921514957842896] = ???;  stack[1152921514957842904] = ???;  //  dest_result_addr=1152921514957842896 |  dest_result_addr=1152921514957842904
            // 0x00AB45A8: STP x22, x21, [sp, #0x30]  | stack[1152921514957842912] = ???;  stack[1152921514957842920] = ???;  //  dest_result_addr=1152921514957842912 |  dest_result_addr=1152921514957842920
            // 0x00AB45AC: STP x20, x19, [sp, #0x40]  | stack[1152921514957842928] = ???;  stack[1152921514957842936] = ???;  //  dest_result_addr=1152921514957842928 |  dest_result_addr=1152921514957842936
            // 0x00AB45B0: STP x29, x30, [sp, #0x50]  | stack[1152921514957842944] = ???;  stack[1152921514957842952] = ???;  //  dest_result_addr=1152921514957842944 |  dest_result_addr=1152921514957842952
            // 0x00AB45B4: ADD x29, sp, #0x50         | X29 = (1152921514957842864 + 80) = 1152921514957842944 (0x1000000268F7AA00);
            // 0x00AB45B8: SUB sp, sp, #0x70          | SP = (1152921514957842864 - 112) = 1152921514957842752 (0x1000000268F7A940);
            // 0x00AB45BC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB45C0: LDRB w8, [x19, #0x40f]     | W8 = (bool)static_value_0373340F;       
            // 0x00AB45C4: TBNZ w8, #0, #0xab45e0     | if (static_value_0373340F == true) goto label_0;
            // 0x00AB45C8: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x00AB45CC: LDR x8, [x8, #0x6b0]       | X8 = 0x2B8EB18;                         
            // 0x00AB45D0: LDR w0, [x8]               | W0 = 0x1186;                            
            // 0x00AB45D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1186, ????);     
            // 0x00AB45D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB45DC: STRB w8, [x19, #0x40f]     | static_value_0373340F = true;            //  dest_result_addr=57881615
            label_0:
            // 0x00AB45E0: STP xzr, xzr, [sp, #0x60]  | stack[1152921514957842848] = 0x0;  stack[1152921514957842856] = 0x0;  //  dest_result_addr=1152921514957842848 |  dest_result_addr=1152921514957842856
            // 0x00AB45E4: STP xzr, xzr, [sp, #0x50]  | stack[1152921514957842832] = 0x0;  stack[1152921514957842840] = 0x0;  //  dest_result_addr=1152921514957842832 |  dest_result_addr=1152921514957842840
            // 0x00AB45E8: STP xzr, xzr, [sp, #0x40]  | stack[1152921514957842816] = 0x0;  stack[1152921514957842824] = 0x0;  //  dest_result_addr=1152921514957842816 |  dest_result_addr=1152921514957842824
            // 0x00AB45EC: ADRP x23, #0x35c8000       | X23 = 56393728 (0x35C8000);             
            // 0x00AB45F0: STR xzr, [sp, #0x38]       | stack[1152921514957842808] = 0x0;        //  dest_result_addr=1152921514957842808
            // 0x00AB45F4: LDR x23, [x23, #0x270]     | X23 = 1152921504903331840;              
            // 0x00AB45F8: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_16 = null;
            // 0x00AB45FC: STP xzr, xzr, [sp, #0x28]  | stack[1152921514957842792] = 0x0;  stack[1152921514957842800] = 0x0;  //  dest_result_addr=1152921514957842792 |  dest_result_addr=1152921514957842800
            // 0x00AB4600: STR xzr, [sp, #0x20]       | stack[1152921514957842784] = 0x0;        //  dest_result_addr=1152921514957842784
            // 0x00AB4604: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4608: TBZ w8, #0, #0xab461c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB460C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4610: CBNZ w8, #0xab461c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB4614: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB4618: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_16 = null;
            label_2:
            // 0x00AB461C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4620: STRB wzr, [x8, #0x70]      | Mihua.Asset.AssetMgr.isWaitClear = false;  //  dest_result_addr=1152921504903336048
            Mihua.Asset.AssetMgr.isWaitClear = false;
            // 0x00AB4624: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB4628: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB462C: LDR x19, [x8, #0x40]       | X19 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB4630: CBNZ x19, #0xab4638        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_3;
            }
            // 0x00AB4634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB4638: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB463C: LDR x8, [x8, #0x8f0]       | X8 = 1152921514957459504;               
            // 0x00AB4640: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB4644: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::GetEnumerator();
            // 0x00AB4648: MOV x8, sp                 | X8 = 1152921514957842752 (0x1000000268F7A940);//ML01
            // 0x00AB464C: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_1 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            // 0x00AB4650: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00AB4654: LDP q1, q0, [sp]           | Q1 = val_2; Q0 = val_3;                  //  find_add[1152921514957830960] |  find_add[1152921514957830960]
            // 0x00AB4658: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x00AB465C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_4 = null;
            // 0x00AB4660: STP q1, q0, [sp, #0x50]    | stack[1152921514957842832] = val_2;  stack[1152921514957842848] = val_3;  //  dest_result_addr=1152921514957842832 |  dest_result_addr=1152921514957842848
            // 0x00AB4664: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB4668: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00AB466C: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x00AB4670: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB4674: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB4678: BL #0x25e9474              | .ctor();                                
            val_4 = new System.Collections.Generic.List<System.String>();
            // 0x00AB467C: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
            // 0x00AB4680: LDR x22, [x22, #0x2b0]     | X22 = 1152921514957460528;              
            // 0x00AB4684: ADD x0, sp, #0x50          | X0 = (1152921514957842752 + 80) = 1152921514957842832 (0x1000000268F7A990);
            // 0x00AB4688: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB468C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB4690: TBZ w0, #0, #0xab47a8      | if ((0x1000000268F7A990 & 0x1) == 0) goto label_4;
            if((1761061264 & 1) == 0)
            {
                goto label_4;
            }
            // 0x00AB4694: ADRP x24, #0x35dc000       | X24 = 56475648 (0x35DC000);             
            // 0x00AB4698: ADRP x25, #0x363e000       | X25 = 56877056 (0x363E000);             
            // 0x00AB469C: ADRP x26, #0x35c7000       | X26 = 56389632 (0x35C7000);             
            // 0x00AB46A0: ADRP x27, #0x3679000       | X27 = 57118720 (0x3679000);             
            // 0x00AB46A4: ADRP x28, #0x35e6000       | X28 = 56516608 (0x35E6000);             
            // 0x00AB46A8: LDR x24, [x24, #0x4d8]     | X24 = 1152921514957461552;              
            // 0x00AB46AC: LDR x25, [x25, #0x9c8]     | X25 = 1152921514957597104;              
            // 0x00AB46B0: LDR x26, [x26, #0xf00]     | X26 = 1152921510891359184;              
            // 0x00AB46B4: LDR x27, [x27, #0x3b8]     | X27 = 1152921514957462576;              
            // 0x00AB46B8: LDR x28, [x28, #0x500]     | X28 = 1152921510890816336;              
            label_11:
            // 0x00AB46BC: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_17 = null;
            // 0x00AB46C0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB46C4: TBZ w8, #0, #0xab46d8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB46C8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB46CC: CBNZ w8, #0xab46d8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB46D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB46D4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_17 = null;
            label_6:
            // 0x00AB46D8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB46DC: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB46E0: ADD x0, sp, #0x50          | X0 = (1152921514957842752 + 80) = 1152921514957842832 (0x1000000268F7A990);
            // 0x00AB46E4: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB46E8: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_5 = val_2.GetHandle();
            // 0x00AB46EC: LDR x8, [x25]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB46F0: STP x0, x1, [sp, #0x40]    | stack[1152921514957842816] = val_5.m_Handle;  stack[1152921514957842824] = val_5.m_Version;  //  dest_result_addr=1152921514957842816 |  dest_result_addr=1152921514957842824
            // 0x00AB46F4: ADD x0, sp, #0x40          | X0 = (1152921514957842752 + 64) = 1152921514957842816 (0x1000000268F7A980);
            // 0x00AB46F8: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB46FC: BL #0x1dc9dd4              | X0 = val_5.m_Handle.get_InitialType();  
            System.Type val_6 = val_5.m_Handle.InitialType;
            // 0x00AB4700: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00AB4704: CBNZ x20, #0xab470c        | if (Mihua.Asset.AssetMgr.nextNeedAssetList != null) goto label_7;
            if(Mihua.Asset.AssetMgr.nextNeedAssetList != null)
            {
                goto label_7;
            }
            // 0x00AB4708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_7:
            // 0x00AB470C: LDR x2, [x26]              | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
            // 0x00AB4710: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB4714: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x00AB4718: BL #0x25ead74              | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_6);
            bool val_7 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_6);
            // 0x00AB471C: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x00AB4720: TBNZ w8, #0, #0xab4794     | if ((val_7 & 1) == true) goto label_8;  
            if(val_8 == true)
            {
                goto label_8;
            }
            // 0x00AB4724: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB4728: ADD x0, sp, #0x50          | X0 = (1152921514957842752 + 80) = 1152921514957842832 (0x1000000268F7A990);
            // 0x00AB472C: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_9 = val_2.GetHandle();
            // 0x00AB4730: LDR x8, [x27]              | X8 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Value();
            // 0x00AB4734: STP x0, x1, [sp, #0x30]    | stack[1152921514957842800] = val_9.m_Handle;  stack[1152921514957842808] = val_9.m_Version;  //  dest_result_addr=1152921514957842800 |  dest_result_addr=1152921514957842808
            // 0x00AB4738: ADD x0, sp, #0x30          | X0 = (1152921514957842752 + 48) = 1152921514957842800 (0x1000000268F7A970);
            // 0x00AB473C: MOV x1, x8                 | X1 = 1152921514957462576 (0x1000000268F1DC30);//ML01
            // 0x00AB4740: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB4744: MOV x20, x0                | X20 = 1152921514957842800 (0x1000000268F7A970);//ML01
            // 0x00AB4748: CBNZ x20, #0xab4750        | if (val_9.m_Handle != 0) goto label_9;  
            if(val_9.m_Handle != 0)
            {
                goto label_9;
            }
            // 0x00AB474C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F7A970, ????);
            label_9:
            // 0x00AB4750: MOV x0, x20                | X0 = 1152921514957842800 (0x1000000268F7A970);//ML01
            // 0x00AB4754: BL #0xab39e8               | val_9.m_Handle.Clear();                 
            val_9.m_Handle.Clear();
            // 0x00AB4758: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB475C: ADD x0, sp, #0x50          | X0 = (1152921514957842752 + 80) = 1152921514957842832 (0x1000000268F7A990);
            // 0x00AB4760: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_10 = val_2.GetHandle();
            // 0x00AB4764: LDR x8, [x25]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB4768: STP x0, x1, [sp, #0x20]    | stack[1152921514957842784] = val_10.m_Handle;  stack[1152921514957842792] = val_10.m_Version;  //  dest_result_addr=1152921514957842784 |  dest_result_addr=1152921514957842792
            // 0x00AB476C: ADD x0, sp, #0x20          | X0 = (1152921514957842752 + 32) = 1152921514957842784 (0x1000000268F7A960);
            // 0x00AB4770: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB4774: BL #0x1dc9dd4              | X0 = val_10.m_Handle.get_InitialType(); 
            System.Type val_11 = val_10.m_Handle.InitialType;
            // 0x00AB4778: MOV x20, x0                | X20 = val_11;//m1                       
            // 0x00AB477C: CBNZ x19, #0xab4784        | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x00AB4780: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_10:
            // 0x00AB4784: LDR x2, [x28]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB4788: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB478C: MOV x1, x20                | X1 = val_11;//m1                        
            // 0x00AB4790: BL #0x25ea480              | Add(item:  val_11);                     
            Add(item:  val_11);
            label_8:
            // 0x00AB4794: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB4798: ADD x0, sp, #0x50          | X0 = (1152921514957842752 + 80) = 1152921514957842832 (0x1000000268F7A990);
            // 0x00AB479C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB47A0: AND w8, w0, #1             | W8 = (1152921514957842832 & 1) = 0 (0x00000000);
            // 0x00AB47A4: TBNZ w8, #0, #0xab46bc     | if ((0x0 & 0x1) != 0) goto label_11;    
            if((0 & 1) != 0)
            {
                goto label_11;
            }
            label_4:
            // 0x00AB47A8: ADRP x24, #0x35fc000       | X24 = 56606720 (0x35FC000);             
            // 0x00AB47AC: ADRP x25, #0x35bd000       | X25 = 56348672 (0x35BD000);             
            // 0x00AB47B0: ADRP x26, #0x35d4000       | X26 = 56442880 (0x35D4000);             
            // 0x00AB47B4: LDR x24, [x24, #0xb58]     | X24 = 1152921510022759280;              
            // 0x00AB47B8: LDR x25, [x25, #0xb50]     | X25 = 1152921510890998992;              
            // 0x00AB47BC: LDR x26, [x26, #0xbe8]     | X26 = 1152921514955719104;              
            // 0x00AB47C0: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x00AB47C4: B #0xab47dc                |  goto label_12;                         
            goto label_12;
            label_19:
            // 0x00AB47C8: LDR x2, [x26]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Remove(System.String key);
            // 0x00AB47CC: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x00AB47D0: MOV x1, x22                | X1 = 58195160 (0x377FCD8);//ML01        
            // 0x00AB47D4: BL #0x23fe354              | X0 = val_6.Remove(key:  1152921514957460528);
            bool val_12 = val_6.Remove(key:  1152921514957460528);
            // 0x00AB47D8: ADD w20, w20, #1           | W20 = (val_18 + 1) = val_18 (0x00000001);
            val_18 = 1;
            label_12:
            // 0x00AB47DC: CBNZ x19, #0xab47e4        | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x00AB47E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_13:
            // 0x00AB47E4: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB47E8: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB47EC: BL #0x25ed72c              | X0 = get_Count();                       
            int val_13 = Count;
            // 0x00AB47F0: CMP w20, w0                | STATE = COMPARE(0x1, val_13)            
            // 0x00AB47F4: B.GE #0xab4844             | if (val_18 >= val_13) goto label_14;    
            if(val_18 >= val_13)
            {
                goto label_14;
            }
            // 0x00AB47F8: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_19 = null;
            // 0x00AB47FC: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4800: TBZ w8, #0, #0xab4814      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00AB4804: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB4808: CBNZ w8, #0xab4814         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00AB480C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB4810: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_19 = null;
            label_16:
            // 0x00AB4814: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB4818: LDR x21, [x8, #0x40]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB481C: CBNZ x19, #0xab4824        | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x00AB4820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_17:
            // 0x00AB4824: LDR x2, [x25]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB4828: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB482C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB4830: BL #0x25ed734              | X0 = get_Item(index:  1);               
            string val_14 = Item[1];
            // 0x00AB4834: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00AB4838: CBNZ x21, #0xab47c8        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_19;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_19;
            }
            // 0x00AB483C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x00AB4840: B #0xab47c8                |  goto label_19;                         
            goto label_19;
            label_14:
            // 0x00AB4844: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00AB4848: LDR x8, [x8, #0x1c8]       | X8 = 1152921514957463600;               
            // 0x00AB484C: ADD x0, sp, #0x50          | X0 = (1152921514957842752 + 80) = 1152921514957842832 (0x1000000268F7A990);
            // 0x00AB4850: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::Dispose();
            // 0x00AB4854: BL #0xf3acac               | val_2.Dispose();                        
            val_2.Dispose();
            // 0x00AB4858: CBNZ x19, #0xab4860        | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x00AB485C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268F7A990, ????);
            label_20:
            // 0x00AB4860: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB4864: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB4868: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB486C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB4870: BL #0x25ead28              | Clear();                                
            Clear();
            // 0x00AB4874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB487C: BL #0x1c3f89c              | System.GC.Collect();                    
            System.GC.Collect();
            // 0x00AB4880: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB4884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB4888: BL #0x1b8b13c              | X0 = UnityEngine.Resources.UnloadUnusedAssets();
            UnityEngine.AsyncOperation val_15 = UnityEngine.Resources.UnloadUnusedAssets();
            // 0x00AB488C: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_20 = null;
            // 0x00AB4890: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB4894: TBZ w8, #0, #0xab48a8      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00AB4898: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB489C: CBNZ w8, #0xab48a8         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00AB48A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB48A4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_20 = null;
            label_22:
            // 0x00AB48A8: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB48AC: LDR x19, [x8, #0x68]       | X19 = Mihua.Asset.AssetMgr.clearEndCallBack;
            // 0x00AB48B0: CBNZ x19, #0xab48b8        | if (Mihua.Asset.AssetMgr.clearEndCallBack != null) goto label_23;
            if(Mihua.Asset.AssetMgr.clearEndCallBack != null)
            {
                goto label_23;
            }
            // 0x00AB48B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_23:
            // 0x00AB48B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB48BC: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.clearEndCallBack;//m1
            // 0x00AB48C0: BL #0x26e3100              | Mihua.Asset.AssetMgr.clearEndCallBack.Invoke();
            Mihua.Asset.AssetMgr.clearEndCallBack.Invoke();
            // 0x00AB48C4: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB48C8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB48CC: STR xzr, [x8, #0x68]       | Mihua.Asset.AssetMgr.clearEndCallBack = null;  //  dest_result_addr=1152921504903336040
            Mihua.Asset.AssetMgr.clearEndCallBack = 0;
            // 0x00AB48D0: SUB sp, x29, #0x50         | SP = (1152921514957842944 - 80) = 1152921514957842864 (0x1000000268F7A9B0);
            // 0x00AB48D4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB48D8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB48DC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB48E0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB48E4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB48E8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AB48EC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB66F8 (11233016), len: 1844  VirtAddr: 0x00AB66F8 RVA: 0x00AB66F8 token: 100693243 methodIndex: 46997 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Clear()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            string val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            // 0x00AB66F8: STP x28, x27, [sp, #-0x60]! | stack[1152921514958016304] = ???;  stack[1152921514958016312] = ???;  //  dest_result_addr=1152921514958016304 |  dest_result_addr=1152921514958016312
            // 0x00AB66FC: STP x26, x25, [sp, #0x10]  | stack[1152921514958016320] = ???;  stack[1152921514958016328] = ???;  //  dest_result_addr=1152921514958016320 |  dest_result_addr=1152921514958016328
            // 0x00AB6700: STP x24, x23, [sp, #0x20]  | stack[1152921514958016336] = ???;  stack[1152921514958016344] = ???;  //  dest_result_addr=1152921514958016336 |  dest_result_addr=1152921514958016344
            // 0x00AB6704: STP x22, x21, [sp, #0x30]  | stack[1152921514958016352] = ???;  stack[1152921514958016360] = ???;  //  dest_result_addr=1152921514958016352 |  dest_result_addr=1152921514958016360
            // 0x00AB6708: STP x20, x19, [sp, #0x40]  | stack[1152921514958016368] = ???;  stack[1152921514958016376] = ???;  //  dest_result_addr=1152921514958016368 |  dest_result_addr=1152921514958016376
            // 0x00AB670C: STP x29, x30, [sp, #0x50]  | stack[1152921514958016384] = ???;  stack[1152921514958016392] = ???;  //  dest_result_addr=1152921514958016384 |  dest_result_addr=1152921514958016392
            // 0x00AB6710: ADD x29, sp, #0x50         | X29 = (1152921514958016304 + 80) = 1152921514958016384 (0x1000000268FA4F80);
            // 0x00AB6714: SUB sp, sp, #0xc0          | SP = (1152921514958016304 - 192) = 1152921514958016112 (0x1000000268FA4E70);
            // 0x00AB6718: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AB671C: LDRB w8, [x19, #0x410]     | W8 = (bool)static_value_03733410;       
            // 0x00AB6720: TBNZ w8, #0, #0xab673c     | if (static_value_03733410 == true) goto label_0;
            // 0x00AB6724: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00AB6728: LDR x8, [x8, #0x490]       | X8 = 0x2B8EB08;                         
            // 0x00AB672C: LDR w0, [x8]               | W0 = 0x1182;                            
            // 0x00AB6730: BL #0x2782188              | X0 = sub_2782188( ?? 0x1182, ????);     
            // 0x00AB6734: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB6738: STRB w8, [x19, #0x410]     | static_value_03733410 = true;            //  dest_result_addr=57881616
            label_0:
            // 0x00AB673C: STP xzr, xzr, [x29, #-0x60] | stack[1152921514958016288] = 0x0;  stack[1152921514958016296] = 0x0;  //  dest_result_addr=1152921514958016288 |  dest_result_addr=1152921514958016296
            // 0x00AB6740: STP xzr, xzr, [x29, #-0x70] | stack[1152921514958016272] = 0x0;  stack[1152921514958016280] = 0x0;  //  dest_result_addr=1152921514958016272 |  dest_result_addr=1152921514958016280
            // 0x00AB6744: STP xzr, xzr, [x29, #-0x80] | stack[1152921514958016256] = 0x0;  stack[1152921514958016264] = 0x0;  //  dest_result_addr=1152921514958016256 |  dest_result_addr=1152921514958016264
            // 0x00AB6748: STP xzr, xzr, [sp, #0x80]  | stack[1152921514958016240] = 0x0;  stack[1152921514958016248] = 0x0;  //  dest_result_addr=1152921514958016240 |  dest_result_addr=1152921514958016248
            // 0x00AB674C: STP xzr, xzr, [sp, #0x70]  | stack[1152921514958016224] = 0x0;  stack[1152921514958016232] = 0x0;  //  dest_result_addr=1152921514958016224 |  dest_result_addr=1152921514958016232
            // 0x00AB6750: STP xzr, xzr, [sp, #0x60]  | stack[1152921514958016208] = 0x0;  stack[1152921514958016216] = 0x0;  //  dest_result_addr=1152921514958016208 |  dest_result_addr=1152921514958016216
            // 0x00AB6754: STP xzr, xzr, [sp, #0x50]  | stack[1152921514958016192] = 0x0;  stack[1152921514958016200] = 0x0;  //  dest_result_addr=1152921514958016192 |  dest_result_addr=1152921514958016200
            // 0x00AB6758: ADRP x23, #0x35c8000       | X23 = 56393728 (0x35C8000);             
            // 0x00AB675C: STR xzr, [sp, #0x48]       | stack[1152921514958016184] = 0x0;        //  dest_result_addr=1152921514958016184
            // 0x00AB6760: LDR x23, [x23, #0x270]     | X23 = 1152921504903331840;              
            // 0x00AB6764: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_30 = null;
            // 0x00AB6768: STP xzr, xzr, [sp, #0x38]  | stack[1152921514958016168] = 0x0;  stack[1152921514958016176] = 0x0;  //  dest_result_addr=1152921514958016168 |  dest_result_addr=1152921514958016176
            // 0x00AB676C: STR xzr, [sp, #0x30]       | stack[1152921514958016160] = 0x0;        //  dest_result_addr=1152921514958016160
            // 0x00AB6770: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6774: TBZ w8, #0, #0xab6788      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB6778: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB677C: CBNZ w8, #0xab6788         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB6780: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6784: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_30 = null;
            label_2:
            // 0x00AB6788: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB678C: LDR x19, [x8, #0x50]       | X19 = Mihua.Asset.AssetMgr.m_DownloadingErrors;
            // 0x00AB6790: CBNZ x19, #0xab6798        | if (Mihua.Asset.AssetMgr.m_DownloadingErrors != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_DownloadingErrors != null)
            {
                goto label_3;
            }
            // 0x00AB6794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB6798: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x00AB679C: LDR x8, [x8, #0x750]       | X8 = 1152921510817589616;               
            // 0x00AB67A0: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_DownloadingErrors;//m1
            // 0x00AB67A4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Clear();
            // 0x00AB67A8: BL #0x23fd92c              | Mihua.Asset.AssetMgr.m_DownloadingErrors.Clear();
            Mihua.Asset.AssetMgr.m_DownloadingErrors.Clear();
            // 0x00AB67AC: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB67B0: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB67B4: LDR x19, [x8, #0x58]       | X19 = Mihua.Asset.AssetMgr.m_InProgressOperations;
            // 0x00AB67B8: CBNZ x19, #0xab67c0        | if (Mihua.Asset.AssetMgr.m_InProgressOperations != null) goto label_4;
            if(Mihua.Asset.AssetMgr.m_InProgressOperations != null)
            {
                goto label_4;
            }
            // 0x00AB67BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_DownloadingErrors, ????);
            label_4:
            // 0x00AB67C0: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00AB67C4: LDR x8, [x8, #0x138]       | X8 = 1152921514957596080;               
            // 0x00AB67C8: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_InProgressOperations;//m1
            // 0x00AB67CC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Asset.ABLoadOperation.ABOperation>::Clear();
            // 0x00AB67D0: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_InProgressOperations.Clear();
            Mihua.Asset.AssetMgr.m_InProgressOperations.Clear();
            // 0x00AB67D4: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB67D8: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB67DC: LDR x19, [x8, #0x88]       | X19 = Mihua.Asset.AssetMgr.m_WaitList;  
            // 0x00AB67E0: CBNZ x19, #0xab67e8        | if (Mihua.Asset.AssetMgr.m_WaitList != null) goto label_5;
            if(Mihua.Asset.AssetMgr.m_WaitList != null)
            {
                goto label_5;
            }
            // 0x00AB67E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_InProgressOperations, ????);
            label_5:
            // 0x00AB67E8: ADRP x20, #0x3666000       | X20 = 57040896 (0x3666000);             
            // 0x00AB67EC: LDR x20, [x20, #0xca8]     | X20 = 1152921510890633680;              
            // 0x00AB67F0: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WaitList;//m1
            // 0x00AB67F4: LDR x1, [x20]              | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB67F8: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_WaitList.Clear();
            Mihua.Asset.AssetMgr.m_WaitList.Clear();
            // 0x00AB67FC: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6800: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6804: LDR x19, [x8, #0x48]       | X19 = Mihua.Asset.AssetMgr.m_RefCountDic;
            // 0x00AB6808: CBNZ x19, #0xab6810        | if (Mihua.Asset.AssetMgr.m_RefCountDic != null) goto label_6;
            if(Mihua.Asset.AssetMgr.m_RefCountDic != null)
            {
                goto label_6;
            }
            // 0x00AB680C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_WaitList, ????);
            label_6:
            // 0x00AB6810: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x00AB6814: LDR x8, [x8, #0xf98]       | X8 = 1152921510807332752;               
            // 0x00AB6818: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_RefCountDic;//m1
            // 0x00AB681C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Clear();
            // 0x00AB6820: BL #0x23f5768              | Mihua.Asset.AssetMgr.m_RefCountDic.Clear();
            Mihua.Asset.AssetMgr.m_RefCountDic.Clear();
            // 0x00AB6824: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6828: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB682C: LDR x19, [x8, #0x60]       | X19 = Mihua.Asset.AssetMgr.m_Dependencies;
            // 0x00AB6830: CBNZ x19, #0xab6838        | if (Mihua.Asset.AssetMgr.m_Dependencies != null) goto label_7;
            if(Mihua.Asset.AssetMgr.m_Dependencies != null)
            {
                goto label_7;
            }
            // 0x00AB6834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_RefCountDic, ????);
            label_7:
            // 0x00AB6838: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00AB683C: LDR x8, [x8, #0xb38]       | X8 = 1152921514170421936;               
            // 0x00AB6840: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_Dependencies;//m1
            // 0x00AB6844: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String[]>::Clear();
            // 0x00AB6848: BL #0x23fd92c              | Mihua.Asset.AssetMgr.m_Dependencies.Clear();
            Mihua.Asset.AssetMgr.m_Dependencies.Clear();
            // 0x00AB684C: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6850: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6854: LDR x19, [x8, #0x98]       | X19 = Mihua.Asset.AssetMgr.m_WWWList;   
            // 0x00AB6858: CBNZ x19, #0xab6860        | if (Mihua.Asset.AssetMgr.m_WWWList != null) goto label_8;
            if(Mihua.Asset.AssetMgr.m_WWWList != null)
            {
                goto label_8;
            }
            // 0x00AB685C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_Dependencies, ????);
            label_8:
            // 0x00AB6860: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB6864: LDR x8, [x8, #0x430]       | X8 = 1152921514957595056;               
            // 0x00AB6868: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_WWWList;//m1
            // 0x00AB686C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Networking.UnityWebRequest>::Clear();
            // 0x00AB6870: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_WWWList.Clear(); 
            Mihua.Asset.AssetMgr.m_WWWList.Clear();
            // 0x00AB6874: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6878: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB687C: LDR x19, [x8, #0x90]       | X19 = Mihua.Asset.AssetMgr.m_LoadingList;
            // 0x00AB6880: CBNZ x19, #0xab6888        | if (Mihua.Asset.AssetMgr.m_LoadingList != null) goto label_9;
            if(Mihua.Asset.AssetMgr.m_LoadingList != null)
            {
                goto label_9;
            }
            // 0x00AB6884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_WWWList, ????);
            label_9:
            // 0x00AB6888: LDR x1, [x20]              | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB688C: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadingList;//m1
            // 0x00AB6890: BL #0x25ead28              | Mihua.Asset.AssetMgr.m_LoadingList.Clear();
            Mihua.Asset.AssetMgr.m_LoadingList.Clear();
            // 0x00AB6894: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6898: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB689C: LDR x19, [x8, #0x40]       | X19 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB68A0: CBNZ x19, #0xab68a8        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_10;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_10;
            }
            // 0x00AB68A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Mihua.Asset.AssetMgr.m_LoadingList, ????);
            label_10:
            // 0x00AB68A8: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00AB68AC: LDR x8, [x8, #0x8f0]       | X8 = 1152921514957459504;               
            // 0x00AB68B0: MOV x0, x19                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;//m1
            // 0x00AB68B4: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::GetEnumerator();
            // 0x00AB68B8: ADD x8, sp, #0x10          | X8 = (1152921514958016112 + 16) = 1152921514958016128 (0x1000000268FA4E80);
            // 0x00AB68BC: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_1 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles.GetEnumerator();
            // 0x00AB68C0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x00AB68C4: LDP q1, q0, [sp, #0x10]    | Q1 = val_2; Q0 = val_3;                  //  find_add[1152921514958004400] |  find_add[1152921514958004400]
            // 0x00AB68C8: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x00AB68CC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_4 = null;
            // 0x00AB68D0: STP q1, q0, [x29, #-0x70]  | stack[1152921514958016272] = val_2;  stack[1152921514958016288] = val_3;  //  dest_result_addr=1152921514958016272 |  dest_result_addr=1152921514958016288
            // 0x00AB68D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00AB68D8: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00AB68DC: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x00AB68E0: MOV x19, x0                | X19 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB68E4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x00AB68E8: BL #0x25e9474              | .ctor();                                
            val_4 = new System.Collections.Generic.List<System.String>();
            // 0x00AB68EC: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
            // 0x00AB68F0: LDR x22, [x22, #0x2b0]     | X22 = 1152921514957460528;              
            // 0x00AB68F4: SUB x0, x29, #0x70         | X0 = (1152921514958016384 - 112) = 1152921514958016272 (0x1000000268FA4F10);
            // 0x00AB68F8: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB68FC: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6900: TBZ w0, #0, #0xab6a18      | if ((0x1000000268FA4F10 & 0x1) == 0) goto label_11;
            if((1761234704 & 1) == 0)
            {
                goto label_11;
            }
            // 0x00AB6904: ADRP x25, #0x35dc000       | X25 = 56475648 (0x35DC000);             
            // 0x00AB6908: ADRP x26, #0x363e000       | X26 = 56877056 (0x363E000);             
            // 0x00AB690C: ADRP x27, #0x35c7000       | X27 = 56389632 (0x35C7000);             
            // 0x00AB6910: ADRP x24, #0x3679000       | X24 = 57118720 (0x3679000);             
            // 0x00AB6914: ADRP x28, #0x35e6000       | X28 = 56516608 (0x35E6000);             
            // 0x00AB6918: LDR x25, [x25, #0x4d8]     | X25 = 1152921514957461552;              
            // 0x00AB691C: LDR x26, [x26, #0x9c8]     | X26 = 1152921514957597104;              
            // 0x00AB6920: LDR x27, [x27, #0xf00]     | X27 = 1152921510891359184;              
            val_31 = 1152921510891359184;
            // 0x00AB6924: LDR x24, [x24, #0x3b8]     | X24 = 1152921514957462576;              
            // 0x00AB6928: LDR x28, [x28, #0x500]     | X28 = 1152921510890816336;              
            label_18:
            // 0x00AB692C: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_32 = null;
            // 0x00AB6930: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6934: TBZ w8, #0, #0xab6948      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00AB6938: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB693C: CBNZ w8, #0xab6948         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00AB6940: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6944: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_32 = null;
            label_13:
            // 0x00AB6948: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB694C: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB6950: SUB x0, x29, #0x70         | X0 = (1152921514958016384 - 112) = 1152921514958016272 (0x1000000268FA4F10);
            // 0x00AB6954: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB6958: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_5 = val_2.GetHandle();
            // 0x00AB695C: LDR x8, [x26]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB6960: STP x0, x1, [x29, #-0x80]  | stack[1152921514958016256] = val_5.m_Handle;  stack[1152921514958016264] = val_5.m_Version;  //  dest_result_addr=1152921514958016256 |  dest_result_addr=1152921514958016264
            // 0x00AB6964: SUB x0, x29, #0x80         | X0 = (1152921514958016384 - 128) = 1152921514958016256 (0x1000000268FA4F00);
            // 0x00AB6968: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB696C: BL #0x1dc9dd4              | X0 = val_5.m_Handle.get_InitialType();  
            System.Type val_6 = val_5.m_Handle.InitialType;
            // 0x00AB6970: MOV x21, x0                | X21 = val_6;//m1                        
            val_33 = val_6;
            // 0x00AB6974: CBNZ x20, #0xab697c        | if (Mihua.Asset.AssetMgr.nextNeedAssetList != null) goto label_14;
            if(Mihua.Asset.AssetMgr.nextNeedAssetList != null)
            {
                goto label_14;
            }
            // 0x00AB6978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_14:
            // 0x00AB697C: LDR x2, [x27]              | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
            // 0x00AB6980: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB6984: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x00AB6988: BL #0x25ead74              | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_33);
            bool val_7 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_33);
            // 0x00AB698C: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x00AB6990: TBNZ w8, #0, #0xab6a04     | if ((val_7 & 1) == true) goto label_15; 
            if(val_8 == true)
            {
                goto label_15;
            }
            // 0x00AB6994: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB6998: SUB x0, x29, #0x70         | X0 = (1152921514958016384 - 112) = 1152921514958016272 (0x1000000268FA4F10);
            // 0x00AB699C: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_9 = val_2.GetHandle();
            // 0x00AB69A0: LDR x8, [x24]              | X8 = public Mihua.Asset.LoadedAssetBundle System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Value();
            // 0x00AB69A4: STP x0, x1, [sp, #0x80]    | stack[1152921514958016240] = val_9.m_Handle;  stack[1152921514958016248] = val_9.m_Version;  //  dest_result_addr=1152921514958016240 |  dest_result_addr=1152921514958016248
            // 0x00AB69A8: ADD x0, sp, #0x80          | X0 = (1152921514958016112 + 128) = 1152921514958016240 (0x1000000268FA4EF0);
            // 0x00AB69AC: MOV x1, x8                 | X1 = 1152921514957462576 (0x1000000268F1DC30);//ML01
            // 0x00AB69B0: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x00AB69B4: MOV x20, x0                | X20 = 1152921514958016240 (0x1000000268FA4EF0);//ML01
            // 0x00AB69B8: CBNZ x20, #0xab69c0        | if (val_9.m_Handle != 0) goto label_16; 
            if(val_9.m_Handle != 0)
            {
                goto label_16;
            }
            // 0x00AB69BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268FA4EF0, ????);
            label_16:
            // 0x00AB69C0: MOV x0, x20                | X0 = 1152921514958016240 (0x1000000268FA4EF0);//ML01
            // 0x00AB69C4: BL #0xab39e8               | val_9.m_Handle.Clear();                 
            val_9.m_Handle.Clear();
            // 0x00AB69C8: LDR x1, [x25]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::get_Current();
            // 0x00AB69CC: SUB x0, x29, #0x70         | X0 = (1152921514958016384 - 112) = 1152921514958016272 (0x1000000268FA4F10);
            // 0x00AB69D0: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_10 = val_2.GetHandle();
            // 0x00AB69D4: LDR x8, [x26]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, Mihua.Asset.LoadedAssetBundle>::get_Key();
            // 0x00AB69D8: STP x0, x1, [sp, #0x70]    | stack[1152921514958016224] = val_10.m_Handle;  stack[1152921514958016232] = val_10.m_Version;  //  dest_result_addr=1152921514958016224 |  dest_result_addr=1152921514958016232
            // 0x00AB69DC: ADD x0, sp, #0x70          | X0 = (1152921514958016112 + 112) = 1152921514958016224 (0x1000000268FA4EE0);
            // 0x00AB69E0: MOV x1, x8                 | X1 = 1152921514957597104 (0x1000000268F3E9B0);//ML01
            // 0x00AB69E4: BL #0x1dc9dd4              | X0 = val_10.m_Handle.get_InitialType(); 
            System.Type val_11 = val_10.m_Handle.InitialType;
            // 0x00AB69E8: MOV x20, x0                | X20 = val_11;//m1                       
            // 0x00AB69EC: CBNZ x19, #0xab69f4        | if ( != 0) goto label_17;               
            if(null != 0)
            {
                goto label_17;
            }
            // 0x00AB69F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_17:
            // 0x00AB69F4: LDR x2, [x28]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB69F8: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB69FC: MOV x1, x20                | X1 = val_11;//m1                        
            // 0x00AB6A00: BL #0x25ea480              | Add(item:  val_11);                     
            Add(item:  val_11);
            label_15:
            // 0x00AB6A04: LDR x1, [x22]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::MoveNext();
            // 0x00AB6A08: SUB x0, x29, #0x70         | X0 = (1152921514958016384 - 112) = 1152921514958016272 (0x1000000268FA4F10);
            // 0x00AB6A0C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6A10: AND w8, w0, #1             | W8 = (1152921514958016272 & 1) = 0 (0x00000000);
            // 0x00AB6A14: TBNZ w8, #0, #0xab692c     | if ((0x0 & 0x1) != 0) goto label_18;    
            if((0 & 1) != 0)
            {
                goto label_18;
            }
            label_11:
            // 0x00AB6A18: ADRP x25, #0x35fc000       | X25 = 56606720 (0x35FC000);             
            // 0x00AB6A1C: ADRP x26, #0x35bd000       | X26 = 56348672 (0x35BD000);             
            // 0x00AB6A20: ADRP x24, #0x35d4000       | X24 = 56442880 (0x35D4000);             
            // 0x00AB6A24: LDR x25, [x25, #0xb58]     | X25 = 1152921510022759280;              
            // 0x00AB6A28: LDR x26, [x26, #0xb50]     | X26 = 1152921510890998992;              
            // 0x00AB6A2C: LDR x24, [x24, #0xbe8]     | X24 = 1152921514955719104;              
            // 0x00AB6A30: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_34 = 0;
            // 0x00AB6A34: B #0xab6a4c                |  goto label_19;                         
            goto label_19;
            label_26:
            // 0x00AB6A38: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, Mihua.Asset.LoadedAssetBundle>::Remove(System.String key);
            // 0x00AB6A3C: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x00AB6A40: MOV x1, x22                | X1 = 58195160 (0x377FCD8);//ML01        
            // 0x00AB6A44: BL #0x23fe354              | X0 = val_6.Remove(key:  1152921514957460528);
            bool val_12 = val_33.Remove(key:  1152921514957460528);
            // 0x00AB6A48: ADD w20, w20, #1           | W20 = (val_34 + 1) = val_34 (0x00000001);
            val_34 = 1;
            label_19:
            // 0x00AB6A4C: CBNZ x19, #0xab6a54        | if ( != 0) goto label_20;               
            if(null != 0)
            {
                goto label_20;
            }
            // 0x00AB6A50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_20:
            // 0x00AB6A54: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB6A58: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6A5C: BL #0x25ed72c              | X0 = get_Count();                       
            int val_13 = Count;
            // 0x00AB6A60: CMP w20, w0                | STATE = COMPARE(0x1, val_13)            
            // 0x00AB6A64: B.GE #0xab6ab4             | if (val_34 >= val_13) goto label_21;    
            if(val_34 >= val_13)
            {
                goto label_21;
            }
            // 0x00AB6A68: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_35 = null;
            // 0x00AB6A6C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6A70: TBZ w8, #0, #0xab6a84      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00AB6A74: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6A78: CBNZ w8, #0xab6a84         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00AB6A7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6A80: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_35 = null;
            label_23:
            // 0x00AB6A84: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6A88: LDR x21, [x8, #0x40]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssetBundles;
            // 0x00AB6A8C: CBNZ x19, #0xab6a94        | if ( != 0) goto label_24;               
            if(null != 0)
            {
                goto label_24;
            }
            // 0x00AB6A90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_24:
            // 0x00AB6A94: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB6A98: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6A9C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB6AA0: BL #0x25ed734              | X0 = get_Item(index:  1);               
            string val_14 = Item[1];
            // 0x00AB6AA4: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00AB6AA8: CBNZ x21, #0xab6a38        | if (Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null) goto label_26;
            if(Mihua.Asset.AssetMgr.m_LoadedAssetBundles != null)
            {
                goto label_26;
            }
            // 0x00AB6AAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x00AB6AB0: B #0xab6a38                |  goto label_26;                         
            goto label_26;
            label_21:
            // 0x00AB6AB4: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00AB6AB8: LDR x8, [x8, #0x1c8]       | X8 = 1152921514957463600;               
            // 0x00AB6ABC: SUB x0, x29, #0x70         | X0 = (1152921514958016384 - 112) = 1152921514958016272 (0x1000000268FA4F10);
            // 0x00AB6AC0: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, Mihua.Asset.LoadedAssetBundle>::Dispose();
            // 0x00AB6AC4: BL #0xf3acac               | val_2.Dispose();                        
            val_2.Dispose();
            // 0x00AB6AC8: CBNZ x19, #0xab6ad0        | if ( != 0) goto label_27;               
            if(null != 0)
            {
                goto label_27;
            }
            // 0x00AB6ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268FA4F10, ????);
            label_27:
            // 0x00AB6AD0: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB6AD4: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB6AD8: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6ADC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB6AE0: BL #0x25ead28              | Clear();                                
            Clear();
            // 0x00AB6AE4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_36 = null;
            // 0x00AB6AE8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6AEC: TBZ w8, #0, #0xab6b00      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x00AB6AF0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6AF4: CBNZ w8, #0xab6b00         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x00AB6AF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6AFC: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_36 = null;
            label_29:
            // 0x00AB6B00: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6B04: LDR x20, [x8, #0x38]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB6B08: CBNZ x20, #0xab6b10        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_30;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_30;
            }
            // 0x00AB6B0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_30:
            // 0x00AB6B10: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00AB6B14: LDR x8, [x8, #0xc88]       | X8 = 1152921514957614512;               
            // 0x00AB6B18: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00AB6B1C: LDR x1, [x8]               | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::GetEnumerator();
            // 0x00AB6B20: ADD x8, sp, #0x10          | X8 = (1152921514958016112 + 16) = 1152921514958016128 (0x1000000268FA4E80);
            // 0x00AB6B24: BL #0x23ff0fc              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_15 = Mihua.Asset.AssetMgr.m_LoadedAssets.GetEnumerator();
            // 0x00AB6B28: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB6B2C: LDP q1, q0, [sp, #0x10]    | Q1 = val_2; Q0 = val_3;                  //  find_add[1152921514958004400] |  find_add[1152921514958004400]
            // 0x00AB6B30: LDR x8, [x8, #0x460]       | X8 = 1152921514957615536;               
            // 0x00AB6B34: ADD x0, sp, #0x50          | X0 = (1152921514958016112 + 80) = 1152921514958016192 (0x1000000268FA4EC0);
            // 0x00AB6B38: LDR x1, [x8]               | X1 = public System.Boolean Dictionary.Enumerator<System.String, UnityEngine.Object>::MoveNext();
            // 0x00AB6B3C: STP q1, q0, [sp, #0x50]    | stack[1152921514958016192] = val_2;  stack[1152921514958016208] = val_3;  //  dest_result_addr=1152921514958016192 |  dest_result_addr=1152921514958016208
            // 0x00AB6B40: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6B44: TBZ w0, #0, #0xab6c64      | if ((0x1000000268FA4EC0 & 0x1) == 0) goto label_31;
            if((1761234624 & 1) == 0)
            {
                goto label_31;
            }
            // 0x00AB6B48: ADRP x24, #0x3644000       | X24 = 56901632 (0x3644000);             
            // 0x00AB6B4C: ADRP x28, #0x362f000       | X28 = 56815616 (0x362F000);             
            // 0x00AB6B50: ADRP x27, #0x35c7000       | X27 = 56389632 (0x35C7000);             
            // 0x00AB6B54: LDR x24, [x24, #0x7c8]     | X24 = 1152921514957616560;              
            // 0x00AB6B58: LDR x28, [x28, #0x1b0]     | X28 = 1152921514957617584;              
            // 0x00AB6B5C: LDR x27, [x27, #0xf00]     | X27 = 1152921510891359184;              
            val_31 = 1152921510891359184;
            label_38:
            // 0x00AB6B60: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_37 = null;
            // 0x00AB6B64: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6B68: TBZ w8, #0, #0xab6b7c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x00AB6B6C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6B70: CBNZ w8, #0xab6b7c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x00AB6B74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6B78: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_37 = null;
            label_33:
            // 0x00AB6B7C: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6B80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB6B84: LDR x20, [x8, #0x30]       | X20 = Mihua.Asset.AssetMgr.nextNeedAssetList;
            // 0x00AB6B88: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00AB6B8C: LDR x8, [x8, #0x728]       | X8 = 1152921514868048752;               
            // 0x00AB6B90: LDR x1, [x8]               | X1 = public static ConfigAssetMgr Singleton<ConfigAssetMgr>::get_Instance();
            // 0x00AB6B94: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
            ILAssetMgr val_16 = Singleton<ILAssetMgr>.Instance;
            // 0x00AB6B98: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, UnityEngine.Object>::get_Current();
            // 0x00AB6B9C: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x00AB6BA0: ADD x0, sp, #0x50          | X0 = (1152921514958016112 + 80) = 1152921514958016192 (0x1000000268FA4EC0);
            // 0x00AB6BA4: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_17 = val_2.GetHandle();
            // 0x00AB6BA8: LDR x8, [x28]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, UnityEngine.Object>::get_Key();
            // 0x00AB6BAC: STP x0, x1, [sp, #0x40]    | stack[1152921514958016176] = val_17.m_Handle;  stack[1152921514958016184] = val_17.m_Version;  //  dest_result_addr=1152921514958016176 |  dest_result_addr=1152921514958016184
            // 0x00AB6BB0: ADD x0, sp, #0x40          | X0 = (1152921514958016112 + 64) = 1152921514958016176 (0x1000000268FA4EB0);
            // 0x00AB6BB4: MOV x1, x8                 | X1 = 1152921514957617584 (0x1000000268F439B0);//ML01
            // 0x00AB6BB8: BL #0x1dc9dd4              | X0 = val_17.m_Handle.get_InitialType(); 
            System.Type val_18 = val_17.m_Handle.InitialType;
            // 0x00AB6BBC: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x00AB6BC0: CBNZ x21, #0xab6bc8        | if (val_16 != null) goto label_34;      
            if(val_16 != null)
            {
                goto label_34;
            }
            // 0x00AB6BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_34:
            // 0x00AB6BC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AB6BCC: MOV x0, x21                | X0 = val_16;//m1                        
            // 0x00AB6BD0: MOV x1, x22                | X1 = val_18;//m1                        
            // 0x00AB6BD4: BL #0xb42c9c               | X0 = val_16.AssetNameToABPath(assetName:  val_18);
            string val_19 = val_16.AssetNameToABPath(assetName:  val_18);
            // 0x00AB6BD8: MOV x21, x0                | X21 = val_19;//m1                       
            val_33 = val_19;
            // 0x00AB6BDC: CBNZ x20, #0xab6be4        | if (Mihua.Asset.AssetMgr.nextNeedAssetList != null) goto label_35;
            if(Mihua.Asset.AssetMgr.nextNeedAssetList != null)
            {
                goto label_35;
            }
            // 0x00AB6BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_35:
            // 0x00AB6BE4: LDR x2, [x27]              | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
            // 0x00AB6BE8: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList;//m1
            // 0x00AB6BEC: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x00AB6BF0: BL #0x25ead74              | X0 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_33);
            bool val_20 = Mihua.Asset.AssetMgr.nextNeedAssetList.Contains(item:  val_33);
            // 0x00AB6BF4: AND w8, w0, #1             | W8 = (val_20 & 1);                      
            bool val_21 = val_20;
            // 0x00AB6BF8: TBNZ w8, #0, #0xab6c40     | if ((val_20 & 1) == true) goto label_36;
            if(val_21 == true)
            {
                goto label_36;
            }
            // 0x00AB6BFC: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, UnityEngine.Object>::get_Current();
            // 0x00AB6C00: ADD x0, sp, #0x50          | X0 = (1152921514958016112 + 80) = 1152921514958016192 (0x1000000268FA4EC0);
            // 0x00AB6C04: BL #0xf3ac3c               | X0 = val_2.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_22 = val_2.GetHandle();
            // 0x00AB6C08: LDR x8, [x28]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, UnityEngine.Object>::get_Key();
            // 0x00AB6C0C: STP x0, x1, [sp, #0x30]    | stack[1152921514958016160] = val_22.m_Handle;  stack[1152921514958016168] = val_22.m_Version;  //  dest_result_addr=1152921514958016160 |  dest_result_addr=1152921514958016168
            // 0x00AB6C10: ADD x0, sp, #0x30          | X0 = (1152921514958016112 + 48) = 1152921514958016160 (0x1000000268FA4EA0);
            // 0x00AB6C14: MOV x1, x8                 | X1 = 1152921514957617584 (0x1000000268F439B0);//ML01
            // 0x00AB6C18: BL #0x1dc9dd4              | X0 = val_22.m_Handle.get_InitialType(); 
            System.Type val_23 = val_22.m_Handle.InitialType;
            // 0x00AB6C1C: MOV x20, x0                | X20 = val_23;//m1                       
            // 0x00AB6C20: CBNZ x19, #0xab6c28        | if ( != 0) goto label_37;               
            if(null != 0)
            {
                goto label_37;
            }
            // 0x00AB6C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_37:
            // 0x00AB6C28: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00AB6C2C: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
            // 0x00AB6C30: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6C34: MOV x1, x20                | X1 = val_23;//m1                        
            // 0x00AB6C38: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x00AB6C3C: BL #0x25ea480              | Add(item:  val_23);                     
            Add(item:  val_23);
            label_36:
            // 0x00AB6C40: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x00AB6C44: LDR x8, [x8, #0x460]       | X8 = 1152921514957615536;               
            // 0x00AB6C48: ADD x0, sp, #0x50          | X0 = (1152921514958016112 + 80) = 1152921514958016192 (0x1000000268FA4EC0);
            // 0x00AB6C4C: LDR x1, [x8]               | X1 = public System.Boolean Dictionary.Enumerator<System.String, UnityEngine.Object>::MoveNext();
            // 0x00AB6C50: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x00AB6C54: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_38 = 0;
            // 0x00AB6C58: AND w8, w0, #1             | W8 = (1152921514958016192 & 1) = 0 (0x00000000);
            // 0x00AB6C5C: TBNZ w8, #0, #0xab6b60     | if ((0x0 & 0x1) != 0) goto label_38;    
            if((0 & 1) != 0)
            {
                goto label_38;
            }
            // 0x00AB6C60: B #0xab6c88                |  goto label_40;                         
            goto label_40;
            label_31:
            // 0x00AB6C64: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_38 = 0;
            // 0x00AB6C68: B #0xab6c88                |  goto label_40;                         
            goto label_40;
            label_47:
            // 0x00AB6C6C: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00AB6C70: LDR x8, [x8, #0x58]        | X8 = 1152921514957634992;               
            // 0x00AB6C74: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x00AB6C78: MOV x1, x22                | X1 = 58195160 (0x377FCD8);//ML01        
            // 0x00AB6C7C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::Remove(System.String key);
            // 0x00AB6C80: BL #0x23fe354              | X0 = val_6.Remove(key:  1152921514957460528);
            bool val_24 = val_33.Remove(key:  1152921514957460528);
            // 0x00AB6C84: ADD w20, w20, #1           | W20 = (val_38 + 1) = val_38 (0x00000001);
            val_38 = 1;
            label_40:
            // 0x00AB6C88: CBNZ x19, #0xab6c90        | if ( != 0) goto label_41;               
            if(null != 0)
            {
                goto label_41;
            }
            // 0x00AB6C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_41:
            // 0x00AB6C90: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x00AB6C94: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6C98: BL #0x25ed72c              | X0 = get_Count();                       
            int val_25 = Count;
            // 0x00AB6C9C: CMP w20, w0                | STATE = COMPARE(0x1, val_25)            
            // 0x00AB6CA0: B.GE #0xab6cf0             | if (val_38 >= val_25) goto label_42;    
            if(val_38 >= val_25)
            {
                goto label_42;
            }
            // 0x00AB6CA4: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_39 = null;
            // 0x00AB6CA8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6CAC: TBZ w8, #0, #0xab6cc0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_44;
            // 0x00AB6CB0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6CB4: CBNZ w8, #0xab6cc0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
            // 0x00AB6CB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6CBC: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_39 = null;
            label_44:
            // 0x00AB6CC0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6CC4: LDR x21, [x8, #0x38]       | X21 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB6CC8: CBNZ x19, #0xab6cd0        | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x00AB6CCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_45:
            // 0x00AB6CD0: LDR x2, [x26]              | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x00AB6CD4: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6CD8: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x00AB6CDC: BL #0x25ed734              | X0 = get_Item(index:  1);               
            string val_26 = Item[1];
            // 0x00AB6CE0: MOV x22, x0                | X22 = val_26;//m1                       
            // 0x00AB6CE4: CBNZ x21, #0xab6c6c        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_47;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_47;
            }
            // 0x00AB6CE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            // 0x00AB6CEC: B #0xab6c6c                |  goto label_47;                         
            goto label_47;
            label_42:
            // 0x00AB6CF0: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x00AB6CF4: LDR x8, [x8, #0x908]       | X8 = 1152921514957640112;               
            // 0x00AB6CF8: ADD x0, sp, #0x50          | X0 = (1152921514958016112 + 80) = 1152921514958016192 (0x1000000268FA4EC0);
            // 0x00AB6CFC: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, UnityEngine.Object>::Dispose();
            // 0x00AB6D00: BL #0xf3acac               | val_2.Dispose();                        
            val_2.Dispose();
            // 0x00AB6D04: CBNZ x19, #0xab6d0c        | if ( != 0) goto label_48;               
            if(null != 0)
            {
                goto label_48;
            }
            // 0x00AB6D08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000268FA4EC0, ????);
            label_48:
            // 0x00AB6D0C: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00AB6D10: LDR x8, [x8, #0xca8]       | X8 = 1152921510890633680;               
            // 0x00AB6D14: MOV x0, x19                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00AB6D18: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::Clear();
            // 0x00AB6D1C: BL #0x25ead28              | Clear();                                
            Clear();
            // 0x00AB6D20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB6D24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6D28: BL #0x1c3f89c              | System.GC.Collect();                    
            System.GC.Collect();
            // 0x00AB6D2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB6D30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6D34: BL #0x1b8b13c              | X0 = UnityEngine.Resources.UnloadUnusedAssets();
            UnityEngine.AsyncOperation val_27 = UnityEngine.Resources.UnloadUnusedAssets();
            // 0x00AB6D38: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00AB6D3C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
            // 0x00AB6D40: LDR x0, [x8]               | X0 = typeof(ZMG);                       
            // 0x00AB6D44: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
            // 0x00AB6D48: TBZ w8, #0, #0xab6d58      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_50;
            // 0x00AB6D4C: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6D50: CBNZ w8, #0xab6d58         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
            // 0x00AB6D54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
            label_50:
            // 0x00AB6D58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB6D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6D60: BL #0x26a8450              | X0 = ZMG.get_FloatTextMgr();            
            FloatTextMgr val_28 = ZMG.FloatTextMgr;
            // 0x00AB6D64: MOV x19, x0                | X19 = val_28;//m1                       
            // 0x00AB6D68: CBNZ x19, #0xab6d70        | if (val_28 != null) goto label_51;      
            if(val_28 != null)
            {
                goto label_51;
            }
            // 0x00AB6D6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_51:
            // 0x00AB6D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6D74: MOV x0, x19                | X0 = val_28;//m1                        
            // 0x00AB6D78: BL #0xc05c1c               | val_28.Clear();                         
            val_28.Clear();
            // 0x00AB6D7C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00AB6D80: LDR x8, [x8, #0xf80]       | X8 = 1152921504912171008;               
            // 0x00AB6D84: LDR x0, [x8]               | X0 = typeof(UIModelDisplayMgr);         
            // 0x00AB6D88: LDRB w8, [x0, #0x10a]      | W8 = UIModelDisplayMgr.__il2cppRuntimeField_10A;
            // 0x00AB6D8C: TBZ w8, #0, #0xab6d9c      | if (UIModelDisplayMgr.__il2cppRuntimeField_has_cctor == 0) goto label_53;
            // 0x00AB6D90: LDR w8, [x0, #0xbc]        | W8 = UIModelDisplayMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6D94: CBNZ w8, #0xab6d9c         | if (UIModelDisplayMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
            // 0x00AB6D98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UIModelDisplayMgr), ????);
            label_53:
            // 0x00AB6D9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB6DA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6DA4: BL #0xfa1f58               | X0 = UIModelDisplayMgr.get_Instance();  
            UIModelDisplayMgr val_29 = UIModelDisplayMgr.Instance;
            // 0x00AB6DA8: MOV x19, x0                | X19 = val_29;//m1                       
            // 0x00AB6DAC: CBNZ x19, #0xab6db4        | if (val_29 != null) goto label_54;      
            if(val_29 != null)
            {
                goto label_54;
            }
            // 0x00AB6DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_54:
            // 0x00AB6DB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB6DB8: MOV x0, x19                | X0 = val_29;//m1                        
            // 0x00AB6DBC: BL #0xfb7b18               | val_29.ClearModel();                    
            val_29.ClearModel();
            // 0x00AB6DC0: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_40 = null;
            // 0x00AB6DC4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6DC8: TBZ w8, #0, #0xab6ddc      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_56;
            // 0x00AB6DCC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6DD0: CBNZ w8, #0xab6ddc         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_56;
            // 0x00AB6DD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6DD8: LDR x0, [x23]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_40 = null;
            label_56:
            // 0x00AB6DDC: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6DE0: LDRB w9, [x8, #0xa0]       | W9 = Mihua.Asset.AssetMgr.isClearAll;   
            // 0x00AB6DE4: CBZ w9, #0xab6e0c          | if (Mihua.Asset.AssetMgr.isClearAll == false) goto label_57;
            if(Mihua.Asset.AssetMgr.isClearAll == false)
            {
                goto label_57;
            }
            // 0x00AB6DE8: LDRB w9, [x0, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6DEC: TBZ w9, #0, #0xab6e04      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_59;
            // 0x00AB6DF0: LDR w9, [x0, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6DF4: CBNZ w9, #0xab6e04         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_59;
            // 0x00AB6DF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6DFC: LDR x8, [x23]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB6E00: LDR x8, [x8, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            label_59:
            // 0x00AB6E04: STRB wzr, [x8, #0xa0]      | Mihua.Asset.AssetMgr.isClearAll = false;  //  dest_result_addr=1152921504903336096
            Mihua.Asset.AssetMgr.isClearAll = false;
            // 0x00AB6E08: BL #0xab5c70               | Mihua.Asset.AssetMgr.ClearAll();        
            Mihua.Asset.AssetMgr.ClearAll();
            label_57:
            // 0x00AB6E0C: SUB sp, x29, #0x50         | SP = (1152921514958016384 - 80) = 1152921514958016304 (0x1000000268FA4F30);
            // 0x00AB6E10: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB6E14: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB6E18: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AB6E1C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AB6E20: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AB6E24: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AB6E28: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB6E2C (11234860), len: 232  VirtAddr: 0x00AB6E2C RVA: 0x00AB6E2C token: 100693244 methodIndex: 46998 delegateWrapperIndex: 0 methodInvoker: 0
        public static void UnloadAsset(string name)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            // 0x00AB6E2C: STP x22, x21, [sp, #-0x30]! | stack[1152921514958177504] = ???;  stack[1152921514958177512] = ???;  //  dest_result_addr=1152921514958177504 |  dest_result_addr=1152921514958177512
            // 0x00AB6E30: STP x20, x19, [sp, #0x10]  | stack[1152921514958177520] = ???;  stack[1152921514958177528] = ???;  //  dest_result_addr=1152921514958177520 |  dest_result_addr=1152921514958177528
            // 0x00AB6E34: STP x29, x30, [sp, #0x20]  | stack[1152921514958177536] = ???;  stack[1152921514958177544] = ???;  //  dest_result_addr=1152921514958177536 |  dest_result_addr=1152921514958177544
            // 0x00AB6E38: ADD x29, sp, #0x20         | X29 = (1152921514958177504 + 32) = 1152921514958177536 (0x1000000268FCC500);
            // 0x00AB6E3C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB6E40: LDRB w8, [x20, #0x411]     | W8 = (bool)static_value_03733411;       
            // 0x00AB6E44: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00AB6E48: TBNZ w8, #0, #0xab6e64     | if (static_value_03733411 == true) goto label_0;
            // 0x00AB6E4C: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00AB6E50: LDR x8, [x8, #0xb40]       | X8 = 0x2B8EB8C;                         
            // 0x00AB6E54: LDR w0, [x8]               | W0 = 0x11A3;                            
            // 0x00AB6E58: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A3, ????);     
            // 0x00AB6E5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB6E60: STRB w8, [x20, #0x411]     | static_value_03733411 = true;            //  dest_result_addr=57881617
            label_0:
            // 0x00AB6E64: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x00AB6E68: LDR x21, [x21, #0x270]     | X21 = 1152921504903331840;              
            // 0x00AB6E6C: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_3 = null;
            // 0x00AB6E70: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6E74: TBZ w8, #0, #0xab6e88      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB6E78: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6E7C: CBNZ w8, #0xab6e88         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB6E80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6E84: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_3 = null;
            label_2:
            // 0x00AB6E88: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6E8C: LDR x20, [x8, #0x38]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB6E90: CBNZ x20, #0xab6e98        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_3;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_3;
            }
            // 0x00AB6E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AB6E98: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00AB6E9C: LDR x8, [x8, #0xad8]       | X8 = 1152921514948372656;               
            // 0x00AB6EA0: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00AB6EA4: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB6EA8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::ContainsKey(System.String key);
            // 0x00AB6EAC: BL #0x23fd9f0              | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets.ContainsKey(key:  X1);
            bool val_1 = Mihua.Asset.AssetMgr.m_LoadedAssets.ContainsKey(key:  X1);
            // 0x00AB6EB0: TBZ w0, #0, #0xab6f04      | if (val_1 == false) goto label_4;       
            if(val_1 == false)
            {
                goto label_4;
            }
            // 0x00AB6EB4: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_4 = null;
            // 0x00AB6EB8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB6EBC: TBZ w8, #0, #0xab6ed0      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB6EC0: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB6EC4: CBNZ w8, #0xab6ed0         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB6EC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            // 0x00AB6ECC: LDR x0, [x21]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            val_4 = null;
            label_6:
            // 0x00AB6ED0: LDR x8, [x0, #0xa0]        | X8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_static_fields;
            // 0x00AB6ED4: LDR x20, [x8, #0x38]       | X20 = Mihua.Asset.AssetMgr.m_LoadedAssets;
            // 0x00AB6ED8: CBNZ x20, #0xab6ee0        | if (Mihua.Asset.AssetMgr.m_LoadedAssets != null) goto label_7;
            if(Mihua.Asset.AssetMgr.m_LoadedAssets != null)
            {
                goto label_7;
            }
            // 0x00AB6EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_7:
            // 0x00AB6EE0: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00AB6EE4: LDR x8, [x8, #0x58]        | X8 = 1152921514957634992;               
            // 0x00AB6EE8: MOV x0, x20                | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets;//m1
            // 0x00AB6EEC: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00AB6EF0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::Remove(System.String key);
            // 0x00AB6EF4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB6EF8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB6EFC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB6F00: B #0x23fe354               | X0 = Mihua.Asset.AssetMgr.m_LoadedAssets.Remove(key:  X1); return;
            bool val_2 = Mihua.Asset.AssetMgr.m_LoadedAssets.Remove(key:  X1);
            return;
            label_4:
            // 0x00AB6F04: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB6F08: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB6F0C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AB6F10: RET                        |  return;                                
            return;
        
        }
    
    }

}
