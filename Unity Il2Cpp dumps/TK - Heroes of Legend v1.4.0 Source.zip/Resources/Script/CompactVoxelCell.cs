using UnityEngine;

namespace Pathfinding.Voxels
{
    public struct CompactVoxelCell
    {
        // Fields
        public uint index; //  0x00000000
        public uint count; //  0x00000004
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00EDC830 (15583280), len: 8  VirtAddr: 0x00EDC830 RVA: 0x00EDC830 token: 100683282 methodIndex: 51355 delegateWrapperIndex: 0 methodInvoker: 0
        public CompactVoxelCell(uint i, uint c)
        {
            //
            // Disasemble & Code
            // 0x00EDC830: STP w1, w2, [x0, #0x10]    | mem[1152921513443555248] = i;  mem[1152921513443555252] = c;  //  dest_result_addr=1152921513443555248 |  dest_result_addr=1152921513443555252
            mem[1152921513443555248] = i;
            mem[1152921513443555252] = c;
            // 0x00EDC834: RET                        |  return;                                
            return;
        
        }
    
    }

}
