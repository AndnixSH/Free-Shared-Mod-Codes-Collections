using UnityEngine;
public class CameraAniCfgMgr
{
    // Fields
    [System.Diagnostics.DebuggerBrowsableAttribute] // 0x286BD98
    private static bool <inited>k__BackingField; // static_offset: 0x00000000
    private static CameraAniCfgMgr _inst; // static_offset: 0x00000008
    private System.Collections.Generic.Dictionary<int, CameraAniMap> cameraAniMaps; //  0x00000010
    
    // Properties
    public static bool inited { get; set; }
    public static CameraAniCfgMgr instance { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA6AE8 (12217064), len: 8  VirtAddr: 0x00BA6AE8 RVA: 0x00BA6AE8 token: 100690315 methodIndex: 25632 delegateWrapperIndex: 0 methodInvoker: 0
    private static CameraAniCfgMgr()
    {
        //
        // Disasemble & Code
        // 0x00BA6AE8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA6AEC: B #0xba6af0                | CameraAniCfgMgr.set_inited(value:  false); return;
        CameraAniCfgMgr.inited = false;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6B60 (12217184), len: 112  VirtAddr: 0x00BA6B60 RVA: 0x00BA6B60 token: 100690316 methodIndex: 25633 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAniCfgMgr()
    {
        //
        // Disasemble & Code
        // 0x00BA6B60: STP x20, x19, [sp, #-0x20]! | stack[1152921514507306208] = ???;  stack[1152921514507306216] = ???;  //  dest_result_addr=1152921514507306208 |  dest_result_addr=1152921514507306216
        // 0x00BA6B64: STP x29, x30, [sp, #0x10]  | stack[1152921514507306224] = ???;  stack[1152921514507306232] = ???;  //  dest_result_addr=1152921514507306224 |  dest_result_addr=1152921514507306232
        // 0x00BA6B68: ADD x29, sp, #0x10         | X29 = (1152921514507306208 + 16) = 1152921514507306224 (0x100000024E1D04F0);
        // 0x00BA6B6C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA6B70: LDRB w8, [x20, #0xade]     | W8 = (bool)static_value_03733ADE;       
        // 0x00BA6B74: MOV x19, x0                | X19 = 1152921514507318240 (0x100000024E1D33E0);//ML01
        // 0x00BA6B78: TBNZ w8, #0, #0xba6b94     | if (static_value_03733ADE == true) goto label_0;
        // 0x00BA6B7C: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00BA6B80: LDR x8, [x8, #0xda8]       | X8 = 0x2B9012C;                         
        // 0x00BA6B84: LDR w0, [x8]               | W0 = 0x170F;                            
        // 0x00BA6B88: BL #0x2782188              | X0 = sub_2782188( ?? 0x170F, ????);     
        // 0x00BA6B8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6B90: STRB w8, [x20, #0xade]     | static_value_03733ADE = true;            //  dest_result_addr=57883358
        label_0:
        // 0x00BA6B94: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00BA6B98: LDR x8, [x8, #0x978]       | X8 = 1152921504615792640;               
        // 0x00BA6B9C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.Int32, CameraAniMap> val_1 = null;
        // 0x00BA6BA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00BA6BA4: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00BA6BA8: LDR x8, [x8, #0xf90]       | X8 = 1152921514507293216;               
        // 0x00BA6BAC: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00BA6BB0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, CameraAniMap>::.ctor();
        // 0x00BA6BB4: BL #0x2413320              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.Int32, CameraAniMap>();
        // 0x00BA6BB8: STR x20, [x19, #0x10]      | this.cameraAniMaps = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921514507318256
        this.cameraAniMaps = val_1;
        // 0x00BA6BBC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6BC0: MOV x0, x19                | X0 = 1152921514507318240 (0x100000024E1D33E0);//ML01
        // 0x00BA6BC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6BC8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6BCC: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6BD0 (12217296), len: 104  VirtAddr: 0x00BA6BD0 RVA: 0x00BA6BD0 token: 100690317 methodIndex: 25634 delegateWrapperIndex: 0 methodInvoker: 0
    public static bool get_inited()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA6BD0: STP x20, x19, [sp, #-0x20]! | stack[1152921514507418208] = ???;  stack[1152921514507418216] = ???;  //  dest_result_addr=1152921514507418208 |  dest_result_addr=1152921514507418216
        // 0x00BA6BD4: STP x29, x30, [sp, #0x10]  | stack[1152921514507418224] = ???;  stack[1152921514507418232] = ???;  //  dest_result_addr=1152921514507418224 |  dest_result_addr=1152921514507418232
        // 0x00BA6BD8: ADD x29, sp, #0x10         | X29 = (1152921514507418208 + 16) = 1152921514507418224 (0x100000024E1EBA70);
        // 0x00BA6BDC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA6BE0: LDRB w8, [x19, #0xadf]     | W8 = (bool)static_value_03733ADF;       
        // 0x00BA6BE4: TBNZ w8, #0, #0xba6c00     | if (static_value_03733ADF == true) goto label_0;
        // 0x00BA6BE8: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00BA6BEC: LDR x8, [x8, #0xde0]       | X8 = 0x2B90130;                         
        // 0x00BA6BF0: LDR w0, [x8]               | W0 = 0x1710;                            
        // 0x00BA6BF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1710, ????);     
        // 0x00BA6BF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6BFC: STRB w8, [x19, #0xadf]     | static_value_03733ADF = true;            //  dest_result_addr=57883359
        label_0:
        // 0x00BA6C00: ADRP x19, #0x3663000       | X19 = 57028608 (0x3663000);             
        // 0x00BA6C04: LDR x19, [x19, #0xb88]     | X19 = 1152921504888635392;              
        // 0x00BA6C08: LDR x0, [x19]              | X0 = typeof(CameraAniCfgMgr);           
        val_1 = null;
        // 0x00BA6C0C: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00BA6C10: TBZ w8, #0, #0xba6c24      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA6C14: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6C18: CBNZ w8, #0xba6c24         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA6C1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        // 0x00BA6C20: LDR x0, [x19]              | X0 = typeof(CameraAniCfgMgr);           
        val_1 = null;
        label_2:
        // 0x00BA6C24: LDR x8, [x0, #0xa0]        | X8 = CameraAniCfgMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA6C28: LDRB w0, [x8]              | W0 = CameraAniCfgMgr.<inited>k__BackingField;
        // 0x00BA6C2C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6C30: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6C34: RET                        |  return (System.Boolean)CameraAniCfgMgr.<inited>k__BackingField;
        return CameraAniCfgMgr.<inited>k__BackingField;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6AF0 (12217072), len: 112  VirtAddr: 0x00BA6AF0 RVA: 0x00BA6AF0 token: 100690318 methodIndex: 25635 delegateWrapperIndex: 0 methodInvoker: 0
    private static void set_inited(bool value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00BA6AF0: STP x20, x19, [sp, #-0x20]! | stack[1152921514507530208] = ???;  stack[1152921514507530216] = ???;  //  dest_result_addr=1152921514507530208 |  dest_result_addr=1152921514507530216
        // 0x00BA6AF4: STP x29, x30, [sp, #0x10]  | stack[1152921514507530224] = ???;  stack[1152921514507530232] = ???;  //  dest_result_addr=1152921514507530224 |  dest_result_addr=1152921514507530232
        // 0x00BA6AF8: ADD x29, sp, #0x10         | X29 = (1152921514507530208 + 16) = 1152921514507530224 (0x100000024E206FF0);
        // 0x00BA6AFC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA6B00: LDRB w8, [x20, #0xae0]     | W8 = (bool)static_value_03733AE0;       
        // 0x00BA6B04: MOV w19, w1                | W19 = W1;//m1                           
        // 0x00BA6B08: TBNZ w8, #0, #0xba6b24     | if (static_value_03733AE0 == true) goto label_0;
        // 0x00BA6B0C: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00BA6B10: LDR x8, [x8, #0x538]       | X8 = 0x2B90140;                         
        // 0x00BA6B14: LDR w0, [x8]               | W0 = 0x1714;                            
        // 0x00BA6B18: BL #0x2782188              | X0 = sub_2782188( ?? 0x1714, ????);     
        // 0x00BA6B1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6B20: STRB w8, [x20, #0xae0]     | static_value_03733AE0 = true;            //  dest_result_addr=57883360
        label_0:
        // 0x00BA6B24: ADRP x20, #0x3663000       | X20 = 57028608 (0x3663000);             
        // 0x00BA6B28: LDR x20, [x20, #0xb88]     | X20 = 1152921504888635392;              
        // 0x00BA6B2C: LDR x0, [x20]              | X0 = typeof(CameraAniCfgMgr);           
        val_2 = null;
        // 0x00BA6B30: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00BA6B34: TBZ w8, #0, #0xba6b48      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA6B38: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6B3C: CBNZ w8, #0xba6b48         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA6B40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        // 0x00BA6B44: LDR x0, [x20]              | X0 = typeof(CameraAniCfgMgr);           
        val_2 = null;
        label_2:
        // 0x00BA6B48: LDR x8, [x0, #0xa0]        | X8 = CameraAniCfgMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA6B4C: AND w9, w19, #1            | W9 = (W1 & 1);                          
        bool val_1 = W1 & 1;
        // 0x00BA6B50: STRB w9, [x8]              | CameraAniCfgMgr.<inited>k__BackingField = (W1 & 1);  //  dest_result_addr=1152921504888639488
        CameraAniCfgMgr.<inited>k__BackingField = val_1;
        // 0x00BA6B54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6B58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6B5C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6C38 (12217400), len: 440  VirtAddr: 0x00BA6C38 RVA: 0x00BA6C38 token: 100690319 methodIndex: 25636 delegateWrapperIndex: 0 methodInvoker: 0
    public static CameraAniCfgMgr get_instance()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        CameraAniCfgMgr val_5;
        //  | 
        var val_6;
        // 0x00BA6C38: STP x22, x21, [sp, #-0x30]! | stack[1152921514507643312] = ???;  stack[1152921514507643320] = ???;  //  dest_result_addr=1152921514507643312 |  dest_result_addr=1152921514507643320
        // 0x00BA6C3C: STP x20, x19, [sp, #0x10]  | stack[1152921514507643328] = ???;  stack[1152921514507643336] = ???;  //  dest_result_addr=1152921514507643328 |  dest_result_addr=1152921514507643336
        // 0x00BA6C40: STP x29, x30, [sp, #0x20]  | stack[1152921514507643344] = ???;  stack[1152921514507643352] = ???;  //  dest_result_addr=1152921514507643344 |  dest_result_addr=1152921514507643352
        // 0x00BA6C44: ADD x29, sp, #0x20         | X29 = (1152921514507643312 + 32) = 1152921514507643344 (0x100000024E2229D0);
        // 0x00BA6C48: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA6C4C: LDRB w8, [x19, #0xae1]     | W8 = (bool)static_value_03733AE1;       
        // 0x00BA6C50: TBNZ w8, #0, #0xba6c6c     | if (static_value_03733AE1 == true) goto label_0;
        // 0x00BA6C54: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00BA6C58: LDR x8, [x8, #0x6b0]       | X8 = 0x2B90134;                         
        // 0x00BA6C5C: LDR w0, [x8]               | W0 = 0x1711;                            
        // 0x00BA6C60: BL #0x2782188              | X0 = sub_2782188( ?? 0x1711, ????);     
        // 0x00BA6C64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6C68: STRB w8, [x19, #0xae1]     | static_value_03733AE1 = true;            //  dest_result_addr=57883361
        label_0:
        // 0x00BA6C6C: ADRP x22, #0x3663000       | X22 = 57028608 (0x3663000);             
        // 0x00BA6C70: LDR x22, [x22, #0xb88]     | X22 = 1152921504888635392;              
        // 0x00BA6C74: LDR x0, [x22]              | X0 = typeof(CameraAniCfgMgr);           
        val_5 = null;
        // 0x00BA6C78: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00BA6C7C: TBZ w8, #0, #0xba6c90      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA6C80: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6C84: CBNZ w8, #0xba6c90         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA6C88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        // 0x00BA6C8C: LDR x0, [x22]              | X0 = typeof(CameraAniCfgMgr);           
        val_5 = null;
        label_2:
        // 0x00BA6C90: LDR x8, [x0, #0xa0]        | X8 = CameraAniCfgMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA6C94: LDR x8, [x8, #8]           | X8 = CameraAniCfgMgr._inst;             
        // 0x00BA6C98: CBNZ x8, #0xba6dc0         | if (CameraAniCfgMgr._inst != null) goto label_3;
        if(CameraAniCfgMgr._inst != null)
        {
            goto label_3;
        }
        // 0x00BA6C9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraAniCfgMgr), ????);
        // 0x00BA6CA0: MOV x19, x0                | X19 = 1152921504888635392 (0x1000000010CBC000);//ML01
        // 0x00BA6CA4: BL #0xba6b60               | .ctor();                                
        val_5 = new CameraAniCfgMgr();
        // 0x00BA6CA8: LDR x0, [x22]              | X0 = typeof(CameraAniCfgMgr);           
        val_6 = null;
        // 0x00BA6CAC: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00BA6CB0: TBZ w8, #0, #0xba6cc4      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00BA6CB4: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6CB8: CBNZ w8, #0xba6cc4         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00BA6CBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        // 0x00BA6CC0: LDR x0, [x22]              | X0 = typeof(CameraAniCfgMgr);           
        val_6 = null;
        label_5:
        // 0x00BA6CC4: LDR x8, [x0, #0xa0]        | X8 = CameraAniCfgMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA6CC8: ADRP x9, #0x3640000        | X9 = 56885248 (0x3640000);              
        // 0x00BA6CCC: ADRP x10, #0x3620000       | X10 = 56754176 (0x3620000);             
        // 0x00BA6CD0: STR x19, [x8, #8]          | CameraAniCfgMgr._inst = typeof(CameraAniCfgMgr);  //  dest_result_addr=1152921504888639496
        CameraAniCfgMgr._inst = val_5;
        // 0x00BA6CD4: LDR x8, [x22]              | X8 = typeof(CameraAniCfgMgr);           
        // 0x00BA6CD8: LDR x8, [x8, #0xa0]        | X8 = CameraAniCfgMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA6CDC: LDR x9, [x9, #0x590]       | X9 = 1152921514507630240;               
        // 0x00BA6CE0: LDR x10, [x10, #0x840]     | X10 = 1152921504657805312;              
        // 0x00BA6CE4: LDR x20, [x8, #8]          | X20 = typeof(CameraAniCfgMgr);          
        // 0x00BA6CE8: LDR x19, [x9]              | X19 = System.Void CameraAniCfgMgr::Init();
        // 0x00BA6CEC: LDR x0, [x10]              | X0 = typeof(System.Threading.ThreadStart);
        System.Threading.ThreadStart val_1 = null;
        // 0x00BA6CF0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Threading.ThreadStart), ????);
        // 0x00BA6CF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA6CF8: MOV x1, x20                | X1 = 1152921504888635392 (0x1000000010CBC000);//ML01
        // 0x00BA6CFC: MOV x2, x19                | X2 = 1152921514507630240 (0x100000024E21F6A0);//ML01
        // 0x00BA6D00: MOV x21, x0                | X21 = 1152921504657805312 (0x1000000003099000);//ML01
        // 0x00BA6D04: BL #0x1b67778              | .ctor(object:  CameraAniCfgMgr._inst, method:  System.Void CameraAniCfgMgr::Init());
        val_1 = new System.Threading.ThreadStart(object:  CameraAniCfgMgr._inst, method:  System.Void CameraAniCfgMgr::Init());
        // 0x00BA6D08: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00BA6D0C: LDR x8, [x8, #0x490]       | X8 = 1152921504650829824;               
        // 0x00BA6D10: LDR x0, [x8]               | X0 = typeof(System.Threading.Thread);   
        System.Threading.Thread val_2 = null;
        // 0x00BA6D14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Threading.Thread), ????);
        // 0x00BA6D18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6D1C: MOV x1, x21                | X1 = 1152921504657805312 (0x1000000003099000);//ML01
        // 0x00BA6D20: MOV x19, x0                | X19 = 1152921504650829824 (0x10000000029F2000);//ML01
        val_4 = val_2;
        // 0x00BA6D24: BL #0x1b66890              | .ctor(start:  val_1);                   
        val_2 = new System.Threading.Thread(start:  val_1);
        // 0x00BA6D28: CBZ x19, #0xba6d68         | if ( == 0) goto label_6;                
        if(null == 0)
        {
            goto label_6;
        }
        // 0x00BA6D2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6D30: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA6D34: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6D38: BL #0x1b671f8              | set_IsBackground(value:  true);         
        IsBackground = true;
        // 0x00BA6D3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6D40: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00BA6D44: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6D48: BL #0x1b6721c              | set_Priority(value:  4);                
        Priority = 4;
        // 0x00BA6D4C: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00BA6D50: LDR x8, [x8, #0xe48]       | X8 = (string**)(1152921514507631264)("InitAniCfgData");
        // 0x00BA6D54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6D58: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6D5C: LDR x1, [x8]               | X1 = "InitAniCfgData";                  
        // 0x00BA6D60: BL #0x1b67218              | set_Name(value:  "InitAniCfgData");     
        Name = "InitAniCfgData";
        // 0x00BA6D64: B #0xba6db0                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00BA6D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(start:  val_1), ????);
        // 0x00BA6D6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6D70: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA6D74: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6D78: BL #0x1b671f8              | set_IsBackground(value:  true);         
        IsBackground = true;
        // 0x00BA6D7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Threading.Thread), ????);
        // 0x00BA6D80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6D84: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00BA6D88: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6D8C: BL #0x1b6721c              | set_Priority(value:  4);                
        Priority = 4;
        // 0x00BA6D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Threading.Thread), ????);
        // 0x00BA6D94: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00BA6D98: LDR x8, [x8, #0xe48]       | X8 = (string**)(1152921514507631264)("InitAniCfgData");
        // 0x00BA6D9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6DA0: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6DA4: LDR x1, [x8]               | X1 = "InitAniCfgData";                  
        // 0x00BA6DA8: BL #0x1b67218              | set_Name(value:  "InitAniCfgData");     
        Name = "InitAniCfgData";
        // 0x00BA6DAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Threading.Thread), ????);
        label_7:
        // 0x00BA6DB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6DB4: MOV x0, x19                | X0 = 1152921504650829824 (0x10000000029F2000);//ML01
        // 0x00BA6DB8: BL #0x1b672dc              | Start();                                
        Start();
        // 0x00BA6DBC: LDR x0, [x22]              | X0 = typeof(CameraAniCfgMgr);           
        val_5 = null;
        label_3:
        // 0x00BA6DC0: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00BA6DC4: TBZ w8, #0, #0xba6dd8      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00BA6DC8: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6DCC: CBNZ w8, #0xba6dd8         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00BA6DD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        // 0x00BA6DD4: LDR x0, [x22]              | X0 = typeof(CameraAniCfgMgr);           
        val_5 = null;
        label_9:
        // 0x00BA6DD8: LDR x8, [x0, #0xa0]        | X8 = CameraAniCfgMgr.__il2cppRuntimeField_static_fields;
        // 0x00BA6DDC: LDR x0, [x8, #8]           | X0 = typeof(CameraAniCfgMgr);           
        // 0x00BA6DE0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6DE4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6DE8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA6DEC: RET                        |  return (CameraAniCfgMgr)typeof(CameraAniCfgMgr);
        return CameraAniCfgMgr._inst;
        //  |  // // {name=val_0, type=CameraAniCfgMgr, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6DF0 (12217840), len: 500  VirtAddr: 0x00BA6DF0 RVA: 0x00BA6DF0 token: 100690320 methodIndex: 25637 delegateWrapperIndex: 0 methodInvoker: 0
    private void Init()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00BA6DF0: STP x28, x27, [sp, #-0x60]! | stack[1152921514507780192] = ???;  stack[1152921514507780200] = ???;  //  dest_result_addr=1152921514507780192 |  dest_result_addr=1152921514507780200
        // 0x00BA6DF4: STP x26, x25, [sp, #0x10]  | stack[1152921514507780208] = ???;  stack[1152921514507780216] = ???;  //  dest_result_addr=1152921514507780208 |  dest_result_addr=1152921514507780216
        // 0x00BA6DF8: STP x24, x23, [sp, #0x20]  | stack[1152921514507780224] = ???;  stack[1152921514507780232] = ???;  //  dest_result_addr=1152921514507780224 |  dest_result_addr=1152921514507780232
        // 0x00BA6DFC: STP x22, x21, [sp, #0x30]  | stack[1152921514507780240] = ???;  stack[1152921514507780248] = ???;  //  dest_result_addr=1152921514507780240 |  dest_result_addr=1152921514507780248
        // 0x00BA6E00: STP x20, x19, [sp, #0x40]  | stack[1152921514507780256] = ???;  stack[1152921514507780264] = ???;  //  dest_result_addr=1152921514507780256 |  dest_result_addr=1152921514507780264
        // 0x00BA6E04: STP x29, x30, [sp, #0x50]  | stack[1152921514507780272] = ???;  stack[1152921514507780280] = ???;  //  dest_result_addr=1152921514507780272 |  dest_result_addr=1152921514507780280
        // 0x00BA6E08: ADD x29, sp, #0x50         | X29 = (1152921514507780192 + 80) = 1152921514507780272 (0x100000024E2440B0);
        // 0x00BA6E0C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA6E10: LDRB w8, [x20, #0xae2]     | W8 = (bool)static_value_03733AE2;       
        // 0x00BA6E14: MOV x19, x0                | X19 = 1152921514507792288 (0x100000024E246FA0);//ML01
        // 0x00BA6E18: TBNZ w8, #0, #0xba6e34     | if (static_value_03733AE2 == true) goto label_0;
        // 0x00BA6E1C: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
        // 0x00BA6E20: LDR x8, [x8, #0x230]       | X8 = 0x2B9013C;                         
        // 0x00BA6E24: LDR w0, [x8]               | W0 = 0x1713;                            
        // 0x00BA6E28: BL #0x2782188              | X0 = sub_2782188( ?? 0x1713, ????);     
        // 0x00BA6E2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6E30: STRB w8, [x20, #0xae2]     | static_value_03733AE2 = true;            //  dest_result_addr=57883362
        label_0:
        // 0x00BA6E34: ADRP x25, #0x3618000       | X25 = 56721408 (0x3618000);             
        // 0x00BA6E38: LDR x25, [x25, #0x530]     | X25 = 1152921504924098560;              
        // 0x00BA6E3C: LDR x0, [x25]              | X0 = typeof(EDebug);                    
        // 0x00BA6E40: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00BA6E44: TBZ w8, #0, #0xba6e54      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA6E48: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6E4C: CBNZ w8, #0xba6e54         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA6E50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00BA6E54: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00BA6E58: LDR x8, [x8, #0x298]       | X8 = (string**)(1152921514507743360)("start level cfg init");
        // 0x00BA6E5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6E60: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00BA6E64: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00BA6E68: LDR x1, [x8]               | X1 = "start level cfg init";            
        // 0x00BA6E6C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA6E70: BL #0xb5abec               | EDebug.Debug(message:  0, isShowStack:  true, user:  1);
        EDebug.Debug(message:  0, isShowStack:  true, user:  1);
        // 0x00BA6E74: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00BA6E78: LDR x8, [x8, #0x638]       | X8 = 1152921504924684288;               
        // 0x00BA6E7C: LDR x0, [x8]               | X0 = typeof(ReadFileTool);              
        // 0x00BA6E80: LDRB w8, [x0, #0x10a]      | W8 = ReadFileTool.__il2cppRuntimeField_10A;
        // 0x00BA6E84: TBZ w8, #0, #0xba6e94      | if (ReadFileTool.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BA6E88: LDR w8, [x0, #0xbc]        | W8 = ReadFileTool.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6E8C: CBNZ w8, #0xba6e94         | if (ReadFileTool.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BA6E90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ReadFileTool), ????);
        label_4:
        // 0x00BA6E94: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00BA6E98: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x00BA6E9C: LDR x8, [x8, #0x6a8]       | X8 = (string**)(1152921514507743472)("Data/CameraShot/CameraShotAni");
        // 0x00BA6EA0: LDR x9, [x9, #0x738]       | X9 = 1152921514507743600;               
        // 0x00BA6EA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6EA8: LDR x1, [x8]               | X1 = "Data/CameraShot/CameraShotAni";   
        // 0x00BA6EAC: LDR x2, [x9]               | X2 = public static CameraAnis ReadFileTool::AddressToClass<CameraAnis>(string txtAddress);
        // 0x00BA6EB0: BL #0xfdecdc               | X0 = ReadFileTool.AddressToClass<JSCMapDataConfig>(txtAddress:  0);
        JSCMapDataConfig val_1 = ReadFileTool.AddressToClass<JSCMapDataConfig>(txtAddress:  0);
        // 0x00BA6EB4: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00BA6EB8: CBNZ x21, #0xba6ec0        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00BA6EBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00BA6EC0: ADRP x26, #0x3616000       | X26 = 56713216 (0x3616000);             
        // 0x00BA6EC4: ADRP x27, #0x35ea000       | X27 = 56532992 (0x35EA000);             
        // 0x00BA6EC8: ADRP x28, #0x35c7000       | X28 = 56389632 (0x35C7000);             
        // 0x00BA6ECC: LDR x21, [x21, #0x10]      | X21 = val_1._jarr; //P2                 
        // 0x00BA6ED0: LDR x26, [x26, #0x240]     | X26 = 1152921514507752816;              
        // 0x00BA6ED4: LDR x27, [x27, #0xfe8]     | X27 = 1152921514507753840;              
        // 0x00BA6ED8: LDR x28, [x28, #0x948]     | X28 = 1152921514507754864;              
        // 0x00BA6EDC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00BA6EE0: B #0xba6efc                |  goto label_6;                          
        goto label_6;
        label_13:
        // 0x00BA6EE4: LDR x3, [x28]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, CameraAniMap>::Add(System.Int32 key, CameraAniMap value);
        // 0x00BA6EE8: MOV x0, x22                | X0 = X22;//m1                           
        // 0x00BA6EEC: MOV w1, w23                | W1 = W23;//m1                           
        // 0x00BA6EF0: MOV x2, x24                | X2 = X24;//m1                           
        // 0x00BA6EF4: BL #0x2415668              | X22.Add(key:  W23, value:  X24);        
        X22.Add(key:  W23, value:  X24);
        // 0x00BA6EF8: ADD w20, w20, #1           | W20 = (val_5 + 1) = val_5 (0x00000001); 
        val_5 = 1;
        label_6:
        // 0x00BA6EFC: CBNZ x21, #0xba6f04        | if (val_1._jarr != null) goto label_7;  
        if(val_1._jarr != null)
        {
            goto label_7;
        }
        // 0x00BA6F00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22, ????);        
        label_7:
        // 0x00BA6F04: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<CameraAniMap>::get_Count();
        // 0x00BA6F08: MOV x0, x21                | X0 = val_1._jarr;//m1                   
        // 0x00BA6F0C: BL #0x25ed72c              | X0 = val_1._jarr.get_Count();           
        int val_2 = val_1._jarr.Count;
        // 0x00BA6F10: CMP w20, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00BA6F14: B.GE #0xba6f6c             | if (val_5 >= val_2) goto label_8;       
        if(val_5 >= val_2)
        {
            goto label_8;
        }
        // 0x00BA6F18: LDR x22, [x19, #0x10]      | X22 = this.cameraAniMaps; //P2          
        // 0x00BA6F1C: CBNZ x21, #0xba6f24        | if (val_1._jarr != null) goto label_9;  
        if(val_1._jarr != null)
        {
            goto label_9;
        }
        // 0x00BA6F20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_9:
        // 0x00BA6F24: LDR x2, [x27]              | X2 = public CameraAniMap System.Collections.Generic.List<CameraAniMap>::get_Item(int index);
        // 0x00BA6F28: MOV x0, x21                | X0 = val_1._jarr;//m1                   
        // 0x00BA6F2C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00BA6F30: BL #0x25ed734              | X0 = val_1._jarr.get_Item(index:  1);   
        CameraAniMap val_3 = val_1._jarr.Item[1];
        // 0x00BA6F34: MOV x23, x0                | X23 = val_3;//m1                        
        // 0x00BA6F38: CBNZ x23, #0xba6f40        | if (val_3 != null) goto label_10;       
        if(val_3 != null)
        {
            goto label_10;
        }
        // 0x00BA6F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x00BA6F40: LDR w23, [x23, #0x10]      | W23 = val_3._id; //P2                   
        // 0x00BA6F44: CBNZ x21, #0xba6f4c        | if (val_1._jarr != null) goto label_11; 
        if(val_1._jarr != null)
        {
            goto label_11;
        }
        // 0x00BA6F48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_11:
        // 0x00BA6F4C: LDR x2, [x27]              | X2 = public CameraAniMap System.Collections.Generic.List<CameraAniMap>::get_Item(int index);
        // 0x00BA6F50: MOV x0, x21                | X0 = val_1._jarr;//m1                   
        // 0x00BA6F54: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00BA6F58: BL #0x25ed734              | X0 = val_1._jarr.get_Item(index:  1);   
        CameraAniMap val_4 = val_1._jarr.Item[1];
        // 0x00BA6F5C: MOV x24, x0                | X24 = val_4;//m1                        
        // 0x00BA6F60: CBNZ x22, #0xba6ee4        | if (this.cameraAniMaps != null) goto label_13;
        if(this.cameraAniMaps != null)
        {
            goto label_13;
        }
        // 0x00BA6F64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        // 0x00BA6F68: B #0xba6ee4                |  goto label_13;                         
        goto label_13;
        label_8:
        // 0x00BA6F6C: LDR x0, [x25]              | X0 = typeof(EDebug);                    
        // 0x00BA6F70: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00BA6F74: TBZ w8, #0, #0xba6f84      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00BA6F78: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6F7C: CBNZ w8, #0xba6f84         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00BA6F80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_15:
        // 0x00BA6F84: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00BA6F88: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921514507768176)("end level cfg init");
        // 0x00BA6F8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6F90: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00BA6F94: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00BA6F98: LDR x1, [x8]               | X1 = "end level cfg init";              
        // 0x00BA6F9C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA6FA0: BL #0xb5abec               | EDebug.Debug(message:  0, isShowStack:  true, user:  1);
        EDebug.Debug(message:  0, isShowStack:  true, user:  1);
        // 0x00BA6FA4: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00BA6FA8: LDR x8, [x8, #0xb88]       | X8 = 1152921504888635392;               
        // 0x00BA6FAC: LDR x0, [x8]               | X0 = typeof(CameraAniCfgMgr);           
        // 0x00BA6FB0: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00BA6FB4: TBZ w8, #0, #0xba6fc4      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00BA6FB8: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA6FBC: CBNZ w8, #0xba6fc4         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00BA6FC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        label_17:
        // 0x00BA6FC4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6FC8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6FCC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA6FD0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA6FD4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA6FD8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA6FDC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00BA6FE0: B #0xba6af0                | CameraAniCfgMgr.set_inited(value:  false); return;
        CameraAniCfgMgr.inited = false;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6FF4 (12218356), len: 160  VirtAddr: 0x00BA6FF4 RVA: 0x00BA6FF4 token: 100690321 methodIndex: 25638 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAniMap GetCameraAniMapByMapid(int mapid)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00BA6FF4: STP x22, x21, [sp, #-0x30]! | stack[1152921514507927056] = ???;  stack[1152921514507927064] = ???;  //  dest_result_addr=1152921514507927056 |  dest_result_addr=1152921514507927064
        // 0x00BA6FF8: STP x20, x19, [sp, #0x10]  | stack[1152921514507927072] = ???;  stack[1152921514507927080] = ???;  //  dest_result_addr=1152921514507927072 |  dest_result_addr=1152921514507927080
        // 0x00BA6FFC: STP x29, x30, [sp, #0x20]  | stack[1152921514507927088] = ???;  stack[1152921514507927096] = ???;  //  dest_result_addr=1152921514507927088 |  dest_result_addr=1152921514507927096
        // 0x00BA7000: ADD x29, sp, #0x20         | X29 = (1152921514507927056 + 32) = 1152921514507927088 (0x100000024E267E30);
        // 0x00BA7004: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA7008: LDRB w8, [x21, #0xae3]     | W8 = (bool)static_value_03733AE3;       
        // 0x00BA700C: MOV w19, w1                | W19 = mapid;//m1                        
        // 0x00BA7010: MOV x20, x0                | X20 = 1152921514507939104 (0x100000024E26AD20);//ML01
        // 0x00BA7014: TBNZ w8, #0, #0xba7030     | if (static_value_03733AE3 == true) goto label_0;
        // 0x00BA7018: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
        // 0x00BA701C: LDR x8, [x8, #0x158]       | X8 = 0x2B90138;                         
        // 0x00BA7020: LDR w0, [x8]               | W0 = 0x1712;                            
        // 0x00BA7024: BL #0x2782188              | X0 = sub_2782188( ?? 0x1712, ????);     
        // 0x00BA7028: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA702C: STRB w8, [x21, #0xae3]     | static_value_03733AE3 = true;            //  dest_result_addr=57883363
        label_0:
        // 0x00BA7030: LDR x21, [x20, #0x10]      | X21 = this.cameraAniMaps; //P2          
        // 0x00BA7034: CBNZ x21, #0xba703c        | if (this.cameraAniMaps != null) goto label_1;
        if(this.cameraAniMaps != null)
        {
            goto label_1;
        }
        // 0x00BA7038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1712, ????);     
        label_1:
        // 0x00BA703C: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00BA7040: LDR x8, [x8, #0x9a0]       | X8 = 1152921514507904864;               
        // 0x00BA7044: MOV x0, x21                | X0 = this.cameraAniMaps;//m1            
        // 0x00BA7048: MOV w1, w19                | W1 = mapid;//m1                         
        // 0x00BA704C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, CameraAniMap>::ContainsKey(System.Int32 key);
        // 0x00BA7050: BL #0x2415bdc              | X0 = this.cameraAniMaps.ContainsKey(key:  mapid);
        bool val_1 = this.cameraAniMaps.ContainsKey(key:  mapid);
        // 0x00BA7054: TBZ w0, #0, #0xba7080      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00BA7058: LDR x20, [x20, #0x10]      | X20 = this.cameraAniMaps; //P2          
        // 0x00BA705C: CBNZ x20, #0xba7064        | if (this.cameraAniMaps != null) goto label_3;
        if(this.cameraAniMaps != null)
        {
            goto label_3;
        }
        // 0x00BA7060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BA7064: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
        // 0x00BA7068: LDR x8, [x8, #0x350]       | X8 = 1152921514507909984;               
        // 0x00BA706C: MOV x0, x20                | X0 = this.cameraAniMaps;//m1            
        // 0x00BA7070: MOV w1, w19                | W1 = mapid;//m1                         
        // 0x00BA7074: LDR x2, [x8]               | X2 = public CameraAniMap System.Collections.Generic.Dictionary<System.Int32, CameraAniMap>::get_Item(System.Int32 key);
        // 0x00BA7078: BL #0x24144f0              | X0 = this.cameraAniMaps.get_Item(key:  mapid);
        CameraAniMap val_2 = this.cameraAniMaps.Item[mapid];
        // 0x00BA707C: B #0xba7084                |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x00BA7080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_3 = 0;
        label_4:
        // 0x00BA7084: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7088: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA708C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA7090: RET                        |  return (CameraAniMap)null;             
        return (CameraAniMap)val_3;
        //  |  // // {name=val_0, type=CameraAniMap, size=8, nGRN=0 }
    
    }

}
