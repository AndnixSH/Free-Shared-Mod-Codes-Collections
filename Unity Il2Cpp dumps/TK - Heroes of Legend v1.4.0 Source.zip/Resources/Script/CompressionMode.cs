using UnityEngine;

namespace Pathfinding.Ionic.Zlib
{
    public enum CompressionMode
    {
        // Fields
        Compress = 0
        ,Decompress = 1
        
    
    }

}
