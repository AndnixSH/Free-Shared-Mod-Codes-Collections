using UnityEngine;

namespace Pathfinding
{
    [Serializable]
    public class AstarColor
    {
        // Fields
        public UnityEngine.Color _NodeConnection; //  0x00000010
        public UnityEngine.Color _UnwalkableNode; //  0x00000020
        public UnityEngine.Color _BoundsHandles; //  0x00000030
        public UnityEngine.Color _ConnectionLowLerp; //  0x00000040
        public UnityEngine.Color _ConnectionHighLerp; //  0x00000050
        public UnityEngine.Color _MeshEdgeColor; //  0x00000060
        public UnityEngine.Color _MeshColor; //  0x00000070
        public UnityEngine.Color[] _AreaColors; //  0x00000080
        public static UnityEngine.Color NodeConnection; // static_offset: 0x00000000
        public static UnityEngine.Color UnwalkableNode; // static_offset: 0x00000010
        public static UnityEngine.Color BoundsHandles; // static_offset: 0x00000020
        public static UnityEngine.Color ConnectionLowLerp; // static_offset: 0x00000030
        public static UnityEngine.Color ConnectionHighLerp; // static_offset: 0x00000040
        public static UnityEngine.Color MeshEdgeColor; // static_offset: 0x00000050
        public static UnityEngine.Color MeshColor; // static_offset: 0x00000060
        private static UnityEngine.Color[] AreaColors; // static_offset: 0x00000070
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0167F1F8 (23589368), len: 380  VirtAddr: 0x0167F1F8 RVA: 0x0167F1F8 token: 100681809 methodIndex: 49756 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarColor()
        {
            //
            // Disasemble & Code
            // 0x0167F1F8: STP d11, d10, [sp, #-0x40]! | stack[1152921513132334048] = ???;  stack[1152921513132334056] = ???;  //  dest_result_addr=1152921513132334048 |  dest_result_addr=1152921513132334056
            // 0x0167F1FC: STP d9, d8, [sp, #0x10]    | stack[1152921513132334064] = ???;  stack[1152921513132334072] = ???;  //  dest_result_addr=1152921513132334064 |  dest_result_addr=1152921513132334072
            // 0x0167F200: STP x20, x19, [sp, #0x20]  | stack[1152921513132334080] = ???;  stack[1152921513132334088] = ???;  //  dest_result_addr=1152921513132334080 |  dest_result_addr=1152921513132334088
            // 0x0167F204: STP x29, x30, [sp, #0x30]  | stack[1152921513132334096] = ???;  stack[1152921513132334104] = ???;  //  dest_result_addr=1152921513132334096 |  dest_result_addr=1152921513132334104
            // 0x0167F208: ADD x29, sp, #0x30         | X29 = (1152921513132334048 + 48) = 1152921513132334096 (0x10000001FC289C10);
            // 0x0167F20C: SUB sp, sp, #0x70          | SP = (1152921513132334048 - 112) = 1152921513132333936 (0x10000001FC289B70);
            // 0x0167F210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F214: MOV x19, x0                | X19 = 1152921513132346112 (0x10000001FC28CB00);//ML01
            // 0x0167F218: BL #0x16f59f0              | this..ctor();                           
            // 0x0167F21C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x0167F220: LDR s11, [x8, #0x954]      | S11 = 0.9;                              
            // 0x0167F224: FMOV s10, #1.00000000      | S10 = 1;                                
            // 0x0167F228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F22C: SUB x0, x29, #0x40         | X0 = (1152921513132334096 - 64) = 1152921513132334032 (0x10000001FC289BD0);
            // 0x0167F230: MOV v0.16b, v10.16b        | V0 = 1;//m1                             
            // 0x0167F234: MOV v1.16b, v10.16b        | V1 = 1;//m1                             
            // 0x0167F238: MOV v2.16b, v10.16b        | V2 = 1;//m1                             
            // 0x0167F23C: MOV v3.16b, v11.16b        | V3 = 1063675494 (0x3F666666);//ML01     
            // 0x0167F240: STP xzr, xzr, [x29, #-0x40] | stack[1152921513132334032] = 0x0;  stack[1152921513132334040] = 0x0;  //  dest_result_addr=1152921513132334032 |  dest_result_addr=1152921513132334040
            // 0x0167F244: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F248: LDUR q0, [x29, #-0x40]     | Q0 = 0x0;                               
            // 0x0167F24C: FMOV s8, wzr               | S8 = 0f;                                
            // 0x0167F250: FMOV s9, #0.50000000       | S9 = 0.5;                               
            // 0x0167F254: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F258: STR q0, [x19, #0x10]       | this._NodeConnection = new UnityEngine.Color();  //  dest_result_addr=1152921513132346128
            this._NodeConnection = 0;
            // 0x0167F25C: ADD x0, sp, #0x50          | X0 = (1152921513132333936 + 80) = 1152921513132334016 (0x10000001FC289BC0);
            // 0x0167F260: MOV v0.16b, v10.16b        | V0 = 1;//m1                             
            // 0x0167F264: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F268: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F26C: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F270: STP xzr, xzr, [sp, #0x50]  | stack[1152921513132334016] = 0x0;  stack[1152921513132334024] = 0x0;  //  dest_result_addr=1152921513132334016 |  dest_result_addr=1152921513132334024
            // 0x0167F274: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F278: LDR q0, [sp, #0x50]        | Q0 = 0x0;                               
            // 0x0167F27C: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x0167F280: ADRP x9, #0x2aa0000        | X9 = 44695552 (0x2AA0000);              
            // 0x0167F284: ADRP x10, #0x2aa0000       | X10 = 44695552 (0x2AA0000);             
            // 0x0167F288: STR q0, [x19, #0x20]       | this._UnwalkableNode = new UnityEngine.Color();  //  dest_result_addr=1152921513132346144
            this._UnwalkableNode = 0;
            // 0x0167F28C: LDR s0, [x8, #0xe68]       | S0 = 0.29;                              
            // 0x0167F290: LDR s1, [x9, #0xe6c]       | S1 = 0.454;                             
            // 0x0167F294: LDR s2, [x10, #0xe70]      | S2 = 0.741;                             
            // 0x0167F298: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F29C: ADD x0, sp, #0x40          | X0 = (1152921513132333936 + 64) = 1152921513132334000 (0x10000001FC289BB0);
            // 0x0167F2A0: MOV v3.16b, v11.16b        | V3 = 1063675494 (0x3F666666);//ML01     
            // 0x0167F2A4: STP xzr, xzr, [sp, #0x40]  | stack[1152921513132334000] = 0x0;  stack[1152921513132334008] = 0x0;  //  dest_result_addr=1152921513132334000 |  dest_result_addr=1152921513132334008
            // 0x0167F2A8: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F2AC: LDR q0, [sp, #0x40]        | Q0 = 0x0;                               
            // 0x0167F2B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F2B4: ADD x0, sp, #0x30          | X0 = (1152921513132333936 + 48) = 1152921513132333984 (0x10000001FC289BA0);
            // 0x0167F2B8: MOV v1.16b, v10.16b        | V1 = 1;//m1                             
            // 0x0167F2BC: STR q0, [x19, #0x30]       | this._BoundsHandles = new UnityEngine.Color();  //  dest_result_addr=1152921513132346160
            this._BoundsHandles = 0;
            // 0x0167F2C0: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
            // 0x0167F2C4: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F2C8: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F2CC: STP xzr, xzr, [sp, #0x30]  | stack[1152921513132333984] = 0x0;  stack[1152921513132333992] = 0x0;  //  dest_result_addr=1152921513132333984 |  dest_result_addr=1152921513132333992
            // 0x0167F2D0: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F2D4: LDR q0, [sp, #0x30]        | Q0 = 0x0;                               
            // 0x0167F2D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F2DC: ADD x0, sp, #0x20          | X0 = (1152921513132333936 + 32) = 1152921513132333968 (0x10000001FC289B90);
            // 0x0167F2E0: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F2E4: STR q0, [x19, #0x40]       | this._ConnectionLowLerp = new UnityEngine.Color();  //  dest_result_addr=1152921513132346176
            this._ConnectionLowLerp = 0;
            // 0x0167F2E8: MOV v0.16b, v10.16b        | V0 = 1;//m1                             
            // 0x0167F2EC: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F2F0: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F2F4: STP xzr, xzr, [sp, #0x20]  | stack[1152921513132333968] = 0x0;  stack[1152921513132333976] = 0x0;  //  dest_result_addr=1152921513132333968 |  dest_result_addr=1152921513132333976
            // 0x0167F2F8: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F2FC: LDR q0, [sp, #0x20]        | Q0 = 0x0;                               
            // 0x0167F300: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F304: ADD x0, sp, #0x10          | X0 = (1152921513132333936 + 16) = 1152921513132333952 (0x10000001FC289B80);
            // 0x0167F308: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F30C: STR q0, [x19, #0x50]       | this._ConnectionHighLerp = new UnityEngine.Color();  //  dest_result_addr=1152921513132346192
            this._ConnectionHighLerp = 0;
            // 0x0167F310: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
            // 0x0167F314: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F318: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F31C: STP xzr, xzr, [sp, #0x10]  | stack[1152921513132333952] = 0x0;  stack[1152921513132333960] = 0x0;  //  dest_result_addr=1152921513132333952 |  dest_result_addr=1152921513132333960
            // 0x0167F320: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F324: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
            // 0x0167F328: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x0167F32C: ADRP x9, #0x2aa0000        | X9 = 44695552 (0x2AA0000);              
            // 0x0167F330: LDR s1, [x8, #0xe74]       | S1 = 0.686;                             
            // 0x0167F334: LDR s3, [x9, #0xe78]       | S3 = 0.19;                              
            // 0x0167F338: STR q0, [x19, #0x60]       | this._MeshEdgeColor = new UnityEngine.Color();  //  dest_result_addr=1152921513132346208
            this._MeshEdgeColor = 0;
            // 0x0167F33C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F340: FMOV s0, #0.12500000       | S0 = 0.125;                             
            // 0x0167F344: MOV x0, sp                 | X0 = 1152921513132333936 (0x10000001FC289B70);//ML01
            // 0x0167F348: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F34C: STP xzr, xzr, [sp]         | stack[1152921513132333936] = 0x0;  stack[1152921513132333944] = 0x0;  //  dest_result_addr=1152921513132333936 |  dest_result_addr=1152921513132333944
            // 0x0167F350: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F354: LDR q0, [sp]               | Q0 = 0x0;                               
            // 0x0167F358: STR q0, [x19, #0x70]       | this._MeshColor = new UnityEngine.Color();  //  dest_result_addr=1152921513132346224
            this._MeshColor = 0;
            // 0x0167F35C: SUB sp, x29, #0x30         | SP = (1152921513132334096 - 48) = 1152921513132334048 (0x10000001FC289BE0);
            // 0x0167F360: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F364: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0167F368: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0167F36C: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x0167F370: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F374 (23589748), len: 272  VirtAddr: 0x0167F374 RVA: 0x0167F374 token: 100681810 methodIndex: 49757 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Color GetAreaColor(uint area)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            UnityEngine.Color[] val_4;
            //  | 
            var val_5;
            // 0x0167F374: STP x22, x21, [sp, #-0x30]! | stack[1152921513132446064] = ???;  stack[1152921513132446072] = ???;  //  dest_result_addr=1152921513132446064 |  dest_result_addr=1152921513132446072
            // 0x0167F378: STP x20, x19, [sp, #0x10]  | stack[1152921513132446080] = ???;  stack[1152921513132446088] = ???;  //  dest_result_addr=1152921513132446080 |  dest_result_addr=1152921513132446088
            // 0x0167F37C: STP x29, x30, [sp, #0x20]  | stack[1152921513132446096] = ???;  stack[1152921513132446104] = ???;  //  dest_result_addr=1152921513132446096 |  dest_result_addr=1152921513132446104
            // 0x0167F380: ADD x29, sp, #0x20         | X29 = (1152921513132446064 + 32) = 1152921513132446096 (0x10000001FC2A5190);
            // 0x0167F384: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167F388: LDRB w8, [x20, #0xb1]      | W8 = (bool)static_value_037380B1;       
            // 0x0167F38C: MOV w19, w1                | W19 = W1;//m1                           
            // 0x0167F390: TBNZ w8, #0, #0x167f3ac    | if (static_value_037380B1 == true) goto label_0;
            // 0x0167F394: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x0167F398: LDR x8, [x8, #0x30]        | X8 = 0x2B8EBE0;                         
            // 0x0167F39C: LDR w0, [x8]               | W0 = 0x11B8;                            
            // 0x0167F3A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B8, ????);     
            // 0x0167F3A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167F3A8: STRB w8, [x20, #0xb1]      | static_value_037380B1 = true;            //  dest_result_addr=57901233
            label_0:
            // 0x0167F3AC: ADRP x20, #0x3646000       | X20 = 56909824 (0x3646000);             
            // 0x0167F3B0: LDR x20, [x20, #0x100]     | X20 = 1152921504836079616;              
            // 0x0167F3B4: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarColor);    
            val_3 = null;
            // 0x0167F3B8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarColor.__il2cppRuntimeField_10A;
            // 0x0167F3BC: TBZ w8, #0, #0x167f3d0     | if (Pathfinding.AstarColor.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167F3C0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished;
            // 0x0167F3C4: CBNZ w8, #0x167f3d0        | if (Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167F3C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarColor), ????);
            // 0x0167F3CC: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarColor);    
            val_3 = null;
            label_2:
            // 0x0167F3D0: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F3D4: LDR x8, [x8, #0x70]        | X8 = Pathfinding.AstarColor.AreaColors; 
            val_4 = Pathfinding.AstarColor.AreaColors;
            // 0x0167F3D8: CBZ x8, #0x167f464         | if (Pathfinding.AstarColor.AreaColors == null) goto label_7;
            if(val_4 == null)
            {
                goto label_7;
            }
            // 0x0167F3DC: LDRB w9, [x0, #0x10a]      | W9 = Pathfinding.AstarColor.__il2cppRuntimeField_10A;
            // 0x0167F3E0: TBZ w9, #0, #0x167f400     | if (Pathfinding.AstarColor.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0167F3E4: LDR w9, [x0, #0xbc]        | W9 = Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished;
            // 0x0167F3E8: CBNZ w9, #0x167f400        | if (Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0167F3EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarColor), ????);
            // 0x0167F3F0: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F3F4: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F3F8: LDR x8, [x8, #0x70]        | X8 = Pathfinding.AstarColor.AreaColors; 
            val_4 = Pathfinding.AstarColor.AreaColors;
            // 0x0167F3FC: CBZ x8, #0x167f480         | if (Pathfinding.AstarColor.AreaColors == null) goto label_6;
            if(val_4 == null)
            {
                goto label_6;
            }
            label_5:
            // 0x0167F400: LDRSW x8, [x8, #0x18]      | X8 = Pathfinding.AstarColor.AreaColors.Length;
            // 0x0167F404: MOV w21, w19               | W21 = W1;//m1                           
            // 0x0167F408: CMP x21, x8                | STATE = COMPARE(W1, Pathfinding.AstarColor.AreaColors.Length)
            // 0x0167F40C: B.GE #0x167f464            | if (W1 >= Pathfinding.AstarColor.AreaColors.Length) goto label_7;
            if(W1 >= Pathfinding.AstarColor.AreaColors.Length)
            {
                goto label_7;
            }
            // 0x0167F410: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarColor);    
            val_5 = null;
            // 0x0167F414: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarColor.__il2cppRuntimeField_10A;
            // 0x0167F418: TBZ w8, #0, #0x167f42c     | if (Pathfinding.AstarColor.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x0167F41C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished;
            // 0x0167F420: CBNZ w8, #0x167f42c        | if (Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x0167F424: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarColor), ????);
            // 0x0167F428: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarColor);    
            val_5 = null;
            label_9:
            // 0x0167F42C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F430: LDR x20, [x8, #0x70]       | X20 = Pathfinding.AstarColor.AreaColors;
            // 0x0167F434: CBNZ x20, #0x167f43c       | if (Pathfinding.AstarColor.AreaColors != null) goto label_10;
            if(Pathfinding.AstarColor.AreaColors != null)
            {
                goto label_10;
            }
            // 0x0167F438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarColor), ????);
            label_10:
            // 0x0167F43C: LDR w8, [x20, #0x18]       | W8 = Pathfinding.AstarColor.AreaColors.Length;
            // 0x0167F440: CMP w8, w19                | STATE = COMPARE(Pathfinding.AstarColor.AreaColors.Length, W1)
            // 0x0167F444: B.HI #0x167f454            | if (Pathfinding.AstarColor.AreaColors.Length > W1) goto label_11;
            if(Pathfinding.AstarColor.AreaColors.Length > W1)
            {
                goto label_11;
            }
            // 0x0167F448: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.AstarColor), ????);
            // 0x0167F44C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F450: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.AstarColor), ????);
            label_11:
            // 0x0167F454: ADD x8, x20, x21, lsl #4   | X8 = (Pathfinding.AstarColor.AreaColors + (W1) << 4);
            UnityEngine.Color[] val_1 = Pathfinding.AstarColor.AreaColors + ((W1) << 4);
            // 0x0167F458: LDP s0, s1, [x8, #0x20]    | S0 = (Pathfinding.AstarColor.AreaColors + (W1) << 4) + 32; S1 = (Pathfinding.AstarColor.AreaColors + (W1) << 4) + 32 + 4; //  not_find_field!2:32 |  not_find_field!2:36
            // 0x0167F45C: LDP s2, s3, [x8, #0x28]    | S2 = (Pathfinding.AstarColor.AreaColors + (W1) << 4) + 40; S3 = (Pathfinding.AstarColor.AreaColors + (W1) << 4) + 40 + 4; //  not_find_field!2:40 |  not_find_field!2:44
            // 0x0167F460: B #0x167f470               |  goto label_12;                         
            goto label_12;
            label_7:
            // 0x0167F464: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x0167F468: MOV w1, w19                | W1 = W1;//m1                            
            // 0x0167F46C: BL #0x167f484              | X0 = Pathfinding.AstarMath.IntToColor(i:  229232640, a:  1f);
            UnityEngine.Color val_2 = Pathfinding.AstarMath.IntToColor(i:  229232640, a:  1f);
            label_12:
            // 0x0167F470: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F474: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0167F478: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0167F47C: RET                        |  return new UnityEngine.Color() {r = val_2.r, g = val_2.g, b = val_2.b, a = val_2.a};
            return new UnityEngine.Color() {r = val_2.r, g = val_2.g, b = val_2.b, a = val_2.a};
            //  |  // // {name=val_0.r, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.g, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.b, type=System.Single, size=4, nSRN=2 }
            //  |  // // {name=val_0.a, type=System.Single, size=4, nSRN=3 }
            label_6:
            // 0x0167F480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarColor), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F500 (23590144), len: 344  VirtAddr: 0x0167F500 RVA: 0x0167F500 token: 100681811 methodIndex: 49758 delegateWrapperIndex: 0 methodInvoker: 0
        public void OnEnable()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0167F500: STP x24, x23, [sp, #-0x40]! | stack[1152921513132594912] = ???;  stack[1152921513132594920] = ???;  //  dest_result_addr=1152921513132594912 |  dest_result_addr=1152921513132594920
            // 0x0167F504: STP x22, x21, [sp, #0x10]  | stack[1152921513132594928] = ???;  stack[1152921513132594936] = ???;  //  dest_result_addr=1152921513132594928 |  dest_result_addr=1152921513132594936
            // 0x0167F508: STP x20, x19, [sp, #0x20]  | stack[1152921513132594944] = ???;  stack[1152921513132594952] = ???;  //  dest_result_addr=1152921513132594944 |  dest_result_addr=1152921513132594952
            // 0x0167F50C: STP x29, x30, [sp, #0x30]  | stack[1152921513132594960] = ???;  stack[1152921513132594968] = ???;  //  dest_result_addr=1152921513132594960 |  dest_result_addr=1152921513132594968
            // 0x0167F510: ADD x29, sp, #0x30         | X29 = (1152921513132594912 + 48) = 1152921513132594960 (0x10000001FC2C9710);
            // 0x0167F514: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167F518: LDRB w8, [x20, #0xb2]      | W8 = (bool)static_value_037380B2;       
            // 0x0167F51C: MOV x19, x0                | X19 = 1152921513132606976 (0x10000001FC2CC600);//ML01
            // 0x0167F520: TBNZ w8, #0, #0x167f53c    | if (static_value_037380B2 == true) goto label_0;
            // 0x0167F524: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x0167F528: LDR x8, [x8, #0x110]       | X8 = 0x2B8EBE4;                         
            // 0x0167F52C: LDR w0, [x8]               | W0 = 0x11B9;                            
            // 0x0167F530: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B9, ????);     
            // 0x0167F534: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167F538: STRB w8, [x20, #0xb2]      | static_value_037380B2 = true;            //  dest_result_addr=57901234
            label_0:
            // 0x0167F53C: ADRP x20, #0x3646000       | X20 = 56909824 (0x3646000);             
            // 0x0167F540: LDR x20, [x20, #0x100]     | X20 = 1152921504836079616;              
            // 0x0167F544: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarColor);    
            val_1 = null;
            // 0x0167F548: LDP w24, w23, [x19, #0x10] | W24 = this._NodeConnection; //P2         //  | 
            // 0x0167F54C: LDP w22, w21, [x19, #0x18] |                                          //  | 
            // 0x0167F550: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarColor.__il2cppRuntimeField_10A;
            // 0x0167F554: TBZ w8, #0, #0x167f568     | if (Pathfinding.AstarColor.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167F558: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished;
            // 0x0167F55C: CBNZ w8, #0x167f568        | if (Pathfinding.AstarColor.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167F560: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarColor), ????);
            // 0x0167F564: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarColor);    
            val_1 = null;
            label_2:
            // 0x0167F568: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F56C: STP w24, w23, [x8]         | Pathfinding.AstarColor.NodeConnection = this._NodeConnection;  Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_4 = ???;  //  dest_result_addr=1152921504836083712 |  dest_result_addr=1152921504836083716
            Pathfinding.AstarColor.NodeConnection = this._NodeConnection;
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_4 = ???;
            // 0x0167F570: STP w22, w21, [x8, #8]     | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_8 = ???;  Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_C = ???;  //  dest_result_addr=1152921504836083720 |  dest_result_addr=1152921504836083724
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_8 = ???;
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_C = ???;
            // 0x0167F574: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F578: LDR w11, [x19, #0x2c]      | 
            // 0x0167F57C: LDR w9, [x19, #0x20]       | W9 = this._UnwalkableNode; //P2         
            // 0x0167F580: LDUR x10, [x19, #0x24]     | 
            // 0x0167F584: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F588: STR w11, [x8, #0x1c]       | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_1C = ???;  //  dest_result_addr=1152921504836083740
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_1C = ???;
            // 0x0167F58C: STR w9, [x8, #0x10]        | Pathfinding.AstarColor.UnwalkableNode = this._UnwalkableNode;  //  dest_result_addr=1152921504836083728
            Pathfinding.AstarColor.UnwalkableNode = this._UnwalkableNode;
            // 0x0167F590: STUR x10, [x8, #0x14]      | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_14 = ???;  //  dest_result_addr=1152921504836083732
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_14 = ???;
            // 0x0167F594: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F598: LDR w11, [x19, #0x3c]      | 
            // 0x0167F59C: LDR w9, [x19, #0x30]       | W9 = this._BoundsHandles; //P2          
            // 0x0167F5A0: LDUR x10, [x19, #0x34]     | 
            // 0x0167F5A4: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F5A8: STR w11, [x8, #0x2c]       | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_2C = ???;  //  dest_result_addr=1152921504836083756
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_2C = ???;
            // 0x0167F5AC: STR w9, [x8, #0x20]        | Pathfinding.AstarColor.BoundsHandles = this._BoundsHandles;  //  dest_result_addr=1152921504836083744
            Pathfinding.AstarColor.BoundsHandles = this._BoundsHandles;
            // 0x0167F5B0: STUR x10, [x8, #0x24]      | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_24 = ???;  //  dest_result_addr=1152921504836083748
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_24 = ???;
            // 0x0167F5B4: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F5B8: LDR w11, [x19, #0x4c]      | 
            // 0x0167F5BC: LDR w9, [x19, #0x40]       | W9 = this._ConnectionLowLerp; //P2      
            // 0x0167F5C0: LDUR x10, [x19, #0x44]     | 
            // 0x0167F5C4: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F5C8: STR w11, [x8, #0x3c]       | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_3C = ???;  //  dest_result_addr=1152921504836083772
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_3C = ???;
            // 0x0167F5CC: STR w9, [x8, #0x30]        | Pathfinding.AstarColor.ConnectionLowLerp = this._ConnectionLowLerp;  //  dest_result_addr=1152921504836083760
            Pathfinding.AstarColor.ConnectionLowLerp = this._ConnectionLowLerp;
            // 0x0167F5D0: STUR x10, [x8, #0x34]      | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_34 = ???;  //  dest_result_addr=1152921504836083764
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_34 = ???;
            // 0x0167F5D4: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F5D8: LDR w11, [x19, #0x5c]      | 
            // 0x0167F5DC: LDR w9, [x19, #0x50]       | W9 = this._ConnectionHighLerp; //P2     
            // 0x0167F5E0: LDUR x10, [x19, #0x54]     | 
            // 0x0167F5E4: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F5E8: STR w11, [x8, #0x4c]       | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_4C = ???;  //  dest_result_addr=1152921504836083788
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_4C = ???;
            // 0x0167F5EC: STR w9, [x8, #0x40]        | Pathfinding.AstarColor.ConnectionHighLerp = this._ConnectionHighLerp;  //  dest_result_addr=1152921504836083776
            Pathfinding.AstarColor.ConnectionHighLerp = this._ConnectionHighLerp;
            // 0x0167F5F0: STUR x10, [x8, #0x44]      | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_44 = ???;  //  dest_result_addr=1152921504836083780
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_44 = ???;
            // 0x0167F5F4: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F5F8: LDR w11, [x19, #0x6c]      | 
            // 0x0167F5FC: LDR w9, [x19, #0x60]       | W9 = this._MeshEdgeColor; //P2          
            // 0x0167F600: LDUR x10, [x19, #0x64]     | 
            // 0x0167F604: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F608: STR w11, [x8, #0x5c]       | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_5C = ???;  //  dest_result_addr=1152921504836083804
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_5C = ???;
            // 0x0167F60C: STR w9, [x8, #0x50]        | Pathfinding.AstarColor.MeshEdgeColor = this._MeshEdgeColor;  //  dest_result_addr=1152921504836083792
            Pathfinding.AstarColor.MeshEdgeColor = this._MeshEdgeColor;
            // 0x0167F610: STUR x10, [x8, #0x54]      | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_54 = ???;  //  dest_result_addr=1152921504836083796
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_54 = ???;
            // 0x0167F614: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F618: LDR w11, [x19, #0x7c]      | 
            // 0x0167F61C: LDR w9, [x19, #0x70]       | W9 = this._MeshColor; //P2              
            // 0x0167F620: LDUR x10, [x19, #0x74]     | 
            // 0x0167F624: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F628: STR w11, [x8, #0x6c]       | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_6C = ???;  //  dest_result_addr=1152921504836083820
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_6C = ???;
            // 0x0167F62C: STR w9, [x8, #0x60]        | Pathfinding.AstarColor.MeshColor = this._MeshColor;  //  dest_result_addr=1152921504836083808
            Pathfinding.AstarColor.MeshColor = this._MeshColor;
            // 0x0167F630: STUR x10, [x8, #0x64]      | Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_64 = ???;  //  dest_result_addr=1152921504836083812
            Pathfinding.AstarColor.NodeConnection.__il2cppRuntimeField_64 = ???;
            // 0x0167F634: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F638: LDR x9, [x19, #0x80]       | X9 = this._AreaColors; //P2             
            // 0x0167F63C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F640: STR x9, [x8, #0x70]        | Pathfinding.AstarColor.AreaColors = this._AreaColors;  //  dest_result_addr=1152921504836083824
            Pathfinding.AstarColor.AreaColors = this._AreaColors;
            // 0x0167F644: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F648: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0167F64C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0167F650: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0167F654: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F658 (23590488), len: 460  VirtAddr: 0x0167F658 RVA: 0x0167F658 token: 100681812 methodIndex: 49759 delegateWrapperIndex: 0 methodInvoker: 0
        private static AstarColor()
        {
            //
            // Disasemble & Code
            // 0x0167F658: STP d11, d10, [sp, #-0x40]! | stack[1152921513132743776] = ???;  stack[1152921513132743784] = ???;  //  dest_result_addr=1152921513132743776 |  dest_result_addr=1152921513132743784
            // 0x0167F65C: STP d9, d8, [sp, #0x10]    | stack[1152921513132743792] = ???;  stack[1152921513132743800] = ???;  //  dest_result_addr=1152921513132743792 |  dest_result_addr=1152921513132743800
            // 0x0167F660: STP x20, x19, [sp, #0x20]  | stack[1152921513132743808] = ???;  stack[1152921513132743816] = ???;  //  dest_result_addr=1152921513132743808 |  dest_result_addr=1152921513132743816
            // 0x0167F664: STP x29, x30, [sp, #0x30]  | stack[1152921513132743824] = ???;  stack[1152921513132743832] = ???;  //  dest_result_addr=1152921513132743824 |  dest_result_addr=1152921513132743832
            // 0x0167F668: ADD x29, sp, #0x30         | X29 = (1152921513132743776 + 48) = 1152921513132743824 (0x10000001FC2EDC90);
            // 0x0167F66C: SUB sp, sp, #0x70          | SP = (1152921513132743776 - 112) = 1152921513132743664 (0x10000001FC2EDBF0);
            // 0x0167F670: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167F674: LDRB w8, [x19, #0xb3]      | W8 = (bool)static_value_037380B3;       
            // 0x0167F678: TBNZ w8, #0, #0x167f694    | if (static_value_037380B3 == true) goto label_0;
            // 0x0167F67C: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x0167F680: LDR x8, [x8, #0x5d0]       | X8 = 0x2B8EBDC;                         
            // 0x0167F684: LDR w0, [x8]               | W0 = 0x11B7;                            
            // 0x0167F688: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B7, ????);     
            // 0x0167F68C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167F690: STRB w8, [x19, #0xb3]      | static_value_037380B3 = true;            //  dest_result_addr=57901235
            label_0:
            // 0x0167F694: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x0167F698: LDR s11, [x8, #0x954]      | S11 = 0.9;                              
            // 0x0167F69C: FMOV s10, #1.00000000      | S10 = 1;                                
            // 0x0167F6A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F6A4: SUB x0, x29, #0x40         | X0 = (1152921513132743824 - 64) = 1152921513132743760 (0x10000001FC2EDC50);
            // 0x0167F6A8: MOV v0.16b, v10.16b        | V0 = 1;//m1                             
            // 0x0167F6AC: MOV v1.16b, v10.16b        | V1 = 1;//m1                             
            // 0x0167F6B0: MOV v2.16b, v10.16b        | V2 = 1;//m1                             
            // 0x0167F6B4: MOV v3.16b, v11.16b        | V3 = 1063675494 (0x3F666666);//ML01     
            // 0x0167F6B8: STP xzr, xzr, [x29, #-0x40] | stack[1152921513132743760] = 0x0;  stack[1152921513132743768] = 0x0;  //  dest_result_addr=1152921513132743760 |  dest_result_addr=1152921513132743768
            // 0x0167F6BC: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F6C0: ADRP x19, #0x3646000       | X19 = 56909824 (0x3646000);             
            // 0x0167F6C4: LDR x19, [x19, #0x100]     | X19 = 1152921504836079616;              
            // 0x0167F6C8: LDUR q0, [x29, #-0x40]     | Q0 = 0x0;                               
            // 0x0167F6CC: FMOV s8, wzr               | S8 = 0f;                                
            // 0x0167F6D0: FMOV s9, #0.50000000       | S9 = 0.5;                               
            // 0x0167F6D4: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F6D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F6DC: ADD x0, sp, #0x50          | X0 = (1152921513132743664 + 80) = 1152921513132743744 (0x10000001FC2EDC40);
            // 0x0167F6E0: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F6E4: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F6E8: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F6EC: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F6F0: STR q0, [x8]               | Pathfinding.AstarColor.NodeConnection = new UnityEngine.Color();  //  dest_result_addr=1152921504836083712
            Pathfinding.AstarColor.NodeConnection = 0;
            // 0x0167F6F4: MOV v0.16b, v10.16b        | V0 = 1;//m1                             
            // 0x0167F6F8: STP xzr, xzr, [sp, #0x50]  | stack[1152921513132743744] = 0x0;  stack[1152921513132743752] = 0x0;  //  dest_result_addr=1152921513132743744 |  dest_result_addr=1152921513132743752
            // 0x0167F6FC: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F700: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F704: LDR q0, [sp, #0x50]        | Q0 = 0x0;                               
            // 0x0167F708: ADRP x9, #0x2aa0000        | X9 = 44695552 (0x2AA0000);              
            // 0x0167F70C: ADRP x10, #0x2aa0000       | X10 = 44695552 (0x2AA0000);             
            // 0x0167F710: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F714: LDR s1, [x9, #0xe6c]       | S1 = 0.454;                             
            // 0x0167F718: LDR s2, [x10, #0xe70]      | S2 = 0.741;                             
            // 0x0167F71C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F720: STR q0, [x8, #0x10]        | Pathfinding.AstarColor.UnwalkableNode = new UnityEngine.Color();  //  dest_result_addr=1152921504836083728
            Pathfinding.AstarColor.UnwalkableNode = 0;
            // 0x0167F724: ADRP x8, #0x2aa0000        | X8 = 44695552 (0x2AA0000);              
            // 0x0167F728: LDR s0, [x8, #0xe68]       | S0 = 0.29;                              
            // 0x0167F72C: ADD x0, sp, #0x40          | X0 = (1152921513132743664 + 64) = 1152921513132743728 (0x10000001FC2EDC30);
            // 0x0167F730: MOV v3.16b, v11.16b        | V3 = 1063675494 (0x3F666666);//ML01     
            // 0x0167F734: STP xzr, xzr, [sp, #0x40]  | stack[1152921513132743728] = 0x0;  stack[1152921513132743736] = 0x0;  //  dest_result_addr=1152921513132743728 |  dest_result_addr=1152921513132743736
            // 0x0167F738: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F73C: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F740: LDR q0, [sp, #0x40]        | Q0 = 0x0;                               
            // 0x0167F744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F748: ADD x0, sp, #0x30          | X0 = (1152921513132743664 + 48) = 1152921513132743712 (0x10000001FC2EDC20);
            // 0x0167F74C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F750: MOV v1.16b, v10.16b        | V1 = 1;//m1                             
            // 0x0167F754: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F758: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F75C: STR q0, [x8, #0x20]        | Pathfinding.AstarColor.BoundsHandles = new UnityEngine.Color();  //  dest_result_addr=1152921504836083744
            Pathfinding.AstarColor.BoundsHandles = 0;
            // 0x0167F760: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
            // 0x0167F764: STP xzr, xzr, [sp, #0x30]  | stack[1152921513132743712] = 0x0;  stack[1152921513132743720] = 0x0;  //  dest_result_addr=1152921513132743712 |  dest_result_addr=1152921513132743720
            // 0x0167F768: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F76C: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F770: LDR q0, [sp, #0x30]        | Q0 = 0x0;                               
            // 0x0167F774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F778: ADD x0, sp, #0x20          | X0 = (1152921513132743664 + 32) = 1152921513132743696 (0x10000001FC2EDC10);
            // 0x0167F77C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F780: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F784: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F788: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F78C: STR q0, [x8, #0x30]        | Pathfinding.AstarColor.ConnectionLowLerp = new UnityEngine.Color();  //  dest_result_addr=1152921504836083760
            Pathfinding.AstarColor.ConnectionLowLerp = 0;
            // 0x0167F790: MOV v0.16b, v10.16b        | V0 = 1;//m1                             
            // 0x0167F794: STP xzr, xzr, [sp, #0x20]  | stack[1152921513132743696] = 0x0;  stack[1152921513132743704] = 0x0;  //  dest_result_addr=1152921513132743696 |  dest_result_addr=1152921513132743704
            // 0x0167F798: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F79C: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F7A0: LDR q0, [sp, #0x20]        | Q0 = 0x0;                               
            // 0x0167F7A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F7A8: ADD x0, sp, #0x10          | X0 = (1152921513132743664 + 16) = 1152921513132743680 (0x10000001FC2EDC00);
            // 0x0167F7AC: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F7B0: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F7B4: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F7B8: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F7BC: STR q0, [x8, #0x40]        | Pathfinding.AstarColor.ConnectionHighLerp = new UnityEngine.Color();  //  dest_result_addr=1152921504836083776
            Pathfinding.AstarColor.ConnectionHighLerp = 0;
            // 0x0167F7C0: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
            // 0x0167F7C4: STP xzr, xzr, [sp, #0x10]  | stack[1152921513132743680] = 0x0;  stack[1152921513132743688] = 0x0;  //  dest_result_addr=1152921513132743680 |  dest_result_addr=1152921513132743688
            // 0x0167F7C8: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F7CC: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F7D0: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
            // 0x0167F7D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F7D8: MOV x0, sp                 | X0 = 1152921513132743664 (0x10000001FC2EDBF0);//ML01
            // 0x0167F7DC: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F7E0: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
            // 0x0167F7E4: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
            // 0x0167F7E8: MOV v3.16b, v9.16b         | V3 = 0.5;//m1                           
            // 0x0167F7EC: STR q0, [x8, #0x50]        | Pathfinding.AstarColor.MeshEdgeColor = new UnityEngine.Color();  //  dest_result_addr=1152921504836083792
            Pathfinding.AstarColor.MeshEdgeColor = 0;
            // 0x0167F7F0: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
            // 0x0167F7F4: STP xzr, xzr, [sp]         | stack[1152921513132743664] = 0x0;  stack[1152921513132743672] = 0x0;  //  dest_result_addr=1152921513132743664 |  dest_result_addr=1152921513132743672
            // 0x0167F7F8: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0167F7FC: LDR x8, [x19]              | X8 = typeof(Pathfinding.AstarColor);    
            // 0x0167F800: LDR q0, [sp]               | Q0 = 0x0;                               
            // 0x0167F804: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarColor.__il2cppRuntimeField_static_fields;
            // 0x0167F808: STR q0, [x8, #0x60]        | Pathfinding.AstarColor.MeshColor = new UnityEngine.Color();  //  dest_result_addr=1152921504836083808
            Pathfinding.AstarColor.MeshColor = 0;
            // 0x0167F80C: SUB sp, x29, #0x30         | SP = (1152921513132743824 - 48) = 1152921513132743776 (0x10000001FC2EDC60);
            // 0x0167F810: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F814: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0167F818: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0167F81C: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
            // 0x0167F820: RET                        |  return;                                
            return;
        
        }
    
    }

}
