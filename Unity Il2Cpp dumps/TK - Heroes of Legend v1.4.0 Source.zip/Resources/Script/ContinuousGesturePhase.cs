using UnityEngine;
public enum ContinuousGesturePhase
{
    // Fields
    None = 0
    ,Started = 1
    ,Updated = 2
    ,Ended = 3
    

}
