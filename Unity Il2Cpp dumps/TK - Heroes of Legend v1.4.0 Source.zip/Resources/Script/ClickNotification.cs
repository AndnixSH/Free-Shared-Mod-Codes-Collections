using UnityEngine;
public enum UICamera.ClickNotification
{
    // Fields
    None = 0
    ,Always = 1
    ,BasedOnDelta = 2
    

}
