using UnityEngine;

namespace wxb
{
    [System.AttributeUsageAttribute] // 0x28597BC
    public class AutoInitAndRelease : Attribute
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2CA3C (14862908), len: 8  VirtAddr: 0x00E2CA3C RVA: 0x00E2CA3C token: 100680967 methodIndex: 57246 delegateWrapperIndex: 0 methodInvoker: 0
        public AutoInitAndRelease()
        {
            //
            // Disasemble & Code
            // 0x00E2CA3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2CA40: B #0x18d1dd4               | this..ctor(); return;                   
            return;
        
        }
    
    }

}
