using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CHECK_POINT_STATE_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0143B768 (21215080), len: 8  VirtAddr: 0x0143B768 RVA: 0x0143B768 token: 100664216 methodIndex: 30263 delegateWrapperIndex: 0 methodInvoker: 0
        public CHECK_POINT_STATE_Binding()
        {
            //
            // Disasemble & Code
            // 0x0143B768: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B76C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0143B770 (21215088), len: 872  VirtAddr: 0x0143B770 RVA: 0x0143B770 token: 100664217 methodIndex: 30264 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_7;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_9;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_10;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_11;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_12;
            // 0x0143B770: STP x24, x23, [sp, #-0x40]! | stack[1152921510121078656] = ???;  stack[1152921510121078664] = ???;  //  dest_result_addr=1152921510121078656 |  dest_result_addr=1152921510121078664
            // 0x0143B774: STP x22, x21, [sp, #0x10]  | stack[1152921510121078672] = ???;  stack[1152921510121078680] = ???;  //  dest_result_addr=1152921510121078672 |  dest_result_addr=1152921510121078680
            // 0x0143B778: STP x20, x19, [sp, #0x20]  | stack[1152921510121078688] = ???;  stack[1152921510121078696] = ???;  //  dest_result_addr=1152921510121078688 |  dest_result_addr=1152921510121078696
            // 0x0143B77C: STP x29, x30, [sp, #0x30]  | stack[1152921510121078704] = ???;  stack[1152921510121078712] = ???;  //  dest_result_addr=1152921510121078704 |  dest_result_addr=1152921510121078712
            // 0x0143B780: ADD x29, sp, #0x30         | X29 = (1152921510121078656 + 48) = 1152921510121078704 (0x1000000148AC7FB0);
            // 0x0143B784: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143B788: LDRB w8, [x20, #0x73]      | W8 = (bool)static_value_03737073;       
            // 0x0143B78C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143B790: TBNZ w8, #0, #0x143b7ac    | if (static_value_03737073 == true) goto label_0;
            // 0x0143B794: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x0143B798: LDR x8, [x8, #0xce0]       | X8 = 0x2B90684;                         
            // 0x0143B79C: LDR w0, [x8]               | W0 = 0x1865;                            
            // 0x0143B7A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1865, ????);     
            // 0x0143B7A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143B7A8: STRB w8, [x20, #0x73]      | static_value_03737073 = true;            //  dest_result_addr=57897075
            label_0:
            // 0x0143B7AC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143B7B0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143B7B4: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0143B7B8: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x0143B7BC: LDR x8, [x8, #0xce8]       | X8 = 1152921504897101824;               
            // 0x0143B7C0: LDR x20, [x8]              | X20 = typeof(CHECK_POINT_STATE);        
            // 0x0143B7C4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143B7C8: TBZ w8, #0, #0x143b7d8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0143B7CC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143B7D0: CBNZ w8, #0x143b7d8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0143B7D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0143B7D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143B7DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143B7E0: MOV x1, x20                | X1 = 1152921504897101824 (0x10000000114CF000);//ML01
            // 0x0143B7E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143B7E8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x0143B7EC: CBNZ x20, #0x143b7f4       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x0143B7F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x0143B7F4: ADRP x9, #0x367e000        | X9 = 57139200 (0x367E000);              
            // 0x0143B7F8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0143B7FC: LDR x9, [x9, #0x238]       | X9 = (string**)(1152921510121061312)("CPS_UNLOCK");
            // 0x0143B800: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143B804: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143B808: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x0143B80C: LDR x1, [x9]               | X1 = "CPS_UNLOCK";                      
            // 0x0143B810: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0143B814: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143B818: ADRP x24, #0x3605000       | X24 = 56643584 (0x3605000);             
            // 0x0143B81C: LDR x24, [x24, #0x388]     | X24 = 1152921504783896576;              
            // 0x0143B820: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x0143B824: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B828: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B82C: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache0;
            val_7 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache0;
            // 0x0143B830: CBNZ x22, #0x143b87c       | if (ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_7 != null)
            {
                goto label_4;
            }
            // 0x0143B834: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x0143B838: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0143B83C: LDR x8, [x8, #0x940]       | X8 = 1152921510121061408;               
            // 0x0143B840: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0143B844: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_UNLOCK_0(ref object o);
            // 0x0143B848: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x0143B84C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143B850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B854: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B858: MOV x2, x22                | X2 = 1152921510121061408 (0x1000000148AC3C20);//ML01
            // 0x0143B85C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_8 = val_2;
            // 0x0143B860: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_UNLOCK_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_UNLOCK_0(ref object o));
            // 0x0143B864: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B868: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B86C: STR x23, [x8]              | ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783900672
            ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache0 = val_8;
            // 0x0143B870: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B874: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B878: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_7 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache0;
            label_4:
            // 0x0143B87C: CBNZ x19, #0x143b884       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x0143B880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_UNLOCK_0(ref object o)), ????);
            label_5:
            // 0x0143B884: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B888: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B88C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143B890: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0143B894: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_7);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_7);
            // 0x0143B898: CBNZ x20, #0x143b8a0       | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x0143B89C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_6:
            // 0x0143B8A0: ADRP x9, #0x3655000        | X9 = 56971264 (0x3655000);              
            // 0x0143B8A4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0143B8A8: LDR x9, [x9, #0x9c0]       | X9 = (string**)(1152921510121062432)("CPS_LOCK");
            // 0x0143B8AC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143B8B0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143B8B4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x0143B8B8: LDR x1, [x9]               | X1 = "CPS_LOCK";                        
            // 0x0143B8BC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0143B8C0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143B8C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B8C8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x0143B8CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B8D0: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache1;
            val_9 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache1;
            // 0x0143B8D4: CBNZ x22, #0x143b920       | if (ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache1 != null) goto label_7;
            if(val_9 != null)
            {
                goto label_7;
            }
            // 0x0143B8D8: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x0143B8DC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0143B8E0: LDR x8, [x8, #0x670]       | X8 = 1152921510121062528;               
            // 0x0143B8E4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0143B8E8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_LOCK_1(ref object o);
            // 0x0143B8EC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_3 = null;
            // 0x0143B8F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143B8F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B8F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B8FC: MOV x2, x22                | X2 = 1152921510121062528 (0x1000000148AC4080);//ML01
            // 0x0143B900: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_8 = val_3;
            // 0x0143B904: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_LOCK_1(ref object o));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_LOCK_1(ref object o));
            // 0x0143B908: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B90C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B910: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783900680
            ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache1 = val_8;
            // 0x0143B914: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B918: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B91C: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_9 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache1;
            label_7:
            // 0x0143B920: CBNZ x19, #0x143b928       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x0143B924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_LOCK_1(ref object o)), ????);
            label_8:
            // 0x0143B928: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B92C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B930: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143B934: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0143B938: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_9);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_9);
            // 0x0143B93C: CBNZ x20, #0x143b944       | if (val_1 != null) goto label_9;        
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x0143B940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_9:
            // 0x0143B944: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x0143B948: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x0143B94C: LDR x9, [x9, #0xe60]       | X9 = (string**)(1152921510121063552)("CPS_FINISH");
            // 0x0143B950: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x0143B954: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0143B958: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x0143B95C: LDR x1, [x9]               | X1 = "CPS_FINISH";                      
            // 0x0143B960: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x0143B964: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143B968: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B96C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x0143B970: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B974: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache2;
            val_10 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache2;
            // 0x0143B978: CBNZ x22, #0x143b9c4       | if (ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache2 != null) goto label_10;
            if(val_10 != null)
            {
                goto label_10;
            }
            // 0x0143B97C: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x0143B980: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x0143B984: LDR x8, [x8, #0xa18]       | X8 = 1152921510121063648;               
            // 0x0143B988: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x0143B98C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_FINISH_2(ref object o);
            // 0x0143B990: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4 = null;
            // 0x0143B994: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143B998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143B99C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B9A0: MOV x2, x22                | X2 = 1152921510121063648 (0x1000000148AC44E0);//ML01
            // 0x0143B9A4: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_8 = val_4;
            // 0x0143B9A8: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_FINISH_2(ref object o));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_FINISH_2(ref object o));
            // 0x0143B9AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B9B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B9B4: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783900688
            ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache2 = val_8;
            // 0x0143B9B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B9BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B9C0: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_10 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__mg$cache2;
            label_10:
            // 0x0143B9C4: CBNZ x19, #0x143b9cc       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x0143B9C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::get_CPS_FINISH_2(ref object o)), ????);
            label_11:
            // 0x0143B9CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143B9D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143B9D4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143B9D8: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x0143B9DC: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_10);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_10);
            // 0x0143B9E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143B9E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143B9E8: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache0;
            val_11 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache0;
            // 0x0143B9EC: CBNZ x21, #0x143ba38       | if (ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache0 != null) goto label_12;
            if(val_11 != null)
            {
                goto label_12;
            }
            // 0x0143B9F0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x0143B9F4: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x0143B9F8: LDR x8, [x8, #0x9f8]       | X8 = 1152921510121064672;               
            // 0x0143B9FC: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x0143BA00: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__0();
            // 0x0143BA04: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_5 = null;
            // 0x0143BA08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x0143BA0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BA10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143BA14: MOV x2, x21                | X2 = 1152921510121064672 (0x1000000148AC48E0);//ML01
            // 0x0143BA18: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x0143BA1C: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__0());
            val_5 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__0());
            // 0x0143BA20: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143BA24: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143BA28: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504783900696
            ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache0 = val_5;
            // 0x0143BA2C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143BA30: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143BA34: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_11 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache0;
            label_12:
            // 0x0143BA38: CBNZ x19, #0x143ba40       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0143BA3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__0()), ????);
            label_13:
            // 0x0143BA40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143BA44: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143BA48: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x0143BA4C: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x0143BA50: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            // 0x0143BA54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143BA58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143BA5C: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache1;
            val_12 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache1;
            // 0x0143BA60: CBNZ x21, #0x143baac       | if (ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache1 != null) goto label_14;
            if(val_12 != null)
            {
                goto label_14;
            }
            // 0x0143BA64: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0143BA68: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x0143BA6C: LDR x8, [x8, #0x3a8]       | X8 = 1152921510121065696;               
            // 0x0143BA70: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x0143BA74: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__1(int s);
            // 0x0143BA78: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_6 = null;
            // 0x0143BA7C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x0143BA80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BA84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143BA88: MOV x2, x21                | X2 = 1152921510121065696 (0x1000000148AC4CE0);//ML01
            // 0x0143BA8C: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x0143BA90: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__1(int s));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__1(int s));
            // 0x0143BA94: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143BA98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143BA9C: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504783900704
            ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache1 = val_6;
            // 0x0143BAA0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding);
            // 0x0143BAA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143BAA8: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_12 = ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding.<>f__am$cache1;
            label_14:
            // 0x0143BAAC: CBNZ x19, #0x143bab4       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x0143BAB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CHECK_POINT_STATE_Binding::<Register>m__1(int s)), ????);
            label_15:
            // 0x0143BAB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x0143BAB8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x0143BABC: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x0143BAC0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0143BAC4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0143BAC8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0143BACC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143BAD0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0143BAD4: B #0x28e5bd8               | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12); return;
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0143BAD8 (21215960), len: 1644  VirtAddr: 0x0143BAD8 RVA: 0x0143BAD8 token: 100664218 methodIndex: 30265 delegateWrapperIndex: 0 methodInvoker: 0
        private static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, ILRuntime.Runtime.Stack.StackObject* ptr_of_this_method, System.Collections.Generic.IList<object> __mStack, ref CHECK_POINT_STATE instance_of_this_method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_10;
            //  | 
            var val_12;
            //  | 
            var val_20;
            //  | 
            object val_21;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            int val_26;
            // 0x0143BAD8: STP x24, x23, [sp, #-0x40]! | stack[1152921510121252032] = ???;  stack[1152921510121252040] = ???;  //  dest_result_addr=1152921510121252032 |  dest_result_addr=1152921510121252040
            // 0x0143BADC: STP x22, x21, [sp, #0x10]  | stack[1152921510121252048] = ???;  stack[1152921510121252056] = ???;  //  dest_result_addr=1152921510121252048 |  dest_result_addr=1152921510121252056
            // 0x0143BAE0: STP x20, x19, [sp, #0x20]  | stack[1152921510121252064] = ???;  stack[1152921510121252072] = ???;  //  dest_result_addr=1152921510121252064 |  dest_result_addr=1152921510121252072
            // 0x0143BAE4: STP x29, x30, [sp, #0x30]  | stack[1152921510121252080] = ???;  stack[1152921510121252088] = ???;  //  dest_result_addr=1152921510121252080 |  dest_result_addr=1152921510121252088
            // 0x0143BAE8: ADD x29, sp, #0x30         | X29 = (1152921510121252032 + 48) = 1152921510121252080 (0x1000000148AF24F0);
            // 0x0143BAEC: SUB sp, sp, #0x40          | SP = (1152921510121252032 - 64) = 1152921510121251968 (0x1000000148AF2480);
            // 0x0143BAF0: ADRP x23, #0x3737000       | X23 = 57896960 (0x3737000);             
            // 0x0143BAF4: LDRB w8, [x23, #0x74]      | W8 = (bool)static_value_03737074;       
            // 0x0143BAF8: MOV x19, x4                | X19 = X4;//m1                           
            val_21 = X4;
            // 0x0143BAFC: MOV x21, x3                | X21 = X3;//m1                           
            val_22 = X3;
            // 0x0143BB00: MOV x20, x2                | X20 = X2;//m1                           
            // 0x0143BB04: MOV x22, x1                | X22 = X1;//m1                           
            // 0x0143BB08: TBNZ w8, #0, #0x143bb24    | if (static_value_03737074 == true) goto label_0;
            // 0x0143BB0C: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x0143BB10: LDR x8, [x8, #0xc00]       | X8 = 0x2B90690;                         
            // 0x0143BB14: LDR w0, [x8]               | W0 = 0x1868;                            
            // 0x0143BB18: BL #0x2782188              | X0 = sub_2782188( ?? 0x1868, ????);     
            // 0x0143BB1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143BB20: STRB w8, [x23, #0x74]      | static_value_03737074 = true;            //  dest_result_addr=57897076
            label_0:
            // 0x0143BB24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143BB28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143BB2C: MOV x1, x20                | X1 = X2;//m1                            
            // 0x0143BB30: STR xzr, [sp, #0x18]       | stack[1152921510121251992] = 0x0;        //  dest_result_addr=1152921510121251992
            // 0x0143BB34: BL #0x1f93c50              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.GetObjectAndResolveReference(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_1 = ILRuntime.Runtime.Intepreter.ILIntepreter.GetObjectAndResolveReference(esp:  null);
            // 0x0143BB38: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x0143BB3C: CBNZ x20, #0x143bb44       | if (val_1 != 0) goto label_1;           
            if(val_1 != 0)
            {
                goto label_1;
            }
            // 0x0143BB40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x0143BB44: LDR w8, [x20]              | W8 = val_1;                             
            var val_20 = val_1;
            // 0x0143BB48: SUB w8, w8, #6             | W8 = (val_1 - 6);                       
            val_20 = val_20 - 6;
            // 0x0143BB4C: CMP w8, #5                 | STATE = COMPARE((val_1 - 6), 0x5)       
            // 0x0143BB50: B.HI #0x143c0f4            | if (val_1 > 0x5) goto label_51;         
            if(val_20 > 5)
            {
                goto label_51;
            }
            // 0x0143BB54: ADRP x9, #0x2aa0000        | X9 = 44695552 (0x2AA0000);              
            // 0x0143BB58: ADD x9, x9, #0x230         | X9 = (44695552 + 560) = 44696112 (0x02AA0230);
            // 0x0143BB5C: LDR w8, [x9, w8, sxtw #2]  | W8 = 44696112 + ((val_1 - 6)) << 2;     
            var val_21 = 44696112 + ((val_1 - 6)) << 2;
            // 0x0143BB60: SUB w8, w8, #3             | W8 = (44696112 + ((val_1 - 6)) << 2 - 3);
            val_21 = val_21 - 3;
            // 0x0143BB64: CMP w8, #4                 | STATE = COMPARE((44696112 + ((val_1 - 6)) << 2 - 3), 0x4)
            // 0x0143BB68: B.HI #0x143c0f4            | if (44696112 + ((val_1 - 6)) << 2 > 0x4) goto label_51;
            if(val_21 > 4)
            {
                goto label_51;
            }
            // 0x0143BB6C: ADRP x9, #0x2aa0000        | X9 = 44695552 (0x2AA0000);              
            // 0x0143BB70: ADD x9, x9, #0x21c         | X9 = (44695552 + 540) = 44696092 (0x02AA021C);
            // 0x0143BB74: LDRSW x8, [x9, x8, lsl #2] | X8 = 44696092 + ((44696112 + ((val_1 - 6)) << 2 - 3)) << 2;
            var val_22 = 44696092 + ((44696112 + ((val_1 - 6)) << 2 - 3)) << 2;
            // 0x0143BB78: ADD x8, x8, x9             | X8 = (44696092 + ((44696112 + ((val_1 - 6)) << 2 - 3)) << 2 + 44696092);
            val_22 = val_22 + 44696092;
            // 0x0143BB7C: BR x8                      | goto (44696092 + ((44696112 + ((val_1 - 6)) << 2 - 3)) << 2 + 44696092);
            goto (44696092 + ((44696112 + ((val_1 - 6)) << 2 - 3)) << 2 + 44696092);
            // 0x0143BB80: LDR w21, [x20, #4]         | W21 = val_1 + 4;                        
            // 0x0143BB84: CBNZ x22, #0x143bb8c       | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x0143BB88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x0143BB8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143BB90: MOV x0, x22                | X0 = X1;//m1                            
            // 0x0143BB94: MOV w1, w21                | W1 = val_1 + 4;//m1                     
            // 0x0143BB98: BL #0x28df874              | X0 = X1.GetType(hash:  val_1 + 4);      
            ILRuntime.CLR.TypeSystem.IType val_2 = X1.GetType(hash:  val_1 + 4);
            // 0x0143BB9C: MOV x21, x0                | X21 = val_2;//m1                        
            val_22 = val_2;
            // 0x0143BBA0: CBZ x21, #0x143bbd8        | if (val_2 == null) goto label_6;        
            if(val_22 == null)
            {
                goto label_6;
            }
            // 0x0143BBA4: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x0143BBA8: LDR x8, [x8, #0x108]       | X8 = 1152921504782192640;               
            // 0x0143BBAC: LDR x9, [x21]              | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BBB0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.ILType);
            // 0x0143BBB4: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BBB8: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BBBC: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BBC0: B.LO #0x143bbd8            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) goto label_6;
            // 0x0143BBC4: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143BBC8: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x0143BBCC: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143BBD0: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.ILType))
            // 0x0143BBD4: B.EQ #0x143c09c            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_7;
            label_6:
            // 0x0143BBD8: CBNZ x20, #0x143bbe0       | if (val_1 != 0) goto label_8;           
            if(val_1 != 0)
            {
                goto label_8;
            }
            // 0x0143BBDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x0143BBE0: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x0143BBE4: LDR w20, [x20, #8]         | W20 = val_1 + 8;                        
            // 0x0143BBE8: LDR w8, [x19]              | W8 = X4;                                
            // 0x0143BBEC: LDR x9, [x9, #0xaa8]       | X9 = 1152921504897101824;               
            // 0x0143BBF0: ADD x1, sp, #0xc           | X1 = (1152921510121251968 + 12) = 1152921510121251980 (0x1000000148AF248C);
            // 0x0143BBF4: STR w8, [sp, #0xc]         | stack[1152921510121251980] = X4;         //  dest_result_addr=1152921510121251980
            // 0x0143BBF8: LDR x0, [x9]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143BBFC: BL #0x27bc028              | X0 = 1152921510121312416 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), X4);
            // 0x0143BC00: MOV x19, x0                | X19 = 1152921510121312416 (0x1000000148B010A0);//ML01
            val_21 = val_21;
            // 0x0143BC04: CBZ x21, #0x143bdec        | if (val_2 == null) goto label_9;        
            if(val_22 == null)
            {
                goto label_9;
            }
            // 0x0143BC08: ADRP x22, #0x35c2000       | X22 = 56369152 (0x35C2000);             
            // 0x0143BC0C: LDR x22, [x22, #0x290]     | X22 = 1152921504782032896;              
            // 0x0143BC10: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BC14: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x0143BC18: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BC1C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BC20: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BC24: B.LO #0x143bc3c            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x0143BC28: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143BC2C: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x0143BC30: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143BC34: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x0143BC38: B.EQ #0x143bc64            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x0143BC3C: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x0143BC40: ADD x8, sp, #0x30          | X8 = (1152921510121251968 + 48) = 1152921510121252016 (0x1000000148AF24B0);
            // 0x0143BC44: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x0143BC48: LDR x0, [sp, #0x30]        | X0 = val_4;                              //  find_add[1152921510121240096]
            // 0x0143BC4C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x0143BC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BC54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x0143BC58: ADD x0, sp, #0x30          | X0 = (1152921510121251968 + 48) = 1152921510121252016 (0x1000000148AF24B0);
            // 0x0143BC5C: BL #0x299a140              | 
            // 0x0143BC60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148AF24B0, ????);
            label_11:
            // 0x0143BC64: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BC68: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x0143BC6C: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BC70: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BC74: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BC78: B.LO #0x143bc90            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x0143BC7C: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143BC80: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x0143BC84: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143BC88: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x0143BC8C: B.EQ #0x143bdf4            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x0143BC90: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x0143BC94: ADD x8, sp, #0x38          | X8 = (1152921510121251968 + 56) = 1152921510121252024 (0x1000000148AF24B8);
            // 0x0143BC98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x0143BC9C: LDR x0, [sp, #0x38]        | X0 = val_6;                              //  find_add[1152921510121240096]
            // 0x0143BCA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x0143BCA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BCA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x0143BCAC: ADD x0, sp, #0x38          | X0 = (1152921510121251968 + 56) = 1152921510121252024 (0x1000000148AF24B8);
            // 0x0143BCB0: BL #0x299a140              | 
            // 0x0143BCB4: B #0x143bdf0               |  goto label_14;                         
            goto label_14;
            // 0x0143BCB8: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x0143BCBC: LDR w20, [x20, #4]         | W20 = val_1 + 8 + 4;                    
            // 0x0143BCC0: LDR w8, [x19]              | W8 = typeof(CHECK_POINT_STATE);         
            // 0x0143BCC4: LDR x9, [x9, #0xaa8]       | X9 = 1152921504897101824;               
            // 0x0143BCC8: ADD x1, sp, #0x14          | X1 = (1152921510121251968 + 20) = 1152921510121251988 (0x1000000148AF2494);
            // 0x0143BCCC: STR w8, [sp, #0x14]        | stack[1152921510121251988] = typeof(CHECK_POINT_STATE);  //  dest_result_addr=1152921510121251988
            // 0x0143BCD0: LDR x0, [x9]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143BCD4: BL #0x27bc028              | X0 = 1152921510121316512 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), typeof(CHECK_POINT_STATE));
            // 0x0143BCD8: MOV x19, x0                | X19 = 1152921510121316512 (0x1000000148B020A0);//ML01
            val_21 = null;
            // 0x0143BCDC: CBNZ x21, #0x143bce4       | if (val_2 != null) goto label_15;       
            if(val_22 != null)
            {
                goto label_15;
            }
            // 0x0143BCE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CHECK_POINT_STATE), ????);
            label_15:
            // 0x0143BCE4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x0143BCE8: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BCEC: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x0143BCF0: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x0143BCF4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x0143BCF8: CBZ x9, #0x143bd24         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_16;
            // 0x0143BCFC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x0143BD00: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_23 = 0;
            // 0x0143BD04: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_18:
            // 0x0143BD08: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x0143BD0C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x0143BD10: B.EQ #0x143be0c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_17;
            // 0x0143BD14: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_23 = val_23 + 1;
            // 0x0143BD18: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x0143BD1C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x0143BD20: B.LO #0x143bd08            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_18;
            label_16:
            // 0x0143BD24: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x0143BD28: MOV x0, x21                | X0 = val_2;//m1                         
            val_23 = val_22;
            // 0x0143BD2C: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x0143BD30: B #0x143be1c               |  goto label_19;                         
            goto label_19;
            // 0x0143BD34: LDR w23, [x20, #4]         | W23 = val_1 + 8 + 4 + 4;                
            val_20 = mem[val_1 + 8 + 4 + 4];
            val_20 = val_1 + 8 + 4 + 4;
            // 0x0143BD38: CBNZ x21, #0x143bd40       | if (val_2 != null) goto label_20;       
            if(val_22 != null)
            {
                goto label_20;
            }
            // 0x0143BD3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_20:
            // 0x0143BD40: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x0143BD44: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BD48: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x0143BD4C: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x0143BD50: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x0143BD54: CBZ x9, #0x143bd80         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_21;
            // 0x0143BD58: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x0143BD5C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x0143BD60: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_23:
            // 0x0143BD64: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x0143BD68: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x0143BD6C: B.EQ #0x143be34            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_22;
            // 0x0143BD70: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x0143BD74: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x0143BD78: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x0143BD7C: B.LO #0x143bd64            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_23;
            label_21:
            // 0x0143BD80: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x0143BD84: MOV x0, x21                | X0 = val_2;//m1                         
            val_24 = val_22;
            // 0x0143BD88: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x0143BD8C: B #0x143be44               |  goto label_24;                         
            goto label_24;
            // 0x0143BD90: LDR w22, [x20, #4]         | W22 = val_1 + 8 + 4 + 4;                
            // 0x0143BD94: CBNZ x21, #0x143bd9c       | if (val_2 != null) goto label_25;       
            if(val_22 != null)
            {
                goto label_25;
            }
            // 0x0143BD98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_25:
            // 0x0143BD9C: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x0143BDA0: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BDA4: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x0143BDA8: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x0143BDAC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x0143BDB0: CBZ x9, #0x143bddc         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_26;
            // 0x0143BDB4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x0143BDB8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_25 = 0;
            // 0x0143BDBC: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_28:
            // 0x0143BDC0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x0143BDC4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x0143BDC8: B.EQ #0x143bfc8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_27;
            // 0x0143BDCC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_25 = val_25 + 1;
            // 0x0143BDD0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x0143BDD4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x0143BDD8: B.LO #0x143bdc0            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_28;
            label_26:
            // 0x0143BDDC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x0143BDE0: MOV x0, x21                | X0 = val_2;//m1                         
            val_25 = val_22;
            // 0x0143BDE4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x0143BDE8: B #0x143bfd8               |  goto label_29;                         
            goto label_29;
            label_9:
            // 0x0143BDEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4, ????);         
            label_14:
            // 0x0143BDF0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_13:
            // 0x0143BDF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143BDF8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x0143BDFC: MOV w1, w20                | W1 = val_1 + 8;//m1                     
            // 0x0143BE00: MOV x2, x19                | X2 = 1152921510121312416 (0x1000000148B010A0);//ML01
            // 0x0143BE04: BL #0x10eece4              | val_22.SetStaticFieldValue(hash:  val_1 + 8, value:  val_21);
            val_22.SetStaticFieldValue(hash:  val_1 + 8, value:  val_21);
            // 0x0143BE08: B #0x143c0f4               |  goto label_51;                         
            goto label_51;
            label_17:
            // 0x0143BE0C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x0143BE10: ADD w9, w9, #4             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4);
            // 0x0143BE14: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4));
            // 0x0143BE18: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4)).272
            label_19:
            // 0x0143BE1C: LDP x8, x3, [x0]           | X8 = typeof(CHECK_POINT_STATE);          //  | 
            // 0x0143BE20: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0143BE24: MOV w1, w20                | W1 = val_1 + 8 + 4;//m1                 
            // 0x0143BE28: MOV x2, x19                | X2 = 1152921510121316512 (0x1000000148B020A0);//ML01
            // 0x0143BE2C: BLR x8                     | X0 = sub_10000000114CF000( ?? val_2, ????);
            // 0x0143BE30: B #0x143c0f4               |  goto label_51;                         
            goto label_51;
            label_22:
            // 0x0143BE34: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x0143BE38: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x0143BE3C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x0143BE40: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_24:
            // 0x0143BE44: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x0143BE48: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0143BE4C: MOV w1, w23                | W1 = val_1 + 8 + 4 + 4;//m1             
            // 0x0143BE50: BLR x8                     | X0 = sub_100000000A746000( ?? val_2, ????);
            // 0x0143BE54: MOV x21, x0                | X21 = val_2;//m1                        
            val_22 = val_22;
            // 0x0143BE58: STR x21, [sp, #0x18]       | stack[1152921510121251992] = val_2;      //  dest_result_addr=1152921510121251992
            ILRuntime.CLR.TypeSystem.IType val_18 = val_22;
            // 0x0143BE5C: CBZ x21, #0x143bf6c        | if (val_2 == null) goto label_32;       
            if(val_22 == null)
            {
                goto label_32;
            }
            // 0x0143BE60: ADRP x23, #0x35dd000       | X23 = 56479744 (0x35DD000);             
            // 0x0143BE64: LDR x23, [x23, #0xb50]     | X23 = 1152921504825909248;              
            val_20 = 1152921504825909248;
            // 0x0143BE68: LDR x9, [x21]              | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BE6C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x0143BE70: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BE74: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BE78: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BE7C: B.LO #0x143bf70            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_34;
            // 0x0143BE80: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143BE84: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepre
            // 0x0143BE88: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143BE8C: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x0143BE90: B.NE #0x143bf70            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_34;
            // 0x0143BE94: CBNZ x20, #0x143be9c       | if (val_1 + 8 + 4 != 0) goto label_35;  
            if((val_1 + 8 + 4) != 0)
            {
                goto label_35;
            }
            // 0x0143BE98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_35:
            // 0x0143BE9C: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x0143BEA0: LDR w20, [x20, #8]         | W20 = val_1 + 8 + 4 + 8;                
            val_26 = mem[val_1 + 8 + 4 + 8];
            val_26 = val_1 + 8 + 4 + 8;
            // 0x0143BEA4: LDR w8, [x19]              | W8 = typeof(CHECK_POINT_STATE);         
            // 0x0143BEA8: LDR x9, [x9, #0xaa8]       | X9 = 1152921504897101824;               
            // 0x0143BEAC: ADD x1, sp, #0x10          | X1 = (1152921510121251968 + 16) = 1152921510121251984 (0x1000000148AF2490);
            // 0x0143BEB0: STR w8, [sp, #0x10]        | stack[1152921510121251984] = typeof(CHECK_POINT_STATE);  //  dest_result_addr=1152921510121251984
            // 0x0143BEB4: LDR x0, [x9]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143BEB8: BL #0x27bc028              | X0 = 1152921510121320608 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), typeof(CHECK_POINT_STATE));
            // 0x0143BEBC: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BEC0: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x0143BEC4: MOV x19, x0                | X19 = 1152921510121320608 (0x1000000148B030A0);//ML01
            val_21 = null;
            // 0x0143BEC8: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BECC: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BED0: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BED4: B.LO #0x143beec            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_36;
            // 0x0143BED8: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143BEDC: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepre
            // 0x0143BEE0: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143BEE4: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x0143BEE8: B.EQ #0x143bf14            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_37;
            label_36:
            // 0x0143BEEC: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x0143BEF0: ADD x8, sp, #0x20          | X8 = (1152921510121251968 + 32) = 1152921510121252000 (0x1000000148AF24A0);
            // 0x0143BEF4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x0143BEF8: LDR x0, [sp, #0x20]        | X0 = val_10;                             //  find_add[1152921510121240096]
            // 0x0143BEFC: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x0143BF00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BF04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x0143BF08: ADD x0, sp, #0x20          | X0 = (1152921510121251968 + 32) = 1152921510121252000 (0x1000000148AF24A0);
            // 0x0143BF0C: BL #0x299a140              | 
            // 0x0143BF10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148AF24A0, ????);
            label_37:
            // 0x0143BF14: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BF18: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x0143BF1C: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BF20: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BF24: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BF28: B.LO #0x143bf40            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_38;
            // 0x0143BF2C: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143BF30: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepre
            // 0x0143BF34: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143BF38: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x0143BF3C: B.EQ #0x143c0e0            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_53;
            label_38:
            // 0x0143BF40: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x0143BF44: ADD x8, sp, #0x28          | X8 = (1152921510121251968 + 40) = 1152921510121252008 (0x1000000148AF24A8);
            // 0x0143BF48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x0143BF4C: LDR x0, [sp, #0x28]        | X0 = val_12;                             //  find_add[1152921510121240096]
            // 0x0143BF50: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0143BF54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BF58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0143BF5C: ADD x0, sp, #0x28          | X0 = (1152921510121251968 + 40) = 1152921510121252008 (0x1000000148AF24A8);
            // 0x0143BF60: BL #0x299a140              | 
            // 0x0143BF64: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x0143BF68: B #0x143c0e0               |  goto label_53;                         
            goto label_53;
            label_32:
            // 0x0143BF6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_34:
            // 0x0143BF70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143BF74: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0143BF78: BL #0x16fb28c              | X0 = val_2.GetType();                   
            System.Type val_13 = val_22.GetType();
            // 0x0143BF7C: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x0143BF80: CBNZ x22, #0x143bf88       | if (typeof(ILRuntime.CLR.TypeSystem.CLRType) != 0) goto label_41;
            if(null != 0)
            {
                goto label_41;
            }
            // 0x0143BF84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_41:
            // 0x0143BF88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143BF8C: MOV x0, x22                | X0 = 57998160 (0x374FB50);//ML01        
            // 0x0143BF90: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x0143BF94: BL #0x28e5da8              | X0 = GetType(t:  val_13);               
            ILRuntime.CLR.TypeSystem.IType val_14 = GetType(t:  val_13);
            // 0x0143BF98: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x0143BF9C: CBZ x0, #0x143c04c         | if (val_14 == null) goto label_44;      
            if(val_14 == null)
            {
                goto label_44;
            }
            // 0x0143BFA0: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x0143BFA4: LDR x8, [x8, #0x290]       | X8 = 1152921504782032896;               
            // 0x0143BFA8: LDR x9, [x0]               | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x0143BFAC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x0143BFB0: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BFB4: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143BFB8: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0143BFBC: B.HS #0x143c038            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth >= ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_43;
            // 0x0143BFC0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x0143BFC4: B #0x143c04c               |  goto label_44;                         
            goto label_44;
            label_27:
            // 0x0143BFC8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x0143BFCC: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x0143BFD0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x0143BFD4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_29:
            // 0x0143BFD8: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x0143BFDC: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0143BFE0: MOV w1, w22                | W1 = val_1 + 8 + 4 + 4;//m1             
            // 0x0143BFE4: BLR x8                     | X0 = sub_100000000A746000( ?? val_2, ????);
            // 0x0143BFE8: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x0143BFEC: LDR x8, [x8, #0x390]       | X8 = 1152921510121223712;               
            // 0x0143BFF0: LDR x1, [x8]               | X1 = typeof(CHECK_POINT_STATE[]);       
            // 0x0143BFF4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x0143BFF8: MOV x21, x0                | X21 = val_2;//m1                        
            val_22 = val_22;
            // 0x0143BFFC: CBNZ x20, #0x143c004       | if (val_1 + 8 + 4 != 0) goto label_45;  
            if((val_1 + 8 + 4) != 0)
            {
                goto label_45;
            }
            // 0x0143C000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_45:
            // 0x0143C004: LDRSW x20, [x20, #8]       | X20 = val_1 + 8 + 4 + 8;                
            // 0x0143C008: CBNZ x21, #0x143c010       | if (val_2 != null) goto label_46;       
            if(val_22 != null)
            {
                goto label_46;
            }
            // 0x0143C00C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_46:
            // 0x0143C010: LDR w8, [x21, #0x18]       | 
            // 0x0143C014: LDR w19, [x19]             | W19 = typeof(CHECK_POINT_STATE);        
            // 0x0143C018: CMP w20, w8                | STATE = COMPARE(val_1 + 8 + 4 + 8, 1152921510121223712)
            // 0x0143C01C: B.LO #0x143c02c            | if (val_1 + 8 + 4 + 8 < 1152921510121223712) goto label_47;
            if((val_1 + 8 + 4 + 8) < 1152921510121223712)
            {
                goto label_47;
            }
            // 0x0143C020: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x0143C024: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143C028: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_47:
            // 0x0143C02C: ADD x8, x21, x20, lsl #2   | X8 = (val_2 + (val_1 + 8 + 4 + 8) << 2);
            ILRuntime.CLR.TypeSystem.IType val_16 = val_22 + ((val_1 + 8 + 4 + 8) << 2);
            // 0x0143C030: STR w19, [x8, #0x20]       | mem2[0] = typeof(CHECK_POINT_STATE);     //  dest_result_addr=0
            mem2[0] = null;
            // 0x0143C034: B #0x143c0f4               |  goto label_51;                         
            goto label_51;
            label_43:
            // 0x0143C038: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x0143C03C: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x0143C040: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0143C044: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x0143C048: CSEL x21, x0, xzr, eq      | X21 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0;
            var val_17 = (((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_14) : 0;
            label_44:
            // 0x0143C04C: CBNZ x20, #0x143c054       | if (val_1 + 8 + 4 != 0) goto label_49;  
            if((val_1 + 8 + 4) != 0)
            {
                goto label_49;
            }
            // 0x0143C050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_49:
            // 0x0143C054: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x0143C058: LDR w20, [x20, #8]         | W20 = val_1 + 8 + 4 + 8;                
            // 0x0143C05C: LDR w8, [x19]              | W8 = typeof(CHECK_POINT_STATE);         
            // 0x0143C060: LDR x9, [x9, #0xaa8]       | X9 = 1152921504897101824;               
            // 0x0143C064: ADD x1, sp, #0x14          | X1 = (1152921510121251968 + 20) = 1152921510121251988 (0x1000000148AF2494);
            // 0x0143C068: STR w8, [sp, #0x14]        | stack[1152921510121251988] = typeof(CHECK_POINT_STATE);  //  dest_result_addr=1152921510121251988
            // 0x0143C06C: LDR x0, [x9]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C070: BL #0x27bc028              | X0 = 1152921510121332896 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), typeof(CHECK_POINT_STATE));
            // 0x0143C074: MOV x19, x0                | X19 = 1152921510121332896 (0x1000000148B060A0);//ML01
            val_21 = null;
            // 0x0143C078: CBNZ x21, #0x143c080       | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0 != 0) goto label_50;
            // 0x0143C07C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CHECK_POINT_STATE), ????);
            label_50:
            // 0x0143C080: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143C084: ADD x2, sp, #0x18          | X2 = (1152921510121251968 + 24) = 1152921510121251992 (0x1000000148AF2498);
            // 0x0143C088: MOV x0, x21                | X0 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0;//m1
            // 0x0143C08C: MOV w1, w20                | W1 = val_1 + 8 + 4 + 8;//m1             
            // 0x0143C090: MOV x3, x19                | X3 = 1152921510121332896 (0x1000000148B060A0);//ML01
            // 0x0143C094: BL #0x10f426c              | (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0.SetFieldValue(hash:  val_1 + 8 + 4 + 8, target: ref  ILRuntime.CLR.TypeSystem.IType val_18 = val_22, value:  null);
            val_17.SetFieldValue(hash:  val_1 + 8 + 4 + 8, target: ref  val_18, value:  null);
            // 0x0143C098: B #0x143c0f4               |  goto label_51;                         
            goto label_51;
            label_7:
            // 0x0143C09C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143C0A0: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x0143C0A4: BL #0x10eeca4              | X0 = val_2.get_StaticInstance();        
            ILRuntime.Runtime.Intepreter.ILTypeStaticInstance val_19 = val_22.StaticInstance;
            // 0x0143C0A8: MOV x21, x0                | X21 = val_19;//m1                       
            val_22 = val_19;
            // 0x0143C0AC: CBNZ x20, #0x143c0b4       | if (val_1 != 0) goto label_52;          
            if(val_1 != 0)
            {
                goto label_52;
            }
            // 0x0143C0B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_52:
            // 0x0143C0B4: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x0143C0B8: LDR w20, [x20, #8]         | W20 = val_1 + 8;                        
            val_26 = mem[val_1 + 8];
            val_26 = val_1 + 8;
            // 0x0143C0BC: LDR w8, [x19]              | W8 = X4;                                
            // 0x0143C0C0: LDR x9, [x9, #0xaa8]       | X9 = 1152921504897101824;               
            // 0x0143C0C4: ADD x1, sp, #0x14          | X1 = (1152921510121251968 + 20) = 1152921510121251988 (0x1000000148AF2494);
            // 0x0143C0C8: STR w8, [sp, #0x14]        | stack[1152921510121251988] = X4;         //  dest_result_addr=1152921510121251988
            // 0x0143C0CC: LDR x0, [x9]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C0D0: BL #0x27bc028              | X0 = 1152921510121341088 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), X4);
            // 0x0143C0D4: MOV x19, x0                | X19 = 1152921510121341088 (0x1000000148B080A0);//ML01
            val_21 = val_21;
            // 0x0143C0D8: CBNZ x21, #0x143c0e0       | if (val_19 != null) goto label_53;      
            if(val_22 != null)
            {
                goto label_53;
            }
            // 0x0143C0DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4, ????);         
            label_53:
            // 0x0143C0E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143C0E4: MOV x0, x21                | X0 = val_19;//m1                        
            // 0x0143C0E8: MOV w1, w20                | W1 = val_1 + 8;//m1                     
            // 0x0143C0EC: MOV x2, x19                | X2 = 1152921510121341088 (0x1000000148B080A0);//ML01
            // 0x0143C0F0: BL #0x1f96638              | val_19.set_Item(index:  val_26, value:  val_21);
            val_22.set_Item(index:  val_26, value:  val_21);
            label_51:
            // 0x0143C0F4: SUB sp, x29, #0x30         | SP = (1152921510121252080 - 48) = 1152921510121252032 (0x1000000148AF24C0);
            // 0x0143C0F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C0FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0143C100: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0143C104: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0143C108: RET                        |  return;                                
            return;
            // 0x0143C10C: MOV x19, x0                | 
            // 0x0143C110: ADD x0, sp, #0x30          | 
            // 0x0143C114: B #0x143c138               | 
            // 0x0143C118: MOV x19, x0                | 
            // 0x0143C11C: ADD x0, sp, #0x38          | 
            // 0x0143C120: B #0x143c138               | 
            // 0x0143C124: MOV x19, x0                | 
            // 0x0143C128: ADD x0, sp, #0x20          | 
            // 0x0143C12C: B #0x143c138               | 
            // 0x0143C130: MOV x19, x0                | 
            // 0x0143C134: ADD x0, sp, #0x28          | 
            label_56:
            // 0x0143C138: BL #0x299a140              | 
            // 0x0143C13C: MOV x0, x19                | 
            // 0x0143C140: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0143C144 (21217604), len: 92  VirtAddr: 0x0143C144 RVA: 0x0143C144 token: 100664219 methodIndex: 30266 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_CPS_UNLOCK_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x0143C144: STP x20, x19, [sp, #-0x20]! | stack[1152921510121421264] = ???;  stack[1152921510121421272] = ???;  //  dest_result_addr=1152921510121421264 |  dest_result_addr=1152921510121421272
            // 0x0143C148: STP x29, x30, [sp, #0x10]  | stack[1152921510121421280] = ???;  stack[1152921510121421288] = ???;  //  dest_result_addr=1152921510121421280 |  dest_result_addr=1152921510121421288
            // 0x0143C14C: ADD x29, sp, #0x10         | X29 = (1152921510121421264 + 16) = 1152921510121421280 (0x1000000148B1B9E0);
            // 0x0143C150: SUB sp, sp, #0x10          | SP = (1152921510121421264 - 16) = 1152921510121421248 (0x1000000148B1B9C0);
            // 0x0143C154: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0143C158: LDRB w8, [x19, #0x75]      | W8 = (bool)static_value_03737075;       
            // 0x0143C15C: TBNZ w8, #0, #0x143c178    | if (static_value_03737075 == true) goto label_0;
            // 0x0143C160: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x0143C164: LDR x8, [x8, #0xa90]       | X8 = 0x2B9067C;                         
            // 0x0143C168: LDR w0, [x8]               | W0 = 0x1863;                            
            // 0x0143C16C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1863, ????);     
            // 0x0143C170: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C174: STRB w8, [x19, #0x75]      | static_value_03737075 = true;            //  dest_result_addr=57897077
            label_0:
            // 0x0143C178: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x0143C17C: LDR x8, [x8, #0xaa8]       | X8 = 1152921504897101824;               
            // 0x0143C180: ADD x1, sp, #0xc           | X1 = (1152921510121421248 + 12) = 1152921510121421260 (0x1000000148B1B9CC);
            // 0x0143C184: STR wzr, [sp, #0xc]        | stack[1152921510121421260] = 0x0;        //  dest_result_addr=1152921510121421260
            // 0x0143C188: LDR x0, [x8]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C18C: BL #0x27bc028              | X0 = 1152921510121469312 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), null);
            // 0x0143C190: SUB sp, x29, #0x10         | SP = (1152921510121421280 - 16) = 1152921510121421264 (0x1000000148B1B9D0);
            // 0x0143C194: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C198: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143C19C: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0143C1A0 (21217696), len: 96  VirtAddr: 0x0143C1A0 RVA: 0x0143C1A0 token: 100664220 methodIndex: 30267 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_CPS_LOCK_1(ref object o)
        {
            //
            // Disasemble & Code
            // 0x0143C1A0: STP x20, x19, [sp, #-0x20]! | stack[1152921510121549488] = ???;  stack[1152921510121549496] = ???;  //  dest_result_addr=1152921510121549488 |  dest_result_addr=1152921510121549496
            // 0x0143C1A4: STP x29, x30, [sp, #0x10]  | stack[1152921510121549504] = ???;  stack[1152921510121549512] = ???;  //  dest_result_addr=1152921510121549504 |  dest_result_addr=1152921510121549512
            // 0x0143C1A8: ADD x29, sp, #0x10         | X29 = (1152921510121549488 + 16) = 1152921510121549504 (0x1000000148B3AEC0);
            // 0x0143C1AC: SUB sp, sp, #0x10          | SP = (1152921510121549488 - 16) = 1152921510121549472 (0x1000000148B3AEA0);
            // 0x0143C1B0: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0143C1B4: LDRB w8, [x19, #0x76]      | W8 = (bool)static_value_03737076;       
            // 0x0143C1B8: TBNZ w8, #0, #0x143c1d4    | if (static_value_03737076 == true) goto label_0;
            // 0x0143C1BC: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x0143C1C0: LDR x8, [x8, #0x8a8]       | X8 = 0x2B90678;                         
            // 0x0143C1C4: LDR w0, [x8]               | W0 = 0x1862;                            
            // 0x0143C1C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1862, ????);     
            // 0x0143C1CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C1D0: STRB w8, [x19, #0x76]      | static_value_03737076 = true;            //  dest_result_addr=57897078
            label_0:
            // 0x0143C1D4: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x0143C1D8: LDR x8, [x8, #0xaa8]       | X8 = 1152921504897101824;               
            // 0x0143C1DC: ADD x1, sp, #0xc           | X1 = (1152921510121549472 + 12) = 1152921510121549484 (0x1000000148B3AEAC);
            // 0x0143C1E0: LDR x0, [x8]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C1E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C1E8: STR w8, [sp, #0xc]         | stack[1152921510121549484] = 0x1;        //  dest_result_addr=1152921510121549484
            // 0x0143C1EC: BL #0x27bc028              | X0 = 1152921510121597536 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), 0x1);
            // 0x0143C1F0: SUB sp, x29, #0x10         | SP = (1152921510121549504 - 16) = 1152921510121549488 (0x1000000148B3AEB0);
            // 0x0143C1F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C1F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143C1FC: RET                        |  return (System.Object)0x1;             
            return (object)1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0143C200 (21217792), len: 96  VirtAddr: 0x0143C200 RVA: 0x0143C200 token: 100664221 methodIndex: 30268 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_CPS_FINISH_2(ref object o)
        {
            //
            // Disasemble & Code
            // 0x0143C200: STP x20, x19, [sp, #-0x20]! | stack[1152921510121677712] = ???;  stack[1152921510121677720] = ???;  //  dest_result_addr=1152921510121677712 |  dest_result_addr=1152921510121677720
            // 0x0143C204: STP x29, x30, [sp, #0x10]  | stack[1152921510121677728] = ???;  stack[1152921510121677736] = ???;  //  dest_result_addr=1152921510121677728 |  dest_result_addr=1152921510121677736
            // 0x0143C208: ADD x29, sp, #0x10         | X29 = (1152921510121677712 + 16) = 1152921510121677728 (0x1000000148B5A3A0);
            // 0x0143C20C: SUB sp, sp, #0x10          | SP = (1152921510121677712 - 16) = 1152921510121677696 (0x1000000148B5A380);
            // 0x0143C210: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0143C214: LDRB w8, [x19, #0x77]      | W8 = (bool)static_value_03737077;       
            // 0x0143C218: TBNZ w8, #0, #0x143c234    | if (static_value_03737077 == true) goto label_0;
            // 0x0143C21C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x0143C220: LDR x8, [x8, #0xc78]       | X8 = 0x2B90674;                         
            // 0x0143C224: LDR w0, [x8]               | W0 = 0x1861;                            
            // 0x0143C228: BL #0x2782188              | X0 = sub_2782188( ?? 0x1861, ????);     
            // 0x0143C22C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C230: STRB w8, [x19, #0x77]      | static_value_03737077 = true;            //  dest_result_addr=57897079
            label_0:
            // 0x0143C234: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x0143C238: LDR x8, [x8, #0xaa8]       | X8 = 1152921504897101824;               
            // 0x0143C23C: ADD x1, sp, #0xc           | X1 = (1152921510121677696 + 12) = 1152921510121677708 (0x1000000148B5A38C);
            // 0x0143C240: LDR x0, [x8]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C244: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x0143C248: STR w8, [sp, #0xc]         | stack[1152921510121677708] = 0x2;        //  dest_result_addr=1152921510121677708
            // 0x0143C24C: BL #0x27bc028              | X0 = 1152921510121725760 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), 0x2);
            // 0x0143C250: SUB sp, x29, #0x10         | SP = (1152921510121677728 - 16) = 1152921510121677712 (0x1000000148B5A390);
            // 0x0143C254: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C258: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143C25C: RET                        |  return (System.Object)0x2;             
            return (object)2;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0143C260 (21217888), len: 208  VirtAddr: 0x0143C260 RVA: 0x0143C260 token: 100664222 methodIndex: 30269 delegateWrapperIndex: 0 methodInvoker: 0
        private static object PerformMemberwiseClone(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0143C260: STP x22, x21, [sp, #-0x30]! | stack[1152921510121805920] = ???;  stack[1152921510121805928] = ???;  //  dest_result_addr=1152921510121805920 |  dest_result_addr=1152921510121805928
            // 0x0143C264: STP x20, x19, [sp, #0x10]  | stack[1152921510121805936] = ???;  stack[1152921510121805944] = ???;  //  dest_result_addr=1152921510121805936 |  dest_result_addr=1152921510121805944
            // 0x0143C268: STP x29, x30, [sp, #0x20]  | stack[1152921510121805952] = ???;  stack[1152921510121805960] = ???;  //  dest_result_addr=1152921510121805952 |  dest_result_addr=1152921510121805960
            // 0x0143C26C: ADD x29, sp, #0x20         | X29 = (1152921510121805920 + 32) = 1152921510121805952 (0x1000000148B79880);
            // 0x0143C270: SUB sp, sp, #0x10          | SP = (1152921510121805920 - 16) = 1152921510121805904 (0x1000000148B79850);
            // 0x0143C274: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143C278: LDRB w8, [x20, #0x78]      | W8 = (bool)static_value_03737078;       
            // 0x0143C27C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143C280: TBNZ w8, #0, #0x143c29c    | if (static_value_03737078 == true) goto label_0;
            // 0x0143C284: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0143C288: LDR x8, [x8, #0xe10]       | X8 = 0x2B90680;                         
            // 0x0143C28C: LDR w0, [x8]               | W0 = 0x1864;                            
            // 0x0143C290: BL #0x2782188              | X0 = sub_2782188( ?? 0x1864, ????);     
            // 0x0143C294: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C298: STRB w8, [x20, #0x78]      | static_value_03737078 = true;            //  dest_result_addr=57897080
            label_0:
            // 0x0143C29C: ADRP x21, #0x361b000       | X21 = 56733696 (0x361B000);             
            // 0x0143C2A0: LDR x20, [x19]             | X20 = X1;                               
            // 0x0143C2A4: LDR x21, [x21, #0xaa8]     | X21 = 1152921504897101824;              
            // 0x0143C2A8: LDR x19, [x21]             | X19 = typeof(CHECK_POINT_STATE);        
            // 0x0143C2AC: CBNZ x20, #0x143c2b4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143C2B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1864, ????);     
            label_1:
            // 0x0143C2B4: LDR x8, [x20]              | X8 = X1;                                
            // 0x0143C2B8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x0143C2BC: LDR x8, [x19, #0x30]       | X8 = CHECK_POINT_STATE.__il2cppRuntimeField_element_class;
            // 0x0143C2C0: CMP x0, x8                 | STATE = COMPARE(X1 + 48, CHECK_POINT_STATE.__il2cppRuntimeField_element_class)
            // 0x0143C2C4: B.NE #0x143c2f8            | if (X1 + 48 != CHECK_POINT_STATE.__il2cppRuntimeField_element_class) goto label_2;
            // 0x0143C2C8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143C2CC: BL #0x27bc4e8              | X1.System.IDisposable.Dispose();        
            X1.System.IDisposable.Dispose();
            // 0x0143C2D0: LDR w8, [x0]               | W8 = X1;                                
            // 0x0143C2D4: LDR x0, [x21]              | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C2D8: ADD x1, sp, #4             | X1 = (1152921510121805904 + 4) = 1152921510121805908 (0x1000000148B79854);
            // 0x0143C2DC: STR w8, [sp, #4]           | stack[1152921510121805908] = X1;         //  dest_result_addr=1152921510121805908
            // 0x0143C2E0: BL #0x27bc028              | X0 = 1152921510121853984 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), X1);
            // 0x0143C2E4: SUB sp, x29, #0x20         | SP = (1152921510121805952 - 32) = 1152921510121805920 (0x1000000148B79860);
            // 0x0143C2E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C2EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0143C2F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0143C2F4: RET                        |  return (System.Object)X1;              
            return (object)X1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_2:
            // 0x0143C2F8: ADD x8, sp, #8             | X8 = (1152921510121805904 + 8) = 1152921510121805912 (0x1000000148B79858);
            // 0x0143C2FC: MOV x1, x19                | X1 = 1152921504897101824 (0x10000000114CF000);//ML01
            // 0x0143C300: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x0143C304: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921510121793968]
            // 0x0143C308: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x0143C30C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143C310: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x0143C314: ADD x0, sp, #8             | X0 = (1152921510121805904 + 8) = 1152921510121805912 (0x1000000148B79858);
            // 0x0143C318: BL #0x299a140              | 
            // 0x0143C31C: MOV x19, x0                | X19 = 1152921510121805912 (0x1000000148B79858);//ML01
            // 0x0143C320: ADD x0, sp, #8             | X0 = (1152921510121805904 + 8) = 1152921510121805912 (0x1000000148B79858);
            // 0x0143C324: BL #0x299a140              | 
            // 0x0143C328: MOV x0, x19                | X0 = 1152921510121805912 (0x1000000148B79858);//ML01
            // 0x0143C32C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000148B79858, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x0143C330 (21218096), len: 92  VirtAddr: 0x0143C330 RVA: 0x0143C330 token: 100664223 methodIndex: 30270 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x0143C330: STP x20, x19, [sp, #-0x20]! | stack[1152921510121930144] = ???;  stack[1152921510121930152] = ???;  //  dest_result_addr=1152921510121930144 |  dest_result_addr=1152921510121930152
            // 0x0143C334: STP x29, x30, [sp, #0x10]  | stack[1152921510121930160] = ???;  stack[1152921510121930168] = ???;  //  dest_result_addr=1152921510121930160 |  dest_result_addr=1152921510121930168
            // 0x0143C338: ADD x29, sp, #0x10         | X29 = (1152921510121930144 + 16) = 1152921510121930160 (0x1000000148B97DB0);
            // 0x0143C33C: SUB sp, sp, #0x10          | SP = (1152921510121930144 - 16) = 1152921510121930128 (0x1000000148B97D90);
            // 0x0143C340: ADRP x19, #0x3737000       | X19 = 57896960 (0x3737000);             
            // 0x0143C344: LDRB w8, [x19, #0x79]      | W8 = (bool)static_value_03737079;       
            // 0x0143C348: TBNZ w8, #0, #0x143c364    | if (static_value_03737079 == true) goto label_0;
            // 0x0143C34C: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x0143C350: LDR x8, [x8, #0x580]       | X8 = 0x2B90688;                         
            // 0x0143C354: LDR w0, [x8]               | W0 = 0x1866;                            
            // 0x0143C358: BL #0x2782188              | X0 = sub_2782188( ?? 0x1866, ????);     
            // 0x0143C35C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C360: STRB w8, [x19, #0x79]      | static_value_03737079 = true;            //  dest_result_addr=57897081
            label_0:
            // 0x0143C364: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x0143C368: LDR x8, [x8, #0xaa8]       | X8 = 1152921504897101824;               
            // 0x0143C36C: ADD x1, sp, #0xc           | X1 = (1152921510121930128 + 12) = 1152921510121930140 (0x1000000148B97D9C);
            // 0x0143C370: STR wzr, [sp, #0xc]        | stack[1152921510121930140] = 0x0;        //  dest_result_addr=1152921510121930140
            // 0x0143C374: LDR x0, [x8]               | X0 = typeof(CHECK_POINT_STATE);         
            // 0x0143C378: BL #0x27bc028              | X0 = 1152921510121974176 = (Il2CppObject*)Box((RuntimeClass*)typeof(CHECK_POINT_STATE), null);
            // 0x0143C37C: SUB sp, x29, #0x10         | SP = (1152921510121930160 - 16) = 1152921510121930144 (0x1000000148B97DA0);
            // 0x0143C380: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C384: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143C388: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0143C38C (21218188), len: 92  VirtAddr: 0x0143C38C RVA: 0x0143C38C token: 100664224 methodIndex: 30271 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x0143C38C: STP x20, x19, [sp, #-0x20]! | stack[1152921510122046240] = ???;  stack[1152921510122046248] = ???;  //  dest_result_addr=1152921510122046240 |  dest_result_addr=1152921510122046248
            // 0x0143C390: STP x29, x30, [sp, #0x10]  | stack[1152921510122046256] = ???;  stack[1152921510122046264] = ???;  //  dest_result_addr=1152921510122046256 |  dest_result_addr=1152921510122046264
            // 0x0143C394: ADD x29, sp, #0x10         | X29 = (1152921510122046240 + 16) = 1152921510122046256 (0x1000000148BB4330);
            // 0x0143C398: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x0143C39C: LDRB w8, [x20, #0x7a]      | W8 = (bool)static_value_0373707A;       
            // 0x0143C3A0: MOV w19, w1                | W19 = W1;//m1                           
            // 0x0143C3A4: TBNZ w8, #0, #0x143c3c0    | if (static_value_0373707A == true) goto label_0;
            // 0x0143C3A8: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x0143C3AC: LDR x8, [x8, #0x6b0]       | X8 = 0x2B9068C;                         
            // 0x0143C3B0: LDR w0, [x8]               | W0 = 0x1867;                            
            // 0x0143C3B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1867, ????);     
            // 0x0143C3B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143C3BC: STRB w8, [x20, #0x7a]      | static_value_0373707A = true;            //  dest_result_addr=57897082
            label_0:
            // 0x0143C3C0: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x0143C3C4: LDR x8, [x8, #0x390]       | X8 = 1152921510121223712;               
            // 0x0143C3C8: LDR x20, [x8]              | X20 = typeof(CHECK_POINT_STATE[]);      
            // 0x0143C3CC: MOV x0, x20                | X0 = 1152921510121223712 (0x1000000148AEB620);//ML01
            // 0x0143C3D0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(CHECK_POINT_STATE[]), ????);
            // 0x0143C3D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0143C3D8: MOV w1, w19                | W1 = W1;//m1                            
            // 0x0143C3DC: MOV x0, x20                | X0 = 1152921510121223712 (0x1000000148AEB620);//ML01
            // 0x0143C3E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143C3E4: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(CHECK_POINT_STATE[]), ????);
        
        }
    
    }

}
