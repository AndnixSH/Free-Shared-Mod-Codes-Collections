using UnityEngine;
private sealed class StringUtils.ActionLine : MulticastDelegate
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x0291CD70 (43109744), len: 16  VirtAddr: 0x0291CD70 RVA: 0x0291CD70 token: 100686912 methodIndex: 49311 delegateWrapperIndex: 0 methodInvoker: 0
    public StringUtils.ActionLine(object object, IntPtr method)
    {
        //
        // Disasemble & Code
        // 0x0291CD70: LDR x8, [x2]               | X8 = method;                            
        // 0x0291CD74: STP x1, x2, [x0, #0x20]    | mem[1152921514017344400] = object;  mem[1152921514017344408] = method;  //  dest_result_addr=1152921514017344400 |  dest_result_addr=1152921514017344408
        mem[1152921514017344400] = object;
        mem[1152921514017344408] = method;
        // 0x0291CD78: STR x8, [x0, #0x10]        | mem[1152921514017344384] = method;       //  dest_result_addr=1152921514017344384
        mem[1152921514017344384] = method;
        // 0x0291CD7C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0291CE24 (43109924), len: 968  VirtAddr: 0x0291CE24 RVA: 0x0291CE24 token: 100686913 methodIndex: 49312 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void Invoke(System.IO.TextWriter textWriter, string line)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        label_1:
        // 0x0291CE24: STP x24, x23, [sp, #-0x40]! | stack[1152921514017472976] = ???;  stack[1152921514017472984] = ???;  //  dest_result_addr=1152921514017472976 |  dest_result_addr=1152921514017472984
        // 0x0291CE28: STP x22, x21, [sp, #0x10]  | stack[1152921514017472992] = ???;  stack[1152921514017473000] = ???;  //  dest_result_addr=1152921514017472992 |  dest_result_addr=1152921514017473000
        // 0x0291CE2C: STP x20, x19, [sp, #0x20]  | stack[1152921514017473008] = ???;  stack[1152921514017473016] = ???;  //  dest_result_addr=1152921514017473008 |  dest_result_addr=1152921514017473016
        // 0x0291CE30: STP x29, x30, [sp, #0x30]  | stack[1152921514017473024] = ???;  stack[1152921514017473032] = ???;  //  dest_result_addr=1152921514017473024 |  dest_result_addr=1152921514017473032
        // 0x0291CE34: ADD x29, sp, #0x30         | X29 = (1152921514017472976 + 48) = 1152921514017473024 (0x1000000230EAC200);
        // 0x0291CE38: SUB sp, sp, #0x10          | SP = (1152921514017472976 - 16) = 1152921514017472960 (0x1000000230EAC1C0);
        // 0x0291CE3C: MOV x23, x0                | X23 = 1152921514017485040 (0x1000000230EAF0F0);//ML01
        // 0x0291CE40: LDR x0, [x23, #0x58]       | 
        // 0x0291CE44: MOV x19, x2                | X19 = line;//m1                         
        // 0x0291CE48: MOV x20, x1                | X20 = textWriter;//m1                   
        // 0x0291CE4C: CBZ x0, #0x291ce5c         | if (this == null) goto label_0;         
        if(this == null)
        {
            goto label_0;
        }
        // 0x0291CE50: MOV x1, x20                | X1 = textWriter;//m1                    
        // 0x0291CE54: MOV x2, x19                | X2 = line;//m1                          
        val_13 = line;
        // 0x0291CE58: BL #0x291ce24              |  R0 = label_1();                        
        label_0:
        // 0x0291CE5C: LDR x0, [x23, #0x10]       | 
        // 0x0291CE60: STR x0, [sp, #8]           | stack[1152921514017472968] = this;       //  dest_result_addr=1152921514017472968
        // 0x0291CE64: LDP x22, x21, [x23, #0x20] |                                          //  | 
        // 0x0291CE68: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291CE6C: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
        // 0x0291CE70: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291CE74: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
        // 0x0291CE78: LDRB w9, [x21, #0x4e]      | W9 = X21 + 78;                          
        // 0x0291CE7C: AND w8, w0, #1             | W8 = (X21 & 1);                         
        var val_1 = X21 & 1;
        // 0x0291CE80: TBZ w8, #0, #0x291cf1c     | if (((X21 & 1) & 0x1) == 0) goto label_2;
        if((val_1 & 1) == 0)
        {
            goto label_2;
        }
        // 0x0291CE84: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x0291CE88: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
        // 0x0291CE8C: B.NE #0x291cf2c            | if (X21 + 78 != 0x2) goto label_3;      
        if((X21 + 78) != 2)
        {
            goto label_3;
        }
        // 0x0291CE90: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
        // 0x0291CE94: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
        // 0x0291CE98: B.EQ #0x291cfe8            | if (X21 + 76 == 65535) goto label_7;    
        if((X21 + 76) == 65535)
        {
            goto label_7;
        }
        // 0x0291CE9C: CBZ x22, #0x291ceac        | if (X22 == 0) goto label_5;             
        if(X22 == 0)
        {
            goto label_5;
        }
        // 0x0291CEA0: LDR x8, [x22]              | X8 = X22;                               
        // 0x0291CEA4: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
        // 0x0291CEA8: TBNZ w8, #0, #0x291cfe8    | if ((X22 + 237 & 0x1) != 0) goto label_7;
        if(((X22 + 237) & 1) != 0)
        {
            goto label_7;
        }
        label_5:
        // 0x0291CEAC: LDR x8, [x23, #0x18]       | 
        // 0x0291CEB0: CBZ x8, #0x291cfe8         | if (X22 + 237 == 0) goto label_7;       
        if((X22 + 237) == 0)
        {
            goto label_7;
        }
        // 0x0291CEB4: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291CEB8: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
        // 0x0291CEBC: MOV w23, w0                | W23 = X21;//m1                          
        // 0x0291CEC0: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291CEC4: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_2 = X21.pressedSprite;
        // 0x0291CEC8: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
        // 0x0291CECC: TBZ w23, #0, #0x291d03c    | if ((X21 & 0x1) == 0) goto label_8;     
        if((X21 & 1) == 0)
        {
            goto label_8;
        }
        // 0x0291CED0: TBZ w0, #0, #0x291d0f4     | if ((val_2 & 0x1) == 0) goto label_9;   
        if((val_2 & 1) == 0)
        {
            goto label_9;
        }
        // 0x0291CED4: LDR x8, [x22]              | X8 = X22;                               
        var val_19 = X22;
        // 0x0291CED8: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
        // 0x0291CEDC: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
        // 0x0291CEE0: LDRH w9, [x8, #0x102]      | W9 = X22 + 258;                         
        // 0x0291CEE4: CBZ x9, #0x291cf10         | if (X22 + 258 == 0) goto label_10;      
        if((X22 + 258) == 0)
        {
            goto label_10;
        }
        // 0x0291CEE8: LDR x10, [x8, #0x98]       | X10 = X22 + 152;                        
        var val_11 = X22 + 152;
        // 0x0291CEEC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x0291CEF0: ADD x10, x10, #8           | X10 = (X22 + 152 + 8);                  
        val_11 = val_11 + 8;
        label_12:
        // 0x0291CEF4: LDUR x12, [x10, #-8]       | X12 = (X22 + 152 + 8) + -8;             
        // 0x0291CEF8: CMP x12, x1                | STATE = COMPARE((X22 + 152 + 8) + -8, X21 + 24)
        // 0x0291CEFC: B.EQ #0x291d13c            | if ((X22 + 152 + 8) + -8 == X21 + 24) goto label_11;
        if(((X22 + 152 + 8) + -8) == (X21 + 24))
        {
            goto label_11;
        }
        // 0x0291CF00: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x0291CF04: ADD x10, x10, #0x10        | X10 = ((X22 + 152 + 8) + 16);           
        val_11 = val_11 + 16;
        // 0x0291CF08: CMP x11, x9                | STATE = COMPARE((0 + 1), X22 + 258)     
        // 0x0291CF0C: B.LO #0x291cef4            | if (0 < X22 + 258) goto label_12;       
        if(val_12 < (X22 + 258))
        {
            goto label_12;
        }
        label_10:
        // 0x0291CF10: MOV x0, x22                | X0 = X22;//m1                           
        val_14 = X22;
        // 0x0291CF14: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
        // 0x0291CF18: B #0x291d14c               |  goto label_13;                         
        goto label_13;
        label_2:
        // 0x0291CF1C: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
        // 0x0291CF20: B.NE #0x291cfb8            | if (X21 + 78 != 0x2) goto label_14;     
        if((X21 + 78) != 2)
        {
            goto label_14;
        }
        // 0x0291CF24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0291CF28: B #0x291cfec               |  goto label_15;                         
        goto label_15;
        label_3:
        // 0x0291CF2C: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
        // 0x0291CF30: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
        // 0x0291CF34: B.EQ #0x291d014            | if (X21 + 76 == 65535) goto label_19;   
        if((X21 + 76) == 65535)
        {
            goto label_19;
        }
        // 0x0291CF38: CBZ x22, #0x291cf48        | if (X22 == 0) goto label_17;            
        if(X22 == 0)
        {
            goto label_17;
        }
        // 0x0291CF3C: LDR x8, [x22]              | X8 = X22;                               
        // 0x0291CF40: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
        // 0x0291CF44: TBNZ w8, #0, #0x291d014    | if ((X22 + 237 & 0x1) != 0) goto label_19;
        if(((X22 + 237) & 1) != 0)
        {
            goto label_19;
        }
        label_17:
        // 0x0291CF48: LDR x8, [x23, #0x18]       | 
        // 0x0291CF4C: CBZ x8, #0x291d014         | if (X22 + 237 == 0) goto label_19;      
        if((X22 + 237) == 0)
        {
            goto label_19;
        }
        // 0x0291CF50: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291CF54: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
        // 0x0291CF58: MOV w22, w0                | W22 = X21;//m1                          
        // 0x0291CF5C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291CF60: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_3 = X21.pressedSprite;
        // 0x0291CF64: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
        // 0x0291CF68: TBZ w22, #0, #0x291d098    | if ((X21 & 0x1) == 0) goto label_20;    
        if((X21 & 1) == 0)
        {
            goto label_20;
        }
        // 0x0291CF6C: TBZ w0, #0, #0x291d108     | if ((val_3 & 0x1) == 0) goto label_21;  
        if((val_3 & 1) == 0)
        {
            goto label_21;
        }
        // 0x0291CF70: LDR x8, [x20]              | X8 = typeof(System.IO.TextWriter);      
        // 0x0291CF74: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
        // 0x0291CF78: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
        // 0x0291CF7C: LDRH w9, [x8, #0x102]      | W9 = System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count;
        // 0x0291CF80: CBZ x9, #0x291cfac         | if (System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
        // 0x0291CF84: LDR x10, [x8, #0x98]       | X10 = System.IO.TextWriter.__il2cppRuntimeField_interfaceOffsets;
        // 0x0291CF88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x0291CF8C: ADD x10, x10, #8           | X10 = (System.IO.TextWriter.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504622964744 (0x1000000000F5F008);
        label_24:
        // 0x0291CF90: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x0291CF94: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X21 + 24)
        // 0x0291CF98: B.EQ #0x291d174            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X21 + 24) goto label_23;
        // 0x0291CF9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x0291CFA0: ADD x10, x10, #0x10        | X10 = (1152921504622964744 + 16) = 1152921504622964760 (0x1000000000F5F018);
        // 0x0291CFA4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count)
        // 0x0291CFA8: B.LO #0x291cf90            | if (0 < System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count) goto label_24;
        label_22:
        // 0x0291CFAC: MOV x0, x20                | X0 = textWriter;//m1                    
        val_15 = textWriter;
        // 0x0291CFB0: BL #0x2776c24              | X0 = sub_2776C24( ?? textWriter, ????); 
        // 0x0291CFB4: B #0x291d184               |  goto label_25;                         
        goto label_25;
        label_14:
        // 0x0291CFB8: LDR x5, [sp, #8]           | X5 = this;                              
        // 0x0291CFBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0291CFC0: MOV x1, x22                | X1 = X22;//m1                           
        // 0x0291CFC4: MOV x2, x20                | X2 = textWriter;//m1                    
        // 0x0291CFC8: MOV x3, x19                | X3 = line;//m1                          
        // 0x0291CFCC: MOV x4, x21                | X4 = X21;//m1                           
        // 0x0291CFD0: SUB sp, x29, #0x30         | SP = (1152921514017473024 - 48) = 1152921514017472976 (0x1000000230EAC1D0);
        // 0x0291CFD4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0291CFD8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0291CFDC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0291CFE0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0291CFE4: BR x5                      | X0 = this( ?? 0x0, ????);               
        label_7:
        // 0x0291CFE8: MOV x0, x22                | X0 = X22;//m1                           
        label_15:
        // 0x0291CFEC: LDR x4, [sp, #8]           | X4 = this;                              
        // 0x0291CFF0: MOV x1, x20                | X1 = textWriter;//m1                    
        // 0x0291CFF4: MOV x2, x19                | X2 = line;//m1                          
        // 0x0291CFF8: MOV x3, x21                | X3 = X21;//m1                           
        label_42:
        // 0x0291CFFC: SUB sp, x29, #0x30         | SP = (1152921514017473024 - 48) = 1152921514017472976 (0x1000000230EAC1D0);
        // 0x0291D000: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0291D004: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0291D008: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0291D00C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0291D010: BR x4                      | X0 = this( ?? X22, ????);               
        label_19:
        // 0x0291D014: LDR x3, [sp, #8]           | X3 = this;                              
        // 0x0291D018: MOV x0, x20                | X0 = textWriter;//m1                    
        // 0x0291D01C: MOV x1, x19                | X1 = line;//m1                          
        // 0x0291D020: MOV x2, x21                | X2 = X21;//m1                           
        label_43:
        // 0x0291D024: SUB sp, x29, #0x30         | SP = (1152921514017473024 - 48) = 1152921514017472976 (0x1000000230EAC1D0);
        // 0x0291D028: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0291D02C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x0291D030: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x0291D034: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x0291D038: BR x3                      | X0 = this( ?? textWriter, ????);        
        label_8:
        // 0x0291D03C: LDRH w23, [x21, #0x4c]     | W23 = X21 + 76;                         
        // 0x0291D040: TBZ w0, #0, #0x291d11c     | if ((val_2 & 0x1) == 0) goto label_26;  
        if((val_2 & 1) == 0)
        {
            goto label_26;
        }
        // 0x0291D044: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291D048: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_4 = X21.pressedSprite;
        // 0x0291D04C: LDR x9, [x22]              | X9 = X22;                               
        // 0x0291D050: MOV x8, x0                 | X8 = val_4;//m1                         
        // 0x0291D054: LDRH w10, [x9, #0x102]     | W10 = X22 + 258;                        
        // 0x0291D058: CBZ x10, #0x291d084        | if (X22 + 258 == 0) goto label_27;      
        if((X22 + 258) == 0)
        {
            goto label_27;
        }
        // 0x0291D05C: LDR x11, [x9, #0x98]       | X11 = X22 + 152;                        
        var val_14 = X22 + 152;
        // 0x0291D060: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_15 = 0;
        // 0x0291D064: ADD x11, x11, #8           | X11 = (X22 + 152 + 8);                  
        val_14 = val_14 + 8;
        label_29:
        // 0x0291D068: LDUR x13, [x11, #-8]       | X13 = (X22 + 152 + 8) + -8;             
        // 0x0291D06C: CMP x13, x8                | STATE = COMPARE((X22 + 152 + 8) + -8, val_4)
        // 0x0291D070: B.EQ #0x291d1a8            | if ((X22 + 152 + 8) + -8 == val_4) goto label_28;
        if(((X22 + 152 + 8) + -8) == val_4)
        {
            goto label_28;
        }
        // 0x0291D074: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_15 = val_15 + 1;
        // 0x0291D078: ADD x11, x11, #0x10        | X11 = ((X22 + 152 + 8) + 16);           
        val_14 = val_14 + 16;
        // 0x0291D07C: CMP x12, x10               | STATE = COMPARE((0 + 1), X22 + 258)     
        // 0x0291D080: B.LO #0x291d068            | if (0 < X22 + 258) goto label_29;       
        if(val_15 < (X22 + 258))
        {
            goto label_29;
        }
        label_27:
        // 0x0291D084: MOV x0, x22                | X0 = X22;//m1                           
        val_16 = X22;
        // 0x0291D088: MOV x1, x8                 | X1 = val_4;//m1                         
        // 0x0291D08C: MOV w2, w23                | W2 = X21 + 76;//m1                      
        // 0x0291D090: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
        // 0x0291D094: B #0x291d1b8               |  goto label_30;                         
        goto label_30;
        label_20:
        // 0x0291D098: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
        // 0x0291D09C: TBZ w0, #0, #0x291d12c     | if ((val_3 & 0x1) == 0) goto label_31;  
        if((val_3 & 1) == 0)
        {
            goto label_31;
        }
        // 0x0291D0A0: MOV x0, x21                | X0 = X21;//m1                           
        // 0x0291D0A4: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_5 = X21.pressedSprite;
        // 0x0291D0A8: LDR x9, [x20]              | X9 = typeof(System.IO.TextWriter);      
        // 0x0291D0AC: MOV x8, x0                 | X8 = val_5;//m1                         
        // 0x0291D0B0: LDRH w10, [x9, #0x102]     | W10 = System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count;
        // 0x0291D0B4: CBZ x10, #0x291d0e0        | if (System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
        // 0x0291D0B8: LDR x11, [x9, #0x98]       | X11 = System.IO.TextWriter.__il2cppRuntimeField_interfaceOffsets;
        // 0x0291D0BC: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_16 = 0;
        // 0x0291D0C0: ADD x11, x11, #8           | X11 = (System.IO.TextWriter.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504622964744 (0x1000000000F5F008);
        label_34:
        // 0x0291D0C4: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x0291D0C8: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_5)
        // 0x0291D0CC: B.EQ #0x291d1cc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_5) goto label_33;
        // 0x0291D0D0: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_16 = val_16 + 1;
        // 0x0291D0D4: ADD x11, x11, #0x10        | X11 = (1152921504622964744 + 16) = 1152921504622964760 (0x1000000000F5F018);
        // 0x0291D0D8: CMP x12, x10               | STATE = COMPARE((0 + 1), System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count)
        // 0x0291D0DC: B.LO #0x291d0c4            | if (0 < System.IO.TextWriter.__il2cppRuntimeField_interface_offsets_count) goto label_34;
        label_32:
        // 0x0291D0E0: MOV x0, x20                | X0 = textWriter;//m1                    
        val_17 = textWriter;
        // 0x0291D0E4: MOV x1, x8                 | X1 = val_5;//m1                         
        // 0x0291D0E8: MOV w2, w22                | W2 = X21 + 76;//m1                      
        val_13 = X21 + 76;
        // 0x0291D0EC: BL #0x2776c24              | X0 = sub_2776C24( ?? textWriter, ????); 
        // 0x0291D0F0: B #0x291d1dc               |  goto label_35;                         
        goto label_35;
        label_9:
        // 0x0291D0F4: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x0291D0F8: LDR x9, [x22]              | X9 = X22;                               
        // 0x0291D0FC: ADD x8, x9, x8, lsl #4     | X8 = (X22 + (X21 + 76) << 4);           
        var val_6 = X22 + ((X21 + 76) << 4);
        // 0x0291D100: LDR x0, [x8, #0x118]       | X0 = (X22 + (X21 + 76) << 4) + 280;     
        val_18 = mem[(X22 + (X21 + 76) << 4) + 280];
        val_18 = (X22 + (X21 + 76) << 4) + 280;
        // 0x0291D104: B #0x291d150               |  goto label_36;                         
        goto label_36;
        label_21:
        // 0x0291D108: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x0291D10C: LDR x9, [x20]              | X9 = typeof(System.IO.TextWriter);      
        // 0x0291D110: ADD x8, x9, x8, lsl #4     | X8 = (1152921504622927872 + (X21 + 76) << 4);
        System.IO.TextWriter val_7 = 1152921504622927872 + ((X21 + 76) << 4);
        // 0x0291D114: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
        val_19 = mem[(1152921504622927872 + (X21 + 76) << 4) + 280];
        // 0x0291D118: B #0x291d188               |  goto label_37;                         
        goto label_37;
        label_26:
        // 0x0291D11C: LDR x8, [x22]              | X8 = X22;                               
        var val_17 = X22;
        // 0x0291D120: ADD x8, x8, w23, uxtw #4   | X8 = (X22 + X21 + 76);                  
        val_17 = val_17 + (X21 + 76);
        // 0x0291D124: LDP x4, x3, [x8, #0x110]   | X4 = (X22 + X21 + 76) + 272; X3 = (X22 + X21 + 76) + 272 + 8; //  | 
        // 0x0291D128: B #0x291d1bc               |  goto label_38;                         
        goto label_38;
        label_31:
        // 0x0291D12C: LDR x8, [x20]              | X8 = typeof(System.IO.TextWriter);      
        // 0x0291D130: ADD x8, x8, w22, uxtw #4   | X8 = (1152921504622927872 + X21 + 76);  
        System.IO.TextWriter val_8 = 1152921504622927872 + (X21 + 76);
        // 0x0291D134: LDP x3, x2, [x8, #0x110]   | X3 = addr_off(public System.Boolean System.Object::Equals(object obj));   //  |  not_find_field!1:280
        // 0x0291D138: B #0x291d1e0               |  goto label_39;                         
        goto label_39;
        label_11:
        // 0x0291D13C: LDR w9, [x10]              | W9 = (X22 + 152 + 8);                   
        var val_18 = val_11;
        // 0x0291D140: ADD w9, w9, w2             | W9 = ((X22 + 152 + 8) + X21 + 76);      
        val_18 = val_18 + (X21 + 76);
        // 0x0291D144: ADD x8, x8, w9, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
        val_19 = val_19 + val_18;
        // 0x0291D148: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
        val_14 = val_19 + 272;
        label_13:
        // 0x0291D14C: LDR x0, [x0, #8]           | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
        val_18 = mem[((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8];
        val_18 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
        label_36:
        // 0x0291D150: MOV x1, x21                | X1 = X21;//m1                           
        // 0x0291D154: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
        // 0x0291D158: MOV x8, x0                 | X8 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
        // 0x0291D15C: LDR x4, [x8]               | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
        // 0x0291D160: MOV x0, x22                | X0 = X22;//m1                           
        // 0x0291D164: MOV x1, x20                | X1 = textWriter;//m1                    
        // 0x0291D168: MOV x2, x19                | X2 = line;//m1                          
        // 0x0291D16C: MOV x3, x8                 | X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
        // 0x0291D170: B #0x291cffc               |  goto label_42;                         
        goto label_42;
        label_23:
        // 0x0291D174: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x0291D178: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
        // 0x0291D17C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504622927872 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
        // 0x0291D180: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504622927872 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
        label_25:
        // 0x0291D184: LDR x0, [x0, #8]           | 
        label_37:
        // 0x0291D188: MOV x1, x21                | X1 = X21;//m1                           
        // 0x0291D18C: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_3, ????);      
        // 0x0291D190: MOV x8, x0                 | X8 = val_3;//m1                         
        // 0x0291D194: LDR x3, [x8]               | X3 = typeof(UnityEngine.Sprite);        
        // 0x0291D198: MOV x0, x20                | X0 = textWriter;//m1                    
        // 0x0291D19C: MOV x1, x19                | X1 = line;//m1                          
        // 0x0291D1A0: MOV x2, x8                 | X2 = val_3;//m1                         
        // 0x0291D1A4: B #0x291d024               |  goto label_43;                         
        goto label_43;
        label_28:
        // 0x0291D1A8: LDR w8, [x11]              | W8 = (X22 + 152 + 8);                   
        var val_20 = val_14;
        // 0x0291D1AC: ADD w8, w8, w23            | W8 = ((X22 + 152 + 8) + X21 + 76);      
        val_20 = val_20 + (X21 + 76);
        // 0x0291D1B0: ADD x8, x9, w8, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
        val_20 = X22 + val_20;
        // 0x0291D1B4: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
        val_16 = val_20 + 272;
        label_30:
        // 0x0291D1B8: LDP x4, x3, [x0]           | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272); X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
        label_38:
        // 0x0291D1BC: MOV x0, x22                | X0 = X22;//m1                           
        // 0x0291D1C0: MOV x1, x20                | X1 = textWriter;//m1                    
        // 0x0291D1C4: MOV x2, x19                | X2 = line;//m1                          
        // 0x0291D1C8: B #0x291cffc               |  goto label_42;                         
        goto label_42;
        label_33:
        // 0x0291D1CC: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x0291D1D0: ADD w8, w8, w22            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
        // 0x0291D1D4: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504622927872 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
        // 0x0291D1D8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504622927872 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
        label_35:
        // 0x0291D1DC: LDP x3, x2, [x0]           | X3 = typeof(UnityEngine.Sprite);         //  | 
        label_39:
        // 0x0291D1E0: MOV x0, x20                | X0 = textWriter;//m1                    
        // 0x0291D1E4: MOV x1, x19                | X1 = line;//m1                          
        // 0x0291D1E8: B #0x291d024               |  goto label_43;                         
        goto label_43;
    
    }
    //
    // Offset in libil2cpp.so: 0x0291DC40 (43113536), len: 52  VirtAddr: 0x0291DC40 RVA: 0x0291DC40 token: 100686914 methodIndex: 49313 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual System.IAsyncResult BeginInvoke(System.IO.TextWriter textWriter, string line, System.AsyncCallback callback, object object)
    {
        //
        // Disasemble & Code
        // 0x0291DC40: STP x29, x30, [sp, #-0x10]! | stack[1152921514017625984] = ???;  stack[1152921514017625992] = ???;  //  dest_result_addr=1152921514017625984 |  dest_result_addr=1152921514017625992
        // 0x0291DC44: MOV x29, sp                | X29 = 1152921514017625984 (0x1000000230ED1780);//ML01
        // 0x0291DC48: SUB sp, sp, #0x20          | SP = (1152921514017625984 - 32) = 1152921514017625952 (0x1000000230ED1760);
        // 0x0291DC4C: STP xzr, xzr, [sp, #0x10]  | stack[1152921514017625968] = 0x0;  stack[1152921514017625976] = 0x0;  //  dest_result_addr=1152921514017625968 |  dest_result_addr=1152921514017625976
        // 0x0291DC50: STP xzr, x2, [sp, #8]      | stack[1152921514017625960] = 0x0;  stack[1152921514017625968] = line;  //  dest_result_addr=1152921514017625960 |  dest_result_addr=1152921514017625968
        // 0x0291DC54: STR x1, [sp, #8]           | stack[1152921514017625960] = textWriter;  //  dest_result_addr=1152921514017625960
        // 0x0291DC58: ADD x1, sp, #8             | X1 = (1152921514017625952 + 8) = 1152921514017625960 (0x1000000230ED1768);
        // 0x0291DC5C: MOV x2, x3                 | X2 = callback;//m1                      
        // 0x0291DC60: MOV x3, x4                 | X3 = object;//m1                        
        // 0x0291DC64: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
        // 0x0291DC68: MOV sp, x29                | SP = 1152921514017625984 (0x1000000230ED1780);//ML01
        // 0x0291DC6C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x0291DC70: RET                        |  return (System.IAsyncResult)this;      
        return (System.IAsyncResult)this;
        //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0291DC74 (43113588), len: 16  VirtAddr: 0x0291DC74 RVA: 0x0291DC74 token: 100686915 methodIndex: 49314 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void EndInvoke(System.IAsyncResult result)
    {
        //
        // Disasemble & Code
        // 0x0291DC74: MOV x8, x1                 | X8 = result;//m1                        
        // 0x0291DC78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0291DC7C: MOV x0, x8                 | X0 = result;//m1                        
        // 0x0291DC80: B #0x278fde8               | X0 = sub_278FDE8( ?? result, ????);     
    
    }

}
