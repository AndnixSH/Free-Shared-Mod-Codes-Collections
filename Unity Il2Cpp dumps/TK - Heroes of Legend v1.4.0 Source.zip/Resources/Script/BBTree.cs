using UnityEngine;

namespace Pathfinding
{
    public class BBTree
    {
        // Fields
        private Pathfinding.BBTree.BBTreeBox[] arr; //  0x00000010
        private int count; //  0x00000018
        public Pathfinding.INavmeshHolder graph; //  0x00000020
        
        // Properties
        public UnityEngine.Rect Size { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01686A60 (23620192), len: 128  VirtAddr: 0x01686A60 RVA: 0x01686A60 token: 100683162 methodIndex: 49884 delegateWrapperIndex: 0 methodInvoker: 0
        public BBTree(Pathfinding.INavmeshHolder graph)
        {
            //
            // Disasemble & Code
            // 0x01686A60: STP x22, x21, [sp, #-0x30]! | stack[1152921513410019904] = ???;  stack[1152921513410019912] = ???;  //  dest_result_addr=1152921513410019904 |  dest_result_addr=1152921513410019912
            // 0x01686A64: STP x20, x19, [sp, #0x10]  | stack[1152921513410019920] = ???;  stack[1152921513410019928] = ???;  //  dest_result_addr=1152921513410019920 |  dest_result_addr=1152921513410019928
            // 0x01686A68: STP x29, x30, [sp, #0x20]  | stack[1152921513410019936] = ???;  stack[1152921513410019944] = ???;  //  dest_result_addr=1152921513410019936 |  dest_result_addr=1152921513410019944
            // 0x01686A6C: ADD x29, sp, #0x20         | X29 = (1152921513410019904 + 32) = 1152921513410019936 (0x100000020CB5C260);
            // 0x01686A70: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01686A74: LDRB w8, [x21, #0xf1]      | W8 = (bool)static_value_037380F1;       
            // 0x01686A78: MOV x19, x1                | X19 = graph;//m1                        
            // 0x01686A7C: MOV x20, x0                | X20 = 1152921513410031952 (0x100000020CB5F150);//ML01
            // 0x01686A80: TBNZ w8, #0, #0x1686a9c    | if (static_value_037380F1 == true) goto label_0;
            // 0x01686A84: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x01686A88: LDR x8, [x8, #0x788]       | X8 = 0x2B8F118;                         
            // 0x01686A8C: LDR w0, [x8]               | W0 = 0x1308;                            
            // 0x01686A90: BL #0x2782188              | X0 = sub_2782188( ?? 0x1308, ????);     
            // 0x01686A94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01686A98: STRB w8, [x21, #0xf1]      | static_value_037380F1 = true;            //  dest_result_addr=57901297
            label_0:
            // 0x01686A9C: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x01686AA0: LDR x8, [x8, #0x848]       | X8 = 1152921513410003856;               
            // 0x01686AA4: LDR x21, [x8]              | X21 = typeof(BBTreeBox[]);              
            // 0x01686AA8: MOV x0, x21                | X0 = 1152921513410003856 (0x100000020CB58390);//ML01
            // 0x01686AAC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(BBTreeBox[]), ????);
            // 0x01686AB0: ORR w1, wzr, #6            | W1 = 6(0x6);                            
            // 0x01686AB4: MOV x0, x21                | X0 = 1152921513410003856 (0x100000020CB58390);//ML01
            // 0x01686AB8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(BBTreeBox[]), ????);
            // 0x01686ABC: STR x0, [x20, #0x10]       | this.arr = typeof(BBTreeBox[]);          //  dest_result_addr=1152921513410031968
            this.arr = null;
            // 0x01686AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686AC4: MOV x0, x20                | X0 = 1152921513410031952 (0x100000020CB5F150);//ML01
            // 0x01686AC8: BL #0x16f59f0              | this..ctor();                           
            // 0x01686ACC: STR x19, [x20, #0x20]      | this.graph = graph;                      //  dest_result_addr=1152921513410031984
            this.graph = graph;
            // 0x01686AD0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01686AD4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01686AD8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01686ADC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01686AE0 (23620320), len: 124  VirtAddr: 0x01686AE0 RVA: 0x01686AE0 token: 100683163 methodIndex: 49885 delegateWrapperIndex: 0 methodInvoker: 0
        public UnityEngine.Rect get_Size()
        {
            //
            // Disasemble & Code
            // 0x01686AE0: STP x20, x19, [sp, #-0x20]! | stack[1152921513410172880] = ???;  stack[1152921513410172888] = ???;  //  dest_result_addr=1152921513410172880 |  dest_result_addr=1152921513410172888
            // 0x01686AE4: STP x29, x30, [sp, #0x10]  | stack[1152921513410172896] = ???;  stack[1152921513410172904] = ???;  //  dest_result_addr=1152921513410172896 |  dest_result_addr=1152921513410172904
            // 0x01686AE8: ADD x29, sp, #0x10         | X29 = (1152921513410172880 + 16) = 1152921513410172896 (0x100000020CB817E0);
            // 0x01686AEC: SUB sp, sp, #0x10          | SP = (1152921513410172880 - 16) = 1152921513410172864 (0x100000020CB817C0);
            // 0x01686AF0: LDR w8, [x0, #0x18]        | W8 = this.count; //P2                   
            // 0x01686AF4: CBZ w8, #0x1686b24         | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x01686AF8: LDR x19, [x0, #0x10]       | X19 = this.arr; //P2                    
            // 0x01686AFC: CBNZ x19, #0x1686b04       | if (this.arr != null) goto label_1;     
            if(this.arr != null)
            {
                goto label_1;
            }
            // 0x01686B00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x01686B04: LDR w8, [x19, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686B08: CBNZ w8, #0x1686b18        | if (this.arr.Length != 0) goto label_2; 
            if(this.arr.Length != 0)
            {
                goto label_2;
            }
            // 0x01686B0C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01686B10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686B14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_2:
            // 0x01686B18: LDP s0, s1, [x19, #0x20]   | S0 = this.arr[0] S1 = this.arr[0]        //  | 
            BBTreeBox val_1 = this.arr[0];
            BBTreeBox val_2 = this.arr[0];
            // 0x01686B1C: LDP s2, s3, [x19, #0x28]   | S2 = this.arr[1] S3 = this.arr[1]        //  | 
            BBTreeBox val_3 = this.arr[1];
            BBTreeBox val_4 = this.arr[1];
            // 0x01686B20: B #0x1686b4c               |  goto label_3;                          
            goto label_3;
            label_0:
            // 0x01686B24: FMOV s0, wzr               | S0 = 0f;                                
            // 0x01686B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686B2C: MOV x0, sp                 | X0 = 1152921513410172864 (0x100000020CB817C0);//ML01
            // 0x01686B30: MOV v1.16b, v0.16b         | V1 = 0;//m1                             
            // 0x01686B34: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
            // 0x01686B38: MOV v3.16b, v0.16b         | V3 = 0;//m1                             
            // 0x01686B3C: STP xzr, xzr, [sp]         | stack[1152921513410172864] = 0x0;  stack[1152921513410172872] = 0x0;  //  dest_result_addr=1152921513410172864 |  dest_result_addr=1152921513410172872
            // 0x01686B40: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
            // 0x01686B44: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
            // 0x01686B48: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
            label_3:
            // 0x01686B4C: SUB sp, x29, #0x10         | SP = (1152921513410172896 - 16) = 1152921513410172880 (0x100000020CB817D0);
            // 0x01686B50: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01686B54: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01686B58: RET                        |  return new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f};
            return new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f};
            //  |  // // {name=val_0.m_XMin, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.m_YMin, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.m_Width, type=System.Single, size=4, nSRN=2 }
            //  |  // // {name=val_0.m_Height, type=System.Single, size=4, nSRN=3 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01686B5C (23620444), len: 8  VirtAddr: 0x01686B5C RVA: 0x01686B5C token: 100683164 methodIndex: 49886 delegateWrapperIndex: 0 methodInvoker: 0
        public void Clear()
        {
            //
            // Disasemble & Code
            // 0x01686B5C: STR wzr, [x0, #0x18]       | this.count = 0;                          //  dest_result_addr=1152921513410333800
            this.count = 0;
            // 0x01686B60: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01686B64 (23620452), len: 332  VirtAddr: 0x01686B64 RVA: 0x01686B64 token: 100683165 methodIndex: 49887 delegateWrapperIndex: 0 methodInvoker: 0
        private void EnsureCapacity(int c)
        {
            //
            // Disasemble & Code
            //  | 
            BBTreeBox[] val_2;
            // 0x01686B64: STP x24, x23, [sp, #-0x40]! | stack[1152921513410544304] = ???;  stack[1152921513410544312] = ???;  //  dest_result_addr=1152921513410544304 |  dest_result_addr=1152921513410544312
            // 0x01686B68: STP x22, x21, [sp, #0x10]  | stack[1152921513410544320] = ???;  stack[1152921513410544328] = ???;  //  dest_result_addr=1152921513410544320 |  dest_result_addr=1152921513410544328
            // 0x01686B6C: STP x20, x19, [sp, #0x20]  | stack[1152921513410544336] = ???;  stack[1152921513410544344] = ???;  //  dest_result_addr=1152921513410544336 |  dest_result_addr=1152921513410544344
            // 0x01686B70: STP x29, x30, [sp, #0x30]  | stack[1152921513410544352] = ???;  stack[1152921513410544360] = ???;  //  dest_result_addr=1152921513410544352 |  dest_result_addr=1152921513410544360
            // 0x01686B74: ADD x29, sp, #0x30         | X29 = (1152921513410544304 + 48) = 1152921513410544352 (0x100000020CBDC2E0);
            // 0x01686B78: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01686B7C: LDRB w8, [x21, #0xf2]      | W8 = (bool)static_value_037380F2;       
            // 0x01686B80: MOV w20, w1                | W20 = c;//m1                            
            // 0x01686B84: MOV x19, x0                | X19 = 1152921513410556368 (0x100000020CBDF1D0);//ML01
            // 0x01686B88: TBNZ w8, #0, #0x1686ba4    | if (static_value_037380F2 == true) goto label_0;
            // 0x01686B8C: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x01686B90: LDR x8, [x8, #0x6c0]       | X8 = 0x2B8F11C;                         
            // 0x01686B94: LDR w0, [x8]               | W0 = 0x1309;                            
            // 0x01686B98: BL #0x2782188              | X0 = sub_2782188( ?? 0x1309, ????);     
            // 0x01686B9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01686BA0: STRB w8, [x21, #0xf2]      | static_value_037380F2 = true;            //  dest_result_addr=57901298
            label_0:
            // 0x01686BA4: LDR x21, [x19, #0x10]      | X21 = this.arr; //P2                    
            val_2 = this.arr;
            // 0x01686BA8: CBNZ x21, #0x1686bb0       | if (this.arr != null) goto label_1;     
            if(val_2 != null)
            {
                goto label_1;
            }
            // 0x01686BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1309, ????);     
            label_1:
            // 0x01686BB0: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686BB4: CMP w8, w20                | STATE = COMPARE(this.arr.Length, c)     
            // 0x01686BB8: B.GE #0x1686c9c            | if (this.arr.Length >= c) goto label_2; 
            if(this.arr.Length >= c)
            {
                goto label_2;
            }
            // 0x01686BBC: LDR x21, [x19, #0x10]      | X21 = this.arr; //P2                    
            // 0x01686BC0: CBNZ x21, #0x1686bc8       | if (this.arr != null) goto label_3;     
            if(this.arr != null)
            {
                goto label_3;
            }
            // 0x01686BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1309, ????);     
            label_3:
            // 0x01686BC8: LDR s0, [x21, #0x18]       | S0 = this.arr.Length; //P2              
            // 0x01686BCC: FMOV s1, #1.50000000       | S1 = 1.5;                               
            // 0x01686BD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686BD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01686BD8: SCVTF s0, s0               | S0 = (float)(this.arr.Length);          
            float val_2 = (float)this.arr.Length;
            // 0x01686BDC: FMUL s0, s0, s1            | S0 = (this.arr.Length * 1.5f);          
            val_2 = val_2 * 1.5f;
            // 0x01686BE0: FCVTZS w2, s0              | W2 = (int)((this.arr.Length * 1.5f));   
            // 0x01686BE4: MOV w1, w20                | W1 = c;//m1                             
            // 0x01686BE8: BL #0x16f9490              | X0 = System.Math.Max(val1:  0, val2:  c);
            int val_1 = System.Math.Max(val1:  0, val2:  c);
            // 0x01686BEC: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x01686BF0: LDR x8, [x8, #0x848]       | X8 = 1152921513410003856;               
            // 0x01686BF4: MOV w21, w0                | W21 = val_1;//m1                        
            val_2 = val_1;
            // 0x01686BF8: LDR x20, [x8]              | X20 = typeof(BBTreeBox[]);              
            // 0x01686BFC: MOV x0, x20                | X0 = 1152921513410003856 (0x100000020CB58390);//ML01
            // 0x01686C00: BL #0x277461c              | X0 = sub_277461C( ?? typeof(BBTreeBox[]), ????);
            // 0x01686C04: MOV w1, w21                | W1 = val_1;//m1                         
            // 0x01686C08: MOV x0, x20                | X0 = 1152921513410003856 (0x100000020CB58390);//ML01
            // 0x01686C0C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(BBTreeBox[]), ????);
            // 0x01686C10: LDR w8, [x19, #0x18]       | W8 = this.count; //P2                   
            // 0x01686C14: MOV x20, x0                | X20 = 1152921513410003856 (0x100000020CB58390);//ML01
            // 0x01686C18: CMP w8, #1                 | STATE = COMPARE(this.count, 0x1)        
            // 0x01686C1C: B.LT #0x1686c98            | if (this.count < 1) goto label_4;       
            if(this.count < 1)
            {
                goto label_4;
            }
            // 0x01686C20: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_9:
            // 0x01686C24: CBNZ x20, #0x1686c2c       | if ( != null) goto label_5;             
            if(null != null)
            {
                goto label_5;
            }
            // 0x01686C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BBTreeBox[]), ????);
            label_5:
            // 0x01686C2C: LDR x22, [x19, #0x10]      | X22 = this.arr; //P2                    
            // 0x01686C30: CBNZ x22, #0x1686c38       | if (this.arr != null) goto label_6;     
            if(this.arr != null)
            {
                goto label_6;
            }
            // 0x01686C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BBTreeBox[]), ????);
            label_6:
            // 0x01686C38: LDR w8, [x20, #0x18]       | W8 = BBTreeBox[].__il2cppRuntimeField_namespaze;
            // 0x01686C3C: SXTW x23, w21              | X23 = 0 (0x00000000);                   
            // 0x01686C40: CMP w21, w8                | STATE = COMPARE(0x0, BBTreeBox[].__il2cppRuntimeField_namespaze)
            // 0x01686C44: B.LO #0x1686c54            | if (0 < BBTreeBox[].__il2cppRuntimeField_namespaze) goto label_7;
            // 0x01686C48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(BBTreeBox[]), ????);
            // 0x01686C4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686C50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(BBTreeBox[]), ????);
            label_7:
            // 0x01686C54: LDR w8, [x22, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686C58: ADD x9, x20, x23, lsl #5   | X9 = (null + 0) = 1152921513410003856 (0x100000020CB58390);
            // 0x01686C5C: ADD x24, x9, #0x20         | X24 = (1152921513410003856 + 32) = 1152921513410003888 (0x100000020CB583B0);
            // 0x01686C60: CMP w21, w8                | STATE = COMPARE(0x0, this.arr.Length)   
            // 0x01686C64: B.LO #0x1686c74            | if (0 < this.arr.Length) goto label_8;  
            if(0 < this.arr.Length)
            {
                goto label_8;
            }
            // 0x01686C68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(BBTreeBox[]), ????);
            // 0x01686C6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686C70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(BBTreeBox[]), ????);
            label_8:
            // 0x01686C74: ADD x8, x22, x23, lsl #5   | X8 = this.arr[0x0]; //PARR1             
            // 0x01686C78: LDR q0, [x8, #0x30]        | Q0 = this.arr[0x0][2]                   
            BBTreeBox val_3 = this.arr[0];
            // 0x01686C7C: ADD w21, w21, #1           | W21 = (0 + 1);                          
            val_2 = 0 + 1;
            // 0x01686C80: STR q0, [x24, #0x10]       | BBTreeBox[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_10 = this.arr[0x0][2];  //  dest_result_addr=1152921513410003904
            BBTreeBox[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_10 = val_3;
            // 0x01686C84: LDR q0, [x8, #0x20]        | Q0 = this.arr[0x0][0]                   
            BBTreeBox val_4 = this.arr[0];
            // 0x01686C88: STR q0, [x24]              | BBTreeBox[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_FFFFFFFFFFFFFFFF = this.arr[0x0][0];  //  dest_result_addr=1152921513410003888
            BBTreeBox[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_FFFFFFFFFFFFFFFF = val_4;
            // 0x01686C8C: LDR w8, [x19, #0x18]       | W8 = this.count; //P2                   
            // 0x01686C90: CMP w21, w8                | STATE = COMPARE((0 + 1), this.count)    
            // 0x01686C94: B.LT #0x1686c24            | if (val_2 < this.count) goto label_9;   
            if(val_2 < this.count)
            {
                goto label_9;
            }
            label_4:
            // 0x01686C98: STR x20, [x19, #0x10]      | this.arr = typeof(BBTreeBox[]);          //  dest_result_addr=1152921513410556384
            this.arr = null;
            label_2:
            // 0x01686C9C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01686CA0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01686CA4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01686CA8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01686CAC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01686CB0 (23620784), len: 700  VirtAddr: 0x01686CB0 RVA: 0x01686CB0 token: 100683166 methodIndex: 49888 delegateWrapperIndex: 0 methodInvoker: 0
        private int GetBox(Pathfinding.MeshNode node)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            float val_15;
            //  | 
            float val_16;
            //  | 
            float val_17;
            //  | 
            var val_18;
            // 0x01686CB0: STP x22, x21, [sp, #-0x30]! | stack[1152921513410844736] = ???;  stack[1152921513410844744] = ???;  //  dest_result_addr=1152921513410844736 |  dest_result_addr=1152921513410844744
            // 0x01686CB4: STP x20, x19, [sp, #0x10]  | stack[1152921513410844752] = ???;  stack[1152921513410844760] = ???;  //  dest_result_addr=1152921513410844752 |  dest_result_addr=1152921513410844760
            // 0x01686CB8: STP x29, x30, [sp, #0x20]  | stack[1152921513410844768] = ???;  stack[1152921513410844776] = ???;  //  dest_result_addr=1152921513410844768 |  dest_result_addr=1152921513410844776
            // 0x01686CBC: ADD x29, sp, #0x20         | X29 = (1152921513410844736 + 32) = 1152921513410844768 (0x100000020CC25860);
            // 0x01686CC0: SUB sp, sp, #0x20          | SP = (1152921513410844736 - 32) = 1152921513410844704 (0x100000020CC25820);
            // 0x01686CC4: MOV x19, x0                | X19 = 1152921513410856784 (0x100000020CC28750);//ML01
            // 0x01686CC8: LDR w21, [x19, #0x18]      | W21 = this.count; //P2                  
            // 0x01686CCC: LDR x22, [x19, #0x10]      | X22 = this.arr; //P2                    
            // 0x01686CD0: MOV x20, x1                | X20 = node;//m1                         
            // 0x01686CD4: CBNZ x22, #0x1686cdc       | if (this.arr != null) goto label_0;     
            if(this.arr != null)
            {
                goto label_0;
            }
            // 0x01686CD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01686CDC: LDR w8, [x22, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686CE0: CMP w21, w8                | STATE = COMPARE(this.count, this.arr.Length)
            // 0x01686CE4: B.LT #0x1686cf8            | if (this.count < this.arr.Length) goto label_1;
            if(this.count < this.arr.Length)
            {
                goto label_1;
            }
            // 0x01686CE8: LDR w8, [x19, #0x18]       | W8 = this.count; //P2                   
            // 0x01686CEC: MOV x0, x19                | X0 = 1152921513410856784 (0x100000020CC28750);//ML01
            // 0x01686CF0: ADD w1, w8, #1             | W1 = (this.count + 1);                  
            int val_1 = this.count + 1;
            // 0x01686CF4: BL #0x1686b64              | this.EnsureCapacity(c:  int val_1 = this.count + 1);
            this.EnsureCapacity(c:  val_1);
            label_1:
            // 0x01686CF8: LDR x21, [x19, #0x10]      | X21 = this.arr; //P2                    
            // 0x01686CFC: LDRSW x22, [x19, #0x18]    | X22 = this.count; //P2                  
            // 0x01686D00: CBNZ x21, #0x1686d08       | if (this.arr != null) goto label_2;     
            if(this.arr != null)
            {
                goto label_2;
            }
            // 0x01686D04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x01686D08: MOV x0, sp                 | X0 = 1152921513410844704 (0x100000020CC25820);//ML01
            // 0x01686D0C: MOV x2, x20                | X2 = node;//m1                          
            // 0x01686D10: STP xzr, xzr, [sp, #0x10]  | stack[1152921513410844720] = 0x0;  stack[1152921513410844728] = 0x0;  //  dest_result_addr=1152921513410844720 |  dest_result_addr=1152921513410844728
            // 0x01686D14: STP xzr, xzr, [sp]         | stack[1152921513410844704] = 0x0;  stack[1152921513410844712] = 0x0;  //  dest_result_addr=1152921513410844704 |  dest_result_addr=1152921513410844712
            // 0x01686D18: BL #0x1686d68              |  R0 = label_3();                        
            // 0x01686D1C: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686D20: CMP w22, w8                | STATE = COMPARE(this.count, this.arr.Length)
            // 0x01686D24: B.LO #0x1686d34            | if (this.count < this.arr.Length) goto label_4;
            if(this.count < this.arr.Length)
            {
                goto label_4;
            }
            // 0x01686D28: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x100000020CC25820, ????);
            // 0x01686D2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686D30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000020CC25820, ????);
            label_4:
            // 0x01686D34: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
            // 0x01686D38: ADD x8, x21, x22, lsl #5   | X8 = this.arr[(this.count) << 5]; //PARR1 
            // 0x01686D3C: STR q0, [x8, #0x30]        | this.arr[(this.count) << 5][2] = new BBTreeBox();  //  dest_result_addr=0
            this.arr[(this.count) << 5] = 0;
            // 0x01686D40: LDR q0, [sp]               | Q0 = 0x0;                               
            // 0x01686D44: STR q0, [x8, #0x20]        | this.arr[(this.count) << 5][0] = new BBTreeBox();  //  dest_result_addr=0
            this.arr[(this.count) << 5] = 0;
            // 0x01686D48: LDR w0, [x19, #0x18]       | W0 = this.count; //P2                   
            // 0x01686D4C: ADD w8, w0, #1             | W8 = (this.count + 1);                  
            int val_2 = this.count + 1;
            // 0x01686D50: STR w8, [x19, #0x18]       | this.count = (this.count + 1);           //  dest_result_addr=1152921513410856808
            this.count = val_2;
            // 0x01686D54: SUB sp, x29, #0x20         | SP = (1152921513410844768 - 32) = 1152921513410844736 (0x100000020CC25840);
            // 0x01686D58: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01686D5C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01686D60: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01686D64: RET                        |  return (System.Int32)this.count;       
            return this.count;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_3:
            // 0x01686D68: STP d9, d8, [sp, #-0x70]!  | stack[1152921513410844672] = ???;  stack[1152921513410844680] = ???;  //  dest_result_addr=1152921513410844672 |  dest_result_addr=1152921513410844680
            // 0x01686D6C: STP x28, x27, [sp, #0x10]  | stack[1152921513410844688] = ???;  stack[1152921513410844696] = ???;  //  dest_result_addr=1152921513410844688 |  dest_result_addr=1152921513410844696
            // 0x01686D70: STP x26, x25, [sp, #0x20]  | stack[1152921513410844704] = ???;  stack[1152921513410844712] = ???;  //  dest_result_addr=1152921513410844704 |  dest_result_addr=1152921513410844712
            // 0x01686D74: STP x24, x23, [sp, #0x30]  | stack[1152921513410844720] = ???;  stack[1152921513410844728] = ???;  //  dest_result_addr=1152921513410844720 |  dest_result_addr=1152921513410844728
            // 0x01686D78: STP x22, x21, [sp, #0x40]  | stack[1152921513410844736] = ;  stack[1152921513410844744] = ;  //  dest_result_addr=1152921513410844736 |  dest_result_addr=1152921513410844744
            // 0x01686D7C: STP x20, x19, [sp, #0x50]  | stack[1152921513410844752] = ;  stack[1152921513410844760] = ;  //  dest_result_addr=1152921513410844752 |  dest_result_addr=1152921513410844760
            // 0x01686D80: STP x29, x30, [sp, #0x60]  | stack[1152921513410844768] = ;  stack[1152921513410844776] = ;  //  dest_result_addr=1152921513410844768 |  dest_result_addr=1152921513410844776
            // 0x01686D84: ADD x29, sp, #0x60         | X29 = (1152921513410844672 + 96) = 1152921513410844768 (0x100000020CC25860);
            // 0x01686D88: SUB sp, sp, #0x10          | SP = (1152921513410844672 - 16) = 1152921513410844656 (0x100000020CC257F0);
            // 0x01686D8C: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01686D90: LDRB w8, [x21, #0xf9]      | W8 = (bool)static_value_037380F9;       
            // 0x01686D94: MOV x20, x2                | X20 = node;//m1                         
            // 0x01686D98: MOV x19, x0                | X19 = this.count;//m1                   
            // 0x01686D9C: TBNZ w8, #0, #0x1686db8    | if (static_value_037380F9 == true) goto label_5;
            // 0x01686DA0: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x01686DA4: LDR x8, [x8, #0x460]       | X8 = 0x2B8F138;                         
            // 0x01686DA8: LDR w0, [x8]               | W0 = 0x1310;                            
            // 0x01686DAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1310, ????);     
            // 0x01686DB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01686DB4: STRB w8, [x21, #0xf9]      | static_value_037380F9 = true;            //  dest_result_addr=57901305
            label_5:
            // 0x01686DB8: STR xzr, [sp, #8]          | stack[1152921513410844664] = 0x0;        //  dest_result_addr=1152921513410844664
            // 0x01686DBC: STR x20, [x19, #0x10]      | mem2[0] = node;                          //  dest_result_addr=0
            mem2[0] = node;
            // 0x01686DC0: CBNZ x20, #0x1686dc8       | if (node != null) goto label_6;         
            if(node != null)
            {
                goto label_6;
            }
            // 0x01686DC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1310, ????);     
            label_6:
            // 0x01686DC8: LDR x8, [x20]              | X8 = typeof(Pathfinding.MeshNode);      
            // 0x01686DCC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01686DD0: MOV x0, x20                | X0 = node;//m1                          
            // 0x01686DD4: LDR x9, [x8, #0x230]       | X9 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_230;
            // 0x01686DD8: LDR x2, [x8, #0x238]       | X2 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_238;
            // 0x01686DDC: BLR x9                     | X0 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_230();
            // 0x01686DE0: ADRP x24, #0x3660000       | X24 = 57016320 (0x3660000);             
            // 0x01686DE4: LDR x24, [x24, #0x540]     | X24 = 1152921504839380992;              
            // 0x01686DE8: MOV x21, x0                | X21 = node;//m1                         
            // 0x01686DEC: AND x22, x1, #0xffffffff   | X22 = (0 & 4294967295) = 0 (0x00000000);
            // 0x01686DF0: LDR x0, [x24]              | X0 = typeof(Pathfinding.Int3);          
            // 0x01686DF4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x01686DF8: TBZ w8, #0, #0x1686e08     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01686DFC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x01686E00: CBNZ w8, #0x1686e08        | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01686E04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_8:
            // 0x01686E08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686E0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01686E10: MOV x1, x21                | X1 = node;//m1                          
            // 0x01686E14: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x01686E18: BL #0x15490f0              | X0 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = node});
            UnityEngine.Vector3 val_3 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = node});
            // 0x01686E1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686E20: ADD x0, sp, #8             | X0 = (1152921513410844656 + 8) = 1152921513410844664 (0x100000020CC257F8);
            // 0x01686E24: MOV v1.16b, v2.16b         | V1 = val_3.z;//m1                       
            val_15 = val_3.z;
            // 0x01686E28: BL #0x2697148              | null..ctor(_x:  val_3.x, _y:  val_15 = val_3.z);
            Geometric.Point val_4 = new Geometric.Point(_x:  val_3.x, _y:  val_15);
            // 0x01686E2C: LDP w26, w25, [sp, #8]     | W26 = val_4.x; W25 = val_4.y;            //  | 
            val_16 = val_4.x;
            val_17 = val_4.y;
            // 0x01686E30: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            val_18 = 1;
            // 0x01686E34: B #0x1686ec0               |  goto label_9;                          
            goto label_9;
            label_14:
            // 0x01686E38: AND x8, x22, #0xffffffff00000000 | X8 = (0 & -4294967296) = 0 (0x00000000);
            // 0x01686E3C: ORR x22, x27, x8           | X22 = (X27 | 0);                        
            var val_5 = X27 | 0;
            // 0x01686E40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686E44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01686E48: MOV x1, x23                | X1 = X23;//m1                           
            // 0x01686E4C: MOV x2, x22                | X2 = (X27 | 0);//m1                     
            // 0x01686E50: BL #0x15490f0              | X0 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = X23});
            UnityEngine.Vector3 val_6 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = X23});
            // 0x01686E54: MOV v8.16b, v0.16b         | V8 = val_6.x;//m1                       
            // 0x01686E58: LDR s0, [sp, #8]           | S0 = val_4.x;                           
            // 0x01686E5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686E60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686E64: MOV v1.16b, v8.16b         | V1 = val_6.x;//m1                       
            // 0x01686E68: MOV v9.16b, v2.16b         | V9 = val_6.z;//m1                       
            // 0x01686E6C: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_4.x, val2:  val_6.x);
            float val_7 = System.Math.Min(val1:  val_4.x, val2:  val_6.x);
            // 0x01686E70: STR s0, [sp, #8]           | stack[1152921513410844664] = val_7;      //  dest_result_addr=1152921513410844664
            // 0x01686E74: LDR s0, [sp, #0xc]         | S0 = val_4.y;                           
            // 0x01686E78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686E7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686E80: MOV v1.16b, v9.16b         | V1 = val_6.z;//m1                       
            // 0x01686E84: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_4.y, val2:  val_6.z);
            float val_8 = System.Math.Min(val1:  val_4.y, val2:  val_6.z);
            // 0x01686E88: STR s0, [sp, #0xc]         | stack[1152921513410844668] = val_8;      //  dest_result_addr=1152921513410844668
            // 0x01686E8C: FMOV s0, w26               | S0 = (val_4.x);                         
            // 0x01686E90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686E98: MOV v1.16b, v8.16b         | V1 = val_6.x;//m1                       
            // 0x01686E9C: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_16, val2:  val_6.x);
            float val_9 = System.Math.Max(val1:  val_16, val2:  val_6.x);
            // 0x01686EA0: FMOV w26, s0               | W26 = (val_9);                          
            val_16 = val_9;
            // 0x01686EA4: FMOV s0, w25               | S0 = (val_4.y);                         
            // 0x01686EA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686EAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686EB0: MOV v1.16b, v9.16b         | V1 = val_6.z;//m1                       
            val_15 = val_6.z;
            // 0x01686EB4: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_17, val2:  val_15 = val_6.z);
            float val_10 = System.Math.Max(val1:  val_17, val2:  val_15);
            // 0x01686EB8: FMOV w25, s0               | W25 = (val_10);                         
            val_17 = val_10;
            // 0x01686EBC: ADD w21, w21, #1           | W21 = (val_18 + 1) = val_18 (0x00000002);
            val_18 = 2;
            label_9:
            // 0x01686EC0: CBNZ x20, #0x1686ec8       | if (node != null) goto label_10;        
            if(node != null)
            {
                goto label_10;
            }
            // 0x01686EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_10:
            // 0x01686EC8: LDR x8, [x20]              | X8 = typeof(Pathfinding.MeshNode);      
            // 0x01686ECC: MOV x0, x20                | X0 = node;//m1                          
            // 0x01686ED0: LDR x9, [x8, #0x240]       | X9 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_240;
            // 0x01686ED4: LDR x1, [x8, #0x248]       | X1 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_248;
            // 0x01686ED8: BLR x9                     | X0 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_240();
            // 0x01686EDC: CMP w21, w0                | STATE = COMPARE(0x2, node)              
            // 0x01686EE0: B.GE #0x1686f20            | if (val_18 >= node) goto label_11;      
            if(val_18 >= node)
            {
                goto label_11;
            }
            // 0x01686EE4: LDR x8, [x20]              | X8 = typeof(Pathfinding.MeshNode);      
            // 0x01686EE8: MOV x0, x20                | X0 = node;//m1                          
            // 0x01686EEC: MOV w1, w21                | W1 = 2 (0x2);//ML01                     
            // 0x01686EF0: LDR x9, [x8, #0x230]       | X9 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_230;
            // 0x01686EF4: LDR x2, [x8, #0x238]       | X2 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_238;
            // 0x01686EF8: BLR x9                     | X0 = typeof(Pathfinding.MeshNode).__il2cppRuntimeField_230();
            // 0x01686EFC: MOV x23, x0                | X23 = node;//m1                         
            // 0x01686F00: LDR x0, [x24]              | X0 = typeof(Pathfinding.Int3);          
            // 0x01686F04: AND x27, x1, #0xffffffff   | X27 = (val_18 & 4294967295) = 2 (0x00000002);
            // 0x01686F08: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x01686F0C: TBZ w8, #0, #0x1686e38     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x01686F10: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x01686F14: CBNZ w8, #0x1686e38        | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x01686F18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            // 0x01686F1C: B #0x1686e38               |  goto label_14;                         
            goto label_14;
            label_11:
            // 0x01686F20: LDP s0, s1, [sp, #8]       | S0 = val_7; S1 = val_8;                  //  | 
            // 0x01686F24: FMOV s2, w26               | S2 = (val_9);                           
            // 0x01686F28: FMOV s3, w25               | S3 = (val_10);                          
            // 0x01686F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686F34: BL #0x1b81640              | X0 = UnityEngine.Rect.MinMaxRect(xmin:  val_7, ymin:  val_8, xmax:  val_16, ymax:  val_17);
            UnityEngine.Rect val_11 = UnityEngine.Rect.MinMaxRect(xmin:  val_7, ymin:  val_8, xmax:  val_16, ymax:  val_17);
            // 0x01686F38: MOVN x8, #0                | X8 = 0 (0x0);//ML01                     
            // 0x01686F3C: STP s0, s1, [x19]          | mem2[0] = val_11.m_XMin;  mem2[0] = val_11.m_YMin;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_11.m_XMin;
            mem2[0] = val_11.m_YMin;
            // 0x01686F40: STP s2, s3, [x19, #8]      | mem2[0] = val_11.m_Width;  mem2[0] = val_11.m_Height;  //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = val_11.m_Width;
            mem2[0] = val_11.m_Height;
            // 0x01686F44: STR x8, [x19, #0x18]       | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x01686F48: SUB sp, x29, #0x60         | SP = (1152921513410844768 - 96) = 1152921513410844672 (0x100000020CC25800);
            // 0x01686F4C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x01686F50: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x01686F54: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x01686F58: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x01686F5C: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x01686F60: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x01686F64: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x01686F68: RET                        |  return (System.Int32)0;                
            return (int)0;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01686F6C (23621484), len: 684  VirtAddr: 0x01686F6C RVA: 0x01686F6C token: 100683167 methodIndex: 49889 delegateWrapperIndex: 0 methodInvoker: 0
        public void Insert(Pathfinding.MeshNode node)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            // 0x01686F6C: STP d15, d14, [sp, #-0x90]! | stack[1152921513411333472] = ???;  stack[1152921513411333480] = ???;  //  dest_result_addr=1152921513411333472 |  dest_result_addr=1152921513411333480
            // 0x01686F70: STP d13, d12, [sp, #0x10]  | stack[1152921513411333488] = ???;  stack[1152921513411333496] = ???;  //  dest_result_addr=1152921513411333488 |  dest_result_addr=1152921513411333496
            // 0x01686F74: STP d11, d10, [sp, #0x20]  | stack[1152921513411333504] = ???;  stack[1152921513411333512] = ???;  //  dest_result_addr=1152921513411333504 |  dest_result_addr=1152921513411333512
            // 0x01686F78: STP d9, d8, [sp, #0x30]    | stack[1152921513411333520] = ???;  stack[1152921513411333528] = ???;  //  dest_result_addr=1152921513411333520 |  dest_result_addr=1152921513411333528
            // 0x01686F7C: STP x26, x25, [sp, #0x40]  | stack[1152921513411333536] = ???;  stack[1152921513411333544] = ???;  //  dest_result_addr=1152921513411333536 |  dest_result_addr=1152921513411333544
            // 0x01686F80: STP x24, x23, [sp, #0x50]  | stack[1152921513411333552] = ???;  stack[1152921513411333560] = ???;  //  dest_result_addr=1152921513411333552 |  dest_result_addr=1152921513411333560
            // 0x01686F84: STP x22, x21, [sp, #0x60]  | stack[1152921513411333568] = ???;  stack[1152921513411333576] = ???;  //  dest_result_addr=1152921513411333568 |  dest_result_addr=1152921513411333576
            // 0x01686F88: STP x20, x19, [sp, #0x70]  | stack[1152921513411333584] = ???;  stack[1152921513411333592] = ???;  //  dest_result_addr=1152921513411333584 |  dest_result_addr=1152921513411333592
            // 0x01686F8C: STP x29, x30, [sp, #0x80]  | stack[1152921513411333600] = ???;  stack[1152921513411333608] = ???;  //  dest_result_addr=1152921513411333600 |  dest_result_addr=1152921513411333608
            // 0x01686F90: ADD x29, sp, #0x80         | X29 = (1152921513411333472 + 128) = 1152921513411333600 (0x100000020CC9CDE0);
            // 0x01686F94: MOV x20, x0                | X20 = 1152921513411345616 (0x100000020CC9FCD0);//ML01
            // 0x01686F98: BL #0x1686cb0              | X0 = this.GetBox(node:  node);          
            int val_1 = this.GetBox(node:  node);
            // 0x01686F9C: MOV w19, w0                | W19 = val_1;//m1                        
            // 0x01686FA0: CBZ w19, #0x16871f0        | if (val_1 == 0) goto label_0;           
            if(val_1 == 0)
            {
                goto label_0;
            }
            // 0x01686FA4: LDR x21, [x20, #0x10]      | X21 = this.arr; //P2                    
            // 0x01686FA8: CBNZ x21, #0x1686fb0       | if (this.arr != null) goto label_1;     
            if(this.arr != null)
            {
                goto label_1;
            }
            // 0x01686FAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x01686FB0: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686FB4: SXTW x22, w19              | X22 = (long)(int)(val_1);               
            // 0x01686FB8: CMP w19, w8                | STATE = COMPARE(val_1, this.arr.Length) 
            // 0x01686FBC: B.LO #0x1686fcc            | if (val_1 < this.arr.Length) goto label_2;
            if(val_1 < this.arr.Length)
            {
                goto label_2;
            }
            // 0x01686FC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01686FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_2:
            // 0x01686FCC: ADD x8, x21, x22, lsl #5   | X8 = this.arr[((long)(int)(val_1)) << 5]; //PARR1 
            // 0x01686FD0: LDP s8, s9, [x8, #0x20]    | S8 = this.arr[((long)(int)(val_1)) << 5][0] S9 = this.arr[((long)(int)(val_1)) << 5][0] //  | 
            BBTreeBox val_8 = this.arr[((long)(int)(val_1)) << 5];
            BBTreeBox val_9 = this.arr[((long)(int)(val_1)) << 5];
            // 0x01686FD4: LDP s10, s11, [x8, #0x28]  | S10 = this.arr[((long)(int)(val_1)) << 5][1] S11 = this.arr[((long)(int)(val_1)) << 5][1] //  | 
            BBTreeBox val_10 = this.arr[((long)(int)(val_1)) << 5];
            BBTreeBox val_11 = this.arr[((long)(int)(val_1)) << 5];
            // 0x01686FD8: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x01686FDC: B #0x1686fe4               |  goto label_19;                         
            goto label_19;
            label_20:
            // 0x01686FE0: MOV w25, w22               | W25 = (long)(int)(val_1);//m1           
            val_8 = (long)val_1;
            label_19:
            // 0x01686FE4: LDR x21, [x20, #0x10]      | X21 = this.arr; //P2                    
            // 0x01686FE8: CBNZ x21, #0x1686ff0       | if (this.arr != null) goto label_4;     
            if(this.arr != null)
            {
                goto label_4;
            }
            // 0x01686FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x01686FF0: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01686FF4: SXTW x24, w25              | X24 = (long)(int)((long)(int)(val_1));  
            // 0x01686FF8: CMP w25, w8                | STATE = COMPARE((long)(int)(val_1), this.arr.Length)
            // 0x01686FFC: B.LO #0x168700c            | if (val_8 < this.arr.Length) goto label_5;
            if(val_8 < this.arr.Length)
            {
                goto label_5;
            }
            // 0x01687000: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01687004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687008: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_5:
            // 0x0168700C: ADD x8, x21, x24, lsl #5   | X8 = this.arr[((long)(int)((long)(int)(val_1))) << 5]; //PARR1 
            // 0x01687010: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)((long)(int)(val_1))) << 5][0] S1 = this.arr[((long)(int)((long)(int)(val_1))) << 5][0] //  | 
            BBTreeBox val_12 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            BBTreeBox val_13 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            // 0x01687014: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)((long)(int)(val_1))) << 5][1] S3 = this.arr[((long)(int)((long)(int)(val_1))) << 5][1] //  | 
            BBTreeBox val_14 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            BBTreeBox val_15 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            // 0x01687018: LDR x21, [x8, #0x30]       | X21 = this.arr[((long)(int)((long)(int)(val_1))) << 5][2]
            BBTreeBox val_16 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            // 0x0168701C: LDP w23, w22, [x8, #0x38]  | W23 = this.arr[((long)(int)((long)(int)(val_1))) << 5][3] W22 = this.arr[((long)(int)((long)(int)(val_1))) << 5][3] //  | 
            BBTreeBox val_17 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            BBTreeBox val_18 = this.arr[((long)(int)((long)(int)(val_1))) << 5];
            // 0x01687020: MOV v4.16b, v8.16b         | V4 = this.arr[((long)(int)(val_1)) << 5][0];//m1
            // 0x01687024: MOV v5.16b, v9.16b         | V5 = this.arr[((long)(int)(val_1)) << 5][0];//m1
            // 0x01687028: MOV v6.16b, v10.16b        | V6 = this.arr[((long)(int)(val_1)) << 5][1];//m1
            // 0x0168702C: MOV v7.16b, v11.16b        | V7 = this.arr[((long)(int)(val_1)) << 5][1];//m1
            // 0x01687030: BL #0x1687218              | X0 = Pathfinding.BBTree.ExpandToContain(r:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)((long)(int)(val_1))) << 5], m_YMin = this.arr[((long)(int)((long)(int)(val_1))) << 5], m_Width = this.arr[((long)(int)((long)(int)(val_1))) << 5], m_Height = this.arr[((long)(int)((long)(int)(val_1))) << 5]}, r2:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)(val_1)) << 5], m_YMin = this.arr[((long)(int)(val_1)) << 5], m_Width = this.arr[((long)(int)(val_1)) << 5], m_Height = this.arr[((lo
            UnityEngine.Rect val_2 = Pathfinding.BBTree.ExpandToContain(r:  new UnityEngine.Rect() {m_XMin = val_12, m_YMin = val_13, m_Width = val_14, m_Height = val_15}, r2:  new UnityEngine.Rect() {m_XMin = val_8, m_YMin = val_9, m_Width = val_10, m_Height = val_11});
            // 0x01687034: MOV v15.16b, v0.16b        | V15 = val_2.m_XMin;//m1                 
            // 0x01687038: MOV v14.16b, v1.16b        | V14 = val_2.m_YMin;//m1                 
            // 0x0168703C: MOV v13.16b, v2.16b        | V13 = val_2.m_Width;//m1                
            // 0x01687040: MOV v12.16b, v3.16b        | V12 = val_2.m_Height;//m1               
            // 0x01687044: CBNZ x21, #0x16871a8       | if (this.arr[((long)(int)((long)(int)(val_1))) << 5][2] != 0) goto label_6;
            if(val_16 != 0)
            {
                goto label_6;
            }
            // 0x01687048: LDR x21, [x20, #0x10]      | X21 = this.arr; //P2                    
            // 0x0168704C: CBNZ x21, #0x1687054       | if (this.arr != null) goto label_7;     
            if(this.arr != null)
            {
                goto label_7;
            }
            // 0x01687050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_7:
            // 0x01687054: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687058: CMP w25, w8                | STATE = COMPARE((long)(int)(val_1), this.arr.Length)
            // 0x0168705C: B.LO #0x168706c            | if (val_8 < this.arr.Length) goto label_8;
            if(val_8 < this.arr.Length)
            {
                goto label_8;
            }
            // 0x01687060: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01687064: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687068: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_8:
            // 0x0168706C: ADD x8, x21, x24, lsl #5   | X8 = this.arr[((long)(int)((long)(int)(val_1))) << 5]; //PARR1 
            // 0x01687070: STP s15, s14, [x8, #0x20]  | this.arr[((long)(int)((long)(int)(val_1))) << 5][0] = val_2.m_XMin;  this.arr[((long)(int)((long)(int)(val_1))) << 5][0] = val_2.m_YMin;  //  dest_result_addr=0 |  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_XMin;
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_YMin;
            // 0x01687074: STP s13, s12, [x8, #0x28]  | this.arr[((long)(int)((long)(int)(val_1))) << 5][1] = val_2.m_Width;  this.arr[((long)(int)((long)(int)(val_1))) << 5][1] = val_2.m_Height;  //  dest_result_addr=0 |  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_Width;
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_Height;
            // 0x01687078: STR xzr, [x8, #0x30]       | this.arr[((long)(int)((long)(int)(val_1))) << 5][2] = new BBTreeBox();  //  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = 0;
            // 0x0168707C: STP w23, w22, [x8, #0x38]  | this.arr[((long)(int)((long)(int)(val_1))) << 5][3] = this.arr[((long)(int)((long)(int)(val_1))) << 5][3];  this.arr[((long)(int)((long)(int)(val_1))) << 5][3] = this.arr[((long)(int)((long)(int)(val_1))) << 5][3];  //  dest_result_addr=0 |  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_17;
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_18;
            // 0x01687080: LDR x24, [x20, #0x10]      | X24 = this.arr; //P2                    
            // 0x01687084: CBNZ x24, #0x168708c       | if (this.arr != null) goto label_9;     
            if(this.arr != null)
            {
                goto label_9;
            }
            // 0x01687088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_9:
            // 0x0168708C: LDR w8, [x24, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687090: SXTW x21, w23              | X21 = (long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3]);
            // 0x01687094: CMP w23, w8                | STATE = COMPARE(this.arr[((long)(int)((long)(int)(val_1))) << 5][3], this.arr.Length)
            // 0x01687098: B.LO #0x16870a8            | if (this.arr[((long)(int)((long)(int)(val_1))) << 5] < this.arr.Length) goto label_10;
            if(val_17 < this.arr.Length)
            {
                goto label_10;
            }
            // 0x0168709C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x016870A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016870A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_10:
            // 0x016870A8: ADD x8, x24, x21, lsl #5   | X8 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]; //PARR1 
            // 0x016870AC: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] S1 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] //  | 
            BBTreeBox val_19 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_20 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x016870B0: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] S3 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] //  | 
            BBTreeBox val_21 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_22 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x016870B4: MOV v4.16b, v8.16b         | V4 = this.arr[((long)(int)(val_1)) << 5][0];//m1
            // 0x016870B8: MOV v5.16b, v9.16b         | V5 = this.arr[((long)(int)(val_1)) << 5][0];//m1
            // 0x016870BC: MOV v6.16b, v10.16b        | V6 = this.arr[((long)(int)(val_1)) << 5][1];//m1
            // 0x016870C0: MOV v7.16b, v11.16b        | V7 = this.arr[((long)(int)(val_1)) << 5][1];//m1
            // 0x016870C4: BL #0x1687338              | X0 = Pathfinding.BBTree.ExpansionRequired(r:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_YMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Width = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Height = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]}, r2:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int
            float val_3 = Pathfinding.BBTree.ExpansionRequired(r:  new UnityEngine.Rect() {m_XMin = val_19, m_YMin = val_20, m_Width = val_21, m_Height = val_22}, r2:  new UnityEngine.Rect() {m_XMin = val_8, m_YMin = val_9, m_Width = val_10, m_Height = val_11});
            // 0x016870C8: LDR x25, [x20, #0x10]      | X25 = this.arr; //P2                    
            // 0x016870CC: MOV v12.16b, v0.16b        | V12 = val_3;//m1                        
            // 0x016870D0: CBNZ x25, #0x16870d8       | if (this.arr != null) goto label_11;    
            if(this.arr != null)
            {
                goto label_11;
            }
            // 0x016870D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_11:
            // 0x016870D8: LDR w8, [x25, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016870DC: SXTW x24, w22              | X24 = (long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3]);
            // 0x016870E0: CMP w22, w8                | STATE = COMPARE(this.arr[((long)(int)((long)(int)(val_1))) << 5][3], this.arr.Length)
            // 0x016870E4: B.LO #0x16870f4            | if (this.arr[((long)(int)((long)(int)(val_1))) << 5] < this.arr.Length) goto label_12;
            if(val_18 < this.arr.Length)
            {
                goto label_12;
            }
            // 0x016870E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x016870EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016870F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_12:
            // 0x016870F4: ADD x8, x25, x24, lsl #5   | X8 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]; //PARR1 
            // 0x016870F8: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] S1 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] //  | 
            BBTreeBox val_23 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_24 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x016870FC: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] S3 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] //  | 
            BBTreeBox val_25 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_26 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x01687100: MOV v4.16b, v8.16b         | V4 = this.arr[((long)(int)(val_1)) << 5][0];//m1
            // 0x01687104: MOV v5.16b, v9.16b         | V5 = this.arr[((long)(int)(val_1)) << 5][0];//m1
            // 0x01687108: MOV v6.16b, v10.16b        | V6 = this.arr[((long)(int)(val_1)) << 5][1];//m1
            // 0x0168710C: MOV v7.16b, v11.16b        | V7 = this.arr[((long)(int)(val_1)) << 5][1];//m1
            // 0x01687110: BL #0x1687338              | X0 = Pathfinding.BBTree.ExpansionRequired(r:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_YMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Width = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Height = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]}, r2:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int
            float val_4 = Pathfinding.BBTree.ExpansionRequired(r:  new UnityEngine.Rect() {m_XMin = val_23, m_YMin = val_24, m_Width = val_25, m_Height = val_26}, r2:  new UnityEngine.Rect() {m_XMin = val_8, m_YMin = val_9, m_Width = val_10, m_Height = val_11});
            // 0x01687114: MOV w25, w23               | W25 = this.arr[((long)(int)((long)(int)(val_1))) << 5][3];//m1
            // 0x01687118: FCMP s12, s0               | STATE = COMPARE(val_3, val_4)           
            // 0x0168711C: B.MI #0x1686fe4            | if (val_3 < 0) goto label_19;           
            if(val_3 < 0)
            {
                goto label_19;
            }
            // 0x01687120: MOV w25, w22               | W25 = this.arr[((long)(int)((long)(int)(val_1))) << 5][3];//m1
            // 0x01687124: FCMP s0, s12               | STATE = COMPARE(val_4, val_3)           
            // 0x01687128: B.MI #0x1686fe4            | if (val_4 < 0) goto label_19;           
            if(val_4 < 0)
            {
                goto label_19;
            }
            // 0x0168712C: LDR x25, [x20, #0x10]      | X25 = this.arr; //P2                    
            // 0x01687130: CBNZ x25, #0x1687138       | if (this.arr != null) goto label_15;    
            if(this.arr != null)
            {
                goto label_15;
            }
            // 0x01687134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_15:
            // 0x01687138: LDR w8, [x25, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x0168713C: CMP w23, w8                | STATE = COMPARE(this.arr[((long)(int)((long)(int)(val_1))) << 5][3], this.arr.Length)
            // 0x01687140: B.LO #0x1687150            | if (this.arr[((long)(int)((long)(int)(val_1))) << 5] < this.arr.Length) goto label_16;
            if(val_17 < this.arr.Length)
            {
                goto label_16;
            }
            // 0x01687144: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01687148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168714C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_16:
            // 0x01687150: ADD x8, x25, x21, lsl #5   | X8 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]; //PARR1 
            // 0x01687154: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] S1 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] //  | 
            BBTreeBox val_27 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_28 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x01687158: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] S3 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] //  | 
            BBTreeBox val_29 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_30 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x0168715C: BL #0x1687460              | X0 = Pathfinding.BBTree.RectArea(r:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_YMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Width = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Height = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]});
            float val_5 = Pathfinding.BBTree.RectArea(r:  new UnityEngine.Rect() {m_XMin = val_27, m_YMin = val_28, m_Width = val_29, m_Height = val_30});
            // 0x01687160: LDR x21, [x20, #0x10]      | X21 = this.arr; //P2                    
            // 0x01687164: MOV v12.16b, v0.16b        | V12 = val_5;//m1                        
            // 0x01687168: CBNZ x21, #0x1687170       | if (this.arr != null) goto label_17;    
            if(this.arr != null)
            {
                goto label_17;
            }
            // 0x0168716C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_17:
            // 0x01687170: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687174: CMP w22, w8                | STATE = COMPARE(this.arr[((long)(int)((long)(int)(val_1))) << 5][3], this.arr.Length)
            // 0x01687178: B.LO #0x1687188            | if (this.arr[((long)(int)((long)(int)(val_1))) << 5] < this.arr.Length) goto label_18;
            if(val_18 < this.arr.Length)
            {
                goto label_18;
            }
            // 0x0168717C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01687180: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687184: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_18:
            // 0x01687188: ADD x8, x21, x24, lsl #5   | X8 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]; //PARR1 
            // 0x0168718C: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] S1 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][0] //  | 
            BBTreeBox val_31 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_32 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x01687190: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] S3 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5][1] //  | 
            BBTreeBox val_33 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            BBTreeBox val_34 = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5];
            // 0x01687194: BL #0x1687460              | X0 = Pathfinding.BBTree.RectArea(r:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_YMin = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Width = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5], m_Height = this.arr[((long)(int)(this.arr[((long)(int)((long)(int)(val_1))) << 5][3])) << 5]});
            float val_6 = Pathfinding.BBTree.RectArea(r:  new UnityEngine.Rect() {m_XMin = val_31, m_YMin = val_32, m_Width = val_33, m_Height = val_34});
            // 0x01687198: MOV w25, w23               | W25 = this.arr[((long)(int)((long)(int)(val_1))) << 5][3];//m1
            // 0x0168719C: FCMP s12, s0               | STATE = COMPARE(val_5, val_6)           
            // 0x016871A0: B.MI #0x1686fe4            | if (val_5 < 0) goto label_19;           
            if(val_5 < 0)
            {
                goto label_19;
            }
            // 0x016871A4: B #0x1686fe0               |  goto label_20;                         
            goto label_20;
            label_6:
            // 0x016871A8: MOV x0, x20                | X0 = 1152921513411345616 (0x100000020CC9FCD0);//ML01
            // 0x016871AC: MOV x1, x21                | X1 = this.arr[((long)(int)((long)(int)(val_1))) << 5][2];//m1
            // 0x016871B0: BL #0x1686cb0              | X0 = this.GetBox(node:  this.arr[((long)(int)((long)(int)(val_1))) << 5]);
            int val_7 = this.GetBox(node:  val_16);
            // 0x016871B4: LDR x21, [x20, #0x10]      | X21 = this.arr; //P2                    
            // 0x016871B8: MOV w20, w0                | W20 = val_7;//m1                        
            // 0x016871BC: CBNZ x21, #0x16871c4       | if (this.arr != null) goto label_21;    
            if(this.arr != null)
            {
                goto label_21;
            }
            // 0x016871C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_21:
            // 0x016871C4: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016871C8: CMP w25, w8                | STATE = COMPARE((long)(int)(val_1), this.arr.Length)
            // 0x016871CC: B.LO #0x16871dc            | if (val_8 < this.arr.Length) goto label_22;
            if(val_8 < this.arr.Length)
            {
                goto label_22;
            }
            // 0x016871D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x016871D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016871D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_22:
            // 0x016871DC: ADD x8, x21, x24, lsl #5   | X8 = this.arr[((long)(int)((long)(int)(val_1))) << 5]; //PARR1 
            // 0x016871E0: STP s15, s14, [x8, #0x20]  | this.arr[((long)(int)((long)(int)(val_1))) << 5][0] = val_2.m_XMin;  this.arr[((long)(int)((long)(int)(val_1))) << 5][0] = val_2.m_YMin;  //  dest_result_addr=0 |  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_XMin;
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_YMin;
            // 0x016871E4: STP s13, s12, [x8, #0x28]  | this.arr[((long)(int)((long)(int)(val_1))) << 5][1] = val_2.m_Width;  this.arr[((long)(int)((long)(int)(val_1))) << 5][1] = val_2.m_Height;  //  dest_result_addr=0 |  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_Width;
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_2.m_Height;
            // 0x016871E8: STR xzr, [x8, #0x30]       | this.arr[((long)(int)((long)(int)(val_1))) << 5][2] = new BBTreeBox();  //  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = 0;
            // 0x016871EC: STP w19, w20, [x8, #0x38]  | this.arr[((long)(int)((long)(int)(val_1))) << 5][3] = val_1;  this.arr[((long)(int)((long)(int)(val_1))) << 5][3] = val_7;  //  dest_result_addr=0 |  dest_result_addr=0
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_1;
            this.arr[((long)(int)((long)(int)(val_1))) << 5] = val_7;
            label_0:
            // 0x016871F0: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
            // 0x016871F4: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
            // 0x016871F8: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
            // 0x016871FC: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
            // 0x01687200: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
            // 0x01687204: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01687208: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x0168720C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01687210: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
            // 0x01687214: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016874A4 (23622820), len: 148  VirtAddr: 0x016874A4 RVA: 0x016874A4 token: 100683168 methodIndex: 49890 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NNInfo Query(UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NNInfo val_0;
            // 0x016874A4: STP x20, x19, [sp, #-0x20]! | stack[1152921513411760880] = ???;  stack[1152921513411760888] = ???;  //  dest_result_addr=1152921513411760880 |  dest_result_addr=1152921513411760888
            // 0x016874A8: STP x29, x30, [sp, #0x10]  | stack[1152921513411760896] = ???;  stack[1152921513411760904] = ???;  //  dest_result_addr=1152921513411760896 |  dest_result_addr=1152921513411760904
            // 0x016874AC: ADD x29, sp, #0x10         | X29 = (1152921513411760880 + 16) = 1152921513411760896 (0x100000020CD05300);
            // 0x016874B0: SUB sp, sp, #0x30          | SP = (1152921513411760880 - 48) = 1152921513411760832 (0x100000020CD052C0);
            // 0x016874B4: STP xzr, xzr, [sp, #0x20]  | stack[1152921513411760864] = 0x0;  stack[1152921513411760872] = 0x0;  //  dest_result_addr=1152921513411760864 |  dest_result_addr=1152921513411760872
            // 0x016874B8: STP xzr, xzr, [sp, #0x10]  | stack[1152921513411760848] = 0x0;  stack[1152921513411760856] = 0x0;  //  dest_result_addr=1152921513411760848 |  dest_result_addr=1152921513411760856
            // 0x016874BC: STP xzr, xzr, [sp]         | stack[1152921513411760832] = 0x0;  stack[1152921513411760840] = 0x0;  //  dest_result_addr=1152921513411760832 |  dest_result_addr=1152921513411760840
            // 0x016874C0: LDR w10, [x0, #0x18]       | W10 = this.count; //P2                  
            // 0x016874C4: MOV x9, x1                 | X9 = constraint;//m1                    
            // 0x016874C8: MOV x19, x8                | X19 = 1152921513411809008 (0x100000020CD10EF0);//ML01
            // 0x016874CC: CBZ w10, #0x168750c        | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x016874D0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x016874D4: MOV x3, sp                 | X3 = 1152921513411760832 (0x100000020CD052C0);//ML01
            // 0x016874D8: MOV x2, x9                 | X2 = constraint;//m1                    
            // 0x016874DC: STP xzr, xzr, [sp, #0x20]  | stack[1152921513411760864] = 0x0;  stack[1152921513411760872] = 0x0;  //  dest_result_addr=1152921513411760864 |  dest_result_addr=1152921513411760872
            // 0x016874E0: STP xzr, xzr, [sp, #0x10]  | stack[1152921513411760848] = 0x0;  stack[1152921513411760856] = 0x0;  //  dest_result_addr=1152921513411760848 |  dest_result_addr=1152921513411760856
            // 0x016874E4: STP xzr, xzr, [sp]         | stack[1152921513411760832] = 0x0;  stack[1152921513411760840] = 0x0;  //  dest_result_addr=1152921513411760832 |  dest_result_addr=1152921513411760840
            // 0x016874E8: BL #0x1687538              | this.SearchBox(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {clampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, constClampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}});
            this.SearchBox(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {clampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, constClampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}});
            // 0x016874EC: MOV x0, sp                 | X0 = 1152921513411760832 (0x100000020CD052C0);//ML01
            // 0x016874F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016874F4: BL #0x156af90              | X0 = sub_156AF90( ?? 0x100000020CD052C0, ????);
            // 0x016874F8: LDP q1, q0, [sp, #0x10]    | Q1 = 0x0; Q0 = 0x0;                      //  | 
            // 0x016874FC: LDR q2, [sp]               | Q2 = 0x0;                               
            // 0x01687500: STP q1, q0, [x19, #0x10]   | val_0.clampedPosition.x = 0; val_0.clampedPosition.y = 0; val_0.clampedPosition.z = 0; val_0.constClampedPosition.x = 0;  val_0.constClampedPosition.y = 0; val_0.constClampedPosition.z = 0; val_0.row = 0; val_0.col = 0;  //  dest_result_addr=1152921513411809024 dest_result_addr=1152921513411809028 dest_result_addr=1152921513411809032 dest_result_addr=1152921513411809036 |  dest_result_addr=1152921513411809040 dest_result_addr=1152921513411809044 dest_result_addr=1152921513411809048 dest_result_addr=1152921513411809052
            val_0.clampedPosition.x = 0f;
            val_0.clampedPosition.y = 0f;
            val_0.clampedPosition.z = 0f;
            val_0.constClampedPosition.x = 0f;
            val_0.constClampedPosition.y = 0f;
            val_0.constClampedPosition.z = 0f;
            val_0.row = 0;
            val_0.col = 0;
            // 0x01687504: STR q2, [x19]              | val_0.node = null;                       //  dest_result_addr=1152921513411809008
            val_0.node = 0;
            // 0x01687508: B #0x1687528               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x0168750C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687510: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01687514: MOV x0, x19                | X0 = 1152921513411809008 (0x100000020CD10EF0);//ML01
            // 0x01687518: STP xzr, xzr, [x19, #0x20] | val_0.constClampedPosition.y = 0; val_0.constClampedPosition.z = 0;  val_0.row = 0; val_0.col = 0;  //  dest_result_addr=1152921513411809040 dest_result_addr=1152921513411809044 |  dest_result_addr=1152921513411809048 dest_result_addr=1152921513411809052
            val_0.constClampedPosition.y = 0f;
            val_0.constClampedPosition.z = 0f;
            val_0.row = 0;
            val_0.col = 0;
            // 0x0168751C: STP xzr, xzr, [x19, #0x10] | val_0.clampedPosition.x = 0; val_0.clampedPosition.y = 0;  val_0.clampedPosition.z = 0; val_0.constClampedPosition.x = 0;  //  dest_result_addr=1152921513411809024 dest_result_addr=1152921513411809028 |  dest_result_addr=1152921513411809032 dest_result_addr=1152921513411809036
            val_0.clampedPosition.x = 0f;
            val_0.clampedPosition.y = 0f;
            val_0.clampedPosition.z = 0f;
            val_0.constClampedPosition.x = 0f;
            // 0x01687520: STP xzr, xzr, [x19]        | val_0.node = null;  val_0.constrainedNode = null;  //  dest_result_addr=1152921513411809008 |  dest_result_addr=1152921513411809016
            val_0.node = 0;
            val_0.constrainedNode = 0;
            // 0x01687524: BL #0x154f320              | X0 = label_Pathfinding_LayerGridGraph_GetNearest_GL0154F320();
            label_1:
            // 0x01687528: SUB sp, x29, #0x10         | SP = (1152921513411760896 - 16) = 1152921513411760880 (0x100000020CD052F0);
            // 0x0168752C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01687530: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01687534: RET                        |  return (Pathfinding.NNInfo)val_0;      
            return val_0;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168782C (23623724), len: 216  VirtAddr: 0x0168782C RVA: 0x0168782C token: 100683169 methodIndex: 49891 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NNInfo QueryCircle(UnityEngine.Vector3 p, float radius, Pathfinding.NNConstraint constraint)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NNInfo val_0;
            // 0x0168782C: STP d11, d10, [sp, #-0x50]! | stack[1152921513411905408] = ???;  stack[1152921513411905416] = ???;  //  dest_result_addr=1152921513411905408 |  dest_result_addr=1152921513411905416
            // 0x01687830: STP d9, d8, [sp, #0x10]    | stack[1152921513411905424] = ???;  stack[1152921513411905432] = ???;  //  dest_result_addr=1152921513411905424 |  dest_result_addr=1152921513411905432
            // 0x01687834: STP x22, x21, [sp, #0x20]  | stack[1152921513411905440] = ???;  stack[1152921513411905448] = ???;  //  dest_result_addr=1152921513411905440 |  dest_result_addr=1152921513411905448
            // 0x01687838: STP x20, x19, [sp, #0x30]  | stack[1152921513411905456] = ???;  stack[1152921513411905464] = ???;  //  dest_result_addr=1152921513411905456 |  dest_result_addr=1152921513411905464
            // 0x0168783C: STP x29, x30, [sp, #0x40]  | stack[1152921513411905472] = ???;  stack[1152921513411905480] = ???;  //  dest_result_addr=1152921513411905472 |  dest_result_addr=1152921513411905480
            // 0x01687840: ADD x29, sp, #0x40         | X29 = (1152921513411905408 + 64) = 1152921513411905472 (0x100000020CD287C0);
            // 0x01687844: SUB sp, sp, #0x30          | SP = (1152921513411905408 - 48) = 1152921513411905360 (0x100000020CD28750);
            // 0x01687848: MOV x21, x0                | X21 = 1152921513411917488 (0x100000020CD2B6B0);//ML01
            // 0x0168784C: STP xzr, xzr, [sp, #0x20]  | stack[1152921513411905392] = 0x0;  stack[1152921513411905400] = 0x0;  //  dest_result_addr=1152921513411905392 |  dest_result_addr=1152921513411905400
            // 0x01687850: STP xzr, xzr, [sp, #0x10]  | stack[1152921513411905376] = 0x0;  stack[1152921513411905384] = 0x0;  //  dest_result_addr=1152921513411905376 |  dest_result_addr=1152921513411905384
            // 0x01687854: STP xzr, xzr, [sp]         | stack[1152921513411905360] = 0x0;  stack[1152921513411905368] = 0x0;  //  dest_result_addr=1152921513411905360 |  dest_result_addr=1152921513411905368
            // 0x01687858: LDR w9, [x21, #0x18]       | W9 = this.count; //P2                   
            // 0x0168785C: MOV x20, x1                | X20 = constraint;//m1                   
            // 0x01687860: MOV v8.16b, v3.16b         | V8 = radius;//m1                        
            // 0x01687864: MOV v9.16b, v2.16b         | V9 = p.z;//m1                           
            // 0x01687868: MOV v10.16b, v1.16b        | V10 = p.y;//m1                          
            // 0x0168786C: MOV v11.16b, v0.16b        | V11 = p.x;//m1                          
            // 0x01687870: MOV x19, x8                | X19 = 1152921513411953584 (0x100000020CD343B0);//ML01
            // 0x01687874: CBZ w9, #0x16878cc         | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x01687878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168787C: MOV x0, sp                 | X0 = 1152921513411905360 (0x100000020CD28750);//ML01
            // 0x01687880: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01687884: BL #0x154f320              | X0 = label_Pathfinding_LayerGridGraph_GetNearest_GL0154F320();
            // 0x01687888: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0168788C: MOV x3, sp                 | X3 = 1152921513411905360 (0x100000020CD28750);//ML01
            // 0x01687890: MOV x0, x21                | X0 = 1152921513411917488 (0x100000020CD2B6B0);//ML01
            // 0x01687894: MOV v0.16b, v11.16b        | V0 = p.x;//m1                           
            // 0x01687898: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
            // 0x0168789C: MOV v2.16b, v9.16b         | V2 = p.z;//m1                           
            // 0x016878A0: MOV v3.16b, v8.16b         | V3 = radius;//m1                        
            // 0x016878A4: MOV x2, x20                | X2 = constraint;//m1                    
            // 0x016878A8: BL #0x1687904              | this.SearchBoxCircle(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {clampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, constClampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}});
            this.SearchBoxCircle(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {clampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, constClampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}});
            // 0x016878AC: MOV x0, sp                 | X0 = 1152921513411905360 (0x100000020CD28750);//ML01
            // 0x016878B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016878B4: BL #0x156af90              | X0 = sub_156AF90( ?? 0x100000020CD28750, ????);
            // 0x016878B8: LDP q1, q0, [sp, #0x10]    | Q1 = 0x0; Q0 = 0x0;                      //  | 
            // 0x016878BC: LDR q2, [sp]               | Q2 = 0x0;                               
            // 0x016878C0: STP q1, q0, [x19, #0x10]   | val_0.clampedPosition.x = 0; val_0.clampedPosition.y = 0; val_0.clampedPosition.z = 0; val_0.constClampedPosition.x = 0;  val_0.constClampedPosition.y = 0; val_0.constClampedPosition.z = 0; val_0.row = 0; val_0.col = 0;  //  dest_result_addr=1152921513411953600 dest_result_addr=1152921513411953604 dest_result_addr=1152921513411953608 dest_result_addr=1152921513411953612 |  dest_result_addr=1152921513411953616 dest_result_addr=1152921513411953620 dest_result_addr=1152921513411953624 dest_result_addr=1152921513411953628
            val_0.clampedPosition.x = 0f;
            val_0.clampedPosition.y = 0f;
            val_0.clampedPosition.z = 0f;
            val_0.constClampedPosition.x = 0f;
            val_0.constClampedPosition.y = 0f;
            val_0.constClampedPosition.z = 0f;
            val_0.row = 0;
            val_0.col = 0;
            // 0x016878C4: STR q2, [x19]              | val_0.node = null;                       //  dest_result_addr=1152921513411953584
            val_0.node = 0;
            // 0x016878C8: B #0x16878e8               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x016878CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016878D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016878D4: MOV x0, x19                | X0 = 1152921513411953584 (0x100000020CD343B0);//ML01
            // 0x016878D8: STP xzr, xzr, [x19, #0x20] | val_0.constClampedPosition.y = 0; val_0.constClampedPosition.z = 0;  val_0.row = 0; val_0.col = 0;  //  dest_result_addr=1152921513411953616 dest_result_addr=1152921513411953620 |  dest_result_addr=1152921513411953624 dest_result_addr=1152921513411953628
            val_0.constClampedPosition.y = 0f;
            val_0.constClampedPosition.z = 0f;
            val_0.row = 0;
            val_0.col = 0;
            // 0x016878DC: STP xzr, xzr, [x19, #0x10] | val_0.clampedPosition.x = 0; val_0.clampedPosition.y = 0;  val_0.clampedPosition.z = 0; val_0.constClampedPosition.x = 0;  //  dest_result_addr=1152921513411953600 dest_result_addr=1152921513411953604 |  dest_result_addr=1152921513411953608 dest_result_addr=1152921513411953612
            val_0.clampedPosition.x = 0f;
            val_0.clampedPosition.y = 0f;
            val_0.clampedPosition.z = 0f;
            val_0.constClampedPosition.x = 0f;
            // 0x016878E0: STP xzr, xzr, [x19]        | val_0.node = null;  val_0.constrainedNode = null;  //  dest_result_addr=1152921513411953584 |  dest_result_addr=1152921513411953592
            val_0.node = 0;
            val_0.constrainedNode = 0;
            // 0x016878E4: BL #0x154f320              | X0 = label_Pathfinding_LayerGridGraph_GetNearest_GL0154F320();
            label_1:
            // 0x016878E8: SUB sp, x29, #0x40         | SP = (1152921513411905472 - 64) = 1152921513411905408 (0x100000020CD28780);
            // 0x016878EC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x016878F0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x016878F4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x016878F8: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x016878FC: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
            // 0x01687900: RET                        |  return (Pathfinding.NNInfo)val_0;      
            return val_0;
        
        }
        //
        // Offset in libil2cpp.so: 0x01687CB4 (23624884), len: 204  VirtAddr: 0x01687CB4 RVA: 0x01687CB4 token: 100683170 methodIndex: 49892 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NNInfo QueryClosest(UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint, out float distance)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NNInfo val_0;
            // 0x01687CB4: STP d11, d10, [sp, #-0x50]! | stack[1152921513412054032] = ???;  stack[1152921513412054040] = ???;  //  dest_result_addr=1152921513412054032 |  dest_result_addr=1152921513412054040
            // 0x01687CB8: STP d9, d8, [sp, #0x10]    | stack[1152921513412054048] = ???;  stack[1152921513412054056] = ???;  //  dest_result_addr=1152921513412054048 |  dest_result_addr=1152921513412054056
            // 0x01687CBC: STP x22, x21, [sp, #0x20]  | stack[1152921513412054064] = ???;  stack[1152921513412054072] = ???;  //  dest_result_addr=1152921513412054064 |  dest_result_addr=1152921513412054072
            // 0x01687CC0: STP x20, x19, [sp, #0x30]  | stack[1152921513412054080] = ???;  stack[1152921513412054088] = ???;  //  dest_result_addr=1152921513412054080 |  dest_result_addr=1152921513412054088
            // 0x01687CC4: STP x29, x30, [sp, #0x40]  | stack[1152921513412054096] = ???;  stack[1152921513412054104] = ???;  //  dest_result_addr=1152921513412054096 |  dest_result_addr=1152921513412054104
            // 0x01687CC8: ADD x29, sp, #0x40         | X29 = (1152921513412054032 + 64) = 1152921513412054096 (0x100000020CD4CC50);
            // 0x01687CCC: SUB sp, sp, #0x60          | SP = (1152921513412054032 - 96) = 1152921513412053936 (0x100000020CD4CBB0);
            // 0x01687CD0: MOV x21, x2                | X21 = 1152921513412102208 (0x100000020CD58840);//ML01
            // 0x01687CD4: MOV x20, x1                | X20 = constraint;//m1                   
            // 0x01687CD8: MOV x22, x0                | X22 = 1152921513412066112 (0x100000020CD4FB40);//ML01
            // 0x01687CDC: MOV x19, x8                | X19 = 1152921513412106256 (0x100000020CD59810);//ML01
            // 0x01687CE0: ORR w8, wzr, #0x7f800000   | W8 = 2139095040(0x7F800000);            
            // 0x01687CE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687CE8: ADD x0, sp, #0x30          | X0 = (1152921513412053936 + 48) = 1152921513412053984 (0x100000020CD4CBE0);
            // 0x01687CEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01687CF0: MOV v8.16b, v2.16b         | V8 = p.z;//m1                           
            // 0x01687CF4: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x01687CF8: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
            // 0x01687CFC: STR w8, [x21]              | distance = Infinity;                     //  dest_result_addr=1152921513412102208
            distance = Infinityf;
            // 0x01687D00: STP xzr, xzr, [sp, #0x50]  | stack[1152921513412054016] = 0x0;  stack[1152921513412054024] = 0x0;  //  dest_result_addr=1152921513412054016 |  dest_result_addr=1152921513412054024
            // 0x01687D04: STP xzr, xzr, [sp, #0x40]  | stack[1152921513412054000] = 0x0;  stack[1152921513412054008] = 0x0;  //  dest_result_addr=1152921513412054000 |  dest_result_addr=1152921513412054008
            // 0x01687D08: STP xzr, xzr, [sp, #0x30]  | stack[1152921513412053984] = 0x0;  stack[1152921513412053992] = 0x0;  //  dest_result_addr=1152921513412053984 |  dest_result_addr=1152921513412053992
            // 0x01687D0C: BL #0x154f320              | X0 = label_Pathfinding_LayerGridGraph_GetNearest_GL0154F320();
            // 0x01687D10: LDP q1, q0, [sp, #0x40]    | Q1 = 0x0; Q0 = 0x0;                      //  | 
            // 0x01687D14: LDR q2, [sp, #0x30]        | Q2 = 0x0;                               
            // 0x01687D18: STP q1, q0, [sp, #0x10]    | stack[1152921513412053952] = 0x0;  stack[1152921513412053968] = 0x0;  //  dest_result_addr=1152921513412053952 |  dest_result_addr=1152921513412053968
            // 0x01687D1C: STR q2, [sp]               | stack[1152921513412053936] = 0x0;        //  dest_result_addr=1152921513412053936
            // 0x01687D20: LDR w8, [x22, #0x18]       | W8 = this.count; //P2                   
            // 0x01687D24: CBZ w8, #0x1687d4c         | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x01687D28: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01687D2C: MOV x4, sp                 | X4 = 1152921513412053936 (0x100000020CD4CBB0);//ML01
            // 0x01687D30: MOV x0, x22                | X0 = 1152921513412066112 (0x100000020CD4FB40);//ML01
            // 0x01687D34: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01687D38: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x01687D3C: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01687D40: MOV x2, x21                | X2 = 1152921513412102208 (0x100000020CD58840);//ML01
            float val_1 = 3.289985E-31f;
            // 0x01687D44: MOV x3, x20                | X3 = constraint;//m1                    
            // 0x01687D48: BL #0x1688134              | this.SearchBoxClosest(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, closestDist: ref  float val_1 = 3.289985E-31f, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {clampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, constClampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}});
            this.SearchBoxClosest(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, closestDist: ref  val_1, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {clampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, constClampedPosition = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}});
            label_0:
            // 0x01687D4C: LDR q0, [sp, #0x20]        | Q0 = 0x0;                               
            // 0x01687D50: LDR q1, [sp, #0x10]        | Q1 = 0x0;                               
            // 0x01687D54: LDR q2, [sp]               | Q2 = 0x0;                               
            // 0x01687D58: STR q0, [x19, #0x20]       | val_0.constClampedPosition.y = 0; val_0.constClampedPosition.z = 0; val_0.row = 0; val_0.col = 0;  //  dest_result_addr=1152921513412106288 dest_result_addr=1152921513412106292 dest_result_addr=1152921513412106296 dest_result_addr=1152921513412106300
            val_0.constClampedPosition.y = 0f;
            val_0.constClampedPosition.z = 0f;
            val_0.row = 0;
            val_0.col = 0;
            // 0x01687D5C: STR q1, [x19, #0x10]       | val_0.clampedPosition.x = 0; val_0.clampedPosition.y = 0; val_0.clampedPosition.z = 0; val_0.constClampedPosition.x = 0;  //  dest_result_addr=1152921513412106272 dest_result_addr=1152921513412106276 dest_result_addr=1152921513412106280 dest_result_addr=1152921513412106284
            val_0.clampedPosition.x = 0f;
            val_0.clampedPosition.y = 0f;
            val_0.clampedPosition.z = 0f;
            val_0.constClampedPosition.x = 0f;
            // 0x01687D60: STR q2, [x19]              | val_0.node = null;                       //  dest_result_addr=1152921513412106256
            val_0.node = 0;
            // 0x01687D64: SUB sp, x29, #0x40         | SP = (1152921513412054096 - 64) = 1152921513412054032 (0x100000020CD4CC10);
            // 0x01687D68: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01687D6C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01687D70: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01687D74: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01687D78: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
            // 0x01687D7C: RET                        |  return (Pathfinding.NNInfo)val_0;      
            return val_0;
        
        }
        //
        // Offset in libil2cpp.so: 0x01687DD4 (23625172), len: 84  VirtAddr: 0x01687DD4 RVA: 0x01687DD4 token: 100683171 methodIndex: 49893 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NNInfo QueryClosestXZ(UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint, ref float distance, Pathfinding.NNInfo previous)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NNInfo val_0;
            // 0x01687DD4: STP x20, x19, [sp, #-0x20]! | stack[1152921513412219152] = ???;  stack[1152921513412219160] = ???;  //  dest_result_addr=1152921513412219152 |  dest_result_addr=1152921513412219160
            // 0x01687DD8: STP x29, x30, [sp, #0x10]  | stack[1152921513412219168] = ???;  stack[1152921513412219176] = ???;  //  dest_result_addr=1152921513412219168 |  dest_result_addr=1152921513412219176
            // 0x01687DDC: ADD x29, sp, #0x10         | X29 = (1152921513412219152 + 16) = 1152921513412219168 (0x100000020CD75120);
            // 0x01687DE0: LDR w10, [x0, #0x18]       | W10 = this.count; //P2                  
            // 0x01687DE4: MOV x19, x3                | X19 = 1152921513412271408 (0x100000020CD81D30);//ML01
            // 0x01687DE8: MOV x9, x1                 | X9 = constraint;//m1                    
            // 0x01687DEC: MOV x20, x8                | X20 = 1152921513412283728 (0x100000020CD84D50);//ML01
            // 0x01687DF0: CBZ w10, #0x1687e04        | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x01687DF4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01687DF8: MOV x3, x9                 | X3 = constraint;//m1                    
            // 0x01687DFC: MOV x4, x19                | X4 = 1152921513412271408 (0x100000020CD81D30);//ML01
            // 0x01687E00: BL #0x1687e28              | this.SearchBoxClosestXZ(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, closestDist: ref  float val_1 = 3.328793E-31f, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {node = previous.node, constrainedNode = previous.constrainedNode, clampedPosition = new UnityEngine.Vector3() {x = previous.clampedPosition.x, y = previous.clampedPosition.y, z = previous.clampedPosition.z}, constClampedPosition = new UnityEngine.Vector3() {x = previous.constClampedPosition.x, y
            this.SearchBoxClosestXZ(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, closestDist: ref  float val_1 = 3.328793E-31f, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {node = previous.node, constrainedNode = previous.constrainedNode, clampedPosition = new UnityEngine.Vector3() {x = previous.clampedPosition.x, y = previous.clampedPosition.y, z = previous.clampedPosition.z}, constClampedPosition = new UnityEngine.Vector3() {x = previous.constClampedPosition.x, y = previous.constClampedPosition.y, z = previous.constClampedPosition.z}, row = previous.row, col = previous.col});
            label_0:
            // 0x01687E04: LDR q0, [x19, #0x20]       | Q0 = previous.constClampedPosition.y;   
            // 0x01687E08: STR q0, [x20, #0x20]       | val_0.constClampedPosition.y = previous.constClampedPosition.y;  //  dest_result_addr=1152921513412283760
            val_0.constClampedPosition.y = previous.constClampedPosition.y;
            // 0x01687E0C: LDR q0, [x19, #0x10]       | Q0 = previous.clampedPosition.x;        
            // 0x01687E10: STR q0, [x20, #0x10]       | val_0.clampedPosition.x = previous.clampedPosition.x;  //  dest_result_addr=1152921513412283744
            val_0.clampedPosition.x = previous.clampedPosition.x;
            // 0x01687E14: LDR q0, [x19]              | Q0 = previous.node;                     
            // 0x01687E18: STR q0, [x20]              | val_0.node = previous.node;              //  dest_result_addr=1152921513412283728
            val_0.node = previous.node;
            // 0x01687E1C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01687E20: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01687E24: RET                        |  return (Pathfinding.NNInfo)val_0;      
            return val_0;
        
        }
        //
        // Offset in libil2cpp.so: 0x01687E28 (23625256), len: 512  VirtAddr: 0x01687E28 RVA: 0x01687E28 token: 100683172 methodIndex: 49894 delegateWrapperIndex: 0 methodInvoker: 0
        private void SearchBoxClosestXZ(int boxi, UnityEngine.Vector3 p, ref float closestDist, Pathfinding.NNConstraint constraint, ref Pathfinding.NNInfo nnInfo)
        {
            //
            // Disasemble & Code
            //  | 
            float val_4;
            //  | 
            var val_5;
            //  | 
            BBTreeBox val_6;
            //  | 
            float val_7;
            label_6:
            // 0x01687E28: STP d13, d12, [sp, #-0x80]! | stack[1152921513412494960] = ???;  stack[1152921513412494968] = ???;  //  dest_result_addr=1152921513412494960 |  dest_result_addr=1152921513412494968
            // 0x01687E2C: STP d11, d10, [sp, #0x10]  | stack[1152921513412494976] = ???;  stack[1152921513412494984] = ???;  //  dest_result_addr=1152921513412494976 |  dest_result_addr=1152921513412494984
            // 0x01687E30: STP d9, d8, [sp, #0x20]    | stack[1152921513412494992] = ???;  stack[1152921513412495000] = ???;  //  dest_result_addr=1152921513412494992 |  dest_result_addr=1152921513412495000
            // 0x01687E34: STP x26, x25, [sp, #0x30]  | stack[1152921513412495008] = ???;  stack[1152921513412495016] = ???;  //  dest_result_addr=1152921513412495008 |  dest_result_addr=1152921513412495016
            // 0x01687E38: STP x24, x23, [sp, #0x40]  | stack[1152921513412495024] = ???;  stack[1152921513412495032] = ???;  //  dest_result_addr=1152921513412495024 |  dest_result_addr=1152921513412495032
            // 0x01687E3C: STP x22, x21, [sp, #0x50]  | stack[1152921513412495040] = ???;  stack[1152921513412495048] = ???;  //  dest_result_addr=1152921513412495040 |  dest_result_addr=1152921513412495048
            // 0x01687E40: STP x20, x19, [sp, #0x60]  | stack[1152921513412495056] = ???;  stack[1152921513412495064] = ???;  //  dest_result_addr=1152921513412495056 |  dest_result_addr=1152921513412495064
            // 0x01687E44: STP x29, x30, [sp, #0x70]  | stack[1152921513412495072] = ???;  stack[1152921513412495080] = ???;  //  dest_result_addr=1152921513412495072 |  dest_result_addr=1152921513412495080
            // 0x01687E48: ADD x29, sp, #0x70         | X29 = (1152921513412494960 + 112) = 1152921513412495072 (0x100000020CDB86E0);
            // 0x01687E4C: MOV x20, x4                | X20 = 1152921513412547328 (0x100000020CDC5300);//ML01
            // 0x01687E50: MOV x21, x3                | X21 = constraint;//m1                   
            // 0x01687E54: MOV x19, x2                | X19 = 1152921513412539088 (0x100000020CDC32D0);//ML01
            // 0x01687E58: MOV v8.16b, v2.16b         | V8 = p.z;//m1                           
            // 0x01687E5C: MOV v10.16b, v1.16b        | V10 = p.y;//m1                          
            val_4 = p.y;
            // 0x01687E60: MOV v9.16b, v0.16b         | V9 = p.x;//m1                           
            // 0x01687E64: MOV w23, w1                | W23 = boxi;//m1                         
            // 0x01687E68: MOV x22, x0                | X22 = 1152921513412507088 (0x100000020CDBB5D0);//ML01
            label_9:
            // 0x01687E6C: LDR x24, [x22, #0x10]      | X24 = this.arr; //P2                    
            // 0x01687E70: CBNZ x24, #0x1687e78       | if (this.arr != null) goto label_0;     
            if(this.arr != null)
            {
                goto label_0;
            }
            // 0x01687E74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01687E78: LDR w8, [x24, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687E7C: SXTW x25, w23              | X25 = (long)(int)(boxi);                
            val_5 = (long)boxi;
            // 0x01687E80: CMP w8, w23                | STATE = COMPARE(this.arr.Length, boxi)  
            // 0x01687E84: B.HI #0x1687e94            | if (this.arr.Length > boxi) goto label_1;
            if(this.arr.Length > boxi)
            {
                goto label_1;
            }
            // 0x01687E88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01687E8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687E90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x01687E94: ADD x8, x24, x25, lsl #5   | X8 = this.arr[((long)(int)(boxi)) << 5]; //PARR1 
            // 0x01687E98: LDR x24, [x8, #0x30]       | X24 = this.arr[((long)(int)(boxi)) << 5][2]
            BBTreeBox val_4 = this.arr[((long)(int)(boxi)) << 5];
            // 0x01687E9C: LDR w23, [x8, #0x3c]       | W23 = this.arr[((long)(int)(boxi)) << 5][3]
            BBTreeBox val_5 = this.arr[((long)(int)(boxi)) << 5];
            // 0x01687EA0: CBNZ x24, #0x1687f68       | if (this.arr[((long)(int)(boxi)) << 5][2] != 0) goto label_2;
            if(val_4 != 0)
            {
                goto label_2;
            }
            // 0x01687EA4: LDRSW x24, [x8, #0x38]     | X24 = this.arr[((long)(int)(boxi)) << 5][3]
            BBTreeBox val_6 = this.arr[((long)(int)(boxi)) << 5];
            // 0x01687EA8: LDR x25, [x22, #0x10]      | X25 = this.arr; //P2                    
            // 0x01687EAC: CBNZ x25, #0x1687eb4       | if (this.arr != null) goto label_3;     
            if(this.arr != null)
            {
                goto label_3;
            }
            // 0x01687EB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x01687EB4: LDR w8, [x25, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687EB8: CMP w24, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x01687EBC: B.LO #0x1687ecc            | if (this.arr[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_4;
            if(val_6 < this.arr.Length)
            {
                goto label_4;
            }
            // 0x01687EC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01687EC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687EC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_4:
            // 0x01687ECC: ADD x8, x25, x24, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]; //PARR1 
            // 0x01687ED0: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] S1 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] //  | 
            BBTreeBox val_7 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            val_6 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01687ED4: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] S3 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] //  | 
            BBTreeBox val_8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            BBTreeBox val_9 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01687ED8: LDR s7, [x19]              | S7 = closestDist;                       
            // 0x01687EDC: MOV v4.16b, v9.16b         | V4 = p.x;//m1                           
            // 0x01687EE0: MOV v5.16b, v10.16b        | V5 = p.y;//m1                           
            // 0x01687EE4: MOV v6.16b, v8.16b         | V6 = p.z;//m1                           
            // 0x01687EE8: BL #0x1688028              | X0 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_YMin = val_6, m_Width = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_Height = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = val_4, z = p.z}, radius:  closestDist);
            bool val_1 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_7, m_YMin = val_6, m_Width = val_8, m_Height = val_9}, p:  new UnityEngine.Vector3() {x = p.x, y = val_4, z = p.z}, radius:  closestDist);
            // 0x01687EEC: TBZ w0, #0, #0x1687f14     | if (val_1 == false) goto label_5;       
            if(val_1 == false)
            {
                goto label_5;
            }
            // 0x01687EF0: MOV x0, x22                | X0 = 1152921513412507088 (0x100000020CDBB5D0);//ML01
            // 0x01687EF4: MOV w1, w24                | W1 = this.arr[((long)(int)(boxi)) << 5][3];//m1
            // 0x01687EF8: MOV v0.16b, v9.16b         | V0 = p.x;//m1                           
            // 0x01687EFC: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
            val_6 = val_4;
            // 0x01687F00: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01687F04: MOV x2, x19                | X2 = 1152921513412539088 (0x100000020CDC32D0);//ML01
            // 0x01687F08: MOV x3, x21                | X3 = constraint;//m1                    
            // 0x01687F0C: MOV x4, x20                | X4 = 1152921513412547328 (0x100000020CDC5300);//ML01
            // 0x01687F10: BL #0x1687e28              |  R0 = label_6();                        
            label_5:
            // 0x01687F14: LDR x24, [x22, #0x10]      | X24 = this.arr; //P2                    
            // 0x01687F18: CBNZ x24, #0x1687f20       | if (this.arr != null) goto label_7;     
            if(this.arr != null)
            {
                goto label_7;
            }
            // 0x01687F1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x01687F20: LDR w8, [x24, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687F24: SXTW x25, w23              | X25 = (long)(int)(this.arr[((long)(int)(boxi)) << 5][3]);
            val_5 = (long)val_5;
            // 0x01687F28: CMP w23, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x01687F2C: B.LO #0x1687f3c            | if (this.arr[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_8;
            if(val_5 < this.arr.Length)
            {
                goto label_8;
            }
            // 0x01687F30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01687F34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687F38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_8:
            // 0x01687F3C: ADD x8, x24, x25, lsl #5   | X8 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5]; //PARR1 
            // 0x01687F40: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][0] S1 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][0] //  | 
            BBTreeBox val_10 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            BBTreeBox val_11 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            // 0x01687F44: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][1] S3 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][1] //  | 
            BBTreeBox val_12 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            BBTreeBox val_13 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            // 0x01687F48: LDR s7, [x19]              | S7 = closestDist;                       
            // 0x01687F4C: MOV v4.16b, v9.16b         | V4 = p.x;//m1                           
            // 0x01687F50: MOV v5.16b, v10.16b        | V5 = p.y;//m1                           
            // 0x01687F54: MOV v6.16b, v8.16b         | V6 = p.z;//m1                           
            // 0x01687F58: BL #0x1688028              | X0 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5], m_YMin = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5], m_Width = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5], m_Height = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = val_4, z = p.z}, radius:  closestDist);
            bool val_2 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_10, m_YMin = val_11, m_Width = val_12, m_Height = val_13}, p:  new UnityEngine.Vector3() {x = p.x, y = val_4, z = p.z}, radius:  closestDist);
            // 0x01687F5C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5] = val_2;
            // 0x01687F60: TBNZ w8, #0, #0x1687e6c    | if ((val_2 & 1) == true) goto label_9;  
            if((this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5]) == true)
            {
                goto label_9;
            }
            // 0x01687F64: B #0x1688004               |  goto label_14;                         
            goto label_14;
            label_2:
            // 0x01687F68: LDR x8, [x24]              | X8 = this.arr[((long)(int)(boxi)) << 5][2].rect;
            // 0x01687F6C: MOV x0, x24                | X0 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01687F70: MOV v0.16b, v9.16b         | V0 = p.x;//m1                           
            float val_14 = p.x;
            // 0x01687F74: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
            // 0x01687F78: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
            // 0x01687F7C: LDR x1, [x8, #0x268]       |  //  not_find_field!1:616
            // 0x01687F80: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01687F84: BLR x9                     | X0 = mem[this.arr[((long)(int)(boxi)) << 5][2].rect + 608]();
            // 0x01687F88: MOV v12.16b, v0.16b        | V12 = p.x;//m1                          
            // 0x01687F8C: MOV v11.16b, v1.16b        | V11 = p.y;//m1                          
            // 0x01687F90: MOV v10.16b, v2.16b        | V10 = p.z;//m1                          
            val_4 = p.z;
            // 0x01687F94: CBZ x21, #0x1687fb0        | if (constraint == null) goto label_11;  
            if(constraint == null)
            {
                goto label_11;
            }
            // 0x01687F98: LDR x8, [x21]              | X8 = typeof(Pathfinding.NNConstraint);  
            // 0x01687F9C: MOV x0, x21                | X0 = constraint;//m1                    
            // 0x01687FA0: MOV x1, x24                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01687FA4: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_168; //  | 
            // 0x01687FA8: BLR x9                     | X0 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160();
            // 0x01687FAC: TBZ w0, #0, #0x1688004     | if ((constraint & 0x1) == 0) goto label_14;
            if((constraint & 1) == 0)
            {
                goto label_14;
            }
            label_11:
            // 0x01687FB0: FSUB s0, s12, s9           | S0 = (p.x - p.x);                       
            val_14 = val_14 - p.x;
            // 0x01687FB4: LDR x8, [x20, #8]          | X8 = nnInfo.constrainedNode;            
            // 0x01687FB8: FSUB s1, s10, s8           | S1 = (p.z - p.z);                       
            float val_3 = val_4 - p.z;
            // 0x01687FBC: FMUL s0, s0, s0            | S0 = ((p.x - p.x) * (p.x - p.x));       
            val_14 = val_14 * val_14;
            // 0x01687FC0: FMUL s1, s1, s1            | S1 = ((p.z - p.z) * (p.z - p.z));       
            val_3 = val_3 * val_3;
            // 0x01687FC4: FADD s0, s0, s1            | S0 = (((p.x - p.x) * (p.x - p.x)) + ((p.z - p.z) * (p.z - p.z)));
            val_14 = val_14 + val_3;
            // 0x01687FC8: CBZ x8, #0x1687fdc         | if (nnInfo.constrainedNode == null) goto label_13;
            if(nnInfo.constrainedNode == null)
            {
                goto label_13;
            }
            // 0x01687FCC: LDR s1, [x19]              | S1 = closestDist;                       
            float val_15 = closestDist;
            // 0x01687FD0: FMUL s1, s1, s1            | S1 = (closestDist * closestDist);       
            val_15 = val_15 * val_15;
            // 0x01687FD4: FCMP s0, s1                | STATE = COMPARE((((p.x - p.x) * (p.x - p.x)) + ((p.z - p.z) * (p.z - p.z))), (closestDist * closestDist))
            // 0x01687FD8: B.PL #0x1688004            | if (p.x >= 0) goto label_14;            
            if(val_14 >= 0)
            {
                goto label_14;
            }
            label_13:
            // 0x01687FDC: FSQRT s1, s0               | 
            // 0x01687FE0: STR x24, [x20, #8]         | nnInfo.constrainedNode = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513412547336
            nnInfo.constrainedNode = val_4;
            // 0x01687FE4: STR s12, [x20, #0x1c]      | nnInfo.constClampedPosition.x = p.x;     //  dest_result_addr=1152921513412547356
            nnInfo.constClampedPosition.x = val_14;
            // 0x01687FE8: STR s11, [x20, #0x20]      | nnInfo.constClampedPosition.y = p.y;     //  dest_result_addr=1152921513412547360
            nnInfo.constClampedPosition.y = val_4;
            // 0x01687FEC: STR s10, [x20, #0x24]      | nnInfo.constClampedPosition.z = p.z;     //  dest_result_addr=1152921513412547364
            nnInfo.constClampedPosition.z = val_4;
            // 0x01687FF0: FCMP s1, s1                | STATE = COMPARE((closestDist * closestDist), (closestDist * closestDist))
            // 0x01687FF4: B.VC #0x1688000            | if (closestDist < _TYPE_MAX_) goto label_15;
            if(val_15 < _TYPE_MAX_)
            {
                goto label_15;
            }
            // 0x01687FF8: BL #0x9813c0               | X0 = sub_9813C0( ?? constraint, ????);  
            // 0x01687FFC: MOV v1.16b, v0.16b         | V1 = (((p.x - p.x) * (p.x - p.x)) + ((p.z - p.z) * (p.z - p.z)));//m1
            val_7 = val_14;
            label_15:
            // 0x01688000: STR s1, [x19]              | closestDist = (((p.x - p.x) * (p.x - p.x)) + ((p.z - p.z) * (p.z - p.z)));  //  dest_result_addr=1152921513412539088
            closestDist = val_7;
            label_14:
            // 0x01688004: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x01688008: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x0168800C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x01688010: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x01688014: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x01688018: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x0168801C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x01688020: LDP d13, d12, [sp], #0x80  | D13 = ; D12 = ;                          //  | 
            // 0x01688024: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01687D80 (23625088), len: 84  VirtAddr: 0x01687D80 RVA: 0x01687D80 token: 100683173 methodIndex: 49895 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NNInfo QueryClosest(UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint, ref float distance, Pathfinding.NNInfo previous)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NNInfo val_0;
            // 0x01687D80: STP x20, x19, [sp, #-0x20]! | stack[1152921513412770960] = ???;  stack[1152921513412770968] = ???;  //  dest_result_addr=1152921513412770960 |  dest_result_addr=1152921513412770968
            // 0x01687D84: STP x29, x30, [sp, #0x10]  | stack[1152921513412770976] = ???;  stack[1152921513412770984] = ???;  //  dest_result_addr=1152921513412770976 |  dest_result_addr=1152921513412770984
            // 0x01687D88: ADD x29, sp, #0x10         | X29 = (1152921513412770960 + 16) = 1152921513412770976 (0x100000020CDFBCA0);
            // 0x01687D8C: LDR w10, [x0, #0x18]       | W10 = this.count; //P2                  
            // 0x01687D90: MOV x19, x3                | X19 = 1152921513412823216 (0x100000020CE088B0);//ML01
            // 0x01687D94: MOV x9, x1                 | X9 = constraint;//m1                    
            // 0x01687D98: MOV x20, x8                | X20 = 1152921513412835536 (0x100000020CE0B8D0);//ML01
            // 0x01687D9C: CBZ w10, #0x1687db0        | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x01687DA0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01687DA4: MOV x3, x9                 | X3 = constraint;//m1                    
            // 0x01687DA8: MOV x4, x19                | X4 = 1152921513412823216 (0x100000020CE088B0);//ML01
            // 0x01687DAC: BL #0x1688134              | this.SearchBoxClosest(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, closestDist: ref  float val_1 = 3.458523E-31f, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {node = previous.node, constrainedNode = previous.constrainedNode, clampedPosition = new UnityEngine.Vector3() {x = previous.clampedPosition.x, y = previous.clampedPosition.y, z = previous.clampedPosition.z}, constClampedPosition = new UnityEngine.Vector3() {x = previous.constClampedPosition.x, y =
            this.SearchBoxClosest(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, closestDist: ref  float val_1 = 3.458523E-31f, constraint:  constraint, nnInfo: ref  new Pathfinding.NNInfo() {node = previous.node, constrainedNode = previous.constrainedNode, clampedPosition = new UnityEngine.Vector3() {x = previous.clampedPosition.x, y = previous.clampedPosition.y, z = previous.clampedPosition.z}, constClampedPosition = new UnityEngine.Vector3() {x = previous.constClampedPosition.x, y = previous.constClampedPosition.y, z = previous.constClampedPosition.z}, row = previous.row, col = previous.col});
            label_0:
            // 0x01687DB0: LDR q0, [x19, #0x20]       | Q0 = previous.constClampedPosition.y;   
            // 0x01687DB4: STR q0, [x20, #0x20]       | val_0.constClampedPosition.y = previous.constClampedPosition.y;  //  dest_result_addr=1152921513412835568
            val_0.constClampedPosition.y = previous.constClampedPosition.y;
            // 0x01687DB8: LDR q0, [x19, #0x10]       | Q0 = previous.clampedPosition.x;        
            // 0x01687DBC: STR q0, [x20, #0x10]       | val_0.clampedPosition.x = previous.clampedPosition.x;  //  dest_result_addr=1152921513412835552
            val_0.clampedPosition.x = previous.clampedPosition.x;
            // 0x01687DC0: LDR q0, [x19]              | Q0 = previous.node;                     
            // 0x01687DC4: STR q0, [x20]              | val_0.node = previous.node;              //  dest_result_addr=1152921513412835536
            val_0.node = previous.node;
            // 0x01687DC8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01687DCC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01687DD0: RET                        |  return (Pathfinding.NNInfo)val_0;      
            return val_0;
        
        }
        //
        // Offset in libil2cpp.so: 0x01688134 (23626036), len: 688  VirtAddr: 0x01688134 RVA: 0x01688134 token: 100683174 methodIndex: 49896 delegateWrapperIndex: 0 methodInvoker: 0
        private void SearchBoxClosest(int boxi, UnityEngine.Vector3 p, ref float closestDist, Pathfinding.NNConstraint constraint, ref Pathfinding.NNInfo nnInfo)
        {
            //
            // Disasemble & Code
            //  | 
            float val_5;
            //  | 
            Pathfinding.MeshNode val_6;
            //  | 
            BBTreeBox[] val_7;
            //  | 
            BBTreeBox val_8;
            //  | 
            float val_9;
            //  | 
            BBTreeBox val_10;
            label_20:
            // 0x01688134: STP d13, d12, [sp, #-0x80]! | stack[1152921513413046768] = ???;  stack[1152921513413046776] = ???;  //  dest_result_addr=1152921513413046768 |  dest_result_addr=1152921513413046776
            // 0x01688138: STP d11, d10, [sp, #0x10]  | stack[1152921513413046784] = ???;  stack[1152921513413046792] = ???;  //  dest_result_addr=1152921513413046784 |  dest_result_addr=1152921513413046792
            // 0x0168813C: STP d9, d8, [sp, #0x20]    | stack[1152921513413046800] = ???;  stack[1152921513413046808] = ???;  //  dest_result_addr=1152921513413046800 |  dest_result_addr=1152921513413046808
            // 0x01688140: STP x26, x25, [sp, #0x30]  | stack[1152921513413046816] = ???;  stack[1152921513413046824] = ???;  //  dest_result_addr=1152921513413046816 |  dest_result_addr=1152921513413046824
            // 0x01688144: STP x24, x23, [sp, #0x40]  | stack[1152921513413046832] = ???;  stack[1152921513413046840] = ???;  //  dest_result_addr=1152921513413046832 |  dest_result_addr=1152921513413046840
            // 0x01688148: STP x22, x21, [sp, #0x50]  | stack[1152921513413046848] = ???;  stack[1152921513413046856] = ???;  //  dest_result_addr=1152921513413046848 |  dest_result_addr=1152921513413046856
            // 0x0168814C: STP x20, x19, [sp, #0x60]  | stack[1152921513413046864] = ???;  stack[1152921513413046872] = ???;  //  dest_result_addr=1152921513413046864 |  dest_result_addr=1152921513413046872
            // 0x01688150: STP x29, x30, [sp, #0x70]  | stack[1152921513413046880] = ???;  stack[1152921513413046888] = ???;  //  dest_result_addr=1152921513413046880 |  dest_result_addr=1152921513413046888
            // 0x01688154: ADD x29, sp, #0x70         | X29 = (1152921513413046768 + 112) = 1152921513413046880 (0x100000020CE3F260);
            // 0x01688158: SUB sp, sp, #0x10          | SP = (1152921513413046768 - 16) = 1152921513413046752 (0x100000020CE3F1E0);
            // 0x0168815C: ADRP x24, #0x3738000       | X24 = 57901056 (0x3738000);             
            // 0x01688160: LDRB w8, [x24, #0xf3]      | W8 = (bool)static_value_037380F3;       
            // 0x01688164: MOV x20, x4                | X20 = 1152921513413099136 (0x100000020CE4BE80);//ML01
            // 0x01688168: MOV x21, x3                | X21 = constraint;//m1                   
            // 0x0168816C: MOV x19, x2                | X19 = 1152921513413090896 (0x100000020CE49E50);//ML01
            // 0x01688170: MOV v8.16b, v2.16b         | V8 = p.z;//m1                           
            val_5 = p.z;
            // 0x01688174: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x01688178: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
            // 0x0168817C: MOV w23, w1                | W23 = boxi;//m1                         
            // 0x01688180: MOV x22, x0                | X22 = 1152921513413058896 (0x100000020CE42150);//ML01
            // 0x01688184: TBNZ w8, #0, #0x16881a0    | if (static_value_037380F3 == true) goto label_0;
            // 0x01688188: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x0168818C: LDR x8, [x8, #0xe8]        | X8 = 0x2B8F130;                         
            // 0x01688190: LDR w0, [x8]               | W0 = 0x130E;                            
            val_6 = 4878;
            // 0x01688194: BL #0x2782188              | X0 = sub_2782188( ?? 0x130E, ????);     
            // 0x01688198: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168819C: STRB w8, [x24, #0xf3]      | static_value_037380F3 = true;            //  dest_result_addr=57901299
            label_0:
            // 0x016881A0: STR wzr, [sp, #8]          | stack[1152921513413046760] = 0x0;        //  dest_result_addr=1152921513413046760
            // 0x016881A4: STR xzr, [sp]              | stack[1152921513413046752] = 0x0;        //  dest_result_addr=1152921513413046752
            // 0x016881A8: LDR x24, [x22, #0x10]      | X24 = this.arr; //P2                    
            // 0x016881AC: CBNZ x24, #0x16881b4       | if (this.arr != null) goto label_1;     
            if(this.arr != null)
            {
                goto label_1;
            }
            // 0x016881B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130E, ????);     
            label_1:
            // 0x016881B4: LDR w8, [x24, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016881B8: SXTW x25, w23              | X25 = (long)(int)(boxi);                
            val_7 = (long)boxi;
            // 0x016881BC: CMP w8, w23                | STATE = COMPARE(this.arr.Length, boxi)  
            // 0x016881C0: B.HI #0x16881d0            | if (this.arr.Length > boxi) goto label_2;
            if(this.arr.Length > boxi)
            {
                goto label_2;
            }
            // 0x016881C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130E, ????);     
            // 0x016881C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016881CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130E, ????);     
            label_2:
            // 0x016881D0: ADD x8, x24, x25, lsl #5   | X8 = this.arr[((long)(int)(boxi)) << 5]; //PARR1 
            // 0x016881D4: LDR x23, [x8, #0x30]       | X23 = this.arr[((long)(int)(boxi)) << 5][2]
            val_8 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016881D8: CBZ x23, #0x16882e0        | if (this.arr[((long)(int)(boxi)) << 5][2] == 0) goto label_3;
            if(val_8 == 0)
            {
                goto label_3;
            }
            // 0x016881DC: LDR s3, [x19]              | S3 = closestDist;                       
            // 0x016881E0: MOV x1, x23                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x016881E4: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016881E8: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x016881EC: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x016881F0: BL #0x16883e4              | X0 = Pathfinding.BBTree.NodeIntersectsCircle(node:  val_6 = 4878, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, radius:  closestDist);
            bool val_1 = Pathfinding.BBTree.NodeIntersectsCircle(node:  val_6, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, radius:  closestDist);
            // 0x016881F4: TBZ w0, #0, #0x16883bc     | if (val_1 == false) goto label_19;      
            if(val_1 == false)
            {
                goto label_19;
            }
            // 0x016881F8: LDR x8, [x23]              | X8 = this.arr[((long)(int)(boxi)) << 5][2].rect;
            // 0x016881FC: MOV x0, x23                | X0 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01688200: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01688204: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x01688208: LDR x9, [x8, #0x250]       |  //  not_find_field!1:592
            // 0x0168820C: LDR x1, [x8, #0x258]       |  //  not_find_field!1:600
            // 0x01688210: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01688214: BLR x9                     | X0 = mem[this.arr[((long)(int)(boxi)) << 5][2].rect + 592]();
            // 0x01688218: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x0168821C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01688220: MOV v12.16b, v0.16b        | V12 = p.x;//m1                          
            // 0x01688224: MOV v11.16b, v1.16b        | V11 = p.y;//m1                          
            // 0x01688228: MOV v13.16b, v2.16b        | V13 = p.z;//m1                          
            // 0x0168822C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x01688230: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01688234: TBZ w8, #0, #0x1688244     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01688238: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0168823C: CBNZ w8, #0x1688244        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01688240: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_6:
            // 0x01688244: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168824C: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
            // 0x01688250: MOV v1.16b, v11.16b        | V1 = p.y;//m1                           
            // 0x01688254: MOV v2.16b, v13.16b        | V2 = p.z;//m1                           
            // 0x01688258: MOV v3.16b, v10.16b        | V3 = p.x;//m1                           
            // 0x0168825C: MOV v4.16b, v9.16b         | V4 = p.y;//m1                           
            // 0x01688260: MOV v5.16b, v8.16b         | V5 = p.z;//m1                           
            // 0x01688264: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5});
            // 0x01688268: MOV x0, sp                 | X0 = 1152921513413046752 (0x100000020CE3F1E0);//ML01
            // 0x0168826C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688270: STP s0, s1, [sp]           | stack[1152921513413046752] = val_2.x;  stack[1152921513413046756] = val_2.y;  //  dest_result_addr=1152921513413046752 |  dest_result_addr=1152921513413046756
            // 0x01688274: STR s2, [sp, #8]           | stack[1152921513413046760] = val_2.z;    //  dest_result_addr=1152921513413046760
            // 0x01688278: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x0168827C: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
            val_5 = val_2.x;
            // 0x01688280: CBZ x21, #0x168829c        | if (constraint == null) goto label_7;   
            if(constraint == null)
            {
                goto label_7;
            }
            // 0x01688284: LDR x8, [x21]              | X8 = typeof(Pathfinding.NNConstraint);  
            // 0x01688288: MOV x0, x21                | X0 = constraint;//m1                    
            // 0x0168828C: MOV x1, x23                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01688290: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_168; //  | 
            // 0x01688294: BLR x9                     | X0 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160();
            // 0x01688298: TBZ w0, #0, #0x16883bc     | if ((constraint & 0x1) == 0) goto label_19;
            if((constraint & 1) == 0)
            {
                goto label_19;
            }
            label_7:
            // 0x0168829C: LDR x8, [x20, #8]          | X8 = nnInfo.constrainedNode;            
            // 0x016882A0: CBZ x8, #0x16882b4         | if (nnInfo.constrainedNode == null) goto label_9;
            if(nnInfo.constrainedNode == null)
            {
                goto label_9;
            }
            // 0x016882A4: LDR s0, [x19]              | S0 = closestDist;                       
            float val_5 = closestDist;
            // 0x016882A8: FMUL s0, s0, s0            | S0 = (closestDist * closestDist);       
            val_5 = val_5 * val_5;
            // 0x016882AC: FCMP s8, s0                | STATE = COMPARE(val_2.x, (closestDist * closestDist))
            // 0x016882B0: B.PL #0x16883bc            | if (val_5 >= 0) goto label_19;          
            if(val_5 >= 0)
            {
                goto label_19;
            }
            label_9:
            // 0x016882B4: FSQRT s0, s8               | 
            // 0x016882B8: STR x23, [x20, #8]         | nnInfo.constrainedNode = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513413099144
            nnInfo.constrainedNode = val_8;
            // 0x016882BC: STR s12, [x20, #0x1c]      | nnInfo.constClampedPosition.x = p.x;     //  dest_result_addr=1152921513413099164
            nnInfo.constClampedPosition.x = p.x;
            // 0x016882C0: STR s11, [x20, #0x20]      | nnInfo.constClampedPosition.y = p.y;     //  dest_result_addr=1152921513413099168
            nnInfo.constClampedPosition.y = p.y;
            // 0x016882C4: STR s13, [x20, #0x24]      | nnInfo.constClampedPosition.z = p.z;     //  dest_result_addr=1152921513413099172
            nnInfo.constClampedPosition.z = val_5;
            // 0x016882C8: FCMP s0, s0                | STATE = COMPARE((closestDist * closestDist), (closestDist * closestDist))
            // 0x016882CC: B.VC #0x16882d8            | if (closestDist < _TYPE_MAX_) goto label_11;
            if(val_5 < _TYPE_MAX_)
            {
                goto label_11;
            }
            // 0x016882D0: MOV v0.16b, v8.16b         | V0 = val_2.x;//m1                       
            val_9 = val_5;
            // 0x016882D4: BL #0x9813c0               | X0 = sub_9813C0( ?? constraint, ????);  
            label_11:
            // 0x016882D8: STR s0, [x19]              | closestDist = val_2.x;                   //  dest_result_addr=1152921513413090896
            closestDist = val_9;
            // 0x016882DC: B #0x16883bc               |  goto label_19;                         
            goto label_19;
            label_3:
            // 0x016882E0: LDPSW x24, x23, [x8, #0x38] | X24 = this.arr[((long)(int)(boxi)) << 5][3] X23 = this.arr[((long)(int)(boxi)) << 5][4] //  | 
            BBTreeBox val_6 = this.arr[((long)(int)(boxi)) << 5];
            val_8 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016882E4: LDR x25, [x22, #0x10]      | X25 = this.arr; //P2                    
            val_7 = this.arr;
            // 0x016882E8: CBNZ x25, #0x16882f0       | if (this.arr != null) goto label_13;    
            if(val_7 != null)
            {
                goto label_13;
            }
            // 0x016882EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130E, ????);     
            label_13:
            // 0x016882F0: LDR w8, [x25, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016882F4: CMP w24, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x016882F8: B.LO #0x1688308            | if (this.arr[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_14;
            if(val_6 < this.arr.Length)
            {
                goto label_14;
            }
            // 0x016882FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130E, ????);     
            // 0x01688300: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688304: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130E, ????);     
            label_14:
            // 0x01688308: ADD x8, x25, x24, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]; //PARR1 
            // 0x0168830C: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] S1 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] //  | 
            BBTreeBox val_7 = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            val_10 = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01688310: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] S3 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] //  | 
            BBTreeBox val_8 = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            BBTreeBox val_9 = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01688314: LDR s7, [x19]              | S7 = val_2.x;                           
            // 0x01688318: MOV v4.16b, v10.16b        | V4 = p.x;//m1                           
            // 0x0168831C: MOV v5.16b, v9.16b         | V5 = p.y;//m1                           
            // 0x01688320: MOV v6.16b, v8.16b         | V6 = p.z;//m1                           
            // 0x01688324: BL #0x1688028              | X0 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_YMin = val_10, m_Width = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_Height = val_7[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, radius:  closestDist);
            bool val_3 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_7, m_YMin = val_10, m_Width = val_8, m_Height = val_9}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, radius:  closestDist);
            // 0x01688328: TBZ w0, #0, #0x1688350     | if (val_3 == false) goto label_15;      
            if(val_3 == false)
            {
                goto label_15;
            }
            // 0x0168832C: MOV x0, x22                | X0 = 1152921513413058896 (0x100000020CE42150);//ML01
            val_6 = this;
            // 0x01688330: MOV w1, w24                | W1 = this.arr[((long)(int)(boxi)) << 5][3];//m1
            // 0x01688334: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01688338: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            val_10 = p.y;
            // 0x0168833C: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01688340: MOV x2, x19                | X2 = 1152921513413090896 (0x100000020CE49E50);//ML01
            // 0x01688344: MOV x3, x21                | X3 = constraint;//m1                    
            // 0x01688348: MOV x4, x20                | X4 = 1152921513413099136 (0x100000020CE4BE80);//ML01
            // 0x0168834C: BL #0x1688134              |  R0 = label_20();                       
            label_15:
            // 0x01688350: LDR x24, [x22, #0x10]      | X24 = this.arr; //P2                    
            // 0x01688354: CBNZ x24, #0x168835c       | if (this.arr != null) goto label_17;    
            if(this.arr != null)
            {
                goto label_17;
            }
            // 0x01688358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_17:
            // 0x0168835C: LDR w8, [x24, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01688360: CMP w23, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][4], this.arr.Length)
            // 0x01688364: B.LO #0x1688374            | if (val_8 < this.arr.Length) goto label_18;
            if(val_8 < this.arr.Length)
            {
                goto label_18;
            }
            // 0x01688368: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0168836C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688370: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_18:
            // 0x01688374: ADD x8, x24, x23, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5]; //PARR1 
            // 0x01688378: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0] S1 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0] //  | 
            BBTreeBox val_10 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            BBTreeBox val_11 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            // 0x0168837C: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][1] S3 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][1] //  | 
            BBTreeBox val_12 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            BBTreeBox val_13 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            // 0x01688380: LDR s7, [x19]              | S7 = val_2.x;                           
            // 0x01688384: MOV v4.16b, v10.16b        | V4 = p.x;//m1                           
            // 0x01688388: MOV v5.16b, v9.16b         | V5 = p.y;//m1                           
            // 0x0168838C: MOV v6.16b, v8.16b         | V6 = p.z;//m1                           
            // 0x01688390: BL #0x1688028              | X0 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5], m_YMin = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5], m_Width = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5], m_Height = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, radius:  closestDist);
            bool val_4 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_10, m_YMin = val_11, m_Width = val_12, m_Height = val_13}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = val_5}, radius:  closestDist);
            // 0x01688394: TBZ w0, #0, #0x16883bc     | if (val_4 == false) goto label_19;      
            if(val_4 == false)
            {
                goto label_19;
            }
            // 0x01688398: MOV x0, x22                | X0 = 1152921513413058896 (0x100000020CE42150);//ML01
            // 0x0168839C: MOV w1, w23                | W1 = this.arr[((long)(int)(boxi)) << 5][4];//m1
            // 0x016883A0: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016883A4: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x016883A8: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x016883AC: MOV x2, x19                | X2 = 1152921513413090896 (0x100000020CE49E50);//ML01
            // 0x016883B0: MOV x3, x21                | X3 = constraint;//m1                    
            // 0x016883B4: MOV x4, x20                | X4 = 1152921513413099136 (0x100000020CE4BE80);//ML01
            // 0x016883B8: BL #0x1688134              |  R0 = label_20();                       
            label_19:
            // 0x016883BC: SUB sp, x29, #0x70         | SP = (1152921513413046880 - 112) = 1152921513413046768 (0x100000020CE3F1F0);
            // 0x016883C0: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x016883C4: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x016883C8: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x016883CC: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x016883D0: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x016883D4: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x016883D8: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x016883DC: LDP d13, d12, [sp], #0x80  | D13 = ; D12 = ;                          //  | 
            // 0x016883E0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168851C (23627036), len: 32  VirtAddr: 0x0168851C RVA: 0x0168851C token: 100683175 methodIndex: 49897 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.MeshNode QueryInside(UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint)
        {
            //
            // Disasemble & Code
            // 0x0168851C: LDR w9, [x0, #0x18]        | W9 = this.count; //P2                   
            // 0x01688520: MOV x8, x1                 | X8 = constraint;//m1                    
            // 0x01688524: CBZ w9, #0x1688534         | if (this.count == 0) goto label_0;      
            if(this.count == 0)
            {
                goto label_0;
            }
            // 0x01688528: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0168852C: MOV x2, x8                 | X2 = constraint;//m1                    
            // 0x01688530: B #0x168853c               | return this.SearchBoxInside(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, constraint:  constraint);
            return this.SearchBoxInside(boxi:  0, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, constraint:  constraint);
            label_0:
            // 0x01688534: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688538: RET                        |  return (Pathfinding.MeshNode)null;     
            return (Pathfinding.MeshNode)0;
            //  |  // // {name=val_0, type=Pathfinding.MeshNode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168853C (23627068), len: 564  VirtAddr: 0x0168853C RVA: 0x0168853C token: 100683176 methodIndex: 49898 delegateWrapperIndex: 0 methodInvoker: 0
        private Pathfinding.MeshNode SearchBoxInside(int boxi, UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint)
        {
            //
            // Disasemble & Code
            //  | 
            BBTreeBox val_6;
            //  | 
            var val_7;
            //  | 
            BBTreeBox val_8;
            label_18:
            // 0x0168853C: STP d11, d10, [sp, #-0x60]! | stack[1152921513413524848] = ???;  stack[1152921513413524856] = ???;  //  dest_result_addr=1152921513413524848 |  dest_result_addr=1152921513413524856
            // 0x01688540: STP d9, d8, [sp, #0x10]    | stack[1152921513413524864] = ???;  stack[1152921513413524872] = ???;  //  dest_result_addr=1152921513413524864 |  dest_result_addr=1152921513413524872
            // 0x01688544: STP x24, x23, [sp, #0x20]  | stack[1152921513413524880] = ???;  stack[1152921513413524888] = ???;  //  dest_result_addr=1152921513413524880 |  dest_result_addr=1152921513413524888
            // 0x01688548: STP x22, x21, [sp, #0x30]  | stack[1152921513413524896] = ???;  stack[1152921513413524904] = ???;  //  dest_result_addr=1152921513413524896 |  dest_result_addr=1152921513413524904
            // 0x0168854C: STP x20, x19, [sp, #0x40]  | stack[1152921513413524912] = ???;  stack[1152921513413524920] = ???;  //  dest_result_addr=1152921513413524912 |  dest_result_addr=1152921513413524920
            // 0x01688550: STP x29, x30, [sp, #0x50]  | stack[1152921513413524928] = ???;  stack[1152921513413524936] = ???;  //  dest_result_addr=1152921513413524928 |  dest_result_addr=1152921513413524936
            // 0x01688554: ADD x29, sp, #0x50         | X29 = (1152921513413524848 + 80) = 1152921513413524928 (0x100000020CEB3DC0);
            // 0x01688558: SUB sp, sp, #0x10          | SP = (1152921513413524848 - 16) = 1152921513413524832 (0x100000020CEB3D60);
            // 0x0168855C: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x01688560: LDRB w8, [x22, #0xf4]      | W8 = (bool)static_value_037380F4;       
            // 0x01688564: MOV x19, x2                | X19 = constraint;//m1                   
            // 0x01688568: MOV v8.16b, v2.16b         | V8 = p.z;//m1                           
            // 0x0168856C: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x01688570: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
            // 0x01688574: MOV w21, w1                | W21 = boxi;//m1                         
            val_6 = boxi;
            // 0x01688578: MOV x20, x0                | X20 = 1152921513413536944 (0x100000020CEB6CB0);//ML01
            // 0x0168857C: TBNZ w8, #0, #0x1688598    | if (static_value_037380F4 == true) goto label_0;
            // 0x01688580: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x01688584: LDR x8, [x8, #0x300]       | X8 = 0x2B8F134;                         
            // 0x01688588: LDR w0, [x8]               | W0 = 0x130F;                            
            // 0x0168858C: BL #0x2782188              | X0 = sub_2782188( ?? 0x130F, ????);     
            // 0x01688590: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01688594: STRB w8, [x22, #0xf4]      | static_value_037380F4 = true;            //  dest_result_addr=57901300
            label_0:
            // 0x01688598: LDR x22, [x20, #0x10]      | X22 = this.arr; //P2                    
            // 0x0168859C: CBNZ x22, #0x16885a4       | if (this.arr != null) goto label_1;     
            if(this.arr != null)
            {
                goto label_1;
            }
            // 0x016885A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130F, ????);     
            label_1:
            // 0x016885A4: LDR w8, [x22, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016885A8: SXTW x23, w21              | X23 = (long)(int)(boxi);                
            val_7 = (long)val_6;
            // 0x016885AC: CMP w8, w21                | STATE = COMPARE(this.arr.Length, boxi)  
            // 0x016885B0: B.HI #0x16885c0            | if (this.arr.Length > val_6) goto label_2;
            if(this.arr.Length > val_6)
            {
                goto label_2;
            }
            // 0x016885B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130F, ????);     
            // 0x016885B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016885BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130F, ????);     
            label_2:
            // 0x016885C0: ADD x8, x22, x23, lsl #5   | X8 = this.arr[((long)(int)(boxi)) << 5]; //PARR1 
            // 0x016885C4: LDR x22, [x8, #0x30]       | X22 = this.arr[((long)(int)(boxi)) << 5][2]
            val_8 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016885C8: CBZ x22, #0x168864c        | if (this.arr[((long)(int)(boxi)) << 5][2] == 0) goto label_3;
            if(val_8 == 0)
            {
                goto label_3;
            }
            // 0x016885CC: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x016885D0: LDR x8, [x8, #0x540]       | X8 = 1152921504839380992;               
            // 0x016885D4: LDR x0, [x8]               | X0 = typeof(Pathfinding.Int3);          
            // 0x016885D8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x016885DC: TBZ w8, #0, #0x16885ec     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x016885E0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x016885E4: CBNZ w8, #0x16885ec        | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x016885E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_5:
            // 0x016885EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016885F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016885F4: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016885F8: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x016885FC: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01688600: BL #0x1548f50              | X0 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            Pathfinding.Int3 val_1 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x01688604: LDR x8, [x22]              | X8 = this.arr[((long)(int)(boxi)) << 5][2].rect;
            // 0x01688608: MOV x4, x0                 | X4 = val_1.x;//m1                       
            // 0x0168860C: AND x2, x1, #0xffffffff    | X2 = (val_1.z & 4294967295);            
            int val_2 = val_1.z & 4294967295;
            // 0x01688610: MOV x0, x22                | X0 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01688614: LDR x9, [x8, #0x270]       |  //  not_find_field!1:624
            // 0x01688618: LDR x3, [x8, #0x278]       |  //  not_find_field!1:632
            // 0x0168861C: MOV x1, x4                 | X1 = val_1.x;//m1                       
            // 0x01688620: BLR x9                     | X0 = mem[this.arr[((long)(int)(boxi)) << 5][2].rect + 624]();
            // 0x01688624: TBZ w0, #0, #0x1688748     | if ((this.arr[((long)(int)(boxi)) << 5][2] & 0x1) == 0) goto label_17;
            if((val_8 & 1) == 0)
            {
                goto label_17;
            }
            // 0x01688628: CBZ x19, #0x168874c        | if (constraint == null) goto label_19;  
            if(constraint == null)
            {
                goto label_19;
            }
            // 0x0168862C: LDR x8, [x19]              | X8 = typeof(Pathfinding.NNConstraint);  
            // 0x01688630: MOV x0, x19                | X0 = constraint;//m1                    
            // 0x01688634: MOV x1, x22                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01688638: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_168; //  | 
            // 0x0168863C: BLR x9                     | X0 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160();
            // 0x01688640: AND w8, w0, #1             | W8 = (constraint & 1);                  
            Pathfinding.NNConstraint val_3 = constraint & 1;
            // 0x01688644: TBZ w8, #0, #0x1688748     | if (((constraint & 1) & 0x1) == 0) goto label_17;
            if((val_3 & 1) == 0)
            {
                goto label_17;
            }
            // 0x01688648: B #0x168874c               |  goto label_19;                         
            goto label_19;
            label_3:
            // 0x0168864C: LDPSW x22, x21, [x8, #0x38] | X22 = this.arr[((long)(int)(boxi)) << 5][3] X21 = this.arr[((long)(int)(boxi)) << 5][4] //  | 
            BBTreeBox val_6 = this.arr[((long)(int)(boxi)) << 5];
            val_6 = this.arr[((long)(int)(boxi)) << 5];
            // 0x01688650: LDR x23, [x20, #0x10]      | X23 = this.arr; //P2                    
            // 0x01688654: CBNZ x23, #0x168865c       | if (this.arr != null) goto label_10;    
            if(this.arr != null)
            {
                goto label_10;
            }
            // 0x01688658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130F, ????);     
            label_10:
            // 0x0168865C: LDR w8, [x23, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01688660: CMP w22, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x01688664: B.LO #0x1688674            | if (this.arr[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_11;
            if(val_6 < this.arr.Length)
            {
                goto label_11;
            }
            // 0x01688668: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130F, ????);     
            // 0x0168866C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688670: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130F, ????);     
            label_11:
            // 0x01688674: ADD x8, x23, x22, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]; //PARR1 
            // 0x01688678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168867C: ADD x0, sp, #8             | X0 = (1152921513413524832 + 8) = 1152921513413524840 (0x100000020CEB3D68);
            // 0x01688680: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01688684: MOV v1.16b, v8.16b         | V1 = p.z;//m1                           
            // 0x01688688: ADD x23, x8, #0x20         | X23 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0x20]; //PARR1 
            // 0x0168868C: STR xzr, [sp, #8]          | stack[1152921513413524840] = 0x0;        //  dest_result_addr=1152921513413524840
            // 0x01688690: BL #0x2697148              | null..ctor(_x:  p.x, _y:  p.z);         
            Geometric.Point val_4 = new Geometric.Point(_x:  p.x, _y:  p.z);
            // 0x01688694: LDP s0, s1, [sp, #8]       | S0 = val_4.x; S1 = val_4.y;              //  | 
            // 0x01688698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168869C: MOV x0, x23                | X0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0x20];//m1
            var val_7 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][32];
            // 0x016886A0: BL #0x1b81aec              | X0 = label_UnityEngine_Rect_set_yMax_GL01B81AEC();
            // 0x016886A4: TBZ w0, #0, #0x16886cc     | if ((this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0x20] & 0x1) == 0) goto label_12;
            if((val_7 & 1) == 0)
            {
                goto label_12;
            }
            // 0x016886A8: MOV x0, x20                | X0 = 1152921513413536944 (0x100000020CEB6CB0);//ML01
            // 0x016886AC: MOV w1, w22                | W1 = this.arr[((long)(int)(boxi)) << 5][3];//m1
            // 0x016886B0: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016886B4: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x016886B8: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x016886BC: MOV x2, x19                | X2 = constraint;//m1                    
            // 0x016886C0: BL #0x168853c              |  R0 = label_18();                       
            // 0x016886C4: MOV x22, x0                | X22 = 1152921513413536944 (0x100000020CEB6CB0);//ML01
            val_8 = this;
            // 0x016886C8: CBNZ x22, #0x168874c       | if (this != null) goto label_19;        
            if(this != null)
            {
                goto label_19;
            }
            label_12:
            // 0x016886CC: LDR x22, [x20, #0x10]      | X22 = this.arr; //P2                    
            // 0x016886D0: CBNZ x22, #0x16886d8       | if (this.arr != null) goto label_15;    
            if(this.arr != null)
            {
                goto label_15;
            }
            // 0x016886D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_15:
            // 0x016886D8: LDR w8, [x22, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016886DC: CMP w21, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][4], this.arr.Length)
            // 0x016886E0: B.LO #0x16886f0            | if (val_6 < this.arr.Length) goto label_16;
            if(val_6 < this.arr.Length)
            {
                goto label_16;
            }
            // 0x016886E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x016886E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016886EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_16:
            // 0x016886F0: ADD x8, x22, x21, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5]; //PARR1 
            // 0x016886F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016886F8: ADD x0, sp, #8             | X0 = (1152921513413524832 + 8) = 1152921513413524840 (0x100000020CEB3D68);
            // 0x016886FC: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01688700: MOV v1.16b, v8.16b         | V1 = p.z;//m1                           
            // 0x01688704: ADD x22, x8, #0x20         | X22 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0x20]; //PARR1 
            // 0x01688708: STR xzr, [sp, #8]          | stack[1152921513413524840] = 0x0;        //  dest_result_addr=1152921513413524840
            // 0x0168870C: BL #0x2697148              | null..ctor(_x:  p.x, _y:  p.z);         
            Geometric.Point val_5 = new Geometric.Point(_x:  p.x, _y:  p.z);
            // 0x01688710: LDP s0, s1, [sp, #8]       | S0 = val_5.x; S1 = val_5.y;              //  | 
            // 0x01688714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688718: MOV x0, x22                | X0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0x20];//m1
            var val_8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][32];
            // 0x0168871C: BL #0x1b81aec              | X0 = label_UnityEngine_Rect_set_yMax_GL01B81AEC();
            // 0x01688720: TBZ w0, #0, #0x1688748     | if ((this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0x20] & 0x1) == 0) goto label_17;
            if((val_8 & 1) == 0)
            {
                goto label_17;
            }
            // 0x01688724: MOV x0, x20                | X0 = 1152921513413536944 (0x100000020CEB6CB0);//ML01
            // 0x01688728: MOV w1, w21                | W1 = this.arr[((long)(int)(boxi)) << 5][4];//m1
            // 0x0168872C: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01688730: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x01688734: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01688738: MOV x2, x19                | X2 = constraint;//m1                    
            // 0x0168873C: BL #0x168853c              |  R0 = label_18();                       
            // 0x01688740: MOV x22, x0                | X22 = 1152921513413536944 (0x100000020CEB6CB0);//ML01
            val_8 = this;
            // 0x01688744: CBNZ x22, #0x168874c       | if (this != null) goto label_19;        
            if(this != null)
            {
                goto label_19;
            }
            label_17:
            // 0x01688748: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_19:
            // 0x0168874C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x01688750: SUB sp, x29, #0x50         | SP = (1152921513413524928 - 80) = 1152921513413524848 (0x100000020CEB3D70);
            // 0x01688754: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01688758: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0168875C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01688760: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01688764: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01688768: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
            // 0x0168876C: RET                        |  return (Pathfinding.MeshNode)null;     
            return (Pathfinding.MeshNode)val_8;
            //  |  // // {name=val_0, type=Pathfinding.MeshNode, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01687904 (23623940), len: 944  VirtAddr: 0x01687904 RVA: 0x01687904 token: 100683177 methodIndex: 49899 delegateWrapperIndex: 0 methodInvoker: 0
        private void SearchBoxCircle(int boxi, UnityEngine.Vector3 p, float radius, Pathfinding.NNConstraint constraint, ref Pathfinding.NNInfo nnInfo)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.MeshNode val_7;
            //  | 
            BBTreeBox[] val_8;
            //  | 
            BBTreeBox val_9;
            //  | 
            float val_10;
            //  | 
            float val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            float val_15;
            //  | 
            BBTreeBox val_16;
            //  | 
            BBTreeBox val_17;
            label_19:
            // 0x01687904: STP d15, d14, [sp, #-0x80]! | stack[1152921513413878528] = ???;  stack[1152921513413878536] = ???;  //  dest_result_addr=1152921513413878528 |  dest_result_addr=1152921513413878536
            // 0x01687908: STP d13, d12, [sp, #0x10]  | stack[1152921513413878544] = ???;  stack[1152921513413878552] = ???;  //  dest_result_addr=1152921513413878544 |  dest_result_addr=1152921513413878552
            // 0x0168790C: STP d11, d10, [sp, #0x20]  | stack[1152921513413878560] = ???;  stack[1152921513413878568] = ???;  //  dest_result_addr=1152921513413878560 |  dest_result_addr=1152921513413878568
            // 0x01687910: STP d9, d8, [sp, #0x30]    | stack[1152921513413878576] = ???;  stack[1152921513413878584] = ???;  //  dest_result_addr=1152921513413878576 |  dest_result_addr=1152921513413878584
            // 0x01687914: STP x24, x23, [sp, #0x40]  | stack[1152921513413878592] = ???;  stack[1152921513413878600] = ???;  //  dest_result_addr=1152921513413878592 |  dest_result_addr=1152921513413878600
            // 0x01687918: STP x22, x21, [sp, #0x50]  | stack[1152921513413878608] = ???;  stack[1152921513413878616] = ???;  //  dest_result_addr=1152921513413878608 |  dest_result_addr=1152921513413878616
            // 0x0168791C: STP x20, x19, [sp, #0x60]  | stack[1152921513413878624] = ???;  stack[1152921513413878632] = ???;  //  dest_result_addr=1152921513413878624 |  dest_result_addr=1152921513413878632
            // 0x01687920: STP x29, x30, [sp, #0x70]  | stack[1152921513413878640] = ???;  stack[1152921513413878648] = ???;  //  dest_result_addr=1152921513413878640 |  dest_result_addr=1152921513413878648
            // 0x01687924: ADD x29, sp, #0x70         | X29 = (1152921513413878528 + 112) = 1152921513413878640 (0x100000020CF0A370);
            // 0x01687928: SUB sp, sp, #0x40          | SP = (1152921513413878528 - 64) = 1152921513413878464 (0x100000020CF0A2C0);
            // 0x0168792C: ADRP x23, #0x3738000       | X23 = 57901056 (0x3738000);             
            // 0x01687930: LDRB w8, [x23, #0xf5]      | W8 = (bool)static_value_037380F5;       
            // 0x01687934: MOV x19, x3                | X19 = 1152921513413926752 (0x100000020CF15F60);//ML01
            // 0x01687938: MOV x20, x2                | X20 = constraint;//m1                   
            // 0x0168793C: MOV v11.16b, v3.16b        | V11 = radius;//m1                       
            // 0x01687940: MOV v8.16b, v2.16b         | V8 = p.z;//m1                           
            // 0x01687944: MOV v9.16b, v1.16b         | V9 = p.y;//m1                           
            // 0x01687948: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
            // 0x0168794C: MOV w21, w1                | W21 = boxi;//m1                         
            // 0x01687950: MOV x22, x0                | X22 = 1152921513413890656 (0x100000020CF0D260);//ML01
            // 0x01687954: TBNZ w8, #0, #0x1687970    | if (static_value_037380F5 == true) goto label_0;
            // 0x01687958: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x0168795C: LDR x8, [x8, #0x318]       | X8 = 0x2B8F12C;                         
            // 0x01687960: LDR w0, [x8]               | W0 = 0x130D;                            
            val_7 = 4877;
            // 0x01687964: BL #0x2782188              | X0 = sub_2782188( ?? 0x130D, ????);     
            // 0x01687968: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168796C: STRB w8, [x23, #0xf5]      | static_value_037380F5 = true;            //  dest_result_addr=57901301
            label_0:
            // 0x01687970: STR wzr, [sp, #0x38]       | stack[1152921513413878520] = 0x0;        //  dest_result_addr=1152921513413878520
            // 0x01687974: STR xzr, [sp, #0x30]       | stack[1152921513413878512] = 0x0;        //  dest_result_addr=1152921513413878512
            // 0x01687978: STR wzr, [sp, #0x28]       | stack[1152921513413878504] = 0x0;        //  dest_result_addr=1152921513413878504
            // 0x0168797C: STR xzr, [sp, #0x20]       | stack[1152921513413878496] = 0x0;        //  dest_result_addr=1152921513413878496
            // 0x01687980: STR wzr, [sp, #0x18]       | stack[1152921513413878488] = 0x0;        //  dest_result_addr=1152921513413878488
            // 0x01687984: STR xzr, [sp, #0x10]       | stack[1152921513413878480] = 0x0;        //  dest_result_addr=1152921513413878480
            // 0x01687988: LDR x23, [x22, #0x10]      | X23 = this.arr; //P2                    
            val_8 = this.arr;
            // 0x0168798C: CBNZ x23, #0x1687994       | if (this.arr != null) goto label_1;     
            if(val_8 != null)
            {
                goto label_1;
            }
            // 0x01687990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130D, ????);     
            label_1:
            // 0x01687994: LDR w8, [x23, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687998: SXTW x24, w21              | X24 = (long)(int)(boxi);                
            // 0x0168799C: CMP w8, w21                | STATE = COMPARE(this.arr.Length, boxi)  
            // 0x016879A0: B.HI #0x16879b0            | if (this.arr.Length > boxi) goto label_2;
            if(this.arr.Length > boxi)
            {
                goto label_2;
            }
            // 0x016879A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130D, ????);     
            // 0x016879A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016879AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130D, ????);     
            label_2:
            // 0x016879B0: ADD x8, x23, x24, lsl #5   | X8 = this.arr[((long)(int)(boxi)) << 5]; //PARR1 
            // 0x016879B4: LDR x21, [x8, #0x30]       | X21 = this.arr[((long)(int)(boxi)) << 5][2]
            val_9 = val_8[((long)(int)(boxi)) << 5];
            // 0x016879B8: CBZ x21, #0x1687ae8        | if (this.arr[((long)(int)(boxi)) << 5][2] == 0) goto label_3;
            if(val_9 == 0)
            {
                goto label_3;
            }
            // 0x016879BC: MOV x1, x21                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x016879C0: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016879C4: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x016879C8: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x016879CC: MOV v3.16b, v11.16b        | V3 = radius;//m1                        
            // 0x016879D0: BL #0x16883e4              | X0 = Pathfinding.BBTree.NodeIntersectsCircle(node:  val_7 = 4877, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius);
            bool val_1 = Pathfinding.BBTree.NodeIntersectsCircle(node:  val_7, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius);
            // 0x016879D4: TBZ w0, #0, #0x1687c8c     | if (val_1 == false) goto label_27;      
            if(val_1 == false)
            {
                goto label_27;
            }
            // 0x016879D8: LDR x8, [x21]              | X8 = this.arr[((long)(int)(boxi)) << 5][2].rect;
            // 0x016879DC: MOV x0, x21                | X0 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x016879E0: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016879E4: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x016879E8: LDR x9, [x8, #0x250]       |  //  not_find_field!1:592
            // 0x016879EC: LDR x1, [x8, #0x258]       |  //  not_find_field!1:600
            // 0x016879F0: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x016879F4: BLR x9                     | X0 = mem[this.arr[((long)(int)(boxi)) << 5][2].rect + 592]();
            // 0x016879F8: ADRP x22, #0x3673000       | X22 = 57094144 (0x3673000);             
            // 0x016879FC: LDR x22, [x22, #0x488]     | X22 = 1152921504695078912;              
            // 0x01687A00: MOV v12.16b, v0.16b        | V12 = p.x;//m1                          
            val_10 = p.x;
            // 0x01687A04: MOV v11.16b, v1.16b        | V11 = p.y;//m1                          
            val_11 = p.y;
            // 0x01687A08: MOV v13.16b, v2.16b        | V13 = p.z;//m1                          
            // 0x01687A0C: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01687A10: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01687A14: TBZ w8, #0, #0x1687a24     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x01687A18: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01687A1C: CBNZ w8, #0x1687a24        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01687A20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_6:
            // 0x01687A24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687A2C: MOV v0.16b, v12.16b        | V0 = p.x;//m1                           
            // 0x01687A30: MOV v1.16b, v11.16b        | V1 = p.y;//m1                           
            // 0x01687A34: MOV v2.16b, v13.16b        | V2 = p.z;//m1                           
            // 0x01687A38: MOV v3.16b, v10.16b        | V3 = p.x;//m1                           
            // 0x01687A3C: MOV v4.16b, v9.16b         | V4 = p.y;//m1                           
            // 0x01687A40: MOV v5.16b, v8.16b         | V5 = p.z;//m1                           
            // 0x01687A44: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10, y = val_11, z = p.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10, y = val_11, z = p.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x01687A48: ADD x0, sp, #0x30          | X0 = (1152921513413878464 + 48) = 1152921513413878512 (0x100000020CF0A2F0);
            // 0x01687A4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687A50: STP s0, s1, [sp, #0x30]    | stack[1152921513413878512] = val_2.x;  stack[1152921513413878516] = val_2.y;  //  dest_result_addr=1152921513413878512 |  dest_result_addr=1152921513413878516
            // 0x01687A54: STR s2, [sp, #0x38]        | stack[1152921513413878520] = val_2.z;    //  dest_result_addr=1152921513413878520
            // 0x01687A58: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x01687A5C: LDR x8, [x19]              | X8 = nnInfo.node;                       
            // 0x01687A60: STR s0, [sp, #0xc]         | stack[1152921513413878476] = val_2.x;    //  dest_result_addr=1152921513413878476
            // 0x01687A64: CBZ x8, #0x1687bc8         | if (nnInfo.node == null) goto label_7;  
            if(nnInfo.node == null)
            {
                goto label_7;
            }
            // 0x01687A68: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01687A6C: STR s12, [sp, #8]          | stack[1152921513413878472] = p.x;        //  dest_result_addr=1152921513413878472
            // 0x01687A70: MOV v12.16b, v11.16b       | V12 = p.y;//m1                          
            val_10 = val_11;
            // 0x01687A74: LDP s11, s14, [x19, #0x10] | S11 = nnInfo.clampedPosition.x; S14 = nnInfo.clampedPosition.y; //  | 
            val_15 = nnInfo.clampedPosition.y;
            // 0x01687A78: LDR s15, [x19, #0x18]      | S15 = nnInfo.clampedPosition.z;         
            // 0x01687A7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01687A80: TBZ w8, #0, #0x1687a90     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x01687A84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01687A88: CBNZ w8, #0x1687a90        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x01687A8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_9:
            // 0x01687A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687A98: MOV v0.16b, v11.16b        | V0 = nnInfo.clampedPosition.x;//m1      
            // 0x01687A9C: MOV v1.16b, v14.16b        | V1 = nnInfo.clampedPosition.y;//m1      
            // 0x01687AA0: MOV v2.16b, v15.16b        | V2 = nnInfo.clampedPosition.z;//m1      
            // 0x01687AA4: MOV v3.16b, v10.16b        | V3 = p.x;//m1                           
            // 0x01687AA8: MOV v4.16b, v9.16b         | V4 = p.y;//m1                           
            // 0x01687AAC: MOV v5.16b, v8.16b         | V5 = p.z;//m1                           
            // 0x01687AB0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = nnInfo.clampedPosition.x, y = val_15, z = nnInfo.clampedPosition.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = nnInfo.clampedPosition.x, y = val_15, z = nnInfo.clampedPosition.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x01687AB4: ADD x0, sp, #0x20          | X0 = (1152921513413878464 + 32) = 1152921513413878496 (0x100000020CF0A2E0);
            // 0x01687AB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687ABC: STP s0, s1, [sp, #0x20]    | stack[1152921513413878496] = val_3.x;  stack[1152921513413878500] = val_3.y;  //  dest_result_addr=1152921513413878496 |  dest_result_addr=1152921513413878500
            // 0x01687AC0: STR s2, [sp, #0x28]        | stack[1152921513413878504] = val_3.z;    //  dest_result_addr=1152921513413878504
            // 0x01687AC4: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x01687AC8: LDR s1, [sp, #0xc]         | S1 = val_2.x;                           
            // 0x01687ACC: MOV v11.16b, v12.16b       | V11 = p.y;//m1                          
            val_11 = val_10;
            // 0x01687AD0: FCMP s1, s0                | STATE = COMPARE(val_2.x, val_3.x)       
            // 0x01687AD4: B.PL #0x1687bdc            | if (val_2.x >= 0) goto label_10;        
            if(val_2.x >= 0)
            {
                goto label_10;
            }
            // 0x01687AD8: LDR s0, [sp, #8]           | S0 = p.x;                               
            // 0x01687ADC: STR x21, [x19]             | nnInfo.node = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513413926752
            nnInfo.node = val_9;
            // 0x01687AE0: STR s0, [x19, #0x10]       | nnInfo.clampedPosition.x = p.x;          //  dest_result_addr=1152921513413926768
            nnInfo.clampedPosition.x = val_10;
            // 0x01687AE4: B #0x1687bd4               |  goto label_11;                         
            goto label_11;
            label_3:
            // 0x01687AE8: LDPSW x23, x21, [x8, #0x38] | X23 = this.arr[((long)(int)(boxi)) << 5][3] X21 = this.arr[((long)(int)(boxi)) << 5][4] //  | 
            BBTreeBox val_7 = val_8[((long)(int)(boxi)) << 5];
            val_9 = val_8[((long)(int)(boxi)) << 5];
            // 0x01687AEC: LDR x24, [x22, #0x10]      | X24 = this.arr; //P2                    
            // 0x01687AF0: CBNZ x24, #0x1687af8       | if (this.arr != null) goto label_12;    
            if(this.arr != null)
            {
                goto label_12;
            }
            // 0x01687AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130D, ????);     
            label_12:
            // 0x01687AF8: LDR w8, [x24, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687AFC: CMP w23, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x01687B00: B.LO #0x1687b10            | if (val_8[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_13;
            if(val_7 < this.arr.Length)
            {
                goto label_13;
            }
            // 0x01687B04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130D, ????);     
            // 0x01687B08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687B0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130D, ????);     
            label_13:
            // 0x01687B10: ADD x8, x24, x23, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]; //PARR1 
            // 0x01687B14: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] S1 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] //  | 
            BBTreeBox val_8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            val_16 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01687B18: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] S3 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] //  | 
            BBTreeBox val_9 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            val_17 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01687B1C: MOV v4.16b, v10.16b        | V4 = p.x;//m1                           
            // 0x01687B20: MOV v5.16b, v9.16b         | V5 = p.y;//m1                           
            // 0x01687B24: MOV v6.16b, v8.16b         | V6 = p.z;//m1                           
            // 0x01687B28: MOV v7.16b, v11.16b        | V7 = radius;//m1                        
            // 0x01687B2C: BL #0x1688028              | X0 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_YMin = val_16, m_Width = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_Height = val_17}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius);
            bool val_4 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_8, m_YMin = val_16, m_Width = val_9, m_Height = val_17}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius);
            // 0x01687B30: TBZ w0, #0, #0x1687b58     | if (val_4 == false) goto label_14;      
            if(val_4 == false)
            {
                goto label_14;
            }
            // 0x01687B34: MOV x0, x22                | X0 = 1152921513413890656 (0x100000020CF0D260);//ML01
            val_7 = this;
            // 0x01687B38: MOV w1, w23                | W1 = this.arr[((long)(int)(boxi)) << 5][3];//m1
            // 0x01687B3C: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01687B40: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            val_16 = p.y;
            // 0x01687B44: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01687B48: MOV v3.16b, v11.16b        | V3 = radius;//m1                        
            val_17 = radius;
            // 0x01687B4C: MOV x2, x20                | X2 = constraint;//m1                    
            // 0x01687B50: MOV x3, x19                | X3 = 1152921513413926752 (0x100000020CF15F60);//ML01
            // 0x01687B54: BL #0x1687904              |  R0 = label_19();                       
            label_14:
            // 0x01687B58: LDR x23, [x22, #0x10]      | X23 = this.arr; //P2                    
            val_8 = this.arr;
            // 0x01687B5C: CBNZ x23, #0x1687b64       | if (this.arr != null) goto label_16;    
            if(val_8 != null)
            {
                goto label_16;
            }
            // 0x01687B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_16:
            // 0x01687B64: LDR w8, [x23, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687B68: CMP w21, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][4], this.arr.Length)
            // 0x01687B6C: B.LO #0x1687b7c            | if (val_9 < this.arr.Length) goto label_17;
            if(val_9 < this.arr.Length)
            {
                goto label_17;
            }
            // 0x01687B70: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01687B74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687B78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_17:
            // 0x01687B7C: ADD x8, x23, x21, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5]; //PARR1 
            // 0x01687B80: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0] S1 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][0] //  | 
            BBTreeBox val_10 = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            BBTreeBox val_11 = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            // 0x01687B84: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][1] S3 = this.arr[(this.arr[((long)(int)(boxi)) << 5][4]) << 5][1] //  | 
            BBTreeBox val_12 = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            BBTreeBox val_13 = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5];
            // 0x01687B88: MOV v4.16b, v10.16b        | V4 = p.x;//m1                           
            // 0x01687B8C: MOV v5.16b, v9.16b         | V5 = p.y;//m1                           
            // 0x01687B90: MOV v6.16b, v8.16b         | V6 = p.z;//m1                           
            // 0x01687B94: MOV v7.16b, v11.16b        | V7 = radius;//m1                        
            // 0x01687B98: BL #0x1688028              | X0 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5], m_YMin = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5], m_Width = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5], m_Height = val_8[(this.arr[((long)(int)(boxi)) << 5][4]) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius);
            bool val_5 = Pathfinding.BBTree.RectIntersectsCircle(r:  new UnityEngine.Rect() {m_XMin = val_10, m_YMin = val_11, m_Width = val_12, m_Height = val_13}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, radius:  radius);
            // 0x01687B9C: TBZ w0, #0, #0x1687c8c     | if (val_5 == false) goto label_27;      
            if(val_5 == false)
            {
                goto label_27;
            }
            // 0x01687BA0: MOV x0, x22                | X0 = 1152921513413890656 (0x100000020CF0D260);//ML01
            // 0x01687BA4: MOV w1, w21                | W1 = this.arr[((long)(int)(boxi)) << 5][4];//m1
            // 0x01687BA8: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x01687BAC: MOV v1.16b, v9.16b         | V1 = p.y;//m1                           
            // 0x01687BB0: MOV v2.16b, v8.16b         | V2 = p.z;//m1                           
            // 0x01687BB4: MOV v3.16b, v11.16b        | V3 = radius;//m1                        
            // 0x01687BB8: MOV x2, x20                | X2 = constraint;//m1                    
            // 0x01687BBC: MOV x3, x19                | X3 = 1152921513413926752 (0x100000020CF15F60);//ML01
            // 0x01687BC0: BL #0x1687904              |  R0 = label_19();                       
            // 0x01687BC4: B #0x1687c8c               |  goto label_27;                         
            goto label_27;
            label_7:
            // 0x01687BC8: STR x21, [x19]             | nnInfo.node = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513413926752
            nnInfo.node = val_9;
            // 0x01687BCC: STR s12, [x19, #0x10]      | nnInfo.clampedPosition.x = p.x;          //  dest_result_addr=1152921513413926768
            nnInfo.clampedPosition.x = val_10;
            // 0x01687BD0: STR s12, [sp, #8]          | stack[1152921513413878472] = p.x;        //  dest_result_addr=1152921513413878472
            label_11:
            // 0x01687BD4: STR s11, [x19, #0x14]      | nnInfo.clampedPosition.y = p.y;          //  dest_result_addr=1152921513413926772
            nnInfo.clampedPosition.y = val_11;
            // 0x01687BD8: STR s13, [x19, #0x18]      | nnInfo.clampedPosition.z = p.z;          //  dest_result_addr=1152921513413926776
            nnInfo.clampedPosition.z = p.z;
            label_10:
            // 0x01687BDC: CBZ x20, #0x1687bf8        | if (constraint == null) goto label_21;  
            if(constraint == null)
            {
                goto label_21;
            }
            // 0x01687BE0: LDR x8, [x20]              | X8 = typeof(Pathfinding.NNConstraint);  
            // 0x01687BE4: MOV x0, x20                | X0 = constraint;//m1                    
            // 0x01687BE8: MOV x1, x21                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x01687BEC: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_168; //  | 
            // 0x01687BF0: BLR x9                     | X0 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160();
            // 0x01687BF4: TBZ w0, #0, #0x1687c8c     | if ((constraint & 0x1) == 0) goto label_27;
            if((constraint & 1) == 0)
            {
                goto label_27;
            }
            label_21:
            // 0x01687BF8: LDR x8, [x19, #8]          | X8 = nnInfo.constrainedNode;            
            // 0x01687BFC: CBZ x8, #0x1687c7c         | if (nnInfo.constrainedNode == null) goto label_23;
            if(nnInfo.constrainedNode == null)
            {
                goto label_23;
            }
            // 0x01687C00: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x01687C04: MOV v12.16b, v11.16b       | V12 = p.y;//m1                          
            val_10 = val_11;
            // 0x01687C08: LDP s11, s14, [x19, #0x1c] | S11 = nnInfo.constClampedPosition.x; S14 = nnInfo.constClampedPosition.y; //  | 
            val_15 = nnInfo.constClampedPosition.y;
            // 0x01687C0C: LDR s15, [x19, #0x24]      | S15 = nnInfo.constClampedPosition.z;    
            // 0x01687C10: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01687C14: TBZ w8, #0, #0x1687c24     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x01687C18: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01687C1C: CBNZ w8, #0x1687c24        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x01687C20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_25:
            // 0x01687C24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687C2C: MOV v0.16b, v11.16b        | V0 = nnInfo.constClampedPosition.x;//m1 
            // 0x01687C30: MOV v1.16b, v14.16b        | V1 = nnInfo.constClampedPosition.y;//m1 
            // 0x01687C34: MOV v2.16b, v15.16b        | V2 = nnInfo.constClampedPosition.z;//m1 
            // 0x01687C38: MOV v3.16b, v10.16b        | V3 = p.x;//m1                           
            // 0x01687C3C: MOV v4.16b, v9.16b         | V4 = p.y;//m1                           
            // 0x01687C40: MOV v5.16b, v8.16b         | V5 = p.z;//m1                           
            // 0x01687C44: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = nnInfo.constClampedPosition.x, y = val_15, z = nnInfo.constClampedPosition.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = nnInfo.constClampedPosition.x, y = val_15, z = nnInfo.constClampedPosition.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x01687C48: ADD x0, sp, #0x10          | X0 = (1152921513413878464 + 16) = 1152921513413878480 (0x100000020CF0A2D0);
            // 0x01687C4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687C50: STP s0, s1, [sp, #0x10]    | stack[1152921513413878480] = val_6.x;  stack[1152921513413878484] = val_6.y;  //  dest_result_addr=1152921513413878480 |  dest_result_addr=1152921513413878484
            // 0x01687C54: STR s2, [sp, #0x18]        | stack[1152921513413878488] = val_6.z;    //  dest_result_addr=1152921513413878488
            // 0x01687C58: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x01687C5C: LDR s1, [sp, #0xc]         | S1 = val_2.x;                           
            // 0x01687C60: FCMP s1, s0                | STATE = COMPARE(val_2.x, val_6.x)       
            // 0x01687C64: B.PL #0x1687c8c            | if (val_2.x >= 0) goto label_27;        
            if(val_2.x >= 0)
            {
                goto label_27;
            }
            // 0x01687C68: LDR s0, [sp, #8]           | S0 = p.x;                               
            // 0x01687C6C: STR x21, [x19, #8]         | nnInfo.constrainedNode = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513413926760
            nnInfo.constrainedNode = val_9;
            // 0x01687C70: STP s0, s12, [x19, #0x1c]  | nnInfo.constClampedPosition.x = p.x;  nnInfo.constClampedPosition.y = p.y;  //  dest_result_addr=1152921513413926780 |  dest_result_addr=1152921513413926784
            nnInfo.constClampedPosition.x = val_10;
            nnInfo.constClampedPosition.y = val_10;
            // 0x01687C74: STR s13, [x19, #0x24]      | nnInfo.constClampedPosition.z = p.z;     //  dest_result_addr=1152921513413926788
            nnInfo.constClampedPosition.z = p.z;
            // 0x01687C78: B #0x1687c8c               |  goto label_27;                         
            goto label_27;
            label_23:
            // 0x01687C7C: LDR s0, [sp, #8]           | S0 = p.x;                               
            // 0x01687C80: STR x21, [x19, #8]         | nnInfo.constrainedNode = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513413926760
            nnInfo.constrainedNode = val_9;
            // 0x01687C84: STP s0, s11, [x19, #0x1c]  | nnInfo.constClampedPosition.x = p.x;  nnInfo.constClampedPosition.y = p.y;  //  dest_result_addr=1152921513413926780 |  dest_result_addr=1152921513413926784
            nnInfo.constClampedPosition.x = val_10;
            nnInfo.constClampedPosition.y = val_11;
            // 0x01687C88: STR s13, [x19, #0x24]      | nnInfo.constClampedPosition.z = p.z;     //  dest_result_addr=1152921513413926788
            nnInfo.constClampedPosition.z = p.z;
            label_27:
            // 0x01687C8C: SUB sp, x29, #0x70         | SP = (1152921513413878640 - 112) = 1152921513413878528 (0x100000020CF0A300);
            // 0x01687C90: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x01687C94: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x01687C98: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x01687C9C: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x01687CA0: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01687CA4: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01687CA8: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01687CAC: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
            // 0x01687CB0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01687538 (23622968), len: 756  VirtAddr: 0x01687538 RVA: 0x01687538 token: 100683178 methodIndex: 49900 delegateWrapperIndex: 0 methodInvoker: 0
        private void SearchBox(int boxi, UnityEngine.Vector3 p, Pathfinding.NNConstraint constraint, ref Pathfinding.NNInfo nnInfo)
        {
            //
            // Disasemble & Code
            //  | 
            int val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            BBTreeBox val_12;
            //  | 
            BBTreeBox val_13;
            //  | 
            var val_14;
            //  | 
            Pathfinding.GraphNode val_15;
            label_7:
            // 0x01687538: STP d11, d10, [sp, #-0x80]! | stack[1152921513414244560] = ???;  stack[1152921513414244568] = ???;  //  dest_result_addr=1152921513414244560 |  dest_result_addr=1152921513414244568
            // 0x0168753C: STP d9, d8, [sp, #0x10]    | stack[1152921513414244576] = ???;  stack[1152921513414244584] = ???;  //  dest_result_addr=1152921513414244576 |  dest_result_addr=1152921513414244584
            // 0x01687540: STP x28, x27, [sp, #0x20]  | stack[1152921513414244592] = ???;  stack[1152921513414244600] = ???;  //  dest_result_addr=1152921513414244592 |  dest_result_addr=1152921513414244600
            // 0x01687544: STP x26, x25, [sp, #0x30]  | stack[1152921513414244608] = ???;  stack[1152921513414244616] = ???;  //  dest_result_addr=1152921513414244608 |  dest_result_addr=1152921513414244616
            // 0x01687548: STP x24, x23, [sp, #0x40]  | stack[1152921513414244624] = ???;  stack[1152921513414244632] = ???;  //  dest_result_addr=1152921513414244624 |  dest_result_addr=1152921513414244632
            // 0x0168754C: STP x22, x21, [sp, #0x50]  | stack[1152921513414244640] = ???;  stack[1152921513414244648] = ???;  //  dest_result_addr=1152921513414244640 |  dest_result_addr=1152921513414244648
            // 0x01687550: STP x20, x19, [sp, #0x60]  | stack[1152921513414244656] = ???;  stack[1152921513414244664] = ???;  //  dest_result_addr=1152921513414244656 |  dest_result_addr=1152921513414244664
            // 0x01687554: STP x29, x30, [sp, #0x70]  | stack[1152921513414244672] = ???;  stack[1152921513414244680] = ???;  //  dest_result_addr=1152921513414244672 |  dest_result_addr=1152921513414244680
            // 0x01687558: ADD x29, sp, #0x70         | X29 = (1152921513414244560 + 112) = 1152921513414244672 (0x100000020CF63940);
            // 0x0168755C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x01687560: LDR x8, [x8, #0x338]       | X8 = 0x2B8F128;                         
            // 0x01687564: MOV x19, x3                | X19 = 1152921513414292784 (0x100000020CF6F530);//ML01
            // 0x01687568: MOV x20, x2                | X20 = constraint;//m1                   
            // 0x0168756C: MOV v9.16b, v2.16b         | V9 = p.z;//m1                           
            // 0x01687570: LDR w22, [x8]              | W22 = 0x130C;                           
            // 0x01687574: MOV v8.16b, v1.16b         | V8 = p.y;//m1                           
            // 0x01687578: MOV v10.16b, v0.16b        | V10 = p.x;//m1                          
            // 0x0168757C: MOV w24, w1                | W24 = boxi;//m1                         
            // 0x01687580: MOV x23, x0                | X23 = 1152921513414256688 (0x100000020CF66830);//ML01
            val_9 = this;
            // 0x01687584: ADRP x25, #0x3738000       | X25 = 57901056 (0x3738000);             
            // 0x01687588: ORR w26, wzr, #1           | W26 = 1(0x1);                           
            label_10:
            // 0x0168758C: LDRB w8, [x25, #0xf6]      | W8 = (bool)static_value_037380F6;       
            // 0x01687590: TBNZ w8, #0, #0x16875a0    | if (static_value_037380F6 == true) goto label_0;
            // 0x01687594: MOV w0, w22                | W0 = 4876 (0x130C);//ML01               
            val_10 = 4876;
            // 0x01687598: BL #0x2782188              | X0 = sub_2782188( ?? 0x130C, ????);     
            // 0x0168759C: STRB w26, [x25, #0xf6]     | static_value_037380F6 = true;            //  dest_result_addr=57901302
            label_0:
            // 0x016875A0: LDR x21, [x23, #0x10]      | X21 = this.arr; //P2                    
            // 0x016875A4: CBNZ x21, #0x16875ac       | if (this.arr != null) goto label_1;     
            if(this.arr != null)
            {
                goto label_1;
            }
            // 0x016875A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130C, ????);     
            label_1:
            // 0x016875AC: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016875B0: SXTW x27, w24              | X27 = (long)(int)(boxi);                
            val_11 = (long)boxi;
            // 0x016875B4: CMP w8, w24                | STATE = COMPARE(this.arr.Length, boxi)  
            // 0x016875B8: B.HI #0x16875c8            | if (this.arr.Length > boxi) goto label_2;
            if(this.arr.Length > boxi)
            {
                goto label_2;
            }
            // 0x016875BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130C, ????);     
            // 0x016875C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016875C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130C, ????);     
            label_2:
            // 0x016875C8: ADD x8, x21, x27, lsl #5   | X8 = this.arr[((long)(int)(boxi)) << 5]; //PARR1 
            // 0x016875CC: LDR x21, [x8, #0x30]       | X21 = this.arr[((long)(int)(boxi)) << 5][2]
            val_12 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016875D0: LDR w24, [x8, #0x3c]       | W24 = this.arr[((long)(int)(boxi)) << 5][3]
            BBTreeBox val_8 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016875D4: CBNZ x21, #0x1687690       | if (this.arr[((long)(int)(boxi)) << 5][2] != 0) goto label_3;
            if(val_12 != 0)
            {
                goto label_3;
            }
            // 0x016875D8: LDRSW x21, [x8, #0x38]     | X21 = this.arr[((long)(int)(boxi)) << 5][3]
            BBTreeBox val_9 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016875DC: LDR x27, [x23, #0x10]      | X27 = this.arr; //P2                    
            // 0x016875E0: CBNZ x27, #0x16875e8       | if (this.arr != null) goto label_4;     
            if(this.arr != null)
            {
                goto label_4;
            }
            // 0x016875E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130C, ????);     
            label_4:
            // 0x016875E8: LDR w8, [x27, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016875EC: CMP w21, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x016875F0: B.LO #0x1687600            | if (this.arr[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_5;
            if(val_9 < this.arr.Length)
            {
                goto label_5;
            }
            // 0x016875F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130C, ????);     
            // 0x016875F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016875FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130C, ????);     
            label_5:
            // 0x01687600: ADD x8, x27, x21, lsl #5   | X8 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]; //PARR1 
            // 0x01687604: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] S1 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][0] //  | 
            BBTreeBox val_10 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            val_13 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x01687608: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] S3 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5][1] //  | 
            BBTreeBox val_11 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            BBTreeBox val_12 = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5];
            // 0x0168760C: MOV v4.16b, v10.16b        | V4 = p.x;//m1                           
            // 0x01687610: MOV v5.16b, v8.16b         | V5 = p.y;//m1                           
            // 0x01687614: MOV v6.16b, v9.16b         | V6 = p.z;//m1                           
            // 0x01687618: BL #0x1688770              | X0 = Pathfinding.BBTree.RectContains(r:  new UnityEngine.Rect() {m_XMin = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_YMin = val_13, m_Width = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5], m_Height = this.arr[(this.arr[((long)(int)(boxi)) << 5][3]) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            bool val_1 = Pathfinding.BBTree.RectContains(r:  new UnityEngine.Rect() {m_XMin = val_10, m_YMin = val_13, m_Width = val_11, m_Height = val_12}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x0168761C: TBZ w0, #0, #0x1687640     | if (val_1 == false) goto label_6;       
            if(val_1 == false)
            {
                goto label_6;
            }
            // 0x01687620: MOV x0, x23                | X0 = 1152921513414256688 (0x100000020CF66830);//ML01
            val_10 = val_9;
            // 0x01687624: MOV w1, w21                | W1 = this.arr[((long)(int)(boxi)) << 5][3];//m1
            // 0x01687628: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x0168762C: MOV v1.16b, v8.16b         | V1 = p.y;//m1                           
            val_13 = p.y;
            // 0x01687630: MOV v2.16b, v9.16b         | V2 = p.z;//m1                           
            // 0x01687634: MOV x2, x20                | X2 = constraint;//m1                    
            // 0x01687638: MOV x3, x19                | X3 = 1152921513414292784 (0x100000020CF6F530);//ML01
            // 0x0168763C: BL #0x1687538              |  R0 = label_7();                        
            label_6:
            // 0x01687640: LDR x21, [x23, #0x10]      | X21 = this.arr; //P2                    
            val_12 = this.arr;
            // 0x01687644: CBNZ x21, #0x168764c       | if (this.arr != null) goto label_8;     
            if(val_12 != null)
            {
                goto label_8;
            }
            // 0x01687648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_8:
            // 0x0168764C: LDR w8, [x21, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x01687650: SXTW x27, w24              | X27 = (long)(int)(this.arr[((long)(int)(boxi)) << 5][3]);
            val_11 = (long)val_8;
            // 0x01687654: CMP w24, w8                | STATE = COMPARE(this.arr[((long)(int)(boxi)) << 5][3], this.arr.Length)
            // 0x01687658: B.LO #0x1687668            | if (this.arr[((long)(int)(boxi)) << 5] < this.arr.Length) goto label_9;
            if(val_8 < this.arr.Length)
            {
                goto label_9;
            }
            // 0x0168765C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01687660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687664: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_9:
            // 0x01687668: ADD x8, x21, x27, lsl #5   | X8 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5]; //PARR1 
            // 0x0168766C: LDP s0, s1, [x8, #0x20]    | S0 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][0] S1 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][0] //  | 
            BBTreeBox val_13 = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            BBTreeBox val_14 = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            // 0x01687670: LDP s2, s3, [x8, #0x28]    | S2 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][1] S3 = this.arr[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5][1] //  | 
            BBTreeBox val_15 = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            BBTreeBox val_16 = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5];
            // 0x01687674: MOV v4.16b, v10.16b        | V4 = p.x;//m1                           
            // 0x01687678: MOV v5.16b, v8.16b         | V5 = p.y;//m1                           
            // 0x0168767C: MOV v6.16b, v9.16b         | V6 = p.z;//m1                           
            // 0x01687680: BL #0x1688770              | X0 = Pathfinding.BBTree.RectContains(r:  new UnityEngine.Rect() {m_XMin = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5], m_YMin = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5], m_Width = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5], m_Height = val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5]}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            bool val_2 = Pathfinding.BBTree.RectContains(r:  new UnityEngine.Rect() {m_XMin = val_13, m_YMin = val_14, m_Width = val_15, m_Height = val_16}, p:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x01687684: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5] = val_2;
            // 0x01687688: TBNZ w8, #0, #0x168758c    | if ((val_2 & 1) == true) goto label_10; 
            if((val_12[((long)(int)(this.arr[((long)(int)(boxi)) << 5][3])) << 5]) == true)
            {
                goto label_10;
            }
            // 0x0168768C: B #0x1687804               |  goto label_28;                         
            goto label_28;
            label_3:
            // 0x01687690: ADRP x22, #0x3660000       | X22 = 57016320 (0x3660000);             
            // 0x01687694: LDR x22, [x22, #0x540]     | X22 = 1152921504839380992;              
            // 0x01687698: LDR x0, [x22]              | X0 = typeof(Pathfinding.Int3);          
            // 0x0168769C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x016876A0: TBZ w8, #0, #0x16876b0     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x016876A4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x016876A8: CBNZ w8, #0x16876b0        | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x016876AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_13:
            // 0x016876B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016876B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016876B8: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x016876BC: MOV v1.16b, v8.16b         | V1 = p.y;//m1                           
            // 0x016876C0: MOV v2.16b, v9.16b         | V2 = p.z;//m1                           
            // 0x016876C4: BL #0x1548f50              | X0 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            Pathfinding.Int3 val_3 = Pathfinding.Int3.op_Explicit(ob:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x016876C8: LDR x8, [x21]              | X8 = this.arr[((long)(int)(boxi)) << 5][2].rect;
            // 0x016876CC: MOV x4, x0                 | X4 = val_3.x;//m1                       
            // 0x016876D0: AND x2, x1, #0xffffffff    | X2 = (val_3.z & 4294967295);            
            val_14 = val_3.z & 4294967295;
            // 0x016876D4: MOV x0, x21                | X0 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x016876D8: LDR x9, [x8, #0x270]       |  //  not_find_field!1:624
            // 0x016876DC: LDR x3, [x8, #0x278]       |  //  not_find_field!1:632
            // 0x016876E0: MOV x1, x4                 | X1 = val_3.x;//m1                       
            // 0x016876E4: BLR x9                     | X0 = mem[this.arr[((long)(int)(boxi)) << 5][2].rect + 624]();
            // 0x016876E8: TBZ w0, #0, #0x1687804     | if ((this.arr[((long)(int)(boxi)) << 5][2] & 0x1) == 0) goto label_28;
            if((val_12 & 1) == 0)
            {
                goto label_28;
            }
            // 0x016876EC: LDR x8, [x19]              | X8 = nnInfo.node;                       
            // 0x016876F0: CBZ x8, #0x1687784         | if (nnInfo.node == null) goto label_15; 
            if(nnInfo.node == null)
            {
                goto label_15;
            }
            // 0x016876F4: LDR x0, [x22]              | X0 = typeof(Pathfinding.Int3);          
            // 0x016876F8: LDR x23, [x21, #0x20]      |  //  not_find_field!1:32
            val_9 = mem[this.arr[((long)(int)(boxi)) << 5][2] + 32];
            // 0x016876FC: LDR w22, [x21, #0x28]      |  //  not_find_field!1:40
            // 0x01687700: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Int3.__il2cppRuntimeField_10A;
            // 0x01687704: TBZ w8, #0, #0x1687714     | if (Pathfinding.Int3.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x01687708: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Int3.__il2cppRuntimeField_cctor_finished;
            // 0x0168770C: CBNZ w8, #0x1687714        | if (Pathfinding.Int3.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x01687710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Int3), ????);
            label_17:
            // 0x01687714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687718: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0168771C: MOV x1, x23                | X1 = mem[this.arr[((long)(int)(boxi)) << 5][2] + 32];//m1
            // 0x01687720: MOV x2, x22                | X2 = mem[this.arr[((long)(int)(boxi)) << 5][2] + 40];//m1
            // 0x01687724: BL #0x15490f0              | X0 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = val_9});
            UnityEngine.Vector3 val_4 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = val_9});
            // 0x01687728: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x0168772C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
            // 0x01687730: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
            // 0x01687734: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x01687738: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x0168773C: TBZ w8, #0, #0x168774c     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x01687740: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x01687744: CBNZ w8, #0x168774c        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x01687748: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            label_19:
            // 0x0168774C: LDR x22, [x19]             | X22 = nnInfo.node;                      
            // 0x01687750: FSUB s0, s9, s8            | S0 = (val_4.y - p.y);                   
            float val_5 = val_4.y - p.y;
            // 0x01687754: FABS s9, s0                | S9 = System.Math.Abs((val_4.y - p.y));  
            float val_17 = System.Math.Abs(val_5);
            // 0x01687758: CBNZ x22, #0x1687760       | if (nnInfo.node != null) goto label_20; 
            if(nnInfo.node != null)
            {
                goto label_20;
            }
            // 0x0168775C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
            label_20:
            // 0x01687760: LDR x1, [x22, #0x20]       | X1 = nnInfo.node.position; //P2         
            // 0x01687764: LDR w2, [x22, #0x28]       | 
            // 0x01687768: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168776C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01687770: BL #0x15490f0              | X0 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = nnInfo.node.position});
            UnityEngine.Vector3 val_6 = Pathfinding.Int3.op_Explicit(ob:  new Pathfinding.Int3() {z = nnInfo.node.position});
            // 0x01687774: FSUB s0, s1, s8            | S0 = (val_6.y - p.y);                   
            float val_7 = val_6.y - p.y;
            // 0x01687778: FABS s0, s0                | S0 = System.Math.Abs((val_6.y - p.y));  
            float val_18 = System.Math.Abs(val_7);
            // 0x0168777C: FCMP s9, s0                | STATE = COMPARE((val_4.y - p.y), (val_6.y - p.y))
            // 0x01687780: B.PL #0x1687788            | if (System.Math.Abs(float val_5 = val_4.y - p.y) >= 0) goto label_21;
            if(val_17 >= 0)
            {
                goto label_21;
            }
            label_15:
            // 0x01687784: STR x21, [x19]             | nnInfo.node = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513414292784
            nnInfo.node = val_12;
            label_21:
            // 0x01687788: CBNZ x20, #0x1687790       | if (constraint != null) goto label_22;  
            if(constraint != null)
            {
                goto label_22;
            }
            // 0x0168778C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_22:
            // 0x01687790: LDR x8, [x20]              | X8 = typeof(Pathfinding.NNConstraint);  
            // 0x01687794: MOV x0, x20                | X0 = constraint;//m1                    
            // 0x01687798: MOV x1, x21                | X1 = this.arr[((long)(int)(boxi)) << 5][2];//m1
            // 0x0168779C: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_168; //  | 
            // 0x016877A0: BLR x9                     | X0 = typeof(Pathfinding.NNConstraint).__il2cppRuntimeField_160();
            // 0x016877A4: TBZ w0, #0, #0x1687804     | if ((constraint & 0x1) == 0) goto label_28;
            if((constraint & 1) == 0)
            {
                goto label_28;
            }
            // 0x016877A8: LDR x8, [x19, #8]          | X8 = nnInfo.constrainedNode;            
            val_15 = nnInfo.constrainedNode;
            // 0x016877AC: CBZ x8, #0x1687800         | if (nnInfo.constrainedNode == null) goto label_24;
            if(nnInfo.constrainedNode == null)
            {
                goto label_24;
            }
            // 0x016877B0: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x016877B4: LDR x9, [x9, #0x3b0]       | X9 = 1152921504695345152;               
            // 0x016877B8: LDR s0, [x21, #0x24]       |  //  not_find_field!1:36
            var val_19 = mem[this.arr[((long)(int)(boxi)) << 5][2] + 36];
            // 0x016877BC: LDR x0, [x9]               | X0 = typeof(UnityEngine.Mathf);         
            // 0x016877C0: SCVTF s9, s0               | S9 = (float)(mem[this.arr[((long)(int)(boxi)) << 5][2] + 36]);
            // 0x016877C4: LDRB w9, [x0, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
            // 0x016877C8: TBZ w9, #0, #0x16877e0     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x016877CC: LDR w9, [x0, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
            // 0x016877D0: CBNZ w9, #0x16877e0        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x016877D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
            // 0x016877D8: LDR x8, [x19, #8]          | X8 = nnInfo.constrainedNode;            
            val_15 = nnInfo.constrainedNode;
            // 0x016877DC: CBZ x8, #0x1687828         | if (nnInfo.constrainedNode == null) goto label_27;
            if(nnInfo.constrainedNode == null)
            {
                goto label_27;
            }
            label_26:
            // 0x016877E0: LDR s1, [x8, #0x24]        | 
            // 0x016877E4: FSUB s0, s9, s8            | S0 = (mem[this.arr[((long)(int)(boxi)) << 5][2] + 36] - p.y);
            val_19 = (float)val_19 - p.y;
            // 0x016877E8: FABS s0, s0                | S0 = System.Math.Abs((mem[this.arr[((long)(int)(boxi)) << 5][2] + 36] - p.y));
            float val_20 = System.Math.Abs(val_19);
            // 0x016877EC: SCVTF s1, s1               | S1 = (float)(val_6.y);                  
            float val_21 = (float)val_6.y;
            // 0x016877F0: FSUB s1, s1, s8            | S1 = (val_6.y - p.y);                   
            val_21 = val_21 - p.y;
            // 0x016877F4: FABS s1, s1                | S1 = System.Math.Abs((val_6.y - p.y));  
            float val_22 = System.Math.Abs(val_21);
            // 0x016877F8: FCMP s0, s1                | STATE = COMPARE((mem[this.arr[((long)(int)(boxi)) << 5][2] + 36] - p.y), (val_6.y - p.y))
            // 0x016877FC: B.PL #0x1687804            | if (System.Math.Abs(mem[this.arr[((long)(int)(boxi)) << 5][2] + 36] = ((float)mem[this.arr[((long)(int)(boxi)) << 5][2] + 36]) - p.y) >= 0) goto label_28;
            if(val_20 >= 0)
            {
                goto label_28;
            }
            label_24:
            // 0x01687800: STR x21, [x19, #8]         | nnInfo.constrainedNode = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513414292792
            nnInfo.constrainedNode = val_12;
            label_28:
            // 0x01687804: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
            // 0x01687808: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
            // 0x0168780C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
            // 0x01687810: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
            // 0x01687814: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
            // 0x01687818: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
            // 0x0168781C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01687820: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
            // 0x01687824: RET                        |  return;                                
            return;
            label_27:
            // 0x01687828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x016887F4 (23627764), len: 72  VirtAddr: 0x016887F4 RVA: 0x016887F4 token: 100683179 methodIndex: 49901 delegateWrapperIndex: 0 methodInvoker: 0
        public void OnDrawGizmos()
        {
            //
            // Disasemble & Code
            // 0x016887F4: STP x29, x30, [sp, #-0x10]! | stack[1152921513414483680] = ???;  stack[1152921513414483688] = ???;  //  dest_result_addr=1152921513414483680 |  dest_result_addr=1152921513414483688
            // 0x016887F8: MOV x29, sp                | X29 = 1152921513414483680 (0x100000020CF9DEE0);//ML01
            // 0x016887FC: STP xzr, xzr, [sp, #-0x10]! | stack[1152921513414483664] = 0x0;  stack[1152921513414483672] = 0x0;  //  dest_result_addr=1152921513414483664 |  dest_result_addr=1152921513414483672
            // 0x01688800: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x01688804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688808: FMOV s3, #0.50000000       | S3 = 0.5;                               
            // 0x0168880C: MOV x0, sp                 | X0 = 1152921513414483664 (0x100000020CF9DED0);//ML01
            // 0x01688810: MOV v1.16b, v0.16b         | V1 = 1;//m1                             
            // 0x01688814: MOV v2.16b, v0.16b         | V2 = 1;//m1                             
            // 0x01688818: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
            // 0x0168881C: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
            // 0x01688820: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
            // 0x01688824: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168882C: BL #0x1a654c8              | UnityEngine.Gizmos.set_color(value:  new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f});
            UnityEngine.Gizmos.color = new UnityEngine.Color() {r = 0f, g = 0f, b = 0f, a = 0f};
            // 0x01688830: MOV sp, x29                | SP = 1152921513414483680 (0x100000020CF9DEE0);//ML01
            // 0x01688834: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x01688838: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168883C (23627836), len: 684  VirtAddr: 0x0168883C RVA: 0x0168883C token: 100683180 methodIndex: 49902 delegateWrapperIndex: 0 methodInvoker: 0
        private void OnDrawGizmos(int boxi, int depth)
        {
            //
            // Disasemble & Code
            label_7:
            // 0x0168883C: STP d13, d12, [sp, #-0x70]! | stack[1152921513414632448] = ???;  stack[1152921513414632456] = ???;  //  dest_result_addr=1152921513414632448 |  dest_result_addr=1152921513414632456
            // 0x01688840: STP d11, d10, [sp, #0x10]  | stack[1152921513414632464] = ???;  stack[1152921513414632472] = ???;  //  dest_result_addr=1152921513414632464 |  dest_result_addr=1152921513414632472
            // 0x01688844: STP d9, d8, [sp, #0x20]    | stack[1152921513414632480] = ???;  stack[1152921513414632488] = ???;  //  dest_result_addr=1152921513414632480 |  dest_result_addr=1152921513414632488
            // 0x01688848: STP x24, x23, [sp, #0x30]  | stack[1152921513414632496] = ???;  stack[1152921513414632504] = ???;  //  dest_result_addr=1152921513414632496 |  dest_result_addr=1152921513414632504
            // 0x0168884C: STP x22, x21, [sp, #0x40]  | stack[1152921513414632512] = ???;  stack[1152921513414632520] = ???;  //  dest_result_addr=1152921513414632512 |  dest_result_addr=1152921513414632520
            // 0x01688850: STP x20, x19, [sp, #0x50]  | stack[1152921513414632528] = ???;  stack[1152921513414632536] = ???;  //  dest_result_addr=1152921513414632528 |  dest_result_addr=1152921513414632536
            // 0x01688854: STP x29, x30, [sp, #0x60]  | stack[1152921513414632544] = ???;  stack[1152921513414632552] = ???;  //  dest_result_addr=1152921513414632544 |  dest_result_addr=1152921513414632552
            // 0x01688858: ADD x29, sp, #0x60         | X29 = (1152921513414632448 + 96) = 1152921513414632544 (0x100000020CFC2460);
            // 0x0168885C: SUB sp, sp, #0x40          | SP = (1152921513414632448 - 64) = 1152921513414632384 (0x100000020CFC23C0);
            // 0x01688860: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x01688864: LDRB w8, [x22, #0xf7]      | W8 = (bool)static_value_037380F7;       
            // 0x01688868: MOV w20, w2                | W20 = depth;//m1                        
            int val_11 = depth;
            // 0x0168886C: MOV w21, w1                | W21 = boxi;//m1                         
            // 0x01688870: MOV x19, x0                | X19 = 1152921513414644560 (0x100000020CFC5350);//ML01
            // 0x01688874: TBNZ w8, #0, #0x1688890    | if (static_value_037380F7 == true) goto label_0;
            // 0x01688878: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x0168887C: LDR x8, [x8, #0xaf8]       | X8 = 0x2B8F124;                         
            // 0x01688880: LDR w0, [x8]               | W0 = 0x130B;                            
            // 0x01688884: BL #0x2782188              | X0 = sub_2782188( ?? 0x130B, ????);     
            // 0x01688888: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168888C: STRB w8, [x22, #0xf7]      | static_value_037380F7 = true;            //  dest_result_addr=57901303
            label_0:
            // 0x01688890: STP xzr, xzr, [sp, #0x30]  | stack[1152921513414632432] = 0x0;  stack[1152921513414632440] = 0x0;  //  dest_result_addr=1152921513414632432 |  dest_result_addr=1152921513414632440
            // 0x01688894: STP xzr, xzr, [sp, #0x20]  | stack[1152921513414632416] = 0x0;  stack[1152921513414632424] = 0x0;  //  dest_result_addr=1152921513414632416 |  dest_result_addr=1152921513414632424
            // 0x01688898: STR wzr, [sp, #0x18]       | stack[1152921513414632408] = 0x0;        //  dest_result_addr=1152921513414632408
            // 0x0168889C: STR xzr, [sp, #0x10]       | stack[1152921513414632400] = 0x0;        //  dest_result_addr=1152921513414632400
            // 0x016888A0: STR wzr, [sp, #8]          | stack[1152921513414632392] = 0x0;        //  dest_result_addr=1152921513414632392
            // 0x016888A4: STR xzr, [sp]              | stack[1152921513414632384] = 0x0;        //  dest_result_addr=1152921513414632384
            // 0x016888A8: LDR x22, [x19, #0x10]      | X22 = this.arr; //P2                    
            // 0x016888AC: CBNZ x22, #0x16888b4       | if (this.arr != null) goto label_1;     
            if(this.arr != null)
            {
                goto label_1;
            }
            // 0x016888B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x130B, ????);     
            label_1:
            // 0x016888B4: LDR w8, [x22, #0x18]       | W8 = this.arr.Length; //P2              
            // 0x016888B8: SXTW x23, w21              | X23 = (long)(int)(boxi);                
            // 0x016888BC: CMP w8, w21                | STATE = COMPARE(this.arr.Length, boxi)  
            // 0x016888C0: B.HI #0x16888d0            | if (this.arr.Length > boxi) goto label_2;
            if(this.arr.Length > boxi)
            {
                goto label_2;
            }
            // 0x016888C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x130B, ????);     
            // 0x016888C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016888CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x130B, ????);     
            label_2:
            // 0x016888D0: ADD x8, x22, x23, lsl #5   | X8 = this.arr[((long)(int)(boxi)) << 5]; //PARR1 
            // 0x016888D4: LDR q0, [x8, #0x30]        | Q0 = this.arr[((long)(int)(boxi)) << 5][2]
            BBTreeBox val_7 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016888D8: ADD x0, sp, #0x20          | X0 = (1152921513414632384 + 32) = 1152921513414632416 (0x100000020CFC23E0);
            // 0x016888DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016888E0: STR q0, [sp, #0x30]        | stack[1152921513414632432] = this.arr[((long)(int)(boxi)) << 5][2];  //  dest_result_addr=1152921513414632432
            // 0x016888E4: LDR q0, [x8, #0x20]        | Q0 = this.arr[((long)(int)(boxi)) << 5][0]
            BBTreeBox val_8 = this.arr[((long)(int)(boxi)) << 5];
            // 0x016888E8: STR q0, [sp, #0x20]        | stack[1152921513414632416] = this.arr[((long)(int)(boxi)) << 5][0];  //  dest_result_addr=1152921513414632416
            // 0x016888EC: BL #0x1b81814              | X0 = this.arr[((long)(int)(boxi)) << 5][0].get_xMin();
            float val_1 = val_8.xMin;
            // 0x016888F0: ADD x0, sp, #0x20          | X0 = (1152921513414632384 + 32) = 1152921513414632416 (0x100000020CFC23E0);
            // 0x016888F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016888F8: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
            // 0x016888FC: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x01688900: FMOV s9, wzr               | S9 = 0f;                                
            // 0x01688904: MOV v2.16b, v0.16b         | V2 = val_1;//m1                         
            // 0x01688908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168890C: ADD x0, sp, #0x10          | X0 = (1152921513414632384 + 16) = 1152921513414632400 (0x100000020CFC23D0);
            // 0x01688910: MOV v0.16b, v8.16b         | V0 = val_1;//m1                         
            // 0x01688914: MOV v1.16b, v9.16b         | V1 = 0;//m1                             
            // 0x01688918: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x0168891C: ADD x0, sp, #0x20          | X0 = (1152921513414632384 + 32) = 1152921513414632416 (0x100000020CFC23E0);
            // 0x01688920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688924: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x01688928: ADD x0, sp, #0x20          | X0 = (1152921513414632384 + 32) = 1152921513414632416 (0x100000020CFC23E0);
            // 0x0168892C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688930: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
            // 0x01688934: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x01688938: MOV v2.16b, v0.16b         | V2 = val_1;//m1                         
            // 0x0168893C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688940: MOV x0, sp                 | X0 = 1152921513414632384 (0x100000020CFC23C0);//ML01
            // 0x01688944: MOV v0.16b, v8.16b         | V0 = val_1;//m1                         
            // 0x01688948: MOV v1.16b, v9.16b         | V1 = 0;//m1                             
            // 0x0168894C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
            // 0x01688950: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x01688954: LDP s8, s9, [sp, #0x10]    | S8 = 0; S9 = 0;                          //  | 
            // 0x01688958: LDR s10, [sp, #0x18]       | S10 = 0;                                
            // 0x0168895C: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01688960: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x01688964: LDP s13, s12, [sp]         | S13 = 0; S12 = 0;                        //  | 
            // 0x01688968: LDR s11, [sp, #8]          | S11 = 0;                                
            // 0x0168896C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01688970: TBZ w8, #0, #0x1688980     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01688974: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01688978: CBNZ w8, #0x1688980        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0168897C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_4:
            // 0x01688980: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688988: MOV v0.16b, v8.16b         | V0 = 0 (0x0);//ML01                     
            // 0x0168898C: MOV v1.16b, v9.16b         | V1 = 0 (0x0);//ML01                     
            // 0x01688990: MOV v2.16b, v10.16b        | V2 = 0 (0x0);//ML01                     
            // 0x01688994: MOV v3.16b, v13.16b        | V3 = 0 (0x0);//ML01                     
            // 0x01688998: MOV v4.16b, v12.16b        | V4 = 0 (0x0);//ML01                     
            // 0x0168899C: MOV v5.16b, v11.16b        | V5 = 0 (0x0);//ML01                     
            // 0x016889A0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
            // 0x016889A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016889A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016889AC: FMOV s3, #0.50000000       | S3 = 0.5;                               
            // 0x016889B0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, d:  0.5f);
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, d:  0.5f);
            // 0x016889B4: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
            // 0x016889B8: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
            float val_10 = val_3.y;
            // 0x016889BC: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
            // 0x016889C0: LDR s3, [sp, #8]           | S3 = 0;                                 
            // 0x016889C4: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
            // 0x016889C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016889CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016889D0: MOV v2.16b, v3.16b         | V2 = 0 (0x0);//ML01                     
            // 0x016889D4: MOV v3.16b, v8.16b         | V3 = val_3.x;//m1                       
            // 0x016889D8: MOV v4.16b, v9.16b         | V4 = val_3.y;//m1                       
            // 0x016889DC: MOV v5.16b, v10.16b        | V5 = val_3.z;//m1                       
            // 0x016889E0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
            UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_10, z = val_3.z});
            // 0x016889E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016889E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016889EC: FMOV s3, #2.00000000       | S3 = 2;                                 
            // 0x016889F0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, d:  2f);
            UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, d:  2f);
            // 0x016889F4: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x016889F8: MOV v11.16b, v0.16b        | V11 = val_5.x;//m1                      
            // 0x016889FC: LDR s0, [x8, #0x7ac]       | S0 = 0.2;                               
            float val_9 = 0.2f;
            // 0x01688A00: MOV v12.16b, v1.16b        | V12 = val_5.y;//m1                      
            // 0x01688A04: SCVTF s1, w20              | S1 = (float)(depth);                    
            // 0x01688A08: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
            // 0x01688A0C: FMUL s0, s1, s0            | S0 = (depth * 0.2f);                    
            val_9 = (float)val_11 * val_9;
            // 0x01688A10: FADD s9, s0, s9            | S9 = ((depth * 0.2f) + val_3.y);        
            val_10 = val_9 + val_10;
            // 0x01688A14: LDR s0, [x8, #0x950]       | S0 = 0.05;                              
            // 0x01688A18: MOV w1, w20                | W1 = depth;//m1                         
            // 0x01688A1C: MOV v13.16b, v2.16b        | V13 = val_5.z;//m1                      
            // 0x01688A20: BL #0x167f484              | X0 = Pathfinding.AstarMath.IntToColor(i:  0, a:  0.05f);
            UnityEngine.Color val_6 = Pathfinding.AstarMath.IntToColor(i:  0, a:  0.05f);
            // 0x01688A24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688A2C: BL #0x1a654c8              | UnityEngine.Gizmos.set_color(value:  new UnityEngine.Color() {r = val_6.r, g = val_6.g, b = val_6.b, a = val_6.a});
            UnityEngine.Gizmos.color = new UnityEngine.Color() {r = val_6.r, g = val_6.g, b = val_6.b, a = val_6.a};
            // 0x01688A30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688A34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688A38: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
            // 0x01688A3C: MOV v1.16b, v9.16b         | V1 = ((depth * 0.2f) + val_3.y);//m1    
            // 0x01688A40: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
            // 0x01688A44: MOV v3.16b, v11.16b        | V3 = val_5.x;//m1                       
            // 0x01688A48: MOV v4.16b, v12.16b        | V4 = val_5.y;//m1                       
            // 0x01688A4C: MOV v5.16b, v13.16b        | V5 = val_5.z;//m1                       
            // 0x01688A50: BL #0x1a6439c              | UnityEngine.Gizmos.DrawCube(center:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, size:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
            UnityEngine.Gizmos.DrawCube(center:  new UnityEngine.Vector3() {x = val_3.x, y = val_10, z = val_3.z}, size:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
            // 0x01688A54: LDR x8, [sp, #0x30]        | X8 = this.arr[((long)(int)(boxi)) << 5][2];
            // 0x01688A58: CBNZ x8, #0x1688a80        | if (this.arr[((long)(int)(boxi)) << 5][2] != 0) goto label_5;
            if(val_7 != 0)
            {
                goto label_5;
            }
            // 0x01688A5C: LDR w1, [sp, #0x38]        | W1 = this.arr[((long)(int)(boxi)) << 5][2];
            // 0x01688A60: ADD w20, w20, #1           | W20 = (depth + 1);                      
            val_11 = val_11 + 1;
            // 0x01688A64: MOV x0, x19                | X0 = 1152921513414644560 (0x100000020CFC5350);//ML01
            // 0x01688A68: MOV w2, w20                | W2 = (depth + 1);//m1                   
            // 0x01688A6C: BL #0x168883c              |  R0 = label_7();                        
            // 0x01688A70: LDR w1, [sp, #0x3c]        | W1 = this.arr[((long)(int)(boxi)) << 5][2];
            // 0x01688A74: MOV x0, x19                | X0 = 1152921513414644560 (0x100000020CFC5350);//ML01
            // 0x01688A78: MOV w2, w20                | W2 = (depth + 1);//m1                   
            // 0x01688A7C: BL #0x168883c              |  R0 = label_7();                        
            label_5:
            // 0x01688A80: SUB sp, x29, #0x60         | SP = (1152921513414632544 - 96) = 1152921513414632448 (0x100000020CFC2400);
            // 0x01688A84: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x01688A88: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x01688A8C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x01688A90: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x01688A94: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01688A98: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x01688A9C: LDP d13, d12, [sp], #0x70  | D13 = ; D12 = ;                          //  | 
            // 0x01688AA0: RET                        |  return;                                
            return;
            // 0x01688AA4: STP x29, x30, [sp, #-0x10]! | 
            // 0x01688AA8: MOV x29, sp                | 
            // 0x01688AAC: ADRP x0, #0x2aa0000        | 
            // 0x01688AB0: ADD x0, x0, #0xef8         | 
            // 0x01688AB4: BL #0x27af3c8              | 
            // 0x01688AB8: MOV x1, xzr                | 
            // 0x01688ABC: BL #0x27ae3bc              | 
            // 0x01688AC0: BL #0x167ef74              | 
            // 0x01688AC4: STP x29, x30, [sp, #-0x10]! | 
            // 0x01688AC8: MOV x29, sp                | 
            // 0x01688ACC: ADRP x0, #0x2aa0000        | 
            // 0x01688AD0: ADD x0, x0, #0xef8         | 
            // 0x01688AD4: BL #0x27af3c8              | 
            // 0x01688AD8: MOV x1, xzr                | 
            // 0x01688ADC: BL #0x27ae3bc              | 
            // 0x01688AE0: BL #0x167ef74              | 
            // 0x01688AE4: RET                        | 
        
        }
        //
        // Offset in libil2cpp.so: 0x016883E4 (23626724), len: 312  VirtAddr: 0x016883E4 RVA: 0x016883E4 token: 100683181 methodIndex: 49903 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool NodeIntersectsCircle(Pathfinding.MeshNode node, UnityEngine.Vector3 p, float radius)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            // 0x016883E4: STP d15, d14, [sp, #-0x60]! | stack[1152921513414785424] = ???;  stack[1152921513414785432] = ???;  //  dest_result_addr=1152921513414785424 |  dest_result_addr=1152921513414785432
            // 0x016883E8: STP d13, d12, [sp, #0x10]  | stack[1152921513414785440] = ???;  stack[1152921513414785448] = ???;  //  dest_result_addr=1152921513414785440 |  dest_result_addr=1152921513414785448
            // 0x016883EC: STP d11, d10, [sp, #0x20]  | stack[1152921513414785456] = ???;  stack[1152921513414785464] = ???;  //  dest_result_addr=1152921513414785456 |  dest_result_addr=1152921513414785464
            // 0x016883F0: STP d9, d8, [sp, #0x30]    | stack[1152921513414785472] = ???;  stack[1152921513414785480] = ???;  //  dest_result_addr=1152921513414785472 |  dest_result_addr=1152921513414785480
            // 0x016883F4: STP x20, x19, [sp, #0x40]  | stack[1152921513414785488] = ???;  stack[1152921513414785496] = ???;  //  dest_result_addr=1152921513414785488 |  dest_result_addr=1152921513414785496
            // 0x016883F8: STP x29, x30, [sp, #0x50]  | stack[1152921513414785504] = ???;  stack[1152921513414785512] = ???;  //  dest_result_addr=1152921513414785504 |  dest_result_addr=1152921513414785512
            // 0x016883FC: ADD x29, sp, #0x50         | X29 = (1152921513414785424 + 80) = 1152921513414785504 (0x100000020CFE79E0);
            // 0x01688400: SUB sp, sp, #0x10          | SP = (1152921513414785424 - 16) = 1152921513414785408 (0x100000020CFE7980);
            // 0x01688404: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01688408: LDRB w8, [x20, #0xf8]      | W8 = (bool)static_value_037380F8;       
            // 0x0168840C: MOV v8.16b, v3.16b         | V8 = radius;//m1                        
            // 0x01688410: MOV v9.16b, v2.16b         | V9 = p.z;//m1                           
            // 0x01688414: MOV v10.16b, v1.16b        | V10 = p.y;//m1                          
            // 0x01688418: MOV v11.16b, v0.16b        | V11 = p.x;//m1                          
            // 0x0168841C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01688420: TBNZ w8, #0, #0x168843c    | if (static_value_037380F8 == true) goto label_0;
            // 0x01688424: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x01688428: LDR x8, [x8, #0x870]       | X8 = 0x2B8F120;                         
            // 0x0168842C: LDR w0, [x8]               | W0 = 0x130A;                            
            // 0x01688430: BL #0x2782188              | X0 = sub_2782188( ?? 0x130A, ????);     
            // 0x01688434: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01688438: STRB w8, [x20, #0xf8]      | static_value_037380F8 = true;            //  dest_result_addr=57901304
            label_0:
            // 0x0168843C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688440: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688444: MOV v0.16b, v8.16b         | V0 = radius;//m1                        
            // 0x01688448: STR wzr, [sp, #8]          | stack[1152921513414785416] = 0x0;        //  dest_result_addr=1152921513414785416
            // 0x0168844C: STR xzr, [sp]              | stack[1152921513414785408] = 0x0;        //  dest_result_addr=1152921513414785408
            // 0x01688450: BL #0x18a6fb8              | X0 = System.Single.IsPositiveInfinity(f:  radius);
            bool val_1 = System.Single.IsPositiveInfinity(f:  radius);
            // 0x01688454: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x01688458: TBZ w8, #0, #0x1688464     | if ((val_1 & 1) == false) goto label_1; 
            if(val_2 == false)
            {
                goto label_1;
            }
            // 0x0168845C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_6 = 1;
            // 0x01688460: B #0x16884fc               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x01688464: CBNZ x19, #0x168846c       | if (X1 != 0) goto label_3;              
            if(X1 != 0)
            {
                goto label_3;
            }
            // 0x01688468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x0168846C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01688470: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01688474: MOV v0.16b, v11.16b        | V0 = p.x;//m1                           
            // 0x01688478: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
            // 0x0168847C: LDR x9, [x8, #0x250]       | X9 = X1 + 592;                          
            // 0x01688480: LDR x1, [x8, #0x258]       | X1 = X1 + 600;                          
            // 0x01688484: MOV v2.16b, v9.16b         | V2 = p.z;//m1                           
            // 0x01688488: BLR x9                     | X0 = X1 + 592();                        
            // 0x0168848C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x01688490: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01688494: MOV v12.16b, v0.16b        | V12 = p.x;//m1                          
            // 0x01688498: MOV v13.16b, v1.16b        | V13 = p.y;//m1                          
            // 0x0168849C: MOV v14.16b, v2.16b        | V14 = p.z;//m1                          
            // 0x016884A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x016884A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x016884A8: TBZ w8, #0, #0x16884b8     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x016884AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x016884B0: CBNZ w8, #0x16884b8        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x016884B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_5:
            // 0x016884B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016884BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016884C0: MOV v0.16b, v11.16b        | V0 = p.x;//m1                           
            // 0x016884C4: MOV v1.16b, v10.16b        | V1 = p.y;//m1                           
            // 0x016884C8: MOV v2.16b, v9.16b         | V2 = p.z;//m1                           
            // 0x016884CC: MOV v3.16b, v12.16b        | V3 = p.x;//m1                           
            // 0x016884D0: MOV v4.16b, v13.16b        | V4 = p.y;//m1                           
            // 0x016884D4: MOV v5.16b, v14.16b        | V5 = p.z;//m1                           
            // 0x016884D8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z}, b:  new UnityEngine.Vector3() {x = p.x, y = p.y, z = p.z});
            // 0x016884DC: MOV x0, sp                 | X0 = 1152921513414785408 (0x100000020CFE7980);//ML01
            // 0x016884E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016884E4: STP s0, s1, [sp]           | stack[1152921513414785408] = val_3.x;  stack[1152921513414785412] = val_3.y;  //  dest_result_addr=1152921513414785408 |  dest_result_addr=1152921513414785412
            // 0x016884E8: STR s2, [sp, #8]           | stack[1152921513414785416] = val_3.z;    //  dest_result_addr=1152921513414785416
            // 0x016884EC: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
            // 0x016884F0: FMUL s1, s8, s8            | S1 = (radius * radius);                 
            float val_4 = radius * radius;
            // 0x016884F4: FCMP s0, s1                | STATE = COMPARE(val_3.x, (radius * radius))
            // 0x016884F8: CSET w0, mi                | W0 = val_3.x < 0 ? 1 : 0;               
            var val_5 = (val_3.x < 0) ? 1 : 0;
            label_2:
            // 0x016884FC: SUB sp, x29, #0x50         | SP = (1152921513414785504 - 80) = 1152921513414785424 (0x100000020CFE7990);
            // 0x01688500: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01688504: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01688508: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x0168850C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01688510: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01688514: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01688518: RET                        |  return (System.Boolean)val_3.x < 0 ? 1 : 0;
            return (bool)val_5;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01688028 (23625768), len: 268  VirtAddr: 0x01688028 RVA: 0x01688028 token: 100683182 methodIndex: 49904 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool RectIntersectsCircle(UnityEngine.Rect r, UnityEngine.Vector3 p, float radius)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            // 0x01688028: STP d13, d12, [sp, #-0x40]! | stack[1152921513414901552] = ???;  stack[1152921513414901560] = ???;  //  dest_result_addr=1152921513414901552 |  dest_result_addr=1152921513414901560
            // 0x0168802C: STP d11, d10, [sp, #0x10]  | stack[1152921513414901568] = ???;  stack[1152921513414901576] = ???;  //  dest_result_addr=1152921513414901568 |  dest_result_addr=1152921513414901576
            // 0x01688030: STP d9, d8, [sp, #0x20]    | stack[1152921513414901584] = ???;  stack[1152921513414901592] = ???;  //  dest_result_addr=1152921513414901584 |  dest_result_addr=1152921513414901592
            // 0x01688034: STP x29, x30, [sp, #0x30]  | stack[1152921513414901600] = ???;  stack[1152921513414901608] = ???;  //  dest_result_addr=1152921513414901600 |  dest_result_addr=1152921513414901608
            // 0x01688038: ADD x29, sp, #0x30         | X29 = (1152921513414901552 + 48) = 1152921513414901600 (0x100000020D003F60);
            // 0x0168803C: MOV v8.16b, v7.16b         | V8 = radius;//m1                        
            // 0x01688040: MOV v9.16b, v6.16b         | V9 = p.z;//m1                           
            // 0x01688044: MOV v10.16b, v4.16b        | V10 = p.x;//m1                          
            // 0x01688048: STP s0, s1, [sp, #-0x10]!  | stack[1152921513414901536] = r.m_XMin;  stack[1152921513414901540] = r.m_YMin;  //  dest_result_addr=1152921513414901536 |  dest_result_addr=1152921513414901540
            // 0x0168804C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688054: MOV v0.16b, v8.16b         | V0 = radius;//m1                        
            // 0x01688058: STP s2, s3, [sp, #8]       | stack[1152921513414901544] = r.m_Width;  stack[1152921513414901548] = r.m_Height;  //  dest_result_addr=1152921513414901544 |  dest_result_addr=1152921513414901548
            // 0x0168805C: BL #0x18a6fb8              | X0 = System.Single.IsPositiveInfinity(f:  radius);
            bool val_1 = System.Single.IsPositiveInfinity(f:  radius);
            // 0x01688060: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x01688064: TBZ w8, #0, #0x1688070     | if ((val_1 & 1) == false) goto label_0; 
            if(val_2 == false)
            {
                goto label_0;
            }
            // 0x01688068: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_11 = 1;
            // 0x0168806C: B #0x168811c               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x01688070: MOV x0, sp                 | X0 = 1152921513414901536 (0x100000020D003F20);//ML01
            // 0x01688074: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688078: BL #0x1b81814              | X0 = r.m_XMin.get_xMin();               
            float val_3 = r.m_XMin.xMin;
            // 0x0168807C: MOV v1.16b, v0.16b         | V1 = val_3;//m1                         
            // 0x01688080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01688084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688088: MOV v0.16b, v10.16b        | V0 = p.x;//m1                           
            // 0x0168808C: BL #0x16f9434              | X0 = System.Math.Max(val1:  p.x, val2:  val_3);
            float val_4 = System.Math.Max(val1:  p.x, val2:  val_3);
            // 0x01688090: MOV x0, sp                 | X0 = 1152921513414901536 (0x100000020D003F20);//ML01
            // 0x01688094: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688098: MOV v11.16b, v0.16b        | V11 = val_4;//m1                        
            // 0x0168809C: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x016880A0: MOV v1.16b, v0.16b         | V1 = val_4;//m1                         
            // 0x016880A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016880A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016880AC: MOV v0.16b, v11.16b        | V0 = val_4;//m1                         
            // 0x016880B0: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_4, val2:  val_4);
            float val_5 = System.Math.Min(val1:  val_4, val2:  val_4);
            // 0x016880B4: MOV x0, sp                 | X0 = 1152921513414901536 (0x100000020D003F20);//ML01
            // 0x016880B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016880BC: MOV v11.16b, v0.16b        | V11 = val_5;//m1                        
            // 0x016880C0: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x016880C4: MOV v1.16b, v0.16b         | V1 = val_5;//m1                         
            // 0x016880C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016880CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016880D0: MOV v0.16b, v9.16b         | V0 = p.z;//m1                           
            // 0x016880D4: BL #0x16f9434              | X0 = System.Math.Max(val1:  p.z, val2:  val_5);
            float val_6 = System.Math.Max(val1:  p.z, val2:  val_5);
            // 0x016880D8: MOV x0, sp                 | X0 = 1152921513414901536 (0x100000020D003F20);//ML01
            // 0x016880DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016880E0: MOV v12.16b, v0.16b        | V12 = val_6;//m1                        
            // 0x016880E4: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x016880E8: MOV v1.16b, v0.16b         | V1 = val_6;//m1                         
            // 0x016880EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016880F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016880F4: MOV v0.16b, v12.16b        | V0 = val_6;//m1                         
            // 0x016880F8: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_6, val2:  val_6);
            float val_7 = System.Math.Min(val1:  val_6, val2:  val_6);
            // 0x016880FC: FSUB s1, s11, s10          | S1 = (val_5 - p.x);                     
            float val_8 = val_5 - p.x;
            // 0x01688100: FSUB s0, s0, s9            | S0 = (val_7 - p.z);                     
            val_7 = val_7 - p.z;
            // 0x01688104: FMUL s1, s1, s1            | S1 = ((val_5 - p.x) * (val_5 - p.x));   
            val_8 = val_8 * val_8;
            // 0x01688108: FMUL s0, s0, s0            | S0 = ((val_7 - p.z) * (val_7 - p.z));   
            val_7 = val_7 * val_7;
            // 0x0168810C: FADD s0, s1, s0            | S0 = (((val_5 - p.x) * (val_5 - p.x)) + ((val_7 - p.z) * (val_7 - p.z)));
            val_7 = val_8 + val_7;
            // 0x01688110: FMUL s1, s8, s8            | S1 = (radius * radius);                 
            float val_9 = radius * radius;
            // 0x01688114: FCMP s0, s1                | STATE = COMPARE((((val_5 - p.x) * (val_5 - p.x)) + ((val_7 - p.z) * (val_7 - p.z))), (radius * radius))
            // 0x01688118: CSET w0, mi                | W0 = val_7 < 0 ? 1 : 0;                 
            var val_10 = (val_7 < 0) ? 1 : 0;
            label_1:
            // 0x0168811C: SUB sp, x29, #0x30         | SP = (1152921513414901600 - 48) = 1152921513414901552 (0x100000020D003F30);
            // 0x01688120: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01688124: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
            // 0x01688128: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
            // 0x0168812C: LDP d13, d12, [sp], #0x40  | D13 = ; D12 = ;                          //  | 
            // 0x01688130: RET                        |  return (System.Boolean)val_7 < 0 ? 1 : 0;
            return (bool)val_10;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01688770 (23627632), len: 132  VirtAddr: 0x01688770 RVA: 0x01688770 token: 100683183 methodIndex: 49905 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool RectContains(UnityEngine.Rect r, UnityEngine.Vector3 p)
        {
            //
            // Disasemble & Code
            // 0x01688770: STP d9, d8, [sp, #-0x20]!  | stack[1152921513415013584] = ???;  stack[1152921513415013592] = ???;  //  dest_result_addr=1152921513415013584 |  dest_result_addr=1152921513415013592
            // 0x01688774: STP x29, x30, [sp, #0x10]  | stack[1152921513415013600] = ???;  stack[1152921513415013608] = ???;  //  dest_result_addr=1152921513415013600 |  dest_result_addr=1152921513415013608
            // 0x01688778: ADD x29, sp, #0x10         | X29 = (1152921513415013584 + 16) = 1152921513415013600 (0x100000020D01F4E0);
            // 0x0168877C: MOV v8.16b, v6.16b         | V8 = p.z;//m1                           
            // 0x01688780: MOV v9.16b, v4.16b         | V9 = p.x;//m1                           
            // 0x01688784: STP s0, s1, [sp, #-0x10]!  | stack[1152921513415013568] = r.m_XMin;  stack[1152921513415013572] = r.m_YMin;  //  dest_result_addr=1152921513415013568 |  dest_result_addr=1152921513415013572
            // 0x01688788: MOV x0, sp                 | X0 = 1152921513415013568 (0x100000020D01F4C0);//ML01
            // 0x0168878C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01688790: STP s2, s3, [sp, #8]       | stack[1152921513415013576] = r.m_Width;  stack[1152921513415013580] = r.m_Height;  //  dest_result_addr=1152921513415013576 |  dest_result_addr=1152921513415013580
            // 0x01688794: BL #0x1b81814              | X0 = r.m_XMin.get_xMin();               
            float val_1 = r.m_XMin.xMin;
            // 0x01688798: FCMP s9, s0                | STATE = COMPARE(p.x, val_1)             
            // 0x0168879C: B.LT #0x16887c8            | if (p.x < val_1) goto label_1;          
            if(p.x < val_1)
            {
                goto label_1;
            }
            // 0x016887A0: MOV x0, sp                 | X0 = 1152921513415013568 (0x100000020D01F4C0);//ML01
            // 0x016887A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016887A8: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x016887AC: FCMP s9, s0                | STATE = COMPARE(p.x, val_1)             
            // 0x016887B0: B.HI #0x16887c8            | if (p.x > val_1) goto label_1;          
            if(p.x > val_1)
            {
                goto label_1;
            }
            // 0x016887B4: MOV x0, sp                 | X0 = 1152921513415013568 (0x100000020D01F4C0);//ML01
            // 0x016887B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016887BC: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x016887C0: FCMP s8, s0                | STATE = COMPARE(p.z, val_1)             
            // 0x016887C4: B.GE #0x16887dc            | if (p.z >= val_1) goto label_2;         
            if(p.z >= val_1)
            {
                goto label_2;
            }
            label_1:
            // 0x016887C8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            label_3:
            // 0x016887CC: SUB sp, x29, #0x10         | SP = (1152921513415013600 - 16) = 1152921513415013584 (0x100000020D01F4D0);
            // 0x016887D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x016887D4: LDP d9, d8, [sp], #0x20    | D9 = ; D8 = ;                            //  | 
            // 0x016887D8: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_2:
            // 0x016887DC: MOV x0, sp                 | X0 = 1152921513415013568 (0x100000020D01F4C0);//ML01
            // 0x016887E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016887E4: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x016887E8: FCMP s8, s0                | STATE = COMPARE(p.z, val_1)             
            // 0x016887EC: CSET w0, ls                | W0 = p.z <= val_1 ? 1 : 0;              
            var val_2 = (p.z <= val_1) ? 1 : 0;
            // 0x016887F0: B #0x16887cc               |  goto label_3;                          
            goto label_3;
        
        }
        //
        // Offset in libil2cpp.so: 0x01687338 (23622456), len: 296  VirtAddr: 0x01687338 RVA: 0x01687338 token: 100683184 methodIndex: 49906 delegateWrapperIndex: 0 methodInvoker: 0
        private static float ExpansionRequired(UnityEngine.Rect r, UnityEngine.Rect r2)
        {
            //
            // Disasemble & Code
            // 0x01687338: STP d11, d10, [sp, #-0x30]! | stack[1152921513415125568] = ???;  stack[1152921513415125576] = ???;  //  dest_result_addr=1152921513415125568 |  dest_result_addr=1152921513415125576
            // 0x0168733C: STP d9, d8, [sp, #0x10]    | stack[1152921513415125584] = ???;  stack[1152921513415125592] = ???;  //  dest_result_addr=1152921513415125584 |  dest_result_addr=1152921513415125592
            // 0x01687340: STP x29, x30, [sp, #0x20]  | stack[1152921513415125600] = ???;  stack[1152921513415125608] = ???;  //  dest_result_addr=1152921513415125600 |  dest_result_addr=1152921513415125608
            // 0x01687344: ADD x29, sp, #0x20         | X29 = (1152921513415125568 + 32) = 1152921513415125600 (0x100000020D03AA60);
            // 0x01687348: SUB sp, sp, #0x20          | SP = (1152921513415125568 - 32) = 1152921513415125536 (0x100000020D03AA20);
            // 0x0168734C: ADD x0, sp, #0x10          | X0 = (1152921513415125536 + 16) = 1152921513415125552 (0x100000020D03AA30);
            // 0x01687350: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687354: STP s0, s1, [sp, #0x10]    | stack[1152921513415125552] = r.m_XMin;  stack[1152921513415125556] = r.m_YMin;  //  dest_result_addr=1152921513415125552 |  dest_result_addr=1152921513415125556
            // 0x01687358: STP s2, s3, [sp, #0x18]    | stack[1152921513415125560] = r.m_Width;  stack[1152921513415125564] = r.m_Height;  //  dest_result_addr=1152921513415125560 |  dest_result_addr=1152921513415125564
            // 0x0168735C: STP s4, s5, [sp]           | stack[1152921513415125536] = r2.m_XMin;  stack[1152921513415125540] = r2.m_YMin;  //  dest_result_addr=1152921513415125536 |  dest_result_addr=1152921513415125540
            // 0x01687360: STP s6, s7, [sp, #8]       | stack[1152921513415125544] = r2.m_Width;  stack[1152921513415125548] = r2.m_Height;  //  dest_result_addr=1152921513415125544 |  dest_result_addr=1152921513415125548
            // 0x01687364: BL #0x1b81814              | X0 = r.m_XMin.get_xMin();               
            float val_1 = r.m_XMin.xMin;
            // 0x01687368: MOV x0, sp                 | X0 = 1152921513415125536 (0x100000020D03AA20);//ML01
            // 0x0168736C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687370: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
            // 0x01687374: BL #0x1b81814              | X0 = r2.m_XMin.get_xMin();              
            float val_2 = r2.m_XMin.xMin;
            // 0x01687378: MOV v1.16b, v0.16b         | V1 = val_2;//m1                         
            // 0x0168737C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687380: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687384: MOV v0.16b, v8.16b         | V0 = val_1;//m1                         
            // 0x01687388: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_1, val2:  val_2);
            float val_3 = System.Math.Min(val1:  val_1, val2:  val_2);
            // 0x0168738C: ADD x0, sp, #0x10          | X0 = (1152921513415125536 + 16) = 1152921513415125552 (0x100000020D03AA30);
            // 0x01687390: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687394: MOV v8.16b, v0.16b         | V8 = val_3;//m1                         
            // 0x01687398: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x0168739C: MOV x0, sp                 | X0 = 1152921513415125536 (0x100000020D03AA20);//ML01
            // 0x016873A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016873A4: MOV v9.16b, v0.16b         | V9 = val_3;//m1                         
            // 0x016873A8: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x016873AC: MOV v1.16b, v0.16b         | V1 = val_3;//m1                         
            // 0x016873B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016873B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016873B8: MOV v0.16b, v9.16b         | V0 = val_3;//m1                         
            // 0x016873BC: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_3, val2:  val_3);
            float val_4 = System.Math.Max(val1:  val_3, val2:  val_3);
            // 0x016873C0: ADD x0, sp, #0x10          | X0 = (1152921513415125536 + 16) = 1152921513415125552 (0x100000020D03AA30);
            // 0x016873C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016873C8: MOV v9.16b, v0.16b         | V9 = val_4;//m1                         
            // 0x016873CC: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x016873D0: MOV x0, sp                 | X0 = 1152921513415125536 (0x100000020D03AA20);//ML01
            // 0x016873D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016873D8: MOV v10.16b, v0.16b        | V10 = val_4;//m1                        
            // 0x016873DC: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x016873E0: MOV v1.16b, v0.16b         | V1 = val_4;//m1                         
            // 0x016873E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016873E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016873EC: MOV v0.16b, v10.16b        | V0 = val_4;//m1                         
            // 0x016873F0: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_4, val2:  val_4);
            float val_5 = System.Math.Min(val1:  val_4, val2:  val_4);
            // 0x016873F4: ADD x0, sp, #0x10          | X0 = (1152921513415125536 + 16) = 1152921513415125552 (0x100000020D03AA30);
            // 0x016873F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016873FC: MOV v10.16b, v0.16b        | V10 = val_5;//m1                        
            // 0x01687400: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x01687404: MOV x0, sp                 | X0 = 1152921513415125536 (0x100000020D03AA20);//ML01
            // 0x01687408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168740C: MOV v11.16b, v0.16b        | V11 = val_5;//m1                        
            // 0x01687410: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x01687414: MOV v1.16b, v0.16b         | V1 = val_5;//m1                         
            // 0x01687418: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168741C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687420: MOV v0.16b, v11.16b        | V0 = val_5;//m1                         
            // 0x01687424: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_5, val2:  val_5);
            float val_6 = System.Math.Max(val1:  val_5, val2:  val_5);
            // 0x01687428: LDP s4, s1, [sp, #0x10]    | S4 = r.m_XMin; S1 = r.m_YMin;            //  | 
            // 0x0168742C: LDP s2, s3, [sp, #0x18]    | S2 = r.m_Width; S3 = r.m_Height;         //  | 
            // 0x01687430: MOV v11.16b, v0.16b        | V11 = val_6;//m1                        
            // 0x01687434: MOV v0.16b, v4.16b         | V0 = r.m_XMin;//m1                      
            // 0x01687438: BL #0x1687460              | X0 = Pathfinding.BBTree.RectArea(r:  new UnityEngine.Rect() {m_XMin = r.m_XMin, m_YMin = r.m_YMin, m_Width = r.m_Width, m_Height = r.m_Height});
            float val_7 = Pathfinding.BBTree.RectArea(r:  new UnityEngine.Rect() {m_XMin = r.m_XMin, m_YMin = r.m_YMin, m_Width = r.m_Width, m_Height = r.m_Height});
            // 0x0168743C: FSUB s1, s9, s8            | S1 = (val_4 - val_3);                   
            float val_8 = val_4 - val_3;
            // 0x01687440: FSUB s2, s11, s10          | S2 = (val_6 - val_5);                   
            float val_9 = val_6 - val_5;
            // 0x01687444: FMUL s1, s1, s2            | S1 = ((val_4 - val_3) * (val_6 - val_5));
            val_8 = val_8 * val_9;
            // 0x01687448: FSUB s0, s1, s0            | S0 = (((val_4 - val_3) * (val_6 - val_5)) - val_7);
            val_7 = val_8 - val_7;
            // 0x0168744C: SUB sp, x29, #0x20         | SP = (1152921513415125600 - 32) = 1152921513415125568 (0x100000020D03AA40);
            // 0x01687450: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01687454: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01687458: LDP d11, d10, [sp], #0x30  | D11 = ; D10 = ;                          //  | 
            // 0x0168745C: RET                        |  return (System.Single)(((val_4 - val_3) * (val_6 - val_5)) - val_7);
            return (float)val_7;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01687218 (23622168), len: 288  VirtAddr: 0x01687218 RVA: 0x01687218 token: 100683185 methodIndex: 49907 delegateWrapperIndex: 0 methodInvoker: 0
        private static UnityEngine.Rect ExpandToContain(UnityEngine.Rect r, UnityEngine.Rect r2)
        {
            //
            // Disasemble & Code
            // 0x01687218: STP d11, d10, [sp, #-0x30]! | stack[1152921513415237568] = ???;  stack[1152921513415237576] = ???;  //  dest_result_addr=1152921513415237568 |  dest_result_addr=1152921513415237576
            // 0x0168721C: STP d9, d8, [sp, #0x10]    | stack[1152921513415237584] = ???;  stack[1152921513415237592] = ???;  //  dest_result_addr=1152921513415237584 |  dest_result_addr=1152921513415237592
            // 0x01687220: STP x29, x30, [sp, #0x20]  | stack[1152921513415237600] = ???;  stack[1152921513415237608] = ???;  //  dest_result_addr=1152921513415237600 |  dest_result_addr=1152921513415237608
            // 0x01687224: ADD x29, sp, #0x20         | X29 = (1152921513415237568 + 32) = 1152921513415237600 (0x100000020D055FE0);
            // 0x01687228: SUB sp, sp, #0x20          | SP = (1152921513415237568 - 32) = 1152921513415237536 (0x100000020D055FA0);
            // 0x0168722C: ADD x0, sp, #0x10          | X0 = (1152921513415237536 + 16) = 1152921513415237552 (0x100000020D055FB0);
            // 0x01687230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687234: STP s0, s1, [sp, #0x10]    | stack[1152921513415237552] = r.m_XMin;  stack[1152921513415237556] = r.m_YMin;  //  dest_result_addr=1152921513415237552 |  dest_result_addr=1152921513415237556
            // 0x01687238: STP s2, s3, [sp, #0x18]    | stack[1152921513415237560] = r.m_Width;  stack[1152921513415237564] = r.m_Height;  //  dest_result_addr=1152921513415237560 |  dest_result_addr=1152921513415237564
            // 0x0168723C: STP s4, s5, [sp]           | stack[1152921513415237536] = r2.m_XMin;  stack[1152921513415237540] = r2.m_YMin;  //  dest_result_addr=1152921513415237536 |  dest_result_addr=1152921513415237540
            // 0x01687240: STP s6, s7, [sp, #8]       | stack[1152921513415237544] = r2.m_Width;  stack[1152921513415237548] = r2.m_Height;  //  dest_result_addr=1152921513415237544 |  dest_result_addr=1152921513415237548
            // 0x01687244: BL #0x1b81814              | X0 = r.m_XMin.get_xMin();               
            float val_1 = r.m_XMin.xMin;
            // 0x01687248: MOV x0, sp                 | X0 = 1152921513415237536 (0x100000020D055FA0);//ML01
            // 0x0168724C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687250: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
            // 0x01687254: BL #0x1b81814              | X0 = r2.m_XMin.get_xMin();              
            float val_2 = r2.m_XMin.xMin;
            // 0x01687258: MOV v1.16b, v0.16b         | V1 = val_2;//m1                         
            // 0x0168725C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687260: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687264: MOV v0.16b, v8.16b         | V0 = val_1;//m1                         
            // 0x01687268: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_1, val2:  val_2);
            float val_3 = System.Math.Min(val1:  val_1, val2:  val_2);
            // 0x0168726C: ADD x0, sp, #0x10          | X0 = (1152921513415237536 + 16) = 1152921513415237552 (0x100000020D055FB0);
            // 0x01687270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687274: MOV v8.16b, v0.16b         | V8 = val_3;//m1                         
            // 0x01687278: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x0168727C: MOV x0, sp                 | X0 = 1152921513415237536 (0x100000020D055FA0);//ML01
            // 0x01687280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687284: MOV v9.16b, v0.16b         | V9 = val_3;//m1                         
            // 0x01687288: BL #0x1b81910              | X0 = label_UnityEngine_Rect_set_min_GL01B81910();
            // 0x0168728C: MOV v1.16b, v0.16b         | V1 = val_3;//m1                         
            // 0x01687290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687298: MOV v0.16b, v9.16b         | V0 = val_3;//m1                         
            // 0x0168729C: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_3, val2:  val_3);
            float val_4 = System.Math.Max(val1:  val_3, val2:  val_3);
            // 0x016872A0: ADD x0, sp, #0x10          | X0 = (1152921513415237536 + 16) = 1152921513415237552 (0x100000020D055FB0);
            // 0x016872A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016872A8: MOV v9.16b, v0.16b         | V9 = val_4;//m1                         
            // 0x016872AC: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x016872B0: MOV x0, sp                 | X0 = 1152921513415237536 (0x100000020D055FA0);//ML01
            // 0x016872B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016872B8: MOV v10.16b, v0.16b        | V10 = val_4;//m1                        
            // 0x016872BC: BL #0x1b8181c              | X0 = label_UnityEngine_Rect_set_center_GL01B8181C();
            // 0x016872C0: MOV v1.16b, v0.16b         | V1 = val_4;//m1                         
            // 0x016872C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016872C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016872CC: MOV v0.16b, v10.16b        | V0 = val_4;//m1                         
            // 0x016872D0: BL #0x16f9600              | X0 = System.Math.Min(val1:  val_4, val2:  val_4);
            float val_5 = System.Math.Min(val1:  val_4, val2:  val_4);
            // 0x016872D4: ADD x0, sp, #0x10          | X0 = (1152921513415237536 + 16) = 1152921513415237552 (0x100000020D055FB0);
            // 0x016872D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016872DC: MOV v10.16b, v0.16b        | V10 = val_5;//m1                        
            // 0x016872E0: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x016872E4: MOV x0, sp                 | X0 = 1152921513415237536 (0x100000020D055FA0);//ML01
            // 0x016872E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016872EC: MOV v11.16b, v0.16b        | V11 = val_5;//m1                        
            // 0x016872F0: BL #0x1b81920              | X0 = label_UnityEngine_Rect_set_min_GL01B81920();
            // 0x016872F4: MOV v1.16b, v0.16b         | V1 = val_5;//m1                         
            // 0x016872F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016872FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687300: MOV v0.16b, v11.16b        | V0 = val_5;//m1                         
            // 0x01687304: BL #0x16f9434              | X0 = System.Math.Max(val1:  val_5, val2:  val_5);
            float val_6 = System.Math.Max(val1:  val_5, val2:  val_5);
            // 0x01687308: MOV v3.16b, v0.16b         | V3 = val_6;//m1                         
            // 0x0168730C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01687310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687314: MOV v0.16b, v8.16b         | V0 = val_3;//m1                         
            // 0x01687318: MOV v1.16b, v10.16b        | V1 = val_5;//m1                         
            // 0x0168731C: MOV v2.16b, v9.16b         | V2 = val_4;//m1                         
            // 0x01687320: BL #0x1b81640              | X0 = UnityEngine.Rect.MinMaxRect(xmin:  val_3, ymin:  val_5, xmax:  val_4, ymax:  val_6);
            UnityEngine.Rect val_7 = UnityEngine.Rect.MinMaxRect(xmin:  val_3, ymin:  val_5, xmax:  val_4, ymax:  val_6);
            // 0x01687324: SUB sp, x29, #0x20         | SP = (1152921513415237600 - 32) = 1152921513415237568 (0x100000020D055FC0);
            // 0x01687328: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168732C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x01687330: LDP d11, d10, [sp], #0x30  | D11 = ; D10 = ;                          //  | 
            // 0x01687334: RET                        |  return new UnityEngine.Rect() {m_XMin = val_7.m_XMin, m_YMin = val_7.m_YMin, m_Width = val_7.m_Width, m_Height = val_7.m_Height};
            return new UnityEngine.Rect() {m_XMin = val_7.m_XMin, m_YMin = val_7.m_YMin, m_Width = val_7.m_Width, m_Height = val_7.m_Height};
            //  |  // // {name=val_0.m_XMin, type=System.Single, size=4, nSRN=0 }
            //  |  // // {name=val_0.m_YMin, type=System.Single, size=4, nSRN=1 }
            //  |  // // {name=val_0.m_Width, type=System.Single, size=4, nSRN=2 }
            //  |  // // {name=val_0.m_Height, type=System.Single, size=4, nSRN=3 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01687460 (23622752), len: 68  VirtAddr: 0x01687460 RVA: 0x01687460 token: 100683186 methodIndex: 49908 delegateWrapperIndex: 0 methodInvoker: 0
        private static float RectArea(UnityEngine.Rect r)
        {
            //
            // Disasemble & Code
            // 0x01687460: STP d9, d8, [sp, #-0x20]!  | stack[1152921513415349584] = ???;  stack[1152921513415349592] = ???;  //  dest_result_addr=1152921513415349584 |  dest_result_addr=1152921513415349592
            // 0x01687464: STP x29, x30, [sp, #0x10]  | stack[1152921513415349600] = ???;  stack[1152921513415349608] = ???;  //  dest_result_addr=1152921513415349600 |  dest_result_addr=1152921513415349608
            // 0x01687468: ADD x29, sp, #0x10         | X29 = (1152921513415349584 + 16) = 1152921513415349600 (0x100000020D071560);
            // 0x0168746C: STP s0, s1, [sp, #-0x10]!  | stack[1152921513415349568] = r.m_XMin;  stack[1152921513415349572] = r.m_YMin;  //  dest_result_addr=1152921513415349568 |  dest_result_addr=1152921513415349572
            // 0x01687470: MOV x0, sp                 | X0 = 1152921513415349568 (0x100000020D071540);//ML01
            // 0x01687474: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687478: STP s2, s3, [sp, #8]       | stack[1152921513415349576] = r.m_Width;  stack[1152921513415349580] = r.m_Height;  //  dest_result_addr=1152921513415349576 |  dest_result_addr=1152921513415349580
            // 0x0168747C: BL #0x1b819b4              | X0 = label_UnityEngine_Rect_set_max_GL01B819B4();
            // 0x01687480: MOV x0, sp                 | X0 = 1152921513415349568 (0x100000020D071540);//ML01
            // 0x01687484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01687488: MOV v8.16b, v0.16b         | V8 = r.m_XMin;//m1                      
            // 0x0168748C: BL #0x1b819d4              | X0 = label_UnityEngine_Rect_set_width_GL01B819D4();
            // 0x01687490: FMUL s0, s8, s0            | S0 = (r.m_XMin * r.m_XMin);             
            r.m_XMin = r.m_XMin * r.m_XMin;
            // 0x01687494: SUB sp, x29, #0x10         | SP = (1152921513415349600 - 16) = 1152921513415349584 (0x100000020D071550);
            // 0x01687498: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168749C: LDP d9, d8, [sp], #0x20    | D9 = ; D8 = ;                            //  | 
            // 0x016874A0: RET                        |  return (System.Single)(r.m_XMin * r.m_XMin);
            return (float)r.m_XMin;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
    
    }

}
