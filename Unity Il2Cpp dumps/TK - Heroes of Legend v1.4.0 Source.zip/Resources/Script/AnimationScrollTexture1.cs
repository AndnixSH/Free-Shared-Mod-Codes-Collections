using UnityEngine;
[Serializable]
public class AnimationScrollTexture1 : MonoBehaviour
{
    // Fields
    public float Speed; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02790984 (41486724), len: 44  VirtAddr: 0x02790984 RVA: 0x02790984 token: 100663297 methodIndex: 57660 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimationScrollTexture1()
    {
        //
        // Disasemble & Code
        // 0x02790984: STP x20, x19, [sp, #-0x20]! | stack[1152921515608988736] = ???;  stack[1152921515608988744] = ???;  //  dest_result_addr=1152921515608988736 |  dest_result_addr=1152921515608988744
        // 0x02790988: STP x29, x30, [sp, #0x10]  | stack[1152921515608988752] = ???;  stack[1152921515608988760] = ???;  //  dest_result_addr=1152921515608988752 |  dest_result_addr=1152921515608988760
        // 0x0279098C: ADD x29, sp, #0x10         | X29 = (1152921515608988736 + 16) = 1152921515608988752 (0x100000028FC75C50);
        // 0x02790990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790994: MOV x19, x0                | X19 = 1152921515609000768 (0x100000028FC78B40);//ML01
        // 0x02790998: BL #0x1b76fd4              | this..ctor();                           
        // 0x0279099C: MOVZ w8, #0x3e80, lsl #16  | W8 = 1048576000 (0x3E800000);//ML01     
        // 0x027909A0: STR w8, [x19, #0x18]       | this.Speed = 0.25;                       //  dest_result_addr=1152921515609000792
        this.Speed = 0.25f;
        // 0x027909A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x027909A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x027909AC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x027909B0 (41486768), len: 196  VirtAddr: 0x027909B0 RVA: 0x027909B0 token: 100663298 methodIndex: 57661 delegateWrapperIndex: 0 methodInvoker: 0
    public override void FixedUpdate()
    {
        //
        // Disasemble & Code
        // 0x027909B0: STP d9, d8, [sp, #-0x30]!  | stack[1152921515609108912] = ???;  stack[1152921515609108920] = ???;  //  dest_result_addr=1152921515609108912 |  dest_result_addr=1152921515609108920
        // 0x027909B4: STP x20, x19, [sp, #0x10]  | stack[1152921515609108928] = ???;  stack[1152921515609108936] = ???;  //  dest_result_addr=1152921515609108928 |  dest_result_addr=1152921515609108936
        // 0x027909B8: STP x29, x30, [sp, #0x20]  | stack[1152921515609108944] = ???;  stack[1152921515609108952] = ???;  //  dest_result_addr=1152921515609108944 |  dest_result_addr=1152921515609108952
        // 0x027909BC: ADD x29, sp, #0x20         | X29 = (1152921515609108912 + 32) = 1152921515609108944 (0x100000028FC931D0);
        // 0x027909C0: SUB sp, sp, #0x10          | SP = (1152921515609108912 - 16) = 1152921515609108896 (0x100000028FC931A0);
        // 0x027909C4: ADRP x20, #0x3745000       | X20 = 57954304 (0x3745000);             
        // 0x027909C8: LDRB w8, [x20, #0x9d8]     | W8 = (bool)static_value_037459D8;       
        // 0x027909CC: MOV x19, x0                | X19 = 1152921515609120960 (0x100000028FC960C0);//ML01
        // 0x027909D0: TBNZ w8, #0, #0x27909ec    | if (static_value_037459D8 == true) goto label_0;
        // 0x027909D4: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x027909D8: LDR x8, [x8, #0xdb0]       | X8 = 0x2B8AF00;                         
        // 0x027909DC: LDR w0, [x8]               | W0 = 0x27E;                             
        // 0x027909E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x27E, ????);      
        // 0x027909E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x027909E8: STRB w8, [x20, #0x9d8]     | static_value_037459D8 = true;            //  dest_result_addr=57956824
        label_0:
        // 0x027909EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x027909F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x027909F4: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x027909F8: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x027909FC: LDR s1, [x19, #0x18]       | S1 = this.Speed; //P2                   
        // 0x02790A00: LDR x8, [x8, #0x8c8]       | X8 = 1152921513055923456;               
        // 0x02790A04: MOV x0, x19                | X0 = 1152921515609120960 (0x100000028FC960C0);//ML01
        // 0x02790A08: FNMUL s8, s0, s1           | S8 = (val_1 * this.Speed);              
        float val_2 = -(val_1 * this.Speed);
        // 0x02790A0C: LDR x1, [x8]               | X1 = public UnityEngine.Renderer UnityEngine.Component::GetComponent<UnityEngine.Renderer>();
        // 0x02790A10: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Renderer>();
        UnityEngine.Renderer val_3 = this.GetComponent<UnityEngine.Renderer>();
        // 0x02790A14: MOV x19, x0                | X19 = val_3;//m1                        
        // 0x02790A18: CBNZ x19, #0x2790a20       | if (val_3 != null) goto label_1;        
        if(val_3 != null)
        {
            goto label_1;
        }
        // 0x02790A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_1:
        // 0x02790A20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790A24: MOV x0, x19                | X0 = val_3;//m1                         
        // 0x02790A28: BL #0x1b863a4              | X0 = val_3.get_material();              
        UnityEngine.Material val_4 = val_3.material;
        // 0x02790A2C: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x02790A30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790A34: FMOV s0, wzr               | S0 = 0f;                                
        // 0x02790A38: ADD x0, sp, #8             | X0 = (1152921515609108896 + 8) = 1152921515609108904 (0x100000028FC931A8);
        // 0x02790A3C: MOV v1.16b, v8.16b         | V1 = (val_1 * this.Speed);//m1          
        // 0x02790A40: STR xzr, [sp, #8]          | stack[1152921515609108904] = 0x0;        //  dest_result_addr=1152921515609108904
        // 0x02790A44: BL #0x2697148              | null..ctor(_x:  0f, _y:  val_2);        
        Geometric.Point val_5 = new Geometric.Point(_x:  0f, _y:  val_2);
        // 0x02790A48: CBNZ x19, #0x2790a50       | if (val_4 != null) goto label_2;        
        if(val_4 != null)
        {
            goto label_2;
        }
        // 0x02790A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? null..ctor(_x:  0f, _y:  val_2), ????);
        label_2:
        // 0x02790A50: LDP s0, s1, [sp, #8]       | S0 = val_5.x; S1 = val_5.y;              //  | 
        // 0x02790A54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02790A58: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x02790A5C: BL #0x1a7818c              | val_4.set_mainTextureOffset(value:  new UnityEngine.Vector2() {x = val_5.x, y = val_5.y});
        val_4.mainTextureOffset = new UnityEngine.Vector2() {x = val_5.x, y = val_5.y};
        // 0x02790A60: SUB sp, x29, #0x20         | SP = (1152921515609108944 - 32) = 1152921515609108912 (0x100000028FC931B0);
        // 0x02790A64: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02790A68: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02790A6C: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x02790A70: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02790A74 (41486964), len: 4  VirtAddr: 0x02790A74 RVA: 0x02790A74 token: 100663299 methodIndex: 57662 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02790A74: RET                        |  return;                                
        return;
    
    }

}
