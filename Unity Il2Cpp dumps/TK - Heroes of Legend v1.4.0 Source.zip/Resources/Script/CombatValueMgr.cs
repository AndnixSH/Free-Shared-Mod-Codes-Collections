using UnityEngine;
public class CombatValueMgr : IZUpdate
{
    // Fields
    public float value01; //  0x00000010
    public float value02; //  0x00000014
    public float value03; //  0x00000018
    public float value04; //  0x0000001C
    public float value05; //  0x00000020
    public float value06; //  0x00000024
    public float value07; //  0x00000028
    public uint value08; //  0x0000002C
    public float value09; //  0x00000030
    public float value10; //  0x00000034
    public float value11; //  0x00000038
    public float value12; //  0x0000003C
    public float value13; //  0x00000040
    private float timer; //  0x00000044
    private CEvent.ZEvent notifyTest; //  0x00000048
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B4158C (11801996), len: 192  VirtAddr: 0x00B4158C RVA: 0x00B4158C token: 100693329 methodIndex: 26633 delegateWrapperIndex: 0 methodInvoker: 0
    public CombatValueMgr()
    {
        //
        // Disasemble & Code
        // 0x00B4158C: STP x20, x19, [sp, #-0x20]! | stack[1152921514973103728] = ???;  stack[1152921514973103736] = ???;  //  dest_result_addr=1152921514973103728 |  dest_result_addr=1152921514973103736
        // 0x00B41590: STP x29, x30, [sp, #0x10]  | stack[1152921514973103744] = ???;  stack[1152921514973103752] = ???;  //  dest_result_addr=1152921514973103744 |  dest_result_addr=1152921514973103752
        // 0x00B41594: ADD x29, sp, #0x10         | X29 = (1152921514973103728 + 16) = 1152921514973103744 (0x1000000269E08680);
        // 0x00B41598: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B4159C: LDRB w8, [x20, #0x7e8]     | W8 = (bool)static_value_037337E8;       
        // 0x00B415A0: MOV x19, x0                | X19 = 1152921514973115760 (0x1000000269E0B570);//ML01
        // 0x00B415A4: TBNZ w8, #0, #0xb415c0     | if (static_value_037337E8 == true) goto label_0;
        // 0x00B415A8: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00B415AC: LDR x8, [x8, #0xa08]       | X8 = 0x2B92340;                         
        // 0x00B415B0: LDR w0, [x8]               | W0 = 0x1F95;                            
        // 0x00B415B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F95, ????);     
        // 0x00B415B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B415BC: STRB w8, [x20, #0x7e8]     | static_value_037337E8 = true;            //  dest_result_addr=57882600
        label_0:
        // 0x00B415C0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B415C4: ADRP x12, #0x2a92000       | X12 = 44638208 (0x2A92000);             
        // 0x00B415C8: LDR q0, [x8, #0xba0]       | Q0 = ;                                  
        // 0x00B415CC: LDR q1, [x12, #0xbb0]      | Q1 = ;                                  
        // 0x00B415D0: MOVZ w9, #0x3f4c, lsl #16  | W9 = 1061945344 (0x3F4C0000);//ML01     
        // 0x00B415D4: MOVZ w10, #0x3f66, lsl #16 | W10 = 1063649280 (0x3F660000);//ML01    
        // 0x00B415D8: MOVZ w11, #0x3f8c, lsl #16 | W11 = 1066139648 (0x3F8C0000);//ML01    
        // 0x00B415DC: MOVZ w13, #0x3ca3, lsl #16 | W13 = 1017315328 (0x3CA30000);//ML01    
        // 0x00B415E0: MOVK w9, #0xcccd           | W9 = 1061997773 (0x3F4CCCCD);           
        // 0x00B415E4: MOVK w10, #0x6666          | W10 = 1063675494 (0x3F666666);          
        // 0x00B415E8: MOVK w11, #0xcccd          | W11 = 1066192077 (0x3F8CCCCD);          
        // 0x00B415EC: MOVK w13, #0xd70a          | W13 = 1017370378 (0x3CA3D70A);          
        // 0x00B415F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B415F4: MOV x0, x19                | X0 = 1152921514973115760 (0x1000000269E0B570);//ML01
        // 0x00B415F8: STR w9, [x19, #0x20]       | this.value05 = 0.8;                      //  dest_result_addr=1152921514973115792
        this.value05 = 0.8f;
        // 0x00B415FC: STP w10, w11, [x19, #0x24] | this.value06 = 0.9;  this.value07 = 1.1;  //  dest_result_addr=1152921514973115796 |  dest_result_addr=1152921514973115800
        this.value06 = 0.9f;
        this.value07 = 1.1f;
        // 0x00B41600: STR q0, [x19, #0x10]       | this.value01 = ; this.value02 = ; this.value03 = 1; this.value04 = 0.2;  //  dest_result_addr=1152921514973115776 dest_result_addr=1152921514973115780 dest_result_addr=1152921514973115784 dest_result_addr=1152921514973115788
        this.value01 = ;
        this.value02 = ;
        this.value03 = 1f;
        this.value04 = 0.2f;
        // 0x00B41604: STR q1, [x19, #0x30]       | this.value09 = ; this.value10 = ; this.value11 = 0.005; this.value12 = 50;  //  dest_result_addr=1152921514973115808 dest_result_addr=1152921514973115812 dest_result_addr=1152921514973115816 dest_result_addr=1152921514973115820
        this.value09 = ;
        this.value10 = ;
        this.value11 = 0.005f;
        this.value12 = 50f;
        // 0x00B41608: STR w13, [x19, #0x40]      | this.value13 = 0.02;                     //  dest_result_addr=1152921514973115824
        this.value13 = 0.02f;
        // 0x00B4160C: BL #0x16f59f0              | this..ctor();                           
        // 0x00B41610: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B41614: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B41618: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        CEvent.ZEvent val_1 = null;
        // 0x00B4161C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B41620: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00B41624: LDR x8, [x8, #0xd00]       | X8 = (string**)(1152921514973091664)("NotifyTest");
        // 0x00B41628: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B4162C: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B41630: LDR x1, [x8]               | X1 = "NotifyTest";                      
        // 0x00B41634: BL #0xd80ce8               | .ctor(name:  "NotifyTest");             
        val_1 = new CEvent.ZEvent(name:  "NotifyTest");
        // 0x00B41638: STR x20, [x19, #0x48]      | this.notifyTest = typeof(CEvent.ZEvent);  //  dest_result_addr=1152921514973115832
        this.notifyTest = val_1;
        // 0x00B4163C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B41640: MOV x0, x19                | X0 = 1152921514973115760 (0x1000000269E0B570);//ML01
        // 0x00B41644: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B41648: B #0xb4164c                | this.AddUpdate(); return;               
        this.AddUpdate();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B4164C (11802188), len: 108  VirtAddr: 0x00B4164C RVA: 0x00B4164C token: 100693330 methodIndex: 26634 delegateWrapperIndex: 0 methodInvoker: 0
    public void AddUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B4164C: STP x20, x19, [sp, #-0x20]! | stack[1152921514973215728] = ???;  stack[1152921514973215736] = ???;  //  dest_result_addr=1152921514973215728 |  dest_result_addr=1152921514973215736
        // 0x00B41650: STP x29, x30, [sp, #0x10]  | stack[1152921514973215744] = ???;  stack[1152921514973215752] = ???;  //  dest_result_addr=1152921514973215744 |  dest_result_addr=1152921514973215752
        // 0x00B41654: ADD x29, sp, #0x10         | X29 = (1152921514973215728 + 16) = 1152921514973215744 (0x1000000269E23C00);
        // 0x00B41658: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B4165C: LDRB w8, [x20, #0x7e9]     | W8 = (bool)static_value_037337E9;       
        // 0x00B41660: MOV x19, x0                | X19 = 1152921514973227760 (0x1000000269E26AF0);//ML01
        // 0x00B41664: TBNZ w8, #0, #0xb41680     | if (static_value_037337E9 == true) goto label_0;
        // 0x00B41668: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00B4166C: LDR x8, [x8, #0x360]       | X8 = 0x2B92344;                         
        // 0x00B41670: LDR w0, [x8]               | W0 = 0x1F96;                            
        // 0x00B41674: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F96, ????);     
        // 0x00B41678: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B4167C: STRB w8, [x20, #0x7e9]     | static_value_037337E9 = true;            //  dest_result_addr=57882601
        label_0:
        // 0x00B41680: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x00B41684: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
        // 0x00B41688: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
        // 0x00B4168C: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B41690: TBZ w8, #0, #0xb416a0      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B41694: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B41698: CBNZ w8, #0xb416a0         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B4169C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        label_2:
        // 0x00B416A0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B416A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B416A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B416AC: MOV x1, x19                | X1 = 1152921514973227760 (0x1000000269E26AF0);//ML01
        // 0x00B416B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B416B4: B #0xb14d7c                | AllUpdate.AddUpdate(update:  0); return;
        AllUpdate.AddUpdate(update:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B416B8 (11802296), len: 1408  VirtAddr: 0x00B416B8 RVA: 0x00B416B8 token: 100693331 methodIndex: 26635 delegateWrapperIndex: 0 methodInvoker: 0
    public void ZUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        CEvent.ZEvent val_2;
        // 0x00B416B8: STP d9, d8, [sp, #-0x40]!  | stack[1152921514973389136] = ???;  stack[1152921514973389144] = ???;  //  dest_result_addr=1152921514973389136 |  dest_result_addr=1152921514973389144
        // 0x00B416BC: STP x22, x21, [sp, #0x10]  | stack[1152921514973389152] = ???;  stack[1152921514973389160] = ???;  //  dest_result_addr=1152921514973389152 |  dest_result_addr=1152921514973389160
        // 0x00B416C0: STP x20, x19, [sp, #0x20]  | stack[1152921514973389168] = ???;  stack[1152921514973389176] = ???;  //  dest_result_addr=1152921514973389168 |  dest_result_addr=1152921514973389176
        // 0x00B416C4: STP x29, x30, [sp, #0x30]  | stack[1152921514973389184] = ???;  stack[1152921514973389192] = ???;  //  dest_result_addr=1152921514973389184 |  dest_result_addr=1152921514973389192
        // 0x00B416C8: ADD x29, sp, #0x30         | X29 = (1152921514973389136 + 48) = 1152921514973389184 (0x1000000269E4E180);
        // 0x00B416CC: SUB sp, sp, #0x40          | SP = (1152921514973389136 - 64) = 1152921514973389072 (0x1000000269E4E110);
        // 0x00B416D0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B416D4: LDRB w8, [x20, #0x7ea]     | W8 = (bool)static_value_037337EA;       
        // 0x00B416D8: MOV x19, x0                | X19 = 1152921514973401200 (0x1000000269E51070);//ML01
        val_2 = this;
        // 0x00B416DC: TBNZ w8, #0, #0xb416f8     | if (static_value_037337EA == true) goto label_0;
        // 0x00B416E0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B416E4: LDR x8, [x8, #0xfe8]       | X8 = 0x2B92348;                         
        // 0x00B416E8: LDR w0, [x8]               | W0 = 0x1F97;                            
        // 0x00B416EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1F97, ????);     
        // 0x00B416F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B416F4: STRB w8, [x20, #0x7ea]     | static_value_037337EA = true;            //  dest_result_addr=57882602
        label_0:
        // 0x00B416F8: LDR s8, [x19, #0x44]       | S8 = this.timer; //P2                   
        // 0x00B416FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B41700: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41704: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_1 = UnityEngine.Time.deltaTime;
        // 0x00B41708: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B4170C: LDR d1, [x8, #0xbe0]       | D1 = 3.14159265358979;                  
        // 0x00B41710: FADD s0, s8, s0            | S0 = (this.timer + val_1);              
        val_1 = this.timer + val_1;
        // 0x00B41714: STR s0, [x19, #0x44]       | this.timer = (this.timer + val_1);       //  dest_result_addr=1152921514973401268
        this.timer = val_1;
        // 0x00B41718: FCVT d0, s0                | D0 = (double)(this.timer + val_1));     
        // 0x00B4171C: FCMP d0, d1                | STATE = COMPARE((this.timer + val_1), 3370280550400)
        // 0x00B41720: B.LE #0xb41c20             | if ((double)val_1 = this.timer + val_1 <= 3.14159265358979) goto label_1;
        if((double)val_1 <= 3.14159265358979)
        {
            goto label_1;
        }
        // 0x00B41724: STR wzr, [x19, #0x44]      | this.timer = 0;                          //  dest_result_addr=1152921514973401268
        this.timer = 0f;
        // 0x00B41728: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B4172C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B41730: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
        // 0x00B41734: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B41738: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B4173C: MOVZ w1, #0xd              | W1 = 13 (0xD);//ML01                    
        // 0x00B41740: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B41744: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B41748: ADRP x22, #0x35e6000       | X22 = 56516608 (0x35E6000);             
        // 0x00B4174C: LDR w9, [x19, #0x10]       | W9 = this.value01; //P2                 
        // 0x00B41750: LDR x22, [x22, #0xce8]     | X22 = 1152921504608444416;              
        // 0x00B41754: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B41758: SUB x1, x29, #0x34         | X1 = (1152921514973389184 - 52) = 1152921514973389132 (0x1000000269E4E14C);
        // 0x00B4175C: STUR w9, [x29, #-0x34]     | stack[1152921514973389132] = this.value01;  //  dest_result_addr=1152921514973389132
        // 0x00B41760: LDR x8, [x22]              | X8 = typeof(System.Single);             
        // 0x00B41764: MOV x0, x8                 | X0 = 1152921504608444416 (0x1000000000186000);//ML01
        // 0x00B41768: BL #0x27bc028              | X0 = 1152921514973433200 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value01);
        // 0x00B4176C: MOV x21, x0                | X21 = 1152921514973433200 (0x1000000269E58D70);//ML01
        // 0x00B41770: CBNZ x20, #0xb41778        | if ( != null) goto label_2;             
        if(null != null)
        {
            goto label_2;
        }
        // 0x00B41774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.value01, ????);
        label_2:
        // 0x00B41778: CBZ x21, #0xb4179c         | if (this.value01 == 0) goto label_4;    
        if(this.value01 == 0)
        {
            goto label_4;
        }
        // 0x00B4177C: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41780: MOV x0, x21                | X0 = 1152921514973433200 (0x1000000269E58D70);//ML01
        // 0x00B41784: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41788: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value01, ????);
        // 0x00B4178C: CBNZ x0, #0xb4179c         | if (this.value01 != 0) goto label_4;    
        if(this.value01 != 0)
        {
            goto label_4;
        }
        // 0x00B41790: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value01, ????);
        // 0x00B41794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41798: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value01, ????);
        label_4:
        // 0x00B4179C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B417A0: CBNZ w8, #0xb417b0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_5;
        // 0x00B417A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value01, ????);
        // 0x00B417A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B417AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value01, ????);
        label_5:
        // 0x00B417B0: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this.value01; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = this.value01;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00B417B4: LDR w8, [x19, #0x14]       | W8 = this.value02; //P2                 
        // 0x00B417B8: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B417BC: ADD x1, sp, #0x38          | X1 = (1152921514973389072 + 56) = 1152921514973389128 (0x1000000269E4E148);
        // 0x00B417C0: STR w8, [sp, #0x38]        | stack[1152921514973389128] = this.value02;  //  dest_result_addr=1152921514973389128
        // 0x00B417C4: BL #0x27bc028              | X0 = 1152921514973437296 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value02);
        // 0x00B417C8: MOV x21, x0                | X21 = 1152921514973437296 (0x1000000269E59D70);//ML01
        // 0x00B417CC: CBZ x21, #0xb417f0         | if (this.value02 == 0) goto label_7;    
        if(this.value02 == 0)
        {
            goto label_7;
        }
        // 0x00B417D0: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B417D4: MOV x0, x21                | X0 = 1152921514973437296 (0x1000000269E59D70);//ML01
        // 0x00B417D8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B417DC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value02, ????);
        // 0x00B417E0: CBNZ x0, #0xb417f0         | if (this.value02 != 0) goto label_7;    
        if(this.value02 != 0)
        {
            goto label_7;
        }
        // 0x00B417E4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value02, ????);
        // 0x00B417E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B417EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value02, ????);
        label_7:
        // 0x00B417F0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B417F4: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B417F8: B.HI #0xb41808             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_8;
        // 0x00B417FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value02, ????);
        // 0x00B41800: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41804: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value02, ????);
        label_8:
        // 0x00B41808: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = this.value02; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = this.value02;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B4180C: LDR w8, [x19, #0x18]       | W8 = this.value03; //P2                 
        // 0x00B41810: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41814: ADD x1, sp, #0x34          | X1 = (1152921514973389072 + 52) = 1152921514973389124 (0x1000000269E4E144);
        // 0x00B41818: STR w8, [sp, #0x34]        | stack[1152921514973389124] = this.value03;  //  dest_result_addr=1152921514973389124
        // 0x00B4181C: BL #0x27bc028              | X0 = 1152921514973441392 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value03);
        // 0x00B41820: MOV x21, x0                | X21 = 1152921514973441392 (0x1000000269E5AD70);//ML01
        // 0x00B41824: CBZ x21, #0xb41848         | if (this.value03 == 0) goto label_10;   
        if(this.value03 == 0)
        {
            goto label_10;
        }
        // 0x00B41828: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B4182C: MOV x0, x21                | X0 = 1152921514973441392 (0x1000000269E5AD70);//ML01
        // 0x00B41830: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41834: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value03, ????);
        // 0x00B41838: CBNZ x0, #0xb41848         | if (this.value03 != 0) goto label_10;   
        if(this.value03 != 0)
        {
            goto label_10;
        }
        // 0x00B4183C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value03, ????);
        // 0x00B41840: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41844: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value03, ????);
        label_10:
        // 0x00B41848: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B4184C: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B41850: B.HI #0xb41860             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_11;
        // 0x00B41854: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value03, ????);
        // 0x00B41858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B4185C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value03, ????);
        label_11:
        // 0x00B41860: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = this.value03; typeof(System.Object[]).__il2cppRuntimeField_34 = 0x10000002;  //  dest_result_addr=1152921504954501312 dest_result_addr=1152921504954501316
        typeof(System.Object[]).__il2cppRuntimeField_30 = this.value03;
        typeof(System.Object[]).__il2cppRuntimeField_34 = 268435458;
        // 0x00B41864: LDR w8, [x19, #0x1c]       | W8 = this.value04; //P2                 
        // 0x00B41868: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B4186C: ADD x1, sp, #0x30          | X1 = (1152921514973389072 + 48) = 1152921514973389120 (0x1000000269E4E140);
        // 0x00B41870: STR w8, [sp, #0x30]        | stack[1152921514973389120] = this.value04;  //  dest_result_addr=1152921514973389120
        // 0x00B41874: BL #0x27bc028              | X0 = 1152921514973445488 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value04);
        // 0x00B41878: MOV x21, x0                | X21 = 1152921514973445488 (0x1000000269E5BD70);//ML01
        // 0x00B4187C: CBZ x21, #0xb418a0         | if (this.value04 == 0) goto label_13;   
        if(this.value04 == 0)
        {
            goto label_13;
        }
        // 0x00B41880: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41884: MOV x0, x21                | X0 = 1152921514973445488 (0x1000000269E5BD70);//ML01
        // 0x00B41888: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B4188C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value04, ????);
        // 0x00B41890: CBNZ x0, #0xb418a0         | if (this.value04 != 0) goto label_13;   
        if(this.value04 != 0)
        {
            goto label_13;
        }
        // 0x00B41894: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value04, ????);
        // 0x00B41898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B4189C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value04, ????);
        label_13:
        // 0x00B418A0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B418A4: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x00B418A8: B.HI #0xb418b8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_14;
        // 0x00B418AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value04, ????);
        // 0x00B418B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B418B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value04, ????);
        label_14:
        // 0x00B418B8: STR x21, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = this.value04; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000002;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
        typeof(System.Object[]).__il2cppRuntimeField_38 = this.value04;
        typeof(System.Object[]).__il2cppRuntimeField_3C = 268435458;
        // 0x00B418BC: LDR w8, [x19, #0x20]       | W8 = this.value05; //P2                 
        // 0x00B418C0: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B418C4: ADD x1, sp, #0x2c          | X1 = (1152921514973389072 + 44) = 1152921514973389116 (0x1000000269E4E13C);
        // 0x00B418C8: STR w8, [sp, #0x2c]        | stack[1152921514973389116] = this.value05;  //  dest_result_addr=1152921514973389116
        // 0x00B418CC: BL #0x27bc028              | X0 = 1152921514973449584 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value05);
        // 0x00B418D0: MOV x21, x0                | X21 = 1152921514973449584 (0x1000000269E5CD70);//ML01
        // 0x00B418D4: CBZ x21, #0xb418f8         | if (this.value05 == 0) goto label_16;   
        if(this.value05 == 0)
        {
            goto label_16;
        }
        // 0x00B418D8: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B418DC: MOV x0, x21                | X0 = 1152921514973449584 (0x1000000269E5CD70);//ML01
        // 0x00B418E0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B418E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value05, ????);
        // 0x00B418E8: CBNZ x0, #0xb418f8         | if (this.value05 != 0) goto label_16;   
        if(this.value05 != 0)
        {
            goto label_16;
        }
        // 0x00B418EC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value05, ????);
        // 0x00B418F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B418F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value05, ????);
        label_16:
        // 0x00B418F8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B418FC: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
        // 0x00B41900: B.HI #0xb41910             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_17;
        // 0x00B41904: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value05, ????);
        // 0x00B41908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B4190C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value05, ????);
        label_17:
        // 0x00B41910: STR x21, [x20, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = this.value05; typeof(System.Object[]).__il2cppRuntimeField_44 = 0x10000002;  //  dest_result_addr=1152921504954501328 dest_result_addr=1152921504954501332
        typeof(System.Object[]).__il2cppRuntimeField_40 = this.value05;
        typeof(System.Object[]).__il2cppRuntimeField_44 = 268435458;
        // 0x00B41914: LDR w8, [x19, #0x24]       | W8 = this.value06; //P2                 
        // 0x00B41918: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B4191C: ADD x1, sp, #0x28          | X1 = (1152921514973389072 + 40) = 1152921514973389112 (0x1000000269E4E138);
        // 0x00B41920: STR w8, [sp, #0x28]        | stack[1152921514973389112] = this.value06;  //  dest_result_addr=1152921514973389112
        // 0x00B41924: BL #0x27bc028              | X0 = 1152921514973453680 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value06);
        // 0x00B41928: MOV x21, x0                | X21 = 1152921514973453680 (0x1000000269E5DD70);//ML01
        // 0x00B4192C: CBZ x21, #0xb41950         | if (this.value06 == 0) goto label_19;   
        if(this.value06 == 0)
        {
            goto label_19;
        }
        // 0x00B41930: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41934: MOV x0, x21                | X0 = 1152921514973453680 (0x1000000269E5DD70);//ML01
        // 0x00B41938: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B4193C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value06, ????);
        // 0x00B41940: CBNZ x0, #0xb41950         | if (this.value06 != 0) goto label_19;   
        if(this.value06 != 0)
        {
            goto label_19;
        }
        // 0x00B41944: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value06, ????);
        // 0x00B41948: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B4194C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value06, ????);
        label_19:
        // 0x00B41950: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41954: CMP w8, #5                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x5)
        // 0x00B41958: B.HI #0xb41968             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x5) goto label_20;
        // 0x00B4195C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value06, ????);
        // 0x00B41960: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41964: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value06, ????);
        label_20:
        // 0x00B41968: STR x21, [x20, #0x48]      | typeof(System.Object[]).__il2cppRuntimeField_48 = this.value06; typeof(System.Object[]).__il2cppRuntimeField_4C = 0x10000002;  //  dest_result_addr=1152921504954501336 dest_result_addr=1152921504954501340
        typeof(System.Object[]).__il2cppRuntimeField_48 = this.value06;
        typeof(System.Object[]).__il2cppRuntimeField_4C = 268435458;
        // 0x00B4196C: LDR w8, [x19, #0x28]       | W8 = this.value07; //P2                 
        // 0x00B41970: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41974: ADD x1, sp, #0x24          | X1 = (1152921514973389072 + 36) = 1152921514973389108 (0x1000000269E4E134);
        // 0x00B41978: STR w8, [sp, #0x24]        | stack[1152921514973389108] = this.value07;  //  dest_result_addr=1152921514973389108
        // 0x00B4197C: BL #0x27bc028              | X0 = 1152921514973457776 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value07);
        // 0x00B41980: MOV x21, x0                | X21 = 1152921514973457776 (0x1000000269E5ED70);//ML01
        // 0x00B41984: CBZ x21, #0xb419a8         | if (this.value07 == 0) goto label_22;   
        if(this.value07 == 0)
        {
            goto label_22;
        }
        // 0x00B41988: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B4198C: MOV x0, x21                | X0 = 1152921514973457776 (0x1000000269E5ED70);//ML01
        // 0x00B41990: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41994: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value07, ????);
        // 0x00B41998: CBNZ x0, #0xb419a8         | if (this.value07 != 0) goto label_22;   
        if(this.value07 != 0)
        {
            goto label_22;
        }
        // 0x00B4199C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value07, ????);
        // 0x00B419A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B419A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value07, ????);
        label_22:
        // 0x00B419A8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B419AC: CMP w8, #6                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x6)
        // 0x00B419B0: B.HI #0xb419c0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x6) goto label_23;
        // 0x00B419B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value07, ????);
        // 0x00B419B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B419BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value07, ????);
        label_23:
        // 0x00B419C0: STR x21, [x20, #0x50]      | typeof(System.Object[]).__il2cppRuntimeField_50 = this.value07; typeof(System.Object[]).__il2cppRuntimeField_54 = 0x10000002;  //  dest_result_addr=1152921504954501344 dest_result_addr=1152921504954501348
        typeof(System.Object[]).__il2cppRuntimeField_50 = this.value07;
        typeof(System.Object[]).__il2cppRuntimeField_54 = 268435458;
        // 0x00B419C4: ADRP x9, #0x35e2000        | X9 = 56500224 (0x35E2000);              
        // 0x00B419C8: LDR w8, [x19, #0x2c]       | W8 = this.value08; //P2                 
        // 0x00B419CC: LDR x9, [x9, #0xe18]       | X9 = 1152921504607645696;               
        // 0x00B419D0: ADD x1, sp, #0x20          | X1 = (1152921514973389072 + 32) = 1152921514973389104 (0x1000000269E4E130);
        // 0x00B419D4: STR w8, [sp, #0x20]        | stack[1152921514973389104] = this.value08;  //  dest_result_addr=1152921514973389104
        // 0x00B419D8: LDR x0, [x9]               | X0 = typeof(System.UInt32);             
        // 0x00B419DC: BL #0x27bc028              | X0 = 1152921514973461872 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), this.value08);
        // 0x00B419E0: MOV x21, x0                | X21 = 1152921514973461872 (0x1000000269E5FD70);//ML01
        // 0x00B419E4: CBZ x21, #0xb41a08         | if (this.value08 == 0) goto label_25;   
        if(this.value08 == 0)
        {
            goto label_25;
        }
        // 0x00B419E8: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B419EC: MOV x0, x21                | X0 = 1152921514973461872 (0x1000000269E5FD70);//ML01
        // 0x00B419F0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B419F4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value08, ????);
        // 0x00B419F8: CBNZ x0, #0xb41a08         | if (this.value08 != 0) goto label_25;   
        if(this.value08 != 0)
        {
            goto label_25;
        }
        // 0x00B419FC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value08, ????);
        // 0x00B41A00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41A04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value08, ????);
        label_25:
        // 0x00B41A08: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41A0C: CMP w8, #7                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x7)
        // 0x00B41A10: B.HI #0xb41a20             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x7) goto label_26;
        // 0x00B41A14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value08, ????);
        // 0x00B41A18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41A1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value08, ????);
        label_26:
        // 0x00B41A20: STR x21, [x20, #0x58]      | typeof(System.Object[]).__il2cppRuntimeField_58 = this.value08; typeof(System.Object[]).__il2cppRuntimeField_5C = 0x10000002;  //  dest_result_addr=1152921504954501352 dest_result_addr=1152921504954501356
        typeof(System.Object[]).__il2cppRuntimeField_58 = this.value08;
        typeof(System.Object[]).__il2cppRuntimeField_5C = 268435458;
        // 0x00B41A24: LDR w8, [x19, #0x30]       | W8 = this.value09; //P2                 
        // 0x00B41A28: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41A2C: ADD x1, sp, #0x1c          | X1 = (1152921514973389072 + 28) = 1152921514973389100 (0x1000000269E4E12C);
        // 0x00B41A30: STR w8, [sp, #0x1c]        | stack[1152921514973389100] = this.value09;  //  dest_result_addr=1152921514973389100
        // 0x00B41A34: BL #0x27bc028              | X0 = 1152921514973465968 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value09);
        // 0x00B41A38: MOV x21, x0                | X21 = 1152921514973465968 (0x1000000269E60D70);//ML01
        // 0x00B41A3C: CBZ x21, #0xb41a60         | if (this.value09 == 0) goto label_28;   
        if(this.value09 == 0)
        {
            goto label_28;
        }
        // 0x00B41A40: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41A44: MOV x0, x21                | X0 = 1152921514973465968 (0x1000000269E60D70);//ML01
        // 0x00B41A48: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41A4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value09, ????);
        // 0x00B41A50: CBNZ x0, #0xb41a60         | if (this.value09 != 0) goto label_28;   
        if(this.value09 != 0)
        {
            goto label_28;
        }
        // 0x00B41A54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value09, ????);
        // 0x00B41A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41A5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value09, ????);
        label_28:
        // 0x00B41A60: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41A64: CMP w8, #8                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x8)
        // 0x00B41A68: B.HI #0xb41a78             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x8) goto label_29;
        // 0x00B41A6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value09, ????);
        // 0x00B41A70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41A74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value09, ????);
        label_29:
        // 0x00B41A78: STR x21, [x20, #0x60]      | typeof(System.Object[]).__il2cppRuntimeField_60 = this.value09; typeof(System.Object[]).__il2cppRuntimeField_64 = 0x10000002;  //  dest_result_addr=1152921504954501360 dest_result_addr=1152921504954501364
        typeof(System.Object[]).__il2cppRuntimeField_60 = this.value09;
        typeof(System.Object[]).__il2cppRuntimeField_64 = 268435458;
        // 0x00B41A7C: LDR w8, [x19, #0x34]       | W8 = this.value10; //P2                 
        // 0x00B41A80: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41A84: ADD x1, sp, #0x18          | X1 = (1152921514973389072 + 24) = 1152921514973389096 (0x1000000269E4E128);
        // 0x00B41A88: STR w8, [sp, #0x18]        | stack[1152921514973389096] = this.value10;  //  dest_result_addr=1152921514973389096
        // 0x00B41A8C: BL #0x27bc028              | X0 = 1152921514973470064 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value10);
        // 0x00B41A90: MOV x21, x0                | X21 = 1152921514973470064 (0x1000000269E61D70);//ML01
        // 0x00B41A94: CBZ x21, #0xb41ab8         | if (this.value10 == 0) goto label_31;   
        if(this.value10 == 0)
        {
            goto label_31;
        }
        // 0x00B41A98: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41A9C: MOV x0, x21                | X0 = 1152921514973470064 (0x1000000269E61D70);//ML01
        // 0x00B41AA0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41AA4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value10, ????);
        // 0x00B41AA8: CBNZ x0, #0xb41ab8         | if (this.value10 != 0) goto label_31;   
        if(this.value10 != 0)
        {
            goto label_31;
        }
        // 0x00B41AAC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value10, ????);
        // 0x00B41AB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41AB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value10, ????);
        label_31:
        // 0x00B41AB8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41ABC: CMP w8, #9                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x9)
        // 0x00B41AC0: B.HI #0xb41ad0             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x9) goto label_32;
        // 0x00B41AC4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value10, ????);
        // 0x00B41AC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41ACC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value10, ????);
        label_32:
        // 0x00B41AD0: STR x21, [x20, #0x68]      | typeof(System.Object[]).__il2cppRuntimeField_68 = this.value10; typeof(System.Object[]).__il2cppRuntimeField_6C = 0x10000002;  //  dest_result_addr=1152921504954501368 dest_result_addr=1152921504954501372
        typeof(System.Object[]).__il2cppRuntimeField_68 = this.value10;
        typeof(System.Object[]).__il2cppRuntimeField_6C = 268435458;
        // 0x00B41AD4: LDR w8, [x19, #0x38]       | W8 = this.value11; //P2                 
        // 0x00B41AD8: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41ADC: ADD x1, sp, #0x14          | X1 = (1152921514973389072 + 20) = 1152921514973389092 (0x1000000269E4E124);
        // 0x00B41AE0: STR w8, [sp, #0x14]        | stack[1152921514973389092] = this.value11;  //  dest_result_addr=1152921514973389092
        // 0x00B41AE4: BL #0x27bc028              | X0 = 1152921514973474160 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value11);
        // 0x00B41AE8: MOV x21, x0                | X21 = 1152921514973474160 (0x1000000269E62D70);//ML01
        // 0x00B41AEC: CBZ x21, #0xb41b10         | if (this.value11 == 0) goto label_34;   
        if(this.value11 == 0)
        {
            goto label_34;
        }
        // 0x00B41AF0: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41AF4: MOV x0, x21                | X0 = 1152921514973474160 (0x1000000269E62D70);//ML01
        // 0x00B41AF8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41AFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value11, ????);
        // 0x00B41B00: CBNZ x0, #0xb41b10         | if (this.value11 != 0) goto label_34;   
        if(this.value11 != 0)
        {
            goto label_34;
        }
        // 0x00B41B04: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value11, ????);
        // 0x00B41B08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41B0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value11, ????);
        label_34:
        // 0x00B41B10: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41B14: CMP w8, #0xa               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xA)
        // 0x00B41B18: B.HI #0xb41b28             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xA) goto label_35;
        // 0x00B41B1C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value11, ????);
        // 0x00B41B20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41B24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value11, ????);
        label_35:
        // 0x00B41B28: STR x21, [x20, #0x70]      | typeof(System.Object[]).__il2cppRuntimeField_70 = this.value11; typeof(System.Object[]).__il2cppRuntimeField_74 = 0x10000002;  //  dest_result_addr=1152921504954501376 dest_result_addr=1152921504954501380
        typeof(System.Object[]).__il2cppRuntimeField_70 = this.value11;
        typeof(System.Object[]).__il2cppRuntimeField_74 = 268435458;
        // 0x00B41B2C: LDR w8, [x19, #0x3c]       | W8 = this.value12; //P2                 
        // 0x00B41B30: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41B34: ADD x1, sp, #0x10          | X1 = (1152921514973389072 + 16) = 1152921514973389088 (0x1000000269E4E120);
        // 0x00B41B38: STR w8, [sp, #0x10]        | stack[1152921514973389088] = this.value12;  //  dest_result_addr=1152921514973389088
        // 0x00B41B3C: BL #0x27bc028              | X0 = 1152921514973478256 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value12);
        // 0x00B41B40: MOV x21, x0                | X21 = 1152921514973478256 (0x1000000269E63D70);//ML01
        // 0x00B41B44: CBZ x21, #0xb41b68         | if (this.value12 == 0) goto label_37;   
        if(this.value12 == 0)
        {
            goto label_37;
        }
        // 0x00B41B48: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41B4C: MOV x0, x21                | X0 = 1152921514973478256 (0x1000000269E63D70);//ML01
        // 0x00B41B50: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41B54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value12, ????);
        // 0x00B41B58: CBNZ x0, #0xb41b68         | if (this.value12 != 0) goto label_37;   
        if(this.value12 != 0)
        {
            goto label_37;
        }
        // 0x00B41B5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value12, ????);
        // 0x00B41B60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41B64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value12, ????);
        label_37:
        // 0x00B41B68: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41B6C: CMP w8, #0xb               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xB)
        // 0x00B41B70: B.HI #0xb41b80             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xB) goto label_38;
        // 0x00B41B74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value12, ????);
        // 0x00B41B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41B7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value12, ????);
        label_38:
        // 0x00B41B80: STR x21, [x20, #0x78]      | typeof(System.Object[]).__il2cppRuntimeField_78 = this.value12; typeof(System.Object[]).__il2cppRuntimeField_7C = 0x10000002;  //  dest_result_addr=1152921504954501384 dest_result_addr=1152921504954501388
        typeof(System.Object[]).__il2cppRuntimeField_78 = this.value12;
        typeof(System.Object[]).__il2cppRuntimeField_7C = 268435458;
        // 0x00B41B84: LDR w8, [x19, #0x40]       | W8 = this.value13; //P2                 
        // 0x00B41B88: LDR x0, [x22]              | X0 = typeof(System.Single);             
        // 0x00B41B8C: ADD x1, sp, #0xc           | X1 = (1152921514973389072 + 12) = 1152921514973389084 (0x1000000269E4E11C);
        // 0x00B41B90: STR w8, [sp, #0xc]         | stack[1152921514973389084] = this.value13;  //  dest_result_addr=1152921514973389084
        // 0x00B41B94: BL #0x27bc028              | X0 = 1152921514973482352 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.value13);
        // 0x00B41B98: MOV x21, x0                | X21 = 1152921514973482352 (0x1000000269E64D70);//ML01
        // 0x00B41B9C: CBZ x21, #0xb41bc0         | if (this.value13 == 0) goto label_40;   
        if(this.value13 == 0)
        {
            goto label_40;
        }
        // 0x00B41BA0: LDR x8, [x20]              | X8 = ;                                  
        // 0x00B41BA4: MOV x0, x21                | X0 = 1152921514973482352 (0x1000000269E64D70);//ML01
        // 0x00B41BA8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B41BAC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.value13, ????);
        // 0x00B41BB0: CBNZ x0, #0xb41bc0         | if (this.value13 != 0) goto label_40;   
        if(this.value13 != 0)
        {
            goto label_40;
        }
        // 0x00B41BB4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.value13, ????);
        // 0x00B41BB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41BBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value13, ????);
        label_40:
        // 0x00B41BC0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B41BC4: CMP w8, #0xc               | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0xC)
        // 0x00B41BC8: B.HI #0xb41bd8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0xC) goto label_41;
        // 0x00B41BCC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.value13, ????);
        // 0x00B41BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B41BD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.value13, ????);
        label_41:
        // 0x00B41BD8: STR x21, [x20, #0x80]      | typeof(System.Object[]).__il2cppRuntimeField_80 = this.value13; typeof(System.Object[]).__il2cppRuntimeField_84 = 0x10000002;  //  dest_result_addr=1152921504954501392 dest_result_addr=1152921504954501396
        typeof(System.Object[]).__il2cppRuntimeField_80 = this.value13;
        typeof(System.Object[]).__il2cppRuntimeField_84 = 268435458;
        // 0x00B41BDC: LDR x21, [x19, #0x48]      | X21 = this.notifyTest; //P2             
        // 0x00B41BE0: CBNZ x21, #0xb41be8        | if (this.notifyTest != null) goto label_42;
        if(this.notifyTest != null)
        {
            goto label_42;
        }
        // 0x00B41BE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.value13, ????);
        label_42:
        // 0x00B41BE8: STR x20, [x21, #0x20]      | this.notifyTest.args = typeof(System.Object[]);  //  dest_result_addr=0
        this.notifyTest.args = null;
        // 0x00B41BEC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B41BF0: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B41BF4: LDR x19, [x19, #0x48]      | X19 = this.notifyTest; //P2             
        val_2 = this.notifyTest;
        // 0x00B41BF8: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B41BFC: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B41C00: TBZ w8, #0, #0xb41c10      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_44;
        // 0x00B41C04: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B41C08: CBNZ w8, #0xb41c10         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
        // 0x00B41C0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_44:
        // 0x00B41C10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B41C14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B41C18: MOV x1, x19                | X1 = this.notifyTest;//m1               
        // 0x00B41C1C: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        label_1:
        // 0x00B41C20: SUB sp, x29, #0x30         | SP = (1152921514973389184 - 48) = 1152921514973389136 (0x1000000269E4E150);
        // 0x00B41C24: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B41C28: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B41C2C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B41C30: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B41C34: RET                        |  return;                                
        return;
    
    }

}
