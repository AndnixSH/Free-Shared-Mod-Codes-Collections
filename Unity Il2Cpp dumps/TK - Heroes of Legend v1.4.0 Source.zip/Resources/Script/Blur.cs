using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x281A608
[UnityEngine.RequireComponent] // 0x281A608
[UnityEngine.AddComponentMenu] // 0x281A608
[Serializable]
public class Blur : PostEffectsBase
{
    // Fields
    [UnityEngine.RangeAttribute] // 0x281A6A0
    public int downsample; //  0x0000001C
    [UnityEngine.RangeAttribute] // 0x281A6B8
    public float blurSize; //  0x00000020
    [UnityEngine.RangeAttribute] // 0x281A6D0
    public int blurIterations; //  0x00000024
    public Blur.BlurType blurType; //  0x00000028
    public UnityEngine.Shader blurShader; //  0x00000030
    private UnityEngine.Material blurMaterial; //  0x00000038
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02675388 (40326024), len: 64  VirtAddr: 0x02675388 RVA: 0x02675388 token: 100663324 methodIndex: 24408 delegateWrapperIndex: 0 methodInvoker: 0
    public Blur()
    {
        //
        // Disasemble & Code
        // 0x02675388: STP x20, x19, [sp, #-0x20]! | stack[1152921509947874448] = ???;  stack[1152921509947874456] = ???;  //  dest_result_addr=1152921509947874448 |  dest_result_addr=1152921509947874456
        // 0x0267538C: STP x29, x30, [sp, #0x10]  | stack[1152921509947874464] = ???;  stack[1152921509947874472] = ???;  //  dest_result_addr=1152921509947874464 |  dest_result_addr=1152921509947874472
        // 0x02675390: ADD x29, sp, #0x10         | X29 = (1152921509947874448 + 16) = 1152921509947874464 (0x100000013E599CA0);
        // 0x02675394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675398: MOV x19, x0                | X19 = 1152921509947886480 (0x100000013E59CB90);//ML01
        // 0x0267539C: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x026753A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026753A4: MOVZ w9, #0x4040, lsl #16  | W9 = 1077936128 (0x40400000);//ML01     
        // 0x026753A8: ORR w10, wzr, #2           | W10 = 2(0x2);                           
        // 0x026753AC: STRB w8, [x19, #0x18]      | mem[1152921509947886504] = 0x1;          //  dest_result_addr=1152921509947886504
        mem[1152921509947886504] = 1;
        // 0x026753B0: STRB w8, [x19, #0x1a]      | mem[1152921509947886506] = 0x1;          //  dest_result_addr=1152921509947886506
        mem[1152921509947886506] = 1;
        // 0x026753B4: STP w8, w9, [x19, #0x1c]   | this.downsample = 1;  this.blurSize = 3;  //  dest_result_addr=1152921509947886508 |  dest_result_addr=1152921509947886512
        this.downsample = 1;
        this.blurSize = 3f;
        // 0x026753B8: STUR x10, [x19, #0x24]     | this.blurIterations = 2; this.blurType = null;  //  dest_result_addr=1152921509947886516 dest_result_addr=1152921509947886520
        this.blurIterations = 2;
        this.blurType = 0;
        // 0x026753BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026753C0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026753C4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026753C8 (40326088), len: 104  VirtAddr: 0x026753C8 RVA: 0x026753C8 token: 100663325 methodIndex: 24409 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x026753C8: STP x20, x19, [sp, #-0x20]! | stack[1152921509947994640] = ???;  stack[1152921509947994648] = ???;  //  dest_result_addr=1152921509947994640 |  dest_result_addr=1152921509947994648
        // 0x026753CC: STP x29, x30, [sp, #0x10]  | stack[1152921509947994656] = ???;  stack[1152921509947994664] = ???;  //  dest_result_addr=1152921509947994656 |  dest_result_addr=1152921509947994664
        // 0x026753D0: ADD x29, sp, #0x10         | X29 = (1152921509947994640 + 16) = 1152921509947994656 (0x100000013E5B7220);
        // 0x026753D4: MOV x19, x0                | X19 = 1152921509948006672 (0x100000013E5BA110);//ML01
        // 0x026753D8: LDR x8, [x19]              | X8 = typeof(Blur);                      
        // 0x026753DC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x026753E0: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(Blur).__il2cppRuntimeField_1B0; X2 = typeof(Blur).__il2cppRuntimeField_1B8; //  | 
        // 0x026753E4: BLR x9                     | X0 = typeof(Blur).__il2cppRuntimeField_1B0();
        // 0x026753E8: LDR x8, [x19]              | X8 = typeof(Blur);                      
        // 0x026753EC: LDP x1, x2, [x19, #0x30]   | X1 = this.blurShader; //P2  X2 = this.blurMaterial; //P2  //  | 
        // 0x026753F0: MOV x0, x19                | X0 = 1152921509948006672 (0x100000013E5BA110);//ML01
        // 0x026753F4: LDP x9, x3, [x8, #0x150]   | X9 = typeof(Blur).__il2cppRuntimeField_150; X3 = typeof(Blur).__il2cppRuntimeField_158; //  | 
        // 0x026753F8: BLR x9                     | X0 = typeof(Blur).__il2cppRuntimeField_150();
        // 0x026753FC: LDRB w8, [x19, #0x1a]      | 
        // 0x02675400: STR x0, [x19, #0x38]       | this.blurMaterial = this;                //  dest_result_addr=1152921509948006728
        this.blurMaterial = this;
        // 0x02675404: CBNZ w8, #0x267541c        | if (typeof(Blur) != null) goto label_0; 
        if(null != null)
        {
            goto label_0;
        }
        // 0x02675408: LDR x8, [x19]              | X8 = typeof(Blur);                      
        // 0x0267540C: MOV x0, x19                | X0 = 1152921509948006672 (0x100000013E5BA110);//ML01
        // 0x02675410: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(Blur).__il2cppRuntimeField_1E0; X1 = typeof(Blur).__il2cppRuntimeField_1E8; //  | 
        // 0x02675414: BLR x9                     | X0 = typeof(Blur).__il2cppRuntimeField_1E0();
        // 0x02675418: LDRB w8, [x19, #0x1a]      | 
        label_0:
        // 0x0267541C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02675420: CMP w8, #0                 | STATE = COMPARE(typeof(Blur), 0x0)      
        // 0x02675424: CSET w0, ne                | W0 = typeof(Blur) != null ? 1 : 0;      
        var val_1 = (null != 0) ? 1 : 0;
        // 0x02675428: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0267542C: RET                        |  return (System.Boolean)typeof(Blur) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02675430 (40326192), len: 184  VirtAddr: 0x02675430 RVA: 0x02675430 token: 100663326 methodIndex: 24410 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnDisable()
    {
        //
        // Disasemble & Code
        // 0x02675430: STP x22, x21, [sp, #-0x30]! | stack[1152921509948123008] = ???;  stack[1152921509948123016] = ???;  //  dest_result_addr=1152921509948123008 |  dest_result_addr=1152921509948123016
        // 0x02675434: STP x20, x19, [sp, #0x10]  | stack[1152921509948123024] = ???;  stack[1152921509948123032] = ???;  //  dest_result_addr=1152921509948123024 |  dest_result_addr=1152921509948123032
        // 0x02675438: STP x29, x30, [sp, #0x20]  | stack[1152921509948123040] = ???;  stack[1152921509948123048] = ???;  //  dest_result_addr=1152921509948123040 |  dest_result_addr=1152921509948123048
        // 0x0267543C: ADD x29, sp, #0x20         | X29 = (1152921509948123008 + 32) = 1152921509948123040 (0x100000013E5D67A0);
        // 0x02675440: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02675444: LDRB w8, [x20, #0xe51]     | W8 = (bool)static_value_03740E51;       
        // 0x02675448: MOV x19, x0                | X19 = 1152921509948135056 (0x100000013E5D9690);//ML01
        // 0x0267544C: TBNZ w8, #0, #0x2675468    | if (static_value_03740E51 == true) goto label_0;
        // 0x02675450: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x02675454: LDR x8, [x8, #0x640]       | X8 = 0x2B8F6CC;                         
        // 0x02675458: LDR w0, [x8]               | W0 = 0x1477;                            
        // 0x0267545C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1477, ????);     
        // 0x02675460: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675464: STRB w8, [x20, #0xe51]     | static_value_03740E51 = true;            //  dest_result_addr=57937489
        label_0:
        // 0x02675468: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x0267546C: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02675470: LDR x20, [x19, #0x38]      | X20 = this.blurMaterial; //P2           
        // 0x02675474: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02675478: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0267547C: TBZ w8, #0, #0x267548c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02675480: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02675484: CBNZ w8, #0x267548c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02675488: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x0267548C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675490: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675494: MOV x1, x20                | X1 = this.blurMaterial;//m1             
        // 0x02675498: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x0267549C: TBZ w0, #0, #0x26754d8     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x026754A0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x026754A4: LDR x19, [x19, #0x38]      | X19 = this.blurMaterial; //P2           
        // 0x026754A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026754AC: TBZ w8, #0, #0x26754bc     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x026754B0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026754B4: CBNZ w8, #0x26754bc        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x026754B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x026754BC: MOV x1, x19                | X1 = this.blurMaterial;//m1             
        // 0x026754C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026754C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026754C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026754CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026754D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026754D4: B #0x1b78bac               | UnityEngine.Object.DestroyImmediate(obj:  0); return;
        UnityEngine.Object.DestroyImmediate(obj:  0);
        return;
        label_3:
        // 0x026754D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026754DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026754E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026754E4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026754E8 (40326376), len: 1080  VirtAddr: 0x026754E8 RVA: 0x026754E8 token: 100663327 methodIndex: 24411 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        var val_15;
        //  | 
        UnityEngine.FilterMode val_16;
        //  | 
        UnityEngine.RenderTexture val_17;
        //  | 
        UnityEngine.Material val_18;
        // 0x026754E8: STP d9, d8, [sp, #-0x70]!  | stack[1152921509948300576] = ???;  stack[1152921509948300584] = ???;  //  dest_result_addr=1152921509948300576 |  dest_result_addr=1152921509948300584
        // 0x026754EC: STP x28, x27, [sp, #0x10]  | stack[1152921509948300592] = ???;  stack[1152921509948300600] = ???;  //  dest_result_addr=1152921509948300592 |  dest_result_addr=1152921509948300600
        // 0x026754F0: STP x26, x25, [sp, #0x20]  | stack[1152921509948300608] = ???;  stack[1152921509948300616] = ???;  //  dest_result_addr=1152921509948300608 |  dest_result_addr=1152921509948300616
        // 0x026754F4: STP x24, x23, [sp, #0x30]  | stack[1152921509948300624] = ???;  stack[1152921509948300632] = ???;  //  dest_result_addr=1152921509948300624 |  dest_result_addr=1152921509948300632
        // 0x026754F8: STP x22, x21, [sp, #0x40]  | stack[1152921509948300640] = ???;  stack[1152921509948300648] = ???;  //  dest_result_addr=1152921509948300640 |  dest_result_addr=1152921509948300648
        // 0x026754FC: STP x20, x19, [sp, #0x50]  | stack[1152921509948300656] = ???;  stack[1152921509948300664] = ???;  //  dest_result_addr=1152921509948300656 |  dest_result_addr=1152921509948300664
        // 0x02675500: STP x29, x30, [sp, #0x60]  | stack[1152921509948300672] = ???;  stack[1152921509948300680] = ???;  //  dest_result_addr=1152921509948300672 |  dest_result_addr=1152921509948300680
        // 0x02675504: ADD x29, sp, #0x60         | X29 = (1152921509948300576 + 96) = 1152921509948300672 (0x100000013E601D80);
        // 0x02675508: SUB sp, sp, #0x20          | SP = (1152921509948300576 - 32) = 1152921509948300544 (0x100000013E601D00);
        // 0x0267550C: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02675510: LDRB w8, [x19, #0xe52]     | W8 = (bool)static_value_03740E52;       
        // 0x02675514: MOV x22, x2                | X22 = destination;//m1                  
        // 0x02675518: MOV x20, x1                | X20 = source;//m1                       
        // 0x0267551C: MOV x21, x0                | X21 = 1152921509948312688 (0x100000013E604C70);//ML01
        // 0x02675520: TBNZ w8, #0, #0x267553c    | if (static_value_03740E52 == true) goto label_0;
        // 0x02675524: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x02675528: LDR x8, [x8, #0x460]       | X8 = 0x2B8F6D0;                         
        // 0x0267552C: LDR w0, [x8]               | W0 = 0x1478;                            
        // 0x02675530: BL #0x2782188              | X0 = sub_2782188( ?? 0x1478, ????);     
        // 0x02675534: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675538: STRB w8, [x19, #0xe52]     | static_value_03740E52 = true;            //  dest_result_addr=57937490
        label_0:
        // 0x0267553C: LDR x8, [x21]              | X8 = typeof(Blur);                      
        // 0x02675540: MOV x0, x21                | X0 = 1152921509948312688 (0x100000013E604C70);//ML01
        // 0x02675544: LDP x9, x1, [x8, #0x190]   | X9 = typeof(Blur).__il2cppRuntimeField_190; X1 = typeof(Blur).__il2cppRuntimeField_198; //  | 
        // 0x02675548: BLR x9                     | X0 = typeof(Blur).__il2cppRuntimeField_190();
        // 0x0267554C: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x02675550: TBZ w8, #0, #0x26755dc     | if (((Blur)[1152921509948312688] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x02675554: STR x22, [sp, #8]          | stack[1152921509948300552] = destination;  //  dest_result_addr=1152921509948300552
        // 0x02675558: LDR w8, [x21, #0x1c]       | W8 = this.downsample; //P2              
        int val_14 = this.downsample;
        // 0x0267555C: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x02675560: LDR s1, [x21, #0x20]       | S1 = this.blurSize; //P2                
        float val_16 = this.blurSize;
        // 0x02675564: FMOV s0, #1.00000000       | S0 = 1;                                 
        float val_15 = 1f;
        // 0x02675568: LSL w8, w9, w8             | W8 = (1 << this.downsample);            
        val_14 = 1 << val_14;
        // 0x0267556C: LDR x22, [x21, #0x38]      | X22 = this.blurMaterial; //P2           
        // 0x02675570: SCVTF s2, w8               | S2 = (float)((1 << this.downsample));   
        // 0x02675574: FDIV s9, s0, s2            | S9 = (1f / (1 << this.downsample));     
        float val_1 = val_15 / (float)val_14;
        // 0x02675578: FMOV s2, wzr               | S2 = 0f;                                
        // 0x0267557C: FMUL s0, s1, s9            | S0 = (this.blurSize * (1f / (1 << this.downsample)));
        val_15 = val_16 * val_1;
        // 0x02675580: FNMUL s1, s1, s9           | S1 = (this.blurSize * (1f / (1 << this.downsample)));
        val_16 = -(val_16 * val_1);
        // 0x02675584: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675588: ADD x0, sp, #0x10          | X0 = (1152921509948300544 + 16) = 1152921509948300560 (0x100000013E601D10);
        // 0x0267558C: MOV v3.16b, v2.16b         | V3 = 0;//m1                             
        // 0x02675590: STP xzr, xzr, [sp, #0x10]  | stack[1152921509948300560] = 0x0;  stack[1152921509948300568] = 0x0;  //  dest_result_addr=1152921509948300560 |  dest_result_addr=1152921509948300568
        // 0x02675594: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02675598: CBNZ x22, #0x26755a0       | if (this.blurMaterial != null) goto label_2;
        if(this.blurMaterial != null)
        {
            goto label_2;
        }
        // 0x0267559C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E601D10, ????);
        label_2:
        // 0x026755A0: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x026755A4: LDR x8, [x8, #0x50]        | X8 = (string**)(1152921509948243536)("_Parameter");
        // 0x026755A8: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026755AC: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026755B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026755B4: LDR x1, [x8]               | X1 = "_Parameter";                      
        // 0x026755B8: MOV x0, x22                | X0 = this.blurMaterial;//m1             
        // 0x026755BC: BL #0x1a79fa8              | this.blurMaterial.SetVector(name:  "_Parameter", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurMaterial.SetVector(name:  "_Parameter", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x026755C0: CBZ x20, #0x2675630        | if (source == null) goto label_3;       
        if(source == null)
        {
            goto label_3;
        }
        // 0x026755C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026755C8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_16 = 1;
        // 0x026755CC: MOV x0, x20                | X0 = source;//m1                        
        // 0x026755D0: BL #0x268eee8              | source.set_filterMode(value:  val_16 = 1);
        source.filterMode = val_16;
        // 0x026755D4: MOV x25, x20               | X25 = source;//m1                       
        val_17 = source;
        // 0x026755D8: B #0x267564c               |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x026755DC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026755E0: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026755E4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026755E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026755EC: TBZ w8, #0, #0x26755fc     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x026755F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026755F4: CBNZ w8, #0x26755fc        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x026755F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_6:
        // 0x026755FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02675604: MOV x1, x20                | X1 = source;//m1                        
        // 0x02675608: MOV x2, x22                | X2 = destination;//m1                   
        // 0x0267560C: SUB sp, x29, #0x60         | SP = (1152921509948300672 - 96) = 1152921509948300576 (0x100000013E601D20);
        // 0x02675610: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x02675614: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x02675618: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x0267561C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x02675620: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x02675624: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x02675628: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x0267562C: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
        label_3:
        // 0x02675630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurMaterial, ????);
        // 0x02675634: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675638: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_16 = 1;
        // 0x0267563C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675640: BL #0x268eee8              | 0.set_filterMode(value:  val_16 = 1);   
        0.filterMode = val_16;
        // 0x02675644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x02675648: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
        val_17 = 0;
        label_4:
        // 0x0267564C: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02675650: MOV x0, x20                | X0 = source;//m1                        
        // 0x02675654: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02675658: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x0267565C: LDR w8, [x21, #0x1c]       | W8 = this.downsample; //P2              
        // 0x02675660: ASR w22, w0, w8            | W22 = (source >> this.downsample);      
        UnityEngine.RenderTexture val_2 = source >> this.downsample;
        // 0x02675664: CBNZ x20, #0x267566c       | if (source != null) goto label_7;       
        if(source != null)
        {
            goto label_7;
        }
        // 0x02675668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_7:
        // 0x0267566C: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02675670: MOV x0, x20                | X0 = source;//m1                        
        // 0x02675674: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02675678: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x0267567C: LDR w8, [x21, #0x1c]       | W8 = this.downsample; //P2              
        // 0x02675680: ASR w23, w0, w8            | W23 = (source >> this.downsample);      
        UnityEngine.RenderTexture val_3 = source >> this.downsample;
        // 0x02675684: CBNZ x20, #0x267568c       | if (source != null) goto label_8;       
        if(source != null)
        {
            goto label_8;
        }
        // 0x02675688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_8:
        // 0x0267568C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675690: MOV x0, x20                | X0 = source;//m1                        
        // 0x02675694: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_4 = source.format;
        // 0x02675698: MOV w4, w0                 | W4 = val_4;//m1                         
        // 0x0267569C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026756A0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026756A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026756A8: MOV w1, w22                | W1 = (source >> this.downsample);//m1   
        // 0x026756AC: MOV w2, w23                | W2 = (source >> this.downsample);//m1   
        // 0x026756B0: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_2, depthBuffer:  val_3, format:  0);
        UnityEngine.RenderTexture val_5 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_2, depthBuffer:  val_3, format:  0);
        // 0x026756B4: MOV x24, x0                | X24 = val_5;//m1                        
        val_18 = val_5;
        // 0x026756B8: CBNZ x24, #0x26756c0       | if (val_5 != null) goto label_9;        
        if(val_18 != null)
        {
            goto label_9;
        }
        // 0x026756BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x026756C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026756C4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x026756C8: MOV x0, x24                | X0 = val_5;//m1                         
        // 0x026756CC: BL #0x268eee8              | val_5.set_filterMode(value:  1);        
        val_18.filterMode = 1;
        // 0x026756D0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026756D4: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026756D8: LDR x26, [x21, #0x38]      | X26 = this.blurMaterial; //P2           
        // 0x026756DC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026756E0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026756E4: TBZ w8, #0, #0x26756f4     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x026756E8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026756EC: CBNZ w8, #0x26756f4        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x026756F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_11:
        // 0x026756F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026756F8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x026756FC: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
        // 0x02675700: MOV x2, x24                | X2 = val_5;//m1                         
        // 0x02675704: MOV x3, x26                | X3 = this.blurMaterial;//m1             
        // 0x02675708: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0267570C: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_17, mat:  val_18, pass:  this.blurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_17, mat:  val_18, pass:  this.blurMaterial);
        // 0x02675710: LDP w10, w9, [x21, #0x24]  | W10 = this.blurIterations; //P2  W9 = this.blurType; //P2  //  | 
        // 0x02675714: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x02675718: CMP w9, #0                 | STATE = COMPARE(this.blurType, 0x0)     
        // 0x0267571C: CSEL w8, wzr, w8, eq       | W8 = this.blurType == null ? 0 : 2;     
        var val_6 = (this.blurType == 0) ? 0 : (2);
        // 0x02675720: CMP w10, #1                | STATE = COMPARE(this.blurIterations, 0x1)
        // 0x02675724: B.LT #0x26758b8            | if (this.blurIterations < 1) goto label_12;
        if(this.blurIterations < 1)
        {
            goto label_12;
        }
        // 0x02675728: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
        // 0x0267572C: ORR w25, w8, #1            | W25 = (this.blurType == null ? 0 : 2 | 1);
        val_17 = val_6 | 1;
        // 0x02675730: ADD w26, w8, #2            | W26 = (this.blurType == null ? 0 : 2 + 2);
        var val_7 = val_6 + 2;
        // 0x02675734: FMOV s8, wzr               | S8 = 0f;                                
        label_20:
        // 0x02675738: LDR s0, [x21, #0x20]       | S0 = this.blurSize; //P2                
        float val_17 = this.blurSize;
        // 0x0267573C: LDR x27, [x21, #0x38]      | X27 = this.blurMaterial; //P2           
        // 0x02675740: SCVTF s1, w19              | S1 = 0;                                 
        float val_18 = 0f;
        // 0x02675744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675748: FMUL s2, s9, s0            | S2 = ((1f / (1 << this.downsample)) * this.blurSize);
        float val_8 = val_1 * val_17;
        // 0x0267574C: FNMUL s3, s9, s0           | S3 = ((1f / (1 << this.downsample)) * this.blurSize);
        float val_9 = -(val_1 * val_17);
        // 0x02675750: FADD s0, s1, s2            | S0 = (0f + ((1f / (1 << this.downsample)) * this.blurSize));
        val_17 = val_18 + val_8;
        // 0x02675754: FSUB s1, s3, s1            | S1 = (((1f / (1 << this.downsample)) * this.blurSize) - 0f);
        val_18 = val_9 - val_18;
        // 0x02675758: ADD x0, sp, #0x10          | X0 = (1152921509948300544 + 16) = 1152921509948300560 (0x100000013E601D10);
        // 0x0267575C: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02675760: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02675764: STP xzr, xzr, [sp, #0x10]  | stack[1152921509948300560] = 0x0;  stack[1152921509948300568] = 0x0;  //  dest_result_addr=1152921509948300560 |  dest_result_addr=1152921509948300568
        // 0x02675768: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x0267576C: CBNZ x27, #0x2675774       | if (this.blurMaterial != null) goto label_13;
        if(this.blurMaterial != null)
        {
            goto label_13;
        }
        // 0x02675770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E601D10, ????);
        label_13:
        // 0x02675774: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
        // 0x02675778: LDR x8, [x8, #0x50]        | X8 = (string**)(1152921509948243536)("_Parameter");
        // 0x0267577C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675780: MOV x0, x27                | X0 = this.blurMaterial;//m1             
        // 0x02675784: LDR x1, [x8]               | X1 = "_Parameter";                      
        // 0x02675788: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x0267578C: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02675790: BL #0x1a79fa8              | this.blurMaterial.SetVector(name:  "_Parameter", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.blurMaterial.SetVector(name:  "_Parameter", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02675794: CBNZ x20, #0x267579c       | if (source != null) goto label_14;      
        if(source != null)
        {
            goto label_14;
        }
        // 0x02675798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.blurMaterial, ????);
        label_14:
        // 0x0267579C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026757A0: MOV x0, x20                | X0 = source;//m1                        
        // 0x026757A4: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_10 = source.format;
        // 0x026757A8: MOV w4, w0                 | W4 = val_10;//m1                        
        // 0x026757AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026757B0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026757B4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026757B8: MOV w1, w22                | W1 = (source >> this.downsample);//m1   
        // 0x026757BC: MOV w2, w23                | W2 = (source >> this.downsample);//m1   
        // 0x026757C0: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_2, depthBuffer:  val_3, format:  0);
        UnityEngine.RenderTexture val_11 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_2, depthBuffer:  val_3, format:  0);
        // 0x026757C4: MOV x27, x0                | X27 = val_11;//m1                       
        // 0x026757C8: CBNZ x27, #0x26757d0       | if (val_11 != null) goto label_15;      
        if(val_11 != null)
        {
            goto label_15;
        }
        // 0x026757CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_15:
        // 0x026757D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026757D4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x026757D8: MOV x0, x27                | X0 = val_11;//m1                        
        // 0x026757DC: BL #0x268eee8              | val_11.set_filterMode(value:  1);       
        val_11.filterMode = 1;
        // 0x026757E0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026757E4: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026757E8: LDR x28, [x21, #0x38]      | X28 = this.blurMaterial; //P2           
        // 0x026757EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026757F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026757F4: TBZ w8, #0, #0x2675804     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x026757F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026757FC: CBNZ w8, #0x2675804        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x02675800: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_17:
        // 0x02675804: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675808: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0267580C: MOV x1, x24                | X1 = val_5;//m1                         
        // 0x02675810: MOV x2, x27                | X2 = val_11;//m1                        
        // 0x02675814: MOV x3, x28                | X3 = this.blurMaterial;//m1             
        // 0x02675818: MOV w4, w25                | W4 = (this.blurType == null ? 0 : 2 | 1);//m1
        // 0x0267581C: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_18, mat:  val_11, pass:  this.blurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_18, mat:  val_11, pass:  this.blurMaterial);
        // 0x02675820: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675824: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675828: MOV x1, x24                | X1 = val_5;//m1                         
        // 0x0267582C: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02675830: CBNZ x20, #0x2675838       | if (source != null) goto label_18;      
        if(source != null)
        {
            goto label_18;
        }
        // 0x02675834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_18:
        // 0x02675838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267583C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02675840: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_12 = source.format;
        // 0x02675844: MOV w4, w0                 | W4 = val_12;//m1                        
        // 0x02675848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267584C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02675850: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02675854: MOV w1, w22                | W1 = (source >> this.downsample);//m1   
        // 0x02675858: MOV w2, w23                | W2 = (source >> this.downsample);//m1   
        // 0x0267585C: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_2, depthBuffer:  val_3, format:  0);
        UnityEngine.RenderTexture val_13 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_2, depthBuffer:  val_3, format:  0);
        // 0x02675860: MOV x24, x0                | X24 = val_13;//m1                       
        val_18 = val_13;
        // 0x02675864: CBNZ x24, #0x267586c       | if (val_13 != null) goto label_19;      
        if(val_18 != null)
        {
            goto label_19;
        }
        // 0x02675868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_19:
        // 0x0267586C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675870: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02675874: MOV x0, x24                | X0 = val_13;//m1                        
        // 0x02675878: BL #0x268eee8              | val_13.set_filterMode(value:  1);       
        val_18.filterMode = 1;
        // 0x0267587C: LDR x3, [x21, #0x38]       | X3 = this.blurMaterial; //P2            
        // 0x02675880: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675884: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02675888: MOV x1, x27                | X1 = val_11;//m1                        
        // 0x0267588C: MOV x2, x24                | X2 = val_13;//m1                        
        // 0x02675890: MOV w4, w26                | W4 = (this.blurType == null ? 0 : 2 + 2);//m1
        // 0x02675894: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_11, mat:  val_18, pass:  this.blurMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_11, mat:  val_18, pass:  this.blurMaterial);
        // 0x02675898: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267589C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026758A0: MOV x1, x27                | X1 = val_11;//m1                        
        // 0x026758A4: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026758A8: LDR w8, [x21, #0x24]       | W8 = this.blurIterations; //P2          
        // 0x026758AC: ADD w19, w19, #1           | W19 = (0 + 1);                          
        val_15 = 0 + 1;
        // 0x026758B0: CMP w19, w8                | STATE = COMPARE((0 + 1), this.blurIterations)
        // 0x026758B4: B.LT #0x2675738            | if (val_15 < this.blurIterations) goto label_20;
        if(val_15 < this.blurIterations)
        {
            goto label_20;
        }
        label_12:
        // 0x026758B8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026758BC: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026758C0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026758C4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026758C8: TBZ w8, #0, #0x26758d8     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x026758CC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026758D0: CBNZ w8, #0x26758d8        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x026758D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_22:
        // 0x026758D8: LDR x2, [sp, #8]           | X2 = destination;                       
        // 0x026758DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026758E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026758E4: MOV x1, x24                | X1 = val_13;//m1                        
        // 0x026758E8: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  val_18);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_18);
        // 0x026758EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026758F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026758F4: MOV x1, x24                | X1 = val_13;//m1                        
        // 0x026758F8: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026758FC: SUB sp, x29, #0x60         | SP = (1152921509948300672 - 96) = 1152921509948300576 (0x100000013E601D20);
        // 0x02675900: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x02675904: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x02675908: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x0267590C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x02675910: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x02675914: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x02675918: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x0267591C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675920 (40327456), len: 4  VirtAddr: 0x02675920 RVA: 0x02675920 token: 100663328 methodIndex: 24412 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02675920: RET                        |  return;                                
        return;
    
    }

}
