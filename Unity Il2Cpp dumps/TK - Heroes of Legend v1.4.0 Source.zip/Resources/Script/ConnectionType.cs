using UnityEngine;
public enum ConnectionType
{
    // Fields
    Connection = 0
    ,ModifyNode = 1
    

}
