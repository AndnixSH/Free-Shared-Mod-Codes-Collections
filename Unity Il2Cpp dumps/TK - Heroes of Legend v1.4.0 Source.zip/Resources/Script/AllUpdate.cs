using UnityEngine;
public class AllUpdate : UpdateBase
{
    // Fields
    private static readonly AllUpdate s_instance; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B25BAC (11688876), len: 208  VirtAddr: 0x00B25BAC RVA: 0x00B25BAC token: 100696490 methodIndex: 24768 delegateWrapperIndex: 0 methodInvoker: 0
    private static AllUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B25BAC: STP x22, x21, [sp, #-0x30]! | stack[1152921515538904128] = ???;  stack[1152921515538904136] = ???;  //  dest_result_addr=1152921515538904128 |  dest_result_addr=1152921515538904136
        // 0x00B25BB0: STP x20, x19, [sp, #0x10]  | stack[1152921515538904144] = ???;  stack[1152921515538904152] = ???;  //  dest_result_addr=1152921515538904144 |  dest_result_addr=1152921515538904152
        // 0x00B25BB4: STP x29, x30, [sp, #0x20]  | stack[1152921515538904160] = ???;  stack[1152921515538904168] = ???;  //  dest_result_addr=1152921515538904160 |  dest_result_addr=1152921515538904168
        // 0x00B25BB8: ADD x29, sp, #0x20         | X29 = (1152921515538904128 + 32) = 1152921515538904160 (0x100000028B99F460);
        // 0x00B25BBC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B25BC0: LDRB w8, [x19, #0x73f]     | W8 = (bool)static_value_0373373F;       
        // 0x00B25BC4: TBNZ w8, #0, #0xb25be0     | if (static_value_0373373F == true) goto label_0;
        // 0x00B25BC8: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x00B25BCC: LDR x8, [x8, #0xe88]       | X8 = 0x2B8ABFC;                         
        // 0x00B25BD0: LDR w0, [x8]               | W0 = 0x1BD;                             
        // 0x00B25BD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BD, ????);      
        // 0x00B25BD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B25BDC: STRB w8, [x19, #0x73f]     | static_value_0373373F = true;            //  dest_result_addr=57882431
        label_0:
        // 0x00B25BE0: ADRP x20, #0x360d000       | X20 = 56676352 (0x360D000);             
        // 0x00B25BE4: LDR x20, [x20, #0xf38]     | X20 = 1152921504922128384;              
        // 0x00B25BE8: LDR x0, [x20]              | X0 = typeof(AllUpdate);                 
        UpdateBase val_1 = null;
        // 0x00B25BEC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AllUpdate), ????);
        // 0x00B25BF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25BF4: MOV x19, x0                | X19 = 1152921504922128384 (0x1000000012CAD000);//ML01
        // 0x00B25BF8: BL #0xe15fc0               | .ctor();                                
        val_1 = new UpdateBase();
        // 0x00B25BFC: LDR x8, [x20]              | X8 = typeof(AllUpdate);                 
        // 0x00B25C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25C08: LDR x8, [x8, #0xa0]        | X8 = AllUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B25C0C: STR x19, [x8]              | AllUpdate.s_instance = typeof(AllUpdate);  //  dest_result_addr=1152921504922132480
        AllUpdate.s_instance = val_1;
        // 0x00B25C10: BL #0x26a7448              | X0 = ZAllUpdate.get_allUpdate();        
        ZAllUpdate val_2 = ZAllUpdate.allUpdate;
        // 0x00B25C14: LDR x8, [x20]              | X8 = typeof(AllUpdate);                 
        // 0x00B25C18: ADRP x9, #0x35d9000        | X9 = 56463360 (0x35D9000);              
        // 0x00B25C1C: ADRP x10, #0x3679000       | X10 = 57118720 (0x3679000);             
        // 0x00B25C20: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B25C24: LDR x8, [x8, #0xa0]        | X8 = AllUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B25C28: LDR x9, [x9, #0x788]       | X9 = 1152921515538418576;               
        // 0x00B25C2C: LDR x10, [x10, #0xbe0]     | X10 = 1152921504687837184;              
        // 0x00B25C30: LDR x22, [x8]              | X22 = typeof(AllUpdate);                
        // 0x00B25C34: LDR x21, [x9]              | X21 = System.Void UpdateBase::Update(); 
        // 0x00B25C38: LDR x8, [x10]              | X8 = typeof(System.Action);             
        // 0x00B25C3C: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_3 = null;
        // 0x00B25C40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B25C44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B25C48: MOV x1, x22                | X1 = 1152921504922128384 (0x1000000012CAD000);//ML01
        // 0x00B25C4C: MOV x2, x21                | X2 = 1152921515538418576 (0x100000028B928B90);//ML01
        // 0x00B25C50: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B25C54: BL #0x26e30f0              | .ctor(object:  AllUpdate.s_instance, method:  System.Void UpdateBase::Update());
        val_3 = new System.Action(object:  AllUpdate.s_instance, method:  System.Void UpdateBase::Update());
        // 0x00B25C58: CBNZ x19, #0xb25c60        | if (val_2 != null) goto label_1;        
        if(val_2 != null)
        {
            goto label_1;
        }
        // 0x00B25C5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  AllUpdate.s_instance, method:  System.Void UpdateBase::Update()), ????);
        label_1:
        // 0x00B25C60: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B25C64: MOV x1, x20                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B25C68: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B25C6C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B25C70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25C74: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B25C78: B #0x26a75e8               | val_2.add_update(value:  val_3); return;
        val_2.add_update(value:  val_3);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B25C7C (11689084), len: 8  VirtAddr: 0x00B25C7C RVA: 0x00B25C7C token: 100696491 methodIndex: 24769 delegateWrapperIndex: 0 methodInvoker: 0
    public AllUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B25C7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25C80: B #0xe15fc0                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14D7C (11619708), len: 128  VirtAddr: 0x00B14D7C RVA: 0x00B14D7C token: 100696492 methodIndex: 24770 delegateWrapperIndex: 0 methodInvoker: 0
    public static void AddUpdate(IZUpdate update)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00B14D7C: STP x20, x19, [sp, #-0x20]! | stack[1152921515539136336] = ???;  stack[1152921515539136344] = ???;  //  dest_result_addr=1152921515539136336 |  dest_result_addr=1152921515539136344
        // 0x00B14D80: STP x29, x30, [sp, #0x10]  | stack[1152921515539136352] = ???;  stack[1152921515539136360] = ???;  //  dest_result_addr=1152921515539136352 |  dest_result_addr=1152921515539136360
        // 0x00B14D84: ADD x29, sp, #0x10         | X29 = (1152921515539136336 + 16) = 1152921515539136352 (0x100000028B9D7F60);
        // 0x00B14D88: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B14D8C: LDRB w8, [x20, #0x740]     | W8 = (bool)static_value_03733740;       
        // 0x00B14D90: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B14D94: TBNZ w8, #0, #0xb14db0     | if (static_value_03733740 == true) goto label_0;
        // 0x00B14D98: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00B14D9C: LDR x8, [x8, #0x9a8]       | X8 = 0x2B8AC00;                         
        // 0x00B14DA0: LDR w0, [x8]               | W0 = 0x1BE;                             
        // 0x00B14DA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BE, ????);      
        // 0x00B14DA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14DAC: STRB w8, [x20, #0x740]     | static_value_03733740 = true;            //  dest_result_addr=57882432
        label_0:
        // 0x00B14DB0: ADRP x20, #0x360d000       | X20 = 56676352 (0x360D000);             
        // 0x00B14DB4: LDR x20, [x20, #0xf38]     | X20 = 1152921504922128384;              
        // 0x00B14DB8: LDR x0, [x20]              | X0 = typeof(AllUpdate);                 
        val_1 = null;
        // 0x00B14DBC: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B14DC0: TBZ w8, #0, #0xb14dd4      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B14DC4: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B14DC8: CBNZ w8, #0xb14dd4         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B14DCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        // 0x00B14DD0: LDR x0, [x20]              | X0 = typeof(AllUpdate);                 
        val_1 = null;
        label_2:
        // 0x00B14DD4: LDR x8, [x0, #0xa0]        | X8 = AllUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B14DD8: LDR x20, [x8]              | X20 = AllUpdate.s_instance;             
        // 0x00B14DDC: CBNZ x20, #0xb14de4        | if (AllUpdate.s_instance != null) goto label_3;
        if(AllUpdate.s_instance != null)
        {
            goto label_3;
        }
        // 0x00B14DE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AllUpdate), ????);
        label_3:
        // 0x00B14DE4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14DE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B14DEC: MOV x0, x20                | X0 = AllUpdate.s_instance;//m1          
        // 0x00B14DF0: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B14DF4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B14DF8: B #0xe16050                | AllUpdate.s_instance.I_AddUpdate(update:  X1); return;
        AllUpdate.s_instance.I_AddUpdate(update:  X1);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B25C84 (11689092), len: 128  VirtAddr: 0x00B25C84 RVA: 0x00B25C84 token: 100696493 methodIndex: 24771 delegateWrapperIndex: 0 methodInvoker: 0
    public static void RemoveUpdate(IZUpdate update)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00B25C84: STP x20, x19, [sp, #-0x20]! | stack[1152921515539256528] = ???;  stack[1152921515539256536] = ???;  //  dest_result_addr=1152921515539256528 |  dest_result_addr=1152921515539256536
        // 0x00B25C88: STP x29, x30, [sp, #0x10]  | stack[1152921515539256544] = ???;  stack[1152921515539256552] = ???;  //  dest_result_addr=1152921515539256544 |  dest_result_addr=1152921515539256552
        // 0x00B25C8C: ADD x29, sp, #0x10         | X29 = (1152921515539256528 + 16) = 1152921515539256544 (0x100000028B9F54E0);
        // 0x00B25C90: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B25C94: LDRB w8, [x20, #0x741]     | W8 = (bool)static_value_03733741;       
        // 0x00B25C98: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00B25C9C: TBNZ w8, #0, #0xb25cb8     | if (static_value_03733741 == true) goto label_0;
        // 0x00B25CA0: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B25CA4: LDR x8, [x8, #0x630]       | X8 = 0x2B8AC1C;                         
        // 0x00B25CA8: LDR w0, [x8]               | W0 = 0x1C5;                             
        // 0x00B25CAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C5, ????);      
        // 0x00B25CB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B25CB4: STRB w8, [x20, #0x741]     | static_value_03733741 = true;            //  dest_result_addr=57882433
        label_0:
        // 0x00B25CB8: ADRP x20, #0x360d000       | X20 = 56676352 (0x360D000);             
        // 0x00B25CBC: LDR x20, [x20, #0xf38]     | X20 = 1152921504922128384;              
        // 0x00B25CC0: LDR x0, [x20]              | X0 = typeof(AllUpdate);                 
        val_1 = null;
        // 0x00B25CC4: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B25CC8: TBZ w8, #0, #0xb25cdc      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B25CCC: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B25CD0: CBNZ w8, #0xb25cdc         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B25CD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        // 0x00B25CD8: LDR x0, [x20]              | X0 = typeof(AllUpdate);                 
        val_1 = null;
        label_2:
        // 0x00B25CDC: LDR x8, [x0, #0xa0]        | X8 = AllUpdate.__il2cppRuntimeField_static_fields;
        // 0x00B25CE0: LDR x20, [x8]              | X20 = AllUpdate.s_instance;             
        // 0x00B25CE4: CBNZ x20, #0xb25cec        | if (AllUpdate.s_instance != null) goto label_3;
        if(AllUpdate.s_instance != null)
        {
            goto label_3;
        }
        // 0x00B25CE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AllUpdate), ????);
        label_3:
        // 0x00B25CEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B25CF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25CF4: MOV x0, x20                | X0 = AllUpdate.s_instance;//m1          
        // 0x00B25CF8: MOV x1, x19                | X1 = X1;//m1                            
        // 0x00B25CFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B25D00: B #0xe16118                | AllUpdate.s_instance.I_RemoveUpdate(update:  X1); return;
        AllUpdate.s_instance.I_RemoveUpdate(update:  X1);
        return;
    
    }

}
