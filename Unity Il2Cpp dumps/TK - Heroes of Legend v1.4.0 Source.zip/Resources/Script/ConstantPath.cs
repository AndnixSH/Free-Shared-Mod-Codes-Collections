using UnityEngine;

namespace Pathfinding
{
    public class ConstantPath : Path
    {
        // Fields
        public Pathfinding.GraphNode startNode; //  0x00000110
        public UnityEngine.Vector3 startPoint; //  0x00000118
        public UnityEngine.Vector3 originalStartPoint; //  0x00000124
        public System.Collections.Generic.List<Pathfinding.GraphNode> allNodes; //  0x00000130
        public Pathfinding.PathEndingCondition endingCondition; //  0x00000138
        
        // Properties
        public override bool FloodingPath { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01689EF8 (23633656), len: 104  VirtAddr: 0x01689EF8 RVA: 0x01689EF8 token: 100683596 methodIndex: 49921 delegateWrapperIndex: 0 methodInvoker: 0
        public ConstantPath()
        {
            //
            // Disasemble & Code
            // 0x01689EF8: STP x20, x19, [sp, #-0x20]! | stack[1152921513507554992] = ???;  stack[1152921513507555000] = ???;  //  dest_result_addr=1152921513507554992 |  dest_result_addr=1152921513507555000
            // 0x01689EFC: STP x29, x30, [sp, #0x10]  | stack[1152921513507555008] = ???;  stack[1152921513507555016] = ???;  //  dest_result_addr=1152921513507555008 |  dest_result_addr=1152921513507555016
            // 0x01689F00: ADD x29, sp, #0x10         | X29 = (1152921513507554992 + 16) = 1152921513507555008 (0x10000002128606C0);
            // 0x01689F04: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01689F08: LDRB w8, [x20, #0xfd]      | W8 = (bool)static_value_037380FD;       
            // 0x01689F0C: MOV x19, x0                | X19 = 1152921513507567024 (0x10000002128635B0);//ML01
            // 0x01689F10: TBNZ w8, #0, #0x1689f2c    | if (static_value_037380FD == true) goto label_0;
            // 0x01689F14: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x01689F18: LDR x8, [x8, #0x860]       | X8 = 0x2B9280C;                         
            // 0x01689F1C: LDR w0, [x8]               | W0 = 0x20C8;                            
            // 0x01689F20: BL #0x2782188              | X0 = sub_2782188( ?? 0x20C8, ????);     
            // 0x01689F24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01689F28: STRB w8, [x20, #0xfd]      | static_value_037380FD = true;            //  dest_result_addr=57901309
            label_0:
            // 0x01689F2C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01689F30: LDR x8, [x8, #0x110]       | X8 = 1152921504840552448;               
            // 0x01689F34: LDR x0, [x8]               | X0 = typeof(Pathfinding.Path);          
            // 0x01689F38: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Path.__il2cppRuntimeField_10A;
            // 0x01689F3C: TBZ w8, #0, #0x1689f4c     | if (Pathfinding.Path.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01689F40: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Path.__il2cppRuntimeField_cctor_finished;
            // 0x01689F44: CBNZ w8, #0x1689f4c        | if (Pathfinding.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01689F48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Path), ????);
            label_2:
            // 0x01689F4C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01689F50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689F54: MOV x0, x19                | X0 = 1152921513507567024 (0x10000002128635B0);//ML01
            // 0x01689F58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01689F5C: B #0x1402a98               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01689F60 (23633760), len: 160  VirtAddr: 0x01689F60 RVA: 0x01689F60 token: 100683597 methodIndex: 49922 delegateWrapperIndex: 0 methodInvoker: 0
        [System.ObsoleteAttribute] // 0x285C700
        public ConstantPath(UnityEngine.Vector3 start, OnPathDelegate callbackDelegate)
        {
            //
            // Disasemble & Code
            // 0x01689F60: STP x20, x19, [sp, #-0x20]! | stack[1152921513507672320] = ???;  stack[1152921513507672328] = ???;  //  dest_result_addr=1152921513507672320 |  dest_result_addr=1152921513507672328
            // 0x01689F64: STP x29, x30, [sp, #0x10]  | stack[1152921513507672336] = ???;  stack[1152921513507672344] = ???;  //  dest_result_addr=1152921513507672336 |  dest_result_addr=1152921513507672344
            // 0x01689F68: ADD x29, sp, #0x10         | X29 = (1152921513507672320 + 16) = 1152921513507672336 (0x100000021287D110);
            // 0x01689F6C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01689F70: LDRB w8, [x20, #0xfe]      | W8 = (bool)static_value_037380FE;       
            // 0x01689F74: MOV x19, x0                | X19 = 1152921513507684352 (0x1000000212880000);//ML01
            // 0x01689F78: TBNZ w8, #0, #0x1689f94    | if (static_value_037380FE == true) goto label_0;
            // 0x01689F7C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x01689F80: LDR x8, [x8, #0x3a0]       | X8 = 0x2B92810;                         
            // 0x01689F84: LDR w0, [x8]               | W0 = 0x20C9;                            
            // 0x01689F88: BL #0x2782188              | X0 = sub_2782188( ?? 0x20C9, ????);     
            // 0x01689F8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01689F90: STRB w8, [x20, #0xfe]      | static_value_037380FE = true;            //  dest_result_addr=57901310
            label_0:
            // 0x01689F94: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01689F98: LDR x8, [x8, #0x110]       | X8 = 1152921504840552448;               
            // 0x01689F9C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Path);          
            // 0x01689FA0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Path.__il2cppRuntimeField_10A;
            // 0x01689FA4: TBZ w8, #0, #0x1689fb4     | if (Pathfinding.Path.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01689FA8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Path.__il2cppRuntimeField_cctor_finished;
            // 0x01689FAC: CBNZ w8, #0x1689fb4        | if (Pathfinding.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01689FB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Path), ????);
            label_2:
            // 0x01689FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01689FB8: MOV x0, x19                | X0 = 1152921513507684352 (0x1000000212880000);//ML01
            // 0x01689FBC: BL #0x1402a98              | this..ctor();                           
            // 0x01689FC0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x01689FC4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x01689FC8: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x01689FCC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x01689FD0: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x01689FD4: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921513507659120)("This constructor is obsolete, please use the Construct method instead");
            // 0x01689FD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01689FDC: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x01689FE0: LDR x1, [x8]               | X1 = "This constructor is obsolete, please use the Construct method instead";
            // 0x01689FE4: BL #0x1c32b48              | .ctor(message:  "This constructor is obsolete, please use the Construct method instead");
            val_1 = new System.Exception(message:  "This constructor is obsolete, please use the Construct method instead");
            // 0x01689FE8: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x01689FEC: LDR x8, [x8, #0xc38]       | X8 = 1152921513507659328;               
            // 0x01689FF0: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x01689FF4: LDR x1, [x8]               | X1 = public System.Void Pathfinding.ConstantPath::.ctor(UnityEngine.Vector3 start, OnPathDelegate callbackDelegate);
            // 0x01689FF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x01689FFC: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A000 (23633920), len: 160  VirtAddr: 0x0168A000 RVA: 0x0168A000 token: 100683598 methodIndex: 49923 delegateWrapperIndex: 0 methodInvoker: 0
        [System.ObsoleteAttribute] // 0x285C738
        public ConstantPath(UnityEngine.Vector3 start, int maxGScore, OnPathDelegate callbackDelegate)
        {
            //
            // Disasemble & Code
            // 0x0168A000: STP x20, x19, [sp, #-0x20]! | stack[1152921513507793536] = ???;  stack[1152921513507793544] = ???;  //  dest_result_addr=1152921513507793536 |  dest_result_addr=1152921513507793544
            // 0x0168A004: STP x29, x30, [sp, #0x10]  | stack[1152921513507793552] = ???;  stack[1152921513507793560] = ???;  //  dest_result_addr=1152921513507793552 |  dest_result_addr=1152921513507793560
            // 0x0168A008: ADD x29, sp, #0x10         | X29 = (1152921513507793536 + 16) = 1152921513507793552 (0x100000021289AA90);
            // 0x0168A00C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A010: LDRB w8, [x20, #0xff]      | W8 = (bool)static_value_037380FF;       
            // 0x0168A014: MOV x19, x0                | X19 = 1152921513507805568 (0x100000021289D980);//ML01
            // 0x0168A018: TBNZ w8, #0, #0x168a034    | if (static_value_037380FF == true) goto label_0;
            // 0x0168A01C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x0168A020: LDR x8, [x8, #0x898]       | X8 = 0x2B92808;                         
            // 0x0168A024: LDR w0, [x8]               | W0 = 0x20C7;                            
            // 0x0168A028: BL #0x2782188              | X0 = sub_2782188( ?? 0x20C7, ????);     
            // 0x0168A02C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A030: STRB w8, [x20, #0xff]      | static_value_037380FF = true;            //  dest_result_addr=57901311
            label_0:
            // 0x0168A034: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x0168A038: LDR x8, [x8, #0x110]       | X8 = 1152921504840552448;               
            // 0x0168A03C: LDR x0, [x8]               | X0 = typeof(Pathfinding.Path);          
            // 0x0168A040: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Path.__il2cppRuntimeField_10A;
            // 0x0168A044: TBZ w8, #0, #0x168a054     | if (Pathfinding.Path.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168A048: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Path.__il2cppRuntimeField_cctor_finished;
            // 0x0168A04C: CBNZ w8, #0x168a054        | if (Pathfinding.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168A050: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Path), ????);
            label_2:
            // 0x0168A054: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A058: MOV x0, x19                | X0 = 1152921513507805568 (0x100000021289D980);//ML01
            // 0x0168A05C: BL #0x1402a98              | this..ctor();                           
            // 0x0168A060: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0168A064: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x0168A068: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x0168A06C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x0168A070: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x0168A074: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921513507659120)("This constructor is obsolete, please use the Construct method instead");
            // 0x0168A078: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A07C: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0168A080: LDR x1, [x8]               | X1 = "This constructor is obsolete, please use the Construct method instead";
            // 0x0168A084: BL #0x1c32b48              | .ctor(message:  "This constructor is obsolete, please use the Construct method instead");
            val_1 = new System.Exception(message:  "This constructor is obsolete, please use the Construct method instead");
            // 0x0168A088: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x0168A08C: LDR x8, [x8, #0x2f0]       | X8 = 1152921513507780544;               
            // 0x0168A090: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0168A094: LDR x1, [x8]               | X1 = public System.Void Pathfinding.ConstantPath::.ctor(UnityEngine.Vector3 start, int maxGScore, OnPathDelegate callbackDelegate);
            // 0x0168A098: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x0168A09C: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A0A0 (23634080), len: 8  VirtAddr: 0x0168A0A0 RVA: 0x0168A0A0 token: 100683599 methodIndex: 49924 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_FloodingPath()
        {
            //
            // Disasemble & Code
            // 0x0168A0A0: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x0168A0A4: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A0A8 (23634088), len: 200  VirtAddr: 0x0168A0A8 RVA: 0x0168A0A8 token: 100683600 methodIndex: 49925 delegateWrapperIndex: 0 methodInvoker: 0
        public static Pathfinding.ConstantPath Construct(UnityEngine.Vector3 start, int maxGScore, OnPathDelegate callback)
        {
            //
            // Disasemble & Code
            // 0x0168A0A8: STP d11, d10, [sp, #-0x50]! | stack[1152921513508030800] = ???;  stack[1152921513508030808] = ???;  //  dest_result_addr=1152921513508030800 |  dest_result_addr=1152921513508030808
            // 0x0168A0AC: STP d9, d8, [sp, #0x10]    | stack[1152921513508030816] = ???;  stack[1152921513508030824] = ???;  //  dest_result_addr=1152921513508030816 |  dest_result_addr=1152921513508030824
            // 0x0168A0B0: STP x22, x21, [sp, #0x20]  | stack[1152921513508030832] = ???;  stack[1152921513508030840] = ???;  //  dest_result_addr=1152921513508030832 |  dest_result_addr=1152921513508030840
            // 0x0168A0B4: STP x20, x19, [sp, #0x30]  | stack[1152921513508030848] = ???;  stack[1152921513508030856] = ???;  //  dest_result_addr=1152921513508030848 |  dest_result_addr=1152921513508030856
            // 0x0168A0B8: STP x29, x30, [sp, #0x40]  | stack[1152921513508030864] = ???;  stack[1152921513508030872] = ???;  //  dest_result_addr=1152921513508030864 |  dest_result_addr=1152921513508030872
            // 0x0168A0BC: ADD x29, sp, #0x40         | X29 = (1152921513508030800 + 64) = 1152921513508030864 (0x10000002128D4990);
            // 0x0168A0C0: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x0168A0C4: LDRB w8, [x21, #0x100]     | W8 = (bool)static_value_03738100;       
            // 0x0168A0C8: MOV x19, x2                | X19 = X2;//m1                           
            // 0x0168A0CC: MOV w20, w1                | W20 = callback;//m1                     
            // 0x0168A0D0: MOV v8.16b, v2.16b         | V8 = start.z;//m1                       
            // 0x0168A0D4: MOV v9.16b, v1.16b         | V9 = start.y;//m1                       
            // 0x0168A0D8: MOV v10.16b, v0.16b        | V10 = start.x;//m1                      
            // 0x0168A0DC: TBNZ w8, #0, #0x168a0f8    | if (static_value_03738100 == true) goto label_0;
            // 0x0168A0E0: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x0168A0E4: LDR x8, [x8, #0xbb0]       | X8 = 0x2B9281C;                         
            // 0x0168A0E8: LDR w0, [x8]               | W0 = 0x20CC;                            
            // 0x0168A0EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x20CC, ????);     
            // 0x0168A0F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A0F4: STRB w8, [x21, #0x100]     | static_value_03738100 = true;            //  dest_result_addr=57901312
            label_0:
            // 0x0168A0F8: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x0168A0FC: LDR x8, [x8, #0x8f8]       | X8 = 1152921504839860224;               
            // 0x0168A100: LDR x0, [x8]               | X0 = typeof(Pathfinding.PathPool<T>);   
            // 0x0168A104: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_10A;
            // 0x0168A108: TBZ w8, #0, #0x168a118     | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168A10C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x0168A110: CBNZ w8, #0x168a118        | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168A114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.PathPool<T>), ????);
            label_2:
            // 0x0168A118: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x0168A11C: LDR x8, [x8, #0xbe8]       | X8 = 1152921513508013760;               
            // 0x0168A120: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A124: LDR x1, [x8]               | X1 = public static Pathfinding.ConstantPath Pathfinding.PathPool<Pathfinding.ConstantPath>::GetPath();
            // 0x0168A128: BL #0x19f1938              | X0 = Pathfinding.PathPool<Pathfinding.RandomPath>.GetPath();
            Pathfinding.RandomPath val_1 = Pathfinding.PathPool<Pathfinding.RandomPath>.GetPath();
            // 0x0168A12C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x0168A130: CBNZ x21, #0x168a138       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x0168A134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x0168A138: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x0168A13C: MOV v0.16b, v10.16b        | V0 = start.x;//m1                       
            // 0x0168A140: MOV v1.16b, v9.16b         | V1 = start.y;//m1                       
            // 0x0168A144: MOV v2.16b, v8.16b         | V2 = start.z;//m1                       
            // 0x0168A148: MOV w1, w20                | W1 = callback;//m1                      
            // 0x0168A14C: MOV x2, x19                | X2 = X2;//m1                            
            // 0x0168A150: BL #0x168a170              | val_1.Setup(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, maxGScore:  callback, callback:  X2);
            val_1.Setup(start:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, maxGScore:  callback, callback:  X2);
            // 0x0168A154: MOV x0, x21                | X0 = val_1;//m1                         
            // 0x0168A158: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A15C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0168A160: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0168A164: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0168A168: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
            // 0x0168A16C: RET                        |  return (Pathfinding.ConstantPath)val_1;
            return (Pathfinding.ConstantPath)val_1;
            //  |  // // {name=val_0, type=Pathfinding.ConstantPath, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A170 (23634288), len: 184  VirtAddr: 0x0168A170 RVA: 0x0168A170 token: 100683601 methodIndex: 49926 delegateWrapperIndex: 0 methodInvoker: 0
        protected void Setup(UnityEngine.Vector3 start, int maxGScore, OnPathDelegate callback)
        {
            //
            // Disasemble & Code
            // 0x0168A170: STP d11, d10, [sp, #-0x50]! | stack[1152921513508155088] = ???;  stack[1152921513508155096] = ???;  //  dest_result_addr=1152921513508155088 |  dest_result_addr=1152921513508155096
            // 0x0168A174: STP d9, d8, [sp, #0x10]    | stack[1152921513508155104] = ???;  stack[1152921513508155112] = ???;  //  dest_result_addr=1152921513508155104 |  dest_result_addr=1152921513508155112
            // 0x0168A178: STP x22, x21, [sp, #0x20]  | stack[1152921513508155120] = ???;  stack[1152921513508155128] = ???;  //  dest_result_addr=1152921513508155120 |  dest_result_addr=1152921513508155128
            // 0x0168A17C: STP x20, x19, [sp, #0x30]  | stack[1152921513508155136] = ???;  stack[1152921513508155144] = ???;  //  dest_result_addr=1152921513508155136 |  dest_result_addr=1152921513508155144
            // 0x0168A180: STP x29, x30, [sp, #0x40]  | stack[1152921513508155152] = ???;  stack[1152921513508155160] = ???;  //  dest_result_addr=1152921513508155152 |  dest_result_addr=1152921513508155160
            // 0x0168A184: ADD x29, sp, #0x40         | X29 = (1152921513508155088 + 64) = 1152921513508155152 (0x10000002128F2F10);
            // 0x0168A188: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x0168A18C: LDRB w8, [x22, #0x101]     | W8 = (bool)static_value_03738101;       
            // 0x0168A190: MOV x21, x2                | X21 = callback;//m1                     
            // 0x0168A194: MOV w19, w1                | W19 = maxGScore;//m1                    
            // 0x0168A198: MOV v8.16b, v2.16b         | V8 = start.z;//m1                       
            // 0x0168A19C: MOV v9.16b, v1.16b         | V9 = start.y;//m1                       
            // 0x0168A1A0: MOV v10.16b, v0.16b        | V10 = start.x;//m1                      
            // 0x0168A1A4: MOV x20, x0                | X20 = 1152921513508167168 (0x10000002128F5E00);//ML01
            // 0x0168A1A8: TBNZ w8, #0, #0x168a1c4    | if (static_value_03738101 == true) goto label_0;
            // 0x0168A1AC: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x0168A1B0: LDR x8, [x8, #0x578]       | X8 = 0x2B92834;                         
            // 0x0168A1B4: LDR w0, [x8]               | W0 = 0x20D2;                            
            // 0x0168A1B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x20D2, ????);     
            // 0x0168A1BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A1C0: STRB w8, [x22, #0x101]     | static_value_03738101 = true;            //  dest_result_addr=57901313
            label_0:
            // 0x0168A1C4: STR s8, [x20, #0x12c]      | mem[1152921513508167468] = start.z;      //  dest_result_addr=1152921513508167468
            mem[1152921513508167468] = start.z;
            // 0x0168A1C8: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x0168A1CC: STR x21, [x20, #0x20]      | mem[1152921513508167200] = callback;     //  dest_result_addr=1152921513508167200
            mem[1152921513508167200] = callback;
            // 0x0168A1D0: STR s10, [x20, #0x118]     | this.startPoint = start;                 //  dest_result_addr=1152921513508167448
            this.startPoint = start;
            // 0x0168A1D4: STR s9, [x20, #0x11c]      | mem[1152921513508167452] = start.y;      //  dest_result_addr=1152921513508167452
            mem[1152921513508167452] = start.y;
            // 0x0168A1D8: STR s8, [x20, #0x120]      | mem[1152921513508167456] = start.z;      //  dest_result_addr=1152921513508167456
            mem[1152921513508167456] = start.z;
            // 0x0168A1DC: STR s10, [x20, #0x124]     | this.originalStartPoint = start;         //  dest_result_addr=1152921513508167460
            this.originalStartPoint = start;
            // 0x0168A1E0: STR s9, [x20, #0x128]      | mem[1152921513508167464] = start.y;      //  dest_result_addr=1152921513508167464
            mem[1152921513508167464] = start.y;
            // 0x0168A1E4: LDR x8, [x8, #0xd80]       | X8 = 1152921504849870848;               
            // 0x0168A1E8: LDR x0, [x8]               | X0 = typeof(Pathfinding.EndingConditionDistance);
            Pathfinding.PathEndingCondition val_1 = null;
            // 0x0168A1EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.EndingConditionDistance), ????);
            // 0x0168A1F0: MOV x21, x0                | X21 = 1152921504849870848 (0x100000000E7C4000);//ML01
            // 0x0168A1F4: MOVZ w8, #0x64             | W8 = 100 (0x64);//ML01                  
            // 0x0168A1F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A1FC: MOV x1, x20                | X1 = 1152921513508167168 (0x10000002128F5E00);//ML01
            // 0x0168A200: STR w8, [x21, #0x18]       | typeof(Pathfinding.EndingConditionDistance).__il2cppRuntimeField_18 = 0x64;  //  dest_result_addr=1152921504849870872
            typeof(Pathfinding.EndingConditionDistance).__il2cppRuntimeField_18 = 100;
            // 0x0168A204: BL #0x1405078              | .ctor(p:  this);                        
            val_1 = new Pathfinding.PathEndingCondition(p:  this);
            // 0x0168A208: STR w19, [x21, #0x18]      | typeof(Pathfinding.EndingConditionDistance).__il2cppRuntimeField_18 = maxGScore;  //  dest_result_addr=1152921504849870872
            typeof(Pathfinding.EndingConditionDistance).__il2cppRuntimeField_18 = maxGScore;
            // 0x0168A20C: STR x21, [x20, #0x138]     | this.endingCondition = typeof(Pathfinding.EndingConditionDistance);  //  dest_result_addr=1152921513508167480
            this.endingCondition = val_1;
            // 0x0168A210: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A214: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0168A218: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0168A21C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0168A220: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
            // 0x0168A224: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A25C (23634524), len: 148  VirtAddr: 0x0168A25C RVA: 0x0168A25C token: 100683602 methodIndex: 49927 delegateWrapperIndex: 0 methodInvoker: 0
        public override void OnEnterPool()
        {
            //
            // Disasemble & Code
            // 0x0168A25C: STP x20, x19, [sp, #-0x20]! | stack[1152921513508275328] = ???;  stack[1152921513508275336] = ???;  //  dest_result_addr=1152921513508275328 |  dest_result_addr=1152921513508275336
            // 0x0168A260: STP x29, x30, [sp, #0x10]  | stack[1152921513508275344] = ???;  stack[1152921513508275352] = ???;  //  dest_result_addr=1152921513508275344 |  dest_result_addr=1152921513508275352
            // 0x0168A264: ADD x29, sp, #0x10         | X29 = (1152921513508275328 + 16) = 1152921513508275344 (0x1000000212910490);
            // 0x0168A268: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A26C: LDRB w8, [x20, #0x102]     | W8 = (bool)static_value_03738102;       
            // 0x0168A270: MOV x19, x0                | X19 = 1152921513508287360 (0x1000000212913380);//ML01
            // 0x0168A274: TBNZ w8, #0, #0x168a290    | if (static_value_03738102 == true) goto label_0;
            // 0x0168A278: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x0168A27C: LDR x8, [x8, #0x18]        | X8 = 0x2B92824;                         
            // 0x0168A280: LDR w0, [x8]               | W0 = 0x20CE;                            
            // 0x0168A284: BL #0x2782188              | X0 = sub_2782188( ?? 0x20CE, ????);     
            // 0x0168A288: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A28C: STRB w8, [x20, #0x102]     | static_value_03738102 = true;            //  dest_result_addr=57901314
            label_0:
            // 0x0168A290: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A294: MOV x0, x19                | X0 = 1152921513508287360 (0x1000000212913380);//ML01
            // 0x0168A298: BL #0x14037d4              | this.OnEnterPool();                     
            this.OnEnterPool();
            // 0x0168A29C: LDR x19, [x19, #0x130]     | X19 = this.allNodes; //P2               
            // 0x0168A2A0: CBZ x19, #0x168a2e4        | if (this.allNodes == null) goto label_1;
            if(this.allNodes == null)
            {
                goto label_1;
            }
            // 0x0168A2A4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0168A2A8: LDR x8, [x8, #0x788]       | X8 = 1152921504839487488;               
            // 0x0168A2AC: LDR x0, [x8]               | X0 = typeof(Pathfinding.Util.ListPool<T>);
            // 0x0168A2B0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
            // 0x0168A2B4: TBZ w8, #0, #0x168a2c4     | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0168A2B8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x0168A2BC: CBNZ w8, #0x168a2c4        | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0168A2C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
            label_3:
            // 0x0168A2C4: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x0168A2C8: LDR x8, [x8, #0x2f8]       | X8 = 1152921513124413440;               
            // 0x0168A2CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A2D0: MOV x1, x19                | X1 = this.allNodes;//m1                 
            // 0x0168A2D4: LDR x2, [x8]               | X2 = public static System.Void Pathfinding.Util.ListPool<Pathfinding.GraphNode>::Release(System.Collections.Generic.List<T> list);
            // 0x0168A2D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A2DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0168A2E0: B #0x19fd24c               | Pathfinding.Util.ListPool<Pathfinding.NavmeshCut>.Release(list:  0); return;
            Pathfinding.Util.ListPool<Pathfinding.NavmeshCut>.Release(list:  0);
            return;
            label_1:
            // 0x0168A2E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A2E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0168A2EC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A2F0 (23634672), len: 116  VirtAddr: 0x0168A2F0 RVA: 0x0168A2F0 token: 100683603 methodIndex: 49928 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Recycle()
        {
            //
            // Disasemble & Code
            // 0x0168A2F0: STP x20, x19, [sp, #-0x20]! | stack[1152921513508392448] = ???;  stack[1152921513508392456] = ???;  //  dest_result_addr=1152921513508392448 |  dest_result_addr=1152921513508392456
            // 0x0168A2F4: STP x29, x30, [sp, #0x10]  | stack[1152921513508392464] = ???;  stack[1152921513508392472] = ???;  //  dest_result_addr=1152921513508392464 |  dest_result_addr=1152921513508392472
            // 0x0168A2F8: ADD x29, sp, #0x10         | X29 = (1152921513508392448 + 16) = 1152921513508392464 (0x100000021292CE10);
            // 0x0168A2FC: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A300: LDRB w8, [x20, #0x103]     | W8 = (bool)static_value_03738103;       
            // 0x0168A304: MOV x19, x0                | X19 = 1152921513508404480 (0x100000021292FD00);//ML01
            // 0x0168A308: TBNZ w8, #0, #0x168a324    | if (static_value_03738103 == true) goto label_0;
            // 0x0168A30C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0168A310: LDR x8, [x8, #0x7a8]       | X8 = 0x2B9282C;                         
            // 0x0168A314: LDR w0, [x8]               | W0 = 0x20D0;                            
            // 0x0168A318: BL #0x2782188              | X0 = sub_2782188( ?? 0x20D0, ????);     
            // 0x0168A31C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A320: STRB w8, [x20, #0x103]     | static_value_03738103 = true;            //  dest_result_addr=57901315
            label_0:
            // 0x0168A324: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x0168A328: LDR x8, [x8, #0x8f8]       | X8 = 1152921504839860224;               
            // 0x0168A32C: LDR x0, [x8]               | X0 = typeof(Pathfinding.PathPool<T>);   
            // 0x0168A330: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_10A;
            // 0x0168A334: TBZ w8, #0, #0x168a344     | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168A338: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x0168A33C: CBNZ w8, #0x168a344        | if (Pathfinding.PathPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168A340: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.PathPool<T>), ????);
            label_2:
            // 0x0168A344: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x0168A348: LDR x8, [x8, #0xb30]       | X8 = 1152921513508379456;               
            // 0x0168A34C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A350: MOV x1, x19                | X1 = 1152921513508404480 (0x100000021292FD00);//ML01
            // 0x0168A354: LDR x2, [x8]               | X2 = public static System.Void Pathfinding.PathPool<Pathfinding.ConstantPath>::Recycle(Pathfinding.ConstantPath path);
            // 0x0168A358: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A35C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0168A360: B #0x19f0bd8               | Pathfinding.PathPool<Pathfinding.RandomPath>.Recycle(path:  0); return;
            Pathfinding.PathPool<Pathfinding.RandomPath>.Recycle(path:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A364 (23634788), len: 224  VirtAddr: 0x0168A364 RVA: 0x0168A364 token: 100683604 methodIndex: 49929 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Reset()
        {
            //
            // Disasemble & Code
            // 0x0168A364: STP x20, x19, [sp, #-0x20]! | stack[1152921513508508544] = ???;  stack[1152921513508508552] = ???;  //  dest_result_addr=1152921513508508544 |  dest_result_addr=1152921513508508552
            // 0x0168A368: STP x29, x30, [sp, #0x10]  | stack[1152921513508508560] = ???;  stack[1152921513508508568] = ???;  //  dest_result_addr=1152921513508508560 |  dest_result_addr=1152921513508508568
            // 0x0168A36C: ADD x29, sp, #0x10         | X29 = (1152921513508508544 + 16) = 1152921513508508560 (0x1000000212949390);
            // 0x0168A370: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A374: LDRB w8, [x20, #0x104]     | W8 = (bool)static_value_03738104;       
            // 0x0168A378: MOV x19, x0                | X19 = 1152921513508520576 (0x100000021294C280);//ML01
            // 0x0168A37C: TBNZ w8, #0, #0x168a398    | if (static_value_03738104 == true) goto label_0;
            // 0x0168A380: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x0168A384: LDR x8, [x8, #0xa18]       | X8 = 0x2B92830;                         
            // 0x0168A388: LDR w0, [x8]               | W0 = 0x20D1;                            
            // 0x0168A38C: BL #0x2782188              | X0 = sub_2782188( ?? 0x20D1, ????);     
            // 0x0168A390: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A394: STRB w8, [x20, #0x104]     | static_value_03738104 = true;            //  dest_result_addr=57901316
            label_0:
            // 0x0168A398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A39C: MOV x0, x19                | X0 = 1152921513508520576 (0x100000021294C280);//ML01
            // 0x0168A3A0: BL #0x1403898              | this.Reset();                           
            this.Reset();
            // 0x0168A3A4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0168A3A8: LDR x8, [x8, #0x788]       | X8 = 1152921504839487488;               
            // 0x0168A3AC: LDR x0, [x8]               | X0 = typeof(Pathfinding.Util.ListPool<T>);
            // 0x0168A3B0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
            // 0x0168A3B4: TBZ w8, #0, #0x168a3c4     | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168A3B8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x0168A3BC: CBNZ w8, #0x168a3c4        | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168A3C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
            label_2:
            // 0x0168A3C4: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x0168A3C8: LDR x8, [x8, #0xc70]       | X8 = 1152921513135616192;               
            // 0x0168A3CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A3D0: LDR x1, [x8]               | X1 = public static System.Collections.Generic.List<T> Pathfinding.Util.ListPool<Pathfinding.GraphNode>::Claim();
            // 0x0168A3D4: BL #0x19fc480              | X0 = Pathfinding.Util.ListPool<Pathfinding.MeshNode>.Claim();
            System.Collections.Generic.List<T> val_1 = Pathfinding.Util.ListPool<Pathfinding.MeshNode>.Claim();
            // 0x0168A3D8: STP x0, xzr, [x19, #0x130] | this.allNodes = val_1;  this.endingCondition = null;  //  dest_result_addr=1152921513508520880 |  dest_result_addr=1152921513508520888
            this.allNodes = val_1;
            this.endingCondition = 0;
            // 0x0168A3DC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x0168A3E0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x0168A3E4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x0168A3E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0168A3EC: TBZ w8, #0, #0x168a3fc     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0168A3F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0168A3F4: CBNZ w8, #0x168a3fc        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0168A3F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_4:
            // 0x0168A3FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A400: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A404: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.zero;
            // 0x0168A408: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A40C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A410: STR s0, [x19, #0x124]      | this.originalStartPoint = val_2;         //  dest_result_addr=1152921513508520868
            this.originalStartPoint = val_2;
            // 0x0168A414: STR s1, [x19, #0x128]      | mem[1152921513508520872] = val_2.y;      //  dest_result_addr=1152921513508520872
            mem[1152921513508520872] = val_2.y;
            // 0x0168A418: STR s2, [x19, #0x12c]      | mem[1152921513508520876] = val_2.z;      //  dest_result_addr=1152921513508520876
            mem[1152921513508520876] = val_2.z;
            // 0x0168A41C: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_3 = UnityEngine.Vector3.zero;
            // 0x0168A420: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x0168A424: STR w8, [x19, #0xcc]       | mem[1152921513508520780] = 0x3;          //  dest_result_addr=1152921513508520780
            mem[1152921513508520780] = 3;
            // 0x0168A428: STR s0, [x19, #0x118]      | this.startPoint = val_3;                 //  dest_result_addr=1152921513508520856
            this.startPoint = val_3;
            // 0x0168A42C: STR s1, [x19, #0x11c]      | mem[1152921513508520860] = val_3.y;      //  dest_result_addr=1152921513508520860
            mem[1152921513508520860] = val_3.y;
            // 0x0168A430: STR s2, [x19, #0x120]      | mem[1152921513508520864] = val_3.z;      //  dest_result_addr=1152921513508520864
            mem[1152921513508520864] = val_3.z;
            // 0x0168A434: STR xzr, [x19, #0x110]     | this.startNode = null;                   //  dest_result_addr=1152921513508520848
            this.startNode = 0;
            // 0x0168A438: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A43C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0168A440: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A444 (23635012), len: 264  VirtAddr: 0x0168A444 RVA: 0x0168A444 token: 100683605 methodIndex: 49930 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Prepare()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.GraphNode val_2;
            //  | 
            var val_3;
            // 0x0168A444: STP d11, d10, [sp, #-0x50]! | stack[1152921513508637040] = ???;  stack[1152921513508637048] = ???;  //  dest_result_addr=1152921513508637040 |  dest_result_addr=1152921513508637048
            // 0x0168A448: STP d9, d8, [sp, #0x10]    | stack[1152921513508637056] = ???;  stack[1152921513508637064] = ???;  //  dest_result_addr=1152921513508637056 |  dest_result_addr=1152921513508637064
            // 0x0168A44C: STP x22, x21, [sp, #0x20]  | stack[1152921513508637072] = ???;  stack[1152921513508637080] = ???;  //  dest_result_addr=1152921513508637072 |  dest_result_addr=1152921513508637080
            // 0x0168A450: STP x20, x19, [sp, #0x30]  | stack[1152921513508637088] = ???;  stack[1152921513508637096] = ???;  //  dest_result_addr=1152921513508637088 |  dest_result_addr=1152921513508637096
            // 0x0168A454: STP x29, x30, [sp, #0x40]  | stack[1152921513508637104] = ???;  stack[1152921513508637112] = ???;  //  dest_result_addr=1152921513508637104 |  dest_result_addr=1152921513508637112
            // 0x0168A458: ADD x29, sp, #0x40         | X29 = (1152921513508637040 + 64) = 1152921513508637104 (0x10000002129689B0);
            // 0x0168A45C: SUB sp, sp, #0x30          | SP = (1152921513508637040 - 48) = 1152921513508636992 (0x1000000212968940);
            // 0x0168A460: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A464: LDRB w8, [x20, #0x105]     | W8 = (bool)static_value_03738105;       
            // 0x0168A468: MOV x19, x0                | X19 = 1152921513508649120 (0x100000021296B8A0);//ML01
            // 0x0168A46C: TBNZ w8, #0, #0x168a488    | if (static_value_03738105 == true) goto label_0;
            // 0x0168A470: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x0168A474: LDR x8, [x8, #0x840]       | X8 = 0x2B92828;                         
            // 0x0168A478: LDR w0, [x8]               | W0 = 0x20CF;                            
            // 0x0168A47C: BL #0x2782188              | X0 = sub_2782188( ?? 0x20CF, ????);     
            // 0x0168A480: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A484: STRB w8, [x20, #0x105]     | static_value_03738105 = true;            //  dest_result_addr=57901317
            label_0:
            // 0x0168A488: LDR x20, [x19, #0xa8]      | 
            // 0x0168A48C: LDR w21, [x19, #0xec]      | 
            // 0x0168A490: CBNZ x20, #0x168a498       | if ( != 0) goto label_1;                
            if(!=0)
            {
                goto label_1;
            }
            // 0x0168A494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x20CF, ????);     
            label_1:
            // 0x0168A498: STR w21, [x20, #0x20]      | static_value_03738020 = ;                //  dest_result_addr=57901088
            // 0x0168A49C: ADRP x20, #0x362c000       | X20 = 56803328 (0x362C000);             
            // 0x0168A4A0: LDR x20, [x20, #0xe80]     | X20 = 1152921504837996544;              
            // 0x0168A4A4: LDR x0, [x20]              | X0 = typeof(AstarPath);                 
            val_3 = null;
            // 0x0168A4A8: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0168A4AC: TBZ w8, #0, #0x168a4c0     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0168A4B0: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0168A4B4: CBNZ w8, #0x168a4c0        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0168A4B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0168A4BC: LDR x0, [x20]              | X0 = typeof(AstarPath);                 
            val_3 = null;
            label_3:
            // 0x0168A4C0: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0168A4C4: LDR s8, [x19, #0x118]      | S8 = this.startPoint; //P2              
            // 0x0168A4C8: LDR s9, [x19, #0x11c]      | 
            // 0x0168A4CC: LDR s10, [x19, #0x120]     | 
            // 0x0168A4D0: LDR x21, [x8, #0x18]       | X21 = AstarPath.active;                 
            // 0x0168A4D4: LDR x20, [x19, #0xa8]      | 
            // 0x0168A4D8: CBNZ x21, #0x168a4e0       | if (AstarPath.active != null) goto label_4;
            if(AstarPath.active != null)
            {
                goto label_4;
            }
            // 0x0168A4DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_4:
            // 0x0168A4E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A4E4: MOV x8, sp                 | X8 = 1152921513508636992 (0x1000000212968940);//ML01
            // 0x0168A4E8: MOV x0, x21                | X0 = AstarPath.active;//m1              
            // 0x0168A4EC: MOV v0.16b, v8.16b         | V0 = this.startPoint;//m1               
            // 0x0168A4F0: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
            // 0x0168A4F4: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
            // 0x0168A4F8: MOV x1, x20                | X1 = 57994512 (0x374ED10);//ML01        
            // 0x0168A4FC: BL #0xb4078c               | X0 = AstarPath.active.GetNearest(position:  new UnityEngine.Vector3() {x = this.startPoint, y = V9.16B, z = V10.16B}, constraint:  1152921504837996544);
            Pathfinding.NNInfo val_1 = AstarPath.active.GetNearest(position:  new UnityEngine.Vector3() {x = this.startPoint, y = V9.16B, z = V10.16B}, constraint:  1152921504837996544);
            // 0x0168A500: LDR x8, [sp]               | X8 = val_2;                              //  find_add[1152921513508625120]
            // 0x0168A504: STR x8, [x19, #0x110]      | this.startNode = val_2;                  //  dest_result_addr=1152921513508649392
            this.startNode = val_2;
            // 0x0168A508: CBNZ x8, #0x168a530        | if (val_2 != 0) goto label_5;           
            if(val_2 != 0)
            {
                goto label_5;
            }
            // 0x0168A50C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A510: MOV x0, x19                | X0 = 1152921513508649120 (0x100000021296B8A0);//ML01
            // 0x0168A514: BL #0x14035e8              | this.Error();                           
            this.Error();
            // 0x0168A518: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x0168A51C: LDR x8, [x8, #0xfe8]       | X8 = (string**)(1152921513508624960)("Could not find close node to the start point");
            // 0x0168A520: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A524: MOV x0, x19                | X0 = 1152921513508649120 (0x100000021296B8A0);//ML01
            // 0x0168A528: LDR x1, [x8]               | X1 = "Could not find close node to the start point";
            // 0x0168A52C: BL #0x140339c              | this.LogError(msg:  "Could not find close node to the start point");
            this.LogError(msg:  "Could not find close node to the start point");
            label_5:
            // 0x0168A530: SUB sp, x29, #0x40         | SP = (1152921513508637104 - 64) = 1152921513508637040 (0x1000000212968970);
            // 0x0168A534: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A538: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0168A53C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0168A540: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0168A544: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
            // 0x0168A548: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A54C (23635276), len: 432  VirtAddr: 0x0168A54C RVA: 0x0168A54C token: 100683606 methodIndex: 49931 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Initialize()
        {
            //
            // Disasemble & Code
            // 0x0168A54C: STP x22, x21, [sp, #-0x30]! | stack[1152921513508798224] = ???;  stack[1152921513508798232] = ???;  //  dest_result_addr=1152921513508798224 |  dest_result_addr=1152921513508798232
            // 0x0168A550: STP x20, x19, [sp, #0x10]  | stack[1152921513508798240] = ???;  stack[1152921513508798248] = ???;  //  dest_result_addr=1152921513508798240 |  dest_result_addr=1152921513508798248
            // 0x0168A554: STP x29, x30, [sp, #0x20]  | stack[1152921513508798256] = ???;  stack[1152921513508798264] = ???;  //  dest_result_addr=1152921513508798256 |  dest_result_addr=1152921513508798264
            // 0x0168A558: ADD x29, sp, #0x20         | X29 = (1152921513508798224 + 32) = 1152921513508798256 (0x100000021298FF30);
            // 0x0168A55C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A560: LDRB w8, [x20, #0x106]     | W8 = (bool)static_value_03738106;       
            // 0x0168A564: MOV x19, x0                | X19 = 1152921513508810272 (0x1000000212992E20);//ML01
            // 0x0168A568: TBNZ w8, #0, #0x168a584    | if (static_value_03738106 == true) goto label_0;
            // 0x0168A56C: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x0168A570: LDR x8, [x8, #0xc08]       | X8 = 0x2B92820;                         
            // 0x0168A574: LDR w0, [x8]               | W0 = 0x20CD;                            
            // 0x0168A578: BL #0x2782188              | X0 = sub_2782188( ?? 0x20CD, ????);     
            // 0x0168A57C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A580: STRB w8, [x20, #0x106]     | static_value_03738106 = true;            //  dest_result_addr=57901318
            label_0:
            // 0x0168A584: LDR x20, [x19, #0x18]      | 
            // 0x0168A588: LDR x21, [x19, #0x110]     | X21 = this.startNode; //P2              
            // 0x0168A58C: CBNZ x20, #0x168a594       | if ( != 0) goto label_1;                
            if(!=0)
            {
                goto label_1;
            }
            // 0x0168A590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x20CD, ????);     
            label_1:
            // 0x0168A594: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A598: MOV x0, x20                | X0 = 57901056 (0x3738000);//ML01        
            // 0x0168A59C: MOV x1, x21                | X1 = this.startNode;//m1                
            // 0x0168A5A0: BL #0x140535c              | X0 = GetPathNode(node:  this.startNode);
            Pathfinding.PathNode val_1 = GetPathNode(node:  this.startNode);
            // 0x0168A5A4: LDR x21, [x19, #0x110]     | X21 = this.startNode; //P2              
            // 0x0168A5A8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x0168A5AC: CBNZ x20, #0x168a5b4       | if (val_1 != null) goto label_2;        
            if(val_1 != null)
            {
                goto label_2;
            }
            // 0x0168A5B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x0168A5B4: STR x21, [x20, #0x10]      | val_1.node = this.startNode;             //  dest_result_addr=0
            val_1.node = this.startNode;
            // 0x0168A5B8: LDR x21, [x19, #0x18]      | 
            // 0x0168A5BC: CBNZ x21, #0x168a5c4       | if (this.startNode != null) goto label_3;
            if(this.startNode != null)
            {
                goto label_3;
            }
            // 0x0168A5C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x0168A5C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A5C8: MOV x0, x21                | X0 = this.startNode;//m1                
            // 0x0168A5CC: BL #0x1404d14              | X0 = this.startNode.get_PathID();       
            ushort val_2 = this.startNode.PathID;
            // 0x0168A5D0: STRH w0, [x20, #0x20]      | val_1.pathID = val_2;                    //  dest_result_addr=0
            val_1.pathID = val_2;
            // 0x0168A5D4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0168A5D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A5DC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0168A5E0: STR xzr, [x20, #0x18]      | val_1.parent = null;                     //  dest_result_addr=0
            val_1.parent = 0;
            // 0x0168A5E4: BL #0x1405bd4              | val_1.set_cost(value:  0);              
            val_1.cost = 0;
            // 0x0168A5E8: LDR x1, [x19, #0x110]      | X1 = this.startNode; //P2               
            // 0x0168A5EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A5F0: MOV x0, x19                | X0 = 1152921513508810272 (0x1000000212992E20);//ML01
            // 0x0168A5F4: BL #0x1403274              | X0 = this.GetTraversalCost(node:  this.startNode);
            uint val_3 = this.GetTraversalCost(node:  this.startNode);
            // 0x0168A5F8: MOV w1, w0                 | W1 = val_3;//m1                         
            // 0x0168A5FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A600: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0168A604: BL #0x1405c98              | val_1.set_G(value:  val_3);             
            val_1.G = val_3;
            // 0x0168A608: LDR x1, [x19, #0x110]      | X1 = this.startNode; //P2               
            // 0x0168A60C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A610: MOV x0, x19                | X0 = 1152921513508810272 (0x1000000212992E20);//ML01
            // 0x0168A614: BL #0x1402e98              | X0 = this.CalculateHScore(node:  this.startNode);
            uint val_4 = this.CalculateHScore(node:  this.startNode);
            // 0x0168A618: MOV w1, w0                 | W1 = val_4;//m1                         
            // 0x0168A61C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A620: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0168A624: BL #0x1405ca8              | val_1.set_H(value:  val_4);             
            val_1.H = val_4;
            // 0x0168A628: LDR x22, [x19, #0x110]     | X22 = this.startNode; //P2              
            // 0x0168A62C: LDR x21, [x19, #0x18]      | 
            // 0x0168A630: CBNZ x22, #0x168a638       | if (this.startNode != null) goto label_4;
            if(this.startNode != null)
            {
                goto label_4;
            }
            // 0x0168A634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x0168A638: LDR x8, [x22]              | X8 = typeof(Pathfinding.GraphNode);     
            // 0x0168A63C: MOV x0, x22                | X0 = this.startNode;//m1                
            // 0x0168A640: MOV x1, x19                | X1 = 1152921513508810272 (0x1000000212992E20);//ML01
            // 0x0168A644: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x0168A648: LDP x9, x4, [x8, #0x1e0]   | X9 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E0; X4 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E8; //  | 
            // 0x0168A64C: MOV x3, x21                | X3 = this.startNode;//m1                
            // 0x0168A650: BLR x9                     | X0 = typeof(Pathfinding.GraphNode).__il2cppRuntimeField_1E0();
            // 0x0168A654: LDR w8, [x19, #0x88]       | 
            // 0x0168A658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A65C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0168A660: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x0168A664: ADD w8, w8, #1             |  //  not_find_field:typeof(Pathfinding.GraphNode).1
            // 0x0168A668: STR w8, [x19, #0x88]       | mem[1152921513508810408] = typeof(Pathfinding.GraphNode);  //  dest_result_addr=1152921513508810408
            mem[1152921513508810408] = null;
            // 0x0168A66C: BL #0x1405bf4              | val_1.set_flag1(value:  true);          
            val_1.flag1 = true;
            // 0x0168A670: LDR x20, [x19, #0x130]     | X20 = this.allNodes; //P2               
            // 0x0168A674: LDR x21, [x19, #0x110]     | X21 = this.startNode; //P2              
            // 0x0168A678: CBNZ x20, #0x168a680       | if (this.allNodes != null) goto label_5;
            if(this.allNodes != null)
            {
                goto label_5;
            }
            // 0x0168A67C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x0168A680: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x0168A684: LDR x8, [x8, #0x278]       | X8 = 1152921513124700544;               
            // 0x0168A688: MOV x0, x20                | X0 = this.allNodes;//m1                 
            // 0x0168A68C: MOV x1, x21                | X1 = this.startNode;//m1                
            // 0x0168A690: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.GraphNode>::Add(Pathfinding.GraphNode item);
            // 0x0168A694: BL #0x25ea480              | this.allNodes.Add(item:  this.startNode);
            this.allNodes.Add(item:  this.startNode);
            // 0x0168A698: LDR x20, [x19, #0x18]      | 
            // 0x0168A69C: CBNZ x20, #0x168a6a4       | if (this.allNodes != null) goto label_6;
            if(this.allNodes != null)
            {
                goto label_6;
            }
            // 0x0168A6A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.allNodes, ????);
            label_6:
            // 0x0168A6A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A6A8: MOV x0, x20                | X0 = this.allNodes;//m1                 
            // 0x0168A6AC: BL #0x14052ec              | X0 = this.allNodes.HeapEmpty();         
            bool val_5 = this.allNodes.HeapEmpty();
            // 0x0168A6B0: TBZ w0, #0, #0x168a6d0     | if (val_5 == false) goto label_7;       
            if(val_5 == false)
            {
                goto label_7;
            }
            // 0x0168A6B4: MOV x0, x19                | X0 = 1152921513508810272 (0x1000000212992E20);//ML01
            // 0x0168A6B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A6BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0168A6C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A6C4: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0168A6C8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168A6CC: B #0x1402bf8               | this.set_CompleteState(value:  2); return;
            this.CompleteState = 2;
            return;
            label_7:
            // 0x0168A6D0: LDR x20, [x19, #0x18]      | 
            // 0x0168A6D4: CBNZ x20, #0x168a6dc       | if (this.allNodes != null) goto label_8;
            if(this.allNodes != null)
            {
                goto label_8;
            }
            // 0x0168A6D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_8:
            // 0x0168A6DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A6E0: MOV x0, x20                | X0 = this.allNodes;//m1                 
            // 0x0168A6E4: BL #0x140528c              | X0 = this.allNodes.PopNode();           
            Pathfinding.PathNode val_6 = this.allNodes.PopNode();
            // 0x0168A6E8: STR x0, [x19, #0x78]       | mem[1152921513508810392] = val_6;        //  dest_result_addr=1152921513508810392
            mem[1152921513508810392] = val_6;
            // 0x0168A6EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A6F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0168A6F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168A6F8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A6FC (23635708), len: 236  VirtAddr: 0x0168A6FC RVA: 0x0168A6FC token: 100683607 methodIndex: 49932 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Cleanup()
        {
            //
            // Disasemble & Code
            // 0x0168A6FC: STP x24, x23, [sp, #-0x40]! | stack[1152921513508963456] = ???;  stack[1152921513508963464] = ???;  //  dest_result_addr=1152921513508963456 |  dest_result_addr=1152921513508963464
            // 0x0168A700: STP x22, x21, [sp, #0x10]  | stack[1152921513508963472] = ???;  stack[1152921513508963480] = ???;  //  dest_result_addr=1152921513508963472 |  dest_result_addr=1152921513508963480
            // 0x0168A704: STP x20, x19, [sp, #0x20]  | stack[1152921513508963488] = ???;  stack[1152921513508963496] = ???;  //  dest_result_addr=1152921513508963488 |  dest_result_addr=1152921513508963496
            // 0x0168A708: STP x29, x30, [sp, #0x30]  | stack[1152921513508963504] = ???;  stack[1152921513508963512] = ???;  //  dest_result_addr=1152921513508963504 |  dest_result_addr=1152921513508963512
            // 0x0168A70C: ADD x29, sp, #0x30         | X29 = (1152921513508963456 + 48) = 1152921513508963504 (0x10000002129B84B0);
            // 0x0168A710: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168A714: LDRB w8, [x20, #0x107]     | W8 = (bool)static_value_03738107;       
            // 0x0168A718: MOV x19, x0                | X19 = 1152921513508975520 (0x10000002129BB3A0);//ML01
            // 0x0168A71C: TBNZ w8, #0, #0x168a738    | if (static_value_03738107 == true) goto label_0;
            // 0x0168A720: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0168A724: LDR x8, [x8, #0x700]       | X8 = 0x2B92818;                         
            // 0x0168A728: LDR w0, [x8]               | W0 = 0x20CB;                            
            // 0x0168A72C: BL #0x2782188              | X0 = sub_2782188( ?? 0x20CB, ????);     
            // 0x0168A730: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168A734: STRB w8, [x20, #0x107]     | static_value_03738107 = true;            //  dest_result_addr=57901319
            label_0:
            // 0x0168A738: LDR x20, [x19, #0x130]     | X20 = this.allNodes; //P2               
            // 0x0168A73C: CBNZ x20, #0x168a744       | if (this.allNodes != null) goto label_1;
            if(this.allNodes != null)
            {
                goto label_1;
            }
            // 0x0168A740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x20CB, ????);     
            label_1:
            // 0x0168A744: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x0168A748: LDR x8, [x8, #0xb50]       | X8 = 1152921513122910176;               
            // 0x0168A74C: MOV x0, x20                | X0 = this.allNodes;//m1                 
            // 0x0168A750: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Pathfinding.GraphNode>::get_Count();
            // 0x0168A754: BL #0x25ed72c              | X0 = this.allNodes.get_Count();         
            int val_1 = this.allNodes.Count;
            // 0x0168A758: MOV w20, w0                | W20 = val_1;//m1                        
            // 0x0168A75C: CMP w20, #1                | STATE = COMPARE(val_1, 0x1)             
            // 0x0168A760: B.LT #0x168a7d4            | if (val_1 < 1) goto label_2;            
            if(val_1 < 1)
            {
                goto label_2;
            }
            // 0x0168A764: ADRP x24, #0x35d1000       | X24 = 56430592 (0x35D1000);             
            // 0x0168A768: LDR x24, [x24, #0x8b8]     | X24 = 1152921513122944992;              
            // 0x0168A76C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            var val_4 = 0;
            label_6:
            // 0x0168A770: LDR x22, [x19, #0x18]      | 
            // 0x0168A774: LDR x23, [x19, #0x130]     | X23 = this.allNodes; //P2               
            // 0x0168A778: CBNZ x23, #0x168a780       | if (this.allNodes != null) goto label_3;
            if(this.allNodes != null)
            {
                goto label_3;
            }
            // 0x0168A77C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x0168A780: LDR x2, [x24]              | X2 = public Pathfinding.GraphNode System.Collections.Generic.List<Pathfinding.GraphNode>::get_Item(int index);
            // 0x0168A784: MOV x0, x23                | X0 = this.allNodes;//m1                 
            // 0x0168A788: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x0168A78C: BL #0x25ed734              | X0 = this.allNodes.get_Item(index:  0); 
            Pathfinding.GraphNode val_2 = this.allNodes.Item[0];
            // 0x0168A790: MOV x23, x0                | X23 = val_2;//m1                        
            // 0x0168A794: CBNZ x22, #0x168a79c       | if (X22 != 0) goto label_4;             
            if(X22 != 0)
            {
                goto label_4;
            }
            // 0x0168A798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x0168A79C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A7A0: MOV x0, x22                | X0 = X22;//m1                           
            // 0x0168A7A4: MOV x1, x23                | X1 = val_2;//m1                         
            // 0x0168A7A8: BL #0x140535c              | X0 = X22.GetPathNode(node:  val_2);     
            Pathfinding.PathNode val_3 = X22.GetPathNode(node:  val_2);
            // 0x0168A7AC: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x0168A7B0: CBNZ x22, #0x168a7b8       | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x0168A7B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x0168A7B8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0168A7BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A7C0: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x0168A7C4: BL #0x1405bf4              | val_3.set_flag1(value:  false);         
            val_3.flag1 = false;
            // 0x0168A7C8: ADD w21, w21, #1           | W21 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x0168A7CC: CMP w20, w21               | STATE = COMPARE(val_1, (0 + 1))         
            // 0x0168A7D0: B.NE #0x168a770            | if (val_1 != 0) goto label_6;           
            if(val_1 != val_4)
            {
                goto label_6;
            }
            label_2:
            // 0x0168A7D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A7D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0168A7DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0168A7E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0168A7E4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168A7E8 (23635944), len: 620  VirtAddr: 0x0168A7E8 RVA: 0x0168A7E8 token: 100683608 methodIndex: 49933 delegateWrapperIndex: 0 methodInvoker: 0
        public override void CalculateStep(long targetTick)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.PathEndingCondition val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            // 0x0168A7E8: STP x28, x27, [sp, #-0x60]! | stack[1152921513509113312] = ???;  stack[1152921513509113320] = ???;  //  dest_result_addr=1152921513509113312 |  dest_result_addr=1152921513509113320
            // 0x0168A7EC: STP x26, x25, [sp, #0x10]  | stack[1152921513509113328] = ???;  stack[1152921513509113336] = ???;  //  dest_result_addr=1152921513509113328 |  dest_result_addr=1152921513509113336
            // 0x0168A7F0: STP x24, x23, [sp, #0x20]  | stack[1152921513509113344] = ???;  stack[1152921513509113352] = ???;  //  dest_result_addr=1152921513509113344 |  dest_result_addr=1152921513509113352
            // 0x0168A7F4: STP x22, x21, [sp, #0x30]  | stack[1152921513509113360] = ???;  stack[1152921513509113368] = ???;  //  dest_result_addr=1152921513509113360 |  dest_result_addr=1152921513509113368
            // 0x0168A7F8: STP x20, x19, [sp, #0x40]  | stack[1152921513509113376] = ???;  stack[1152921513509113384] = ???;  //  dest_result_addr=1152921513509113376 |  dest_result_addr=1152921513509113384
            // 0x0168A7FC: STP x29, x30, [sp, #0x50]  | stack[1152921513509113392] = ???;  stack[1152921513509113400] = ???;  //  dest_result_addr=1152921513509113392 |  dest_result_addr=1152921513509113400
            // 0x0168A800: ADD x29, sp, #0x50         | X29 = (1152921513509113312 + 80) = 1152921513509113392 (0x10000002129DCE30);
            // 0x0168A804: SUB sp, sp, #0x10          | SP = (1152921513509113312 - 16) = 1152921513509113296 (0x10000002129DCDD0);
            // 0x0168A808: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x0168A80C: LDRB w8, [x21, #0x108]     | W8 = (bool)static_value_03738108;       
            // 0x0168A810: MOV x20, x1                | X20 = targetTick;//m1                   
            // 0x0168A814: MOV x19, x0                | X19 = 1152921513509125408 (0x10000002129DFD20);//ML01
            // 0x0168A818: TBNZ w8, #0, #0x168a834    | if (static_value_03738108 == true) goto label_0;
            // 0x0168A81C: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x0168A820: LDR x8, [x8, #0xba0]       | X8 = 0x2B92814;                         
            // 0x0168A824: LDR w0, [x8]               | W0 = 0x20CA;                            
            // 0x0168A828: BL #0x2782188              | X0 = sub_2782188( ?? 0x20CA, ????);     
            // 0x0168A82C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            bool val_10 = true;
            // 0x0168A830: STRB w8, [x21, #0x108]     | static_value_03738108 = true;            //  dest_result_addr=57901320
            label_0:
            // 0x0168A834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A838: MOV x0, x19                | X0 = 1152921513509125408 (0x10000002129DFD20);//ML01
            // 0x0168A83C: STP xzr, xzr, [sp]         | stack[1152921513509113296] = 0x0;  stack[1152921513509113304] = 0x0;  //  dest_result_addr=1152921513509113296 |  dest_result_addr=1152921513509113304
            // 0x0168A840: BL #0x1402bf0              | X0 = this.get_CompleteState();          
            PathCompleteState val_1 = this.CompleteState;
            // 0x0168A844: CBNZ w0, #0x168a9f4        | if (val_1 != 0) goto label_20;          
            if(val_1 != 0)
            {
                goto label_20;
            }
            // 0x0168A848: ADRP x24, #0x364f000       | X24 = 56946688 (0x364F000);             
            // 0x0168A84C: ADRP x26, #0x35d8000       | X26 = 56459264 (0x35D8000);             
            // 0x0168A850: LDR x24, [x24, #0x9e0]     | X24 = 1152921504652693504;              
            // 0x0168A854: LDR x26, [x26, #0x278]     | X26 = 1152921513124700544;              
            // 0x0168A858: MOVZ w25, #0xf, lsl #16    | W25 = 983040 (0xF0000);//ML01           
            // 0x0168A85C: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x0168A860: MOVK w25, #0x4241          | W25 = 1000001 (0xF4241);                
            label_19:
            // 0x0168A864: LDR w8, [x19, #0x88]       | 
            // 0x0168A868: LDR x21, [x19, #0x138]     | X21 = this.endingCondition; //P2        
            val_10 = this.endingCondition;
            // 0x0168A86C: LDR x22, [x19, #0x78]      | 
            // 0x0168A870: ADD w8, w8, #1             | W8 = (true + 1);                        
            val_10 = val_10 + 1;
            // 0x0168A874: STR w8, [x19, #0x88]       | mem[1152921513509125544] = (true + 1);   //  dest_result_addr=1152921513509125544
            mem[1152921513509125544] = val_10;
            // 0x0168A878: CBNZ x21, #0x168a880       | if (this.endingCondition != null) goto label_2;
            if(val_10 != null)
            {
                goto label_2;
            }
            // 0x0168A87C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x0168A880: LDR x8, [x21]              | X8 = typeof(Pathfinding.PathEndingCondition);
            // 0x0168A884: MOV x0, x21                | X0 = this.endingCondition;//m1          
            // 0x0168A888: MOV x1, x22                | X1 = X22;//m1                           
            // 0x0168A88C: LDP x9, x2, [x8, #0x150]   | X9 = typeof(Pathfinding.PathEndingCondition).__il2cppRuntimeField_150; X2 = typeof(Pathfinding.PathEndingCondition).__il2cppRuntimeField_158; //  | 
            // 0x0168A890: BLR x9                     | X0 = typeof(Pathfinding.PathEndingCondition).__il2cppRuntimeField_150();
            // 0x0168A894: TBNZ w0, #0, #0x168a9e4    | if ((this.endingCondition & 0x1) != 0) goto label_12;
            if((val_10 & 1) != 0)
            {
                goto label_12;
            }
            // 0x0168A898: LDR x21, [x19, #0x78]      | 
            // 0x0168A89C: CBNZ x21, #0x168a8a4       | if (this.endingCondition != null) goto label_4;
            if(val_10 != null)
            {
                goto label_4;
            }
            // 0x0168A8A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.endingCondition, ????);
            label_4:
            // 0x0168A8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A8A8: MOV x0, x21                | X0 = this.endingCondition;//m1          
            // 0x0168A8AC: BL #0x1405be8              | X0 = this.endingCondition.get_flag1();  
            bool val_2 = val_10.flag1;
            // 0x0168A8B0: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x0168A8B4: TBNZ w8, #0, #0x168a900    | if ((val_2 & 1) == true) goto label_5;  
            if(val_3 == true)
            {
                goto label_5;
            }
            // 0x0168A8B8: LDR x21, [x19, #0x130]     | X21 = this.allNodes; //P2               
            // 0x0168A8BC: LDR x22, [x19, #0x78]      | 
            // 0x0168A8C0: CBNZ x22, #0x168a8c8       | if (X22 != 0) goto label_6;             
            if(X22 != 0)
            {
                goto label_6;
            }
            // 0x0168A8C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x0168A8C8: LDR x22, [x22, #0x10]      | X22 = X22 + 16;                         
            // 0x0168A8CC: CBNZ x21, #0x168a8d4       | if (this.allNodes != null) goto label_7;
            if(this.allNodes != null)
            {
                goto label_7;
            }
            // 0x0168A8D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_7:
            // 0x0168A8D4: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<Pathfinding.GraphNode>::Add(Pathfinding.GraphNode item);
            // 0x0168A8D8: MOV x0, x21                | X0 = this.allNodes;//m1                 
            // 0x0168A8DC: MOV x1, x22                | X1 = X22 + 16;//m1                      
            // 0x0168A8E0: BL #0x25ea480              | this.allNodes.Add(item:  X22 + 16);     
            this.allNodes.Add(item:  X22 + 16);
            // 0x0168A8E4: LDR x21, [x19, #0x78]      | 
            // 0x0168A8E8: CBNZ x21, #0x168a8f0       | if (this.allNodes != null) goto label_8;
            if(this.allNodes != null)
            {
                goto label_8;
            }
            // 0x0168A8EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.allNodes, ????);
            label_8:
            // 0x0168A8F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A8F4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0168A8F8: MOV x0, x21                | X0 = this.allNodes;//m1                 
            // 0x0168A8FC: BL #0x1405bf4              | this.allNodes.set_flag1(value:  true);  
            this.allNodes.flag1 = true;
            label_5:
            // 0x0168A900: LDR x22, [x19, #0x78]      | 
            // 0x0168A904: MOV x21, x22               | X21 = X22 + 16;//m1                     
            val_12 = X22 + 16;
            // 0x0168A908: CBNZ x22, #0x168a914       | if (X22 + 16 != 0) goto label_9;        
            if((X22 + 16) != 0)
            {
                goto label_9;
            }
            // 0x0168A90C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.allNodes, ????);
            // 0x0168A910: LDR x21, [x19, #0x78]      | 
            label_9:
            // 0x0168A914: LDR x23, [x22, #0x10]      | X23 = X22 + 16 + 16;                    
            // 0x0168A918: LDR x22, [x19, #0x18]      | 
            // 0x0168A91C: CBNZ x23, #0x168a924       | if (X22 + 16 + 16 != 0) goto label_10;  
            if((X22 + 16 + 16) != 0)
            {
                goto label_10;
            }
            // 0x0168A920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.allNodes, ????);
            label_10:
            // 0x0168A924: LDR x8, [x23]              | X8 = X22 + 16 + 16;                     
            // 0x0168A928: MOV x0, x23                | X0 = X22 + 16 + 16;//m1                 
            // 0x0168A92C: MOV x1, x19                | X1 = 1152921513509125408 (0x10000002129DFD20);//ML01
            // 0x0168A930: MOV x2, x21                | X2 = X22 + 16;//m1                      
            // 0x0168A934: LDP x9, x4, [x8, #0x1e0]   | X9 = X22 + 16 + 16 + 480; X4 = X22 + 16 + 16 + 480 + 8; //  | 
            // 0x0168A938: MOV x3, x22                | X3 = X22 + 16;//m1                      
            // 0x0168A93C: BLR x9                     | X0 = X22 + 16 + 16 + 480();             
            // 0x0168A940: LDR x21, [x19, #0x18]      | 
            // 0x0168A944: CBNZ x21, #0x168a94c       | if (X22 + 16 != 0) goto label_11;       
            if(val_12 != 0)
            {
                goto label_11;
            }
            // 0x0168A948: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22 + 16 + 16, ????);
            label_11:
            // 0x0168A94C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A950: MOV x0, x21                | X0 = X22 + 16;//m1                      
            // 0x0168A954: BL #0x14052ec              | X0 = X22 + 16.HeapEmpty();              
            bool val_4 = val_12.HeapEmpty();
            // 0x0168A958: TBNZ w0, #0, #0x168a9e4    | if (val_4 == true) goto label_12;       
            if(val_4 == true)
            {
                goto label_12;
            }
            // 0x0168A95C: LDR x21, [x19, #0x18]      | 
            // 0x0168A960: CBNZ x21, #0x168a968       | if (X22 + 16 != 0) goto label_13;       
            if(val_12 != 0)
            {
                goto label_13;
            }
            // 0x0168A964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_13:
            // 0x0168A968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A96C: MOV x0, x21                | X0 = X22 + 16;//m1                      
            // 0x0168A970: BL #0x140528c              | X0 = X22 + 16.PopNode();                
            Pathfinding.PathNode val_5 = val_12.PopNode();
            // 0x0168A974: STR x0, [x19, #0x78]       | mem[1152921513509125528] = val_5;        //  dest_result_addr=1152921513509125528
            mem[1152921513509125528] = val_5;
            // 0x0168A978: CMP w27, #0x1f5            | STATE = COMPARE(0x0, 0x1F5)             
            // 0x0168A97C: B.LT #0x168a9cc            | if (val_11 < 0x1F5) goto label_14;      
            if(val_11 < 501)
            {
                goto label_14;
            }
            // 0x0168A980: LDR x0, [x24]              | X0 = typeof(System.DateTime);           
            // 0x0168A984: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x0168A988: TBZ w8, #0, #0x168a998     | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x0168A98C: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x0168A990: CBNZ w8, #0x168a998        | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x0168A994: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_16:
            // 0x0168A998: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168A99C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A9A0: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
            System.DateTime val_6 = System.DateTime.UtcNow;
            // 0x0168A9A4: STP x0, x1, [sp]           | stack[1152921513509113296] = val_6.ticks._ticks;  stack[1152921513509113304] = val_6.kind;  //  dest_result_addr=1152921513509113296 |  dest_result_addr=1152921513509113304
            // 0x0168A9A8: MOV x0, sp                 | X0 = 1152921513509113296 (0x10000002129DCDD0);//ML01
            // 0x0168A9AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A9B0: BL #0x1bacf30              | X0 = val_6.ticks._ticks.get_Ticks();    
            long val_7 = val_6.ticks._ticks.Ticks;
            // 0x0168A9B4: CMP x0, x20                | STATE = COMPARE(val_7, targetTick)      
            // 0x0168A9B8: B.GE #0x168a9f4            | if (val_7 >= targetTick) goto label_20; 
            if(val_7 >= targetTick)
            {
                goto label_20;
            }
            // 0x0168A9BC: LDR w8, [x19, #0x88]       | 
            // 0x0168A9C0: CMP w8, w25                | STATE = COMPARE(System.DateTime.__il2cppRuntimeField_cctor_finished, 0xF4241)
            // 0x0168A9C4: B.GE #0x168aa14            | if (System.DateTime.__il2cppRuntimeField_cctor_finished >= 0xF4241) goto label_18;
            // 0x0168A9C8: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_14:
            // 0x0168A9CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168A9D0: MOV x0, x19                | X0 = 1152921513509125408 (0x10000002129DFD20);//ML01
            // 0x0168A9D4: ADD w27, w27, #1           | W27 = (val_13 + 1);                     
            val_14 = val_13 + 1;
            // 0x0168A9D8: BL #0x1402bf0              | X0 = this.get_CompleteState();          
            PathCompleteState val_8 = this.CompleteState;
            // 0x0168A9DC: CBZ w0, #0x168a864         | if (val_8 == 0) goto label_19;          
            if(val_8 == 0)
            {
                goto label_19;
            }
            // 0x0168A9E0: B #0x168a9f4               |  goto label_20;                         
            goto label_20;
            label_12:
            // 0x0168A9E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168A9E8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x0168A9EC: MOV x0, x19                | X0 = 1152921513509125408 (0x10000002129DFD20);//ML01
            // 0x0168A9F0: BL #0x1402bf8              | this.set_CompleteState(value:  2);      
            this.CompleteState = 2;
            label_20:
            // 0x0168A9F4: SUB sp, x29, #0x50         | SP = (1152921513509113392 - 80) = 1152921513509113312 (0x10000002129DCDE0);
            // 0x0168A9F8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0168A9FC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0168AA00: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0168AA04: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0168AA08: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0168AA0C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0168AA10: RET                        |  return;                                
            return;
            label_18:
            // 0x0168AA14: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0168AA18: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x0168AA1C: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_9 = null;
            // 0x0168AA20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x0168AA24: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x0168AA28: LDR x8, [x8, #0xbc0]       | X8 = (string**)(1152921513506508864)("Probable infinite loop. Over 1,000,000 nodes searched");
            // 0x0168AA2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168AA30: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0168AA34: LDR x1, [x8]               | X1 = "Probable infinite loop. Over 1,000,000 nodes searched";
            // 0x0168AA38: BL #0x1c32b48              | .ctor(message:  "Probable infinite loop. Over 1,000,000 nodes searched");
            val_9 = new System.Exception(message:  "Probable infinite loop. Over 1,000,000 nodes searched");
            // 0x0168AA3C: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x0168AA40: LDR x8, [x8, #0x508]       | X8 = 1152921513509100384;               
            // 0x0168AA44: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0168AA48: LDR x1, [x8]               | X1 = public System.Void Pathfinding.ConstantPath::CalculateStep(long targetTick);
            // 0x0168AA4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x0168AA50: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
    
    }

}
