using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonValue : BsonToken
    {
        // Fields
        private object _value; //  0x00000020
        private Newtonsoft.Json.Bson.BsonType _type; //  0x00000028
        
        // Properties
        public object Value { get; }
        public override Newtonsoft.Json.Bson.BsonType Type { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD4794 (11356052), len: 60  VirtAddr: 0x00AD4794 RVA: 0x00AD4794 token: 100684776 methodIndex: 47436 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonValue(object value, Newtonsoft.Json.Bson.BsonType type)
        {
            //
            // Disasemble & Code
            // 0x00AD4794: STP x22, x21, [sp, #-0x30]! | stack[1152921513723640096] = ???;  stack[1152921513723640104] = ???;  //  dest_result_addr=1152921513723640096 |  dest_result_addr=1152921513723640104
            // 0x00AD4798: STP x20, x19, [sp, #0x10]  | stack[1152921513723640112] = ???;  stack[1152921513723640120] = ???;  //  dest_result_addr=1152921513723640112 |  dest_result_addr=1152921513723640120
            // 0x00AD479C: STP x29, x30, [sp, #0x20]  | stack[1152921513723640128] = ???;  stack[1152921513723640136] = ???;  //  dest_result_addr=1152921513723640128 |  dest_result_addr=1152921513723640136
            // 0x00AD47A0: ADD x29, sp, #0x20         | X29 = (1152921513723640096 + 32) = 1152921513723640128 (0x100000021F673940);
            // 0x00AD47A4: MOV x20, x1                | X20 = value;//m1                        
            // 0x00AD47A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD47AC: MOV w19, w2                | W19 = type;//m1                         
            // 0x00AD47B0: MOV x21, x0                | X21 = 1152921513723652144 (0x100000021F676830);//ML01
            // 0x00AD47B4: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00AD47B8: STRB w19, [x21, #0x28]     | this._type = type;                       //  dest_result_addr=1152921513723652184
            this._type = type;
            // 0x00AD47BC: STR x20, [x21, #0x20]      | this._value = value;                     //  dest_result_addr=1152921513723652176
            this._value = value;
            // 0x00AD47C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD47C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD47C8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AD47CC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1838 (11343928), len: 8  VirtAddr: 0x00AD1838 RVA: 0x00AD1838 token: 100684777 methodIndex: 47437 delegateWrapperIndex: 0 methodInvoker: 0
        public object get_Value()
        {
            //
            // Disasemble & Code
            // 0x00AD1838: LDR x0, [x0, #0x20]        | X0 = this._value; //P2                  
            // 0x00AD183C: RET                        |  return (System.Object)this._value;     
            return this._value;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD47E4 (11356132), len: 8  VirtAddr: 0x00AD47E4 RVA: 0x00AD47E4 token: 100684778 methodIndex: 47438 delegateWrapperIndex: 0 methodInvoker: 0
        public override Newtonsoft.Json.Bson.BsonType get_Type()
        {
            //
            // Disasemble & Code
            // 0x00AD47E4: LDRB w0, [x0, #0x28]       | W0 = this._type; //P2                   
            // 0x00AD47E8: RET                        |  return (Newtonsoft.Json.Bson.BsonType)this._type;
            return this._type;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonType, size=8, nGRN=0 }
        
        }
    
    }

}
