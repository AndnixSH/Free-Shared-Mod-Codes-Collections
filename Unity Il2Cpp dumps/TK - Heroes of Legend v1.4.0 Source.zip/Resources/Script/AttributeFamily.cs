using UnityEngine;
[System.FlagsAttribute] // 0x286A4A0
internal enum MetaType.AttributeFamily
{
    // Fields
    None = 0
    ,ProtoBuf = 1
    ,DataContractSerialier = 2
    ,XmlSerializer = 4
    ,AutoTuple = 8
    

}
