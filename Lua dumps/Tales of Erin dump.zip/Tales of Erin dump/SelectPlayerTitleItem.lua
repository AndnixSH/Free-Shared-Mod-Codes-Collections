
--[[
	SelectPlayerTitleItem.lua
]]
SelectPlayerTitleItem = class("SelectPlayerTitleItem", XUICellView)
SelectPlayerTitleItem.CS_FILE_NAME = "SelectPlayerTitleItem.csb"
SelectPlayerTitleItem.CS_BIND_TABLE = 
{
    rootPanel = "/s:panel",
    touchPanel = "/s:panel"
}

function SelectPlayerTitleItem:init(...)
    SelectPlayerTitleItem.super.init(self,...)
    self.isSelect = false
    self.skeletonNode = nil
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    --self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)
    return self
end

--重置UI
function SelectPlayerTitleItem:onResetData()
    if not self._data then return end
    local data = self._data

    local root = self.rootPanel
    local id = tonumber(data.id)

    local isSelectImg = root:getChildByName("isSelect")

	local desLabel = root:getChildByName("des")
	local desStr = UITool.getUserLanguage(title_conf[id].des)
    -- local desStr = "无称号技能"
    -- if title_conf[id].psk_id == 0 then 

    -- else 
    --     --todo 获取技能说明
    --     local skStr = ""
    --     if passive_sk[title_conf[id].psk_id] then 
    --         skStr = passive_sk[title_conf[id].psk_id].sk_det_des
    --     end 
    --     desStr = skStr
    -- end 
    desLabel:setString(desStr)

    local btn = root:getChildByName("UserBtn")
    --id:称号id,state:称号状态,-1未拥有,0未装备,1已装备
    if data.state == 1 then 
    	isSelectImg:setVisible(true)
    	btn:setVisible(false)
    else 
		isSelectImg:setVisible(false)
		btn:setVisible(true)
	end 
	btn:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			dump("点击装备")
			self.selectUserEvent(id)
        end
    end)

	local spineRoot = root:getChildByName("spineRoot")
	if self.skeletonNode and tolua.isnull(self.skeletonNode) == false then 
		self.skeletonNode:stopAllActions()
		self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
	end 

    local id_str = title_conf[id].res_spine
    if cc.FileUtils:getInstance():isFileExist(id_str) then 
        local function addSpine()
             ---添加spine
            local end_pos = string.find(id_str,'atlas') - 1
            local spName = string.sub(id_str,0,end_pos)
            self.skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
            self.skeletonNode:setPosition(0,0)
            spineRoot:addChild(self.skeletonNode,1000)
            self.skeletonNode:setAnimation(1, "effect", true)
        end
        addSpine()
    else 
        print("文件不存在 error file not exist:"..id_str)
    end
end
-- ---预加载
-- function SelectPlayerTitleItem:playSpine(spine)

--     if not spine or not cc.FileUtils:getInstance():isFileExist(spine) then return end
--     local size = self.panelVideo:getSize()

--     local id_str = spine
--     local end_pos = string.find(id_str,'atlas') - 1
--     local spName = string.sub(id_str,0,end_pos)

--     --local skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
--     if self.asyncHandler then
--         self.asyncHandler:cancel()
--         self.asyncHandler = nil
--     end

--     self.asyncHandler = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(skeletonNode)
--         self.asyncHandler = nil
--         skeletonNode:setPosition(size.width / 2,size.height / 2)
--         self.panelVideo:addChild(skeletonNode)
--         skeletonNode:setAnimation(1, "effect", false)
--         skeletonNode:setCompleteListener(function(trackIndex,loopCount)
--             skeletonNode:setToSetupPose()
--             skeletonNode:clearTracks()
--             skeletonNode:addAnimation(1, "effect", false)
--         end)
--     end)
-- end
