--[[
	PlayerInfoLayer.lua
	玩家信息
	会长、副会长、成员权限
	用户身份和 查看会员的身份
	1、公会成员列表（成员列表包含自己）（如果是会长，可以任命和踢人，副会长可以踢人）
	2、申请列表进入（只能查看，本页面没有操作按钮）
    3、查看其它公会的成员信息（只能查看，本页面没有操作按钮）
    参数如下：
    local info = {
        fromType = 1,                    -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息 , 4 查看玩家信息（用于排行榜等）
        m_position = 1,                  --自己的公会职位。（没有职位 传nil）
        other_infos= {                   --要查看对象的信息
            uid= "",
            head = "", 
        } 
    }
    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] = nil --回调函数 .用于刷新界面 （开除会员、升级会员等等）、不刷新的话，传nil
    rcvData["info"] =  info

    1。fromType 1、查看会内成员 2、申请列表查看信息 、4 查看玩家信息（用于排行榜等）
    1.自己的公会职位 m_position
    3.other_infos = {uid= "",head = ""} 
    --可以直接将guild_members接口中的members数据直接传过来 目前必用到的是 uid= "",head = "" 

]]
require "BasicLayer"

--公会职务 常量 这个地方需要放到公共里面
local G_P_President = 3
local G_P_Vice_President = 2
local G_P_Members = 1

PlayerInfoLayer = class("PlayerInfoLayer",BasicLayer)
PlayerInfoLayer.__index = PlayerInfoLayer
PlayerInfoLayer.lClass = 3

function PlayerInfoLayer:create(rData)
     local layer = PlayerInfoLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end

function PlayerInfoLayer:init()
    self.m_IconID = nil
    self.m_skeletonNode = nil 
    self.m_titleID = nil
    self.m_titleSkeletonNode =nil 
    self.sManager = self.rData["sManager"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.backFunc = self.rData["rcvData"]["sFunc"]   --返回回调（可用于刷新等等）
    self.infoRoot = nil
    self.teamRoot = nil
    self.selectPlayerData = nil --服务器获取的当前玩家的数据

    self.fromType = self.rData["rcvData"]["info"]["fromType"]     --来源  1、查看会内成员 2、申请列表查看信息
    self.rData["rcvData"]["info"]["m_position"] = self.rData["rcvData"]["info"]["m_position"] or 1 --
    self.m_position = tonumber(self.rData["rcvData"]["info"]["m_position"])--默认   --自己的公会职位
    self.other_infos = self.rData["rcvData"]["info"]["other_infos"]
    self.rData = {}

    local node = cc.CSLoader:createNode("PlayerInfoLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    self._rootCSbNode = node:getChildByTag(102) 
    self:initDefautUI()

	local infoRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode,"root_info")
	local teamRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode,"root_team")
	infoRoot:setVisible(false)
	teamRoot:setVisible(false)
    --返回按钮
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end
    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(touchCallBack)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self:initPageBtn()

    self:changePage(1)
end

--初始化界面的状态信息
--要不然卡的话很难看
function PlayerInfoLayer:initDefautUI( ... )
    -- body
        --name
    self._labName = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_name")
    if g_channel_control.PlayerCardLayerUseName == true then 
        self._labName:setPosition(cc.p(150,496)) --欧美服右移名字
    end
    --等级icon
    self._imgLevelTitle = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab2")

    self._imgLevel = ccui.Helper:seekWidgetByName(self._rootCSbNode, "img_level")
    --level冒险等级哦
    self._labLv = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_lv")
    --冒险经验
    self._labExp = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_exp")
    --expbar
    self._labExpBar = ccui.Helper:seekWidgetByName(self._rootCSbNode, "bar1")
    --level探索等级哦
    self._labExploreLv = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_lv_1")
    --探索经验
    self._labExploreExp = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_exp_1")
    --expbar
    self._labExploreBar = ccui.Helper:seekWidgetByName(self._rootCSbNode, "bar1_1")
    --描述
    self._inputDes = ccui.Helper:seekWidgetByName(self._rootCSbNode, "descrption")

    --称号root
    self._spineTitleNode = ccui.Helper:seekWidgetByName(self._rootCSbNode, "spinetitleNode")
    
    self._labName:setString("")
    self._imgLevelTitle:setVisible(false)
    self._imgLevel:setVisible(false)
    self._labLv:setString("")
    self._labExp:setString("")
    self._labExploreLv:setString("")
    self._inputDes:setString("")
    self._labExpBar:setPercent(0)
    self._labExploreBar:setPercent(0)
end

function  PlayerInfoLayer:initPageBtn()
	 --标签切换
    local function touchLabelBtnBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:changePage(sender.myTag )
        end
    end
    for i=1,2 do
    	local btn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_"..i)
    	btn.myTag = i --注：不用setTag 是为了防止tag值混乱
    	btn:addTouchEventListener(touchLabelBtnBack)
    end
end
-- 1、为玩家卡片信息 2、为玩家队伍信息
function PlayerInfoLayer:changePage(_index)
	local function setBtnStatue(btn,statue)
		btn:setTouchEnabled(statue)
        btn:setBright(statue)
	end
	local btn1 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_1")
	local btn2 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_2")
	local isShowFrist = true
	if _index == 1 then 
		if self.infoRoot == nil then 
			--init 卡片信息
			print("创建卡片信息")
			self.infoRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode,"root_info")
			self:initUIEmelent()
		end
		print("显示卡片信息")
	else 
		if self.teamRoot == nil then 
			--todo init 队伍信息
			self.teamRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode,"root_team")
			print("创建队伍信息")
            --请求队伍数据
            self:reqTeamInfo(self.other_infos.uid)
		end 
		print("显示队伍信息")
		isShowFrist = false
	end 
    setBtnStatue(btn1,not isShowFrist)
    setBtnStatue(btn2,isShowFrist)
	if self.infoRoot then 
		self.infoRoot:setVisible(isShowFrist)
	end 
	if self.teamRoot then
		self.teamRoot:setVisible(not isShowFrist) 
	end 

end

--返回
--返回要刷新 ，开除 或者 升级 都要刷新
function PlayerInfoLayer:returnBack()
	if self.backFunc then 
		self.backFunc(self.sDelegate)
	end 
    self.exist = false
    self:clearEx()
end

function PlayerInfoLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--初始化卡片控件
function PlayerInfoLayer:initUIEmelent()
    local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender:getTag() == 1000 then
                print("更改会阶")
                --todo 更改会阶弹窗
                self:changePositionView()
            elseif sender:getTag() == 1001 then 
                print("开除会员")
                --todo 开除 之后 返回刷新
                local str = string.format(UITool.ToLocalization("是否开除 %s"), self.selectPlayerData.name)
                MsgManager:showSimpMsgWithCallFunc(str,self,self.reqFriedInfo)
            end 
        end
    end
    --更改会阶（等级）
    local changeLevelBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_changeLevel")
    changeLevelBtn:addTouchEventListener(onBtnEvent)
    changeLevelBtn:setTag(1000)
    changeLevelBtn:setVisible(false)
    self._btnChangeLevel = changeLevelBtn
    --开除
    local firedBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_fired")
    firedBtn:addTouchEventListener(onBtnEvent)
    firedBtn:setTag(1001)
    firedBtn:setVisible(false)
    self._firedBtn = firedBtn
    ----获取当前查看玩家的数据
    self:reqSomeoneInfo(self.other_infos.uid)
end

--用于刷新当前的UI状态
function PlayerInfoLayer:updateUI(data)
    self.selectPlayerData = data
    -- value
    local desStr = data["signature"] or UITool.ToLocalization("我来自苍蓝境界,请多关照!")
    local expStr = data["exp"].."/"..data["exp_max"]
    local lvStr = ""..data["rank"]
    
    local nameStr = data.name --昵称
    local level = data.position  --会员等级
    --name
    self._labName:setString(nameStr)
    --level冒险等级哦
    self._labLv:setString(lvStr)
    --冒险经验200/300
    self._labExp:setString(expStr)
    --个性签名
    local strDes = UITool.ToLocalization("个性签名: \n")..desStr
    self._inputDes:setString(strDes)
    self._inputDes:setContentSize(cc.size(442,100))
    --expbar
    self._labExpBar:setPercent(100 * data.exp/data.exp_max)
    --探索
    local explorelvStr = ""..data.explore_lv 
    local expPrecentValue = math.floor(data.explore_exp/data.explore_max_exp*100)
    local exploreStr = data.explore_exp.."/"..data.explore_max_exp
    self._labExploreLv:setString(explorelvStr)
    self._labExploreExp:setString(exploreStr)
    self._labExploreBar:setPercent(expPrecentValue)
    --头像
    self:addIconSpine()
    self:refreshTitleUI(data.title_id)--添加称号
    --1会内成员 2申请查看
    if self.fromType == 1 then 
        --todo 根据等级处理按钮状态
        if self.m_position == G_P_President then 
            self._btnChangeLevel:setVisible(true)
            self._firedBtn:setVisible(true)
        elseif self.m_position == G_P_Vice_President then 
            self._btnChangeLevel:setVisible(false)
            self._firedBtn:setVisible(true)
        else 
            self._btnChangeLevel:setVisible(false)
            self._firedBtn:setVisible(false)
        end 
        --会阶 处理 如果是申请列表，这个不现实
        self._imgLevel:setUnifySizeEnabled(false)
        self._imgLevel:loadTexture(GUILD_MEMBER_RANK_ICON[level])
        self._imgLevel:setVisible(true)
        self._imgLevelTitle:setVisible(true)
    elseif self.fromType == 2 then 
        self._btnChangeLevel:setVisible(false)
        self._firedBtn:setVisible(false)
        self._imgLevel:setVisible(false)
        self._imgLevelTitle:setVisible(false)
    elseif self.fromType == 3 then  --查看别人公会的信息
        self._btnChangeLevel:setVisible(false)
        self._firedBtn:setVisible(false)
        self._imgLevel:setUnifySizeEnabled(false)
        self._imgLevel:setVisible(true)
        self._imgLevel:loadTexture(GUILD_MEMBER_RANK_ICON[level])
        self._imgLevelTitle:setVisible(true)
    elseif self.fromType == 4 then  --查看个人名片 （排行榜等）
        self._btnChangeLevel:setVisible(false)
        self._firedBtn:setVisible(false)
        self._imgLevel:setUnifySizeEnabled(false)
        self._imgLevel:setVisible(false)
       -- self._imgLevel:loadTexture(GUILD_MEMBER_RANK_ICON[level])
       self._imgLevelTitle:setVisible(false)   
    end 
    --查看自己 所有按钮不能点击
    if self.other_infos.uid == user_info["id"] then 
        self._btnChangeLevel:setVisible(false)
        self._firedBtn:setVisible(false)
    end 
    --不能开除等级比自己高的人
    if self.fromType == 4 then 
    else 
        if tonumber(self.m_position) <= tonumber(data.position) then 
            self._firedBtn:setVisible(false)
        end 
    end 
end

--玩家头像spine
function PlayerInfoLayer:addIconSpine()
    -- body
    local iconId =tonumber(self.other_infos.head)
    if self.m_IconID == nil or self.m_IconID ~= iconId then 
        self.m_IconID = iconId
        local spineNameStr =  hero[iconId].hero_des_spi
        if self.m_skeletonNode ~=nil then 
            self.m_skeletonNode:stopAllActions()
            self.m_skeletonNode:removeFromParent()
            self.m_skeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local spineParent = ccui.Helper:seekWidgetByName(self._rootCSbNode,"spineRoot")
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            self.m_skeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            self.m_skeletonNode:setAnimation(1, "effect1", true)
            spineParent:addChild(self.m_skeletonNode)
            self.m_skeletonNode:setPosition(0,0)  
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 
end

--刷新称号
function PlayerInfoLayer:refreshTitleUI(title_id)
    dump("刷新称号")
    local iconId = tonumber(title_id)
    if self.m_titleID == nil or self.m_titleID ~= iconId then 
        self.m_titleID = iconId
        local spineNameStr = title_conf[iconId].res_spine
        if self.m_titleSkeletonNode ~=nil then 
            self.m_titleSkeletonNode:stopAllActions()
            self.m_titleSkeletonNode:removeFromParent()
            self.m_titleSkeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local spineParent = ccui.Helper:seekWidgetByName(self._rootCSbNode,"spinetitleNode")
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            self.m_titleSkeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            spineParent:addChild(self.m_titleSkeletonNode)
            self.m_titleSkeletonNode:setAnimation(1, "effect", true)
            spineParent:setVisible(false)
            local dt = cc.DelayTime:create(0.01)
            local cf = cc.CallFunc:create(function()
                self.m_titleSkeletonNode:setPosition(self.m_titleSkeletonNode:getBoundingBox().width/2,-1)    
                spineParent:setVisible(true)
            end)
            local seq = cc.Sequence:create(dt,cf)
            spineParent:runAction(seq)
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 
end

--修改成员公会级别
--弹出弹窗，这里单独处理的，没有走公共的消息弹窗
function PlayerInfoLayer:changePositionView( ... )
    -- body
    local data = {
        info = self.selectPlayerData,
        sDelegate = self,
        callFunc = self.doAppoint
    }
    local layer = GuildAppointPopView:create(data) 
    self.sManager.rootLayer:addChild(layer.uiLayer,9991)
end

--任命
function PlayerInfoLayer:doAppoint(selectPos)
    --todo 掉任命借口呀
    selectPos = tonumber(selectPos)
    self:reqAppoint(self.other_infos.uid, selectPos)
end

--添加队伍信息
function PlayerInfoLayer:addTeamUI(data)
    local teamLayer = GuildTeamView:create(data)
    self.teamRoot:addChild(teamLayer.uiLayer)
end

--获取要查看人的信息
function PlayerInfoLayer:reqSomeoneInfo(the_uid)
    local function ReqSuccess(data)
        self:updateUI(data)
    end
    local tempTable
    if self.fromType == 4 then 
        tempTable = {
            ["rpc"] = "someone_info",
            ["the_uid"] = the_uid,
        }
    else 
        tempTable = {
            ["rpc"] = "guild_someone",
            ["the_uid"] = the_uid,
        }
    end 

    self:doReq(tempTable, ReqSuccess)  
end
--获取指定人队伍信息
function PlayerInfoLayer:reqTeamInfo(the_uid)
    local function ReqSuccess(data)
        --self.team_info = data.team_info
        --判断队伍信息需不需要保存，目前只是用来查看，就不保存了
        self:addTeamUI(data.team_info)
    end
    local tempTable = {
        ["rpc"] = "guild_someone_team",
        ["the_uid"] = the_uid,
    }
    self:doReq(tempTable, ReqSuccess)  
end
--任命
function PlayerInfoLayer:reqAppoint(the_uid,_position)
    local function ReqSuccess(data)
        --todo 任命 刷新
        self.sManager:showPromptLabel(UITool.ToLocalization("任命成功，刷新"))
        ----重新请求一下当前的数据
        --todo 处理一下玩家自己当前等级，如果降为副会长
        --self.m_position = 
        self:reqSomeoneInfo(self.other_infos.uid)
    end
    local tempTable = {
        ["rpc"] = "guild_appointment", 
        ["uid"] = the_uid,
        ["position"] = _position,
    }
    self:doReq(tempTable, ReqSuccess)  
end
--开除
function PlayerInfoLayer:reqFriedInfo()
    local function ReqSuccess(data)
        --todo 返回 下面页面一定要刷新啊
        self.sManager:showPromptLabel(UITool.ToLocalization("删除成功"))
        self:returnBack()
    end
    local tempTable = {
        ["rpc"] = "guild_kick",
        ["uid"] = self.other_infos.uid,
    }
    self:doReq(tempTable, ReqSuccess)  
end

function PlayerInfoLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
