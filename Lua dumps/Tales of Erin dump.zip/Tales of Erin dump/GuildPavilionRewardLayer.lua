--[[
	GuildPavilionRewardLayer.lua
	公会道馆 层奖励 和积分排名奖励
	1、层奖励 2、积分奖励
]]
require "BasicLayer"

GuildPavilionRewardLayer = class("GuildPavilionRewardLayer",BasicLayer)
GuildPavilionRewardLayer.__index = GuildPavilionRewardLayer
GuildPavilionRewardLayer.lClass = 3

function GuildPavilionRewardLayer:create(rData)
     local layer = GuildPavilionRewardLayer.new()
     layer.rData = rData
     layer:init()
     return layer
end

function GuildPavilionRewardLayer:init()

	self.sManager = self.rData["sManager"]
	self.mType = self.rData.rcvData.mType --1、层奖励 2、积分奖励
    self.uiLayer = cc.Layer:create()
	--1、层奖励 2、积分奖励
    if self.mType ==1 then 
		self.itemCsb = "GuildPRankRewardItem.csb"
		self.data = guild_tower_reward
		self.descri = UITool.ToLocalization("层次通过后，对应层次奖励以邮件形式发给公会所有人")
	else 
		self.itemCsb = "GuildPRankRewardItem.csb"--需要删除，现在不知道两个界面长得一样不一样，如果不一样就
		self.data = nil 
		self.descri = UITool.ToLocalization("本次活动结束后奖励以邮件的形式发放")
    end 

    local node = cc.CSLoader:createNode("GuildPavilionReward.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
	self._rootCSbNode = node:getChildByTag(102) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end
    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn")
    backBtn:addTouchEventListener(touchCallBack)

 	local desinfo = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"des")
 	desinfo:setString(self.descri)

  
    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")

	self:initListView()

    if self.mType ==1 then
        self:refreshListView()
    else 
        --请求积分奖励
        self:reqGuildRankReward()
    end 
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end

function GuildPavilionRewardLayer:initListView()
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 435.00,116)
    self.gridview.itemCreateEvent = function()
        local temp = GuildPRankRewardItem.new():init()
        temp.ClickEvent = function(item)
        end
        temp.resetDataEvent = function(item)
        end
        temp.subType = self.mType
        return temp
    end
end

--刷新列表列表
function GuildPavilionRewardLayer:refreshListView()
    self.gridview:setDataSource(self.data)
end
--guild_tower_reward
--返回
function GuildPavilionRewardLayer:returnBack()
   self.exist = false
   self:clearEx()
end

function GuildPavilionRewardLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--获取排行奖励
function GuildPavilionRewardLayer:reqGuildRankReward()
    local function ReqSuccess(data)
        self.data = data.reward
        self:refreshListView()
    end
    local tempTable = {
        ["rpc"] = "guild_tower_reward",
    }
    self:doReq(tempTable, ReqSuccess)  
end

-----todo 发送请求的放到公共里面，现在不知道放哪，暂时放着。
function GuildPavilionRewardLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

