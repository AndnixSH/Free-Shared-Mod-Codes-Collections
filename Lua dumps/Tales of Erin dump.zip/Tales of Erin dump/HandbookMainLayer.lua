--[[
	HandbookMainLayer.lua
    -图鉴主页 
]]
HandbookMainLayer = class("HandbookMainLayer",XUIView)
HandbookMainLayer.CS_FILE_NAME = "HandbookMainLayer.csb"
HandbookMainLayer.CS_BIND_TABLE = 
{
    vpanel="/i:1/i:103",
    btnTab1="/i:1/i:104/i:301",
    btnTab2="/i:1/i:104/i:302",
    btnTab3="/i:1/i:104/i:303",
    btnClose="/i:1/i:105/s:btnClose",
    heroImg="/i:1/s:heroImg",
    btnHelp= "/i:1/s:btnHelp",
}

function HandbookMainLayer:init(tab)
    HandbookMainLayer.super.init(self)
    
    self.views = XUIView.new():init(self.vpanel)

    self.heroImg:setTexture("icons/role/vdrawing/jq_r_051.png")

    self._titleBookLayer = TitleBookLayer.new():init()
    self.views:addSubView(self._titleBookLayer)

    self._heroBookLayer = HeroBookLayer.new():init()
    self.views:addSubView(self._heroBookLayer)

    self._equipBookLayer = EquipBookLayer.new():init()
    self.views:addSubView(self._equipBookLayer)

    self.exist = true

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)
    print("@@KeyboardManager:registeredKeyBoardEvent..."..tostring(self.keyboardValue))
    
    self:switchView(tab)

    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)

    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    -- self.btnHelp:addClickEventListener(function()
    --     self:showGuidePicLayer()
    -- end)
    self.btnHelp:setVisible(false)

    return self
end

function HandbookMainLayer:refresh()
    if self.curTab == 1 then
        self._titleBookLayer:refresh()
    elseif self.curTab == 2 then
        self._heroBookLayer:refresh()
    elseif self.curTab == 3 then
        self._equipBookLayer:refresh()
    end
end

function HandbookMainLayer:switchView(tab)
    local num = tab or 1
    if self.curTab ~= num then
        local ctls = {
            {btn = self.btnTab1, view= self._titleBookLayer},
            {btn = self.btnTab2, view= self._heroBookLayer},
            {btn = self.btnTab3, view= self._equipBookLayer},
        }

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            ctls[i].btn:setBright(i ~= num)
            ctls[i].view:getRootNode():setVisible(i == num)
        end
        self.curTab = num
        self:refresh()
    end
end

function HandbookMainLayer:showGuidePicLayer()
    -- local data = {}
    -- data.pictures = {
    --       "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_010.png",
    --   }
    -- self.sManager:toGuidePictureLayer(data)
end

function HandbookMainLayer:onNavigateTo(isback)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    end
end

function HandbookMainLayer:setShow()
    self.sManager.menuLayer:hiddenUserInfo(true) 
    self.sManager.menuLayer:showTopBar(true)
    self:onNavigateTo(true)
end

function HandbookMainLayer:setManager(sManager)
    self.sManager = sManager
end

function HandbookMainLayer:clear()
    if self:getRootNode() then
        self:getRootNode():removeFromParent()
    end
end

function HandbookMainLayer:returnBack()
    self:clear()
    self.sManager:removeFromNavNodes()
    self.sManager:toStartLayer()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self.exist = false
end

