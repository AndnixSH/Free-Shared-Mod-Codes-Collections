ImgCacheManager = {}
ImgCacheManager.img_paths = {
}

function ImgCacheManager:clearCache()
	if self.img_handles then
		for _,v in ipairs(self.img_handles) do
			v:release()
		end
	end
	self.img_handles = {}
end

function ImgCacheManager:getImageCount()
	return #ImgCacheManager.img_paths
end

function ImgCacheManager:addImageByIndex(idx)
	if not self.img_handles then
		self.img_handles = {}
	end

	local texture = cc.Director:getInstance():getTextureCache():addImage(self.img_paths[idx])
	texture:retain()
	table.insert(self.img_handles,texture)
end

---预加载csb ，todo预加载图片资源
--[[
	1.创建node保存起来，使用，这个方案有bug，因为一份，无法使用 clone 或者copy 。自己在写一份？
	2.直接缓存图片吧
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile();
]]
CsbCacheManager = {}

CsbCacheManager.csb_caches = {}

--主界面，队伍界面，灵装界面，商店界面，抽卡，公会，出征
function CsbCacheManager:cacheCsbs()
	--todo 暂时不缓存了
	--local files = {"Menue.csb","RoleMainView.csb","EquipMainView.csb","ShopLayer.csb","GachaView.csb","GuildMainView.csb","SMapLayer.csb"}
	local files = {}
	for i=1,#files do
		CsbCacheManager:addCSBToCache(files[i])
	end
	-- dump("加载 缓存文件")
	-- local cache = cc.SpriteFrameCache:getInstance()
 --    cache:addSpriteFrames("res/uifile/n_UIShare/Global_UI/tp_global_ui.plist")--, "res/uifile/n_UIShare/Global_UI/tp_global_ui.png")
end

function CsbCacheManager:addCSBToCache(file)
	local node = cc.CSLoader:createNode(file)
	node:retain()
	CsbCacheManager.csb_caches[file] = node
end
--
--说明 这个有bug
function CsbCacheManager:getCSBfromCache(file)
	 return cc.CSLoader:createNode(file)
	-- if CsbCacheManager.csb_caches[file] == nil  then
	-- 	return cc.CSLoader:createNode(file)
	-- end
	-- local node = CsbCacheManager.csb_caches[file]
	-- return node
end

function CsbCacheManager:clearCache()
 	for k,v in pairs(CsbCacheManager.csb_caches) do
		if v~=nil then
		  v:release()
		  v = nil	
		end 	
	end
end