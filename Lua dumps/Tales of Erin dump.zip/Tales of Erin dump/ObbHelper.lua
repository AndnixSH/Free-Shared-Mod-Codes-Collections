--[[
    2018-06-28 zft
	ObbHelper.lua
	obb分包管理器
    只限android
]]

ObbHelper = {}

ObbHelper.isSkipObbCheck = false  --false 为release 、true为debug（跳过obb下载）

ObbHelper.COCOS2DXHELPER_JAVA 	= "org/cocos2dx/lib/Cocos2dxHelper"

--init.lua 还未加载，此方法重复
function ObbHelper:luaBridgeCall(className,functionName,args,sigs)
    local platform = cc.Application:getInstance():getTargetPlatform()
    local ok = false
    local ret = nil
    if platform == cc.PLATFORM_OS_ANDROID then
        local luaj = require("src/cocos/cocos2d/luaj.lua")
        ok,ret  = luaj.callStaticMethod(className,functionName,args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        -- local luaoc = require_ex("src/cocos/cocos2d/luaoc.lua")
        local luaoc = require "cocos.cocos2d.luaoc" 

        ok,ret  = luaoc.callStaticMethod(className, functionName, args)
    end
    if not ok then
        print("luaoc error:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(functionName))
    else
        print("The oc ret is:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(functionName))
    end
    return ok, ret
end

--检测是否需要下载obb包
function ObbHelper:isNeedDownloadObb()
	if ObbHelper.isSkipObbCheck then 
		return false
	end 
    --非android渠道，不需要下载obb
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform ~= cc.PLATFORM_OS_ANDROID then
        return false
    end

	local obbPath = self:getObbFileFullpath()
	local isExit = self:fileIsExists(obbPath)
	if not isExit then 
		return true
	end 
	return false
end

function ObbHelper:getObbFileName( )
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local ok, ret = self:luaBridgeCall(ObbHelper.COCOS2DXHELPER_JAVA,"getObbFileName",args,sigs)    
    if ok then
        return ret
    end
end

--obb文件绝对路径 XXXXX/android/obb/包名／文件名
function ObbHelper:getObbFileFullpath()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local ok, ret = self:luaBridgeCall(ObbHelper.COCOS2DXHELPER_JAVA,"getObbFileFullpath",args,sigs)    
    if ok then
        return ret
    end
end

--obb文件所在文件夹 XXXXX/android/obb/包名／
function ObbHelper:getObbFilepath()
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        local sigs = "()Ljava/lang/String;"
        local args = {}
        local ok, ret = self:luaBridgeCall(ObbHelper.COCOS2DXHELPER_JAVA,"getObbFilePath",args,sigs)    
        if ok then
            return ret
        else 
            return ""
        end
    else
        return cc.FileUtils:getInstance():getWritablePath()
    end
end

function ObbHelper:fileIsExists(filePath)
    local sigs = "(Ljava/lang/String;)Z"
    local args = {filePath}
    local ok, ret = self:luaBridgeCall(ObbHelper.COCOS2DXHELPER_JAVA,"fileIsExists",args,sigs)    
    if ok then
        return ret
    end
end
--删除文件
function ObbHelper:deleteFileEx(filePath)
    local sigs = "(Ljava/lang/String;)V"
    local args = {filePath}
    local ok, ret = self:luaBridgeCall(ObbHelper.COCOS2DXHELPER_JAVA,"deleteFileEx",args,sigs)    
    if ok then
        return ret
    end
end
function ObbHelper:restartGame()
    local args = {}
    local sigs = "()V"
    self:luaBridgeCall(ObbHelper.COCOS2DXHELPER_JAVA,"restartGame",args,sigs)    
end


