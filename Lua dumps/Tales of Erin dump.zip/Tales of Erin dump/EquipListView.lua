--require "XUIView"
--require "EquipListItemView"
--require "EquipInfoView"

EquipListView = class("EquipListView",XUIView)
EquipListView.CS_FILE_NAME = "EquipListView.csb"
EquipListView.CS_BIND_TABLE = 
{
    vpanel="/i:206/i:406",
    panelSort = "/i:206/s:panelSort",
    panelList = "/i:206/i:208",
    topBtn = "/i:206/i:780",
    topBtnTitle = "/i:206/i:780/i:781",
    lbNum = "i:206/i:407/i:49",
    lbNumMax = "i:206/i:407/i:51",
    btnAdd = "i:206/i:465",
    ImgBtnEq = "i:206/i:473",
    ImgBtnNoEq = "i:206/i:474",
    panelBagInfo = "/i:206/i:407",
}

function EquipListView.createWithBackBtn(nSelectTitleNum)
    local v = EquipListView.new():init()
    --local b = BackgroundView.new():initWithBackBtn(v,"n_UIShare/Global_UI/bg/bg_003_1.png")
    local b = BackgroundView.new():initWithBackBtn(v)
    if g_channel_control.b_newEqBag then
        v.nDefaultSelect = nSelectTitleNum
        v.nSelectTitleNum = nSelectTitleNum
        v:setTopBtnVisible(false)
        v:onCallEqListByTitle(nSelectTitleNum)
    end

    return b,v
end

function EquipListView:init()
    EquipListView.super.init(self)

    self.views = XUIView.new():init(self.vpanel)
    
    self.topBtn:setVisible(false)
    self.topBtn:setPressedActionEnabled(false)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = EquipListItemView.new():init()

        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end
       
        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = 0
            if g_channel_control.b_newEqBag then
                smode = math.floor(self.sortBtnView:getSortMode() / 10)
            else
                smode = self.sortBtnView:getSortMode() % 10
            end
            item:setTitleMode(smode)

            self:onItemReset(item)
        end

        return temp
    end

    --排序
    if g_channel_control.b_newEqBag then
        self.sortBtnView = EqSortButtonView.new():init(self.panelSort,"EqP_l",11,"EqS_Rank_l",0,"EqS_Ele_l",0,"EqS_Brk_l",0)
    else
        self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_l",213,1)
    end
    if g_channel_control.b_newEqBag then
        self.sortBtnView.sortModeChangedEvent = function()
            self:ReLoadData()
        end
    else
        self.sortBtnView.sortModeChangedEvent = function()
            self:refresh()
        end
    end
    --

    self.btnAdd:addClickEventListener(function()
        self:onAddBagNum()
    end)

    if g_channel_control.b_newEqBag then
        self.btnAdd:setVisible(true)
        self.btnAdd:setTouchEnabled(true)

        self.nBagCurNum = 0
        self.nBagMaxNum = 0

        self.nSelectTitleNum = 0 --1:已装。0:未装
        self.nDefaultSelect = nil

        self.bEnableEqTitle = true   --已装灵装按钮是否有效
        self.bEnableNoEqTitle = true --未装灵装按钮是否有效

        self.ImgBtnEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableEqTitle then
                    self:onSelectTitle(1)
                end
            end
        end)
        self.ImgBtnEq:setSwallowTouches(true)

        self.ImgBtnNoEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableNoEqTitle then
                    self:onSelectTitle(0)
                end
            end
        end)
        self.ImgBtnNoEq:setSwallowTouches(true)
        
        --self:onCallEqListByTitle(self.nSelectTitleNum)
    else
        self.btnAdd:setVisible(false)
        self.btnAdd:setTouchEnabled(false)
        self.ImgBtnEq:setVisible(false)
        self.ImgBtnEq:setSwallowTouches(false)
        self.ImgBtnNoEq:setVisible(false)
        self.ImgBtnNoEq:setSwallowTouches(false)
    end

    return self
end

function EquipListView:onSelectTitle(nSelectNum)
    if self.nSelectTitleNum ~= nSelectNum then
        self.nSelectTitleNum = nSelectNum
        if self.nSelectTitleNum == 1 then
            if self.EndSaleCallback then
                self.EndSaleCallback(self.EndSaleDelegate)
            end
        end
        self:onCallEqListByTitle(self.nSelectTitleNum)
    end
end

function EquipListView:onCallEqListByTitle(nSelectNum)
    --与后端交互获取新的装备列表
    self:ReLoadData()
    --
    --self:refreshTitleBtnState()
end

function EquipListView:refreshTitleBtnState()
    if self.nSelectTitleNum == 1 then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[2])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[1])
        --
        self.btnAdd:setTouchEnabled(false)
        self.btnAdd:setVisible(false)
        self.panelBagInfo:setVisible(false)
        self.topBtn:setVisible(false)
    else
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[1])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[2])
        --
        self.btnAdd:setTouchEnabled(true)
        self.btnAdd:setVisible(true)
        self.panelBagInfo:setVisible(true)
        self.topBtn:setVisible(true)
        if self.nDefaultSelect then
            self.topBtn:setVisible(false)
        else
            self.topBtn:setVisible(true)
        end
        
    end

    if not self.bEnableEqTitle then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
    if not self.bEnableNoEqTitle then
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
end

function EquipListView:onAddBagNum()
    if self.nBagMaxNum >= eq_bag.max_capacity then--已达到扩容上限
        local strDec = "灵装背包已扩充到最大格数，无法继续扩充。"
        MsgManager:showSimpMsg(UITool.ToLocalization(strDec))
    else
        local addSucessFunc = function()
            self:refresh()
            self:addLabel(UITool.ToLocalization("灵装背包扩容成功"))
        end
        --local addSucessFunc =  self.refresh
        self.bagAddView = BagAddView.new():init(user_info["eq_max"],addSucessFunc,self)
        self.views:addSubView(self.bagAddView)
    end
end
-- /*提示信息*/
function EquipListView:addLabel(str)
  
    local label = cc.Label:createWithTTF(str, TEXT_FONT_NAME, 40)
    label:setPosition(cc.p(640,360))
    self:getRootNode():addChild(label, 1)
    local function removeThis()
       label:removeFromParent()
    end
    --After 1.5 second, self will be removed.
    local moveBy  = cc.MoveBy:create(1.5,cc.p(0,150))
    local fadeOut = cc.FadeOut:create(1.5)
    local spawn = cc.Spawn:create(moveBy,fadeOut)
    label:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(removeThis)))

end 

function EquipListView:setTopBtn(title,callback,EndSaleCallback,delegate)
    self.topBtnTitle:setString(UITool.ToLocalization(title))

    self.topBtn:setVisible(true)
    if g_channel_control.b_newEqBag then
        self.EndSaleDelegate = delegate
        self.EndSaleCallback = EndSaleCallback
        if self.nSelectTitleNum == 1 then
            self.topBtn:setVisible(false)
        end
    end
    self.topBtn:addClickEventListener(callback)
end

function EquipListView:setTopBtnVisible(visible)
    self.topBtn:setVisible(visible)
    if g_channel_control.b_newEqBag then
        if self.nSelectTitleNum == 1 then
            self.topBtn:setVisible(false)
        end
    end
end

function EquipListView:setEquipNum(nEquipNum)
    self.nBagCurNum = nEquipNum
    self.lbNum:setString(nEquipNum)
end

function EquipListView:setEquipNumMax(nEquipNumMax)
    if nEquipNumMax ~= 0 then
        self.nBagMaxNum = nEquipNumMax
        self.lbNumMax:setString("/"..nEquipNumMax)
    else
        self.lbNumMax:setString(UITool.ToLocalization("/未获取到数据"))
    end
    
end

function EquipListView:refreshEquipNumState()
    if self.nBagCurNum > self.nBagMaxNum then
        self.lbNum:setColor(cc.c3b(255, 0, 0))
    else
        self.lbNum:setColor(cc.c3b(255, 255, 255))
    end
    
end

function EquipListView:onItemClicked(item)    
    if self.ItemClickedEvent then
        self.ItemClickedEvent(item)
    end
end

function EquipListView:onItemReset(item)    
    if self.ItemResetEvent then
        self.ItemResetEvent(item)
    end
end

function EquipListView:ReLoadData()
    local rankVaules = table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = self.nSelectTitleNum,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()       
        --DataManager:wAllBagData({mat = data["mat"]})
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end

        --self.equipListView:setDataSource(equip_list)
        self.dataLoaded = true
        self:refresh()

        if g_channel_control.b_newEqBag then
            if self.nSelectTitleNum == 0 then
                if self.nBagMaxNum and self.nBagMaxNum ~= 0 then
                    if self.nBagCurNum >= self.nBagMaxNum then
                        --进入灵装列表&&第一次背包满时，提示一次背包扩容,之后不再提示
                        local nHasTiped = cc.UserDefault:getInstance():getIntegerForKey("Eq_Add_Tip")
                        if (nHasTiped == nil) or (nHasTiped == 0) then
                            --没有提示过
                            cc.UserDefault:getInstance():setIntegerForKey("Eq_Add_Tip",1)
                            local strDec = UITool.ToLocalization("灵装背包已满，您将无法获得更多灵装。是否进行扩充？")
                            GameManagerInst:confirm(strDec,function()
                                if GameManagerInst.gameType == 2 then
                                    self:onAddBagNum()
                                end
                            end)
                        end
                    end
                end
            end
            self:refreshTitleBtnState()
        end
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
            --self:returnBack()
        end)
    end,
    true)
end

function EquipListView:getDataSource(sort_mode)
    if self.dataSourceEvent then
        return self.dataSourceEvent(self,sort_mode)
    else

        local dataset =  table.deepcopy(equip_list)
        if g_channel_control.b_newEqBag then
            EqSortBoxView.SortEquip (dataset, sort_mode)
        else
            SortBoxView.SortEquip (dataset, sort_mode)
        end
        return dataset
    end
end

-- function EquipListView:setDataSource(dataSource)
--     self.currentDataSource = table.deepcopy(dataSource)
-- end

function EquipListView:refresh()
    --先排序，后刷列表  
    local ds = self:getDataSource(self.sortBtnView:getSortMode())

    if ds == nil then
        return
    end

    self.currentDataSource = ds

    if eq_list then
    end
    if g_channel_control.b_newEqBag then
        if user_info["eq_num"] then
            self:setEquipNum(user_info["eq_num"])
        else
            self:setEquipNum(0)
        end
    else
        self:setEquipNum(#ds)
    end

    if user_info["eq_max"] then
        self:setEquipNumMax(user_info["eq_max"])
    else
        self:setEquipNumMax(0)
    end
    self:refreshEquipNumState()
    

    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(self.currentDataSource)
    self.gridview:jumpToPercent(percent)
end
