require "BasicLayer"
-- 登陆奖励
SignInLayer = class("SignInLayer",BasicLayer)
SignInLayer.__index   = SignInLayer
SignInLayer.lClass    = 2 
SignInLayer.SignList  = {}
SignInLayer.ListLen   = 0
SignInLayer.TestLen   = 21  -- 临时变量  以后正式对接服务器用 ListLen
SignInLayer.initX     = 0   -- 记录初始的坐标
--/*注意说明*/
--"SIgnInLayer.csb"  这个命名的时候SI里的I写成大写了
--/* 函数说明
    -- sendSever    链接服务器，获取签到列表
    -- setModel     设置模板的listView的模板
    -- showListEl   显示列表上的元素
    -- refreDay     用来刷新活显示当前签到天数的
    -- ItemCallBack 点击Item 的背景的回调函数，处理当前点击如果没有领取就领取，如果领取了就弹出物品详细
    -- ShowDec      弹窗  点击item响应的物品信息弹窗
    -- SendGet      点击没有签到的item 链接服务器获取数据 并对item和数据进行处理
    -- setDayArrow  根据每个月的天数换算小箭头每次应该移动多少，记录初始化的坐标，在初始坐标上进行移动
    -- setBox       根据每个月的天数设置宝箱的位置
    -- BoxCallBack  点击宝箱的回调 根据点击 1 7 21三宝箱  领取弹出详细没领取的直接领取
    -- SenderBox    领取宝箱 服务器获取数据
    -- SpineSign    设置spine 签到特效的播放
    -- SpineDelete  删除spine 签到特效
    -- refreArrt    领取后刷新显示的状态
    -- isHideBox    控制箱子的隐藏显示
--*/
function SignInLayer:init()
    local node    = cc.CSLoader:createNode("SIgnInLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true
    -- 获取到小三角
    local imageBg = node:getChildByName("Image_form_bg")
    local day     = imageBg:getChildByName("Image_day")
    -- 记录小三角的初始坐标X y不变
    self.initX   = day:getPositionX()
    self:IsHideBox(false)
    self:sendSever()
    self:initBtn()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:BtnClose()
    end)
     
end
function SignInLayer:initBtn( ... )
    -- body
    local  node    = self.uiLayer:getChildByTag(2)
    local imageBg  = node:getChildByName("Image_form_bg")
    local closeBtn = imageBg:getChildByName("Button_close")
    local function callBack( sender,eventType )
        -- body
        if eventType == ccui.TouchEventType.ended then
            self:BtnClose()
        end
    end
    closeBtn:addTouchEventListener(callBack)
    closeBtn:setEffectType(3)
end
function SignInLayer:sendSever( ... )
    -- body
    --检测宝箱是否领取过
    local function checkBoxGet( dayIndex,states )
        local stateArr = states
        local stateLen = #stateArr
        local bState = false
        local state = nil
        for i = 1,stateLen do
            if stateArr and stateArr[i] then
                 state = stateArr[i]
                if state == dayIndex then
                    bState = true
                    break
                end
            end
        end
        return bState
    end
    --刷新宝箱状态
    local function refreshBoxStates( t_data )
        self.SignList["extra_awards_state"] = {}
        local state_data = t_data
        local days = {1,7,21}
        local len = #days
        for i = 1,len do
            local day = days[i]
            local bState = checkBoxGet(day,state_data)
            if bState == true then
                self.SignList["extra_awards_state"][i] = day
            end
        end
    end

    local function reiceSthCallBack(data)
        print("获取签到列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self ~= nil and self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.BtnClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            
             MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.BtnClose)
            return
        end 
        if t_data["data"]["state_code"]  == 1 then
            self.SignList["landing_count"]         = t_data["data"]["landing_count"]
            self.SignList["is_landed"]             = t_data["data"]["is_landed"]
            self.SignList["awards"]                = t_data["data"]["awards"]
            self.SignList["extra_awards"]          = t_data["data"]["extra_awards"]
            refreshBoxStates(t_data["data"]["extra_awards_state"])
            --self.SignList["extra_awards_state"]    = t_data["data"]["extra_awards_state"]
        end
       
        -- print("self.ListLen self.ListLen == "..self.ListLen)


        self:setModel()
    end
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "landing_award_list",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励列表 mydata = "..mydata)
    self.sManager:createWaitLayer()
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)

end
-- 设置模板
function SignInLayer:setModel( ... )
    -- body
   local node    = self.uiLayer:getChildByTag(2)
   local imageBG = node:getChildByName("Image_form_bg")
   self.ListView = imageBG:getChildByName("ListView_1")

   local  layout_list = ccui.Layout:create()
   layout_list:setAnchorPoint(cc.p(0,1))
   local  list_item = cc.CSLoader:createNode("SignInNode.csb")
    local  item_1 = list_item:getChildByName("Panel_1")
    local item_c = item_1:clone()
    item_c:setName("item_1")
    layout_list:addChild(item_c)

    layout_list:setContentSize(146,340)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)
    self:showListEl()
end
--显示list上的元素
function SignInLayer:showListEl( ... )
    -- body
     self.ListLen  = #self.SignList["awards"] 
    for i = 1 , self.ListLen do
        self.ListView:pushBackDefaultItem()
    end

    -- 已签到天数
    local ShowNum    = self.SignList["landing_count"] 
    self:refreDay(ShowNum)
    self:setDayArrow(ShowNum)
    self:setBox()
    self:refreBox()
    --  是否签到过
    local IsLanding  = self.SignList["is_landed"] 

    local width = self.ListLen * (146+25)
    self.ListView:setInnerContainerSize(cc.size(width,self.ListView:getContentSize().height))
    --根据测试 如果 ShowNum <= 3 item会从右到左滑进来，
    -- 这个函数是跳到指定下标，如果下标在屏幕内，会经过计算先跳到屏幕内坐标，在回弹到起点
    if ShowNum > 3 then
        self.ListView:jumpToItem(ShowNum,cc.p(0.5,0.5),cc.p(0,0))
    end

   
    for i = 1,  self.ListLen do
        
         local itme_info = self.ListView:getItem(i - 1)
          local item = itme_info:getChildByName("item_1")
         -- 获取这个奖励的类型
         local  IconType  = self.SignList["awards"][i]["award_type"]
         -- 奖励类型的id
         local e_id = tonumber(self.SignList["awards"][i]["award_id"])
         local prop = {}
         prop = UITool.getItemInfos(IconType,e_id)
         --点击背景的回调函数
         local function callBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                self:ItemCallBack(sender,eventType,i,item)
            end
         end
         -- 获取显示第几天的font
         local font     = item:getChildByName("BitmapFontLabel_1")
         font:setString(i)
         -- 获取背景给背景加上点击事件
         local imageBg  = item:getChildByName("Image_bg")
         imageBg:addTouchEventListener(callBack)
         --获取item要显示的属性
         -- 显示icon
         local pane_2 = item:getChildByName("Panel_2")
         pane_2:setSwallowTouches(false)
         local icon = pane_2:getChildByName("Image_icon")
         icon:setUnifySizeEnabled(true)

         -- 如果是角色类型 ，在签到显示需要新的尺寸 在hero中新加一个字段 hero_landaward_icon
         if IconType == 4 then
            local h_icon = hero[tonumber(e_id)]["hero_landaward_icon"]
            if h_icon ~= nil and h_icon ~= "" then
                icon:loadTexture(h_icon)
            end
         else
             if prop and prop[2] then
                icon:loadTexture(prop[2])
             end
         end
         -- 显示数量
         local num  = item:getChildByName("Text_1")
         num:setString(self.SignList["awards"][i]["award_num"])
         ---------------------下边是对是否签到做的一些逻辑处理
         -- ShowNum 是签到天数，需要两步对显示进行处理 
         -- 1 分领取过和没领取过进行显示，不对今天是否领取就行处理

         if i > ShowNum then
            item:getChildByName("Image_sprit"):setVisible(false)
            item:getChildByName("Image_Isshow"):setVisible(false)
         elseif i <= ShowNum then
            item:getChildByName("Image_sprit"):setVisible(false)
            item:getChildByName("Image_Isshow"):setVisible(true)

         end

         -- 2 等一false 是今天还没有领取 ，如果没领取就是当前签到数量+1，领取过了就是ShowNum
         -- 第二不是对今天的物品进行处理
         if IsLanding == false then
            if i == ShowNum+1 then
                item:getChildByName("Image_sprit"):setVisible(true)
                item:getChildByName("Image_Isshow"):setVisible(false)
                self:runAnimation(item,item:getChildByName("Image_sprit"))
                local ii = item:getChildByName("Panel_3")
                if ii then
                    self:SpineSign(ii)
                else
                    print("ii == nil")
                end
            end
         else
            if i == ShowNum then
                item:getChildByName("Image_sprit"):setVisible(true)
                item:getChildByName("Image_Isshow"):setVisible(true)
                self:runAnimation(item,item:getChildByName("Image_sprit"))
            end
         end
    end
end
-- 执行ky上下飘动的动作
function SignInLayer:runAnimation( icon,item )
    -- body
   
    local moveBy  = cc.MoveTo:create(0.5,cc.p(item:getPositionX(),item:getPositionY()+6))
    local moveBy1 = cc.MoveTo:create(0.5,cc.p(item:getPositionX(),item:getPositionY()-6))
    --local callfunc = cc.CallFunc:create(cardViewEnd_callBack)
    local seq = cc.Sequence:create(moveBy,moveBy1)

    item:runAction(cc.RepeatForever:create(seq))
end
-- 执行spine 签到特效
function SignInLayer:SpineSign( spineRoot1 )
-- body
    local spineRoot = spineRoot1
    --local dt = cc.DelayTime:create(0.01)
    local cf = cc.CallFunc:create(function()
         ---添加spine
        -- local end_pos = string.find(id_str,'atlas') - 1
        -- local spName = string.sub(id_str,0,end_pos)

        self.skeletonNode = sp.SkeletonAnimation:create("res/uifile/n_UIShare/sign_in/qian_dao/qiandao.json","res/uifile/n_UIShare/sign_in/qian_dao/qiandao.atlas", 1.0)
        self.skeletonNode:setAnchorPoint(0.5,0.5)
        self.skeletonNode:setPosition(51,68)
        spineRoot:addChild(self.skeletonNode,1000)
        self.skeletonNode:setAnimation(1, "effect", true)

    end)
    local seq = cc.Sequence:create(cf)
    spineRoot:runAction(seq)
end
-- 删除spine 签到特效
function SignInLayer:SpineDelete( ... )
    -- body
    if self.skeletonNode ~=nil then 
       self.skeletonNode:stopAllActions()
       self.skeletonNode:removeFromParent()
       self.skeletonNode = nil
    end
end
-- 点击item的回调 对item的事件响应和显示的设置
function SignInLayer:ItemCallBack( sender,eventType,index,item )
    -- body
    
    local ShowNum    = self.SignList["landing_count"] -- 已领取的数量
    local IsLanding  = self.SignList["is_landed"]     -- 今天是否登陆
    -- local index = sender:getTag()-1000
    print("点击模板进入"..index)
    if IsLanding then
       
       self:ShowDec(self.SignList["awards"][index])
    else
        if ShowNum + 1 == index then 

            self:SendGet(sender)
            -- 领取后刷新item的显示
            self:refreArrt(item)
        else
            self:ShowDec(self.SignList["awards"][index])
        end
    end

end
-- 刷新界面属性
-- 点击领取后刷新当前领取item的显示
function SignInLayer:refreArrt( item )
    -- body
    -- 刷新item
    item:getChildByName("Image_sprit"):setVisible(true)
    item:getChildByName("Image_Isshow"):setVisible(true)
    self:SpineDelete()
end
-- 点击Item回调后响应的弹窗
function SignInLayer:ShowDec( table )

    local e_id = tonumber(table["award_id"])
    local  IconType  = table["award_type"]
    MsgManager:showSimpItemInfo(IconType,e_id)
    
end
-- 点击没有签到的item 链接服务器获取数据 并对item和数据进行处理
function SignInLayer:SendGet(sender )
    -- body
    local function reiceSthCallBack(data)
        print("获取奖励")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.BtnClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["state_code"]  == 1 then
           for i=1,#t_data["data"]["get"] do
               local Type     = t_data["data"]["get"][i]["item_type"]
               if Type == 1 then  -- 金币
                    user_info["gold"] = user_info["gold"] + t_data["data"]["get"][i]["num"]
                    if self.sManager and self.sManager.menuLayer then
                       self.sManager.menuLayer:RefshTopBar()
                    end
                elseif Type == 2 then  -- 星石
                    user_info["gem"] = user_info["gem"] + t_data["data"]["get"][i]["num"]
                    if self.sManager and self.sManager.menuLayer then
                        self.sManager.menuLayer:RefshTopBar()
                    end
                end     
           end
            if g_channel_control.UIVersion > 1 then
                local itemData  ={}
                local oneItemData = {}
                oneItemData["id"]        = t_data["data"]["get"][1]["id"]
                oneItemData["item_type"] = t_data["data"]["get"][1]["item_type"]
                oneItemData["num"]       = t_data["data"]["get"][1]["num"]
                
                table.insert(itemData,oneItemData)

                local sData = {}
                sData["AllData"] = itemData
                sData["naem"] = UITool.ToLocalization("领取成功")
                if self.sManager ~= nil then
                    self.sManager:toMailGetAllLayer(sData)
                end

            else

                 MsgManager:showSimpItemInfo(t_data["data"]["get"][1]["item_type"],t_data["data"]["get"][1]["id"],t_data["data"]["get"][1]["num"],UITool.ToLocalization("领取成功"))

            end
            
           
            self.SignList["is_landed"] = true   

            self.SignList["landing_count"]  =  self.SignList["landing_count"] + 1
            self:refreDay(self.SignList["landing_count"])
            self:setDayArrow(self.SignList["landing_count"])
            self:refreBox()
        end
    end
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "landing_award_get",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 获取奖励 mydata = "..mydata)
    self.sManager:createWaitLayer()
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--根据天数设置小三角箭头
function SignInLayer:setDayArrow( num )
    -- body
    -- 这是天数进度条的总长度
    local distance  = 1002
    -- 算出每一天需要移动的距离
    local dayDistance = distance/self.TestLen
    -- 获取季度条
    local node    = self.uiLayer:getChildByTag(2)
    local imageBg = node:getChildByName("Image_form_bg")
    local iBG     = imageBg:getChildByName("Image_bg")
    local bar     = iBG:getChildByName("LoadingBar_2")
   

    -- -- 记录小三角的初始坐标X y不变
    -- local pointX   = day:getPositionX()
    -- 根据签到的天数算出便宜距离
    local offx = num/self.TestLen *100
    bar:setPercent(offx)
    --day:setPositionX(pointX+offx)

end
--初始化隐藏箱子 ，根据参数来控制显示隐藏
function SignInLayer:IsHideBox( isValue )
    -- body
    local node     = self.uiLayer:getChildByTag(2)
    local imageBgF = node:getChildByName("Image_form_bg")
    local imageBg_1  = imageBgF:getChildByName("Image_bg")
    local box_1    = imageBg_1:getChildByName("Image_model_1")
    box_1:setVisible(isValue)
    local box_2    = imageBg_1:getChildByName("Image_model_2")
    box_2:setVisible(isValue)
    box_2:setAnchorPoint(cc.p(0.5,0.5))
    local box_3    = imageBg_1:getChildByName("Image_model_3")
    box_3:setVisible(isValue)
end
-- 根据天数初始化宝箱的位置
function SignInLayer:setBox( ... )
    -- body
    self:IsHideBox(true)
    -- 这是天数进度条的总长度
    local distance  = 1002
    -- 算出每一天需要移动的距离
    local dayDistance = 1002/self.TestLen
    -- 获取到宝箱
    local node     = self.uiLayer:getChildByTag(2)
    local imageBgF = node:getChildByName("Image_form_bg")
    local imageBg_1  = imageBgF:getChildByName("Image_bg")
    local box_1    = imageBg_1:getChildByName("Image_model_1")
    box_1:setAnchorPoint(cc.p(0.5,0.5))
    local box_2    = imageBg_1:getChildByName("Image_model_2")
    box_2:setAnchorPoint(cc.p(0.5,0.5))
    local box_3    = imageBg_1:getChildByName("Image_model_3")
    box_3:setAnchorPoint(cc.p(0.5,0.5))
    -- 1天 7天 21天  这三个位置放宝箱
    box_1:setPositionX(self.initX+dayDistance-12) 
    box_2:setPositionX(self.initX+dayDistance*7-12)
    box_3:setPositionX(self.initX+dayDistance*21-65)
    local function callBack( sender,eventType )
        -- body 
        local name = sender:getName()
        print("name name name == "..name)
        if eventType == ccui.TouchEventType.ended then
            if name == "Image_model_1" then
                self:BoxCallBack("1")
            elseif name == "Image_model_2" then
                self:BoxCallBack("7")
            elseif name == "Image_model_3" then
                self:BoxCallBack("21")
            end
        end
    end

    box_1:addTouchEventListener(callBack)
    box_2:addTouchEventListener(callBack)
    box_3:addTouchEventListener(callBack)
end
-- 点击宝箱的回调 
function SignInLayer:BoxCallBack( day )
    -- body
    -- extra_awards_state 这表里的值是代表领取过的
    -- 获取签到次数
    local dayNum =  self.SignList["landing_count"] 
    print("day day day == "..day)
    if day == "1" then
        if self.SignList["extra_awards_state"][1] or dayNum == 0 then --这个领取过的
            local sData = {}
            sData["naem"] = UITool.ToLocalization("物品信息")
            sData["AllData"] = self.SignList["extra_awards"]["1"]
            sData["isShow"] = true
            self.sManager:toMailGetAllLayer(sData)
        else --这个是没有领取过，需要判断现在是否可以领取
            if dayNum  >= 1 then
                self:SenderBox(1)
            end
        end
    elseif day == "7" then
        if self.SignList["extra_awards_state"][2] or dayNum < 7 then --这个领取过的
            local sData = {}
            sData["naem"] = UITool.ToLocalization("物品信息")
            sData["AllData"] = self.SignList["extra_awards"]["7"]
            sData["isShow"] = true
            self.sManager:toMailGetAllLayer(sData)
        else --这个是没有领取过，需要判断现在是否可以领取
            print("dayNum dayNum dayNum == "..dayNum)
            if dayNum  >= 7 then
                 self:SenderBox(7)
            end
        end
    elseif day == "21" then
        if self.SignList["extra_awards_state"][3] or dayNum < 21 then --这个领取过的
            local sData = {}
            sData["naem"] = UITool.ToLocalization("物品信息")
            sData["AllData"] = self.SignList["extra_awards"]["21"]
            sData["isShow"] = true
            self.sManager:toMailGetAllLayer(sData)
        else --这个是没有领取过，需要判断现在是否可以领取
            if dayNum  >= 21 then
                self:SenderBox(21)
            end
        end
    end

end
-- 像服务器发送领取宝箱的消息
function SignInLayer:SenderBox( day )
    -- body
    local function reiceSthCallBack(data)
        print("获取宝箱奖励奖励")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
           
           MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.BtnClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            
             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["state_code"]  == 1 then
           local sData = {}
           sData["AllData"] = t_data["data"]["get"]
           -- print("gggggggggg == "..#t_data["data"]["get"])
           if self.sManager then
              self.sManager:toMailGetAllLayer(sData)
           end
           
           if day == 1 then
             self.SignList["extra_awards_state"][1] = 1
           elseif day == 7 then
             self.SignList["extra_awards_state"][2] = 7
           elseif day == 21 then
             self.SignList["extra_awards_state"][3] = 21
           end
           self:refreBox()
        end
    end
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "landing_extra_award_get",
        ["extra_award_index"] = day
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 宝箱获取奖励 mydata = "..mydata)
    self.sManager:createWaitLayer()
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

-- 刷新宝箱的视图
function SignInLayer:refreBox( ... )
    -- body
    print("进入了这里refreBox")
        -- 获取到宝箱
    local node       = self.uiLayer:getChildByTag(2)
    local imageBgF   = node:getChildByName("Image_form_bg")
    local imageBg_1  = imageBgF:getChildByName("Image_bg")
    local box_1      = imageBg_1:getChildByName("Image_model_1")
    local boxI_1     = box_1:getChildByName("Image_box")
    local box_2      = imageBg_1:getChildByName("Image_model_2")
     local boxI_2    = box_2:getChildByName("Image_box")
    local box_3      = imageBg_1:getChildByName("Image_model_3")
    local boxI_3    = box_3:getChildByName("Image_box")
    local dayNum =  self.SignList["landing_count"] 
    if self.SignList["extra_awards_state"][1] then -- 领取过了
        boxI_1:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_019.png")
         print("进入了这里refreBox  1 ")
    else --  没有领取，但满足领取条件的 
        if dayNum >= 1 then 
            boxI_1:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_018.png") 
            print("进入了这里refreBox  2 ")
        else -- 不满足条件的
           boxI_1:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_017.png")  
           print("进入了这里refreBox  3 ")
        end
    end

    if self.SignList["extra_awards_state"][2] then -- 领取过了
        boxI_2:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_016.png")

    else --  没有领取，但满足领取条件的 
        if dayNum >= 7 then 
            boxI_2:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_015.png") 
        else-- 不满足条件的
            boxI_2:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_014.png") 
        end
    end


    if self.SignList["extra_awards_state"][3] then -- 领取过了
        boxI_3:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_007.png")

    else --  没有领取，但满足领取条件的 
        if dayNum >= 21 then 
            boxI_3:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_006.png") 
        else-- 不满足条件的
            boxI_3:loadTexture("res/uifile/n_UIShare/sign_in/yq_ui_005.png") 
        end
    end
end
--  刷新天数
function SignInLayer:refreDay( day )
    -- body
    local node    = self.uiLayer:getChildByTag(2)
    local imagebg = node:getChildByName("Image_form_bg")
    local test    = imagebg:getChildByName("Text_day")
    if g_channel_control.transform_SignInLayer_dayPosition == true then 
        test:setAnchorPoint(cc.p(0.5,0.5))
        test:setPosition(cc.p(119,42))
    end
    test:setString(day)
    --改变 已签到的天数的位置
    if g_channel_control.transform_SignInLayer_Text_day_pos == true then
        local textDayPosX, textDayPosY = 105.5,42--test:getPosition();

        local offset = 15;
        if tonumber(day) < 10 then
            offset = 20
        end

        print("offset "..offset)
        test:setPosition(textDayPosX + offset, textDayPosY);
        
    end
    
  
    
end
-- 关闭按钮
function SignInLayer:BtnClose( ... )
    self.exist = false
    self.sData = {}
    self.rData = {}
    self.AwardItemList = nil
    self.AwardItemList = nil
    self:clearEx()
    SceneManager:toStartLayer()
end

function SignInLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function SignInLayer:create(rData)

     local login = SignInLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login

end
