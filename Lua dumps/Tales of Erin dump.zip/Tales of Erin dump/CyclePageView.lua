--[[
	CyclePageView.lua
	循环pageview
	目前只有横向 
	以后有时间再扩展
	这里先整图片吧，没时间了。。
	SCROLLVIEW_DIR_HORIZONTAL
]]

CyclePageView = class("CyclePageView",function()
    return cc.Node:create()
end)

function CyclePageView:ctor(size)
	self:initWithSize(size)
end

function CyclePageView:initWithSize(size)
    self._scrollView =  ccui.ScrollView:create()
    self._scrollView:setContentSize(size)
    self._scrollView:setDirection(SCROLLVIEW_DIR_HORIZONTAL)
    self._scrollView:setBounceEnabled(false)
    self._scrollView:setTouchTotalTimeThreshold(0.1)
    self._scrollView:setScrollBarEnabled(false)
    self:addChild(self._scrollView)
    self._size = size
    self._isAutoMove = true  --自动滚动开关
end

function CyclePageView:setIsAutoMove(isAutoMove)
    self._isAutoMove = isAutoMove
end

function CyclePageView:updatePageView(data)
	self._data = data
	self._scrollView:removeAllChildren()
    self._totalNum = #self._data
    self._curIndex = 1

    self.pageNodes = {}

    if self._totalNum <= 1 then 
    	self._scrollView:setInnerContainerSize(cc.size(self._size.width, self._size.height))
    	self._pos = {cc.p(0,0)}
    	self:initOnePage()
    else 
    	self._scrollView:setInnerContainerSize(cc.size(self._size.width*3, self._size.height))
    	self._pos = {cc.p(0,0),cc.p(self._size.width,0),cc.p(self._size.width*2,0)}
    	self:initThreePage()
    	self:restoreFirst() ---恢复到第一个
    	self:starAutoMove() ---开启自动旋转
    end 
end

---刷新节点
function CyclePageView:reloadPage(imgNode, i)
    if imgNode == nil then
        return
    end
    if #self._data == 0 or self._data[i] == nil then
        return
    end
    --由于搜索路径的问题导致搜索到包体内部，所以现在临时方案换名字
    local bannerPath = "act/"..tostring(self._data[i].imgFile)..".png"
    imgNode:loadTexture(bannerPath)
    -- imgNode:loadTexture("res/hd/Resources/act/"..tostring(self._data[i].imgFile)..".png")
    local function touchEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
              local p1 = sender:getTouchBeganPosition()
              local p2 = sender:getTouchEndPosition()
              local l = cc.pGetDistance(p1,p2)
              if l < 20 then
                  self.onClickEvent(i)
              end
        end
    end
    imgNode._dataTag = i
    imgNode:setTouchEnabled(true)
    imgNode:setSwallowTouches(false)
    imgNode:addTouchEventListener(touchEvent) 
end
---初始化只有一页
function CyclePageView:initOnePage()
    self._scrollView:setTouchEnabled(false)
    local img = ccui.ImageView:create()
    img:setAnchorPoint(cc.p(0,0))
    img:setPosition(self._pos[1])
    self:reloadPage(img, 1)
    self._scrollView:addChild(img)
end
---初始化大于1页的情况
function CyclePageView:initThreePage()
    self._scrollView:setTouchEnabled(true)
    for i=1,3 do
        local img = ccui.ImageView:create()
        img:setAnchorPoint(cc.p(0,0))
        local idx = i 
        if idx > self._totalNum then 
        	idx = 1
        end 
 		self:reloadPage(img, idx)
        img:setPosition(self._pos[i])
        self._scrollView:addChild(img)
        self.pageNodes[i] = img
        img._dataTag = idx
    end
    self._scrollView:jumpToPercentHorizontal(50)
    self:turnPageEnd(2)
    self._scrollView:addTouchEventListener(function(sender,eventType)
        self:onScrollEvent(sender,eventType)
    end)
end

function CyclePageView:onScrollEvent(sender,eventType)
    self:stopAllActions()
    if eventType == TOUCH_EVENT_BEGAN then
       	self._dealPageView = true
        self:stopAutoMove()
    elseif eventType == TOUCH_EVENT_MOVED then
    elseif eventType == TOUCH_EVENT_CANCELED then
    	if self._dealPageView then 
    		self:dealMovePage(sender)
    	end 
        self:starAutoMove();
    elseif eventType == TOUCH_EVENT_ENDED then
    	if self._dealPageView then 
    		self:dealMovePage(sender)  
    	end
        self:starAutoMove();
    end
end

--翻页结束
function CyclePageView:turnPageEnd(showIndex)
	self.onturnEvent(showIndex)
end

function CyclePageView:getPercent()
    local innerCSize = self._scrollView:getInnerContainerSize()
    local contSize =  self._scrollView:getContentSize()
    local w = innerCSize.width - contSize.width;
    local pos = self._scrollView:getInnerContainerPosition()
    local percent = 0
    if w ~= 0 then 
        percent = -(pos.x *100/w)
    end 
    if percent <0 then 
        percent = 0
    end 
    if percent >100 then 
        percent = 100
    end 
    return percent
end
--todo 扩展成方向可设置
function CyclePageView:starAutoMove()
    if self._isAutoMove then 
        local function doTurn( )
            self:stopAllActions()
            self._scrollView:jumpToPercentHorizontal(100)
            self:leftAction()
        end
        self:stopAllActions()
        local delay = cc.DelayTime:create(3.5)
        self:runAction(cc.Sequence:create(delay,cc.CallFunc:create(doTurn)))
    end 
end

function CyclePageView:stopAutoMove()
    self:stopAllActions()
end

------todo代码重构一下
---这个是恢复到第一个
function CyclePageView:restoreFirst()
    local newImgs = {}
    for i=1,3 do
        local img = self.pageNodes[i]
        local newPos = i+1
        if newPos>3 then 
            newPos = 1
        end
        img:setPosition(self._pos[newPos])
        newImgs[newPos] = img
    end
    self.pageNodes = newImgs
    ---先跳转到相反的方向
    self._scrollView:jumpToPercentHorizontal(50)

    local centerPage = self.pageNodes[2]
    local leftPage = self.pageNodes[1]
    local newTag = centerPage._dataTag - 1
    if newTag <= 0 then 
    	newTag = self._totalNum
    end 
	self:reloadPage(leftPage, newTag)
	self:turnPageEnd(centerPage._dataTag)
end

------todo代码重构一下
function CyclePageView:rightAction()
    local newImgs = {}
    for i=1,3 do
        local img = self.pageNodes[i]
        local newPos = i+1
        if newPos>3 then 
            newPos = 1
        end
        img:setPosition(self._pos[newPos])
        newImgs[newPos] = img
    end
    self.pageNodes = newImgs
    ---先跳转到相反的方向
    local per = 100 - self:getPercent()
    self._scrollView:jumpToPercentHorizontal(per)
    local _time = 0.3
    self._scrollView:scrollToPercentHorizontal(50, _time,false)
    local function endFunc()
        --刷新
        local centerPage = self.pageNodes[2]
        local leftPage = self.pageNodes[1]
        local newTag = centerPage._dataTag - 1
        if newTag <= 0 then 
        	newTag = self._totalNum
        end 
		self:reloadPage(leftPage, newTag)
		self:turnPageEnd(centerPage._dataTag)
		self._scrollView:setTouchEnabled(true)
		self:starAutoMove()   
    end
    self._scrollView:setTouchEnabled(false)
    local delay = cc.DelayTime:create(_time+0.1)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(endFunc))
    self._scrollView:runAction(sequence)
    self:stopAutoMove()	
end

function CyclePageView:leftAction( )
    local newImgs = {}
    for i=1,3 do
        local img = self.pageNodes[i]
        local newPos = i-1
        if newPos<=0 then 
            newPos = 3
        end
        if img ~= nil then
            img:setPosition(self._pos[newPos])
            newImgs[newPos] = img
        end 
    end
    self.pageNodes = newImgs
    local per = 100 - self:getPercent()
    self._scrollView:jumpToPercentHorizontal(per)
    local _time = 0.3
    self._scrollView:scrollToPercentHorizontal(50, _time,false)
    local function endFunc()
    	--刷新
        local centerPage = self.pageNodes[2]
        local rightPage = self.pageNodes[3]
        local newTag = centerPage._dataTag + 1
    	if newTag > self._totalNum then 
        	newTag = 1
        end 
		self:reloadPage(rightPage, newTag)
		self:turnPageEnd(centerPage._dataTag)
        self._scrollView:setTouchEnabled(true)
        self:starAutoMove()
    end
    self._scrollView:setTouchEnabled(false)
    local delay = cc.DelayTime:create(_time+0.1)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(endFunc))
    self._scrollView:runAction(sequence)
    self:stopAutoMove() 
end

function CyclePageView:dealMovePage(sender)
    local p1 = sender:getTouchBeganPosition()
    local p2 = sender:getTouchMovePosition()
    local distanceX = p2.x - p1.x
    if distanceX == 0 then 
        return 
    end 
    local width = self._scrollView:getContentSize().width
    if distanceX < 0 then  ---左转
        if math.abs(distanceX) >= width*0.3 then 
            self:leftAction()
        else 
            local _time = 0.3
            self._scrollView:scrollToPercentHorizontal(50, _time,false)
            local function endFunc()
                self._scrollView:setTouchEnabled(true)
            end
            self._scrollView:setTouchEnabled(false)
            local delay = cc.DelayTime:create(_time+0.1)
            local sequence = cc.Sequence:create(delay, cc.CallFunc:create(endFunc))
            self._scrollView:runAction(sequence)
        end 
    else 
        if math.abs(distanceX) >=width*0.3 then 
            self:rightAction()
        else 
            local _time = 0.3
            self._scrollView:scrollToPercentHorizontal(50, _time,false)
            local function endFunc()
                self._scrollView:setTouchEnabled(true)
            end
            self._scrollView:setTouchEnabled(false)
            local delay = cc.DelayTime:create(_time+0.1)
            local sequence = cc.Sequence:create(delay, cc.CallFunc:create(endFunc))
            self._scrollView:runAction(sequence)
        end 
    end
    self._dealPageView = false
end

