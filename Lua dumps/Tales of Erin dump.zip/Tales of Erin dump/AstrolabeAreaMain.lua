--/*说明
	--星盘主区
--*/
AstrolabeAreaMain = {}

function AstrolabeAreaMain:init(_self)
	self.baseSelf = _self
	self:setClimax()
	self:touchClick()
	self.skeletonNode = nil

end
--每个区域标示图片左下角的
function AstrolabeAreaMain:setMarkImage( ... )
	--星盘主界面不需要显示
	local  areaImage = self.baseSelf.rootNode:getChildByName("Image_area")
	areaImage:setVisible(false)
end
--设置顶级技能
function AstrolabeAreaMain:setClimax( ... )
	--从本地或取需要的数据
	local  cmType    = self.baseSelf.areaTable["climax_type"]
	local  cmId      = self.baseSelf.areaTable["climax_id"] 
	local  cmNum     = self.baseSelf.areaTable["climax_num"]
	--取出图片
	local  cmBtn     = self.baseSelf.rootNode:getChildByName("Image_climax")
	print(" cmType cmType == "..cmType)
	print(" cmId cmId  == "..cmId )
	if cmType == 0 and cmId == 0 then
		cmBtn:setVisible(false)
		return
	end
	local  cmTable   = astrolabe_climax[cmType][cmId]
	self:setMarkImage()
	--或取服务器的状态
	local  climax  =  self.baseSelf.serverData["climax"]
	-- 与的判断
	-- 与的条件达成 在根据服务器状态显示图片
	local climaxB  = self.baseSelf:andTrue(self.baseSelf.areaTable["climax_unlock"])
	if climaxB then
		if climax == 1 then
			cmBtn:loadTexture(cmTable["icon_checked"])
		else
			cmBtn:loadTexture(cmTable["icon_unlock"])
		end
	else
		cmBtn:loadTexture(cmTable["icon_locked"])
	end
		
end
--点击事件

function AstrolabeAreaMain:touchClick( ... )

	for i = 1,self.baseSelf.len do
		local imageChild = self.baseSelf.rootNode:getChildByName("Image_"..i)
		imageChild:setTouchEnabled(true)
	
		print("点击 Image_ == "..imageChild:getName())
		imageChild:addClickEventListener(function()
			print("点击 jin ru Image_ == "..imageChild:getName())
        	self:toAstrolabeLockBox(imageChild)
    	end)
    end  
    --点击顶级天赋
    local  cmBtn     = self.baseSelf.rootNode:getChildByName("Image_climax")
    cmBtn:addClickEventListener(function()
        self:toAstrolabeClimaxBox()
    end)
end


--[[
	星盘解锁提升弹窗 2次
	
]]
function AstrolabeAreaMain:toAstrolabeInfo( imageChild )
	local view = AstrolabeInfoBoxLayer.new():init()
	--点击确定
	view.confrimBtn:addClickEventListener(function()
		local tempData = { 
            rpc = "hero_astrolabe_star_up",
            hero_id = self.baseSelf.hero_id,
            area_id = self.baseSelf.curAreaIndex,
            star_id = view.skillId,
            star_lv = view.addLv - view.lv_count

        }
        GameManagerInst:rpc(tempData,3,
        function(data)
            --刷新次界面
            self:playSkillEffc(imageChild)
            self.serverData = data
			self.baseSelf.refreshCallFunc(self.baseSelf.asrMianLaSelf)
			view:returnBack()

        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText,function()
               
            end)
        end,
        true)

    end)

    view:loadData(imageChild,self.baseSelf,self,self.baseSelf.hero_id)
    GameManagerInst:showModalView(view)	
end
--播放技能点升级特效
function AstrolabeAreaMain:playSkillEffc(spinNode)
    local spineRoot = spinNode
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
    end 
    local id_str = "res/uifile/n_UIShare/astrolabe/xing_pan_sheng_ji/xing_pan_sheng_ji.atlas"--title_conf[tonumber(item_id)].res_spine
    if cc.FileUtils:getInstance():isFileExist(id_str) then 
        self.skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(id_str))
        local size = spineRoot:getSize()
        self.skeletonNode:setPosition(size.width/2+2,size.height/2)
        self.skeletonNode:registerSpineEventHandler(
            function (event) 
            	print(string.format("-------=====[spine] %d end:", event.trackIndex))
               -- self.baseSelf.refreshCallFunc(self.baseSelf.newRoleStarSelf)
        end, sp.EventType.ANIMATION_END)
        
        spineRoot:addChild(self.skeletonNode,123)
        self.skeletonNode:addAnimation(1,"effect",false)
        
    else 
          print("文件不存在 error file not exist:"..id_str)
    end
    
end
--[[
	星盘解锁确认弹窗 1次
	
]]
function AstrolabeAreaMain:toAstrolabeLockBox( imageChild )
	    --点击链接服务器
    local view = AstrolabeLockBoxLayer.new():init()

    view.upBtn:addClickEventListener(function()
    	view:returnBack()
    	self:toAstrolabeInfo(imageChild)
    end)
 
    view:loadData(imageChild,self.baseSelf,self,self.baseSelf.hero_id)
    GameManagerInst:showModalView(view)

end

-- 顶级天赋的弹窗
function AstrolabeAreaMain:toAstrolabeClimaxBox( ... )
	local view = AstrolabeClimaxBoxLayer.new():init()
	view.confrimBtn:addClickEventListener(function()
    	local tempData = { 
            rpc = "hero_astrolabe_climax_up",
            hero_id = self.baseSelf.hero_id,
            area_id = self.baseSelf.curAreaIndex,

        }
        GameManagerInst:rpc(tempData,3,
        function(data)
            --刷新次界面
            self.serverData = data
			self.baseSelf.refreshCallFunc(self.baseSelf.asrMianLaSelf)
			view:returnBack()

        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText,function()
               
            end)
        end,
        true)
    	
    end)
    view:loadData(self.baseSelf,self)
    GameManagerInst:showModalView(view)	

end

function AstrolabeAreaMain:AsbLockStr( _tabel )
	-- body
	local andTable = _tabel
	local index = 0
	local strTable = {}
	if  andTable.hero_lv  > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2000]),andTable.hero_lv)
	end
	if andTable.hero_add > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2001]),andTable.hero_add)
	end
	if andTable.feeling_lv > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2002]),andTable.feeling_lv)
	end
	if andTable.soul_lv > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2003]),andTable.soul_lv)
	end
	if andTable.astro_lv > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2004]),andTable.astro_lv)
	end
	if andTable.hero_sk_add > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2005]),andTable.hero_sk_add)
	end
	if andTable.astro_sk_add > 0 then
		index = index+1
		strTable[index] = {}
		strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2006]),andTable.astro_sk_add)
	end
	return strTable
 
end










