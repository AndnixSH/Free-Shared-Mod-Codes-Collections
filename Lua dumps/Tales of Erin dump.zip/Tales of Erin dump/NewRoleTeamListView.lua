--require "XUIView"

NewRoleTeamListView = class("NewRoleTeamListView",XUIView)
NewRoleTeamListView.CS_FILE_NAME = "NewRoleTeamListView.csb"
NewRoleTeamListView.CS_BIND_TABLE = 
{
    --
    panelGray = "/i:364/i:147",
    btnTeamList = "/i:364/i:254",
    panelBtns = "/i:364/i:204",
    imgBtnTeam1 = "/i:364/i:204/i:271",
    imgBtnTeam2 = "/i:364/i:204/i:272",
    imgBtnTeam3 = "/i:364/i:204/i:274",
    imgBtnTeam4 = "/i:364/i:204/i:276",
    imgBtnTeam5 = "/i:364/i:204/i:278",
    imgBtnTeam6 = "/i:364/i:204/i:280",
    imgBtnTeam7 = "/i:364/i:204/i:282",
    imgBtnTeam8 = "/i:364/i:204/i:149",
    imgBtnTeam9 = "/i:364/i:204/i:151",
    imgBtnTeam10 = "/i:364/i:204/i:153",
}

NewRoleTeamListView.titleSelected = cc.c3b(225, 188, 113)
NewRoleTeamListView.titleNor = cc.c3b(255, 231, 180)

function NewRoleTeamListView:init(returnBackCallFunc,sDelegate,currentTeamIndex,teamListNames)
    NewRoleTeamListView.super.init(self)

    self.returnBackCallFunc = returnBackCallFunc
    self.sDelegate = sDelegate

    self.teamListNames = teamListNames
    
    self.currentTeamIndex = currentTeamIndex
    if self.currentTeamIndex == 0 then
        self.currentTeamIndex = 1
    end
    --
    self.changeTeamIndex = self.currentTeamIndex
    self.changeTeamBtns = {
        self.imgBtnTeam1,
        self.imgBtnTeam2,
        self.imgBtnTeam3,
        self.imgBtnTeam4,
        self.imgBtnTeam5,
        self.imgBtnTeam6,
        self.imgBtnTeam7,
        self.imgBtnTeam8,
        self.imgBtnTeam9,
        self.imgBtnTeam10,
    }

    local function btnFunc(sender)
        self:OnBtnChangeTeam(sender:getTag())
    end

    for i = 1,10 do
        self.changeTeamBtns[i]:setTag(i)
        self.changeTeamBtns[i]:addClickEventListener(btnFunc)
    end
    
    self.panelGray:addClickEventListener(function()
        self:returnBack()
    end)
    self.btnTeamList:addClickEventListener(function()
        self:returnBack()
    end)
    --
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    --
    self:refreshBtns()

    return self
end

function NewRoleTeamListView:returnBack()
    if self.returnBackCallFunc then
        self.returnBackCallFunc(self.sDelegate,self.changeTeamIndex)
    end
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function NewRoleTeamListView:OnBtnChangeTeam(idx)
    self.changeTeamIndex = idx
    self:returnBack()
end

function NewRoleTeamListView:refreshBtns()
    for i = 1,#self.changeTeamBtns do
        local lbTeamName = self.changeTeamBtns[i]:getChildByName("lbTeamName")
        if self.teamListNames[i] then
            local teamName = self.teamListNames[i]
            lbTeamName:setString(UITool.ToLocalization(teamName))
            if i == self.currentTeamIndex then
                self.changeTeamBtns[i]:loadTexture("n_UIShare/role/team/newteam/jsjm_b_018_2.png")
                lbTeamName:setColor(self.titleSelected)
            else
                self.changeTeamBtns[i]:loadTexture("n_UIShare/role/team/newteam/jsjm_b_018_1.png")
                lbTeamName:setColor(self.titleNor)
            end
        else
            self.changeTeamBtns[i]:setVisible(false)
        end
    end
end



