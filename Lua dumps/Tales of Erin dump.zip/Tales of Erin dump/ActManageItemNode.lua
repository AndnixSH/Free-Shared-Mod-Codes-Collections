-----------/*备注*/--------
-- 右边的控件 在ActManage调用sendData函数 获取服务器数据
-- 获取的数据里边是当前开放的活动，和所需要显示的信息
-- 没个活动里边具体有多少条目，需要在请求服务器获得 例如签到成就
-- 此界面设置右边条目，和记录当前选择的活动
-- self.OnSelf.selectIndex  这个数据是ActManageLayer里面定义
    -- 因为这个类会根据元素进行创建，例如6个就会创建六次，selectIndex 需要唯一性所以放在调用类中定义
-- act_show_type 三种类型  achieve成就 landing_award登陆奖励  only_show显示单一图片的 
    -- 如果是成就 还有一种是上边是图片下面是列表的类型  是根据main_pic  来做区分的 
    -- main_pic 是空就是成就无图片类型  否则是有图片类型，其次不是空类型是only_show 显示单个
ActManageItemNode = class("ActManageItemNode", XUICellView)

ActManageItemNode.CS_FILE_NAME = "ActManageItemNode.csb"
ActManageItemNode.tableAll  = {}

ActManageItemNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}

function ActManageItemNode:init(...)

    NewMailNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    print("走了几遍初始化函数")
    return self
end
function ActManageItemNode:setData( tdad )
    -- body
    self.DataTest = tdad;
    self.OnSelf  = tdad["OnSelf"];
end


function ActManageItemNode:onResetData()
    if not self._data then return end
    local dtable = {
            ["title_des"]           = UITool.getUserLanguage(self._data["title_des"]),          -- 长描述            
            ["tm_str"]              = self._data["tm_str"],             -- 时间描述     
            ["main_pic"]            = self._data["main_pic"],           -- 显示图片  
            ["title"]               = UITool.getUserLanguage(self._data["title"]),              -- 活动主标题      
            ["title_des_s"]         = UITool.getUserLanguage(self._data["title_des_s"]),        -- 活动短描述             
            ["right_title"]         = UITool.getUserLanguage(self._data["right_title"]),        -- 活动右标题
            ["act_show_type"]       = self._data["act_show_type"],      -- 活动类型
            ["right_corner_pic"]    = self._data["right_corner_pic"],   -- 右角标
            ["right_pic"]           = self._data["right_pic"],          -- 右图片路径 规则_1 _2 _1为选中状态，_2选中状态  
            ["id"]                  = self._data["id"],                 -- 活动的ID
            ["parameter"]           = self._data["parameter"],          -- 跳转的功能
            ["red_point"]           = self._data["red_point"],          -- 红点状态
            ["unlock_lv"]           = self._data["unlock_lv"],          -- 解锁等级
            ["ui_file"]             = self._data["ui_file"],

    }
    ---- 跳转网页新加的参数 评分点赞开关
    if g_channel_control.b_facebook then
        dtable["btn_normal"]      = self._data["btn_normal"]        -- 跳转正常的按钮图片
        dtable["btn_click"]       = self._data["btn_click"]          -- 跳转点击高亮图片
        dtable["btn_state"]       = self._data["btn_state"]          -- 状态 1 跳转状态  2 领取状态  3 领取过状态
        dtable["btn_time"]        = self._data["btn_time"]           -- 跳转网页 多少秒后显示领取状态
    end
    print("调用了几次")
    local  panelP        = self.PanelList
    -- 图标
    local  ItemBg        = panelP:getChildByName("Image_1")
    -- 标题
    local tex            = panelP:getChildByName("Text_1")
    -- 红点
    local Image_h        = panelP:getChildByName("Image_h")
    if self._data["red_point"] == 1 then
        Image_h:setVisible(true)
    else
        Image_h:setVisible(false)
    end
    if g_channel_control.transform_ActManageItemNode_Alignment == true then
        -- tex:setFontSize(20) 
        tex:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        tex:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        tex:ignoreContentAdaptWithSize(false);
        tex:setTextAreaSize(cc.size(160,60))
        tex:setPosition(cc.p(84,22))
        tex:setFontSize(20)     
    end    
    if self:getIndex() == self.OnSelf.selectIndex then
        print("走了几遍 "..self.OnSelf.selectIndex)
        ItemBg:loadTexture(dtable["right_pic"].."_2.png")
        tex:setColor(cc.c3b(2, 255, 246))
        self.tableAll["Image"] = ItemBg
        self.tableAll["string"] = dtable["right_pic"]
        self.tableAll["text"]   = tex
        if dtable["act_show_type"] == "only_show" then    -- 单一图片
            self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
            self.OnSelf:ShowOnlyImage(dtable)
        elseif dtable["act_show_type"] == "achieve" then  -- 成就类型。1 成就获取条  2 成就上边有图片 下边成就条
            if dtable["main_pic"] == "" then
                self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                self.OnSelf:setPublicPor(dtable)
                self.OnSelf:sendDataOnly(dtable["id"],"achieve")
            else
                self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                self.OnSelf:ShowOnlyAch(dtable)
                self.OnSelf:sendDataOnly(dtable["id"],"onlyImageAc")
            end
        elseif dtable["act_show_type"] == "landing_award" then  -- 签到类型
            self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
            self.OnSelf:setPublicPor(dtable)
            self.OnSelf:sendDataOnly(dtable["id"],"achieve")
        elseif dtable["act_show_type"] == "facebook" then       -- 跳转网页
            if g_channel_control.b_facebook then
                self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                self.OnSelf:ShowOnlyImageToFacebook(dtable)
            end
        end
    else
        ItemBg:loadTexture(dtable["right_pic"].."_1.png")
        tex:setColor(cc.c3b(244, 231, 167))
    end

    tex:setString(dtable["right_title"])
    -- 角标
    local  corner        = panelP:getChildByName("Image_title")
    if corner then
        corner:loadTexture(dtable["right_corner_pic"])
    end
    -- id
    local  curId         = panelP:getChildByName("Text_id")
    curId:setString(dtable["id"])
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                
                self.tableAll["Image"]:loadTexture(self.tableAll["string"].."_1.png")
                self.tableAll["text"]:setColor(cc.c3b(244, 231, 167))
                ItemBg:loadTexture(dtable["right_pic"].."_2.png")
                tex:setColor(cc.c3b(2, 255, 246))
                self.tableAll["Image"] = ItemBg
                self.tableAll["string"] = dtable["right_pic"]
                self.tableAll["text"]   = tex
                self.OnSelf.selectIndex  = self:getIndex()
                -- 重新获取数据是因为判断是否显示小红点
               -- self.OnSelf:sendData()
                -- 点击活动按钮
 
                self.OnSelf:sendData(true)

                --self.OnSelf:PassOnRightNode()
                if dtable["act_show_type"] == "achieve" then -- 成就
                    if dtable["main_pic"] == "" then
                        self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                        self.OnSelf:setPublicPor(dtable)
                        self.OnSelf:sendDataOnly(dtable["id"],"achieve")
                    else
                        self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                        self.OnSelf:ShowOnlyAch(dtable)
                        self.OnSelf:sendDataOnly(dtable["id"],"onlyImageAc")
                    end
                elseif dtable["act_show_type"] == "landing_award" then -- 登陆奖励
                    self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                    self.OnSelf:setPublicPor(dtable)
                    self.OnSelf:sendDataOnly(dtable["id"],"achieve")
                elseif dtable["act_show_type"] == "only_show" then
                    self.OnSelf:steUnLockLevel(dtable["unlock_lv"])
                    self.OnSelf:setPublicPor(dtable)
                    self.OnSelf:ShowOnlyImage(dtable)
                end
                
            end      
        end
    end
    ItemBg:setSwallowTouches(false)
    ItemBg:addTouchEventListener(touchCallBack)
    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end
