--require "BagLayer"
--require "ConsoleLayer"

BagLayer = class("BagLayer",BasicLayer)
BagLayer.__index   = BagLayer
BagLayer.lClass    = 2
BagLayer.TabList   = nil
BagLayer.BagIndex  = 1  -- 1是素材 2是道具
BagLayer.m_matBtn  = nil
BagLayer.m_dojuBtn = nil
BagLayer.ListView  = nil
BagLayer.tsetNum   = nil
BagLayer.testId    = nil

local LIST_ITEM_H = 170 --item高度

function BagLayer:init()
	
    local node =cc.CSLoader:createNode("BagLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true
    self.ListView = node:getChildByName("ListView_1")
    -- 初始化背包按钮的状态
    local btnBag  = node:getChildByName("Image_bag")
    btnBag:loadTexture("res/uifile/n_UIShare/forge/xlzz_b_003_2.png")
    self:senderBag()
    self:initBtn()
    self:switchBtnIamg()
    self:initModel()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)
end
-- 获取服务器背包数据
function BagLayer:senderBag( ... )   
    -- body
    local function reiceSthCallBack(data)
        
        print("获取背包列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
             self.sManager:delWaitLayer()
         end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        print("---------------------")
         dump(t_data)
        if  t_data["data"]["state_code"] ~=1 then
            
            --MsgManager:showSimpMsg(t_data["data"]["warning"])
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            return
        end   
        if t_data["data"]["state_code"]  == 1 then

            self.TabList = t_data["data"]["bag"]
            -- 是否显示小红点
            if self.uiLayer ~= nil then
                local node = self.uiLayer:getChildByTag(2)
                if node ~= nil then
                    local btnForge = node:getChildByName("Image_forge")
                    if t_data["data"]["forge_state"] == 0 then
                        UITool.setCommmonBtnRedDop(btnForge,false)
                    elseif t_data["data"]["forge_state"] == 1 then
                        UITool.setCommmonBtnRedDop(btnForge,true,cc.p(137,66))
                    end
                end
            end
            dump( self.TabList)
            self:rsfBagMat()
            self:rsfBagUseprop()
            --print("bag mat len == "..self.TabList["mat"][1])
            self:refsList()

        end
    end
    self.sManager:createWaitLayer()

    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "bag_list",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励列表 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 初始化 背包按钮
function BagLayer:initBtn( ... )
    -- body
    local node     = self.uiLayer:getChildByTag(2)
    m_matBtn       = node:getChildByName("Image_mat")     -- 素材
    m_dojuBtn      = node:getChildByName("Image_mat_dj")   -- 道具
    local  close   = node:getChildByName("Button_close")
    local btnForge = node:getChildByName("Image_forge")
    local btnExchange = node:getChildByName("Image_Exchange")
    local btnReforge = node:getChildByName("Image_Reforge")
    local function btnCallBack( sender,eventType)
        if eventType == ccui.TouchEventType.ended     then
            if sender:getName() == "Image_mat"        then
                self.BagIndex = 1 
                self:switchBtnIamg()
                self:refsList()
            elseif sender:getName() == "Image_mat_dj" then
                self.BagIndex = 2
                self:switchBtnIamg()
                self:refsList()
            elseif sender:getName() == "Button_close" then
                self:returnBack()
            elseif sender:getName() == "Image_forge"  then
                self:callForge()
            elseif sender:getName() == "Image_Exchange" then
                self:callExchange()
            elseif sender:getName() == "Image_Reforge" then
               self:callReforge()
            end
        end
    end
    m_matBtn:addTouchEventListener(btnCallBack)
    m_dojuBtn:addTouchEventListener(btnCallBack)
    close:addTouchEventListener(btnCallBack)
    close:setEffectType(3)
    btnForge:addTouchEventListener(btnCallBack)

    if g_channel_control.bagLayer_hideReforge  == true  then
        btnReforge:setVisible(false)
    else
        btnReforge:addTouchEventListener(btnCallBack)
    end
    if g_channel_control.bagLayer_hideExchange  == true  then
        btnExchange:setVisible(false)
    else
        btnExchange:addTouchEventListener(btnCallBack)
    end

end
-- 去往铸造
function BagLayer:callForge( ... )
    -- body
    
    --self.rData["back"] = "bag"
    local sData = {}
    sData["back"] = "bag"
    SceneManager:toECastingLayer(sData)--self.rData
    self:beforeReturnBack()

end

-- 去往兑换
function BagLayer:callExchange( ... )
    -- body
    
    --self.rData["back"] = "bag"
    local sData = {}
    sData["back"] = "bag"
    SceneManager:toExchangeLayer(sData)--self.rData
    self:beforeReturnBack()

end

-- 去往轮回重铸
function BagLayer:callReforge( ... )
    -- body
    
    --self.rData["back"] = "bag"
    local sData = {}
    sData["back"] = "bag"
    SceneManager:toReforgeLayer(sData)--self.rData
    self:beforeReturnBack()

end

function BagLayer:beforeReturnBack()
    -- body
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    SceneManager:removeFromNavNodes(self)
    self.sData = {}
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clear()
    self:clearData()
end

function BagLayer:returnBack( ... )
    -- body
    self:beforeReturnBack()
    SceneManager:toStartLayer()
end
-- 数据解析错误的时候调用
function BagLayer:returnBack1( ... )
    -- body
    self:beforeReturnBack()
    SceneManager:toStartLayer()
end
function BagLayer:switchBtnIamg(  ) -- 根据选择来更换显示的Image  素材 道具
    -- body
    if self.BagIndex == 1 then
        m_matBtn:loadTexture("res/uifile/n_UIShare/Global_UI/btn/bbjm_ui_001.png")
        m_dojuBtn:loadTexture("res/uifile/n_UIShare/Global_UI/btn/bbjm_ui_002.png")
        m_matBtn:getChildByName("Text_5"):setColor(cc.c3b(255,246,185)) 
        m_dojuBtn:getChildByName("Text_5"):setColor(cc.c3b(255,255,255)) 
    elseif self.BagIndex == 2 then
        m_matBtn:loadTexture("res/uifile/n_UIShare/Global_UI/btn/bbjm_ui_002.png")
        m_dojuBtn:loadTexture("res/uifile/n_UIShare/Global_UI/btn/bbjm_ui_001.png")
        m_dojuBtn:getChildByName("Text_5"):setColor(cc.c3b(255,246,185)) 
        m_matBtn:getChildByName("Text_5"):setColor(cc.c3b(255,255,255)) 
    end
end
function BagLayer:initModel( ... )   -- 初始化模板
    -- body
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("BagItemNode.csb")
    local  item_1 = list_item:getChildByName("Panel_1")

    for i=1,6 do
        local item_c = item_1:clone()
        item_c:setPosition(((i-1)*(152+22)+18),0)
        local touchItem = ccui.Helper:seekWidgetByName(item_c,"Image_1")
        item_c:setName("item"..i)
        layout_list:addChild(item_c)
    end
    layout_list:setContentSize(1060,155)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)
end

function BagLayer:SortMat(dataSet)
    for i = 1,#dataSet do
        local id = getMatID(dataSet[i]["id"])
        if id then
            local order = mat[id]["order"]
            if order then
                dataSet[i]["order"] = order
            end
        end
    end
    local sort_order = nil
    local sort_id = nil
    
    local compFuncAs = nil
    local compFuncDes = nil
    compFuncAs = function(a,b) return a < b end
    compFuncDes = function(a,b) return a > b end
    sort_order = function (item) return item["order"] end
    if sort_order == nil then
      return
    end
    sort_id = function (item) return getMatID(item["id"]) end
    if sort_id == nil then
      return
    end
    --
    table.sort(dataSet,function(x,y)
        if sort_order(x) ~= sort_order(y) then
            return compFuncAs(sort_order(x),sort_order(y))
        else
            return compFuncDes(sort_id(x),sort_id(y))
        end
    end)
end
function BagLayer:refsList( ... )
    -- body
    if self.exist == false then
        return
    end
    if self.TabList == nil then
        return
    end
    self.ListView:removeAllChildren()
    local iTable   = nil
    if self.BagIndex == 1 then -- 素材
        iTable   = self.TabList["mat"]
        self:SortMat(iTable)
    elseif self.BagIndex == 2 then -- 道具
        iTable   = self.TabList["useprop"]
    end

    local len      = #iTable
    --
    local laoutLen = math.ceil(len / 6 )
    self.ListView:setInnerContainerSize(cc.size(self.ListView:getContentSize().width,LIST_ITEM_H*laoutLen))
    
    print("lenlenlenlen =="..len)
    print("laoutLen laoutLen =="..len)
    for i = 1,laoutLen do
        self.ListView:pushBackDefaultItem()
    end
    for i = 1 , laoutLen do
        for m = 1,6 do
            local item = self.ListView:getItem(i - 1)
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)*2 +m

            local itme_info = item:getChildByName("item"..m)
            local e_bg    = itme_info:getChildByName("Image_bg")
            local e_fr    = itme_info:getChildByName("Image_form")
            local e_icon  = itme_info:getChildByName("Image_icon")
            local tex_num = itme_info:getChildByName("Text_1")
            local num     = (i-1)*6+m
            --numIndex = num

            local prop    = {}
            if num > len then
                itme_info:setVisible(false)
            else 
                -- print("mat_id_num  888 == "..iTable[num]["id"])
            local mat_id_num = getMatID(iTable[num]["id"])
            print("mat_id_num == "..mat_id_num)
            local listTab = {}
            if self.BagIndex == 1 then
                listTab = mat
            elseif self.BagIndex == 2 then
                listTab = useprop
            end
            local dtable = {
                ["type"]     = listTab[mat_id_num]["item_type"],
                ["itemId"]   = mat_id_num,
                ["num"]      = iTable[num]["num"],
                ["sell_type"]= listTab[mat_id_num]["sell_type"],
                ["desc"]     = UITool.getUserLanguage(listTab[mat_id_num]["desc"]),
                ["sell_num"] = listTab[mat_id_num]["sell_num"],
                ["icon"]     = listTab[mat_id_num]["icon"],
                ["name"]     = UITool.getUserLanguage(listTab[mat_id_num]["name"]),
                
            }
                if self.BagIndex == 1 then
                    --fileName = "icons/mat/"..mat[mat_id_num]["icon"]
                    prop = UITool.getItemInfos(5,dtable["itemId"])
                end
                if self.BagIndex == 2 then
                    --fileName = "icons/mat/"..useprop[mat_id_num]["icon"]
                    prop = UITool.getItemInfos(6,dtable["itemId"])
                end
                local Texnum  = itme_info:getChildByName("Text_1")
                Texnum:setString("X"..iTable[num]["num"])
                local curBuyNum = 0;
                e_bg:loadTexture(prop[4])
                e_fr:loadTexture(prop[1])
                e_icon:loadTexture(prop[2])
                local function callBack( sender,eventType )
                    -- body
                    if eventType == ccui.TouchEventType.ended then
                       if self.BagIndex == 1 then
                           local function senderSell( inum)
                                -- body
                                local function reiceSthCallBack(data)
                                    print("获取登陆奖励列表")
                                    data = tolua.cast(data, "PassData");
                                    print("callBack-----"..data:getData())
 				    if self.sManager ~= nil then
             				self.sManager:delWaitLayer()
         			    end
                                    if self.exist == false then
                                        return
                                    end
                                    local cjsonSafe = require "cjson.safe"
                                    local t_data = cjsonSafe.decode(data:getData())
                                    if t_data == nil then 
                                        MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
                                        --todo 处理错误数据页面跳转逻辑
                                        return
                                    end 
                                    if  t_data["data"]["state_code"] ~=1 then
            
                                         MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
                                        return
                                    end   
                                    if t_data["data"]["state_code"]  == 1 then
                                        user_info["gold"] = t_data["data"]["resource"]["gold"]
                                        user_info["gem"] = t_data["data"]["resource"]["gem"]
                                        user_info["gem_r"] = t_data["data"]["resource"]["gem_r"]
                                        if self.BagIndex == 1 then
                                            --self:rsfBagMat()
                                            
                                            print("self.testId == "..self.testId)
                                            print("self. mat num == "..inum)
                                            self.TabList["mat"][num]["num"] = self.TabList["mat"][num]["num"] - inum
                                            print("回掉函数里面的数量 == "..self.TabList["mat"][num]["num"])
                                            self:rMat()
                                            self:refsList()
                                        elseif self.BagIndex == 2 then
                                            self.TabList["useprop"][num]["num"] = self.TabList["useprop"][num]["num"] - inum
                                           -- self:rsfBagUseprop()
                                            self:rUsp()
                                            self:refsList()
                                        end
                                    end
                                end
                                local cjson = require "cjson"
                                local tempTable = {
                                    ["rpc"]       = "item_sell",
                                    ["item_id"]   = self.testId, 
                                    ["item_num"]  = inum,
                                }
                                print("BagLayer.testId == "..self.testId)
                                print("BagLayer.tsetNum == "..num)
                                local mydata =  cjson.encode(tempTable)
                                print("测试  奖励列表 mydata = "..mydata)
                                self.sManager:createWaitLayer()
                                local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
                                ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
                                dbhttp:creatHttpRequestWithURL(mydata,3)
                            end
                            --print(dtable["type"],dtable["sell_type"],"wwwwwwwwwww==>")
                            self.testId  = "mat_"..mat_id_num
                            print("mat_id_num "..self.testId)
                            MsgManager:sellItemsInfo(5,dtable["itemId"],dtable["type"],dtable["sell_num"],dtable["num"],self,senderSell,dtable["sell_num"],dtable["num"],dtable["sell_type"])
                       elseif self.BagIndex == 2 then
                            local function senderUser( ... )
                            -- body
                            end
                            -- local function useItemCallBack(num,oneself)
                            --     MsgManager:showBagModelItem(6,dtable["itemId"],num,oneself,nil)
                            -- end
                            self.testId  = "useprop_"..mat_id_num   
                           -- local icon   = "icons/mat/"..dtable["icon"]             
                              --print(dtable["type"],dtable["sell_type"],"wwwwwwwwwww==>") 
                              --MsgManager:useItemsInfo(6,dtable["itemId"],self,useItemCallBack,1)
                              --MsgManager:showBagModelItem(6,dtable["itemId"],0,self,nil)--,icon,dtable["desc"],dtable["name"]
                             -- ( item_type,item_id,item_num,oneSelf,callfunc,img,dec,name)
                           MsgManager:showBagModelItem(6,dtable["itemId"],dtable["num"],self,senderUser)
                       end
                    end
                end
                e_fr:addTouchEventListener(callBack)
            end
        end
    end
end


-- 转化素材
function BagLayer:rsfBagMat( ... )
  -- body
    local temp_list = {}
    local index = 1
    if self.TabList["mat"] ~= nil then
      for k,v in pairs(self.TabList["mat"]) do
       -- print("vvvvvv == "..v)
        if v ~= 0 then
          temp_list[index] = {}
          temp_list[index]["num"] = v
          if temp_list[index]["num"]~= 0 then 
            temp_list[index]["id"] = tostring(k) 
            temp_list[index]["num"] = v
            print("mat  id id == "..temp_list[index]["id"])
            print("mat  num mun == "..temp_list[index]["num"])
            index = index +1
          end
        end
      end
    end
   self.TabList["mat"] = {}
   self.TabList["mat"] = table.deepcopy(temp_list)
   print("bag_mat len == "..#self.TabList["mat"])
end
-- 刷新素材
function BagLayer:rMat( ... )
    -- body
    local temp_list = {}
    local index = 1
    for i = 1 , #self.TabList["mat"] do
        if self.TabList["mat"][i]["num"] ~= 0 then
            temp_list[index] = {}
             print("素材的数量 == "..self.TabList["mat"][i]["num"] )
            temp_list[index] = self.TabList["mat"][i]
            index = index +1
        end
    end
   self.TabList["mat"] = {}
   self.TabList["mat"] = table.deepcopy(temp_list)
   print("bag_mat len == "..#self.TabList["mat"])
end
-- 刷新道具
-- 刷新
function BagLayer:rUsp( ... )
    -- body
    local temp_list = {}
    local index = 1
    for i = 1 , #self.TabList["useprop"] do   
        if self.TabList["useprop"][i]["num"] ~= 0 then
            temp_list[index] = {}
            temp_list[index] = self.TabList["useprop"][i]
            index = index +1
        end
    end
   self.TabList["useprop"] = {}
   self.TabList["useprop"] = table.deepcopy(temp_list)
   print("bag_mat len == "..#self.TabList["useprop"])
end
-- 转化使用道具
function BagLayer:rsfBagUseprop( ... )
  -- body
   local temp_list = {}
   local index = 1
   if self.TabList["useprop"]~= nil then
   for k,v in pairs(self.TabList["useprop"]) do
      if v ~= 0 then
        temp_list[index] = {}
        temp_list[index]["num"] = v
        if temp_list[index]["num"]~=0 then 
          print("kkkkk == "..k)
          print("vvvv == "..v)
          temp_list[index]["id"] = tostring(k) 
          temp_list[index]["num"] = v
          index = index +1
        end
      end
   end
   end
   self.TabList["useprop"] = {}
   self.TabList["useprop"] = table.deepcopy(temp_list)
end
function BagLayer:create(rData)
    local login = BagLayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end
--清理数据
function BagLayer:clearData()
    self.sManager = nil
    self.backFunc = nil
    self.sDelegate = nil
    self.ListView = nil 
    self.TabList = nil
    self.BagIndex = nil
    self.TabList = nil
end


