--摆pose状态。目前只有尤娜用到了。
--created by kobejaw.2018.3.29.
State_Posing = class("State_Posing",StateBase)

function State_Posing:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.Posing
end

function State_Posing:Enter(animationName)
	if self.entity.isDead then
		return
	end
	
	self.entity.spineNode:setToSetupPose()
	self.entity.spineNode:setAnimation(0,animationName,false)
end

function State_Posing:onSpineCompleteCallback(event)
	if self.entity.isBoss then
		self.entity.fsm:changeState(StateEnum.Attacking_Boss)
	else
		--摆完pose。切换到RunningToEnemy状态
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)		
	end
end

function State_Posing:Exit()
	self.super.Exit(self)
end