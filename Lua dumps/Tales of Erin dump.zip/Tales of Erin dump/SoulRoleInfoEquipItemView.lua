--require "XUIView"

SoulRoleInfoEquipItemView = class("SoulRoleInfoEquipItemView", XUIView)

SoulRoleInfoEquipItemView.CS_FILE_NAME = "SoulRoleInfoEquipItemView.csb"
SoulRoleInfoEquipItemView.CS_BIND_TABLE = 
{
    panelBlocked = "/i:709",
    panelBlocked_img3 = "/i:709/i:710",
    panelNoOpen = "/i:3070",
    panelNoOpen_img3 = "/i:3070/i:3071",
    panelInfo = "/i:657",
    panelSkill = "/i:679",
    panelTouch = "/i:598",

    lbName = "/i:657/i:665",
    lbLevel = "/i:657/i:706",
    lbHP = "/i:657/i:707",
    lbAtk = "/i:657/i:708",
    
    imgBG = "/i:657/i:661/i:662",
    imgFace = "/i:657/i:661/i:659",
    imgRarity = "/i:657/i:661/i:663",

    Skill_1 = "/i:657/i:435",
    Skill_2 = "/i:657/i:436",
    Skill_3 = "/i:657/i:437",
    Skill_4 = "/i:657/i:438",
    Skill_5 = "/i:657/i:439",
    skill_icon1 = "/i:657/i:3438",
    skill_icon2 = "/i:657/i:3439",
    skill_icon3 = "/i:657/i:3440",
    skill_icon4 = "/i:657/i:3441",
    skill_icon5 = "/i:657/i:3442",
}

SoulRoleInfoEquipItemView.IconSmallPath = "icons/soulequip/list/"

function SoulRoleInfoEquipItemView:init(rootNode,nSeId)
    SoulRoleInfoEquipItemView.super.init(self,rootNode)

    self.panelInfo:setVisible(false)
    self.panelBlocked:setVisible(false)
    self.panelNoOpen:setVisible(true)

    self.lbAtk:setString("")
    self.lbHP:setString("")
    self.lbLevel:setString("")
    self.lbName:setString("")
    for i=1,5 do
        self["skill_icon"..i]:setVisible(false)
    end

    if nSeId then
        self.curSoulEquipId = tonumber(getNumID(nSeId))
    end
    --根据魂灵装ID取本地数据
    print("SoulRoleInfoEquipItemView:init curSoulEquipId:"..self.curSoulEquipId)
    if hero_soul[self.curSoulEquipId] then
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
    end

    --self:RefreshInfo()

    return self
end

function SoulRoleInfoEquipItemView:FillSoulEquipInfo(rcvData)
    -- body
    if rcvData then
        self.Se_data = table.deepcopy(rcvData)
        self:RefreshInfo()
    end
end

-- "soul":{
--                 "Lv":1,
--                 "atk":50,
--                 "hp":108,
--                 "exp":0,
--                 "exp_max":100,
--                 "add_atk":0,
--                 "break_count":0,
--                 "state":1,
--                 "skills":{

--                 },
--                 "Lv_max":50,
--                 "add_hp":0
--             },
function SoulRoleInfoEquipItemView:RefreshInfo()
    if not self.Se_data then
        return
    end

    self.curSoulEquipId = tonumber(getNumID(self.Se_data.id))

    if hero_soul[self.curSoulEquipId] then
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
    end
    
    if not self.hero_soul_info then
        return
    end

    local SoulEq_Data = self.Se_data.soul

    if not self.Se_data["soul"] then
        return
    end

    if SoulEq_Data.state == 3 then
        --魂灵装解锁
        self.panelInfo:setVisible(true)
        self.panelNoOpen:setVisible(false)
        self.panelBlocked:setVisible(false)

        local nAtk = SoulEq_Data["atk"] + SoulEq_Data["add_atk"]
        local nHp = SoulEq_Data["hp"] + SoulEq_Data["add_hp"]

        if SoulEq_Data["ex_atk"] ~= nil and SoulEq_Data["ex_atk"] > 0 then
            nAtk = nAtk + SoulEq_Data["ex_atk"]
            nHp = nHp + SoulEq_Data["ex_hp"]
        end
        -- local nAtk = SoulEq_Data["atk"] + SoulEq_Data["add_atk"] + SoulEq_Data["ex_atk"]
        -- local nHp = SoulEq_Data["hp"] + SoulEq_Data["add_hp"] + SoulEq_Data["ex_hp"]
        self.lbAtk:setString(nAtk)
        self.lbHP:setString(nHp)

        -- self.lbAtk:setString(SoulEq_Data["atk"])
        -- self.lbHP:setString(SoulEq_Data["hp"])
        self.lbLevel:setString(UITool.ToLocalization("等级 ")..SoulEq_Data["Lv"])

        --魂灵装名称
        local seName = UITool.getUserLanguage(self.hero_soul_info.name)
        if seName then
            self.lbName:setString(seName)
        end
        --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
        local face = self.hero_soul_info["soul_break"]["break_1"].icon_small
        if face then
            self.imgFace:setTexture(self.IconSmallPath..face)
        end
        --魂灵装技能
        -- SoulEq_Data["skills"][1] = 6013001
        -- SoulEq_Data["skills"][2] = 6013002
        -- SoulEq_Data["skills"][3] = 6013003

        for i=1,5 do
            self["skill_icon"..i]:setVisible(false)
        end

        local len = #SoulEq_Data["skills"]
        if len > 0 then
            for i=1,len do
                if SoulEq_Data["skills"][i] then
                    local node = SESkillIconView.new():init(self["skill_icon"..i],SoulEq_Data["skills"][i])
                    self["skill_icon"..i]:setVisible(true)
                end
            end
        else
            print("SoulRoleInfoEquipItemView Has No Skill!!!")
        end
    elseif SoulEq_Data.state == 2 then
        --预留：魂灵装解锁动画阶段（目前无）
    elseif SoulEq_Data.state == 1 then
        --魂灵装开放未解锁
        self.panelInfo:setVisible(false)
        self.panelNoOpen:setVisible(false)
        self.panelBlocked:setVisible(true)

        self.lbAtk:setString("")
        self.lbHP:setString("")
        self.lbLevel:setString("")
        self.lbName:setString("")
        for i=1,5 do
            self["skill_icon"..i]:setVisible(false)
        end
    else
        --专属剧情未解锁或未开放
        self.panelInfo:setVisible(false)
        self.panelNoOpen:setVisible(true)
        self.panelBlocked:setVisible(false)

        self.lbAtk:setString("")
        self.lbHP:setString("")
        self.lbLevel:setString("")
        self.lbName:setString("")
        for i=1,5 do
            self["skill_icon"..i]:setVisible(false)
        end
    end
end