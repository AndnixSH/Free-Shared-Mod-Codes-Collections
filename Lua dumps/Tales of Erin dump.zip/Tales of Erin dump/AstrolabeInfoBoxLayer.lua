--require "XUIView"
--星盘加点二次弹窗
AstrolabeInfoBoxLayer = class("AstrolabeInfoBoxLayer",XUIView)
AstrolabeInfoBoxLayer.CS_FILE_NAME = "AstrolabeInfoBoxLayer.csb"
AstrolabeInfoBoxLayer.CS_BIND_TABLE = 
{ 
    panle     = "/s:Panel_lockBox_1",
    imgBg     = "/s:Panel_lockBox_1/s:Image_bg",
    --图标
    icon      = "/s:Panel_lockBox_1/s:Image_bg/s:Image_icon",
    --技能名称
    skName    = "/s:Panel_lockBox_1/s:Image_bg/s:Text_name",
    --当前加点数量
    num       = "/s:Panel_lockBox_1/s:Image_bg/s:Text_num",
    --解锁条件
    textLock  = "/s:Panel_lockBox_1/s:Image_bg/s:Text_des_1",
    --所需点数
    textPoint = "/s:Panel_lockBox_1/s:Image_bg/s:Text_point",
    --前置属性
    textLockDes = "/s:Panel_lockBox_1/s:Image_bg/s:Text_des_lock_0",
    --上一等级描述
    upLvDec   = "/s:Panel_lockBox_1/s:Image_bg/s:Text_des_2",
    --下一等级描述
    nextLvDec = "/s:Panel_lockBox_1/s:Image_bg/s:Text_des_3",
    --选择升级 显示
    curSelect    = "/s:Panel_lockBox_1/s:Image_bg/s:Text_num_0",
    --左
    leftBtn      = "/s:Panel_lockBox_1/s:Image_bg/s:Button_left",
    --右
    rightBtn     = "/s:Panel_lockBox_1/s:Image_bg/s:Button_right",

    cancleBtn  = "/s:Panel_lockBox_1/s:Image_bg/s:Button_cancle",
    confrimBtn = "/s:Panel_lockBox_1/s:Image_bg/s:Button_confirm",
}

function AstrolabeInfoBoxLayer:init()
    AstrolabeInfoBoxLayer.super.init(self)

    self.leftBtn:addClickEventListener(function()
        self:setMatCount(-1)
    end)
    self.rightBtn:addClickEventListener(function()
        self:setMatCount(1)
    end)
    self.cancleBtn:setEffectType(3)
    self.cancleBtn:addClickEventListener(function()
        self:returnBack()
    end)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end
--获得或与与的条件是否双向达成
function AstrolabeInfoBoxLayer:getOrAndBool(curOnlyT,_id)   
    --或的前置解锁条件
    local orTable  = curOnlyT["star_unlock_tree"]
    local orLen    = #orTable
    --本地数据 自身解锁需要达成的条件
    local andTabel = curOnlyT["star_unlock"]
    local onlySvLv =  self.baseSelf.serverData["stars"][tostring(_id)]    
    local isTrue   =  self.baseSelf:andTrue(andTabel)
    -- 如果orLen等于零代表不需要前置解锁条件(需要根据自身等级显示图片)
    print("orLen orLen == "..orLen)
    if orLen == 0 then
        if isTrue then
            --大于零是解锁升级过
            if onlySvLv > 0 then
                return true
            else
                return true
            end
        else
            return false
        end
    end
    --需要前置解锁条件的
    -- 循环取出前置的解锁条件
    -- 跟服务器对比前置条件是否达成 前置是或的关系达成
    local isBool = false
    for i = 1 , orLen do

        local c_id    = orTable[i]["star_id"]
        local c_lv    = orTable[i]["star_lv"]
        local c_svLv  = self.baseSelf.serverData["stars"][tostring(c_id)] 
        --[[
            从本地表中读取前置解锁条件表，进行服务器数据对比，是否达成条件
            达成条件在进行与的比较 andTrue
        ]]
        -- 或的关心有一个问题达成就返回 true
        if c_svLv >= c_lv then
            if isTrue then
                -- --大于零是解锁升级过(是根据自身等级显示自己状态图)
                -- if onlySvLv > 0 then
                --     return true

                -- else
                --     return true
                -- end
                isBool = true
            --else
                --没有解锁
             --   return false
            end
        --else
                --return false
        end
    end 
    return isBool
end
--前置条件是否达成
function AstrolabeInfoBoxLayer:getOrBool(curOnlyT,_id)   
    --或的前置解锁条件
    local orTable  = curOnlyT["star_unlock_tree"]
    local orLen    = #orTable
    local onlySvLv =  self.baseSelf.serverData["stars"][tostring(_id)]    
    -- 如果orLen等于零代表不需要前置解锁条件(需要根据自身等级显示图片)
    print("orLen orLen == "..orLen)
    if orLen == 0 then
            return true
    end
    --需要前置解锁条件的
    -- 循环取出前置的解锁条件
    -- 跟服务器对比前置条件是否达成 前置是或的关系达成
    -- 因为是或的关系 又个达成就可以
    local isBool = false
    for i = 1 , orLen do
        local c_id    = orTable[i]["star_id"]
        local c_lv    = orTable[i]["star_lv"]
        local c_svLv  = self.baseSelf.serverData["stars"][tostring(c_id)] 
        if c_svLv >= c_lv then
             isBool = true
        --else
          --  return false
        end
    end 
    return isBool
end
function AstrolabeInfoBoxLayer:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end
--变动的属性
function AstrolabeInfoBoxLayer:changePer()
        --显示下一级的描述
        local nexLv    = self.addLv --+ 1
        if nexLv >= self.skillTable["max_lv"] then
            nexLv = self.skillTable["max_lv"]
        end
        --下一等级的描述
        local decNum      = nexLv*self.skillTable["prop_num"]
        local nextstr2 = string.format(UITool.getUserLanguage(self.skillTable["desc"]), decNum)
        self.nextLvDec:setString(nextstr2)

        --上一等级的描述
        local curNum      = self.lv_count*self.skillTable["prop_num"]
        local curstr2 = string.format(UITool.getUserLanguage(self.skillTable["desc"]), curNum)
        self.upLvDec:setString(curstr2)

        --显示变动的等级和最大等级
        self.curSelect:setString(""..self.addLv.."/"..self.skillTable["max_lv"])
        --point:setColor(cc.c3b(0,255,0))
        self.textPoint:setString(self.skillTable["asp_cost"]*(self.addLv - self.lv_count))
        if g_channel_control.transform_AstrolabeInfoBoxLayer_textPoint_pos == true then 
            self.textPoint:setPosition(151,112)    
        end 
        --解锁前置条件 根据是否达成显示颜色
        local isOk = self:getOrBool(self.curOnlyT,self.id)
        if isOk then
            self.textLockDes:setColor(cc.c3b(184, 184, 184))
        else
            self.textLockDes:setColor(cc.c3b(255, 0, 0))
        end
        --与和或的条件
        local orAndB = self:getOrAndBool(self.curOnlyT,self.id)
        if self.skillTable["asp_cost"]*(self.addLv - self.lv_count) > self.baseSelf.rcvData["astrolabe"]["asp_left"] then
            self.textPoint:setColor(cc.c3b(255,0,0))
            self.confrimBtn:setTouchEnabled(false)
            self.confrimBtn:setBright(false)
      
        else
          
            self.textPoint:setColor(cc.c3b(0,255,0))
            if orAndB then
                self.confrimBtn:setTouchEnabled(true)
                self.confrimBtn:setBright(true)
            else
                self.confrimBtn:setTouchEnabled(false)
                self.confrimBtn:setBright(false)
            end
            
        end
 


end
function AstrolabeInfoBoxLayer:setMatCount(offect)
    self.addLv = self.addLv + offect
    local ll = false
    local lr = false

    if self.addLv <= self.conLv then
        self.addLv = self.conLv
        ll = true
    end

    if  self.addLv >= self.skillTable["max_lv"] then
        self.addLv = self.skillTable["max_lv"]
        lr = true
    end


    self.leftBtn:setTouchEnabled(not ll)
    self.leftBtn:setBright(not ll)
    self.rightBtn:setTouchEnabled(not lr)
    self.rightBtn:setBright(not lr)
    self:changePer()
   -- self.numMat:setString(""..self.lv_count)
end

function AstrolabeInfoBoxLayer:loadData(imageChild,baseSelf,Pself,hero_id)
    local name = imageChild:getName()
    self.baseSelf = baseSelf
    self.Pself    = Pself
    self.hero_sub_id = getNumID(hero_id)
    --新盘self.id
    self.id   = tonumber(UITool.SubStringToInt( name,"_",2))
    --本地数据
    self.curOnlyT  = self.baseSelf:getOnlyData(self.id)
    --技能表
    self.skillTable = astrolabe_skill[self.hero_sub_id][self.curOnlyT["star_sk_id"]]
    
    self.skillId    = tonumber(self.curOnlyT["star_id"])
    --图标
    self.icon:loadTexture(self.skillTable["icon_checked"])

    --技能名称
    self.skName:setString(UITool.getUserLanguage(self.skillTable["name"]))

    --显示自己的加点
    local svLv  = self.baseSelf.serverData["stars"][tostring(self.id)]
    self.num:setString("【"..svLv.."/"..self.skillTable["max_lv"].."】")

    --解锁前置条件
    local strTable  = self.Pself:AsbLockStr(self.curOnlyT["star_unlock"])
    local allStr    = ""
    for i = 1, #strTable do
        allStr = allStr..strTable[i]["str"].." "    
    end
    self.textLock:setString(allStr)

    --初始自己的加点状态
    self.lv_count = svLv
    --初始化等级自己
    self.addLv    = self.lv_count + 1
    self.conLv    = self.lv_count + 1
    self:setMatCount(0)



end


