--[[
  屏幕适配 单例类
  iphoneX 分辨率 2436 x 1152 rate = 2.165 相当于 1559 *720

  蒙版大小 1600 x 960 位置 640 x 360

]]
--屏幕设计宽度
g_designWidth = 1280;
--屏幕设计高度
g_designHeight = 720;

g_minScreenRate = 1.77;

g_maxScreenRate = 2.2;

ScreenManager = class("ScreenManager")


--[[
=============================================
  public start
============================================
]]

function ScreenManager:getInstance(  )
  if self.instance == nil  then
    self.instance = ScreenManager:new()
    self:init()
  end
  return self.instance
end

function ScreenManager:autoFit()
  self:showParam();
  local director = cc.Director:getInstance()
  local glview = director:getOpenGLView()
  if glview == nil then
    print("ScreenManager: autoFit glview should not nil")
    return;
  end
  -- if true then
  --   glview:setDesignResolutionSize(g_designWidth, g_designHeight, cc.ResolutionPolicy.SHOW_ALL)
  --   return;
  -- end
  --glview:setDesignResolutionSize(g_designWidth, g_designHeight, cc.ResolutionPolicy.SHOW_ALL)
  --glview:setDesignResolutionSize(g_designWidth, g_designHeight, cc.ResolutionPolicy.FIXED_WIDTH)
  -- glview:setDesignResolutionSize(1559, 720, cc.ResolutionPolicy.FIXED_WIDTH)
  -- self:showParam();


  local designWidth = g_designWidth;
  local designHeight = g_designHeight;

  print("ScreenManager: g_designWidth = ", designWidth, ", g_designHeight = ", designHeight);
  --屏幕设计比率
  local designRate = designWidth/designHeight;
  print("ScreenManager: designRate = ", designRate);
  --屏幕可见大小
  local visibleSize =  cc.Director:getInstance():getVisibleSize();
  print("ScreenManager: visibleSize width = ", visibleSize.width, ", height = ", visibleSize.height)
  --屏幕可见比率
  local visibleRate = visibleSize.width/visibleSize.height;
  print("ScreenManager: visibleRate = ", visibleRate);
  if visibleRate > g_maxScreenRate then
    print("ScreenManager: visibleRate > g_maxScreenRate， DesignResolution = SHOW_ALL");
    glview:setDesignResolutionSize(designWidth, designHeight, cc.ResolutionPolicy.SHOW_ALL)
  elseif visibleRate > designRate then
    print("ScreenManager: visibleRate > designRate DesignResolution = FIXED_HEIGHT");
    glview:setDesignResolutionSize(designWidth, designHeight, cc.ResolutionPolicy.FIXED_HEIGHT)
  elseif visibleRate > g_minScreenRate then
    print("ScreenManager: visibleRate > g_minScreenRate DesignResolution = FIXED_WIDTH");
    glview:setDesignResolutionSize(designWidth, designHeight, cc.ResolutionPolicy.FIXED_WIDTH)
  else
    print("ScreenManager: visibleRate < g_minScreenRate DesignResolution = SHOW_ALL");
    glview:setDesignResolutionSize(designWidth, designHeight, cc.ResolutionPolicy.SHOW_ALL)
  end



 
end

--获得 屏幕适配之后，ui在场景中的位置
function ScreenManager:getRootPoint( )
  -- body
  local visibleSize =  cc.Director:getInstance():getVisibleSize();
   local rootPoint = {}
  rootPoint.x = (visibleSize.width - g_designWidth)/2;
  rootPoint.y = (visibleSize.height - g_designHeight)/2;
  print("ScreenManager:getRootPoint x = ", rootPoint.x, ", y = ", rootPoint.y);
  return rootPoint
  --return { x = 0, y = 0}
end

function ScreenManager:getScreenScale()
 

  local visibleSize =  cc.Director:getInstance():getVisibleSize();
  local widthRate = visibleSize.width/g_designWidth;
  local heightRate = visibleSize.height/g_designHeight;
  return math.max(widthRate, heightRate);
  --return 1;
end



--[[
=============================================
  private start
============================================
]]

function ScreenManager:showParam( )
  -- body
  -- body
  local winSize = cc.Director:getInstance():getWinSize();
  print("ScreenManager:winSize:  width = ", winSize.width, ", height = ", winSize.height);

  local visibleSize =  cc.Director:getInstance():getVisibleSize();

  print("ScreenManager:visibleSize:  width = ", visibleSize.width, ", height = ", visibleSize.height)

  local originPoint = cc.Director:getInstance():getVisibleOrigin();

  print("ScreenManager:originPoint:  x = ", originPoint.x, ", y = ", originPoint.y)
end


function ScreenManager:init()
    print("ScreenManager:init");
    

end



