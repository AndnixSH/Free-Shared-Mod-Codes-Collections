--require "XUIView"

EquipInfoView = class("EquipInfoView",XUIView)
EquipInfoView.CS_FILE_NAME = "EquipInfoView.csb"
EquipInfoView.CS_BIND_TABLE = 
{
    -- tbText="/i:123/s:tbt",
    -- btnOK="/s:btnOK",
    btnClose="/i:227/i:92",
    
    equipBG = "/i:367/i:368/i:417",
    equipName = "/i:367/i:368/i:362",
    equipImage = "/i:367/i:368/i:7",
    equipElement = "/i:367/i:368/i:361",
    equipFrame = "/i:367/i:368/i:416",
    equipFrameImg = "/i:367/i:368/i:416/i:4161",
    equipNotGet = "/i:367/i:368/i:220",
    
    btnPrev = "/i:367/i:191",
    btnNext = "/i:367/i:190",

    awk1 = "/i:367/i:8/i:10",
    awk2 = "/i:367/i:8/i:11",
    awk3 = "/i:367/i:8/i:12",
    awk4 = "/i:367/i:8/i:13",
    -- awkNum = "/i:367/i:8/i:14",

    barAtk = "/i:367/i:8/i:15",
    barHP = "/i:367/i:8/i:16",
    numAtk = "/i:367/i:8/i:17",
    numHP = "/i:367/i:8/i:18",

    -- lbLv = "/i:367/i:8/i:347",
    lbCurMaxLv = "/i:367/i:8/i:348",
    lbExpNext = "/i:367/i:8/i:349",
    barExp = "/i:367/i:8/i:540",

    skillIcon_1 = "/i:367/i:8/i:350",
    skillName_1 = "/i:367/i:8/i:351",
    skillLevel_1 = "/i:367/i:8/i:352",
    skillDescPanel_1 = "/i:367/i:8/i:354",
    skillBtnRandom = "/i:367/i:8/i:186",

    skillIcon_2 = "/i:367/i:8/i:392/i:394",
    skillName_2 = "/i:367/i:8/i:392/i:395",
    skillLevel_2 = "/i:367/i:8/i:392/i:396",
    skillDescPanel_2 = "/i:367/i:8/i:392/i:397",
    skillNo_2 = "/i:367/i:8/i:392/i:398",
    
    btnRSK = "/i:367/i:8/i:186",

    skillPrsk1 = "/i:367/i:8/i:177",
    skillPrsk2 = "/i:367/i:8/i:180",

    -- btnAtlas1 = "/i:367/i:8/i:355", 
    -- btnAtlas2 = "/i:367/i:8/i:358",

    --强化融合突破 --所有者
    ownerText = "/i:367/i:368/s:ownerText",
    ownerFace = "/i:367/i:368/s:ownerFace",
    btnSth = "/i:367/i:8/s:btnSth",
    btnSkill = "/i:367/i:8/s:btnSkill",
    btnAwaken = "/i:367/i:8/s:btnAwaken",

    --灵装锁
    btnLock = "/i:367/i:89",
    btnUnlock = "/i:367/i:90",
}

function EquipInfoView:init(equip_id,other_ids,eb)
    EquipInfoView.super.init(self)
    self.eb = eb 
    self.equip_id = equip_id

    if other_ids then
        self.other_ids = other_ids
        if #self.other_ids <= 1 then
            self.btnPrev:setTouchEnabled(false)
            self.btnPrev:setBright(false)

            self.btnNext:setTouchEnabled(false)
            self.btnNext:setBright(false)
        else
            self.other_ids_index = 0
            for i = 1,#self.other_ids do
                if self.equip_id == self.other_ids[i] then
                    self.other_ids_index = i
                    break
                end
            end
        end
        self.btnPrev:addClickEventListener(function()
            self:switchEquip(-1)
        end)
        self.btnNext:addClickEventListener(function()
            self:switchEquip(1)
        end)
    else
        self.btnPrev:setVisible(false)
        self.btnNext:setVisible(false)
    end

    self.exist = true;
    self.equipEAtb = cc.CSLoader:createNode("EffElementAll.csb")    
    self.equipEAtb:setPosition(self.equipElement:getPosition())
    self.equipElement:getParent():addChild(self.equipEAtb,1)

    self.equipEAtbAct = cc.CSLoader:createTimeline("EffElementAll.csb")
    self.equipEAtb:runAction(self.equipEAtbAct)
    self.equipEAtbAct:play("reset",false)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    -- self.btnAtlas1:addClickEventListener(function()
    --     self:showAtlas(1)
    -- end)

    self.btnRSK:addClickEventListener(function()
        self:onBtnRsk()
    end)

    -- self.btnAtlas2:addClickEventListener(function()
    --     self:showAtlas(2)
    -- end)
    
    self.btnSkill:addClickEventListener(function()
        self:showEquipSkill()
    end)
    self.btnSth:addClickEventListener(function()
        self:showEquipSth()
    end)
    self.btnAwaken:addClickEventListener(function()
        self:showEquipAwaken()
    end)

    self.btnLock:addClickEventListener(function()
        self:lockEquip()
    end)
    self.btnUnlock:addClickEventListener(function()
        self:lockEquip()
    end)

    self:refreshStaticState()
    self:refresh()
    
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end

function EquipInfoView:loadInfo()
    if not self.equip_id then return end

    local eq_num_id = getNumID( self.equip_id )
    local time_id = getTimeNumID( self.equip_id )

    if time_id > 10 then
        GameManagerInst:rpc( 
            {
                rpc = "eq_info",
                eq_id = self.equip_id
            },
            3,
            function(data)
                --success
                if self.exist == false then
                    return
                end
                self.equip_data = data["eq"][self.equip_id]
                self:refresh()
            end,
            function(state_code,msgText)
                --failed
                if self.exist == false then
                    return
                end
                GameManagerInst:alert(msgText,function()
                    self:returnBack()
                end)
            end,
            true)
    else
        local lv_infos = equip_upgrade[eq_num_id]
        local lv_info = lv_infos[#lv_infos]
        self.equip_data = {
            Lv = 100,
            sk = {
                Lv = 10,
                next_add_atk = 0,
                provide_sk_exp = 0,
                add_atk_rate = {},
                Lv_max = 10,
                up_need_exp = 0
            },
            fp = 1000,
            atk = lv_info[3],
            element = 4,
            rarity = 4,
            owner = "0",
            is_lock = false,
            exp_max = 101,
            brk_num = 4,
            sell = 0,
            rsk = {
                {
                    -1,
                    0
                },
                {
                    -1,
                    0
                }
            },
            sk_two = {
            provide_sk_id = equip[eq_num_id]["passive_sk_list"][5],
            Lv = 5,
            },
            exp= 0,
            Lv_max= 100,
            hp= lv_info[2]
        }
        self:refresh()
    end
end

function EquipInfoView:switchEquip(offect)

    self.other_ids_index = self.other_ids_index + offect
    if self.other_ids_index < 1 then
        self.other_ids_index = #self.other_ids
    elseif self.other_ids_index > #self.other_ids then
        self.other_ids_index = 1
    end

    self.equip_id = self.other_ids[self.other_ids_index]
    self.equip_data = nil

    self:refreshStaticState()
    self:refresh()
    
    self:loadInfo()
end

function EquipInfoView:refreshStaticState()
--
    if self.equipRankAnime then
        self.equipRankAnime:removeFromParent()
        self.equipRankAnime = nil
    end

    -- if not self.equip_id then
    --     self.btnAtlas1:setVisible(false)
    --     self.btnAtlas2:setVisible(false)
    --     return
    -- end

    local e_id_num = getNumID(self.equip_id)
    local time_id = getTimeNumID( self.equip_id )

    local img_color = cc.c3b(255,255,255)

    if time_id > 10 then
        --已拥有
        self.equipNotGet:setVisible(false)
    else
        --图鉴
        if time_id == 0 then
            self.equipNotGet:setVisible(true)
            img_color = cc.c3b(0,0,0)
        else
            self.equipNotGet:setVisible(false)
        end
    end

    self.equipName:setString(UITool.getUserLanguage(equip[e_id_num].equip_name))--(equip[e_id_num].equip_name)
    self.equipImage:setTexture(equip[e_id_num].equip_vdw_icon)
    self.equipImage:setColor(img_color)

    local efsize = self.equipFrame:getSize()
    self.equipRankAnime = cc.CSLoader:createNode(RANK_ACG[equip[e_id_num].equip_rank])
    self.equipRankAnime:setPosition(cc.p(efsize.width / 2 , efsize.height / 2))
    self.equipFrame:addChild(self.equipRankAnime)
    local frameact = cc.CSLoader:createTimeline(RANK_ACG[equip[e_id_num].equip_rank])
    self.equipRankAnime:runAction(frameact)
    frameact:play("animation0",true)

    local erank = equip[e_id_num].equip_rank
    local frameimg = nil
    local framebg = nil
    if erank == 5 then
        frameimg = "n_UIShare/equip/info/zbxy_ui_001.png"
        framebg = "n_UIShare/equip/info/xqzx_bg_002_1.png"
    elseif erank == 4 then
        frameimg = "n_UIShare/equip/info/zbxy_ui_002.png"
        framebg = "n_UIShare/equip/info/xqzx_bg_002_2.png"
    elseif erank == 3 then
        frameimg = "n_UIShare/equip/info/zbxy_ui_003.png"
        framebg = "n_UIShare/equip/info/xqzx_bg_002_3.png"
    else 
        frameimg = "n_UIShare/equip/info/zbxy_ui_004.png"
        framebg = "n_UIShare/equip/info/xqzx_bg_002_4.png"
    end
    self.equipFrameImg:setTexture(frameimg)
    self.equipBG:setTexture(framebg)

    local equip_atb = equip[e_id_num].equip_atb
        
    if equip_atb == 1 then
        self.equipEAtbAct:play("shui",true)
    elseif equip_atb == 2 then
        self.equipEAtbAct:play("huo",true)
    elseif equip_atb == 3 then
        self.equipEAtbAct:play("feng",true)
    elseif equip_atb == 4 then
        self.equipEAtbAct:play("guang",true)
    elseif equip_atb == 5 then
        self.equipEAtbAct:play("an",true)
    else
        self.equipEAtbAct:play("reset",false)
    end

    --self.equipElement:setVisible(true)
    self.equipElement:setTexture( ATB_Icon[equip_atb])

    -- self.btnAtlas1:setVisible(equip[e_id_num].equip_pass == 1)
    -- self.btnAtlas2:setVisible(equip[e_id_num].equip_explore == 1)

    self.btnLock:setVisible(false)
    self.btnUnlock:setVisible(false)
--
end

function EquipInfoView:refresh()
    self.skillDescPanel_1:removeAllChildren()
    self.skillDescPanel_2:removeAllChildren()

    local time_id = getTimeNumID( self.equip_id )

    if time_id > 10 then
        --已拥有
        self.btnRSK:setVisible(true)
        self.btnSkill:setVisible(true)
        self.btnAwaken:setVisible(true)
        self.btnSth:setVisible(true)
    else
        self.btnRSK:setVisible(false)
        self.btnSkill:setVisible(false)
        self.btnAwaken:setVisible(false)
        self.btnSth:setVisible(false)
    end

    if self.equip_data then
        if time_id > 10 then
            self.btnLock:setVisible(self.equip_data["is_lock"])
            self.btnUnlock:setVisible(not self.equip_data["is_lock"])
        end

	    local e_id_num = getNumID(self.equip_id)
        --有数据
		-- ["icon"] = equip[e_id_num].equip_vdw_icon,
		-- ["atb"]  = equip[e_id_num].equip_atb,
		-- ["job"]  = equip[e_id_num].equip_job,
		-- ["name"] = equip[e_id_num].equip_name,
		-- ["egg"]  = eq_info[self.m_EquipId].egg,
		-- ["lv"]   = eq_info[self.m_EquipId].Lv,
		-- ["rare"] = getRoleRank(equip[e_id_num].equip_rank),
        
        local  breakCount  = self.equip_data["brk_num"] -- 突破次数
        --local  breakLimit  = self.equip_data["rarity"]  -- 最大突破次数
         
        for i = 1,4 do
            self["awk"..i]:setVisible(breakCount >=i)
        end
        -- self.awkNum:setString(""..breakCount.."/4")

        self.numAtk:setString(self.equip_data["atk"])
        self.numHP:setString(self.equip_data["hp"])
        self.barAtk:setPercent(getEquipATKPrent(self.equip_data["atk"])*100)
        self.barHP:setPercent(getEquipHPPrent(self.equip_data["hp"])*100)
        
        local lvcur = self.equip_data.Lv
        local lvmax = self.equip_data.Lv_max

        -- self.lbCurLv:setString("等级 "..lvcur)
        if g_channel_control.transform_EquipInfoView_lbCurMaxLv_pos == true then
            local lbCurMaxLvX = 310
            local lbCurMaxLvXNew = lbCurMaxLvX -20
            self.lbCurMaxLv:setPositionX(lbCurMaxLvXNew)
        end
        self.lbCurMaxLv:setString(lvcur.."/"..lvmax)
        
        if lvcur < lvmax then --不满级
            self.lbExpNext:setString(UITool.ToLocalization("离下一级：")..(self.equip_data.exp_max - self.equip_data.exp))
            self.barExp:setPercent(self.equip_data.exp / self.equip_data.exp_max * 100)
        else
            self.lbExpNext:setString("")
            self.barExp:setPercent(100)
        end
        
        if self.equip_data["owner"] ~= "0" then
            self.ownerFace:setVisible(true)
            self.ownerText:setVisible(true)

            local h_id_num = getNumID(self.equip_data["owner"])
            self.ownerFace:setTexture(hero[h_id_num].hero_list_icon)
        else
            self.ownerFace:setVisible(false)
            self.ownerText:setVisible(false)
        end
        
        --技能1
        self.skillName_1:setString(UITool.getUserLanguage(equip[e_id_num]["equip_skill"]["skill_name"]))--(equip[e_id_num]["equip_skill"]["skill_name"])
        self.skillIcon_1:setVisible(true)
        self.skillIcon_1:setTexture(equip[e_id_num]["equip_skill"]["skill_img"])
        self.skillLevel_1:setString(self.equip_data["sk"]["Lv"])
        
        for i = 1,2 do
            local prsk = self["skillPrsk"..i]
            if self.equip_data["rsk"] ~= nil and self.equip_data["rsk"][i] ~= nil then
                prsk:setVisible(true)
                local rsk_id = self.equip_data["rsk"][i][1]
                if rsk_id > 0 then
                    local strsrc = UITool.getUserLanguage(eq_random_sk[rsk_id])--eq_random_sk[rsk_id]
                    strsrc = string.gsub(strsrc,"%*",""..(self.equip_data["rsk"][i][2]))
                    prsk:getChildByName("rskDesc"):setString(strsrc)
                else
                    prsk:getChildByName("rskDesc"):setString(UITool.ToLocalization("可获得随机加成"))
                end
            else
                prsk:setVisible(false)
            end
        end

        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(equip[e_id_num]["equip_skill"]["skill_des"])--equip[e_id_num]["equip_skill"]["skill_des"]
       if #self.equip_data["sk"]["add_atk_rate"] > 0 then
            --str_des = string.gsub(str_des,"%*",""..(self.equip_data["sk"]["add_atk_rate"]).."%%")
            str_des = UITool.stringForEqSK(str_des,self.equip_data["sk"]["add_atk_rate"])
        else
            if self.eb == false then
                str_des = string.gsub(str_des,"%*","")
            end
        end
        if self.eb == false then
            self.skillDescPanel_1:setString(str_des)
        elseif self.eb == true then
            local basic  = equip[e_id_num]["equip_skill"]["basic"]
            local upadd  = equip[e_id_num]["equip_skill"]["up_add"]
            local basic2 = equip[e_id_num]["equip_skill"]["basic2"]
            local upadd2 = equip[e_id_num]["equip_skill"]["up_add2"]
            local v1 = basic+(10-1)*upadd
            local v2 = basic2+(10-1)*upadd2
            local tb = {}
            if v2 == 0 then
                tb[1] = v1
                str_des = UITool.stringForEqSK(str_des,tb)
            else
                tb[1] = v1
                tb[2] = v2
                str_des = UITool.stringForEqSK(str_des,tb)
            end
             self.skillDescPanel_1:setString(str_des)
        end

        --技能2
        if equip[e_id_num]["is_there_sk_two"] == 0 then
            self.skillNo_2:setVisible(true)
        else
            self.skillNo_2:setVisible(false)
            local skill_two_icon = passive_sk[self.equip_data["sk_two"]["provide_sk_id"]]["sk_icon"]
            local skill_two_name = UITool.getUserLanguage(passive_sk[self.equip_data["sk_two"]["provide_sk_id"]]["sk_name"])--passive_sk[self.equip_data["sk_two"]["provide_sk_id"]]["sk_name"]
            self.skillName_2:setString(skill_two_name)
            self.skillIcon_2:setVisible(true)
            self.skillIcon_2:setTexture(skill_two_icon)
            self.skillLevel_2:setString(self.equip_data["sk_two"]["Lv"])

            --技能描述


            if self.eb == true then 
                local strSkillTwo_des = UITool.getUserLanguage(passive_sk[equip[e_id_num]["equip_skill2"]["skill_id"]]["sk_des"])
                self.skillDescPanel_2:setString(strSkillTwo_des)
            else
                local time_id = getTimeNumID( self.equip_id )
                if time_id > 10 then
                    local strSkillTwo_det_des = UITool.getUserLanguage(passive_sk[self.equip_data["sk_two"]["provide_sk_id"]]["sk_det_des"])
                    self.skillDescPanel_2:setString(strSkillTwo_det_des)
                else
                    local strSkillTwo_des = UITool.getUserLanguage(passive_sk[self.equip_data["sk_two"]["provide_sk_id"]]["sk_des"])
                    self.skillDescPanel_2:setString(strSkillTwo_des)
                end
            end
        end

        
    else
        for i = 1,4 do
            self["awk"..i]:setVisible(false)
        end
        -- self.awkNum:setString("")

        self.barAtk:setPercent(0)
        self.barHP:setPercent(0)
        self.numAtk:setString("")
        self.numHP:setString("")

        self.ownerFace:setVisible(false)
        self.ownerText:setVisible(false)
        -- self.equipName:setString("")
        -- self.equipImage:setVisible(false)
        -- self.equipElement:setVisible(false)
        
        -- self.lbCurLv:setString("")
        self.lbCurMaxLv:setString("")
        self.lbExpNext:setString("")
        self.barExp:setPercent(0)

        self.skillIcon_1:setVisible(false)
        self.skillName_1:setString("")
        self.skillLevel_1:setString("")

        self.skillNo_2:setVisible(true)

        self.skillPrsk1:setVisible(false)
        self.skillPrsk2:setVisible(false)
    end
end

function EquipInfoView:onListChanged()
    GameManagerInst:rpc("{\"rpc\":\"eq_list\"}",3,
    function(data)
        --success
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        DataManager:rfsElist()   
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end

    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipInfoView:loadBagList(callback)
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
		DataManager:wAllBagData(data["bag"])
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipInfoView:lockEquip()
    if not self.equip_data then
        return
    end

    local tempTable = {
        ["rpc"] = "eq_lock",
        ["eq_id"] = self.equip_id,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        if user_info["eq"][self.equip_id] then
            user_info["eq"][self.equip_id]["is_lock"] = data["is_lock"]
            DataManager:rfsElist()
        end
        self.equip_data["is_lock"] = data["is_lock"]

        if data["is_lock"] then
            GameManagerInst:alert(UITool.ToLocalization("灵装已锁定"))
        else
            GameManagerInst:alert(UITool.ToLocalization("灵装已解锁"))
        end

        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    true)

end

function EquipInfoView:showEquipSkill()
    if not self.equip_id then return end

    local nCurEquiped = 0
    if self.equip_data then
        if self.equip_data["owner"] == "0" then
            nCurEquiped = 0
        else
            nCurEquiped = 1
        end
    end
    SceneManager:toEquipFromRole({rootNode = self:getRootNode(), tab = 1, eq_id = self.equip_id, nEquiped = nCurEquiped})
end

function EquipInfoView:onBtnRsk()
    if not self.equip_id then
        return
    end
    
    -- local mid = getMatID(ID_EQUIP_RSK)
    -- local cnt = user_info["bag"]["mat"][ID_EQUIP_RSK]
    -- if not cnt or cnt <= 0 then 
    --     GameManagerInst:alert(""..mat[mid].name..UITool.ToLocalization("不足"))
    --     return
    -- end

    local view = EquipRskView.new():initWithData(self.equip_id,self.equip_data)
    view.updateInfoEvent = function(sender,data)
        self.equip_data = table.deepcopy(data)
        self:refresh()
    end
    GameManagerInst:showModalView(view)
end

function EquipInfoView:showEquipSth()
    if not self.equip_id then return end

    local nCurEquiped = 0
    if self.equip_data then
        if self.equip_data["owner"] == "0" then
            nCurEquiped = 0
        else
            nCurEquiped = 1
        end
    end
    SceneManager:toEquipFromRole({rootNode = self:getRootNode(), tab = 2, eq_id = self.equip_id, nEquiped = nCurEquiped})   
end

function EquipInfoView:showEquipAwaken()
    if not self.equip_id then return end

    local nCurEquiped = 0
    if self.equip_data then
        if self.equip_data["owner"] == "0" then
            nCurEquiped = 0
        else
            nCurEquiped = 1
        end
    end
    SceneManager:toEquipFromRole({rootNode = self:getRootNode(), tab = 3, eq_id = self.equip_id, nEquiped = nCurEquiped})
end


function EquipInfoView:showAtlas(atlasType)
    -- if GameManagerInst.gameType ~= 2 then return end


    if atlasType == 1 then         
        local rcvData = {}
        rcvData["item_type"] = 3
        rcvData["item_id"] = self.equip_id
        rcvData["isCallFunc"] = true
        rcvData["callFunc"]   = self.onListChanged
        rcvData["self"]       = self
        SceneManager:toBattlePassListLayer(rcvData)
    elseif atlasType == 2 then
        if tonumber(user_info["rank"]) >= UnlockExploreRank then        
            local rcvData = {}
            rcvData["isCallFunc"] = true
            rcvData["callFunc"]   = self.onListChanged
            rcvData["self"]       = self
            rcvData.isBackStartLayer = 0
            SceneManager:toExploreLayer(rcvData)
       else 
            local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),UnlockExploreRank)
            SceneManager:showPromptLabel(str)
       end 
    end
end

function EquipInfoView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self.exist = false;
    if self._navigationView then
        self._navigationView:popView()
    end
end


function EquipInfoView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType(nil,3)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        self:loadInfo()
        self:refresh()
    else
        self:loadInfo()
    end
end
