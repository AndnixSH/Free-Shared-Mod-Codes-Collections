--require "XUIView"

---弃用

display    = require("cocos.framework.display")

RoleInfoView = class("RoleInfoView",XUIView)
RoleInfoView.CS_FILE_NAME = "RoleInfoMainView.csb"
RoleInfoView.CS_BIND_TABLE = 
{
    panelBG = "/s:panelBG",
    panelClose = "/i:125",
    panelRightBtn = "/i:22",

    pState="/i:1063",
    pSkill="/i:1081",
    pEquip="/i:1147",
    pStory="/i:1143",
    
    btnTab1="/i:22/i:23",
    btnTab2="/i:22/i:24",
    btnTab2Tip="/i:22/i:24/i:414",
    btnTab3="/i:22/i:25",
    btnTab4="/i:22/i:26",

    btnClose = "/i:125/i:92",

    --all
    roleName = "/i:137/i:463",
    roleIconPos = "/i:137/s:roleIconPos",
    roleElement = "/i:137/i:77",
    roleFrameStar = "/i:137/i:112",
    roleNotGetImg = "/i:137/i:348",
    roleNotGetNode = "/i:137/i:3481",
    roleNotGetNum1 = "/i:137/i:3481/i:163",
    roleNotGetSlash = "/i:137/i:3481/i:164",
    roleNotGetNum2 = "/i:137/i:3481/i:162",
    roleNotGetBtn = "/i:137/i:3481/i:215",
    roleBtnProp = "/i:137/i:275",
    roleBtnPropText = "/i:137/i:275/i:207",
    btnVoice = "/i:137/s:btnVoice",
    btnShare = "/i:137/s:btnShare",
    btnPrevHero = "/i:137/s:btnPrevHero",
    btnNextHero = "/i:137/s:btnNextHero",
    imgIntimacyBg = "/i:137/s:imgIntimacyBg",
    imgIntimacy = "/i:137/s:imgIntimacy",
    btnIntimacy = "/i:137/i:659",

    --story
    storyDetail="/i:1143/i:210",
    storyHeroName="/i:1143/i:452",
    storyRaceName="/i:1143/i:443",
    storyRaceIcon="/i:1143/i:450",
    storyPowerName="/i:1143/i:444",
    storySexName="/i:1143/i:455",
    storySexIcon="/i:1143/i:456",
    storyCV="/i:1143/i:453",
    storyArt="/i:1143/i:454",

    storyBG1 ="/i:1143/s:storyBG1",

    btnExclusiveStory="/i:1143/i:541",
    spExclusiveStoryNoOpen="/i:1143/i:541/i:542",
    --state
    stateBG1 = "/i:1063/s:stateBG1",
    stateBG2 = "/i:1063/s:stateBG2",
    stateHead1 = "/i:1063/s:stateHead1",
    awk1 = "/i:1063/i:250/i:493",
    awk2 = "/i:1063/i:250/i:496",
    awk3 = "/i:1063/i:250/i:495",
    awk4 = "/i:1063/i:250/i:494",
    awkNum = "/i:1063/i:250/i:535",
    lbCurLv = "/i:1063/i:250/i:492",
    lbMaxLv = "/i:1063/i:250/i:491",
    lbExpNext = "/i:1063/i:250/i:490",
    barExp = "/i:1063/i:250/i:536",

    stateHead2 = "/i:1063/s:stateHead2",
    stateGetMethod = "/i:1063/s:stateHead2/i:253",

    barAtk = "/i:1063/i:629",
    barAtkAdd = "/i:1063/s:barAtkAdd",
    barHP = "/i:1063/i:628",
    barHPAdd = "/i:1063/s:barHPAdd",
    numAtk = "/i:1063/i:627",
    numHP = "/i:1063/i:626",
    numAtkAdd = "/i:1063/s:numAtkAdd",
    numHPAdd = "/i:1063/s:numHPAdd",
    numProp1 = "/i:1063/s:numProp1",   --暴击
    numProp2 = "/i:1063/s:numProp2",   --回复
    numProp3 = "/i:1063/s:numProp3",   --爆伤
    numProp4 = "/i:1063/s:numProp4",   --防御
    numProp5 = "/i:1063/s:numProp5",   --攻速
    numProp1Add = "/i:1063/s:numProp1Add",   --暴击
    numProp2Add = "/i:1063/s:numProp2Add",   --回复
    numProp3Add = "/i:1063/s:numProp3Add",   --爆伤
    numProp4Add = "/i:1063/s:numProp4Add",   --防御
    numProp5Add = "/i:1063/s:numProp5Add",   --攻速

    jobImg = "/i:1063/s:jobImg",  
    jobName = "/i:1063/s:jobName",  
    jobDesc = "/i:1063/s:jobDesc",  

    pRoleModel = "/i:1063/i:412", 

    --skill
    skill1 = "/i:1081/i:950",
    skill2 = "/i:1081/i:951",
    skill3 = "/i:1081/i:952",
    skill4 = "/i:1081/i:953",
    pSkillNormal = "/i:1081/i:954",
    pSkillNormalButtons = "/i:1081/i:954/i:548",
    btnBuySP = "/i:1081/i:954/i:548/i:244",
    btnSkillReset = "/i:1081/i:954/i:548/i:956",
    btnSkillAdd = "/i:1081/i:954/i:548/i:958",
    pSkillAdd = "/i:1081/i:955",
    btnSkillCancel = "/i:1081/i:955/i:960",
    btnSkillCommit = "/i:1081/i:955/i:962",
    spPanel = "/i:1081/i:549",
    spLeft = "/i:1081/i:549/i:551",

    skDescPanel = "/i:1081/s:panelSkillDesc",
    skDescPos1 = "/i:1081/s:panelSkillDesc/s:descpos1",
    skDescPos2 = "/i:1081/s:panelSkillDesc/s:descpos2",
    skDescPos3 = "/i:1081/s:panelSkillDesc/s:descpos3",
    skDescPos4 = "/i:1081/s:panelSkillDesc/s:descpos4",
    skDescTouch1 = "/i:1081/s:panelSkillDesc/s:skDesTouch1",
    skDescTouch2 = "/i:1081/s:panelSkillDesc/s:skDesTouch2",
    skDescTouch3 = "/i:1081/s:panelSkillDesc/s:skDesTouch3",
    skDescTouch4 = "/i:1081/s:panelSkillDesc/s:skDesTouch4",
    skDesc = "/i:1081/s:panelSkillDesc/s:skDesc",
    skDescTitle = "/i:1081/s:panelSkillDesc/s:skDesc/s:Text_1",
    skDescDetail = "/i:1081/s:panelSkillDesc/s:skDesc/s:Text_2",
    skDescCD = "/i:1081/s:panelSkillDesc/s:skDesc/s:lbCD",
    skDescCDText = "/i:1081/s:panelSkillDesc/s:skDesc/s:lbCDText",

    --equip
    equip1 = "/i:1147/i:726",
    equip2 = "/i:1147/i:743",
    equip3 = "/i:1147/i:744",
    equipSoul = "/i:1147/i:898",
    eqDetailPanel ="/i:1147/i:747",
    eqName ="/i:1147/i:747/i:772",
    eqBG ="/i:1147/i:747/i:767/i:771",
    eqIcon ="/i:1147/i:747/i:767/i:770",
    eqFrame ="/i:1147/i:747/i:767/i:769",
    eqElement ="/i:1147/i:747/i:767/i:768",
    eqAtk ="/i:1147/i:747/i:25",
    eqHP ="/i:1147/i:747/i:24",
    eqLv ="/i:1147/i:747/i:26",
    eqMaxLv ="/i:1147/i:747/i:27",
    -- eqExpNext ="/i:1147/i:747/i:28",
    eqExpBar ="/i:1147/i:747/i:57",

    --技能1
    eqSkName1 ="/i:1147/i:747/i:59",
    eqSkLv1 ="/i:1147/i:747/i:60",
    eqSkDesc1 ="/i:1147/i:747/i:213/i:61",
    eqSkIcon1 = "/i:1147/i:747/i:213/i:219",

    --技能2
    eqSkName2 ="/i:1147/i:747/i:214",
    eqSkLv2 ="/i:1147/i:747/i:215",
    eqSkDesc2 ="/i:1147/i:747/i:216/i:217",
    eqSkIcon2 = "/i:1147/i:747/i:216/i:218",
    eqSkNo2 = "/i:1147/i:747/i:216/i:220",

    eqBtnSkRnd ="/i:1147/i:747/i:39",
    eqSkPrsk1 ="/i:1147/i:747/i:33",
    eqSkPrsk2 ="/i:1147/i:747/i:36",

    eqBtnChange ="/i:1147/i:747/i:784",
    --eqBtnSkill ="/i:1147/i:747/i:786",
    eqBtnSth ="/i:1147/i:747/i:788",
    --eqBtnAwaken ="/i:1147/i:747/i:790"
    eqAwk1 = "/i:1147/i:747/i:304",
    eqAwk2 = "/i:1147/i:747/i:305",
    eqAwk3 = "/i:1147/i:747/i:306",
    eqAwk4 = "/i:1147/i:747/i:307",
}

RoleInfoView.SKILL_COLOR = cc.c4b(255,192,0,255)
RoleInfoView.PSKILL_COLOR = cc.c4b(0,232,255,255)
RoleInfoView.LastTab = 1
RoleInfoView.VoiceMap = {2,5,7,8,9}

function RoleInfoView:init(hero_id,other_ids,team_id)
    RoleInfoView.super.init(self)
    self.exist = true;
    self.galleryMode = 0
    self.team_id = team_id
    self.hero_id = hero_id

    if other_ids then
        self.other_ids = other_ids
        if #self.other_ids <= 1 then
            self.btnPrevHero:setTouchEnabled(false)
            self.btnPrevHero:setBright(false)

            self.btnNextHero:setTouchEnabled(false)
            self.btnNextHero:setBright(false)
        else
            self.other_ids_index = 0
            for i = 1,#self.other_ids do
                if self.hero_id == self.other_ids[i] then
                    self.other_ids_index = i
                    break
                end
            end
        end
        self.btnPrevHero:addClickEventListener(function()
            self:switchHero(-1)
        end)
        self.btnNextHero:addClickEventListener(function()
            self:switchHero(1)
        end)
    else
        self.btnPrevHero:setVisible(false)
        self.btnNextHero:setVisible(false)
    end

    if g_channel_control.b_LikeState then
        self.btnIntimacy:addClickEventListener(function()
            local roleIntimacyView = RoleIntimacyView.new():init(self.hero_id)
            self:addSubView(roleIntimacyView)
        end)
    end


    self.btnVoice:setEffectType(-1)
    self.btnVoice:addClickEventListener(function()
        self:playNestVoice()
    end)

    self.btnShare:setEffectType(-1)
    self.btnShare:setVisible(false)
    self.btnShare:addClickEventListener(function()
        self:toShareRole()
    end)
    ----------
    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)

    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.btnTab4:setPressedActionEnabled(false)
    self.btnTab4:addClickEventListener(function()
        self:switchView(4)
    end)

    self.btnTab1Pos = {self.btnTab1:getPosition()}
    self.btnTab2Pos = {self.btnTab2:getPosition()}
    self.btnTab3Pos = {self.btnTab3:getPosition()}
    self.btnTab4Pos = {self.btnTab4:getPosition()}

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:getRootNode():stopAllActions()

        if self.asyncHandler1 then
            self.asyncHandler1:cancel(true)
            self.asyncHandler1 = nil
        end
        
        if self.asyncHandler2 then
            self.asyncHandler2:cancel(true)
            self.asyncHandler2 = nil
        end
        self:returnBack()
    end)

    --开启角色
    self.roleNotGetBtn:addClickEventListener(function()
        self:confirmHeroOpen()
    end)

    ---
    self.pRoleModel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:swithModelAction()
        end
    end)

    --角色额外提升属性
    self.roleBtnProp:addClickEventListener(function()
        self:showHeroProp()
    end)

    self.roleEAtb = cc.CSLoader:createNode("EffElementAll.csb")    
    self.roleEAtb:setPosition(self.roleElement:getPosition())
    self.roleElement:getParent():addChild(self.roleEAtb)

    self.roleEAtbAct = cc.CSLoader:createTimeline("EffElementAll.csb")
    self.roleEAtb:runAction(self.roleEAtbAct)
    self.roleEAtbAct:play("reset",false)

    --加载装备
    self.eqBtnChange:addClickEventListener(function()
        self:showEquipList()
    end)
    -- self.eqBtnSkill:addClickEventListener(function()
    --     self:showEquipSkill()
    -- end)
    self.eqBtnSth:addClickEventListener(function()
        self:showEquipSth()
    end)
    -- self.eqBtnAwaken:addClickEventListener(function()
    --     self:showEquipAwaken()
    -- end)

    self.eqBtnSkRnd:addClickEventListener(function()
        self:onEqSkRnd()
    end)

    --

    local bindTable =
    {
        panelNoOpen = "/i:709",
        panelNoOpen_img3 = "/i:709/i:710",
        panelNoOpen_img1 = "/i:709/i:18",
        panelInfo = "/i:657",
        panelTouch = "/i:598",

        lbName = "/i:657/i:665",
        --lbDesc = "/i:657/i:705",
        lbLevel = "/i:657/i:706",
        lbHP = "/i:657/i:707",
        lbAtk = "/i:657/i:708",
        --eskIcon = "/i:657/s:eskIcon",

        eskIcon1 = "/i:657/i:216/s:eskIcon",
        eskIcon2 = "/i:657/i:219/s:eskIcon",
        lbSkillLv1 = "/i:657/i:216/s:skillLv",
        lbSkillLv2 = "/i:657/i:219/s:skillLv",
        skillPanel1 = "/i:657/i:216",
        skillPanel2 = "/i:657/i:219",
        
        imgBG = "/i:657/i:661/i:662",
        imgElement = "/i:657/i:661/i:664",
        imgFace = "/i:657/i:661/i:659",
        imgRarity = "/i:657/i:661/i:663",
    }

    self.equipView1 = XUIView.new():init(self.equip1,"RoleInfoEquipItemView.csb",bindTable)
    self.equipView2 = XUIView.new():init(self.equip2,"RoleInfoEquipItemView.csb",bindTable)
    self.equipView3 = XUIView.new():init(self.equip3,"RoleInfoEquipItemView.csb",bindTable)

    local SEbindTable =
    {
        panelNoOpen = "/i:709",
        panelNoOpen_img3 = "/i:709/i:710",
        panelInfo = "/i:657",
        panelTouch = "/i:598",

        lbName = "/i:657/i:665",
        lbLevel = "/i:657/i:706",
        lbHP = "/i:657/i:707",
        lbAtk = "/i:657/i:708",
        eskIcon = "/i:657/s:eskIcon",
        
        imgBG = "/i:657/i:661/i:662",
        imgFace = "/i:657/i:661/i:659",
        imgRarity = "/i:657/i:661/i:663",
    }

    --self.equipSoulView = XUIView.new():init(self.equipSoul,"SoulRoleInfoEquipItemView.csb",SEbindTable)
    print("RoleInfoView:init===self.hero_id:"..self.hero_id)
    if g_channel_control.roleInfoView_hideEquipSoulView ~= true then
       self.equipSoulView = SoulRoleInfoEquipItemView.new():init(self.equipSoul,self.hero_id)
    else
        self.equipSoulView = nil
        self.equipSoul:setVisible(false)
    end


    self.equipView1.panelNoOpen_img3:removeFromParent()
    self.equipView2.panelNoOpen_img3:removeFromParent()
    self.equipView3.panelNoOpen_img1:removeFromParent()


    self.equip1:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickEquip(1)
        end
    end)
    self.equip2:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickEquip(2)
        end
    end)
    self.equip3:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickEquip(3)
        end
    end)
    ---equip end

    --SoulEquip Start
    self.equipSoul:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickSoulEquip()
        end
    end)
    --SoulEquip End

    --加载技能

    local skillBindTable =
    {
        skillIcon = "/i:902",
        skillName = "/i:903",
        skillCD = "/i:925",
        skillCDText = "/i:475",
        skillDesc = "/i:25",
        btnAdd = "/i:926",
        skillLevel = "/i:864",
        skillMaxLevel = "/i:244",
        skFromEquip = "/s:skFromEquip",
    }
    self.skillView1 = XUIView.new():init(self.skill1,"RoleInfoSkillItemView.csb",skillBindTable)
    self.skillView2 = XUIView.new():init(self.skill2,"RoleInfoSkillItemView.csb",skillBindTable)
    self.skillView3 = XUIView.new():init(self.skill3,"RoleInfoSkillItemView.csb",skillBindTable)
    self.skillView4 = XUIView.new():init(self.skill4,"RoleInfoSkillItemView.csb",skillBindTable)

    -- self.skillView1.btnAdd:addClickEventListener(function()
    --     self:onSkillAdd(1)
    -- end)
    -- self.skillView2.btnAdd:addClickEventListener(function()
    --     self:onSkillAdd(2)
    -- end)
    -- self.skillView3.btnAdd:addClickEventListener(function()
    --     self:onSkillAdd(3)
    -- end)
    -- self.skillView4.btnAdd:addClickEventListener(function()
    --     self:onSkillAdd(4)
    -- end)

    for i = 1,4 do
        self["skillView"..i].btnAdd:addClickEventListener(function()
            self:onSkillAdd(i)
        end)

        self["skDescTouch"..i]:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                self:onShowSkillDesc(i)
            end
        end)

        if g_channel_control.transform_RoleInfoView_skillDesc_contentSize then

            self["skillView"..i].skillDesc:setContentSize(375,80)
            
        end

        
    end

    self.pSkillAdd:setVisible(false)
    self.pSkillNormal:setVisible(true)

    self.btnBuySP:addClickEventListener(function()
        self:onSkillBuySP()
    end)

    self.btnSkillReset:addClickEventListener(function()
        --需要加重置技能确认提示        
        GameManagerInst:confirm(UITool.ToLocalization("重置技能点数花费")..G_SkillResetCost..UITool.ToLocalization("金币，\n是否重置？"),function()
            self:onSkillReset()
        end)
    end)
    self.btnSkillAdd:addClickEventListener(function()
        self:onSkillStartAdd()
    end)
    self.btnSkillCancel:addClickEventListener(function()
        self:onSkillCancel()
    end)
    self.btnSkillCommit:addClickEventListener(function()
        self:onSkillCommit()
    end)
    --skill end

    -- story start
    self.btnExclusiveStory:addClickEventListener(function()
        self:onExcluSiveStory()
    end)
    -- story end

    self:refreshStaticState()

    self:switchView()

    self:refresh()

    self:setNodeLockState()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end

function RoleInfoView:switchView(tab)
    local num = tab or 1
    if self.galleryMode == 2 then
        num = tab or RoleInfoView.LastTab
    end

    if self.curTab ~= num then
        
        self.curSkDescIdx = nil
        self.skDesc:setVisible(false)
        
        self.curEquipIndex = nil
        self.eqDetailPanel:setVisible(false)
        
        local ctls = {
            {btn = self.btnTab1, view= self.pState},
            {btn = self.btnTab2, view= self.pSkill},
            {btn = self.btnTab3, view= self.pEquip},
            {btn = self.btnTab4, view= self.pStory}
        }

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            ctls[i].btn:setBright(i ~= num)
            ctls[i].view:setVisible(i == num)
        end
        
        self.curTab = num

        if self.galleryMode == 2 then
            RoleInfoView.LastTab = num
            self.roleBtnProp:setVisible(self.curTab ~= 2)
        end

    end
end

function RoleInfoView:switchHero(offect)
    self:getRootNode():stopAllActions()

    self.other_ids_index = self.other_ids_index + offect
    if self.other_ids_index < 1 then
        self.other_ids_index = #self.other_ids
    elseif self.other_ids_index > #self.other_ids then
        self.other_ids_index = 1
    end

    self.hero_id = self.other_ids[self.other_ids_index]
    self.hero_data = nil

    --cc.Director:getInstance():getTextureCache():removeUnusedTextures()

    self:refreshStaticState()
    self:refresh()
    
    -- if self.galleryMode == 1 then
        self:loadInfo(false)
    -- else
    --     local delay = cc.DelayTime:create(1)
    --     local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
    --         self:loadInfo()
    --     end))
    --     self:getRootNode():runAction(sequence)
    -- end
end

---上帝才知道是做什么用的
function RoleInfoView:loadInfo1(tempTable)
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            self.hero_data = table.deepcopy(data["hero_info"])
            
            if data["fp_all_in_team"] ~= nil then
                self.hero_data.fp_all = table.deepcopy(data["fp_all_in_team"])
            end

            --更新装备槽魂灵装信息
            if not self.equipSoulView then
            else
                if self.hero_data then
                    self.equipSoulView:FillSoulEquipInfo(self.hero_data)
                end
            end

            if user_info["hero"][data["hero_info"].id] then
                for k,v in pairs(user_info["hero"][data["hero_info"].id]) do
                    user_info["hero"][data["hero_info"].id][k] = table.deepcopy(data["hero_info"][k])
                end
                DataManager:rfsHlist()
            end
            self:refresh()
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end

function RoleInfoView:loadInfo(bRefresh)
    if not self.hero_id then return end

    --图鉴界面时，加载假数据
    local h_id_num = getNumID( self.hero_id )
    local time_id = getTimeNumID( self.hero_id )

    if time_id > 10 then
        local tempTable = {
                rpc = "hero_info",
                hero_id = self.hero_id
            }

        if self.team_id then
            tempTable["team_id"] = ""..self.team_id
        end

        if bRefresh and self.hero_data ~= nil and #self.hero_data.team_list > 0 then            
            self:loadTeamList(function()
                self:loadInfo1(tempTable)
            end)
            return
        end

        --已获得角色，读取数据
        GameManagerInst:rpc( 
            tempTable,
            3,
            function(data)
                --success
                if self.exist == false then
                    return
                end
                self.hero_data = table.deepcopy(data["hero_info"])
                
                if data["fp_all_in_team"] ~= nil then
                    self.hero_data.fp_all = table.deepcopy(data["fp_all_in_team"])
                end
                --GameManagerInst:saveToFile("hero_info_1.json",data)
                --更新装备槽魂灵装信息
                if not self.equipSoulView then
                else
                    if self.hero_data then
                        self.equipSoulView:FillSoulEquipInfo(self.hero_data)
                    end
                end
                --更新故事槽专属剧情状态
                
                --self:FillSoulEquipFakeInfo()

                if bRefresh then
                    if user_info["hero"][data["hero_info"].id] then
                        for k,v in pairs(user_info["hero"][data["hero_info"].id]) do
                            user_info["hero"][data["hero_info"].id][k] = table.deepcopy(data["hero_info"][k])
                        end
                        DataManager:rfsHlist()
                    end
                    self:refresh()
                else
                    self:refresh()
                end

            end,
            function(state_code,msgText)
                --failed
                if self.exist == false then
                    return
                end
                GameManagerInst:alert(msgText)
            end,
            true)
    else
        --未获得角色
        local tdata = {}
        
        tdata.id = self.hero_id
        tdata.hero_add = 0
        tdata.Lv = 100
        tdata.Lv_max = 100
        tdata.exp = 0
        tdata.exp_max = 100
        tdata.hp = hero_upgrade[h_id_num][100][2]
        tdata.atk = hero_upgrade[h_id_num][100][3]
        tdata.def = hero_upgrade[h_id_num][100][4]
        tdata.crit = hero_upgrade[h_id_num][100][5]
        tdata.crit_dmg = hero_upgrade[h_id_num][100][6]
        tdata.hel = hero_upgrade[h_id_num][100][9]
        tdata.asp = hero_upgrade[h_id_num][100][7]
        tdata.break_count = 4
        tdata.eq = {}
        tdata.eq["1"] = { eq_id = "", eq_info = {} }
        tdata.eq["2"] = { eq_id = "", eq_info = {} }
        tdata.eq["3"] = { eq_id = "", eq_info = {} }
        tdata.tp = { max_num = 40 , num = 0 , from_other = 0}
        tdata.fp_all = {
            all = 0 ,
            hp = tdata.hp,
            atk = tdata.atk,
            def = tdata.def,
            crit = tdata.crit,
            crit_dmg = tdata.crit_dmg,
            hel = tdata.hel,
            asp = tdata.asp
        }
        tdata.rarity = hero[h_id_num].hero_rank
        tdata.element = hero[h_id_num].hero_atb

        tdata.active_sk = {}
        tdata.active_sk["1"] = {lv = 10 ,max_lv = 10, id = (4000110 + h_id_num * 1000)}
        tdata.active_sk["2"] = {lv = 10 ,max_lv = 10, id = (4000210 + h_id_num * 1000)}

        tdata.passive_sk = {}
        tdata.passive_sk["1"] = {lv = 10 ,max_lv = 10, id = (5000110 + h_id_num * 1000)}
        tdata.passive_sk["2"] = {lv = 10 ,max_lv = 10, id = (5000210 + h_id_num * 1000)}

        self.hero_data = tdata
        self:refresh()
    end
end

--- 以下为魂灵装相关

-- "soul":{
--                 "Lv":1,
--                 "atk":50,
--                 "hp":108,
--                 "exp":0,
--                 "exp_max":100,
--                 "add_atk":0,
--                 "break_count":0,
--                 "state":1,
--                 "skills":{

--                 },
--                 "Lv_max":50,
--                 "add_hp":0
--             },

--- 填充魂灵装假数据
function RoleInfoView:FillSoulEquipFakeInfo()
    local tdata = {}
    
    tdata.Lv = 1
    tdata.atk = 50
    tdata.hp = 108
    tdata.exp = 0
    tdata.exp_max = 100
    tdata.add_atk = 0
    tdata.break_count = 0
    tdata.state = 1
    tdata.Lv_max = 50
    tdata.add_hp = 0
    tdata.skills = {}
    tdata.skills["1"] = 6013001
    tdata.skills["2"] = 6013002
    tdata.skills["3"] = 6013003

    self.hero_data.soul = tdata
end

--对纹理进行裁剪  裁剪的图片路径spritePath   裁剪的形状图片路径maskPath  
-- function cc.exports.maskedSprite(spritePath, maskPath)  
--     local textureSprite = cc.Sprite:create(spritePath)  
--     local textureSize = textureSprite:getContentSize()  
  
--     local maskSprite = cc.Sprite:create(maskPath)  
--     local maskSize = maskSprite:getContentSize()  
  
--     local renderTexture = cc.RenderTexture:create(maskSize.width,maskSize.height)  
--     maskSprite:setPosition(cc.p(maskSize.width/2,maskSize.height/2))  
--     textureSprite:setPosition(cc.p(textureSize.width/2,textureSize.height/2))  
  
--     maskSprite:setBlendFunc(cc.blendFunc(GL_ONE,GL_ZERO))  
--     textureSprite:setBlendFunc(cc.blendFunc(GL_DST_ALPHA,GL_ZERO))  
  
--     renderTexture:begin()  
--     maskSprite:visit()  
--     textureSprite:visit()  
--     renderTexture:endToLua()  
  
--     local retSprite = cc.Sprite:createWithTexture(renderTexture:getSprite():getTexture())  
--     retSprite:setFlippedY(true)  
--     return retSprite  
-- end


----
--cc.exports.display = display or {}  
  
function createMaskedSprite(srcFile, maskFile)  
    local src = display.newSprite(srcFile)  
    local mask = display.newSprite(maskFile)  
  
    local size_src = src:getContentSize()  
    local size_mask = mask:getContentSize()  
  
    local canva = cc.RenderTexture:create(size_src.width, size_src.height, cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)  
      
    local ratiow = size_src.width / size_mask.width  
    local ratioh = size_src.height / size_mask.height  
    mask:setScaleX(ratiow)  
    mask:setScaleY(ratioh)  
  
    mask:setPosition(size_src.width / 2, size_src.height / 2)  
    src:setPosition(size_src.width / 2, size_src.height / 2)  
  
    local blendfunc_mask = cc.blendFunc(gl.ONE, gl.ZERO)  
    mask:setBlendFunc(blendfunc_mask)  
    local blendfunc_src = cc.blendFunc(gl.DST_ALPHA, gl.ZERO)  
    src:setBlendFunc(blendfunc_src)  
  
    canva:begin()  
    mask:visit()  
    src:visit()  
    canva:endToLua()  
  
    local masked_sprite = cc.Sprite:createWithTexture(canva:getSprite():getTexture())  
    masked_sprite:setFlippedY(true)  
    return masked_sprite  
end  
  
function createCircleSprite(srcFile, maskFile)  
    local src = display.newSprite(srcFile)  
    local mask = display.newSprite(maskFile)  
  
    local size_src = src:getContentSize()  
    local size_mask = mask:getContentSize()  
  
    local canva = cc.RenderTexture:create(size_mask.width, size_mask.height, cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)  
      
    local ratiow = size_mask.width / size_src.width  
    local ratioh = size_mask.height / size_src.height  
    src:setScaleX(ratiow)  
    src:setScaleY(ratioh)  
  
    mask:setPosition(size_mask.width / 2, size_mask.height / 2)  
    src:setPosition(size_mask.width / 2, size_mask.height / 2)  
  
    local blendfunc_mask = cc.blendFunc(gl.ONE, gl.ZERO)  
    mask:setBlendFunc(blendfunc_mask)  
    local blendfunc_src = cc.blendFunc(gl.DST_ALPHA, gl.ZERO)  
    src:setBlendFunc(blendfunc_src)  
  
    canva:begin()  
    mask:visit()  
    src:visit()  
    canva:endToLua()  
  
    local masked_sprite = cc.Sprite:createWithTexture(canva:getSprite():getTexture())  
    masked_sprite:setFlippedY(true)  
    return masked_sprite  
end 

-- "soul":{
--             "Lv":1,
--             "atk":50,
--             "hp":108,
--             "exp":0,
--             "exp_max":100,
--             "add_atk":0,
--             "break_count":0,
--             "state":1,
--             "skills":{

--             },
--             "Lv_max":50,
--             "add_hp":0
--         },

function RoleInfoView:refreshSoulEquip()
    if self.hero_data ~= nil then
        print("RoleInfoView:refreshSoulEquip == has Data")
        if self.hero_data.soul == nil then
            print("RoleInfoView:refreshSoulEquip == no soul")
            -- --假数据
            -- local tdata = {}
            
            -- tdata.Lv = 1
            -- tdata.atk = 0
            -- tdata.hp = 0
            -- tdata.exp = 48
            -- tdata.exp_max = 295
            -- tdata.add_atk = 0
            -- tdata.break_count = 1
            -- tdata.state = 1
            -- tdata.Lv_max = 1
            -- tdata.add_hp = 1
            -- tdata.skills = {
            --     4013101,
            --     4013101,
            --     4013101,
            --     4013101,
            --     4013101,
            -- }
            -- self.hero_data.soul = tdata
            --self:refreshExclusiveStoryBtn()
            self.btnExclusiveStory:setVisible(false)
        else
            print("RoleInfoView:refreshSoulEquip == has soul")
            self:refreshExclusiveStoryBtn()
        end
    else
        --无数据
        print("RoleInfoView:refreshSoulEquip == No Data")
    end
    
end

--- 以下为装备相关
function RoleInfoView:refreshEquip()
    -- self.curEquipIndex = nil
    -- self.eqDetailPanel:setVisible(false)
    if self.hero_data then 
        for i = 1,3 do  
            local eqdata = self.hero_data.eq[""..i]
            local eqview = self["equipView"..i]
            if eqdata["eq_id"] == "lock" then
                --锁定
                eqview.panelInfo:setVisible(false)
                eqview.panelNoOpen:setVisible(true)
            elseif eqdata["eq_id"] == "" then
                --未装备
                eqview.panelNoOpen:setVisible(false)
                eqview.panelInfo:setVisible(false)
            else
                eqview.panelNoOpen:setVisible(false)
                eqview.panelInfo:setVisible(true)

                local eqinfo = eqdata["eq_info"]

                eqview.lbAtk:setString(eqinfo["atk"])
                eqview.lbHP:setString(eqinfo["hp"])
                eqview.lbLevel:setString(string.format(UITool.ToLocalization("等级 %d"),eqinfo["Lv"]))

                local enumid = getNumID(eqdata["eq_id"])
                -- eqview.lbDesc:setString(equip[enumid]["equip_skill"]["skill_name"])
                -- eqview.eskIcon:setTexture(equip[enumid]["equip_skill"]["skill_img"])
                eqview.lbSkillLv1:setString("LV "..eqinfo["skOne_Lv"])
                eqview.eskIcon1:setTexture(equip[enumid]["equip_skill"]["skill_img"])

                if equip[enumid]["is_there_sk_two"] == 0 then
                    if eqview.skillPanel2 then
                        eqview.skillPanel2:setVisible(false)
                    end
                else
                    eqview.lbSkillLv2:setString("LV "..eqinfo["skTwo_Lv"])
                    local skill_two_icon = passive_sk[eqinfo["provide_sk_id"]]["sk_icon"]
                    eqview.eskIcon2:setTexture(skill_two_icon)

                    if eqview.skillPanel2 then
                        eqview.skillPanel2:setVisible(true)
                    end
                end

                eqview.lbName:setString(UITool.getUserLanguage(equip[enumid].equip_name))--(equip[enumid].equip_name)

                
                eqview.imgRarity:setTexture( Rarity_Icon[equip[enumid].equip_rank] ) --外框

                eqview.imgBG:setTexture( Rarity_E_BG[equip[enumid].equip_rank])   --背景
                eqview.imgElement:setTexture( ATB_Icon[equip[enumid].equip_atb]) --属性球

                eqview.imgFace:setTexture(equip[enumid].equip_list_icon)
            end
        end
    else
        for i = 1,3 do  
            local eqview = self["equipView"..i]

            eqview.panelNoOpen:setVisible(false)
            eqview.panelInfo:setVisible(false)
        end


    end
    self:refreshEquipDetail()
end

--刷新装备详情
function RoleInfoView:refreshEquipDetail()
    if not self.curEquipIndex then
        self.eqDetailPanel:setVisible(false)
        return
    end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]



    -- for i = 1,4 do
    --     self["eqAwk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
    -- end

    if eqdata["eq_id"] == "lock" 
        or eqdata["eq_id"] == "" 
        or user_info["eq"] == nil 
        or user_info["eq"][eqdata.eq_id] == nil then

        self.curEquipIndex = nil
        self.eqDetailPanel:setVisible(false)
    else

        local equip_data = user_info["eq"][eqdata.eq_id]
        self.vCurShowDetailEqData = user_info["eq"][eqdata.eq_id]

        local e_id_num = getNumID( eqdata.eq_id )

        self.eqBG:setTexture(Rarity_E_BG[equip_data["rarity"]])
        self.eqIcon:setTexture(equip[e_id_num].equip_list_icon)
        self.eqFrame:setTexture(Rarity_Icon[equip_data["rarity"]])
        self.eqElement:setTexture(ATB_Icon[equip_data["element"]])

        self.eqName:setString(UITool.getUserLanguage(equip[e_id_num].equip_name))--(equip[e_id_num].equip_name)


        self.eqAtk:setString(equip_data["atk"])
        self.eqHP:setString(equip_data["hp"])

        local eqlv = equip_data["Lv"]
        local eqlvmax = equip_data["Lv_max"]

        -- self.eqLv:setString("等级 "..eqlv)
        -- self.eqMaxLv:setString("等级上限 "..eqlvmax)
        self.eqMaxLv:setString(eqlv.."/"..eqlvmax)

        if eqlv >= eqlvmax then
            --满级
            -- self.eqExpNext:setString("")
            self.eqExpBar:setPercent(100)
        else
            -- self.eqExpNext:setString("离下一级："..(equip_data.exp_max - equip_data.exp))
            self.eqExpBar:setPercent(100 * equip_data.exp / equip_data.exp_max)
        end

        -- 一技能
        self.eqSkName1:setString(UITool.getUserLanguage(equip[e_id_num]["equip_skill"]["skill_name"]))--(equip[e_id_num]["equip_skill"]["skill_name"])
        self.eqSkLv1:setString(UITool.ToLocalization("等级: ")..equip_data["sk"]["Lv"])
        self.eqSkIcon1:setTexture(equip[e_id_num]["equip_skill"]["skill_img"])

        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(equip[e_id_num]["equip_skill"]["skill_des"])--equip[e_id_num]["equip_skill"]["skill_des"]
        str_des = UITool.stringForEqSK(str_des,equip_data["sk"]["add_atk_rate"])
        self.eqSkDesc1:setString(str_des)

        -- 二技能
        if equip[e_id_num]["is_there_sk_two"] == 0 then
            self.eqSkNo2:setVisible(true)
            self.eqSkName2:setVisible(false)
            self.eqSkLv2:setVisible(false)
        else
            self.eqSkNo2:setVisible(false)
            self.eqSkName2:setVisible(true)
            self.eqSkLv2:setVisible(true)

            local skill_two_name = UITool.getUserLanguage(passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_name"])--passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_name"]
            local skill_two_icon = passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_icon"]
            self.eqSkName2:setString(skill_two_name)
            self.eqSkLv2:setString(UITool.ToLocalization("等级: ")..equip_data["sk_two"]["Lv"])
            self.eqSkIcon2:setTexture(skill_two_icon)

            --技能描述-当前等级
            local str_des = UITool.getUserLanguage(passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_det_des"])--passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_det_des"]
            self.eqSkDesc2:setString(str_des)
            --
        end


        self.eqDetailPanel:setVisible(true)

        for i = 1,2 do
            local prsk = self["eqSkPrsk"..i]
            if equip_data["rsk"] ~= nil and equip_data["rsk"][i] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[equip_data["rsk"][i][1]])--eq_random_sk[equip_data["rsk"][i][1]]
                strsrc = string.gsub(strsrc,"%*",""..(equip_data["rsk"][i][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end

        local break_count = equip_data["brk_num"]
        for i = 1,4 do
            if break_count>= i then
                --self["eqAwk"..i]:setTexture("n_UIShare/equip/info/ggsc_ui_145.png")
                self["eqAwk"..i]:setVisible(true)
            else
                --self["eqAwk"..i]:setTexture("n_UIShare/equip/info/ggsc_ui_146.png")
                self["eqAwk"..i]:setVisible(false)
            end
        end

        self:setEquipNodeLockState()
    end
end

function RoleInfoView:onClickEquip(index)
    if  self.hero_data == nil
        or index > 3 
        or index < 0 
        or index == nil then

        self.curEquipIndex = nil
        self:refreshEquipDetail()
    else

        local eqdata = self.hero_data.eq[""..index]

        if eqdata["eq_id"] == "lock" then
            self.curEquipIndex = nil
            self:refreshEquipDetail()
        elseif eqdata["eq_id"] == "" then
            self.curEquipIndex = nil
            if g_channel_control.b_newEqBag then
                self:loadEquipList(function()
                    self:showEquipList(index)
                end,0)
            else
                if self.eqlistLoaded then
                    self:showEquipList(index)
                else
                    self:loadEquipList(function()
                        self:showEquipList(index)
                    end)
                end
            end

        elseif self.curEquipIndex == index then
                --点的同一个
            self.curEquipIndex = nil 
            self:refreshEquipDetail()
        else
            self.curEquipIndex = index
            if g_channel_control.b_newEqBag then
                self:loadEquipList(function()
                    self:refreshEquipDetail()
                end,1)
            else
                if self.eqlistLoaded then
                    self:refreshEquipDetail()
                else
                    self:loadEquipList(function()
                        self:refreshEquipDetail()
                    end)
                end
            end
        end
    end

end

function RoleInfoView:loadEquipList(callback,nEquiped)
    local nCurEquiped = nEquiped or 0
    local tempData = {}
    if g_channel_control.b_newEqBag then
        tempData = { 
            rpc = "eq_list",
            rarity = {3,4,5},
            element = {1,2,3,4,5,0},
            brk_num = {1,2,3,4,0},
            key = "element",
            reverse = 0,
            equipped = nCurEquiped,
        }
    else
        tempData = { 
            rpc = "eq_list"
        }
    end
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        DataManager:rfsElist()   
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end

        self.eqlistLoaded = true

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleInfoView:onClickSoulEquip()
    if self.hero_data == nil then
        print("RoleInfoView:onClickSoulEquip == hero_data == nil")
    else
        if user_info["rank"] < 7 then -- 判断等级限制因素，低于7级不显示
            return
        else
            if self.hero_data.soul.state == 3 then
                --魂灵装已解锁,调魂灵装界面
                --已解锁
                --self:loadBagList()
                local sData = {tab = 1,nHero_id = self.hero_id}
                sData["sDelegate"] = self
                sData["sFunc"] =  self.ReLoadInfoBySoul
                SceneManager:toSoulEquipLayer(sData)
            elseif self.hero_data.soul.state == 2 then
                --预留动画过程，不处理
                return
            elseif self.hero_data.soul.state == 1 then
                --魂灵装已开放但未解锁,跳转剧情列表界面
                --专属剧情已开放(需判断是否有专属剧情：男主目前没有)
                local h_id_num = getNumID(self.hero_id)
                if hero_soul[h_id_num].unlock_type == 2 then
                    GameManagerInst:alert(UITool.getUserLanguage(hero_soul[h_id_num].unlock_msg))--(hero_soul[h_id_num].unlock_msg)--提示解锁条件（目前只男主）
                else
                    self:onExcluSiveStory()
                end
            else
                --魂灵装未开放,不跳转
                return
            end

        end

        -- if self.hero_data["soul"]["state"] ~= 0 then
        --     if self.hero_data["soul"]["state"] == 3 then
        --         --已解锁
        --         local sData = {tab = 1,nHero_id = self.hero_id}
        --         SceneManager:toSoulEquipLayer(sData)
        --     else
        --         --开放未解锁
        --         self:switchView(4)
        --     end
            
        -- else
        --     print("RoleInfoView:onClickSoulEquip == 未开放")
        -- end
        
    end
    
end

function RoleInfoView:showEquipSkill()
    if not self.curEquipIndex then return end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]

    SceneManager:toEquipFromRole({rootNode = self:getRootNode(), tab = 1, eq_id = eqdata.eq_id, nEquiped = 1})
end

function RoleInfoView:showEquipSth()
    if not self.curEquipIndex then return end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]

    SceneManager:toEquipFromRole({rootNode = self:getRootNode(), tab = 2, eq_id = eqdata.eq_id , hideAllEquipBtn = true, nEquiped = 1})
   
end

function RoleInfoView:loadBagList(callback)
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
		DataManager:wAllBagData(data["bag"])
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleInfoView:onEqSkRnd()
    if not self.curEquipIndex then return end

    -- local mid = getMatID(ID_EQUIP_RSK)
    -- local cnt = user_info["bag"]["mat"][ID_EQUIP_RSK]
    -- if not cnt or cnt <= 0 then 
    --     GameManagerInst:alert(""..mat[mid].name.."不足")
    --     return
    -- end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]
    local equip_id = eqdata.eq_id    
    local equip_data = user_info["eq"][eqdata.eq_id]

    local needrefresh = false

    local view = EquipRskView.new():initWithData(equip_id,equip_data)
    view.updateInfoEvent = function(sender,data)
        self:refreshEquipDetail()
        needrefresh = true
    end

    view.beforeCloseEvent = function(sender)
        if needrefresh then
            self:loadInfo(true)
        end
    end
    GameManagerInst:showModalView(view)
end

function RoleInfoView:showEquipAwaken()
    if not self.curEquipIndex then return end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]

    SceneManager:toEquipFromRole({rootNode = self:getRootNode(), tab = 3, eq_id = eqdata.eq_id, nEquiped = 1})
end

function RoleInfoView:showEquipList(i)
    local index = i or self.curEquipIndex
    if not index then return end

    local eq_id = self.hero_data.eq[""..index].eq_id
    
    local b,v
    if g_channel_control.b_newEqBag then
        b,v = EquipListView.createWithBackBtn(0)
        v:ReLoadData()
    else
        b,v = EquipListView.createWithBackBtn()
    end
    self.changeCompareView = nil

    v.ItemResetEvent = function(item)
        local d = item:getData()
        if d.id == eq_id then
            item:showUnequip()
        end
    end

    v.ItemClickedEvent = function(item)
        local eqdata = item:getData()



        local function callback ()
            if b then
                b:returnBack()
            end
            self:sendChangeEquip(index,eqdata.id)
        end

        local function callbackCompare ()
            if eqdata.owner ~= "0" and eqdata.owner ~= self.hero_id then--选中装备已装备于别的角色
                local hid_cur = getNumID( self.hero_id )
                local hid_other = getNumID( eqdata.owner )
                local eid = getNumID( eqdata.id )

                local name_cur = UITool.getUserLanguage(hero[hid_cur].hero_name)--hero[hid_cur].hero_name
                local name_other = UITool.getUserLanguage(hero[hid_other].hero_name)--hero[hid_other].hero_name
            local name_eq = UITool.getUserLanguage(equip[eid].equip_name)..UITool.ToLocalization("(等级")..eqdata["Lv"]..")"--equip[eid].equip_name..UITool.ToLocalization("(等级")..eqdata["Lv"]..")"
                --GameManagerInst:confirm("是否从 "..name_other.." 身上卸下 "..name_eq.." ，为 "..name_cur.." 装上此灵装？",callback)
	 	local str = UITool.ToLocalization("是否从 %s 身上卸下 %s , 为 %s 装上此灵装")
            	GameManagerInst:confirm(string.format(str, name_other,name_eq,name_cur),callback)
            else
                callback()
            end
        end

        if eq_id ~= "" and eq_id ~= eqdata.id then--原槽中有装备且不是卸下操作（替换）
            local function callbackCancel ()
                self.changeCompareView:removeFromParentView()
                self.changeCompareView = nil
            end

            local function callbackSure ()
                callbackCompare()
                self.changeCompareView:removeFromParentView()
                self.changeCompareView = nil
            end

            if g_channel_control.b_newEqBag then
                self.changeCompareView = EquipChangeCompareView:initEx(self.vCurShowDetailEqData,eqdata,callbackCancel,callbackSure)
            else
                self.changeCompareView = EquipChangeCompareView:init(eq_id,eqdata.id,callbackCancel,callbackSure)
            end
            self:getRootNode():addChild(self.changeCompareView:getRootNode())
        else--原槽无装备情况下装备操作或原槽有装备情况下装备卸下操作
            callbackCompare()
        end
        --b:returnBack()
    end
    
    v.dataSourceEvent = function(sender,sortmode)
        local dataset = {}
        -- for i = 1,#equip_list do
        --     if equip_list[i]["owner"] == "0" or equip_list[i].id == eq_id then
        --         table.insert(dataset,table.deepcopy(equip_list[i]))
        --     end
        -- end
        -- SortBoxView.SortEquip (dataset, sortmode)

        if g_channel_control.b_newEqBag then
            -- dataset =  table.deepcopy(equip_list)
            -- EqSortBoxView.SortEquip (dataset, sortmode)
            ------优化方案
            local ds2 = {}
            for i = 1,#equip_list do
                if equip_list[i]["owner"] == "0" or equip_list[i].id == eq_id then
                    table.insert(dataset,table.deepcopy(equip_list[i]))
                else
                    table.insert(ds2,table.deepcopy(equip_list[i]))
                end
            end
            EqSortBoxView.SortEquip (dataset, sortmode)
            EqSortBoxView.SortEquip (ds2, sortmode)
            for j = 1,#ds2 do
                table.insert(dataset,ds2[j])
            end
            ------
        else
            ------优化方案
            local ds2 = {}
            for i = 1,#equip_list do
                if equip_list[i]["owner"] == "0" or equip_list[i].id == eq_id then
                    table.insert(dataset,table.deepcopy(equip_list[i]))
                else
                    table.insert(ds2,table.deepcopy(equip_list[i]))
                end
            end
            SortBoxView.SortEquip (dataset, sortmode)
            SortBoxView.SortEquip (ds2, sortmode)
            for j = 1,#ds2 do
                table.insert(dataset,ds2[j])
            end
            ------
        end

        return dataset
    end

    v:refresh()
    self:getRootNode():addChild(b:getRootNode())
    
end

--新手引导
function RoleInfoView:newGuideRoleInfoFunc()
    --新手引导 编队
    self:sendChangeEquip(1, self.ng_needId )
    if self.ng_b ~= nil then
        self.ng_b:returnBack()
    end
    --self.ng_b:removeFromParentView()
    --self:onClickEquip(1)--隐藏左边显示的装备信息
end

function RoleInfoView:sendChangeEquip(pos,eid)
    --一键卸装时pos为0，暂不处理
    local strpos = ""..pos
    local eqdata = self.hero_data.eq[strpos]

    local tempTable = nil
    local successFunc = nil

    if eqdata.eq_id == eid then
        --卸下
	    tempTable = {
            ["rpc"]     = "eq_unload",
            ["hero_id"] = self.hero_id,
            ["slot"]    = strpos,
	    }
        
        successFunc = function(data)
            --success
            DataManager:modEqiupUnload(self.hero_id,strpos,data)
            self.curEquipIndex = nil
            self:loadInfo(true)
        end
    else
        --装备
        tempTable = {
            ["rpc"] = "eq_use",
            ["eq_id"] = eid,
            ["hero_id"] = self.hero_id,
            ["slot"] = strpos
        }

        successFunc = function(data)
            --success
            --烫烫烫烫烫 发现接口BUG
            if g_channel_control.b_newEqBag then
                for k,v in pairs(data["hero"]) do
                    print(k,v)
                    user_info["hero"][k] = v
                end
                DataManager:rfsHlist()
            else
                DataManager:modEqiupUse(self.hero_id,strpos,eid,data)
            end
            
            --self.hero_data = data["hero"][self.hero_id]
            self.curEquipIndex = pos
            self:loadInfo(true)
            --self:refresh()
        end
    end

    GameManagerInst:rpc(tempTable,3,
    successFunc
    ,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    true)
end
---以上为装备相关

---以下为技能相关
function RoleInfoView:refreshSkill()
    -- self.pSkillAdd:setVisible(false)
    -- self.pSkillNormal:setVisible(true)
    
    if self.hero_data then         

        self.spLeft:setString(self.hero_data.tp.num)
        self.btnTab2Tip:setVisible(self.hero_data.tp.num > 0)

        local ask1 = self.hero_data.active_sk["1"]  --主动技能
        local ask2 = self.hero_data.active_sk["2"]  --主动技能
        local psk1 = self.hero_data.passive_sk["1"]  --被动技能
        local psk2 = self.hero_data.passive_sk["2"]  --被动技能

        local skills = {ask1,ask2}

        for i = 1,2 do
            local v = self["skillView"..i]
            
            --[3] = skill[skill_info["id"]]["skill_des"], 255 192 00

            v.skillIcon:setVisible(true)
            v.skillIcon:setTexture(skill[skills[i].id].skill_icon)
            v.skillName:setString(UITool.ToLocalization("主动 ")..UITool.getUserLanguage(skill[skills[i].id].skill_name))--(UITool.ToLocalization("主动 ")..skill[skills[i].id].skill_name)
            v.skillName:setTextColor(RoleInfoView.SKILL_COLOR)
            v.skillCD:setString(""..skill[skills[i].id].skill_cd..UITool.ToLocalization("秒"))
            v.skillCDText:setVisible(true)
            v.skillLevel:setString(""..skills[i].lv)
            v.skillMaxLevel:setString(""..skills[i].max_lv)

            if skills[i].lv >= skills[i].max_lv then
                v.skillLevel:setTextColor(v.skillMaxLevel:getTextColor())
            else
                v.skillLevel:setTextColor(cc.c3b(255,255,255))
            end

            v.skillDesc:setString(UITool.getUserLanguage(skill[skills[i].id].skill_des))--(skill[skills[i].id].skill_des)
            v.btnAdd:setVisible(false)
            v.skFromEquip:setVisible(false)
        end

        skills={psk1,psk2}

        for i = 1,2 do
            local v = self["skillView"..(i+2)]
            --[3] = passive_sk[skill_info["id"]]["sk_des"], 8 225 251  --  

            v.skillIcon:setVisible(true)
            v.skillIcon:setTexture(passive_sk[skills[i].id].sk_icon)
            v.skillName:setString(UITool.ToLocalization("被动 ")..UITool.getUserLanguage(passive_sk[skills[i].id].sk_name))
            v.skillName:setTextColor(RoleInfoView.PSKILL_COLOR)
            v.skillCD:setString("")
            v.skillCDText:setVisible(false)
            v.skillLevel:setString(""..skills[i].lv)
            v.skillMaxLevel:setString(""..skills[i].max_lv)

            if skills[i].lv >= skills[i].max_lv then
                v.skillLevel:setTextColor(v.skillMaxLevel:getTextColor())
            else
                v.skillLevel:setTextColor(cc.c3b(255,255,255))
            end 

            v.skillDesc:setString(UITool.getUserLanguage(passive_sk[skills[i].id].sk_des))--(passive_sk[skills[i].id].sk_des)
            v.btnAdd:setVisible(false)
            v.skFromEquip:setVisible(false)

        end
    else
        --无数据
        for i = 1,4 do
            local v = self["skillView"..i]
            v.skillIcon:setVisible(false)
            v.skillName:setString("")
            v.skillCD:setString("")
            v.skillCDText:setVisible(false)
            v.skillLevel:setString("0")
            v.skillLevel:setTextColor(cc.c3b(255,255,255))
            v.skillMaxLevel:setString("10")
            v.skillDesc:setString("")
            v.btnAdd:setVisible(false)
            v.skFromEquip:setVisible(false)
        end

        self.btnTab2Tip:setVisible(false)
        self.spLeft:setString(0)
    end
end

function RoleInfoView:loadTeamList(callback)
    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success

        DataManager:wTeamData(data["team"])

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

--额外技能点
function RoleInfoView:onSkillBuySP()
    if not self.hero_data then return end
    if self.galleryMode ~= 2 then return end

    if self.hero_data.tp.from_other >= 10 then
        GameManagerInst:alert(UITool.ToLocalization("技能点已扩充至上限"))
    else
        local view = RoleInfoAddSPView.new():init()
        view.addSpEvent = function(sender,matCount)
            self:OnAddSp(matCount)
            sender:returnBack()
        end
        view:loadData(self.hero_data.tp.from_other)
        GameManagerInst:showModalView(view)
    end
end

--重置技能
function RoleInfoView:onSkillReset()
    if not self.hero_data then return end

    local tempTable = {
        ["rpc"] = "hero_sk_reset",
        ["hero_id"]=self.hero_id
    }
    
    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        for k,v in pairs(data["hero_info"]) do
            self.hero_data[k] = v
        end
        user_info["gold"] = data["gold"]
        self:onSkillCancel()
        self:loadInfo(true)
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

--确认加点
function RoleInfoView:onSkillCommit()
    if not self.hero_data then return end

    local skTable = {}
    local reyun_str = ""
    for i = 1,4 do
        skTable[i] = self.skillAddInfo.nums[i].cur
        reyun_str = reyun_str..self.skillAddInfo.nums[i].cur..","
    end
    local tempTable = {
        ["rpc"] = "hero_sk_lv_up",
        ["hero_id"]=self.hero_id,
        ["sk_lv"] = skTable
    }
    
    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        for k,v in pairs(data["hero_info"]) do
            self.hero_data[k] = v
        end
        self:onSkillCancel()
        self:loadInfo(true)
        --结束加点新手引导
        print(" --结束加点新手引导")
        if  NewGuideManager.isStartWeakGuide and  NewGuideManager._nowGuideID == guide_id_config.RoleSkill then
            local function dealEndReq()
                NewGuideManager:startSubGuide(self,9)
            end
            NewGuideManager:reqSoftGuidePass(dealEndReq)
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

--取消加点
function RoleInfoView:onSkillCancel()
    if not self.hero_data then return end

    self.pSkillAdd:setVisible(false)
    self.pSkillNormal:setVisible(true)
    self.panelClose:setVisible(true)
    self.panelRightBtn:setVisible(true)
    --self.skDescPanel:setVisible(true)

    if self.other_ids then        
        self.btnPrevHero:setVisible(true)
        self.btnNextHero:setVisible(true)
    end

    self.skillAddInfo = nil 
    
    self.curSkDescIdx = nil
    self.skDesc:setVisible(false)
    self:refreshSkill()
end
--技能加点
function RoleInfoView:onSkillAdd(index)
    if self.skillAddInfo.alltp == 0 then
        return
    end

    local temp = self.skillAddInfo.nums[index]
    temp.cur = temp.cur + 1
    if temp.cur > temp.max then
        temp.cur = temp.max
    else
        self.skillAddInfo.alltp = self.skillAddInfo.alltp - 1
    end
    
    self.spLeft:setString(self.skillAddInfo.alltp)

    local v = self["skillView"..index]
    v.skillLevel:setString(""..temp.cur)
    if index == 1 or index == 2 then
        v.skillDesc:setString(UITool.getUserLanguage(skill[temp.sid + temp.cur].skill_des))--(skill[temp.sid + temp.cur].skill_des)
    else
        v.skillDesc:setString(UITool.getUserLanguage(passive_sk[temp.sid + temp.cur].sk_des))--(passive_sk[temp.sid + temp.cur].sk_des)
    end
    self.curSkDescIdx = nil
    self:onShowSkillDesc(index)
end

--展示详情
function RoleInfoView:onShowSkillDesc(idx)
    if not self.hero_data then return end

    if self.curSkDescIdx == idx then
        self.curSkDescIdx = nil
        self.skDesc:setVisible(false)
    else
        self.curSkDescIdx = idx
        self.skDesc:setVisible(true)

        local skId = nil
        if self.skillAddInfo then
            local temp = self.skillAddInfo.nums[idx]
            skId = temp.sid + temp.cur
        end

        local posNode = self["skDescPos"..idx]

        local pos_x,pos_y = posNode:getPositionX(),posNode:getPositionY()
        self.skDesc:setPosition(pos_x,pos_y)

        if idx < 3 and idx > 0 then
            local sid = self.hero_data.active_sk[""..idx].id
            if skId then
                sid = skId
            end
            self.skDescTitle:setString(UITool.ToLocalization("主动技能：")..UITool.getUserLanguage(skill[sid].skill_name))--(UITool.ToLocalization("主动技能：")..skill[sid].skill_name)
            self.skDescTitle:setTextColor(RoleInfoView.SKILL_COLOR)
            self.skDescDetail:setString(UITool.getUserLanguage(skill[sid].sk_det_des))--(skill[sid].sk_det_des)    
            self.skDescCD:setVisible(true)
            self.skDescCD:setString(""..skill[sid].skill_cd..UITool.ToLocalization("秒"))
            self.skDescCDText:setVisible(true)  

        elseif idx > 2 and idx < 5 then
            local psid = self.hero_data.passive_sk[""..(idx - 2)].id
            if skId then
                psid = skId
            end
            self.skDescTitle:setString(UITool.ToLocalization("被动技能：")..UITool.getUserLanguage(passive_sk[psid].sk_name))
            self.skDescTitle:setTextColor(RoleInfoView.PSKILL_COLOR)
            self.skDescDetail:setString(UITool.getUserLanguage(passive_sk[psid].sk_det_des))--(passive_sk[psid].sk_det_des)      
            self.skDescCD:setVisible(false)
            self.skDescCDText:setVisible(false)  
        end
    end
end

--开始加点
function RoleInfoView:onSkillStartAdd()
    if not self.hero_data then return end


    local ask1 = self.hero_data.active_sk["1"]  --主动技能
    local ask2 = self.hero_data.active_sk["2"]  --主动技能
    local psk1 = self.hero_data.passive_sk["1"]  --被动技能
    local psk2 = self.hero_data.passive_sk["2"]  --被动技能

    local sss = {ask1,ask2,psk1,psk2}
    self.skillAddInfo = {}
    self.skillAddInfo.alltp = self.hero_data.tp.num
    self.skillAddInfo.nums = {}
    
    
    for i = 1,4 do
        local v = self["skillView"..i]
        v.btnAdd:setVisible(true)
        self.skillAddInfo.nums[i] = {
            sid = math.floor(sss[i].id / 100) * 100,
            cur = sss[i].lv,
            max = sss[i].max_lv
        }
    end

    -- self.curSkDescIdx = nil
    -- self.skDesc:setVisible(false)

    self.pSkillAdd:setVisible(true)
    self.pSkillNormal:setVisible(false)
    self.panelClose:setVisible(false)
    self.panelRightBtn:setVisible(false)
    --self.skDescPanel:setVisible(false)

    self.btnPrevHero:setVisible(false)
    self.btnNextHero:setVisible(false)

end
---以上为技能相关

-- 魂灵装故事剧情相关添加 Start

function RoleInfoView:ReLoadInfoBySoul()
    self:loadInfo(true)
end

--专属剧情按钮回调
function RoleInfoView:onExcluSiveStory()
    local sData = {}
    sData.nHeroId = tonumber(getNumID(self.hero_id))
    sData["sDelegate"] = self
    sData["sFunc"] =  self.ReLoadInfoBySoul
    sData["hid"] = self.hero_id
    sData["hList"] = self.other_ids
    sData["team_id"] = self.team_id
    SceneManager:toExclusiveStoryListLayer(sData)
    
end

function RoleInfoView:refreshExclusiveStoryBtn()
    if not self.hero_data.soul then
        return
    end

    self:SetExclusiveStoryBtn(0)

    if user_info["rank"] < 7 or g_channel_control.roleInfoView_hideExclusiveStory == true then -- 判断等级限制因素，低于7级不显示
        self:SetExclusiveStoryBtn(0)
    else
        if self.hero_data.soul.state == 0 then
            --魂灵装未开放,不显示按钮
            self:SetExclusiveStoryBtn(0)
        else
            --魂灵装已开放,
            --专属剧情已开放(需判断是否有专属剧情决定是否显示按钮：男主目前没有) 
            local h_id_num = getNumID(self.hero_id)
            if hero_soul[h_id_num].unlock_type == 2 then
                self:SetExclusiveStoryBtn(0)
            else
                self:SetExclusiveStoryBtn(1)
            end
        end

    end

end

function RoleInfoView:SetExclusiveStoryBtn(bOpen)
    self.spExclusiveStoryNoOpen:setVisible(false)
    
    if bOpen == 0 then
        self.btnExclusiveStory:setVisible(false)
        self.btnExclusiveStory:setTouchEnabled(false)
    elseif bOpen == 1 then
        self.btnExclusiveStory:setVisible(true)
        self.btnExclusiveStory:setTouchEnabled(true)
    end
end
-- 魂灵装故事剧情相关添加 End

function RoleInfoView:swithModelAction()
    if not self.skeletonNode then return end

    local time_id = getTimeNumID( self.hero_id )
    if time_id == 0 then return end

    if self.modelActionIndex == 1 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "run", true)  
    elseif self.modelActionIndex == 2 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "attack", false)
        self.skeletonNode:addAnimation(1, "loading", true) 
    elseif self.modelActionIndex == 3 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "singleattack", false)
        self.skeletonNode:addAnimation(1, "loading", true)   
    elseif self.modelActionIndex == 4 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "bigskill", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 5 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "up1", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 6 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "up2", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 7 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "behit", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 8 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "float", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 9 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "dead", false)
        self.skeletonNode:addAnimation(1, "loading", true) 
   end
    self.modelActionIndex = self.modelActionIndex + 1
    if self.modelActionIndex > 4 then
        self.modelActionIndex = 1
    end
end

function RoleInfoView:refreshState()
    if self.hero_data then
        --有数据        
        local h_id_num = getNumID( self.hero_id )
        local time_id = getTimeNumID( self.hero_id )

        --[[if not self.skeletonNode then
            local id_str = hero[h_id_num].hero_bat
            local end_pos = string.find(id_str,'atlas') - 1
            local spName = string.sub(id_str,0,end_pos)
            
            cc.Director:getInstance():getTextureCache():removeUnusedTextures()
            cc.Texture2D:setDefaultAlphaPixelFormat(cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A4444)
            self.skeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            cc.Texture2D:setDefaultAlphaPixelFormat(cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)

            local prmsize = self.pRoleModel:getSize()
            self.pRoleModel:addChild(self.skeletonNode)
            self.skeletonNode:setPosition(prmsize.width/2, 0)
            self.skeletonNode:setAnimation(1, "loading", true)

            self.modelActionIndex = 1

            if time_id == 0 then
                self.skeletonNode:setColor(cc.c3b(0,0,0))
            end
        end]]

        --突破次数
        local break_count = self.hero_data.break_count
        for i = 1,4 do
            if break_count>= i then
                self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_145.png")
            else
                self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
            end
        end
        self.awkNum:setString(break_count.."/4")

        --等级
        local lvcur = self.hero_data.Lv
        local lvmax = self.hero_data.Lv_max
        self.lbCurLv:setString(string.format(UITool.ToLocalization("等级 %d"),lvcur))
        self.lbMaxLv:setString(string.format(UITool.ToLocalization("等级上限 %d"),lvmax))

        if lvcur >= lvmax  then  --已经满级
            self.barExp:setPercent(100)
            self.lbExpNext:setString("")
        else
            self.barExp:setPercent(100 * self.hero_data.exp / self.hero_data.exp_max)
            self.lbExpNext:setString(string.format(UITool.ToLocalization("离下一级：%d"),(self.hero_data.exp_max - self.hero_data.exp)))
        end
        --属性
        if self.hero_data.fp_all.atk > self.hero_data.atk then
            local patkadd = getRoleATKPrent(self.hero_data.fp_all.atk)

            self.barAtkAdd:setPercent(patkadd * 100)
            self.barAtk:setPercent( self.hero_data.atk / self.hero_data.fp_all.atk * patkadd * 100)
        else
            self.barAtkAdd:setPercent(0)
            self.barAtk:setPercent( getRoleATKPrent(self.hero_data.atk) * 100)
        end

        if self.hero_data.fp_all.hp > self.hero_data.hp then
            local phpadd = getRoleATKPrent(self.hero_data.fp_all.hp)

            self.barHPAdd:setPercent(phpadd * 100)
            self.barHP:setPercent(self.hero_data.hp / self.hero_data.fp_all.hp * phpadd * 100)  
        else
            self.barHPAdd:setPercent(0)
            self.barHP:setPercent( getRoleATKPrent(self.hero_data.hp) * 100)  
        end   

        --重复抽卡加成，变色
        local tempTextColor = cc.c3b(255,255,255)
        local titlename = ""
        if self.hero_data.hero_add > 0 then
            for i = 1,#color_hero_bouns do
                local coloritem = color_hero_bouns[i]
                if self.hero_data.hero_add >= coloritem[1] then
                    tempTextColor = cc.c3b(coloritem[2], coloritem[3], coloritem[4])                    
                    if string.len(title_hero_conf[h_id_num]["title"][i]) > 0 then
                        titlename = title_hero_conf[h_id_num]["title"][i].." "
                    else
                        titlename = ""
                    end
                end
            end

            self.roleBtnPropText:setString("+"..self.hero_data.hero_add)
        else
            self.roleBtnPropText:setString("+0")
        end

        self.roleName:setString(UITool.getUserLanguage(titlename)..UITool.getUserLanguage(hero[h_id_num].hero_name))
        self.roleName:setTextColor(tempTextColor)
        if titlename ~= "" and g_channel_control.transform_RoleInfoView_roleName_fontSize == true then
            self.roleName:setFontSize(32)
        end
        self.numAtk:setTextColor(tempTextColor)
        self.numHP:setTextColor(tempTextColor)
        self.numProp1:setTextColor(tempTextColor)
        self.numProp2:setTextColor(tempTextColor)
        self.numProp3:setTextColor(tempTextColor)
        self.numProp4:setTextColor(tempTextColor)
        self.numProp5:setTextColor(tempTextColor)
        --


        self.numAtk:setString(self.hero_data.atk)
        self.numHP:setString(self.hero_data.hp)
        self.numProp1:setString(self.hero_data.crit.."%")       --暴击
        self.numProp2:setString(self.hero_data.hel)             --回复
        self.numProp3:setString(self.hero_data.crit_dmg.."%")   --爆伤
        self.numProp4:setString(self.hero_data.def)             --防御
        self.numProp5:setString(self.hero_data.asp/1000)        --攻速

        local temp_data = {
            {   
                num1 = self.hero_data.fp_all.atk,
                num2 = self.hero_data.atk,
                uiobj = self.numAtkAdd, 
                numFunc = function(num)
                    if num ~= 0 then
                        return string.format("%+d",num) 
                    else
                        return ""
                    end
                end 
            },
            {   
                num1 = self.hero_data.fp_all.hp,
                num2 = self.hero_data.hp,
                uiobj = self.numHPAdd, 
                numFunc = function(num)
                    if num ~= 0 then
                        return string.format("%+d",num) 
                    else
                        return ""
                    end
                end 
            },
            {   
                num1 = self.hero_data.fp_all.crit,
                num2 = self.hero_data.crit,
                uiobj = self.numProp1Add, 
                numFunc = function(num)
                    if num ~= 0 then
                        return string.format("%+d%%",num) 
                    else
                        return ""
                    end
                end 
            },
            {   
                num1 = self.hero_data.fp_all.hel,
                num2 = self.hero_data.hel,
                uiobj = self.numProp2Add, 
                numFunc = function(num) 
                    if num ~= 0 then
                        return string.format("%+d",num) 
                    else
                        return ""
                    end
                end 
            },
            {   
                num1 = self.hero_data.fp_all.crit_dmg,
                num2 = self.hero_data.crit_dmg,
                uiobj = self.numProp3Add, 
                numFunc = function(num)
                    if num ~= 0 then
                        return string.format("%+d%%",num) 
                    else
                        return ""
                    end
                end 
            },
            {   
                num1 = self.hero_data.fp_all.def,
                num2 = self.hero_data.def,
                uiobj = self.numProp4Add, 
                numFunc = function(num) 
                    if num ~= 0 then
                        return string.format("%+d",num) 
                    else
                        return ""
                    end
                end 
            },
            {   
                num1 = self.hero_data.fp_all.asp,
                num2 = self.hero_data.asp,
                uiobj = self.numProp5Add, 
                numFunc = function(num) 
                    if num ~= 0 then
                        return string.format("%+.2f",(num/1000))
                    else
                        return ""
                    end
                end 
            },
        }

        for i = 1,#temp_data do
            local t_data = temp_data[i]
            if t_data.num1 then
                local t_num = t_data.num1 - t_data.num2
                t_data.uiobj:setString(t_data.numFunc(t_num))
            end
        end

        if g_channel_control.b_LikeState then
            --好感度
            local intimacyState = self.hero_data.like_feel_state.icon_state
            if intimacyState then
                local intimacy = like_state[intimacyState].icon_max
                if intimacy then
                    self.imgIntimacy:setTexture(intimacy)
                    self.imgIntimacy:setVisible(true)
                    self.imgIntimacyBg:setVisible(true)
                end
                self.btnIntimacy:setTouchEnabled(true)
                self.btnIntimacy:setVisible(true)
            end
        else
            self.imgIntimacy:setVisible(false)
            self.imgIntimacyBg:setVisible(false)
            self.btnIntimacy:setTouchEnabled(false)
            self.btnIntimacy:setVisible(false)
        end
    else
        for i = 1,4 do
            self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
        end

        for j = 1,5 do
            self["numProp"..j]:setString("")
            self["numProp"..j.."Add"]:setString("")
        end

        self.awkNum:setString("")
        if g_channel_control.RoleInfoView_stateAwkNumPos == true then
            self.awkNum:setPosition(cc.p(191,26))
        end
        self.lbCurLv:setString("")
        self.lbMaxLv:setString("")
        self.barExp:setPercent(0)
        self.lbExpNext:setString("")
        self.numAtk:setString("")
        self.numAtkAdd:setString("")
        self.numHP:setString("")
        self.numHPAdd:setString("")
        self.barAtk:setPercent(0)
        self.barHP:setPercent(0)  
        self.barAtkAdd:setPercent(0)
        self.barHPAdd:setPercent(0)
        --
        self.imgIntimacyBg:setVisible(false)
        self.imgIntimacy:setVisible(false)
        self.btnIntimacy:setTouchEnabled(false)
        self.btnIntimacy:setVisible(false)
    end
    
end

function RoleInfoView:showHeroProp()
    if self.galleryMode == 2 and self.hero_data ~= nil then
        --有数据        
        local h_id_num = getNumID( self.hero_id )
        local time_id = getTimeNumID( self.hero_id )

        local view = RoleInfoPropView.new():init()
        view.addPropEvent = function(sender,matCount)
            self:OnAddProp(matCount)
            sender:returnBack()
        end
        view:loadData(self.hero_data.hero_add_values,h_id_num,self.hero_data.hero_add)

        GameManagerInst:showModalView(view)

    end
end

function RoleInfoView:refreshStaticState()

    local time_id = getTimeNumID( self.hero_id )
    local h_id_num = getNumID( self.hero_id )

    --背景  effects/juesexiangqin
    --local bganimefile = nil

    if time_id > 10 then
        --已获取时界面状态
        if self.galleryMode ~= 2 then
            self.galleryMode = 2
            local platform = cc.Application:getInstance():getTargetPlatform()
            if (cc.PLATFORM_OS_ANDROID == platform) then
                self.btnShare:setVisible(false)--暂时屏蔽分享按钮
            else
                self.btnShare:setVisible(false)--暂时屏蔽分享按钮
            end
           
            self.stateHead1:setVisible(true)
            self.stateHead2:setVisible(false)

            self.stateBG1:setTexture("n_UIShare/role/info/jsxq_ui_099_1.png")
            self.stateBG2:setTexture("n_UIShare/role/info/jsxq_ui_099.png")
            self.storyBG1:setTexture("n_UIShare/role/info/jsgs_ui_001_1.png")

            self.spPanel:setVisible(true)
            self.pSkillNormalButtons:setVisible(true)
            -- self.btnSkillReset:setVisible(true)
            -- self.btnSkillAdd:setVisible(true)
            
            self.btnTab3:setVisible(true)
            self.btnTab4:setPosition(self.btnTab4Pos[1],self.btnTab4Pos[2]) 
        end   
    else
        --未获取时界面状态
        if self.galleryMode ~= 1 then
            self.galleryMode = 1
            self.btnShare:setVisible(false)
            self.stateHead1:setVisible(false)
            self.stateHead2:setVisible(true)

            self.stateBG1:setTexture("n_UIShare/role/info/jstj_ui_005_1.png")
            self.stateBG2:setTexture("n_UIShare/role/info/jstj_ui_005.png")
            self.storyBG1:setTexture("n_UIShare/role/info/jstj_ui_006_1.png")

            self.spPanel:setVisible(false)            
            self.pSkillNormalButtons:setVisible(false)
            -- self.btnSkillReset:setVisible(false)
            -- self.btnSkillAdd:setVisible(false)

            self.btnTab3:setVisible(false)
            self.btnTab4:setPosition(self.btnTab3:getPosition()) 

            self.imgIntimacyBg:setVisible(false)
            self.imgIntimacy:setVisible(false)
            self.btnIntimacy:setTouchEnabled(false)
            self.btnIntimacy:setVisible(false)
        end       
    end

    if self.galleryMode == 1 then
        if time_id == 0 then --未获得
            self.roleNotGetImg:setVisible(true)
            self.btnVoice:setVisible(false)
            self:showHeroOpen(h_id_num)
        else
            self.roleNotGetImg:setVisible(false)
            self.btnVoice:setVisible(true)
            self.roleNotGetNode:setVisible(false)
        end

        self.roleBtnProp:setVisible(false)
    else
        self.roleNotGetImg:setVisible(false)
        self.roleNotGetNode:setVisible(false)
        self.roleBtnProp:setVisible(self.curTab ~= 2)
        self.roleBtnPropText:setString("")
        
        self.btnVoice:setVisible(true)
    end
    ---

    self.currentVoiceIndex = 1

    --动态模型，立绘
    local lihuifile = hero[h_id_num].hero_des_spi

    self.roleIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(lihuifile) then

        local end_pos = string.find(lihuifile,'atlas') - 1
        local spName = string.sub(lihuifile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil

            local rps = self.roleIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2 , rps.height / 2))
            self.roleIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect1", true)
            
            if time_id == 0 then
                --未获得
                roleIcon:setColor(cc.c3b(0,0,0))
            end
        end)
        
        -- local roleIcon = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
        -- local rps = self.roleIconPos:getSize()
        -- roleIcon:setPosition(cc.p(rps.width / 2 , rps.height / 2))
        -- self.roleIconPos:addChild(roleIcon,0,123)
        -- roleIcon:setAnimation(1, "loading", true)
        
        -- if time_id == 0 then
        --     --未获得
        --     roleIcon:setColor(cc.c3b(0,0,0))
        -- end
    end

    self.roleName:setString("")
    self.roleName:setTextColor(cc.c3b(255,255,255))
    --self.roleIcon:setTexture(hero[h_id_num].hero_xq_icon)  --立绘大图
    local hero_atb = hero[h_id_num].hero_atb

    self.roleElement:setTexture(ATB_Icon[hero_atb]) --属性球
    if hero_atb == 1 then
        self.roleEAtbAct:play("shui",true)
    elseif hero_atb == 2 then
        self.roleEAtbAct:play("huo",true)
    elseif hero_atb == 3 then
        self.roleEAtbAct:play("feng",true)
    elseif hero_atb == 4 then
        self.roleEAtbAct:play("guang",true)
    elseif hero_atb == 5 then
        self.roleEAtbAct:play("an",true)
    else
        self.roleEAtbAct:play("reset",false)
    end
    
    local hero_job = hero[h_id_num].hero_job

    if hero_job == 1 then  -- 1  近战
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_098.png")
        self.jobImg:setVisible(true)
    elseif hero_job == 11 then   -- 11 远程 
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_095.png")
        self.jobImg:setVisible(true)
    elseif hero_job == 12 then   -- 12 法师
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_097.png")
        self.jobImg:setVisible(true)
    elseif hero_job == 21 then  -- 21 治疗
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_096.png")
        self.jobImg:setVisible(true)
    else
        self.jobImg:setVisible(false)
    end

    self.jobName:setString(UITool.getUserLanguage(hero[h_id_num].position_name))--(hero[h_id_num].position_name)
    self.jobDesc:setString(UITool.getUserLanguage(hero[h_id_num].position_desc))--(hero[h_id_num].position_desc)

    -- local rfsize = self.roleFrame:getSize()
    -- self.roleRankAnime = cc.CSLoader:createNode(RANK_ACG[hero[h_id_num].hero_rank])
    -- self.roleRankAnime:setPosition(cc.p(rfsize.width / 2 , rfsize.height / 2))
    -- self.roleFrame:addChild(self.roleRankAnime)
    -- local frameact = cc.CSLoader:createTimeline(RANK_ACG[hero[h_id_num].hero_rank])
    -- self.roleRankAnime:runAction(frameact)
    -- frameact:play("animation0",true)

    local hrank = hero[h_id_num].hero_rank
    self.roleFrameStar:setTexture(getRoleRank(hrank))
    -- self.roleFrameStar:setLocalZOrder(1)

    -- local frameimg = nil
    -- if hrank == 5 then
    --     frameimg = "n_UIShare/role/info/jsxy_ui_001.png"
    -- elseif hrank == 4 then
    --     frameimg = "n_UIShare/role/info/jsxy_ui_002.png"
    -- elseif hrank == 3 then
    --     frameimg = "n_UIShare/role/info/jsxy_ui_003.png"
    -- else
    --     frameimg = "n_UIShare/role/info/jsxy_ui_004.png"
    -- end
    -- self.roleFrameImg:setTexture(frameimg)

    --故事
    local storypath = nil

    self.storyDetail:setString(UITool.getUserLanguage(hero[h_id_num].hero_des_all))--(hero[h_id_num].hero_des_all)
    self.storyHeroName:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))--(hero[h_id_num].hero_name)

    self.stateGetMethod:setString(UITool.getUserLanguage(hero[h_id_num].get_method))--(hero[h_id_num].get_method)   --获取方式

    self.storyRaceName:setString(UITool.ToLocalization(HERO_RACE_NAME[hero[h_id_num].hero_race]))

    if g_channel_control.transform_RoleInfoView_racename_align == true then
        self.storyRaceName:ignoreContentAdaptWithSize(false)
        self.storyRaceName:setFontSize(20)
        self.storyRaceName:setPosition(632, 612)
        self.storyRaceName:setTextAreaSize(cc.size(150,25))
        self.storyRaceName:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    end


    storypath = HERO_RACE_ICON[hero[h_id_num].hero_race]
    if storypath ~= nil and storypath ~= "" then
        self.storyRaceIcon:setTexture(storypath)
    else
        self.storyRaceIcon:setVisible(false)
    end

    self.storyPowerName:setString(UITool.getUserLanguage(hero[h_id_num].power_str))

    --修改势力位置
    if g_channel_control.transform_RoleInfoView_powername_align == true then
        self.storyPowerName:ignoreContentAdaptWithSize(false)
        self.storyPowerName:setPosition(900, 612)
        self.storyPowerName:setTextAreaSize(cc.size(150,25))
        self.storyPowerName:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.storyPowerName:setFontSize(20)
    end


    local sexNameStr = UITool.getSexName(hero[h_id_num].sex_name)
    self.storySexName:setString(sexNameStr)
    
    storypath = hero[h_id_num].sex_img
    if storypath ~= "" then
        self.storySexIcon:setTexture(storypath)
    else
        self.storySexIcon:setVisible(false)
    end

    self.storyCV:setString(UITool.getUserLanguage(hero[h_id_num].hero_cv))--(hero[h_id_num].hero_cv)
    self.storyArt:setString(UITool.getUserLanguage(hero[h_id_num].hero_author))--(hero[h_id_num].hero_author)

    self.pRoleModel:removeAllChildren()
    self.skeletonNode = nil
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()

    local id_str = hero[h_id_num].hero_bat
    local end_pos = string.find(id_str,'atlas') - 1
    local spName = string.sub(id_str,0,end_pos)

    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end

    self.asyncHandler1 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(spine)
        self.asyncHandler1 = nil
        self.skeletonNode = spine
        
        local prmsize = self.pRoleModel:getSize()
        self.pRoleModel:addChild(self.skeletonNode)
        self.skeletonNode:setPosition(prmsize.width/2, 0)
        self.skeletonNode:setAnimation(1, "loading", true)

        self.modelActionIndex = 1

        if time_id == 0 then
            self.skeletonNode:setColor(cc.c3b(0,0,0))
        end
    end)

    --专属剧情
    if self.hero_data ~= nil then
        self:refreshExclusiveStoryBtn()
    end

    --技能
    self.curSkDescIdx = nil
    self.skDesc:setVisible(false)

    --装备
    self.curEquipIndex = nil
    self.eqDetailPanel:setVisible(false)
end

--角色自选功能
function RoleInfoView:showHeroOpen(h_id_num)
    if hero_open == nil or hero_open[h_id_num] == nil then
        self.roleNotGetNode:setVisible(false)
    end

    local hoinfo = hero_open[h_id_num]
    
    --[[{
        "need_mat_num": 50,
        "hero_id": 23,
        "can_choose": 0
    },]]

    if hoinfo.can_choose == 0 then
        self.roleNotGetNode:setVisible(false)
    else
        --之后 如果新增自选商店，点击也复用此处逻辑，再做处理
        if g_channel_control.open_NewHeroBookLayer then
            self.roleNotGetNode:setVisible(false)
        else 
            self.roleNotGetNode:setVisible(true)
            local mat_opt = user_info["bag"]["mat"][ID_HERO_OPT] or 0
            self.roleNotGetNum1:setString(""..mat_opt)
            self.roleNotGetNum2:setString(""..hoinfo.need_mat_num)
            
            if mat_opt < hoinfo.need_mat_num then
                self.roleNotGetNum1:setTextColor(cc.c3b(255,0,0))
            else
                self.roleNotGetNum1:setTextColor(cc.c3b(96,255,0))
            end

            self.roleNotGetSlash:setPosition(self.roleNotGetNum2:getPositionX() - self.roleNotGetNum2:getContentSize().width,self.roleNotGetNum2:getPositionY())
            self.roleNotGetNum1:setPosition(self.roleNotGetSlash:getPositionX() - self.roleNotGetSlash:getContentSize().width,self.roleNotGetSlash:getPositionY())
        end
    end

end

function RoleInfoView:confirmHeroOpen()
    if not self.hero_id then return end
    local h_id_num = getNumID( self.hero_id )
    local hoinfo = hero_open[h_id_num]
    if hoinfo then
        local mat_id = getMatID( ID_HERO_OPT )
       -- local msg = UITool.ToLocalization("是否花费")..hoinfo.need_mat_num..UITool.ToLocalization("个")..mat[mat_id].name..UITool.ToLocalization("召唤 ")..hero[h_id_num].hero_name
        local msg = ""
        if g_channel_control.order_RoleInfoView_summon_msg == false then

           msg = string.format(UITool.ToLocalization("是否花费%d个%s召唤%s"),hoinfo.need_mat_num,UITool.getUserLanguage(mat[mat_id].name),UITool.getUserLanguage(hero[h_id_num].hero_name) )

        else

           msg = string.format(UITool.ToLocalization("是否花费%d个%s召唤%s"), UITool.getUserLanguage(mat[mat_id].name), hoinfo.need_mat_num, UITool.getUserLanguage(hero[h_id_num].hero_name))
        end

        GameManagerInst:confirm(msg,function()
            local mat_opt = user_info["bag"]["mat"][ID_HERO_OPT] or 0
            if mat_opt < hoinfo.need_mat_num then
                GameManagerInst:alert(UITool.ToLocalization("您的道具不足，无法召唤角色。"))
            else
                self:sendHeroOpen()
            end
        end)
    end
end

function RoleInfoView:sendHeroOpen()
    if not self.hero_id then return end
    
    local h_id_num = getNumID( self.hero_id )

    local tempData = {
        rpc = "hero_choose",
        static_id = h_id_num,
    }
    
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        -- {
        --     "state_code":  1,
        --     "opt_count":  12,
        --     "get_hero_id":  "13*123124121",  # 自选到的英雄id
        -- }
        if self.exist == false then
            return
        end
        if user_info["bag"]["mat"][ID_HERO_OPT] then
             user_info["bag"]["mat"][ID_HERO_OPT] = data.opt_count
        end

        if self.other_ids then
            for i = 1,#self.other_ids do
                if self.other_ids[i] == self.hero_id then
                    self.other_ids[i] = ""..h_id_num.."*1"
                end
            end
        end

        self.hero_id = ""..h_id_num.."*1"
        GalleryView.needReload = true

        local getdata = {
        {
            story = "hero_"..h_id_num,
            id = h_id_num,
            type = 4,
            is_new = 1,
            change_to = {},
            element = hero[h_id_num].hero_atb,
            rarity = hero[h_id_num].hero_rank,
            in_mail = 0
        }}

        if GameManagerInst.gameType == 2 then
            SceneManager:toDrawCardEndLayer({   itemList = getdata,
                                                finalFunc = function()
                                                        self:refreshStaticState()
                                                        self:loadInfo(true)
                                                end
                                                })
        end
        
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleInfoView:refresh()
    self:refreshState()
    self:refreshEquip()
    self:refreshSkill()
    self:refreshSoulEquip()
    --self:refreshStory()
end

function RoleInfoView:playNestVoice()
    if not self.hero_data then return end

    local h_id_num = getNumID( self.hero_id )

    local voiceIdx = RoleInfoView.VoiceMap[self.currentVoiceIndex]
    local voicepath  = hero[h_id_num].hero_vce[voiceIdx]

    if self.voice_handle then        
        AudioManager:shareDataManager():stop(self.voice_handle)
    end

    --语音音效，type类型改为1，原来是0
    self.voice_handle = AudioManager:shareDataManager():playMusic( voicepath ,1, false)

    self.currentVoiceIndex = self.currentVoiceIndex + 1
    if self.currentVoiceIndex > #RoleInfoView.VoiceMap then
        self.currentVoiceIndex = 1
    end

end

function RoleInfoView:toShareRole()
    if not self.hero_data then return end
    local h_id_num = getNumID( self.hero_id )
    local heroID = h_id_num
    if not hero[heroID] then return end
    local rcvData = {}
    rcvData.heroID = heroID
    SceneManager:toShareRoleLayer(rcvData)
end

function RoleInfoView:OnAddSp(matNum)
    if not self.hero_data then return end

    local tempData = {
        rpc = "hero_sk_point_add",
        hero_id = self.hero_id,
        add_num = matNum,
    }

    
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        if user_info["bag"]["mat"][ID_ROLE_ADDSK] then
            user_info["bag"]["mat"][ID_ROLE_ADDSK] = user_info["bag"]["mat"][ID_ROLE_ADDSK] - matNum
        end
        
        self.hero_data.tp = table.deepcopy(data["tp"])

        if user_info["hero"][self.hero_id] then
            user_info["hero"][self.hero_id].tp = table.deepcopy(data["tp"])
            DataManager:rfsHlist()
        end
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)

end

function RoleInfoView:OnAddProp(matNum)
    if not self.hero_data then return end

    local tempData = {
        rpc = "hero_extra_add",
        hero_id = self.hero_id,
        add_num = matNum,
    }

    
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        if user_info["bag"]["mat"][ID_ROLE_ADDPROP] then
            user_info["bag"]["mat"][ID_ROLE_ADDPROP] = user_info["bag"]["mat"][ID_ROLE_ADDPROP] - matNum
        end
        
        self:loadInfo(true)
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleInfoView:returnBack()
    self.exist = false
    if self._navigationView then
        self._navigationView:popView()
    end
    -- self:removeFromParentView()
    --GameManagerInst:alert(#GameManagerInst.view._viewStack)
end

function RoleInfoView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType(nil,3)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        self:loadInfo(true)
        self:refresh()
    else
        self:loadInfo(false)
    end
end

--设置按钮等级解锁状态
function RoleInfoView:setNodeLockState()
    local curNodes = {self.btnTab2, self.btnTab3}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleInfoView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end
        end 
    end   
end
--设置按钮等级解锁状态
function RoleInfoView:setEquipNodeLockState()
    --local curNodes = {self.eqBtnSkill, self.eqBtnSth, self.eqBtnAwaken}
    local curNodes = {self.eqBtnSth}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleInfoView_Equip"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        else 
            btn:setVisible(true)
        end 
    end   
end
