--[[
	DDBattleRoleListView.lua
    --说明：
    SortBoxView用的别的排序，所以其中队伍中的在前面没有处理。如果处理，最好自己单独写个
]]

require "BasicLayer"

DDBattleRoleListView = class("DDBattleRoleListView",BasicLayer)
DDBattleRoleListView.__index = DDBattleRoleListView
DDBattleRoleListView.lClass = 3

function DDBattleRoleListView:create(rData)
     local layer = DDBattleRoleListView.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end

function DDBattleRoleListView:init()
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.refreshBack = false
    self.isChangeTeam = false
    --数据
    self._heros = self.rData["rcvData"]["team_info"] or {} -- 存放当前选中的队伍ID，是个数组
    self.currentHeroNum = 0 --当前已经选中的人数
    for i=1,#self._heros do
        local s = self._heros[i]
        if s == nil or s == "" or tostring(s) == "0" then 

        else 
            self.currentHeroNum = self.currentHeroNum + 1
        end 
    end

    self.heroMaxNum = 8     --当前最多可以选中多少人

    local node = cc.CSLoader:createNode("DDRoleListVIew.csb")
    self.uiLayer:addChild(node,0,1)
    self._rootCSbNode = node:getChildByTag(101) 
    self.exist = true
    --确认选择
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("comfirmBtn")
        	self:dealBackEvent()
        end
    end
    local comfirmBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_comfirm")
    comfirmBtn:addTouchEventListener(touchCallBack)

    --关闭
    local function touchCallCloseBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("closebtn")
            self.refreshBack = false
            self:returnBack()
        end
    end
    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(touchCallCloseBack)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")
    self.panelSort = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelSort")
    self.selectNum = ccui.Helper:seekWidgetByName(self._rootCSbNode,"selectNum")

    self:initListView()
    self:updateShowNum()



    self:reqHeroList()

end

function DDBattleRoleListView:initListView()
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = DDBattleRoleListItem.new():init()

        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end

        temp.resetDataEvent = function(item)
            --设置展示模式
            local smode = self.sortBtnView:getSortMode() % 10
            item:setTitleMode(smode)

            self:onItemShow(item)
        end

        return temp
    end

    --排序
    self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_x",213,0)
    self.sortBtnView.sortModeChangedEvent = function()
        self:refreshListView()
    end
end

function DDBattleRoleListView:updateShowNum()
    self.selectNum:setString(self.currentHeroNum)
end

--点击列表中的英雄
--todo 处理入队 出对的数据
function DDBattleRoleListView:onItemClicked(item)
    local id = item:getData().id
    if item.isSelect then
        self:removeHeroFromTeam(item,item._location,id)
    else    
        if self.currentHeroNum >= self.heroMaxNum then
            SceneManager:showPromptLabel(UITool.ToLocalization("编队已满"))
            do return end 
        end
        local i = 1
        --遍历找到空位置，入队
        while i <= self.heroMaxNum   do
            if self._heros[i]==nil or self._heros[i] == "" or tostring(self._heros[i]) == "0" then 
                self:addItemToTeam(item,id,i)
                break
            end
            i = i + 1
        end    
    end
end

--当前显示
-- todo 如果在队伍中，就选中选中状态 
-- item:setSelectState(0)
function DDBattleRoleListView:onItemShow(item)    
    local id = item:getData().id
    for i=1,#self._heros  do
        if self._heros[i] == id then 
            item:setSelectState(0)
            item._location = i
        end
    end
end

--添加
function DDBattleRoleListView:addItemToTeam(item,id,location)
    self._heros[location] = id
    self.currentHeroNum = self.currentHeroNum + 1 
    item:setSelectState(0)
    item._location = location
    self:updateShowNum()
    self.isChangeTeam = true
end
--删除
function DDBattleRoleListView:removeHeroFromTeam(item,location,id)
    self._heros[location] = "0"
    self.currentHeroNum = self.currentHeroNum - 1 
    if item~=nil then
        item:setSelectState(1)
    end
    self:updateShowNum()
    self.isChangeTeam = true
end

function DDBattleRoleListView:getDataSource(sort_mode)
    if self.dataSourceEvent then
        return self.dataSourceEvent(self,sort_mode)
    else
        local dataset =  table.deepcopy(self.hero_list)
        SortBoxView.SortRole (dataset, sort_mode ,false)
        return dataset
    end
end

function DDBattleRoleListView:refreshListView()
    --先排序，后刷列表 
    local ds = self:getDataSource(self.sortBtnView:getSortMode())
    self.currentDataSource = ds
    self.gridview:setDataSource(ds)
end

--是个字典，转为数组
function DDBattleRoleListView:dealHeroArryData(data)
	local temp_list = {}
    local index = 1
    for k,v in pairs(data) do
         temp_list[index] = v
         if temp_list[index]~=nil then 
           temp_list[index]["id"] = k 
           temp_list[index]["time_id"] = getTimeNumID(""..k)
           temp_list[index]["hero_rank"] = hero[getNumID(""..k)]["hero_rank"]
           temp_list[index]["hero_name"] = UITool.getUserLanguage(hero[getNumID(""..k)]["hero_name"])--hero[getNumID(""..k)]["hero_name"]
           index = index +1
         end 
end
    self.hero_list = {}
    self.hero_list = table.deepcopy(temp_list)
end
--接口相关
--请求队伍信息
function DDBattleRoleListView:reqHeroList()
    local function ReqSuccess(data)
        --刷新当前UI
        --todo还用刷新 user_info 的数据吗
        self:dealHeroArryData(data.hero_list)
        self:refreshListView()
    end
    local tempTable = {
        ["rpc"] = "hero_list",
    }
    self:doReq(tempTable, ReqSuccess)  
end

--todo 判断队伍信息是不是有更改，如果有的话，就请求，然后返回，否则直接返回
function DDBattleRoleListView:dealBackEvent()
    if self.isChangeTeam then 
        self:reqEditHeroList()
    else 
        self.refreshBack = false
        self:returnBack()
    end 
end

--返回
function DDBattleRoleListView:returnBack()
    --如果是派遣返回。舒刷新
    if self.refreshBack then 
        self.backFunc(self.sDelegate)
    end 
    self.exist = false
    self._heros = {}
    self.hero_list = {}
    self:clearEx()
end

function DDBattleRoleListView:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--请求编队
function DDBattleRoleListView:reqEditHeroList()
    dump("ssssssssss   reqEditHeroList")
    local function ReqSuccess(data)
        self.refreshBack = true
        self:returnBack()
    end
    local tempTable = {
        ["rpc"] = "dd_battle_edit",
        ["team_info"] = self._heros,
    }
    self:doReq(tempTable, ReqSuccess)  
end

function DDBattleRoleListView:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
