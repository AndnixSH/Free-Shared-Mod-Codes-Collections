--require "XUIView"

RoleInfoAddSPView = class("RoleInfoAddSPView",XUIView)
RoleInfoAddSPView.CS_FILE_NAME = "RoleInfoAddSPView.csb"
RoleInfoAddSPView.CS_BIND_TABLE = 
{
    numLv = "/i:295/i:296/i:339/s:numLv",
    numMat = "/i:295/i:296/i:339/s:numMat",
    btnLeft = "/i:295/i:296/i:339/s:btnLeft",
    btnRight = "/i:295/i:296/i:339/s:btnRight",
    btnUp = "/i:295/i:296/i:339/s:btnUp",

    m_panel = "/i:295/i:296/i:339/i:347",
    m_imgBG = "/i:295/i:296/i:339/i:347/s:imgBG",
    m_imgFace = "/i:295/i:296/i:339/i:347/s:imgFace",
    m_imgRarity = "/i:295/i:296/i:339/i:347/s:imgRarity",
    m_lbNum = "/i:295/i:296/i:339/i:347/s:lbNum",

    lbHint = "/i:295/i:296/i:352",
    btnOk = "/i:295/i:296/i:353",
}

function RoleInfoAddSPView:init()
    RoleInfoAddSPView.super.init(self)

    self.btnUp:addClickEventListener(function()
        if not self.mat_count then return end
        
        if self.mat_count == 0 then
            GameManagerInst:alert(UITool.ToLocalization("请选择素材数量"))
            return
        end

        local mid = getMatID(ID_ROLE_ADDSK)
        local msg = "使用%d个%s提升角色技能点数？"
        local msg1 = ""

        if g_channel_control.order_RoleInfoAddSPView_enhangce_skill_msg == false then

            msg1 = string.format(UITool.ToLocalization(msg),self.mat_count,UITool.getUserLanguage(mat[mid].name)) 

        else

            msg1 = string.format(UITool.ToLocalization(msg), tostring(UITool.getUserLanguage(mat[mid].name)),tonumber(self.mat_count))
        end

       

        -- UITool.ToLocalization("使用")..self.mat_count..UITool.ToLocalization("个")..mat[mid].name..UITool.ToLocalization("提升角色技能点数？")
        GameManagerInst:confirm(msg1,function()
            if self.addSpEvent then
                self.addSpEvent(self,self.mat_count)
            end
        end)
    end)

    self.m_panel:setTouchEnabled(true)
    self.m_panel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local mid = getMatID(ID_ROLE_ADDSK)
            MsgManager:showSimpItemInfo(5,mid)
        end
    end)

    self.btnLeft:addClickEventListener(function()
        self:setMatCount(-1)
    end)

    self.btnRight:addClickEventListener(function()
        self:setMatCount(1)
    end)

    self.btnOk:addClickEventListener(function()
        self:returnBack()
    end)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

function RoleInfoAddSPView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function RoleInfoAddSPView:loadData(sp_add)
    self.hero_sp_add = sp_add

    self.mat_count = 0
    self.mat_max = user_info["bag"]["mat"][ID_ROLE_ADDSK]
    if not self.mat_max then
        self.mat_max = 0
    end

    self.bouns_sp_max = 10    --额外技能点上限

    self.numLv:setString(""..sp_add.."/"..self.bouns_sp_max)

    local mid = getMatID(ID_ROLE_ADDSK)
    local rarity = mat[mid].rarity
    
    self.m_imgBG:setTexture(Rarity_BG[rarity])
    self.m_imgRarity:setTexture(Rarity_mat[rarity])
    self.m_imgFace:setTexture("icons/mat/"..mat[mid].icon)
    self.m_lbNum:setString("x"..self.mat_max)

    local str = UITool.ToLocalization("提示： 每个角色最多使用%s%d次")
    local lbStr = "";

    if g_channel_control.order_RoleInfoAddSPView_msg == false then

        lbStr = string.format(str,UITool.getUserLanguage(mat[mid].name),self.bouns_sp_max);

    else

        lbStr = string.format(str, tonumber(self.bouns_sp_max),tostring(UITool.getUserLanguage(mat[mid].name)))

    end


    -- UITool.ToLocalization("提示： 每个角色最多使用")..self.bouns_sp_max..UITool.ToLocalization("次")..mat[mid].name
    self.lbHint:setString(lbStr)

    self:setMatCount(0)
end


function RoleInfoAddSPView:setMatCount(offect)
    self.mat_count = self.mat_count + offect
    local ll = false
    local lr = false

    if self.mat_count <= 0 then
        self.mat_count = 0
        ll = true
    end

    if self.mat_count + self.hero_sp_add >= self.bouns_sp_max then
        self.mat_count = self.bouns_sp_max - self.hero_sp_add
        lr = true
    end

    if  self.mat_count >= self.mat_max then
        self.mat_count = self.mat_max
        lr = true
    end


    self.btnLeft:setTouchEnabled(not ll)
    self.btnLeft:setBright(not ll)
    self.btnRight:setTouchEnabled(not lr)
    self.btnRight:setBright(not lr)

    self.numMat:setString(""..self.mat_count)
end
