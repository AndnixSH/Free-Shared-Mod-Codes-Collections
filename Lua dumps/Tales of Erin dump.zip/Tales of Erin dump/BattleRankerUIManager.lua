BattleRankerUIManager = class("BattleRankerUIManager") 
BattleRankerUIManager.__index = BattleRankerUIManager
BattleRankerUIManager.rootNode = nil
BattleRankerUIManager.panel_ranker = nil
BattleRankerUIManager.BATTLE_UI_PATH = "uifile/zhandou.csb"
BattleRankerUIManager.playerNameText = nil

function BattleRankerUIManager:createWithMainUINode(node)
	local battleInfo = BattleRankerUIManager.new()
    battleInfo:init(node)
	return battleInfo
end

function BattleRankerUIManager:init(node)
	self.rootNode = node
    self.panel_ranker = self.rootNode:getChildByTag(61)
    self.panel_ranker:setVisible(false)
    self.playerNameText =ccui.Helper:seekWidgetByTag(self.panel_ranker,92)
end

function BattleRankerUIManager:showRanking(rankers) -- 刷新多人战排名信息并展示新玩家加入动画
    self.panel_ranker:setVisible(true)
    for i = 1, 3 do
        local imgview = self.panel_ranker:getChildByTag((i+6)*10)
        if rankers and i <= #rankers then 
            imgview:setVisible(true) 
            local name = imgview:getChildByTag((i+6)*1000+2)
            local gx = imgview:getChildByTag((i+6)*1000+3)  --贡献
            if rankers[i]["player_name"] and rankers[i]["gx"] then
                name:setString(rankers[i]["player_name"])
                gx:setString(rankers[i]["gx"])
            end
        else
            imgview:setVisible(false)   
        end 
    end
end

function BattleRankerUIManager:showAddMembers(addMembers) -- 刷新多人战新玩家加入
  	if addMembers and #addMembers > 0 then
        name = addMembers[1]["player_name"]
        self.playerNameText:setString(name)
        self.rootNode:stopActionByTag(1010)
        local action = cc.CSLoader:createTimeline(self.BATTLE_UI_PATH)
        action:setTag(1010)
        self.rootNode:runAction(action)
        action:play("play",false)
  	end
end