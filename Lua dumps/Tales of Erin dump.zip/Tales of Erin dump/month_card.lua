--desc 描述
--desc_simple 引导描述
month_card = {}   
month_card[1] = {
    name = "135963",
    rarity = 5,
    icon = "mat_652.png",
    desc = "135966",
    desc_simple = "135969",
    reward = {  
       {
           type=2,--奖励的类型
           id=0,
           num=100,--奖励的数量
      },   
    }
}    
month_card[2] = {
    name = "135964",
    rarity = 5,
    icon = "mat_654.png",
    desc = "135967",
    desc_simple = "135970",
    reward = {   
       {
           type=2,--奖励的类型
           id=0,
           num=100,--奖励的数量
      },  
    }
}    
month_card[3] = {
    name = "135965",
    rarity = 5,
    icon = "mat_653.png",
    desc = "135968",
    desc_simple = "135971",
    reward = {    
       {
           type=2,--奖励的类型
           id=0,
           num=100,--奖励的数量
      }, 
    }
}   