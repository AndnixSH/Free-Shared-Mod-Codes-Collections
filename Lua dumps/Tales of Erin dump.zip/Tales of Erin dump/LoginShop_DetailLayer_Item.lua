--付费登陆的单个item详情界面
LoginShop_DetailLayer_Item = class("LoginShop_DetailLayer_Item", function()
    return cc.Layer:create();
end);

--@isAvailable,是否可购买
function LoginShop_DetailLayer_Item:ctor(data,fatherLayer,isAvailable)
    self.data = data
    self.fatherLayer = fatherLayer
    self.isAvailable = isAvailable
    self:init()
end

function LoginShop_DetailLayer_Item:init()
    self.rootNode = cc.CSLoader:createNode("MsgBoxNode_14.csb")
    self:addChild(self.rootNode)

    self:setPanelInfo()
end


-- 弹出框上显示的 除了Item 以外的属性信息
function LoginShop_DetailLayer_Item:setPanelInfo()

    local popr  = UITool.getItemInfos(self.data.product_type,self.data.product_id_local)
    local panel = self.rootNode:getChildByName("Panel_4")

    -- 图标背景
    local icon_bg    = panel:getChildByName("Image_icon_bg")
    icon_bg:loadTexture(popr[4])

    -- 图标
    local icon       = panel:getChildByName("Image_icon")
    icon:loadTexture(popr[2])
    icon:setUnifySizeEnabled(true)

    -- 图标属性框
    local icon_form  = panel:getChildByName("Image_icon_form")
    icon_form:loadTexture(popr[1])

    -- 数量
    local itemNumText = panel:getChildByName("Text_gem")
    if self.data.product_num and self.data.product_num > 1 then
        itemNumText:setString(self.data.product_num)   
    else
        itemNumText:setVisible(false)
    end

    --描述
    local destText = panel:getChildByName("Text_dec")
    destText:setString(popr[6])

    -- 名字
    local gift_name  = panel:getChildByName("Text_name")
    gift_name:setString(popr[5])

    --消耗的人民币
    local cost_icon = panel:getChildByName("Image_gem")
    local cost_num = panel:getChildByName("Text_number")
    cost_icon:setUnifySizeEnabled(true)
    cost_icon:loadTexture(UITool:Coin_type(14))
    cost_num:setString(self.data.cost)

    --补买消耗的星石
    local cost_icon_0 = panel:getChildByName("Image_gem_0")
    local cost_num_0 = panel:getChildByName("Text_number_0")
    local isNotEnoughGem = false   --有偿钻石不够
    if self.data.product_state == 3 then
        cost_icon_0:setVisible(true)
        cost_num_0:setVisible(true)
        cost_icon_0:setUnifySizeEnabled(true)
        cost_icon_0:loadTexture(UITool:Coin_type(2))
        cost_num_0:setString(self.data.star_needed) 

        --如果有偿钻石不够
        if user_info["gem_r"] < self.data.star_needed then
            isNotEnoughGem = true
            cost_num_0:setColor(cc.c3b(255, 0, 0))
        end

    else
        cost_icon_0:setVisible(false)
        cost_num_0:setVisible(false)
    end

    -- 购买按钮
    local buy_btn    = panel:getChildByName("Button_buy")
    if not self.isAvailable or isNotEnoughGem then
        buy_btn:setEnabled(false)
    else
        buy_btn:addClickEventListener(function ()
            self:showConfirmDialog()
        end)
    end

    -- 取消按钮
    local cancle_btn = panel:getChildByName("Button_cancel")
    cancle_btn:addClickEventListener(function ()
        self:removeFromParent()
    end)
end

--点击购买按钮,弹出二次确认窗口
--二级弹窗：MsgWithTwoButtons.csb
function LoginShop_DetailLayer_Item:showConfirmDialog()
    local confirmLayer = cc.CSLoader:createNode("MsgWithTwoButtons.csb")
    self:addChild(confirmLayer)

    local panel = confirmLayer:getChildByName("Panel")

    local contentText = panel:getChildByName("Text_dec")
    local currency_type = UITool.ToLocalization("美元")
    local str = string.format(UITool.ToLocalization("是否花费%s%s购买礼包"),tostring(self.data.cost),currency_type)
    contentText:setString(str)

    local this = self

    --付费后发送productIdx
    local function sendProductIdx()
        local tempTable = {}
        tempTable["rpc"] = "loginshop_deductingstars"
        tempTable["productidx"] = this.data.product_puid

        GameManagerInst:rpc(tempTable,
            3,
            function(data)
                --success
                print("扣除星石成功")
                this.fatherLayer:requestData(true)
                this:removeFromParent()
            end,
            function(state_code,msgText)
                --failed
                SceneManager:delWaitLayer()
                print("扣除星石失败")
                GameManagerInst:alert(msgText)
            end,
        true)        
    end

    --付费回调
    local function payCallback(state)
        if state == "SUCCESS" then
            print("付费登陆支付成功") 
            sendProductIdx()
        else
            SceneManager:delWaitLayer()
            print("付费登陆支付失败")
        end
    end

    --[[
        local function test()
       --测试
        local tempTable = {}
        tempTable["rpc"] = "loginshop_test"

        GameManagerInst:rpc(tempTable,
            3,
            function(data)
                --success
                print("付费成功")
                sendProductIdx()
                --this.fatherLayer:requestData(true)
            end,
            function(state_code,msgText)
                --failed
                SceneManager:delWaitLayer()
                print("付费失败")
                GameManagerInst:alert(msgText)
            end,
        true)
    end
    ]]

    -- 购买按钮
    local confirm_btn = panel:getChildByName("Button_confirm")
    confirm_btn:addClickEventListener(function ()
       local product = {}
       product.product_id = this.data.product_puid
       
       SceneManager:createWaitLayer()--开启屏蔽层
       SDKManagerLua:buyItem(product,payCallback)
       --test()
    end)

    -- 取消按钮
    local cancle_btn = panel:getChildByName("Button_cancle")
    cancle_btn:addClickEventListener(function ()
        confirmLayer:removeFromParent()
    end)
end
