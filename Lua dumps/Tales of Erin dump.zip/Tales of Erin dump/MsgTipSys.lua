
--消息飘字提示系统
MsgTipSys = class("MsgTipSys")

function MsgTipSys:getInstance()
   if self.s_instance == nil then
        self.s_instance = MsgTipSys.new()
        self.s_instance:initialize()
   end
   return self.s_instance;
end

function MsgTipSys:initialize( )
   self:resetData()
end


function MsgTipSys:resetData( )
    self.tipsMap = {}
    self.b_Ready = true
    self.schedulerEntry = nil

    self.defaultInterval = 1
    self.interval = self.defaultInterval
end



function MsgTipSys:addData( info )
    local index = #self.tipsMap + 1
    self.tipsMap[index] = info
    if self.b_Ready == true then
        
        self:startWork()
      
    end
end

function MsgTipSys:takeOutNextData( ... )
    local count = #self.tipsMap
    local data = nil
    if count > 0 then
         data = self.tipsMap[1]
         table.remove(self.tipsMap, 1) 
    end
    return data
end



function MsgTipSys:sendData( ... )
    -- body
    local data = self:takeOutNextData()
    if data ~= nil then
        SceneManager:showTipLayer(data)
    end
end

function MsgTipSys:isEmpty( ... )
    -- body
    local bEmpty = false
    local num = #self.tipsMap
    if num == 0 then
        bEmpty = true
    end
    return bEmpty
end


function MsgTipSys:stopWork()

   
    if self.schedulerEntry ~= nil then 
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.schedulerEntry)
        self.schedulerEntry = nil
    end

    self:resetData()
    
end

function MsgTipSys:startWork()

    self.b_Ready = false

    self:sendData()

    local owner = self
    local function callBackFunc()
       
        local bEmpty = owner:isEmpty()
        if bEmpty == true then
            owner:stopWork()
        else
            owner:sendData()
        end
        dump(self.tipsMap,"MsgTipSys:initScheduler  callBackFunc: ")
    end

    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerEntry = scheduler:scheduleScriptFunc(callBackFunc, 1.3, false)
    

end

--设置间隔时间
function MsgTipSys:setIntervalTime(interval)

    self.interval = interval or self.interval

end

--获得实际执行时的时间间隔
function MsgTipSys:getExcuteInterval()

   return self.interval * self.getRate()

end

--设置间隔时间
function MsgTipSys:getRate()

   local length = #self.tipsMap
   local rate = 1
   if length < 3 then
        rate = 1
    elseif length < 10 then
        rate = 0.5
    else
        rate = 0.1 
    end
    return rate
end






