--角色和怪物所在Layer。
--created by kobejaw.2018.3.22.
BattleEntityLayer = class("BattleEntityLayer", function()
    return cc.Layer:create();
end);

function BattleEntityLayer:ctor()
	G_EntityLayer = self;
	self.entities = {}       --所有entity。
	self:initChosenSprites() --角色选中特效。图层在角色之下。
	self:addTouchOperation()
	self:startUpdate()
end

--创建所有玩家角色
function BattleEntityLayer:createRoles(teamManager)
	for i = 1,#BattleDataManager.roleDataArray do
		local data = BattleDataManager.roleDataArray[i]
		local role = BattleRole.new(data,teamManager)
		G_Roles[i] = role
		self:addChild(role)
	end

	--按从左到右,从下到上的顺序排序
	table.sort(G_Roles,function(a,b)
		if a.data.initialPos.x ~= b.data.initialPos.x then
			return a.data.initialPos.x < b.data.initialPos.x
		else
			return a.data.initialPos.y < b.data.initialPos.y
		end
	end)

	BattleRuntimeInfo:setTeam1Num(#G_Roles)
end

--角色选中效果，脚底下的小框和拖动的时候的线
--TODO切换场景的时候恢复到默认默认状态
function BattleEntityLayer:initChosenSprites()
	--拖动相关
    self.pullLine = cc.Scale9Sprite:create("zdui216.png")
    self.pullLine:setAnchorPoint(cc.p(0,0.5))
    self.pullEndPoint1 = cc.Sprite:create("zdui220.png")
    self.pullEndPoint2 = cc.Sprite:create("MaskUI/zdjm_ui_008.png")
    self.pullEndPoint2:setAnchorPoint(cc.p(0.5,-0.3))
    self.chosenSprite = cc.Scale9Sprite:create("zdjm_ui_006.png")

    self.layoutForChosenSprite = ccui.Layout:create()
    self.layoutForChosenSprite:setContentSize(self.chosenSprite:getContentSize())
    self.layoutForChosenSprite:setScaleY(0.45)
    self.layoutForChosenSprite:addChild(self.chosenSprite)

    self.pullLine:setVisible(false)
    self.pullEndPoint1:setVisible(false)
    self.pullEndPoint2:setVisible(false)
    self.layoutForChosenSprite:setVisible(false)

    self:addChild(self.pullLine)
    self:addChild(self.pullEndPoint1)
    self:addChild(self.pullEndPoint2)
    self:addChild(self.layoutForChosenSprite)
end

--设置所有人未选中状态。场景切换时，被选中的角色死亡时调用一下
function BattleEntityLayer:setNoOneChosen()
    self.pullLine:setVisible(false)
    self.pullEndPoint1:setVisible(false)
    self.layoutForChosenSprite:setVisible(false)
    self.chosenSprite:stopAllActions()	
end

--点击和拖动事件
function BattleEntityLayer:addTouchOperation()
	self.touchedRole = nil;
	local touchBeganPos = nil;
	local isMoved = false;
	local this = self

	local deltaX,deltaY,length,currPos,angle,aimedMonster
	--设为未选中状态
	local function setNoOneChosenState()
	    self.pullLine:setVisible(false)
	    self.pullEndPoint1:setVisible(false)
	    self.layoutForChosenSprite:setVisible(false)
	    self.chosenSprite:stopAllActions()
	end

	--检测某个角色是否被点击
	local function checkIsTouched(role)
		if role.isDead or role.fsm.currentState.isSkill or role.fsm.stateEnum == StateEnum.UnusualCondition or role.componentManager:checkIsInVertigo() then
			return false
		end
		local pos = role:convertToNodeSpace(touchBeganPos)--这个是相对于角色自身坐标系的。坐标原点和锚点豆在下方中间位置
		local rect = role.touchRect
		if pos.x >= rect[1] and pos.x<=rect[1]+rect[3] and pos.y>=rect[2] and pos.y<=rect[2]+rect[4] then
			local centerPointY = rect[4]/2
			return true,pos.x * pos.x + (pos.y - centerPointY)*(pos.y - centerPointY)
		else
			return false
		end
	end

	--检测是否拖动到了某个怪物身上
	local function checkIsMonsterAimed(mon,touch)
		if mon.isDead then
			return
		end

		local rect = mon.touchRect
		local pos = mon:convertToNodeSpace(touch:getLocation())

		if pos.x >= rect[1] and pos.x<=rect[1]+rect[3] and pos.y >=rect[2] and pos.y <=rect[2]+rect[4] then
			return true;
		end
	end

	--移除怪物被瞄准的动画
	local function removeAimedAnimation()
		if this.aimedSprite then
			this.aimedSprite:removeFromParent();
			this.aimedSprite = nil;
		end
	end

	--生成怪物被瞄准的动画
	local function createAimedAnimation(mon)
	    local frames = {}
	    for i = 1,7 do
	        frames[i] = cc.Sprite:create(string.format("EnemyState/enemy%04d.png",i)):getSpriteFrame();
	    end
	    this.aimedSprite = cc.Sprite:createWithSpriteFrame(frames[1]);
	    local animation = cc.Animation:createWithSpriteFrames(frames, 1/8);
	    local seq = cc.Sequence:create(cc.Repeat:create(cc.Animate:create(animation),3), cc.CallFunc:create(removeAimedAnimation)) 
	    this.aimedSprite:runAction(seq);

	    mon:addChild(this.aimedSprite)
	    this.aimedSprite:setPosition(mon.centerPoint)
	end

	--设置被瞄准的怪物
	local function setAimedMonster(touch)
		for i = 1,#G_Monsters do
			local m = G_Monsters[i]
			if checkIsMonsterAimed(m,touch) then
				if aimedMonster == m then
					return true
				end
				aimedMonster = m
				removeAimedAnimation();
				createAimedAnimation(m)
				return true
			end
		end
		aimedMonster = nil;
		return false
	end	

	local function onTouchBegan(touch, event)
		this.touchedRole = nil

		if G_STAGE_TYPE == 0 then
			return false;
		end

		touchBeganPos = touch:getLocation();
		isMoved = false;

		local touchedRolesArray = {}
		for i=1,#G_Roles do
			local isTouch,dis = checkIsTouched(G_Roles[i])
			if isTouch then
				local data = {}
				data.role = G_Roles[i]
				data.dis = dis
				table.insert(touchedRolesArray,data)
			end
		end

		if #touchedRolesArray == 0 then
			if this.touchedRole ~= nil then
				setNoOneChosenState();
			end
			this.touchedRole = nil;
			return false
		end

		if #touchedRolesArray == 1 then
			this.touchedRole = touchedRolesArray[1].role
		else
			table.sort(touchedRolesArray,function(a,b)
				return a.dis < b.dis
			end)
			this.touchedRole = touchedRolesArray[1].role
		end

		touchBeganPos = {}
		touchBeganPos.x,touchBeganPos.y = this.touchedRole:getPosition()
		this.layoutForChosenSprite:setVisible(true)

	    local action = cc.RepeatForever:create(cc.RotateBy:create(0.5,87))
	    this.chosenSprite:runAction(action)
	    local action2 = cc.Sequence:create(cc.ScaleTo:create(0.15,1.5),cc.ScaleTo:create(0.15,0.8));
	    this.chosenSprite:runAction(action2)

	    this.layoutForChosenSprite:setPosition(touchBeganPos.x,touchBeganPos.y)

		return true;
	end

	local function onTouchMoved(touch, event)
		if not this.touchedRole then
			return
		end

		if this.touchedRole.isDead or this.touchedRole.fsm.currentState.isSkill or this.touchedRole.fsm.stateEnum == StateEnum.UnusualCondition or this.touchedRole.componentManager:checkIsInVertigo() then
			return
		end

		local touchX = touch:getLocation().x
		local touchY = touch:getLocation().y

		if touchX <= 5 then
			touchX = 5
		end

		currPos = this.touchedRole:convertToNodeSpace(cc.p(touchX,touchY))
		currPos.x = touchBeganPos.x + currPos.x
		currPos.y = touchBeganPos.y + currPos.y
		currPos = GetCorrectedPoint(currPos.x,currPos.y)

		deltaX = currPos.x - touchBeganPos.x
		deltaY = currPos.y - touchBeganPos.y

		if math.abs(deltaX) <= 1 and math.abs(deltaY) <= 1 then
			return
		end

		isMoved = true;

		length = math.sqrt(deltaX*deltaX + deltaY*deltaY)
		angle = math.acos(deltaX /length) * 180 / math.pi
		if deltaY > 0 then
			angle = -angle
		elseif deltaY == 0 and deltaX < 0 then
			angle = 180
		end

		this.pullLine:setPosition(touchBeganPos.x,touchBeganPos.y)
		this.pullLine:setVisible(true)
		this.pullLine:setRotation(angle)
		this.pullLine:setContentSize(cc.size(length,this.pullLine:getContentSize().height))

		--怪物是否被瞄准
		if setAimedMonster(touch) then
			this.pullEndPoint1:setVisible(false)
			this.pullEndPoint2:setVisible(false)
			this.pullEndPoint2:stopAllActions();		
		else
			this.pullEndPoint1:setVisible(true)
			this.pullEndPoint2:setVisible(true)
			this.pullEndPoint1:setPosition(currPos.x,currPos.y)
			this.pullEndPoint2:setPosition(currPos.x,currPos.y)
		end
	end

	local function onTouchEnded(touch, event)
		--如果没有发生拖动，脚底下选中框消失
		if not this.touchedRole then
			setNoOneChosenState()
			return
		elseif not isMoved then
			return;
		end

		if this.touchedRole.isDead or this.touchedRole.fsm.currentState.isSkill or this.touchedRole.fsm.stateEnum == StateEnum.UnusualCondition or this.touchedRole.componentManager:checkIsInVertigo() then
			setNoOneChosenState()
			return
		end

		local touchX = touch:getLocation().x
		local touchY = touch:getLocation().y

		if touchX <= 5 then
			touchX = 5
		end

		currPos = this.touchedRole:convertToNodeSpace(cc.p(touchX,touchY))

		touchBeganPos.x,touchBeganPos.y = this.touchedRole:getPosition()
		currPos.x = touchBeganPos.x + currPos.x
		currPos.y = touchBeganPos.y + currPos.y

		currPos = GetCorrectedPoint(currPos.x,currPos.y)

		this.pullLine:setVisible(false)
	    this.pullEndPoint1:setVisible(false)

	    --如果瞄准了怪物
		if aimedMonster then
			local msg = {}
			msg.data = aimedMonster
			msg.code = MsgType.RunToEnemy
			MessageDispatcher:dispatchMessage(this.touchedRole.fsm,msg)
		--如果瞄准了地块
		else
			this.pullEndPoint2:setVisible(true)
			removeAimedAnimation();

			if math.abs(currPos.x - touchBeganPos.x) < 5 and math.abs(currPos.y - touchBeganPos.y) < 5 then
				return
			end

		    local moveY = cc.MoveBy:create(0.3, cc.p(0, -20));
		    local moveY_2 = cc.MoveBy:create(0.05, cc.p(0,20));
		    local seq_move = cc.Sequence:create(moveY,moveY_2);
		    this.pullEndPoint2:runAction(cc.RepeatForever:create(seq_move));

		    local wave1 = cc.Sprite:create("wave.png")
		    wave1:setOpacity(122)
			local wave2 = cc.Sprite:create("wave.png")
			wave2:setOpacity(122)
			wave2:setVisible(false)

			this:addChild(wave1)
			this:addChild(wave2)
			wave1:setPosition(currPos.x,currPos.y)
			wave2:setPosition(currPos.x,currPos.y)

			local wave1Action = cc.ScaleTo:create(0.4,0.3)

			local function func()
				wave2:setVisible(true)
				local wave2Action = cc.ScaleTo:create(0.4,0.3)
				local function func2()
					wave1:removeFromParent()
					wave2:removeFromParent()
					this.pullEndPoint2:stopAllActions()
					this.pullEndPoint2:setVisible(false)
				end
				local seq2 = cc.Sequence:create(wave2Action,cc.CallFunc:create(func2));
				wave2:runAction(seq2)
			end

			local seq1 = cc.Sequence:create(wave1Action,cc.CallFunc:create(func));
			wave1:runAction(seq1)

			local msg = {}
			msg.data = currPos
			msg.code = MsgType.RunToPos
			MessageDispatcher:dispatchMessage(this.touchedRole.fsm,msg)
		end
	end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
end

function BattleEntityLayer:startUpdate()
	local this = self;
	local function update()
		if this.touchedRole then
			this.layoutForChosenSprite:setPosition(this.touchedRole:getPosition())
		end
	end
	this:scheduleUpdateWithPriorityLua(update,0)	
end

--重置Zorder(当某个角色完成移动的时候执行一次)
function BattleEntityLayer:resetZOrder()
	for k,v in pairs(self.entities) do
		if not v.isDead then
			local w,h = v:getBoxWH()
			v:setLocalZOrder(BattleGlobals.BOX_N - h)
		end
	end 
end

--设置角色位置，进入下一波怪时调用
function BattleEntityLayer:resetRolesPosition()
	--检测是否有近战英雄
	local ishasMellee = false
	for k,v in pairs(G_Roles) do
		if not v.isDead and v.data.mellee then
			ishasMellee = true
		end
	end

	for k,v in pairs(G_Roles) do
		v.deltaForUpdate = 0
		v.idxForUpdate = 1

		v:setTeammateAndEnemyList()
		if not v.isDead then
			v:setPosition(cc.p(v.data.initialPos.x - 300,v.data.initialPos.y))
			local data = {}
			data.type = 1
			data.isEnter = true
			if ishasMellee then
				data.w,data.h = GetBoxWHByPoint(v.data.initialPos.x + 50,v.data.initialPos.y)
			else
				data.w,data.h = GetBoxWHByPoint(v.data.initialPos.x + 100,v.data.initialPos.y)
			end
			v.fsm:changeState(StateEnum.RunningToPosition,data)
		end
	end
end

--怪物相关
--创建一波怪
--@waveNum,第几波
function BattleEntityLayer:createOneWaveMonster(teamManager)
	G_Monsters = {}

	local waveInfoArray = BattleDataManager.wavesArray[BattleRuntimeInfo.currentWaveNum].wave

	for i = 1, #waveInfoArray do

		local puid
		if G_STAGE_TYPE == 3 then
			puid = tonumber(waveInfoArray[i].m_id+1) --无力吐槽了
		else
			puid = tonumber(waveInfoArray[i].m_id)
		end
		 
		local data = BattleDataManager:getMonsterDataById(puid)

		local x = tonumber(waveInfoArray[i].x)
		local y = tonumber(waveInfoArray[i].y)
		local monster
		if BattleDataManager.isBoss then
			monster = BattleBoss.new(data,x,y,teamManager)
		else
			monster = BattleMonster.new(data,x,y,teamManager)
		end
		
		table.insert(G_Monsters,monster)
		self:addChild(monster)
	end

	BattleRuntimeInfo.team2EntityNum = #G_Monsters--当前波里的怪的总数
end

function BattleEntityLayer:clearMonsters()
	for k,v in pairs(G_Monsters) do
		v.spineNode:setToSetupPose()
		v.spineNode:removeFromParent()
		v:removeFromParent()
	end
end

--每次切换场景时调用一下
function BattleEntityLayer:clearEntities()
	self.entities = {}
end
--每次切换场景时调用一下
function BattleEntityLayer:resetEntities()
	for k,v in pairs(G_Roles) do
		table.insert(self.entities,v)
	end

	for k,v in pairs(G_Monsters) do
		table.insert(self.entities,v)
	end
end

--复活的时候调用一下,靠左的小怪被击飞
function BattleEntityLayer:onRevive()
	if not BattleDataManager.isBoss then
		for k,v in pairs(G_Monsters) do
			if not v.isDead then
				v:setOrientation()
				local posInScreen = v:convertToWorldSpace(cc.p(0,0))
				if posInScreen.x <= 360 then
					local data = {}
					data.stateType = 4
					data.arg = 3
					v.fsm:changeState(StateEnum.UnusualCondition,data)
				end
			end
		end
	end
end