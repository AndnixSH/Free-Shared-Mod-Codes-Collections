require "BasicLayer"
--[[
--参数
  1.sFunc 关闭回调函数
  -- self.pictures = {
  --     "res/uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_001.png",
  --     "res/uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_002.png",
  --     "res/uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_003.png",
  -- }--test
]]
GuidePictureLayer = class("GuidePictureLayer",BasicLayer)
GuidePictureLayer.__index = GuidePictureLayer
GuidePictureLayer.lClass = 1

function GuidePictureLayer:initWithData(rData)
  --data
    KeyboardManager._isShowGuidePic = true
    rData.rcvData= rData.rcvData or {}
    self.rData = rData
    self.sManager = rData["sManager"]
    self.backFunc = rData["rcvData"]["sFunc"]
    self.sDelegate = rData["rcvData"]["sDelegate"]
    self.pictures =  rData["rcvData"]["pictures"] or {} --图片数组
    self.isShowGuide = rData["rcvData"]["isShowGuide"]
    -- self.pictures = {
    --   "res/uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_001.png",
    --   "res/uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_002.png",
    --   "res/uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_003.png",
    -- }--test

    self._totalNum = #self.pictures
    self._curIndex = 1 --从1开始 ，对应getCurrentPageIndex +1

    self.uiLayer = cc.Layer:create()
    local node = cc.CSLoader:createNode("GuideiPictureView.csb")
    self.uiLayer:addChild(node,0,1)
    self.rootNode = node:getChildByTag(10)

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("关闭按钮")
            self:closeEvent()
        end
    end
    self.closeBtn = ccui.Helper:seekWidgetByName(self.rootNode,"btn_close")
    self.closeBtn:addTouchEventListener(touchCallBack) 

    local pos = cc.p(self.closeBtn:getPositionX(),self.closeBtn:getPositionY()-34)
    
    local skeletonNode = sp.SkeletonAnimation:create("effects/pic_next_effect/wenzifaguang.json", "effects/pic_next_effect/wenzifaguang.atlas", 1.0)
    skeletonNode:setPosition(pos)
    self.rootNode:addChild(skeletonNode,1000)
    self.skeletonNode = skeletonNode
    self.skeletonNode:setAnimation(1, "effect", true)
    self.skeletonNode:setVisible(false)
    --左边按钮
    local function touchLeftCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:leftEvent()
        end
    end
    self.leftBtn = ccui.Helper:seekWidgetByName(self.rootNode,"btn_left")
    self.leftBtn:addTouchEventListener(touchLeftCallBack) 

    --右边按钮
    local function touchRightCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:rightEvent()
        end
    end
    self.rightBtn = ccui.Helper:seekWidgetByName(self.rootNode,"btn_right")
    self.rightBtn :addTouchEventListener(touchRightCallBack) 
    self:initPageView()
    self:setBtnState()
    
        --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:keyboardEvent()
    end)
    if self.isShowGuide then 
        self:addClip(pos)
    end 
end 

function GuidePictureLayer:addClip(pos)
    local data = {
        dialog = "",
        clipping = "n_UIShare/gacha/ck_b_002_2.png",
        clippingImg = "n_UIShare/gacha/ck_b_002_2.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
            a_Y = 0,
            a_Y = -30,
        },
        btn = {
            pos_X = pos.x,
            pos_Y = pos.y+40,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    }
    local clip = NGClippingNode:create(data)
    clip:setStencilVisible(true)
    self.uiLayer:addChild(clip,2)
end

function GuidePictureLayer:initPageView( )
   -- body
    local function pageViewEvent(sender, eventType)
        if eventType == ccui.PageViewEventType.turning then
            local pageView  = sender
            self._curIndex = pageView:getCurrentPageIndex() + 1
            print( self._curIndex)
            self:setBtnState()
        end
    end

    local pageView = ccui.Helper:seekWidgetByName(self.rootNode,"PageView")
    pageView:addEventListener(pageViewEvent)
    --下面是指示器
    if #self.pictures >1 then 
        pageView:setDirection(2)
        pageView:setIndicatorEnabled(true)
        pageView:setIndicatorPosition(cc.p(640,-80))
        pageView:setIndicatorSelectedIndexColor(cc.c3b(255, 255, 255))
        pageView:setIndicatorSpaceBetweenIndexNodes(14)
    else 
        pageView:setIndicatorEnabled(false)
    end

    self.pageView = pageView
    for i=1,#self.pictures do 
        local img = ccui.ImageView:create()
        img:setAnchorPoint(cc.p(0,0))
        img:loadTexture(self.pictures[i])
        img:setPosition(cc.p(0,0))

        local layout = ccui.Layout:create()
        layout:addChild(img,0,1)
        pageView:addPage(layout)
    end 
    pageView:setCurrentPageIndex(self._curIndex-1)
end
--left
function GuidePictureLayer:leftEvent()
    if self._curIndex < 1 then 
        return 
    end
    self._curIndex = self._curIndex - 1 
    self.pageView:scrollToPage(self._curIndex-1)
    self:setBtnState()
end
--right
function GuidePictureLayer:rightEvent()
    if self._curIndex > self._totalNum then 
        return 
    end
    self._curIndex = self._curIndex + 1 
    self.pageView:scrollToPage(self._curIndex-1)
    self:setBtnState()
end
--设置按钮状态
function GuidePictureLayer:setBtnState()
    if  self._totalNum<=1 then 
        self.pageView:setIndicatorEnabled(false)
        self.rightBtn:setVisible(false)
        self.leftBtn:setVisible(false)
        self.closeBtn:setVisible(true)
        self:showEffect()
    else 
        self.pageView:setIndicatorEnabled(true)
        if self._curIndex <=1 then 
            self.closeBtn:setVisible(false)
            self.rightBtn:setVisible(true)
            self.leftBtn:setVisible(false)
            self.skeletonNode:setVisible(false)
        elseif self._curIndex > 1 and self._curIndex < self._totalNum then 
            self.closeBtn:setVisible(false)
            self.rightBtn:setVisible(true)
            self.leftBtn:setVisible(true)
            self.skeletonNode:setVisible(false)
        elseif  self._curIndex == self._totalNum then
            self.closeBtn:setVisible(true)
            self.rightBtn:setVisible(false)
            self.leftBtn:setVisible(true)
            self:showEffect()
        end         
    end 
end

function GuidePictureLayer:showEffect()
    -- body
    self.skeletonNode:setVisible(true)
end

function GuidePictureLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function GuidePictureLayer:closeEvent()
    KeyboardManager._isShowGuidePic = false
    if self.backFunc ~= nil then 
        self.backFunc(self.sDelegate)
    end 
    self.skeletonNode:removeFromParent(true)
    self:clearEx()
end

function GuidePictureLayer:keyboardEvent(  )
    if self._curIndex < self._totalNum then 
        self:rightEvent()
    else
        self:closeEvent()
    end
end

function GuidePictureLayer:create(rData)
    local layer = GuidePictureLayer.new()
    layer:initWithData(rData)
    return layer
end