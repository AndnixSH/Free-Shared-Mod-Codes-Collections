--require "XUICellView"

NewRoleDataItemView = class("NewRoleDataItemView", XUICellView)
NewRoleDataItemView.CS_FILE_NAME = "NewRoleDataItemView.csb"
NewRoleDataItemView.CS_BIND_TABLE = 
{
    PropTitleSp = "/i:255/i:256",
    PropTitle = "/i:255/i:257",
    numProp = "/i:255/i:258",
    numPropAdd = "/i:255/i:259",
}

function NewRoleDataItemView:init(...)
    NewRoleDataItemView.super.init(self,...)

    return self
end

function NewRoleDataItemView:refresh()
    if not self.index then
        return
    end
    self:RefreshState()
end

function NewRoleDataItemView:RefreshState()
    if not self.index then
        return
    end
    local dataIndex = self._data["dataIndex"]
    local dataSpPath = self._data["dataSpPath"]
    local dataName = self._data["dataName"]
    local dataNum = self._data["dataNum"]
    local dataNumAdd = self._data["dataNumAdd"]
    local dataTextColor = self._data["dataTextColor"]

    if dataSpPath then
        self.PropTitleSp:setTexture(dataSpPath)
    end
    if dataName then
        self.PropTitle:setString(dataName)
        if g_channel_control.transform_NewRoleDataItemView_PropTitle_posAndfontSize == true then
            self.PropTitle:setFontSize(20)
            local oldX = self.PropTitle:getPositionX()
            local newX = oldX - 14
            self.PropTitle:setPositionX(newX)
        end
    end
    if dataNum then
        self.numProp:setString(dataNum)
        if g_channel_control.transform_NewRoleDataItemView_numProp_fontSize == true then
            self.numProp:setFontSize(20)
        end
    end
    if dataNumAdd then
        self.numPropAdd:setString(dataNumAdd)
        if g_channel_control.transform_NewRoleDataItemView_numPropAdd_fontSize == true then
            self.numPropAdd:setFontSize(20)
        end
    else
        self.numPropAdd:setString("")
    end
    if dataTextColor then
        self.numProp:setColor(dataTextColor)
    end
end

function NewRoleDataItemView:SetDataIndex(nIndex)
    self.index = nIndex
    self:refresh()
end



