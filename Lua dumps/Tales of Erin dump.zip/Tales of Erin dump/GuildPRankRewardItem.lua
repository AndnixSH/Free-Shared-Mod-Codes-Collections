--[[
--公会塔奖励 item
GuildPRankRewardItem.lua
]]
GuildPRankRewardItem = class("GuildPRankRewardItem", XUICellView)
GuildPRankRewardItem.CS_FILE_NAME = "GuildPRankRewardItem.csb"
GuildPRankRewardItem.CS_BIND_TABLE = 
{
    rootPanel = "/s:panel",
    touchPanel = "/s:panel"
}

function GuildPRankRewardItem:init(...)
    GuildPRankRewardItem.super.init(self,...)
    self.isSelect = false
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    --self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)
    return self
end

--重置UI
function GuildPRankRewardItem:onResetData()
    if not self._data then return end
    local data = self._data
    local rank = data.rank_num
    local root = self.rootPanel

    local name = root:getChildByName("name")
    name:setString(UITool.getUserLanguage(data.name))
    local showInfo2 = root:getChildByName("name_2")
    if self.subType == 1 then 
    	showInfo2:setVisible(true)
        showInfo2:setString(UITool.ToLocalization("每五层奖励"))
    else 
		showInfo2:setVisible(false)
	end 
   
    for i=1,4 do 
    	local itemRoot = root:getChildByName("listitem_"..i)
        if itemRoot~=nil then 
            if data.reward_list[i] ~= nil then  
                self:dealIcon(data.reward_list[i],itemRoot)
            else 
                self:showNoReward(itemRoot)
            end 
        end 
    end 
end

--没有奖励的状态
function GuildPRankRewardItem:showNoReward(root)
    local bg =  root:getChildByName("bg_1")
    local icon = root:getChildByName("icon_2")
    local kuang = root:getChildByName("kuang_3")
    local element = root:getChildByName("element_4")
    local num = root:getChildByName("num")
    bg:setVisible(true)
    kuang:setVisible(true)
    icon:setVisible(false)
   
    element:setVisible(false)
    num:setVisible(false)

    bg:loadTexture(Rarity_BG[5])
    kuang:loadTexture(Rarity_mat[3])
end

function GuildPRankRewardItem:dealIcon(reward,root,itemName)
    local tabs = UITool.getItemInfos(reward.reward_type,reward.reward_id)
    if tabs == nil then
        return
    end
    local bg =  root:getChildByName("bg_1")
    local icon = root:getChildByName("icon_2")
    local kuang = root:getChildByName("kuang_3")
    local element = root:getChildByName("element_4")
    local num = root:getChildByName("num")
    
    icon:setVisible(true)
    element:setVisible(true)
    num:setVisible(true)

    kuang:loadTexture(tabs[1])
    icon:setUnifySizeEnabled(true)
    icon:loadTexture(tabs[2])
    num:setString("x"..reward.reward_num)
    if tabs[3] == "" then 
        element:setVisible(false)
    else
        element:loadTexture(tabs[3])
    end

    if tabs[4]~= "" then 
        bg:loadTexture(tabs[4])
    end
    --显示道具详情
    local function CallBackEvent( sender,eventType )
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()
            local l = cc.pGetDistance(p1,p2) 
            if l < 30 then
 				MsgManager:showSimpItemInfo(reward.reward_type,reward.reward_id)
            end
        end
    end 
    icon:addTouchEventListener(CallBackEvent)
    icon:setSwallowTouches(false)

    if itemName then 
    	itemName:setString(tabs[5].."x"..reward.reward_num)
    end 
end
