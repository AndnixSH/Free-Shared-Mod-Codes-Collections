--毒的组件
--created by kobejaw.2018.6.30.
Com_D_Poison = class("Com_D_Poison",ComponentBase)

function Com_D_Poison:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 2
	self.buffType = Com_DebuffEnum.Poison

	self.seconds_poison = self.comData.effect1 --每几秒掉一次血
	self.remainTime_poison = 0

	if self.option and self.option.attacker then
		if self.comData.effect3 ~= 0 then
			self.damage = math.ceil(self.comData.effect3/1000 * BattleDamageCompute:getSoloATK(self.option.attacker.attributeManager:getAttack()))  
		elseif self.comData.effect4 ~= 0 then
			self.damage = math.ceil(self.comData.effect4/1000 * self.target.attr[AE.hp_max])
		else
			print("纠错，不该执行到这里。Com_D_Poison 1")
			self.damage = GetRandomBetweenAB(90,110);			
		end
	else
		print("纠错，不该执行到这里。Com_D_Poison 2")
		self.damage = GetRandomBetweenAB(90,110);
	end
end

function Com_D_Poison:update(dt)
	self.remainTime_poison = self.remainTime_poison - dt
	if self.remainTime_poison <= 0 then
		--播放特效
		self:playSpineAnimation(false)

		self.remainTime_poison = self.seconds_poison

		if self.option.attacker and self.option.attacker.isBoss and self.option.attacker.isDead then
			self.damage = 0
		end

		BattleDamageCompute:computeDamage_FixedDmg(self.damage,self.target,1)
	end

	self.super.update(self,dt)
end