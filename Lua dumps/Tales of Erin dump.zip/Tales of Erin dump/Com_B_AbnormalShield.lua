--异常护盾组件
--created by kobejaw. 2018.6.8.
Com_B_AbnormalShield = class("Com_B_AbnormalShield",ComponentBase)

function Com_B_AbnormalShield:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.AbnormalShield
end
