
require "BasicLayer"
require_ex("explain_help")
---------大型活素材详细
PublicHelpText = class("PublicHelpText",BasicLayer)
PublicHelpText.__index = PublicHelpText
PublicHelpText.lClass  = 3                     ------  锻造弹窗tag 555
PublicHelpText.rData = nil
--[[
    --data     数据
    prefix     前缀（如explain_help） 根据前缀去读当前界面说明 
    titleName  标题
    fontSize   设置字体的大小
]]
function PublicHelpText:init()
    print("进入了msgModel 界面")
    local node =cc.CSLoader:createNode("GuildHelpTextLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self._csbNode = node
    -- 获取scroView
    self.scorView      = self._csbNode:getChildByName("ScrollView_1")

    -- 显示文本
    self._desc         = self.scorView:getChildByName("Text_1")
    -- 图片帮助按钮
    self.ImageHelp_btn = self._csbNode:getChildByName("btnHelp")

    self.panel_1       = self._csbNode:getChildByName("Panel_1")
    --[[每个界面都有不同的前缀  prefix]]
   
    if self.rData["rcvData"]["prefix"] then
        self.data_table = explain_help[self.rData["rcvData"]["prefix"]]
        if self.data_table ~=nil then
           self:setScorAre()
           self:setDesc()
        end    
        
    else
        --没有数据暂未处理
    end
    --[[如果需要设置title 需要未此字段赋值]]
    if self.rData["rcvData"]["titleName"] then
        self:setTitle(self.rData["rcvData"]["titleName"])
    end
    --[[如果要设置字体的大小 需要未此字段赋值]]
    if self.rData["rcvData"]["fontSize"] then
        self:setLableFont(self.rData["rcvData"]["fontSize"])
    end
    --[[又上的 图片帮助按钮]]
    if self.rData["rcvData"]["Iamgdata"] then

        self.ImageHelp_btn:addClickEventListener(function()

            self:showHelpImage(self.rData["rcvData"]["Iamgdata"])

        end)
      
    end
    -- 点击panel 关闭按钮
    self.panel_1:addClickEventListener(function()

            self:returnBack()

    end)

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
   
end

--设置可滑动的区域
function PublicHelpText:setScorAre( ... )
    -- body
    local fontS = 22
    local max   = self.data_table["max"]
    local startIndex = self.data_table["startNum"]
    local endIndex   = self.data_table["endNum"]
    local nTotalHangNum = 1 + 1--满滑状态下底部增加一行空行

    local pat = "(.-)" .. "\n" .. "()"
    local maxNb = 0

    for i = startIndex , endIndex do
        local str = self.data_table[i]
        local nb = 0
        for part, pos in string.gfind(str, pat) do
            nb = nb + 1
            if nb == maxNb then break end
        end
        nTotalHangNum = nTotalHangNum + nb
    end

    local innerWidth = 1
    local innerHeight = 1
    local fontRate = g_channel_control.transform_PublicHelpText_fontRate or 1.0
    if self.rData["rcvData"]["fontSize"] then
        fontS = self.rData["rcvData"]["fontSize"]
        innerWidth = 1026
        innerHeight = fontS*fontRate * nTotalHangNum
    else
        innerWidth = 1026
        innerHeight = 22* fontRate* nTotalHangNum
    end
    self.scorView:setInnerContainerSize(cc.size(innerWidth, innerHeight))  
    local scollViewHeight = self.scorView:getSize().height
    if scollViewHeight then
        if innerHeight > scollViewHeight then
            self._desc:setPosition(cc.p(37,innerHeight-10))
        else
            self._desc:setPosition(cc.p(37,scollViewHeight-10))
        end
    end

end
--设置Lable字体的大小
function PublicHelpText:setLableFont( fontSize )
    -- body
    self._desc:setFontSize(fontSize)
end
-- 根据文本读取拼接 显示出来
function PublicHelpText:setDesc( ... )
    -- body
    local max = self.data_table["max"]
    local startIndex = self.data_table["startNum"]
    local endIndex   = self.data_table["endNum"]
    print("str str str == "..self.data_table[startIndex])
    print("stratNum stratNum stratNum == "..self.data_table["startNum"])
    print("endNum endNum endNum == "..self.data_table["endNum"])
    local str = ""
    for i = startIndex , endIndex do
        str = str..UITool.getUserLanguage(self.data_table[i])--self.data_table[i]
    end
    print("str str str == "..self.data_table[startIndex])
    self._desc:setString(UITool.ToLocalization(str))
end
-- 设置标题
function PublicHelpText:setTitle( sName )
    -- body
    local title = self._csbNode:getChildByName("Text_2")
    title:setString(sName)
end
-- 设置帮助图片
function PublicHelpText:showHelpImage( data )
    -- body
    SceneManager:toGuidePictureLayer(data)
end



function PublicHelpText:returnBack( ... )
	-- body
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)

    self.exist = false
    self:clear()


end


function PublicHelpText:create(tdata,sManager)

     local msgModel = PublicHelpText.new()
	 msgModel.rData = tdata 
	 msgModel.sManager  = sManager
     msgModel.uiLayer = cc.Layer:create()
     msgModel:init()
     return msgModel
end