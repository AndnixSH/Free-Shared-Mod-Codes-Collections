--战斗相关全局定义
--created by kobejaw.2018.3.16.

BattleGlobals = {}
StateEnum = {} --战斗状态
MsgType = {}   --战斗消息
BattleZOrder = {}
SpineAnimationName = {} --动画名称
SpineEventName = {}     --事件名称
DamageFontType = {}     --伤害飘字的类型
ComTriggerTime = {}     --组件触发时机
ComTriggerType = {}     --组件触发器类型

--资源预加载相关
BattleGlobals.BOSS_MODE_OD_SPINE = "armatures/monster/Boss_kuangbao/Boss_kuangbao.atlas"
BattleGlobals.BOSS_SHOW = "effects/Bossdengchang/Bossdengchang.atlas"  --显示boss出现
BattleGlobals.DeadEffect = "armatures/monster/deadeffect/deadeffect.atlas"

BattleGlobals.CutInEffect_water = "effects/cutin/Shui/Shui/Shui_1.atlas"
BattleGlobals.CutInEffect_fire = "effects/cutin/HuoYan/Huoyan/Huoyan_2.atlas";
BattleGlobals.CutInEffect_wind = "effects/cutin/Feng/Feng/Feng_3.atlas";
BattleGlobals.CutInEffect_light = "effects/cutin/Guang/Guang/Guang_4.atlas";
BattleGlobals.CutInEffect_dard = "effects/cutin/An/An/An_5.atlas";

BattleGlobals.HPBAR = "uifile/HPBar.csb"
BattleGlobals.HP_Res_role = "uifile/n_UIShare/zhandou/zdjm_ui_002_1.png"
BattleGlobals.HP_Res_monster = "uifile/n_UIShare/zhandou/zdjm_ui_002_2.png"

-- 显示失败的特效
BattleGlobals.DEFEATE_EFFECT = "effects/zhandoushibai/zhandoushibai.atlas"
-- 显示胜利特效
BattleGlobals.VICTORY_EFFECT = "effects/zhandoushengli/zhandoushengli.atlas"
--通用音效
BattleGlobals.Sound_CutIn = "music/ui/cutin_se_1.mp3"
BattleGlobals.Sound_BossDead = "music/GarageBand/gei_com.wav"
BattleGlobals.Sound_Revive = "music/GarageBand/buff.mp3"--复活音效
BattleGlobals.Sound_Debuff = "music/GarageBand/debuff.mp3"
BattleGlobals.Sound_Buff = "music/GarageBand/buff.mp3"
BattleGlobals.Sound_BossShow = "music/ui/bossstart.mp3" --boss战的警报声
BattleGlobals.Sound_Heal = "music/zhiliao.mp3"    --治疗音效

--图层
BattleZOrder.BG = 1
BattleZOrder.Entity = 2
BattleZOrder.Effect = 3

--所有动作名
SpineAnimationName.Idle = "loading"--待机动作
SpineAnimationName.Run = "run"     --走路
SpineAnimationName.Attack = "singleattack"  --普通攻击
SpineAnimationName.Skill = "attack"         --小技能
SpineAnimationName.BigSkill = "bigskill"    --大技能
SpineAnimationName.Float = "float" --浮空
SpineAnimationName.StandUp1 = "up1" --起身1
SpineAnimationName.StandUp2 = "up2"  --起身2
SpineAnimationName.Idle2 = "loading2" --boss BK状态。待验证。已废弃。
SpineAnimationName.BeHit = "behit"
SpineAnimationName.Dead = "dead"

--所有事件名
SpineEventName.PlayEffect1 = "Autoplay1"--播放特效。对应skill.lua中的skill_play_hit这个数组，即播放哪个特效。1对应第一个，2对应第2个
SpineEventName.CauseDamage1 = "attack1" --造成伤害。对应skill.lua中的skill_attack_hit这个数组，即攻击相关的数值（伤害，范围，是否加buff等）。1对应第一个，2对应第二个
SpineEventName.CauseDamage2 = "attack2"
SpineEventName.CauseDamage3 = "attack3"
SpineEventName.CauseDamage4 = "attack4"
SpineEventName.CauseDamage5 = "attack5"
SpineEventName.CauseDamage6 = "attack6"
SpineEventName.PlayMusic = "playmusic"
SpineEventName.Shake1 = "shake1"
SpineEventName.Shake2 = "shake2"
SpineEventName.Shake3 = "shake3"
SpineEventName.CutIn = "cutin"
SpineEventName.EndCutIn = "endcutin"

--EntityType
BattleGlobals.EntityType = {}
BattleGlobals.EntityType.Role = 1;
BattleGlobals.EntityType.Monster = 2;

--战场大小相关的常量
BattleGlobals.BOX_W = 50;  --每个格子的宽度(初始化角色的时候按80算，其他时候按50算)
BattleGlobals.BOX_H = 50;  --每个格子的高度
BattleGlobals.BOX_N = 3;   --战场分为3行
BattleGlobals.localMinY = 150;   --战场y最小值
BattleGlobals.localMaxY = 150 + BattleGlobals.localMinY - 25;   --战场y最大值

--触发镜头跟随的在屏幕上坐标的最左侧和最右侧值。
BattleGlobals.CameraScroll_LeftX = 256  --1280*0.2
BattleGlobals.CameraScroll_RightX = 640 --1280*0.5
BattleGlobals.CameraScroll_RightX_NoMellee = 384 --1280*0.3 无近战时的情况
BattleGlobals.CameraSpeed = 5.5  --镜头移动的速度，每帧像素值

--按住技能图标多长时间弹出技能介绍
BattleGlobals.TouchTimeForSkillInfoShow = 0.6

--朝向
BattleGlobals.FaceLeft = 1;
BattleGlobals.FaceRight = 2;

--体积类型,
BattleGlobals.CubageType = {}
BattleGlobals.CubageType.Type1 = 0; --1*1
BattleGlobals.CubageType.Type2 = 2; --5*1
BattleGlobals.CubageType.Type3 = 3; --7*1

--普攻类型。对应Attack.lua中的attack_type
BattleGlobals.AttackType = {}
BattleGlobals.AttackType.Type0 = 0;--无普通攻击，只有技能攻击。部分怪物有这种配置。
BattleGlobals.AttackType.Type1 = 1;--近战
BattleGlobals.AttackType.Type2 = 2;--法师爆炸。隔空打，无子弹
BattleGlobals.AttackType.Type3 = 3;--远程。有子弹。

--所有角色状态
StateEnum.RunningToEnemy = 1
StateEnum.RunningToPosition = 2
StateEnum.Attacking = 3
StateEnum.PlayingSkill_Self = 4  --自身类技能
StateEnum.PlayingSkill_Scene = 5  --场景类技能
StateEnum.PlayingSkill_StraightLine = 6 --直线贯穿类技能
StateEnum.PlayingSkill_Target_Entity = 7       --选取目标类技能，在目标身上生效
StateEnum.PlayingSkill_Target_Pos = 8          --选取目标类技能，在目标位置生效
StateEnum.Idling = 9
StateEnum.UnusualCondition = 10--异常状态。击飞，击倒，浮空，击退。注：眩晕，麻痹等放在buff里。
StateEnum.Attacking_Boss = 11  --boss的攻击状态
StateEnum.Dead = 12           --已经死了，死亡动画的播放过程中
StateEnum.Posing = 13            --摆pose，目前只有尤娜用到了

--战斗消息
MsgType.HitByAttack = 1
MsgType.HitBySkill = 2
MsgType.SkillClicked = 3
MsgType.BigSkillClicked = 4
MsgType.RunToEnemy = 5--来自玩家手动选中某个怪
MsgType.RunToPos = 6  --来自玩家手动选中某个地块

--飘字类型
DamageFontType.Normal      = 1       --普通    (人物的普通攻击)
DamageFontType.M_Normal    = 2       --怪物普通 (怪物的普通攻击)
DamageFontType.Skill       = 3       --技能伤害 (没有暴击的技能伤害)
DamageFontType.AddHP       = 4       --加血    
DamageFontType.Miss        = 5       --未命中     (未命中 闪避 免疫 吸收 格挡 都属于此类型)
DamageFontType.Dodge       = 6       -- 闪避
DamageFontType.Immune      = 7       -- 免疫
DamageFontType.Absorb      = 8       -- 吸收
DamageFontType.Block       = 9       -- 格挡
DamageFontType.AddHP_Crit  = 10  	 --加血暴击
DamageFontType.Normal_Crit = 11      --普通暴击
DamageFontType.Poison      = 12      --中毒
DamageFontType.SelfHPLoss  = 13      --自身掉血（有些技能减自己的血）
DamageFontType.Crit_Block  = 14      --暴击被格挡

--组件触发时机(注：C++中定义过但是从来没用到的触发时机和触发器类型lua暂不考虑)
--注意区分“前”和“后”
ComTriggerTime.ZHANQIAN = 0          	--战前计算（客户端不需要处理）   1,3,4
ComTriggerTime.PTATK = 1           	--普攻造成伤害后               1,3,4,8,13 
ComTriggerTime.SKATK = 2         	--主动技能造成伤害后（可能增加固定伤害，或者判定是否暴击）              11,1,14  
ComTriggerTime.SKILL = 3             	--进入技能状态时                 11(两种情况，特定技能或者随意技能)
ComTriggerTime.ON_HIT = 4           	--受击时。（伤害计算后，对defender触发）                     1,2,4,6,7            
ComTriggerTime.ON_ZL  = 5           	--被治疗时                   1,10                  
ComTriggerTime.HP_CHANGE = 7       	--hp发生变化                 2                     
ComTriggerTime.PR_JL     = 9        	--女主降临                    1,3                  
ComTriggerTime.ON_DEAD      = 10     	      --死亡时                      1
ComTriggerTime.B_START      = 11  	--战斗开始时                  1
ComTriggerTime.ON_CD        = 12    	--cd类型，每隔多少秒           1,4
ComTriggerTime.ON_MISS_BUFF = 13    	--buff debuff消失时（包括被移除和时间到了消失两种场景）           9
ComTriggerTime.ON_BUFF = 14         	--当获取某种buff时             4,9,16
ComTriggerTime.ON_LJ        = 15    	--连击发生变化时              12
ComTriggerTime.ON_SKCOM     = 16     --用于主动技能计算伤害前 1,4,16,17,21。跟时机2是同一个时机，区别在于一个配在主动里一个在被动里。

--Boss状态切换时，向所有玩家广播。
ComTriggerTime.ON_MODE_CHANGE = 6  

--针对我方全体的检测
ComTriggerTime.ON_T_PTATK   = 101    	--队友普攻造成伤害前（目前只有提线傀儡），影响被动技能拥有者               4
ComTriggerTime.ON_SKILL_HIT = 102       --队友技能造成伤害时,影响被动技能拥有者。2018.11.23新增.
ComTriggerTime.ON_T_SKILL   = 103  	--我方角色进入技能状态时，影响被动技能拥有者               11 
ComTriggerTime.ON_T_HIT     = 104   	--队友受到伤害后（全体和提线傀儡两种情况），影响被动技能拥有者                   1,4
ComTriggerTime.ON_T_HP_MISS_BUFF = 113	--我方角色失去buffdebuff时，影响被动技能拥有者       9
--如果是影响触发者的，走服务器，目前只有5413201。

--组件触发器类型
ComTriggerType.BATE_TRIG = 1-- 基础触发器，只有概率 触发的时机 以及 cd           --2,4,5,9,10,11,12,16,104。
ComTriggerType.HP_TRIG = 2  -- hp触发器。场景：当生命值低于xx时。                  --4,7
ComTriggerType.STATE_TRIG=3-- odBK触发器                                      --1,6,9
ComTriggerType.STATE_TRIG_ONE = 4--身上是否有某个buff或debuff            --1,3,12,14,16,101,104
ComTriggerType.HIT_TRIG = 6  --累计受到多少次伤害                               --4
ComTriggerType.GMG_TRIG = 7--累计多少伤害                                      --4
ComTriggerType.ATK_TRIG = 8-- 每进行多少次攻击                                 --1
ComTriggerType.MISS_BUFF_TRIG = 9--是否是当前获得或者失去的buff或debuff。                               --13,14,113
ComTriggerType.HEL_TRIG = 10 --和时机5配合使用。受到治疗时 --注：走类型1的逻辑     --5
ComTriggerType.SK_TRIG = 11--使用某个技能                                      --2,3,103
ComTriggerType.LJ_TRIG = 12-- 连击触发器                                       --15
ComTriggerType.PTATK_TRIG = 13-- 和时机1配合使用，用于普攻暴击时。                   --1
ComTriggerType.SKILL_HIT = 14 --技能造成伤害时.主要用于是否发生暴击的检测。2018.11.23新增.
ComTriggerType.DIS_TRIG = 15 --距离
ComTriggerType.STATE_BUFF = 16-- 增减益                                        --16,14
ComTriggerType.CHECK_P    = 17-- 判断是否属于某个种族，势力，性别        	         --16。--放在这里导致逻辑混乱，废弃，移动至target_type
--新增
ComTriggerType.CHECK_P_NUM   = 18-- 判断某个种族，势力，性别的总数是否等于或大于小于某个值 
ComTriggerType.CHECK_TYPE_19   = 19 --判定整个队伍中种族，势力，性别等的种类。
ComTriggerType.CHECK_TYPE_22   = 22 --降临值信息
ComTriggerType.CHECK_TYPE_23   = 23 --受到单次伤害大于某值
ComTriggerType.CHECK_TYPE_24   = 24 --每受到xx伤害。参数的作用跟类型7一样。
--ComTriggerType.CHECK_TYPE_21   = 21 --判定是否是某个属性值最高或者最低的角色。         --放在这里导致逻辑混乱，废弃，移动至target_type


--优化相关。2018.9.29.
--逻辑的优化
--每两帧更新一次:ActiveSkillManager
--角色的组件和触发器管理器在奇数帧更新，怪物的在偶数帧更新。注：fsm暂时每帧更新。

--TODO,渲染效率优化
