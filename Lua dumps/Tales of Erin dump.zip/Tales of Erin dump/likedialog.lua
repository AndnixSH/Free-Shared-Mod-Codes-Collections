likedialog = {}
-- 序列ID = 标签, 解锁好感度大于, 解锁后正文内容
-- 角色备注 = 乌拉基米露
likedialog[11] = { 
    {
        title = "133589",
        unlock_lv = 50,
        content = "133850",
        unlockable = 1
    }, 
    {
        title = "133590",
        unlock_lv = 100,
        content = "133851",
        unlockable = 1
    }, 
    {
        title = "133591",
        unlock_lv = 200,
        content = "133852",
        unlockable = 1
    }, 
}
-- 角色备注 = 阿尔芬
likedialog[13] = { 
    {
        title = "133592",
        unlock_lv = 50,
        content = "133853",
        unlockable = 1
    }, 
    {
        title = "133593",
        unlock_lv = 100,
        content = "133854",
        unlockable = 1
    }, 
    {
        title = "133594",
        unlock_lv = 200,
        content = "133855",
        unlockable = 1
    }, 
}
-- 角色备注 = 塞拉斯
likedialog[23] = { 
    {
        title = "133595",
        unlock_lv = 50,
        content = "133856",
        unlockable = 1
    }, 
    {
        title = "133596",
        unlock_lv = 100,
        content = "133857",
        unlockable = 1
    }, 
    {
        title = "133597",
        unlock_lv = 200,
        content = "133858",
        unlockable = 1
    }, 
}
-- 角色备注 = 祈里
likedialog[24] = { 
    {
        title = "133598",
        unlock_lv = 50,
        content = "133859",
        unlockable = 1
    }, 
    {
        title = "133599",
        unlock_lv = 100,
        content = "133860",
        unlockable = 1
    }, 
    {
        title = "133600",
        unlock_lv = 200,
        content = "133861",
        unlockable = 1
    }, 
}
-- 角色备注 = 涅菲鲁
likedialog[36] = { 
    {
        title = "133601",
        unlock_lv = 50,
        content = "133862",
        unlockable = 1
    }, 
    {
        title = "133602",
        unlock_lv = 100,
        content = "133863",
        unlockable = 1
    }, 
    {
        title = "133603",
        unlock_lv = 200,
        content = "133864",
        unlockable = 1
    }, 
}
-- 角色备注 = 凯蒂
likedialog[37] = { 
    {
        title = "133604",
        unlock_lv = 50,
        content = "133865",
        unlockable = 1
    }, 
    {
        title = "133605",
        unlock_lv = 100,
        content = "133866",
        unlockable = 1
    }, 
    {
        title = "133606",
        unlock_lv = 200,
        content = "133867",
        unlockable = 1
    }, 
}
-- 角色备注 = 席洛
likedialog[51] = { 
    {
        title = "133607",
        unlock_lv = 50,
        content = "133868",
        unlockable = 1
    }, 
    {
        title = "133608",
        unlock_lv = 100,
        content = "133869",
        unlockable = 1
    }, 
    {
        title = "133609",
        unlock_lv = 200,
        content = "133870",
        unlockable = 1
    }, 
}
-- 角色备注 = 魅娅
likedialog[61] = { 
    {
        title = "133610",
        unlock_lv = 50,
        content = "133871",
        unlockable = 1
    }, 
    {
        title = "133611",
        unlock_lv = 100,
        content = "133872",
        unlockable = 1
    }, 
    {
        title = "133612",
        unlock_lv = 200,
        content = "133873",
        unlockable = 1
    }, 
}
-- 角色备注 = 莉法
likedialog[62] = { 
    {
        title = "133613",
        unlock_lv = 50,
        content = "133874",
        unlockable = 1
    }, 
    {
        title = "133614",
        unlock_lv = 100,
        content = "133875",
        unlockable = 1
    }, 
    {
        title = "133615",
        unlock_lv = 200,
        content = "133876",
        unlockable = 1
    }, 
}
-- 角色备注 = 莎夏
likedialog[76] = { 
    {
        title = "133616",
        unlock_lv = 50,
        content = "133877",
        unlockable = 1
    }, 
    {
        title = "133617",
        unlock_lv = 100,
        content = "133878",
        unlockable = 1
    }, 
    {
        title = "133618",
        unlock_lv = 200,
        content = "133879",
        unlockable = 1
    }, 
}
-- 角色备注 = 库拉夏
likedialog[101] = { 
    {
        title = "133619",
        unlock_lv = 50,
        content = "133880",
        unlockable = 1
    }, 
    {
        title = "133620",
        unlock_lv = 100,
        content = "133881",
        unlockable = 1
    }, 
    {
        title = "133621",
        unlock_lv = 200,
        content = "133882",
        unlockable = 1
    }, 
}
-- 角色备注 = 阿温娜
likedialog[103] = { 
    {
        title = "133622",
        unlock_lv = 50,
        content = "133883",
        unlockable = 1
    }, 
    {
        title = "133623",
        unlock_lv = 100,
        content = "133884",
        unlockable = 1
    }, 
    {
        title = "133624",
        unlock_lv = 200,
        content = "133885",
        unlockable = 1
    }, 
}
-- 角色备注 = 阿玛娜
likedialog[116] = { 
    {
        title = "133625",
        unlock_lv = 50,
        content = "133886",
        unlockable = 1
    }, 
    {
        title = "133626",
        unlock_lv = 100,
        content = "133887",
        unlockable = 1
    }, 
    {
        title = "133627",
        unlock_lv = 200,
        content = "133888",
        unlockable = 1
    }, 
}
-- 角色备注 = 艾露薇
likedialog[117] = { 
    {
        title = "133628",
        unlock_lv = 50,
        content = "133889",
        unlockable = 1
    }, 
    {
        title = "133629",
        unlock_lv = 100,
        content = "133890",
        unlockable = 1
    }, 
    {
        title = "133630",
        unlock_lv = 200,
        content = "133891",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[132] = { 
    {
        title = "601229",
        unlock_lv = 50,
        content = "601238",
        unlockable = 1
    }, 
    {
        title = "601230",
        unlock_lv = 100,
        content = "601239",
        unlockable = 1
    }, 
    {
        title = "601231",
        unlock_lv = 200,
        content = "601240",
        unlockable = 1
    }, 
}
-- 角色备注 = 艾卡姆
likedialog[142] = { 
    {
        title = "133631",
        unlock_lv = 50,
        content = "133892",
        unlockable = 1
    }, 
    {
        title = "133632",
        unlock_lv = 100,
        content = "133893",
        unlockable = 1
    }, 
    {
        title = "133633",
        unlock_lv = 200,
        content = "133894",
        unlockable = 1
    }, 
}
-- 角色备注 = 米拉弗斯
likedialog[156] = { 
    {
        title = "133634",
        unlock_lv = 50,
        content = "133895",
        unlockable = 1
    }, 
    {
        title = "133635",
        unlock_lv = 100,
        content = "133896",
        unlockable = 1
    }, 
    {
        title = "133636",
        unlock_lv = 200,
        content = "133897",
        unlockable = 1
    }, 
}
-- 角色备注 = 丝拉夏
likedialog[157] = { 
    {
        title = "133637",
        unlock_lv = 50,
        content = "133898",
        unlockable = 1
    }, 
    {
        title = "133638",
        unlock_lv = 100,
        content = "133899",
        unlockable = 1
    }, 
    {
        title = "133639",
        unlock_lv = 200,
        content = "133900",
        unlockable = 1
    }, 
}
-- 角色备注 = 达琪丝
likedialog[181] = { 
    {
        title = "133640",
        unlock_lv = 50,
        content = "133901",
        unlockable = 1
    }, 
    {
        title = "133641",
        unlock_lv = 100,
        content = "133902",
        unlockable = 1
    }, 
    {
        title = "133642",
        unlock_lv = 200,
        content = "133903",
        unlockable = 1
    }, 
}
-- 角色备注 = 皮莉莉恩
likedialog[182] = { 
    {
        title = "133643",
        unlock_lv = 50,
        content = "133904",
        unlockable = 1
    }, 
    {
        title = "133644",
        unlock_lv = 100,
        content = "133905",
        unlockable = 1
    }, 
    {
        title = "133645",
        unlock_lv = 200,
        content = "133906",
        unlockable = 1
    }, 
}
-- 角色备注 = 莱姆
likedialog[183] = { 
    {
        title = "133646",
        unlock_lv = 50,
        content = "133907",
        unlockable = 1
    }, 
    {
        title = "133647",
        unlock_lv = 100,
        content = "133908",
        unlockable = 1
    }, 
    {
        title = "133648",
        unlock_lv = 200,
        content = "133909",
        unlockable = 1
    }, 
}
-- 角色备注 = 米赛尔
likedialog[184] = { 
    {
        title = "133649",
        unlock_lv = 50,
        content = "133910",
        unlockable = 1
    }, 
    {
        title = "133650",
        unlock_lv = 100,
        content = "133911",
        unlockable = 1
    }, 
    {
        title = "133651",
        unlock_lv = 200,
        content = "133912",
        unlockable = 1
    }, 
}
-- 角色备注 = 米蕾妮
likedialog[196] = { 
    {
        title = "133652",
        unlock_lv = 50,
        content = "133913",
        unlockable = 1
    }, 
    {
        title = "133653",
        unlock_lv = 100,
        content = "133914",
        unlockable = 1
    }, 
    {
        title = "133654",
        unlock_lv = 200,
        content = "133915",
        unlockable = 1
    }, 
}
-- 角色备注 = 芙拉米
likedialog[305] = { 
    {
        title = "133655",
        unlock_lv = 50,
        content = "133916",
        unlockable = 1
    }, 
    {
        title = "133656",
        unlock_lv = 100,
        content = "133917",
        unlockable = 1
    }, 
    {
        title = "133657",
        unlock_lv = 200,
        content = "133918",
        unlockable = 1
    }, 
}
-- 角色备注 = 拉比丝
likedialog[353] = { 
    {
        title = "133658",
        unlock_lv = 50,
        content = "133919",
        unlockable = 1
    }, 
    {
        title = "133659",
        unlock_lv = 100,
        content = "133920",
        unlockable = 1
    }, 
    {
        title = "133660",
        unlock_lv = 200,
        content = "133921",
        unlockable = 1
    }, 
}
-- 角色备注 = 亚邦
likedialog[354] = { 
    {
        title = "133661",
        unlock_lv = 50,
        content = "133922",
        unlockable = 1
    }, 
    {
        title = "133662",
        unlock_lv = 100,
        content = "133923",
        unlockable = 1
    }, 
    {
        title = "133663",
        unlock_lv = 200,
        content = "133924",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[355] = { 
    {
        title = "614538",
        unlock_lv = 50,
        content = "614541",
        unlockable = 1
    }, 
    {
        title = "614539",
        unlock_lv = 100,
        content = "614542",
        unlockable = 1
    }, 
    {
        title = "614540",
        unlock_lv = 200,
        content = "614543",
        unlockable = 1
    }, 
}
-- 角色备注 = 薇莉安
likedialog[356] = { 
    {
        title = "133664",
        unlock_lv = 50,
        content = "133925",
        unlockable = 1
    }, 
    {
        title = "133665",
        unlock_lv = 100,
        content = "133926",
        unlockable = 1
    }, 
    {
        title = "133666",
        unlock_lv = 200,
        content = "133927",
        unlockable = 1
    }, 
}
-- 角色备注 = 娜伊
likedialog[357] = { 
    {
        title = "133667",
        unlock_lv = 50,
        content = "133928",
        unlockable = 1
    }, 
    {
        title = "133668",
        unlock_lv = 100,
        content = "133929",
        unlockable = 1
    }, 
    {
        title = "133669",
        unlock_lv = 200,
        content = "133930",
        unlockable = 1
    }, 
}
-- 角色备注 = 艾璐
likedialog[359] = { 
    {
        title = "133670",
        unlock_lv = 50,
        content = "133931",
        unlockable = 1
    }, 
    {
        title = "133671",
        unlock_lv = 100,
        content = "133932",
        unlockable = 1
    }, 
    {
        title = "133672",
        unlock_lv = 200,
        content = "133933",
        unlockable = 1
    }, 
}
-- 角色备注 = 芳辉
likedialog[360] = { 
    {
        title = "133673",
        unlock_lv = 50,
        content = "133934",
        unlockable = 1
    }, 
    {
        title = "133674",
        unlock_lv = 100,
        content = "133935",
        unlockable = 1
    }, 
    {
        title = "133675",
        unlock_lv = 200,
        content = "133936",
        unlockable = 1
    }, 
}
-- 角色备注 = 博莉尔
likedialog[361] = { 
    {
        title = "133676",
        unlock_lv = 50,
        content = "133937",
        unlockable = 1
    }, 
    {
        title = "133677",
        unlock_lv = 100,
        content = "133938",
        unlockable = 1
    }, 
    {
        title = "133678",
        unlock_lv = 200,
        content = "133939",
        unlockable = 1
    }, 
}
-- 角色备注 = 尼可拉丝
likedialog[362] = { 
    {
        title = "133679",
        unlock_lv = 50,
        content = "133940",
        unlockable = 1
    }, 
    {
        title = "133680",
        unlock_lv = 100,
        content = "133941",
        unlockable = 1
    }, 
    {
        title = "133681",
        unlock_lv = 200,
        content = "133942",
        unlockable = 1
    }, 
}
-- 角色备注 = 黑鸦
likedialog[363] = { 
    {
        title = "133682",
        unlock_lv = 50,
        content = "133943",
        unlockable = 1
    }, 
    {
        title = "133683",
        unlock_lv = 100,
        content = "133944",
        unlockable = 1
    }, 
    {
        title = "133684",
        unlock_lv = 200,
        content = "133945",
        unlockable = 1
    }, 
}
-- 角色备注 = 提亚马特
likedialog[364] = { 
    {
        title = "133685",
        unlock_lv = 50,
        content = "133946",
        unlockable = 1
    }, 
    {
        title = "133686",
        unlock_lv = 100,
        content = "133947",
        unlockable = 1
    }, 
    {
        title = "133687",
        unlock_lv = 200,
        content = "133948",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[366] = { 
    {
        title = "616223",
        unlock_lv = 50,
        content = "616224",
        unlockable = 1
    }, 
    {
        title = "616225",
        unlock_lv = 100,
        content = "616226",
        unlockable = 1
    }, 
    {
        title = "616227",
        unlock_lv = 200,
        content = "616228",
        unlockable = 1
    }, 
}
-- 角色备注 = 幽戏
likedialog[367] = { 
    {
        title = "133691",
        unlock_lv = 50,
        content = "133952",
        unlockable = 1
    }, 
    {
        title = "133692",
        unlock_lv = 100,
        content = "133953",
        unlockable = 1
    }, 
    {
        title = "133693",
        unlock_lv = 200,
        content = "133954",
        unlockable = 1
    }, 
}
-- 角色备注 = 佩托丽雅
likedialog[369] = { 
    {
        title = "133694",
        unlock_lv = 50,
        content = "133955",
        unlockable = 1
    }, 
    {
        title = "133695",
        unlock_lv = 100,
        content = "133956",
        unlockable = 1
    }, 
    {
        title = "133696",
        unlock_lv = 200,
        content = "133957",
        unlockable = 1
    }, 
}
-- 角色备注 = 梅璐缇雅
likedialog[370] = { 
    {
        title = "133697",
        unlock_lv = 50,
        content = "133958",
        unlockable = 1
    }, 
    {
        title = "133698",
        unlock_lv = 100,
        content = "133959",
        unlockable = 1
    }, 
    {
        title = "133699",
        unlock_lv = 200,
        content = "133960",
        unlockable = 1
    }, 
}
-- 角色备注 = 雾恋
likedialog[373] = { 
    {
        title = "133700",
        unlock_lv = 50,
        content = "133961",
        unlockable = 1
    }, 
    {
        title = "133701",
        unlock_lv = 100,
        content = "133962",
        unlockable = 1
    }, 
    {
        title = "133702",
        unlock_lv = 200,
        content = "133963",
        unlockable = 1
    }, 
}
-- 角色备注 = 潘
likedialog[374] = { 
    {
        title = "133703",
        unlock_lv = 50,
        content = "133964",
        unlockable = 1
    }, 
    {
        title = "133704",
        unlock_lv = 100,
        content = "133965",
        unlockable = 1
    }, 
    {
        title = "133705",
        unlock_lv = 200,
        content = "133966",
        unlockable = 1
    }, 
}
-- 角色备注 = 海拉
likedialog[375] = { 
    {
        title = "133706",
        unlock_lv = 50,
        content = "133967",
        unlockable = 1
    }, 
    {
        title = "133707",
        unlock_lv = 100,
        content = "133968",
        unlockable = 1
    }, 
    {
        title = "133708",
        unlock_lv = 200,
        content = "133969",
        unlockable = 1
    }, 
}
-- 角色备注 = 克丽丝
likedialog[376] = { 
    {
        title = "133709",
        unlock_lv = 50,
        content = "133970",
        unlockable = 1
    }, 
    {
        title = "133710",
        unlock_lv = 100,
        content = "133971",
        unlockable = 1
    }, 
    {
        title = "133711",
        unlock_lv = 200,
        content = "133972",
        unlockable = 1
    }, 
}
-- 角色备注 = 库洛伊
likedialog[377] = { 
    {
        title = "133712",
        unlock_lv = 50,
        content = "133973",
        unlockable = 1
    }, 
    {
        title = "133713",
        unlock_lv = 100,
        content = "133974",
        unlockable = 1
    }, 
    {
        title = "133714",
        unlock_lv = 200,
        content = "133975",
        unlockable = 1
    }, 
}
-- 角色备注 = 玛欧
likedialog[378] = { 
    {
        title = "133715",
        unlock_lv = 50,
        content = "133976",
        unlockable = 1
    }, 
    {
        title = "133716",
        unlock_lv = 100,
        content = "133977",
        unlockable = 1
    }, 
    {
        title = "133717",
        unlock_lv = 200,
        content = "133978",
        unlockable = 1
    }, 
}
-- 角色备注 = 加尔凯撒
likedialog[379] = { 
    {
        title = "133718",
        unlock_lv = 50,
        content = "133979",
        unlockable = 1
    }, 
    {
        title = "133719",
        unlock_lv = 100,
        content = "133980",
        unlockable = 1
    }, 
    {
        title = "133720",
        unlock_lv = 200,
        content = "133981",
        unlockable = 1
    }, 
}
-- 角色备注 = 莲月
likedialog[380] = { 
    {
        title = "133721",
        unlock_lv = 50,
        content = "133982",
        unlockable = 1
    }, 
    {
        title = "133722",
        unlock_lv = 100,
        content = "133983",
        unlockable = 1
    }, 
    {
        title = "133723",
        unlock_lv = 200,
        content = "133984",
        unlockable = 1
    }, 
}
-- 角色备注 = 咪咪露
likedialog[381] = { 
    {
        title = "133724",
        unlock_lv = 50,
        content = "133985",
        unlockable = 1
    }, 
    {
        title = "133725",
        unlock_lv = 100,
        content = "133986",
        unlockable = 1
    }, 
    {
        title = "133726",
        unlock_lv = 200,
        content = "133987",
        unlockable = 1
    }, 
}
-- 角色备注 = 莉洁
likedialog[382] = { 
    {
        title = "133727",
        unlock_lv = 50,
        content = "133988",
        unlockable = 1
    }, 
    {
        title = "133728",
        unlock_lv = 100,
        content = "133989",
        unlockable = 1
    }, 
    {
        title = "133729",
        unlock_lv = 200,
        content = "133990",
        unlockable = 1
    }, 
}
-- 角色备注 = 灰鸦
likedialog[383] = { 
    {
        title = "133730",
        unlock_lv = 50,
        content = "133991",
        unlockable = 1
    }, 
    {
        title = "133731",
        unlock_lv = 100,
        content = "133992",
        unlockable = 1
    }, 
    {
        title = "133732",
        unlock_lv = 200,
        content = "133993",
        unlockable = 1
    }, 
}
-- 角色备注 = 维拉
likedialog[384] = { 
    {
        title = "133733",
        unlock_lv = 50,
        content = "133994",
        unlockable = 1
    }, 
    {
        title = "133734",
        unlock_lv = 100,
        content = "133995",
        unlockable = 1
    }, 
    {
        title = "133735",
        unlock_lv = 200,
        content = "133996",
        unlockable = 1
    }, 
}
-- 角色备注 = 蕾欧奈
likedialog[385] = { 
    {
        title = "133736",
        unlock_lv = 50,
        content = "133997",
        unlockable = 1
    }, 
    {
        title = "133737",
        unlock_lv = 100,
        content = "133998",
        unlockable = 1
    }, 
    {
        title = "133738",
        unlock_lv = 200,
        content = "133999",
        unlockable = 1
    }, 
}
-- 角色备注 = 芙茵
likedialog[386] = { 
    {
        title = "133739",
        unlock_lv = 50,
        content = "134000",
        unlockable = 1
    }, 
    {
        title = "133740",
        unlock_lv = 100,
        content = "134001",
        unlockable = 1
    }, 
    {
        title = "133741",
        unlock_lv = 200,
        content = "134002",
        unlockable = 1
    }, 
}
-- 角色备注 = 哈露比
likedialog[387] = { 
    {
        title = "133742",
        unlock_lv = 50,
        content = "134003",
        unlockable = 1
    }, 
    {
        title = "133743",
        unlock_lv = 100,
        content = "134004",
        unlockable = 1
    }, 
    {
        title = "133744",
        unlock_lv = 200,
        content = "134005",
        unlockable = 1
    }, 
}
-- 角色备注 = 神示雫
likedialog[388] = { 
    {
        title = "133745",
        unlock_lv = 50,
        content = "134006",
        unlockable = 1
    }, 
    {
        title = "133746",
        unlock_lv = 100,
        content = "134007",
        unlockable = 1
    }, 
    {
        title = "133747",
        unlock_lv = 200,
        content = "134008",
        unlockable = 1
    }, 
}
-- 角色备注 = 吉尔福德
likedialog[389] = { 
    {
        title = "133748",
        unlock_lv = 50,
        content = "134009",
        unlockable = 1
    }, 
    {
        title = "133749",
        unlock_lv = 100,
        content = "134010",
        unlockable = 1
    }, 
    {
        title = "133750",
        unlock_lv = 200,
        content = "134011",
        unlockable = 1
    }, 
}
-- 角色备注 = 雷尼希安
likedialog[390] = { 
    {
        title = "133751",
        unlock_lv = 50,
        content = "134012",
        unlockable = 1
    }, 
    {
        title = "133752",
        unlock_lv = 100,
        content = "134013",
        unlockable = 1
    }, 
    {
        title = "133753",
        unlock_lv = 200,
        content = "134014",
        unlockable = 1
    }, 
}
-- 角色备注 = 夏朵
likedialog[391] = { 
    {
        title = "133754",
        unlock_lv = 50,
        content = "134015",
        unlockable = 1
    }, 
    {
        title = "133755",
        unlock_lv = 100,
        content = "134016",
        unlockable = 1
    }, 
    {
        title = "133756",
        unlock_lv = 200,
        content = "134017",
        unlockable = 1
    }, 
}
-- 角色备注 = 路迪
likedialog[392] = { 
    {
        title = "133757",
        unlock_lv = 50,
        content = "134018",
        unlockable = 1
    }, 
    {
        title = "133758",
        unlock_lv = 100,
        content = "134019",
        unlockable = 1
    }, 
    {
        title = "133759",
        unlock_lv = 200,
        content = "134020",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[393] = { 
    {
        title = "614630",
        unlock_lv = 50,
        content = "614648",
        unlockable = 1
    }, 
    {
        title = "614631",
        unlock_lv = 100,
        content = "614649",
        unlockable = 1
    }, 
    {
        title = "614632",
        unlock_lv = 200,
        content = "614650",
        unlockable = 1
    }, 
}
-- 角色备注 = 安洁莉娜
likedialog[394] = { 
    {
        title = "133760",
        unlock_lv = 50,
        content = "134021",
        unlockable = 1
    }, 
    {
        title = "133761",
        unlock_lv = 100,
        content = "134022",
        unlockable = 1
    }, 
    {
        title = "133762",
        unlock_lv = 200,
        content = "134023",
        unlockable = 1
    }, 
}
-- 角色备注 = 阿尔芬♀
likedialog[395] = { 
    {
        title = "133847",
        unlock_lv = 50,
        content = "134108",
        unlockable = 1
    }, 
    {
        title = "133848",
        unlock_lv = 100,
        content = "134109",
        unlockable = 1
    }, 
    {
        title = "133849",
        unlock_lv = 200,
        content = "134110",
        unlockable = 1
    }, 
}
-- 角色备注 = 式鬼
likedialog[397] = { 
    {
        title = "133763",
        unlock_lv = 50,
        content = "134024",
        unlockable = 1
    }, 
    {
        title = "133764",
        unlock_lv = 100,
        content = "134025",
        unlockable = 1
    }, 
    {
        title = "133765",
        unlock_lv = 200,
        content = "134026",
        unlockable = 1
    }, 
}
-- 角色备注 = 葛叶
likedialog[398] = { 
    {
        title = "133766",
        unlock_lv = 50,
        content = "134027",
        unlockable = 0
    }, 
    {
        title = "133767",
        unlock_lv = 100,
        content = "134028",
        unlockable = 0
    }, 
    {
        title = "133768",
        unlock_lv = 200,
        content = "134029",
        unlockable = 0
    }, 
}
-- 角色备注 = 雪娜
likedialog[402] = { 
    {
        title = "133769",
        unlock_lv = 50,
        content = "134030",
        unlockable = 1
    }, 
    {
        title = "133770",
        unlock_lv = 100,
        content = "134031",
        unlockable = 1
    }, 
    {
        title = "133771",
        unlock_lv = 200,
        content = "134032",
        unlockable = 1
    }, 
}
-- 角色备注 = 五季院凶罗
likedialog[403] = { 
    {
        title = "133772",
        unlock_lv = 50,
        content = "134033",
        unlockable = 1
    }, 
    {
        title = "133773",
        unlock_lv = 100,
        content = "134034",
        unlockable = 1
    }, 
    {
        title = "133774",
        unlock_lv = 200,
        content = "134035",
        unlockable = 1
    }, 
}
-- 角色备注 = 乌特迦
likedialog[404] = { 
    {
        title = "133775",
        unlock_lv = 50,
        content = "134036",
        unlockable = 1
    }, 
    {
        title = "133776",
        unlock_lv = 100,
        content = "134037",
        unlockable = 1
    }, 
    {
        title = "133777",
        unlock_lv = 200,
        content = "134038",
        unlockable = 1
    }, 
}
-- 角色备注 = 罗蕾莱
likedialog[405] = { 
    {
        title = "133778",
        unlock_lv = 50,
        content = "134039",
        unlockable = 1
    }, 
    {
        title = "133779",
        unlock_lv = 100,
        content = "134040",
        unlockable = 1
    }, 
    {
        title = "133780",
        unlock_lv = 200,
        content = "134041",
        unlockable = 1
    }, 
}
-- 角色备注 = 萨拉
likedialog[406] = { 
    {
        title = "133781",
        unlock_lv = 50,
        content = "134042",
        unlockable = 1
    }, 
    {
        title = "133782",
        unlock_lv = 100,
        content = "134043",
        unlockable = 1
    }, 
    {
        title = "133783",
        unlock_lv = 200,
        content = "134044",
        unlockable = 1
    }, 
}
-- 角色备注 = 蕾拉
likedialog[407] = { 
    {
        title = "133784",
        unlock_lv = 50,
        content = "134045",
        unlockable = 1
    }, 
    {
        title = "133785",
        unlock_lv = 100,
        content = "134046",
        unlockable = 1
    }, 
    {
        title = "133786",
        unlock_lv = 200,
        content = "134047",
        unlockable = 1
    }, 
}
-- 角色备注 = 霜星
likedialog[408] = { 
    {
        title = "133787",
        unlock_lv = 50,
        content = "134048",
        unlockable = 1
    }, 
    {
        title = "133788",
        unlock_lv = 100,
        content = "134049",
        unlockable = 1
    }, 
    {
        title = "133789",
        unlock_lv = 200,
        content = "134050",
        unlockable = 1
    }, 
}
-- 角色备注 = 天津四
likedialog[409] = { 
    {
        title = "133790",
        unlock_lv = 50,
        content = "134051",
        unlockable = 1
    }, 
    {
        title = "133791",
        unlock_lv = 100,
        content = "134052",
        unlockable = 1
    }, 
    {
        title = "133792",
        unlock_lv = 200,
        content = "134053",
        unlockable = 1
    }, 
}
-- 角色备注 = 尤诺
likedialog[410] = { 
    {
        title = "133793",
        unlock_lv = 50,
        content = "134054",
        unlockable = 1
    }, 
    {
        title = "133794",
        unlock_lv = 100,
        content = "134055",
        unlockable = 1
    }, 
    {
        title = "133795",
        unlock_lv = 200,
        content = "134056",
        unlockable = 1
    }, 
}
-- 角色备注 = 希格德莉法
likedialog[411] = { 
    {
        title = "133796",
        unlock_lv = 50,
        content = "134057",
        unlockable = 1
    }, 
    {
        title = "133797",
        unlock_lv = 100,
        content = "134058",
        unlockable = 1
    }, 
    {
        title = "133798",
        unlock_lv = 200,
        content = "134059",
        unlockable = 1
    }, 
}
-- 角色备注 = 尤娜
likedialog[412] = { 
    {
        title = "133799",
        unlock_lv = 50,
        content = "134060",
        unlockable = 1
    }, 
    {
        title = "133800",
        unlock_lv = 100,
        content = "134061",
        unlockable = 1
    }, 
    {
        title = "133801",
        unlock_lv = 200,
        content = "134062",
        unlockable = 1
    }, 
}
-- 角色备注 = 天满月
likedialog[413] = { 
    {
        title = "133802",
        unlock_lv = 50,
        content = "134063",
        unlockable = 1
    }, 
    {
        title = "133803",
        unlock_lv = 100,
        content = "134064",
        unlockable = 1
    }, 
    {
        title = "133804",
        unlock_lv = 200,
        content = "134065",
        unlockable = 1
    }, 
}
-- 角色备注 = IA
likedialog[414] = { 
    {
        title = "133805",
        unlock_lv = 50,
        content = "134066",
        unlockable = 0
    }, 
    {
        title = "133806",
        unlock_lv = 100,
        content = "134067",
        unlockable = 0
    }, 
    {
        title = "133807",
        unlock_lv = 200,
        content = "134068",
        unlockable = 0
    }, 
}
-- 角色备注 = 绊爱
likedialog[451] = { 
    {
        title = "133808",
        unlock_lv = 50,
        content = "134069",
        unlockable = 0
    }, 
    {
        title = "133809",
        unlock_lv = 100,
        content = "134070",
        unlockable = 0
    }, 
    {
        title = "133810",
        unlock_lv = 200,
        content = "134071",
        unlockable = 0
    }, 
}
-- 角色备注 = 棉华
likedialog[500] = { 
    {
        title = "133811",
        unlock_lv = 50,
        content = "134072",
        unlockable = 1
    }, 
    {
        title = "133812",
        unlock_lv = 100,
        content = "134073",
        unlockable = 1
    }, 
    {
        title = "133813",
        unlock_lv = 200,
        content = "134074",
        unlockable = 1
    }, 
}
-- 角色备注 = 英实
likedialog[501] = { 
    {
        title = "612330",
        unlock_lv = 50,
        content = "612333",
        unlockable = 1
    }, 
    {
        title = "612331",
        unlock_lv = 100,
        content = "612334",
        unlockable = 1
    }, 
    {
        title = "612332",
        unlock_lv = 200,
        content = "612335",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[502] = { 
    {
        title = "616886",
        unlock_lv = 50,
        content = "616892",
        unlockable = 1
    }, 
    {
        title = "616887",
        unlock_lv = 100,
        content = "616893",
        unlockable = 1
    }, 
    {
        title = "616888",
        unlock_lv = 200,
        content = "616894",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[503] = { 
    {
        title = "615686",
        unlock_lv = 50,
        content = "615687",
        unlockable = 1
    }, 
    {
        title = "615688",
        unlock_lv = 100,
        content = "615689",
        unlockable = 1
    }, 
    {
        title = "615690",
        unlock_lv = 200,
        content = "615691",
        unlockable = 1
    }, 
}
-- 角色备注 = 布拉德雷
likedialog[504] = { 
    {
        title = "133817",
        unlock_lv = 50,
        content = "134081",
        unlockable = 1
    }, 
    {
        title = "133818",
        unlock_lv = 100,
        content = "134082",
        unlockable = 1
    }, 
    {
        title = "133819",
        unlock_lv = 200,
        content = "134083",
        unlockable = 1
    }, 
}
-- 角色备注 = 玛丽欧涅
likedialog[506] = { 
    {
        title = "133820",
        unlock_lv = 50,
        content = "134084",
        unlockable = 1
    }, 
    {
        title = "133821",
        unlock_lv = 100,
        content = "134085",
        unlockable = 1
    }, 
    {
        title = "133822",
        unlock_lv = 200,
        content = "134086",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[511] = { 
    {
        title = "615664",
        unlock_lv = 50,
        content = "615665",
        unlockable = 1
    }, 
    {
        title = "615666",
        unlock_lv = 100,
        content = "615667",
        unlockable = 1
    }, 
    {
        title = "615668",
        unlock_lv = 200,
        content = "615669",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[513] = { 
    {
        title = "616171",
        unlock_lv = 50,
        content = "616172",
        unlockable = 1
    }, 
    {
        title = "616173",
        unlock_lv = 100,
        content = "616174",
        unlockable = 1
    }, 
    {
        title = "616175",
        unlock_lv = 200,
        content = "616176",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[514] = { 
    {
        title = "616197",
        unlock_lv = 50,
        content = "616198",
        unlockable = 1
    }, 
    {
        title = "616199",
        unlock_lv = 100,
        content = "616200",
        unlockable = 1
    }, 
    {
        title = "616201",
        unlock_lv = 200,
        content = "616202",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[516] = { 
    {
        title = "617993",
        unlock_lv = 50,
        content = "617999",
        unlockable = 1
    }, 
    {
        title = "617994",
        unlock_lv = 100,
        content = "618000",
        unlockable = 1
    }, 
    {
        title = "617995",
        unlock_lv = 200,
        content = "618001",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[519] = { 
    {
        title = "616664",
        unlock_lv = 50,
        content = "616670",
        unlockable = 1
    }, 
    {
        title = "616665",
        unlock_lv = 100,
        content = "616671",
        unlockable = 1
    }, 
    {
        title = "616666",
        unlock_lv = 200,
        content = "616672",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[520] = { 
    {
        title = "616667",
        unlock_lv = 50,
        content = "616673",
        unlockable = 1
    }, 
    {
        title = "616668",
        unlock_lv = 100,
        content = "616674",
        unlockable = 1
    }, 
    {
        title = "616669",
        unlock_lv = 200,
        content = "616675",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[524] = { 
    {
        title = "601226",
        unlock_lv = 50,
        content = "601235",
        unlockable = 1
    }, 
    {
        title = "601227",
        unlock_lv = 100,
        content = "601236",
        unlockable = 1
    }, 
    {
        title = "601228",
        unlock_lv = 200,
        content = "601237",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[525] = { 
    {
        title = "601223",
        unlock_lv = 50,
        content = "601232",
        unlockable = 1
    }, 
    {
        title = "601224",
        unlock_lv = 100,
        content = "601233",
        unlockable = 1
    }, 
    {
        title = "601225",
        unlock_lv = 200,
        content = "601234",
        unlockable = 1
    }, 
}
-- 角色备注 = 小漱
likedialog[527] = { 
    {
        title = "133844",
        unlock_lv = 50,
        content = "134105",
        unlockable = 1
    }, 
    {
        title = "133845",
        unlock_lv = 100,
        content = "134106",
        unlockable = 1
    }, 
    {
        title = "133846",
        unlock_lv = 200,
        content = "134107",
        unlockable = 1
    }, 
}
-- 角色备注 = 格兰妮
likedialog[528] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 1
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 1
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 1
    }, 
}
-- 角色备注 = 黛希
likedialog[529] = { 
    {
        title = "607010",
        unlock_lv = 50,
        content = "607110",
        unlockable = 1
    }, 
    {
        title = "607011",
        unlock_lv = 100,
        content = "607111",
        unlockable = 1
    }, 
    {
        title = "607012",
        unlock_lv = 200,
        content = "607112",
        unlockable = 1
    }, 
}
-- 角色备注 = 席洛(庆典）
likedialog[530] = { 
    {
        title = "607001",
        unlock_lv = 50,
        content = "607101",
        unlockable = 1
    }, 
    {
        title = "607002",
        unlock_lv = 100,
        content = "607102",
        unlockable = 1
    }, 
    {
        title = "607003",
        unlock_lv = 200,
        content = "607103",
        unlockable = 1
    }, 
}
-- 角色备注 = 佩托丽雅（庆典）
likedialog[531] = { 
    {
        title = "607004",
        unlock_lv = 50,
        content = "607104",
        unlockable = 1
    }, 
    {
        title = "607005",
        unlock_lv = 100,
        content = "607105",
        unlockable = 1
    }, 
    {
        title = "607006",
        unlock_lv = 200,
        content = "607106",
        unlockable = 1
    }, 
}
-- 角色备注 = 安洁莉娜（庆典）
likedialog[532] = { 
    {
        title = "607007",
        unlock_lv = 50,
        content = "607107",
        unlockable = 1
    }, 
    {
        title = "607008",
        unlock_lv = 100,
        content = "607108",
        unlockable = 1
    }, 
    {
        title = "607009",
        unlock_lv = 200,
        content = "607109",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[534] = { 
    {
        title = "615708",
        unlock_lv = 50,
        content = "615709",
        unlockable = 1
    }, 
    {
        title = "615710",
        unlock_lv = 100,
        content = "615711",
        unlockable = 1
    }, 
    {
        title = "615712",
        unlock_lv = 200,
        content = "615713",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[535] = { 
    {
        title = "616889",
        unlock_lv = 50,
        content = "616895",
        unlockable = 1
    }, 
    {
        title = "616890",
        unlock_lv = 100,
        content = "616896",
        unlockable = 1
    }, 
    {
        title = "616891",
        unlock_lv = 200,
        content = "616897",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[537] = { 
    {
        title = "617768",
        unlock_lv = 50,
        content = "617771",
        unlockable = 1
    }, 
    {
        title = "617769",
        unlock_lv = 100,
        content = "617772",
        unlockable = 1
    }, 
    {
        title = "617770",
        unlock_lv = 200,
        content = "617773",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[538] = { 
    {
        title = "617134",
        unlock_lv = 50,
        content = "617140",
        unlockable = 1
    }, 
    {
        title = "617135",
        unlock_lv = 100,
        content = "617141",
        unlockable = 1
    }, 
    {
        title = "617136",
        unlock_lv = 200,
        content = "617142",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[539] = { 
    {
        title = "617430",
        unlock_lv = 50,
        content = "617436",
        unlockable = 1
    }, 
    {
        title = "617431",
        unlock_lv = 100,
        content = "617437",
        unlockable = 1
    }, 
    {
        title = "617432",
        unlock_lv = 200,
        content = "617438",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[540] = { 
    {
        title = "617137",
        unlock_lv = 50,
        content = "617143",
        unlockable = 1
    }, 
    {
        title = "617138",
        unlock_lv = 100,
        content = "617144",
        unlockable = 1
    }, 
    {
        title = "617139",
        unlock_lv = 200,
        content = "617145",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[541] = { 
    {
        title = "617433",
        unlock_lv = 50,
        content = "617439",
        unlockable = 1
    }, 
    {
        title = "617434",
        unlock_lv = 100,
        content = "617440",
        unlockable = 1
    }, 
    {
        title = "617435",
        unlock_lv = 200,
        content = "617441",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[542] = { 
    {
        title = "617996",
        unlock_lv = 50,
        content = "618002",
        unlockable = 1
    }, 
    {
        title = "617997",
        unlock_lv = 100,
        content = "618003",
        unlockable = 1
    }, 
    {
        title = "617998",
        unlock_lv = 200,
        content = "618004",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[543] = { 
    {
        title = "618146",
        unlock_lv = 50,
        content = "618149",
        unlockable = 1
    }, 
    {
        title = "618147",
        unlock_lv = 100,
        content = "618150",
        unlockable = 1
    }, 
    {
        title = "618148",
        unlock_lv = 200,
        content = "618151",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[544] = { 
    {
        title = "618189",
        unlock_lv = 50,
        content = "618192",
        unlockable = 1
    }, 
    {
        title = "618190",
        unlock_lv = 100,
        content = "618193",
        unlockable = 1
    }, 
    {
        title = "618191",
        unlock_lv = 200,
        content = "618194",
        unlockable = 1
    }, 
}
-- 角色备注 = 蕾琪尔
likedialog[600] = { 
    {
        title = "133823",
        unlock_lv = 50,
        content = "134087",
        unlockable = 0
    }, 
    {
        title = "133824",
        unlock_lv = 100,
        content = "134088",
        unlockable = 0
    }, 
    {
        title = "133825",
        unlock_lv = 200,
        content = "134089",
        unlockable = 0
    }, 
}
-- 角色备注 = 奈茵
likedialog[601] = { 
    {
        title = "133826",
        unlock_lv = 50,
        content = "134090",
        unlockable = 0
    }, 
    {
        title = "133827",
        unlock_lv = 100,
        content = "134091",
        unlockable = 0
    }, 
    {
        title = "133828",
        unlock_lv = 200,
        content = "134092",
        unlockable = 0
    }, 
}
-- 角色备注 = 如月琴恩
likedialog[602] = { 
    {
        title = "133829",
        unlock_lv = 50,
        content = "134093",
        unlockable = 0
    }, 
    {
        title = "133830",
        unlock_lv = 100,
        content = "134094",
        unlockable = 0
    }, 
    {
        title = "133831",
        unlock_lv = 200,
        content = "134095",
        unlockable = 0
    }, 
}
-- 角色备注 = 伊邪那美
likedialog[603] = { 
    {
        title = "133832",
        unlock_lv = 50,
        content = "134096",
        unlockable = 0
    }, 
    {
        title = "133833",
        unlock_lv = 100,
        content = "134097",
        unlockable = 0
    }, 
    {
        title = "133834",
        unlock_lv = 200,
        content = "134098",
        unlockable = 0
    }, 
}
-- 角色备注 = 拉格纳
likedialog[604] = { 
    {
        title = "133835",
        unlock_lv = 50,
        content = "134099",
        unlockable = 0
    }, 
    {
        title = "133836",
        unlock_lv = 100,
        content = "134100",
        unlockable = 0
    }, 
    {
        title = "133837",
        unlock_lv = 200,
        content = "134101",
        unlockable = 0
    }, 
}
-- 角色备注 = 缪恩
likedialog[605] = { 
    {
        title = "133838",
        unlock_lv = 50,
        content = "134102",
        unlockable = 0
    }, 
    {
        title = "133839",
        unlock_lv = 100,
        content = "134103",
        unlockable = 0
    }, 
    {
        title = "133840",
        unlock_lv = 200,
        content = "134104",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[606] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 0
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 0
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[607] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 0
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 0
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[608] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 0
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 0
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[609] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 0
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 0
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[610] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 0
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 0
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[611] = { 
    {
        title = "607013",
        unlock_lv = 50,
        content = "607113",
        unlockable = 0
    }, 
    {
        title = "607014",
        unlock_lv = 100,
        content = "607114",
        unlockable = 0
    }, 
    {
        title = "607015",
        unlock_lv = 200,
        content = "607115",
        unlockable = 0
    }, 
}
-- 角色备注 = 
likedialog[700] = { 
    {
        title = "614615",
        unlock_lv = 50,
        content = "614633",
        unlockable = 1
    }, 
    {
        title = "614616",
        unlock_lv = 100,
        content = "614634",
        unlockable = 1
    }, 
    {
        title = "614617",
        unlock_lv = 200,
        content = "614635",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[702] = { 
    {
        title = "614618",
        unlock_lv = 50,
        content = "614636",
        unlockable = 1
    }, 
    {
        title = "614619",
        unlock_lv = 100,
        content = "614637",
        unlockable = 1
    }, 
    {
        title = "614620",
        unlock_lv = 200,
        content = "614638",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[703] = { 
    {
        title = "614621",
        unlock_lv = 50,
        content = "614639",
        unlockable = 1
    }, 
    {
        title = "614622",
        unlock_lv = 100,
        content = "614640",
        unlockable = 1
    }, 
    {
        title = "614623",
        unlock_lv = 200,
        content = "614641",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[704] = { 
    {
        title = "614624",
        unlock_lv = 50,
        content = "614642",
        unlockable = 1
    }, 
    {
        title = "614625",
        unlock_lv = 100,
        content = "614643",
        unlockable = 1
    }, 
    {
        title = "614626",
        unlock_lv = 200,
        content = "614644",
        unlockable = 1
    }, 
}
-- 角色备注 = 
likedialog[705] = { 
    {
        title = "614627",
        unlock_lv = 50,
        content = "614645",
        unlockable = 1
    }, 
    {
        title = "614628",
        unlock_lv = 100,
        content = "614646",
        unlockable = 1
    }, 
    {
        title = "614629",
        unlock_lv = 200,
        content = "614647",
        unlockable = 1
    }, 
}
-- 角色备注 = 黑潮遗迹NPC
likedialog[950] = { 
    {
        title = "133841",
        unlock_lv = 50,
        content = "134078",
        unlockable = 0
    }, 
    {
        title = "133842",
        unlock_lv = 100,
        content = "134079",
        unlockable = 0
    }, 
    {
        title = "133843",
        unlock_lv = 200,
        content = "134080",
        unlockable = 0
    }, 
}
