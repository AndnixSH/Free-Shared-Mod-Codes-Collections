MsgBoxLayer_Gift = class("MsgBoxLayer_Gift",XUIView)
MsgBoxLayer_Gift.CS_FILE_NAME = "MsgBoxLayer_Gift.csb"
MsgBoxLayer_Gift.CS_BIND_TABLE = 
{
	Panel_1 				= "/i:1",
	Panel_list 				= "/i:1/i:4983",
	Button_single 			= "/i:1/i:10503",
	Button_close 			= "/i:1/i:296",
	Text_Select_count 		= "/i:1/i:1111",
	Text_Tips_count			= "/i:1/i:4985",
}
MsgBoxLayer_Gift.Select_count = 0

function MsgBoxLayer_Gift:init(tab)
	MsgBoxLayer_Gift.super.init(self)
	if tab == nil then
		return nil
	end
	self.TabList = {}
	item_id = tab["item_id"]
	self.item_id = item_id
	self.item_type = tab["item_type"]
	self.fCall = tab["fCall"]
	self.TabList = gift[item_id]["reward"]
	local function add( ... )
		self:addSelectCount()
	end
	local function reduce( ... )
		self:reduceSelectCount()
	end
	for i,v in ipairs(self.TabList) do
		v["IsTouch"] = true
		v["select"] = 0
	end
	self.Max_Optional_Count = gift[item_id]["max_optional_num"]
	local msg_tips = string.format(UITool.ToLocalization("请从以下奖励中选择%d个"),self.Max_Optional_Count)
	self.Text_Tips_count:setString(msg_tips)
	--self.Text_Tips_count:setString(tostring(self.Max_Optional_Count))
	local pSize = self.Panel_list:getContentSize()
	self.gridview = XUIGridView.new():initWithNodeAndSize(self.Panel_list,pSize.width,pSize.height,690,140)
	self.gridview.itemCreateEvent = function()
		local temp = MsgBoxLayer_GiftItem.new():init()
		temp.ClickAddEvent = function(oneself)
			self:onItemClicked1(oneself)
		end
		temp.ClickSubEvent = function(oneself)
			self:onItemClicked2(oneself)
		end

		return temp
	end

	self:initUI()
	self:refreshList()

	return self
end

function MsgBoxLayer_Gift:addSelectCount()
	if self.Select_count >= self.Max_Optional_Count then
		self.Select_count = self.Max_Optional_Count
		for i,v in ipairs(self.TabList) do
			v["IsTouch"] = false
		end
		self:refreshList()
	else
		self.Select_count = self.Select_count + 1
		if self.Select_count == self.Max_Optional_Count then
			for i,v in ipairs(self.TabList) do
			v["IsTouch"] = false
		end
		self:refreshList()
		end
	end
	self.Text_Select_count:setString(tostring(self.Select_count).."/"..tostring(self.Max_Optional_Count))
end
function MsgBoxLayer_Gift:reduceSelectCount()
	if self.Select_count <= 0 then
		self.Select_count = 0
	else
		if self.Select_count == self.Max_Optional_Count then
			if self.Select_count == self.Max_Optional_Count then
				for i,v in ipairs(self.TabList) do
					v["IsTouch"] = true
				end
			end
			self:refreshList()
		end
		self.Select_count = self.Select_count - 1
	end
	
	self.Text_Select_count:setString(tostring(self.Select_count).."/"..tostring(self.Max_Optional_Count))
end

function MsgBoxLayer_Gift:initUI()
	self.Text_Select_count:setString(tostring(self.Select_count).."/"..tostring(self.Max_Optional_Count))
	self.Button_close:addTouchEventListener(function (sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			self:removeFromParentView()
		end
	end)

	self.Button_single:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()
            local l = cc.pGetDistance(p1,p2)
            if l < 30 then
            	local _data = self:getFinalData()
            	local count = 0
            	for i,v in ipairs(_data) do
            		count = count + v["num"]
            	end
            	if count == self.Max_Optional_Count then
					self:GiftUse(self.item_id,self.fCall,_data)
				else
					MsgTipSys:getInstance():addData(UITool.ToLocalization("选取的数量不对 "))
				end
            end
		end
	end)
end

function MsgBoxLayer_Gift:refreshList()
	if self.TabList == nil then
	 	return
	end
    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(self.TabList)
    self.gridview:jumpToPercent(percent)
end

function MsgBoxLayer_Gift:onItemClicked1(oneself)
	local ret,_data = oneself:getSingleData()
	if not ret then
		return
	end
	local index = oneself:getIndex()
	local _select = self.TabList[index]["select"]
	if _select < _data["num"] then
		self.TabList[index]["select"] = _select + 1
		if self.TabList[index]["select"] == _data["num"] then
			oneself:setButtonAddState(false)
			self.TabList[index]["IsTouch"] = false
		end
		if self.TabList[index]["select"] >= 0 then
			oneself:setButtonSubState(true)
		end
	end
	oneself:setSelectText(self.TabList[index]["select"])
	self:addSelectCount()
end
function MsgBoxLayer_Gift:onItemClicked2(oneself)
	local ret,_data = oneself:getSingleData()
	if not ret then
		return
	end
	local index = oneself:getIndex()
	local _select = self.TabList[index]["select"]
	if _select > 0 then
		self.TabList[index]["select"] = _select - 1
		if self.TabList[index]["select"] == 0 then
			oneself:setButtonSubState(false)
		end
		if self.TabList[index]["select"] < _data["num"] then
			oneself:setButtonAddState(true)
			self.TabList[index]["IsTouch"] = true
		end
	end
	oneself:setSelectText(self.TabList[index]["select"])
	self:reduceSelectCount()
end

function MsgBoxLayer_Gift:getFinalData()
	local _tab = {}
	for i,v in ipairs(self.TabList) do
		if v["select"] > 0 then
			-- for m=1,v["select"] do
			-- 	local _t = {}
			-- 	_t["num"] = v["select"]
			-- 	_t["id"] = v["id"]
			-- 	_t["type"] = v["type"]
			-- 	table.insert(_tab,_t)
			-- end
			local _t = {}
			_t["num"] = v["select"]
			_t["id"] = v["id"]
			_t["type"] = v["type"]
			table.insert(_tab,_t)
		end
	end
	dump(_tab,"_tab:")
	return _tab
end

--展示获得的物品
function MsgBoxLayer_Gift:ShowItemInfo(itemGainData,_heroData)
    local function fCall()
    	-- if _heroData and #_heroData > 0 then
    	-- 	self:showHeroEffects(_heroData)
    	-- end
    end
    local tableLen = #itemGainData
    local sData = {}
    if tableLen <= 1 then
        itemType = table.getValue("itemGainData", itemGainData, 1, "item_type")
        Itemid   = table.getValue("itemGainData", itemGainData, 1, "id")
        Itemnum  = table.getValue("itemGainData", itemGainData, 1, "num")
        local oneMailData  ={}
        local oneMailItemData = {}
        oneMailItemData["id"]        = Itemid
        oneMailItemData["item_type"] = itemType
        oneMailItemData["num"]       = Itemnum
        
        table.insert(oneMailData,oneMailItemData)

        
        sData["AllData"] = oneMailData
    else
        sData["AllData"] = itemGainData
    end

    sData["fCall"] = fCall
    SceneManager:toMailGetAllLayer(sData)
    
end

function MsgBoxLayer_Gift:GiftUse(_item_id,f_call,_tab)
	local tempTable = {
                ["rpc"]       = "item_gift_use",
                ["item_id"]   = "gift_".._item_id,
                ["chosen"] = _tab,
            }
    GameManagerInst:rpc(tempTable,3,
        function(data)
            if data == nil then
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.sDelegate)
                return
            end
            if data["state_code"] == 1 then
            	self:ShowItemInfo(data["get"])
            	if f_call then
            		f_call()
            	end
				self:removeFromParentView()
            end
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true)
end




