
--[[  战斗结算的特效
      失败和胜利的特效 
]]
BattleEndEffectUI = class("BattleEndEffectUI", function()
    return cc.Layer:create();
end);

function BattleEndEffectUI:ctor()
    self:initVariables()
end
function BattleEndEffectUI:effectBase( spName,strMusic,endMusic,pos,Func)

    BattleStopBGM()
    local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(BattleCacheManager:getData(spName))
    spineNode:setPosition(pos);
    self:addChild(spineNode, 10000);   
    BattlePlaySound(strMusic,false,0)

    -- spine的回调
    spineNode:registerSpineEventHandler(
        function (event) 
            
            local  delay = cc.DelayTime:create(0.01)
            local sequence = cc.Sequence:create(delay, cc.RemoveSelf:create())
            spineNode:runAction(sequence)
            
            self:runAction(cc.Sequence:create(delay,cc.CallFunc:create(function()
                    Func()
            end )))
        end, sp.EventType.ANIMATION_COMPLETE)

    spineNode:setAnimation(0, "effect", false);
    BattlePlaySound(endMusic,false,1)
end
--失败特效
function BattleEndEffectUI:defeateEffect(callBackFuc)
    local function effectCallBack()
        callBackFuc()
    end
    local deadMusic  = "music/GarageBand/gei_com.wav"
    local defeateStr = "music/ui/battlefail.mp3";
    self:effectBase(BattleGlobals.DEFEATE_EFFECT,defeateStr,deadMusic,cc.p(0,720),effectCallBack)
end

-- 胜利特效
function BattleEndEffectUI:victotyEffect(callBackFuc )
    local function effectCallBack()
        callBackFuc()
    end
    local victoryMusic = "music/GarageBand/gei_com.wav"
    local victoryeStr  = "music/battle/b8.mp3";
    self:effectBase(BattleGlobals.VICTORY_EFFECT,victoryeStr,victoryMusic,cc.p(640,360),effectCallBack)
end

-- 初始化变量
function BattleEndEffectUI:initVariables()
    self.battleData = BattleDataManager:getData()
end




