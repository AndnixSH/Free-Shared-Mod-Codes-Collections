
--------------------------------
-- @module loadingLayer
-- @extend Layer
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#loadingLayer] getPercentage 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#loadingLayer] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#loadingLayer] MultUpdate 
-- @param self
-- @param #float 
-- @return loadingLayer#loadingLayer self (return value: loadingLayer)
        
--------------------------------
-- 
-- @function [parent=#loadingLayer] setPercentage 
-- @param self
-- @param #float percentage
-- @return loadingLayer#loadingLayer self (return value: loadingLayer)
        
--------------------------------
-- 
-- @function [parent=#loadingLayer] create 
-- @param self
-- @return loadingLayer#loadingLayer ret (return value: loadingLayer)
        
--------------------------------
-- 
-- @function [parent=#loadingLayer] loadingLayer 
-- @param self
-- @return loadingLayer#loadingLayer self (return value: loadingLayer)
        
return nil
