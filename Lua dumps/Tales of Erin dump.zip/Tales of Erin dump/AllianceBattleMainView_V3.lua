
--带事件点的版本的工会战主界面。2018.10.17
AllianceBattleMainView_V3 = class("AllianceBattleMainView_V3",XUIView)
AllianceBattleMainView_V3.CS_BIND_TABLE = 
{
    btnClose="/i:217"
}

--[[buff显示
    1.关闭中
    2.充能中
    3.发动中
    4.今日已激活
    5.充能完成
    6.点击激活（前5个都不可点击，6可点击，且只有会长和副会长显示）
]]

function AllianceBattleMainView_V3:init()
    AllianceBattleMainView_V3.CS_FILE_NAME = "AllianceBattleMainView_3.csb"
    
    AllianceBattleMainView_V3.super.init(self)

    --V1和V2版本公会战状态。0未开启。1报名中 2.战斗中 3.休战中。4.已结束（兑换期）。
    --V3版本公会战状态。0未开启。1报名中 2.昼战中 3.夜战中 4.休战中。5.已结束（兑换期）。
    self.guildBattleState = SceneManager.menuLayer.guildBattleState;
    self.is_sign_up = false

    self.rootPanel = self._csNode:getChildByTag(181)
    self.infoPanel = self.rootPanel:getChildByTag(265);
    self.infoPanelNotSignUp = self.rootPanel:getChildByTag(80);

    self.nodeForOtherLayer = self._csNode:getChildByTag(53)
    self.nodeForUpperLayer = self._csNode:getChildByTag(216)

    --初始化左侧信息栏
    self:initLeftInfoPanel()
    --初始化5个标签按钮
    self:initSwichBtns();
    --初始化“战场”界面的其他按钮
    self:initOtherBtns();
    --初始化地图点
    self:initMap();

    --请求数据
    self:requestBattleFieldData();

    return self
end

--初始化左侧信息栏
function AllianceBattleMainView_V3:initLeftInfoPanel()
    
    self.GuildName2 = self.infoPanel:getChildByTag(58); --对手公会名称
    self.chargingbar = self.infoPanel:getChildByTag(51);--充能的条
    if g_channel_control.b_allianceBattle_version2 then 
        self.activateTimes = self.infoPanel:getChildByTag(333);--剩余激活次数
    end 
    self.buff_desc = self.infoPanel:getChildByTag(68);      --buff描述
    self.buffBtns = {}--6种状态对应的按钮
    self.text_enegyNum = self.infoPanel:getChildByTag(101);      --能量值，状态2，5，6时可见

    --下方的三个值
    local temp1 = self.rootPanel:getChildByTag(128);
    self.points1 = temp1:getChildByTag(92);  --个人当日积分
    self.points2 = temp1:getChildByTag(93);  --个人累计积分
    self.pointsRank = temp1:getChildByTag(94);  --个人累计积分排行

    --帮助按钮
    local helpBtn = self.infoPanel:getChildByTag(59);
    helpBtn:addClickEventListener(function()
        self:showGuidePicLayer();
    end)

    self.GuildName1 = self.infoPanel:getChildByTag(57); --本方公会名称
    self.lunhuibi = self.infoPanel:getChildByTag(272);  --轮回币
    self.medals = self.infoPanel:getChildByTag(273);    --奖章
    self.day = self.infoPanel:getChildByTag(61);        --第几天
    self.Text_BattleTime = self.infoPanel:getChildByTag(62);--昼战时间
    self.Text_BattleTime_Night = self.infoPanel:getChildByTag(256);--夜战时间
    self.Text_Date = self.infoPanel:getChildByTag(63);      --开始和结束的日期

    self.GuildName1_notSign = self.infoPanelNotSignUp:getChildByTag(88); --本方公会名称
    self.lunhuibi_notSign = self.infoPanelNotSignUp:getChildByTag(83);  --轮回币
    self.medals_notSign = self.infoPanelNotSignUp:getChildByTag(84);    --奖章
    self.day_notSign = self.infoPanelNotSignUp:getChildByTag(85);        --第几天
    self.Text_BattleTime_notSign = self.infoPanelNotSignUp:getChildByTag(86);--昼战时间
    self.Text_BattleTime_Night_notSign = self.infoPanelNotSignUp:getChildByTag(341);--夜战时间
    self.Text_Date_notSign = self.infoPanelNotSignUp:getChildByTag(87);      --开始和结束的日期

    for i = 1,6 do
        self.buffBtns[i] = self.infoPanel:getChildByName("Button_BuffState_"..i);
    end

    self.noticeText = {} --开战后才可再次充能这句文本。
    for i = 1,6 do
        if i == 1 or i == 4 then
            self.noticeText[i] = self.buffBtns[i]:getChildByName("Text_7_0");
        end
    end

    self.text_remainTime = self.buffBtns[3]:getChildByTag(74);  --发动中的剩余时间。状态3时可见。
    self.text_remainTime:setString("");

    local function  btn6Clicked()
        --激活成功或者提示已经激活
        --MsgManager:showSimpMsgWithCallFunc1("XXXX 已被激活，本日不需再次激活。",self,doNothing);
        local tempTable = {}
        tempTable["rpc"] = "guildbattle_buff_activate"

        GameManagerInst:rpc(tempTable,
            3,
            function(data)
                --success
                print("团战buff激活成功")
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("激活成功"),nil);
                self:requestBattleFieldData();
            end,
            function(state_code,msgText)
                --failed
                print("团战buff激活失败")
                GameManagerInst:alert(msgText,function()
                    self:returnBack()
                end)
            end,
        true)
    end

    self.buffBtns[6]:addClickEventListener(function()
        --会长或者副会长激活buff
        local str = UITool.ToLocalization("是否激活 “%s”,%s")
        local forstr = string.format(str, UITool.getUserLanguage(passive_sk[self.battlefield_data.buffid].sk_name),UITool.getUserLanguage(passive_sk[self.battlefield_data.buffid].sk_des))
        MsgManager:showSimpMsgWithCallFunc(
            forstr,self,btn6Clicked);
    end)
end

--5个标签切换按钮
function AllianceBattleMainView_V3:initSwichBtns()
    self.currChannel = 1;
    self.switchBtns = {};
    self.switchImageTable_1 = {};
    self.switchImageTable_2 = {};

    for i = 1,4 do
        self.switchBtns[i] = self._csNode:getChildByName("Button_6_"..i)
        self.switchImageTable_1[i] = self._csNode:getChildByName("SwichImage"..i)
        self.switchImageTable_2[i] = self._csNode:getChildByName("SwichImage"..i+5)

        self.switchBtns[i]:addClickEventListener(function()
            if i == self.currChannel then
                return
            else
                local lastChannel = self.currChannel;
                self.currChannel = i;
                self:switchView(i,lastChannel)
            end
        end)
    end

    self.switchImageTable_1[1]:setVisible(false);
    self.switchImageTable_2[1]:setVisible(true);

    --去多人战界面
    local toMulBattleLayerBtn = self._csNode:getChildByName("Button_6_5")
    toMulBattleLayerBtn:addClickEventListener(function ( )
        self:toMulBattleLayer();
    end)
end

function AllianceBattleMainView_V3:initOtherBtns()
    --查看战绩
    local checkRecordBtn = self.infoPanel:getChildByTag(270);
    checkRecordBtn:addClickEventListener(function()
        self.nodeForUpperLayer:addChild(AllianceBattle_CheckRecord:create(self.battlefield_data.exploit,self.battlefield_data.name_self));
    end)

    --返回按钮
    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)    

    --成员积分按钮
    self.memberPointsBtn = self.rootPanel:getChildByTag(219);
    self.memberPointsBtn:setEnabled(false);

    local function callbackfunc()
        --do nothing
    end
    self.memberPointsBtn:addClickEventListener(function()
        print("成员积分")
        local rcvData = {}
        rcvData["sDelegate"] =  self
        rcvData["sFunc"] = callbackfunc
        SceneManager:toContribute(rcvData);
    end)

    --轮回排行按钮
    local lunhuiRankBtn = self.rootPanel:getChildByTag(220);
    lunhuiRankBtn:addClickEventListener(function()
        print("轮回排行")
        local rcvData = {}
        rcvData["sDelegate"] =  self
        rcvData["sFunc"] = callbackfunc
        SceneManager:toAnBRBL(rcvData);
    end) 
end

--设置地图点状态
function AllianceBattleMainView_V3:setMapPointState(idx,isOpen)
    self.mapPoints[idx].isOpen = isOpen

    assert(self.guild_battle_event[idx],"self.guild_battle_event[idx] is Non_existent!")

    local pic = self.guild_battle_event[idx]["icon"]
    local pic_gray = string.sub(pic,1,string.len(pic)-4).."b.png"
    local title = self.guild_battle_event[idx]["title"]
    local title_gray = string.sub(title,1,string.len(title)-4).."b.png"

    if isOpen == 0 then
        self.mapPoints[idx].isOpen = false
        self.mapPoints[idx].pic_icon:loadTexture(pic_gray)
        self.mapPoints[idx].pic_name:loadTexture(title_gray)
    else
        self.mapPoints[idx].isOpen = true
        self.mapPoints[idx].pic_icon:loadTexture(pic)
        self.mapPoints[idx].pic_name:loadTexture(title)
    end

-- 原来的代码暂时不用
--[[
    local picPath1 = guild_battle["resource"][2]
    local picPath2 = guild_battle["resource"][3]
    local picPath3 = guild_battle["resource"][4]
    local temp1 = string.sub(picPath1,1,string.len(picPath1)-4)
    local temp2 = string.sub(picPath2,1,string.len(picPath2)-4)
    local temp3 = string.sub(picPath3,1,string.len(picPath3)-4)
    local picPath4 = temp1.."b.png"
    local picPath5 = temp2.."b.png"
    local picPath6 = temp3.."b.png"

    local namePicPath1 = guild_battle["resource"][8]
    local namePicPath2 = guild_battle["resource"][9]
    local namePicPath3 = guild_battle["resource"][10]
    local namePicTemp1 = string.sub(namePicPath1,1,string.len(namePicPath1)-4)
    local namePicTemp2 = string.sub(namePicPath2,1,string.len(namePicPath2)-4)
    local namePicTemp3 = string.sub(namePicPath3,1,string.len(namePicPath3)-4)
    local namePicPath4 = namePicTemp1.."b.png"
    local namePicPath5 = namePicTemp2.."b.png"
    local namePicPath6 = namePicTemp3.."b.png"

    --未开启时置灰
    if isOpen == 0 then
        self.mapPoints[idx].isOpen = false
        if idx == 1 then
            self.mapPoints[idx].pic_icon:loadTexture(picPath4)
            self.mapPoints[idx].pic_name:loadTexture(namePicPath4)
        elseif idx == 2 then
            self.mapPoints[idx].pic_icon:loadTexture(picPath5)
            self.mapPoints[idx].pic_name:loadTexture(namePicPath5)    
        elseif idx == 3 then
            self.mapPoints[idx].pic_icon:loadTexture(picPath6)
            self.mapPoints[idx].pic_name:loadTexture(namePicPath6)
        end
    else
        self.mapPoints[idx].isOpen = true
        if idx == 1 then
            self.mapPoints[idx].pic_icon:loadTexture(picPath1)
            self.mapPoints[idx].pic_name:loadTexture(namePicPath1)
        elseif idx == 2 then
            self.mapPoints[idx].pic_icon:loadTexture(picPath2)
            self.mapPoints[idx].pic_name:loadTexture(namePicPath2)    
        elseif idx == 3 then
            self.mapPoints[idx].pic_icon:loadTexture(picPath3)
            self.mapPoints[idx].pic_name:loadTexture(namePicPath3)
        end        
    end
]]--
end

--初始化3个地图点
function AllianceBattleMainView_V3:initMap()
    self.mapPoints = {}

    for i = 1,3 do
        self.mapPoints[i] = {}
    end

    self.mapPoints[1].pic_icon = self.rootPanel:getChildByTag(199);
    self.mapPoints[2].pic_icon = self.rootPanel:getChildByTag(200);
    self.mapPoints[3].pic_icon = self.rootPanel:getChildByTag(201);

    self.mapPoints[1].pic_name = self.rootPanel:getChildByTag(202);
    self.mapPoints[2].pic_name = self.rootPanel:getChildByTag(203);
    self.mapPoints[3].pic_name = self.rootPanel:getChildByTag(204);

    --btn
    self.mapPoints[1].btn = self.rootPanel:getChildByTag(182);
    self.mapPoints[1].btn:addClickEventListener(function()
        self:onMapPointClicked(1);
    end)

    self.mapPoints[2].btn = self.rootPanel:getChildByTag(183);
    self.mapPoints[2].btn:addClickEventListener(function()
        self:onMapPointClicked(2);
    end)

    self.mapPoints[3].btn = self.rootPanel:getChildByTag(198);
    self.mapPoints[3].btn:addClickEventListener(function()
        self:onMapPointClicked(3);
    end) 

    --地图背景
    self.rootPanel:setBackGroundImage(guild_battle["resource"][1])
end

--点击地图点的响应
function AllianceBattleMainView_V3:onMapPointClicked(idx)
    --未开启时
    if not self.mapPoints[idx].isOpen then
        MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("未开启"),nil);
    --开启时，显示事件层
    else
        self.eventsLayer = AllianceBattle_EventsLayer:create(self.battlefield_data.battlefield_list[idx],self,self.guild_battle_event)
        self.nodeForUpperLayer:addChild(self.eventsLayer)
        self.mapDataIdx = idx
    end
end

--刷新战场界面
function AllianceBattleMainView_V3:refreshBattleFieldView()
    local is_sign_up = self.battlefield_data.is_sign_up

    if is_sign_up == 1 then
        self.memberPointsBtn:setEnabled(true);
        self.infoPanel:setVisible(true)
        self.infoPanelNotSignUp:setVisible(false)

        --刷新一下战力对比的动画
        self:refreshContributionContrast()
        --刷新一下已报名时的左侧信息栏
        self:refreshLeftInfoPanel()
    else
        self.memberPointsBtn:setEnabled(false); 
        self.infoPanel:setVisible(false)
        self.infoPanelNotSignUp:setVisible(true)
        --刷新一下未报名时的左侧信息栏
        self:refreshLeftInfoPanel_NotSignUp()
    end

    --刷新地图点
    self:refreshMap()

    --如果此时处在事件点界面，刷新事件点数据
    if self.mapDataIdx and self.eventsLayer then
        --修复bugly 上lua错误   #3652 [string "AllianceBattle_EventsLayer.lua"]
        if self.battlefield_data.battlefield_list[self.mapDataIdx] then 
            self.eventsLayer:removeFromParent()
            self.eventsLayer = AllianceBattle_EventsLayer:create(self.battlefield_data.battlefield_list[self.mapDataIdx],self)
            self.nodeForUpperLayer:addChild(self.eventsLayer) 
        else
            if XBConfigManager:getInstance():getCocosDebugModel() then
                GameManagerInst:alert("mapDataIdx error:"..self.mapDataIdx,function()
                    self:returnBack()
                end)     
            end  
        end
    end

    self:refreshRedDot()
end

--请求战场主界面数据
function AllianceBattleMainView_V3:requestBattleFieldData()
    local tempTable = {}
    tempTable["rpc"] = "guildbattle_battlefield_v3"

    GameManagerInst:rpc(tempTable,
        3,
        function(data)
            --success
            print("请求团战数据成功。")
            self.battlefield_data = data;
            if self.battlefield_data.guildbattle_achi_red_point then
                SceneManager.guildbattle_achi_red_point = self.battlefield_data.guildbattle_achi_red_point
            end
            self:refreshBattleFieldView();
        end,
        function(state_code,msgText)
            --failed
            print("请求团战数据失败。")
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
    true)
end

--刷新地图点,V3版新增
function AllianceBattleMainView_V3:refreshMap()
    for i,v in ipairs(self.battlefield_data.battlefield_list) do
        self.battlefield_data.battlefield_list[i]._guild_battle_event = table.deepcopy(guild_battle["event"][v.map_point_idx])
    end

    table.sort( self.battlefield_data.battlefield_list, function(a,b)
        return a._guild_battle_event.area_id < b._guild_battle_event.area_id
    end )

    self.guild_battle_event = {}
    for i,v in ipairs(self.battlefield_data.battlefield_list) do
        self.guild_battle_event[i] = v._guild_battle_event
        v._guild_battle_event = nil
    end

    for i = 1,3 do 
        local isOpen = tonumber(self.battlefield_data.battlefield_list[i].is_open)
        self:setMapPointState(i,isOpen)
    end
end

--刷新一下左侧信息栏信息
function AllianceBattleMainView_V3:refreshLeftInfoPanel(TEST_STATE)--参数是测试用的

    local buffState;
    if TEST_STATE ~= nil then
        buffState = TEST_STATE
    else
        buffState = self.battlefield_data.buffstate;
    end

    if buffState == nil or buffState == "" or buffState == 4 then
        buffState = 1;
    elseif buffState == 0 then
        buffState = 2
    elseif buffState == 1 then
        buffState = 5
    elseif buffState == 2 then
        buffState = 3;
    elseif buffState == 3 then
        buffState = 4;
    end

    local remainTime = self.battlefield_data.remaintime;
    local enegy = self.battlefield_data.energy;
    local enegymax = self.battlefield_data.energy_max;

    local ischairman = self.battlefield_data.ischairman;
    if ischairman == 1 and buffState == 5 then
        buffState = 6;
    end

    for i = 1,6 do
        if(i == buffState) then
            self.buffBtns[i]:setVisible(true)
        else
            self.buffBtns[i]:setVisible(false)
        end
    end

    --充能中或者能量值已满
    if(buffState == 2 or buffState == 5 or buffState == 6) then
        self.text_enegyNum:setVisible(true)
        self.chargingbar:setVisible(true)
        self.chargingbar:setScaleX(enegy/enegymax);

        self.text_enegyNum:setString(enegy.."/"..enegymax)
    else
        self.chargingbar:setVisible(false)
        self.text_enegyNum:setVisible(false)
    end
    --发动中显示剩余时间
    if buffState == 3 then
        self.text_remainTime:stopAllActions();
        self.chargingbar:setVisible(true)
        self.chargingbar:setScaleX(1);
        self.text_remainTime:setString(UITool.getFormatTime(remainTime))
        local function func()
            self.text_remainTime:stopAllActions();

            UITool.delayTask(1.2,function()
                self:requestBattleFieldData()
            end)  
            --TODO刷新一下buffbtn，切换至状态5或者6
        end 
        UITool:schedule(self.text_remainTime, 1,remainTime ,self.text_remainTime,func)
    else
        self.text_remainTime:stopAllActions();
    end

    --发动中或者充能完成时，能量槽播放特效
    if buffState == 3 or buffState == 5 or buffState == 6 then
        if not self.enegyEffect then
            local frames = {}
            for i = 1,15 do
                frames[i] = cc.Sprite:create(string.format("n_UIShare/AllianceBattle/guildbattlebuff_00%02d.png",i-1)):getSpriteFrame();
            end

            self.enegyEffect = cc.Sprite:createWithSpriteFrame(frames[1]);

            local animation = cc.Animation:createWithSpriteFrames(frames, 1/15)
            self.enegyEffect:runAction(cc.RepeatForever:create(cc.Animate:create(animation)))

            local charging_bg = self.infoPanel:getChildByTag(266);
            charging_bg:addChild(self.enegyEffect)
            self.enegyEffect:setPosition(102,9)
        end
    else
        if self.enegyEffect then
            self.enegyEffect:removeFromParent();
            self.enegyEffect = nil;
        end
    end

    --如果是关闭状态，则不显示“明日开启”这句话
    if self.guildBattleState == 4 then
        for k,v in pairs(self.noticeText) do
            v:setVisible(false);
        end
    end

    --各种文本的值
    self.GuildName1:setString(self.battlefield_data.name_self) --本方公会名称
    self.GuildName2:setString(self.battlefield_data.name_enemy) --对手公会名称

    self.lunhuibi:setString(self.battlefield_data.tuanzhanbi) --轮回币
    self.medals:setString(self.battlefield_data.medal)   --奖章
    self.day:setString(self.battlefield_data.day)   --第几天
    self.Text_BattleTime:setString(self.battlefield_data.dayfight_time_start .. "~" ..self.battlefield_data.dayfight_time_end)--昼战时间
    self.Text_BattleTime_Night:setString(self.battlefield_data.nightfight_time_start .. "~" ..self.battlefield_data.nightfight_time_end)--昼战时间
    if g_channel_control.b_allianceBattle_version2 and self.activateTimes~=nil then
        local str = UITool.ToLocalization("剩余激活次数: %d")
        self.activateTimes:setString(string.format(str,self.battlefield_data.activate_times))   --剩余充能激活次数
    end 
    
    --开始和结束的日期
    local temp1 = {};
    local temp2 = {};
    temp1 = UITool.stringSplit(self.battlefield_data.data_start,"/");
    temp2 = UITool.stringSplit(self.battlefield_data.data_end,"/");
    local startDateText = temp1[1]
    local endDateText = temp2[1]
    for i = 2,#temp1 do
        startDateText = startDateText .."."..tonumber(temp1[i])
    end
    for i = 2,#temp2 do
        endDateText = endDateText .."."..tonumber(temp2[i])
    end
    
    self.Text_Date:setString(startDateText .. "~" ..endDateText)      
    
    self.points1:setString(self.battlefield_data.contribution_single_today)  --个人当日积分
    self.points2:setString(self.battlefield_data.contribution_single_total) --个人累计积分
    self.pointsRank:setString(self.battlefield_data.contribution_single_rank)  --个人累计积分排行

    --TODO
    --两处，1:此处。2:点击buff激活按钮时的显示
    self.buff_desc:setString(UITool.getUserLanguage(passive_sk[self.battlefield_data.buffid].sk_des))      --buff描述
end

--刷新一下信息(未报名)
function AllianceBattleMainView_V3:refreshLeftInfoPanel_NotSignUp()

    --各种文本的值
    if g_channel_control.transform_AllianceBattleMainView_V3_GuildName1_notSign_Text_pos == true then
        self.GuildName1_notSign:setAnchorPoint(cc.p(0.5,0))
        local oldY = self.GuildName1_notSign:getPositionY()
        local newY = oldY + 2
        self.GuildName1_notSign:setPositionY(newY)
        self.GuildName1_notSign:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.GuildName1_notSign:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    end
    self.GuildName1_notSign:setString(self.battlefield_data.name_self) --本方公会名称
    self.lunhuibi_notSign:setString(self.battlefield_data.tuanzhanbi) --轮回币
    self.medals_notSign:setString(self.battlefield_data.medal)   --奖章 TODO，medal字段为空
    self.day_notSign:setString(self.battlefield_data.day)   --第几天
    self.Text_BattleTime_notSign:setString(self.battlefield_data.dayfight_time_start .. "~" ..self.battlefield_data.dayfight_time_end)--昼战时间
    self.Text_BattleTime_Night_notSign:setString(self.battlefield_data.nightfight_time_start .. "~" ..self.battlefield_data.nightfight_time_end)--夜战时间

    --开始和结束的日期
    local temp1 = {};
    local temp2 = {};

    temp1 = UITool.stringSplit(self.battlefield_data.data_start,"/");
    temp2 = UITool.stringSplit(self.battlefield_data.data_end,"/");
    local startDateText = temp1[1]
    local endDateText = temp2[1]
    for i = 2,#temp1 do
        startDateText = startDateText .."."..tonumber(temp1[i])
    end
    for i = 2,#temp2 do
        endDateText = endDateText .."."..tonumber(temp2[i])
    end
    self.Text_Date_notSign:setString(startDateText .. "~" ..endDateText)

    self.points1:setString(self.battlefield_data.contribution_single_today)  --个人当日积分
    self.points2:setString(self.battlefield_data.contribution_single_total) --个人累计积分
    self.pointsRank:setString(self.battlefield_data.contribution_single_rank)  --个人累计积分排行

end

--刷新一下贡献值对比的值和动画
function AllianceBattleMainView_V3:refreshContributionContrast()
    local panel = self.infoPanel:getChildByTag(47);
    panel:unscheduleUpdate();
    panel:removeAllChildren();

    panel:setVisible(false)

    local value_self = self.battlefield_data.contribution_allience_self;--己方公会贡献值
    local value_enemy = self.battlefield_data.contribution_allience_enemy;--对手公会贡献值

    local ratio
    if(value_self == 0 and value_enemy == 0) then
        ratio = 0.5
    else
        ratio = value_self/(value_self+value_enemy);
    end

    self.infoPanel:getChildByTag(383):setString(value_self);
    self.infoPanel:getChildByTag(384):setString(value_enemy);

    local a = 458*ratio;
    local b = 458-458*ratio;
    local c = 34+ratio*458;
    local d = 526-34-ratio*458;
    
    local sprite_shine = cc.Sprite:create("n_UIShare/AllianceBattle/allienceBattle_huang.png");
    sprite_shine:setPosition(a,0);
    sprite_shine:setScale(2);
    panel:addChild(sprite_shine,1,1)

    local frames = {};
    for i = 1,10 do
        local sprite = cc.Sprite:create(string.format("n_UIShare/AllianceBattle/allienceBattle_shine%02d.png",i))
        local frame=sprite:getSpriteFrame();
        frames[i] = frame;
    end
    local animation = cc.Animation:createWithSpriteFrames(frames, 0.1)
    sprite_shine:runAction(cc.RepeatForever:create(cc.Animate:create(animation)))

    local sprite_yellow_bg = cc.Sprite:create("n_UIShare/AllianceBattle/allienceBattle_huang.png",cc.rect(0,0,a,24));
    local sprite_blue_bg = cc.Sprite:create("n_UIShare/AllianceBattle/allienceBattle_lan.png",cc.rect(a,0,b,24));
    sprite_yellow_bg:setPosition(0,0)
    sprite_yellow_bg:setAnchorPoint(cc.p(0,0.5))
    sprite_blue_bg:setPosition(a,0)
    sprite_blue_bg:setAnchorPoint(cc.p(0,0.5))
    panel:addChild(sprite_yellow_bg)
    panel:addChild(sprite_blue_bg)

    local t = 0;
    local idx = 1;
    local idxForShow = 0;--解决刚打开界面时闪烁的问题

    local yellowFrames = {};
    local blueFrames = {};
    for i = 1,7 do
        yellowFrames[i] = "n_UIShare/AllianceBattle/allienceBattle_huang_0"..i..".png";
        blueFrames[i] = "n_UIShare/AllianceBattle/allienceBattle_lan_0"..i..".png";
    end

    local sprite_yellow,sprite_blue,sprite_yellow_last,sprite_blue_last

    local function reloadSprite()

        sprite_yellow_last = sprite_yellow;
        sprite_blue_last = sprite_blue;

        sprite_yellow= cc.Sprite:create(yellowFrames[idx],cc.rect(0,0,c,92));
        sprite_blue = cc.Sprite:create(blueFrames[idx],cc.rect(c,0,d,92));

        sprite_yellow:setPosition(-32.28,-1.29);
        sprite_blue:setPosition(-32.28+c,-1.29);
        sprite_yellow:setAnchorPoint(cc.p(0,0.5));
        sprite_blue:setAnchorPoint(cc.p(0,0.5));
        panel:addChild(sprite_yellow)
        panel:addChild(sprite_blue)

        --解决刚打开界面时闪烁的问题      
        if idxForShow >= 1 then
            panel:setVisible(true)
        end
    end

    --reloadSprite();

    local isNextFrame = false;
    local function update(dt)
        t = dt + t;
        if isNextFrame then
            isNextFrame = false;
            if sprite_yellow_last~=nil then
                sprite_yellow_last:removeFromParent();
            end

            if sprite_blue_last ~= nil then
                sprite_blue_last:removeFromParent();
            end
            return;
        end

        if t >=0.15 then
            t=0
            idxForShow = idxForShow + 1;
            isNextFrame = true;
            idx = idx + 1;
            if(idx >=8) then
                idx = 1;
            end
            reloadSprite();
        end
    end

    panel:scheduleUpdateWithPriorityLua(update,0)
end

--切换界面
function AllianceBattleMainView_V3:switchView(channel,lastChannel)
    self.switchImageTable_1[lastChannel]:setVisible(true);
    self.switchImageTable_2[lastChannel]:setVisible(false);
    
    self.switchImageTable_1[channel]:setVisible(false);
    self.switchImageTable_2[channel]:setVisible(true); 

    --删除旧的
    if(lastChannel == 2) then
        SceneManager:hideAllianceAchi()
    elseif lastChannel == 3 then
        SceneManager:hideAllianceGacha()
    elseif lastChannel == 4 then
        SceneManager:hideAllianceShop()
    end

    --添加新的
    if(channel == 1) then
        self:requestBattleFieldData();
    elseif channel == 2 then
        local function refreshRedDotCallBack()
            self:refreshRedDot()
        end
        SceneManager:showAllianceAchi( self.nodeForOtherLayer,self.battlefield_data.war_id,1,refreshRedDotCallBack)
    elseif channel == 3 then
        SceneManager:showAllianceGacha( self.nodeForOtherLayer,self.battlefield_data.war_id)
    elseif channel == 4 then
        SceneManager:showAllianceShop( self.nodeForOtherLayer)
    end
end

--去大型战斗
function AllianceBattleMainView_V3:toMulBattleLayer()

    --从多人战界面返回时的回调
    local function callback_backFromMul( ... )
        --do nothing
    end

    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] = callback_backFromMul
    SceneManager:toMulBattleLayer(rcvData)
end

--请求战斗结束后的积分变化
function AllianceBattleMainView_V3:requestForPointsShow()
    local tempTable = {}
    tempTable["rpc"] = "guildbattle_win_points"

    GameManagerInst:rpc(tempTable,
        3,
        function(data)
            --success
            print("请求积分变化数据成功")
            if data.points_guild ~= 0 or data.points_personal ~= 0 then
                self:showAddedPoints(data.points_guild,data.points_personal);
            end
        end,
        function(state_code,msgText)
            --failed
            print("请求积分变化数据失败")
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
        true)
end

--积分增加的飘字动画
function AllianceBattleMainView_V3:showAddedPoints(points_guild,points_personal)
    if not points_guild or not points_personal then
        return
    end

    local startPos1 = cc.p(180,289)
    local startPos2 = cc.p(180,242)
    local endPos1 = cc.p(180,464)
    local endPos2 = cc.p(180,417)

    UITool.playFadeOutWords(self.nodeForUpperLayer,UITool.ToLocalization("本次 公会积分+")..points_guild,startPos1,endPos1)
    UITool.playFadeOutWords(self.nodeForUpperLayer,UITool.ToLocalization("本次 个人积分+")..points_personal,startPos2,endPos2)
    
end

function AllianceBattleMainView_V3:showGuidePicLayer( )
    local data = {}
    data.pictures = { --一张或者多张
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_033.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_034.png"
    }
    SceneManager:toGuidePictureLayer(data)
end

function AllianceBattleMainView_V3:SMapRefresh()
    self:requestForPointsShow();
    self:requestBattleFieldData();
end

function AllianceBattleMainView_V3:onNavigateTo(isback)
    if isback then
        print("从多人战界面返回公会战")
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    else
        print("从主界面进入公会战")
    end
end

--检测红点
function AllianceBattleMainView_V3:refreshRedDot()
    if self._csNode then
        local achiSwitchBtnImg1 = self._csNode:getChildByName("SwichImage2")
        local achiSwitchBtnImg2 = self._csNode:getChildByName("SwichImage7")
        if self:checkRedDot() then
            UITool.setCommmonBtnRedDop(achiSwitchBtnImg1,true,cc.p(150,75))
            UITool.setCommmonBtnRedDop(achiSwitchBtnImg2,true,cc.p(150,75))
        else
            UITool.setCommmonBtnRedDop(achiSwitchBtnImg1,false)
            UITool.setCommmonBtnRedDop(achiSwitchBtnImg2,false)
        end
    end
end

--检测红点
function AllianceBattleMainView_V3:checkRedDot()
    if self.battlefield_data then
        if SceneManager.guildbattle_achi_red_point > 0 then
            return true
        else
            return false
        end
    else
        return false
    end
end