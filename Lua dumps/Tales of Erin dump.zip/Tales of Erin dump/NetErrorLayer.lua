require "BasicLayer"

NetErrorLayer = class("NetErrorLayer",BasicLayer)
NetErrorLayer.__index = NetErrorLayer
NetErrorLayer.lClass = 3


--传入的数据结构

--[[
  data.desText = "网络连接不稳定,正在尝试恢复链接";
    data.showBtn = false;
    data.showTime = true;
    data.elpaseTime = self.netErrorElpaseTime;


]]



function NetErrorLayer:init()
	 print("NetErrorLayer:init");
    self:initView();
    
    self:addBtnListener();
    
    self:refresh(self.rData)
     

end

function NetErrorLayer:initView()
  print("NetErrorLayer:initView");
  -- body
  local uiNode =cc.CSLoader:createNode("NetError.csb")
    self.uiLayer:addChild(uiNode,100,2)
    
    -- 描述文本
    self.desText = uiNode:getChildByTag(1);
    self.confirmBtn = uiNode:getChildByTag(2);
    self.confirmBtn:setVisible(false);
    self.Text_time_elapse = uiNode:getChildByTag(17);
    
end

function NetErrorLayer:refresh(rData)
  print("NetErrorLayer:refresh");
  --dump(rData, "Data")
    self.rData = rData
    if self.rData ~= nil then
      self.sManager = self.rData["sManager"]
    end
    if self.rData and self.rData["rcvData"] then
      local rcvData = self.rData["rcvData"]

      --描述文字
      if rcvData.desText then

        self.desText:setString(UITool.ToLocalization(rcvData.desText) );

      end

      -- 是否显示按钮
      if rcvData.showBtn then
        self.confirmBtn:setVisible(true);
      else
        self.confirmBtn:setVisible(false);
      end
      
      --时间
      if rcvData.showTime and rcvData.elpaseTime then
       

        self:refreshTime(rcvData.elpaseTime);
      end

    end

end

function NetErrorLayer:refreshTime(time)
  if(self.Text_time_elapse == nil) then
    return 
  end
  self.Text_time_elapse:setVisible(true);
  time = time or 0
  time = math.floor(time);
  time = math.max(time, 0)
  self.Text_time_elapse:setString(time);
end


function NetErrorLayer:showBtn()
  self.confirmBtn:setVisible(true);
end



function NetErrorLayer:addBtnListener()
   local function onBtnConfirmCallback( )
     -- body
     print("click netError confirm ");
     cc.Director:getInstance():endToLua()
   end 
   
  self.confirmBtn:addClickEventListener(onBtnConfirmCallback);

end

function NetErrorLayer:clear()
  print("NetErrorLayer:clear")
  if self.uiLayer then
    print("NetErrorLayer:clear  uiLayer exist")
    self.uiLayer:removeFromParent()
    self.uiLayer:release()
    self.uiLayer = nil
  end

    
  self.super:clear()

end



function NetErrorLayer:create(rData)
     local layer = NetErrorLayer.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer.uiLayer:retain();
     layer:init()
     return layer
end


