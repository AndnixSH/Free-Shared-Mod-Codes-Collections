--组件基类
--组件分三个大类。buff,debuff和直接生效的效果，基类都是ComponentBase。
--created by kobejaw 2018.6.3.

--注：83004和83055两种特殊情况直接生效，不创建component。
--83开头的不需要添加到ComManager

ComponentBase = class("ComponentBase")
ComponentBase.BATTLE_BUFF_PATH = "uifile/buff_effect.csb" --buff效果展示动画文件

--@option,有些com会用到，例如根据伤害值计算吸血，option里有伤害值信息。根据攻击力计算毒伤害，option有攻击力信息。
function ComponentBase:ctor(comId,level,target,option)
	self.comId = comId
	self.level = level
	self.option = option
	self.target = target --绑定这个com的对象
	self.isNeedRemove = false
	if self.comId < 84000 then
		self.comData = state[self.comId][self.level]
		if not self.comData then  --有些83开头的不需要comData
			return
		end

		self.state_type = self.comData.state_type --效果类型。1.buff类。2.控制类。3.伤害类 4.标识  TODO,state_type为4时，不参与debuff是否命中的计算。一定命中。
		self.state_dispel = self.comData.state_dispel --是否可驱散，0不可。1为可。
		self.state_share = self.comData.state_share   --多人战时是否可共享。0不可。1可。

		self.remainTime = self.comData.t

		self.overlayNum = 1;--已经叠加的层数

		--多人战时，我方团队buff生命周期由前端自己管理，boss身上的debuff生命周期由服务器管理。所以，buff的isShared为nil
		if G_STAGE_TYPE == 2 and self.target.entityType == 2 and self.state_share == 1 and self.comId > 82000 and self.comId < 83000 then
			self.isShared = true    --多人战时共享的debuff，客户端不管理生命周期。
		end

		--是否可叠加
		if state[self.comId][level].state_op == 0 then
			self.canOverlay = false
		else  
			self.canOverlay = true
			self.overlayMaxNum = self.comData.state_op_max
			if self.overlayMaxNum == 0 then
				self.overlayMaxNum = 1;
			end
		end
	end
end

function ComponentBase:update(dt)
	if self.isShared then
		return
	end
	
	if self.remainTime then
		self.remainTime = self.remainTime - dt
		if self.remainTime <= 0 then
			self.isNeedRemove = true
		end
	end
end

--重置一下剩余时间
function ComponentBase:resetRemainTime()
	self.remainTime = self.comData.t
end

--@type 默认true.中毒和加血的中间过程false 
function ComponentBase:playSpineAnimation(type) -- type bool值，是否展示图片动画 主要针对毒和治疗，效果再次生效时只展示动画不展示图片，如治疗，只展示加血特效,不展示恢复文字
	if self.comData["state_spine"] == "" then
		return
	end
	--特效
	local spineData = BattleCacheManager:getData(self.comData["state_spine"])
	local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
    local effectNode = self.target.effectNode
    if self.target:getMonsterEnum() == 5 then
       spineNode:setScale(1.2)
    end
    effectNode:addChild(spineNode);

    --如果是眩晕，需要在debuff移除时停止特效，其他的都是播放完一次就自动移除。
    if self.comType == 2 and self.buffType == Com_DebuffEnum.Vertigo then
    	self.spineNode = spineNode
    	spineNode:setAnimation(0, "effect", true)
    else
    	spineNode:setAnimation(0, "effect", false)
    	local isEffect1 = spineNode:findAnimation("effect1")

    	if isEffect1 then
    		self.spineNode = spineNode
    	end

    	local this = self
	    local function completeCallback(event)
	    	--不知道unregisterSpineEventHandler这个函数怎么用，暂时重新注册一个空函数代替
	    	local function doNothing()
	    	end

	        local function removeSelf()
	        	if G_IsInBattle and not this.target.isDead and this.spineNode then
		        	--持续展示特效的那些buff，例如生命护盾，次数护盾等
		        	if isEffect1 then
		        		spineNode:setAnimation(0, "effect1", true)
		        		spineNode:registerSpineEventHandler(doNothing,sp.EventType.ANIMATION_COMPLETE)
		        	else
		        		spineNode:removeFromParent();
		        	end
	        	end
	        end
	        PerformWithDelayTime(removeSelf,0.01)
	    end
	    spineNode:registerSpineEventHandler(completeCallback,sp.EventType.ANIMATION_COMPLETE)
	end

    --文字显示
    if self.comData["state_sicon"]~="" and type == true then
    	local acNode = cc.CSLoader:createNode(self.BATTLE_BUFF_PATH)
    	local imgNode = acNode:getChildByTag(1)
    	imgNode:setUnifySizeEnabled(true)
    	imgNode:loadTexture(self.comData["state_sicon"])
    	local action = cc.CSLoader:createTimeline(self.BATTLE_BUFF_PATH)
    	action:play("play",false)
    	acNode:runAction(action)
    	effectNode:addChild(acNode,1)
    	local function removeNode()
    		if G_IsInBattle then
    	       acNode:stopAllActions()
    	       acNode:removeFromParent()
	   		end
        end
        
	    if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
	    	PerformWithDelayTime(removeNode,1.5)
	    else
	    	action:setLastFrameCallFunc(removeNode)
	    end
    end
end

--生效。
--@isAdd :是否是正向生效
--override if neccessary
function ComponentBase:takeEffect(isAdd)
	if isAdd then
		if self.comId < 84000 then
			self:playSpineAnimation(true)
		end
	else
		if self.spineNode and not self.target.isDead and G_IsInBattle then
			self.spineNode:removeFromParent()
			self.spineNode = nil;
		end
	end
end

function ComponentBase:checkIsNeedRemove()
	if self.isShared then  --如果是团战共享的buff或debuff，不需要客户端管理生命周期
		return false
	end
	return self.isNeedRemove
end

--检测是否可被驱散
function ComponentBase:checkCanBeDispelled()
	if self.state_dispel == 0 then
		return false
	else
		return true
	end	
end