--- 团站排行的基类根据类型 来设置公用的显示框

FaceBookLayer     = class("FaceBookLayer",BasicLayer)
FaceBookLayer.__index  = FaceBookLayer
FaceBookLayer.lClass         = 2


function FaceBookLayer:init()
	local node  = cc.CSLoader:createNode("FaceBookLayer.csb")
    
    self.uiLayer:addChild(node,0,2)
    self:initVariables()  
    self:sendDate()
    self:initBtns()
end
--初始化变量
function FaceBookLayer:initVariables( ... )
    if self.rData["facebook_id"] then
        self.facebookid = self.rData["facebook_id"]
    end
    self.table_facebook = {}
    self.exist = true
    self._csNode      = self.uiLayer:getChildByTag(2)
    --背景
    self.facebook_bg  = self._csNode:getChildByName("Image_facebook")
    --标题
    self.titleTex     = self.facebook_bg:getChildByName("Text_title")
    --图片
    self.imageMain    = self.facebook_bg:getChildByName("Image_16")
    --跳转按钮
    self.btn_to       = self.facebook_bg:getChildByName("Button_to")
    --获取按钮
    self.btn_get      = self.facebook_bg:getChildByName("Button_get")
    --关闭按钮
    self.btn_close    = self.facebook_bg:getChildByName("Button_close")
 end
--初始化按钮
function FaceBookLayer:initBtns( ... )
    local function touchCallBack( sender,eventType )
        if eventType == ccui.TouchEventType.ended then
            self:touchClick(sender,eventType)
        end
    end
    self.btn_to:addTouchEventListener(touchCallBack)
    self.btn_get:addTouchEventListener(touchCallBack)
    self.btn_close:addTouchEventListener(touchCallBack)
end
--点击事件
function FaceBookLayer:touchClick(  sender,eventType )
    local name = sender:getName()
    if name == "Button_to" then         -- 跳转
        self:btnToCallBack()
    elseif name == "Button_get" then    -- 获取
        self:btnGetCallBack()
    elseif name == "Button_close" then  -- 关闭
        self:btnCloseCallBack()
    end
end
-- 禁用领取按钮
function FaceBookLayer:getBrightBtn( ... )
    self.btn_to:setVisible(false)
    self.btn_get:setTouchEnabled(false)
    self.btn_get:setBright(false)
end
--跳转按钮回调事件
function FaceBookLayer:btnToCallBack( ... )
    -- body
        -- 记录跳转之前 和 回来之后的时间
    local time1  = 0
    local time2 = 0
    -- 跳转按钮回掉

    time1  = os.time()
    cc.Application:getInstance():openURL(self.table_facebook["parameter"])
    --self:sendFacebookState()
    self.btn_to:setTouchEnabled(false)
    self.btn_to:setBright(false)          
    --[[
        跳转网页的过程
        1 跳转网页 游戏暂停（同时会执行下边的函数）
        2 返回游戏 游戏恢复 (同时执行下边暂停的函数，恢复记时)
        3 原因是因为 游戏跳转会后台运行状态 游戏回来不会执行(而是在执行后台时候进行，的调用后，暂停)
        这样做，返回设置状态会有延时(为了避免c++代码处理 进行冷更)

    ]]
    local function TimeFunc( ... )
        self.btn_to:setTouchEnabled(true)
        self.btn_to:setBright(true)
        print("hhhhhhhhhhh == "..self.table_facebook["btn_time"])
        time2  = os.time()
        if time2 - time1 >= self.table_facebook["btn_time"] then
            -- self.btn_get:setVisible(true)
            -- self.btn_to:setVisible(false)
            self:sendFacebookState()
        end 
    end  
    local delay    = CCDelayTime:create(0.00001)
    local callfunc = CCCallFunc:create(TimeFunc)
    local sequence = cc.Sequence:create(delay, callfunc)
    self.btn_to:runAction(sequence)

end
--获取按钮回调事件
function FaceBookLayer:btnGetCallBack( ... )
    local function reiceSthCallBack(data)
        
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        local sData = {}
        sData["naem"] = UITool.ToLocalization("获取成功")
        sData["AllData"] = t_data["data"]["reward"]
        self.sManager:toMailGetAllLayer(sData)
        if t_data["data"]["btn_state"]  == 1 then
             self:setFacebookBtnState(t_data["data"]["btn_state"])
        else
            self:getBrightBtn()
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_facebook_get",
        ["act_id"]    = self.facebookid,
        ["is_pop"]    = 1
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--返回按钮回调事件
function FaceBookLayer:btnCloseCallBack( )
    self:returnBack()
end

function FaceBookLayer:setFacebookBtnState(btnState)
    -- body
    self.imageMain:loadTexture(self.table_facebook["main_pic"])
   -- self.btn_to:loadTextures(t_data["btn_normal"],t_data["btn_click"],t_data["btn_click"])
    if btnState   == 1 then      -- 跳转
        self.btn_to:loadTextures(self.table_facebook["btn_normal"],self.table_facebook["btn_click"],self.table_facebook["btn_click"])
        self.btn_get:setVisible(false)
        self.btn_to:setVisible(true)
    elseif btnState  == 2 then  -- 领取
        self.btn_get:setVisible(true)
        self.btn_get:setBright(true)
        self.btn_get:setTouchEnabled(true)
        self.btn_to:setVisible(false)
    elseif btnState  == 3 then  -- 领取过
        self.btn_get:setVisible(true)
        self.btn_to:setVisible(false)
        self.btn_get:setTouchEnabled(false)
        self.btn_get:setBright(false)
    end

end
--获取数据
function FaceBookLayer:sendDate( ... )

    local function reiceSthCallBack(data)
        
        print("获取facebook数据")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.table_facebook = t_data["data"]["facebook"]
        print("state == "..self.table_facebook["btn_state"])
        print("btn_time == "..self.table_facebook["btn_time"])
        self:setFacebookBtnState(self.table_facebook["btn_state"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_facebook",
        ["act_id"]    = self.facebookid
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 同步服务器获取状态
function FaceBookLayer:sendFacebookState( ... )
    -- body
    local function reiceSthCallBack(data)
        
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self:setFacebookBtnState(t_data["data"]["btn_state"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_facebook_state",
        ["act_id"]    = self.facebookid
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

-- 关闭函数
function FaceBookLayer:returnBack( ... )

    if self.sManager and self.sManager.FBKLayer then
        self.sManager.FBKLayer = nil
    end
    if self.uiLayer~=nil then
      self.uiLayer:removeFromParent()
      self.uiLayer = nil
    end
    self:clear()

end
function FaceBookLayer:create(sManager,tdata)

    local facebook = FaceBookLayer.new()
    facebook.rData = tdata 
    facebook.sManager  = sManager
    facebook.uiLayer   = cc.Layer:create()
    facebook:init()
    return facebook
end
