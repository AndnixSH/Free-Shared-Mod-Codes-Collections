achi_act_97_conf={} 
achi_act_97_conf[1] = {
        id= 1,
        achi_name= "重塑神之力1",
        achi_desc= "重复获得2次乌特迦",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[2] = {
        id= 2,
        achi_name= "重塑神之力2",
        achi_desc= "重复获得4次乌特迦",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[3] = {
        id= 3,
        achi_name= "重塑神之力3",
        achi_desc= "重复获得6次乌特迦",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[4] = {
        id= 4,
        achi_name= "重塑神之力4",
        achi_desc= "重复获得8次乌特迦",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[5] = {
        id= 5,
        achi_name= "半神之力",
        achi_desc= "重复获得10次乌特迦",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[6] = {
        id= 6,
        achi_name= "未知试炼1",
        achi_desc= "废神来袭∞胜利1次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[7] = {
        id= 7,
        achi_name= "未知试炼2",
        achi_desc= "废神来袭∞胜利10次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[8] = {
        id= 8,
        achi_name= "未知试炼3",
        achi_desc= "废神来袭∞胜利50次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[9] = {
        id= 9,
        achi_name= "未知试炼4",
        achi_desc= "废神来袭∞胜利200次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[10] = {
        id= 10,
        achi_name= "无尽试炼1",
        achi_desc= "废神来袭胜利100次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[11] = {
        id= 11,
        achi_name= "无尽试炼2",
        achi_desc= "废神来袭胜利200次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[12] = {
        id= 12,
        achi_name= "无尽试炼3",
        achi_desc= "废神来袭胜利300次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[13] = {
        id= 13,
        achi_name= "无尽试炼4",
        achi_desc= "废神来袭胜利400次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[14] = {
        id= 14,
        achi_name= "无尽试炼5",
        achi_desc= "废神来袭胜利500次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[15] = {
        id= 15,
        achi_name= "无尽试炼6",
        achi_desc= "废神来袭胜利600次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[16] = {
        id= 16,
        achi_name= "无尽试炼7",
        achi_desc= "废神来袭胜利800次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[17] = {
        id= 17,
        achi_name= "废神解析0.5%",
        achi_desc= "废神认知等级超越1",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[18] = {
        id= 18,
        achi_name= "废神解析1%",
        achi_desc= "废神认知等级超越2",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[19] = {
        id= 19,
        achi_name= "废神解析1.5%",
        achi_desc= "废神认知等级超越3",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[20] = {
        id= 20,
        achi_name= "废神解析2%",
        achi_desc= "废神认知等级超越4",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[21] = {
        id= 21,
        achi_name= "废神解析2.5%",
        achi_desc= "废神认知等级超越5",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[22] = {
        id= 22,
        achi_name= "废神解析3%",
        achi_desc= "废神认知等级超越6",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[23] = {
        id= 23,
        achi_name= "废神解析3.5%",
        achi_desc= "废神认知等级超越7",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[24] = {
        id= 24,
        achi_name= "废神解析4%",
        achi_desc= "废神认知等级超越8",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[25] = {
        id= 25,
        achi_name= "废神解析4.5%",
        achi_desc= "废神认知等级超越9",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[26] = {
        id= 26,
        achi_name= "废神解析5%",
        achi_desc= "废神认知等级超越10",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[27] = {
        id= 27,
        achi_name= "废神解析5.5%",
        achi_desc= "废神认知等级超越11",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[28] = {
        id= 28,
        achi_name= "废神解析6%",
        achi_desc= "废神认知等级超越12",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[29] = {
        id= 29,
        achi_name= "废神解析6.5%",
        achi_desc= "废神认知等级超越13",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[30] = {
        id= 30,
        achi_name= "废神解析7%",
        achi_desc= "废神认知等级超越14",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[31] = {
        id= 31,
        achi_name= "废神解析7.5%",
        achi_desc= "废神认知等级超越15",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[32] = {
        id= 32,
        achi_name= "废神解析8%",
        achi_desc= "废神认知等级超越16",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[33] = {
        id= 33,
        achi_name= "废神解析8.5%",
        achi_desc= "废神认知等级超越17",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[34] = {
        id= 34,
        achi_name= "废神解析9%",
        achi_desc= "废神认知等级超越18",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[35] = {
        id= 35,
        achi_name= "废神解析9.5%",
        achi_desc= "废神认知等级超越19",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[36] = {
        id= 36,
        achi_name= "废神解析10%",
        achi_desc= "废神认知等级超越20",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[37] = {
        id= 37,
        achi_name= "废神解析10.5%",
        achi_desc= "废神认知等级超越21",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[38] = {
        id= 38,
        achi_name= "废神解析11%",
        achi_desc= "废神认知等级超越22",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[39] = {
        id= 39,
        achi_name= "废神解析11.5%",
        achi_desc= "废神认知等级超越23",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[40] = {
        id= 40,
        achi_name= "废神解析12%",
        achi_desc= "废神认知等级超越24",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[41] = {
        id= 41,
        achi_name= "废神解析12.5%",
        achi_desc= "废神认知等级超越25",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[42] = {
        id= 42,
        achi_name= "废神解析13%",
        achi_desc= "废神认知等级超越26",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[43] = {
        id= 43,
        achi_name= "废神解析13.5%",
        achi_desc= "废神认知等级超越27",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[44] = {
        id= 44,
        achi_name= "废神解析14%",
        achi_desc= "废神认知等级超越28",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[45] = {
        id= 45,
        achi_name= "废神解析14.5%",
        achi_desc= "废神认知等级超越29",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[46] = {
        id= 46,
        achi_name= "废神解析15%",
        achi_desc= "废神认知等级超越30",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[47] = {
        id= 47,
        achi_name= "废神解析15.5%",
        achi_desc= "废神认知等级超越31",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[48] = {
        id= 48,
        achi_name= "废神解析16%",
        achi_desc= "废神认知等级超越32",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[49] = {
        id= 49,
        achi_name= "废神解析16.5%",
        achi_desc= "废神认知等级超越33",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[50] = {
        id= 50,
        achi_name= "废神解析17%",
        achi_desc= "废神认知等级超越34",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[51] = {
        id= 51,
        achi_name= "废神解析17.5%",
        achi_desc= "废神认知等级超越35",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[52] = {
        id= 52,
        achi_name= "废神解析18%",
        achi_desc= "废神认知等级超越36",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[53] = {
        id= 53,
        achi_name= "废神解析18.5%",
        achi_desc= "废神认知等级超越37",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[54] = {
        id= 54,
        achi_name= "废神解析19%",
        achi_desc= "废神认知等级超越38",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[55] = {
        id= 55,
        achi_name= "废神解析19.5%",
        achi_desc= "废神认知等级超越39",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[56] = {
        id= 56,
        achi_name= "废神解析20%",
        achi_desc= "废神认知等级超越40",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[57] = {
        id= 57,
        achi_name= "废神解析20.5%",
        achi_desc= "废神认知等级超越41",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[58] = {
        id= 58,
        achi_name= "废神解析21%",
        achi_desc= "废神认知等级超越42",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[59] = {
        id= 59,
        achi_name= "废神解析21.5%",
        achi_desc= "废神认知等级超越43",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[60] = {
        id= 60,
        achi_name= "废神解析22%",
        achi_desc= "废神认知等级超越44",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[61] = {
        id= 61,
        achi_name= "废神解析22.5%",
        achi_desc= "废神认知等级超越45",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[62] = {
        id= 62,
        achi_name= "废神解析23%",
        achi_desc= "废神认知等级超越46",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[63] = {
        id= 63,
        achi_name= "废神解析23.5%",
        achi_desc= "废神认知等级超越47",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[64] = {
        id= 64,
        achi_name= "废神解析24%",
        achi_desc= "废神认知等级超越48",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[65] = {
        id= 65,
        achi_name= "废神解析24.5%",
        achi_desc= "废神认知等级超越49",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[66] = {
        id= 66,
        achi_name= "废神解析25%",
        achi_desc= "废神认知等级超越50",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[67] = {
        id= 67,
        achi_name= "废神解析25.5%",
        achi_desc= "废神认知等级超越51",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[68] = {
        id= 68,
        achi_name= "废神解析26%",
        achi_desc= "废神认知等级超越52",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[69] = {
        id= 69,
        achi_name= "废神解析26.5%",
        achi_desc= "废神认知等级超越53",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[70] = {
        id= 70,
        achi_name= "废神解析27%",
        achi_desc= "废神认知等级超越54",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[71] = {
        id= 71,
        achi_name= "废神解析27.5%",
        achi_desc= "废神认知等级超越55",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[72] = {
        id= 72,
        achi_name= "废神解析28%",
        achi_desc= "废神认知等级超越56",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[73] = {
        id= 73,
        achi_name= "废神解析28.5%",
        achi_desc= "废神认知等级超越57",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[74] = {
        id= 74,
        achi_name= "废神解析29%",
        achi_desc= "废神认知等级超越58",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[75] = {
        id= 75,
        achi_name= "废神解析29.5%",
        achi_desc= "废神认知等级超越59",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[76] = {
        id= 76,
        achi_name= "废神解析30%",
        achi_desc= "废神认知等级超越60",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[77] = {
        id= 77,
        achi_name= "废神解析30.5%",
        achi_desc= "废神认知等级超越61",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[78] = {
        id= 78,
        achi_name= "废神解析31%",
        achi_desc= "废神认知等级超越62",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[79] = {
        id= 79,
        achi_name= "废神解析31.5%",
        achi_desc= "废神认知等级超越63",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[80] = {
        id= 80,
        achi_name= "废神解析32%",
        achi_desc= "废神认知等级超越64",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[81] = {
        id= 81,
        achi_name= "废神解析32.5%",
        achi_desc= "废神认知等级超越65",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[82] = {
        id= 82,
        achi_name= "废神解析33%",
        achi_desc= "废神认知等级超越66",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[83] = {
        id= 83,
        achi_name= "废神解析33.5%",
        achi_desc= "废神认知等级超越67",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[84] = {
        id= 84,
        achi_name= "废神解析34%",
        achi_desc= "废神认知等级超越68",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[85] = {
        id= 85,
        achi_name= "废神解析34.5%",
        achi_desc= "废神认知等级超越69",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[86] = {
        id= 86,
        achi_name= "废神解析35%",
        achi_desc= "废神认知等级超越70",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[87] = {
        id= 87,
        achi_name= "废神解析35.5%",
        achi_desc= "废神认知等级超越71",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[88] = {
        id= 88,
        achi_name= "废神解析36%",
        achi_desc= "废神认知等级超越72",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[89] = {
        id= 89,
        achi_name= "废神解析36.5%",
        achi_desc= "废神认知等级超越73",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[90] = {
        id= 90,
        achi_name= "废神解析37%",
        achi_desc= "废神认知等级超越74",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[91] = {
        id= 91,
        achi_name= "废神解析37.5%",
        achi_desc= "废神认知等级超越75",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[92] = {
        id= 92,
        achi_name= "废神解析38%",
        achi_desc= "废神认知等级超越76",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[93] = {
        id= 93,
        achi_name= "废神解析38.5%",
        achi_desc= "废神认知等级超越77",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[94] = {
        id= 94,
        achi_name= "废神解析39%",
        achi_desc= "废神认知等级超越78",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[95] = {
        id= 95,
        achi_name= "废神解析39.5%",
        achi_desc= "废神认知等级超越79",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[96] = {
        id= 96,
        achi_name= "废神解析40%",
        achi_desc= "废神认知等级超越80",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[97] = {
        id= 97,
        achi_name= "废神解析40.5%",
        achi_desc= "废神认知等级超越81",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[98] = {
        id= 98,
        achi_name= "废神解析41%",
        achi_desc= "废神认知等级超越82",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[99] = {
        id= 99,
        achi_name= "废神解析41.5%",
        achi_desc= "废神认知等级超越83",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[100] = {
        id= 100,
        achi_name= "废神解析42%",
        achi_desc= "废神认知等级超越84",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[101] = {
        id= 101,
        achi_name= "废神解析42.5%",
        achi_desc= "废神认知等级超越85",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[102] = {
        id= 102,
        achi_name= "废神解析43%",
        achi_desc= "废神认知等级超越86",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[103] = {
        id= 103,
        achi_name= "废神解析43.5%",
        achi_desc= "废神认知等级超越87",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[104] = {
        id= 104,
        achi_name= "废神解析44%",
        achi_desc= "废神认知等级超越88",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[105] = {
        id= 105,
        achi_name= "废神解析44.5%",
        achi_desc= "废神认知等级超越89",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[106] = {
        id= 106,
        achi_name= "废神解析45%",
        achi_desc= "废神认知等级超越90",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[107] = {
        id= 107,
        achi_name= "废神解析45.5%",
        achi_desc= "废神认知等级超越91",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[108] = {
        id= 108,
        achi_name= "废神解析46%",
        achi_desc= "废神认知等级超越92",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[109] = {
        id= 109,
        achi_name= "废神解析46.5%",
        achi_desc= "废神认知等级超越93",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[110] = {
        id= 110,
        achi_name= "废神解析47%",
        achi_desc= "废神认知等级超越94",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[111] = {
        id= 111,
        achi_name= "废神解析47.5%",
        achi_desc= "废神认知等级超越95",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[112] = {
        id= 112,
        achi_name= "废神解析48%",
        achi_desc= "废神认知等级超越96",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[113] = {
        id= 113,
        achi_name= "废神解析48.5%",
        achi_desc= "废神认知等级超越97",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[114] = {
        id= 114,
        achi_name= "废神解析49%",
        achi_desc= "废神认知等级超越98",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[115] = {
        id= 115,
        achi_name= "废神解析49.5%",
        achi_desc= "废神认知等级超越99",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[116] = {
        id= 116,
        achi_name= "废神解析50%",
        achi_desc= "废神认知等级超越100",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[117] = {
        id= 117,
        achi_name= "废神解析50.5%",
        achi_desc= "废神认知等级超越101",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[118] = {
        id= 118,
        achi_name= "废神解析51%",
        achi_desc= "废神认知等级超越102",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[119] = {
        id= 119,
        achi_name= "废神解析51.5%",
        achi_desc= "废神认知等级超越103",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[120] = {
        id= 120,
        achi_name= "废神解析52%",
        achi_desc= "废神认知等级超越104",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[121] = {
        id= 121,
        achi_name= "废神解析52.5%",
        achi_desc= "废神认知等级超越105",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[122] = {
        id= 122,
        achi_name= "废神解析53%",
        achi_desc= "废神认知等级超越106",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[123] = {
        id= 123,
        achi_name= "废神解析53.5%",
        achi_desc= "废神认知等级超越107",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[124] = {
        id= 124,
        achi_name= "废神解析54%",
        achi_desc= "废神认知等级超越108",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[125] = {
        id= 125,
        achi_name= "废神解析54.5%",
        achi_desc= "废神认知等级超越109",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[126] = {
        id= 126,
        achi_name= "废神解析55%",
        achi_desc= "废神认知等级超越110",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[127] = {
        id= 127,
        achi_name= "废神解析55.5%",
        achi_desc= "废神认知等级超越111",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[128] = {
        id= 128,
        achi_name= "废神解析56%",
        achi_desc= "废神认知等级超越112",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[129] = {
        id= 129,
        achi_name= "废神解析56.5%",
        achi_desc= "废神认知等级超越113",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[130] = {
        id= 130,
        achi_name= "废神解析57%",
        achi_desc= "废神认知等级超越114",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[131] = {
        id= 131,
        achi_name= "废神解析57.5%",
        achi_desc= "废神认知等级超越115",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[132] = {
        id= 132,
        achi_name= "废神解析58%",
        achi_desc= "废神认知等级超越116",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[133] = {
        id= 133,
        achi_name= "废神解析58.5%",
        achi_desc= "废神认知等级超越117",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[134] = {
        id= 134,
        achi_name= "废神解析59%",
        achi_desc= "废神认知等级超越118",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[135] = {
        id= 135,
        achi_name= "废神解析59.5%",
        achi_desc= "废神认知等级超越119",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[136] = {
        id= 136,
        achi_name= "废神解析60%",
        achi_desc= "废神认知等级超越120",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[137] = {
        id= 137,
        achi_name= "废神解析60.5%",
        achi_desc= "废神认知等级超越121",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[138] = {
        id= 138,
        achi_name= "废神解析61%",
        achi_desc= "废神认知等级超越122",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[139] = {
        id= 139,
        achi_name= "废神解析61.5%",
        achi_desc= "废神认知等级超越123",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[140] = {
        id= 140,
        achi_name= "废神解析62%",
        achi_desc= "废神认知等级超越124",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[141] = {
        id= 141,
        achi_name= "废神解析62.5%",
        achi_desc= "废神认知等级超越125",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[142] = {
        id= 142,
        achi_name= "废神解析63%",
        achi_desc= "废神认知等级超越126",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[143] = {
        id= 143,
        achi_name= "废神解析63.5%",
        achi_desc= "废神认知等级超越127",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[144] = {
        id= 144,
        achi_name= "废神解析64%",
        achi_desc= "废神认知等级超越128",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[145] = {
        id= 145,
        achi_name= "废神解析64.5%",
        achi_desc= "废神认知等级超越129",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[146] = {
        id= 146,
        achi_name= "废神解析65%",
        achi_desc= "废神认知等级超越130",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[147] = {
        id= 147,
        achi_name= "废神解析65.5%",
        achi_desc= "废神认知等级超越131",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[148] = {
        id= 148,
        achi_name= "废神解析66%",
        achi_desc= "废神认知等级超越132",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[149] = {
        id= 149,
        achi_name= "废神解析66.5%",
        achi_desc= "废神认知等级超越133",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[150] = {
        id= 150,
        achi_name= "废神解析67%",
        achi_desc= "废神认知等级超越134",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[151] = {
        id= 151,
        achi_name= "废神解析67.5%",
        achi_desc= "废神认知等级超越135",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[152] = {
        id= 152,
        achi_name= "废神解析68%",
        achi_desc= "废神认知等级超越136",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[153] = {
        id= 153,
        achi_name= "废神解析68.5%",
        achi_desc= "废神认知等级超越137",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[154] = {
        id= 154,
        achi_name= "废神解析69%",
        achi_desc= "废神认知等级超越138",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[155] = {
        id= 155,
        achi_name= "废神解析69.5%",
        achi_desc= "废神认知等级超越139",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[156] = {
        id= 156,
        achi_name= "废神解析70%",
        achi_desc= "废神认知等级超越140",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[157] = {
        id= 157,
        achi_name= "废神解析70.5%",
        achi_desc= "废神认知等级超越141",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[158] = {
        id= 158,
        achi_name= "废神解析71%",
        achi_desc= "废神认知等级超越142",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[159] = {
        id= 159,
        achi_name= "废神解析71.5%",
        achi_desc= "废神认知等级超越143",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[160] = {
        id= 160,
        achi_name= "废神解析72%",
        achi_desc= "废神认知等级超越144",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[161] = {
        id= 161,
        achi_name= "废神解析72.5%",
        achi_desc= "废神认知等级超越145",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[162] = {
        id= 162,
        achi_name= "废神解析73%",
        achi_desc= "废神认知等级超越146",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[163] = {
        id= 163,
        achi_name= "废神解析73.5%",
        achi_desc= "废神认知等级超越147",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[164] = {
        id= 164,
        achi_name= "废神解析74%",
        achi_desc= "废神认知等级超越148",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[165] = {
        id= 165,
        achi_name= "废神解析74.5%",
        achi_desc= "废神认知等级超越149",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[166] = {
        id= 166,
        achi_name= "废神解析75%",
        achi_desc= "废神认知等级超越150",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[167] = {
        id= 167,
        achi_name= "废神解析75.5%",
        achi_desc= "废神认知等级超越151",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[168] = {
        id= 168,
        achi_name= "废神解析76%",
        achi_desc= "废神认知等级超越152",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[169] = {
        id= 169,
        achi_name= "废神解析76.5%",
        achi_desc= "废神认知等级超越153",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[170] = {
        id= 170,
        achi_name= "废神解析77%",
        achi_desc= "废神认知等级超越154",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[171] = {
        id= 171,
        achi_name= "废神解析77.5%",
        achi_desc= "废神认知等级超越155",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[172] = {
        id= 172,
        achi_name= "废神解析78%",
        achi_desc= "废神认知等级超越156",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[173] = {
        id= 173,
        achi_name= "废神解析78.5%",
        achi_desc= "废神认知等级超越157",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[174] = {
        id= 174,
        achi_name= "废神解析79%",
        achi_desc= "废神认知等级超越158",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[175] = {
        id= 175,
        achi_name= "废神解析79.5%",
        achi_desc= "废神认知等级超越159",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[176] = {
        id= 176,
        achi_name= "废神解析80%",
        achi_desc= "废神认知等级超越160",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[177] = {
        id= 177,
        achi_name= "废神解析80.5%",
        achi_desc= "废神认知等级超越161",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[178] = {
        id= 178,
        achi_name= "废神解析81%",
        achi_desc= "废神认知等级超越162",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[179] = {
        id= 179,
        achi_name= "废神解析81.5%",
        achi_desc= "废神认知等级超越163",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[180] = {
        id= 180,
        achi_name= "废神解析82%",
        achi_desc= "废神认知等级超越164",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[181] = {
        id= 181,
        achi_name= "废神解析82.5%",
        achi_desc= "废神认知等级超越165",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[182] = {
        id= 182,
        achi_name= "废神解析83%",
        achi_desc= "废神认知等级超越166",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[183] = {
        id= 183,
        achi_name= "废神解析83.5%",
        achi_desc= "废神认知等级超越167",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[184] = {
        id= 184,
        achi_name= "废神解析84%",
        achi_desc= "废神认知等级超越168",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[185] = {
        id= 185,
        achi_name= "废神解析84.5%",
        achi_desc= "废神认知等级超越169",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[186] = {
        id= 186,
        achi_name= "废神解析85%",
        achi_desc= "废神认知等级超越170",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[187] = {
        id= 187,
        achi_name= "废神解析85.5%",
        achi_desc= "废神认知等级超越171",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[188] = {
        id= 188,
        achi_name= "废神解析86%",
        achi_desc= "废神认知等级超越172",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[189] = {
        id= 189,
        achi_name= "废神解析86.5%",
        achi_desc= "废神认知等级超越173",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[190] = {
        id= 190,
        achi_name= "废神解析87%",
        achi_desc= "废神认知等级超越174",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[191] = {
        id= 191,
        achi_name= "废神解析87.5%",
        achi_desc= "废神认知等级超越175",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[192] = {
        id= 192,
        achi_name= "废神解析88%",
        achi_desc= "废神认知等级超越176",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[193] = {
        id= 193,
        achi_name= "废神解析88.5%",
        achi_desc= "废神认知等级超越177",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[194] = {
        id= 194,
        achi_name= "废神解析89%",
        achi_desc= "废神认知等级超越178",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[195] = {
        id= 195,
        achi_name= "废神解析89.5%",
        achi_desc= "废神认知等级超越179",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[196] = {
        id= 196,
        achi_name= "废神解析90%",
        achi_desc= "废神认知等级超越180",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[197] = {
        id= 197,
        achi_name= "废神解析90.5%",
        achi_desc= "废神认知等级超越181",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[198] = {
        id= 198,
        achi_name= "废神解析91%",
        achi_desc= "废神认知等级超越182",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[199] = {
        id= 199,
        achi_name= "废神解析91.5%",
        achi_desc= "废神认知等级超越183",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[200] = {
        id= 200,
        achi_name= "废神解析92%",
        achi_desc= "废神认知等级超越184",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[201] = {
        id= 201,
        achi_name= "废神解析92.5%",
        achi_desc= "废神认知等级超越185",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[202] = {
        id= 202,
        achi_name= "废神解析93%",
        achi_desc= "废神认知等级超越186",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[203] = {
        id= 203,
        achi_name= "废神解析93.5%",
        achi_desc= "废神认知等级超越187",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[204] = {
        id= 204,
        achi_name= "废神解析94%",
        achi_desc= "废神认知等级超越188",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[205] = {
        id= 205,
        achi_name= "废神解析94.5%",
        achi_desc= "废神认知等级超越189",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[206] = {
        id= 206,
        achi_name= "废神解析95%",
        achi_desc= "废神认知等级超越190",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[207] = {
        id= 207,
        achi_name= "废神解析95.5%",
        achi_desc= "废神认知等级超越191",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[208] = {
        id= 208,
        achi_name= "废神解析96%",
        achi_desc= "废神认知等级超越192",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[209] = {
        id= 209,
        achi_name= "废神解析96.5%",
        achi_desc= "废神认知等级超越193",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[210] = {
        id= 210,
        achi_name= "废神解析97%",
        achi_desc= "废神认知等级超越194",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[211] = {
        id= 211,
        achi_name= "废神解析97.5%",
        achi_desc= "废神认知等级超越195",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[212] = {
        id= 212,
        achi_name= "废神解析98%",
        achi_desc= "废神认知等级超越196",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[213] = {
        id= 213,
        achi_name= "废神解析98.5%",
        achi_desc= "废神认知等级超越197",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[214] = {
        id= 214,
        achi_name= "废神解析99%",
        achi_desc= "废神认知等级超越198",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[215] = {
        id= 215,
        achi_name= "废神解析99.5%",
        achi_desc= "废神认知等级超越199",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_97_conf[216] = {
        id= 216,
        achi_name= "废神解析100%",
        achi_desc= "废神认知等级超越200",
        achi_icon= "icons/achiv/cjxt_001.png",

} 