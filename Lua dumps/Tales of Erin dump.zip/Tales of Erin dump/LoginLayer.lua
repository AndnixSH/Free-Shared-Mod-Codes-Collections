require "BasicLayer"


LoginLayer = class("LoginLayer",BasicLayer)
LoginLayer.__index = LoginLayer
LoginLayer.lClass = 2
function LoginLayer:init()
	
     local node =cc.CSLoader:createNode("LoginLayer.csb")
      self.uiLayer:addChild(node,100,2)

     -- local versionLabel = cc.LabelTTF:create("1.0.0",  "Marker Felt", 24)
     -- local size = cc.Director:getInstance():getWinSize()
     -- versionLabel:setPosition(size.width-20, size.height-10)
     -- versionLabel:setAnchorPoint(cc.p(1,1))
     -- self.uiLayer:addChild(versionLabel,1,10)
     -- --测试获取设备信息 
     -- local devicesStr = cc.UserDefault:getInstance():getStringForKey("DEVICES_DESCRIPTION")
     -- local devicesLabel = cc.LabelTTF:create(devicesStr,  "Marker Felt", 24)
     -- local size = cc.Director:getInstance():getWinSize()
     -- devicesLabel:setPosition(40, size.height - 10)
     -- devicesLabel:setAnchorPoint(cc.p(0,1))
     -- self.uiLayer:addChild(devicesLabel,1,10)

      ---控制台
    --   local btnTester = ccui.Button:create("n_UIShare/Global_UI/btn/qhzx_b_002_1.png", "n_UIShare/Global_UI/btn/qhzx_b_002_2.png")
    --     btnTester:setTitleText("控制台")
    --     btnTester:setTitleFontSize(26)
    --     btnTester:setTitleFontName(TEXT_FONT_NAME)
    --     btnTester:setPosition(1190,35)
    --     btnTester:addClickEventListener(function (sender,eventType)
    --         self.uiLayer:addChild(ConsoleView.new():init():getRootNode(),99)
    --     end)
    --   self.uiLayer:addChild(btnTester)

      local panel_1 = node:getChildByTag(1)


      local function textFieldEvent(sender, eventType)
        if eventType == ccui.TextFiledEventType.attach_with_ime then
              print("1")
    
        elseif eventType == ccui.TextFiledEventType.detach_with_ime then
              print("2")
        elseif eventType == ccui.TextFiledEventType.insert_text then
              print("3")
        elseif eventType == ccui.TextFiledEventType.delete_backward then
              print("4")
        end
      end
      for i=1,2 do 
         local textfield = ccui.Helper:seekWidgetByTag(panel_1,190+i)
         textfield:setTextVerticalAlignment(_G.kCCTextAlignmentCenter)
         textfield:addTouchEventListener(textFieldEvent)

         if i==1 then
            if cc.UserDefault:getInstance():getStringForKey("login_name") ~= "" then
               textfield:setText(cc.UserDefault:getInstance():getStringForKey("login_name"))
            end
         else   
           if cc.UserDefault:getInstance():getStringForKey("login_password") ~= "" then
               textfield:setText(cc.UserDefault:getInstance():getStringForKey("login_password"))
            end
         end      
       end 
      local touchEventTable = {
        [121] = self.rgtCallBack,
        [122] = self.logCallBack,
        [1]   = self.touchLogCallBack,
      }
      local touch_node =cc.CSLoader:createNode("touch_login.csb")

      local namePic = touch_node:getChildByName("Image_3")
      namePic:ignoreContentAdaptWithSize(true)
      --屏幕背景放大处理
      -- local touch_node_bg = touch_node:getChildByName("Image_2")
      -- local screenScale = ScreenManager:getInstance():getScreenScale()
      -- touch_node_bg:setScale(screenScale);

      local loginImgBg = touch_node:getChildByName("Image_2")
      local loginImage_4 = touch_node:getChildByName("Image_4")
      if g_channel_control.b_ZhouNianHD == true then
         local acNode =touch_node:getChildByTag(5)
         acNode:setVisible(false)
         loginImgBg:loadTexture(ZHOU_NIAN_BG_LOGIN)
         loginImage_4:setVisible(false)

         local namePicFor31you = touch_node:getChildByName("Image_3")
         namePicFor31you:setVisible(false)
      end
      if g_channel_control.b_CangYi == true then
         loginImgBg:loadTexture(CANG_YI_BG_LOGIN)
         loginImage_4:setVisible(false)
      end
      --31you渠道换一下游戏名称
      if(GAME_CHANNEL == CHANNEL.IOS.CHANNEL_CODE_31YOU) then
        local namePicFor31you = touch_node:getChildByName("Image_3")
        namePicFor31you:loadTexture("n_UIShare/login/Logo_31you.png")
      end

      local imageGameName = touch_node:getChildByName("Image_3")
      if g_channel_control.b_CangYi == true then
          imageGameName:setVisible(false)
      end
      
      local function touchCallBack(sender,eventType)
         if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            if sender:getTag()==6 then
              node:setVisible(true)
              touch_node:setVisible(false)
            elseif sender:getTag() == 7 then
               if DEBUG_MODE_LOGIN == 0 then
                 node:setVisible(true)
               else 
                  SDKManagerLua:showUserCenter(2)
               end 
            elseif sender:getTag() == 8 then
                self:dealRepariEvent()
            elseif sender:getTag() == 9 then --欧美服新增instagram主页按钮
                self:showInstagram()
            elseif sender:getTag() == 10 then --欧美服新增facebook主页按钮
                self:showFacebook()
            else
              touchEventTable[sender:getTag()](self)
            end
            
         end
      end

      for i =1,2 do
          local button = ccui.Helper:seekWidgetByTag(panel_1,120+i)
          button:addTouchEventListener(touchCallBack)

      end

      local imageView = ccui.Helper:seekWidgetByTag(panel_1,404)
      
   
      local imageView_2 = ccui.Helper:seekWidgetByTag(panel_1,403)
          
    self.uiLayer:addChild(touch_node,0,3)
    local zc_btn =touch_node:getChildByTag(6)
    zc_btn:addTouchEventListener(touchCallBack)

    local zw_btn = touch_node:getChildByTag(7)
    zw_btn:addTouchEventListener(touchCallBack)
    if CHANNEL.Android.CHANNEL_CODE_YJ ~= GAME_CHANNEL then
      local text=zw_btn:getChildByTag(11)
      text:setString(UITool.ToLocalization("注销登录"))
    end   
    local repari_btn = touch_node:getChildByTag(8)
    repari_btn:addTouchEventListener(touchCallBack)

    if CHANNEL.Android.CHANNEL_CODE_XM == GAME_CHANNEL then
       zw_btn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_JL == GAME_CHANNEL then
       zw_btn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_HW == GAME_CHANNEL then
       zw_btn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_VV == GAME_CHANNEL then
       zw_btn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_LX == GAME_CHANNEL then
       zw_btn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_OP == GAME_CHANNEL then
       zw_btn:setVisible(false)
    elseif CHANNEL.IOS.CHANNEL_CODE_31YOU == GAME_CHANNEL then
        zw_btn:setVisible(false)       
    end

    --欧美服新增INS主页以及facebook主页
    if(g_channel_control.loginLayer_showNewBtn == true) then
        local instagram_btn = touch_node:getChildByTag(9)
        instagram_btn:addTouchEventListener(touchCallBack)

        local facebook_btn = touch_node:getChildByTag(10)
        facebook_btn:addTouchEventListener(touchCallBack)
    end



    zc_btn:setVisible(false)
    local bgImg = touch_node:getChildByTag(1)
    bgImg:setTouchEnabled(true)
    bgImg:addTouchEventListener(touchCallBack)
    if g_channel_control.b_CangYi == false and g_channel_control.b_SuQing == false and g_channel_control.b_ZhouNianHD == false then
        local skeletonNode = sp.SkeletonAnimation:create("effects/login_yun/Logo.json", "effects/login_yun/Logo.atlas", 1.0)
        skeletonNode:setPosition(640,360)
        bgImg:addChild(skeletonNode)
        skeletonNode:setAnimation(1, "animation", true)
        self.skeletonNode = skeletonNode
    end

    local acNode =touch_node:getChildByTag(5)
    acNode:stopAllActions()

    if g_channel_control.b_CangYi == true then
        acNode:removeAllChildren()
        local logoEffNode = sp.SkeletonAnimation:create("n_UIShare/login/cangyidenglu/denglu_cangyi/denglu_cangyi.json", "n_UIShare/login/cangyidenglu/denglu_cangyi/denglu_cangyi.atlas", 1.0)
        logoEffNode:setPosition(10,50)
        acNode:addChild(logoEffNode)
        logoEffNode:setAnimation(1, "effect", true)
    else
        local acAction = cc.CSLoader:createTimeline("logo_effect.csb")
        acNode:runAction(acAction)
        acAction:play("play",true)
    end
    
    --MsgManager:showSimpMsg(XBConfigManager:getInstance():getADChannel())
    
    local tcAction = cc.CSLoader:createTimeline("touch_login.csb")

    touch_node:stopAllActions()
    touch_node:runAction(tcAction)
    tcAction:play("play",true)

    --测试代码     
     -- self.Test = true
     -- if self.Test then
     --       self:initTestGoogleLayer()
     --       return
     -- end

    if DEBUG_MODE_LOGIN == 0 then
       if cc.UserDefault:getInstance():getStringForKey("login_name") ~= "" and cc.UserDefault:getInstance():getStringForKey("login_password") ~= ""  then
          -- node:setVisible(false)
       else
          touch_node:setVisible(false)
          node:setVisible(true)
       end 

       --SDKManagerLua:showLogin()

    else 
      node:setVisible(false)

       SDKManagerLua:showLogin();
    end  
    touch_node:setVisible(true)
    local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
    --todo 停止或者恢复当前音乐
    if musicState == 0 then --开启音乐
        if AudioManager:shareDataManager():getBGId() ~= -1 then
            AudioManager:shareDataManager():resumeBGMusic()
        else
            local fullpath = lua_musci["loginBGM"]
            if g_channel_control.useBgMusicOnIAByLogin == true then
               fullpath = act_music_file["IA"]
            elseif g_channel_control.b_CangYi == true then 
               fullpath = act_music_file["Hanatan"]
            end
            AudioManager:shareDataManager():preloadM(fullpath)
            AudioManager:shareDataManager():playBGMusic(fullpath, true)
        end
    end 

    --local textArr = JsonUtil.getTableFromFile("system_btn/treat_agree.json" );

end

--检测是否需要显示条款层，还是显示登录选择层
function LoginLayer:checkShowLayer()
    local treatAgree = false;
    if cc.UserDefault:getInstance():getBoolForKey("treat_agree") ~= "" then
      treatAgree = cc.UserDefault:getInstance():getBoolForKey("treat_agree");
    end

    --  --初始化多语言项目配置
    -- ILocalizationManager  lm = JsonLocalizationManager:getInstance();
    --local file = cc.FileUtils:getInstance():fullPathForFilename("res/testHero/format.json");
    --MsgManager:showSimpMsg("format.json fullpath = "..file)
    -- lm:initLanguageData(file);
    -- LocalizationHelper:setCurrentManager(lm, false);

    --test
    --treatAgree = false;
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
      if treatAgree then
        if self:getTokenFromFile() ~= nil then
          local token = self:getTokenFromFile();
          --print("checkShowLayer login token = ", token);
          cc.MyHttpHelper:shareMyHttpHelper():setToken(token);
        else
          self:initLoginChooseLayer();
        end
        
      else
        self:initLoginTreatLayer();


      end
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
      if treatAgree == false then -- kochava 打点
        cc.UserDefault:getInstance():setBoolForKey("treat_agree", true);
        
      end

      self:initLoginChooseLayer();

    end 


   

  -- body
end

--初始化条款层
function LoginLayer:initLoginTreatLayer()
    print("initLoginTreatLayer");
    self._loginTreatLayer = LoginTreatLayer:create()
    self.uiLayer:addChild(self._loginTreatLayer.uiLayer ,120,4);
    self._loginTreatLayer:setConfirmCallback(function ( )
      -- body
        print("agree treat and show choose layer");
        self:initLoginChooseLayer()
    end)
end

--初始化登录选择层
function LoginLayer:initLoginChooseLayer()
    print("initLoginChooseLayer");

    self._loginChooseLayer = LoginChooseLayer:create()
    self.uiLayer:addChild(self._loginChooseLayer.uiLayer ,130,5);


    
end

--初始化测试层
function LoginLayer:initTestGoogleLayer()
    print("initLoginChooseLayer");

    self.testGoogleLayer = TestGoogleBillingLayer:create()
    self.uiLayer:addChild(self.testGoogleLayer.uiLayer ,130,5);


    
end


function LoginLayer:saveTokenToFile( )

  local token = cc.MyHttpHelper:shareMyHttpHelper():getGameToken();
  --print("saveTokenToFile token = ", token)
  local realToken = ""
  if token ~= nil and string.len(token) > 6 then
     realToken = string.sub(token, 7)
  end
  --print("saveTokenToFile realToken = ", realToken)
  cc.UserDefault:getInstance():setStringForKey("IS_TIP_BORN_STRING", realToken)
  
 

  --XBConfigManager:getInstance():setGlobalStringByKey("IS_TIP_BORN_STRING", token);

  

 
end

--从本地获取token
function LoginLayer:getTokenFromFile( )
  --local token = XBConfigManager:getInstance():getGlobalStringByKey("IS_TIP_BORN_STRING");
  local realToken = cc.UserDefault:getInstance():getStringForKey("IS_TIP_BORN_STRING")
  --print("getTokenFromFile realToken file = ", realToken)
  local token = nil;
  if realToken ~= nil and realToken ~= "" then
    token = "TOKEN:"..realToken;
  end
  --print("getTokenFromFile token file = ", token)
  if token ~= nil and token ~= "" then
    return token;
  end
  return nil;
end



--玩家信息请求
function LoginLayer:reqPlayerInfo()
   self.sManager:createWaitLayer()
   local function recTeamInfo(data)
        print("收到玩家信息结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            self.sManager:delWaitLayer()
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        user_info = {}
        user_info = t_data["data"]
        dump(user_info, "user_info:");
        if user_info["new_user"] == true then
          self.sManager:delWaitLayer()
            --2016.12.21 新手引导改成一开始不起名字
             self:createUsr()
        else
            -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
            -- if cc.PLATFORM_OS_ANDROID == targetPlatform then
            --     --dataeye 登陆
            --     if CHANNEL.Android.CHANNEL_CODE_YJ == GAME_CHANNEL then
            --         XBDataeyeManager:getInstance():login(user_info["id"])
            --     end 
            -- else 
            --     XBDataeyeManager:getInstance():login(user_info["id"])
            -- end

            DataManager:initDataManager()
            self.sManager:runMainScene()
            if g_channel_control.openUpdateRoleInfo then
                SDKManagerLua.updateRoleInfo()--每次进游戏后更新角色信息
            end
            ---登陆成功，开启心跳
            self.sManager:startHeartBeat()
            
            if self.skeletonNode then
                self.skeletonNode:stopAllActions()
                self.skeletonNode:removeFromParent()
                self.skeletonNode = nil
            end
            self:clear()
        end
    
   end
   
    local version =  UpdateManager:getVersion()
    local cjson = require "cjson"
      local tempTable = {
        ["rpc"]       = "user_info",
        ["version"] = version
    }

    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),recTeamInfo, cc.Handler.CALLFUNC); 
    dbhttp:creatHttpRequestWithURL(mydata,9)

end


function LoginLayer:createUsr()
    --起名字
    -- self.sManager:toNewNameLayer()
    -- self:clear()
    self.sManager:createWaitLayer()
    local function recUsrInfo(data)
        print("收到创建用户结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        self.sManager:delWaitLayer()
        if  t_data["data"]["state_code"] ~=1 then
            -- local popData = {}
            -- popData["showButType"] = 1
            -- popData["showDecType"] = 1
            -- popData["texDec"]      = t_data["warning"]
            -- popData["MsgType"]     = 5 
             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"])) --服务器返回中文需要改成韩文
            --self.sManager.msgMgr:showECastingMsg(popData)
            return
        end
        user_info = t_data["data"]
        -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
        -- if cc.PLATFORM_OS_ANDROID == targetPlatform then
        --     --dataeye 创建新用户
        --     if CHANNEL.Android.CHANNEL_CODE_YJ == GAME_CHANNEL then
        --         XBDataeyeManager:getInstance():createAccount(user_info["id"])
        --     end 
        -- else 
        --     XBDataeyeManager:getInstance():createAccount(user_info["id"])    
        -- end
        SDKManagerLua.updateRoleInfo()--创建用户后更新角色信息
        SysDot:eventCreateRole() --角色创建打点
        SysDot:eventLogin()     --角色登陆

        DataManager:initDataManager()
        self.sManager:runMainScene()
        ---登陆成功，开启心跳
        self.sManager:startHeartBeat()

        local roleData = {}
        roleData.id = user_info["id"]
        roleData.name = user_info["name"]
        SDKManagerLua:setCreateRoleData(roleData)
        
   end


    print("执行新建用户")
  
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "user_create",
        ["user_name"] = user_info["new_name"],
        ["adchannel"] = XBConfigManager:getInstance():getADChannel()
    }
    local str =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),recUsrInfo, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(str,8)

end
----登陆、以后按照渠道分，目前只接了易接，先按照 平台分
function LoginLayer:touchLogCallBack()
  if SDKManagerLua:isSdkLogin() == false then
    SceneManager:resetData();
    SDKManagerLua:showLogin();
  else
    self:loginServer();
  end
 
    
    --MsgManager:showSimpMsg(UpdateManager:getVersion())
end

function LoginLayer:loginServer()
  -- body
    local str = SDKManagerLua:getLoginStr()
    if not str then 
          SDKManagerLua:showLogin()
       return 
    end
    self.sManager:createWaitLayer()
    function reiceLogCallBack(data)
         print("收到登陆返回结果")
         data = tolua.cast(data, "PassData");
         print("callBack-----"..data:getData())
         self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
              if  t_data["data"]["state_code"] ~=1 then
                  self.sManager:popBillboard(t_data["data"]["warning"])
                 return
              end
          SDKManagerLua:setSDKLoginData(t_data["data"])
          SysDot:eventLogin()--AppsFlyer打点
          --self:saveTokenToFile();
          self:reqPlayerInfo()
     end
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceLogCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatLoginWithURL(str)
end

function LoginLayer:logCallBack()

    
    print("点击登录按钮")
    local node = self.uiLayer:getChildByTag(2)
    local panel_1 = node:getChildByTag(1)
    local nameTxt = ccui.Helper:seekWidgetByTag(panel_1,191)
    local passTxt = ccui.Helper:seekWidgetByTag(panel_1,192)

    local str_1 = nameTxt:getString()
    local str_2 = passTxt:getString()

    local str = "{".."\"login_name\":\""..str_1.."\",\"login_password\":\""..str_2.."\"".."}"
    print("用户名"..str_1.."  密码"..str_2.."  发送数据"..str)
    cc.UserDefault:getInstance():setStringForKey("login_name", str_1)
    cc.UserDefault:getInstance():setStringForKey("login_password", str_2)

    self.sManager:createWaitLayer()
    
    function reiceLogCallBack(data)
      print("收到登陆返回结果")
     
      data = tolua.cast(data, "PassData");
      print("callBack-----"..data:getData())
      self.sManager:delWaitLayer()
      local cjsonSafe = require "cjson.safe"
      local t_data = cjsonSafe.decode(data:getData())
      if t_data == nil then 
          MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
          --todo 处理错误数据页面跳转逻辑
          return
      end 
      if  t_data["data"]["state_code"] ~=1 then
          MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
        return
      end
      self:reqPlayerInfo()
    end

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceLogCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatLoginWithURL(str)
    
end


function LoginLayer:rgtCallBack()
   print("点击注册按钮")
   
    local node = self.uiLayer:getChildByTag(2)
    local panel_1 = node:getChildByTag(1)
    local nameTxt = ccui.Helper:seekWidgetByTag(panel_1,191)
    local passTxt = ccui.Helper:seekWidgetByTag(panel_1,192)

    local str_1 = nameTxt:getString()
    local str_2 = passTxt:getString()

    if str_1 == "" or str_2 ==""  then
        
       local label = cc.Label:createWithTTF(UITool.ToLocalization("用户名或密码不能为空"), TEXT_FONT_NAME, 32)
       label:setPosition(cc.p(visibleSize.width/2,visibleSize.height/2))
       self.uiLayer:addChild(label, 1)

        local function removeThis()
          label:removeFromParent()
        end

        --After 1.5 second, self will be removed.
        label:runAction(cc.Sequence:create(cc.DelayTime:create(1.5),cc.CallFunc:create(removeThis)))

    else
      
        function reiceRegCallBack(data)
             print("收到注册返回结果")
             data = tolua.cast(data, "PassData");
             print("callBack-----"..data:getData())

              self.sManager:delWaitLayer()
              local cjsonSafe = require "cjson.safe"
              local t_data = cjsonSafe.decode(data:getData())
              if t_data == nil then 
                  MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
                  --todo 处理错误数据页面跳转逻辑
                  return
              end 
             if  t_data["data"]["state_code"] ~=1 then
                  MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
                  return
             end
       self:logCallBack()
       end

        self.sManager:createWaitLayer()
        
       

        local str = "\"login_name\":\""..str_1.."\",\"login_password\":\""..str_2.."\""
        print("用户名"..str_1.."  密码"..str_2.."  发送数据"..str)
        cc.UserDefault:getInstance():setStringForKey("login_name", str_1)
        cc.UserDefault:getInstance():setStringForKey("login_password", str_2)
        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
         ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceRegCallBack, cc.Handler.CALLFUNC);    
         dbhttp:creatRegistrationURL(str)
    end


end

function LoginLayer:create(rData)
     local login = LoginLayer.new()
     login.rData = rData
     login.sManager = login.rData["sManager"]
     login.uiLayer = cc.Layer:create()
     login:init()
     return login
end

---添加应用宝登陆按钮
--登陆成功之后隐藏
function LoginLayer:initTencentLoginNode(rootNode)
    local size = cc.Director:getInstance():getWinSize()
    local maskLayout = ccui.Layout:create()
    maskLayout:setTouchEnabled(true)
    maskLayout:setContentSize(size)
    maskLayout:setPosition(0,0)
    maskLayout:setAnchorPoint(0,0)

    local btnWX = ccui.Button:create("system_btn/dljm_ui_01.png", "system_btn/dljm_ui_01.png")
    btnWX:setTitleText("")
    btnWX:setPosition(size.width/2 - 180,95)
    btnWX:addClickEventListener(function (sender,eventType)
          dump("微信")
          --[[
            TODO:弹出微信的登录框
            SDKManagerLua:showLogin(1) --参数按照应用宝处理
            注意在登陆成功之后或者直接隐藏吧，要调用 isShowTencentLoginNode(false) 隐藏登陆选择按钮
          ]] 
          --暂时点击就直接隐藏
          SDKManagerLua.txType = 1
          SDKManagerLua:showLogin()
          
    end)

    local btnQQ = ccui.Button:create("system_btn/dljm_ui_02.png", "system_btn/dljm_ui_02.png")
    btnQQ:setTitleText("")
    btnQQ:setPosition(size.width/2 + 180,95)
    btnQQ:addClickEventListener(function (sender,eventType)
          dump("QQ")
         --[[
            TODO:弹出QQ的登录框
            SDKManagerLua:showLogin(2)
            注意在登陆成功之后，要调用 isShowTencentLoginNode(false) 隐藏登陆选择按钮
          ]] 
          SDKManagerLua.txType = 2
          SDKManagerLua:showLogin()
         
    end)
    maskLayout:addChild(btnWX)
    maskLayout:addChild(btnQQ)
    rootNode:addChild(maskLayout,10000)
    self.tencentNode = maskLayout
end
---显示或者关闭QQ或者微信登陆按钮
function LoginLayer:isShowTencentLoginNode(isShow)
    self.tencentNode:setVisible(isShow)
    if self.zw_btn then 
        self.zw_btn:setVisible(not isShow)
    end 
end


---显示或者关闭韩国九天的登录界面
function LoginLayer:showNineSkyLoginChooseLayer(isShow)
  --MsgManager:showSimpMsg("showNineSkyLoginChooseLayer")
  if self._loginChooseLayer == nil then
    self:initLoginChooseLayer();
  else 
    self._loginChooseLayer.uiLayer:setVisible(isShow)
    self._loginChooseLayer:refreshBtn();
  end
end

function LoginLayer:dealRepariEvent()
  -- body
    local msg = UITool.ToLocalization("确认修复客户端？")
    MsgManager:showSimpMsgWithCallFunc(msg,self,self.dealRepari)
end
function LoginLayer:dealRepari()
    local write =  cc.FileUtils:getInstance():getWritablePath();
    FileUtilsEx:getInstance():deleteDir(write)
    cc.FileUtils:getInstance():createDirectory(write) 
    cc.FileUtils:getInstance():purgeCachedEntries() 
    --设置没有语音文件
    VoiceManager:setHaveVoiceFile(false);
    --在登陆界面修复客户端的时候，sdk的处理方案
    SDKManagerLua:sdkHandleRepairClient()
    cc.UserDefault:getInstance():setStringForKey("IS_TIP_BORN_STRING", "")
    XBConfigManager:getInstance():setGlobalBooleanByKey("HAS_DOWN_BASE",false) 
    UpdateManager:checkUpdate()
    
end

function LoginLayer:showInstagram(  )
    -- LogManager.showSimpMsgDebug("showInstagram")
    ins_url = "https://www.instagram.com/talesoferin.game/"
    cc.Application:getInstance():openURL(ins_url)
end

function LoginLayer:showFacebook(  )
    -- LogManager.showSimpMsgDebug("showFacebook")
    fb_url = "https://www.facebook.com/208347339794571"
  cc.Application:getInstance():openURL(fb_url)


end
