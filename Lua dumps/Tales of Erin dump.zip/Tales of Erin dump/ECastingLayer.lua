require "BasicLayer"

ECastingLayer= class("ECastingLayer",BasicLayer)
ECastingLayer.__index      = ECastingLayer
ECastingLayer.lClass       = 2
ECastingLayer.CastingMax   = nil
ECastingLayer.CastingCur   = nil
ECastingLayer.ListView     = nil
ECastingLayer.tableItem    = nil
ECastingLayer.server_t     = nil
ECastingLayer.complete_t   = nil
ECastingLayer.scheduler    = nil

ECastingLayer.CastingTable = nil
ECastingLayer.QuickTable   = nil
ECastingLayer.t_d_rate     = nil  --每个钻石恢复多少秒
ECastingLayer.t_d_need     = nil  --

ECastingLayer.curCastingTrue = false
ECastingLayer.IsOnlyCasting  = false


function ECastingLayer:init()

    local node =cc.CSLoader:createNode("ECastingLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true
    self.sManager.rootStop = self
   -- self.scheduler = cc.Director:getInstance():getScheduler()
    --隐藏兑换
    local exchangeBtn = node:getChildByName("Image_Exchange")
    if g_channel_control.ecastLayer_hideExchange == true then
        exchangeBtn:setVisible(false)
    end
    local btnReforge  = node:getChildByName("Image_Reforge")
    if g_channel_control.ecastLayer_hideReforge == true then
        btnReforge:setVisible(false)
    end

    local btnBag  = node:getChildByName("Image_forge")
    btnBag:loadTexture("res/uifile/n_UIShare/forge/xlzz_b_004_2.png")
    self:initSend()

    local MaxNum = node:getChildByName("Text_num")    -- 最大铸造数量
    -- MaxNum:setString("最大铸造数量"..self.CastingMax)
    MaxNum:setString("")
    local Goldbg = node:getChildByName("Image_goldbg") 
    local gold   = Goldbg:getChildByName("Text_goldnum") -- 金币
    gold:setString("")
    local gemBg  = node:getChildByName("Image_gembg")    -- 星石
    local gem    = gemBg:getChildByName("Text_gemNum")
    gem:setString("")
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    --首次进入 说明 key 统一用类名吧
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."ECastingLayer_1") == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."ECastingLayer_1", 1)
        self:ShowUiInfo()
    end
    ---第一次进入工坊，更改配置文件
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Casting) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Casting, 1)
    end

end

function ECastingLayer:refreshtable( ... )
    -- body

     self:initSend()
end
function ECastingLayer:initSend( ... )
    -- body
    self.curCastingTrue = false
    --self.tableItem  = nil
    self.IsOnlyCasting  = false
    local function reiceSellCallBack(data)
        print("收到铸造列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
           MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
           --MsgManager:showSimpMsg(t_data["data"]["warning"])
           MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
        return
        end
        self.CastingCur = t_data["data"]["curr_build"]
        self.CastingMax = t_data["data"]["max_build"]
        self.tableItem  = t_data["data"]["list"] 
        if self.CastingCur > 0 then
            for i = 1 ,#self.tableItem do
                if self.tableItem[i]["building_state"] == 1 then
                    print("进入这里面")
                    self.curCastingTrue = true
                end
            end
        end
        if self.curCastingTrue then
            print("第一次是否进入初始化的里面")
            self:ShowCastingEc(1)
        end
        if self.curCastingTrue == false or self.CastingCur == 0 then
            self:removeEffects()
        end
        self.server_t   = t_data["server_tm"]
        self.t_d_rate   = t_data["data"]["time_diamond_rate"]
        self.t_d_need   = t_data["data"]["time_diamond_need"]
        print("init CastingCur == "..self.CastingCur)
        self:initPro()
        self:sortCasting()
        --self:initCastingItem()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()


    local tempTable = {
        ["rpc"] = "forge_list",

    }


    local mydata =  cjson.encode(tempTable)
    print(":********************")
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSellCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 显示红点
function ECastingLayer:showHongdian( ... )
    -- body
    local ishsow = false
    print("#self.tableItem  == "..#self.tableItem )
    for i = 1 ,#self.tableItem do
        if self.tableItem[i]["building_state"] == 2 then
            ishsow = true
        end
        print("self.tableItem[i] building_state == "..self.tableItem[i]["building_state"] )
    end
    local node   = self.uiLayer:getChildByTag(2)
    local btnForge  = node:getChildByName("Image_forge")
    if ishsow == true then
        UITool.setCommmonBtnRedDop(btnForge,true,cc.p(137,66))
    else
         UITool.setCommmonBtnRedDop(btnForge,false)
    end
end
function ECastingLayer:initPro( ... )
	-- body
	local node   = self.uiLayer:getChildByTag(2)

	local Icon   = node:getChildByName("Image_icon")  -- 铸造图标 -- 根据锻造播放特效

	local MaxNum = node:getChildByName("Text_num")    -- 最大铸造数量
   -- MaxNum:setString("最大铸造数量"..self.CastingMax)
    MaxNum:setString(UITool.ToLocalization("铸造列表"))
	local Goldbg = node:getChildByName("Image_goldbg") 
	local gold   = Goldbg:getChildByName("Text_goldnum") -- 金币
	gold:setString(user_info["gold"])
	local gemBg  = node:getChildByName("Image_gembg")    -- 星石
	local gem    = gemBg:getChildByName("Text_gemNum")
	gem:setString(user_info["gem"])
	self.ListView = node:getChildByName("ListView_1")
    local function touchCallBack(sender,eventType)
       if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Image_bag"  then
               self:callBag()
            elseif sender:getName() == "Image_Exchange" then
               self:callExchange()
            elseif sender:getName() == "Image_Reforge" then
               self:callReforge()
            elseif sender:getName() == "Button_info" then
               self:ShowUiInfo()
            else
               self:returnBack()
            end
       end
    end
    local btn    = node:getChildByName("Button_close")
    btn:addTouchEventListener(touchCallBack)
    btn:setEffectType(3)

    local btnBag  = node:getChildByName("Image_bag")
    btnBag:addTouchEventListener(touchCallBack)

    local btnExchange  = node:getChildByName("Image_Exchange")
    btnExchange:addTouchEventListener(touchCallBack)

    local btnReforge  = node:getChildByName("Image_Reforge")
    btnReforge:addTouchEventListener(touchCallBack)

    local ButtonInfo = node:getChildByName("Button_info")
    ButtonInfo:addTouchEventListener(touchCallBack)


    ------------------------设置加载条---------------------
    self.ListView:setScrollBarEnabled(true)
    self.ListView:setScrollBarWidth(20)
    self.ListView:setScrollBarColor(cc.c3b(255, 255, 255))
    self.ListView:setScrollBarOpacity(225*0.5)
    self.ListView:setScrollBarPositionFromCorner(cc.p(2,2))

end
-- /*说明按钮的回调函数*/
function ECastingLayer:ShowUiInfo( ... )
    -- body
        --铸造
        local data = {}
        data.pictures = { --一张或者多张
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_024.png",
        }
        SceneManager:toGuidePictureLayer(data)
end

function ECastingLayer:callBag( ... )
    -- body
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    
    local sData = {}
    sData["back"] = "forge"
    --self.rData["back"] = "forge"
    self.sManager:toBagLayer(sData)--self.rData
    --self:clearEx()
    self:beforeReturnBack()
end

-- 去往兑换
function ECastingLayer:callExchange( ... )
    -- body

    --self.rData["back"] = "bag"
    local sData = {}
    sData["back"] = "forge"
    self.sManager:toExchangeLayer(sData)--self.rData
    --self:clearEx()
    self:beforeReturnBack()

end

-- 去往轮回重铸
function ECastingLayer:callReforge( ... )
    -- body

    --self.rData["back"] = "bag"
    local sData = {}
    sData["back"] = "forge"
    self.sManager:toReforgeLayer(sData)--self.rData
    --self:clearEx()
    self:beforeReturnBack()

end
function ECastingLayer:clearEx()
    self:clear()
end

function ECastingLayer:initCastingItem( ... )
	-- body
	local layout_list = ccui.Layout:create()
	local item        = cc.CSLoader:createNode("ECastingNode.csb")
	local itemMode    = item:getChildByName("Panel_2")
	layout_list:setContentSize(694,164)
    layout_list:setHighlighted(false)
	layout_list:setTouchEnabled(true)
	local itemModeC   = itemMode:clone()
	layout_list:addChild(itemModeC)
    self.ListView:setItemModel(layout_list)

    local len = #self.tableItem
    for i = 1 , len do
    	self.ListView:pushBackDefaultItem()
    end
    --if self.run_logic == nil then
       -- print("uuuuuuuuuuuuu 调用几次")
        self:Countdown()
   -- end
    for i = 1 , len do
    	local tab     = self.tableItem[i]
    	local itemEl  = self.ListView:getItem(i - 1)
        local item_1  = itemEl:getChildByName("Panel_2")
        local Texid   = item_1:getChildByName("Text_id")
        Texid:setString(self.tableItem[i]["id"])
    	-----------------铸造物品显示的属性--------------
    	local ImageIcon = item_1:getChildByName("Image_icon")   -- 图片
        print("image icon == "..tab["img"])
    	ImageIcon:loadTexture(tab["img"])

    	local dec       = item_1:getChildByName("Text_dec")
    	dec:setString(tab["des"])

    	local nameBg    = item_1:getChildByName("Image_upFrame")
    	local name      = nameBg:getChildByName("Text_num")
    	name:setString(tab["name"])
        local  isCasting = true
    	----------------锻造的素材属性的显示-------------
        local nType = nil
    	for m = 1 , 3 do
    		  --道具类型 1金币 2星石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
    		local mat_mat    = item_1:getChildByName("mat_"..m)
    		local matNum = item_1:getChildByName("Text_mat_"..m)
    		local nType  = tab["expend"][m]["type"]
    		--local icon   = ""
    		local need   = tab["expend"][m]["needs"]  -- 消耗
    		local have   = tab["expend"][m]["have"]   -- 拥有
            local id     = tab["expend"][m]["id"]
            -- local name   = ""
            -- local des    = ""
            local tabData = {}
            if need > have then
                isCasting = false
            end
            print("nType == "..nType)
            print("id ====  "..id)
    		if nType     == 1 then
    			tabData["img"]  = Coin_Icon[4]--"res/uifile/n_UIShare/main_page/hdgq_ui_006.png"

    		elseif nType == 2 then
    			tabData["img"]  = Coin_Icon[2]--"res/uifile/n_UIShare/main_page/ggsc_ui_076_1.png"
    		elseif nType == 3 then
    		elseif nType == 4 then
    		elseif nType == 5 then
    			tabData["img"]  = "icons/mat/"..mat[id]["icon"] 
                tabData["name"]  = UITool.getUserLanguage(mat[id]["name"])
                tabData["des"]   = UITool.getUserLanguage(mat[id]["desc"])     
    		end
            

            mat_mat:setUnifySizeEnabled(true)
    		mat_mat:loadTexture(tabData["img"])
    		matNum:setString(have.."/"..need)
            local function CallBackEvent( sender,eventType )
              -- body
               if eventType == ccui.TouchEventType.ended then
                 -- self:cllEInfo(tabData)
                 print("素材 nType == "..nType)
                 --self:showComInfo(nType,id,1,nil)
                 MsgManager:showSimpItemInfoAndDropInfo(nType,id,true,self.refreshtable,self)
               end
            end 
    		mat_mat:addTouchEventListener(CallBackEvent)
    	end
	    local function CallBackEvent( sender,eventType )
	      -- body
	      local name = sender:getName()
          local id   = Texid:getString()
	      if eventType == ccui.TouchEventType.ended then
	      	if name == "Button_Casting" then  -- 锻造
	      		self:callCasting(id,item_1)
	      	elseif name == "Button_KSZZ" then -- 快速完成
	      		self:callKSCasting(id,item_1)
	      	elseif name == "Button_4" then  -- 完成
	      		self:callCastingOk(id,item_1)
            elseif name == "Image_upFrame" then -- 显示铸造物品详细

               self:showComInfo(1,nil,nil,tab)
	      	end
	      end
	    end 
        -------------------铸造物品框响应事件---------------
        local upFrame  = item_1:getChildByName("Image_upFrame")
        upFrame:addTouchEventListener(CallBackEvent)
    	local Casting_state = tab["building_state"]   -- 建造状态 0 没有铸造 1 正在铸造 2 铸造完成
    	if Casting_state == 0 then
    		local btn = item_1:getChildByName("Button_Casting")
            btn:getChildByName("Text_8"):enableOutline(cc.c4b(0,0,0,255),1)
    		if isCasting == false then
    			btn:setBright(false)
    			btn:setEnabled(false)
    		else
    			btn:addTouchEventListener(CallBackEvent)
    		end
    	elseif Casting_state == 1 then
    		local inC = item_1:getChildByName("Image_Casting_in")
    		inC:setVisible(true)



    		local btn = inC:getChildByName("Button_KSZZ")
            btn:getChildByName("Text_6"):enableOutline(cc.c4b(0,0,0,255),1)
    		btn:addTouchEventListener(CallBackEvent)
    	elseif Casting_state == 2 then
    		local COk = item_1:getChildByName("Image_Casting_Ok")
    		COk:setVisible(true)
            if self.tableItem[i]["isFirst"] then
                self:ShowDoneEc(COk,0)
                self:ShowDoneEc(COk,1)
                self.tableItem[i]["isFirst"] = nil
            else
                self:ShowDoneEc(COk,2)
                self:ShowDoneEc(COk,0)
            end
    		local btn = COk:getChildByName("Button_4")
            COk:getChildByName("Text_12"):enableOutline(cc.c4b(0,0,0,255),1)
    		btn:addTouchEventListener(CallBackEvent)

    	end
    end
end

function ECastingLayer:cllEInfo( tab )
    -- body
    local node    = self.uiLayer:getChildByTag(2)
    local panel   = node:getChildByName("Panel_2")
    panel:setVisible(true)
    local ImageBg = panel:getChildByName("Image_Bg")
    local iconBg  = ImageBg:getChildByName("Image_Icon")
    local icon    = iconBg:getChildByName("Image_9")
    if tab["img"] then
        icon:setUnifySizeEnabled(true)
        icon:loadTexture(tab["img"])
    end
    local name    = ImageBg:getChildByName("Text_Name")
    name:setString(tab["name"])
    local des     = ImageBg:getChildByName("Text_Dec")
    des:setString(tab["des"])

    local function CallBackEvent( sender,eventType )
          -- body
        if eventType == ccui.TouchEventType.ended then
            panel:setVisible(false)
        end
    end 
    local btn     = ImageBg:getChildByName("Button_1")
    btn:addTouchEventListener(CallBackEvent)
end
function ECastingLayer:callCasting( id, item_1)    -- 锻造
	-- body
        print("锻造 id == "..id)
        local str = nil
        local tab = nil
        local len = #self.tableItem or 0
        for i = 1 ,len do
            print("循环的id == "..self.tableItem[i]["id"])
            if id == self.tableItem[i]["id"] then
             tab = self.tableItem[i]
            end
        end

        MsgManager:forgeStartModel(tab["img"],tab["name"],UITool.getUserLanguage(mat[tab["expend"][1]["id"]]["name"]),
            tab["expend"][1]["needs"],UITool.getUserLanguage(mat[tab["expend"][2]["id"]]["name"]),tab["expend"][2]["needs"],
            1,tab["expend"][3]["needs"],self,self.callCastingSend)
        --self.sManager.msgMgr:showECastingMsg(popData)
        self.CastingTable = {}
        self.CastingTable["id"] = id
        self.CastingTable["item_1"]= item_1

    

end
function ECastingLayer:callCastingSend( ... ) -- 发送锻造消息
    -- body
    local tab = nil
    local id  = self.CastingTable["id"]
    for i = 1 ,#self.tableItem do
        if id == self.tableItem[i]["id"] then
            tab = self.tableItem[i]
        end
    end
    --local id  = self.CastingTable["id"]
    local item_1 = self.CastingTable["item_1"]
    local function reiceSellCallBack(data)
        print("收到铸造列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
        return
        end
        local inC = self.CastingTable["item_1"]:getChildByName("Image_Casting_in")
        inC:setVisible(true)

        for i = 1 ,#self.tableItem do
            if id == self.tableItem[i]["id"] then
                self.tableItem[i]["building_state"] = 1
                self.tableItem[i]["complete_time"]  = t_data["data"]["complete_time"]
               -- tab = self.tableItem[i]
            end
        end
        if self.IsOnlyCasting == false then
            print("self.IsOnlyCasting == false")
            self:ShowCastingEc(0)
            self.IsOnlyCasting = true
        else
             print("self.IsOnlyCasting == true")
        end 
      
        local function CallBackEvent( sender,eventType )
          -- body
          if eventType == ccui.TouchEventType.ended then
              self:callKSCasting(id,item_1)
          end
        end 
        local btn = inC:getChildByName("Button_KSZZ")
        btn:addTouchEventListener(CallBackEvent)



        self.server_t = t_data["server_tm"] 
        for m = 1 , 3 do
              --道具类型 1金币 2星石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
            --local mat    = item_1:getChildByName("mat_"..m)
            --local matNum = item_1:getChildByName("Text_mat_"..m)
            local nType  = tab["expend"][m]["type"]
            local icon   = ""
            local need   = tab["expend"][m]["needs"]  -- 消耗
            local have   = tab["expend"][m]["have"]   -- 拥有
            local id     = tab["expend"][m]["id"]
            local name   = ""
            if nType     == 1 then
                name = "金币"
            elseif nType == 2 then
                
            elseif nType == 3 then
            elseif nType == 4 then
            elseif nType == 5 then
             --   user_info["bag"]["mat"]["mat_"..id] = user_info["bag"]["mat"]["mat_"..id] - need     
            end 
        end
        user_info["gold"] = t_data["data"]["gold"]
        self.CastingCur   = self.CastingCur + 1
        self:rfsRate()
        self:rfsGold()
        self.CastingTable = nil
        self:sortCasting()

    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()


    local tempTable = {
        ["rpc"] = "forge_build",
        ["id"]  = tab["id"]

    }


    local mydata =  cjson.encode(tempTable)
    print(":********************")
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSellCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function  ECastingLayer:sortCasting( ... )
    -- body
    for i = 1 , #self.tableItem do
       table.sort(self.tableItem , function(a , b)
            return a["building_state"] >  b["building_state"]  
        end)
    end
    self:showHongdian()
    self.ListView:removeAllChildren()
   -- self:Stop()
    self:initCastingItem()

end
function ECastingLayer:callKSCasting( id,item_1 )  -- 快速锻造
    print("进入高速锻造界面")
	-- body
    local cTime = 1
    for i = 1 ,#self.tableItem do
        if id == self.tableItem[i]["id"] then
            cTime  = self.tableItem[i]["complete_time"]
        end
    end
    local Surplus_t = cTime - self.server_t
    local mod = Surplus_t%self.t_d_rate
    local gemNum = (1 + math.floor(Surplus_t/self.t_d_rate))*self.t_d_need
    if mod == 0 then
        gemNum = math.floor(Surplus_t/self.t_d_rate)*self.t_d_need
    end
    if gemNum > user_info["gem"] then

        MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("购买星石"),self,self.callBuyGem)
       -- self.sManager:toPSPopupLayer(popData)
    else

        MsgManager:shwoCostType( 2 ,gemNum,self,self.callBuyCasting)
        self.QuickTable = {}
        self.QuickTable["id"]  = id
        self.QuickTable["item_1"] = item_1

    end


end
-------------------刷新金币----------
function ECastingLayer:rfsGold( ... )
    -- body
    local node   = self.uiLayer:getChildByTag(2)
    local Goldbg = node:getChildByName("Image_goldbg") 
    local gold   = Goldbg:getChildByName("Text_goldnum") -- 金币
    gold:setString(user_info["gold"])

end
function ECastingLayer:rfsGem( ... )
    -- body
    local node   = self.uiLayer:getChildByTag(2)
    local gemBg  = node:getChildByName("Image_gembg")    -- 星石
    local gem    = gemBg:getChildByName("Text_gemNum")
    gem:setString(user_info["gem"])
end
function ECastingLayer:rfsRate( ... )
    -- body
    -- local node   = self.uiLayer:getChildByTag(2)
    -- local rate   = node:getChildByName("Text_rate")   -- 运转率
    -- local rateN = 0
    -- if self.CastingCur == 0 or self.CastingCur == nil then
    --     rateN = 0
    -- else
    --     rateN  = math.floor(self.CastingCur/self.CastingMax*100)
    -- end
    -- rate:setString(UITool.ToLocalization("运转率")..rateN.."%")

    -- local Icon   = node:getChildByName("Image_icon")  -- 铸造图标 -- 根据锻造播放特效

end
function ECastingLayer:callBuyGem( ... )     -- 购买星石
    -- body
    local sData = {}
        sData["shopTypeIndex"] = 1
        self.sManager:toShopLayer(sData)
end
function ECastingLayer:callBuyCasting( ... )        -- 发送快速锻造
    -- body
    local function reiceSellCallBack(data)
        print("快速锻造")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
        return
        end

        local inC = self.QuickTable["item_1"]:getChildByName("Image_Casting_in")
        inC:setVisible(false)
        local inO = self.QuickTable["item_1"]:getChildByName("Image_Casting_Ok")
        inO:setVisible(true)

        local id  = self.QuickTable["id"]
        local item_1 = self.QuickTable["item_1"]

        local function CallBackEvent( sender,eventType )
          -- body
          if eventType == ccui.TouchEventType.ended then
              self:callCastingOk(id,item_1)
          end
        end 
        local btn = inO:getChildByName("Button_4")
        btn:addTouchEventListener(CallBackEvent)
        user_info["gem"] = t_data["data"]["gem"]
        user_info["gem_r"] = t_data["data"]["gem_r"]
        for i = 1 ,#self.tableItem do
            if id == self.tableItem[i]["id"] then
                self.tableItem[i]["building_state"] = 2
                self.tableItem[i]["isFirst"] = true
                -- self.tableItem[i]["complete_time"]  = t_data["data"]["complete_time"]
                -- tab = self.tableItem[i]
            end
        end
        local isE = false
        for i = 1 ,#self.tableItem do
            if self.tableItem[i]["building_state"] == 1 then
                isE = true      
            end
        end
        if isE == false then
            self:removeEffects()
        end

        self:rfsGem()
        self:sortCasting()

    end
    local tab = nil
    for i = 1 ,#self.tableItem do
        if self.QuickTable["id"] == self.tableItem[i]["id"] then
             tab = self.tableItem[i]
        end
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()


    local tempTable = {
        ["rpc"] = "forge_build_speedup",
        ["id"]  = tab["id"]

    }
    local mydata =  cjson.encode(tempTable)
    print(":********************")
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSellCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function ECastingLayer:callCastingOk( id,item_1 )  -- 锻造完成
	-- body
    local sData = {}
    local tab   = nil 
    if self.tableItem ~= nil and #self.tableItem > 0 then
        for i = 1 ,#self.tableItem do
            if id == self.tableItem[i]["id"] then
                sData["name"] = UITool.getUserLanguage(self.tableItem[i]["name"])
                sData["des"]  = UITool.getUserLanguage(self.tableItem[i]["des"])
                sData["img"]  = self.tableItem[i]["img"]
                tab = self.tableItem[i]
            end
        end    
    end
    
    local function reiceSellCallBack(data)
        print("锻造完成,收取道具")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))       
            return
        end
        self:Stop()
        self.sData = {}
        self.rData = {}
        self.CastingMax = nil
        self.CastingCur = nil
        self.ListView   = nil
        self.tableItem  = nil
        self.curCastingTrue = nil
        self.IsOnlyCasting  = nil
        self.QuickTable = nil
        self.t_d_rate = nil
        self.server_t = nil
        self.complete_t = nil
        self.CastingTable = nil 
        if t_data["data"]["get"]["real_id"] == nil then

            self:initSend()
             MsgManager:showSimpMsg(UITool.ToLocalization("背包已满,请到邮件进行查收"));
            return
        end
        -- 
        self:showComInfo(2,t_data["data"]["get"]["id"],t_data["data"]["get"]["item_type"],nil,t_data["data"]["get"]["real_id"])
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    -- dump(tab, "callCastingOk:tab111")
    local forge_id = ""
    if tab and tab["id"] then
        forge_id = tostring(tab["id"])
    end
    if forge_id == nil or forge_id == "" then
        return
    end
    local tempTable = {
        ["rpc"] = "forge_get",
        ["id"]  = forge_id

    }
    local mydata =  cjson.encode(tempTable)
    print(":********************")
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSellCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)

end
function ECastingLayer:Countdown()
	-- body
    print("uuuuuuu 执行几次")
	-- body   
    for i = 1 ,#self.tableItem do
        local tab    = self.tableItem[i]
        local Panel = self.ListView:getItem(i - 1)
        local item_1 = Panel:getChildByName("Panel_2")

        local Casting_state = tab["building_state"] 
        if Casting_state == 1 then
            local inC    = item_1:getChildByName("Image_Casting_in")
            inC:setVisible(true)
            local Tex_t  = inC:getChildByName("Text_time")
            local t_time = tab["complete_time"]   -- 显示倒计时
            local cur_t  =  t_time - self.server_t
            print("倒计时开始")
            local function function_name( ... )
                -- body
        
                self:removeEffects()
                self:refreshtable()   
            end 
            UITool:schedule(inC, 1,cur_t ,Tex_t,function_name)
            print("倒计时结束")
            Tex_t:setString(time)  
        else

        end 
    end

end

function ECastingLayer:beforeReturnBack()
    -- body
    self.exist = false
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    SceneManager:removeFromNavNodes(self)
    self.sData = {}
    self.rData = {}
    self.sManager.rootStop = nil
    self.CastingMax = nil
    self.CastingCur = nil
    self.ListView   = nil
    self.tableItem  = nil
    self.curCastingTrue = nil
    self.IsOnlyCasting  = nil
    self.tag = nil 
    self:clearEx()
end

function ECastingLayer:returnBack( ... )
	-- body
    self:beforeReturnBack()
    SceneManager:toStartLayer()
    
end
-- 数据出错调用这个函数 ，直接返回首页
function ECastingLayer:returnBack1( ... )
    -- body
    self:beforeReturnBack()
    SceneManager:toStartLayer()
end
function ECastingLayer:Stop( ... )
    -- body
    -- if self.scheduler ~= nil and self.run_logic ~= nil then
    --     self.scheduler:unscheduleScriptEntry(self.run_logic) 
    -- end 
    -- self.run_logic = nil
    
end
function ECastingLayer:ShowDoneEc(bg, index )
    -- body
    if index == 0 then
        local node  = cc.CSLoader:createNode("CastingEOKNode.csb")
        self:HideDoneEc(node,0)
        local Anim  = cc.CSLoader:createTimeline("CastingEOKNode.csb")
        bg:addChild(node)
        node:runAction(Anim)
        Anim:play("animation0", false);
    elseif index == 1 then
        local node  = cc.CSLoader:createNode("CastingEOKNode.csb")
        local Anim  = cc.CSLoader:createTimeline("CastingEOKNode.csb")
        local function caiSeCallBack( ... )
            -- body
             self:HideDoneEc(node,2)
             Anim:play("animation2", true);
        end 

        bg:addChild(node)
        node:runAction(Anim)
        Anim:setLastFrameCallFunc(caiSeCallBack)
        self:HideDoneEc(node,1)
        Anim:play("animation1", false);
    elseif index == 2 then
        local node  = cc.CSLoader:createNode("CastingEOKNode.csb")
        self:HideDoneEc(node,2)
        local Anim  = cc.CSLoader:createTimeline("CastingEOKNode.csb")
        bg:addChild(node)
        node:runAction(Anim)
        Anim:play("animation2", true);
    end
end
function ECastingLayer:HideDoneEc( bg,index )
    -- body
    local btnE  = bg:getChildByName("Sprite_btn")
    local onlyE = bg:getChildByName("Sprite_only")
    local xh    = bg:getChildByName("Sprite_xh")
    if index == 0 then
        btnE:setVisible(true)
        onlyE:setVisible(false)
        xh:setVisible(false)
    elseif index == 1 then
        btnE:setVisible(false)
        onlyE:setVisible(true)
        xh:setVisible(false)
    elseif index == 2 then
        btnE:setVisible(false)
        onlyE:setVisible(false)
        xh:setVisible(true)
    end

end
function ECastingLayer:ShowCastingEc(index)
  -- body
    if index == 0 then
        local bgCsd = cc.CSLoader:createNode("CastingNode.csb")
        local Aninode = cc.CSLoader:createTimeline("CastingNode.csb") 

          self:HideEffects(bgCsd,0)
          self.uiLayer:addChild(bgCsd,0,3)
          bgCsd:runAction(Aninode);
        ------------------回调函数------------------
          local function caiSeCallBack( ... )
            bgCsd:removeFromParent()
            local bgCsd1 = cc.CSLoader:createNode("CastingNode.csb")
            local Aninode1 = cc.CSLoader:createTimeline("CastingNode.csb") 
            self:HideEffects(bgCsd1,1)
            self.uiLayer:addChild(bgCsd1,0,3)
            bgCsd1:runAction(Aninode1);
            Aninode1:play("animation1", true);

            local bgCsd2 = cc.CSLoader:createNode("CastingNode.csb")
            local Aninode2 = cc.CSLoader:createTimeline("CastingNode.csb") 
            self:HideEffects(bgCsd2,2)
            self.uiLayer:addChild(bgCsd2,0,4)
            bgCsd2:runAction(Aninode2);
            Aninode2:play("animation2", true);

            local bgCsd3 = cc.CSLoader:createNode("CastingNode.csb")
            local Aninode3 = cc.CSLoader:createTimeline("CastingNode.csb") 
            self:HideEffects(bgCsd3,3)
            self.uiLayer:addChild(bgCsd3,0,5)
            bgCsd3:runAction(Aninode3);
            Aninode3:play("animation3", true);
           end
        Aninode:setLastFrameCallFunc(caiSeCallBack)
        Aninode:play("animation0", false);
    elseif index == 1 then
           -- bgCsd:removeFromParent()
            local bgCsd1 = cc.CSLoader:createNode("CastingNode.csb")
            local Aninode1 = cc.CSLoader:createTimeline("CastingNode.csb") 
            self:HideEffects(bgCsd1,1)
            self.uiLayer:addChild(bgCsd1,0,3)
            bgCsd1:runAction(Aninode1);
            Aninode1:play("animation1", true);

            local bgCsd2 = cc.CSLoader:createNode("CastingNode.csb")
            local Aninode2 = cc.CSLoader:createTimeline("CastingNode.csb") 
            self:HideEffects(bgCsd2,2)
            self.uiLayer:addChild(bgCsd2,0,4)
            bgCsd2:runAction(Aninode2);
            Aninode2:play("animation2", true);

            local bgCsd3 = cc.CSLoader:createNode("CastingNode.csb")
            local Aninode3 = cc.CSLoader:createTimeline("CastingNode.csb") 
            self:HideEffects(bgCsd3,3)
            self.uiLayer:addChild(bgCsd3,0,5)
            bgCsd3:runAction(Aninode3);
            Aninode3:play("animation3", true);
    end
end
function ECastingLayer:HideEffects( bg,index )
  -- body
    local sp_l = bg:getChildByName("Sprite_KS_l")
    local sp_m = bg:getChildByName("Sprite_KS_m")
    local sp_m_x = bg:getChildByName("Sprite_xh_m")
    local sp_l_x = bg:getChildByName("Sprite_xh_l")
    local sp_m_t = bg:getChildByName("Sprite_xh_m_t")
        --if index == 0 then
    if index == 0 then
        sp_l:setVisible(true)
        sp_m:setVisible(true)
        sp_m_x:setVisible(false)
        sp_l_x:setVisible(false)
        sp_m_t:setVisible(false)
    elseif index == 1 then  -- lz
        sp_l:setVisible(false)
        sp_m:setVisible(false)
        sp_m_x:setVisible(false)
        sp_l_x:setVisible(true)
        sp_m_t:setVisible(false)
    elseif index == 2 then     -- mf
        sp_l:setVisible(false)
        sp_m:setVisible(false)
        sp_m_x:setVisible(true)
        sp_l_x:setVisible(false)
        sp_m_t:setVisible(false)
    elseif index == 3 then
        sp_l:setVisible(false)
        sp_m:setVisible(false)
        sp_m_x:setVisible(false)
        sp_l_x:setVisible(false)
        sp_m_t:setVisible(true)
    end
end

--u_item_id物品的真实ID
function ECastingLayer:showComInfo(ntype,id,item_type,tab,real_id) -- 显示铸造预测物品
          print("type == "..ntype)
        local reTable = {}
        local item_id = id
        if ntype == 1 then     -- 预测铸造显示
        
          reTable[1] = nil
          reTable[2] = tab["img"]
          reTable[3] = tab["name"]
          reTable[4] = tab["des"]
          MsgManager:showBagModelItem(0,0,0,self,nil,reTable[2],reTable[4],reTable[3])
          --return
        else  -- 素材显示掉落信息
            print("进入这里 showSimpItemInfo 的调用")
            GameManagerInst:rpc( 
                {
                    rpc = "eq_info",
                    eq_id = real_id
                },
                3,
                function(data)
                    --success
                    if self.exist == false then
                        return
                    end
                    local equipInfos = {}
                    equipInfos.rsk = data["eq"][real_id].rsk

                    local function name( ... )
                        -- body
                        self:initSend()
                    end 
                    MsgManager:showSimpItemInfo1(3,id,true,self,name,equipInfos)
                end,
                function(state_code,msgText)
                    --failed
                    GameManagerInst:alert(msgText)
                end,
            true)
        end
 end

function ECastingLayer:removeEffects( ... )
    -- body
    if self.exist == false then
        return
    end
    self.uiLayer:removeChildByTag(3)
    self.uiLayer:removeChildByTag(4)
    self.uiLayer:removeChildByTag(5)
end

function ECastingLayer:create(rData)
    local login = ECastingLayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end
