require "BasicLayer"

GuildInterface = class("GuildInterface")
GuildInterface.__index      = GuildInterface 
       
-- /*公会第一次进入调用推荐的接口*/
-- 1 推荐公会  2 公会排行
-- 二级界面在下面，加入公会成功后回调就行了
-- paramers["sDelegate"] =  self
-- paramers["sFunc"] =  self.reqGuildMine
function GuildInterface:GuildRecommend(paramers)
    -- body
    local sData = {}
    sData["sDelegate"] = paramers["sDelegate"] 
    sData["sFunc"] =  paramers["sFunc"]  
    sData["GuildType"] = 1  
   	--sData["sFunc"] = SceneManager.toTestGuildMainLayer
    SceneManager:toRecommendGuildLayer(sData)
end  

--/*公会排行接口*/
-- sData["sFunc"]  这是测试 返回到需要的界面
function GuildInterface:GuildRanking( ... )
         	-- body
    local sData = {}
    sData["GuildType"] = 2  
    --sData["sFunc"] = SceneManager.toTestGuildMainLayer
    SceneManager:toRecommendGuildLayer(sData)
end  

-- /*公会成员列表*/ 
-- nType 1  从guildBaseInfo 进入的  点击查看公会成员信息    外部一般用不到  非公会成员查看使用
-- 主要是设置是 2  本公会成员查看使用
-- guildId  传入公会的ID
-- selectIndex  1 公会成员 2 申请
-- GuildType  1 从推荐列表进入     2 从成员列表进入   3 申请列表 此参数 nType == 1 时候有效
-- pos 自己的职位 
--- infoTable = {}

-- function GuildInterface:GuildMember(nType, guildId,selectIndex,GuildType ,pos)
--     	-- body
--     local sData = {}
--     sData["nType"]     = nType
--     if nType == 1 then
--     	sData["sFunc"] = SceneManager.toRecommendGuildLayer
--     	sData["GuildType"]    = GuildType
--     else
--     	sData["sFunc"] = SceneManager.toTestGuildMainLayer
--     	sData["pos"]     = pos
--     end
--     sData["guild_id"]     = guildId
--     sData["selectIndex"]  = selectIndex
--     SceneManager:toGuildMemberLayer(sData)
-- end 

-- infoTable = {}

-- infoTable["nType"]           1 是从 baseInfolayer 进入   这是查看别人信息，不需要操作 ，否则 传nil是从正式接口进入 主界面的成员列表

-- infoTable["GuildType"]       1 从推荐列表进入     2 从排行表进入    nil 是从主界面进入的
                                -- 返回 公会列表时需要的参数

-- infoTable["guildId"]         -- 公会ID

-- infoTable["selectIndex"]     1 公会成员 2 申请

-- infoTable["pos"]             －－ 自己的职位   没有 ＝＝ nil

-- infoTable["senTable"]        从服务起获取的参数   如果可选参数 目前没有用到防止以后用到

function GuildInterface:GuildMember(infoTable)
     -- body
    local sData = {}
    sData["nType"]     = infoTable["nType"]
    if sData["nType"] == 1 then
        --sData["sFunc"] = SceneManager.toRecommendGuildLayer
        sData["GuildType"]    = infoTable["GuildType"]
    else
        --sData["sFunc"]   = SceneManager.toTestGuildMainLayer
        sData["pos"]     = infoTable["pos"]
    end
    sData["guild_id"]     = infoTable["guild_id"]
    sData["selectIndex"]  = infoTable["selectIndex"]
    SceneManager:toGuildMemberLayer(sData)
end 


function GuildInterface:GuildCreate( ... )
	-- body
	local sData = {}
    SceneManager:toCreateGuildLayer(sData)
end
  