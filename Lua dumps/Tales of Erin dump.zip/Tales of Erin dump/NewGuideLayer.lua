--[[
NewGuideLayer.lua
新手引导按钮
guide_id:
curIndex:
btnEvent
]]
NewGuideLayer = class("NewGuideLayer",BasicLayer)

function NewGuideLayer:ctor(data)
    -- body
    self._data = data
    self.manager = self._data.manager 
    self.clip=nil 
    self:init()
end

function NewGuideLayer:init()
    --dump(self._data)
    

    if g_channel_control.UIVersion >= 2 then
        self._newGuideConfig = xb_new_guide[self._data.guide_id][self._data.curIndex]
    else
        self._newGuideConfig = new_guide[self._data.guide_id][self._data.curIndex]
    end

    
    self.isSelectGuide = self._newGuideConfig.isSelectGuide or 0                --是不是选择引导
    self.isShowBtnEffect = self._newGuideConfig.isShowBtnEffect or 0            --是不是显示按钮出现特效
    self.isNoBtn = self._newGuideConfig.isNoBtn or 0            --纯剧情，没有按钮
    self.isOKBtn = self._newGuideConfig.isOKBtn or 0                 
	self.uiLayer = cc.Layer:create()
    local node = cc.CSLoader:createNode("NewGuideLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self._rootCSbNode = node:getChildByTag(102) 
	local size = cc.Director:getInstance():getWinSize()
    self.size = size

    --添加ClippingNode遮罩
    if self.isNoBtn == 0 then 
        self.clip = NGClippingNode:create(self._newGuideConfig)
        self.uiLayer:addChild(self.clip,2)
    else 
        self.clip = nil 
    end 

    self.touchLayer = cc.Layer:create()
    self.uiLayer:addChild(self.touchLayer,3)

    self._rootCSbNode:setTouchEnabled(true)
    --添加监听事件
    self:event()

    self.dialog_root = ccui.Helper:seekWidgetByName(self._rootCSbNode,"dialog_root")
    --显示对话
    if self._newGuideConfig.dialog ~= "" and self._newGuideConfig.dialog ~= "" then 
        self:setClipState(false)
        self.dialog_root:setVisible(true)
        self.dialog_root:setOpacity(0)
    else 
        self:setClipState(true)
        self.dialog_root:setVisible(false)
    end 
    if SceneManager.sceneNum == 1 then
        SceneManager.menuLayer.princessController:releaseAnime()
    end 

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        --不处理返回键
    end)

end

function NewGuideLayer:setClipState(state)
    if self.clip then 
        self.clip:setStencilVisible(state)
    end 
end

function NewGuideLayer:startPlay()
    if self._newGuideConfig.dialog ~= "" and self._newGuideConfig.dialog ~= "" then 
        self:playDialog()
    else 

    end 
end
--如果对话很复杂，就自己拿出去单独写吧
--todo 单独写个按钮
function NewGuideLayer:playDialog()
     local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.curD < #self._newGuideConfig.dialog then 
                self.curD = self.curD + 1
                local curDia = UITool.getUserLanguage(self._newGuideConfig.dialog[self.curD])
                local str = string.format(curDia, user_info["name"])
                self.speakStr:setString(str)
                if self.curD == #self._newGuideConfig.dialog then 
                    if self.isNoBtn == 0 then 
                        self:dealLastDialog()
                        self.nextBtn:setVisible(false)
                    end
                    if self.isOKBtn ~= 0 then 
                        self:showOKUI()
                    end   
                end
            elseif self.curD == #self._newGuideConfig.dialog then 
                if self.isNoBtn == 1 then 
                    --todo end guide func
                    NewGuideManager:nilGuideLayer()
                    self:clear()
                    NewGuideManager:endGuideFunc()
                elseif self.isNoBtn == 2 then 
                    self:onButtonTouchEvent()
                end 
            end 
        end
    end
    --下一段
    self.nextBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Image_next")
    self.nextBtn:addTouchEventListener(onBtnEvent)
    self.nextBtn:setVisible(true)
    --下一段
    self.dialog_root:addTouchEventListener(onBtnEvent)

    local npcName = ccui.Helper:seekWidgetByName(self.dialog_root,"lab_name")
    local icon = ccui.Helper:seekWidgetByName(self.dialog_root,"Image_icon")
    self.speakStr = ccui.Helper:seekWidgetByName(self.dialog_root,"lab_desc")

    icon:setUnifySizeEnabled(true)
    icon:loadTexture("res/uifile/n_UIShare/newGuide/guide_img_nvzhu.png")
    --icon:setScale(0.6)
    --icon:setVisible(false)
    npcName:setString(UITool.ToLocalization("爱夏"))
    self.curD = 1

    local str = string.format(UITool.getUserLanguage(self._newGuideConfig.dialog[self.curD]),user_info["name"])

    self.speakStr:setString(str)
    if self.curD == #self._newGuideConfig.dialog then 
        if self.isNoBtn == 0 then 
            self:dealLastDialog()
        else
            self.nextBtn:setVisible(false)
        end
        if self.isOKBtn ~= 0 then 
            self:showOKUI()
        end  
    end
    --渐变出来
    local function endToAct()
        --
    end
   
    local fade = cc.FadeIn:create(0.5)
    local sq = cc.Sequence:create(fade,cc.CallFunc:create(endToAct))
    self.dialog_root:runAction(sq)

end

--处理剧情最后一句话
function  NewGuideLayer:dealLastDialog( ... )
    self.nextBtn:setVisible(false)
    if self.isSelectGuide == 1 then 
        self:showTeamSelectUI()
        self.isSelectGuide = 0
    else 
        self:setClipState(true)
        if self.isShowBtnEffect==1 then 
            self.manager:showBtn()
        end 
    end 
end

function NewGuideLayer:event()
    local function onTouchBegin(touch,event)
        return true
    end

    local function onTouchMoved(touch,event)

    end

    local function onTouchEnded(touch,event)
        local location = touch:getLocationInView()  -- touch in screen
        local glPoint = cc.Director:getInstance():convertToGL(location)
        if self.clip and self.clip:isStencilVisible() then
            local rect = self.clip:getStencilRect()
            if cc.rectContainsPoint(rect,glPoint) then
                self:onButtonTouchEvent()
            end
        end
    end
    local listener = cc.EventListenerTouchOneByOne:create()
    --listener:setSwallowTouches(true)
    listener:registerScriptHandler(onTouchBegin,cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local dispacher = cc.Director:getInstance():getEventDispatcher()
    --dispacher:addEventListenerWithFixedPriority(listener,-3000)
    dispacher:addEventListenerWithSceneGraphPriority(listener,self.touchLayer)
end

function NewGuideLayer:onButtonTouchEvent()
    --cc.SimpleAudioEngine:getInstance():playEffect("music/ui/touchlight.mp3", false)  
    NewGuideManager:nilGuideLayer()
    self.manager:dealMenuGuide(self._data.guide_id, self._data.curIndex)
    self:clear()
end
--
function NewGuideLayer:showOKUI()
    if self.isOKBtn ~=1 then 
        return
    end 
    local node = cc.CSLoader:createNode("NewGuideOKUI.csb")
    self.uiLayer:addChild(node,11,1000)
    local rootNode  = node:getChildByTag(100) 
    --标签切换
    local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.isNoBtn == 1 then 
                self.manager:nilGuideLayer()
                self:clear()
                self.manager:endGuideFunc()
            elseif self.isNoBtn == 2 then 
                self:onButtonTouchEvent()
            end 
        end
    end
    local btn = ccui.Helper:seekWidgetByName(rootNode,"btn_ok")
    btn:addTouchEventListener(onBtnEvent)
    self.isOKBtn = 0
end
--显示两个选择按钮
function NewGuideLayer:showTeamSelectUI()
    if self.isSelectGuide ~=1 then 
        return
    end 
    local node = cc.CSLoader:createNode("NewGuideSelectUI.csb")
    self.uiLayer:addChild(node,11,1000)
    local selectNode  = node:getChildByTag(100) 
    --标签切换
    local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
           self:dealBtnEvent(sender.myTag)
        end
    end
    -- local btnkeys = {"btn_accept","btn_refused"}
    -- for i=1,#btnkeys do
    --     local key = btnkeys[i]
    --     dump(key)
    --     local btn = ccui.Helper:seekWidgetByName(selectNode,key)
    --     btn.myTag = i --注：不用setTag 是为了防止tag值混乱
    --     btn:addTouchEventListener(onBtnEvent)
    -- end
    local btn = ccui.Helper:seekWidgetByName(selectNode,"btn_accept")
    btn.myTag = 1 --注：不用setTag 是为了防止tag值混乱
    btn:addTouchEventListener(onBtnEvent)

    local refusedBtn = ccui.Helper:seekWidgetByName(selectNode,"btn_refused")
    refusedBtn:setVisible(false)

    local acceptLab = ccui.Helper:seekWidgetByName(selectNode,"lab_accept")
    local refusedLab = ccui.Helper:seekWidgetByName(selectNode,"lab_refused")
    acceptLab:setString(UITool.ToLocalization(UITool.getUserLanguage(self._newGuideConfig.acceptBtnStr)))
    --refusedLab:setString(self._newGuideConfig.refusedBtnStr)
    refusedLab:setVisible(false)
    
    self.isSelectGuide = 0
end

--处理接受和拒绝按钮
function NewGuideLayer:dealBtnEvent(tag)
    self.uiLayer:removeChildByTag(1000) --删除选择UI
    if tag == 1 then 
        dump("accept")
        --进行下一步引导
        self:onButtonTouchEvent()
    else 
        dump("refused")
        --todo处理拒绝
        --refusedType强制引导是根据引导id进行判断的
        if self._newGuideConfig.refusedType == 1 then 
            NewGuideManager:reqSendGuideWithCallBack(self, self.playRefusedDiag)
        else 
            --通知完成弱引导
            local function dealEndReq()
                self:playRefusedDiag()
                self.isStartWeakGuide = false
            end
            NewGuideManager:reqSoftGuidePass(dealEndReq)
        end  
    end 
end
--显示拒绝 剧情
function NewGuideLayer:playRefusedDiag()
    dump("显示拒绝 剧情")
    local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.curD == #self._newGuideConfig.refusedDialog then 
                NewGuideManager:nilGuideLayer()
                self:clear()
                NewGuideManager:dealRefused()
            end 
            if self.curD < #self._newGuideConfig.dialog then 
                self.curD = self.curD + 1
                local curDia = UITool.getUserLanguage(self._newGuideConfig.refusedDialog[self.curD])
                self.speakStr:setString(curDia)
            end 
        end
    end
    --下一段
    self.nextBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Image_next")
    self.nextBtn:addTouchEventListener(onBtnEvent)
    self.nextBtn:setVisible(true)
    --下一段
    self.dialog_root:addTouchEventListener(onBtnEvent)

    local npcName = ccui.Helper:seekWidgetByName(self.dialog_root,"lab_name")
    local icon = ccui.Helper:seekWidgetByName(self.dialog_root,"Image_icon")
    self.speakStr = ccui.Helper:seekWidgetByName(self.dialog_root,"lab_desc")

    icon:setUnifySizeEnabled(true)
    
    icon:setUnifySizeEnabled(true)
    icon:loadTexture("res/uifile/n_UIShare/newGuide/guide_img_nvzhu.png")
    --icon:setScale(0.6)
    --icon:setVisible(false)
    npcName:setString(UITool.ToLocalization("爱夏"))

    self.curD = 1
    local curDia = UITool.getUserLanguage(self._newGuideConfig.refusedDialog[self.curD])

    self.speakStr:setString(curDia)
    self.dialog_root:setVisible(true) 

end

function NewGuideLayer:clear()
    if self.clip~=nil then 
        self.clip:mClear()
        self.clip=nil 
    end 
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self.uiLayer:removeFromParent()
    self.uiLayer = nil
    -- body
end
function NewGuideLayer:create(data)
	local layer = NewGuideLayer.new(data)
    return layer
end

