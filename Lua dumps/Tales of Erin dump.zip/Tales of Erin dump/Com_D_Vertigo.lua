--眩晕类（包括眩晕和麻痹）的组件
--created by kobejaw.2018.6.30.
Com_D_Vertigo = class("Com_D_Vertigo",ComponentBase)

function Com_D_Vertigo:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 2
	self.buffType = Com_DebuffEnum.Vertigo
end

--开始生效。
function Com_D_Vertigo:takeEffect(isAdd)
	if self.target.fsm.currentState.stateEnum ~= StateEnum.UnusualCondition then
		if isAdd then
			self.target.fsm:changeState(StateEnum.Idling)
		else
			--注：目前的规则是boss不会被眩晕
			if self.target.isBoss then
				self.target.fsm:changeState(StateEnum.Attacking_Boss)
			else
				if self.target.fsm.currentState.stateEnum == StateEnum.Idling then
					local data = {}
					data.type = 1
					data.isJustAweak = true
					self.target.fsm:changeState(StateEnum.RunningToEnemy,data)
				end  
			end
		end
	end
	self.super.takeEffect(self,isAdd)
end