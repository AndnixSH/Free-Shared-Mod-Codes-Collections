--[[
    台湾 打点
]]


AppsFlyerManager = {} 

AppsFlyerManager.APPS_FLYER_ANDROID_CLASS = "org/cocos2dx/lua/AppsFlyer"
AppsFlyerManager.CUSTOMER_SERVICE_IOS_CLASS = "LuLuSDKManager"

-- 登陆打点
function AppsFlyerManager:login()
    --MsgManager:showSimpMsg("AppsFlyerManager:login")
    local platform = cc.Application:getInstance():getTargetPlatform()
    local args = {  }

    if platform == cc.PLATFORM_OS_ANDROID then
        local sigs = "()V"
        zc.luaBridgeCall(AppsFlyerManager.APPS_FLYER_ANDROID_CLASS,"login",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        zc.luaBridgeCall(AppsFlyerManager.CUSTOMER_SERVICE_IOS_CLASS,"EventLogin",args,"")
    end
    
end


-- 引导完成
--success == 1 表示true， 0 表示false
function AppsFlyerManager:tutorialComplete(guideIndex)
    --MsgManager:showSimpMsg("AppsFlyerManager:tutorialComplete==>引导节点==>"..guideIndex)
    guideIndex = guideIndex or 1;
    local args = {
        success             = "1",
        guideIndex            = tostring(guideIndex)
             
    }
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(AppsFlyerManager.APPS_FLYER_ANDROID_CLASS,"tutorialComplete",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        zc.luaBridgeCall(AppsFlyerManager.CUSTOMER_SERVICE_IOS_CLASS,"EventtutorialComplete",args,"")
    end
    
end


-- 等级取得
--玩家角色到达30/40/50 级别时进行调用该接口
function AppsFlyerManager:levelAchieved(level, vipLevel)
    --MsgManager:showSimpMsg("AppsFlyerManager:levelAchieved==>level:"..level)
    print("level==>"..level)
    level = level or 1;
    vipLevel = vipLevel or 0;
    local args = {
        level             = tostring(level),
        vipLevel            = tostring(vipLevel)
             
    }
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(AppsFlyerManager.APPS_FLYER_ANDROID_CLASS,"levelAchieved",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        zc.luaBridgeCall(AppsFlyerManager.CUSTOMER_SERVICE_IOS_CLASS,"EventlevelAchieved",args,"")
    end
    
end

-- 应用内购买
-- data = {
--     revenue             = tostring(revenue),    --总收入
--     itemName            = tostring(itemName),    --商品名字
--     itemId              = tostring(itemId),      --商品id 在平台商店中
--     price               = tostring(price),       --商品价格
--     quantity            = tostring(quantity),    --商品数量

--     orderId             = tostring(orderId),     --订单
-- }
function AppsFlyerManager:purchase(data)
    --MsgManager:showSimpMsg("AppsFlyerManager:purchase"..json.encode(data))
    print("purchase_data"..tostring(data))
    if not data then
        print("AppsFlyerManager:purchase, data should be not nil")
        return
    end 

    local revenue = data.revenue or 0;
    local itemName = data.itemName or "itemName";
    --注意：google 后台的item id e.g  cljjtw_1
    local itemId = data.itemId or 0;
    local price = data.price or 0;
    local quantity = data.quantity or 1;
    --币种固定为usa
    local currency = "USD";
    local orderId = data.orderId or 1;
    
    local args = {
        revenue             = tostring(revenue),
        itemName            = tostring(itemName),
        itemId              = tostring(itemId),
        price               = tostring(price),
        quantity            = tostring(quantity),
        currency            = tostring(currency),
        orderId             = tostring(orderId)    
    }
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(AppsFlyerManager.APPS_FLYER_ANDROID_CLASS,"purchase",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        
        zc.luaBridgeCall(AppsFlyerManager.CUSTOMER_SERVICE_IOS_CLASS,"Eventpurchase",args,"")

    end
    
end

-- 解锁成就
function AppsFlyerManager:achievementUnlock(achieveName)
    --MsgManager:showSimpMsg("AppsFlyerManager:achievementUnlock==>"..achieveName)
    print("achieveName==>"..achieveName)
    achieveName = achieveName or "achieveName";
    local args = {
        achieveName             = tostring(achieveName)
    }
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(AppsFlyerManager.APPS_FLYER_ANDROID_CLASS,"achievementUnlock",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
                
        zc.luaBridgeCall(AppsFlyerManager.CUSTOMER_SERVICE_IOS_CLASS,"EventachievementUnlock",args,"")
    end
    
end



    
    

