SceneManager = class("SceneManager")
SceneManager.__index          = SceneManager 
SceneManager.mainScene        = nil    --主场景
SceneManager.loginScene       = nil    --登录场景
SceneManager.login            = nil    --登录界面对象
SceneManager.rootLayer        = nil    --场景上根节点
SceneManager.rootNode         = nil    --跳转界面展示信息的节点
SceneManager.menuLayer        = nil    -- startLayer对象
SceneManager.waitLayer        = nil    --等待返回结果
SceneManager.bPush            = false  --主界面是否弹出 
SceneManager.sceneNum         = 1
SceneManager.rootStop         = nil
SceneManager.IsTeam           = false
SceneManager.RfuncCall        = nil  -- 开始调用         -- 1 返回主界面
SceneManager.particleRoot     = nil -- 点击特效层级
SceneManager.streak           = nil -- 拖尾图片
SceneManager.msgMgr           = nil -- 提示框管理器  
SceneManager.newGuidMgr       = nil -- 新手引导管理器 
SceneManager.rootLocation        = 1  -- 当前在 一级还是二级界面（不设计三级和弹窗）
SceneManager.isAct            = false  -- 有的界面在返回的时候 不需要左边邮件之类的有动作  加一个数据进行判断
SceneManager.isTabBar         = false  -- 有的界面返回的时候  不需要下边的tabBar 有动作  加一个数据进行判断
SceneManager.isShowNotice = false --是否显示公告
SceneManager.isShowChating = false --是否展示聊天室
--据点 队伍 灵装 工坊 大型战斗 公会 商店 召唤 星界 出征 活动 试炼之地 黑潮遗迹 信息 排行榜 任务 签到 公告 邮件 
SceneManager.titleTable = {[1]=UITool.ToLocalization("活动"),[2]=UITool.ToLocalization("队伍"),[3]=UITool.ToLocalization("灵装"),[4]=UITool.ToLocalization("工坊"),[5]=UITool.ToLocalization("黑潮遗迹"),[6]=UITool.ToLocalization("召唤"),[7]=UITool.ToLocalization("公会"),[8]=UITool.ToLocalization("出征") 
,[9]=UITool.ToLocalization("商店"),[11]=UITool.ToLocalization("大型活动"),[12]=UITool.ToLocalization("大型战斗"),[13]=UITool.ToLocalization("星界"),[14]=UITool.ToLocalization("试炼之地"),[15]=UITool.ToLocalization("信息"),[16]=UITool.ToLocalization("排行榜"),[17]=UITool.ToLocalization("主页"),[18]=UITool.ToLocalization("剧情活动")
,[19]=UITool.ToLocalization("邮件"),[20]=UITool.ToLocalization("签到"),[21]=UITool.ToLocalization("任务"),[22] = UITool.ToLocalization("公会战"),[23] = UITool.ToLocalization("轮回重铸"),[24] = UITool.ToLocalization("图鉴")}
SceneManager.navNodeTable = {}
--切换主界面
function SceneManager:runMainScene()
   NetErrorManager:getInstance():setServerError(false);
  --加入 Act_2搜索路径
  self:addExtraSearchPath()

   self.mainScene = cc.Scene:create()
   self.rootLayer = cc.Layer:create()
   local rootPos = ScreenManager:getInstance():getRootPoint();
   self.rootLayer:setPosition(rootPos.x,rootPos.y);
  self.rootLayer:setName("root_layer");
   --添加屏幕适配层
   local screenfitLayer = ScreenFitMainLayer:create();
   self.rootLayer:addChild(screenfitLayer, 100000);
   

   self.waitLayer = nil
   self.touchMaskLayer = nil
   self.aniMaskLayer = nil

   self.login = nil --清理login

    local noticePanel = NoticeManager:createPanel()
    self.mainScene:addChild(noticePanel,20,888)

   --todo 需要重构
   AudioManager:shareDataManager():stopBGMusic()
   --引导系统 初始 引导
   GuideSys:getInstance():initGuide();
   NewGuideManager:setManager(self)
   -- 播放粒子特效的层------------------------
   self.particleRoot = cc.Layer:create()
   self.particleRoot:setContentSize(cc.size(80, 80))
   self.mainScene:addChild(self.particleRoot,21,999)
   self:ParticlePlay()
   ----------------------------------------
   self.mainScene:addChild(self.rootLayer,0,1)
   cc.Director:getInstance():replaceScene(self.mainScene)
   GameManagerInst:BackupMode()
   self:createStartLayer()
    ------sdk设置数据 
    local roleData = {}
    roleData.id = user_info["id"]
    roleData.name = user_info["name"]
    roleData.rank = user_info["rank"]
    cc.UserDefault:getInstance():setStringForKey("RoleID",user_info["id"])
    cc.UserDefault:getInstance():setStringForKey("RoleRank",user_info["rank"])
    if CHANNEL.Android.CHANNEL_CODE_CN == GAME_CHANNEL then
        SDKManagerLua:serverSelected()
    end
    SDKManagerLua:setRoleData(roleData)
    buglySetUserId(user_info["id"])
    
    --初始化云信SDK
    XBChatSys:getInstance():initNimSDK()

    --按键精灵检测
    if g_channel_control.quickMacroabled == true then 
        local qm_layer = QuickMacroTools:getInstance():getQMLayer()
        self.mainScene:addChild(qm_layer,999)
        QuickMacroTools:getInstance():prepare()
    end 
end

    --加入 Act_2搜索路径
function SceneManager:addExtraSearchPath(  )
    local write =  cc.FileUtils:getInstance():getWritablePath();
    local updatePath = write.."update/" 
    
    local searchPaths = cc.FileUtils:getInstance():getSearchPaths()

    --加入 Act_2搜索路径
    local act_2_path =  updatePath.."src/Act_2/"

    if self:isExistSearchPath(act_2_path) == false then

        table.insert(searchPaths, 10, act_2_path) 

    end
    

    cc.FileUtils:getInstance():setSearchPaths(searchPaths)

    for i=1,#searchPaths do
        local path = searchPaths[i]
        print("searchPath = "..tostring(i)..tostring(path))
    end

end

--查询某个搜索路径是否存在
function SceneManager:isExistSearchPath( searchPath )
    local searchPathArr = cc.FileUtils:getInstance():getSearchPaths()

    for i=1,#searchPathArr do
        local path = searchPathArr[i]
        if searchPath == path then
          return true
        end
    end
  
    return false

end


function SceneManager:ParticlePlay( ... )
    -- body
    self.streak = cc.MotionStreak:create(0.5, 3, 50, cc.c3b(255, 255, 255), "res/uifile/n_UIShare/touch_effect/shubiao003.png")
    self.particleRoot:addChild(self.streak)
    self:particleRootEv()
end
function SceneManager:particleRootEv( ... )
    -- body
    local  isTrue = false
    local function onTouchBegan(touch, event)
        if isTrue then
            if self.particleRoot then 
                self.particleRoot:removeAllChildren() 
            else
                print("-CrashTest-Info===SceneManager:onTouchBegan===self.particleRoot is nil!!!")
            end
            self.streak = cc.MotionStreak:create(0.5, 3, 50, cc.c3b(255, 255, 255), "res/uifile/n_UIShare/touch_effect/shubiao003.png")
            self.particleRoot:addChild(self.streak)
            isTrue = false
        end
        local scroll_prepoint = touch:getPreviousLocation()
        local scroll_movepoint = touch:getLocation()
        self.streak:setPosition(scroll_movepoint)
        local emitter1 = cc.ParticleSystemQuad:create("res/uifile/n_UIShare/touch_effect/tuowei01.plist")
        emitter1:setPosition(scroll_movepoint)
        self.particleRoot:addChild(emitter1)
        self.streak:reset();
        return true
    end

    local function onTouchMoved(touch,event)
       
       --- 特效-------------
       local scroll_prepoint = touch:getPreviousLocation()
       local scroll_movepoint = touch:getLocation()
       local emitter1 = cc.ParticleSystemQuad:create("res/uifile/n_UIShare/touch_effect/tuowei01.plist")
       if emitter1 then
          emitter1:setPosition(scroll_movepoint)
          self.particleRoot:addChild(emitter1)
       end
       self.streak:setPosition(scroll_movepoint); 
               
        --s 删除所有活动条带段     
       print("进入了移动函数")
       self.streak:reset();

    end

    local function onTouchEnded(touch, event)
        local scroll_prepoint = touch:getPreviousLocation()
        local scroll_endpoint = touch:getLocation()
        self.streak:reset();
        isTrue = true
        local function callback( ... )
            -- body
            isTrue = false
            if self.particleRoot then 
                self.particleRoot:removeAllChildren() 
            else
                print("-CrashTest-Info===SceneManager:onTouchEnded===self.particleRoot is nil!!!")
            end
            self.streak = cc.MotionStreak:create(0.5, 3, 50, cc.c3b(255, 255, 255), "res/uifile/n_UIShare/touch_effect/shubiao003.png")
            self.particleRoot:addChild(self.streak)
        end
        local delay = cc.DelayTime:create(0.8)
        local sequence = cc.Sequence:create(delay, cc.CallFunc:create(callback))

    end
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.particleRoot:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.particleRoot)
end

-- 弹出支付购买页面
function SceneManager:showPurchase( tab )
    if  KeyboardManager._isShowNotice  then 
        return 
    end 
    local purchase = PurchaseUI:create(tab,self) 
    if self.rootLayer then
       if purchase.uiLayer then
          self.rootLayer:addChild(purchase.uiLayer)
       end
    else
      if purchase.uiLayer and self.mainScene then
         self.mainScene:addChild(purchase.uiLayer)
      end
    end
end
--/*抽卡弹窗的创建和隐藏*/
function SceneManager:showGachaBox( tab )

    local GachaViewBox = GachaViewBox:create(tab,self) 
    if self.rootLayer then
       if GachaViewBox.uiLayer then
          self.rootLayer:addChild(GachaViewBox.uiLayer,9991,777)
       end
    else
      if GachaViewBox.uiLayer and self.mainScene then
         self.mainScene:addChild(GachaViewBox.uiLayer,9991,777)
      end
    end
end
function SceneManager:hideGachaBox( ... )

  if self.rootLayer then
    if self.rootLayer:getChildByTag(777) then
      self.rootLayer:removeChildByTag(777, true)
    end
  else
    if self.mainScene then
      if self.mainScene:getChildByTag(777) then
        self.mainScene:removeChildByTag(777, true)
      end
    end
  end
end
--/*模板弹窗的创建和隐藏*/
function SceneManager:showMsgMode( tab )
    -- if self.rootLaye:getChildByTag(777) then
    --     self.rootLayer:removeChildByTag(777)
    -- end
    --如果现实公告，就不显示弹窗
    if  KeyboardManager._isShowNotice  then 
        return 
    end 
    local MsgModelLayer = MsgModelLayer:create(tab,self) 
    if self.rootLayer then
       if MsgModelLayer.uiLayer then
          self.rootLayer:addChild(MsgModelLayer.uiLayer,9991,777)
       end
    else
      if MsgModelLayer.uiLayer and self.mainScene then
         self.mainScene:addChild(MsgModelLayer.uiLayer,9991,777)
      end
    end
end

function SceneManager:showShopBuyMsgLayer( rcvData )
  -- body
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local shopBuyMsgLayer = XbShopBuyMsgLayer:create(sData) 
    if self.rootLayer then
       if shopBuyMsgLayer.uiLayer then
          self.rootLayer:addChild(shopBuyMsgLayer.uiLayer,9991,777)
       end
    else
        if shopBuyMsgLayer.uiLayer then
          self.mainScene:addChild(shopBuyMsgLayer.uiLayer,9991,777)
       end
    end

end
function SceneManager:hideMsgMode( ... )
   print("进入了管理类的返回函数体")
  -- body
  if self.rootLayer then
    if self.rootLayer:getChildByTag(777) then
      self.rootLayer:removeChildByTag(777, true)
    end
  else
    if self.mainScene then
      if self.mainScene:getChildByTag(777) then
        self.mainScene:removeChildByTag(777, true)
      end
    end
  end
end
--创建并非最高层的弹窗（用于可被二级界面遮挡的弹窗）
function SceneManager:showMsgModeCanOver( tab )
    --如果现实公告，就不显示弹窗
    if  KeyboardManager._isShowNotice  then 
        return 
    end 
  local MsgModelLayer = MsgModelLayer:create(tab,self) 
  if self.rootLayer then
     if MsgModelLayer.uiLayer then
        self.rootLayer:addChild(MsgModelLayer.uiLayer)
     end
  else
    if MsgModelLayer.uiLayer then
       self.mainScene:addChild(MsgModelLayer.uiLayer)
    end
  end
  
end

function SceneManager:showBagAddView(tab)
  local view = BagAddView.new():init(tab["equipMax"],tab["callFunc"],tab["oneself"])
  if self.rootLayer then
    self.rootLayer:addChild(view:getRootNode(),1,1111)
  end

end
--显示公告
function SceneManager:popBillboard( strW )
    -- body
  self.MsgBillboard = BillboardLayer:create(strW,self) 
  self.rootLayer:addChild(self.MsgBillboard.uiLayer,9992,778)
  
end
-- 隐藏公告
function SceneManager:hideBillboard( ... )
    -- body
    if self.rootLayer:getChildByTag(778) then
      self.rootLayer:removeChildByTag(778, true)
    end
    print("隐藏公告板")
end
--弹出一句话提醒
function SceneManager:showPromptLabel(str,color)
    --local label = cc.Label:createWithTTF(str, TEXT_FONT_NAME, 40)
    --local label = ccui.Text:create(str,TEXT_FONT_NAME,40)
    MsgManager:showSimpMsg(str)
    -- local label = ccui.Text:create()
    -- label:setString(str)
    -- label:setFontSize(40)
    -- label:setPosition(cc.p(640,360))
    -- if color ~= nil then
    --   label:setColor(color)
    -- end
   
    -- local function removeThis()
    --     label:removeFromParent()
    -- end
    -- --After 1.5 second, self will be removed.
    -- local moveBy  = cc.MoveBy:create(1.5,cc.p(0,150))
    -- local fadeOut = cc.FadeOut:create(2.0)
    -- local spawn = cc.Spawn:create(moveBy,fadeOut)
    -- label:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(removeThis)))
    -- self.rootLayer:addChild(label, 9999,888)
end

function SceneManager:initLanguageData()
    TLManaget = TransformLanguageMgr:getInstance()
    if cc.UserDefault:getInstance():getIntegerForKey("language_type") > 0 then
        local lauguage_index = cc.UserDefault:getInstance():getIntegerForKey("language_type")
        TLManaget:setCurUsedIndex(lauguage_index)
    else
        TLManaget:setCurUsedIndex(4)--每个项目的默认语言不同，随着项目修改
    end
end

function SceneManager:creatLoginScene()

    self:reset();

    self:initLanguageData()

    self.loginScene = cc.Scene:create()

    self.rootLayer = cc.Layer:create()
    local rootPos = ScreenManager:getInstance():getRootPoint();
    self.rootLayer:setPosition(rootPos.x,rootPos.y);
    self.rootLayer:setName("root_layer");
    self.loginScene:addChild(self.rootLayer)

    --添加屏幕适配层
    local screenfitLayer = ScreenFitMainLayer:create();
    self.rootLayer:addChild(screenfitLayer, 100000);

    self:createLoginLayer()

    cc.Director:getInstance():getTextureCache():removeUnusedTextures()

    cc.Director:getInstance():replaceScene(self.loginScene)
    --todo 处理安卓返回键
    KeyboardManager:bindingAndroidKeyboard(self.loginScene,1)
end

--移除所有通知，切换回登陆时操作
function SceneManager:clearAllEventListener(  )
  XBChatSys:getInstance():clearData();
  -- lemon.EventManager:clearData();
end

--登陆界面
function SceneManager:runLoginScene()
  self:reset();
  self:clearAllEventListener()

  if SDKManagerLua.sdkHandleRepairClient then
    SDKManagerLua:sdkHandleRepairClient()
  end
  
  cc.Director:getInstance():getTextureCache():removeUnusedTextures()
  require_ex("UpdateManager")
  UpdateManager = UpdateManager.new()
  UpdateManager:checkUpdate()

end

--重置 数据 和 ui
function SceneManager:reset()
  -- body
  self:resetData()
  AudioManager:shareDataManager():stopAll()

    self:removeAllFromNavNodes()
    self:removeAniMaskLayer()
   if  self.menuLayer ~= nil then
       self.menuLayer:clear()
   end 
    if  self.rootLayer ~= nil then
        self.rootLayer:removeAllChildren()
        self.rootLayer:removeFromParent()
        self.rootLayer = nil
    else
        print("-CrashTest-Info===SceneManager:runLoginScene===self.rootLayer is nil!!!")
    end

    if self._keyBoardListener then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._keyBoardListener)
        self._keyBoardListener = nil 
    end 
    
    self.mainScene = nil
    self.waitLayer = nil
    self.touchMaskLayer = nil
    self.aniMaskLayer = nil
    
    self._shopLayer = nil
end

function SceneManager:resetData()
    
    SceneManager:clearAllData()
    SceneManager:stopHeartBeat()
    NewGuideManager:resetState()
    
    GameManagerInst:clear()
    NoticeManager:clear()
    UserDataMgr:reset();
    
   KeyboardManager:clearAndReset()
   --NetErrorManager:getInstance():openCheckNet();
end

--创建登陆界面
function SceneManager:createLoginLayer()
     
     local sData = {}
     sData["sManager"] = self
     local login =LoginLayer:create(sData)
     self.login = login 
     self.rootLayer:addChild(login.uiLayer)

end
--起名字页面
function SceneManager:toNewNameLayer()
     local sData = {}
     sData["sManager"] = self
     local layer = NewNameLayer:create(sData)
     self.rootLayer:addChild(layer.uiLayer)
end

function SceneManager:ShowTitle( ... )
    -- body
    self.menuLayer:ShowTitle()
end
function SceneManager:HideTitle( ... )
    -- body
    self.menuLayer:HideTitle()
end

--创建主界面
function SceneManager:createStartLayer()
    self.isStartLayerInit = true --用于判断是不是创建了 StartLayer
    local sData = {}
    sData["sManager"] =  self
    local startLayer = nil;
    if g_channel_control.UIVersion == 2 then
      startLayer = XbStartLayer:create(sData)
    else
      startLayer = StartLayer:create(sData)
    end
    
    self.rootLayer:addChild(startLayer.uiLayer,-1,9898)
    self.menuLayer:changeBGScene(1)
    self.tempBackFunc = self.toStartLayer   --初始返回接口
    self.menuLayer.uiLayer:setVisible(false)
    --新手引导
    user_info["guide_id"] =  user_info["guide_id"] or 1
    if user_info["guide_id"] < 1 then 
        user_info["guide_id"] = 1
    end 
    --todo 处理安卓返回键
    KeyboardManager:bindingAndroidKeyboard(self.mainScene,2)
    local isStart = NewGuideManager:startGuide()
    if isStart then
    else 
        print("新手引导已过")
        self.tempBackFunc = self.toStartLayer   --初始返回接口
        self:toStartLayer()
--        cc.SimpleAudioEngine:getInstance():playEffect(lua_musci["huanying"], false)
        local rnd_huanying = math.random(1, 2)
        local fullpath = lua_musci["huanying"..rnd_huanying]
        AudioManager:shareDataManager():playMusic(fullpath,1, false) 
        --首次进入 显示游戏公告
        if g_channel_control.showGameNoticeLayer == true and cc.UserDefault:getInstance():getIntegerForKey("DEVICE_CHECK_STATE") == 1 then
            local sData = {}
            self:toGameNoticeLayer(sData)
        end 
    end
end

--返回到主界面
function SceneManager:toStartLayer() -- 根据 UIRturnMode 返回参数 设置背景图
    SDKManagerLua:refreshUserCoin(nil)
    if g_channel_control.UIVersion == 2 then
      self.menuLayer:showTopBar(true,true)
      if self.menuLayer.showView then
        dump(self.menuLayer.showView,"SceneManager:toStartLayer   showView")
         self.menuLayer:showView()
      end 

    else
      self.menuLayer:showTopBar(true)
    end
    self.menuLayer.uiLayer:setVisible(true)
    self.isStartLayerInit = false
    self:removeAllFromNavNodes()
    ---清空
    KeyboardManager:clearAndReset()

    self.menuLayer:setTitle(self.titleTable[17])
    local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
    --todo 停止或者恢复当前音乐
    if musicState == 0 then --开启音乐
        
        if AudioManager:shareDataManager():getBGId() ~= -1 then 
            AudioManager:shareDataManager():resumeBGMusic()
        else 
            local fullpath =lua_musci["zhuyeBGM"]
            AudioManager:shareDataManager():preloadM(fullpath)
            AudioManager:shareDataManager():playBGMusic(fullpath, true)
        end
    end 
     --第一次进入进行设备检测，以后韩版的就可以直接备注
    if cc.UserDefault:getInstance():getIntegerForKey("DEVICE_CHECK_STATE") == 0 then
        cc.UserDefault:getInstance():setIntegerForKey("DEVICE_CHECK_STATE",1)
        self:checkBlackDevices()
    end

    ActBanerManager:updateBaner() --每次到首页刷新一次
    self:toFirClass()
    
    NoticeManager:startNotice()
    
    if g_channel_control.quickMacroabled == true then 
        QuickMacroTools:getInstance():backhome()
    end  
    
    XbTriggerGuideManager:startTriggerGuide()
end

--menu按钮切换到主界面
function SceneManager:pushStartLayer()
    

end
--弹出主界面
function SceneManager:popStartLayer()
    self.bPush = false
    self.menuLayer:hiddenAll()
end


function SceneManager:toDialogLayer(rcvData)
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  DialogLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 
-- 播放成就特效
function ShowAchiEfc( tab )
    -- body
    if( SceneManager.rootLayer:getChildByTag(111))then
        SceneManager.rootLayer:removeChildByTag(111, true)
    end
    SceneManager.rootLayer:addChild(AchiEfecLayer:create(tab),999,111)
end
-- 隐藏成就特效
function HideAchiEfc( ... )
    -- body
    G_Efc_num = 0
    if( SceneManager.rootLayer:getChildByTag(111))then
      SceneManager.rootLayer:removeChildByTag(111, true)
    end
end


--世界地图
function SceneManager:toWMapLayer(rcvData)
   
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  WMapLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 

--二级地图
function SceneManager:toSMapLayer(rcvData)
    NoticeManager:startNotice()
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =  self
     rcvData["sFunc"] =  self.toStartLayer
     sData["rcvData"]  =  rcvData 
     local layer = SMapLayer:create(sData)
     layer.titleNum = 8
     self.rootNode:addChild(layer.uiLayer)
     self:addToNavNodes(layer)
end 

--查看掉落 
function SceneManager:toMapItemDropsLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  MapItemDrops:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 

--魔王情报
function SceneManager:toBossInformationLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  BossInformationLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 

--战斗选关 
function SceneManager:toBattlePassListLayer(rcvData)
    rcvData = rcvData or {}
    --rcvData["sDelegate"] =  self
    --todo 返回函数为刷新
    --rcvData["sFunc"] = rcvData["sFunc"] or self.toStartLayer
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData
    local layer = BattlePassListLayer:create(sData)
    layer.titleNum = 8
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
end

--编队界面
function SceneManager:toFormationLayer(rcvData) 

end
--团战排行
function SceneManager:toAnBRBL( rcvData )
     self.menuLayer:setTitle(self.titleTable[22])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =   rcvData["sDelegate"] or self
     rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = AllianceBattle_RankBaseayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self.menuLayer:hiddenUserInfo(false)
end
-- 团战贡献度
function SceneManager:toContribute( rcvData )
  -- body
      self.menuLayer:setTitle(self.titleTable[22])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =   rcvData["sDelegate"] or self
     rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = AllianceBattle_ContributeLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self.menuLayer:hiddenUserInfo(false)
end
-- 显示团站成就
function SceneManager:showAllianceAchi( curNode,act_id,_type ,refreshSFunc)
  -- body
    local  sData = {}
    sData["act_id"]   = act_id
    if _type then -- 1 团战成就  2 极限挑战成就
      sData["_type"]  = _type
    else
      sData["_type"] = 1
    end

    if refreshSFunc then
      sData["refreshSFunc"]  = refreshSFunc
    else
      sData["refreshSFunc"] = nil
    end
       
    sData["alliance"] = "true"

    local rData = {}
    rData["sManager"] =  self
    rData["rcvData"] = sData

    self.allianceNode = curNode
    self.publicRank = ActAchievementLayer:create(rData)
    self.allianceNode:addChild(self.publicRank.uiLayer,9991,777)
end

-- 团战报名
function SceneManager:toAllianceApply(rcvData )
     self.menuLayer:setTitle(self.titleTable[22])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =   rcvData["sDelegate"] or self
     rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = AllianceBattle_ApplyLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self.menuLayer:hiddenUserInfo(true)
end
-- 隐藏
function SceneManager:hideAllianceAchi( ... )
  -- body
  if self.allianceNode then
    self.allianceNode:removeChildByTag(777)
    self.allianceNode = nil
  end
end
-- 显示团站商店（团战界面用）
function SceneManager:showAllianceShop(curNode ,_type,buyCallback)
  -- body
  -- _type  1  团战商店 2 极限挑战商店
    self.allianceNode = curNode
    local sData = {}
    sData["sManager"] =  self
    if _type then
      sData["_type"] = _type
    else
      sData["_type"] = 1
    end
    if buyCallback then
      sData["buyCallback"] = buyCallback
    else
      sData["buyCallback"] = nil
    end
    self.publicRank = AllianceBattle_ShopLayer:create(sData)
    self.allianceNode:addChild(self.publicRank.uiLayer,9991,777)
end

-- 隐藏团站商店(通用)
function SceneManager:hideAllianceShop( ... )
  -- body
  if self.allianceNode then
    self.allianceNode:removeChildByTag(777)
    self.allianceNode = nil
  end
end
-- 抽卡
function SceneManager:toCardShop(rcvData) 
  -- body
    rcvData["sDelegate"] =  rcvData["sDelegate"] or self
    rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer

    self.menuLayer:setTitle(self.titleTable[1])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     sData["_type"]    = rcvData["_type"]


     sData["rcvData"]  =  rcvData 
    local layer = Card_ShopLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    --self.menuLayer:hiddenUserInfo(true)

end
-- 团站商店(通用)
function SceneManager:toAllianceShop(rcvData) 
  -- body
      self.menuLayer:setTitle(self.titleTable[1])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     sData["_type"]    = rcvData["_type"]
     rcvData["sDelegate"] =  rcvData["sDelegate"] or self
     rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = AllianceBattle_ShopLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    --self.menuLayer:hiddenUserInfo(true)

end


-- 显示团战抽卡（团战界面用）
function SceneManager:showAllianceGacha(curNode,war_id)
  -- body
    self.allianceNode = curNode
    local sData = {}
    sData["sManager"] =  self
    sData["war_id"] = war_id

    local view = AllianceBattleGachaView:create(sData)
    self.publicRank = view

    self.allianceNode:addChild(view:getRootNode(),9991,777)
end
-- 隐藏团战抽卡(通用)
function SceneManager:hideAllianceGacha( ... )
  -- body
  if self.allianceNode then
    self.allianceNode:removeChildByTag(777)
    self.allianceNode = nil
  end
end

--公会战界面
function SceneManager:toAllienceBattleLayer( )
    --未加入公会无法进入
    if SceneManager.menuLayer.hasJoinedGuild == 0 then
      --提示未加入公会无法参战
      local function  doNothing()
      end
      MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("无法进入，请先加入公会。"),self,doNothing);      
      return
    end

    NoticeManager:stopNotice()
    self.menuLayer:setTitle(self.titleTable[9])
    local isback = false;

    local view
    if g_channel_control.b_allianceBattle_version3 then
      view = AllianceBattleMainView_V3.new():init()
    else
      view = AllianceBattleMainView.new():init()
    end

    view.clear = function(s)
        if s:getRootNode() then
            s:getRootNode():removeFromParent()
        end
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.setShow= function(s)
        self.menuLayer:showTopBar(true)
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 22
    self:addToNavNodes(view)
    view.uiLayer = view:getRootNode();
    self.rootNode:addChild(view.uiLayer)
    self.menuLayer:hiddenUserInfo(false)
    self:toSecClass()
end
function SceneManager:toPublicHelpText(rcvData)
    print("toPublicHelpText")
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  PublicHelpText:create(sData)
    if layer.uiLayer then
       self.rootLayer:addChild(layer.uiLayer,1,98)
    end
end
-----------------极限挑战

-- 极限挑战主界面
function SceneManager:toUltimateCha_MainLayer(rcvData )
     --self.menuLayer:setTitle(self.titleTable[22])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =   rcvData["sDelegate"] or self
     rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
     sData["rcvData"]  = rcvData 
    local layer = UltimateCha_MainLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self.menuLayer:hiddenUserInfo(false)
end
-- 极限挑战排行榜界面
function SceneManager:toUltimateCha_rankLayer( rcvData )
     self.menuLayer:setTitle(self.titleTable[16])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =   rcvData["sDelegate"] or self
     rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = UltimateCha_rankLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self.menuLayer:hiddenUserInfo(true)
end
--/*极限挑战结算弹窗*/
function SceneManager:showUltimateChaBox( tab )

  local Msg = UltimateCha_BoxLayer:create(tab,self) 
  self.rootLayer:addChild(Msg.uiLayer,9991,77777)
end
function SceneManager:hideUltimateChaBox( ... )
   print("进入了管理类的返回函数体")
  -- body
  if self.rootLayer:getChildByTag(77777) then
    self.rootLayer:removeChildByTag(77777, true)
  end
end
-- -- -- 邮件
-- function SceneManager:toMailLayer(rcvData)
--      self.menuLayer:setTitle(self.titleTable[1])
--      self:toSecClass()
--      local sData = {}
--      sData["sManager"] =  self
--      rcvData["sDelegate"] =  self
--      rcvData["sFunc"] =  self.toStartLayer
--      sData["rcvData"]  =  rcvData 
--     local layer = n_MailLayer:create(sData)
--     self:addToNavNodes(layer)
--     self.rootNode:addChild(layer.uiLayer)
--      --self.rootLayer:addChild(MailLayer:create(sData).uiLayer,0,9)
--     self.menuLayer:hiddenUserInfo(true)
-- end
function SceneManager:toMailLayer(rcvData)

    if g_channel_control.mailVersion == 2 then
          NoticeManager:stopNotice()
          self.menuLayer:setTitle(self.titleTable[19])
          -- self.menuLayer:hiddenUserInfo(false)
          self.menuLayer:showTopBar(false)
          self:toSecClass()
          local sData = {}
          rcvData["sDelegate"] =   rcvData["sDelegate"] or self
          rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
          sData["rcvData"]  =  rcvData 
          local layer = XbMailLayer:create(sData)

          layer:setClearCallback(function()
              self:removeFromNavNodes()
              self:toStartLayer()
          end)

          layer:setShowCallback(function()
              --self.menuLayer:showTopBar(true)
              self.menuLayer:showTopBar(false)
              
          end)

          layer.titleNum = 19
          self:addToNavNodes(layer)
          self.rootNode:addChild(layer:getRootNode())
          

    else

        self.menuLayer:setTitle(self.titleTable[19])
        self:toThirClass()
        local sData = {}
        sData["sManager"] = self 
        sData["rcvData"] = rcvData
        local layer = NewMailLayer:create(sData)
        self.rootLayer:addChild(layer.uiLayer)

    end
end

--好友页面
function SceneManager:toFriendLayer(rcvData)

    NoticeManager:stopNotice()
    self.menuLayer:setTitle(self.titleTable[19])
    self.menuLayer:hiddenUserInfo(false)
    self:toSecClass()
    local sData = {}
    rcvData["sDelegate"] =   rcvData["sDelegate"] or self
    rcvData["sFunc"] =  rcvData["sFunc"] or self.toStartLayer
    sData["rcvData"]  =  rcvData 
    local layer = XbFriendsLayer:create(sData)

    layer:setClearCallback(function()
        self:removeFromNavNodes()
        self:toStartLayer()
    end)

    layer:setShowCallback(function()
        self.menuLayer:showTopBar(true)
        
    end)

    self:addToNavNodes(layer)
    self.rootNode:addChild(layer:getRootNode())
end

--好友申请页面
function SceneManager:toFriendApplyLayer(rcvData)
  
    self:toThirClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"] = rcvData
    sData["type"] = "friendApply"
    local layer = XbFriendsApplyLayer:create(sData)
    self.rootLayer:addChild(layer:getRootNode())
end

--黑名单
function SceneManager:toBlackListLayer(rcvData)
  
    self:toThirClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"] = rcvData
    sData["type"] = "blacklist"
    local layer = XbFriendsApplyLayer:create(sData)
    self.rootLayer:addChild(layer:getRootNode())
end

--添加好友确认页面
function SceneManager:toAddFriendConfirmLayer(rcvData)
  
    self:toThirClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"] = rcvData
    local layer = XbFriendsAddFriendConfirmLayer:create(sData)
    self.rootLayer:addChild(layer:getRootNode())
end

--请求公会信息，跳转公会
function SceneManager:reqToGuild(  )
    local sData = {}
    GameManagerInst:rpc("{\"rpc\":\"guild_mine\"}",3,
        function(data)
            --success
            --GameManagerInst:saveToFile("guild_mine.json",data)
            if data.have_guild == 1 then
                local sData = {}
                sData["guild_data"] = table.deepcopy(data)  
                GuildSingleton:getInstance():setMedal_num(data.medal_num or 0)            
                self:toGuildMain(sData) 
            elseif data.have_guild == 0 then
                --无公会
                local sData = {}
                sData["sDelegate"] = self
                sData["sFunc"] = self.toStartLayer
                GuildSingleton:getInstance():setMedal_num(data.medal_num or 0)
                GuildInterface:GuildRecommend(sData)
            else
                GameManagerInst:alert(UITool.ToLocalization("冒险等级不足，公会暂未开启"))
            end
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true) 

end

--公会申请页面
function SceneManager:toGuildApplyLayer(rcvData)
  
    self:toThirClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"] = rcvData
    local layer = XbFriendsGuildApplyLayer:create(sData)
    self.rootLayer:addChild(layer:getRootNode())
end




function SceneManager:toMailDetailLayer(rcvData)
  
    self:toThirClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"] = rcvData
    local layer = XbMailDetailLayer:create(sData)
    self.rootLayer:addChild(layer:getRootNode())
end


-- -- -- 活动
function SceneManager:toActManageLayer(rcvData)
     self.menuLayer:setTitle(self.titleTable[1])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =  self
     rcvData["sFunc"] =  self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = ActManageLayer:create(sData)
    layer.titleNum = 1
    self.sActManage = layer
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
     --self.rootLayer:addChild(MailLayer:create(sData).uiLayer,0,9)
    self.menuLayer:hiddenUserInfo(true)
end
-- 显示获取的邮件
-- 邮件
function SceneManager:toMailGetAllLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  MailGetAllLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end
-- 公会推荐
function SceneManager:toRecommendGuildLayer(rcvData)
     --self.menuLayer:setTitle(self.titleTable[1])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     sData["rcvData"]  =  rcvData 
    local layer = RecommendGuildLayer:create(sData)
    layer.titleNum = 7
    if g_channel_control.show_new_guild_main == true then
      
      self:addToNavNodes(layer)
      self.menuLayer:showTopBar(false)
    else
      self:addToNavNodes(layer)
      self.menuLayer:hiddenUserInfo(true)
    end
    self.rootNode:addChild(layer.uiLayer)
     --self.rootLayer:addChild(MailLayer:create(sData).uiLayer,0,9)
    
end
-- 显示公会排行
function SceneManager:showGuildRank(curNode)
    -- body
    self.allianceNode = curNode
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  = {}
    sData["rcvData"]["GuildType"] = 2
    self.publicRank = RecommendGuildLayer:create(sData)
    self.allianceNode:addChild(self.publicRank.uiLayer,9991,777)
end
-- 隐藏公会排行
function SceneManager:hideGuildRank( ... )
    -- body
    self.allianceNode:removeChildByTag(777)
    self.allianceNode = nil
end
-- 公会基础信息  弹窗
function SceneManager:toGuildBaseInfoLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  GuildBaseInfoLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
    -- self.menuLayer:setTitle(self.titleTable[1])
    -- self:toSecClass()
    -- local sData = {}
    -- sData["sManager"] =  self
    -- rcvData["sDelegate"] =  self
    -- rcvData["sFunc"] =  self.toStartLayer
    -- sData["rcvData"]  =  rcvData 
    -- local layer = GuildBaseInfoLayer:create(sData)
    -- self:addToNavNodes(layer)
    -- self.rootNode:addChild(layer.uiLayer)
    --  --self.rootLayer:addChild(MailLayer:create(sData).uiLayer,0,9)
    -- self.menuLayer:hiddenUserInfo(true)
end
-- 公会创建 弹窗
function SceneManager:toCreateGuildLayer(rcvData)
   -- body
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  CreateGuildLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
 end 
 -- 搜索公会
 function SceneManager:toSearchGuildLayer( rcvData )
   -- body
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  SearchGuildLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
 end
 -- 公会成员列表
 function SceneManager:toGuildMemberLayer( rcvData )
   -- body
    --self.menuLayer:setTitle(self.titleTable[7])
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    rcvData["sDelegate"] =  self
    -- if rcvData["nType"] == 1 then
    --     --if rcvData["GuildType"] == 1 then
    --     rcvData["sFunc"] =  self.toRecommendGuildLayer
    -- else
    --     rcvData["sFunc"] =  self.toStartLayer
    -- end
    
    sData["rcvData"]  =  rcvData 
    local layer = GuildMemberLayer:create(sData)
    layer.titleNum = 7
    self.rootNode:addChild(layer.uiLayer)
     --self.rootLayer:addChild(MailLayer:create(sData).uiLayer,0,9)
    
    if g_channel_control.show_new_guild_main == true then
        self.menuLayer:showTopBar(false)
        self:addToNavNodes(layer)
    else
      self:addToNavNodes(layer)
      self.menuLayer:hiddenUserInfo(true)
    end
 end
-- -- 登陆奖励
function SceneManager:toLandingAward(rcvData)
    self.menuLayer:setTitle(self.titleTable[20])
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer = SignInLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
    --  self.menuLayer:setTitle(self.titleTable[1])
    --  self:toSecClass()
    --  local sData = {}
    --  sData["sManager"] =  self
    --  rcvData["sDelegate"] =  self
    --  rcvData["sFunc"] =  self.toStartLayer
    --  sData["rcvData"]  =  rcvData 
    -- -- self.rootLayer:addChild(LandingAward:create(sData).uiLayer,0,9)
    -- local layer = LandingAward:create(sData)
    -- self:addToNavNodes(layer)
    -- self.rootNode:addChild(layer.uiLayer)
    --  self.menuLayer:hiddenUserInfo(true)
end
--/*模板弹窗的创建和隐藏*/
function SceneManager:fackBookShowBox(tdata)

  self.FBKLayer = FaceBookLayer:create(self,tdata) 
  if self.rootLayer then
     if self.FBKLayer.uiLayer then
        self.rootLayer:addChild(self.FBKLayer.uiLayer,9999,7778)
     end
  else
    if self.FBKLayer.uiLayer then
       self.mainScene:addChild(self.FBKLayer.uiLayer,9999,7778)
    end
  end
  
end
function SceneManager:fackBookHideBox( ... )
   print("进入了管理类的返回函数体")
  -- body
  if self.FBKLayer == nil then
    return
  end
  self.FBKLayer:returnBack()

end
-- -- 跳转网页
-- function SceneManager:toFaceBookLayer(rcvData)
--     -- self.menuLayer:setTitle(self.titleTable[20])
--     -- self:toThirClass()
--     -- local sData = {}
--     -- sData["sManager"] = self 
--     -- sData["rcvData"] = rcvData
--     -- local layer = FaceBookLayer:create(sData)
--     -- self.rootLayer:addChild(layer.uiLayer)

--     NoticeManager:stopNotice()
--     rcvData = rcvData or {}
--     rcvData["sDelegate"] = rcvData["sDelegate"] or self
--     rcvData["sFunc"]     = rcvData["sFunc"] or self.toStartLayer
--     local sData = {}
--     sData["sManager"]    = self
--     sData["rcvData"]     = rcvData 
--     local layer          = FaceBookLayer:create(sData)
--     self:addToNavNodes(layer)
--     self.rootNode:addChild(layer.uiLayer)
--    -- self:toSecClass()

-- end
-- 八日签到奖励 暂时走登陆奖励的接口

-- function SceneManager:toLandingAward(rcvData)
--     self.menuLayer:setTitle(self.titleTable[20])
--     self:toThirClass()
--     local sData = {}
--     sData["sManager"] = self 
--     sData["rcvData"] = rcvData
--     local layer = EightDayLayer:create(sData)
--     self.rootLayer:addChild(layer.uiLayer)

-- end
-- 灵装铸造
function SceneManager:toECastingLayer( rcvData )
    if g_channel_control.b_XbWorkShopView then
      self:toWorkShopLayer(rcvData)
    else
      NoticeManager:stopNotice()
      -- body
       self.menuLayer:setTitle(self.titleTable[4])
       self:toSecClass()
       local sData = {}
       sData["sManager"] =  self
       rcvData["sDelegate"] =  self
       if rcvData["back"] == "bag" then
          rcvData["sFunc"] =  self.toBagLayer
       else
          rcvData["sFunc"] =  self.toStartLayer
       end
       sData["rcvData"]  =  rcvData 
      -- self.rootLayer:addChild(ECastingLayer:create(sData).uiLayer,0,9)
      local layer = ECastingLayer:create(sData)
      self:addToNavNodes(layer)
      self.rootNode:addChild(layer.uiLayer)
      self.menuLayer:hiddenUserInfo(true)
    end
end

-- 轮回重铸
function SceneManager:toReforgeLayer( rcvData )
    if g_channel_control.b_XbWorkShopView then
      self:toWorkShopLayer(rcvData)
    else
      NoticeManager:stopNotice()
      self.menuLayer:setTitle(self.titleTable[4])

      local sData = {}
      sData["sManager"] =  self
      rcvData["sDelegate"] =  self
      rcvData["sFunc"] =  self.toStartLayer
      sData["rcvData"]  =  rcvData

      local isback = false;

      local view = EquipReforgeView.new():init(sData)

      view.clear = function(s)
          if s:getRootNode() then
              s:getRootNode():removeFromParent()
          end
      end
      view.returnBack = function(s)
          s:clear()
          self:removeFromNavNodes()
          self:toStartLayer()
      end
      view.setShow= function(s)
          self.menuLayer:showTopBar(true)
          s:onNavigateTo(isback)
          isback = true
          self.menuLayer:hiddenUserInfo(false)
      end
      view.titleNum = 4
      self:addToNavNodes(view)
      view.uiLayer = view:getRootNode()
      self.rootNode:addChild(view.uiLayer)
      self.menuLayer:hiddenUserInfo(true)
      self:toSecClass()
    end
end

-- 排行榜
function SceneManager:toRanklistLayer(rcvData)
    NoticeManager:stopNotice()
     self.menuLayer:setTitle(self.titleTable[16])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =  self
     rcvData["sFunc"] =  self.toStartLayer
     sData["rcvData"]  =  rcvData 
    local layer = RanklistLayer:create(sData)
    layer.titleNum = 16
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
     --self.rootLayer:addChild(MailLayer:create(sData).uiLayer,0,9)
    self.menuLayer:hiddenUserInfo(true)
end
function SceneManager:toChatLayer(rcvData)
    -- NoticeManager:stopNotice()
    if self.chatLayer ~= nil and self.chatLayer.uiLayer ~= nil   then
      return 
    end
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self
    sData["rcvData"]  =  rcvData
    sData["enterIndex"] = rcvData["enterIndex"] --默认展开的标签页（2 世界 3 战斗）
    -- self.chatLayer = nil
    if g_channel_control.chatVersion == 1 then

      self.chatLayer = ChatUILayer:create(sData)
    elseif g_channel_control.chatVersion == 2 then
      self.chatLayer = ChatNewMainLayer:create(sData)
    end
    self.isShowChating = true
    self.rootLayer:addChild(self.chatLayer.uiLayer)

end

function SceneManager:toChatNewLayer(rcvData)
    -- NoticeManager:stopNotice()
    rcvData = rcvData or {}
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self
    sData["rcvData"]  =  rcvData
    sData["enterIndex"] = rcvData["enterIndex"] --默认展开的标签页（2 世界 3 战斗）
    self.isShowChating = true
   local layer = ChatNewMainLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)

end

function SceneManager:toShowChatBtn( tab )
  if SceneManager.isShowNotice then 
      return 
    end 
  --self.MsgModelLayer = ChatBtnLayer:create(tab,self) 
  local chatLayer = ChatBtnLayerNew:create(tab,self) 
  self.rootLayer:addChild(chatLayer.uiLayer,9991,777)
end

--战前准备
function SceneManager:toReadyLayer(rcvData)
    --消耗AP 转移到 战斗准备页面
    NoticeManager:stopNotice()
    rcvData["ap"] = rcvData["ap"] or 0
    rcvData["gold"] = rcvData["gold"] or 0
    if rcvData["ap"] > user_info["ap"] then --ap不够则弹出ap界面进行快捷使用
        local popData = {}
        popData["oneself"] = self
        popData["callFunc"] = self.toReadyLayer
        popData["rcvData"] = rcvData
        local battle_id = rcvData["b_id"]
        local flag = nil
        if battle_id then
           flag = string.sub(battle_id,1,1)
        end
        --flag 为k表示星盘关卡  星盘关卡不消耗体力，不会提示体力不足
        if flag == nil then
            self:toLoadApLayer(popData)
        elseif flag ~= "k" then
            self:toLoadApLayer(popData)
        else
            battle_data_cache.level_id = rcvData["level_id"] or 0
            self:toThirClass()
            local sData = {}
            sData["sManager"] = self 
            sData["rcvData"] = rcvData
            user_info["team"] = {}
            local layer = ReadyLayer:create(sData)
            self.rootLayer:addChild(layer.uiLayer)
        end
    else                                    -- gold足够则直接进入战前准备界面
        if rcvData["gold"] > user_info["gold"] then 
            --todo 金币不足
            MsgManager:showSimpMsg(UITool.ToLocalization("金币不足"))
        else
            print("SceneManager:toReadyLayer")
            --缓存战斗关卡数据
            battle_data_cache.level_id = rcvData["level_id"] or 0
            self:toThirClass()
            local sData = {}
            sData["sManager"] = self 
            sData["rcvData"] = rcvData
            user_info["team"] = {}
            local layer = ReadyLayer:create(sData)
            self.rootLayer:addChild(layer.uiLayer)
        end 
    end
end
--角色界面跳转灵装养成
function SceneManager:toEquipFromRole(rcvData)
    NoticeManager:stopNotice()
    local isback = false

    local view = EquipMainView.new():init(rcvData.tab)
    
    view.clear = function(s)
        s.exist = false
        if s.equipAwakenView then
            s.equipAwakenView:DestroyHandle()
        end
        if s.equipSkillView then
            s.equipSkillView:DestroyHandle()
        end
        if s.equipSthView then
            s.equipSthView:DestroyHandle()
        end
        if s:getRootNode() then
            s:getRootNode():removeFromParent()
        end
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        --self:toStartLayer()
    end
    view.titleNum = 3
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        isback = true
    end
    --view.uiLayer = view:getRootNode()
    
    rcvData.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
    view:lockSthTargetID(rcvData.eq_id,rcvData.nEquiped)
    view:lockAwakenTarget(rcvData.eq_id,rcvData.nEquiped)
    view:lockSkillTarget(rcvData.eq_id,rcvData.nEquiped)
    view:setHideAllEquip(true)
    view:refresh()
end

--灵装养成
function SceneManager:toEquip(rcvData)
    NoticeManager:stopNotice()
    local isback = false

    local view = EquipMainView.new():init(rcvData.tab)
    view.clear = function(s)
        s.exist = false
        if s.equipAwakenView then
            s.equipAwakenView:DestroyHandle()
        end
        if s.equipSkillView then
            s.equipSkillView:DestroyHandle()
        end
        if s.equipSthView then
            s.equipSthView:DestroyHandle()
        end
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.titleNum = 3
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        isback = true
    end
    view.uiLayer = view:getRootNode()
    
    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end
--灵装详情
function SceneManager:toEquipInfo(rcvData)
    NoticeManager:stopNotice()
    local isback = false
    local eb = false
    if rcvData.eb then
      eb = rcvData.eb
    end
    local view = EquipInfoView.new():init(rcvData.eid,rcvData.elist,eb)
    --view.infoChangedEvent = rcvData.event
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        if s:getRootNode() then
            s:getRootNode():removeFromParent()
        end
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
    end
    view.setShow= function(s)
        self.menuLayer:showTopBar(false)
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 3
    view.uiLayer = view:getRootNode()
 
    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--魂灵装界面
function SceneManager:toSoulEquipLayer(rcvData)
    NoticeManager:stopNotice()
    local isback = false

    rcvData = rcvData or {}
    rcvData["sDelegate"] =  rcvData["sDelegate"] or self
    rcvData["sFunc"] = rcvData["sFunc"]
    rcvData["sManager"] =  self

    local view = SoulEquipMainView.new():init(rcvData)
    view.clear = function(s)
        s:getRootNode():removeFromParent()
    end
    -- view.returnBack = function(s)
    --     s:clear()
    --     self:removeFromNavNodes()
    -- end
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        --isback = true
    end
    view.titleNum = 2
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--专属剧情关卡界面
function SceneManager:toExclusiveStoryListLayer(rcvData)
    print("SceneManager:toExclusiveStoryListLayer")
    NoticeManager:stopNotice()
    rcvData = rcvData or {}
    rcvData["sDelegate"] =  rcvData["sDelegate"] or self
    rcvData["sFunc"] = rcvData["sFunc"] or self.toRoleInfo
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    local layer = ExclusiveStoryListLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self:toSecClass()
end

-- 魂灵装素材兑换
function SceneManager:toExchangeLayer( rcvData )
    if g_channel_control.b_XbWorkShopView then
      self:toWorkShopLayer(rcvData)
    else
      NoticeManager:stopNotice()
      -- body
       self.menuLayer:setTitle(self.titleTable[4])
       self:toSecClass()
       local sData = {}
       sData["sManager"] =  self
       rcvData["sDelegate"] =  self
       if rcvData["back"] == "bag" then
          rcvData["sFunc"] =  self.toBagLayer
       elseif rcvData["back"] == "forge" then
          rcvData["sFunc"] =  self.toECastingLayer
       else
          rcvData["sFunc"] =  self.toStartLayer
       end
       sData["rcvData"]  =  rcvData 
      -- self.rootLayer:addChild(ECastingLayer:create(sData).uiLayer,0,9)
      local layer = ExChangeLayer:create(sData)
      self:addToNavNodes(layer)
      self.rootNode:addChild(layer.uiLayer)
      self.menuLayer:hiddenUserInfo(true)
    end
end

--角色养成
function SceneManager:toRole(rcvData)
    NoticeManager:stopNotice()
    local isback = false

    local view = RoleMainView.new():init(rcvData.tab)
    view.clear = function(s)

        s:MainViewSaveTeamIndex() --点击home键 发送当前队伍到服务器
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 2
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--公会设置
function SceneManager:toGuildSetup(rcvData)

    local isback = false

    local view = GuildSetupView.new():initWithData(rcvData.guild_data)
    view.guildQuitEvent = rcvData.exitGuildFunc
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
    end
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        if g_channel_control.show_new_guild_main == true then
          self.menuLayer:showTopBar(false)
        end
        isback = true
    end
    view.titleNum = 7
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end
--typedef std::function<void(int,std::string)> sdkAccountCallback;

-- --公会主页
-- function SceneManager:toGuildMain(rcvData)
--     NoticeManager:stopNotice()
--     local isback = false

--     local view = GuildMainView.new():init(rcvData.guild_data)
--     view.clear = function(s)
--         KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
--         s:getRootNode():removeFromParent()
--     end
--     view.returnBack = function(s)
--         s:clear()
--         self:removeFromNavNodes()
--         self:toStartLayer()
--     end
--     view.setShow= function(s)
--         self.menuLayer:hiddenUserInfo(true) 
--         s:onNavigateTo(isback)
--         isback = true
--     end
--     view.titleNum = 7
--     view.uiLayer = view:getRootNode()

--     self:toSecClass()
--     self.rootNode:addChild(view:getRootNode(),0,9)
--     self:addToNavNodes(view)
-- end
--公会主页
function SceneManager:toGuildMain(rcvData)
    NoticeManager:stopNotice()
    local isback = false

    local view = NewGuildMainLayer.new():init(rcvData.guild_data)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.setShow= function(s)
      if g_channel_control.show_new_guild_main == true then 
          self.menuLayer:showTopBar(false)
      else
        self.menuLayer:hiddenUserInfo(true) 
      end
      s:onNavigateTo(isback)
      isback = true
    end
    view.titleNum = 7
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end
--公会留言板
function SceneManager:toGuildBBS()

    local isback = false

    local view = GuildBBSView.new():init()
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
    end
    view.setShow= function(s)
        if g_channel_control.show_new_guild_main == true then
            self.menuLayer:showTopBar(false)
        else
          self.menuLayer:hiddenUserInfo(true) 
        end
        
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 7
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    if g_channel_control.show_new_guild_main == true then
      self.menuLayer:showTopBar(false)
      self:addToNavNodes(view)
    else
      self:addToNavNodes(view)
    end
end
--星盘
function SceneManager:toAstrolabeMainLayer(rcvData)
    NoticeManager:stopNotice()
    local isback = false
    rcvData["sManager"] =  self
    local view = AstrolabeMainLayer.new():init(rcvData)

    view.clear = function(s)
        if view and view.keyboardValue then
            KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        end
        s:getRootNode():removeFromParent()
    end
    -- view.returnBack = function(s)
    --     s:clear()
    --     self:removeFromNavNodes()
    -- end
    view.setShow= function(s)
        self.menuLayer:showTopBar(false)
        isback = true
    end
    view.titleNum = 2
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end
--剧情
function SceneManager:toStoryActiManageLayer(rcvData)
    NoticeManager:stopNotice()
    --local isback = false
    rcvData["sManager"] =  self
    local view = StoryActiManageLayer.new():init(rcvData)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.setShow= function(s)
        self.menuLayer:showTopBar(false)
       -- isback = true
    end
    view.titleNum = 2--------
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end
-- 显示公会设施（公会界面用）
function SceneManager:showGuildFacility(rcvData)--curNode ,sDelegate ,sFunc 
  -- body
  -- _type  1  团战商店 2 极限挑战商店
    self.guildNode = rcvData["curNode"]
    local sData = {}
    sData["sDelegate"] = rcvData["sDelegate"] or self
    sData["sManager"] =  self
    sData["sFunc"] = rcvData["sFunc"] or nil
    sData["refreshTopBar"] = rcvData["refreshTopBar"] or nil
    self.publicRank = GuildFacilityView:create(sData)
    self.publicRank:onNavigateTo(false)
    self.guildNode:addChild(self.publicRank:getRootNode(),9991,888)
end

-- 隐藏公会设施(通用)
function SceneManager:hideGuildFacility( ... )
  -- body
    self.guildNode:removeChildByTag(888)
    self.guildNode = nil
end
--公会设施
function SceneManager:toGuildFacility(rcvData)
  
    self.menuLayer:setTitle(self.titleTable[7])
    self:toSecClass()

    local sData = {}
    sData["sDelegate"] = rcvData["sDelegate"] or self
    sData["sManager"] =  self
    sData["sFunc"] = rcvData["sFunc"] or nil
    local isback = false

    local view = GuildFacilityView:create(sData)
    -- view.clear = function(s)
    --     if s.getRootNode then
    --         s:getRootNode():removeFromParent()
    --     end
    -- end
    -- view.returnBack = function(s)
    --     s:clear()
    --     self:removeFromNavNodes()
    -- end
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(false) 
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 7
    view.uiLayer = view:getRootNode()
    self:addToNavNodes(view)
    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--图鉴
function SceneManager:toGallery(rcvData)
    NoticeManager:stopNotice()
    local isback = false

    local view = GalleryView.new():init()
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.setShow= function(s)
        self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 15
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end
--星盘
function SceneManager:toAstrolabeMainLayer(rcvData)
    NoticeManager:stopNotice()
    local isback = false
    rcvData["sManager"] =  self
    local view = AstrolabeMainLayer.new():init(rcvData)

    view.clear = function(s)
        if view and view.keyboardValue then
            KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        end
        s:getRootNode():removeFromParent()
    end
    -- view.returnBack = function(s)
    --     s:clear()
    --     self:removeFromNavNodes()
    -- end
    view.setShow= function(s)
        self.menuLayer:showTopBar(false)
        isback = true
    end
    view.titleNum = 15
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--角色详情
function SceneManager:toRoleInfo(rcvData)
    NoticeManager:stopNotice()
    local isback = false
    local this = self
    if g_channel_control.b_newRole then
        self.RoleInfoView = NewRoleMainView.new():init(rcvData.hid,rcvData.hlist,rcvData.teamidx,rcvData.tab_piece_id)
    else
        self.RoleInfoView = RoleInfoView.new():init(rcvData.hid,rcvData.hlist,rcvData.teamidx,rcvData.tab_piece_id)
    end
    self.RoleInfoView.clear = function(s)
        if g_channel_control.b_newRole then
          if this.RoleInfoView then
              this.RoleInfoView:DestroyHandle()
          end
        end

        if this.RoleInfoView and this.RoleInfoView.keyboardValue then
            KeyboardManager:removeKeyBoardEvent(this.RoleInfoView.keyboardValue)
            this.RoleInfoView = nil 
        end
        s:getRootNode():removeFromParent()
    end
    self.RoleInfoView.returnBack = function(s)
        -- self.RoleInfoView = nil
        s:clear()
        self:removeFromNavNodes()
    end
    self.RoleInfoView.setShow= function(s)
        self.menuLayer:showTopBar(false)
        s:onNavigateTo(isback)
        isback = true
    end
    self.RoleInfoView.titleNum = 2
    self.RoleInfoView.uiLayer = self.RoleInfoView:getRootNode()
 

    self:toSecClass()
    self.rootNode:addChild(self.RoleInfoView:getRootNode(),0,9)
    self:addToNavNodes(self.RoleInfoView)
end

--控制台
function SceneManager:toConsole(rcvData)
    local view = ConsoleView.new():init()
    view.clear = function(s)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        -- self:removeFromNavNodes()
        -- self:toStartLayer()
    end
    -- self:toSecClass()
    -- self:addToNavNodes(view)
    self.rootLayer:addChild(view:getRootNode(),1,99)
 
end
-- 显示Gift弹窗
function SceneManager:toGiftShowListlayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  nil
    if g_channel_control.bNewGiftInfo == true then
        layer =  XbGiftInfoLayer:create(sData)
    else
        layer =  GiftShowListLayer:create(sData)
    end
    self.rootLayer:addChild(layer.uiLayer)
end
-- 显示Gift成长礼包弹窗
function SceneManager:toGiftShowGrowUpLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  GiftShowGrowUpLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end
--阶段性礼包
function SceneManager:toShopPeriodicGiftLayer( rcvData )
   self:toThirClass()
   local sData = {}
   sData["sManager"] = self 
   sData["rcvData"] = rcvData
   local layer = ShopPeriodicGiftLayer:create(sData)
   self.rootLayer:addChild(layer.uiLayer)
end

--商店列表
function SceneManager:toShopLayer( rcvData )
    NoticeManager:stopNotice()
    self.menuLayer:setTitle(self.titleTable[9])
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    rcvData["sDelegate"] = rcvData["sDelegate"] or self
    rcvData["sFunc"] = rcvData["sFunc"] or self.toStartLayer
    sData["rcvData"]  =  rcvData

    local layer = nil
    if g_channel_control.bNewShop == true then
        layer = XbShopLayer:create(sData)
        layer:setClearCallback(function()
            -- self:removeFromNavNodes()
            -- self:toStartLayer()
        end)

        layer:setShowCallback(function()
            self.menuLayer:showTopBar(false)
            
        end)
        print("SceneManager:toShopLayer    g_channel_control.bNewShop",g_channel_control.bNewShop)
    else
        layer = ShopLayer:create(sData)
        self.menuLayer:hiddenUserInfo(false)
    end
    
    layer.titleNum = 9
    self._shopLayer = layer
    self:addToNavNodes(layer)

    if g_channel_control.bNewShop == true then
        self.rootNode:addChild(layer:getRootNode())
    else
        self.rootNode:addChild(layer.uiLayer)
    end
end

-- 背包列表
function SceneManager:toBagLayer( rcvData )
    if g_channel_control.b_XbWorkShopView then
      self:toWorkShopLayer(rcvData)
    else
      NoticeManager:stopNotice()
       print("进入背包的toBagLayer")
       self.menuLayer:setTitle(self.titleTable[4])
       self:toSecClass()
       local sData = {}
       sData["sManager"] =  self
       rcvData["sDelegate"] =  self
       if rcvData["back"] == "forge" then
          rcvData["sFunc"] =  self.toECastingLayer
       else
          rcvData["sFunc"] =  self.toStartLayer
      end
       sData["rcvData"]  =  rcvData 
       --self.rootNode:addChild(BagLayer:create(sData).uiLayer,0,9)
           local layer = BagLayer:create(sData)
      self:addToNavNodes(layer)
      self.rootNode:addChild(layer.uiLayer)
       self.menuLayer:hiddenUserInfo(true)
    end
end

function SceneManager:toWorkShopLayer(rcvData)
    NoticeManager:stopNotice()
    local isback = false
    local this = self
    local returnBackCallBack = rcvData["sFunc"] or self.toStartLayer
    self.workShopMainView = WorkShopMainView.new():init()
    self.workShopMainView.clear = function(s)
        if this.workShopMainView then
          this.workShopMainView:DestroyHandle()
        end

        if this.workShopMainView and this.workShopMainView.keyboardValue then
            KeyboardManager:removeKeyBoardEvent(this.workShopMainView.keyboardValue)
            this.workShopMainView = nil 
        end
        s:getRootNode():removeFromParent()
    end
    self.workShopMainView.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    self.workShopMainView.setShow= function(s)
        --self.menuLayer:hiddenAllUserInfo(true)
        --self.menuLayer:showTopBarBG(false)
        self.menuLayer:showTopBar(false)
        s:onNavigateTo(isback)
        isback = true
    end
    self.workShopMainView.titleNum = 4
    self.workShopMainView.uiLayer = self.workShopMainView:getRootNode()


    self:toSecClass()
    self.rootNode:addChild(self.workShopMainView:getRootNode(),0,11)
    self:addToNavNodes(self.workShopMainView)
end

function SceneManager:toMulBattleLayer(rcvData)
    NoticeManager:startNotice()
    rcvData = rcvData or {}
    rcvData["sDelegate"] =  rcvData["sDelegate"] or self
    rcvData["sFunc"] = rcvData["sFunc"] or self.toStartLayer
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData
    local layer = nil
    if g_channel_control.use_NewMulPassLayer then 
       layer = MulPassLayerNew:create(sData)
    else 
       layer = MulPassLayer:create(sData)
    end 
    --layer.titleNum = 19
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
end

--神灵装(城技能)
function SceneManager:toPSkillLayer(rcvData)
    NoticeManager:stopNotice()
    -- self.menuLayer:setTitle(self.titleTable[15])
    -- if self.bPush == true then
    --      self.tempBackFunc = self.toStartLayer
    --      PSkillLayer.backFunc = self.tempBackFunc
    --      self.bPush = false 
    -- end

    -- if PSkillLayer.exist == false then
    --     PSkillLayer.backFunc = self.tempBackFunc
    -- end
    -- self.tempBackFunc = self.toPSkillLayer

    self:toSecClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer = PSkillLayer:create(sData)
    self.rootNode:addChild(layer.uiLayer,0,9)
    self:addToNavNodes(layer)
    self.PSkillLayer = layer
end

function SceneManager:toPInfoLayer(rcvData)
    NoticeManager:stopNotice()
    local view = PrincessInfoView.new():init(rcvData.index_1,rcvData.index_2)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
    end
    view.listChangedEvent = function()
        rcvData["callFunc_1"](rcvData["ref"])
    end
    self.rootLayer:addChild(view:getRootNode(),1,99)
    view:onNavigateTo(false)

    ---说明：新手引导 
    self.PrincessInfoView = view
end

--抽卡
function SceneManager:toDrawCardLayer(rcvData)
    NoticeManager:startNotice()
    local isback = false
    local defGid = nil
    if rcvData then
        defGid = rcvData.defGachaID
    end
    local view = GachaView.new():init(defGid)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:onNavigateFrom(true)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
        self:removeFromNavNodes()
        self:toStartLayer()
    end
    view.setShow= function(s)
        --self.menuLayer:hiddenUserInfo(true) 
        self.menuLayer:showTopBar(false)
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 6
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--十连抽结果
function SceneManager:toDrawCardEndLayer(rcvData)
    NoticeManager:_stopNotice()   
    rcvData.CoinType = rcvData.CoinType or 0 
    local view = GachaResultView.new():init(rcvData.itemList,rcvData.berylNum,rcvData.CoinType,rcvData.finalFunc)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        --抽卡结束后的引导，这里是返回首页
        if user_info["guide_id"] == guide_id_config.ThatCard then 
            NewGuideManager:startSubGuide(nil, NewGuideManager._curIndex+1)
        end 
        s:clear()
    end
    --view.setShow= function(s)end
 
    self:toThirClass()
    self.rootLayer:addChild(view:getRootNode(),1,99)
    view:onNavigateTo(false)
end

function SceneManager:toGetNewHeroView(rcvData)
    NoticeManager:_stopNotice()
    local view = GetNewHeroView.new():init(rcvData.itemList,rcvData.finalFunc)--(rcvData.itemList,rcvData.finalFunc)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
    end
 
    self:toThirClass()
    self.rootLayer:addChild(view:getRootNode(),9999,99)
    view:onNavigateTo(false)
end

---极限挑战战后结算处理
function SceneManager:dealLimitBattleReslut()
  print("进入  dealLimitBattleReslut ")
    local isLimit = false
    if battle_data_cache.level_id ~= 0 then 
        if UITool.checkPrefixStr(battle_data_cache.level_id,"cl_") then
            isLimit = true
           
            dump("todo 处理极限挑战结算")
            --SceneManager:getRootNode():showUltimateChaBox({})
            SceneManager:showUltimateChaBox({})
            
        end 
    end 
    return isLimit
end
--战斗结算
function SceneManager:toBattleEndLayer(rcvData)
    print("进入  toBattleEndLayer ")
    if self:dealLimitBattleReslut() then 
        do return end 
    end 
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    local layer = BattleEndLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 

--战斗失败
function SceneManager:toBattleFailedLayer(rcvData)
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    local layer = BattleFailedLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 

function SceneManager:tobattleEndBInfo(str)
    if str == nil or str == "" then
       return
    end
    
    local function ReqSuccess(data)
      data = tolua.cast(data, "PassData");
     local cjsonSafe = require "cjson.safe"
     local t_data = cjsonSafe.decode(data:getData())
       print( "成功")
    end
    local cjsonSafe = require "cjson.safe"
     print(str)  
    local tempTable = cjsonSafe.decode(str)
    local cjson = require "cjson"
    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),ReqSuccess, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end


--购买AP界面
function SceneManager:toLoadApLayer(rcvData)
   self:toThirClass()
   local sData = {}
   sData["sManager"] = self 
   sData["rcvData"] = rcvData
   local layer = LoadAp:create(sData)
   self.rootLayer:addChild(layer.uiLayer)
end
-- 活动任务界面
function SceneManager:toActAchievementLayer(rcvData)   
    NoticeManager:stopNotice()
     self.menuLayer:setTitle(self.titleTable[21])
    --  self:toSecClass()
      self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] = rcvData["sDelegate"] or  self

     rcvData["sFunc"] = rcvData["sFunc"] or self.toStartLayer
 
     sData["rcvData"]  =  rcvData 
    
    local layer = ActAchievementLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)

   -- self.menuLayer:hiddenUserInfo(true)
   -- self:toThirClass()
   -- local sData = {}
   -- sData["sManager"] = self 
   -- sData["rcvData"] = rcvData
   -- self.rootLayer:addChild(AchievementLayer:create(sData))
end

-- 成就界面
function SceneManager:toAchievement(rcvData)   
    NoticeManager:stopNotice()
    self.menuLayer:setTitle(self.titleTable[21])
     self:toSecClass()
     local sData = {}
     sData["sManager"] =  self
     rcvData["sDelegate"] =  self

    rcvData["sFunc"] =  self.toStartLayer
 
     sData["rcvData"]  =  rcvData 
    
    local layer = AchievementLayer:create(sData)
    layer.titleNum = 21
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self.menuLayer:hiddenUserInfo(true)
   -- self:toThirClass()
   -- local sData = {}
   -- sData["sManager"] = self 
   -- sData["rcvData"] = rcvData
   -- self.rootLayer:addChild(AchievementLayer:create(sData))
end
-- 公告
---特殊处理，在按键返回提示框的上面盖住了。
function SceneManager:toGameNoticeLayer(rcvData)   
   self:toThirClass()
   local sData = {}
   sData["sManager"] = self 
   sData["rcvData"] = rcvData
   local layer = GameNoticeLayer:create(sData)
   self.rootLayer:addChild(layer.uiLayer,9999,888)
   --self.rootLayer:addChild(layer.uiLayer)
end
-- 活动页面
function SceneManager:toActLayer(rcvData)
    ActBanerManager:requireFile()
    self:toSecClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    sData["sFunc"] = self.toStartLayer
    sData["actID"] = ActBanerManager:getSelectActID()  --当前活动ID
    local layer = ActPassLayerCreate(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer,0,9) 
end
-- 非banner 跳转活动
-- banner 调用toActLayer   非banner进入调用toNoBanerActLayer
function SceneManager:toNoBanerActLayer(rcvData)
    self:toSecClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    sData["sFunc"] = self.toStartLayer
    sData["actID"] = self.sActManage:getActMangeActId() 
    local layer = ActPassLayerCreate(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer,0,9) 
end
--剧情跳转活动 --actType 1 
function SceneManager:toStoryActLayer(rcvData)
    self:toSecClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"]  = rcvData
    sData["sFunc"]    = self.toStartLayer
    sData["actID"]    = StoryActiItem:getActId()
    print("dddddd =="..sData["actID"])
    local layer = ActPassLayerCreate(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer,0,9) 
end
--抽卡
-- gachaLua 
function SceneManager:toActDrawCardLayer(rcvData)
    NoticeManager:startNotice()
   
    local isback = false
    local view = rcvData.view
    view.sDelegate = rcvData.sDelegate
    view.sFunc = rcvData.sFunc
    if view == nil then 
        print("GachaView error")
        do return end 
    end 
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:onNavigateFrom(true)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        if view.sFunc then 
           view.sFunc(view.sDelegate)
        end  
        s:clear()
        self:removeFromNavNodes()
    end
    view.setShow= function(s)
        --self.menuLayer:hiddenUserInfo(true) 
        s:onNavigateTo(isback)
        isback = true
    end
    view.titleNum = 18
    view.uiLayer = view:getRootNode()

    self:toSecClass()
    self.rootNode:addChild(view:getRootNode(),0,9)
    self:addToNavNodes(view)
end

--探索页面
--isBackStartLayer 0 是不返回主页， 1 是返回主页
function SceneManager:toExploreLayer(rcvData)
    NoticeManager:stopNotice()
    if rcvData.isBackStartLayer == nil then 
        rcvData.isBackStartLayer = 1
    end 

    rcvData["sDelegate"] =  self
    if rcvData.isBackStartLayer ==1 then
        rcvData["sFunc"] = self.toStartLayer
    else 
        rcvData["sFunc"] = nil 
    end 
  
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 

    local layer = ExploreLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer,0,9)
    
end
--探索选择队伍页面
function SceneManager:toExploreTeamLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  ExploreTeamLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end 

--探索结果页面
function SceneManager:toExploreResultLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  ExploreResultLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end 
--探索队伍筛选 --
function SceneManager:toExploreTeamSiftLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  ExploreTeamSiftLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end

--新手引导页面
function SceneManager:addGuideLayer(layer)
    self.rootLayer:addChild(layer.uiLayer,2,999)
end 

--图片引导页面
--rcvData["sDelegate"] =  
--rcvData["sFunc"] = 
--[[
    local data = {}
    data.sFunc = self.dealPictureGuide  --不回调 为nil 或者不设置
    data.sDelegate = self  --不回调 为nil 或者不设置
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_010.png",
    }
    self.sManager:toGuidePictureLayer(data)
--]]
function SceneManager:toGuidePictureLayer(rcvData)
    print("toGuidePictureLayer")
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  GuidePictureLayer:create(sData)
    if layer.uiLayer then
       self.rootLayer:addChild(layer.uiLayer,1,99)
    end
end
--玩家卡片页面
function SceneManager:toPlayerCardLayer(rcvData)
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] = self.toStartLayer
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    local layer = PlayerCardLayer:create(sData)
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
end
--玩家头像列表
function SceneManager:toPlayerCardListLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer = PlayerCardListLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end 
--玩家板娘列表
function SceneManager:toBanNiangListLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer = BNListLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end

--去输入框 ,返回layer 自己控制移除
function SceneManager:toInputModelLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  InputModelLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
    return layer
end 

-- --公会成员列表
-- function SceneManager:toGuildMembersLayer(rcvData)
--     dump(rcvData)
--     rcvData["sDelegate"] =  self
--     --rcvData["sFunc"] = self.toActLayer
--     rcvData["sFunc"] = nil --不需要返回主页
--     self:toSecClass()
--     local sData = {}
--     sData["sManager"] =  self
--     sData["rcvData"]  =  rcvData 
--     --todo 成员列表
--     -- local layer = MulPassLayer:create(sData)
--     -- self:addToNavNodes(layer)
--     -- self.rootNode:addChild(layer.uiLayer)
-- end
--玩家信息页面
function SceneManager:toPlayerInfoLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    sData["sFunc"] =  self.toStartLayer
    local layer = nil
    if g_channel_control.b_XbPlayerInfoView == true then
        layer =  XbPlayerInfoMainLayer:create(sData)
        self.rootLayer:addChild(layer.uiLayer,1,99)
    else
        layer =  PlayerInfoLayer:create(sData)
        self.rootLayer:addChild(layer.uiLayer,1,99)
    end
end

--公会道馆
function SceneManager:toGuildPavilionLayer(rcvData)
    self:toSecClass()
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    rcvData["sDelegate"] =  self
    --rcvData["sFunc"] = self.toStartLayer 不需要返回首页，这个地方需要回到 公会主页吗、
    local layer = GuildPavilionLayer:create(sData)
    if g_channel_control.show_new_guild_main == true then
      layer.titleNum = 7
      self:addToNavNodes(layer)
      self.menuLayer:showTopBar(false)
    else
      self:addToNavNodes(layer)
    end
    self.rootNode:addChild(layer.uiLayer,0,9)
end
--道馆 奖励列表
function SceneManager:toPavilionRewardLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  GuildPavilionRewardLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 
--排行榜 奖励列表
function SceneManager:toRankListRewardLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  RankListRewardLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 
--选择玩家称号列表
function SceneManager:toSelectPlayerTitleLayer(rcvData)
    rcvData = rcvData or {}
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  SelectPlayerTitleLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end

--变更称号浏览列表
function SceneManager:toTitleBrowerLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer = XbTitleBrowerLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end 

--横向玩法1
function SceneManager:toDDBattleMainLayer(rcvData)
    NoticeManager:stopNotice()
    self:toSecClass()
    self.menuLayer:setTitle(self.titleTable[5])
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] = self.toStartLayer
    local layer = DDBattleMainLayer:create(sData)
    layer.titleNum = 5
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer,0,9)
end

--横向玩法1选择队伍页面
function SceneManager:toDDBattleRoleListView(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  DDBattleRoleListView:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end 

--合战战后结算界面
function SceneManager:toDDBattleRewardLayer(rcvData)
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer = DDBattleRewardLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer)
end 

--试炼之地
function SceneManager:toTrialLandLayer(rcvData)
    local user_lv = user_info["rank"] or 1
    if user_lv < UnlockTrialRank then
       local unlockTip = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"), UnlockTrialRank)
       GameManagerInst:alert(unlockTip)
       return
    end
    NoticeManager:stopNotice()
    rcvData = rcvData or {}
    rcvData["sDelegate"] =  rcvData["sDelegate"] or self
    rcvData["sFunc"] = rcvData["sFunc"] or self.toStartLayer
    local sData = {}
    sData["sManager"] =  self
    sData["rcvData"]  =  rcvData 
    local layer = TrialLandLayer:create(sData)
    layer.titleNum = 14
    self:addToNavNodes(layer)
    self.rootNode:addChild(layer.uiLayer)
    self:toSecClass()
end

--图鉴（称号图鉴、角色图鉴、装备图鉴）
function SceneManager:toEpithetLayer( rcvData )
    NoticeManager:stopNotice()
    self.menuLayer:hiddenUserInfo(true)
    
    self.menuLayer:setTitle(self.titleTable[24])
    local view = HandbookMainLayer.new():init(1)
    view:setManager(self)
    view.titleNum = 24
    self:addToNavNodes(view)
    view.uiLayer = view:getRootNode()
    self.rootNode:addChild(view.uiLayer)
    
    self:toSecClass()
end

--极限挑战
function SceneManager:toExtremeChallengeLayer( rcvData )
   print("SceneManager:toEpithetLayer");

end

--竞技场
function SceneManager:toArenaLayer( rcvData )
   print("SceneManager:toArenaLayer");

end

--剧情
function SceneManager:toScenarioLayer( rcvData )
   print("SceneManager:toScenarioLayer");

end


function SceneManager:toShareRoleLayer(rcvData)   
    NoticeManager:_stopNotice()
    self:toThirClass()
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = rcvData
    local layer =  ShareRoleLayer:create(sData)
    self.rootLayer:addChild(layer.uiLayer,1,99)
end

function SceneManager:toGMEffectLayer(rcvData)
    NoticeManager:_stopNotice()
    local view = GMEffectView.new():init(rcvData.nHeroId,rcvData.finalFunc)
    view.clear = function(s)
        KeyboardManager:removeKeyBoardEvent(view.keyboardValue)
        s:getRootNode():removeFromParent()
    end
    view.returnBack = function(s)
        s:clear()
    end
    --view.setShow= function(s)end
 
    self:toThirClass()
    self.rootLayer:addChild(view:getRootNode(),1,99)
    view:onNavigateTo(false)
end

--返回一级界面
function SceneManager:toFirClass()
    self.menuLayer:showAll()
    self.menuLayer:changeBGScene(1)
    self.menuLayer:refshBtnsState()
    self.sceneNum = 1
    self.rootLocation = 1
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
end

--跳转到二级界面
function SceneManager:toSecClass()
    self.sceneNum = 2
    self.rootLocation = 2
    self.menuLayer:hiddenAll() --跳转后一级界面隐藏
    --因hiddenall在其他地方会调用 而释放女主动画只需在此调用 故将此部分从hiddenall函数中提出
    self.menuLayer:ReleaseHeroineAnime() --跳转到二级界面释放女主动画
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
end

--跳转到三级界面
function SceneManager:toThirClass()
   self.sceneNum = 3
end

--创建等待界面
function SceneManager:createWaitLayer()
    KeyboardManager:setIsDealReturnBack(false)
    if self.waitLayer == nil then
       self.waitLayer = cc.Layer:create()
       local node =cc.CSLoader:createNode("WaitingLayer.csb")
       self.waitLayer:addChild(node,0,2)
       self.rootLayer:addChild(self.waitLayer,1000,10)
       local zAction = cc.CSLoader:createTimeline("WaitingLayer.csb")
       node:stopAllActions()
       node:runAction(zAction)
       zAction:play("zhuan",true)
       
       local  panel = node:getChildByTag(353)
       local  dian = panel:getChildByTag(28)
       local dAction = cc.CSLoader:createTimeline("LoadingSp.csb")
       dian:stopAllActions()
       dian:runAction(dAction)
       dAction:play("play",true)

    else
    if  self.waitLayer:getParent() ~= self.rootLayer then
         print("移除遮罩层")
         self.waitLayer:removeFromParent()
         self.waitLayer = nil 
         self.waitLayer = cc.Layer:create()
      local node =cc.CSLoader:createNode("WaitingLayer.csb")
       self.waitLayer:addChild(node,0,2)
       self.rootLayer:addChild(self.waitLayer,1000,10)
       local zAction = cc.CSLoader:createTimeline("WaitingLayer.csb")
       node:stopAllActions()
       node:runAction(zAction)
       zAction:play("zhuan",true)
       
       local  panel = node:getChildByTag(353)
       local  dian = panel:getChildByTag(28)
       local dAction = cc.CSLoader:createTimeline("LoadingSp.csb")
       dian:stopAllActions()
       dian:runAction(dAction)
       dAction:play("play",true)
     end
            print("显示遮罩层")
           self.waitLayer:setVisible(true)
    end
    NewGuideManager:setGuideLayerVisibele(false)
    KeyboardManager:setWaitState(true)
end


function SceneManager:delWaitLayer()
    KeyboardManager:setIsDealReturnBack(true)
    if self.waitLayer ~=nil  then 
        self.waitLayer:setVisible(false)
    end
    --新手引导显示
    NewGuideManager:setGuideLayerVisibele(true)
    KeyboardManager:setWaitState(false)
end
--添加触摸遮罩层 遮挡点击事件
function SceneManager:addTouchMask()
    KeyboardManager:setIsDealReturnBack(false)
    if self.touchMaskLayer == nil then
       self.touchMaskLayer = cc.Layer:create()
       --TouchMaskLayer UI 为了以后加特效等，暂时为空panel
       local node =cc.CSLoader:createNode("TouchMaskLayer.csb")
       self.touchMaskLayer:addChild(node,0,2)
       self.rootLayer:addChild(self.touchMaskLayer,1000,10)
    else
        print("显示遮罩层")
        self.touchMaskLayer:setVisible(true)
    end
end
--deal 移除触摸遮罩层
function SceneManager:removeTouchMaskLayer()
    KeyboardManager:setIsDealReturnBack(true)
    if self.touchMaskLayer ~=nil  then 
        self.touchMaskLayer:removeFromParent()
        self.touchMaskLayer = nil 
    end
end
--动画正在进行中，屏蔽触摸事件
--添加触摸遮罩层 遮挡点击事件
function SceneManager:addAniMask()
    KeyboardManager:setIsDealReturnBack(false)
    if self.aniMaskLayer == nil then
       self.aniMaskLayer = cc.Layer:create()
       --TouchMaskLayer UI 为了以后加特效等，暂时为空panel
       local node =cc.CSLoader:createNode("TouchMaskLayer.csb")
       self.aniMaskLayer:addChild(node,0,2)
       self.rootLayer:addChild(self.aniMaskLayer,1000,10)
    else
        self.aniMaskLayer:setVisible(true)
    end
end
--deal 移除触摸遮罩层
function SceneManager:removeAniMaskLayer()
    KeyboardManager:setIsDealReturnBack(true)
    if self.aniMaskLayer ~=nil  then 
        self.aniMaskLayer:removeFromParent()
        self.aniMaskLayer = nil 
    end
end

function SceneManager:fadeOutBGScene()
    self.menuLayer:fadeOutBGScene()
end

--添加到navTable
function SceneManager:addToNavNodes(bNode)
    local num = #self.navNodeTable + 1
    self.navNodeTable[num] = bNode
     if bNode.titleNum >-1 then -- 设置标题
          print("HomeTest--addToNavNodes:"..self.titleTable[bNode.titleNum])
         self.menuLayer:setTitle(self.titleTable[bNode.titleNum])
         if g_channel_control.UIVersion == 2 then
          local bHideHome = true
          if self.menuLayer:getTitle() == self.titleTable[17] then
            bHideHome = false
          end
          self.menuLayer:showHomeBtn(bHideHome)
          self.menuLayer:showTopBar(true)
         end
     end
    print("添加到导航栏中") 
    bNode:setShow()--调用当前界面的显示方法
end
--从navTable移除
function SceneManager:removeFromNavNodes(bNode)
  print("从导航栏中移除")
    local num = #self.navNodeTable
    table.remove(self.navNodeTable,num)
    if num > 1 then
       local nowNode = self.navNodeTable[num-1]
       if nowNode.titleNum >-1 then -- 设置标题为上个界面的的title
        self.menuLayer:setTitle(self.titleTable[nowNode.titleNum])
        if g_channel_control.UIVersion == 2 then
          local bHideHome = true
          if self.menuLayer:getTitle() == self.titleTable[17] then
            bHideHome = false
          end
          self.menuLayer:showHomeBtn(bHideHome)
        end
       end
       nowNode:setShow()--调用当前界面的显示方法
    end 
end

function SceneManager:getRootNode()

  local num = #self.navNodeTable
  if num > 0 then
    return self.navNodeTable[num]
  end
  return self.menuLayer
end  

--全部从navTable移除
function SceneManager:removeAllFromNavNodes()
    print("弹出到首页")
     for i=#self.navNodeTable, 1, -1 do
        self.navNodeTable[i]:clear()
        table.remove(self.navNodeTable,i)    
     end 
    self.navNodeTable = {}  
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
end

--清理所有数据
function SceneManager:clearAllData()    
    DataManager:clearAllData()
    UserDataMgr:getInstance():clearData()
end
----开启心跳,登陆成功时开启
function SceneManager:startHeartBeat()
    if self.hbSchedulerEntry ~= nil then return end
    local heartBeatTime = 30 --心跳时长30s。这个如果经常改的话，拿到常量里面
    local function unpause(time)
        --请求心跳
        self:reqHeartBeat()
    end
    local scheduler = cc.Director:getInstance():getScheduler()
    self.hbSchedulerEntry = scheduler:scheduleScriptFunc(unpause,heartBeatTime, false)
end
----关闭心跳 runLoginScene ，关闭
function SceneManager:stopHeartBeat()
    if self.hbSchedulerEntry == nil then return end
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.hbSchedulerEntry)
    self.hbSchedulerEntry = nil
end

function SceneManager:reqHeartBeat()
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    local function ReqSuccess(data)
        user_info["ap_next"] = data.ap_next or user_info["ap_next"]
        local ap = data.ap or user_info["ap"]
        if ap > user_info["ap"]  then 
            user_info["ap"] = ap 
            if self.menuLayer then 
                self.menuLayer:RefshTopBar()
            end
        end 
    end
    local function ReqFailes(data)
        dump("heart_beat failes")
    end
    local version =  UpdateManager:getVersion()
    ----这个不需要屏蔽层 delWaitLayer
    local function doHeardReq(tempTable, successFunc,urlType,failesFunc)
        urlType = urlType or 3
        local function reicePointCallBack(data)
            --心跳异常不处理
            data = tolua.cast(data, "PassData");
            print("callBack-----"..data:getData())
            local cjsonSafe = require "cjson.safe"
            local t_data = cjsonSafe.decode(data:getData())
            if t_data == nil then 
                return
            end 
            if t_data ~= nil and t_data["server_tm"] then
                UserDataMgr:getInstance().timeData:setTime(t_data["server_tm"])
            end
            --增加禁言结束时间
            if t_data ~= nil and t_data["data"]["ban_speak_end_time"] then
                XBChatSys:getInstance():setBanSpeakTimeEnd(t_data["data"]["ban_speak_end_time"])
            end

            if  t_data["data"]["state_code"] ~=1 then
                return
            end
            
            if  t_data["data"]["check_id"] and t_data["data"]["check_id"] ~="" then
               check_sk_id = t_data["data"]["check_id"]
               check_sk_info = {}
               check_sk_info = t_data["data"]["check_info"]
            end

            self.lastHeardBeatTime = self.lastHeardBeatTime or 0
            if self.lastHeardBeatTime < t_data["server_tm"] then 
                self.lastHeardBeatTime = t_data["server_tm"]
                successFunc(t_data["data"])
            end  
        end
        local cjson = require "cjson"
        local mydata =  cjson.encode(tempTable)
        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
        ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
        dbhttp:creatHttpRequestWithURL(mydata,urlType)
    end
    local check_sk = {}
    check_sk["check_id"] = check_sk_id
    check_sk["check_info"] = DataManager:getbeat_checksk()

    local qm_checkMsg = ""
    if g_channel_control.quickMacroabled == true then 
        qm_checkMsg = QuickMacroTools:getInstance():getSendmessage()
    end   
    local tempTable = {
        ["rpc"] = "heart_beat",
        ["version"] = version,
        ["check_sk"] = check_sk,
        ["qm_check"] = qm_checkMsg
    }
    doHeardReq(tempTable, ReqSuccess,11, ReqFailes)
end

----这个不需要屏蔽层 delWaitLayer
function SceneManager:doReq(tempTable, successFunc,urlType,failesFunc)
    urlType = urlType or 3
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end
    local cjson = require "cjson"
    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,urlType)
end

---检测低端黑名单机型
function SceneManager:checkBlackDevices()
    local fullpath = cc.FileUtils:getInstance():fullPathForFilename("devices.json")
    local str = cc.FileUtils:getInstance():getStringFromFile(fullpath)
    local isIn = DeviceCheck:getInstance():isDeviceInBlacklist(str)
    if isIn then 
        require "BlackDevicesShow"
        local layer = BlackDevicesShow:create()
        self.rootLayer:addChild(layer.uiLayer,3,10000)
    end 
end

function SceneManager:toStartBattle()
    KeyboardManager:setbattleState(true)
    GameManagerInst:blackScreenOn()
    if g_channel_control.battleLua and G_STAGE_TYPE ~= 0 then
        PushBattleScene(t_data["data"])
    else
        cc.MyHttpHelper:shareMyHttpHelper():startGame() 
    end
    UITool.delayTask(0.1,function ( ... )
      local scene = cc.Director:getInstance():getRunningScene()
          dump(scene, "SceneManager:toStartBattle    22222")
          if scene then
              KeyboardManager:bindingAndroidKeyboard(scene,3)
          end
      end)

end

function SceneManager:showTipLayer(info)
    local tipLayer = MsgTipLayer:create(info)
    if self.rootLayer and tolua.isnull(self.rootLayer) == false then
      self.rootLayer:addChild(tipLayer,1000000);
    else
      if self and tolua.isnull(self) == false then
         self:addChild(tipLayer,1000000);
      end
    end

end

---绑定按钮home back 键
--todo 绑定到scene上面，需要多次绑定，更换scene的时候
-- fromID 1 为登陆界面，目前没有token，不需要调用game_quit ，2 为mainScene
function SceneManager:bindingAndroidKeyboard(scene,fromID)
    --绑定返回键
    self._touchKeyBoardNum = 0
    if self._keyBoardListener then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._keyBoardListener)
        self._keyBoardListener = nil 
    end 
    local function exitGame()
        if fromID == 2 then 
            GameManagerInst:rpc( 
                {
                    rpc = "game_quit",
                },
                3,
                function(data)
                    --success
                end,
                function(state_code,msgText)
                    --failed
                end,
            true)
        end 
        os.exit()
    end 
    local function cancelFunc()
      -- body
        self._touchKeyBoardNum = 0
    end
    local function onKeyReleased(keyCode, event)
        --local label = event:getCurrentTarget()
        if keyCode == cc.KeyCode.KEY_BACK then

          if CHANNEL.Android.CHANNEL_CODE_360 == GAME_CHANNEL then
             zc.SDKQuitGame()
          elseif CHANNEL.Android.CHANNEL_CODE_CN == GAME_CHANNEL then
             zc.SDKQuitGame()     
          elseif CHANNEL.Android.CHANNEL_CODE_UC == GAME_CHANNEL then
             zc.SDKQuitGame() 
          elseif CHANNEL.Android.CHANNEL_CODE_MZ == GAME_CHANNEL then
             zc.SDKQuitGame()  
          elseif CHANNEL.Android.CHANNEL_CODE_BD == GAME_CHANNEL then
             zc.SDKQuitGame()      
          elseif CHANNEL.Android.CHANNEL_CODE_JL == GAME_CHANNEL then
             zc.SDKQuitGame() 
          elseif CHANNEL.Android.CHANNEL_CODE_LX == GAME_CHANNEL then
             zc.SDKQuitGame()  
          elseif CHANNEL.Android.CHANNEL_CODE_VV == GAME_CHANNEL then
             zc.SDKQuitGame()   
          elseif CHANNEL.Android.CHANNEL_CODE_OP == GAME_CHANNEL then
             zc.SDKQuitGame()   
          else 
            if  self._touchKeyBoardNum == 0 then 
                MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("是否退出游戏"),self,exitGame,cancelFunc)
                self._touchKeyBoardNum = 1
            else 
                exitGame()
            end 
          end   
        elseif keyCode == cc.KeyCode.KEY_MENU  then
        end
    end
    self._keyBoardListener = cc.EventListenerKeyboard:create()
    self._keyBoardListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    if scene then 
        local eventDispatcher =  cc.Director:getInstance():getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(self._keyBoardListener, scene)
    end 
end

function SceneManager:showMsgBox(tab)
  if  KeyboardManager._isShowNotice  then 
      return 
  end 
  local MsgBoxLayer = MsgBoxLayer.new():init(tab)
  if self.rootLayer then
     if MsgBoxLayer:getRootNode() then
        self.rootLayer:addChild(MsgBoxLayer:getRootNode(),9991,777)
     end
  else
    if MsgBoxLayer:getRootNode() and self.mainScene then
       self.mainScene:addChild(MsgBoxLayer:getRootNode(),9991,777)
    end
  end
end

function SceneManager:toShowMsgBoxGift(tab)
  if  KeyboardManager._isShowNotice  then 
      return 
  end 
  local MsgBoxLayer_Gift = MsgBoxLayer_Gift.new():init(tab)
  if self.rootLayer then
     if MsgBoxLayer_Gift:getRootNode() then
        self.rootLayer:addChild(MsgBoxLayer_Gift:getRootNode(),9991,777)
     end
  else
    if MsgBoxLayer_Gift:getRootNode() and self.mainScene then
       self.mainScene:addChild(MsgBoxLayer_Gift:getRootNode(),9991,777)
    end
  end
end

function SceneManager:ReqCheckNewName(newNameStr)
  local function ReqChangeName(newNameStr)
    local tempTable = 
    {
      rpc = "user_name_change",
      name = newNameStr,
    }
    GameManagerInst:rpc(tempTable,
    3,
    function(data)
      if data == nil then
         MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
        return
      end
      if data["state_code"] == 1 then
        user_info["name"] = newNameStr
        if self.menuLayer then
          self.menuLayer:RefshTopBar()
        end
        local str = UITool.ToLocalization("昵称修改成功")
        SceneManager:showPromptLabel(str)
        dump(SceneManager.fCall,"fCall=")
        if SceneManager.fCall then
          SceneManager.fCall()
        end
      end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
  end

  local function callback ()
      ReqChangeName(newNameStr)
  end

  local tempTable = 
      {
        rpc = "user_name_check",
        name = newNameStr,
      }
  GameManagerInst:rpc(tempTable,
  3,
  function(data)
      if data == nil then
         MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
          return
      end
      if data["state_code"] == 1 then
          --todo刷新数据
        if user_info["name"] ~= nil and newNameStr ~= user_info["name"] then--昵称变更
            GameManagerInst:confirm(UITool.ToLocalization("原昵称:")..user_info["name"]..UITool.ToLocalization("\n新昵称:")..newNameStr..UITool.ToLocalization("\n是否确认修改？"),callback)
        end
      end
  end,
  function(state_code,msgText)
      GameManagerInst:alert(msgText)
  end,
  true)
end

function SceneManager:showPlayerCard(oneself,func)
  SceneManager.fCall = nil
  SceneManager.fCall = func

  local function callback()
      local rcvData = {}
      rcvData["sDelegate"] = oneself
      rcvData["confirmFunc"] = self.ReqCheckNewName 
      rcvData["defalutStr"] = user_info["name"]
      rcvData["maxLength"] = 6
      rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
      self.inputLayer = self:toInputModelLayer(rcvData)
  end

  local function ReqGetChangeNameNum()
      GameManagerInst:rpc(
      {
          rpc = "rename_cards_num"
      },
      3,
      function(data)
          if data == nil then
             MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
              return
          end
          if data["state_code"] == 1 then
              if data["rename_cards_num"] ~= nil then
                self.nRenameCardNum = tonumber(data["rename_cards_num"])
                if self.nRenameCardNum > 0 then
                    MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("是否消耗 改名卡*1 修改昵称")..string.format(UITool.ToLocalization("\n(改名卡剩余：%d枚"),self.nRenameCardNum)..")",oneself,callback,nil,true)
                else
                    MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("是否消耗 改名卡*1 修改昵称")..string.format(UITool.ToLocalization("\n(改名卡剩余：%d枚"),self.nRenameCardNum)..")",oneself,callback,nil,false)
                end
              end
          end
      end,
      function(state_code,msgText)
          GameManagerInst:alert(msgText)
      end,
      true)
  end

  ReqGetChangeNameNum()
end

function SceneManager:ReqUseAp(sData,callfunc,callfunc1)
  local function reqAP(tempTable)
    GameManagerInst:rpc(tempTable,
    3,
    function(data)
      if data == nil then
         MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
        return
      end
      dump(data,"使用体力=")
      if data["state_code"] == 1 then
        DataManager:eatAP(data)
        -- if self.menuLayer then
        --   self.menuLayer:RefshTopBar()
        -- end
        if callfunc1 then
          callfunc1()
        end
        callfunc()
        MsgTipSys:getInstance():addData(UITool.ToLocalization("使用体力成功"))
        --MsgManager:showSimpMsg(UITool.ToLocalization("使用体力成功"))
      end
    end,
    function(state_code,msgText)
      GameManagerInst:alert(msgText)
    end,
    true)
  end
  local tempTable = {
     rpc = "eat_item",
     item_type = sData["item_type"],
     item_num = 1,
   }
   reqAP(tempTable)
end


