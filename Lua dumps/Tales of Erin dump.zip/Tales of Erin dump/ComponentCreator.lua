--组件创建。
--buff和debuff创建完后添加到componentManager。立即生效的情况直接执行不添加。
--created by kobejaw.2018.6.3.
ComponentCreator = {}

local skillOwner
function ComponentCreator:createComponent(trigEffectData,entity,option)
	--团战共享的buff只有81003这一个，在这里特殊处理一下.skill_m这个字段以后就不用了，有特殊情况在这里加。
	local comId = trigEffectData.debuff_id
	local lv = trigEffectData.lv
	skillOwner = entity

	--创建
	local isHasSendMultiBuff = false
	local targetList = self:getTarget(trigEffectData,entity,option)
	for k,target in pairs(targetList) do
		if not target.isDead and self:checkIsNeedCreate(trigEffectData,entity,target,option) then
			if comId < 82000 then
				if G_STAGE_TYPE == 2 and not isHasSendMultiBuff and target.entityType == 1 then --多人战同步，只有神格技能会用到
					isHasSendMultiBuff = true
					self:sendMultiBuff(comId,lv)
				end
				self:createCom_Buff(comId,lv,target,option)
			elseif comId < 83000 then
				local com = self:createCom_Debuff(comId,lv,target,option)
				if com and G_STAGE_TYPE == 2 and target.isBoss and com.isShared then --多人战同步
					self:sendMultiDeBuff(comId,lv)
				end
			elseif comId < 84000 then
				if option and option.isReverse then
					self:removeCom_ImmediateEffect(comId,lv,target,option)
				else
					self:createCom_ImmediateEffect(comId,lv,target,option)
				end
			end
		end
	end

	if comId <82000 then
		BattlePlaySound(BattleGlobals.Sound_Buff,false,2)
	elseif comId < 83000 then
		BattlePlaySound(BattleGlobals.Sound_Debuff,false,2)
	end
end

--获取在哪些entity上生效。如果在被攻击者或者被治疗者身上生效，target从option里取。取不到的话一定是策划配错表了。
function ComponentCreator:getTarget(trigEffectData,entity,option)
	local targetList = {}

	--注：entity为nil时为神格。神格的trigEffectData的target_type不能配成1.
	--注：先这么弄吧，因为pvp不可能存在神格技能。

	if trigEffectData.target_type == 1 then     --自身
		if entity then
			table.insert(targetList,entity)
		else
			print("神格技能的target_type不能配成1")
		end
	elseif trigEffectData.target_type == 3 or trigEffectData.target_type == 5 then--正在被攻击，被治疗或被反弹的对象
		if option and option.affectedEntity then
			table.insert(targetList,option.affectedEntity)
		end
	elseif trigEffectData.target_type == 2 then --我方全体
		if entity then
			targetList = entity.teammateList
		else
			targetList = BattleRuntimeInfo.teams[1].entities
		end
	elseif trigEffectData.target_type == 4  then--敌方全体 
		if entity then
			targetList = entity.enemyList
		else
			targetList = BattleRuntimeInfo.teams[2].entities
		end
	--我方X属性角色
	elseif trigEffectData.target_type >=6 and trigEffectData.target_type <= 10 then
		local tempList
		if entity then
			tempList = entity.teammateList
		else
			tempList = BattleRuntimeInfo.teams[1].entities
		end

		local element = trigEffectData.target_type - 5
		for k,v in pairs(entity.teammateList) do
			if v.attr[AE.element] == element then
				table.insert(targetList,v)
			end
		end
	--新规则
	else
		local str = tostring(trigEffectData.target_type)
		targetList = self:getTarget_NewRule(entity,str)
	end

	return targetList
end

--检测是否需要创建。
function ComponentCreator:checkIsNeedCreate(trigEffectData,entity,target,option)

	if option and option.isReverse then--随触发器失效的情况,一定返回true
		return true
	end

	local comId = trigEffectData.debuff_id
	if comId > 83000 then
		return self:checkIsNeedCreate_ImmediateEffect(comId,target)
	end

	local comLv = trigEffectData.lv
	local com = target.componentManager:getComById(comId)
	if com then
		--如果管理器中存在相同id的高等级的组件
		if com.comData.state_lv > comLv then
			return false
		end
		--如果叠加次数达到上限
		if com.comData.state_lv == comLv and com.canOverlay then
			if com.overlayNum >= com.overlayMaxNum then
				--重置一下com的剩余时间
				com:resetRemainTime()
				return false
			end
		end
	end

	if comId > 82000 then
		--无敌状态对debuff免疫
		if target.componentManager:checkIsWuDi() then
			--飘字，“免疫”
			BattleDamageDisplay:create(target:getDamageShowingPos(true),-1,DamageFontType.Immune)
			return false
		end

		--boss对眩晕免疫
		if target.isBoss and (comId == 82029 or comId == 82030) then
			return false
		end

		--检测是否对该debuff免疫
		if target.attributeManager:checkIsImmuneToDebuff(comId) then
			--飘字，“免疫”
			BattleDamageDisplay:create(target:getDamageShowingPos(true),-1,DamageFontType.Immune)
			return false
		end

		--检测是否有异常护盾
		local com = target.componentManager:getComById(81034)
		if com then--触发并移除异常护盾
			target.componentManager:removeCom(com)
			--飘字，“免疫”
			BattleDamageDisplay:create(target:getDamageShowingPos(true),-1,DamageFontType.Immune)
			return false
		end

		--计算概率
		if entity and target then
			local rate = trigEffectData.debuff_hit + entity.attr[AE.add_debuff_rate] - target.attr[AE.add_debuff_dodge_rate]
			rate = rate * BattleDamageCompute:getRaceRestraint(entity,target)--元素属性克制加成
			return CheckProbabilityEvent(rate)
		end
	end

	return true	
end

function ComponentCreator:checkIsNeedCreate_ImmediateEffect(comId,target)
	--使用小技能进行反击的情况，身处异常状态或者正在使用技能的时候不触发。
	if comId == 83035 then
		if target.fsm.currentState.isSkill or target.fsm.currentState.stateEnum == StateEnum.Idling
		or target.fsm.currentState.stateEnum == StateEnum.UnusualCondition then
			return false
		end
	end
	return true
end

function ComponentCreator:createCom_Buff(comId,level,target,option)
	local buffType = self:getBuffType(comId,level)
	if buffType == nil then
		return
	end

	local com
	if buffType == 1 then
		com = Com_B_AttributeUp.new(comId,level,target,option)
	elseif buffType == 2 then
		com = Com_B_SpecialState.new(comId,level,target,option)
	elseif buffType == 3 then
		com = Com_B_HPRecover.new(comId,level,target,option)
	elseif buffType == 4 then
		com = Com_B_LifeShield.new(comId,level,target,option)
	elseif buffType == 5 then
		com = Com_B_NumShield.new(comId,level,target,option)
	elseif buffType == 6 then
		com = Com_B_AbnormalShield.new(comId,level,target,option)
	elseif buffType == 7 then
		com = Com_B_ReduceDmg.new(comId,level,target,option)
	elseif buffType == 8 then
		com = Com_B_BaTiNumShield.new(comId,level,target,option)
	end

	if com then
		target.componentManager:addCom(com)
	end
end

function ComponentCreator:createCom_Debuff(comId,level,target,option)
	local debuffType = self:getDebuffType(comId)
	if debuffType == nil then
		return
	end

	if debuffType == 1 then
		com = Com_D_AttributeDown.new(comId,level,target,option)
	elseif debuffType == 2 then
		com = Com_D_SpecialState.new(comId,level,target,option)
	elseif debuffType == 3 then
		option.attacker = skillOwner
		com = Com_D_Poison.new(comId,level,target,option)
	elseif debuffType == 4 then
		com = Com_D_RelatedToBoss.new(comId,level,target,option)
	elseif debuffType == 5 then
		com = Com_D_Temptation.new(comId,level,target,option)
	elseif debuffType == 6 then
		com = Com_D_Vertigo.new(comId,level,target,option)
	end

	if com then
		target.componentManager:addCom(com)	
	end

	return com
end

--不走管理器了，直接在这里生效
function ComponentCreator:createCom_ImmediateEffect(comId,level,target,option)
	local com = Com_ImmediateEffect.new(comId,level,target,option)
	com:takeEffect(true)
end

--使失效，针对随触发器失效的情况。
function ComponentCreator:removeCom_ImmediateEffect(comId,level,target,option)
	local com = Com_ImmediateEffect.new(comId,level,target,option)
	com:takeEffect(false)
end

function ComponentCreator:getBuffType(comId,lv)
	--不再使用的comId
	if comId == 81045 then
		return nil
	end

	--每X秒回血
	if comId == 81031 or comId == 81054 or comId == 81070 or comId == 81301 then
		return Com_BuffEnum.HPRecover
	--生命护盾
	elseif comId == 81033 then
		return Com_BuffEnum.LifeShield
	--次数护盾
	elseif comId == 81032 then
		return Com_BuffEnum.NumShield
	--异常护盾
	elseif comId == 81034 then
		return Com_BuffEnum.AbnormalShield
	--格挡护盾
	elseif comId == 81052 then
		return Com_BuffEnum.ReduceDmg
	--霸体次数护盾
	elseif comId == 81067 then
		return Com_BuffEnum.BaTiNumShield
	--特殊状态
	elseif comId == 81036 or comId == 81037 or comId == 81040 or comId == 81043 
	or comId == 81044 or comId == 81042  or (comId == 81050 and lv ~= 4)  
	or (comId == 81024 and lv >30) or comId == 81055 or comId == 81038 
	or comId == 81997 or comId == 81068 then
		return Com_BuffEnum.SpecialState
	--属性上升(所有跟新规则有关的都是属性相关的)
	else
		return Com_BuffEnum.AttributeUp
	end
end

function ComponentCreator:getDebuffType(comId)
	--每X秒减血（毒）
	if (comId >=82019 and comId <= 82024) or (comId >=82044 and comId <=82048) then
		return Com_DebuffEnum.Poison
	--麻痹和眩晕（其实都是眩晕）
	elseif comId == 82029 or comId == 82030 then
		return Com_DebuffEnum.Vertigo
	--针对boss的
	elseif comId == 82027 or comId == 82031 or comId == 82032 then
		return Com_DebuffEnum.RelatedToBoss
	--魅惑
	elseif comId == 82028 then
		return Com_DebuffEnum.Temptation
	--特殊标识，只是一个标识，用于被引爆或者被检测
	elseif comId == 82033 or comId == 82994 then
		return Com_DebuffEnum.SpecialState
	--属性下降
	else
		return Com_DebuffEnum.AttributeDown
	end
end

--创建团战buff，一定是针对我方全体
function ComponentCreator:createMultiBuff(buffId,level)
	for k,target in pairs(G_Roles) do
		if not target.isDead  then
			self:createCom_Buff(buffId,level,target)
		end
	end	
end

--创建团战debuff，一定是针对boss
function ComponentCreator:createMultiDebuff(debuffId,level)
	if debuffId == 81050 or debuffId == 81055 then
		self:createCom_Buff(debuffId,level,G_Monsters[1])
		return
	end

	local debuffType = self:getDebuffType(debuffId)
	if debuffType == nil then
		return
	end

	local com
	if debuffType == 1 then
		com = Com_D_AttributeDown.new(debuffId,level,G_Monsters[1])
	elseif debuffType == 2 then
		com = Com_D_SpecialState.new(debuffId,level,G_Monsters[1])
	elseif debuffType == 3 then
		com = Com_D_Poison.new(debuffId,level,G_Monsters[1])
	elseif debuffType == 4 then
		com = Com_D_RelatedToBoss.new(debuffId,level,G_Monsters[1])
	elseif debuffType == 5 then
		com = Com_D_Temptation.new(debuffId,level,G_Monsters[1])
	elseif debuffType == 6 then
		com = Com_D_Vertigo.new(debuffId,level,G_Monsters[1])
	end

	if com then
		G_Monsters[1].componentManager:addCom(com)
	end
end

--发送团战buff
function ComponentCreator:sendMultiBuff(comId,lv)
	if comId == 81003 then
		local data = {}
		data.buff_id = comId
		data.buff_lv = lv
		data.buff_target = 1
		table.insert(BattleRuntimeInfo.msgData.buff_list,data)
	end	
end

--发送团战debuff
function ComponentCreator:sendMultiDeBuff(comId,lv)
	local levelInRuntimeInfo = BattleRuntimeInfo.sharedBossDebuff[comId]
	if not levelInRuntimeInfo or (levelInRuntimeInfo < lv) then
		local data = {}
		data.buff_id = comId
		data.buff_lv = lv
		data.buff_target = 0
		table.insert(BattleRuntimeInfo.msgData.buff_list,data)
	end
end

function ComponentCreator:getTarget_NewRule(entity,str)
	local num = tonumber(string.sub(str,1,1))
	local targetList = {}
	if num == 1 then--1 00 00 00 00 00  种族，势力，性别，属性，职业。支持多选。
		self:setTarget_NewRule_1(entity,str,targetList)
	elseif num == 2 then --2 0 0 0 0 0 0 0 0 血量 防御 攻击 暴击 爆伤 攻速 血量上限 移动速度。0为不使用 1为最大值，2为最小值。只支持单选。
		self:setTarget_NewRule_2(entity,str,targetList)
	elseif num == 3 then --随机。3 00 00。队伍（0为全体，1为我方队伍，2为敌方队伍） 数量
		self:setTarget_NewRule_3(entity,str,targetList)
	elseif num == 4 then--判定目标身上是否有特定的com
		self:setTarget_NewRule_4(entity,str,targetList)
	end	
	return targetList
end

--------------------------------------------1级私有函数----------------------------------------
--1 00 00 00 00 00  种族，势力，性别，属性，职业。支持多选。
function ComponentCreator:setTarget_NewRule_1(entity,str,targetList)
	local num1 = tonumber(string.sub(str,2,3))
	local num2 = tonumber(string.sub(str,4,5))
	local num3 = tonumber(string.sub(str,6,7))
	local num4 = tonumber(string.sub(str,8,9))
	local num5 = tonumber(string.sub(str,10,11))

	for k,v in pairs(entity.teammateList) do
		if not v.isDead then
			local isFit = true
			if num1 ~= 0 and v.data.race ~= num1 then
				isFit = false
			elseif num2 ~= 0 and v.data.power_name ~= num2 then
				isFit = false
			elseif num3 ~= 0 and v.data.sex ~= num3 then
				isFit = false
			elseif num4 ~= 0 and v.data.atb ~= num4 then
				isFit = false
			elseif num5 ~= 0 and v.data.job ~= num5 then
				isFit = false
			end
			if isFit then
				table.insert(targetList,v)
			end
		end
	end
end

--2 0 0 0 0 0 0 0 0 血量 防御 攻击 暴击率 暴伤 攻速 血量上限 移动速度。0为不使用 1为最大值，2为最小值。只支持单选。
function ComponentCreator:setTarget_NewRule_2(entity,str,targetList)
	if entity.entityType == 2 then
		return
	end

	local function getTypeValue()
		for i = 2,9 do
			local ret = tonumber(string.sub(str,i,i))
			if ret ~= 0 then
				return ret,i-1
			end
		end
	end

	local sortValue,typeValue = getTypeValue()
	if not sortValue then
		return
	end

	local roleList = {}
	for k,v in pairs(entity.teammateList) do
		if not v.isDead then
			table.insert(roleList,v)
		end
	end

	local length = #roleList
	if length == 0 then
		return
	end

	table.sort(roleList,function(a,b)
		if typeValue == 1 then
			return a.attr[AE.hp] > b.attr[AE.hp]
		elseif typeValue == 2 then
			return a.attributeManager:getDefence() > b.attributeManager:getDefence()
		elseif typeValue == 3 then
			return a.attributeManager:getAttack() > b.attributeManager:getAttack()
		elseif typeValue == 4 then
			return a.attr[AE.crit_rate] + a.attr[AE.add_crit_rate] > b.attr[AE.crit_rate] + b.attr[AE.add_crit_rate]
		elseif typeValue == 5 then
			return a.attr[AE.crit_multiplying] + a.attr[AE.add_dmg_crit] > b.attr[AE.crit_multiplying] + b.attr[AE.add_dmg_crit]
		elseif typeValue == 6 then
			return a.attributeManager:getAtkInterval() < b.attributeManager:getAtkInterval()
		elseif typeValue == 7 then
			return a.attr[AE.hp_max] > b.attr[AE.hp_max]
		elseif typeValue == 8 then
			return a.data.speed > b.data.speed
		end
	end)

	--属性值最大的角色
	if sortValue == 1 then
		local role = roleList[1]
		if role then
			table.insert(targetList,role)
		end
	--属性值最小的角色
	elseif sortValue == 2 then
		local role = roleList[length]
		if role then
			table.insert(targetList,role)
		end
	end
end

--随机目标。3 00 00 队伍 数量
function ComponentCreator:setTarget_NewRule_3(entity,str,targetList)
	local num1 = tonumber(string.sub(str,2,3))
	local num2 = tonumber(string.sub(str,4,5))

	local potentialList = {} 
	if num1 == 1 then
		for k,v in pairs(entity.teammateList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end
	elseif num1 == 2 then
		for k,v in pairs(entity.enemyList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end
	else
		for k,v in pairs(entity.teammateList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end
		for k,v in pairs(entity.enemyList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end		
	end


	if num2 >= #potentialList then
		for k,v in pairs(potentialList) do
			table.insert(targetList,v)
		end		
	else
		local function getOneRandomTarget()
			local length = #potentialList
			local randomValue = GetRandomBetweenAB(1,length)
			local randomTarget = potentialList[randomValue]
			table.remove(potentialList,randomValue)
			return randomTarget
		end

		for i = 1,num2 do
			local oneRandomTarget = getOneRandomTarget()
			if oneRandomTarget then
				table.insert(targetList,oneRandomTarget)
			end
		end
	end
end

--随机目标。4 00000 0 0 0 四个参数分别是comId 目标 com类型1 com类型2
--目标：0全体1我方2敌方 
--com类型1：1buff2debuff com类型2 1不可驱散2可驱散
--comId com类型1 com类型2只能三选一。另外两个必须配成0
function ComponentCreator:setTarget_NewRule_4(entity,str,targetList)
	local num1 = tonumber(string.sub(str,2,6))
	local num2 = tonumber(string.sub(str,7,7))
	local num3 = tonumber(string.sub(str,8,8))	
	local num4 = tonumber(string.sub(str,9,9))		

	local potentialList = {} 
	if num2 == 1 then
		for k,v in pairs(entity.teammateList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end
	elseif num2 == 2 then
		for k,v in pairs(entity.enemyList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end
	else
		for k,v in pairs(entity.teammateList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end
		for k,v in pairs(entity.enemyList) do
			if not v.isDead then
				table.insert(potentialList,v)
			end
		end		
	end

	--根据某个具体的comId
	if num1 ~=0 then
		for k,v in ipairs(potentialList) do
			if v.componentManager:getComById(num1) then
				table.insert(targetList,v)
			end
		end
	--根据是buff还是debuff
	elseif num3 ~= 0 then
		if num3 == 1 then
			for k,v in ipairs(potentialList) do
				if v.componentManager:checkIsBuffExist() then
					table.insert(targetList,v)
				end
			end			
		else
			for k,v in ipairs(potentialList) do
				if v.componentManager:checkIsDebuffExist() then
					table.insert(targetList,v)
				end
			end
		end
	--根据是否可驱散
	elseif num4 ~= 0 then
		--不可驱散类
		if num4 == 1 then
			for k,v in ipairs(potentialList) do
				if v.componentManager:checkExist_CanNotBeDispel() then
					table.insert(targetList,v)
				end
			end			
		--可驱散类
		else
			for k,v in ipairs(potentialList) do
				if v.componentManager:checkExist_CanBeDispel() then
					table.insert(targetList,v)
				end
			end
		end
	end
end
