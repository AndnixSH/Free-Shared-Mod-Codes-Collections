--[[
	ShareRoleLayer.lua

]]
require "BasicLayer"

ShareRoleLayer = class("ShareRoleLayer",BasicLayer)
ShareRoleLayer.__index = ShareRoleLayer
ShareRoleLayer.lClass = 3

 ---1 QQ、2 微信、3 朋友圈
ShareType = {}
ShareType.QQ = 1
ShareType.WX = 2
ShareType.WXF = 3

function ShareRoleLayer:init()
    self._rootCSbNode = nil 
    self._shareType = nil 
    self.sManager = self.rData["sManager"]
    self._roleID = self.rData["rcvData"]["heroID"]

    local node = cc.CSLoader:createNode("ShareRoleUI.csb")
    self.uiLayer:addChild(node,0,1)
   	self._rootCSbNode = node:getChildByTag(101)
   	self._btnRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn_root")
    self:initViewUI()
    self:initBtn()
        --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end

function ShareRoleLayer:initViewUI()
	local roleNameImg = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"img_title")
	local roleLiHuiImg = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"img_role")
	if roleLiHuiImg then 
		roleLiHuiImg:setUnifySizeEnabled(true)
		roleLiHuiImg:loadTexture(hero[self._roleID].hero_vcw_icon)
	end 
	if roleNameImg then 
		roleNameImg:setUnifySizeEnabled(true)
		roleNameImg:loadTexture(hero[self._roleID].role_share_img)
	end 
end

function ShareRoleLayer:initBtn()
    local backBtn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:returnBack()
        end
    end)
    local btnKeys = {"btn_QQ","btn_WX","btn_WXF"}
    for i=1,#btnKeys do
	    local btn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,btnKeys[i])
	    if btn then 
            if i==1 then 
               btn:setVisible(false) 
            else    
    		    btn:setEffectType(3)
    		    btn:addTouchEventListener(function(sender,eventType)
    		        if eventType == ccui.TouchEventType.ended then
    		            self:dealShareEvent(i)
    		        end
    		    end)
            end
	    end
    end
end

function ShareRoleLayer:dealShareEvent(shareType)
    --检测对应软件安装没安装
end

function ShareRoleLayer:toCaptureImg()
    local fileName = "shareImg.png"
    local function afterCaptured(succeed, outputFile)
        if succeed then
            local shareFile = cc.FileUtils:getInstance():getWritablePath()..fileName
            if cc.FileUtils:getInstance():isFileExist(shareFile) then 
            	self:toShareImg(shareFile)
            end
        else
            MsgManager:showSimpMsg(UITool.ToLocalization("截图分享失败，请重试"))
        end
        self:setBtnRootState(true)
    end
    if cc.Director:getInstance():getTextureCache():getTextureForKey(fileName) then 
    	cc.Director:getInstance():getTextureCache():removeTextureForKey(fileName)
    end 
    cc.utils:captureScreen(afterCaptured, fileName)
end

function ShareRoleLayer:toShareImg(imgPath)
    --1 成功 2失败 3取消
    --如果出现特殊情况，可以在发送分享之前把关闭按钮显示出来，处理玩家卡死在当前界面的bug
    --说明 这个地方是 如果各个渠道都是按照正常的申请appid，能够正常回调，否则没戏
    --todo所以按钮的显示，可以放到这里
end

function ShareRoleLayer:setBtnRootState(_isVisible)
	if self._btnRoot then 
		self._btnRoot:setVisible(_isVisible)
	end 
end

--返回
function ShareRoleLayer:returnBack()
    self._rootCSbNode = nil 
    self._shareType = nil
    self.exist = false
    self:clearEx()
end

function ShareRoleLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ShareRoleLayer:create(rData)
     local layer = ShareRoleLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
