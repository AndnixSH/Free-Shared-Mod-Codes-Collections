
--[[
    ObbDownloader.lua
 	obb下载器
    obb包，只使用热更新的下载器，不使用版本控制，是否下载只取决于本地是否存在obb包
    需测试：
    直接替换安装包、卸载之后再次安装包、客户端升级、下载一半强制退出等
]]
require "UpdateLayer"
require "DeviceManager"
require "UITool" 
require "NetErrorManager"
require "ScreenFitMainLayer"
require "ObbHelper"

--配置文件所在位置
local manifest = "obb_project.manifest"

ObbDownloader = class("ObbDownloader")
ObbDownloader.__index = ObbDownloader

local OBB_ROOT_PATH = ObbHelper:getObbFilepath().."/" 

function  ObbDownloader:getVersion()
   return self._versionStrValue
end
--清理可写路径，清理文件缓存
function ObbDownloader:initObbDownloader()
	cc.FileUtils:getInstance():purgeCachedEntries() 
	--临时重置可目录
    local fileUtils = cc.FileUtils:getInstance()
    local tempPath = string.sub(OBB_ROOT_PATH,1,string.len(OBB_ROOT_PATH)-1).."_temp/"
    FileUtilsEx:getInstance():deleteDir(OBB_ROOT_PATH)
    self:clearTempManifest(tempPath)
    
    local searchPaths = {} 
    fileUtils:setSearchPaths(searchPaths)
    --将obb路径临时设置为第一位
    cc.FileUtils:getInstance():addSearchPath(OBB_ROOT_PATH,true)
    cc.FileUtils:getInstance():addSearchPath(OBB_ROOT_PATH.."res/Manifests")
    cc.FileUtils:getInstance():addSearchPath(OBB_ROOT_PATH.."res")
    cc.FileUtils:getInstance():addSearchPath(tempPath)

    searchPaths = {
    	"assets/","assets/1","src","res","src/ui","src/sdk",
    	"src/cocos","src/data","res/hd","res/hd/Resources/","res/Manifests","res/testHero",
    	"res/uifile","music","voice"
    }

    for i=1,#searchPaths do
    	cc.FileUtils:getInstance():addSearchPath(searchPaths[i])
    end

	self:checkUpdate()
end
--清理缓存，处理卸载重装等无法下载情况
function ObbDownloader:clearTempManifest(rootPath)
    -- body
    local fileUtils = cc.FileUtils:getInstance()
    local n = {
        "obb_project.manifest","project.manifest.temp","version.manifest","project.manifest.downtemp"
    }
    for i=1,#n do
       ObbHelper:deleteFileEx(rootPath..n[i])
    end
end
--检测版本
function ObbDownloader:checkUpdate()
 
    print("checkUpdate obb")
    self._assetsManager = nil 
    self._listener = nil
    self._checklistener = nil
    self._checkManifestlistener = nil
    self._updateLayer = nil
    self._versionStrValue = "1.0.0"
    self.needUpdate = false
    self.loadResSchedulerEntry = nil;
    --资源包大小
    self._resSize = 0;
    --是否已经弹出下载提示框
    self._bHasPopDownLoadTip = false;

    local sData = {}
    sData["sManager"] = self;
    self._updateLayer = UpdateLayer:create(sData)
    self._updateLayer:setVersion(self._versionStrValue)
    local scene = cc.Scene:create()
    self.rootLayer = cc.Layer:create();
    local rootPos = ScreenManager:getInstance():getRootPoint();
    self.rootLayer:setPosition(rootPos.x,rootPos.y);
    self.rootLayer:setName("root_layer");
    scene:addChild(self.rootLayer)

     --添加屏幕适配层
   local screenfitLayer = ScreenFitMainLayer:create();
   self.rootLayer:addChild(screenfitLayer, 100000);

    self.rootLayer:addChild(self._updateLayer.uiLayer)

    --scene:addChild(self._updateLayer.uiLayer)
    cc.Director:getInstance():replaceScene(scene)
    self._updateLayer.uiLayer:setVisible(true)

    print("ObbDownloader:checkUpdate")
    dump(OBB_ROOT_PATH)
	self._assetsManager = cc.AssetsManagerEx:create(manifest, OBB_ROOT_PATH)
    if self._assetsManager.setMd5VerifyCallback ~= nil then
        print("self._assetsManager.setMd5VerifyCallback ~= nil ")
        self._assetsManager:setMd5VerifyCallback(false)
    end
    --设置自动加载资源为false
    self._assetsManager:setAutoDownLoadResource(false)

    self._assetsManager:retain() 
    --本地版本号
    self._versionStrValue = self._assetsManager:getLocalManifest():getVersion() or "1.0.0"
    self._updateLayer:setVersion(self._versionStrValue)

    ---开始更新
    self:toShowUpdateLayer()

    --开启网络检测
    NetErrorManager:getInstance():openCheckNet();
     
end

--重置
function ObbDownloader:reset( )
    -- body
    self:resetGameAssetManager() 
end

function ObbDownloader:resetGameAssetManager()
    -- body
    if self._assetsManager ~= nil then
        self._assetsManager:release()
        self._assetsManager = nil 
    end 
    if self._checklistener ~= nil then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._checklistener)
        self._checklistener = nil 
    end 

     if self._checkManifestlistener ~= nil then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._checkManifestlistener)
        self._checkManifestlistener = nil 
    end 
    if self._listener ~= nil then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._listener)
        self._listener = nil
    end 
    if self._updateLayer and self._updateLayer.uiLayer then
        self._updateLayer.uiLayer:stopAllActions()
    end
    
end
-- 修理客户端
function ObbDownloader:dealRepari()
    --dump(self,  "updatelayer")
    self:reset();
    local write =  cc.FileUtils:getInstance():getWritablePath();
    FileUtilsEx:getInstance():deleteDir(write)
    cc.FileUtils:getInstance():createDirectory(write) 
    cc.FileUtils:getInstance():purgeCachedEntries() 

    cc.UserDefault:getInstance():setStringForKey("IS_TIP_BORN_STRING", "")
    XBConfigManager:getInstance():setGlobalBooleanByKey("HAS_DOWN_BASE",false) 

    self:checkUpdate()
end

--资源更新UI界面
function ObbDownloader:toShowUpdateLayer()
    print("ObbDownloader:toShowUpdateLayer()")
    if self._listener ~= nil then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._listener)
        self._listener = nil 
    end
    self:getVersionDate()
end
--检测更新
function ObbDownloader:getVersionDate()
    print("ObbDownloader:getVersionDate")
     --initUI
    if not self._assetsManager:getLocalManifest():isLoaded() then
        print("Fail to update assets, step skipped.")
    else
        ---下载失败重连
        local function retryCheck()
           local function TimeFunc()
                print("ObbDownloader:getVersionDate TimeFunc");
                self._updateLayer:setDownError("Reconnect...")
                self._assetsManager:checkUpdate()
            end
            local delay    = CCDelayTime:create(3.0)
            local callfunc = CCCallFunc:create(TimeFunc)
            local sequence = cc.Sequence:create(delay, callfunc)
            --self._updateLayer.uiLayer:runAction(sequence)
            local action   = CCRepeatForever:create(sequence)
            self._updateLayer.uiLayer:runAction(action)
        end

          --检测是否已经进行不断检测运行，如果没有运行，就让他运行，否则不做处理
        local retrying = false;
        local function checkAndRetryCheck()
            if not retrying then
                retrying = true
                retryCheck()
            end 
        end

        local function stopRetryCheck( )
            -- body
            retrying = false
            self._updateLayer.uiLayer:stopAllActions()
        end 

        local function onUpdateEvent(event)
            local eventCode = event:getEventCode()
            if eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_NO_LOCAL_MANIFEST then
                self._updateLayer:setDownError("Local configuration file error")
                checkAndRetryCheck()
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_DOWNLOAD_MANIFEST or 
                   eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_PARSE_MANIFEST then
                self._updateLayer:setDownError("Download failed. Please check the network")
                checkAndRetryCheck()
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ALREADY_UP_TO_DATE or 
                   eventCode == cc.EventAssetsManagerEx.EventCode.UPDATE_FINISHED then
                    stopRetryCheck( )
                    self._updateLayer:updateObbProgress(100,100)
                    self:exitUpdate(false) 
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_UPDATING then
                    print("Asset ", event:getAssetId(), ", ", event:getMessage())
                    checkAndRetryCheck()
                    self._updateLayer:setDownError(".")
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.NEW_VERSION_FOUND then  
                cc.Director:getInstance():getEventDispatcher():removeEventListener(self._checklistener)
                self._checklistener = nil
                --todo有新版本，判断是不是要下载
                --self:checkWifi()
                stopRetryCheck( )
                self:checkManifest();

            end
        end   
        self._checklistener = cc.EventListenerAssetsManagerEx:create(self._assetsManager, onUpdateEvent)
        cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self._checklistener, 1)
        self._assetsManager:checkUpdate()
    end
end

--检测manifest文件
function ObbDownloader:checkManifest()

     --initUI
    if not self._assetsManager:getLocalManifest():isLoaded() then
        print("Fail to update assets, step skipped.")
    else
        ---下载失败重连
        local function retryCheck()
            print("ObbDownloader:checkManifest retryCheck");
           local function TimeFunc()
                print("ObbDownloader:checkManifest TimeFunc");
                self._updateLayer:setDownError("Reconnect...")
                self._assetsManager:update()
            end
            local delay    = CCDelayTime:create(3.0)
            local callfunc = CCCallFunc:create(TimeFunc)
            local sequence = cc.Sequence:create(delay, callfunc)
            --self._updateLayer.uiLayer:runAction(sequence)
            local action   = CCRepeatForever:create(sequence)
            self._updateLayer.uiLayer:runAction(action)
        end

          --检测是否已经进行不断检测运行，如果没有运行，就让他运行，否则不做处理
        local retrying = false;
        local function checkAndRetryCheck()
            if not retrying then
                retrying = true
                retryCheck()
            end 
        end

        local function stopRetryCheck( )
            -- body
            retrying = false
            self._updateLayer.uiLayer:stopAllActions()
        end 

        local function onUpdateEvent(event)
            local eventCode = event:getEventCode()
            if eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_NO_LOCAL_MANIFEST then
                self._updateLayer:setDownError("Local configuration file error")
                checkAndRetryCheck()
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_DOWNLOAD_MANIFEST or 
                   eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_PARSE_MANIFEST then
                self._updateLayer:setDownError("Download failed. Please check the network")
                checkAndRetryCheck()
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ALREADY_UP_TO_DATE or 
                eventCode == cc.EventAssetsManagerEx.EventCode.UPDATE_FINISHED then
                stopRetryCheck();
                self._updateLayer:updateObbProgress(100,100)
                self:exitUpdate(false) 
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_UPDATING then
                print("Asset ", event:getAssetId(), ", ", event:getMessage())
                checkAndRetryCheck()
                self._updateLayer:setDownError(".")
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.NEW_VERSION_FOUND then  
                stopRetryCheck();
                cc.Director:getInstance():getEventDispatcher():removeEventListener(self._checkManifestlistener)
                self._checkManifestlistener = nil
                --todo有新版本，判断是不是要下载
                --self:checkWifi()
                local resSize  = self._assetsManager:getDownLoadSize()
                self._resSize = resSize;
                print("update resource file Size = "..resSize)

                self:tipDownLoad("res");

            end
        end   
        self._checkManifestlistener = cc.EventListenerAssetsManagerEx:create(self._assetsManager, onUpdateEvent)
        cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self._checkManifestlistener, 1)
        self._assetsManager:update()
        --self._assetsManager:checkUpdate()
    end
end

--提示是否要下载
function ObbDownloader:tipDownLoad(resType)
    self._bHasPopDownLoadTip = true;
     --注册提示确认更新回调
    local function confirmFunc()
        print("confirm download")
        UITool.delayTask(0.1,function()
            self:checkWifi(resType)
                
        end) 
        
    end

    local fileSize = self._resSize
    fileSize = math.max(fileSize, 1)

    print("total resource file Size = "..tostring(fileSize))
    local minChangeValue = 1024*1024
    local rate = 1024*1024;
    local fileSizeStr = math.ceil(fileSize/1024).."KB"
    if fileSize >= minChangeValue then
        fileSizeStr = math.ceil(fileSize/(1024*1024)).."MB";
    end

     --计算需求的空间，如果机身空间不够，提示玩家，删除空间方便热更新
    local needSize = fileSize/(1024*1024)
    if not DeviceManager:checkEnoughSDAvailableSize(needSize) then
   
        -- local msg = "매모리 부족합니다."..fileSizeStr.."가 필요합니다"
        local str1 = "内存不足，需要%s的空间"
        self._updateLayer:showNotEnoughSize(string.format(UITool.ToLocalization(str1),fileSizeStr))
        return;
    end

    local str2 = "补丁的大小为%s，是否进行下载"
    self._updateLayer:showTipIfUpdate(string.format(UITool.ToLocalization(str2),fileSizeStr), confirmFunc)
end

function ObbDownloader:checkWifi(resType)
    print("checkWifi")
    local  function startDownLoad()
        -- body
        if resType == "res" then
            self:startUpDate() 
        else 
            self:updateLanguage() 
        end
    end 
    -- body
    local  network = SDKManager:getInstance():getNetworkType()
    if network == "wifi" then 
         --self:startUpDate() 
         startDownLoad();
    else 
        print("showNotWiFiView")
        local function confirmFunc()
            dump("start  confirmFunc ")
            --self:startUpDate() 
            startDownLoad();
        end
        local function cancleFunc()
            -- body
            os.exit()
        end
        self._updateLayer:showNotWiFiView(confirmFunc, cancleFunc)
    end 
end

--开始更新
function ObbDownloader:startUpDate()
	 --initUI
    print("ObbDownloader:startUpDate")
	if not self._assetsManager:getLocalManifest():isLoaded() then
        print("Fail to update assets, step skipped.")
    else
                ---下载失败重连
        local function retryUpdate()
           local function TimeFunc()
                if self._assetsManager then 
                    self._assetsManager:update()
                end    
            end
            local delay    = CCDelayTime:create(3.0)
            local callfunc = CCCallFunc:create(TimeFunc)
            local sequence = cc.Sequence:create(delay, callfunc)
            --self._updateLayer.uiLayer:runAction(sequence)
            local action   = CCRepeatForever:create(sequence)
            self._updateLayer.uiLayer:runAction(action)
        end

    
        local function onUpdateEvent(event)
            local eventCode = event:getEventCode()
            if eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_DOWNLOAD_MANIFEST or --远程资源清单文件下载失败
                eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_PARSE_MANIFEST then --远程配置文件解析失败
                print("Fail to download manifest file, update skipped.")
                print(eventCode)
                --todo 优先级高
                --如果解析失败或者下载失败怎么处理 新下载还是进入游戏
                self._updateLayer:setDownError("Download failed. Please check the network")
                --checkAndRetryCheck()
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.NEW_VERSION_FOUND then  
                print("有新版本.") 
                self._updateLayer.uiLayer:setVisible(true)          
                self.needUpdate = true
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_UPDATING then
                print("下载中出错 ", event:getAssetId(), ", ", event:getMessage())
                print("#########ERROR_UPDATING#### ", event:getAssetId(), ", ", event:getMessage())
                self._updateLayer:setDownError("download error, retry...")
                self._assetsManager:update()
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_DECOMPRESS  then
                print("解压失败 ", event:getAssetId(), ", ", event:getMessage())
                --self._assetsManager:update()
                --self._updateLayer:setDownError("解压失败")
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.UPDATE_PROGRESSION then  
                local assetId = event:getAssetId()
                local percent = event:getPercent()        ---单个文件的下载进度
                local percent2 = event:getPercentByFile() ---总进度
                local strInfo = ""
                if assetId == cc.AssetsManagerExStatic.VERSION_ID then-- --只下载 VERSION_ID  
                    print("down load  VERSION_ID") 
                elseif assetId == cc.AssetsManagerExStatic.MANIFEST_ID then
                    print("down load  MANIFEST_ID")
                else
                    self._updateLayer:updateObbProgress(percent,percent)
                end 
            --elseif eventCode == cc.EventAssetsManagerEx.EventCode.ALREADY_UP_TO_DATE or 
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.UPDATE_FINISHED then
                print("**********下载完成Update finished.")
                self._updateLayer:updateObbProgress(100,100)
                self:exitUpdate(true) 
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ERROR_NO_LOCAL_MANIFEST then  
                 self._updateLayer:setDownError("Local configuration file error")
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.ASSET_UPDATED then 
                
            elseif eventCode == cc.EventAssetsManagerEx.EventCode.UPDATE_FAILED  then
                self._assetsManager:downloadFailedAssets()
       		end
     	end   
        self._listener = cc.EventListenerAssetsManagerEx:create(self._assetsManager, onUpdateEvent)
        cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(self._listener, 1)
        self._assetsManager:startUpdate()
    end
end

--退出更新模块
function ObbDownloader:exitUpdate(isRefresh)
    self:resetGameAssetManager();
    self:finish()
end

function ObbDownloader:finish()
	UITool.delayTask(1.0,function()
         ObbHelper:restartGame()      
    end) 
    self._updateLayer:setDownError("Download success, Restart Game")
end
