--伤害计算
--2018.6.13.
--TODO,为了区分旧的这个文件，可能需要把所有变量名和函数名改名。

BattleDamageCompute = {}

--属性克制计算伤害先关
RACE_RST = 1.25 --克制时伤害加成
NO_RACE_RST = 0.75 --非克制时伤害加成
DEBUFF_RST = 50 --克制异常命中加成
NO_DEBUFF_RST = -30 --非克制异常命中加成

--连击相关
HIT_NUM1 = 49    --连击1阶段需要连击数
HIT_NUM2 = 99   --连击2阶段需要连击数
HIT_NUM3 = 149   --连击3阶段需要连击数
HIT_NUM4 = 199   --连击4阶段需要连击数
HIT_NUM5 = 249  --连击5阶段需要连击数
HIT_NUM6 = 299  --连击5阶段需要连击数
HIT_NUM7 = 349  --连击5阶段需要连击数
HIT_NUM8 = 399  --连击5阶段需要连击数
HIT_NUM9 = 449  --连击5阶段需要连击数
HIT_NUM10 = 499  --连击5阶段需要连击数
HIT_NUM11 = 99999  --连击5阶段需要连击数

ADD_HIT1_DMG = 0 --连击1阶段伤害加成
ADD_HIT2_DMG = 5 --连击2阶段伤害加成
ADD_HIT3_DMG = 10 --连击3阶段伤害加成
ADD_HIT4_DMG = 15 --连击4阶段伤害加成
ADD_HIT5_DMG = 20 --连击5阶段伤害加成
ADD_HIT6_DMG = 25 --连击1阶段伤害加成
ADD_HIT7_DMG = 30 --连击2阶段伤害加成
ADD_HIT8_DMG = 35 --连击3阶段伤害加成
ADD_HIT9_DMG = 40 --连击4阶段伤害加成
ADD_HIT10_DMG = 45 --连击5阶段伤害加成
ADD_HIT11_DMG = 50 --连击5阶段伤害加成

--攻击力 防御力 计算相关
PA_ATK1 = 0.04 --治疗系数1
PA_ATK2 = 0.04 --治疗系数2
PA_PM = 10000  --阶段参数

SA_ATK1 = 0.1 --普通攻击 技能攻击系数1
SA_ATK2 = 0.1 --普通攻击 技能攻击系数2
SA_PM = 15000 --阶段参数

DEF_1 = 1 --防御系数1
DEF_2 = 1 --防御系数2
DEF_PM = 4000 --防御阶段系数

---背水阶段计算
EM_NUM1 = 80 --第1阶段背水触发需要血线
EM_NUM2 = 50 --第2阶段背水触发需要血线
EM_NUM3 = 25 --第4阶段背水触发需要血线
EM_NUM4 = 10 --第4阶段背水触发需要血线
EM_ADD1 = 1  --第1阶段背水攻击力加成效果
EM_ADD2 = 2  --第2阶段背水攻击力加成效果
EM_ADD3 = 3  --第3阶段背水攻击力加成效果
EM_ADD4 = 4  --第4阶段背水攻击力加成效果

--神格技能的攻击力系数
Atk_Coefficient_Princess = 0.1
--计算伤害的浮动系数
Atk_Coefficient_Floating = 30

--获得属性克制攻击力加成。
--元素值。1水2火3风4光5暗
function BattleDamageCompute:getRaceRestraint(attacker,defender)    
    local result = 1;
    local element1 = attacker.attr[AE.element]
    local element2 = defender.attr[AE.element]

    --水克火，火克风，风克水
    if ((element1==1 and element2==2) or (element1==2 and element2==3) or (element1==3 and element2==1)) then
        result = RACE_RST
   
    elseif ((element2==1 and element1==2) or (element2==2 and element1==3) or (element2==3 and element1==1)) then
        result = NO_RACE_RST
    end

    --光暗相互克制。我方克制敌方。
    if (attacker.entityType==1) then
        if((element1==4 and element2==5) or (element1==5 and element2==4)) then
           result = RACE_RST
        end
    else
        if((element2==4 and element1==5) or (element2==5 and element1==4)) then
            result = NO_RACE_RST
        end
    end
    
    return result;
end

--获得异常命中加成
function BattleDamageCompute:getDebuffRate(attacker,defender)
    local rate = self:getRaceRestraint(attacker,defender) 
    local result = 0
    if rate > 1 then
        kz = DeBUFF_RST;
    elseif rate < 1  then
        kz = NO_DEBUFF_RST
    else 
        kz = 0
    end
    return result
end

--获得连击数加成
function BattleDamageCompute:getAddHitDmg(hit)
    local dmg = 0
    if hit > HIT_NUM11 then
		dmg = ADD_HIT11_DMG
    elseif hit > HIT_NUM10 then
		dmg = ADD_HIT11_DMG
    elseif hit > HIT_NUM9 then
		dmg = ADD_HIT10_DMG
    elseif hit > HIT_NUM8 then
		dmg = ADD_HIT9_DMG
    elseif hit > HIT_NUM7 then
		dmg = ADD_HIT8_DMG
    elseif hit > HIT_NUM6 then
		dmg = ADD_HIT7_DMG
    elseif hit > HIT_NUM5 then
		dmg = ADD_HIT6_DMG
    elseif hit > HIT_NUM4 then
		dmg = ADD_HIT5_DMG
    elseif hit > HIT_NUM3 then
		dmg = ADD_HIT4_DMG
    elseif hit > HIT_NUM2 then
		dmg = ADD_HIT3_DMG
    elseif hit > HIT_NUM1 then 
		dmg = ADD_HIT2_DMG
    else 
		dmg = ADD_HIT1_DMG
    end
    return dmg
end

-- 获取治疗攻击力
function BattleDamageCompute:getPastorATK(atk)
    if not atk or atk < 0 then
        atk = 0
    end

    --[[等哪一天PA_ATK1不等于PA_ATK2了再用注释的这部分
    if atk <= PA_PM then
        return atk * PA_ATK1
    else
        return PA_PM*PA_ATK1 + (atk-PA_PM)*PA_ATK2
    end
    ]]
    return atk * PA_ATK1
end

--获取普攻攻击力（伤害计算的时候调用一下，把算好的攻击力带进来得出新的攻击力。其他计算不用，比如攻击力15%的生命护盾）
function BattleDamageCompute:getSoloATK(atk)
    if not atk or atk < 0 then
        atk = 0
    end

    --[[等哪一天SA_ATK1不等于SA_ATK2了再用注释的这部分
    if atk <= SA_PM then
        return atk * SA_ATK1
    else
        return SA_ATK1 * SA_PM + (atk - SA_PM) * SA_ATK2
    end
    ]]
    return atk * SA_ATK1
end

--获取防御系数
function BattleDamageCompute:getDef(defence)
    if defence<0 or defence == nil then
        defence = 0;
    end
    --return 1 - defence*DEF_1/(DEF_PM+defence*DEF_2)暂时不需要DEF_1和DEF_2
    return 1 - defence/(DEF_PM+defence)
end

--防御减伤
--注：两个属性影响减伤。AE.reduce_dmg 和 某具体属性的减伤。
function BattleDamageCompute:getReduceDmg(attacker,defender,dmgType)
    --2019.1.4.新增。对于玩家角色，大招释放期间添加80%减伤。
    local reduce_dmg
    local ae_reduce_dmg
    --真实伤害无视防御力和伤害折断
    if dmgType == 4 then
        ae_reduce_dmg = 0
    else
        ae_reduce_dmg = defender.attr[AE.reduce_dmg]
    end

    if defender.entityType == 1 and defender.fsm.currentState.isSkill and defender.fsm.currentState.skillInfo.isBigSkill then
        reduce_dmg = ae_reduce_dmg + 80
    else
        reduce_dmg = ae_reduce_dmg
    end
    local result = 1 - reduce_dmg/100

    local element = attacker.attr[AE.element]
    local enumValue
    if element == 1 then
        enumValue = AE.add_def_water
    elseif element == 2 then
        enumValue = AE.add_def_fire
    elseif element == 3 then
        enumValue = AE.add_def_wind
    elseif element == 4 then
        enumValue = AE.add_def_light
    else
        enumValue = AE.add_def_dark      
    end

    result = result * (1 - defender.attr[enumValue]/100)

    if result < 0 then
        result = 0
    end

    return result
end

--获取背水攻击力
function BattleDamageCompute:getEMIATK(pe)
    local rATK = 0
    if (pe<=EM_NUM4) then
        rATK = 4
    elseif (pe<=EM_NUM3)then
        rATK = 3
    elseif (pe<=EM_NUM2)then
        rATK = 2
    elseif (pe<=EM_NUM1) then
        rATK = 1;
    end
    return rATK
end

--备注
--[[
真实伤害:无视防御力、无视伤害遮断。 不无视元素属性耐性
固定伤害:无视防御力、无视元素属性耐性、无视伤害遮断、无视格挡护盾。
贯通伤害:无视次数护盾、无视生命护盾、无视无敌、无视格挡护盾。
真实贯通:真实+贯通

各种类型处理流程（按顺序优先级）
0 普通伤害:      无敌 次数护盾 伤害计算(防御力，元素相克) 生命护盾 减伤 格挡护盾
4 真实伤害:      无敌 次数护盾 伤害计算(元素相克) 生命护盾 格挡护盾
5 贯通伤害:      伤害计算(防御力，元素相克）减伤
6 真实贯通伤害:   伤害计算(元素相克)
3 固定伤害:      无敌 次数护盾 伤害计算(无) 生命护盾
]]

--计算最终伤害值。
--@type 1.技能。2.神格技能  3.普通攻击。 
--@dmgType  0.普通伤害  1.治疗  4.真实伤害  5.贯穿伤害  6.真实贯穿              2buffdebuff  3固定伤害
--注：固定伤害只会出现在附加xx固定伤害里、中毒、每秒回血里，这里用不到.debuffdebuff这里也用不到。

function BattleDamageCompute:computeDamage(type,attacker,defender,skillData,hitData,isCrit,dmgType)
    --普攻攻击
    if type == 3 then
        return self:computeDamage_NormalAttack(attacker,defender,hitData,isCrit)
    --治疗。
    --2018.11.9新增。神格技能也可能是给我方全体加血的。
    elseif dmgType == 1 then
        return self:computeDamage_Heal(type,attacker,defender,skillData,hitData)
    --伤害类技能。包括普攻技能和神格技能。
    else
        return self:computeDamage_Skill(type,attacker,defender,skillData,hitData,isCrit,dmgType)
    end
end

--固定伤害的计算，计算完后直接显示，独立于其他伤害计算。
--无敌 次数护盾 伤害计算(无) 生命护盾
--@type 0固定伤害 1毒
function BattleDamageCompute:computeDamage_FixedDmg(dmg,defender,type)
    local d = math.ceil(dmg)
    if d <= 0 then
        return
    end

    --检测无敌
    if defender.componentManager:checkIsWuDi() then
        --飘字，"免疫"
        BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Immune)        
    end

    --生命护盾
    local remainDmg = math.floor(self:checkHPShield(d,defender))
    if remainDmg == 0 then
        --print("固定伤害完全被生命护盾吸收")
        --飘字
        BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Absorb)
    else
        --print("附加固定伤害值：  "..remainDmg)
        self:changeHP(remainDmg,defender)
        --飘字
        if type == 0 then
            BattleDamageDisplay:create(defender:getDamageShowingPos(false),remainDmg,DamageFontType.Normal)
        else
            BattleDamageDisplay:create(defender:getDamageShowingPos(false),remainDmg,DamageFontType.Poison)
        end
    end
end

--获取computeDamage所需的参数。是否命中
--攻击方的黑暗减的命中率，防守方的闪避减的命中率之和。
--只针对造成伤害的情况。
function BattleDamageCompute:isRoquet(attacker,defender)
    if attacker.isPrincess then
        return true
    else
        return CheckProbabilityEvent(attacker.attr[AE.hit_rate] - defender.attr[AE.dodge])
    end
end

--获取computeDamage所需的参数。是否暴击.
function BattleDamageCompute:isCrit(type,attacker,defender,skillData)
    --技能
    if type == 1 then
        return CheckProbabilityEvent(attacker.attr[AE.crit_rate] + attacker.attr[AE.add_crit_rate] + attacker.attr[AE.add_crit_rate_skill] + skillData.skill_crit - defender.attr[AE.crit_resistance])
    --神格
    elseif type == 2 then
        return CheckProbabilityEvent(skillData.skill_crit - defender.attr[AE.crit_resistance])
    --普攻
    else
        return CheckProbabilityEvent(attacker.attr[AE.crit_rate] + attacker.attr[AE.add_crit_rate] - defender.attr[AE.crit_resistance])
    end
end


--获取伤害类型
--return  0.普通伤害  1.治疗  4.真实伤害  5.贯穿伤害  6.真实贯穿              2buffdebuff  3固定伤害
--注：固定伤害只会出现在附加xx固定伤害里、中毒、每秒回血里，这里用不到.debuffdebuff这里也用不到。
function BattleDamageCompute:getDmgType(type,skillData,hitData)
    if type == 3 then
        return 0
    elseif #skillData.skill_trig_cdn > 0 then  --skill_trig_cdn里面只会出现83004和83055
        for k1,v1 in pairs(skillData.skill_trig_cdn) do
            local option = {}
            option.affectedEntity = defender
            option.isCrit = isCrit            
            if TriggerChecker:checkTriggerType(v1,attacker,option) then
                for k2,v2 in pairs(v1.skill_trig_effect) do
                    if v2.debuff_id == 83055 then
                        return v2.lv
                    end
                end
            end
        end
    end
    return hitData.hit_type
end

-----------------------------------------1级私有函数-----------------------------------------

--普通攻击.dmgType为0
function BattleDamageCompute:computeDamage_NormalAttack(attacker,defender,hitData,isCrit)
    if not hitData then --忍受不了各种配错表取不到数据了，没数据时暂时不管了
        return
    end

    local atk = self:getSoloATK(attacker.attributeManager:getAttack() * (100 + attacker.attr[AE.add_atk_normal]) * hitData/10000)

    --暴击倍率
    local multiplying_crit
    if isCrit then
        multiplying_crit = (attacker.attr[AE.crit_multiplying] + attacker.attr[AE.add_dmg_crit])/100
    else
        multiplying_crit = 1
    end
    --元素相克
    local restrict = self:getRaceRestraint(attacker,defender)
    --增伤
    local addedDamage = self:getAddedDmg(attacker,defender)
    --随机浮动
    local random = 1 + GetRandomBetweenAB(1,Atk_Coefficient_Floating)/1000  
    --伤害值
    local dmg = math.ceil(atk  * multiplying_crit * random * restrict * addedDamage)
    --灵剑乱舞特殊处理
    if attacker.componentManager.LingJianLuanWu then
        dmg = dmg + 5000
    end

    if dmg == 0 then
        BattleDamageDisplay:create(defender:getDamageShowingPos(false), 0,DamageFontType.Normal)
        return 0
    end

    --生命护盾
    dmg = math.ceil(self:checkHPShield(dmg,defender))
    if dmg == 0 then
        --飘字，“吸收“
        if IsLogMode then
            if attacker.entityType == 1 then
                print("普通伤害完全被生命护盾吸收")
            end
        end         
        BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Absorb)
        return 0
    end

    --是否格挡(注：这个格挡是按百分比减伤，下面的格挡护盾是减固定值的伤害)
    local isBlock = CheckProbabilityEvent(defender.attr[AE.block_rate] - attacker.attr[AE.reduce_block_rate])
    local block = 1
    if isBlock then
        block = 100 - defender.attr[AE.block_value] + attacker.attr[AE.reduce_block_value]
        if block > 100 then
            block = 100
        end
        block = block/100
    end

    --减伤.根据防御力计算出的减伤 * 减伤属性带来的减伤 * 格挡带来的减伤
    local defence = defender.attributeManager:getDefence()
    local reduceDmg = BattleDamageCompute:getDef(defence) * self:getReduceDmg(attacker,defender,0)
    dmg = dmg * reduceDmg * block

    --格挡护盾
    dmg = math.ceil(self:checkReduceDmgShiled(dmg,defender))
    if dmg == 0 then
        if IsLogMode then
            if attacker.entityType == 1 then
                print("普通伤害完全被格挡护盾吸收")
            end
        end         
        --飘字 ，“吸收”
        BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Absorb)
        return 0
    end

    --修改血量
    self:changeHP(dmg,defender)

    --飘字
    if isCrit then
        if isBlock then
            BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.Crit_Block)
        else
            BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.Normal_Crit)
        end
    else
        if isBlock then
            BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.Block)
        else
            BattleDamageDisplay:create(defender:getDamageShowingPos(false), dmg,DamageFontType.Normal)
        end
    end

    if IsLogMode then
        if attacker.entityType == 1 then
            print("普通伤害值：  "..dmg)
        end
    end 

    return dmg
end

--技能（包含常规技能和神格技能） dmgType可能是除治疗和固定伤害外的任意类型。
function BattleDamageCompute:computeDamage_Skill(type,attacker,defender,skillData,hitData,isCrit,dmgType)
    --基础伤害
    local dmg
    if type == 1 then
        dmg = self:getBaseDmg_Skill(attacker,defender,skillData,hitData,isCrit)
    elseif type == 2 then
        dmg = self:getBaseDmg_PrincessSkill(attacker,defender,skillData,hitData,isCrit)
    else
        print("出错了 computeDamage_Skill")
    end

    if dmg == 0 then
        BattleDamageDisplay:create(defender:getDamageShowingPos(false), 0,DamageFontType.Normal)
        return 0
    end

    --生命护盾
    --注：普攻伤害和真实伤害需要考虑生命护盾和格挡护盾
    if dmgType == 0 or dmgType == 4 then
        dmg = math.ceil(self:checkHPShield(dmg,defender))
        if dmg == 0 then
            --飘字，“吸收“
            if IsLogMode then
                if type == 1 and attacker.entityType == 1 then
                    print("技能伤害完全被生命护盾吸收")
                end
            end            
            BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Absorb)
            return 0
        end
    end

    --减伤.
    if dmgType == 0 or dmgType == 5 then
        local defence = defender.attributeManager:getDefence()
        local reduceDmg = BattleDamageCompute:getDef(defence) * self:getReduceDmg(attacker,defender,dmgType)
        dmg = math.ceil(dmg * reduceDmg)
    elseif dmgType == 4 then
        --无视防御力和伤害折断，不无视耐性
        local reduceDmg = self:getReduceDmg(attacker,defender,4)
        dmg = math.ceil(dmg * reduceDmg)
    end

    local isBlock
    --格挡减伤和格挡护盾。注：虽然都叫格挡，但不是一个概念。不过与真实，贯通的伤害的判定是一样的。
    if dmgType == 0 or dmgType == 4 then
        --格挡减伤。
        --是否格挡(注：这个格挡是按百分比减伤，下面的格挡护盾是减固定值的伤害)
        
        --神格技能没有格挡判定
        if type ~= 2 then
            isBlock = CheckProbabilityEvent(defender.attr[AE.block_rate] - attacker.attr[AE.reduce_block_rate])
        end
        if isBlock then
            local block = 100 - defender.attr[AE.block_value] + attacker.attr[AE.reduce_block_value]
            if block > 100 then
                block = 100
            end
            dmg = dmg * block/100
        end        

        --格挡护盾
        dmg = math.ceil(self:checkReduceDmgShiled(dmg,defender))
        if dmg == 0 then
            --飘字，“吸收“
            if IsLogMode then
                if type == 1 and attacker.entityType == 1 then
                    print("技能伤害完全被格挡护盾吸收")
                end
            end            
            BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Absorb)
            return 0
        end
    end

    --修改血量
    self:changeHP(dmg,defender)

    --飘字
    if isCrit then
        if isBlock then
            BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.Crit_Block)
        else
            BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.Normal_Crit)
        end
    else
        if isBlock then
            BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.Block)
        else
            BattleDamageDisplay:create(defender:getDamageShowingPos(false), dmg,DamageFontType.Normal)
        end
    end

    if IsLogMode then
        if type == 1 and attacker.entityType == 1 then
            print("技能伤害值：  "..dmg)
        end
    end 

    return dmg
end

--治疗.dmgType为1
--注：治疗类不计算暴击、属性克制、伤害加成。
--2018.11.9新增。伸个技能也可能是加血的。--@type 1.技能。2.神格技能
function BattleDamageCompute:computeDamage_Heal(type,attacker,defender,skillData,hitData)
    local atk = 0
    if type == 1 then
        atk = self:getPastorATK(attacker.attributeManager:getAttack())
    else
        for k,v in pairs(G_Roles) do
            if not v.isDead then
                atk = atk + v.attributeManager:getAttack()
            end
        end
        atk = math.ceil(atk * Atk_Coefficient_Princess)        
    end
    --技能倍率
    local skillMultiplying = self:getSkillMultiplying(attacker,defender,skillData,hitData,false)    
    --随机浮动
    local random = 1.001 + GetRandomBetweenAB(1,Atk_Coefficient_Floating)/1000    
    --治疗系数
    local healCoefficient = defender.attributeManager:getRecover()/100

    return math.ceil(atk * skillMultiplying * random * healCoefficient)    
end


-----------------------------------------2级私有函数-----------------------------------------

--获取skillData中的技能倍率
function BattleDamageCompute:getSkillMultiplying(attacker,defender,skillData,hitData,isCrit)
    local baseMutli = 1--基础倍率
    if #skillData.skill_trig_cdn > 0 then  --skill_trig_cdn里面只会出现83004和83055
        for k1,v1 in pairs(skillData.skill_trig_cdn) do
            local option = {}
            option.affectedEntity = defender
            option.isCrit = isCrit
            if TriggerChecker:checkTriggerType(v1,attacker,option) then
                for k2,v2 in pairs(v1.skill_trig_effect) do
                    if v2.debuff_id == 83004 then
                        baseMutli = v2.lv
                    end
                end     
            end
        end
    end

    if baseMutli == 1 then
        baseMutli = skillData.skill_dmg
    end

    return baseMutli/100 * hitData.hit_dmg/100
end

--获取增伤
--参考C++中BaseCard::getAddDamage函数
function BattleDamageCompute:getAddedDmg(attacker,defender)
    local addDmg = 100 --增伤的百分比
    --弱点增伤
    if attacker.attr[AE.add_dmg_chimera] > 0 then
        local debuffNum = defender.componentManager:getDebuffNum()
        addDmg = addDmg + attacker.attr[AE.add_dmg_chimera] * debuffNum
    end
    --od增伤
    if defender.isBoss and attacker.attr[AE.add_dmg_od] ~= 0 and defender.attr[AE.state] == 0 then
        addDmg = addDmg + attacker.attr[AE.add_dmg_od]
    end
    --bk增伤
    if defender.isBoss and attacker.attr[AE.add_dmg_bk] ~= 0 and defender.attr[AE.state] == 1 then
        addDmg = addDmg + attacker.attr[AE.add_dmg_bk]
    end
    --属性中的增伤
    addDmg = addDmg + attacker.attr[AE.add_dmg]
    --连击buff增伤(注：前面是加法，这里是乘法)
    addDmg = addDmg * (1 + self:getAddHitDmg(BattleUIManager:getHitNum())/100)

    return addDmg/100
end


--获取普通技能的基础伤害
function BattleDamageCompute:getBaseDmg_Skill(attacker,defender,skillData,hitData,isCrit)
    local atk = self:getSoloATK(attacker.attributeManager:getAttack())
    --技能倍率
    local skillMultiplying = self:getSkillMultiplying(attacker,defender,skillData,hitData,isCrit)    
    --暴击倍率
    local multiplying_crit
    if isCrit then
        multiplying_crit = (attacker.attr[AE.crit_multiplying] + attacker.attr[AE.add_dmg_crit] + attacker.attr[AE.add_dmg_skill_crit])/100
    else
        multiplying_crit = 1
    end
    --随机浮动
    local random = 1 + GetRandomBetweenAB(1,Atk_Coefficient_Floating)/1000    
    --增伤
    local addedSkillDamage = 1 + attacker.attr[AE.add_dmg_skill]/100
    --add_dmg_skill_1和add_dmg_skill_2在设计上不可能同时出现，所以不需要判定目前是正在播放的是1技能还是2技能
    if attacker.attr[AE.add_dmg_skill_1] ~= 0 then
        addedSkillDamage = addedSkillDamage + attacker.attr[AE.add_dmg_skill_1]/100
    elseif attacker.attr[AE.add_dmg_skill_2] ~= 0 then
        addedSkillDamage = addedSkillDamage + attacker.attr[AE.add_dmg_skill_2]/100
    end
    local addedDamage = self:getAddedDmg(attacker,defender) * addedSkillDamage

    --元素相克
    local restrict = self:getRaceRestraint(attacker,defender)
    return math.ceil(atk * skillMultiplying * multiplying_crit * random * addedDamage * restrict)
end

--获取神格技能的基础伤害
function BattleDamageCompute:getBaseDmg_PrincessSkill(attacker,defender,skillData,hitData,isCrit)
    local atk = 0
    for k,v in pairs(G_Roles) do
        if not v.isDead then
            atk = atk + v.attributeManager:getAttack()
        end
    end
    atk = math.ceil(atk * Atk_Coefficient_Princess)
    --技能倍率
    local skillMultiplying = self:getSkillMultiplying(attacker,defender,skillData,hitData,isCrit) 
    --暴击倍率
    local multiplying_crit
    if isCrit then
        multiplying_crit = 1.5
    else
        multiplying_crit = 1
    end
    --随机浮动
    local random = 1.001 + GetRandomBetweenAB(1,Atk_Coefficient_Floating)/1000

    return math.ceil(atk * skillMultiplying * multiplying_crit * random)
end

--生命护盾的处理
function BattleDamageCompute:checkHPShield(dmg,defender)
    if dmg <= 0 then
        return 0
    end
    if defender.componentManager.ShengMingHuDun then
        local remainDmg = defender.componentManager.ShengMingHuDunCom:onAttacked(dmg) --吸收后剩余的伤害值
        if remainDmg < 0 then
            remainDmg = 0
        end
        return remainDmg
    else
        return dmg
    end
end

--格挡护盾的处理(dmg一定不是固定伤害)
function BattleDamageCompute:checkReduceDmgShiled(dmg,defender)
    if dmg < 1 then
        dmg = 1
    end
    if defender.componentManager.GeDangHuDun then
        local remainDamage = dmg - defender.componentManager.GeDangHuDunCom.blockNum
        if remainDamage < 0 then
            remainDamage = 0
        end
        return remainDamage
    else
        return dmg
    end
end

--获取伤害转移后的伤害值，传入最终伤害值
function BattleDamageCompute:getDamageAfterTransfered(dmg,defender)
    if defender.componentManager.ShangHaiZhuanYi then
        local com = defender.componentManager.ShangHaiZhuanYiCom
        local percent = com.comData.effect1/1000
        local str = tostring(com.comData.effect2)
        local temp = ComponentCreator:getTarget_NewRule(com.target,str)
        local targets = {}
        for k,v in pairs(temp) do
            if v ~= defender then
                table.insert(targets,v)
            end
        end

        local targetsNum = #targets

        if targetsNum == 0 then
            defender.componentManager.ShangHaiZhuanYi = false
            defender.componentManager.ShangHaiZhuanYiCom = nil
            return dmg          
        else
            local transferedDmg = math.ceil(dmg * percent)
            percent = percent / targetsNum
            local transferedDmg_each = math.ceil(transferedDmg/targetsNum)
            local remainDamage = dmg - transferedDmg
            for k,v in ipairs(targets) do
                self:computeDamage_FixedDmg(transferedDmg_each,v,0)
            end
            return remainDamage
        end
    else
        return dmg
    end
end

--改变血量
function BattleDamageCompute:changeHP(dmg,defender)
    --伤害转移
    dmg = self:getDamageAfterTransfered(dmg,defender)

    if dmg <= 0 then
        return
    end

    if defender.isBoss then
        defender:onAttacked(dmg)
        if G_STAGE_TYPE == 2 then--如果是多人战，同步下信息
            BattleRuntimeInfo.msgData.dmgForMulti = BattleRuntimeInfo.msgData.dmgForMulti + dmg
        else
            defender.attributeManager:changeAttr(AE.hp,-dmg)
        end
    else
        defender.attributeManager:changeAttr(AE.hp,-dmg)
    end

    --受到的伤害累加，用于受到的累计伤害的判定
    defender.attr[AE.total_dmg] = defender.attr[AE.total_dmg] + dmg

    --受到的伤害累加，用于每受到xx伤害的判定
    defender.attr[AE.total_dmg_2] = defender.attr[AE.total_dmg_2] + dmg

    --队伍受到的总伤害累加
    --defender.teamManager.totalDmg = defender.teamManager.totalDmg + finalDmg 
end