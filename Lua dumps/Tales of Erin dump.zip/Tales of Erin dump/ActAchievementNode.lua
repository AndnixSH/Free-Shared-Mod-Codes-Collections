

ActAchievementNode = class("ActAchievementNode", XUICellView)
ActAchievementNode.CS_FILE_NAME = "ActAchievementNode.csb"
ActAchievementNode.curId    = nil -- 成就Id
ActAchievementNode.ItemType = nil -- 获得物品类型
ActAchievementNode.ItemId   = nil -- 获得物品Id
ActAchievementNode.ItemNum  = nil -- 获得物品数量
ActAchievementNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
    icon = "/s:Panel_1/s:Image_icon"
}

function ActAchievementNode:init(...)
    ActAchievementNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    self.gbStr = "null"
    return self
end
function ActAchievementNode:setActID(id)
   self.act_id = id
end
function ActAchievementNode:setBattle( str )
    -- body
    self.gbStr = str
end
function ActAchievementNode:setIsCYStory(bIsCYStory,cyConfig)
    -- body
    self.bIsCYStory = bIsCYStory
    self.cyConfig = cyConfig
    if self.bIsCYStory then
        local bg = self.PanelList:getChildByName("Image_1")  -- bg
        if bg ~= nil then
            local achievementItemBg = self.cyConfig.achievementItemBg
            if achievementItemBg ~= nil then
                bg:loadTexture(achievementItemBg)
            end
        end
    end
end
function ActAchievementNode:onResetData()
	 print("第一步  执行 ActAchievementNode onResetData")
	 if not self._data then return end
	 print("没有 执行 ActAchievementNode onResetData")
        ----------------获取需要的资源-------------------------------------------------
             local dataT = {
                ["state"] = self._data["state"],         -- 状态 # 0 未完成 1 已完成 2 已领取
                ["num"]   = self._data["reward_num"],    -- 数量
                ["cur_n"] = self._data["curr_times"] ,   -- 次数
                ["max_n"] = self._data["finish_times"],  -- 最大次数
            }
            local rid      = tonumber(self._data["id"])  -- 成就ID
            self.curId     = rid
            print("rid rid == "..rid)
            dataT["id"]    = rid
            if self.gbStr == "alliance" then
                dataT["name"]  = UITool.getUserLanguage(guild_battle_achi_conf[rid]["achi_name"])--guild_battle_achi_conf[rid]["achi_name"]
                dataT["dec"]   = UITool.getUserLanguage(guild_battle_achi_conf[rid]["achi_desc"])--guild_battle_achi_conf[rid]["achi_desc"]
                dataT["icon"]  = guild_battle_achi_conf[rid]["achi_icon"] -- 任务图标
            elseif self.gbStr == "ultimate" then
                dataT["name"]  = UITool.getUserLanguage(challenge_limit_achi_conf[rid]["achi_name"])--challenge_limit_achi_conf[rid]["achi_name"]
                dataT["dec"]   = UITool.getUserLanguage(challenge_limit_achi_conf[rid]["achi_desc"])--challenge_limit_achi_conf[rid]["achi_desc"]
                dataT["icon"]  = challenge_limit_achi_conf[rid]["achi_icon"] -- 任务图标
            else
                local achiTable = string.format("achi_act_%d_conf",tonumber(self.act_id)) 
                local achi_tabel = loadstring("return "..achiTable)() --string转化读取表
                dataT["name"]  = UITool.getUserLanguage(achi_tabel[rid]["achi_name"])--achi_tabel[rid]["achi_name"]
                dataT["dec"]   = UITool.getUserLanguage(achi_tabel[rid]["achi_desc"])--achi_tabel[rid]["achi_desc"]
                dataT["icon"]  = achi_tabel[rid]["achi_icon"] -- 任务图标
            end
            local rwid     = self._data["reward_id"]   -- 道具Id
            local rwType   = self._data["reward_type"] -- 道具类型
            dataT["itemId"]= rwid
            dataT["type"]  = rwType
            self.ItemId    = rwid
            self.ItemType  = rwType
            self.ItemNum   = dataT["num"]
            --print("itemId == "..rwid)
            --print("type  === "..rwType)
            local popr = {}
            if dataT["type"]   == 1 then
                 --dataT["rname"]  = "金币"

                popr = UITool.getItemInfos(1,1)
            elseif dataT["type"] == 2 then
                 --dataT["rname"]  = "星石"
                popr = UITool.getItemInfos(2,1)
            else
                popr = UITool.getItemInfos(dataT["type"],dataT["itemId"])
            end
            local itme_info = self.PanelList
            local tex_name  = itme_info:getChildByName("Text_name")  -- name
            local tex_dec   = itme_info:getChildByName("Text_dec")   -- 描述
            --local icon      = itme_info:getChildByName("Image_icon") -- 物品图片
            self.icon:setUnifySizeEnabled(true)


            local icon_bg   = itme_info:getChildByName("Image_icon_bg")     -- 物品背景
            local icon_fr   = itme_info:getChildByName("Image_icon_form")   -- 物品框
            local iconNum   = itme_info:getChildByName("Text_itemNum") -- 数量
            local bar_1     = itme_info:getChildByName("LoadingBar_1")  --  为完成的
            local Text_f    = itme_info:getChildByName("Text_4")        -- 完成显示CLEAR  未完成 1/2
            local but_get   = itme_info:getChildByName("Button_get")    -- 获取按钮
   
            local imag_h_f  = itme_info:getChildByName("Image_panel")   -- 领取后显示
            ------------------------------显示处理--------------------------------
            imag_h_f:setSwallowTouches(false)
            ----字体描边处理
            tex_name:enableOutline(cc.c4b(0,0,0,255),1)
            tex_dec:enableOutline(cc.c4b(0,0,0,255),1)
            Text_f:enableOutline(cc.c4b(0,0,0,255),1)
            --itme_info:getChildByName("Text_3"):enableOutline(cc.c4b(0,0,0,255),1)

            tex_name:setString(dataT["name"])
            tex_dec:setString(dataT["dec"])
            -- 添加属性
            if icon_fr:getChildByTag(100) then
                icon_fr:removeChildByTag(100)
            end
            if popr[3] ~= "" then 
                    print("popr[3] == "..popr[3])
                  local elementImg = cc.Sprite:create(popr[3])
                  elementImg:setAnchorPoint(cc.p(1,1))
                  elementImg:setPosition(icon_fr:getContentSize().width,icon_fr:getContentSize().height)
                  elementImg:setScale(0.8)

                  icon_fr:addChild(elementImg,100,100)
            elseif popr[3] == "" or popr[3] == nil or popr[3] == 0 then
                  icon_fr:removeChildByTag(100)
            end 
                icon_bg:loadTexture(popr[4])


            --if rwType ~= 16 then -- 称号成就
                self.icon:loadTexture(popr[2])
                icon_fr:loadTexture(popr[1])
              
            --end
              self.icon:setTouchEnabled(true)
  

            iconNum:setString("x"..dataT["num"])
            if dataT["state"] == 0 then -- 状态 # 0 未完成 1 已完成 2 已领取

                but_get:setVisible(false)

                imag_h_f:setVisible(false)
                Text_f:setString( tonumber(dataT["cur_n"]).."/"..tonumber(dataT["max_n"]))
            elseif dataT["state"] == 1 then


                but_get:setVisible(true)

                imag_h_f:setVisible(false)
                Text_f:setString(UITool.ToLocalization("已完成"))
            elseif dataT["state"] == 2 then

                but_get:setVisible(false)
                imag_h_f:setVisible(true)
                Text_f:setString(UITool.ToLocalization("已完成"))
                -------------------
             
            end
            bar_1:setVisible(true)
            --bar_2:setVisible(false)
            print("cur_n == "..tonumber(dataT["cur_n"]))
            print("max_n == "..tonumber(dataT["max_n"]))
            local  percent = math.ceil(tonumber(dataT["cur_n"]) / tonumber(dataT["max_n"]) * 100)
            bar_1:setPercent(percent)
            local function onCickItem( sender,eventType )
                if eventType == ccui.TouchEventType.ended then
                    --print("dataT state == "..dataT["state"]);
                    print("进入了这；i")
                    if dataT["type"] ~= 16 then
                        if dataT["state"] == 1 then
                            print("dataT state 11111 == "..dataT["state"]);
                        else
                            print("dataT state 2222 == "..dataT["state"]);
                            print("dataT state 1112 == "..dataT["type"]);
                            print("dataT state 3333 == "..dataT["itemId"]);
                            MsgManager:showSimpItemInfo(dataT["type"],dataT["itemId"])
                        end
                    else
                        MsgManager:showBaseSpine(dataT["itemId"])
                    end

                end
            end 
            self.icon:addTouchEventListener(onCickItem)    
            --
            if self.bIsCYStory then
                local bg = self.PanelList:getChildByName("Image_1")  -- bg
                if bg ~= nil then
                    local achievementItemBg = self.cyConfig.achievementItemBg
                    if achievementItemBg ~= nil then
                        bg:loadTexture(achievementItemBg)
                    end
                end
            end

    	if self.resetDataEvent then
        	self.resetDataEvent(self)
    	end

end


