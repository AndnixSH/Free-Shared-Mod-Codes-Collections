MessageInfo = {} 
MessageInfo["RoleInfo"] = {
 "装备卸除成功", 
 "自动换装成功" 
}
MessageInfo["Awaken"]   = {
	"突破所需金币不足",
	"突破素材不足",
	"突破已达上限",
}
MessageInfo["Strengthen"] ={
	
	"请选择强化素材",
	"素材移除成功",
	"所选素材带有加蛋的星之卵，是否继续强化"
}
MessageInfo["StrengthenWI"] ={
	
	"素材中含有",
	"级素材",
	"是否继续 ?",
	"icons/role/frame/ggsc_ui_168.png",
}
MessageInfo["EquipList"]  = {
	
	"素材超出",
	"没有素材，快去获得"

}
MessageInfo["Mail"]  = {
	
	"背包已满",
	"没有素材，快去获得"

}
MessageInfo["gongneng"]  = {
	
	"功能暂未开放,敬请期待!"

}