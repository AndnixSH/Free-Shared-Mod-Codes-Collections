-- 多语言切换

language_settings = {}

language_settings[1] = {
    id = 1,
    language_index = "1",  -- 语言索引
    language_name = "137359",  -- 语言名称
    order = "1",  -- 显示排序
    is_show = "1",  -- 是否显示
}

language_settings[2] = {
    id = 2,
    language_index = "2",  -- 语言索引
    language_name = "137360",  -- 语言名称
    order = "3",  -- 显示排序
    is_show = "0",  -- 是否显示
}

language_settings[3] = {
    id = 3,
    language_index = "3",  -- 语言索引
    language_name = "137361",  -- 语言名称
    order = "4",  -- 显示排序
    is_show = "0",  -- 是否显示
}

language_settings[4] = {
    id = 4,
    language_index = "4",  -- 语言索引
    language_name = "137362",  -- 语言名称
    order = "2",  -- 显示排序
    is_show = "1",  -- 是否显示
}

language_settings[5] = {
    id = 5,
    language_index = "5",  -- 语言索引
    language_name = "137363",  -- 语言名称
    order = "5",  -- 显示排序
    is_show = "0",  -- 是否显示
}
