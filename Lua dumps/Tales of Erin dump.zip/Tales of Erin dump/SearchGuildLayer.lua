require "BasicLayer"

SearchGuildLayer = class("SearchGuildLayer",BasicLayer)
SearchGuildLayer.__index = SearchGuildLayer
SearchGuildLayer.lClass = 2 
SearchGuildLayer.GuildName = nil
function SearchGuildLayer:init()
    local node =cc.CSLoader:createNode("SearchGuildLayer.csb")
    self.uiLayer:addChild(node,0,2) 
    self.exist = true
    self:initAttrbute()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    
end
--/*初始化公会的属性*/
function SearchGuildLayer:initAttrbute( ... )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imageBg           = panel:getChildByName("Image_bg")
    --/*取消按钮*/
    local cancleBtn         = imageBg:getChildByName("canButton_cancle")
     --/*确定按钮*/
    local confrimBtn        = imageBg:getChildByName("canButton_confrim")
     --/*搜索北京*/
    local SearchBg          = imageBg:getChildByName("Image_searchName")
    --/*搜索输入框*/
    local SearchE           = SearchBg:getChildByName("Text_1_zhezhao")


    
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if name == "canButton_cancle" then
                self:returnBack()
            elseif name == "canButton_confrim" then
                self:SearchSend()
                --self:returnBack()
            elseif name == "Text_1_zhezhao" then
                self:EGuildName()
            end
        end
    end

    SearchE:addTouchEventListener(touchCallBack)
    cancleBtn:addTouchEventListener(touchCallBack)
    confrimBtn:addTouchEventListener(touchCallBack)


end
function SearchGuildLayer:SearchSend( ... )
    -- body
    if self.GuildName == nil then
        MsgManager:showSimpMsg(UITool.ToLocalization("请输入搜索公会名字"))
        return
    end
    local function reiceSthCallBack(data)
        print("搜索公会")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
             MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

              MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["guild_list"][1] then   -- 有值证明找到了公会
            local sData = {}
            sData["guildData"] = t_data["data"]["guild_list"][1]  -- 1 推荐公会  2 公会排行
            sData["guild_id"]  = t_data["data"]["guild_list"][1]["id"]
            sData["GuildType"] = self.rData["rcvData"]["GuildType"]
            sData["callFunc"]  = self.rData["rcvData"]["callFunc"]
            sData["self"]      = self.rData["rcvData"]["self"]
            SceneManager:toGuildBaseInfoLayer(sData)
            self:returnBack()
        else -- 没有搜索到
            MsgManager:showSimpMsg(UITool.ToLocalization("您输入的公会不存在"))
            return
        end
    end
    self.sManager:createWaitLayer()
    local cjson = require "cjson"


    local tempTable = {
        ["rpc"]       = "guild_search",
        ["guild_name"] = self.GuildName,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--/*监听输入公会的名字*/
function SearchGuildLayer:EGuildName( ... )
    -- body
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.GuildSetName 
    rcvData["defalutStr"] = ""
    rcvData["maxLength"] = 8
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    self.inputLayer = self.sManager:toInputModelLayer(rcvData)
end
--/*文本设置输入的名字*/
function SearchGuildLayer:GuildSetName( str )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imageBg           = panel:getChildByName("Image_bg")
    local SearchBg          = imageBg:getChildByName("Image_searchName")
    --/*搜索输入框*/
    local SearchE           = SearchBg:getChildByName("Text_1")
    SearchE:setString(str)
    self.GuildName = str
end

function SearchGuildLayer:returnBack( ... )
    -- body
    self.exist = false
   -- self.area = {}
    self:clearEx()
end

function SearchGuildLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function SearchGuildLayer:create(rData)

     local login = SearchGuildLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login

     
end
