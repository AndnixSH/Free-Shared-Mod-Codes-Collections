--  Created by zhangchao on 16-05-06.
CHANNEL = {
	Android = {
		CHANNEL_CODE_US = "efun",	--us
	},
	IOS     = {
		CHANNEL_CODE_US = "efun",	--us
	}
}

--游戏设备信息
GAME_CHANNEL = XBConfigManager:getInstance():getChannelName()
GAME_MAC = ""
GAME_IDFA = ""
GAME_OS_VERSION = ""
GAME_ANDROIDID = ""
GAME_PACKAGENAME = ""--ios才有，bundleId
PACKAGE_VERSION = ""--打包时的project.manifest文件的version
GAME_DEVICE_SIGN = ""--设备唯一标示(安卓为GAME_ANDROIDID， ios为GAME_IDFA)
GAME_SDK = ""--[[用于判断对接的是哪个sdk]]
local platform = cc.Application:getInstance():getTargetPlatform()

--Java中用的类
JAVA_ZCJNIHELPER 	= "com/poxiao/cocos/jni/ZCJniHelper"--[[从java端获取数据并返回给lua的一个工具]]
JAVA_USERLOGIN 		= "com/poxiao/cocos/sdk/SdkHelper"
JAVA_SDKHELPER 		= "com/poxiao/cocos/sdk/SdkHelper"
--用于异步更新渠道判断
if (cc.PLATFORM_OS_ANDROID == platform) then
    LUA_BRIDGE_CLASS 	= JAVA_SDKHELPER
    LUA_SDKHELPER_CLASS = JAVA_ZCJNIHELPER
elseif (cc.PLATFORM_OS_IPHONE == platform) or (cc.PLATFORM_OS_IPAD == platform) or (cc.PLATFORM_OS_MAC == platform) then
    LUA_BRIDGE_CLASS 	= "SdkHelper" --IOS官网
    LUA_SDKHELPER_CLASS = "SdkHelper"
end

OC_ZCJNIHELPER = "ZCJniHelper"

