hero_soul = {}

hero_soul[13] = {
    name = "56418",
    desc = "56505",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 3,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56331",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 40,
            add_hp = 94,
            add_atk = 80,
            skill_unlock = 0,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                            
            },
        }, 
        break_1 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 60,
            add_hp = 567,
            add_atk = 480,
            skill_unlock = 6013001,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1005,20,5 },   
                { 1021,10,5 },   
                { 1082,10,5 },   
                { 1122,10,5 },   
                { 1081,30,5 },   
                { 1105,20,5 },   
                { 1109,10,5 },   
                { 1121,10,5 },                                                                                                                            
            },
        }, 
        break_2 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 80,
            add_hp = 1323,
            add_atk = 1120,
            skill_unlock = 6013002,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1006,10,5 },   
                { 1005,20,5 },   
                { 1022,7,5 },   
                { 1021,15,5 },   
                { 1114,15,5 },   
                { 1106,10,5 },   
                { 1110,10,5 },   
                { 1081,30,5 },   
                { 1121,20,5 },   
                { 1085,20,5 },   
                { 1089,20,5 },                                                                                                      
            },
        }, 
        break_3 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 120,
            add_hp = 2079,
            add_atk = 1760,
            skill_unlock = 6013003,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1022,10,5 },   
                { 1021,20,5 },   
                { 1123,1,5 },   
                { 1082,20,5 },   
                { 1122,20,5 },   
                { 1110,10,5 },   
                { 1090,10,5 },   
                { 1121,30,5 },   
                { 1113,30,5 },   
                { 1117,20,5 },   
                { 1201,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 160,
            add_hp = 2835,
            add_atk = 2400,
            skill_unlock = 6013004,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                   
                { 1144,30,5 },   
                { 1141,10,5 },   
                { 1142,4,5 },   
                { 1007,15,5 },   
                { 1006,30,5 },   
                { 1023,15,5 },   
                { 1022,30,5 },   
                { 1041,20,5 },   
                { 1042,10,5 },   
                { 1083,20,5 },   
                { 1103,15,5 },   
                { 1123,10,5 },   
                { 1082,20,5 },   
                { 1110,20,5 },   
                { 1114,20,5 },   
                { 1105,30,5 },   
                { 1097,30,5 },   
                { 1201,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 200,
            add_hp = 3780,
            add_atk = 3200,
            skill_unlock = 6013005,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                       
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1128,1,5 },   
                { 1124,1,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1023,20,5 },   
                { 1022,40,5 },   
                { 1043,10,5 },   
                { 1042,20,5 },   
                { 1123,20,5 },   
                { 1087,20,5 },   
                { 1111,30,5 },   
                { 1106,30,5 },   
                { 1114,20,5 },   
                { 1122,20,5 },   
                { 1117,40,5 },   
                { 1082,40,5 },   
                { 1201,1,5 },  
            },
        }, 
    }
}
hero_soul[378] = {
    name = "56419",
    desc = "56506",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56332",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_378.png",
            icon_big = "hs_378.png",
            Lv_max = 40,
            add_hp = 68,
            add_atk = 100,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_378.png",
            icon_big = "hs_378.png",
            Lv_max = 60,
            add_hp = 410,
            add_atk = 605,
            skill_unlock = 6378001,
            hp_max = 8000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_378.png",
            icon_big = "hs_378.png",
            Lv_max = 80,
            add_hp = 957,
            add_atk = 1412,
            skill_unlock = 6378002,
            hp_max = 8000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_378.png",
            icon_big = "hs_378.png",
            Lv_max = 120,
            add_hp = 1504,
            add_atk = 2219,
            skill_unlock = 6378003,
            hp_max = 8000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 1203,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_378.png",
            icon_big = "hs_378.png",
            Lv_max = 160,
            add_hp = 2052,
            add_atk = 3027,
            skill_unlock = 6378004,
            hp_max = 8000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 1203,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_378.png",
            icon_big = "hs_378.png",
            Lv_max = 200,
            add_hp = 2736,
            add_atk = 4036,
            skill_unlock = 6378005,
            hp_max = 8000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 1203,1,5 },  
            },
        }, 
    }
}
hero_soul[384] = {
    name = "56420",
    desc = "56507",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56333",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_384.png",
            icon_big = "hs_384.png",
            Lv_max = 40,
            add_hp = 67,
            add_atk = 115,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 14000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_384.png",
            icon_big = "hs_384.png",
            Lv_max = 60,
            add_hp = 403,
            add_atk = 695,
            skill_unlock = 6384001,
            hp_max = 8000,
            atk_max = 14000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1033,10,5 },   
                { 1094,10,5 },   
                { 1102,10,5 },   
                { 1093,30,5 },   
                { 1101,20,5 },   
                { 1085,10,5 },   
                { 1113,10,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_384.png",
            icon_big = "hs_384.png",
            Lv_max = 80,
            add_hp = 940,
            add_atk = 1622,
            skill_unlock = 6384002,
            hp_max = 8000,
            atk_max = 14000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1034,20,5 },   
                { 1033,30,5 },   
                { 1094,20,5 },   
                { 1102,10,5 },   
                { 1098,10,5 },   
                { 1093,30,5 },   
                { 1113,15,5 },   
                { 1105,15,5 },   
                { 1089,15,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_384.png",
            icon_big = "hs_384.png",
            Lv_max = 120,
            add_hp = 1478,
            add_atk = 2549,
            skill_unlock = 6384003,
            hp_max = 8000,
            atk_max = 14000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1034,30,5 },   
                { 1033,40,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1095,12,5 },   
                { 1123,6,5 },   
                { 1127,6,5 },   
                { 1094,30,5 },   
                { 1102,10,5 },   
                { 1126,10,5 },   
                { 1093,40,5 },   
                { 1113,10,5 },   
                { 1121,10,5 },   
                { 1204,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_384.png",
            icon_big = "hs_384.png",
            Lv_max = 160,
            add_hp = 2016,
            add_atk = 3477,
            skill_unlock = 6384004,
            hp_max = 8000,
            atk_max = 14000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,10,5 },   
                { 1143,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1035,20,5 },   
                { 1034,40,5 },   
                { 1062,20,5 },   
                { 1061,30,5 },   
                { 1095,40,5 },   
                { 1103,20,5 },   
                { 1127,15,5 },   
                { 1094,50,5 },   
                { 1098,30,5 },   
                { 1102,30,5 },   
                { 1093,40,5 },   
                { 1097,40,5 },   
                { 1204,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_384.png",
            icon_big = "hs_384.png",
            Lv_max = 200,
            add_hp = 2688,
            add_atk = 4636,
            skill_unlock = 6384005,
            hp_max = 8000,
            atk_max = 14000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1143,20,5 },   
                { 1124,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1035,30,5 },   
                { 1034,50,5 },   
                { 1063,20,5 },   
                { 1061,30,5 },   
                { 1127,40,5 },   
                { 1095,30,5 },   
                { 1119,20,5 },   
                { 1094,40,5 },   
                { 1102,30,5 },   
                { 1126,30,5 },   
                { 1093,50,5 },   
                { 1085,50,5 },   
                { 1204,1,5 },  
            },
        }, 
    }
}
hero_soul[375] = {
    name = "56421",
    desc = "56508",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56334",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_375.png",
            icon_big = "hs_375.png",
            Lv_max = 40,
            add_hp = 102,
            add_atk = 85,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_375.png",
            icon_big = "hs_375.png",
            Lv_max = 60,
            add_hp = 616,
            add_atk = 513,
            skill_unlock = 6375001,
            hp_max = 12000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1001,30,5 },   
                { 1029,10,5 },   
                { 1126,20,5 },   
                { 1102,10,5 },   
                { 1125,40,5 },   
                { 1113,30,5 },   
                { 1085,20,5 },   
                { 1093,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_375.png",
            icon_big = "hs_375.png",
            Lv_max = 80,
            add_hp = 1437,
            add_atk = 1198,
            skill_unlock = 6375002,
            hp_max = 12000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1002,20,5 },   
                { 1001,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1126,30,5 },   
                { 1094,20,5 },   
                { 1114,10,5 },   
                { 1125,30,5 },   
                { 1085,30,5 },   
                { 1097,20,5 },   
                { 1089,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_375.png",
            icon_big = "hs_375.png",
            Lv_max = 120,
            add_hp = 2259,
            add_atk = 1883,
            skill_unlock = 6375003,
            hp_max = 12000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1002,30,5 },   
                { 1001,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1091,15,5 },   
                { 1095,10,5 },   
                { 1126,20,5 },   
                { 1094,15,5 },   
                { 1082,10,5 },   
                { 1125,40,5 },   
                { 1093,30,5 },   
                { 1089,10,5 },   
                { 1202,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_375.png",
            icon_big = "hs_375.png",
            Lv_max = 160,
            add_hp = 3081,
            add_atk = 2568,
            skill_unlock = 6375004,
            hp_max = 12000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1143,10,5 },   
                { 1003,20,5 },   
                { 1002,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1062,20,5 },   
                { 1061,30,5 },   
                { 1127,30,5 },   
                { 1091,30,5 },   
                { 1119,10,5 },   
                { 1126,30,5 },   
                { 1094,36,5 },   
                { 1102,36,5 },   
                { 1125,50,5 },   
                { 1113,30,5 },   
                { 1202,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_375.png",
            icon_big = "hs_375.png",
            Lv_max = 200,
            add_hp = 4108,
            add_atk = 3424,
            skill_unlock = 6375005,
            hp_max = 12000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1143,20,5 },   
                { 1146,10,5 },   
                { 1003,30,5 },   
                { 1002,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1063,20,5 },   
                { 1062,30,5 },   
                { 1127,40,5 },   
                { 1091,30,5 },   
                { 1095,20,5 },   
                { 1098,40,5 },   
                { 1086,30,5 },   
                { 1114,30,5 },   
                { 1125,50,5 },   
                { 1093,50,5 },   
                { 1202,1,5 },  
            },
        }, 
    }
}
hero_soul[364] = {
    name = "56422",
    desc = "56509",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56335",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_364.png",
            icon_big = "hs_364.png",
            Lv_max = 40,
            add_hp = 93,
            add_atk = 80,
            skill_unlock = 0,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_364.png",
            icon_big = "hs_364.png",
            Lv_max = 60,
            add_hp = 558,
            add_atk = 483,
            skill_unlock = 6364001,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1098,20,5 },   
                { 1118,10,5 },   
                { 1097,40,5 },   
                { 1121,30,5 },   
                { 1109,20,5 },   
                { 1093,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_364.png",
            icon_big = "hs_364.png",
            Lv_max = 80,
            add_hp = 1303,
            add_atk = 1127,
            skill_unlock = 6364002,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1122,30,5 },   
                { 1098,20,5 },   
                { 1110,10,5 },   
                { 1121,40,5 },   
                { 1105,20,5 },   
                { 1117,20,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_364.png",
            icon_big = "hs_364.png",
            Lv_max = 120,
            add_hp = 2048,
            add_atk = 1771,
            skill_unlock = 6364003,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1119,20,5 },   
                { 1123,10,5 },   
                { 1111,15,5 },   
                { 1122,20,5 },   
                { 1110,20,5 },   
                { 1106,10,5 },   
                { 1117,40,5 },   
                { 1085,30,5 },   
                { 1089,20,5 },   
                { 1205,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_364.png",
            icon_big = "hs_364.png",
            Lv_max = 160,
            add_hp = 2793,
            add_atk = 2415,
            skill_unlock = 6364004,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1142,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1050,20,5 },   
                { 1049,30,5 },   
                { 1123,30,5 },   
                { 1087,20,5 },   
                { 1083,15,5 },   
                { 1098,40,5 },   
                { 1106,25,5 },   
                { 1090,25,5 },   
                { 1121,40,5 },   
                { 1117,40,5 },   
                { 1205,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_364.png",
            icon_big = "hs_364.png",
            Lv_max = 200,
            add_hp = 3724,
            add_atk = 3220,
            skill_unlock = 6364005,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1146,20,5 },   
                { 1147,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1051,20,5 },   
                { 1050,30,5 },   
                { 1123,40,5 },   
                { 1119,40,5 },   
                { 1087,20,5 },   
                { 1098,50,5 },   
                { 1082,30,5 },   
                { 1086,20,5 },   
                { 1121,50,5 },   
                { 1117,50,5 },   
                { 1205,1,5 },  
            },
        }, 
    }
}
hero_soul[362] = {
    name = "56423",
    desc = "56510",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56336",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_362.png",
            icon_big = "hs_362.png",
            Lv_max = 40,
            add_hp = 112,
            add_atk = 70,
            skill_unlock = 0,
            hp_max = 14000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_362.png",
            icon_big = "hs_362.png",
            Lv_max = 60,
            add_hp = 676,
            add_atk = 424,
            skill_unlock = 6362001,
            hp_max = 14000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1017,30,5 },   
                { 1021,20,5 },   
                { 1098,20,5 },   
                { 1118,10,5 },   
                { 1097,40,5 },   
                { 1117,30,5 },   
                { 1081,20,5 },   
                { 1089,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_362.png",
            icon_big = "hs_362.png",
            Lv_max = 80,
            add_hp = 1579,
            add_atk = 991,
            skill_unlock = 6362002,
            hp_max = 14000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1018,20,5 },   
                { 1017,40,5 },   
                { 1022,20,5 },   
                { 1021,30,5 },   
                { 1118,30,5 },   
                { 1086,20,5 },   
                { 1082,10,5 },   
                { 1117,30,5 },   
                { 1097,30,5 },   
                { 1101,20,5 },   
                { 1085,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_362.png",
            icon_big = "hs_362.png",
            Lv_max = 120,
            add_hp = 2481,
            add_atk = 1557,
            skill_unlock = 6362003,
            hp_max = 14000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1018,30,5 },   
                { 1017,50,5 },   
                { 1022,30,5 },   
                { 1021,40,5 },   
                { 1119,20,5 },   
                { 1107,10,5 },   
                { 1091,10,5 },   
                { 1118,30,5 },   
                { 1098,30,5 },   
                { 1082,15,5 },   
                { 1081,40,5 },   
                { 1105,25,5 },   
                { 1113,25,5 },   
                { 1206,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_362.png",
            icon_big = "hs_362.png",
            Lv_max = 160,
            add_hp = 3384,
            add_atk = 2124,
            skill_unlock = 6362004,
            hp_max = 14000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1145,10,5 },   
                { 1019,20,5 },   
                { 1018,40,5 },   
                { 1023,20,5 },   
                { 1022,40,5 },   
                { 1054,20,5 },   
                { 1053,30,5 },   
                { 1119,30,5 },   
                { 1099,20,5 },   
                { 1111,20,5 },   
                { 1098,40,5 },   
                { 1118,20,5 },   
                { 1082,20,5 },   
                { 1101,50,5 },   
                { 1117,30,5 },   
                { 1206,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_362.png",
            icon_big = "hs_362.png",
            Lv_max = 200,
            add_hp = 4512,
            add_atk = 2832,
            skill_unlock = 6362005,
            hp_max = 14000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1145,20,5 },   
                { 1142,10,5 },   
                { 1019,30,5 },   
                { 1018,50,5 },   
                { 1023,30,5 },   
                { 1022,50,5 },   
                { 1055,20,5 },   
                { 1054,30,5 },   
                { 1119,40,5 },   
                { 1099,30,5 },   
                { 1083,20,5 },   
                { 1118,40,5 },   
                { 1098,30,5 },   
                { 1082,30,5 },   
                { 1117,50,5 },   
                { 1097,50,5 },   
                { 1206,1,5 },  
            },
        }, 
    }
}
hero_soul[407] = {
    name = "56424",
    desc = "56511",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56337",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_407.png",
            icon_big = "hs_407.png",
            Lv_max = 40,
            add_hp = 97,
            add_atk = 103,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_407.png",
            icon_big = "hs_407.png",
            Lv_max = 60,
            add_hp = 582,
            add_atk = 618,
            skill_unlock = 6407001,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1122,20,5 },   
                { 1106,10,5 },   
                { 1089,40,5 },   
                { 1085,30,5 },   
                { 1113,20,5 },   
                { 1121,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_407.png",
            icon_big = "hs_407.png",
            Lv_max = 80,
            add_hp = 1359,
            add_atk = 1442,
            skill_unlock = 6407002,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1090,20,5 },   
                { 1086,20,5 },   
                { 1122,10,5 },   
                { 1089,40,5 },   
                { 1105,30,5 },   
                { 1113,30,5 },   
                { 1121,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_407.png",
            icon_big = "hs_407.png",
            Lv_max = 120,
            add_hp = 2136,
            add_atk = 2266,
            skill_unlock = 6407003,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1111,10,5 },   
                { 1106,20,5 },   
                { 1110,20,5 },   
                { 1122,10,5 },   
                { 1121,30,5 },   
                { 1093,30,5 },   
                { 1105,30,5 },   
                { 1207,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_407.png",
            icon_big = "hs_407.png",
            Lv_max = 160,
            add_hp = 2913,
            add_atk = 3090,
            skill_unlock = 6407004,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1146,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1062,20,5 },   
                { 1061,30,5 },   
                { 1123,40,5 },   
                { 1111,15,5 },   
                { 1099,15,5 },   
                { 1090,30,5 },   
                { 1106,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1097,40,5 },   
                { 1207,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_407.png",
            icon_big = "hs_407.png",
            Lv_max = 200,
            add_hp = 3884,
            add_atk = 4120,
            skill_unlock = 6407005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1146,20,5 },   
                { 1143,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1063,20,5 },   
                { 1062,30,5 },   
                { 1123,50,5 },   
                { 1103,20,5 },   
                { 1115,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1121,60,5 },   
                { 1113,40,5 },   
                { 1207,1,5 },  
            },
        }, 
    }
}
hero_soul[403] = {
    name = "612336",
    desc = "56512",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56338",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_403.png",
            icon_big = "hs_403.png",
            Lv_max = 40,
            add_hp = 92,
            add_atk = 111,
            skill_unlock = 0,
            hp_max = 11000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_403.png",
            icon_big = "hs_403.png",
            Lv_max = 60,
            add_hp = 555,
            add_atk = 669,
            skill_unlock = 6403001,
            hp_max = 11000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1017,30,5 },   
                { 1029,10,5 },   
                { 1118,20,5 },   
                { 1099,20,5 },   
                { 1117,30,5 },   
                { 1105,30,5 },   
                { 1101,30,5 },   
                { 1093,30,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_403.png",
            icon_big = "hs_403.png",
            Lv_max = 80,
            add_hp = 1295,
            add_atk = 1561,
            skill_unlock = 6403002,
            hp_max = 11000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1018,20,5 },   
                { 1017,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1094,30,5 },   
                { 1118,20,5 },   
                { 1098,20,5 },   
                { 1105,20,5 },   
                { 1101,20,5 },   
                { 1113,20,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_403.png",
            icon_big = "hs_403.png",
            Lv_max = 120,
            add_hp = 2035,
            add_atk = 2453,
            skill_unlock = 6403003,
            hp_max = 11000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1018,30,5 },   
                { 1017,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1119,20,5 },   
                { 1099,10,5 },   
                { 1087,10,5 },   
                { 1094,20,5 },   
                { 1106,20,5 },   
                { 1118,20,5 },   
                { 1101,20,5 },   
                { 1117,20,5 },   
                { 1113,20,5 },   
                { 1210,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_403.png",
            icon_big = "hs_403.png",
            Lv_max = 160,
            add_hp = 2775,
            add_atk = 3345,
            skill_unlock = 6403004,
            hp_max = 11000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1145,10,5 },   
                { 1019,20,5 },   
                { 1018,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1058,20,5 },   
                { 1057,30,5 },   
                { 1119,30,5 },   
                { 1091,20,5 },   
                { 1083,20,5 },   
                { 1094,40,5 },   
                { 1110,30,5 },   
                { 1114,30,5 },   
                { 1121,30,5 },   
                { 1101,30,5 },   
                { 1210,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_403.png",
            icon_big = "hs_403.png",
            Lv_max = 200,
            add_hp = 3700,
            add_atk = 4460,
            skill_unlock = 6403005,
            hp_max = 11000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1145,20,5 },   
                { 1128,10,5 },   
                { 1019,30,5 },   
                { 1018,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1059,20,5 },   
                { 1058,30,5 },   
                { 1119,40,5 },   
                { 1115,30,5 },   
                { 1087,30,5 },   
                { 1118,40,5 },   
                { 1094,30,5 },   
                { 1098,30,5 },   
                { 1097,50,5 },   
                { 1101,50,5 },   
                { 1210,1,5 },  
            },
        }, 
    }
}
hero_soul[412] = {
    name = "56426",
    desc = "56513",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56339",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_412.png",
            icon_big = "hs_412.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_412.png",
            icon_big = "hs_412.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6412001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1001,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1126,10,5 },   
                { 1125,40,5 },   
                { 1105,30,5 },   
                { 1085,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_412.png",
            icon_big = "hs_412.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6412002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1002,20,5 },   
                { 1001,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1126,20,5 },   
                { 1102,20,5 },   
                { 1082,10,5 },   
                { 1101,40,5 },   
                { 1085,30,5 },   
                { 1109,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_412.png",
            icon_big = "hs_412.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6412003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1002,30,5 },   
                { 1001,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1095,20,5 },   
                { 1127,10,5 },   
                { 1103,10,5 },   
                { 1122,20,5 },   
                { 1098,20,5 },   
                { 1094,10,5 },   
                { 1113,30,5 },   
                { 1125,30,5 },   
                { 1121,30,5 },   
                { 1208,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_412.png",
            icon_big = "hs_412.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6412004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1145,10,5 },   
                { 1003,20,5 },   
                { 1002,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1127,40,5 },   
                { 1095,15,5 },   
                { 1099,15,5 },   
                { 1114,30,5 },   
                { 1094,30,5 },   
                { 1126,30,5 },   
                { 1101,40,5 },   
                { 1113,40,5 },   
                { 1208,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_412.png",
            icon_big = "hs_412.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6412005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1145,20,5 },   
                { 1128,10,5 },   
                { 1003,30,5 },   
                { 1002,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1099,50,5 },   
                { 1107,20,5 },   
                { 1127,20,5 },   
                { 1102,50,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1085,60,5 },   
                { 1125,40,5 },   
                { 1208,1,5 },  
            },
        }, 
    }
}
hero_soul[405] = {
    name = "56427",
    desc = "56514",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56340",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_405.png",
            icon_big = "hs_405.png",
            Lv_max = 40,
            add_hp = 87,
            add_atk = 121,
            skill_unlock = 0,
            hp_max = 9000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_405.png",
            icon_big = "hs_405.png",
            Lv_max = 60,
            add_hp = 523,
            add_atk = 728,
            skill_unlock = 6405001,
            hp_max = 9000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1025,10,5 },   
                { 1110,20,5 },   
                { 1114,10,5 },   
                { 1125,40,5 },   
                { 1085,30,5 },   
                { 1113,20,5 },   
                { 1121,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_405.png",
            icon_big = "hs_405.png",
            Lv_max = 80,
            add_hp = 1220,
            add_atk = 1699,
            skill_unlock = 6405002,
            hp_max = 9000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1026,20,5 },   
                { 1025,30,5 },   
                { 1082,20,5 },   
                { 1102,20,5 },   
                { 1126,10,5 },   
                { 1117,40,5 },   
                { 1109,30,5 },   
                { 1093,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_405.png",
            icon_big = "hs_405.png",
            Lv_max = 120,
            add_hp = 1918,
            add_atk = 2670,
            skill_unlock = 6405003,
            hp_max = 9000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1026,30,5 },   
                { 1025,40,5 },   
                { 1123,20,5 },   
                { 1095,10,5 },   
                { 1111,10,5 },   
                { 1114,20,5 },   
                { 1110,20,5 },   
                { 1122,10,5 },   
                { 1121,30,5 },   
                { 1093,30,5 },   
                { 1101,30,5 },   
                { 1212,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_405.png",
            icon_big = "hs_405.png",
            Lv_max = 160,
            add_hp = 2616,
            add_atk = 3642,
            skill_unlock = 6405004,
            hp_max = 9000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1146,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1027,20,5 },   
                { 1026,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1127,40,5 },   
                { 1115,15,5 },   
                { 1103,15,5 },   
                { 1090,30,5 },   
                { 1126,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1113,40,5 },   
                { 1212,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_405.png",
            icon_big = "hs_405.png",
            Lv_max = 200,
            add_hp = 3488,
            add_atk = 4856,
            skill_unlock = 6405005,
            hp_max = 9000,
            atk_max = 11000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1146,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1027,30,5 },   
                { 1026,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1119,50,5 },   
                { 1095,20,5 },   
                { 1099,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1117,60,5 },   
                { 1109,40,5 },   
                { 1212,1,5 },  
            },
        }, 
    }
}
hero_soul[413] = {
    name = "56428",
    desc = "56515",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56341",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_413.png",
            icon_big = "hs_413.png",
            Lv_max = 40,
            add_hp = 141,
            add_atk = 42,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_413.png",
            icon_big = "hs_413.png",
            Lv_max = 60,
            add_hp = 846,
            add_atk = 255,
            skill_unlock = 6413001,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_413.png",
            icon_big = "hs_413.png",
            Lv_max = 80,
            add_hp = 1975,
            add_atk = 596,
            skill_unlock = 6413002,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_413.png",
            icon_big = "hs_413.png",
            Lv_max = 120,
            add_hp = 3104,
            add_atk = 937,
            skill_unlock = 6413003,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_413.png",
            icon_big = "hs_413.png",
            Lv_max = 160,
            add_hp = 4233,
            add_atk = 1278,
            skill_unlock = 6413004,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1102,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_413.png",
            icon_big = "hs_413.png",
            Lv_max = 200,
            add_hp = 5644,
            add_atk = 1704,
            skill_unlock = 6413005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[11] = {
    name = "56429",
    desc = "56516",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56342",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 23,
            add_atk = 29,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 140,
            add_atk = 179,
            skill_unlock = 6011001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1106,5,5 },   
                { 1109,8,5 },   
                { 1105,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 327,
            add_atk = 418,
            skill_unlock = 6011002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1106,5,5 },   
                { 1126,5,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 514,
            add_atk = 657,
            skill_unlock = 6011003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2011,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 702,
            add_atk = 897,
            skill_unlock = 6011004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 2011,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 936,
            add_atk = 1196,
            skill_unlock = 6011005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1107,8,5 },   
                { 1127,8,5 },   
                { 1106,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1105,15,5 },   
                { 1125,15,5 },   
                { 2011,1,5 },  
            },
        }, 
    }
}
hero_soul[23] = {
    name = "56430",
    desc = "56517",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56343",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 46,
            add_atk = 19,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 276,
            add_atk = 117,
            skill_unlock = 6023001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1106,5,5 },   
                { 1109,8,5 },   
                { 1105,8,5 },   
                { 1085,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 645,
            add_atk = 273,
            skill_unlock = 6023002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1106,5,5 },   
                { 1086,5,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 1014,
            add_atk = 429,
            skill_unlock = 6023003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1107,5,5 },   
                { 1087,5,5 },   
                { 1106,8,5 },   
                { 1086,8,5 },   
                { 1110,8,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 1109,10,5 },   
                { 2023,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1383,
            add_atk = 585,
            skill_unlock = 6023004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1058,5,5 },   
                { 1057,8,5 },   
                { 1111,5,5 },   
                { 1107,5,5 },   
                { 1087,5,5 },   
                { 1106,8,5 },   
                { 1086,8,5 },   
                { 1110,8,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 2023,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1844,
            add_atk = 780,
            skill_unlock = 6023005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1059,5,5 },   
                { 1058,10,5 },   
                { 1111,8,5 },   
                { 1107,8,5 },   
                { 1087,8,5 },   
                { 1106,10,5 },   
                { 1086,10,5 },   
                { 1110,10,5 },   
                { 1105,15,5 },   
                { 1085,15,5 },   
                { 2023,1,5 },  
            },
        }, 
    }
}
hero_soul[24] = {
    name = "56431",
    desc = "56518",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56344",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[36] = {
    name = "56432",
    desc = "56519",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56345",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 29,
            add_atk = 36,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 175,
            add_atk = 221,
            skill_unlock = 6036001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1106,5,5 },   
                { 1113,8,5 },   
                { 1105,8,5 },   
                { 1085,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 408,
            add_atk = 516,
            skill_unlock = 6036002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1106,5,5 },   
                { 1086,5,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 642,
            add_atk = 811,
            skill_unlock = 6036003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1107,5,5 },   
                { 1087,5,5 },   
                { 1106,8,5 },   
                { 1086,8,5 },   
                { 1114,8,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 1113,10,5 },   
                { 2036,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 876,
            add_atk = 1107,
            skill_unlock = 6036004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1058,5,5 },   
                { 1057,8,5 },   
                { 1115,5,5 },   
                { 1107,5,5 },   
                { 1087,5,5 },   
                { 1106,8,5 },   
                { 1086,8,5 },   
                { 1114,8,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 2036,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1168,
            add_atk = 1476,
            skill_unlock = 6036005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1059,5,5 },   
                { 1058,10,5 },   
                { 1115,8,5 },   
                { 1107,8,5 },   
                { 1087,8,5 },   
                { 1106,10,5 },   
                { 1086,10,5 },   
                { 1114,10,5 },   
                { 1105,15,5 },   
                { 1085,15,5 },   
                { 2036,1,5 },  
            },
        }, 
    }
}
hero_soul[37] = {
    name = "56433",
    desc = "56520",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56346",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 20,
            add_atk = 30,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 124,
            add_atk = 183,
            skill_unlock = 6037001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1106,5,5 },   
                { 1101,8,5 },   
                { 1105,8,5 },   
                { 1113,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 291,
            add_atk = 428,
            skill_unlock = 6037002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1106,5,5 },   
                { 1114,5,5 },   
                { 1105,10,5 },   
                { 1113,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 457,
            add_atk = 673,
            skill_unlock = 6037003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1107,5,5 },   
                { 1115,5,5 },   
                { 1106,8,5 },   
                { 1114,8,5 },   
                { 1102,8,5 },   
                { 1105,10,5 },   
                { 1113,10,5 },   
                { 1101,10,5 },   
                { 2037,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 624,
            add_atk = 918,
            skill_unlock = 6037004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1046,5,5 },   
                { 1045,8,5 },   
                { 1103,5,5 },   
                { 1107,5,5 },   
                { 1115,5,5 },   
                { 1106,8,5 },   
                { 1114,8,5 },   
                { 1102,8,5 },   
                { 1105,10,5 },   
                { 1113,10,5 },   
                { 2037,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 832,
            add_atk = 1224,
            skill_unlock = 6037005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1047,5,5 },   
                { 1046,10,5 },   
                { 1103,8,5 },   
                { 1107,8,5 },   
                { 1115,8,5 },   
                { 1106,10,5 },   
                { 1114,10,5 },   
                { 1102,10,5 },   
                { 1105,15,5 },   
                { 1113,15,5 },   
                { 2037,1,5 },  
            },
        }, 
    }
}
hero_soul[51] = {
    name = "56434",
    desc = "56521",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56347",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 28,
            add_atk = 33,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 172,
            add_atk = 203,
            skill_unlock = 6051001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1090,5,5 },   
                { 1113,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 403,
            add_atk = 474,
            skill_unlock = 6051002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 633,
            add_atk = 745,
            skill_unlock = 6051003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1114,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1113,10,5 },   
                { 2051,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 864,
            add_atk = 1017,
            skill_unlock = 6051004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1115,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1114,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2051,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1152,
            add_atk = 1356,
            skill_unlock = 6051005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1115,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1114,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2051,1,5 },  
            },
        }, 
    }
}
hero_soul[61] = {
    name = "56435",
    desc = "56522",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56348",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 24,
            add_atk = 38,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 145,
            add_atk = 233,
            skill_unlock = 6061001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1106,5,5 },   
                { 1081,8,5 },   
                { 1105,8,5 },   
                { 1117,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 340,
            add_atk = 544,
            skill_unlock = 6061002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1106,5,5 },   
                { 1118,5,5 },   
                { 1105,10,5 },   
                { 1117,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 534,
            add_atk = 855,
            skill_unlock = 6061003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1107,5,5 },   
                { 1119,5,5 },   
                { 1106,8,5 },   
                { 1118,8,5 },   
                { 1082,8,5 },   
                { 1105,10,5 },   
                { 1117,10,5 },   
                { 1081,10,5 },   
                { 2061,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 729,
            add_atk = 1167,
            skill_unlock = 6061004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1054,5,5 },   
                { 1053,8,5 },   
                { 1083,5,5 },   
                { 1107,5,5 },   
                { 1119,5,5 },   
                { 1106,8,5 },   
                { 1118,8,5 },   
                { 1082,8,5 },   
                { 1105,10,5 },   
                { 1117,10,5 },   
                { 2061,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 972,
            add_atk = 1556,
            skill_unlock = 6061005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1055,5,5 },   
                { 1054,10,5 },   
                { 1083,8,5 },   
                { 1107,8,5 },   
                { 1119,8,5 },   
                { 1106,10,5 },   
                { 1118,10,5 },   
                { 1082,10,5 },   
                { 1105,15,5 },   
                { 1117,15,5 },   
                { 2061,1,5 },  
            },
        }, 
    }
}
hero_soul[62] = {
    name = "56436",
    desc = "56523",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56349",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 18,
            add_atk = 34,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 110,
            add_atk = 205,
            skill_unlock = 6062001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1090,5,5 },   
                { 1081,8,5 },   
                { 1089,8,5 },   
                { 1113,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 257,
            add_atk = 478,
            skill_unlock = 6062002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1090,5,5 },   
                { 1114,5,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 404,
            add_atk = 752,
            skill_unlock = 6062003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1091,5,5 },   
                { 1115,5,5 },   
                { 1090,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },   
                { 2062,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 552,
            add_atk = 1026,
            skill_unlock = 6062004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1046,5,5 },   
                { 1045,8,5 },   
                { 1083,5,5 },   
                { 1091,5,5 },   
                { 1115,5,5 },   
                { 1090,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 2062,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 736,
            add_atk = 1368,
            skill_unlock = 6062005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1047,5,5 },   
                { 1046,10,5 },   
                { 1083,8,5 },   
                { 1091,8,5 },   
                { 1115,8,5 },   
                { 1090,10,5 },   
                { 1114,10,5 },   
                { 1082,10,5 },   
                { 1089,15,5 },   
                { 1113,15,5 },   
                { 2062,1,5 },  
            },
        }, 
    }
}
hero_soul[76] = {
    name = "56437",
    desc = "56524",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56350",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 51,
            add_atk = 27,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 307,
            add_atk = 162,
            skill_unlock = 6076001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1109,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 716,
            add_atk = 379,
            skill_unlock = 6076002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 1126,
            add_atk = 596,
            skill_unlock = 6076003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2076,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1536,
            add_atk = 813,
            skill_unlock = 6076004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2076,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 2048,
            add_atk = 1084,
            skill_unlock = 6076005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2076,1,5 },  
            },
        }, 
    }
}
hero_soul[101] = {
    name = "56438",
    desc = "56525",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56351",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 32,
            add_atk = 31,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 196,
            add_atk = 188,
            skill_unlock = 6101001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1094,5,5 },   
                { 1109,8,5 },   
                { 1093,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 457,
            add_atk = 439,
            skill_unlock = 6101002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1094,5,5 },   
                { 1126,5,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 719,
            add_atk = 690,
            skill_unlock = 6101003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2101,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 981,
            add_atk = 942,
            skill_unlock = 6101004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 2101,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1308,
            add_atk = 1256,
            skill_unlock = 6101005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1095,8,5 },   
                { 1127,8,5 },   
                { 1094,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1093,15,5 },   
                { 1125,15,5 },   
                { 2101,1,5 },  
            },
        }, 
    }
}
hero_soul[103] = {
    name = "56439",
    desc = "56526",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56352",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 25,
            add_atk = 39,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 153,
            add_atk = 238,
            skill_unlock = 6103001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1094,5,5 },   
                { 1101,8,5 },   
                { 1093,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 358,
            add_atk = 555,
            skill_unlock = 6103002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1094,5,5 },   
                { 1126,5,5 },   
                { 1093,10,5 },   
                { 1101,10,5 },   
                { 1125,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 563,
            add_atk = 873,
            skill_unlock = 6103003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1102,8,5 },   
                { 1126,8,5 },   
                { 1093,10,5 },   
                { 1101,10,5 },   
                { 1125,10,5 },   
                { 2103,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 768,
            add_atk = 1191,
            skill_unlock = 6103004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1062,5,5 },   
                { 1061,8,5 },   
                { 1103,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1102,8,5 },   
                { 1126,8,5 },   
                { 1093,10,5 },   
                { 1101,10,5 },   
                { 2103,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1024,
            add_atk = 1588,
            skill_unlock = 6103005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1063,5,5 },   
                { 1062,10,5 },   
                { 1103,8,5 },   
                { 1095,8,5 },   
                { 1127,8,5 },   
                { 1094,10,5 },   
                { 1102,10,5 },   
                { 1126,10,5 },   
                { 1093,15,5 },   
                { 1101,15,5 },   
                { 2103,1,5 },  
            },
        }, 
    }
}
hero_soul[116] = {
    name = "56440",
    desc = "56527",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56353",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 31,
            add_atk = 20,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 186,
            add_atk = 122,
            skill_unlock = 6116001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1094,5,5 },   
                { 1113,8,5 },   
                { 1093,8,5 },   
                { 1101,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 435,
            add_atk = 285,
            skill_unlock = 6116002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1094,5,5 },   
                { 1102,5,5 },   
                { 1093,10,5 },   
                { 1101,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 684,
            add_atk = 448,
            skill_unlock = 6116003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1095,5,5 },   
                { 1103,5,5 },   
                { 1094,8,5 },   
                { 1102,8,5 },   
                { 1114,8,5 },   
                { 1093,10,5 },   
                { 1101,10,5 },   
                { 1113,10,5 },   
                { 2116,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 933,
            add_atk = 612,
            skill_unlock = 6116004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1062,5,5 },   
                { 1061,8,5 },   
                { 1115,5,5 },   
                { 1095,5,5 },   
                { 1103,5,5 },   
                { 1094,8,5 },   
                { 1102,8,5 },   
                { 1114,8,5 },   
                { 1093,10,5 },   
                { 1101,10,5 },   
                { 2116,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1244,
            add_atk = 816,
            skill_unlock = 6116005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1063,5,5 },   
                { 1062,10,5 },   
                { 1115,8,5 },   
                { 1095,8,5 },   
                { 1103,8,5 },   
                { 1094,10,5 },   
                { 1102,10,5 },   
                { 1114,10,5 },   
                { 1093,15,5 },   
                { 1101,15,5 },   
                { 2116,1,5 },  
            },
        }, 
    }
}
hero_soul[117] = {
    name = "56441",
    desc = "56528",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56354",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 24,
            add_atk = 57,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 145,
            add_atk = 346,
            skill_unlock = 6117001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1094,5,5 },   
                { 1081,8,5 },   
                { 1093,8,5 },   
                { 1113,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 340,
            add_atk = 807,
            skill_unlock = 6117002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1094,5,5 },   
                { 1114,5,5 },   
                { 1093,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 534,
            add_atk = 1269,
            skill_unlock = 6117003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1095,5,5 },   
                { 1115,5,5 },   
                { 1094,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1093,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },   
                { 2117,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 729,
            add_atk = 1731,
            skill_unlock = 6117004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1046,5,5 },   
                { 1045,8,5 },   
                { 1083,5,5 },   
                { 1095,5,5 },   
                { 1115,5,5 },   
                { 1094,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1093,10,5 },   
                { 1113,10,5 },   
                { 2117,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 972,
            add_atk = 2308,
            skill_unlock = 6117005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1047,5,5 },   
                { 1046,10,5 },   
                { 1083,8,5 },   
                { 1095,8,5 },   
                { 1115,8,5 },   
                { 1094,10,5 },   
                { 1114,10,5 },   
                { 1082,10,5 },   
                { 1093,15,5 },   
                { 1113,15,5 },   
                { 2117,1,5 },  
            },
        }, 
    }
}
hero_soul[142] = {
    name = "56442",
    desc = "56529",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56355",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 23,
            add_atk = 28,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 138,
            add_atk = 168,
            skill_unlock = 6142001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1013,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1122,5,5 },   
                { 1101,8,5 },   
                { 1121,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 322,
            add_atk = 393,
            skill_unlock = 6142002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1014,5,5 },   
                { 1013,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1122,5,5 },   
                { 1126,5,5 },   
                { 1121,10,5 },   
                { 1101,10,5 },   
                { 1125,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 506,
            add_atk = 618,
            skill_unlock = 6142003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1014,10,5 },   
                { 1013,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1123,5,5 },   
                { 1127,5,5 },   
                { 1122,8,5 },   
                { 1102,8,5 },   
                { 1126,8,5 },   
                { 1121,10,5 },   
                { 1101,10,5 },   
                { 1125,10,5 },   
                { 2142,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 690,
            add_atk = 843,
            skill_unlock = 6142004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1015,5,5 },   
                { 1014,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1062,5,5 },   
                { 1061,8,5 },   
                { 1103,5,5 },   
                { 1123,5,5 },   
                { 1127,5,5 },   
                { 1122,8,5 },   
                { 1102,8,5 },   
                { 1126,8,5 },   
                { 1121,10,5 },   
                { 1101,10,5 },   
                { 2142,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 920,
            add_atk = 1124,
            skill_unlock = 6142005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1015,8,5 },   
                { 1014,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1063,5,5 },   
                { 1062,10,5 },   
                { 1103,8,5 },   
                { 1123,8,5 },   
                { 1127,8,5 },   
                { 1122,10,5 },   
                { 1102,10,5 },   
                { 1126,10,5 },   
                { 1121,15,5 },   
                { 1101,15,5 },   
                { 2142,1,5 },  
            },
        }, 
    }
}
hero_soul[157] = {
    name = "56443",
    desc = "56530",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56356",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 45,
            add_atk = 19,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 273,
            add_atk = 115,
            skill_unlock = 6157001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1109,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 638,
            add_atk = 270,
            skill_unlock = 6157002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 1003,
            add_atk = 424,
            skill_unlock = 6157003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2157,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1368,
            add_atk = 579,
            skill_unlock = 6157004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2157,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1824,
            add_atk = 772,
            skill_unlock = 6157005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2157,1,5 },  
            },
        }, 
    }
}
hero_soul[181] = {
    name = "56444",
    desc = "56531",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56357",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 24,
            add_atk = 56,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 146,
            add_atk = 336,
            skill_unlock = 6181001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1017,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1098,5,5 },   
                { 1081,8,5 },   
                { 1097,8,5 },   
                { 1113,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 341,
            add_atk = 784,
            skill_unlock = 6181002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1018,5,5 },   
                { 1017,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1098,5,5 },   
                { 1114,5,5 },   
                { 1097,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 536,
            add_atk = 1232,
            skill_unlock = 6181003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1018,10,5 },   
                { 1017,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1099,5,5 },   
                { 1115,5,5 },   
                { 1098,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1097,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },   
                { 2181,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 732,
            add_atk = 1680,
            skill_unlock = 6181004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1019,5,5 },   
                { 1018,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1046,5,5 },   
                { 1045,8,5 },   
                { 1083,5,5 },   
                { 1099,5,5 },   
                { 1115,5,5 },   
                { 1098,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1097,10,5 },   
                { 1113,10,5 },   
                { 2181,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 976,
            add_atk = 2240,
            skill_unlock = 6181005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1019,8,5 },   
                { 1018,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1047,5,5 },   
                { 1046,10,5 },   
                { 1083,8,5 },   
                { 1099,8,5 },   
                { 1115,8,5 },   
                { 1098,10,5 },   
                { 1114,10,5 },   
                { 1082,10,5 },   
                { 1097,15,5 },   
                { 1113,15,5 },   
                { 2181,1,5 },  
            },
        }, 
    }
}
hero_soul[182] = {
    name = "56445",
    desc = "56532",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56358",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 25,
            add_atk = 26,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 151,
            add_atk = 156,
            skill_unlock = 6182001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1017,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1098,5,5 },   
                { 1109,8,5 },   
                { 1097,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 354,
            add_atk = 365,
            skill_unlock = 6182002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1018,5,5 },   
                { 1017,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1098,5,5 },   
                { 1126,5,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 556,
            add_atk = 574,
            skill_unlock = 6182003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1018,10,5 },   
                { 1017,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1099,5,5 },   
                { 1127,5,5 },   
                { 1098,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2182,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 759,
            add_atk = 783,
            skill_unlock = 6182004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1019,5,5 },   
                { 1018,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1099,5,5 },   
                { 1127,5,5 },   
                { 1098,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 2182,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1012,
            add_atk = 1044,
            skill_unlock = 6182005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1019,8,5 },   
                { 1018,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1099,8,5 },   
                { 1127,8,5 },   
                { 1098,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1097,15,5 },   
                { 1125,15,5 },   
                { 2182,1,5 },  
            },
        }, 
    }
}
hero_soul[183] = {
    name = "56446",
    desc = "56533",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56359",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 18,
            add_atk = 33,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 109,
            add_atk = 199,
            skill_unlock = 6183001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1017,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1098,5,5 },   
                { 1113,8,5 },   
                { 1097,8,5 },   
                { 1101,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 254,
            add_atk = 464,
            skill_unlock = 6183002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1018,5,5 },   
                { 1017,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1098,5,5 },   
                { 1102,5,5 },   
                { 1097,10,5 },   
                { 1101,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 400,
            add_atk = 730,
            skill_unlock = 6183003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1018,10,5 },   
                { 1017,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1099,5,5 },   
                { 1103,5,5 },   
                { 1098,8,5 },   
                { 1102,8,5 },   
                { 1114,8,5 },   
                { 1097,10,5 },   
                { 1101,10,5 },   
                { 1113,10,5 },   
                { 2183,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 546,
            add_atk = 996,
            skill_unlock = 6183004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1019,5,5 },   
                { 1018,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1062,5,5 },   
                { 1061,8,5 },   
                { 1115,5,5 },   
                { 1099,5,5 },   
                { 1103,5,5 },   
                { 1098,8,5 },   
                { 1102,8,5 },   
                { 1114,8,5 },   
                { 1097,10,5 },   
                { 1101,10,5 },   
                { 2183,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 728,
            add_atk = 1328,
            skill_unlock = 6183005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1019,8,5 },   
                { 1018,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1063,5,5 },   
                { 1062,10,5 },   
                { 1115,8,5 },   
                { 1099,8,5 },   
                { 1103,8,5 },   
                { 1098,10,5 },   
                { 1102,10,5 },   
                { 1114,10,5 },   
                { 1097,15,5 },   
                { 1101,15,5 },   
                { 2183,1,5 },  
            },
        }, 
    }
}
hero_soul[196] = {
    name = "56447",
    desc = "56534",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56360",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 25,
            add_atk = 38,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 151,
            add_atk = 229,
            skill_unlock = 6196001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1017,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1098,5,5 },   
                { 1101,8,5 },   
                { 1097,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 354,
            add_atk = 534,
            skill_unlock = 6196002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1018,5,5 },   
                { 1017,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1098,5,5 },   
                { 1126,5,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 556,
            add_atk = 840,
            skill_unlock = 6196003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1018,10,5 },   
                { 1017,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1099,5,5 },   
                { 1127,5,5 },   
                { 1098,8,5 },   
                { 1126,8,5 },   
                { 1102,8,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 1101,10,5 },   
                { 2196,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 759,
            add_atk = 1146,
            skill_unlock = 6196004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1019,5,5 },   
                { 1018,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1103,5,5 },   
                { 1099,5,5 },   
                { 1127,5,5 },   
                { 1098,8,5 },   
                { 1126,8,5 },   
                { 1102,8,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 2196,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1012,
            add_atk = 1528,
            skill_unlock = 6196005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1019,8,5 },   
                { 1018,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1103,8,5 },   
                { 1099,8,5 },   
                { 1127,8,5 },   
                { 1098,10,5 },   
                { 1126,10,5 },   
                { 1102,10,5 },   
                { 1097,15,5 },   
                { 1125,15,5 },   
                { 2196,1,5 },  
            },
        }, 
    }
}
hero_soul[305] = {
    name = "56448",
    desc = "56535",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56361",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 26,
            add_atk = 57,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 156,
            add_atk = 346,
            skill_unlock = 6305001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1106,5,5 },   
                { 1081,8,5 },   
                { 1105,8,5 },   
                { 1085,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 365,
            add_atk = 807,
            skill_unlock = 6305002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1106,5,5 },   
                { 1086,5,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 574,
            add_atk = 1269,
            skill_unlock = 6305003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1107,5,5 },   
                { 1087,5,5 },   
                { 1106,8,5 },   
                { 1086,8,5 },   
                { 1082,8,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 1081,10,5 },   
                { 2305,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 783,
            add_atk = 1731,
            skill_unlock = 6305004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1058,5,5 },   
                { 1057,8,5 },   
                { 1083,5,5 },   
                { 1107,5,5 },   
                { 1087,5,5 },   
                { 1106,8,5 },   
                { 1086,8,5 },   
                { 1082,8,5 },   
                { 1105,10,5 },   
                { 1085,10,5 },   
                { 2305,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1044,
            add_atk = 2308,
            skill_unlock = 6305005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1059,5,5 },   
                { 1058,10,5 },   
                { 1083,8,5 },   
                { 1107,8,5 },   
                { 1087,8,5 },   
                { 1106,10,5 },   
                { 1086,10,5 },   
                { 1082,10,5 },   
                { 1105,15,5 },   
                { 1085,15,5 },   
                { 2305,1,5 },  
            },
        }, 
    }
}
hero_soul[354] = {
    name = "56449",
    desc = "56536",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56362",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 45,
            add_atk = 18,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 271,
            add_atk = 111,
            skill_unlock = 6354001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1094,5,5 },   
                { 1109,8,5 },   
                { 1093,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 632,
            add_atk = 260,
            skill_unlock = 6354002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1094,5,5 },   
                { 1126,5,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 994,
            add_atk = 409,
            skill_unlock = 6354003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2354,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1356,
            add_atk = 558,
            skill_unlock = 6354004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 2354,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1808,
            add_atk = 744,
            skill_unlock = 6354005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1095,8,5 },   
                { 1127,8,5 },   
                { 1094,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1093,15,5 },   
                { 1125,15,5 },   
                { 2354,1,5 },  
            },
        }, 
    }
}
hero_soul[356] = {
    name = "56450",
    desc = "56537",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56363",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 22,
            add_atk = 42,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 135,
            add_atk = 252,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1090,5,5 },   
                { 1081,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 315,
            add_atk = 589,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 495,
            add_atk = 926,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1082,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1081,10,5 },   
                { 2356,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 675,
            add_atk = 1263,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1083,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1082,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2356,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 900,
            add_atk = 1684,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1083,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1082,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2356,1,5 },  
            },
        }, 
    }
}
hero_soul[357] = {
    name = "56451",
    desc = "56538",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56364",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 29,
            add_atk = 53,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 179,
            add_atk = 319,
            skill_unlock = 6357001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1017,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1098,5,5 },   
                { 1101,8,5 },   
                { 1097,8,5 },   
                { 1117,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 418,
            add_atk = 744,
            skill_unlock = 6357002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1018,5,5 },   
                { 1017,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1098,5,5 },   
                { 1118,5,5 },   
                { 1097,10,5 },   
                { 1117,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 657,
            add_atk = 1170,
            skill_unlock = 6357003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1018,10,5 },   
                { 1017,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1099,5,5 },   
                { 1119,5,5 },   
                { 1098,8,5 },   
                { 1118,8,5 },   
                { 1102,8,5 },   
                { 1097,10,5 },   
                { 1117,10,5 },   
                { 1101,10,5 },   
                { 2357,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 897,
            add_atk = 1596,
            skill_unlock = 6357004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1019,5,5 },   
                { 1018,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1054,5,5 },   
                { 1053,8,5 },   
                { 1103,5,5 },   
                { 1099,5,5 },   
                { 1119,5,5 },   
                { 1098,8,5 },   
                { 1118,8,5 },   
                { 1102,8,5 },   
                { 1097,10,5 },   
                { 1117,10,5 },   
                { 2357,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1196,
            add_atk = 2128,
            skill_unlock = 6357005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1019,8,5 },   
                { 1018,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1055,5,5 },   
                { 1054,10,5 },   
                { 1103,8,5 },   
                { 1099,8,5 },   
                { 1119,8,5 },   
                { 1098,10,5 },   
                { 1118,10,5 },   
                { 1102,10,5 },   
                { 1097,15,5 },   
                { 1117,15,5 },   
                { 2357,1,5 },  
            },
        }, 
    }
}
hero_soul[359] = {
    name = "56452",
    desc = "56539",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56365",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 23,
            add_atk = 29,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 142,
            add_atk = 178,
            skill_unlock = 6359001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1090,5,5 },   
                { 1113,8,5 },   
                { 1089,8,5 },   
                { 1101,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 331,
            add_atk = 417,
            skill_unlock = 6359002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1090,5,5 },   
                { 1102,5,5 },   
                { 1089,10,5 },   
                { 1101,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 521,
            add_atk = 655,
            skill_unlock = 6359003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1091,5,5 },   
                { 1103,5,5 },   
                { 1090,8,5 },   
                { 1102,8,5 },   
                { 1114,8,5 },   
                { 1089,10,5 },   
                { 1101,10,5 },   
                { 1113,10,5 },   
                { 2359,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 711,
            add_atk = 894,
            skill_unlock = 6359004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1062,5,5 },   
                { 1061,8,5 },   
                { 1115,5,5 },   
                { 1091,5,5 },   
                { 1103,5,5 },   
                { 1090,8,5 },   
                { 1102,8,5 },   
                { 1114,8,5 },   
                { 1089,10,5 },   
                { 1101,10,5 },   
                { 2359,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 948,
            add_atk = 1192,
            skill_unlock = 6359005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1063,5,5 },   
                { 1062,10,5 },   
                { 1115,8,5 },   
                { 1091,8,5 },   
                { 1103,8,5 },   
                { 1090,10,5 },   
                { 1102,10,5 },   
                { 1114,10,5 },   
                { 1089,15,5 },   
                { 1101,15,5 },   
                { 2359,1,5 },  
            },
        }, 
    }
}
hero_soul[360] = {
    name = "56453",
    desc = "56540",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56366",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 32,
            add_atk = 30,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 192,
            add_atk = 183,
            skill_unlock = 6360001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1109,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 449,
            add_atk = 428,
            skill_unlock = 6360002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 706,
            add_atk = 673,
            skill_unlock = 6360003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2360,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 963,
            add_atk = 918,
            skill_unlock = 6360004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2360,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1284,
            add_atk = 1224,
            skill_unlock = 6360005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2360,1,5 },  
            },
        }, 
    }
}
hero_soul[361] = {
    name = "56454",
    desc = "56541",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56367",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 34,
            add_atk = 42,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 207,
            add_atk = 257,
            skill_unlock = 6361001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1094,5,5 },   
                { 1109,8,5 },   
                { 1093,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 484,
            add_atk = 600,
            skill_unlock = 6361002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1094,5,5 },   
                { 1126,5,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 761,
            add_atk = 943,
            skill_unlock = 6361003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2361,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1038,
            add_atk = 1287,
            skill_unlock = 6361004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 2361,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1384,
            add_atk = 1716,
            skill_unlock = 6361005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1095,8,5 },   
                { 1127,8,5 },   
                { 1094,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1093,15,5 },   
                { 1125,15,5 },   
                { 2361,1,5 },  
            },
        }, 
    }
}
hero_soul[363] = {
    name = "56455",
    desc = "56542",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56368",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 35,
            add_atk = 43,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 212,
            add_atk = 262,
            skill_unlock = 6363001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1017,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1098,5,5 },   
                { 1109,8,5 },   
                { 1097,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 495,
            add_atk = 613,
            skill_unlock = 6363002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1018,5,5 },   
                { 1017,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1098,5,5 },   
                { 1126,5,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 778,
            add_atk = 963,
            skill_unlock = 6363003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1018,10,5 },   
                { 1017,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1099,5,5 },   
                { 1127,5,5 },   
                { 1098,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2363,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1062,
            add_atk = 1314,
            skill_unlock = 6363004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1019,5,5 },   
                { 1018,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1099,5,5 },   
                { 1127,5,5 },   
                { 1098,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1097,10,5 },   
                { 1125,10,5 },   
                { 2363,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1416,
            add_atk = 1752,
            skill_unlock = 6363005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1019,8,5 },   
                { 1018,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1099,8,5 },   
                { 1127,8,5 },   
                { 1098,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1097,15,5 },   
                { 1125,15,5 },   
                { 2363,1,5 },  
            },
        }, 
    }
}
hero_soul[370] = {
    name = "56456",
    desc = "56543",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56369",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 61,
            add_atk = 21,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 371,
            add_atk = 126,
            skill_unlock = 6370001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1106,5,5 },   
                { 1101,8,5 },   
                { 1105,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 866,
            add_atk = 295,
            skill_unlock = 6370002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1106,5,5 },   
                { 1126,5,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 1361,
            add_atk = 464,
            skill_unlock = 6370003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1102,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1101,10,5 },   
                { 2370,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1857,
            add_atk = 633,
            skill_unlock = 6370004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1103,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1102,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 2370,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 2476,
            add_atk = 844,
            skill_unlock = 6370005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1103,8,5 },   
                { 1107,8,5 },   
                { 1127,8,5 },   
                { 1106,10,5 },   
                { 1126,10,5 },   
                { 1102,10,5 },   
                { 1105,15,5 },   
                { 1125,15,5 },   
                { 2370,1,5 },  
            },
        }, 
    }
}
hero_soul[374] = {
    name = "56457",
    desc = "56544",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56370",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 29,
            add_atk = 36,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 175,
            add_atk = 216,
            skill_unlock = 6374001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1090,5,5 },   
                { 1101,8,5 },   
                { 1089,8,5 },   
                { 1117,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 408,
            add_atk = 504,
            skill_unlock = 6374002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1090,5,5 },   
                { 1118,5,5 },   
                { 1089,10,5 },   
                { 1101,10,5 },   
                { 1117,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 642,
            add_atk = 792,
            skill_unlock = 6374003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1091,5,5 },   
                { 1119,5,5 },   
                { 1090,8,5 },   
                { 1102,8,5 },   
                { 1118,8,5 },   
                { 1089,10,5 },   
                { 1101,10,5 },   
                { 1117,10,5 },   
                { 2374,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 876,
            add_atk = 1080,
            skill_unlock = 6374004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1062,5,5 },   
                { 1061,8,5 },   
                { 1103,5,5 },   
                { 1091,5,5 },   
                { 1119,5,5 },   
                { 1090,8,5 },   
                { 1102,8,5 },   
                { 1118,8,5 },   
                { 1089,10,5 },   
                { 1101,10,5 },   
                { 2374,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1168,
            add_atk = 1440,
            skill_unlock = 6374005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1063,5,5 },   
                { 1062,10,5 },   
                { 1103,8,5 },   
                { 1091,8,5 },   
                { 1119,8,5 },   
                { 1090,10,5 },   
                { 1102,10,5 },   
                { 1118,10,5 },   
                { 1089,15,5 },   
                { 1101,15,5 },   
                { 2374,1,5 },  
            },
        }, 
    }
}
hero_soul[376] = {
    name = "56458",
    desc = "56545",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56371",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 28,
            add_atk = 54,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 168,
            add_atk = 327,
            skill_unlock = 6376001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1090,5,5 },   
                { 1101,8,5 },   
                { 1089,8,5 },   
                { 1113,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 393,
            add_atk = 763,
            skill_unlock = 6376002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1090,5,5 },   
                { 1114,5,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 618,
            add_atk = 1199,
            skill_unlock = 6376003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1091,5,5 },   
                { 1115,5,5 },   
                { 1090,8,5 },   
                { 1114,8,5 },   
                { 1102,8,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 1101,10,5 },   
                { 2376,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 843,
            add_atk = 1635,
            skill_unlock = 6376004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1046,5,5 },   
                { 1045,8,5 },   
                { 1103,5,5 },   
                { 1091,5,5 },   
                { 1115,5,5 },   
                { 1090,8,5 },   
                { 1114,8,5 },   
                { 1102,8,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 2376,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1124,
            add_atk = 2180,
            skill_unlock = 6376005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1047,5,5 },   
                { 1046,10,5 },   
                { 1103,8,5 },   
                { 1091,8,5 },   
                { 1115,8,5 },   
                { 1090,10,5 },   
                { 1114,10,5 },   
                { 1102,10,5 },   
                { 1089,15,5 },   
                { 1113,15,5 },   
                { 2376,1,5 },  
            },
        }, 
    }
}
hero_soul[380] = {
    name = "56459",
    desc = "56546",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56372",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 26,
            add_atk = 57,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 157,
            add_atk = 343,
            skill_unlock = 6380001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1106,5,5 },   
                { 1081,8,5 },   
                { 1105,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 368,
            add_atk = 800,
            skill_unlock = 6380002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1106,5,5 },   
                { 1126,5,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 578,
            add_atk = 1258,
            skill_unlock = 6380003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1082,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1081,10,5 },   
                { 2380,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 789,
            add_atk = 1716,
            skill_unlock = 6380004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1066,5,5 },   
                { 1065,8,5 },   
                { 1083,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1082,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 2380,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1052,
            add_atk = 2288,
            skill_unlock = 6380005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1067,5,5 },   
                { 1066,10,5 },   
                { 1083,8,5 },   
                { 1107,8,5 },   
                { 1127,8,5 },   
                { 1106,10,5 },   
                { 1126,10,5 },   
                { 1082,10,5 },   
                { 1105,15,5 },   
                { 1125,15,5 },   
                { 2380,1,5 },  
            },
        }, 
    }
}
hero_soul[382] = {
    name = "56460",
    desc = "56547",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56373",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 26,
            add_atk = 55,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 158,
            add_atk = 331,
            skill_unlock = 6382001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1025,5,5 },   
                { 1082,5,5 },   
                { 1090,5,5 },   
                { 1081,8,5 },   
                { 1089,8,5 },   
                { 1113,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 369,
            add_atk = 774,
            skill_unlock = 6382002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1026,5,5 },   
                { 1025,8,5 },   
                { 1082,5,5 },   
                { 1090,5,5 },   
                { 1114,5,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 580,
            add_atk = 1216,
            skill_unlock = 6382003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1026,8,5 },   
                { 1025,10,5 },   
                { 1083,5,5 },   
                { 1091,5,5 },   
                { 1115,5,5 },   
                { 1090,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 1081,10,5 },   
                { 2382,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 792,
            add_atk = 1659,
            skill_unlock = 6382004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1027,5,5 },   
                { 1026,10,5 },   
                { 1046,5,5 },   
                { 1045,8,5 },   
                { 1083,5,5 },   
                { 1091,5,5 },   
                { 1115,5,5 },   
                { 1090,8,5 },   
                { 1114,8,5 },   
                { 1082,8,5 },   
                { 1089,10,5 },   
                { 1113,10,5 },   
                { 2382,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1056,
            add_atk = 2212,
            skill_unlock = 6382005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1120,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1027,8,5 },   
                { 1026,15,5 },   
                { 1047,5,5 },   
                { 1046,10,5 },   
                { 1083,8,5 },   
                { 1091,8,5 },   
                { 1115,8,5 },   
                { 1090,10,5 },   
                { 1114,10,5 },   
                { 1082,10,5 },   
                { 1089,15,5 },   
                { 1113,15,5 },   
                { 2382,1,5 },  
            },
        }, 
    }
}
hero_soul[383] = {
    name = "56461",
    desc = "56548",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56374",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 32,
            add_atk = 30,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 192,
            add_atk = 183,
            skill_unlock = 6383001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1109,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 449,
            add_atk = 428,
            skill_unlock = 6383002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 706,
            add_atk = 673,
            skill_unlock = 6383003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2383,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 963,
            add_atk = 918,
            skill_unlock = 6383004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2383,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1284,
            add_atk = 1224,
            skill_unlock = 6383005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2383,1,5 },  
            },
        }, 
    }
}
hero_soul[386] = {
    name = "56462",
    desc = "56549",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56375",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 31,
            add_atk = 21,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 189,
            add_atk = 127,
            skill_unlock = 6386001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1094,5,5 },   
                { 1113,8,5 },   
                { 1093,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 441,
            add_atk = 296,
            skill_unlock = 6386002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1094,5,5 },   
                { 1126,5,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 693,
            add_atk = 466,
            skill_unlock = 6386003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1114,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 1113,10,5 },   
                { 2386,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 945,
            add_atk = 636,
            skill_unlock = 6386004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1115,5,5 },   
                { 1095,5,5 },   
                { 1127,5,5 },   
                { 1094,8,5 },   
                { 1126,8,5 },   
                { 1114,8,5 },   
                { 1093,10,5 },   
                { 1125,10,5 },   
                { 2386,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1260,
            add_atk = 848,
            skill_unlock = 6386005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1115,8,5 },   
                { 1095,8,5 },   
                { 1127,8,5 },   
                { 1094,10,5 },   
                { 1126,10,5 },   
                { 1114,10,5 },   
                { 1093,15,5 },   
                { 1125,15,5 },   
                { 2386,1,5 },  
            },
        }, 
    }
}
hero_soul[387] = {
    name = "56463",
    desc = "56550",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56376",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 25,
            add_atk = 37,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 154,
            add_atk = 222,
            skill_unlock = 6387001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1009,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1094,5,5 },   
                { 1101,8,5 },   
                { 1093,8,5 },   
                { 1085,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 359,
            add_atk = 519,
            skill_unlock = 6387002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1010,5,5 },   
                { 1009,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1094,5,5 },   
                { 1086,5,5 },   
                { 1093,10,5 },   
                { 1085,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 565,
            add_atk = 816,
            skill_unlock = 6387003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1010,10,5 },   
                { 1009,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1095,5,5 },   
                { 1087,5,5 },   
                { 1094,8,5 },   
                { 1086,8,5 },   
                { 1102,8,5 },   
                { 1093,10,5 },   
                { 1085,10,5 },   
                { 1101,10,5 },   
                { 2387,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 771,
            add_atk = 1113,
            skill_unlock = 6387004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1011,5,5 },   
                { 1010,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1058,5,5 },   
                { 1057,8,5 },   
                { 1103,5,5 },   
                { 1095,5,5 },   
                { 1087,5,5 },   
                { 1094,8,5 },   
                { 1086,8,5 },   
                { 1102,8,5 },   
                { 1093,10,5 },   
                { 1085,10,5 },   
                { 2387,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1028,
            add_atk = 1484,
            skill_unlock = 6387005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1011,8,5 },   
                { 1010,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1059,5,5 },   
                { 1058,10,5 },   
                { 1103,8,5 },   
                { 1095,8,5 },   
                { 1087,8,5 },   
                { 1094,10,5 },   
                { 1086,10,5 },   
                { 1102,10,5 },   
                { 1093,15,5 },   
                { 1085,15,5 },   
                { 2387,1,5 },  
            },
        }, 
    }
}
hero_soul[389] = {
    name = "56464",
    desc = "56551",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56377",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 61,
            add_atk = 20,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 366,
            add_atk = 124,
            skill_unlock = 6389001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1013,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1122,5,5 },   
                { 1109,8,5 },   
                { 1121,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 855,
            add_atk = 289,
            skill_unlock = 6389002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1014,5,5 },   
                { 1013,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1122,5,5 },   
                { 1126,5,5 },   
                { 1121,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 1344,
            add_atk = 455,
            skill_unlock = 6389003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1014,10,5 },   
                { 1013,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1123,5,5 },   
                { 1127,5,5 },   
                { 1122,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1121,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2389,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1833,
            add_atk = 621,
            skill_unlock = 6389004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1015,5,5 },   
                { 1014,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1123,5,5 },   
                { 1127,5,5 },   
                { 1122,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1121,10,5 },   
                { 1125,10,5 },   
                { 2389,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 2444,
            add_atk = 828,
            skill_unlock = 6389005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1015,8,5 },   
                { 1014,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1123,8,5 },   
                { 1127,8,5 },   
                { 1122,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1121,15,5 },   
                { 1125,15,5 },   
                { 2389,1,5 },  
            },
        }, 
    }
}
hero_soul[394] = {
    name = "56465",
    desc = "56552",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56378",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 55,
            add_atk = 27,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 330,
            add_atk = 165,
            skill_unlock = 6394001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1013,8,5 },   
                { 1033,5,5 },   
                { 1114,5,5 },   
                { 1122,5,5 },   
                { 1113,8,5 },   
                { 1121,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 771,
            add_atk = 386,
            skill_unlock = 6394002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1014,5,5 },   
                { 1013,10,5 },   
                { 1034,5,5 },   
                { 1033,8,5 },   
                { 1114,5,5 },   
                { 1122,5,5 },   
                { 1126,5,5 },   
                { 1121,10,5 },   
                { 1125,10,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 1212,
            add_atk = 607,
            skill_unlock = 6394003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1014,10,5 },   
                { 1013,15,5 },   
                { 1034,8,5 },   
                { 1033,10,5 },   
                { 1115,5,5 },   
                { 1123,5,5 },   
                { 1127,5,5 },   
                { 1122,8,5 },   
                { 1126,8,5 },   
                { 1114,8,5 },   
                { 1121,10,5 },   
                { 1125,10,5 },   
                { 1113,10,5 },   
                { 2394,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1653,
            add_atk = 828,
            skill_unlock = 6394004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1146,5,5 },   
                { 1015,5,5 },   
                { 1014,10,5 },   
                { 1035,5,5 },   
                { 1034,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1115,5,5 },   
                { 1123,5,5 },   
                { 1127,5,5 },   
                { 1122,8,5 },   
                { 1126,8,5 },   
                { 1114,8,5 },   
                { 1121,10,5 },   
                { 1125,10,5 },   
                { 2394,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 2204,
            add_atk = 1104,
            skill_unlock = 6394005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1147,5,5 },   
                { 1124,5,5 },   
                { 1015,8,5 },   
                { 1014,15,5 },   
                { 1035,8,5 },   
                { 1034,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1115,8,5 },   
                { 1123,8,5 },   
                { 1127,8,5 },   
                { 1122,10,5 },   
                { 1126,10,5 },   
                { 1114,10,5 },   
                { 1121,15,5 },   
                { 1125,15,5 },   
                { 2394,1,5 },  
            },
        }, 
    }
}
hero_soul[409] = {
    name = "56466",
    desc = "56553",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56379",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 44,
            add_atk = 36,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 264,
            add_atk = 219,
            skill_unlock = 6409001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1013,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1122,5,5 },   
                { 1109,8,5 },   
                { 1121,8,5 },   
                { 1117,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 616,
            add_atk = 511,
            skill_unlock = 6409002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1014,5,5 },   
                { 1013,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1122,5,5 },   
                { 1118,5,5 },   
                { 1121,10,5 },   
                { 1117,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 968,
            add_atk = 803,
            skill_unlock = 6409003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1014,10,5 },   
                { 1013,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1123,5,5 },   
                { 1119,5,5 },   
                { 1122,8,5 },   
                { 1118,8,5 },   
                { 1110,8,5 },   
                { 1121,10,5 },   
                { 1117,10,5 },   
                { 1109,10,5 },   
                { 2409,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 1320,
            add_atk = 1095,
            skill_unlock = 6409004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1015,5,5 },   
                { 1014,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1070,5,5 },   
                { 1069,8,5 },   
                { 1111,5,5 },   
                { 1123,5,5 },   
                { 1119,5,5 },   
                { 1122,8,5 },   
                { 1118,8,5 },   
                { 1110,8,5 },   
                { 1121,10,5 },   
                { 1117,10,5 },   
                { 2409,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1760,
            add_atk = 1460,
            skill_unlock = 6409005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1015,8,5 },   
                { 1014,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1071,5,5 },   
                { 1070,10,5 },   
                { 1111,8,5 },   
                { 1123,8,5 },   
                { 1119,8,5 },   
                { 1122,10,5 },   
                { 1118,10,5 },   
                { 1110,10,5 },   
                { 1121,15,5 },   
                { 1117,15,5 },   
                { 2409,1,5 },  
            },
        }, 
    }
}
hero_soul[156] = {
    name = "56467",
    desc = "56554",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56380",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_156.png",
            icon_big = "hs_156.png",
            Lv_max = 40,
            add_hp = 91,
            add_atk = 78,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_156.png",
            icon_big = "hs_156.png",
            Lv_max = 60,
            add_hp = 546,
            add_atk = 468,
            skill_unlock = 6156001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1114,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1097,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_156.png",
            icon_big = "hs_156.png",
            Lv_max = 80,
            add_hp = 1274,
            add_atk = 1092,
            skill_unlock = 6156002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1098,20,5 },   
                { 1122,20,5 },   
                { 1086,10,5 },   
                { 1125,30,5 },   
                { 1121,30,5 },   
                { 1113,30,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_156.png",
            icon_big = "hs_156.png",
            Lv_max = 120,
            add_hp = 2002,
            add_atk = 1716,
            skill_unlock = 6156003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1099,10,5 },   
                { 1098,20,5 },   
                { 1114,20,5 },   
                { 1122,10,5 },   
                { 1101,30,5 },   
                { 1089,30,5 },   
                { 1121,30,5 },   
                { 1215,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_156.png",
            icon_big = "hs_156.png",
            Lv_max = 160,
            add_hp = 2730,
            add_atk = 2340,
            skill_unlock = 6156004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,30,5 },   
                { 1099,20,5 },   
                { 1103,20,5 },   
                { 1122,30,5 },   
                { 1102,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1125,40,5 },   
                { 1215,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_156.png",
            icon_big = "hs_156.png",
            Lv_max = 200,
            add_hp = 3640,
            add_atk = 3120,
            skill_unlock = 6156005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1128,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1099,40,5 },   
                { 1095,30,5 },   
                { 1123,20,5 },   
                { 1122,40,5 },   
                { 1102,30,5 },   
                { 1114,20,5 },   
                { 1085,50,5 },   
                { 1097,50,5 },   
                { 1215,1,5 },  
            },
        }, 
    }
}
hero_soul[184] = {
    name = "56468",
    desc = "56555",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56381",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[353] = {
    name = "56469",
    desc = "56556",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56382",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[367] = {
    name = "56471",
    desc = "56558",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56384",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[369] = {
    name = "56472",
    desc = "56559",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56385",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[373] = {
    name = "56473",
    desc = "56560",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56386",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[377] = {
    name = "56474",
    desc = "56561",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56387",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[379] = {
    name = "56475",
    desc = "56562",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56388",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[381] = {
    name = "56476",
    desc = "56563",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56389",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[385] = {
    name = "56477",
    desc = "56564",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56390",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_385.png",
            icon_big = "hs_385.png",
            Lv_max = 40,
            add_hp = 108,
            add_atk = 75,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_385.png",
            icon_big = "hs_385.png",
            Lv_max = 60,
            add_hp = 649,
            add_atk = 453,
            skill_unlock = 6385001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1021,10,5 },   
                { 1094,20,5 },   
                { 1086,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1125,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_385.png",
            icon_big = "hs_385.png",
            Lv_max = 80,
            add_hp = 1516,
            add_atk = 1058,
            skill_unlock = 6385002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1022,20,5 },   
                { 1021,30,5 },   
                { 1102,20,5 },   
                { 1086,20,5 },   
                { 1122,10,5 },   
                { 1093,30,5 },   
                { 1121,30,5 },   
                { 1085,30,5 },   
                { 1113,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_385.png",
            icon_big = "hs_385.png",
            Lv_max = 120,
            add_hp = 2382,
            add_atk = 1663,
            skill_unlock = 6385003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1022,30,5 },   
                { 1021,40,5 },   
                { 1095,20,5 },   
                { 1087,10,5 },   
                { 1091,10,5 },   
                { 1114,20,5 },   
                { 1122,20,5 },   
                { 1094,10,5 },   
                { 1101,30,5 },   
                { 1089,30,5 },   
                { 1113,30,5 },   
                { 2385,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_385.png",
            icon_big = "hs_385.png",
            Lv_max = 160,
            add_hp = 3249,
            add_atk = 2268,
            skill_unlock = 6385004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1146,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1023,20,5 },   
                { 1022,40,5 },   
                { 1046,20,5 },   
                { 1045,30,5 },   
                { 1095,30,5 },   
                { 1115,20,5 },   
                { 1103,20,5 },   
                { 1122,30,5 },   
                { 1114,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1093,40,5 },   
                { 2385,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_385.png",
            icon_big = "hs_385.png",
            Lv_max = 200,
            add_hp = 4332,
            add_atk = 3024,
            skill_unlock = 6385005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1147,20,5 },   
                { 1146,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1023,30,5 },   
                { 1022,50,5 },   
                { 1047,20,5 },   
                { 1046,30,5 },   
                { 1115,40,5 },   
                { 1095,30,5 },   
                { 1123,20,5 },   
                { 1094,40,5 },   
                { 1102,20,5 },   
                { 1114,30,5 },   
                { 1085,50,5 },   
                { 1097,50,5 },   
                { 2385,1,5 },  
            },
        }, 
    }
}
hero_soul[388] = {
    name = "56478",
    desc = "56565",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56391",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[390] = {
    name = "56479",
    desc = "56566",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56392",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[391] = {
    name = "56480",
    desc = "56567",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56393",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[392] = {
    name = "56481",
    desc = "56568",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56394",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[397] = {
    name = "56482",
    desc = "56569",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56395",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_397.png",
            icon_big = "hs_397.png",
            Lv_max = 40,
            add_hp = 90,
            add_atk = 116,
            skill_unlock = 0,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_397.png",
            icon_big = "hs_397.png",
            Lv_max = 60,
            add_hp = 545,
            add_atk = 696,
            skill_unlock = 6397001,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1001,30,5 },   
                { 1021,10,5 },   
                { 1118,20,5 },   
                { 1114,10,5 },   
                { 1101,40,5 },   
                { 1085,30,5 },   
                { 1113,20,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_397.png",
            icon_big = "hs_397.png",
            Lv_max = 80,
            add_hp = 1272,
            add_atk = 1624,
            skill_unlock = 6397002,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1002,20,5 },   
                { 1001,40,5 },   
                { 1022,20,5 },   
                { 1021,30,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1098,10,5 },   
                { 1125,30,5 },   
                { 1097,30,5 },   
                { 1117,30,5 },   
                { 1121,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_397.png",
            icon_big = "hs_397.png",
            Lv_max = 120,
            add_hp = 1999,
            add_atk = 2552,
            skill_unlock = 6397003,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1002,30,5 },   
                { 1001,50,5 },   
                { 1022,30,5 },   
                { 1021,40,5 },   
                { 1099,20,5 },   
                { 1087,10,5 },   
                { 1115,10,5 },   
                { 1102,20,5 },   
                { 1110,20,5 },   
                { 1122,10,5 },   
                { 1125,30,5 },   
                { 1117,30,5 },   
                { 1085,30,5 },   
                { 1214,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_397.png",
            icon_big = "hs_397.png",
            Lv_max = 160,
            add_hp = 2727,
            add_atk = 3480,
            skill_unlock = 6397004,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1145,10,5 },   
                { 1003,20,5 },   
                { 1002,40,5 },   
                { 1023,20,5 },   
                { 1022,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1119,30,5 },   
                { 1103,20,5 },   
                { 1099,20,5 },   
                { 1118,30,5 },   
                { 1126,30,5 },   
                { 1098,30,5 },   
                { 1101,40,5 },   
                { 1097,40,5 },   
                { 1214,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_397.png",
            icon_big = "hs_397.png",
            Lv_max = 200,
            add_hp = 3636,
            add_atk = 4640,
            skill_unlock = 6397005,
            hp_max = 11000,
            atk_max = 10000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1145,10,5 },   
                { 1003,30,5 },   
                { 1002,50,5 },   
                { 1023,30,5 },   
                { 1022,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1127,40,5 },   
                { 1103,30,5 },   
                { 1115,20,5 },   
                { 1122,40,5 },   
                { 1102,20,5 },   
                { 1114,30,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 1214,1,5 },  
            },
        }, 
    }
}
hero_soul[398] = {
    name = "56483",
    desc = "56570",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56396",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[402] = {
    name = "56484",
    desc = "56571",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56397",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_402.png",
            icon_big = "hs_402.png",
            Lv_max = 40,
            add_hp = 83,
            add_atk = 138,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_402.png",
            icon_big = "hs_402.png",
            Lv_max = 60,
            add_hp = 502,
            add_atk = 831,
            skill_unlock = 6402001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1021,10,5 },   
                { 1114,20,5 },   
                { 1094,10,5 },   
                { 1113,40,5 },   
                { 1117,30,5 },   
                { 1109,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_402.png",
            icon_big = "hs_402.png",
            Lv_max = 80,
            add_hp = 1173,
            add_atk = 1940,
            skill_unlock = 6402002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1022,20,5 },   
                { 1021,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_402.png",
            icon_big = "hs_402.png",
            Lv_max = 120,
            add_hp = 1843,
            add_atk = 3049,
            skill_unlock = 6402003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1022,30,5 },   
                { 1021,40,5 },   
                { 1127,20,5 },   
                { 1083,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1213,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_402.png",
            icon_big = "hs_402.png",
            Lv_max = 160,
            add_hp = 2514,
            add_atk = 4158,
            skill_unlock = 6402004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1128,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1023,20,5 },   
                { 1022,40,5 },   
                { 1058,20,5 },   
                { 1057,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1101,40,5 },   
                { 1089,40,5 },   
                { 1213,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_402.png",
            icon_big = "hs_402.png",
            Lv_max = 200,
            add_hp = 3352,
            add_atk = 5544,
            skill_unlock = 6402005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1120,20,5 },   
                { 1147,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1023,30,5 },   
                { 1022,50,5 },   
                { 1059,20,5 },   
                { 1058,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1117,40,5 },   
                { 1213,1,5 },  
            },
        }, 
    }
}
hero_soul[404] = {
    name = "56485",
    desc = "56572",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56398",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[406] = {
    name = "617761",
    desc = "56573",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56399",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_406.png",
            icon_big = "hs_406.png",
            Lv_max = 40,
            add_hp = 163,
            add_atk = 170,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_406.png",
            icon_big = "hs_406.png",
            Lv_max = 60,
            add_hp = 979,
            add_atk = 1025,
            skill_unlock = 6406001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1033,10,5 },   
                { 1122,20,5 },   
                { 1106,10,5 },   
                { 1089,40,5 },   
                { 1085,30,5 },   
                { 1113,20,5 },   
                { 1121,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_406.png",
            icon_big = "hs_406.png",
            Lv_max = 80,
            add_hp = 2284,
            add_atk = 2392,
            skill_unlock = 6406002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1034,20,5 },   
                { 1033,30,5 },   
                { 1090,20,5 },   
                { 1086,20,5 },   
                { 1122,10,5 },   
                { 1089,40,5 },   
                { 1105,30,5 },   
                { 1113,30,5 },   
                { 1121,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_406.png",
            icon_big = "hs_406.png",
            Lv_max = 120,
            add_hp = 3590,
            add_atk = 3759,
            skill_unlock = 6406003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1034,30,5 },   
                { 1033,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1111,10,5 },   
                { 1106,20,5 },   
                { 1110,20,5 },   
                { 1122,10,5 },   
                { 1121,30,5 },   
                { 1093,30,5 },   
                { 1105,30,5 },   
                { 2406,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_406.png",
            icon_big = "hs_406.png",
            Lv_max = 160,
            add_hp = 4896,
            add_atk = 5127,
            skill_unlock = 6406004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1146,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1035,20,5 },   
                { 1034,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1111,15,5 },   
                { 1099,15,5 },   
                { 1090,30,5 },   
                { 1106,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1097,40,5 },   
                { 2406,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_406.png",
            icon_big = "hs_406.png",
            Lv_max = 200,
            add_hp = 6528,
            add_atk = 6836,
            skill_unlock = 6406005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1146,20,5 },   
                { 1143,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1035,30,5 },   
                { 1034,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,50,5 },   
                { 1103,20,5 },   
                { 1115,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1121,60,5 },   
                { 1113,40,5 },   
                { 2406,1,5 },  
            },
        }, 
    }
}
hero_soul[408] = {
    name = "56487",
    desc = "56574",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56400",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[410] = {
    name = "56488",
    desc = "56575",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56401",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[411] = {
    name = "56489",
    desc = "56576",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56402",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 67,
            add_atk = 110,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 13000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 404,
            add_atk = 662,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 13000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1122,20,5 },   
                { 1106,10,5 },   
                { 1089,40,5 },   
                { 1085,30,5 },   
                { 1113,20,5 },   
                { 1121,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 943,
            add_atk = 1545,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 13000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1090,20,5 },   
                { 1086,20,5 },   
                { 1122,10,5 },   
                { 1089,40,5 },   
                { 1105,30,5 },   
                { 1113,30,5 },   
                { 1121,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1482,
            add_atk = 2428,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 13000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1111,10,5 },   
                { 1106,20,5 },   
                { 1110,20,5 },   
                { 1122,10,5 },   
                { 1121,30,5 },   
                { 1093,30,5 },   
                { 1105,30,5 },   
                { 1207,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2022,
            add_atk = 3312,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 13000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1146,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1062,20,5 },   
                { 1061,30,5 },   
                { 1123,40,5 },   
                { 1111,15,5 },   
                { 1099,15,5 },   
                { 1090,30,5 },   
                { 1106,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1097,40,5 },   
                { 1207,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2696,
            add_atk = 4416,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 13000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1146,20,5 },   
                { 1143,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1063,20,5 },   
                { 1062,30,5 },   
                { 1123,50,5 },   
                { 1103,20,5 },   
                { 1115,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1121,60,5 },   
                { 1113,40,5 },   
                { 1207,1,5 },  
            },
        }, 
    }
}
hero_soul[414] = {
    name = "56490",
    desc = "56577",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56403",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[451] = {
    name = "56491",
    desc = "56578",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56404",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[500] = {
    name = "56492",
    desc = "56579",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56405",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[501] = {
    name = "56493",
    desc = "56580",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56406",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[504] = {
    name = "56495",
    desc = "56582",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56408",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[506] = {
    name = "56496",
    desc = "56583",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56409",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[395] = {
    name = "56497",
    desc = "56584",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56410",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 40,
            add_hp = 56,
            add_atk = 24,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 60,
            add_hp = 338,
            add_atk = 144,
            skill_unlock = 6395001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1005,8,5 },   
                { 1021,5,5 },   
                { 1110,5,5 },   
                { 1106,5,5 },   
                { 1109,8,5 },   
                { 1105,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 80,
            add_hp = 789,
            add_atk = 336,
            skill_unlock = 6395002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1006,5,5 },   
                { 1005,10,5 },   
                { 1022,5,5 },   
                { 1021,8,5 },   
                { 1110,5,5 },   
                { 1106,5,5 },   
                { 1126,5,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 120,
            add_hp = 1240,
            add_atk = 528,
            skill_unlock = 6395003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1006,10,5 },   
                { 1005,15,5 },   
                { 1022,8,5 },   
                { 1021,10,5 },   
                { 1111,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 1109,10,5 },   
                { 2395,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 160,
            add_hp = 1692,
            add_atk = 720,
            skill_unlock = 6395004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1143,5,5 },   
                { 1007,5,5 },   
                { 1006,10,5 },   
                { 1023,5,5 },   
                { 1022,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1111,5,5 },   
                { 1107,5,5 },   
                { 1127,5,5 },   
                { 1106,8,5 },   
                { 1126,8,5 },   
                { 1110,8,5 },   
                { 1105,10,5 },   
                { 1125,10,5 },   
                { 2395,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_013.png",
            icon_big = "hs_013.png",
            Lv_max = 200,
            add_hp = 2256,
            add_atk = 960,
            skill_unlock = 6395005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1142,5,5 },   
                { 1124,5,5 },   
                { 1007,8,5 },   
                { 1006,15,5 },   
                { 1023,8,5 },   
                { 1022,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1111,8,5 },   
                { 1107,8,5 },   
                { 1127,8,5 },   
                { 1106,10,5 },   
                { 1126,10,5 },   
                { 1110,10,5 },   
                { 1105,15,5 },   
                { 1125,15,5 },   
                { 2395,1,5 },  
            },
        }, 
    }
}
hero_soul[600] = {
    name = "56498",
    desc = "56585",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56411",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_600.png",
            icon_big = "hs_600.png",
            Lv_max = 40,
            add_hp = 45,
            add_atk = 65,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                    
            },
        }, 
        break_1 = {
            icon_small = "hss_600.png",
            icon_big = "hs_600.png",
            Lv_max = 60,
            add_hp = 274,
            add_atk = 393,
            skill_unlock = 6600001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1154,2,5 },   
                { 1152,15,5 },   
                { 1153,15,5 },   
                { 1149,35,5 },   
                { 1150,35,5 },   
                { 1151,35,5 },                                                        
            },
        }, 
        break_2 = {
            icon_small = "hss_600.png",
            icon_big = "hs_600.png",
            Lv_max = 80,
            add_hp = 639,
            add_atk = 917,
            skill_unlock = 6600002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型               
                { 1154,4,5 },   
                { 1152,20,5 },   
                { 1153,20,5 },   
                { 1149,50,5 },   
                { 1150,50,5 },   
                { 1151,50,5 },                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_600.png",
            icon_big = "hs_600.png",
            Lv_max = 120,
            add_hp = 1005,
            add_atk = 1441,
            skill_unlock = 6600003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                           
                { 1154,6,5 },   
                { 1152,25,5 },   
                { 1153,25,5 },   
                { 1149,65,5 },   
                { 1150,65,5 },   
                { 1151,65,5 },   
                { 2600,1,5 },                              
            },
        }, 
        break_4 = {
            icon_small = "hss_600.png",
            icon_big = "hs_600.png",
            Lv_max = 160,
            add_hp = 1371,
            add_atk = 1965,
            skill_unlock = 6600004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1154,8,5 },   
                { 1152,30,5 },   
                { 1153,30,5 },   
                { 1149,80,5 },   
                { 1150,80,5 },   
                { 1151,80,5 },   
                { 2600,1,5 },                
            },
        }, 
        break_5 = {
            icon_small = "hss_600.png",
            icon_big = "hs_600.png",
            Lv_max = 200,
            add_hp = 1828,
            add_atk = 2620,
            skill_unlock = 6600005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                       
                { 1154,10,5 },   
                { 1152,35,5 },   
                { 1153,35,5 },   
                { 1149,95,5 },   
                { 1150,95,5 },   
                { 1151,95,5 },   
                { 2600,1,5 },  
            },
        }, 
    }
}
hero_soul[601] = {
    name = "56499",
    desc = "56586",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56412",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_601.png",
            icon_big = "hs_601.png",
            Lv_max = 40,
            add_hp = 49,
            add_atk = 60,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                    
            },
        }, 
        break_1 = {
            icon_small = "hss_601.png",
            icon_big = "hs_601.png",
            Lv_max = 60,
            add_hp = 299,
            add_atk = 364,
            skill_unlock = 6601001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1155,2,5 },   
                { 1152,15,5 },   
                { 1153,15,5 },   
                { 1149,35,5 },   
                { 1150,35,5 },   
                { 1151,35,5 },                                                        
            },
        }, 
        break_2 = {
            icon_small = "hss_601.png",
            icon_big = "hs_601.png",
            Lv_max = 80,
            add_hp = 698,
            add_atk = 851,
            skill_unlock = 6601002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型               
                { 1155,4,5 },   
                { 1152,20,5 },   
                { 1153,20,5 },   
                { 1149,50,5 },   
                { 1150,50,5 },   
                { 1151,50,5 },                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_601.png",
            icon_big = "hs_601.png",
            Lv_max = 120,
            add_hp = 1097,
            add_atk = 1337,
            skill_unlock = 6601003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                           
                { 1155,6,5 },   
                { 1152,25,5 },   
                { 1153,25,5 },   
                { 1149,65,5 },   
                { 1150,65,5 },   
                { 1151,65,5 },   
                { 2601,1,5 },                              
            },
        }, 
        break_4 = {
            icon_small = "hss_601.png",
            icon_big = "hs_601.png",
            Lv_max = 160,
            add_hp = 1497,
            add_atk = 1824,
            skill_unlock = 6601004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1155,8,5 },   
                { 1152,30,5 },   
                { 1153,30,5 },   
                { 1149,80,5 },   
                { 1150,80,5 },   
                { 1151,80,5 },   
                { 2601,1,5 },                
            },
        }, 
        break_5 = {
            icon_small = "hss_601.png",
            icon_big = "hs_601.png",
            Lv_max = 200,
            add_hp = 1996,
            add_atk = 2432,
            skill_unlock = 6601005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                       
                { 1155,10,5 },   
                { 1152,35,5 },   
                { 1153,35,5 },   
                { 1149,95,5 },   
                { 1150,95,5 },   
                { 1151,95,5 },   
                { 2601,1,5 },  
            },
        }, 
    }
}
hero_soul[602] = {
    name = "56500",
    desc = "56587",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56413",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_602.png",
            icon_big = "hs_602.png",
            Lv_max = 40,
            add_hp = 55,
            add_atk = 55,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                    
            },
        }, 
        break_1 = {
            icon_small = "hss_602.png",
            icon_big = "hs_602.png",
            Lv_max = 60,
            add_hp = 335,
            add_atk = 332,
            skill_unlock = 6602001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1156,2,5 },   
                { 1152,15,5 },   
                { 1153,15,5 },   
                { 1149,35,5 },   
                { 1150,35,5 },   
                { 1151,35,5 },                                                        
            },
        }, 
        break_2 = {
            icon_small = "hss_602.png",
            icon_big = "hs_602.png",
            Lv_max = 80,
            add_hp = 782,
            add_atk = 775,
            skill_unlock = 6602002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型               
                { 1156,4,5 },   
                { 1152,20,5 },   
                { 1153,20,5 },   
                { 1149,50,5 },   
                { 1150,50,5 },   
                { 1151,50,5 },                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_602.png",
            icon_big = "hs_602.png",
            Lv_max = 120,
            add_hp = 1229,
            add_atk = 1218,
            skill_unlock = 6602003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                           
                { 1156,6,5 },   
                { 1152,25,5 },   
                { 1153,25,5 },   
                { 1149,65,5 },   
                { 1150,65,5 },   
                { 1151,65,5 },   
                { 2602,1,5 },                              
            },
        }, 
        break_4 = {
            icon_small = "hss_602.png",
            icon_big = "hs_602.png",
            Lv_max = 160,
            add_hp = 1677,
            add_atk = 1662,
            skill_unlock = 6602004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1156,8,5 },   
                { 1152,30,5 },   
                { 1153,30,5 },   
                { 1149,80,5 },   
                { 1150,80,5 },   
                { 1151,80,5 },   
                { 2602,1,5 },                
            },
        }, 
        break_5 = {
            icon_small = "hss_602.png",
            icon_big = "hs_602.png",
            Lv_max = 200,
            add_hp = 2236,
            add_atk = 2216,
            skill_unlock = 6602005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                       
                { 1156,10,5 },   
                { 1152,35,5 },   
                { 1153,35,5 },   
                { 1149,95,5 },   
                { 1150,95,5 },   
                { 1151,95,5 },   
                { 2602,1,5 },  
            },
        }, 
    }
}
hero_soul[603] = {
    name = "56501",
    desc = "56588",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56414",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_603.png",
            icon_big = "hs_603.png",
            Lv_max = 40,
            add_hp = 52,
            add_atk = 54,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                    
            },
        }, 
        break_1 = {
            icon_small = "hss_603.png",
            icon_big = "hs_603.png",
            Lv_max = 60,
            add_hp = 315,
            add_atk = 325,
            skill_unlock = 6603001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1157,2,5 },   
                { 1152,15,5 },   
                { 1153,15,5 },   
                { 1149,35,5 },   
                { 1150,35,5 },   
                { 1151,35,5 },                                                        
            },
        }, 
        break_2 = {
            icon_small = "hss_603.png",
            icon_big = "hs_603.png",
            Lv_max = 80,
            add_hp = 736,
            add_atk = 760,
            skill_unlock = 6603002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型               
                { 1157,4,5 },   
                { 1152,20,5 },   
                { 1153,20,5 },   
                { 1149,50,5 },   
                { 1150,50,5 },   
                { 1151,50,5 },                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_603.png",
            icon_big = "hs_603.png",
            Lv_max = 120,
            add_hp = 1157,
            add_atk = 1194,
            skill_unlock = 6603003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                           
                { 1157,6,5 },   
                { 1152,25,5 },   
                { 1153,25,5 },   
                { 1149,65,5 },   
                { 1150,65,5 },   
                { 1151,65,5 },   
                { 2603,1,5 },                              
            },
        }, 
        break_4 = {
            icon_small = "hss_603.png",
            icon_big = "hs_603.png",
            Lv_max = 160,
            add_hp = 1578,
            add_atk = 1629,
            skill_unlock = 6603004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1157,8,5 },   
                { 1152,30,5 },   
                { 1153,30,5 },   
                { 1149,80,5 },   
                { 1150,80,5 },   
                { 1151,80,5 },   
                { 2603,1,5 },                
            },
        }, 
        break_5 = {
            icon_small = "hss_603.png",
            icon_big = "hs_603.png",
            Lv_max = 200,
            add_hp = 2104,
            add_atk = 2172,
            skill_unlock = 6603005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                       
                { 1157,10,5 },   
                { 1152,35,5 },   
                { 1153,35,5 },   
                { 1149,95,5 },   
                { 1150,95,5 },   
                { 1151,95,5 },   
                { 2603,1,5 },  
            },
        }, 
    }
}
hero_soul[604] = {
    name = "56502",
    desc = "56589",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56415",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_604.png",
            icon_big = "hs_604.png",
            Lv_max = 40,
            add_hp = 67,
            add_atk = 36,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                    
            },
        }, 
        break_1 = {
            icon_small = "hss_604.png",
            icon_big = "hs_604.png",
            Lv_max = 60,
            add_hp = 405,
            add_atk = 220,
            skill_unlock = 6604001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1158,2,5 },   
                { 1152,15,5 },   
                { 1153,15,5 },   
                { 1149,35,5 },   
                { 1150,35,5 },   
                { 1151,35,5 },                                                        
            },
        }, 
        break_2 = {
            icon_small = "hss_604.png",
            icon_big = "hs_604.png",
            Lv_max = 80,
            add_hp = 945,
            add_atk = 513,
            skill_unlock = 6604002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型               
                { 1158,4,5 },   
                { 1152,20,5 },   
                { 1153,20,5 },   
                { 1149,50,5 },   
                { 1150,50,5 },   
                { 1151,50,5 },                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_604.png",
            icon_big = "hs_604.png",
            Lv_max = 120,
            add_hp = 1485,
            add_atk = 807,
            skill_unlock = 6604003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                           
                { 1158,6,5 },   
                { 1152,25,5 },   
                { 1153,25,5 },   
                { 1149,65,5 },   
                { 1150,65,5 },   
                { 1151,65,5 },   
                { 2604,1,5 },                              
            },
        }, 
        break_4 = {
            icon_small = "hss_604.png",
            icon_big = "hs_604.png",
            Lv_max = 160,
            add_hp = 2025,
            add_atk = 1101,
            skill_unlock = 6604004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1158,8,5 },   
                { 1152,30,5 },   
                { 1153,30,5 },   
                { 1149,80,5 },   
                { 1150,80,5 },   
                { 1151,80,5 },   
                { 2604,1,5 },                
            },
        }, 
        break_5 = {
            icon_small = "hss_604.png",
            icon_big = "hs_604.png",
            Lv_max = 200,
            add_hp = 2700,
            add_atk = 1468,
            skill_unlock = 6604005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                       
                { 1158,10,5 },   
                { 1152,35,5 },   
                { 1153,35,5 },   
                { 1149,95,5 },   
                { 1150,95,5 },   
                { 1151,95,5 },   
                { 2604,1,5 },  
            },
        }, 
    }
}
hero_soul[605] = {
    name = "56503",
    desc = "56590",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56416",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_605.png",
            icon_big = "hs_605.png",
            Lv_max = 40,
            add_hp = 56,
            add_atk = 55,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                    
            },
        }, 
        break_1 = {
            icon_small = "hss_605.png",
            icon_big = "hs_605.png",
            Lv_max = 60,
            add_hp = 340,
            add_atk = 332,
            skill_unlock = 6605001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1159,2,5 },   
                { 1152,15,5 },   
                { 1153,15,5 },   
                { 1149,35,5 },   
                { 1150,35,5 },   
                { 1151,35,5 },                                                        
            },
        }, 
        break_2 = {
            icon_small = "hss_605.png",
            icon_big = "hs_605.png",
            Lv_max = 80,
            add_hp = 793,
            add_atk = 775,
            skill_unlock = 6605002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型               
                { 1159,4,5 },   
                { 1152,20,5 },   
                { 1153,20,5 },   
                { 1149,50,5 },   
                { 1150,50,5 },   
                { 1151,50,5 },                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_605.png",
            icon_big = "hs_605.png",
            Lv_max = 120,
            add_hp = 1247,
            add_atk = 1218,
            skill_unlock = 6605003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                           
                { 1159,6,5 },   
                { 1152,25,5 },   
                { 1153,25,5 },   
                { 1149,65,5 },   
                { 1150,65,5 },   
                { 1151,65,5 },   
                { 2605,1,5 },                              
            },
        }, 
        break_4 = {
            icon_small = "hss_605.png",
            icon_big = "hs_605.png",
            Lv_max = 160,
            add_hp = 1701,
            add_atk = 1662,
            skill_unlock = 6605004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1159,8,5 },   
                { 1152,30,5 },   
                { 1153,30,5 },   
                { 1149,80,5 },   
                { 1150,80,5 },   
                { 1151,80,5 },   
                { 2605,1,5 },                
            },
        }, 
        break_5 = {
            icon_small = "hss_605.png",
            icon_big = "hs_605.png",
            Lv_max = 200,
            add_hp = 2268,
            add_atk = 2216,
            skill_unlock = 6605005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                       
                { 1159,10,5 },   
                { 1152,35,5 },   
                { 1153,35,5 },   
                { 1149,95,5 },   
                { 1150,95,5 },   
                { 1151,95,5 },   
                { 2605,1,5 },  
            },
        }, 
    }
}
hero_soul[527] = {
    name = "56504",
    desc = "56591",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[528] = {
    name = "617064",
    desc = "611712",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_528.png",
            icon_big = "hs_528.png",
            Lv_max = 40,
            add_hp = 126,
            add_atk = 105,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_528.png",
            icon_big = "hs_528.png",
            Lv_max = 60,
            add_hp = 760,
            add_atk = 632,
            skill_unlock = 6528001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1017,30,5 },   
                { 1029,10,5 },   
                { 1118,20,5 },   
                { 1099,20,5 },   
                { 1117,30,5 },   
                { 1105,30,5 },   
                { 1101,30,5 },   
                { 1093,30,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_528.png",
            icon_big = "hs_528.png",
            Lv_max = 80,
            add_hp = 1773,
            add_atk = 1475,
            skill_unlock = 6528002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1018,20,5 },   
                { 1017,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1094,30,5 },   
                { 1118,20,5 },   
                { 1098,20,5 },   
                { 1105,20,5 },   
                { 1101,20,5 },   
                { 1113,20,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_528.png",
            icon_big = "hs_528.png",
            Lv_max = 120,
            add_hp = 2787,
            add_atk = 2318,
            skill_unlock = 6528003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1018,30,5 },   
                { 1017,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1119,20,5 },   
                { 1099,10,5 },   
                { 1087,10,5 },   
                { 1094,20,5 },   
                { 1106,20,5 },   
                { 1118,20,5 },   
                { 1101,20,5 },   
                { 1117,20,5 },   
                { 1113,20,5 },   
                { 2528,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_528.png",
            icon_big = "hs_528.png",
            Lv_max = 160,
            add_hp = 3801,
            add_atk = 3162,
            skill_unlock = 6528004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1145,10,5 },   
                { 1019,20,5 },   
                { 1018,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1058,20,5 },   
                { 1057,30,5 },   
                { 1119,30,5 },   
                { 1091,20,5 },   
                { 1083,20,5 },   
                { 1094,40,5 },   
                { 1110,30,5 },   
                { 1114,30,5 },   
                { 1121,30,5 },   
                { 1101,30,5 },   
                { 2528,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_528.png",
            icon_big = "hs_528.png",
            Lv_max = 200,
            add_hp = 5068,
            add_atk = 4216,
            skill_unlock = 6528005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1145,20,5 },   
                { 1128,10,5 },   
                { 1019,30,5 },   
                { 1018,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1059,20,5 },   
                { 1058,30,5 },   
                { 1119,40,5 },   
                { 1115,30,5 },   
                { 1087,30,5 },   
                { 1118,40,5 },   
                { 1094,30,5 },   
                { 1098,30,5 },   
                { 1097,50,5 },   
                { 1101,50,5 },   
                { 2528,1,5 },  
            },
        }, 
    }
}
hero_soul[529] = {
    name = "611717",
    desc = "611711",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_529.png",
            icon_big = "hs_529.png",
            Lv_max = 40,
            add_hp = 100,
            add_atk = 119,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_529.png",
            icon_big = "hs_529.png",
            Lv_max = 60,
            add_hp = 603,
            add_atk = 714,
            skill_unlock = 6529001,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1126,20,5 },   
                { 1102,10,5 },   
                { 1125,40,5 },   
                { 1113,30,5 },   
                { 1085,20,5 },   
                { 1093,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_529.png",
            icon_big = "hs_529.png",
            Lv_max = 80,
            add_hp = 1407,
            add_atk = 1666,
            skill_unlock = 6529002,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1126,30,5 },   
                { 1094,20,5 },   
                { 1114,10,5 },   
                { 1125,30,5 },   
                { 1085,30,5 },   
                { 1097,20,5 },   
                { 1089,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_529.png",
            icon_big = "hs_529.png",
            Lv_max = 120,
            add_hp = 2211,
            add_atk = 2618,
            skill_unlock = 6529003,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1091,15,5 },   
                { 1095,10,5 },   
                { 1126,20,5 },   
                { 1094,15,5 },   
                { 1082,10,5 },   
                { 1125,40,5 },   
                { 1093,30,5 },   
                { 1089,10,5 },   
                { 2529,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_529.png",
            icon_big = "hs_529.png",
            Lv_max = 160,
            add_hp = 3015,
            add_atk = 3570,
            skill_unlock = 6529004,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1143,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1062,20,5 },   
                { 1061,30,5 },   
                { 1127,30,5 },   
                { 1091,30,5 },   
                { 1119,10,5 },   
                { 1126,30,5 },   
                { 1094,36,5 },   
                { 1102,36,5 },   
                { 1125,50,5 },   
                { 1113,30,5 },   
                { 2529,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_529.png",
            icon_big = "hs_529.png",
            Lv_max = 200,
            add_hp = 4020,
            add_atk = 4760,
            skill_unlock = 6529005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1143,20,5 },   
                { 1146,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1063,20,5 },   
                { 1062,30,5 },   
                { 1127,40,5 },   
                { 1091,30,5 },   
                { 1095,20,5 },   
                { 1098,40,5 },   
                { 1086,30,5 },   
                { 1114,30,5 },   
                { 1125,50,5 },   
                { 1093,50,5 },   
                { 2529,1,5 },  
            },
        }, 
    }
}
hero_soul[530] = {
    name = "611718",
    desc = "611713",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 1,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 50,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 40,
            add_hp = 32,
            add_atk = 48,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                  
            },
        }, 
        break_1 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 60,
            add_hp = 193,
            add_atk = 288,
            skill_unlock = 6530001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,5,5 },   
                { 1001,8,5 },   
                { 1029,5,5 },   
                { 1102,5,5 },   
                { 1090,5,5 },   
                { 1101,8,5 },   
                { 1089,8,5 },   
                { 1125,8,5 },                                                                                                                                  
            },
        }, 
        break_2 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 80,
            add_hp = 450,
            add_atk = 672,
            skill_unlock = 6530002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                   
                { 1144,10,5 },   
                { 1002,5,5 },   
                { 1001,10,5 },   
                { 1030,5,5 },   
                { 1029,8,5 },   
                { 1102,5,5 },   
                { 1090,5,5 },   
                { 1126,5,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1101,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 120,
            add_hp = 708,
            add_atk = 1056,
            skill_unlock = 6530003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                         
                { 1144,15,5 },   
                { 1141,5,5 },   
                { 1002,10,5 },   
                { 1001,15,5 },   
                { 1030,8,5 },   
                { 1029,10,5 },   
                { 1103,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1102,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 1101,10,5 },   
                { 2530,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 160,
            add_hp = 966,
            add_atk = 1440,
            skill_unlock = 6530004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                         
                { 1144,20,5 },   
                { 1141,8,5 },   
                { 1145,5,5 },   
                { 1003,5,5 },   
                { 1002,10,5 },   
                { 1031,5,5 },   
                { 1030,10,5 },   
                { 1042,5,5 },   
                { 1041,8,5 },   
                { 1103,5,5 },   
                { 1091,5,5 },   
                { 1127,5,5 },   
                { 1090,8,5 },   
                { 1126,8,5 },   
                { 1102,8,5 },   
                { 1089,10,5 },   
                { 1125,10,5 },   
                { 2530,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_999.png",
            icon_big = "hs_999.png",
            Lv_max = 200,
            add_hp = 1288,
            add_atk = 1920,
            skill_unlock = 6530005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                             
                { 1144,30,5 },   
                { 1141,15,5 },   
                { 1148,5,5 },   
                { 1128,5,5 },   
                { 1003,8,5 },   
                { 1002,15,5 },   
                { 1031,8,5 },   
                { 1030,15,5 },   
                { 1043,5,5 },   
                { 1042,10,5 },   
                { 1103,8,5 },   
                { 1091,8,5 },   
                { 1127,8,5 },   
                { 1090,10,5 },   
                { 1126,10,5 },   
                { 1102,10,5 },   
                { 1089,15,5 },   
                { 1125,15,5 },   
                { 2530,1,5 },  
            },
        }, 
    }
}
hero_soul[531] = {
    name = "611719",
    desc = "611714",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 65,
            add_atk = 63,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 392,
            add_atk = 379,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1009,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1122,10,5 },   
                { 1085,40,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },   
                { 1101,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 915,
            add_atk = 884,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1010,20,5 },   
                { 1009,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1102,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1101,40,5 },   
                { 1093,30,5 },   
                { 1085,30,5 },   
                { 1113,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1438,
            add_atk = 1390,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1010,30,5 },   
                { 1009,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1127,20,5 },   
                { 1087,10,5 },   
                { 1095,10,5 },   
                { 1122,20,5 },   
                { 1114,20,5 },   
                { 1126,10,5 },   
                { 1102,30,5 },   
                { 1093,30,5 },   
                { 1094,30,5 },   
                { 1211,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 1962,
            add_atk = 1896,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1124,10,5 },   
                { 1011,20,5 },   
                { 1010,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1066,20,5 },   
                { 1065,30,5 },   
                { 1123,40,5 },   
                { 1103,15,5 },   
                { 1095,15,5 },   
                { 1086,30,5 },   
                { 1094,30,5 },   
                { 1114,30,5 },   
                { 1103,40,5 },   
                { 1089,40,5 },   
                { 1211,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 2616,
            add_atk = 2528,
            skill_unlock = 6999005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1128,20,5 },   
                { 1148,10,5 },   
                { 1011,30,5 },   
                { 1010,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1067,20,5 },   
                { 1066,30,5 },   
                { 1115,50,5 },   
                { 1103,20,5 },   
                { 1095,20,5 },   
                { 1122,50,5 },   
                { 1102,20,5 },   
                { 1126,20,5 },   
                { 1121,60,5 },   
                { 1125,40,5 },   
                { 1211,1,5 },  
            },
        }, 
    }
}
hero_soul[532] = {
    name = "617760",
    desc = "611715",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 1,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_532.png",
            icon_big = "hs_532.png",
            Lv_max = 40,
            add_hp = 180,
            add_atk = 133,
            skill_unlock = 0,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_532.png",
            icon_big = "hs_532.png",
            Lv_max = 60,
            add_hp = 1082,
            add_atk = 798,
            skill_unlock = 6532001,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1033,10,5 },   
                { 1122,20,5 },   
                { 1102,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1085,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_532.png",
            icon_big = "hs_532.png",
            Lv_max = 80,
            add_hp = 2525,
            add_atk = 1863,
            skill_unlock = 6532002,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1034,20,5 },   
                { 1033,30,5 },   
                { 1114,20,5 },   
                { 1122,20,5 },   
                { 1082,10,5 },   
                { 1121,30,5 },   
                { 1117,30,5 },   
                { 1113,30,5 },   
                { 1125,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_532.png",
            icon_big = "hs_532.png",
            Lv_max = 120,
            add_hp = 3968,
            add_atk = 2928,
            skill_unlock = 6532003,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1034,30,5 },   
                { 1033,40,5 },   
                { 1115,20,5 },   
                { 1123,10,5 },   
                { 1127,10,5 },   
                { 1114,20,5 },   
                { 1082,20,5 },   
                { 1122,10,5 },   
                { 1121,30,5 },   
                { 1081,30,5 },   
                { 1117,30,5 },   
                { 2532,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_532.png",
            icon_big = "hs_532.png",
            Lv_max = 160,
            add_hp = 5412,
            add_atk = 3993,
            skill_unlock = 6532004,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1120,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1035,20,5 },   
                { 1034,40,5 },   
                { 1070,20,5 },   
                { 1069,30,5 },   
                { 1123,30,5 },   
                { 1115,20,5 },   
                { 1087,20,5 },   
                { 1122,30,5 },   
                { 1126,30,5 },   
                { 1114,30,5 },   
                { 1081,40,5 },   
                { 1125,40,5 },   
                { 2532,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_532.png",
            icon_big = "hs_532.png",
            Lv_max = 200,
            add_hp = 7216,
            add_atk = 5324,
            skill_unlock = 6532005,
            hp_max = 8000,
            atk_max = 8000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1124,20,5 },   
                { 1128,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1035,30,5 },   
                { 1034,50,5 },   
                { 1071,20,5 },   
                { 1070,30,5 },   
                { 1123,40,5 },   
                { 1127,30,5 },   
                { 1115,20,5 },   
                { 1082,40,5 },   
                { 1122,30,5 },   
                { 1102,20,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2532,1,5 },  
            },
        }, 
    }
}
hero_soul[524] = {
    name = "56494",
    desc = "601217",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 83,
            add_atk = 117,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 502,
            add_atk = 705,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1114,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1097,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1173,
            add_atk = 1646,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1098,20,5 },   
                { 1122,20,5 },   
                { 1086,10,5 },   
                { 1125,30,5 },   
                { 1121,30,5 },   
                { 1113,30,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1843,
            add_atk = 2587,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1099,10,5 },   
                { 1098,20,5 },   
                { 1114,20,5 },   
                { 1122,10,5 },   
                { 1101,30,5 },   
                { 1089,30,5 },   
                { 1121,30,5 },   
                { 2610,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2514,
            add_atk = 3528,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,30,5 },   
                { 1099,20,5 },   
                { 1103,20,5 },   
                { 1122,30,5 },   
                { 1102,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1125,40,5 },   
                { 2610,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3352,
            add_atk = 4704,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1128,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1099,40,5 },   
                { 1095,30,5 },   
                { 1123,20,5 },   
                { 1122,40,5 },   
                { 1102,30,5 },   
                { 1114,20,5 },   
                { 1085,50,5 },   
                { 1097,50,5 },   
                { 2610,1,5 },  
            },
        }, 
    }
}
hero_soul[525] = {
    name = "56495",
    desc = "601218",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 83,
            add_atk = 117,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 502,
            add_atk = 705,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1114,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1097,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1173,
            add_atk = 1646,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1098,20,5 },   
                { 1122,20,5 },   
                { 1086,10,5 },   
                { 1125,30,5 },   
                { 1121,30,5 },   
                { 1113,30,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1843,
            add_atk = 2587,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1099,10,5 },   
                { 1098,20,5 },   
                { 1114,20,5 },   
                { 1122,10,5 },   
                { 1101,30,5 },   
                { 1089,30,5 },   
                { 1121,30,5 },   
                { 2610,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2514,
            add_atk = 3528,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,30,5 },   
                { 1099,20,5 },   
                { 1103,20,5 },   
                { 1122,30,5 },   
                { 1102,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1125,40,5 },   
                { 2610,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3352,
            add_atk = 4704,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1128,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1099,40,5 },   
                { 1095,30,5 },   
                { 1123,20,5 },   
                { 1122,40,5 },   
                { 1102,30,5 },   
                { 1114,20,5 },   
                { 1085,50,5 },   
                { 1097,50,5 },   
                { 2610,1,5 },  
            },
        }, 
    }
}
hero_soul[132] = {
    name = "56496",
    desc = "601219",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 83,
            add_atk = 117,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 502,
            add_atk = 705,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1114,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1097,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1173,
            add_atk = 1646,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1098,20,5 },   
                { 1122,20,5 },   
                { 1086,10,5 },   
                { 1125,30,5 },   
                { 1121,30,5 },   
                { 1113,30,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1843,
            add_atk = 2587,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1099,10,5 },   
                { 1098,20,5 },   
                { 1114,20,5 },   
                { 1122,10,5 },   
                { 1101,30,5 },   
                { 1089,30,5 },   
                { 1121,30,5 },   
                { 2610,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2514,
            add_atk = 3528,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,30,5 },   
                { 1099,20,5 },   
                { 1103,20,5 },   
                { 1122,30,5 },   
                { 1102,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1125,40,5 },   
                { 2610,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3352,
            add_atk = 4704,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1128,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1099,40,5 },   
                { 1095,30,5 },   
                { 1123,20,5 },   
                { 1122,40,5 },   
                { 1102,30,5 },   
                { 1114,20,5 },   
                { 1085,50,5 },   
                { 1097,50,5 },   
                { 2610,1,5 },  
            },
        }, 
    }
}
hero_soul[355] = {
    name = "56496",
    desc = "601219",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 83,
            add_atk = 117,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 502,
            add_atk = 705,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1013,30,5 },   
                { 1029,10,5 },   
                { 1102,20,5 },   
                { 1114,10,5 },   
                { 1101,40,5 },   
                { 1121,30,5 },   
                { 1113,20,5 },   
                { 1097,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1173,
            add_atk = 1646,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1014,20,5 },   
                { 1013,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1098,20,5 },   
                { 1122,20,5 },   
                { 1086,10,5 },   
                { 1125,30,5 },   
                { 1121,30,5 },   
                { 1113,30,5 },   
                { 1109,20,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1843,
            add_atk = 2587,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1014,30,5 },   
                { 1013,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,20,5 },   
                { 1087,10,5 },   
                { 1099,10,5 },   
                { 1098,20,5 },   
                { 1114,20,5 },   
                { 1122,10,5 },   
                { 1101,30,5 },   
                { 1089,30,5 },   
                { 1121,30,5 },   
                { 2610,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2514,
            add_atk = 3528,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,60,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1015,20,5 },   
                { 1014,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,30,5 },   
                { 1099,20,5 },   
                { 1103,20,5 },   
                { 1122,30,5 },   
                { 1102,30,5 },   
                { 1098,30,5 },   
                { 1081,40,5 },   
                { 1125,40,5 },   
                { 2610,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3352,
            add_atk = 4704,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1128,10,5 },   
                { 1015,30,5 },   
                { 1014,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1099,40,5 },   
                { 1095,30,5 },   
                { 1123,20,5 },   
                { 1122,40,5 },   
                { 1102,30,5 },   
                { 1114,20,5 },   
                { 1085,50,5 },   
                { 1097,50,5 },   
                { 2610,1,5 },  
            },
        }, 
    }
}
hero_soul[700] = {
    name = "56494",
    desc = "614609",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[702] = {
    name = "56495",
    desc = "614610",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[703] = {
    name = "56496",
    desc = "614611",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[704] = {
    name = "56496",
    desc = "614612",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[705] = {
    name = "56496",
    desc = "614613",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[393] = {
    name = "56496",
    desc = "614614",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[511] = {
    name = "56496",
    desc = "615739",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[503] = {
    name = "56496",
    desc = "615740",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[534] = {
    name = "56496",
    desc = "615741",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[514] = {
    name = "56496",
    desc = "616269",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[513] = {
    name = "56496",
    desc = "616270",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[366] = {
    name = "56496",
    desc = "56557",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[519] = {
    name = "56496",
    desc = "616632",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[520] = {
    name = "56496",
    desc = "616633",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[502] = {
    name = "56496",
    desc = "616884",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[535] = {
    name = "56496",
    desc = "616885",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[538] = {
    name = "56496",
    desc = "617132",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[540] = {
    name = "56496",
    desc = "617133",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[539] = {
    name = "56496",
    desc = "617428",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[541] = {
    name = "56496",
    desc = "617429",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[537] = {
    name = "56496",
    desc = "617767",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[516] = {
    name = "56496",
    desc = "617991",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[542] = {
    name = "56496",
    desc = "617992",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[543] = {
    name = "56496",
    desc = "618145",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}
hero_soul[544] = {
    name = "56496",
    desc = "618188",
    open_lv = 15,  -- 魂灵开放等级限制
    unlock_type = 2,  -- 1 3/4星角色  2 5星角色
    unlock_msg = "56417",
    unlock_lv = 1,  -- 魂灵角色解锁等级
    enabled = 0,  -- 0 未开放  1 已开放
    animation = "hun_ling_jie_suo.atlas",  -- 点击专属剧情解锁立绘动画资源
    soul_break = {
        total_break = 5, 
        break_0 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 40,
            add_hp = 76,
            add_atk = 127,
            skill_unlock = 0,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                                                      
            },
        }, 
        break_1 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 60,
            add_hp = 457,
            add_atk = 764,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型   
                { 1144,10,5 },   
                { 1005,30,5 },   
                { 1029,10,5 },   
                { 1106,30,5 },   
                { 1118,15,5 },   
                { 1097,40,5 },   
                { 1085,25,5 },   
                { 1101,25,5 },   
                { 1117,20,5 },                                                                                                                                    
            },
        }, 
        break_2 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 80,
            add_hp = 1068,
            add_atk = 1783,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                     
                { 1144,30,5 },   
                { 1006,20,5 },   
                { 1005,40,5 },   
                { 1030,20,5 },   
                { 1029,30,5 },   
                { 1106,40,5 },   
                { 1122,30,5 },   
                { 1114,15,5 },   
                { 1097,40,5 },   
                { 1113,30,5 },   
                { 1105,30,5 },   
                { 1081,10,5 },                                                                                                            
            },
        }, 
        break_3 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 120,
            add_hp = 1678,
            add_atk = 2802,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                             
                { 1144,50,5 },   
                { 1141,10,5 },   
                { 1006,30,5 },   
                { 1005,50,5 },   
                { 1030,30,5 },   
                { 1029,40,5 },   
                { 1123,25,5 },   
                { 1099,10,5 },   
                { 1115,10,5 },   
                { 1106,50,5 },   
                { 1098,15,5 },   
                { 1113,15,5 },   
                { 1117,30,5 },   
                { 1121,30,5 },   
                { 1097,30,5 },   
                { 2611,1,5 },                                                                            
            },
        }, 
        break_4 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 160,
            add_hp = 2289,
            add_atk = 3822,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                             
                { 1144,70,5 },   
                { 1141,20,5 },   
                { 1148,10,5 },   
                { 1007,20,5 },   
                { 1006,40,5 },   
                { 1031,20,5 },   
                { 1030,40,5 },   
                { 1042,20,5 },   
                { 1041,30,5 },   
                { 1123,40,5 },   
                { 1087,15,5 },   
                { 1111,15,5 },   
                { 1106,60,5 },   
                { 1094,20,5 },   
                { 1122,20,5 },   
                { 1121,40,5 },   
                { 1105,40,5 },   
                { 2611,1,5 },                                        
            },
        }, 
        break_5 = {
            icon_small = "hss_998.png",
            icon_big = "hs_998.png",
            Lv_max = 200,
            add_hp = 3052,
            add_atk = 5096,
            skill_unlock = 6999005,
            hp_max = 12000,
            atk_max = 12000,
            common_icon_big = "hs_998.png",  -- 通用大图
            common_icon_small = "hss_998.png",  -- 通用小图
            break_mat = {
                -- ID 数量 类型                                                                                                                 
                { 1144,90,5 },   
                { 1141,40,5 },   
                { 1148,20,5 },   
                { 1147,10,5 },   
                { 1007,30,5 },   
                { 1006,50,5 },   
                { 1031,30,5 },   
                { 1030,50,5 },   
                { 1043,20,5 },   
                { 1042,30,5 },   
                { 1123,40,5 },   
                { 1103,25,5 },   
                { 1115,25,5 },   
                { 1106,70,5 },   
                { 1094,25,5 },   
                { 1098,25,5 },   
                { 1121,50,5 },   
                { 1113,50,5 },   
                { 2611,1,5 },  
            },
        }, 
    }
}