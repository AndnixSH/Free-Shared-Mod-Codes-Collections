--/*说明

--*/
AstrolabeSthEff = {}
--[[	effData
	_self 调用的对象
	final 升级后的等级
	asLv  未升级前的等级
	effData ={
		
		["EffSthExpbar"]   = 强化经验条
		["imageModel"]     = 模版  
		["EffSthBall"]     = 经验球
		["EffSthBallFade"] = 球消失
		["EffSthExpFull"]  = 经验条满
		["EffSthLvnum"]    = 等级上升


	}用到的特效


]]
AstrolabeSthEff.isPlayB = false
function AstrolabeSthEff:init(_self,final)
	self.baseSelf   = _self
	--当前的最大等级
	self.finalLevel = final
	--记录升级前的等级
	self.curLv      = self.baseSelf.asLv
	--记录升级前的经验值
	self.curExp     = self.baseSelf.serverData["astrolabe"]["exp"]
	--吃狗粮获取的经验
	self.addExp     = self.baseSelf.matAddExp
	--最大等级
	self.maxLv      = #hero_astrolabe[self.baseSelf.hero_sub_id]["upgrade"]
	--经验条特效panel
	self.effExpbar   = self.baseSelf.panelEffcet:getChildByName("effExpbar")
	--球特效panel
 	self.effExpball  = self.baseSelf.panelEffcet:getChildByName("effExpball")
 	--升级特效panel
 	self.effLevel    = self.baseSelf.panelEffcet:getChildByName("effLevel")
 	if self.finalLevel >= self.maxLv then
 		self.finalExp      = 100
 		self.finalExpNext  = 100
 	else
 		self.finalExp = self.baseSelf.finalExp --self.curExp + self.addExp
 		self.finalExpNext = self.baseSelf.finalExpNext--hero_astrolabe[self.baseSelf.hero_sub_id]["upgrade"][self.finalLevel][2]
 	end
    --现在是否播放特效
 	self:playEffect()
    --是否在播放特效
    self.isPlayEff = true
end
function AstrolabeSthEff:playEffect()
    -- self.panelEffect:setVisible(true)
    AstrolabeSthEff.isPlayB = true
    self.baseSelf.panelEffcet:setVisible(true)
    self.baseSelf.expText:setString("")
    self.baseSelf.expBar:setVisible(false)
    self.baseSelf.expBar2:setVisible(false)

    local addlv = self.finalLevel - self.curLv

    local once_time = 0.4

    --经验条特效node
    local nodeExpbar = cc.CSLoader:createNode("EffSthExpbar.csb")
    --经验特效
    local timelineExpbar =cc.CSLoader:createTimeline("EffSthExpbar.csb")
    --背景大小
    local psize = self.effExpbar:getSize()

    --裁切 模版放到底板上裁剪出模版样式
    --node
    local clipNode = cc.ClippingNode:create()
    --模版
    local clipSprite = cc.Sprite:create()
    --底板
    local clipLayer = cc.Layer:create()
    --设置模版
    clipSprite:setTexture("n_UIShare/astrolabe/xp_ui_005.png")
    clipSprite:setPosition(cc.p(psize.width / 2 , psize.height / 2))
    clipNode:setAlphaThreshold(0.5)
    clipNode:setStencil(clipSprite)
    --设置底板
    clipNode:addChild(clipLayer)    

    ---播放特效
    local pos_y = psize.height / 2
    nodeExpbar:runAction(timelineExpbar)
    timelineExpbar:play("animation0",true)
    --添加创建裁剪的node
    self.effExpbar:addChild(clipNode,1,123)   
    --设置裁剪的底板
    clipLayer:addChild(nodeExpbar)        

    --经验球
    local nodeBall = cc.CSLoader:createNode("EffSthBall.csb")
    local timelineBall = cc.CSLoader:createTimeline("EffSthBall.csb")       
    local psize2 = self.effExpball:getSize()
    local pos_y2 = psize2.height / 2
    nodeBall:runAction(timelineBall)
    timelineBall:play("animation0",true)
    self.effExpball:addChild(nodeBall,2,123)

    local function playExpBarBall(ratio,ratio2,endFunc)
        --经验条
        nodeExpbar:setVisible(true)        
        nodeExpbar:setPosition(cc.p(ratio * psize.width,pos_y))
        local moveby = cc.MoveBy:create(ratio2 * once_time,
                                        cc.p( ratio2 * psize.width ,  0)
                                        )
        local seq = cc.Sequence:create(moveby, cc.CallFunc:create(endFunc))
        nodeExpbar:runAction(seq)

        --球
        nodeBall:setVisible(true)
        nodeBall:setPosition(cc.p(ratio * psize2.width,pos_y2))
        local moveby2 = cc.MoveBy:create(ratio2 * once_time,
                                        cc.p( ratio2 * psize2.width ,  0)
                                        )
        nodeBall:runAction(moveby2)

    end

    --球消失
    local nodeBallFade = cc.CSLoader:createNode("EffSthBallFade.csb")
    local timelineBallFade = cc.CSLoader:createTimeline("EffSthBallFade.csb")
    nodeBallFade:setPosition(cc.p(psize2.width,pos_y2))
    nodeBallFade:runAction(timelineBallFade)
    self.effExpball:addChild(nodeBallFade,3,234)

    --经验条满
    local nodeExpFull = cc.CSLoader:createNode("EffSthExpFull.csb")
    local timelineExpFull = cc.CSLoader:createTimeline("EffSthExpFull.csb")
    nodeExpFull:setPosition(cc.p(psize2.width / 2,pos_y2))
    nodeExpFull:runAction(timelineExpFull)
    self.effExpball:addChild(nodeExpFull,1,345)
    
    --等级上升
    local nodeLvnum = cc.CSLoader:createNode("EffSthLvnum.csb")
    local timelineLvnum = cc.CSLoader:createTimeline("EffSthLvnum.csb")
    local psize3 = self.effLevel:getSize()
    nodeLvnum:setPosition(cc.p(psize3.width / 2,0))
    nodeLvnum:runAction(timelineLvnum)
    self.effLevel:addChild(nodeLvnum,1,123)
                                     
    if addlv == 0 then
        --没升级，播一次涨条

        local tempNextExp = hero_astrolabe[self.baseSelf.hero_sub_id]["upgrade"][self.curLv][2]  --满级经验
        local ratio =  self.curExp / tempNextExp   --开始百分比
        local ratio2 = self.addExp / tempNextExp   --涨多少

        self:playLVMusic(1)
        playExpBarBall(ratio,ratio2,function()
            self:stopLVEMusic()
            self:onEffectEnd()
        end)
    else
        -- 1次当前经验到满条
        -- addlv - 1次满条 
        -- 1次最后部分
        local nowlv = self.curLv

        local runBarFull = nil 

        local function runOnce()
            --走一条经验到满级
            self:playLVMusic(1)
            playExpBarBall(0,1,function()
                runBarFull()
            end)
            --已满级则停止
            --未满级则继续下一级
        end
        runBarFull = function()
            self:stopLVEMusic()
            nodeBall:setVisible(false)
            nodeExpbar:setVisible(false)
            --满级三个闪光
            --runOnce()
            nowlv = nowlv + 1
            --self:setCurLv(nowlv)
            self.baseSelf.lv:setString(UITool.ToLocalization("星盘等级")..nowlv)
            if nowlv == self.finalLevel then
                --升级完毕，播最后                
                timelineExpFull:setLastFrameCallFunc(function()
                    local tempMax = self.maxLv--math.min(self.maxLv, #hero_astrolabe[self.baseSelf.hero_sub_id]["upgrade"])

                    if (self.finalLevel >= tempMax) then
                        --已满级，不博最后一条
                            self:onEffectEnd()
                    else
                        --未满级，播最后一条
                        self:playLVMusic(1)
                        playExpBarBall(0,self.finalExp / self.finalExpNext,function()
                            self:stopLVEMusic()
                            self:onEffectEnd()
                        end)
                    end
                end)
            end
            --每次升级播放的特效。经验条 经验球 升级
            timelineBallFade:play("animation0",false)
            timelineExpFull:play("animation0",false)
            timelineLvnum:play("animation0",false)
            self:playLVMusic(2)

        end

        timelineExpFull:setLastFrameCallFunc(runOnce)

        local tempNextExp = hero_astrolabe[self.baseSelf.hero_sub_id]["upgrade"][self.curLv][2]  --满级经验
        local ratio =  self.curExp / tempNextExp   --开始百分比
        self:playLVMusic(1)
        playExpBarBall(ratio,(1-ratio),runBarFull)
    end

end
--播放音效
function AstrolabeSthEff:playLVMusic(type)
	if type == 1 then
		self:stopLVEMusic()
        self.lvping_handle = AudioManager:shareDataManager():playMusic("music/ui/lvuping.mp3",0, true)
	else
	
        AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3",0, false)
	end
end
--暂停音效
function AstrolabeSthEff:stopLVEMusic()
	if self.lvping_handle ~= nil then
        AudioManager:shareDataManager():stop(self.lvping_handle)
		self.lvping_handle = nil
	end
end
--返回播放特效
function AstrolabeSthEff:getIsPlay( ... )
    return self.isPlayEff
end

--暂停特效
function AstrolabeSthEff:onEffectEnd()
    self.isPlayEff = false
    self:stopEffect()
    self:refrshAsMainLa()
    AstrolabeSthEff.isPlayB = false
end
--暂停特效
function AstrolabeSthEff:stopEffect()
    --self.panelEffect:stopAllActions()

    local effs = {
        self.effLevel,
        self.effExpball,
        self.effExpbar
    }

    for i = 1,#effs do
        effs[i]:removeAllChildren()
    end

    self:stopLVEMusic()
    self.baseSelf.panelEffcet:setVisible(false)
end







