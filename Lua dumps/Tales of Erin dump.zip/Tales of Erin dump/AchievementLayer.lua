require "BasicLayer"

AchievementLayer= class("AchievementLayer",BasicLayer)
AchievementLayer.__index        = AchievementLayer
AchievementLayer.lClass         = 3
AchievementLayer.everydayTable  = nil  -- 每日成就
AchievementLayer.weekTable      = nil  -- 每周成就
AchievementLayer.durationTable  = nil  -- 每月成就
AchievementLayer.TypeIndex      = 1 -- 1 每日成就  2 本周 3 连续 

AchievementLayer.changeTable    = nil
AchievementLayer.Boxtab         = nil -- 获取宝箱的列表
AchievementLayer.panelList      = nil

function AchievementLayer:init()
	local node  = cc.CSLoader:createNode("AchievementLayer.csb")
    self.uiLayer:addChild(node,0,2)
    local panel = node:getChildByName("Panel_right")
    self.exist = true
    self:brightImage(1)
    self:initBut()
    self:initListView()
    self:BoxTouch()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)
end

function AchievementLayer:initBut( ... )
	-- body
	local node      = self.uiLayer:getChildByTag(2);
	local panel_r   = node:getChildByName("Panel_right")
	local but_day   = panel_r:getChildByName("Image_day")   --  每日成就
	local but_Close = panel_r:getChildByName("Button_close") 
	local but_day1  = panel_r:getChildByName("Image_day_1") --  本周
	local but_mo    = panel_r:getChildByName("Image_mo")    --  连续
    local but_ch    = panel_r:getChildByName("Image_mo_0")    --  称号
    --做UI时候没有这个图   现在直接在代码里面改过来
    --but_ch:loadTexture("res/uifile/n_UIShare/Achievement/cjxt_b_005_1.png")
	local function touchCallBack(sender,eventType)
	   local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
        	if name == "Image_day" then  -- 每日奖励
        		self:brightImage(1)
                self:sendTable(1)
                self:showBox()
                --self:setBoxSate()
        	elseif name == "Image_day_1" then  --  连续成就
        		self:brightImage(2)
                self:sendTable(2)
                self:HidBox()
        	elseif name == "Image_mo" then --  本月成就
        		self:brightImage(3)
                self:sendTable(3)
                self:HidBox()
        	elseif name == "Button_close" then
                self:returnBack()
            elseif name == "Image_mo_0" then -- 称号成就
                self:brightImage(4)
                self:sendTable(4)
                self:HidBox()
        	end
       end
    end

   self:setNodeLockState(but_day1,but_mo,but_ch)
    
    but_Close:addTouchEventListener(touchCallBack)
    but_Close:setEffectType(3)
------------------没有开放显示灰色事件注销--------------------
    --but_day1:loadTexture("res/uifile/n_UIShare/Achievement/cjxt_b_003_1.png")
    --but_mo:loadTexture("res/uifile/n_UIShare/Achievement/cjxt_b_004_1.png")
    -- but_mo:setEnabled(false)
    -- but_day1:setEnabled(false)
    but_day:addTouchEventListener(touchCallBack)
    but_day1:addTouchEventListener(touchCallBack)
    but_mo:addTouchEventListener(touchCallBack)
    but_ch:addTouchEventListener(touchCallBack)
end

function AchievementLayer:setNodeLockState( btn1,btn2,btn3 )
    -- body
    local but_day1 = btn2
    local but_mo = btn3
    local but_ch = btn4
    
    if but_day1 then
        UnlockSys:getInstance():bindLock(45, but_day1, true)
    end

    if but_mo then
        UnlockSys:getInstance():bindLock(46, but_mo, true)
    end

    if but_ch then
        UnlockSys:getInstance():bindLock(47, but_ch, true)
    end
    
end

function AchievementLayer:brightImage( index )
	-- body
	local node      = self.uiLayer:getChildByTag(2);
	local panel_r   = node:getChildByName("Panel_right")
	local but_day   = panel_r:getChildByName("Image_day")
	local but_day1  = panel_r:getChildByName("Image_day_1")
	local but_mo    = panel_r:getChildByName("Image_mo")
    local but_ch    = panel_r:getChildByName("Image_mo_0")
    print("现在的 index == "..index)
--	/Users/Helloworld/Desktop/cocos3.6/CocosProjects/XbreakStudio/cocosstudio/n_UIShare/Achievement/cjxt_b_002_1.png
	if index == 1 then
		but_day:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_001_2.png")
		but_day1:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_003_1.png")
		but_mo:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_002_1.png")
        but_ch:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_004_1.png")
		self.TypeIndex = 1
        self.isLoadDone = false
        self.amountLend = nil
        --self:sendTable()
       
	elseif index == 2 then

        but_day:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_001_1.png")
        but_day1:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_003_2.png")
        but_mo:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_002_1.png")
        but_ch:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_004_1.png")
		self.TypeIndex = 2
        self.isLoadDone = false
        self.amountLend = nil
       -- self:sendTable()
	elseif index == 3 then

        but_day:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_001_1.png")
        but_day1:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_003_1.png")
        but_mo:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_002_2.png")
        but_ch:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_004_1.png")
		self.TypeIndex = 3
        self.isLoadDone = false
        self.amountLend = nil
        --self:sendTable()
    elseif index == 4 then

        but_day:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_001_1.png")
        but_day1:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_003_1.png")
        but_mo:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_002_1.png")
        but_ch:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_b_004_2.png")
        self.TypeIndex = 4
        self.isLoadDone = false
        self.amountLend = nil
	end
end
-- 红色叹号的提示
function AchievementLayer:refeshHint( ... )
    -- body

end
-- 隐藏宝箱
function AchievementLayer:HidBox( ... )
    -- body
    local node  = self.uiLayer:getChildByTag(2);
    local bg    = node:getChildByName("Image_box_bg");
    bg:setVisible(false)
end
function AchievementLayer:showBox( ... )
    -- body
    local node  = self.uiLayer:getChildByTag(2);
    local bg    = node:getChildByName("Image_box_bg");
    bg:setVisible(true)
end
-- 点击宝箱的时间
function AchievementLayer:BoxTouch( ... )
    -- body
    local node  = self.uiLayer:getChildByTag(2);
    local bg    = node:getChildByName("Image_box_bg");
    local box_3 = bg:getChildByName("Image_box_3");
    local box_7 = bg:getChildByName("Image_box_7") 
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
            if name == "Image_box_3" then
                print("box3 外层调用")
                self:getBox3()
            elseif name == "Image_box_7" then
                self:getBox7()
            end
       end
    end
    box_3:addTouchEventListener(touchCallBack)
    box_7:addTouchEventListener(touchCallBack)
    
end
-- 三天的点击回调
function AchievementLayer:getBox3( ... )
    if self.Boxtab ~= nil and self.Boxtab[1] ~= nil and self.Boxtab[1]["state"] ~= nil then
        if self.Boxtab[1]["state"] == 0 or self.Boxtab[1]["state"] == 2 then
             if self.Boxtab[1]["item_list"] ~= nil then
                 if #self.Boxtab[1]["item_list"] <= 1 then
                    print("3个人物奖励 弹出奖励 类型== "..self.Boxtab[1]["item_list"][1].type)
                    print("3个人物奖励 弹出奖励 id == "..self.Boxtab[1]["item_list"][1].id)
                    MsgManager:showSimpItemInfo(self.Boxtab[1]["item_list"][1].type,self.Boxtab[1]["item_list"][1].id,self.Boxtab[1]["item_list"][1].num,"物品信息")
                 else
                    local sData = {}
                    sData["naem"] = UITool.ToLocalization("物品信息")
                    sData["AllData"] = self.Boxtab[1]["item_list"]
                    sData["isShow"] = true
                    self.sManager:toMailGetAllLayer(sData)
                 end
             end
        else
            if self.Boxtab[1]["item_list"] ~= nil then
                 if #self.Boxtab[1]["item_list"] <= 1 then
                    print("3个人物奖励 领取奖励 类型== "..self.Boxtab[1]["item_list"][1].type)
                    print("3个人物奖励 领取奖励 id == "..self.Boxtab[1]["item_list"][1].id)
                    MsgManager:showSimpItemInfo(self.Boxtab[1]["item_list"][1].type,self.Boxtab[1]["item_list"][1].id,self.Boxtab[1]["item_list"][1].num,"获取物品")
                 else
                    local sData = {}
                    sData["AllData"] = self.Boxtab[1]["item_list"]
                    self.sManager:toMailGetAllLayer(sData)
                 end
            end
            self:sendBox(self.Boxtab[1].id,3)
       end
    end
end
-- 7天的点击回调
function AchievementLayer:getBox7( ... )
    -- body
    if self.Boxtab ~= nil and self.Boxtab[2] ~= nil and self.Boxtab[2]["state"] ~= nil then
        if self.Boxtab[2]["state"] == 0 or self.Boxtab[2]["state"] == 2 then
             if self.Boxtab[2]["item_list"] ~= nil then
                if #self.Boxtab[2]["item_list"] <= 1 then
                    MsgManager:showSimpItemInfo(self.Boxtab[2]["item_list"][1].type,self.Boxtab[2]["item_list"][1].id,self.Boxtab[2]["item_list"][1].num,"物品信息")
                else
                    local sData = {}
                    sData["naem"] = UITool.ToLocalization("物品信息")
                    sData["AllData"] = self.Boxtab[2]["item_list"]
                    sData["isShow"] = true
                    self.sManager:toMailGetAllLayer(sData)
                end
             end
        else
            if self.Boxtab[2]["item_list"] ~= nil then
                if #self.Boxtab[2]["item_list"] <= 1 then
                    MsgManager:showSimpItemInfo(self.Boxtab[2]["item_list"][1].type,self.Boxtab[2]["item_list"][1].id,self.Boxtab[2]["item_list"][1].num,"获取物品")
                else
                    local sData = {}
                    sData["AllData"] = self.Boxtab[2]["item_list"]
                    self.sManager:toMailGetAllLayer(sData)
                end
            end
            self:sendBox(self.Boxtab[2].id,7)
        end
    end
end
--设置宝箱的状态
function AchievementLayer:setBoxSate( ... )
    -- body
    local node  = self.uiLayer:getChildByTag(2);
    local bg    = node:getChildByName("Image_box_bg");
    local box_3 = bg:getChildByName("Image_box_3");

    local box_7 = bg:getChildByName("Image_box_7") 
    box_3:getChildByName("Text_28"):setFontSize(16)
    box_7:getChildByName("Text_28_0"):setFontSize(16)
   -- state:0,未完成 1可领取 2
   for i = 1,#self.Boxtab do
        local testBtn = nil
        if i == 1 then
            testBtn = box_3
        else
            testBtn = box_7
        end
        if self.Boxtab[i]["state"] == 0 then
            testBtn:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_ui_010.png")
            if i== 1 then
                testBtn:getChildByName("Text_28"):setString(UITool.ToLocalization("完成3个任务开启"))
            else
                testBtn:getChildByName("Text_28_0"):setString(UITool.ToLocalization("完成7个任务开启"))
            end
        elseif self.Boxtab[i]["state"] == 1 then
            testBtn:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_ui_011.png")
            if i== 1 then
                testBtn:getChildByName("Text_28"):setVisible(false)
            else
                testBtn:getChildByName("Text_28_0"):setVisible(false)
            end
        elseif self.Boxtab[i]["state"] == 2 then
            testBtn:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_ui_009.png")
            if i== 1 then
                testBtn:getChildByName("Text_28"):setVisible(false)
            else
                testBtn:getChildByName("Text_28_0"):setVisible(false)
            end
        end
   end

end
function AchievementLayer:sendBox( id ,indexBox)
    -- body
    local function reiceSthCallBack(data)
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if  self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        local node  = self.uiLayer:getChildByTag(2);
        local bg    = node:getChildByName("Image_box_bg");
        local box_3 = bg:getChildByName("Image_box_3");
        local box_7 = bg:getChildByName("Image_box_7") 
        if indexBox == 3 then
            box_3:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_ui_009.png")
            self.Boxtab[1]["state"] = 2
           -- box_3:getChildByName("Text_28"):setString(UITool.ToLocalization("已领取"))
        elseif indexBox == 7 then
            box_7:loadTexture("res/uifile/n_UIShare/Achievement/rwjm_ui_009.png")
            self.Boxtab[2]["state"] = 2
          --  box_7:getChildByName("Text_28_0"):setString("已领取")
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "achi_extra_get",
        ["reward_id"]   = id
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function AchievementLayer:initListView( ... )
    -- body

    local node      = self.uiLayer:getChildByTag(2);
    local panel = node:getChildByName("Panel_right")
    self.panelList = panel:getChildByName("Panel_List")
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,830,145)
    self.gridview.itemCreateEvent = function()
        local temp = AchievementNode.new():init()
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()
                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    print("curId == "..temp.curId)
                    self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                end
            end
        end 
        --temp.PanelList:getChildByName("Button_get"):setSwallowTouches(false)
        -- temp.PanelList:getChildByName("Image_panel")setSwallowTouches(false)
        --temp.PanelList:getChildByName("Button_get"):addTouchEventListener(touchCallBack)
        temp.PanelList:getChildByName("Panel_touch"):setSwallowTouches(false)
        temp.PanelList:getChildByName("Panel_touch"):setVisible(false)
        temp.PanelList:getChildByName("Panel_touch"):addTouchEventListener(touchCallBack)

        return temp
    end
    self:sendTable(1)
end
--刷新Tble  每次点击不一样的 table 都会更改
function AchievementLayer:refreshTale()
    print("self.changeTable self.changeTable == "..#self.changeTable)
    self.gridview:setDataSource(self.changeTable)
end

function AchievementLayer:returnBack( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    self.backFunc(self.sManager,self.sData)
    self.exist = false
    self.sData = {}
    self.rData = {}
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()

end
function AchievementLayer:sendGet( id,ItemId,ItemType,ItemNum )
    -- body
    local function reiceSthCallBack(data)
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
           
            return
        end
        
        XbTriggerGuideManager:finishGuide(TriggerGuideConfig.Achive, self)

        -------------根据类型刷新及时跟新数据-------------
        if ItemType ~= 16 then
            if g_channel_control.UIVersion > 1 then
                local itemData  ={}
                local oneItemData = {}
                oneItemData["id"]        = ItemId
                oneItemData["item_type"] = ItemType
                oneItemData["num"]       = ItemNum
                
                table.insert(itemData,oneItemData)

                local sData = {}
                sData["AllData"] = itemData
                sData["naem"] = UITool.ToLocalization("获取成功")
                if self.sManager ~= nil then
                    self.sManager:toMailGetAllLayer(sData)
                end

            else
                 MsgManager:showSimpItemInfo(ItemType,ItemId,ItemNum,UITool.ToLocalization("获取成功"))
            end
            
           
        else
            MsgManager:showBaseSpine(ItemId)
        end
       -- MsgManager:showSimpItemInfo(ItemType,ItemId,ItemNum,UITool.ToLocalization("获取成功"))
        local testTable = t_data["data"]["achi_change"]
        print(cjsonSafe.encode(testTable))
        user_info["gold"] = t_data["data"]["resource"]["gold"]
        user_info["gem"]  = t_data["data"]["resource"]["gem"]
        user_info["ap"] = t_data["data"]["resource"]["ap"] or user_info["ap"]
        if self.sManager ~= nil then
            self.sManager.menuLayer:RefshTopBar()
        end
        -- 根据新街口的需求 需要从新来下服务器列表
        self.everydayTable = nil;
        self:sendTable(5)
       -- local len  =  #testTable["1"]
       -- print("len len len =="..len)
        -- if #testTable[""..id] > 0 then  --根据服务器返回的值 来进行修改当前单一的选项的状态
        --     local ArrTable = testTable[""..id]
        --    -- print("len > 1")
        --       --print("self.testTable == "..ArrTable[1]["curr_times"])
        --     for i = 1 ,#ArrTable do
        --          print("self.testTable == "..ArrTable[i]["curr_times"])
        --         for j = 1 , #self.everydayTable do
        --              print("self.everydayTable == "..self.everydayTable[j]["curr_times"])
        --             if self.everydayTable[j]["id"] == ArrTable[i]["id"] then
        --                 self.everydayTable[j] = ArrTable[i]          
        --             end
        --         end
        --     end

        -- end
        --排序
       -- if self.TypeIndex == 1 then
            -- for i = 1 , #self.everydayTable do
            --     if self.everydayTable[i]["id"] == id then
            --         self.everydayTable[i]["state"] = 2 
            --         self.changeTable   = nil
            --         self.changeTable   = self.everydayTable
            --         print("self.changeTable == "..#self.changeTable)
            --         self:getRefeshHonfdian()
            --         self:SortItem()

            --         return
            --     end
            -- end


        -- self.sManager.menuLayer:RefshTopBar()
        if self.TypeIndex == 1 then
            self:sendTable(1)
        end


    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "achi_get",
        ["achi_type"] = self.TypeIndex,
        ["achi_id"]   = id
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function AchievementLayer:sendTable(inden)
	-- body
	local function reiceSthCallBack(data)
        print("获取人物奖励")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self ~= nil and self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            --MsgManager:showSimpMsg(t_data["data"]["warning"])
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
	        return
        end

        self:refeshHonfdian(t_data)
        self.everydayTable = t_data["data"]["list"]--t_data["data"]["everyday_list"]
        
        self.changeTable = self.everydayTable
        self:getRefeshHonfdian()
        self:SortItem()
        if inden == 1 then
            self.Boxtab  = t_data["data"]["extra_reward_list"]
            print("sendata 3个人物奖励 奖励 类型== "..self.Boxtab[1]["item_list"][1].type)
            print("sendata 3个人物奖励 奖励 id == "..self.Boxtab[1]["item_list"][1].id)
            self:setBoxSate()

            if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Achive) then 
                XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.Achive)
            end 
        end
        
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "achi_list",
        ["achi_type"] = self.TypeIndex,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 是否显示红点
function AchievementLayer:refeshHonfdian( t_data )
    -- body
    if self.uiLayer == nil then
        return
    end
    for i = 1, # t_data["data"]["achi_state"] do
        local node       = self.uiLayer:getChildByTag(2);
        local panel_r    = node:getChildByName("Panel_right")
        local but_day    = panel_r:getChildByName("Image_day")   --  每日成就
        local but_Close  = panel_r:getChildByName("Button_close") 
        local but_day1   = panel_r:getChildByName("Image_day_1") --  本周
        local but_mo     = panel_r:getChildByName("Image_mo")    --  连续
        local but_ch     = panel_r:getChildByName("Image_mo_0")    --  称号
        local changedBtn = nil
        if i == 1 then
            changedBtn = but_day
        elseif i == 2 then
            changedBtn = but_day1
        elseif i == 3 then
            changedBtn = but_mo
        elseif i == 4 then
            changedBtn = but_ch
        end
        if t_data["data"]["achi_state"][i] == 0 then
            UITool.setCommmonBtnRedDop(changedBtn,false)
        elseif t_data["data"]["achi_state"][i] == 1 then
            UITool.setCommmonBtnRedDop(changedBtn,true,cc.p(139,79))
        end
        -- if self.TypeIndex == i then
        --     UITool.setCommmonBtnRedDop(changedBtn,false)
        -- end
    end
end
-- 获取后刷新红点
function AchievementLayer:getRefeshHonfdian( ... )
    -- body
    if self.uiLayer == nil then
        return
    end
    local isNot = false
    for i = 1,#self.changeTable do
        if  self.changeTable[i]["state"] == 1 then
            isNot = true
        end 
    end
    if isNot == false then
        local node       = self.uiLayer:getChildByTag(2);
        local panel_r    = node:getChildByName("Panel_right")
        local but_day    = panel_r:getChildByName("Image_day")   --  每日成就
        local but_Close  = panel_r:getChildByName("Button_close") 
        local but_day1   = panel_r:getChildByName("Image_day_1") --  本周
        local but_mo     = panel_r:getChildByName("Image_mo")    --  连续
        local but_ch     = panel_r:getChildByName("Image_mo_0")    --  连续
        local changedBtn = nil
        if self.TypeIndex == 1 then
            changedBtn = but_day
        elseif self.TypeIndex == 2 then
            changedBtn = but_day1
        elseif self.TypeIndex == 3 then
            changedBtn = but_mo
        elseif self.TypeIndex == 4 then
            changedBtn = but_ch
        end
        UITool.setCommmonBtnRedDop(changedBtn,false)
    end
end
function AchievementLayer:SortItem( tab )
    -- body
------------------怎样的排序----------------------
    local function getStatePriority(_state)
        local priority = 1
        if _state == 1 then 
            priority = 3
        elseif _state == 0 then 
            priority = 2
        end 
        return priority
    end
    local function SortFunc(a,b)
        a.state_priority = getStatePriority(a.state) 
        b.state_priority = getStatePriority(b.state) 
        if a.state_priority == b.state_priority then
            if a.state_priority == 3 then 
                return tonumber(a.id) > tonumber(b.id)
            else 
                return tonumber(a.id) < tonumber(b.id)
            end   
        else
            return a.state_priority > b.state_priority
        end
    end

    table.sort(self.changeTable ,SortFunc)
    -- 需要刷新新的列表
    --self:addItem(self.changeTable,1,4)
    self:refreshTale()
    
end

function AchievementLayer:create(rData)
    local login = AchievementLayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end