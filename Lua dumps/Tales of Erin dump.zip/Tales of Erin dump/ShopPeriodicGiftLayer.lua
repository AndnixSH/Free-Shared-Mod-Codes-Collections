
require "BasicLayer"
-- 登陆奖励
ShopPeriodicGiftLayer = class("ShopPeriodicGiftLayer",BasicLayer)
ShopPeriodicGiftLayer.__index   = ShopPeriodicGiftLayer
ShopPeriodicGiftLayer.lClass    = 2 




function ShopPeriodicGiftLayer:init( )
	-- body
    -- self.rData["rcvData"]["product_id"] = "PRODUCT_42"
    -- self.rData["rcvData"]["cost_num"] = "99.99"
	-- self.item_id = self.rData["rcvData"]["item_id"] or 1 --传入商品ID
    self.product_id = self.rData["rcvData"]["product_id"]
    self.price,self.currency = UITool.toCurrencyValue(self.rData["rcvData"]["cost_num"]) 
    print("product_id:"..tostring(self.product_id).."....price:"..tostring(self.price))
    if self.product_id ~= nil and self.price ~= nil then
        self.t_product = Data_Shop_Map[self.product_id] or {}
        self:initUI()
    end

        --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

end

function ShopPeriodicGiftLayer:initUI( )
    print("ShopPeriodicGiftLayer:initUI")
	local  node = cc.CSLoader:createNode("HanPeriodicGiftLayer.csb");
    self.uiLayer:addChild(node,0,1);   
    

    local panel = node:getChildByTag(1)
    local mask =  panel:getChildByName("mask")
    local btn_buy = panel:getChildByName("Button_buy")
    local btn_refund = panel:getChildByName("Button_refund")

    local gift_bg = panel:getChildByName("gift_img") --阶段性礼包背景图

    -- local bgName = prop[8] or "periodic_gift_1.png"
    local bgName = self.t_product["imageName"] 
    if bgName ~= nil and bgName ~= "" then
            print("bgName:"..bgName)
            gift_bg:loadTexture(bgName)
    end

    local gift_cost = btn_buy:getChildByName("buy_cost") --礼包价格
    gift_cost:setString(self.price)

    local function touchMaskCall(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("退出--")
            self:returnBack()
        end

    end
  	mask:addTouchEventListener(touchMaskCall) 

    btn_refund:addClickEventListener(handler(self,self.refundCall))
    btn_buy:addClickEventListener(handler(self,self.buyCall))
end

function ShopPeriodicGiftLayer:buyCall( sender,eventType )
	-- body
	print("buy----")

    local function payCallFunc(state)
        self.sManager:delWaitLayer()   ---对应关闭屏蔽层
        print("现金支付支付回调")
        if state == "SUCCESS" then 
            --test
            -- UITool.delayTask(0,function()  
            --     MsgManager:showSimpMsg("ShopPeriodicGiftLayer:buyCall payCallFunc")
            -- end)

            --真正的支付成功：
            --todo 处理shoplayer的相关逻辑吧，比如关闭只能买一次的
            -- 刷新界面和刷新体力金币货币
            -- self.sManager.menuLayer:RefshTopBar()
            -- self:refreshBerylNum()
            -- self:RefishList()
            -- self:refreshTimeBtn()
            -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
            -- if cc.PLATFORM_OS_ANDROID == targetPlatform then
            --     ---android
            --     --dataeye 支付
            --     if CHANNEL.Android.CHANNEL_CODE_YJ == GAME_CHANNEL then
            --         XBDataeyeManager:getInstance():paymentSuccess(user_info["id"],SDKPayData.orderId,tonumber(SDKPayData.price ),"unkonw","unkonw")
            --     end 
            -- else 
            --     XBDataeyeManager:getInstance():paymentSuccess(user_info["id"],SDKPayData.orderId,tonumber(SDKPayData.price ),"unkonw","unkonw")
            -- end           
            -- self:SendShopTable(1)

            ActBanerManager:updateBaner() --每次到首页刷新一次

            -- local purcharseName = Data_Shop_Map[SDKPayData.product]["kachavaName"]
            -- local transactionName = Data_Shop_Map[SDKPayData.product]["googlePayID"]
            -- local product_id1 = SDKPayData.product["product_id"]
            -- local purcharseName = DataManager:getValue("Data_Shop_Map", Data_Shop_Map, product_id1, "kachavaName")
            -- local transactionName = DataManager:getValue("Data_Shop_Map", Data_Shop_Map, product_id1, "googlePayID")
            
            -- UITool.delayTask(0,function()  
            --     MsgManager:showSimpMsg("SDKPayData.product = "..tostring(SDKPayData.product))
            -- end)

            -- local priceStr,currcyStr = self.price,self.currency
            --kochavaSendEventPlatform(100,"Purcharse",purcharseName,priceStr,currcyStr,transactionName)--kochava 支付统计
            --kochavaSendEventPlatform(120,"Purcharse",purcharseName,priceStr,currcyStr,transactionName)
            --kochavaSendEventPlatform(100,self.t_product["kachavaName"],self.t_product["kachavaName"],tostring(self.price),self.currency,self.t_product["googlePayID"])--kochava 支付统计
            


            self:returnBack();
            


        else 
            print("支付回调"..state)
        end 
    end
    local function test(  )

       local buyData = self.rData["rcvData"]
       self.sManager:createWaitLayer()----开启屏蔽层
       SDKManagerLua:buyItem(buyData,payCallFunc) 
    end 
    local platform = cc.Application:getInstance():getTargetPlatform()
    local currency_type = UITool.ToLocalization("人民币")
    if platform == cc.PLATFORM_OS_ANDROID then
        --todo
    else
        currency_type = UITool.ToLocalization("美元")
    end
    -- self.currency "KRW"
    MsgManager:showSimpMsgWithCallFunc(string.format(UITool.ToLocalization("是否花费%s%s购买礼包"),self.price,currency_type),self,test)

    -- 测试kochava 正式需要去掉
    --     local purcharseName = DataManager:getValue("Data_Shop_Map", Data_Shop_Map, self.product_id, "kachavaName")
    -- local transactionName = DataManager:getValue("Data_Shop_Map", Data_Shop_Map, self.product_id, "googlePayID")
    
    -- local priceStr,currcyStr = self.price,self.currency
    -- kochavaSendEventPlatform(199,"Purcharse",purcharseName,priceStr,currcyStr,transactionName)--kochava 支付统计
    -- local purcharseName = Data_Shop_Map[self.product_id]["kachavaName"]
    -- local transactionName = Data_Shop_Map[self.product_id]["googlePayID"]
    -- local priceStr,currcyStr = self.price,self.currency
    -- print("periodicGiftLayer  199:"..tostring(purcharseName).."  "..tostring(transactionName).."   "..tostring(priceStr).."  "..tostring(currcyStr))
    -- print("kochavaSendEventPlatform type = 199----")
    -- kochavaSendEventPlatform(199,"Purcharse",tostring(purcharseName),tostring(priceStr),tostring(currcyStr),tostring(transactionName))--kochava 支付统计

end

function ShopPeriodicGiftLayer:refundCall( sender,eventType )
	-- body
	print("refundCall--")
    local _refundsDetailLayer = ShopRefundsLayer:create();
    self.uiLayer:addChild(_refundsDetailLayer.uiLayer ,1000);
end

function ShopPeriodicGiftLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ShopPeriodicGiftLayer:returnBack()
    self.exist = false
    self.uiLayer:removeFromParent()
    self.uiLayer = nil 

    self:clearEx()
end
function ShopPeriodicGiftLayer:create(rData)

     local login = ShopPeriodicGiftLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()

     return login

end