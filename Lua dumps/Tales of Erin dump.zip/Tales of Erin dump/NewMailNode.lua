NewMailNode = class("NewMailNode", XUICellView)
NewMailNode.CS_FILE_NAME = "NewMailNode.csb"

NewMailNode.skeletonNode = nil

NewMailNode.AllIndexTable = {}
NewMailNode.AllIndexTable["OldIndex"] = 1


NewMailNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}

function NewMailNode:init(...)
    self.skeletonNode = nil
    --self.AllIndexTable["OldIndex"] = 1
   -- self.AllIndexTable["OldImage"] = nil
    NewMailNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
 
    return self
end
function NewMailNode:setData( tdad )
    -- body
    self.DataTest = tdad;
    self.OnSelf  = tdad["OnSelf"];
end
function NewMailNode:setSelectIndex( ... )
    -- body
    
    self.AllIndexTable["OldImage"] = nil
    self.AllIndexTable["OldIndex"] = 1
end
function NewMailNode:Close()
   self.skeletonNode = nil;
   self.AllIndexTable["OldIndex"] = 1
   self.AllIndexTable["OldImage"] = nil
end
function NewMailNode:onResetData()
  
    if not self._data then return end
    local dtable = {
            ["mail_id"]           = self._data["mail_id"],               
            ["alive_time"]   = self._data["alive_time"],     --邮件过期时间         
            ["item_rarity"]  = self._data["item_rarity"],        
            ["msg_title"]    = self._data["msg_title"],       -- 显示邮件的标题 name        
            -- ["item_id"]      = self._data["item_id"],              
            -- ["num"]          = self._data["num"],
            ["item_list"]    = self._data["item_list"],
            ["mail_type"]    = self._data["alive_time"],
            ["mail_icon_type"]  = self._data["mail_icon_type"],       

    }
    --print("shehehehheheh == "..["item_list"][1][1])
     local  panelP        = self.PanelList
     -- bg
     local  ItemBg        = panelP:getChildByName("Image_bg")
     -- icon
     local  ItemIcon      = panelP:getChildByName("Image_icon")
     -- 临时的会根据服务器加的字段进行修改  这个判断是否是限时和永久
     if dtable["mail_type"] == -1 then  --永久
         ItemBg:loadTexture("res/uifile/n_UIShare/NewMail/yj_ui_002.png")
        -- ItemIcon:loadTexture("res/uifile/n_UIShare/NewMail/yj_ui_004.png")
     else -- 限时
         ItemBg:loadTexture("res/uifile/n_UIShare/NewMail/yj_ui_003.png")
         --ItemIcon:loadTexture("res/uifile/n_UIShare/NewMail/yj_ui_005.png")
         --ItemIcon:loadTexture("res/uifile/n_UIShare/NewMail/yj_ui_004.png")
     end
     --print("ooo == "..mail[tonumber(dtable["mail_icon_type"])].mail_icon);
     local icon_type = tonumber(dtable["mail_icon_type"])
     if mail[icon_type] and mail[icon_type]["mail_icon"] then
        local texture = mail[icon_type]["mail_icon"]
        ItemIcon:loadTexture(texture)
     end
    -- -- name
     local  ItemName      = panelP:getChildByName("Text_name")
     ItemName:setString(UITool.getUserLanguage(dtable["msg_title"]))
     -- 高亮框
     local  image_light   = panelP:getChildByName("Image_light")
     -- 时间
     local now  =UserDataMgr:getInstance().timeData:getCurrentTime()-- os.time()
     local dist = nil --dtable.alive_time - now 
     local tableTime = nil --UITool.ShowTime(dist)
    if dtable["mail_type"] == -1 then  --永久
        dist = dtable.alive_time
        tableTime = UITool.ShowTime(dist)
        local  time          = panelP:getChildByName("Text_tiam")
        print("走的是这个")
        time:setString(UITool.ToLocalization("(永久)")..os.date("%Y-%m-%d  %H:%M",math.floor(tonumber(dtable["mail_id"]))))
    else
        dist = dtable.alive_time - now 
        tableTime = UITool.ShowTime(dist)
        local  time          = panelP:getChildByName("Text_tiam")
        time:setString(UITool.ToLocalization("(限时)")..tableTime["D"]..UITool.ToLocalization("天")..tableTime["H"]..UITool.ToLocalization("时")..tableTime["M"]..UITool.ToLocalization("分"))
    end

 
  --/*
        -- 第一次进来 高亮框选中的是第一个
        -- AllIndexTable 用来记录上一次选中的高亮框  在点击的时候隐藏掉  从新记录当前的高亮框
  --*/
    if self.AllIndexTable["OldIndex"]  == self:getIndex() then
        self.AllIndexTable["OldImage"] = image_light
        self.AllIndexTable["OldImage"]:setVisible(true)
        self.OnSelf:NodeCallBack(self._data,self:getIndex())
    else
        image_light:setVisible(false)
    end
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                print("打印现在的index"..self:getIndex());
                -- if self.AllIndexTable["OldImage"] then
                --     self.AllIndexTable["OldImage"]:setVisible(false)
                -- end
                if self.AllIndexTable["OldIndex"] ~= self:getIndex() then
                    
                    self.AllIndexTable["OldImage"]:setVisible(false)
                    self.AllIndexTable["OldImage"] = nil
                end
                
                image_light:setVisible(true)

                self.AllIndexTable["OldImage"] = image_light
                self.AllIndexTable["OldIndex"] = self:getIndex()
                
                self.OnSelf:NodeCallBack(self._data,self:getIndex())
            end      
        end
    end
    panelP:addTouchEventListener(touchCallBack)
    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end
