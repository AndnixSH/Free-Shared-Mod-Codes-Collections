--[[
	CommonSortButtonView.lua
]]

CommonSortButtonView = class("CommonSortButtonView", XUIView)
CommonSortButtonView.CS_FILE_NAME = "SortButtonView.csb"
CommonSortButtonView.CS_BIND_TABLE = 
{
    sortBtnSort = "/i:169/s:btnSort",
    sortBtnSortTitle = "/i:169/s:btnSort/s:btnSortTitle",
    sortBtnAsc = "/i:169/s:btnAsc",
    sortBtnDesc = "/i:169/s:btnDesc"
}

CommonSortButtonView.bDisableSortBtn = false

function CommonSortButtonView:init(rootNode,manager)
    CommonSortButtonView.super.init(self,rootNode)
    self._manager = manager
    --升序按钮
    self.sortBtnAsc:setPressedActionEnabled(false)
    self.sortBtnAsc:addClickEventListener(function()
        if self.bDisableSortBtn then
            GameManagerInst:alert(UITool.ToLocalization("当前界面无法进行筛选"))
            return
        end 
        --改为降序
        self:sortStateChangedEvent(SortStateEnum.DOWN)
    end)
    --降序按钮
    self.sortBtnDesc:setPressedActionEnabled(false)
    self.sortBtnDesc:addClickEventListener(function()
        if self.bDisableSortBtn then
            GameManagerInst:alert(UITool.ToLocalization("当前界面无法进行筛选"))
            return
        end
        self:sortStateChangedEvent(SortStateEnum.UP)
    end)

    self.sortBtnSort:setPressedActionEnabled(false)
    self.sortBtnSort:addClickEventListener(function()
        if self.bDisableSortBtn then
            GameManagerInst:alert(UITool.ToLocalization("当前界面无法进行筛选"))
            return
        end
        self._manager:showSortBoxUI()
    end)

    self:refreshBtns()
    
    return self
end

function CommonSortButtonView:refreshBtns()
    self:refeshSortButtonState()
    self:refresRootBtnState()
end

--排序发生变化
function CommonSortButtonView:sortStateChangedEvent(sortState)
	self._manager:setSortState(sortState)
	self:refeshSortButtonState()
end

function CommonSortButtonView:refeshSortButtonState()
	local data = self._manager:getSortData()
	local sortState = data.sortState
    self.sortBtnAsc:setVisible(sortState == SortStateEnum.UP)
    self.sortBtnDesc:setVisible(sortState == SortStateEnum.DOWN)
    self.sortBtnSortTitle:setString(data.sortName)
end

function CommonSortButtonView:refresRootBtnState()
    if self._manager:isSelectAll() then 
        self.sortBtnSort:loadTextures(EQ_SORT_BTN_BG_NOR[1],EQ_SORT_BTN_BG_NOR[2],EQ_SORT_BTN_BG_NOR[3])
    else 
        self.sortBtnSort:loadTextures(EQ_SORT_BTN_BG_CHANGE[1],EQ_SORT_BTN_BG_CHANGE[2],EQ_SORT_BTN_BG_CHANGE[3])
    end 
end