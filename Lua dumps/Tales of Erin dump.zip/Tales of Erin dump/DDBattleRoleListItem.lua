--[[
	DDBattleRoleListItem.lua
	横向玩法一 选择队伍的item
    todo 要统一 item吗？现在都是各自定制，用的是同一个csb
]]

DDBattleRoleListItem = class("DDBattleRoleListItem", XUICellView)
DDBattleRoleListItem.CS_FILE_NAME = "REListItemView.csb"
DDBattleRoleListItem.CS_BIND_TABLE = 
{
    touchPanel = "/i:221",
    imgBG = "/i:29/i:30/i:39",
    imgFace = "/i:29/i:30/i:40",
    imgRarity = "/i:29/i:30/i:38",
    imgElement = "/i:29/i:30/i:41",
    inTeamFlag = "/i:29/i:36",
    inTeamText = "/i:29/i:36/i:45",
    atkdefPanel = "/i:29/i:44",
    rankPanel = "/i:29/i:41",
    zhanliPanel = "/i:29/i:42",
    rankImg1 = "/i:29/i:41/i:44",
    rankImg2 = "/i:29/i:41/i:45",
    rankImg3 = "/i:29/i:41/i:46",
    rankImg4 = "/i:29/i:41/i:47",
    lbATK = "/i:29/i:44/i:42",
    lbHP = "/i:29/i:44/i:43",
    lbZhanli = "/i:29/i:42/i:50",
    lbZhanliName ="/i:29/i:42/i:49",
    imgOutTeam = "/i:29/i:295",
    panSelArrow = "/i:29/i:298",
    panSelect = "/i:29/i:298",
    redPoint = "/i:29/i:103",
    intimacyNode = "/i:29/i:30/i:68",
    intimacyIconPos = "/i:29/i:30/i:612",
}

function DDBattleRoleListItem:init(...)
    DDBattleRoleListItem.super.init(self,...)
    self.panSelect:setVisible(false)
    self.redPoint:setVisible(false)
    
    self.imgOutTeam:setVisible(false)    --n_UIShare\equip\list\ggsc_ui_222.png

    self.bShowSkillPoint = false

    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)

    return self
end

function DDBattleRoleListItem:startGMeffect(intimacyState)
    local effectFile = like_state[intimacyState].special_effect --特效资源路径

    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(effectFile) then
        local end_pos = string.find(effectFile,'atlas') - 1
        local spName = string.sub(effectFile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil

            local rps = self.intimacyIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2, rps.height / 2))
            roleIcon:setScale(1)
            self.intimacyIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect", true)
        end)
    end
end

function DDBattleRoleListItem:stopGMeffect()
    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
end

function DDBattleRoleListItem:startHold()
    self:stopHold()
    
    local scheduler = cc.Director:getInstance():getScheduler()
end
function DDBattleRoleListItem:stopHold()
    local scheduler = cc.Director:getInstance():getScheduler()
end

function DDBattleRoleListItem:showOutTeam()
    self.imgOutTeam:setVisible(true) 
    self.imgOutTeam:setTexture("n_UIShare/role/list/ggsc_ui_222.png")
end

function DDBattleRoleListItem:setTitleMode(mode)
    self.atkdefPanel:setVisible(false)
    self.zhanliPanel:setVisible(false)
    self.rankPanel:setVisible(false)

    if mode == 4 then
        --突破次数
        self.rankPanel:setVisible(true)
        for i=1,4 do    
            if i <= self._data.break_count then
                self["rankImg"..i]:setVisible(true)
                self["rankImg"..i]:setTexture("n_UIShare/role/info/ggsc_ui_145.png")
            else
                self["rankImg"..i]:setVisible(false)
            end
        end
    elseif mode == 3 then
        --战斗力
        self.zhanliPanel:setVisible(true)
        self.lbZhanliName:setString(UITool.ToLocalization("战斗力"))
        self.lbZhanli:setString(self._data.fp_all.all)
    elseif mode == 2 then
        --等级
        self.zhanliPanel:setVisible(true)
        self.lbZhanliName:setString(UITool.ToLocalization("等级"))
        self.lbZhanli:setString(self._data.Lv)
    else
        --攻击力，血量            
        self.atkdefPanel:setVisible(true)
        self.lbATK:setString(""..self._data["atk"])
        self.lbHP:setString(""..self._data["hp"])
    end
end

--[[
      "hero_list": {
        # 实际的[hero_id]是程序自动生成的
        # 格式为[hero*tm], tm为角色的入手时间, 例如: 1*1299656990
           "1*1299656990":{ 
            "Lv": 1,            # 等级 
            "Lv_max": 40,       # 等级上限
            "hp": 735,          # 生命力
            "atk": 1400,        # 攻击力
            "def": 12,          # 防御
            "break_count": 0,   # 突破次数, 0-5
            "crit": 0,          # 暴击率
            "crit_dmg": 2,      # 暴击加成
            "hel": 100,         # 恢复力 
            "team_list":["2"],  # 编队序号
            "asp": 2,           # 攻击速度
            "exp": 0,           # 当前经验
            "exp_max": 100,     # 升级经验(升级后的属性变化,对应[h_lv_1]表)
            "tp": {"max_num": 0,"num": 0, "from_other": 0},
            "fp":{"all":21231,"atk":211,"hp":331,"def":245},# 战斗力 由英雄和所带装备组成
            "rarity": 5,       # 角色稀有度
            "element": 5,       # 角色元素类型: 1水 2火 3风 4光 5暗
         },        
    }, 
     "mat": {"mat_1": 66, },# 只返回强化、突破素材 
]]

function DDBattleRoleListItem:setShowSkillPoint(isShow)
    self.bShowSkillPoint = isShow
end

function DDBattleRoleListItem:onResetData()
    self.imgOutTeam:setVisible(false)
    --重置状态，默认是不选中
    self:setSelectState(1)

    if not self._data then return end

    local h_id_num = getNumID( self._data["id"] )
    local h_id_str = getStrID( self._data["id"] )
    
    local frame = Rarity_Icon[self._data["rarity"]]  --外框
    --Rarity_BG  --背景
    if frame then
        self.imgRarity:setTexture(frame)
    end

    local rbg = Rarity_E_BG[self._data["rarity"]]   --背景
    if rbg then
        self.imgBG:setTexture(rbg)
    end

    local element = ATB_Icon[self._data["element"]] --属性球

    if element then
        self.imgElement:setTexture(element)
    end

    local face = hero[h_id_num].hero_list_icon    
    if face then
        self.imgFace:setTexture(face)
    end

    if g_channel_control.b_LikeState then
        local intimacyState = self._data["like_feel_state"]["icon_state"]

        local intimacy = like_state[intimacyState].icon_min --亲密度
        if intimacy then
            self.intimacyNode:setTexture(intimacy)
        end
        local effectFile = like_state[intimacyState].special_effect --特效资源路径
        if effectFile ~= "" then
            self:startGMeffect(intimacyState)
        else
            self:stopGMeffect()
        end
    end
    
    self.inTeamFlag:setVisible(false)

    self:setTitleMode(1)
    
    if self.bShowSkillPoint then
        self.redPoint:setVisible(self._data["tp"]["num"] > 0)
    else
        self.redPoint:setVisible(false)
    end

    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end

--设置状态 0 为选中  1不选中状态
function DDBattleRoleListItem:setSelectState(_state)
    --最好的
    if _state == 0 then
        --print("选中状态")
        self.isSelect = true
        self.panSelArrow:setVisible(true)  
    else 
        --print("取消选中")
        self.isSelect = false
        self.panSelArrow:setVisible(false)
    end
end
