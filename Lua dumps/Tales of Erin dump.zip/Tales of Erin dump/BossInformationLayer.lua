--[[
	BossInformationLayer.lua
	魔王情报
]]
require "BasicLayer"

BossInformationLayer = class("BossInformationLayer",BasicLayer)
BossInformationLayer.__index = BossInformationLayer
BossInformationLayer.lClass = 3
local LIST_ITEM_H = 110 --item高度
local LIST_COLUMN = 3   --一行显示几个
local TITLE_X = 50 --boss情报 左边边距	

function BossInformationLayer:init()
    local data = self.rData.rcvData.data
    self.rewards = data.rewards or {}--奖励列表
    self.level_id = data.level_id
    self.dropListView = nil 
    self.bossInfoList = nil
    --self:sortRewards()--奖励排序
    local node = cc.CSLoader:createNode("BossInformationLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self._csbRootNode = node:getChildByTag(101) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end

    local backBtn  =  ccui.Helper:seekWidgetByName(self._csbRootNode,"back_btn")
    backBtn:addTouchEventListener(touchCallBack)

    self.title  =  ccui.Helper:seekWidgetByName(self._csbRootNode,"title")
    self.title:setString(data.title)

    self:initDropListView()
    self:refreshDropListView()

    self:initBossInfoList()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

end
--排序奖励
function BossInformationLayer:sortRewards()
    --info 由于 不同类型之间的 品质取不同字段，所以要提前将品质取出来
     for i=1,#self.rewards do
        local reward = self.rewards[i]
        local quality = UITool.getItemQuality(reward.type,reward.id)
        local type_Q =  UITool.getItemTypeQuality(reward.type)
        self.rewards[i].com_quality = quality
        self.rewards[i].type_Q = type_Q
     end
     local function qualitySort(a,b)
        if a.type_Q == b.type_Q then 
            return a.com_quality > b.com_quality
        else
            return a.type_Q > b.type_Q
        end
     end
     table.sort(self.rewards, qualitySort)
end

function BossInformationLayer:initDropListView()
    -- body
    self.dropListView = ccui.Helper:seekWidgetByName(self._csbRootNode,"drop_list")
    --set bar
    self.dropListView:setScrollBarEnabled(true)
    self.dropListView:setScrollBarWidth(20)
    self.dropListView:setScrollBarColor(cc.c3b(0, 0, 0))
    self.dropListView:setScrollBarOpacity(225*0.5)
    self.dropListView:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end
    local  item = cc.CSLoader:createNode("MapDropsItem.csb")
    local  item_1 = item:getChildByTag(102)
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    for i=1,LIST_COLUMN do
        local item = item_1:clone()
        item:setPosition((i-1)*(154*0.8+10),0) --152为框的大小。缩放80%
        --local touchItem = ccui.Helper:seekWidgetByName(item_c,"Image_e_bg")
        item:setName("item"..i)
        layout_list:addChild(item)
    end
    layout_list:setContentSize(400,110)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.dropListView:setItemModel(layout_list)
    self.dropListView:removeAllItems()
    self.dropListView:addEventListener(listViewEvent)
end

function BossInformationLayer:refreshDropListView()
    self.dropListView:removeAllItems()
    local totalNum = #self.rewards --总数
    local row = math.ceil(totalNum /LIST_COLUMN)  -- 行数
    self.dropListView:setInnerContainerSize(cc.size(self.dropListView:getContentSize().width,LIST_ITEM_H*row))
    for i = 1,row do 
        self.dropListView:pushBackDefaultItem()
        local item = self.dropListView:getItem(i - 1)
        for m = 1 , LIST_COLUMN do          
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)*LIST_COLUMN + m

            if num > totalNum then
                itme_info:setVisible(false)
            else
                local reward = self.rewards[num]
                local tabs = UITool.getItemInfos(reward.type,reward.id)

                local bg = itme_info:getChildByTag(1)
                local icon = itme_info:getChildByTag(2)
                local kuang = itme_info:getChildByTag(3)
                local element = itme_info:getChildByTag(4)
                local drop_res = itme_info:getChildByTag(6)
                if reward.tag then
                    if reward.tag == 0 then
                        drop_res:setVisible(false)
                    else
                        local path = table.getValue("drop_tag",drop_tag,reward.tag,"path_res")
                        if path == "" then
                            drop_res:setVisible(false)
                        else
                            drop_res:setVisible(true)
                            drop_res:loadTexture(path)
                            icon:setUnifySizeEnabled(true)
                        end
                    end
                end
                kuang:loadTexture(tabs[1])
                icon:setUnifySizeEnabled(true)
                icon:loadTexture(tabs[2])
                if tabs[3] == "" then 
                    element:setVisible(false)
                else
                    element:loadTexture(tabs[3])
                end
                if tabs[4]~= "" then 
                    bg:loadTexture(tabs[4])
                else

                end 
                --显示道具详情
                local function CallBackEvent( sender,eventType )
                    if eventType == ccui.TouchEventType.ended then
                       --此处为正确调用
                      MsgManager:showSimpItemInfo(reward.type,reward.id)
                    end
                end 
                icon:addTouchEventListener(CallBackEvent)
            end
        end
    end
    self.dropListView:jumpToTop()
end
----bossInfo
function BossInformationLayer:initBossInfoList()
 	self.bossInfoList = ccui.Helper:seekWidgetByName(self._csbRootNode,"info_list")
    --set bar
    self.bossInfoList:setScrollBarEnabled(true)
    self.bossInfoList:setScrollBarWidth(20)
    self.bossInfoList:setScrollBarColor(cc.c3b(0, 0, 0))
    self.bossInfoList:setScrollBarOpacity(225*0.5)
    self.bossInfoList:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end

	local item_title = ccui.Layout:create()
    local imageview_1 = self:getTitleUI(UITool.ToLocalization("魔王基础情报"))
    item_title:setContentSize(cc.size(imageview_1:getCustomSize().width , imageview_1:getCustomSize().height))
    item_title:addChild(imageview_1)
	self.bossInfoList:pushBackCustomItem(item_title)

    local boss_info_data = battle_intro[self.level_id]
    if boss_info_data == nil then
        LogManager.showSimpMsgDebug("error,missing index :   "..tostring(self.level_id).."\nin :   battle_intro.lua","battle_intro")
        -- print("error:-----------------------------battle_intro:index:"..tostring(self.level_id))
    end
	local item_des = ccui.Layout:create()
    local desText = self:getLabelUI(UITool.getUserLanguage(boss_info_data.des),30)
    item_des:setContentSize(cc.size(desText:getCustomSize().width , desText:getCustomSize().height+10))
    item_des:addChild(desText)
    self.bossInfoList:pushBackCustomItem(item_des)

    --技能
    for i=1,#boss_info_data.skill do
        if boss_info_data.skill[i] and boss_info_data.skill[i] ~= "" then
            if UITool.getUserLanguage(boss_info_data.skill[i]) and UITool.getUserLanguage(boss_info_data.skill[i]) ~= "" then
                local item_title = ccui.Layout:create()
                local imageview_1 = self:getTitleUI(UITool.ToLocalization("技能"))
                item_title:setContentSize(cc.size(imageview_1:getCustomSize().width , imageview_1:getCustomSize().height))
                item_title:addChild(imageview_1)
                self.bossInfoList:pushBackCustomItem(item_title)

                local item_des = ccui.Layout:create()
                local desText = self:getLabelUI(UITool.getUserLanguage(boss_info_data.skill[i]))
                item_des:setContentSize(cc.size(desText:getCustomSize().width , desText:getCustomSize().height+10))
                item_des:addChild(desText)
                self.bossInfoList:pushBackCustomItem(item_des)
            end
        end
    end
end

---图片标题
function BossInformationLayer:getTitleUI(titleStr)
	-- body
    local imageview = ccui.ImageView:create("n_UIShare/bossAtbSort/cxbh_ui_006.png")
    imageview:setPositionX(0)
    imageview:setAnchorPoint(cc.p(0, 0))
    ---小标题
    local alert = ccui.Text:create(titleStr,TEXT_FONT_NAME,24)
    alert:setColor(cc.c3b(255, 255, 255))
    alert:enableOutline(cc.c4b(0,0,0,255),2)
    alert:setPosition(TITLE_X,19)
    alert:setAnchorPoint(cc.p(0, 0.5))
    imageview:addChild(alert)

    return imageview
end

---label
--说明： 在创建的时候设置字体，比创建完成设置字体要快很多
function BossInformationLayer:getLabelUI(infoStr,addH)
    -- body
    addH = addH or 0
    local row = math.ceil(UITool.getCharLength(infoStr)/25)+2
   -- local desText = ccui.Text:create("",TEXT_FONT_NAME,22)  
    local desText = ccui.Text:create()
    desText:setFontSize(22)
    desText:ignoreContentAdaptWithSize(false)
    desText:setString(infoStr)
    desText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    desText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    desText:setColor(cc.c3b(255, 255, 255))
    desText:setPosition(TITLE_X-5,0)
    desText:setAnchorPoint(cc.p(0, 0))
    desText:setContentSize(cc.size(530.00, 20 * row+addH))
    return desText
end

--返回
function BossInformationLayer:returnBack()
   self.exist = false
   self:clearEx()
end

function BossInformationLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function BossInformationLayer:create(rData)
     local layer = BossInformationLayer.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end