
--引导系统




GuideSys = class("GuideSys")



function GuideSys:getInstance()
   if self.s_instance == nil then

        self.s_instance = GuideSys.new()
        self.s_instance:initialize()

   end
   return self.s_instance;
end


function GuideSys:initialize()
    self.openGuide = true
end

--初始化引导
function GuideSys:initGuide()
    

    if self.openGuide == false then
        self._oldNewGuideManager = NewGuideManager
        NewGuideManager = GuideImplNull

    else
        
        if g_channel_control.UIVersion >= 2 then
            self._oldNewGuideManager = NewGuideManager
            NewGuideManager = XbNewGuideManager
        end


    end
    NewGuideManager:resetState()
    
end

