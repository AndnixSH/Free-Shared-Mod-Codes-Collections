
BNListItem = class("BNListItem", XUICellView)
BNListItem.CS_FILE_NAME = "BNListItem.csb"
BNListItem.CS_BIND_TABLE = 
{
    touchPanel = "/s:root",
    imgRarity = "/s:root/s:imgRarity",
    imgFace = "/s:root/s:imgFace",
    selectImg = "/s:root/s:selectImg",
    imgBG = "/s:root/s:imgBG",
    bnName = "/i:646/i:648",
}

function BNListItem:init(...)
    BNListItem.super.init(self,...)

    self.isSelect = false
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)
    return self
end

--重置UI
function BNListItem:onResetData()
    if not self._data then return end
    local bnid = self._data

    -- local rbg = Rarity_E_BG[4]   --背景
    -- if rbg then
    --     self.imgBG:setTexture(rbg)
    -- end

    --icon
    local face = princess_mainpage[tonumber(bnid)]["bn_icon"]
    if face then
        self.imgFace:setTexture(face)
    end
    --name
    local lbname = UITool.getUserLanguage(princess_mainpage[tonumber(bnid)]["bn_name"])
    if lbname then
        if g_channel_control.transform_BNListItem_bnName_fontSize == true then 
            self.bnName:setFontSize(16)
        end
        self.bnName:setString(lbname)
    end
    
    local iconBgPath = Rarity_E_BG[princess_mainpage[tonumber(bnid)]["level"]]  --背景
    if iconBgPath then
        self.imgBG:setTexture(iconBgPath)
    end
    local iconRarityPath = Rarity_mat[princess_mainpage[tonumber(bnid)]["level"]]  --外框
    if iconRarityPath then
        self.imgRarity:setTexture(iconRarityPath)
    end

    --kuang
    -- local frame = Rarity_Icon[4]  --外框
    -- if frame then
    --     self.imgRarity:setTexture(frame)
    -- end
    if user_info["signboard"] == self._data then 
		self.selectImg:setVisible(true)
    else 
		self.selectImg:setVisible(false)
    end 
end
