
--商店信息
--暂时无用 
ShopDataCache = class("ShopDataCache")
ShopDataCache.__index   = ShopDataCache


-- UserDataMgr.shopData:setData(key ,value)
-- getData(key)

function ShopDataCache:init()

-- body
    self.giftCount = 1
    self.dataMap = {}
    self.periodicLv = 1 --阶段性礼包
    self.growUpLv = 1 	--成长礼包
end

function ShopDataCache:clearData()
    self.giftCount = 1
    self.dataMap = {}
    self.periodicLv = 1 --阶段性礼包
    self.growUpLv = 1 	--成长礼包
end
--设置礼包数量
function ShopDataCache:setGiftCount(count)
	self.giftCount = count;
end

function ShopDataCache:getGiftCount()
	return self.giftCount;
end

--设置阶段性礼包
function ShopDataCache:setperiodicLv(lv)
	self.periodicLv = lv;
end

function ShopDataCache:getperiodicLv()
	return self.periodicLv;
end

--设置成长礼包
function ShopDataCache:setgrowUpLv(lv)
	self.growUpLv = lv;
end

function ShopDataCache:getgrowUpLv()
	return self.growUpLv;
end




function ShopDataCache:setShopData(key,value )
	self.dataMap[key] = value
end

function ShopDataCache:getShopData( key )
	return self.dataMap[key]
end

--工厂函数
function ShopDataCache:create()
     local shopData = ShopDataCache.new()

     shopData:init()
     return shopData
end