
DropBoxLayer= class("DropBoxLayer",function ()
    return cc.Layer:create()
end)

function DropBoxLayer:initialize(container,drop,drop_item_list)
    self.panelList = container
    self.dropData = drop
    self.drop_item_list = drop_item_list 
    self:initView()
    self:refreshListView()
end

function DropBoxLayer:initView()
    -- body
    self.listView = ccui.ScrollView:create()
    self.listView:setDirection(SCROLLVIEW_DIR_VERTICAL)
    self.listView:setTouchEnabled(true)
    self.listView:setBounceEnabled(true)
    self.listView:setScrollBarEnabled(false)
    self.listView:setAnchorPoint(cc.p(0,0))
    self.panelList:addChild(self.listView)

    local itemCount = #self.dropData
    local row = math.ceil(itemCount / 4)
    local col = 4

    local viewWidth = col * 120
    local viewHeight = row * 120
    local viewSize = cc.size(viewWidth,viewHeight)
    self.listView:setSize(viewSize)
    self.listView:setInnerContainerSize(viewSize)
    self.panelList:setSize(viewSize)

    for i=1,row do
        for j=1,col do
            local rIdx = i-1
            local cIdx = j-1
            local n = rIdx * 4+j
            local itemX = cIdx * 120+6
            local itemY = row * 120 - i * 120+12--rIdx * 120
            local itemData = self.dropData[n]
            if itemData then
                local item = BoxItemNode:create(itemData)
                item:setPosition(cc.p(itemX,itemY))
                item:setTag(n)
                self.listView:addChild(item)
                local rootNode = item.rootNode
                table.insert(self.drop_item_list,rootNode)
            end 
        end
    end
end

function DropBoxLayer:refreshListView( ... )
    -- body
    local itemCount = #self.dropData
    for i=1,itemCount do
        local item = self.listView:getChildByTag(i)
        if item ~= nil then
            item:refershView()
        end
    end
end

function DropBoxLayer:playBoxAnim( ... )
    -- body
    local itemCount = #self.dropData
    for i=1,itemCount do
        local delayTime = i * 0.3
        local item = self.listView:getChildByTag(i)
        if item then
            item:playAnim(delayTime)
        end
    end
end

function DropBoxLayer:stopBoxAnim( ... )
    -- body
    local itemCount = #self.dropData
    for i=1,itemCount do
        local item = self.listView:getChildByTag(i)
        if item then
            item:stopAnim()
        end
    end
end

function printItems( ... )
    -- body
    -- local boxItemArr = self.gridview:getItems()
    -- local boxItemNum = #boxItemArr
    -- for i=1,boxItemNum do
    --     local itemArr = boxItemArr[i]
    --     local len = #itemArr
    --     for j=1,len do
    --         local delayTime = ((i-1) * len+j) * 0.3
    --         local item = itemArr[j]
    --         item:playAnim(delayTime)
    --     end
    -- end
end

function DropBoxLayer:create(container,drop,drop_items_list)
    local dropLayer = DropBoxLayer.new()
     dropLayer:initialize(container,drop,drop_items_list)
    return dropLayer
end
