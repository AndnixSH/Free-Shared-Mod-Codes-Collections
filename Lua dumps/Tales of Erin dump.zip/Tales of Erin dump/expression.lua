
expression = {}   
expression[1] = {
 file = "icons/expression/zdlt_bq_001.png"
}
expression[2] = {
file = "icons/expression/zdlt_bq_002.png"
}
expression[3] = {
file = "icons/expression/zdlt_bq_003.png"
}
expression[4] = {
file = "icons/expression/zdlt_bq_004.png"
}
expression[5] = {
file = "icons/expression/zdlt_bq_005.png"
}
expression[6] = {
file = "icons/expression/zdlt_bq_006.png"
}
expression[7] = {
file = "icons/expression/zdlt_bq_007.png"
}
expression[8] = {
file = "icons/expression/zdlt_bq_008.png"
}
expression[9] = {
file = "icons/expression/zdlt_bq_009.png"
}
expression[10] = {
file = "icons/expression/zdlt_bq_010.png"
}
expression[11] = {
file = "icons/expression/zdlt_bq_011.png"
}
expression[12] = {
file = "icons/expression/zdlt_bq_012.png"
}
expression[13] = {
file = "icons/expression/zdlt_bq_013.png"
}
expression[14] = {
file = "icons/expression/zdlt_bq_014.png"
}
expression[15] = {
file = "icons/expression/zdlt_bq_015.png"
}
expression[16] = {
file = "icons/expression/zdlt_bq_016.png"
}
expression[17] = {
file = "icons/expression/zdlt_bq_017.png"
}
expression[18] = {
file = "icons/expression/zdlt_bq_018.png"
}
expression[19] = {
file = "icons/expression/zdlt_bq_019.png"
}
expression[20] = {
file = "icons/expression/zdlt_bq_020.png"
}
expression[21] = {
file = "icons/expression/zdlt_bq_021.png"
}expression[22] = {
file = "icons/expression/zdlt_bq_022.png"
}
