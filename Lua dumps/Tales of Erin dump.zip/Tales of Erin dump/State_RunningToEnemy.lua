--跑向某个敌人。
--created by kobejaw.2018.3.29.
State_RunningToEnemy = class("State_RunningToEnemy",StateBase)

function State_RunningToEnemy:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.RunningToEnemy
	self.needUpdate = false;
end

--data.type 1.自动寻敌。2.手动选中某个怪物
--data.enemyEntity 玩家手动选中的某个怪物
function State_RunningToEnemy:Enter(data)
	if self.entity.isDead then
		return
	end

	--眩晕状态的特殊处理
	if self.entity.componentManager:checkIsInVertigo() and not data.isJustAweak then
		self.entity.fsm:changeState(StateEnum.Idling)
		return
	end

	if G_GameState == 5 then
		self.entity.fsm:changeState(StateEnum.Idling)
		return
	end

	self.data = data

	if not self:checkIsNeedRun() then
		return
	end

	if self.entity.fsm.previousState.stateEnum == StateEnum.RunningToEnemy or self.entity.fsm.previousState.stateEnum == StateEnum.RunningToPosition then
		--do nothing
	else
		self.entity:playRunAnimation()
	end

	self.initial_w = self.entity.box_w
	self.initial_h = self.entity.box_h
	
	self:searchEnemy()
end

function State_RunningToEnemy:Exit()
	self.super.Exit(self)

	self.destinationBoxIdx = nil
	self.frames = nil;
	self.deltaXPerFrame = nil;
	self.deltaYPerFrame = nil;
	self.enemyEntity = nil;
	self.needUpdate = false
end

function State_RunningToEnemy:checkIsNeedRun()
	--全部敌人都死完了
	if self.entity:checkIsAllEnemiesDead() then
		return false
	end

	if self.data.type == 2 then
		if self.data.enemyEntity.isDead then
			local data = {}
			data.type = 1
			self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
			return false
		end

		if self:checkIsEnemyInRange(self.data.enemyEntity) then
			--开始攻击
			self.entity.fsm:changeState(StateEnum.Attacking,self.data.enemyEntity)
			return false
		end
	else
		--检测对面是否有嘲讽
		local target = self.entity:checkTaunt()
		if not target then
			target = self:getTarget()
		end

		if not target then
			self.entity.fsm:changeState(StateEnum.Idling)
		end

		if self:checkIsEnemyInRange(target) then
			--开始攻击
			self.entity.fsm:changeState(StateEnum.Attacking,target)
			return false
		end
	end

	return true;
end

function State_RunningToEnemy:searchEnemy()
	self.destinationoxIdx = nil

	if self.entity:checkIsAllEnemiesDead() then
		return
	end

	if self.data.type == 2 then
		self.enemyEntity = self.data.enemyEntity     --手动选择的目标
	else
		--检测对面是否有嘲讽
		local target = self.entity:checkTaunt()
		if not target then
			target = self:getTarget()
		end
		self.enemyEntity = target                   --自动寻找目标
	end

	self.enemyInitial_W,self.enemyInitial_H = self.enemyEntity:getBoxWH()
	
	--计算应该移动到的位置，不可能没有位置，如果真没有，原地idle到战斗结束吧
	self:calculateDestination()

	if self.destinationBoxIdx ~= nil then
		--设置移动的角度和速度
		local destPoint = GetPointByBoxIdx(self.destinationBoxIdx)
		local deltaX = destPoint.x - self.entity:getPositionX()
		local deltaY = destPoint.y - self.entity:getPositionY()
		local distance = math.sqrt(deltaX * deltaX + deltaY * deltaY)

		local pixelsPerFrame = self.entity.data.speed/100
		self.frames = math.ceil(distance/pixelsPerFrame)

		self.deltaXPerFrame = deltaX/self.frames 
		self.deltaYPerFrame = deltaY/self.frames

		--设置朝向
		self.entity:setOrientation(self.enemyEntity)
		
		self.needUpdate = true
	end
end

function State_RunningToEnemy:update()
	if self.data.type == 1 then --自动寻敌
		self:update_type1()
	else                        --手动锁敌
		self:update_type2()
	end
end

--自动寻敌的update
function State_RunningToEnemy:update_type1()
	local nearestEnemy = self:getTarget()
	if nearestEnemy == nil then --所有敌人都死完了
		self.entity.fsm:changeState(StateEnum.Idling)
		return
	end

	if self.enemyEntity ~= nearestEnemy then
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)--重新寻敌
		return
	end

	--检测目标是否移动
	if self:checkIsEnemyMoved() then
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)--重新寻敌
		return
	end

	self:updatePosition()
end

--手动锁敌的update
function State_RunningToEnemy:update_type2()
	--目标敌人死亡
	if self.enemyEntity.isDead then
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)--重新寻敌,切换到type1类型。
		return
	end

	--检测目标是否移动
	if self:checkIsEnemyMoved() then
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,self.data)--重新寻敌,保持self.data不变。
		return
	end

	self:updatePosition()
end

--获取离自己最近的敌人
function State_RunningToEnemy:getTarget()

	local posW,posH,monsterPosW,monsterPosH,deltaW,deltaH
	local dataList = {}
	posW,posH = self.entity:getBoxWH()

	local isAllDead = true

	for i = 1,#self.entity.enemyList do
		if not self.entity.enemyList[i].isDead then
			isAllDead = false;
			monsterPosW,monsterPosH = self.entity.enemyList[i]:getBoxWH()
			deltaW = monsterPosW - posW
			deltaH = monsterPosH - posH
			local data = {}
			data.idx = i;
			data.distance = math.abs(deltaW) + math.abs(deltaH)
			data.deltaW = math.abs(deltaW)
			table.insert(dataList,data)
		end
	end

	if not isAllDead then
		table.sort(dataList,function(a,b)
			if a.distance ~= b.distance then
				return a.distance < b.distance
			else
				return a.deltaW < b.deltaW
			end
		end)
		return self.entity.enemyList[dataList[1].idx]
	else
		return nil;
	end
end

--计算应该移动到的位置
function State_RunningToEnemy:calculateDestination()
	--如果在射程范围内,切换到战斗状态
	if self:checkIsInRange(self.enemyInitial_W,self.enemyInitial_H,self.enemyEntity) then
		self.destinationBoxIdx = nil;
		self.entity.fsm:changeState(StateEnum.Attacking,self.enemyEntity)
		return;
	end

	--如果不在射程范围内，优先横着走。满足射程的横向第一个格子如果出现竖向距离大于横向距离的情况。则换到跟敌人同一行。如果同一行满了，则换到另外一行。
    local width,height = self.enemyEntity:getBoxWH()
    local w_self,h_self = self.entity:getBoxWH()

    --处理体积。体积的处理转化为射程。见StateBase:checkIsInRange(w,h,enemy)。
    if not BattleDataManager.isBoss then
    	if self.entity.cubageType >0 or self.enemyEntity.cubageType >0 then
    		local cubageType = 0
    		if self.entity.cubageType > 0 then
    			cubageType = self.entity.cubageType
    		else
    			cubageType = self.enemyEntity.cubageType
    		end

    		if w_self<width then
    			width = width - cubageType
    		elseif w_self>width then
    			width = width + cubageType
    		end
    	end
    end

    local deltaW = width - w_self
    --第1步，检测横向移动是否有符合的格子.
    local potentialList = {}
    local temp1
    if width>w_self then
		for i = w_self+1,width-1,1 do
			temp1 = i*3+h_self
			if self.entity:checkBoxAvailableByIdx(temp1) then
				self.destinationBoxIdx = temp1
				if math.abs(i-width)>=math.abs(h_self-height) then
					return
				end
			end
		end
    else
 		for i = w_self-1,width+1,-1 do
			temp1 = i*3+h_self
			if self.entity:checkBoxAvailableByIdx(temp1) then
				self.destinationBoxIdx = temp1
				if math.abs(i-width)>=math.abs(h_self-height) then
					return
				end
			end
		end
    end

    --第2步。横向没有，暴力检测所有格子。
	potentialList = {}
	local this = self
	local function checkAvailable(w,h)
		if w<0 or h>2 or h<0 then
			return
		else
			local idx = w*3+h
			if this.entity:checkBoxAvailableByIdx(idx) then
				if math.abs(w - w_self) >= math.abs(h - h_self) then
					local data = {}
					data[1] = idx;
					data[2] = math.abs(w - w_self)
					data[3] = data[2] + math.abs(h - h_self)
					table.insert(potentialList,data)
				end
			end
		end
	end
	local range = self.entity.shotRange
    local totalPotentialNum = (range-2)*6+10 --所有潜在可选的格子总数
    
    --正上，正下，最左，最右四个格子
    checkAvailable(width,height+1)
    checkAvailable(width,height-1)
    checkAvailable(width-range,height)
    checkAvailable(width+range,height)

    --中间的所有格子
    local w1,h1,a,b,c
    for n = 5,totalPotentialNum do
    	a = (n-2)%3
    	if a == 2 then
    		a = -1
    	end
    	h1 = height + a
		if h1 >=0 and h1<=2 then
			b = (n-5)%6
			c = math.floor((n-5)/6) + 1
			if b<3 then
				w1 = width - c
			else
				w1 = width + c
			end
			checkAvailable(w1,h1)
		end
    end

    table.sort(potentialList,function(v1,v2)
    	if v1[3] ~= v2[3] then
    		return v1[3]<v2[3]
    	else
    		return v1[2]<v2[2]
    	end
    end)

    if #potentialList > 0 then
    	local resultBoxIdx = potentialList[1][1]
    	self.destinationBoxIdx = resultBoxIdx
    	return
    else
    	print("不可能执行到这里,如果执行到这里，原地idle")
    	print(self.entity.data.heroName)
    	self.entity.fsm:changeState(StateEnum.Idling)
    end
end

--更新位置
function State_RunningToEnemy:updatePosition()
	if self.frames == nil then
		print("不可能执行到这里_State_RunningToEnemy:update(dt)")
		return
	end

	--更新所属地块
	self.entity.box_w,self.entity.box_h = GetBoxWHByPoint(self.entity:getPositionX(),self.entity:getPositionY())

	self.frames = self.frames - 1
	--跑动中
	if self.frames >= 0 then
		--检测下一帧是否换了格子，新格子里是否有敌人。
		self.nextPosX = self.entity:getPositionX() + self.deltaXPerFrame
		self.nextPosY = self.entity:getPositionY() + self.deltaYPerFrame

		self.nextW,self.nextH = GetBoxWHByPoint(self.nextPosX,self.nextPosY)

		if (self.nextW ~= self.entity.box_w or self.nextH ~= self.entity.box_h) then
			--检测下一个格子中是否有敌人。如果有，在当前格子停下来并修正位置。
			if self.entity:checkBoxOccupiedByEnemyWithWH(self.nextW,self.nextH) then
				--修正位置
				self:correctPosWithRunning()
				return
			else
				self.entity:setPosition(self.nextPosX,self.nextPosY)
			end
		else
			self.entity:setPosition(self.nextPosX,self.nextPosY)
		end
	--到达目标位置后
	else
		if not self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h) then
			--修正位置
			self:correctPosWithRunning()
			return
		end

		if self:checkIsEnemyInRange(self.enemyEntity) then
			--开始攻击
			self.entity.fsm:changeState(StateEnum.Attacking,self.enemyEntity)
		else
			self.entity.fsm:changeState(StateEnum.RunningToEnemy,self.data)
		end
	end
end

--检测enemy是否发生了移动。
function State_RunningToEnemy:checkIsEnemyMoved()
	local w,h = self.enemyEntity:getBoxWH()
	if w ~= self.enemyInitial_W or h ~= self.enemyInitial_H then
		self.enemyInitial_W = w
		self.enemyInitial_H = h
		return true
	else
		return false
	end
end