ChatDataCache = class("ChatDataCache")
ChatDataCache.__index = ChatDataCache

ChatDataCache.friendMax = 100 --好友上限
ChatDataCache.blackMax  = 100 -- 黑名单上限
ChatDataCache.recentChatMax = 100 --最近聊天上限

function ChatDataCache:clearData( )
	self.friendMax = 100
	self.friendMax = 100
	self.recentChatMax = 100
	self.banSpeakEndTime = 0
end

function ChatDataCache:init(  )
	self.friendMax = 100
	self.friendMax = 100
	self.recentChatMax = 100
	self.banSpeakEndTime = 0
end

function ChatDataCache:create(  )
	 local chatData = ChatDataCache.new()
     chatData:init()
     return chatData
end

function ChatDataCache:setBanSpeakTimeEnd( tm )
	self.banSpeakEndTime = tm
end

function ChatDataCache:getBanSpeakTimeEnd(  )
	return self.banSpeakEndTime 
end