NoticeManager = {}
NoticeManager._container = nil
NoticeManager._last_load_time = 0

function NoticeManager:createPanel()
    if self._container then return end

    local npBg = cc.Sprite:create("res/uifile/n_UIShare/Global_UI/other/ggsc_ui_130.png")
    
                                    -- "res/uifile/n_UIShare/Global_UI/other/ggsc_ui_130.png"

    local npbgsize = cc.size(900,500);
    if npBg then
         npBg:setAnchorPoint(cc.p(0.5,0))
        npBg:setPosition(640,0)
        npbgsize = npBg:getContentSize()
    
    end
   

    local rootPos = cc.Director:getInstance():getVisibleSize()
    local y = ScreenManager:getRootPoint().y

    self._container = ccui.Layout:create()
    self._container:setAnchorPoint(cc.p(0.5,1))
    self._container:setContentSize(1280,npbgsize.height)
    self._container:setPosition(rootPos.width/2,635+y)
    self._container:setClippingEnabled(true)
   -- self._container:setTouchEnabled(true)
    if npBg then
        self._container:addChild(npBg,0,1)
    end
    
    -- self.noticePanel:setBackGroundColor(cc.c3b(100,0,0))
    -- self.noticePanel:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    self._container:setVisible(false)
    return self._container
end

function NoticeManager:clear()
    self._willStop = false
    NoticeManager:_stopNotice()
    if self._container then
        self._container:removeFromParent()
        self._container = nil
    end
    self.system_notice = nil
    self.world_notice = nil
    self.local_notice = nil
end

function NoticeManager:startNotice()
    self._willStop = false

    if not self._container then return end
    if self._schedulerEntry then return end

    self._timeCount = 10000
    self._isplaying = false
    local scheduler = cc.Director:getInstance():getScheduler()
    self._schedulerEntry = scheduler:scheduleScriptFunc(function()
        NoticeManager:onTime()
    end,1, false)
end

function NoticeManager:stopNotice()
    self._willStop = true
end

function NoticeManager:_stopNotice()
    if self._schedulerEntry then
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self._schedulerEntry)
        self._schedulerEntry = nil
    end

    if self._container then
        local ch111 = self._container:getChildByTag(111)
        if ch111 then
            ch111:stopAllActions()
            ch111:removeFromParent()
        end
        self._container:setVisible(false)
    end

    self._timeCount = nil
    self._isplaying = nil
    self._willStop = false
end

function NoticeManager:onTime()
    if self._willStop then
        self:_stopNotice()
        self._willStop = false
        return
    end

    self._timeCount = self._timeCount + 1
    if self._timeCount >= 30 then
        self._timeCount = 0
        local ostime = UserDataMgr:getInstance().timeData:getCurrentTime()--os.time()
        if ostime - self._last_load_time > 25 then
            self:loadNotice()
        end
        self._last_load_time = ostime
    end

    if self._isplaying then return end

    local noticebody = nil

    if self.system_notice ~=nil and  #self.system_notice > 0 then
        local sysstr = self.system_notice[1]
        noticebody = UITool.buildSystemNotice(sysstr)
        table.remove(self.system_notice,1)
    elseif self.local_notice ~= nil and #self.local_notice > 0 then
        local ldata = self.local_notice[1]
        noticebody = UITool.buildWorldNotice(ldata.notice_type,ldata.item_type,ldata.item_id,ldata.item_num,ldata.name)
        table.remove(self.local_notice,1)
    elseif self.world_notice ~= nil and #self.world_notice > 0 then
        local wdata = self.world_notice[1]
        noticebody = UITool.buildWorldNotice(wdata.notice_type,wdata.item_type,wdata.item_id,wdata.item_num,wdata.name)
        table.remove(self.world_notice,1)
    else
        self._container:setVisible(false)
    end

    if noticebody then
        self._container:setVisible(true)
        self._container:addChild(noticebody,0,111)

        local size1 = self._container:getContentSize()
        local size2 = noticebody:getContentSize()

        noticebody:setPosition(size1.width/2,- size2.height / 2)
        local move = cc.MoveTo:create(0.5,cc.p(size1.width/2,size1.height / 2))
        local move1 = cc.MoveTo:create(0.5,cc.p(size1.width/2,size2.height / 2 + size1.height))
        local sequence = cc.Sequence:create(move,cc.DelayTime:create(5),move1, cc.CallFunc:create(function()
            noticebody:removeFromParent()
            self._isplaying = false
        end))
        self._isplaying = true
        noticebody:runAction(sequence)
    end

end

function NoticeManager:insertRoleNotice(h_num_id)
    if not self.local_notice then
        self.local_notice = {}
    end
    table.insert(self.local_notice,{
        uid = user_info["id"],
        name = user_info["name"],
        notice_type = 1,
        item_type = 4,
        item_id = h_num_id,
        item_num = 1,
    })
end
function NoticeManager:insertEquipNotice(eq_num_id)
    if not self.local_notice then
        self.local_notice = {}
    end
    table.insert(self.local_notice,{
        uid = user_info["id"],
        name = user_info["name"],
        notice_type = 1,
        item_type = 3,
        item_id = eq_num_id,
        item_num = 1,
    })
end
--[[data = {
  "state_code": 1,
  "world_notice":[  # 世界公告,滚动播放
      [uid,name,notice_type,item_type,item_id,item_num],
      [uid,name,notice_type,item_type,item_id,item_num],
  ],
  "system_notice":["测试测试","关服关服"],# 系统公告,单条.优先播放一次
}]]

function NoticeManager:addSystemNotice(notice)
    if not self.system_notice then
        self.system_notice = {}
    end
    table.insert(self.system_notice,table.deepcopy(notice))
end


function NoticeManager:addWorldNotice(notice)
    if not self.world_notice then
        self.world_notice = {}
    end
    table.insert(self.world_notice,table.deepcopy(notice))
end

function NoticeManager:loadNotice()
    GameManagerInst:rpc("{\"rpc\":\"notice_beat\"}",11,
    function(data)
        --success
        --GameManagerInst:saveToFile("notice_beat.json",data)
        self.world_notice = table.deepcopy(data.world_notice)
        self.system_notice = table.deepcopy(data.system_notice)
    end,
    function(state_code,msgText)
        --GameManagerInst:alert(msgText)
    end,
    false)
end
