
ChatNewPannelChatroom = class("ChatNewPannelChatroom",XUIView)
ChatNewPannelChatroom.CS_FILE_NAME = "ChatPannelChatroom.csb"
ChatNewPannelChatroom.CS_BIND_TABLE = 
{
    chatRoomPannel 				= "/i:1",
	chatRoom_bg 				= "/i:1/i:1",
    chatRoom_pannel_name 		= "/i:1/i:2/i:1",
    chatroom_btn_changeRoom		="/i:1/i:2/i:2",
    -- chatroom_inputNode			="/i:1/i:3",

    chatroom_chatList_pannel	= "/i:1/i:4",
    
}

ChatNewPannelChatroom.LogTag = "ChatNewPannelChatroom"

function ChatNewPannelChatroom:create(rData)
    local login = ChatNewPannelChatroom.new()
    login.uiLayer   = cc.Layer:create()
    login:initUI()
    return login
end

function ChatNewPannelChatroom:clear( )
	self:registEventDispatcher(false)
	if self._scrollView then
		self._scrollView:clear()
		self._scrollView = nil
	end

	
end

function ChatNewPannelChatroom:returnBack(  )
	self:clear()
end

function ChatNewPannelChatroom:initUI(  )
	self:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)
	
	self:initData()

	self:bindAllBtn()

	self:refreshChannelName()

	self:registEventDispatcher(true) 	--启动通知事件

end

function ChatNewPannelChatroom:initData(  )

	self._scrollView 			= nil 
	self._wordRooomID 			= nil
	self.fetchMessage 			= false 

	self.change_room_idex 		= 1
	self.change_room_id 		= nil 

end

function ChatNewPannelChatroom:bindAllBtn(  )
	self.chatRoom_bg:setVisible(false);

	self.inputNode = ChatInputNode:create()
	self.inputNode:setDelegate(self)
	self.inputNode:setSendCallback(function ( sender,message )
		self:sendMessage(message)
	end)
	self.chatRoomPannel:addChild(self.inputNode:getRootNode())

    self.chatroom_btn_changeRoom:addTouchEventListener(handler(self,self.chatroomChangeCallback))


	local psize = self.chatroom_chatList_pannel:getContentSize()
	self._scrollView = XBChatNewListView.new():initWithNodeAndSize(self.chatroom_chatList_pannel, psize.width, psize.height)
	self._scrollView:setItemCreateFunc(handler(self,self.createItem))
	self._scrollView:setItemRemoveFunc(handler(self,self.removeItem))
	
end

function ChatNewPannelChatroom:registEventDispatcher(bTrue)
	print("registEventDispatcher:::"..tostring(bTrue))
	if bTrue == false  then
		-- lemon.EventManager:getInstance():removeEventListener(self.world_login_listener)
		return 
	end
	--监听当前聊天室进入
	-- self.world_login_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHATROOM_ENTER_WORLD,handler(self,self.eventCbEnterChatroomWorld))
end

function ChatNewPannelChatroom:eventEnterChatroom( session_type,session_id ,code) --登陆结果通知回调
	if session_type ~= 2  then
		print("拒绝处理：类型不匹配。。eventEnterChatroom type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._wordRooomID))
		return 
	end

	if code ~= 0 then
		-- print("聊天室登陆失败！！code:"..tostring(code)..",session_id:"..tostring(session_id)..",session_type:"..tostring(session_type))
		XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1031015))

		self:refreshChannelName()

		return
	end

	local worldRoomid = XBChatData:getInstance():getWorldRoomID()

	-- print("ChatNewPannelChatroom;;eventEnterChatroom====="..worldRoomid.."....:"..session_id)
	if tostring(session_id) == worldRoomid then
		self._wordRooomID = worldRoomid
		XBChatData:getInstance():setCurrentSession(self._wordRooomID, 2)

		self:refreshChatListView()

		self:refreshChannelName()

	elseif tostring(session_id) == tostring(self.change_room_id) then
		--切换聊天室
		local msg = string.format(Lang:toLocalization(1031012),tonumber(self.change_room_idex) )
		MsgTipSys:getInstance():addData(msg)

		XBChatData:getInstance():setWorldRoomID(self.change_room_id)
		XBChatData:getInstance():setWorldIndex(self.change_room_idex)

		self:exitChatRoom(self._wordRooomID)

		self._wordRooomID = self.change_room_id

		XBChatData:getInstance():setCurrentSession(self._wordRooomID, 2)

		self:refreshChannelName()

		self.change_room_id = nil 

		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self._wordRooomID)
		self._scrollView:setDataSource(chatroom_datas)
	end 


end

function ChatNewPannelChatroom:eventRefreshUI( session_type,session_id,scrollEnd )

	if session_type ~= 2 then
		print("拒绝处理：类型不匹配。。eventRefreshUI: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._wordRooomID))
		return 
	end
	if  tostring(session_id) ~= tostring(self.change_room_id) and tostring(session_id) ~= tostring(self._wordRooomID)  then
		print("拒绝处理：非聊天室！！")	
		return 
	end
	XBChatData:getInstance():setCurrentSession(self._wordRooomID, 2)
	
	self:refreshChatListView(scrollEnd)

end
--
function ChatNewPannelChatroom:eventFecthSession( session_type,session_id )
	if session_type ~= 2 or session_id ~= self._wordRooomID  then
		print("拒绝处理：类型不匹配。。eventFecthSession: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._wordRooomID))
		return 
	end

	self.fetchMessage = true 

	self:refreshChatListView(true)
end



function ChatNewPannelChatroom:createItem( data )
	data["size_type_small"] = false -- 是否为小item
	return XBChatListViewItemPool:getInstance():createItemByData(data)
end

function ChatNewPannelChatroom:removeItem( item )

	return XBChatListViewItemPool:getInstance():removeItemToPool(item)

end

function ChatNewPannelChatroom:channelDataRefresh( ... )
	self:initConcationChatRoom()
end

function ChatNewPannelChatroom:initConcationChatRoom(  )
	local roomid = XBChatData:getInstance():getWorldRoomID()
	if roomid == nil  then
		print("error=======roomid无效")
		return
	end
	if  XBChatData:getInstance():getChatRoomEnterState(roomid) ~= true  then --世界
		print("initConcationChatRoom.....roomid:"..tostring(roomid))

		if roomid == "0"  then
			XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1010797))
			return
		end
		XBChatData:getInstance():setWorldRoomID(roomid)

		XBChatSys:getInstance():createChatWaitLayer();

		local t_data = {
			session_id = roomid,
		}
		XBChatSys:getInstance():enterChatRoom(t_data)
	else
		self._wordRooomID = roomid
		XBChatData:getInstance():setCurrentSession(self._wordRooomID, 2)

		self:refreshChatListView()

	end
end

function ChatNewPannelChatroom:exitChatRoom(roomid)
	-- body
	local function exitRoomCallback( t_data  )
		if t_data == nil  then
			return 
		end

		local code = t_data["code"]
		local roomid_exit = t_data["room_id"]


		if code == 0  then
			if tostring(roomid_exit) == tostring(self._wordRooomID) then
				self._wordRooomID = nil 
			end

		else
			print("error==========退出聊天室失败！！！code == "..tostring(code))
		end
		


	end
	local t_data_exit = {
		session_id = roomid,
	}
	XBChatSys:getInstance():exitChatRoom(t_data_exit, exitRoomCallback)

end
function ChatNewPannelChatroom:changeChatRoomByIndex( newChatRoomIndex )
	
	local changeRoomid = XBChatData:getInstance():getRoomIDByIndex(newChatRoomIndex)
	if changeRoomid == nil or changeRoomid == "0" then
		-- XBChatSys:getInstance():showChatDebugMsg("找不到对应聊天室ID:"..tostring(number),"ChatNewPannelChatroom")
		XBChatSys:getInstance():showChatSimpMsg(string.format(Lang:toLocalization(1031005), tostring(newChatRoomIndex)))
		
		self:refreshChannelName()
		return 
	end

	if tostring(self._wordRooomID) == tostring(changeRoomid) then 
		print("已在当前频道")
		return 
	end

	self.change_room_id = changeRoomid
	self.change_room_idex = newChatRoomIndex

	XBChatSys:getInstance():createChatWaitLayer();

	local t_data = {
		session_id = changeRoomid,
	}
	XBChatSys:getInstance():enterChatRoom(t_data)


end

function ChatNewPannelChatroom:removeScrollView( ... )
	print("ChatNewPannelChatroom:removeScrollView===")
	if self._scrollView then
		self._scrollView:resetTempData()
	end

	self._wordRooomID 			= nil
	self.fetchMessage 			= false 

	self.change_room_id 		= nil 
end

function ChatNewPannelChatroom:refreshChatListView( scrollEnd )
	if self._wordRooomID == nil  then
		return 
	end

	if self.fetchMessage == true or self._scrollView:getDataSource() == nil  then
		if self.fetchMessage == true  then
			self.fetchMessage = false 
		end
		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self._wordRooomID)
		self._scrollView:setDataSource(chatroom_datas)
	else
		self._scrollView:refreshDataSource(scrollEnd)
	end 


end

function ChatNewPannelChatroom:sendMessage( message )
	
	print("sendBtnCallback:"..tostring(message).."..._wordRooomID:"..tostring(self._wordRooomID))
	local channelIndex = 2
	XBChatPlatform:getInstance():sendmessage(channelIndex, self._wordRooomID,2,tostring(message),"" ,function (  )
		self.inputNode:setInputString("")
	end)
end

function ChatNewPannelChatroom:chatroomChangeCallback( sender,eventType )
	-- body
	print("chatroomChangeCallback:"..sender:getTag())
	if eventType == ccui.TouchEventType.ended then
		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self._wordRooomID)
		local list = chatroom_datas:getList()
		dump(list, "ChatNewPannelChatroom.."..tostring(self._wordRooomID))

		
		
		self:showChangeChannelLayer()
	end
end

--显示改变频道页面
function ChatNewPannelChatroom:showChangeChannelLayer( )

	self:createChannelLayer()
end

--创建改变频道页面
function ChatNewPannelChatroom:createChannelLayer( sender,eventType )

		--切换到新的聊天频道
		local function confirmFunc(roomNumber)
			local number = tonumber(roomNumber)

			--更改成功之后进入对应的聊天室
			-- self:refreshChannelName()
			print("ChatNewPannelChatroom:chatroomChangeCallback confirmFunc", tostring(number))

			self:changeChatRoomByIndex(number)

		end


		--	恢复成默认的聊天频道
		local function cancelFunc()
			
			self:refreshChannelName()
			
		end

		--刷新 当前的选择的数字
		local function refreshFunc(roomNumber)
			
			local number = tonumber(roomNumber)
			self.chatRoom_pannel_name:setString(number)
			print("ChatNewPannelChatroom:chatroomChangeCallback backFunc", tostring(number))
			
		end

		local data = {

			confirmCallback = confirmFunc,
			cancelCallback = cancelFunc,
			refreshCallback = refreshFunc
		}


		local changeChannelLayer = XBChatNewChangeChannelLayer:create(data)

		self:getRootNode():addChild(changeChannelLayer:getRootNode())
end


--刷新频道名字
function ChatNewPannelChatroom:refreshChannelName( )
	print("refreshChannelName")
	local channelNumber = XBChatData:getInstance():getWorldIndex(  ) or 1
	print("channelNumber ", channelNumber)
	local channelStr = string.format(Lang:toLocalization(1031009),channelNumber)
	print("channelStr ", channelStr)
	self.chatRoom_pannel_name:setString(channelStr)

end
