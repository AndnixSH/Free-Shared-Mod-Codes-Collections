SPCacheManager  = {} 
sp_cache = {}
asyncHandlers = {}

function SPCacheManager:addSPToCache(file)
	local id_str = file
    local end_pos = string.find(id_str,'atlas') - 1
	local spName = string.sub(id_str,0,end_pos)
    cc.Texture2D:setDefaultAlphaPixelFormat(cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A4444)
	local Sp = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
	cc.Texture2D:setDefaultAlphaPixelFormat(cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)
	Sp:retain()
	sp_cache[file] = Sp
end

--暂时废弃
-- function SPCacheManager:getSPFromCache(file)
-- 	if sp_cache[file] == nil  then
-- 	    local id_str = file
-- 	    local end_pos = string.find(id_str,'atlas') - 1
-- 		local spName = string.sub(id_str,0,end_pos)
-- 		local Sp = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
-- 		Sp:retain()
-- 		sp_cache[file] = Sp
-- 	end
-- 	return sp_cache[file]:getSkeletonData()
-- end

function SPCacheManager:getSPFromCache(file)
	if sp_cache[file] ==nil  then
	    local id_str = file
		--assert(string.find(id_str,'atlas'),"传入的文件名字是："..string.format("%s",id_str))
	    local end_pos = string.find(id_str,'atlas') - 1
		local spName = string.sub(id_str,0,end_pos)
		cc.Texture2D:setDefaultAlphaPixelFormat(cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A4444)
		local Sp = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
		cc.Texture2D:setDefaultAlphaPixelFormat(cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)
		Sp:retain()
		sp_cache[file] = Sp
	end
	return sp_cache[file]
end
---异步加载
--添加异步缓存 spine到缓冲区
function SPCacheManager:addAsyncSPToCache(file,callBackFunc)
	if sp_cache[file] == nil then
	  	local id_str = file
	    local end_pos = string.find(id_str,'atlas') - 1
		local spName = string.sub(id_str,0,end_pos)
	    local asyncHandler = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(skeletonNode)
    		skeletonNode:retain()
			sp_cache[file] = skeletonNode
			asyncHandlers[file] = nil   	--出
            if callBackFunc then
                callBackFunc(file,sp_cache[file])
            end  
	    end)
	    asyncHandlers[file] = asyncHandler  --入
	else 
        if callBackFunc then
            callBackFunc(file,sp_cache[file])
        end
	end
end

function SPCacheManager:removeSPFromCache(file)
	  if sp_cache[file] ~=nil  then
	  	 sp_cache[file]:release()
	  	 sp_cache[file] = nil
      end
      if asyncHandlers[file] ~= nil then 
      		print("中断异步加载removeSPFromCache :"..file)
      		asyncHandlers[file]:cancel(true)
      		asyncHandlers[file] = nil 
      end 
end

function SPCacheManager:clearCache()
	for k,v in pairs(sp_cache) do
		if v~=nil then
		  v:release()
		  v = nil	
		end
	end
	for k,v in pairs(asyncHandlers) do
		if v~=nil then
		  v:cancel(true)
		  print("退出界面中断异步加载clearCache:"..k)
		  v = nil	
		end
	end
	asyncHandlers = {}
	sp_cache = {}
end