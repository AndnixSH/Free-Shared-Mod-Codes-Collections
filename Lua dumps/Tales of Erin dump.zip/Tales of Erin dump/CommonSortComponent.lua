--[[
	CommonSortComponent.lua
	筛选排序器

	筛选+排序
    	CommonSortButtonView --排序按钮
    	CommonSortBoxLayer	 --筛选UI

	guestLayer：需实现两个方法
    	sortStateChangeFunc() ---生降序发生变化
    	sortTypeChangeFunc()  ---排序筛选规则发生变化

    说明：
	    1、只处理 排序筛选数据如（herobook_sort_data），修改其选中状态，绝不改变结构
	       排序、筛选 发生改变直接返回给调用者
	    2、调用者 根据修改后的排序tab，对数据进行 筛选排序操作。如：称号列表，如角色列表、装备列表

	Example：
	    use_herobook_sort_data = use_herobook_sort_data or herobook_sort_data--临时缓存排序数据
	    self._sortComponent = CommonSortComponent.new():init(self, use_herobook_sort_data) 
	    self._sortComponent:addSortButtonUI(self.panelSort)
	    详情可以参考 HeroBookLayer.lua

]]
CommonSortComponent = class("CommonSortComponent")

function CommonSortComponent:ctor()
	self._sortLayer = nil
	self._sortType = nil
	self._guestLayer = nil
	self._data = nil
end

function CommonSortComponent:init(guestLayer, data)
	self._data = table.deepcopy(data)
	self:initSortTypeFormData()
	self._guestLayer = guestLayer
	return self
end

function CommonSortComponent:addSortButtonUI(rootNode)
	self._sortButton = CommonSortButtonView.new():init(rootNode,self)
	return self._sortButton
end

function CommonSortComponent:showSortBoxUI()
	self._sortLayer = CommonSortBoxLayer.new():init(self, self._data)
	GameManagerInst:showModalView(self._sortLayer)
end

function CommonSortComponent:resetData(data)
	for i=1,#data do
		for t=1,#data[i].items do
			if t==1 then 
				data[i].items[t].state = 1
			else 
				data[i].items[t].state = 0
			end 
		end
	end
end

--单选
function CommonSortComponent:initSortTypeFormData()
	if  self._data  == nil then 
		return 
	end 
	for i=1,#self._data[1].items do
		if self._data[1].items[i].state == 1 then 
			self._sortType = i
		end 
	end
	if self._sortType == nil then 
		self._sortType = 1 
		dump("排序表错误，未设置默认排序")
	end 
end

function CommonSortComponent:getSortData()
	local temp_sortName = self._data[1].items[self._sortType].name
	local temp_sortState = self:getSortState()
	local data = {
		sortType = self._sortType,
		sortName = temp_sortName,
		sortState = temp_sortState
	}
	return data
end

function CommonSortComponent:getSortTypeValue()
	local sortValue = self._data[1].items[self._sortType].value
	return sortValue
end

--生序 、降序 发生变化
function CommonSortComponent:setSortState(sortState) 
	self._data[1].sortState = sortState
	self:sortStateChangeFunc()
end

function CommonSortComponent:getSortState()
	return self._data[1].sortState
end

--生降序发生变化
function CommonSortComponent:sortStateChangeFunc()
	self._guestLayer:sortStateChangeFunc()
end

--筛选盒子 点击确认按钮，回调
function CommonSortComponent:siftBoxCallBack(boxTempData)
	local isChange = false
	for i=1,#boxTempData do
		local items = boxTempData[i].items
		local baseItems = self._data[i].items
		for t=1,#items do
			if items[t].state ~= baseItems[t].state then
				isChange = true
			end 
		end
	end
	if isChange then 
		print("筛选排序规则、发生变化")
		self._data = boxTempData
		self:initSortTypeFormData()
		self._sortButton:refreshBtns()
		self:sortTypeChangeFunc()
	else 
		print("排序筛选-不需要处理")
	end
end

--筛选条件发生变化、排序类型发生变化,直接反馈给调用者即可
function CommonSortComponent:sortTypeChangeFunc()
	self._guestLayer:sortTypeChangeFunc()
end

--[[
	返回当前的筛选集合
	selects = {
		rank = {1,2,3},
		element = {2,3,3,4}
	}
--]]
function CommonSortComponent:getSelectData()
	local selects = {} --字典
	for i=2,#self._data do
		local data = self._data[i]
		local key = data.s_type
		selects[key] = {}
		if data.items[1].state == 1 then --全部
			selects[key].selectAll = true
		else 
			selects[key].selectAll = false
			for t=2,#data.items do
				local item = data.items[t]
				if item.state == 1 then 
					selects[key][#selects[key]+1] = data.items[t].value
				end 
			end
		end 
	end
	return selects
end

function CommonSortComponent:isSelectAll()
	for i=2,#self._data do
		local data = self._data[i]
		if data.items[1].state ~= 1 then --全部
			return false
		end 
	end
	return true
end