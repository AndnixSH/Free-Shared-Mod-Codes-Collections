
--邮件系统


--邮件类型
EMailType = {
    friend = 2,
    system = 1,
    message = 3

}




MailSys = class("MailSys")




function MailSys:getInstance()
   if self.s_instance == nil then

        self.s_instance = MailSys.new()
        self.s_instance:initialize()

   end
   return self.s_instance;
end


function MailSys:initialize()
  
end


-----------------------------------------------------------------------
------------------------      接口 开始   -------------------------------
-----------------------------------------------------------------------

--请求邮件列表
-- ["source_type"] = 0 (-1、全部，2、好友， 1、系统)
function MailSys:reqMailList(reqData,successCallback, failCallback)
  

    local mailType = table.getValue("MailSys:reqMailList data", reqData, "mailType")
    if self:isMail(mailType) ==  false then
        LogManager.showSimpMsgDebug("Type "..tostring(mailType).." is not a mail","MailSys:reqMailList" )
        return;
    end

    if self:isSimpleMail(mailType) then

        self:reqSimpleMailList(reqData,successCallback, failCallback)

    elseif self:isMessageMail(mailType) then

        self:reqMessageList(reqData,successCallback, failCallback)

    end
    
end

--获取单纯的邮件列表
-- ["source_type"] = 0 (-1、全部，2、好友， 1、系统)
function MailSys:reqSimpleMailList(reqData,successCallback, failCallback)
    dump(reqData, "MailSys:reqSimpleMailList data")

    local mailType = table.getValue("MailSys:reqSimpleMailList data", reqData, "mailType")
    

    local tempData = {
        ["rpc"] = "mail_list",
        ["source_type"] = mailType
        -- ["mail_type"] = 1,
        -- ["item_rarity"] = 0,
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end

--先获取所有的信息，然后筛选出有没有未读的邮件；PS：就是刷新红点
function MailSys:reqAllMailInfoForRedShow(successCallback,failCallback)
    local tempData = {
        ["rpc"] = "mail_list",
        ["source_type"] = -1
    }
    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end

--获取单纯的邮件列表

function MailSys:reqMessageList(reqData,successCallback, failCallback)
    dump(reqData, "MailSys:reqMessageList data")

    local mailType = table.getValue("MailSys:reqMessageList data", reqData, "mailType")
    

    local tempData = {
        ["rpc"] = "mail_list",
        -- ["mail_type"] = 1,
        -- ["item_rarity"] = 0,
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end



--删除已读
--source_type
--mailArr 邮件数组，里面填写需要删除的邮件id，如果不填，就是全部
function MailSys:reqDeleteMailRead(reqData, successCallback, failCallback)

    assert(reqData ~= nil, "MailSys:reqDeleteMailRead data should no be nil")
    local source_type = table.getValue("MailSys:reqDeleteMailRead", reqData, "source_type") or ""

    print("MailSys:reqDeleteMailRead source_type: ", source_type)


    local tempData = {
        ["rpc"] = "mail_del_read",
        ["source_type"] = source_type,
        
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            if failCallback then
                failCallback()
            end
        end,
        true)
end


--标记已读
-- data.read_type 1 是读指定若干邮件 2 读取所有
-- data.mail_ids  邮件id(数组)

function MailSys:reqMarkMailRead(reqData,successCallback, failCallback)

    assert(reqData ~= nil, "MailSys:reqMarkMailRead data should no be nil")
    local read_type = table.getValue("MailSys:reqMarkMailRead", reqData, "read_type") or ""
    local mail_ids = table.getValue("MailSys:reqMarkMailRead", reqData, "mail_ids") or {}
    local source_type = table.getValue("MailSys:reqMarkMailRead", reqData, "source_type") or {}
  
    print("MailSys:reqMarkMailRead read_type: ", read_type)
    dump(mail_ids, "MailSys:reqMarkMailRead mail_ids")

    local tempData = {
        ["rpc"] = "mail_read",
        ["read_type"] = read_type,
        ["mail_ids"] = mail_ids,
        ["source_type"] = source_type
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        false)
end

-- 快速领取
-- data.source_type（好友，系统，消息）
-- data.mailArr 邮件数组，里面填写需要删除的邮件id，如果不填，就是全部
-- data.auto_del
-- data.get_type (1、所有, 2、素材) 
function MailSys:reqQuickGain(reqData, successCallback, failCallback)

    assert(reqData ~= nil, "MailSys:reqQuickGain data should no be nil")
    local source_type = table.getValue("MailSys:reqQuickGain", reqData, "source_type") or ""
    local get_type = table.getValue("MailSys:reqQuickGain", reqData, "get_type")
    local auto_del = table.getValue("MailSys:reqQuickGain", reqData, "auto_del")
    local auto_give_ap = table.getValue("MailSys:reqQuickGain", reqData, "auto_give_ap")
    print("MailSys:reqQuickGain source_type: ", source_type)

    if self:isSimpleMail(source_type) ==  false then
        LogManager.showSimpMsgDebug("Type "..tostring(source_type).." is not a simple mail","MailSys:reqQuickGain" )
        return;
    end




    local tempData = {
        ["rpc"]       = "mail_get_all",
        ["get_type"]   = get_type,
        ["source_type"]   = source_type,
        ["auto_del"]   = auto_del,
        ["auto_give_ap"] = auto_give_ap,
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end


-- 领取单个文件

function MailSys:reqSingleMail(reqData, successCallback, failCallback)

    assert(reqData ~= nil, "MailSys:reqSingleMail data should no be nil")
    local mail_id = table.getValue("MailSys:reqSingleMail", reqData, "mail_id")

    local auto_del = table.getValue("MailSys:reqSingleMail", reqData, "auto_del")

    local auto_give = table.getValue("MailSys:reqSingleMail", reqData, "auto_give_ap")

    local tempData = {
        ["rpc"]       = "mail_get",
        ["mail_id"]   = mail_id,
        ["auto_del"]   = auto_del,
        ["auto_give_ap"] = auto_give
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end

--  请求战斗邀请列表
function MailSys:reqBattleInviteList(reqData, successCallback, failCallback)

    print("MailSys:reqBattleInviteList ")

    local tempData = {
        ["rpc"] = "battle_invite_list",
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
           
        end,
        false)
end



-- 拒绝战斗邀请
function MailSys:reqRefuseBattleInvite(reqData, successCallback, failCallback)

    print("MailSys:reqRefuseBattleInvite mailType: ")

    local enabled = table.getValue("MailSys:reqRefuseBattleInvite", reqData, "enabled")

    local tempData = {
        ["rpc"] = "battle_invite_enable",
        ["enabled"] = enabled,
    }

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end


-- 消息中心 一键 删除

function MailSys:reqQuickDelete(reqData, successCallback, failCallback)

    assert(reqData ~= nil, "MailSys:reqQuickDelete data should no be nil")
    print("MailSys:reqQuickDelete")
    local del_type = table.getValue("MailSys:reqQuickDelete", reqData, "del_type")
    local tempData = {
        ["rpc"]       = "battle_invite_del",
        ["del_type"]   = del_type,
    }
    
    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end


-----------------------------------------------------------------------
------------------------      接口 结束   -------------------------------
-----------------------------------------------------------------------


-- 设置自动删除已读邮件

function MailSys:setAutoDelete(mailType, bRet)

    local saveKey = self:getAutoDeleteKey(mailType)

    XBConfigManager:getInstance():setGlobalBooleanByKey(saveKey, bRet)
end


-- 读取自动删除已读邮件

function MailSys:getAutoDelete(mailType)
    local saveKey = self:getAutoDeleteKey(mailType)
    local autoDelete = XBConfigManager:getInstance():getGlobalBooleanByKey(saveKey)
    return autoDelete
end


function MailSys:getAutoDeleteKey(mailType)
    local userId = user_info["id"]
    local saveKey = userId..",mail_auto_delete,"..tostring(mailType)
    print("AutoDeleteKey", saveKey)
    return saveKey
end


--对邮件排序
function MailSys:sortMailList(mailList)
   
    local mailArr = mailList
    print("sort before")
    dump(mailArr, "sortMailList mailList")
    table.sort(mailArr,function(a, b)
            local result = false
            if (a.is_new or 0) > (b.is_new or 0) then
                return true
            elseif (a.is_new or 0) == (b.is_new or 0) then
                if (a.alive_time or 0) > (b.alive_time or 0) then
                    return true
                elseif (a.alive_time or 0) == (b.alive_time or 0) then
                    if (a.mail_id or 0) > (b.mail_id or 0) then
                        return true
                    end
                end
            end
            return false

        end)
    print("sort after")
    dump(mailArr, "sortMailList mailList")
    return mailList

end


--在某个邮件列表中 删除邮件
function MailSys:deleteMail(mailList, deleteMailList)
    mailList = mailList or {}
    deleteMailList = deleteMailList or {}
    local function check(mailId)
        for i = 1, #deleteMailList do
            
            if deleteMailList[i] ==  mailId then
                print("MailSys:deleteMail mailId = "..tostring(mailId))
                return true
            end
        end
        return false
    end

    local mailArr = mailList

    local newMailArr = {}
    for i = 1, #mailArr  do
        local mail = table.getValue("MailSys mailArr", mailArr, i)
        local mailId = table.getValue("MailSys mail", mail, "mail_id")

        if check(mailId) == false then
           table.insert(newMailArr, mailArr[i])
        end 
    end
    return newMailArr

end



--在某个邮件列表中 标记已读
function MailSys:readMail(mailList, readMailList)
    mailList = mailList or {}
    readMailList = readMailList or {}
    
     local function check(mailId)
        for i = 1, #readMailList do
            
            if readMailList[i] ==  mailId then
                print("MailSys:readMail mailId ="..tostring(mailId))
                return true
            end
        end
        return false
    end

    local mailArr = mailList
    for i = 1, #mailArr  do
        local mail = table.getValue("MailSys mailArr", mailArr, i)
        local mailId = table.getValue("MailSys mail", mail, "mail_id")

        if check(mailId) then
            mail["is_new"] = 0
        end 
    end

    return mailList
end


--在某个邮件列表中 标记已读
function MailSys:gainMail(mailList, gainMailList)
    mailList = mailList or {}
    gainMailList = gainMailList or {}

    dump(mailList, "gainMail mailList")
    dump(gainMailList, "gainMail gainMailList")
    
     local function check(mailId)
        for i = 1, #gainMailList do
            
            if gainMailList[i] ==  mailId then
                print("MailSys:gainMail mailId ="..tostring(mailId))
                return true
            end
        end
        return false
    end

    local mailArr = mailList
    for i = 1, #mailArr  do
        local mail = table.getValue("MailSys mailArr", mailArr, i)
        local mailId = table.getValue("MailSys mail", mail, "mail_id")

        if check(mailId) then
            mail["item_list"] = nil
            mail["is_new"] = 0
        end 
    end
    dump(mailList, "gainMail mailList")
    return mailList
end


-- 是邮件
function MailSys:isMail(mailType)
   for key, value in pairs(EMailType) do
        if mailType == value then
            return true
        end

   end
    return false
end

-- 是普通邮件
function MailSys:isSimpleMail(mailType)
    if mailType == EMailType.friend 
        or mailType == EMailType.system then
        return true
    end
    return false
end


-- 是消息邮件
function MailSys:isMessageMail(mailType)
    if mailType == EMailType.message then
        return true
    end
    return false
end

--获取所有的切换按钮
function MailSys:getAllChangeButton(btn,type)
    if self.tab_button == nil then
        self.tab_button = {}
    end
    self.tab_button[type] = btn
end
function MailSys:setButtonState(type,_isShow,pos)
    if self.tab_button[type] ~= nil then
        print("name = ",type)
        UITool.setCommmonBtnRedDop(self.tab_button[type],_isShow,pos)
    end
end

function MailSys:IsPower(pType)
    return pType == 15
end

function MailSys:setRcvPowerAllTimes(times,pType)
    if not self.rcvPowerAllTimes then
        self.rcvPowerAllTimes = {}
    end
    if not self.rcvPowerAllTimes[pType] then
        self.rcvPowerAllTimes[pType] = {}
    end
    self.rcvPowerAllTimes[pType] = times
end

function MailSys:getRcvPowerAllTimes(pType)
    return self.rcvPowerAllTimes[pType] or 0
end

function MailSys:setRcvPowerCurTimes(times,pType)
    if not self.rcvPowerCurTimes then
        self.rcvPowerCurTimes = {}
    end
    if not self.rcvPowerCurTimes[pType] then
        self.rcvPowerCurTimes[pType] = {}
    end
    self.rcvPowerCurTimes[pType] = times
end

function MailSys:getRcvPowerCurTimes(pType)--当前已经用的次数
    return self.rcvPowerCurTimes[pType] or 0
end

function MailSys:getRcvPowerRemainTimes(pType)
    local remainTimes = self:getRcvPowerAllTimes(pType) - self:getRcvPowerCurTimes(pType)
    return remainTimes >= 0 and remainTimes or 0
end

function MailSys:setGivePowerAllTimes(times,pType)
    if not self.givePowerAllTimes then
        self.givePowerAllTimes = {}
    end
    if not self.givePowerAllTimes[pType] then
        self.givePowerAllTimes[pType] = {}
    end
    self.givePowerAllTimes[pType] = times
end

function MailSys:getGivePowerAllTimes(pType)
    return self.givePowerAllTimes[pType] or 0
end
function MailSys:setGivePowerCurTimes(times,pType)
    if not self.givePowerCurTimes then
        self.givePowerCurTimes = {}
    end
    if not self.givePowerCurTimes[pType] then
        self.givePowerCurTimes[pType] = {}
    end
    self.givePowerCurTimes[pType] = times
end

function MailSys:getGivePowerCurTimes(pType)--当前已经用的次数
    return self.givePowerCurTimes[pType] or 0
end

function MailSys:getGivePowerRemainTimes(pType)
    local remainTimes = self:getGivePowerAllTimes(pType) - self:getGivePowerCurTimes(pType)
    return remainTimes >= 0 and remainTimes,0
end


