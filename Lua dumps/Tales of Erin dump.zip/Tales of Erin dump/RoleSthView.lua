--require "XUIView"
--require "SthMatNumView"
--require "SthLevelUpView"
--require "REIconView"
----队伍强化 ---
RoleSthView = class("RoleSthView",XUIView)
RoleSthView.CS_FILE_NAME = "RoleSthView.csb"
RoleSthView.CS_BIND_TABLE = 
{
    panelEffect = "/i:412",
    effIcon = "/i:412/s:effIcon",

    panelSort = "/i:352/s:panelSort",
    panelList = "/i:352/i:354",
    panelMatL = "/i:352/i:90",
    panelMatM = "/i:352/i:76",
    panelLevel = "/i:352/i:130",
    lbTitle = "/i:352/i:193",
    panelIcon = "/i:352/i:53",

    lbCurAtk = "/i:352/i:141/i:144",
    lbAddAtk = "/i:352/i:141/i:148",
    lbCurHP = "/i:352/i:141/i:146",
    lbAddHP = "/i:352/i:141/i:149",
    lbCurDef = "/i:352/i:141/i:145",
    lbAddDef = "/i:352/i:141/i:150",
    lbCurSP = "/i:352/i:141/i:147",
    lbAddSP = "/i:352/i:141/i:151",

    btnStartSth = "/i:352/i:253",
    btnHelp = "/i:352/s:btnHelp"
}

-- ID_H_L  --狗粮ID
-- ID_H_M

function RoleSthView:init()
    RoleSthView.super.init(self)

    self.panelEffect:setVisible(false)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = RoleListItemView.new():init()
        
        temp.ClickEvent = function(item)
            local i = item:getIndex()
            self:setSelectedHero(i)

            if XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.StHero) then 
                XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.StHero)
            end
            
        end
        
        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = self.sortBtnView:getSortMode() % 10
            item:setTitleMode(smode)
        end
        
        return temp
    end
    
    --排序
    self.sortBtnView = SortButtonView.new():init(self.panelSort,"role_q",512,0)
    self.sortBtnView.sortModeChangedEvent = function()
        self:refresh()
    end
    --

    self.matViewL = SthMatNumView.new():init(self.panelMatL)
    self.matViewL:setMatInfo(ID_H_L,0)
    self.matViewL.CurNumChangedEvent = function()
        self:computExp()
        self.matViewM:refresh()
    end
    self.matViewL.iconClickEvent = function()
        local nid = getMatID(ID_H_L)
        if GameManagerInst.gameType == 2 then
            MsgManager:showSimpItemInfoAndDropInfo(5,nid,true,self.onMatChanged,self)
        end
    end

    self.matViewM = SthMatNumView.new():init(self.panelMatM)
    self.matViewM:setMatInfo(ID_H_M,0)
    self.matViewM.CurNumChangedEvent = function()
        self:computExp()
        self.matViewL:refresh()
    end
    self.matViewM.iconClickEvent = function()
        local nid = getMatID(ID_H_M)
        if GameManagerInst.gameType == 2 then
            MsgManager:showSimpItemInfoAndDropInfo(5,nid,true,self.onMatChanged,self)
        end
    end

    self.btnStartSth:addClickEventListener(function()
        self:onRoleSth()
    end)

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)

    self.lvupView = SthLevelUpView.new():init(self.panelLevel)

    self.iconView = REIconView.new():init(self.panelIcon)

    self:setSelectedHero()

    if g_channel_control.transform_RoleSthView_lbTitle_fontSize == true  then
        self.lbTitle:setFontSize(20)
    end

    return self
end

function RoleSthView:onMatChanged()
    if self.matChangedEvent then
        self.matChangedEvent(self)
    end
end

--角色强化
function RoleSthView:showGuidePicLayer( ... )
    local data = {}
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_jsqh_001.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function RoleSthView:computExp()
    if self.currentIndex then
        local midm = getMatID(ID_H_M)
        local midl = getMatID(ID_H_L)
        local expm = mat[midm].mat_data
        local expl = mat[midl].mat_data
        
        local n = self.matViewM:getCurMatNum()
        local n2 = self.matViewL:getCurMatNum()

        self.lvupView:setAddExp(n * expm + n2 * expl)
        local flv,ismax = self.lvupView:getFinalLevel()
        --刷新属性区域
        self:refreshPropNum(flv)

        self.matViewL:setIsMaxLevel(ismax)
        self.matViewM:setIsMaxLevel(ismax)

    end
end

function RoleSthView:playEffect()
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)

    local node_1 = cc.CSLoader:createNode("EffSthFrame.csb")
    local timeline_1 =cc.CSLoader:createTimeline("EffSthFrame.csb")
    local psize = self.effIcon:getSize()
    node_1:setPosition(cc.p(psize.width/2,0))
    node_1:runAction(timeline_1)
    self.effIcon:addChild(node_1,0,123)

    self.lvupView.levelUpEffectEvent = function()
        timeline_1:play("animation0",false) 
    end
    self.lvupView.effectEndEvent = function()
        self:stopEffect()
    end
    self.lvupView:playEffect()    

    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
end

function RoleSthView:stopEffect()
    KeyboardManager._isShowEffect = false
    self.lvupView.levelUpEffectEvent = nil
    self.lvupView.effectEndEvent = nil
    self.lvupView:stopEffect()

    self.effIcon:removeAllChildren()

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)

    if self.effectStopedEvent then
        self.effectStopedEvent(self)
    end

    self:refresh()

    XbTriggerGuideManager:finishGuide(TriggerGuideConfig.StHero, self)

end

function RoleSthView:onRoleSth()

    if  not self.currentIndex then return end

    local matnum1 = self.matViewL:getCurMatNum() or 0
    local matnum2 = self.matViewM:getCurMatNum() or 0

    if matnum1 + matnum2 == 0 then
        GameManagerInst:alert(UITool.ToLocalization("请选择强化素材"))
        return
    end

    local dd = self.currentDataSource[self.currentIndex]
    local hid = dd.id

    local tempTable = {
        ["rpc"] = "hero_lv_up",
        ["target_id"] = hid,
        ["eat_mats"] ={},
    }
    
	if matnum1 > 0 then 
		table.insert(tempTable["eat_mats"],{mat_id = ID_H_L, mat_nums = matnum1})
	end
	
	if matnum2 > 0 then 
		table.insert(tempTable["eat_mats"],{mat_id = ID_H_M, mat_nums = matnum2})
	end

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        DataManager:wHeroData({data = data["data"][hid]},hid)
		--hero_info[self.n_h_id] = t_data["data"]["data"][self.n_h_id]
        --self.sManager:toRSthEndLayer(tempTable)
        --self.eMsg = nil 
		for k,v in pairs(data["mat"]) do
			user_info["bag"]["mat"][k] = v
		end

        if  #data["data"][hid]["team_list"] > 0  then
            self:loadTeamList(function()
                self:playEffect()
            end)
        else
            self:playEffect()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end


function RoleSthView:loadTeamList(callback)

    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success
        DataManager:wTeamData(data["team"])   
             
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleSthView:setSelectedHero(i)
    if  i then 
        self.currentIndex = i
        if self.currentDataSource ~= nil and self.currentDataSource[self.currentIndex] ~= nil then
            local data = self.currentDataSource[self.currentIndex]
            local h_id_num = getNumID( data["id"] )
            --local h_id_str = getStrID( data["id"] )

            ----------------------showhero    
            -- local frame = Rarity_Icon[data["rarity"]]  --外框

            -- local element = ATB_Icon[data["element"]] --属性球

            if g_channel_control.b_LikeState then
                self.iconView:showHero(h_id_num,data["like_feel_state"]["icon_state"])
            else
                self.iconView:showHero(h_id_num)
            end

            --加载经验值
            local expTable = {}
            for i = 1,#hero_upgrade[h_id_num] do
                expTable[i] = hero_upgrade[h_id_num][i][1]
            end
            
            self.lvupView:setLevelInfo(expTable,data["Lv"],data["Lv_max"],data["exp"])

            local flv,ismax = self.lvupView:getFinalLevel()

            self.matViewL:setIsMaxLevel(ismax)
            self.matViewM:setIsMaxLevel(ismax)

            self.matViewL:setCurMatNum(0)
            self.matViewM:setCurMatNum(0)

            self.btnStartSth:setTouchEnabled(not ismax)
            self.btnStartSth:setBright(not ismax)

            self:refreshPropNum(flv)
        end
    else
        self.currentIndex = nil

        self.iconView:showNoIcon()

        self.matViewL:setIsMaxLevel(true)
        self.matViewM:setIsMaxLevel(true)

        self.matViewL:setCurMatNum(0)
        self.matViewM:setCurMatNum(0)

        self.lvupView:setLevelInfo(nil,0,0,0)
        
        self.btnStartSth:setTouchEnabled(false)
        self.btnStartSth:setBright(false)

        self:refreshPropNum()
    end
end

function RoleSthView:refreshPropNum(flv)
    if self.currentIndex then
        local data = self.currentDataSource[self.currentIndex]
        local h_id_num = getNumID( data["id"] )
        local h_id_str = getStrID( data["id"] )

        local curAtk = data["atk"]
        local curDef = data["def"]
        local curHP = data["hp"]
        local curSP = data["tp"]["max_num"]

        local curLv = data["Lv"]

        local addAtk = 0--hero_upgrade[h_id_num][flv][3] - curAtk
        local addDef = 0--hero_upgrade[h_id_num][flv][4] - curDef
        local addHP = 0--hero_upgrade[h_id_num][flv][2] - curHP
        if hero_upgrade[h_id_num] then
            if hero_upgrade[h_id_num][flv] then
                if hero_upgrade[h_id_num][flv][3] then
                    addAtk = hero_upgrade[h_id_num][flv][3] - curAtk
                end

                if hero_upgrade[h_id_num][flv][4] then
                    addDef = hero_upgrade[h_id_num][flv][4] - curDef
                end

                if hero_upgrade[h_id_num][flv][2] then
                    addHP = hero_upgrade[h_id_num][flv][2] - curHP
                end
            end
        end
        

        --计算技能点数
        local addSP = 0
        if flv > curLv then
            for i = curLv + 1,flv do
                addSP = addSP + hero_upgrade[h_id_num][i][8]
            end
        end

        self.lbCurAtk:setString(""..curAtk)
        if addAtk > 0 then
            self.lbCurAtk:setTextColor(cc.c3b(255,255,255))
            self.lbAddAtk:setString("+"..addAtk)
        else
            self.lbCurAtk:setTextColor(cc.c3b(171,171,171))
            self.lbAddAtk:setString("")
        end


        self.lbCurDef:setString(""..curDef)
        if addDef > 0 then
            self.lbCurDef:setTextColor(cc.c3b(255,255,255))
            self.lbAddDef:setString("+"..addDef)
        else
            self.lbCurDef:setTextColor(cc.c3b(171,171,171))
            self.lbAddDef:setString("")
        end

        
        self.lbCurHP:setString(""..curHP)
        if addHP > 0 then
            self.lbCurHP:setTextColor(cc.c3b(255,255,255))
            self.lbAddHP:setString("+"..addHP)
        else
            self.lbCurHP:setTextColor(cc.c3b(171,171,171))
            self.lbAddHP:setString("")
        end

        
        self.lbCurSP:setString(""..curSP)
        if addSP > 0 then
            self.lbCurSP:setTextColor(cc.c3b(255,255,255))
            self.lbAddSP:setString("+"..addSP)
        else
            self.lbCurSP:setTextColor(cc.c3b(171,171,171))
            self.lbAddSP:setString("")
        end

    else
        self.lbCurAtk:setString("")
        self.lbAddAtk:setString("")
        self.lbCurDef:setString("")
        self.lbAddDef:setString("")
        self.lbCurHP:setString("")
        self.lbAddHP:setString("")
        self.lbCurSP:setString("")
        self.lbAddSP:setString("")
    end
end

function RoleSthView:getDataSource()
    local ds = table.deepcopy(hero_list)

    SortBoxView.SortRole (ds, self.sortBtnView:getSortMode(),true)

    return ds
end

function RoleSthView:refresh()
    --先排序，后刷列表  equip_list

    local tempid = nil

    if self.currentIndex and self.currentDataSource and self.currentDataSource[self.currentIndex].id then
        tempid = self.currentDataSource[self.currentIndex].id
    end

    self.currentDataSource = self:getDataSource()
    self.gridview:setDataSource(self.currentDataSource)

    local tempindex = nil

    if tempid then
        for i = 1,#self.currentDataSource do
            if self.currentDataSource[i].id == tempid then
                tempindex = i
                break
            end
        end
    end

    self:setSelectedHero(tempindex)

    local nl = user_info["bag"]["mat"][ID_H_L]
    local nm = user_info["bag"]["mat"][ID_H_M]

    if nl == nil then nl = 0 end
    if nm == nil then nm = 0 end

    self.matViewL:setMatInfo(ID_H_L,nl)
    self.matViewM:setMatInfo(ID_H_M,nm)
    
end
