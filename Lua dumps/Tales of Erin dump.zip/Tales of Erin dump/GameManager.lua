--require "XUINavigationView"
--require "WaitingView"
--require "ConsoleView"

GAME_PROFILE_KEY_LANGUAGE = "language"
GAME_PROFILE_KEY_LANGCHECKED = "langchecked"

-- GAME_PROFILE_TEMPLATE = {
--     language = "",
--     langchecked = false,
--     userprofile = {}    
-- }
-- GAME_PROFILE_USER_TEMPLATE = {
--     userid = "",
--     teamIdx = 0
-- }

GameManager = class("GameManager")

-- GameManager.profileFileName = "profile.json"
-- GameManager.profileData = nil
-- GameManager.profileAutoSave = true


function GameManager:ctor()
    self.view = nil
    self.gameType = 0
    self.waitingView = nil
    self.waitingCount = 0
end

function GameManager:Start()   --暂时没用
    self.gameType = 1
    self.view = XUINavigationView.new():init()
    local mainScene = cc.Scene:create()
    mainScene:addChild(self.view:getRootNode())
    cc.Director:getInstance():replaceScene(mainScene)

    --self.view:pushView(LoginView.new():init())
end

--[[
function GameManager:loadProfileData()
    local data = self:loadFromFile(self.profileFileName)

    if data then
        self.profileData = data
    else
        self.profileData = table.deepcopy(GAME_PROFILE_TEMPLATE)
        self:saveProfileData()
    end
end

function GameManager:saveProfileData()
    if self.profileData then
        self:saveToFile(self.profileFileName,self.profileData)
    end
end

function GameManager:getGlobalStringByKey(key)
    if not self.profileData then return nil end

    return self.profileData[key] or ""
end

function GameManager:setGlobalStringByKey(key,value)
    if not self.profileData then
        self.profileData = {}
    end

    self.profileData[key] = tostring(value)

    if self.profileAutoSave then
        self:saveProfileData()
    end
end

function GameManager:getGlobalNumberByKey(key)
    if not self.profileData then return nil end

    return self.profileData[key] or 0
end

function GameManager:setGlobalNumberByKey(key,value)
    if not self.profileData then
        self.profileData = {}
    end

    self.profileData[key] = tonumber(value)

    if self.profileAutoSave then
        self:saveProfileData()
    end
end

function GameManager:getGlobalBooleanByKey(key)
    if not self.profileData then return nil end

    if self.profileData[key] then
        return true
    else
        return false
    end
end

function GameManager:setGlobalBooleanByKey(key,value)
    if not self.profileData then
        self.profileData = {}
    end

    if value then
        self.profileData[key] = true
    else
        self.profileData[key] = false
    end

    if self.profileAutoSave then
        self:saveProfileData()
    end
end
]]

function GameManager:BackupMode()
    self.gameType = 2
    --self.view = XUINavigationView.new():init()
end

function GameManager:goHome()
    self.view:popToFirstView()
end

-- function GameManager:www()
-- end

function GameManager:confirm(message,callback,cancelCallback)
    --self.gameType == 1 暂不支持
    if self.gameType == 2 then        
        if cancelCallback then
            MsgManager:showSimpMsgWithCallFunc(message,nil,callback,cancelCallback)
        else
            MsgManager:showSimpMsgWithCallFunc(message,nil,callback)
        end
    end    
end
function GameManager:confirm1(table,callback,cancelCallback)
    --self.gameType == 1 暂不支持
    if self.gameType == 2 then        
        if cancelCallback then
            MsgManager:showSimpMsgWithCallFunc(message,nil,callback,cancelCallback)
        else
            MsgManager:showGuildAdd(table,callback)
        end
    end    
end

function GameManager:alert(message,callback)
    if self.gameType == 1 then
    elseif self.gameType == 2 then        
        if callback then
            MsgManager:showSimpMsgWithCallFunc1(message,nil,callback)
        else
            MsgManager:showSimpMsg(message)
        end
    end
end
function GameManager:clear()
    self.bsView = nil
end
function GameManager:showModalView(view)
    if self.gameType == 1 then
        self.view:addSubView(view)
    elseif self.gameType == 2 then  
        SceneManager.rootLayer:addChild(view:getRootNode(),1)
    end
end

function GameManager:showWaiting()
    if self.gameType == 1 then
        self.waitingCount = self.waitingCount + 1

        if self.waitingCount == 1 then
            self.waitingView = WaitingView.new():init()
            self.waitingView:startAnime()
            self.view:addSubView(self.waitingView)    
        end
    elseif self.gameType == 2 then
        SceneManager:createWaitLayer()
    end
end

function GameManager:hideWaiting()
    if self.gameType == 1 then
        if self.waitingCount == 0 then return end
        self.waitingCount = self.waitingCount - 1
        if self.waitingCount == 0 then
            self.waitingView:stopAnime()
            self.view:removeSubView(self.waitingView)
            self.waitingView = nil
        end
    elseif self.gameType == 2 then
        SceneManager:delWaitLayer()
    end
end

-- function GameManager:setTitleUIType(title,uitype)
--     if self.gameType == 2 then
--         if uitype == 1 then
--             SceneManager:toFirClass()
--         elseif uitype == 2 then
--             SceneManager:toSecClass()
--         elseif uitype == 3 then
--             SceneManager:toThirClass()
--         end
--     end
-- end

function GameManager:blackScreenOn()
    if not self.bsView then
        self.bsView = XUIFullScreenView.new():init()
        self:showModalView(self.bsView)
    end
end
function GameManager:blackScreenOff(delayTime)
    if not self.bsView then
        return
    end

    local view = self.bsView
    self.bsView = nil

    if delayTime then
        UITool.delayTask(delayTime,function()  
            view:removeFromParentView()
        end)
    else
        view:removeFromParentView()
    end
end

function GameManager:loadFromFile(filename)

    local path = cc.FileUtils:getInstance():getWritablePath()
    path = path..filename

    if not cc.FileUtils:getInstance():isFileExist(path) then
        return nil
    end
    
    local cjson  = require "cjson"
    local str = cc.FileUtils:getInstance():getStringFromFile(path)
    return cjson.decode(str)
end

function GameManager:saveToFile(filename,obj)
    local cjson = require "cjson"
    local path = cc.FileUtils:getInstance():getWritablePath()

    local content = cjson.encode(obj)

    local file = io.open(path..filename,"w+")
    file:write(content)
    file:close()
end

function GameManager:rpc(rpcData,rpcType,successFunc,failedFunc,showCover)
    local isShowCover = false
    if showCover then isShowCover = true end

    local function reqfunc(rcv)
        if isShowCover then
            self:hideWaiting()
        end

        local pdata = tolua.cast(rcv, "PassData")
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(pdata:getData())
        if t_data == nil then 
            if failedFunc then
                failedFunc(nil,UITool.ToLocalization("获取数据异常，请联系客服"),pdata:getData())
            end
            return
        end 

        local state_code = t_data["data"]["state_code"]
        if  state_code ~=1 then
            --failed
            local warning = t_data["data"]["warning"]
            if not warning then
                warning = ""..t_data["data"]["Status"]
            end
            if failedFunc then
                failedFunc(state_code,UITool.getUserLanguage(warning),pdata:getData())
            end
        else
            --success
            local rdata = t_data["data"]
            if successFunc then
                successFunc(rdata)
            end
        end
    end

    local sendData = nil
    local dataType = type(rpcData)

    if dataType == "table" then
        local cjson = require "cjson"
        sendData = cjson.encode(rpcData)
    elseif dataType == "string" then
        sendData = rpcData
    else
        error("GameManager:rpc() - invalid data type", 0)
        return
    end

    if isShowCover then
        self:showWaiting()
    end

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reqfunc, cc.Handler.CALLFUNC); 
    dbhttp:creatHttpRequestWithURL(sendData,rpcType)

end