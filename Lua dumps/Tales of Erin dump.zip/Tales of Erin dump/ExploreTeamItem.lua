--ExploreTeamItem.lua

ExploreTeamItem = class("ExploreTeamItem", XUICellView)
ExploreTeamItem.CS_FILE_NAME = "REListItemView.csb"
ExploreTeamItem.CS_BIND_TABLE = 
{
    touchPanel = "/i:221",
    imgBG = "/i:29/i:30/i:39",
    imgFace = "/i:29/i:30/i:40",
    imgRarity = "/i:29/i:30/i:38",
    imgElement = "/i:29/i:30/i:41",
    inTeamFlag = "/i:29/i:36",
    inTeamText = "/i:29/i:36/i:45",
    atkdefPanel = "/i:29/i:44",
    rankPanel = "/i:29/i:41",
    zhanliPanel = "/i:29/i:42",
    rankImg1 = "/i:29/i:41/i:44",
    rankImg2 = "/i:29/i:41/i:45",
    rankImg3 = "/i:29/i:41/i:46",
    rankImg4 = "/i:29/i:41/i:47",
    lbATK = "/i:29/i:44/i:42",
    lbHP = "/i:29/i:44/i:43",
    lbZhanli = "/i:29/i:42/i:50",
    imgOutTeam = "/i:29/i:295",
    panSelArrow = "/i:29/i:298",
    redPoint = "/i:29/i:103",
}

function ExploreTeamItem:init(...)
    ExploreTeamItem.super.init(self,...)
    self.imgOutTeam:setVisible(false)    --n_UIShare\equip\list\ggsc_ui_222.png
    self.panSelArrow:setVisible(false)
    self.redPoint:setVisible(false)
    
    self.isSelect = false
    self.isBastRace = false
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)

    return self
end
--重置UI
function ExploreTeamItem:onResetData()
    if not self._data then return end
    
    self.isSelect = false
    self.isBastRace = false
    --重置状态，默认是不选中
    self:setSelectState(1)
    self:setShowBastRace(false)

    local h_id_num = getNumID( self._data["id"] )
    local h_id_str = getStrID( self._data["id"] )
    
    local frame = Rarity_Icon[self._data["rarity"]]  --外框
    --Rarity_BG  --背景
    if frame then
        self.imgRarity:setTexture(frame)
    end
    
    local rbg = Rarity_E_BG[self._data["rarity"]]   --背景
    if rbg then
        self.imgBG:setTexture(rbg)
    end

    --todo 属性球换为种族图标 目前加上去效果不好，暂时备注8.26
    local race_idx = hero[h_id_num].hero_race
    local raceIcon = HERO_RACE_ICON[race_idx]
    if raceIcon then
        self.imgElement:setTexture(raceIcon)
        self.imgElement:setScale(1.0)
    end
    -- --todo 属性球换为种族图标
    -- local element = ATB_Icon[self._data["element"]] --属性球
    -- if element then
    --     self.imgElement:setTexture(element)
    -- end

    local face = hero[h_id_num].hero_list_icon    
    if face then
        self.imgFace:setTexture(face)
    end
    -- 0、未派遣 1、已派遣
    self.inTeamFlag:setVisible(false)
    self.isDispatch = false
    if self._data["is_dispatch"] == 0 then 
        self.imgOutTeam:setVisible(false)
    else
        self.imgOutTeam:setVisible(true)
        self.imgOutTeam:setTexture("res/uifile/n_UIShare/explore/ts_ui_015.png")
        self.isDispatch = true
    end
    self.lbZhanli:setString(""..self._data["fp_all"])

    self.atkdefPanel:setVisible(false)
    self.zhanliPanel:setVisible(true)
    self.rankPanel:setVisible(false)
    --刷新数据回调
    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end
--设置状态 0 为选中  1不选中状态
function ExploreTeamItem:setSelectState(_state)
    --最好的
    if _state == 0 then
        --print("选中状态")
        self.isSelect = true
        self.panSelArrow:setVisible(true)  
        self:setShowBastRace(false)  
    else 
        --print("取消选中")
        self.isSelect = false
        self.panSelArrow:setVisible(false)
        self:setShowBastRace(true)
    end
end
--特效
function ExploreTeamItem:setShowBastRace(isShow)

    if self.isDispatch == true then 
        if self.effectNode ~= nil then 
            self.effectNode:stopAllActions()
            self.effectNode:removeFromParent()
            self.effectNode = nil 
        end 
        do return end 
    end 
    if  self.isBastRace == false then 
        if self.effectNode ~= nil then 
            self.effectNode:stopAllActions()
            self.effectNode:removeFromParent()
            self.effectNode = nil 
        end 
        do return end 
    end
    --如果是选中状态，则不显示
    if self.isSelect then
        isShow = false
    end 
    if isShow then
        local node =cc.CSLoader:createNode("Ani_Frame_Light.csb")
        local size = self.imgRarity:getContentSize()
        node:setPosition(cc.p(size.width/2,-8))
        self.imgRarity:addChild(node)
        self.action = cc.CSLoader:createTimeline("Ani_Frame_Light.csb")
        node:stopAllActions()
        node:runAction(self.action)
        self.action:play("play", true) 
        self.effectNode = node
    else
        if self.effectNode ~= nil then 
            self.effectNode:stopAllActions()
            self.effectNode:removeFromParent()
            self.effectNode = nil 
        end 
    end 
end