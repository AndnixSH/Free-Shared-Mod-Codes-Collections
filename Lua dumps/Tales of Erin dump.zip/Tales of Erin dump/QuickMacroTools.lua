-- 按键精灵检测管理
-- require "QuickMacroData"
-- require "QuickMacroLayer"
QuickMacroTools = class("QuickMacroTools")
QuickMacroTools.__index = QuickMacroTools
QuickMacroTools.instance = nil
QuickMacroTools.open = false --默认关闭

QuickMacroTools.DATA_COMPARISON_NUM_MAX = 9 -- 比对上限 

QuickMacroTools.DATA_COMPARISON_NUM = 3 -- 比对 N组 数据是否相同
QuickMacroTools.DATA_COMPARISON_COEFFICIENT = 1 -- 比对系数，

QuickMacroTools.STATE = { --状态
	QM_prepare		= 0,	--准备
	QM_Start 		= 1,	--开始	
	QM_running		= 2,	--检测中
	QM_finish		= 3 	--结束
}

QuickMacroTools.DATA_TYPE = { --类型
	QM_data_null 			= 0, --无
	QM_data_mulPassLayer 	= 1, --大型战斗
	QM_data_guildPassLayer 	= 2, --工会战
}


function QuickMacroTools:getInstance(  )
	if self.instance == nil then
		self.instance = self.new()
		self.instance:init()
	end
	return self.instance
end

function QuickMacroTools:init( ... )

	if g_channel_control.quickMacroabled == true then 
		self.open = true 
	end 

	self.state = QuickMacroTools.STATE.QM_prepare
	self.data_type = QuickMacroTools.DATA_TYPE.QM_data_null
	self.data_comparision_num = 0 	-- 当前比对相同的数据量
	self.qm_data = nil  			--当前操作数据
	self.qm_dataVecs = {} 			--所有数据集合

	self.triggered = false 			--是否有加入战斗

	self.sendOk 	= false 		--是否已发送服务器
	self.sendMessage = "" 			--最终发送到服务器的字段
	self.sendMessageTable = {}	


end

function QuickMacroTools:getQMLayer( ... )
	if self.qm_layer == nil then 
		self.qm_layer = QuickMacroLayer:create()
	end

	return self.qm_layer.uiLayer
end

function QuickMacroTools:prepare( ... )
	if self.open == false then 
		return 
	end 
	self.state = QuickMacroTools.STATE.QM_prepare
	self.data_type = QuickMacroTools.DATA_TYPE.QM_data_null
	self.qm_data = nil 
	self.triggered = false 			--是否有加入战斗
end

function QuickMacroTools:start( qm_type )
	if self.open == false then 
		return 
	end
	print("------QuickMacroTools:start-----type::"..tonumber(qm_type))

	self.state = QuickMacroTools.STATE.QM_Start
	self.data_type = qm_type
	self.qm_data = QuickMacroData:create()
	-- dump(self.qm_data,"self.qm_data")
	-- self:addNewQMdataByType(qm_type) --放到结束时添加
	

end

function QuickMacroTools:finish( ... ) --检测,去除触摸层，准备比对数据
	if self.open == false then 
		return 
	end
	print("------QuickMacroTools:finish-----")

	self.state = QuickMacroTools.STATE.QM_finish
	-- if self.qm_layer then 
	-- 	self.qm_layer:clear()
	-- 	self.qm_layer = nil 
	-- end 
	self:addNewQMdataByType(self.data_type)

	self:compareQMdataByType(self.data_type)

end

function QuickMacroTools:addNewQMdataByType( data_type )
	if self.open == false then 
		return 
	end
	if data_type == QuickMacroTools.DATA_TYPE.QM_data_null then 
		print("error ---------self.data_type == 0")
		return 
	end 
	if self.qm_dataVecs[data_type] == nil then 
		self.qm_dataVecs[data_type] = {}
	end
	-- dump(self.qm_data,"self.qm_data22222")

	local len = #self.qm_dataVecs[data_type]
	self.qm_dataVecs[data_type][len+1] = self.qm_data

	-- print("self.qm_data:"..tostring(self.qm_data))
	-- dump(self.qm_data,"self.qm_data233333")

	-- dump(self.qm_dataVecs[data_type],"self.qm_dataVecs")

	-- local len2 = #self.qm_dataVecs[data_type]

	-- print("-------QuickMacroTools:addNewQMdataByType------len："..len.."....len2:"..len2)
end

function QuickMacroTools:compareQMdataByType( data_type)
	-- body
	if self.open == false then 
		return 
	end
	local len = #self.qm_dataVecs[data_type]
	if len > 1 then 
		-- print("QuickMacroTools:compareQMdataByType")
		--比对数据
		-- 如果已经比对成功n组*系数 则保存上报服务器
		-- 如果比对失败，则保留当前数据，其余清空
		local qm_1 = self.qm_dataVecs[data_type][len-1]
		local qm_2 = self.qm_dataVecs[data_type][len]
		if qm_1:compare(qm_2) == true then 
			self.data_comparision_num = self.data_comparision_num +1 
			local comparison_num = QuickMacroTools.DATA_COMPARISON_NUM * QuickMacroTools.DATA_COMPARISON_COEFFICIENT

			if self.data_comparision_num >= comparison_num then 
				QuickMacroTools.DATA_COMPARISON_COEFFICIENT = QuickMacroTools.DATA_COMPARISON_COEFFICIENT + 1
				self:sendQMMessageToServer(data_type)	

				if self.data_comparision_num >= QuickMacroTools.DATA_COMPARISON_NUM_MAX then  --达到最大比对长度时直接清空
					self:clearQMVector(data_type)
				end 
			end 
		else 
			if len > QuickMacroTools.DATA_COMPARISON_NUM then --上传len-1组数据到服务器
			 	self.qm_dataVecs[data_type][len] = nil 
				self:sendQMMessageToServer(data_type)	
			end 

			self:resaveQMVector(data_type)
		end 

	end 
end

function QuickMacroTools:resaveQMVector( data_type ) --检测失败，保留当前数据，其余清空
	-- body
	-- print("QuickMacroTools:resaveQMVector")

	QuickMacroTools.DATA_COMPARISON_COEFFICIENT = 1
	self.data_comparision_num = 0
	self.qm_dataVecs[data_type] = {}
	self.qm_dataVecs[data_type][1] = self.qm_data
end

function QuickMacroTools:clearQMVector( data_type ) --清空所有数据
	-- body
	-- print("QuickMacroTools:clearQMVector")

	QuickMacroTools.DATA_COMPARISON_COEFFICIENT = 1
	self.data_comparision_num = 0
	self.qm_dataVecs[data_type] = {}

end

function QuickMacroTools:backhome(  ) --点击home/back返回主界面,直接清空数据
	if self.open == false then 
		return 
	end
	print("------QuickMacroTools:backhome-----")
	if (self.state == QuickMacroTools.STATE.QM_Start or self.state == QuickMacroTools.STATE.QM_running) and self.triggered == true then 
		self:finish()
	end 

	self:prepare()
	
end

function QuickMacroTools:setTriggered( vBool ) --是否有触发战斗
	-- body
	if self.open == false then 
		return 
	end 
	if self.state ~= QuickMacroTools.STATE.QM_Start and self.state ~= QuickMacroTools.STATE.QM_running then 
		--未开启检测不做处理
		return 
	end 
	self.triggered = vBool > 0 and true or false
end

function QuickMacroTools:sendQMMessageToServer( data_type ) --检测成功，发送数据到服务器
	-- body
	print("-------------QuickMacroTools:sendQMMessageToServer----------")
	local len = self.qm_dataVecs[data_type]
	local data_1 = self.qm_dataVecs[data_type][1]
	-- print("len:"..len)
	-- dump(data_1,"self.qm_dataVecs[data_type][1]")


	self.sendOk = true 
 	local tempTable = {
		data_type 	= data_type,
		data_len 	= len 
	}
	local len = #self.sendMessageTable
	self.sendMessageTable[len+1] = tempTable

	dump(self.sendMessageTable,"self.sendMessageTable")

	LogManager.showSimpMsgDebug("QMMessage:data_len:"..len..",data_type:"..data_type)

end

function QuickMacroTools:getSendmessage(  )
	-- body
	if self.open == false then 
		return ""
	end 
	if self.sendOk == true then 
		return ""
	end 
	self.sendOk = true 

	local cjson = require "cjson"
	local msg = cjson.encode(self.sendMessageTable)
	self.sendMessageTable = {}	
	
	print("self.sendMessage   :"..msg)

	return msg

end

function QuickMacroTools:addTouchPoint( point )
	if self.state ~= QuickMacroTools.STATE.QM_Start and self.state ~= QuickMacroTools.STATE.QM_running then 
		print("invalid point:-----------self.state == "..tonumber(self.state))
		return 
	end 

	self.state = QuickMacroTools.STATE.QM_running
	if self.qm_data ~= nil then 
		-- print("----------QuickMacroTools:addTouchPoint------:"..point.x..","..point.y)
		self.qm_data:saveTouchPoint(point)
	end 
end


-- qm_dataVecs = {

-- 	QM_data_mulPassLayerVec = {
-- 		qm_data = {
-- 			saveTouchPoint(point)
-- 		}



-- 	}

-- 	addPoint(point) = {

-- 	}

-- }