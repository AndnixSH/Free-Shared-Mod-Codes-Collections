achi_act_109_conf={} 
achi_act_109_conf[1] = {
        id= 1,
        achi_name= "通关！",
        achi_desc= "完成活动所有关卡",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[2] = {
        id= 2,
        achi_name= "恶魔猎手（简单）",
        achi_desc= "通关简单难度活动多人副本5次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[3] = {
        id= 3,
        achi_name= "恶魔猎手（困难）",
        achi_desc= "通关困难难度活动多人副本10次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[4] = {
        id= 4,
        achi_name= "群魔梦魇",
        achi_desc= "通关超难难度活动多人副本30次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[5] = {
        id= 5,
        achi_name= "诛魔煞星",
        achi_desc= "通关超难难度活动多人副本100次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[6] = {
        id= 6,
        achi_name= "神圣歼灭",
        achi_desc= "通关超难难度活动多人副本150次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[7] = {
        id= 7,
        achi_name= "荡涤裁决",
        achi_desc= "通关超难难度活动多人副本350次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[8] = {
        id= 8,
        achi_name= "终结黑暗",
        achi_desc= "通关超难难度活动多人副本600次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[9] = {
        id= 9,
        achi_name= "闪耀黎明",
        achi_desc= "通关超难难度活动多人副本800次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[10] = {
        id= 10,
        achi_name= "单枪匹马（简单）",
        achi_desc= "单独通关简单难度活动多人副本",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[11] = {
        id= 11,
        achi_name= "单枪匹马（困难）",
        achi_desc= "单独通关困难难度活动多人副本",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[12] = {
        id= 12,
        achi_name= "单枪匹马（超难）",
        achi_desc= "单独通关超难难度活动多人副本",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[13] = {
        id= 13,
        achi_name= "夜晚的守护者1",
        achi_desc= "击杀恶魔30只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[14] = {
        id= 14,
        achi_name= "夜晚的守护者2",
        achi_desc= "击杀恶魔50只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_109_conf[15] = {
        id= 15,
        achi_name= "夜晚的守护者3",
        achi_desc= "击杀恶魔100只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 