require "BasicLayer"
---------大型活素材详细
BillboardLayer = class("BillboardLayer",BasicLayer)
BillboardLayer.__index = BillboardLayer
function BillboardLayer:init()
    print("进入了msgModel 界面")
    local node =cc.CSLoader:createNode("BillboardLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self:initAll();
end
function BillboardLayer:initAll( ... )
	-- body
	local node = self.uiLayer:getChildByTag(2);
	local p_bg   = node:getChildByName("Panel_1")
	local i_bg   = p_bg:getChildByName("Image_Bg")
	local dec    = i_bg:getChildByName("Text_dec")
	dec:setString(self.strDs);
	local btn    = i_bg:getChildByName("Button_1")
	local function CallBak( sender,eventType )
        -- body
       if eventType == ccui.TouchEventType.ended then
       		self:close()
       end
    end 
    btn:addTouchEventListener(CallBak)
end
function BillboardLayer:close( ... )
	-- body
	self.sManager:hideBillboard();
end

function BillboardLayer:create(tdata,sManager)

     local billModel = BillboardLayer.new()
	 billModel.strDs = tdata 
	 billModel.sManager  = sManager
     billModel.uiLayer = cc.Layer:create()
     billModel:init()
     return billModel
end