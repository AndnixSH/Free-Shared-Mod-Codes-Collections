GuildSingleton = {}

GuildSingleton.pType = 
{
	normal = 0,--正常状态
	manage = 1,--管理状态
}

function GuildSingleton:getInstance()
    if self.instance == nil  then
        self.instance = self:new()
        self.instance:init()
    end
    return self.instance
end

function GuildSingleton:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end

function GuildSingleton:init()
	self.member_state = GuildSingleton.pType.normal
end

function GuildSingleton:setMemberState(pType)
  self.member_state = pType
end
function GuildSingleton:GetMemberState()
  return self.member_state
end

function GuildSingleton:setMedal_num(num)
    print("array_cointype[4] = ",num)
    array_cointype[4] = num
    self:setBeryl()--刷新公会币的时候同时刷新苍玉，PS：暂时在此调用，如果有用的着苍玉的地方在确定在那里调用
end

function GuildSingleton:setBeryl()
    array_cointype[7] = user_info["beryl"] or 0
end

function GuildSingleton:setGuildLeaderState(state)
    self.leader_state = state or 0
end
function GuildSingleton:getGuildLeaderState()
    return self.leader_state or 0
end