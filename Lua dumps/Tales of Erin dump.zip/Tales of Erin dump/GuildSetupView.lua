
--require "XUIView"

GuildSetupView = class("GuildSetupView" , XUIView)
GuildSetupView.CS_FILE_NAME = "GuildSetupView.csb"
GuildSetupView.CS_BIND_TABLE = 
{
    btnClose = "/s:panelClose/i:92",
    lbName = "/i:96/i:102/i:120",
    lbDesc = "/i:96/i:102/i:121",
    pDesc = "/i:96/i:102/i:122",
    btnName = "/i:96/i:102/i:104",
    btnDesc = "/i:96/i:102/i:106",
    btnAutoPass = "/i:96/i:102/i:108",
    btnNeedCheck = "/i:96/i:102/i:109",
    btnGQUIT = "/i:96/i:102/i:110",
    topBarViewPanel = "i:580",
    Panel_list = "/i:96/i:219",
    btn_change = "/i:96/i:102/i:113",
    label_member = "i:96/i:102/i:807",
}

function GuildSetupView:initWithData(data)
    if g_channel_control.show_new_guild_main == true then
        GuildSetupView.CS_FILE_NAME = "GuildSetupView_new.csb" 
    end
    GuildSetupView.super.init(self)
    self.exist = true;
    self.guild_data = data

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    self.btnGQUIT:addClickEventListener(function()
        self:gquit()
    end)

    self.pDesc:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            --设置公告
            self:beginDesc()
        end
    end)

    self.btnName:addClickEventListener(function()
        self:beginName()
    end)

    self.btnDesc:addClickEventListener(function()
        self:changeDesc()
    end)

    self.btnAutoPass:addClickEventListener(function()
        self:changeEnter(0)
    end)

    self.btnNeedCheck:addClickEventListener(function()
        self:changeEnter(1)
    end)

    if g_channel_control.show_new_guild_main == true then
        self:InitTopBarView()
        self:initListView()
        self:initBtnChange()
        -- self.guild_data["history"] = {
        --     {["heroId"] = 11,["timeStr"] = 11554436512,["index"] = 1,["des"] = {"aaa","bbbb"},},
        --     {["heroId"] = 13,["timeStr"] = 11554433512,["index"] = 2,["des"] = {"ssa","ccc"},},
        --     {["heroId"] = 23,["timeStr"] = 11554566512,["index"] = 15,["des"] = {"rwd","ghd"},},
        -- }
        self.TabList = {}
        for i,v in ipairs(self.guild_data["history"]) do
            local temp = {}
            temp.heroId = v["heroId"]
            temp.timeStr = os.date(UITool.ToLocalization("%Y年%m月%d日 %H:%M:%S"),v["timeStr"])

            local len = #v["des"]
            local _str = UITool.getUserLanguage(guild_diary[v["index"]])
            if len == 3 then
                _str = string.format(UITool.ToLocalization(_str),v["des"][1],v["des"][2],v["des"][3])
            elseif len == 2 then
                _str = string.format(UITool.ToLocalization(_str),v["des"][1],v["des"][2])
            elseif len == 1 then
                _str = string.format(UITool.ToLocalization(_str),v["des"][1])
            else
                _str = UITool.ToLocalization(_str)
            end
            temp.des = _str

            table.insert(self.TabList,temp)
        end
        dump(self.TabList,"self.TabList = ")
        
        self.label_member:setString(self.guild_data["mem_num"])
        self:refreshList()
    end

    self:refresh()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return  self
end

--    # 如果有公会, 会出现下面属性 <--可能出现的属性-->  
--     "guild_id": "1437719007",     # 公会ID
--     "name": u"蜀山",        # 公会名
--   #  "Lv": 1,                # 公会等级 1-M(从低到高)
--     "ranking":"100",#公会排行,注：字符串，以防后续出现文本描述
--     "score": 0,             # 公会积分
--     "notice": u"这是公会的公告文本",
--     "mem_num": "18/20",     # 公会成员数量
--     "chairman": u"清虚",    # 会长名字
--     "image": "xxxxxx.jpg",  # 公会形象-----暂为公会会长头像
--     "join_condition": 1,    # 加入条件: 0-自动通过, 1-需要审批
--     "position": 6,          # 自己处职位,1-6(6最高,会长) 
--     # 公会buff
--     "buff": {
--          {
--             "skill_id":1,#生效的buffID
--             "need_gold": 500,
--             "end_time": 1437384422,  

function GuildSetupView:refresh()
    if self.guild_data then
        self.lbName:setString(self.guild_data.name)
        self.lbDesc:setString(self.guild_data.notice)
        
        local canEditJoin = self.guild_data.position > 1


        if self.guild_data.join_condition == 0 then
            --自动通过
            self.btnAutoPass:setTouchEnabled(false)
            self.btnAutoPass:setBright(false)
            self.btnNeedCheck:setTouchEnabled(canEditJoin)
            self.btnNeedCheck:setBright(true)
        else
            --需要审批
            self.btnAutoPass:setTouchEnabled(canEditJoin)
            self.btnAutoPass:setBright(true)
            self.btnNeedCheck:setTouchEnabled(false)
            self.btnNeedCheck:setBright(false)
        end
    else
        self.lbName:setString("")
        self.lbDesc:setString("")
        self.btnAutoPass:setTouchEnabled(true)
        self.btnAutoPass:setBright(true)
        self.btnNeedCheck:setTouchEnabled(true)
        self.btnNeedCheck:setBright(true)
    end

    self.btnName:setVisible(false)
    self.btnDesc:setVisible(false)
end

function GuildSetupView:beginName()
    if not self.guild_data then return end
    if self.guild_data.position < 2 then return end

    if GameManagerInst.gameType == 2 then
        local rcvData = {}
        rcvData["sDelegate"] = self
        rcvData["confirmFunc"] =  function(self,text)
            self:changeName(text)
        end
        rcvData["defalutStr"] = self.guild_data.name
        rcvData["maxLength"] = 40
        rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord

        SceneManager:toInputModelLayer(rcvData)
    end
end

function GuildSetupView:beginDesc()
    if not self.guild_data then return end
    if self.guild_data.position < 2 then return end

    if GameManagerInst.gameType == 2 then
        local rcvData = {}
        rcvData["sDelegate"] = self
        rcvData["confirmFunc"] =  function(self,text)
            self.guild_data.notice = text
            self.lbDesc:setString(text)
            self.btnDesc:setVisible(true)
        end
        rcvData["defalutStr"] = self.guild_data.notice
        rcvData["maxLength"] = 40
        rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
        SceneManager:toInputModelLayer(rcvData)
    end

end

function GuildSetupView:gquit()
    GameManagerInst:confirm(UITool.ToLocalization("确认退出公会？\n（退出后24小时内不能再次加入或创建公会）"),function()
        GameManagerInst:rpc("{\"rpc\":\"guild_quit\"}",
            3,
            function(data)
                --success
                if self.exist == false then
                    return
                end
                if self.guildQuitEvent then
                    self.guildQuitEvent(self)
                end
                self:returnBack()
            end,
            function(state_code,msgText)
                --failed
                if self.exist == false then
                    return
                end
                GameManagerInst:alert(msgText)
            end,
            true)
    end)
end

function GuildSetupView:changeName(name)
    if not self.guild_data then return end
end

function GuildSetupView:changeDesc()
    if not self.guild_data then return end

    local tempTable = {
        rpc = "guild_notice",
        new_notice = self.guild_data.notice
    }

    GameManagerInst:rpc( tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            GameManagerInst:alert(UITool.ToLocalization("修改公告成功"))
            
            self.lbDesc:setString(self.guild_data.notice)
            self.btnDesc:setVisible(false)
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end

function GuildSetupView:changeEnter(n)
    if not self.guild_data then return end

    local tempTable = {
        rpc = "guild_join_condition",
        condition = n
    }

    GameManagerInst:rpc( tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            self.guild_data.join_condition = n
            self:refresh()
            GameManagerInst:alert(UITool.ToLocalization("修改加入方式成功"))
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end

function GuildSetupView:loadData()
    -- GameManagerInst:rpc("{\"rpc\":\"guild_mine\"}",
    --     3,
    --     function(data)
    --         --success
    --     end,
    --     function(state_code,msgText)
    --         --failed
    --         GameManagerInst:alert(msgText)
    --     end,
    --     true)
end

function GuildSetupView:onNavigateTo(isback)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    else
        self:loadData()
    end
end

function GuildSetupView:returnBack()
    self.exist = false;
    if self._navigationView then
        self._navigationView:popView()
    else
        self:removeFromParentView()
    end
end

function GuildSetupView:InitTopBarView()
    self.topBarViews = XUIView.new():init(self.topBarViewPanel)
    local iteamDatas = {}
    local rcvData = {}
    rcvData["sIteamDatas"] = iteamDatas
    rcvData["bIsStartLayer"] = false
    rcvData["nInfoState"] = table.getValue("coinbar",coinbar,62,"coinbar_type")
    rcvData["nTitleNum"] = 7

    self.topBarView = TopBarView.new():init(rcvData)
    self.topBarViews:addSubView(self.topBarView)
    self:InitSociatySetTopBarView()
end

function GuildSetupView:InitSociatySetTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,62,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

-- 当货币栏中有不是金币，体力和星石时，需要单独刷洗数据 (根据不同的类型数据存入array_cointype中),具体类型参考cointype表 
function GuildSetupView:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
            if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end

function GuildSetupView:initBtnChange()
    self.pDesc:setTouchEnabled(false)
    if self.btn_change then
        local function onBtnEvent(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                if sender:getTag() == 113 then
                    self:toInputLayer()
                end 
            end
        end 
        self.btn_change:addTouchEventListener(onBtnEvent)
    end
end

--弹出输入框
function GuildSetupView:toInputLayer()
    if not self.guild_data then return end
    if self.guild_data.position < 2 then return end
    if GameManagerInst.gameType == 2 then
        local rcvData = {}
        rcvData["sDelegate"] = self
        rcvData["confirmFunc"] =  function(self,text)
            self.guild_data.notice = text
            self.lbDesc:setString(text)
            self:changeDesc()
        end
        rcvData["defalutStr"] = self.guild_data.notice
        rcvData["maxLength"] = 40
        rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
        SceneManager:toInputModelLayer(rcvData)
    end
end

function GuildSetupView:initListView()
    local pSize = self.Panel_list:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.Panel_list,pSize.width,pSize.height,425,80)
    self.gridview.itemCreateEvent = function()
        local temp = GuildHistoryItem.new():init()
        return temp
    end
end

function GuildSetupView:refreshList()
    if self.TabList == nil then
        return
    end
    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(self.TabList)
    --self.gridview:jumpToPercent(percent)
    --滚动到最底端
    self.gridview:getScrollView():jumpToBottom()
end
