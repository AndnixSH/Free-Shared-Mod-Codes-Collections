
ChatNewMainLayer = class("ChatNewMainLayer",XUIView)
ChatNewMainLayer.CS_FILE_NAME = "ChatMainUILayer.csb"
ChatNewMainLayer.CS_BIND_TABLE = 
{
	mask_bg 					= "/i:1",
    channelNode 				= "/i:2",

    pannelNode 					= "i:8",

    chat_mask_top 				= "/i:11",
    chat_mask_bottom 			= "/i:12",

    mask_top 					= "/s:mask_top",
}
ChatNewMainLayer.PANNEL_NUM = 5 --页签数量 
ChatNewMainLayer.LogTag = "ChatNewMainLayer"

function ChatNewMainLayer:create(rData)
    local login = ChatNewMainLayer.new( )
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end

function ChatNewMainLayer:clear( )
	self:registEventDispatcher(false)

	if self.pannelSystem then
		self.pannelSystem:clear() 			--= nil 
		self.pannelSystem = nil 
	end
	if self.pannelChatroom then
		self.pannelChatroom:clear() 		--= nil 
		self.pannelChatroom = nil 
	end
	if self.pannelGuild then
		self.pannelGuild:clear() 			--= nil 
		self.pannelGuild = nil 
	end
	if self.pannelFriend then
		self.pannelFriend:clear() 			--= nil 
		self.pannelFriend = nil 
	end
	if self.pannelBattle then
		self.pannelBattle:clear() 			--= nil 
		self.pannelBattle = nil 
	end

	XBChatData:getInstance():setCurrentSession("", 0)
	if tolua.isnull(self.uiLayer) == false then
		self.uiLayer:removeFromParent()
		self.uiLayer = nil 
	end
	if self.sManager ~= nil then
		self.sManager.isShowChating = false--不显示聊天室
	end
end

function ChatNewMainLayer:returnBack(  )
    --主界面先清一次红点！！
    lemon.EventManager:dispatchCustomEvent(EEventType.CHAT_MAIN_SHOW_REDDOT,{ 
        code = 0 ,
        show = 0 ,
      })

    --判断当前为首页，非首页不掉用该函数
    if  self.sManager.menuLayer:getTitle() == SceneManager.titleTable[17] then 
        self.sManager.sceneNum = 1
        XbTriggerGuideManager:startTriggerGuideFromThird()
    end
    
	self:clear()
end

function ChatNewMainLayer:init(  )
	self.super:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)
	print("ChatNewMainLayer:init=================")
	self:initData()

	if self.rData["enterIndex"] ~= nil then
		self.default_index = tonumber(self.rData["enterIndex"])
	end
	if self.default_index > 5 or self.default_index < 0 then
		self.default_index = 2
	end
	if self.default_index == 3 then 
		self.showBattleChannel = true
	end

	self:bindAllBtn()

	self:callLoginNim()

end

function ChatNewMainLayer:initData(  )
	self.reqChatData 			= false 

	self.loginNimOK 			= false
	self.default_index 			= 2 --默认切换世界聊天频道  1 系统，2 世界，3 战斗，4 私聊，5 公会
	self.showBattleChannel 		= false
	self.showGuideChannel 		= false


	self.pannelSystem 			= nil 
	self.pannelChatroom 		= nil 
	self.pannelGuild 			= nil 
	self.pannelFriend 			= nil 
	self.pannelBattle 			= nil 

end

function ChatNewMainLayer:initChannelView(  )

	self.pannelSystem = ChatNewPannelSystem:create()
	self.pannelNode:addChild(self.pannelSystem:getRootNode())
	self.pannelSystem:hideView()

	self.pannelChatroom = ChatNewPannelChatroom:create()
	self.pannelNode:addChild(self.pannelChatroom:getRootNode())
	self.pannelChatroom:hideView()

	self.pannelBattle = ChatNewPannelBattle:create()
	self.pannelNode:addChild(self.pannelBattle:getRootNode())
	self.pannelBattle:hideView()


	self.pannelFriend = ChatNewPannelFriend:create()
	self.pannelNode:addChild(self.pannelFriend:getRootNode())
	self.pannelFriend:hideView()

	self.pannelGuild = ChatNewPannelGuild:create()
	self.pannelNode:addChild(self.pannelGuild:getRootNode())
	self.pannelGuild:hideView()

end

function ChatNewMainLayer:bindAllBtn(  )
	local function touchChannelEvent(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			self:channelItemCallBack(sender,eventType)
		end
	end
    for i=1,ChatNewMainLayer.PANNEL_NUM do
    	local  tabBTN = self.channelNode:getChildByTag(i)
   		tabBTN:addTouchEventListener(touchChannelEvent)
    end


    local function touchMaskCallback( sender,eventType )
    	if eventType == ccui.TouchEventType.ended then
    		print("touch---mask--:"..sender:getTag())

    		if sender:getName() == "mask_top" then
    			XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1031002))
    		else
    			self:returnBack()
    		end

		end
    end
    self.mask_bg:addTouchEventListener(touchMaskCallback)
    self.chat_mask_top:addTouchEventListener(touchMaskCallback)
    self.chat_mask_bottom:addTouchEventListener(touchMaskCallback)

    self.mask_top:addTouchEventListener(touchMaskCallback)
end

function ChatNewMainLayer:registEventDispatcher(bTrue)
	print("ChatNewMainLayer:registEventDispatcher:::"..tostring(bTrue))

	if bTrue == false  then

		lemon.EventManager:getInstance():removeEventListener(self.fetch_session_listener)
		self.fetch_session_listener = nil
	
		lemon.EventManager:getInstance():removeEventListener(self.chatroom_login_listener)
		self.chatroom_login_listener = nil 
	
		lemon.EventManager:getInstance():removeEventListener(self.receive_msg_listener)
		self.receive_msg_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.send_msg_listener)
		self.send_msg_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.record_over_listener)
		self.record_over_listener = nil 
		
		lemon.EventManager:getInstance():removeEventListener(self.audio_play_listener)
		self.audio_play_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.send_expression_listener)
		self.send_expression_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.rec_player_listener)
		self.rec_player_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.nim_init_listener)
		self.nim_init_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.close_chat_listener)
		self.close_chat_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.channel_change_listener)
		self.channel_change_listener = nil 

		lemon.EventManager:getInstance():removeEventListener(self.session_unread_listener)
		self.session_unread_listener = nil 

		return 
	end

	--监听历史消息接受完成，分发UI处理
	if self.fetch_session_listener == nil then
		self.fetch_session_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.FETCH_HISTORY_SESSION,handler(self,self.eventFecthSessionCb))
	end
	
	--监听聊天室登陆回调，分发UI处理
	if self.chatroom_login_listener == nil  then
		self.chatroom_login_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHATROOM_ENTER_WORLD,handler(self,self.eventCbEnterChatroomWorld))
	end
	
	if self.receive_msg_listener == nil  then
		self.receive_msg_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.UI_REFRUSH_RECEIVE_MSG,handler(self,self.eventReceiveMsg))
	end

	if self.send_msg_listener == nil  then
		self.send_msg_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.UI_REFRUSH_SEND_MSG,handler(self,self.eventSendMsg))
	end
	
	--监听玩家信息
	if self.rec_player_listener == nil  then
		self.rec_player_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_SHOW_PLAYER_INFO,handler(self,self.eventReceivePlayerInfoMsg))
	end
	
	--录音完成，回调
	if self.record_over_listener == nil  then
		self.record_over_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_RECORD_OVER,handler(self,self.eventRecordOverCb))
	end
	
	--监听语音播放完成！
	if self.audio_play_listener == nil  then
		self.audio_play_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_PLAY_AUDIO_OVER,handler(self,self.eventAudioPlayCb))
	end

	--发送表情到聊天室
	if self.send_expression_listener == nil  then
		self.send_expression_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_EXPRESSION_SEND,handler(self,self.eventSendExpression))
	end	
	
	--监听SDK初始化完成
	if self.nim_init_listener == nil then
		self.nim_init_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_NIM_INIT_RESULT,handler(self,self.eventNimInitResultCb))
	end

	--退出聊天
	if self.close_chat_listener == nil  then
		--todo  REMOVE_CHAT_MAIN
		self.close_chat_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CLOSE_CHAT_MAIN,handler(self,self.eventCloseChatMain))
	end

    --切换频道
	if self.channel_change_listener == nil  then
		--todo  REMOVE_CHAT_MAIN
		self.channel_change_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_CHANNEL_CHANGE,handler(self,self.eventChannelChangeCb))
	end

	--未读消息 变更
	if self.session_unread_listener == nil  then
		self.session_unread_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_SESSION_UNREAD,handler(self,self.eventSessionUnreadChange))
	end
end

--监听未读消息变更,设定红点
function ChatNewMainLayer:eventSessionUnreadChange( event_table )

	local unreadNum = table.getValue("eventSessionUnreadChange",event_table,"unreadNum")
	local session_id = table.getValue("eventSessionUnreadChange",event_table,"session_id")
	local session_type = table.getValue("eventSessionUnreadChange",event_table,"session_type")

	--世界，公会，好友，多人战显示红点

	local guideId = XBChatData:getInstance():getGuideID()
	local guideRedSet = XBChatSys:getInstance():getChatSetting(EChatSetting.RED_TIP_GUILD)

	local friendRedSet = XBChatSys:getInstance():getChatSetting(EChatSetting.RED_TIP_PRIVATE_CHAT)

	local worldId = XBChatData:getInstance():getWorldRoomID()
	local worldRedSet = XBChatSys:getInstance():getChatSetting(EChatSetting.RED_TIP_WORLD)

	if session_type == 0 then
		--显示私聊红点
		if friendRedSet == true and self.default_index ~= 4 then
			self:addChannelRedDop(4,1,true)
		end
	elseif session_type == 2 then 
		if tostring(session_id) == tostring(worldId) and  worldRedSet == true and self.default_index ~= 2  then
			self:addChannelRedDop(2,unreadNum,true)
		elseif tostring(session_id) == tostring(guideId) and  guideRedSet == true  then
			if  self.default_index ~= 5 then 
				self:addChannelRedDop(5,unreadNum,true)
			else 
				self:addChannelRedDop(5,0,false)
			end 
		end
	end

end

--监听退出聊天
function ChatNewMainLayer:eventCloseChatMain( event_table )
	-- body
	local resultCode = table.getValue("event_table",event_table,"code")

	if resultCode == 0 then
		self:returnBack()
	end

end

function ChatNewMainLayer:eventChannelChangeCb( event_table )
	-- body
	local index = event_table["enterIndex"]
	if  index == nil or index > 5 or index < 0 then
		print("error:找不到聊天频道！！  idnex:"..tostring(index))
	end
	if index == self.default_index then 
		print("已经是当前频道，不处理")
 		return 
	end 
	self:initChannelCall(index)

end
--监听初始化
function ChatNewMainLayer:eventNimInitResultCb( event_table )
	if event_table == nil then
		print("ChatNewMainLayer:eventNimInitResultCb ================nil")
	end

	-- LogManager.dump(event_table, "ChatNewMainLayer.eventNimInitResultCb")

	local resultCode = table.getValue("event_table",event_table,"code")

	if resultCode == 0   then
		self:callLoginNim()
	else
		local msg = Lang:toLocalization(1031001)
		local message = msg.."\n resultCode = "..tostring(resultCode)
		XBChatSys:getInstance():showChatDebugMsg( message,"LoginNimFail")

		-- self:returnBack()
	end


end

function ChatNewMainLayer:eventAudioPlayCb( event_table)
	-- body
	LogManager.dump(event_table, "ChatNewMainLayer.eventAudioPlayCb")
	local t_data_str = table.getValue("event_table",event_table,"event_data")
	local cjsonSafe = require "cjson.safe"
	local t_data = cjsonSafe.decode(t_data_str)

	local code = t_data["code"]
	local filename = t_data["filePath"]
	if code == 0 and filename ~= nil then
		local isFileExist = cc.FileUtils:getInstance():isFileExist(filename)
		print("isFileExist:"..tostring(isFileExist))


		PlayerInfoSys:getInstance():refreshCurAudioState()

	else
		
		XBChatSys:getInstance():showChatDebugMsg("error:code："..tostring(code), "eventAudioPlayCb")   	
		
	end
end

--监听录音完成
function ChatNewMainLayer:eventRecordOverCb( event_table )
	-- body
	if event_table == nil then
		print("ChatNewMainLayer:eventRecordOverCb ================nil")
	end

	-- LogManager.dump(event_table, "ChatNewMainLayer.eventRecordOverCb")
	PlayerInfoSys:getInstance():refreshCurAudioState()

	local t_data_str = table.getValue("event_table",event_table,"event_data")
	local cjsonSafe = require "cjson.safe"
	local t_data = cjsonSafe.decode(t_data_str)

	local code = t_data["code"]
	local filename = t_data["filePath"]
	if code == 0 and filename ~= nil then
		local isFileExist = cc.FileUtils:getInstance():isFileExist(filename)
		print("isFileExist:"..tostring(isFileExist))
		local session = XBChatData:getInstance():getCurrentSession()
		if session["session_id"] == nil or session["session_id"] == "" then
			
			return 
		end

		XBChatPlatform:getInstance():sendChatVoice(filename,session["session_id"],session["session_type"], t_data["duration"])

	end





end
--监听表情点击
function ChatNewMainLayer:eventSendExpression( event_table )
	-- body
	if event_table == nil then
		print("ChatNewMainLayer:eventSendExpression ================nil")
	end

	-- LogManager.dump(event_table, "ChatNewMainLayer.eventSendExpression")

	local expressionId 		= event_table["id"]
	local expressionType 	= event_table["type"]
	print("ChatNewMainLayer:eventSendExpression  expressionId ",expressionId)
	print("ChatNewMainLayer:eventSendExpression  expressionType ",expressionType)
	dump(event_table,"ChatNewMainLayer:eventSendExpression  event_table ")
	local session = XBChatData:getInstance():getCurrentSession()

	if XBChatData:getInstance():canSpeakEabled() == true  then
		local temp_t = {
			session_id = session["session_id"],
			session_type = session["session_type"],
			attach = {
				sysType = 1002,
				id 		= expressionId,
				type 	=expressionType,
			}

		}

		XBChatPlatform:getInstance():sendChatCustom(temp_t)

	end


end

function ChatNewMainLayer:eventReceivePlayerInfoMsg( event_table )
	-- body
	local event_data = event_table
	local playerInfoLayer = ChatPlayerInfoLayer:create(event_data)
	self.pannelNode:addChild(playerInfoLayer.uiLayer,999)
end

function ChatNewMainLayer:eventCbEnterChatroomWorld( event_table ) --登陆结果通知回调
	if event_table == nil then
		print("ChatNewMainLayer:eventCbEnterChatroomWorld ================nil")
	end


	local t_data_str = table.getValue("event_table",event_table,"event_data")
	local cjsonSafe = require "cjson.safe"
	local t_data = cjsonSafe.decode(t_data_str)

	-- LogManager.dump(t_data, "ChatNewMainLayer.eventCbEnterChatroomWorld")

	local code = table.getValue("t_data",t_data,"code")
	local session_id = table.getValue("t_data",t_data,"room_id")
	local session_type = 2


	local ctls = {
        {view= self.pannelSystem},
        {view= self.pannelChatroom},
        {view= self.pannelBattle},
        {view= self.pannelFriend},
        {view= self.pannelGuild},
    }
    for i=1,5 do
    	if ctls[i].view ~= nil and ctls[i].view:isViewVisible() then
 			ctls[i].view:eventEnterChatroom(session_type,session_id,code)   	
    	end
     end

	XBChatSys:getInstance():delChatWaitLayer()
	-- SceneManager:delWaitLayer()

end

function ChatNewMainLayer:eventFecthSessionCb( event_data )
	-- body

	dump(event_data, "ChatNewMainLayer:eventFecthSessionCb")

	local t_data = event_data

	local session_id = t_data["session_id"]
	local session_type = t_data["session_type"]

	-- local datas = t_data["data"]
	if session_type == nil or session_id == nil or session_type == "" or session_id == "" then
		print("error:::::type:"..tostring(session_type).."..id:"..tostring(session_id))
		return
	end

	local ctls = {
        {view= self.pannelSystem},
        {view= self.pannelChatroom},
        {view= self.pannelBattle},
        {view= self.pannelFriend},
        {view= self.pannelGuild},
    }
    for i=1,5 do
    	if ctls[i].view:isViewVisible() then
 			ctls[i].view:eventFecthSession(session_type,session_id)   	
    	end
     end

end
function ChatNewMainLayer:eventSendMsg( event_data )
	local scrollEnd = true 
	self:refreshUI(event_data,scrollEnd)
end

function ChatNewMainLayer:eventReceiveMsg( event_data )

	self:refreshUI(event_data)

end

function ChatNewMainLayer:refreshUI( event_data,scrollEnd )
	dump(event_data, "ChatNewMainLayer:refreshUI")

	local t_data = event_data

	local session_id = t_data["session_id"]
	local session_type = t_data["session_type"]

	-- local datas = t_data["data"]
	if session_type == nil or session_id == nil or session_type == "" or session_id == "" then
		print("error:::::type:"..tostring(session_type).."..id:"..tostring(session_id))
		return
	end

	local ctls = {
        {view= self.pannelSystem},
        {view= self.pannelChatroom},
        {view= self.pannelBattle},
        {view= self.pannelFriend},
        {view= self.pannelGuild},
    }
    for i=1,5 do
    	if ctls[i].view ~= nil  and  ctls[i].view:isViewVisible() then
 			ctls[i].view:eventRefreshUI(session_type,session_id,scrollEnd)   	
    	end
     end
end

function ChatNewMainLayer:callLoginNim(  )
		
	self:registEventDispatcher(true) 	--启动通知事件



	if XBChatSys:getInstance():getInitSdkResult() == true and true == self.reqChatData then
		self.showGuideChannel = XBChatData:getInstance():isShowGuide()
		self:loginNimSuccess()
	else
		self:reLoginNim() 
	end

end

function ChatNewMainLayer:reLoginNim( ... )
	self.reqChatData = true 

	XBChatSys:getInstance():initNimSDK()
end

function ChatNewMainLayer:loginNimFailed( )
	print("loginNimFailed")
	-- self.loginNimOK = false
 --    MsgManager:showSimpMsgWithCallFunc(Lang:toLocalization(1010997),self,self.callLoginNim,self.returnBack)
end

function ChatNewMainLayer:loginNimSuccess(  )
	self.loginNimOK = true

	self.mask_top:setVisible(false)

	self:initChannelView()

	self:initChannelCall(self.default_index)

	self:initChannelUnread()
end


function ChatNewMainLayer:channelItemCallBack( sender,evnetType )
	-- body
	local tag = sender:getTag()
	print("channelIndex:"..tag)

	self.default_index = tag

	self:addChannelRedDop(self.default_index,0,false) --去除频道红点

     self:changeChannelPannel(self.default_index) --切换频道

	self:channelDataRefresh(self.default_index) --切换频道数据

end

function ChatNewMainLayer:changeChannelPannel( index )
	--更新频道标签UI    
    for i=1,ChatNewMainLayer.PANNEL_NUM do
		local btnNode = self.channelNode:getChildByTag(i)
		local fileName1 = "uifile/n_UIShare/chatNew/lt_b_00%d%s.png"
		local fileName = string.format(fileName1,i,"a")
         if i == index then 
            btnNode:setEnabled(false)
            fileName = string.format(fileName1,i,"b") --高亮
        else 
	   		if (i == 3 and self.showBattleChannel ~= true ) or (i == 5 and self.showGuideChannel ~= true) then
	            btnNode:setEnabled(false)
	            fileName = string.format(fileName1,i,"c") --灰

	        else
	            btnNode:setEnabled(true)
	            fileName = string.format(fileName1,i,"a") --normal
	        end
        end 
        -- print("fileName:"..tostring(fileName))
        btnNode:loadTexture(fileName)
    end

	local ctls = {
        {view= self.pannelSystem},
        {view= self.pannelChatroom},
        {view= self.pannelBattle},
        {view= self.pannelFriend},
        {view= self.pannelGuild},
    }
    --切换pannel
	for i=1,ChatNewMainLayer.PANNEL_NUM do
		if ctls[i].view ~= nil  then
			if i == index then
				ctls[i].view:showView()
				print("index====="..i)
			else
				ctls[i].view:hideView()
				ctls[i].view:removeScrollView() --同时清理滚动视图
			end			
		end
	end
end

function ChatNewMainLayer:initChannelCall( index ) --
	if self.uiLayer == nil then
		return
	end
    local  tabBTN = self.channelNode:getChildByTag(index)
	self:channelItemCallBack(tabBTN,nil)
end

function ChatNewMainLayer:channelDataRefresh( index )
	-- body
	local ctls = {
        {view= self.pannelSystem},
        {view= self.pannelChatroom},
        {view= self.pannelBattle},
        {view= self.pannelFriend},
        {view= self.pannelGuild},

    }

    if ctls[index].view ~= nil  then
    	ctls[index].view:channelDataRefresh()
    end
end


function ChatNewMainLayer:initChannelUnread(  )

	local guideRedSet = XBChatSys:getInstance():getChatSetting(EChatSetting.RED_TIP_GUILD)

	local friendRedSet = XBChatSys:getInstance():getChatSetting(EChatSetting.RED_TIP_PRIVATE_CHAT)

	local worldRedSet = XBChatSys:getInstance():getChatSetting(EChatSetting.RED_TIP_WORLD)



	if self.default_index ~= 4 and friendRedSet and XBChatData:getInstance():getFriendUnread() then
			self:addChannelRedDop(4,1,true)
	end

	if self.default_index ~= 2 and worldRedSet  then
		local worldId = XBChatData:getInstance():getWorldRoomID()
		local unReadWorldNum = XBChatData:getInstance():getSessionUnreadNum(2, worldId)
		if unReadWorldNum == 0 then
			self:addChannelRedDop(2,0,false)
		else
			self:addChannelRedDop(2,unReadWorldNum,true)
		end

	end

	if self.default_index ~= 5 and guideRedSet  then
		local guideID = XBChatData:getInstance():getGuideID()
		local unReadWorldNum = XBChatData:getInstance():getSessionUnreadNum(2, guideID)

		if unReadWorldNum == 0 then
			self:addChannelRedDop(5,0,false)
		else
			self:addChannelRedDop(5,unReadWorldNum,true)
		end

	end

end

function ChatNewMainLayer:addChannelRedDop( channelTag,unReadNum,bShow )--添加红点：主频道（系1，世2，战3，私4，公5）
  	
  	print("ChatNewMainLayer:addChannelRedDop=====channelTag:"..tostring(channelTag)..",unReadNum:"..tostring(unReadNum))
	local channelIndexNode = self.channelNode:getChildByTag(channelTag)

	if channelIndexNode ~= nil  then
		if bShow == true and self.default_index ~= channelTag then
			self:setCommmonBtnRedDopChat(channelIndexNode,bShow,unReadNum)
		elseif bShow ~= true and self.default_index == channelTag then
			self:setCommmonBtnRedDopChat(channelIndexNode,bShow,unReadNum)
		end
	end


	if bShow ~= true  then
		--世界，公会，好友，多人战显示红点

		if channelTag == 2 then
			--世界频道
			local worldId = XBChatData:getInstance():getWorldRoomID()
			XBChatData:getInstance():setSessionUnreadNum(2, worldId, 0)
		elseif channelTag == 5 then
			--公会频道
			local guideId = XBChatData:getInstance():getGuideID()
			XBChatData:getInstance():setSessionUnreadNum(2, guideId, 0)
		end



	end


end

function ChatNewMainLayer:setCommmonBtnRedDopChat(btn, _isShow,unReadNum)

    local oldTip = btn:getChildByTag(TIP_POINT_TAG)
    if _isShow then 
        if oldTip == nil then 
            local p = cc.p(btn:getContentSize().width-10,btn:getContentSize().height-10)
            local imageFile = "n_UIShare/chatNew/lt_ui_032.png"
            local unReadBg = ccui.ImageView:create(imageFile)
            unReadBg:setPosition(p)
            btn:addChild(unReadBg) 
		    unReadBg:setTag(TIP_POINT_TAG)

		    if unReadNum > 1 then
		    	imageFile2 = "n_UIShare/chatNew/lt_ui_031.png"
		    	unReadBg:loadTexture(imageFile2)

		    	local unReadText = unReadBg:getChildByTag(TIP_POINT_TAG)
		    	if unReadText == nil  then
				    local sprContent = unReadBg:getContentSize() 
				    unReadText = ccui.Text:create(tostring(unReadNum),TEXT_FONT_NAME,16)
				    unReadText:setPosition(cc.p(sprContent.width/2,sprContent.height/2))
				    unReadText:setTouchEnabled(false)
				    unReadText:setSwallowTouches(false)
				    unReadText:setTag(TIP_POINT_TAG)
				    unReadBg:addChild(unReadText)
				else
					unReadText:setString(tostring(unReadNum))
			    end
		    end
		else
		    if unReadNum > 1 then
		    	local imageFile2 = "n_UIShare/chatNew/lt_ui_031.png"
		    	oldTip:loadTexture(imageFile2)
		    	local unReadText = oldTip:getChildByTag(TIP_POINT_TAG)
		    	if unReadText == nil  then
				    local sprContent = oldTip:getContentSize() 
				    unReadText = ccui.Text:create(tostring(unReadNum),TEXT_FONT_NAME,16)
				    unReadText:setPosition(cc.p(sprContent.width/2,sprContent.height/2))
				    unReadText:setTouchEnabled(false)
				    unReadText:setSwallowTouches(false)
				    unReadText:setTag(TIP_POINT_TAG)
				    oldTip:addChild(unReadText)
				else
					unReadText:setString(tostring(unReadNum))
			    end
			else
            	local imageFile = "n_UIShare/chatNew/lt_ui_032.png"
		    	oldTip:loadTexture(imageFile)
		    	local unReadText = oldTip:getChildByTag(TIP_POINT_TAG)
		    	if unReadText then
		    		unReadText:removeFromParent()
		    		unReadText = nil 
		    	end
		    end
        end 
    else
        if oldTip ~= nil then 
            oldTip:removeFromParent(true)
            oldTip = nil 
        end 
    end  
end

