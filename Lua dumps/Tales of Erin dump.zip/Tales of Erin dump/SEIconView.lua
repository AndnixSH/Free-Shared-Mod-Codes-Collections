--require "XUIView"

SEIconView = class("SEIconView", XUIView)

SEIconView.CS_FILE_NAME = "SEIconView.csb"
SEIconView.CS_BIND_TABLE = 
{
    panelIcon = "/i:1770/i:1776",
    panelName = "/i:1770/i:1767",
    lbName = "/i:1770/i:1767/i:1769",
    iconImage = "/i:1770/i:1776/i:1779"
}

SEIconView.IconSmallPath = "icons/soulequip/list/"

function SEIconView:init(rootNode,nSeId,bNameShow)
    SEIconView.super.init(self,rootNode)

    if nSeId then
        self.curSoulEquipId = nSeId
    end
    --根据魂灵装ID取本地数据
    if hero_soul[self.curSoulEquipId] then
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
    end
    self:ShowSEName(bNameShow)

    return self
end

function SEIconView:RefreshSeIcon(nSeId,nSeSublStage)
    if not nSeId then
        return
    end
    if nSeId then
        self.curSoulEquipId = nSeId
    end
    --根据魂灵装ID取本地数据
    if hero_soul[self.curSoulEquipId] then
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
    end
    
    if not self.hero_soul_info then
        return
    end
    
    --魂灵装名称
    local seName = UITool.getUserLanguage(self.hero_soul_info.name)
    if seName then
        self.lbName:setString(seName)
    end
    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    local face = self.hero_soul_info["soul_break"]["break_"..nSeSublStage].icon_small
    if face then
        self.iconImage:setTexture(self.IconSmallPath..face)
    end  
end

function SEIconView:ShowSEName(bNameShow)
    if bNameShow == 1 then
        self.panelName:setVisible(true)
    else
        self.panelName:setVisible(false)
    end
end