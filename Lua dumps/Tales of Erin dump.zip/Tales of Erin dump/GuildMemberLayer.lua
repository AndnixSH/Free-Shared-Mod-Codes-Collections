require "BasicLayer"

GuildMemberLayer = class("GuildMemberLayer",BasicLayer)
GuildMemberLayer.__index = GuildMemberLayer
GuildMemberLayer.lClass = 2 
GuildMemberLayer.GuildName = nil
GuildMemberLayer.GuildMemberIndex = 1
GuildMemberLayer.GuildMemberTable = nil
GuildMemberLayer.ListView   = nil
GuildMemberLayer.guildId    = nil
GuildMemberLayer.nType      = nil    
GuildMemberLayer.pos        = nil
GuildMemberLayer.lay_out    = nil
GuildMemberLayer.panelList  = nil
GuildMemberLayer.tempNode   = nil
function GuildMemberLayer:init()
    local node = nil 
    if g_channel_control.show_new_guild_main == true then
        node = cc.CSLoader:createNode("GuildMemberLayer_new.csb")
    else
        node = cc.CSLoader:createNode("GuildMemberLayer.csb")
    end
    self.uiLayer:addChild(node,0,2) 
    self.exist = true

    self.nType   = self.rData["rcvData"]["nType"]
    self.guildId = self.rData["rcvData"]["guild_id"]
   -- print("defaultSelectBtn defaultSelectBtn == "..self.rData["rcvData"]["defaultSelectBtn"])

    local panel             = node:getChildByName("Panel_1")
    self.panelList          = panel:getChildByName("Panel_List")
    -- self.ListView           = panel:getChildByName("ListView_1")
    -- self.ListView:setItemModel(self.lay_out)

    self:initAttrbute() 
   
    --self:memeberListSnd(self.guildId)
    self.GuildMemberIndex = self.rData["rcvData"]["selectIndex"]

    self.GuildType  =   self.rData["rcvData"]["GuildType"]
    --if self.GuildMemberIndex == 2 then
     self.pos     = self.rData["rcvData"]["pos"]
     if self.pos then--
         print("init pos == "..self.pos)
     end 
    --end
    GuildSingleton:getInstance():setMemberState(GuildSingleton.pType.normal)
    self:ininListView()
    self:ImageHighLight(self.GuildMemberIndex)
    
    self:registerCustomEventListener()
    
    if g_channel_control.show_new_guild_main == true then
        self.Panel_state = panel:getChildByName("Panel_state")
        self.Button_manage = self.Panel_state:getChildByName("Button_manage")
        self.Button_normal = self.Panel_state:getChildByName("Button_normal")
        self.Panel_state:setVisible(true)
        self.Button_manage:setVisible(false)
        self.Button_normal:setVisible(false)
        self.Button_find = panel:getChildByName("Button_find")
        self:initSearch()
        self:InitTopBarView()
        self:hideGiveTimes() 
        if self.pos == 2 or self.pos == 3 then
            self.Button_manage:setVisible(true)
        end

        local function btnCallBack(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                if sender:getName() == "Button_manage" then
                    if self.gridview == nil then
                        return
                    end
                    self.Button_manage:setVisible(false)
                    GuildSingleton:getInstance():setMemberState(GuildSingleton.pType.manage)
                    self.gridview:setDataSource(self.GuildMemberTable["tab"])
                    self.Button_normal:setVisible(true)
                elseif sender:getName() == "Button_normal" then
                    if self.gridview == nil then
                        return
                    end
                    self.Button_normal:setVisible(false)
                    GuildSingleton:getInstance():setMemberState(GuildSingleton.pType.normal)
                    self.gridview:setDataSource(self.GuildMemberTable["tab"])
                    self.Button_manage:setVisible(true)
                elseif sender:getName() == "Button_find" then
                    local key = self:getSearchKey()
                    if key == "" then
                        local msg = Lang:toLocalization(1040145)
                        MsgTipSys:getInstance():addData(msg)
                        return
                    end
                    self:onBtnFindCallback(key)
                    print("点击搜索功能")
                end
            end
        end       
        self.Button_manage:addTouchEventListener(btnCallBack)
        self.Button_normal:addTouchEventListener(btnCallBack)
        self.Button_find:addTouchEventListener(btnCallBack)
    end
      --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
--/*初始化公会的属性*/
function GuildMemberLayer:initAttrbute( ... )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imageBg           = panel:getChildByName("Image_BgForm")
    local GiveBg            = imageBg:getChildByName("Image_give")
    --/*关闭按钮*/
    local colseBtn          = panel:getChildByName("Button_close")
    --/*成员按钮*/
    local memeberBtn        = panel:getChildByName("Image_member")
    --/*申请按钮*/
    local shenqBtn          = panel:getChildByName("Image_shengqing")
    -- /*公会推荐背景*/
    if  self.nType == 1 then
        memeberBtn:setVisible(false)
        shenqBtn:setVisible(false)
       -- GiveBg:setVisible(false)
    end

   -- self.ListView           = panel:getChildByName("ListView_1")

    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if name == "Button_close" then
                self:returnBack()
            elseif  name == "Image_member" then
                self.GuildMemberIndex = 1
                self:ImageHighLight(self.GuildMemberIndex)
            elseif  name == "Image_shengqing" then
                if g_channel_control.show_new_guild_main == false then
                    self.GuildMemberIndex = 2
                    self:ImageHighLight(self.GuildMemberIndex)
                else
                    self:applyList()
                end
            end
        end
    end
    colseBtn:addTouchEventListener(touchCallBack)
    colseBtn:setEffectType(3)
    memeberBtn:addTouchEventListener(touchCallBack)
    shenqBtn:addTouchEventListener(touchCallBack)
end
--什么
function GuildMemberLayer:refreshTale()
    --print("self.changeTable self.changeTable == "..#self.changeTable)
    -- self.GuildMemberTable["tab"]["GuildMemberIndex"] = self.GuildMemberIndex;
    -- self.GuildMemberTable["tab"]["OnSelf"] = self;
    if self.GuildMemberIndex == 1 then
        table.sort(self.GuildMemberTable["tab"],function ( x,y )
            -- body
            if x["can_get"] == y["can_get"] then
                if x["can_get"] > 0 then
                    return x["can_get"] > y["can_get"]
                else
                    return x["position"] > y["position"]
                end
            else
                return x["can_get"] > y["can_get"]
            end 
            
        end)
    end
    if self.gridview == nil then
        return
    end
    self.gridview:setDataSource(self.GuildMemberTable["tab"])

end
--/*显示初始属性*/
function GuildMemberLayer:ShowTex( ... )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imageBg           = panel:getChildByName("Image_BgForm")
    local GiveBg            = imageBg:getChildByName("Image_give")
    --/*当前赠送次数*/
    local curGive           = GiveBg:getChildByName("Text_curGivegive")
    --/*最大赠送次数*/
    local maxGive           = GiveBg:getChildByName("Text_maxGivegive")
    if self.GuildMemberIndex == 1 then
        if self.nType == 1 then
            GiveBg:setVisible(false)
        else
            if g_channel_control.show_new_guild_main == true then
                GiveBg:setVisible(false)
            else
                GiveBg:setVisible(true)
            end
            --GiveBg:setVisible(true)
        end
        -- /*最大赠送次数*/
         local max_give_num = self.GuildMemberTable["max_give_num"] or 0
         maxGive:setString("/"..max_give_num)
         maxGive:setAnchorPoint(cc.p(0,0.5))
         maxGive:setPosition(cc.p(149.74,14.22))

         -- /*当前赠送次数*/
         curGive:setString(self.GuildMemberTable["cur_give_num"])
         curGive:setAnchorPoint(cc.p(1.0,0.5))
         curGive:setPosition(cc.p(150.63,14.22))
 
    else
        GiveBg:setVisible(false)
    end
    local memberBg          = panel:getChildByName("Image_memberBg")
    --/*当前成员数*/
    local curMember         = memberBg:getChildByName("Text_curNum")
    --/*最大成员数*/
    local maxMember         = memberBg:getChildByName("Text_curNum_0")
    local  ncur             = UITool.SubStringToInt(self.GuildMemberTable["mem_num"],'/',1)
    local  nMax             = UITool.SubStringToInt(self.GuildMemberTable["mem_num"],'/',2)
    curMember:setString(ncur)

    maxMember:setString("/"..nMax)

end
function GuildMemberLayer:refreshGiveNum( num )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imageBg           = panel:getChildByName("Image_BgForm")
    local GiveBg            = imageBg:getChildByName("Image_give")
    --/*当前赠送次数*/
    local curGive           = GiveBg:getChildByName("Text_curGivegive")
    --/*最大赠送次数*/
    curGive:setString(num)
end
-- /*初始化List 模板*/
function GuildMemberLayer:initModel( ... )
    -- -- body
    -- -- local node              = self.uiLayer:getChildByTag(2)
    -- -- local panel             = node:getChildByName("Panel_1")
    -- -- self.ListView           = panel:getChildByName("ListView_1")
    -- local  layout_list = ccui.Layout:create()
    -- layout_list:setAnchorPoint(cc.p(0,1))
    -- local  list_item = cc.CSLoader:createNode("GuildMemberItemNode.csb")
    -- local  item_1 = list_item:getChildByName("Panel_1")
    -- local item_c = item_1:clone()
    -- item_c:setName("item1")
    -- layout_list:addChild(item_c)
    -- layout_list:setContentSize(1045,118)
    -- layout_list:setHighlighted(false)
    -- layout_list:setTouchEnabled(true)
    -- --self.ListView:setItemModel(layout_list)
    -- return layout_list
end
-- /*初始化 滑动列表*/
function GuildMemberLayer:ininListView( ... )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    local panel = node:getChildByName("Panel_1")
    self.panelList = panel:getChildByName("Panel_List")
    local psize = self.panelList:getContentSize()
    if g_channel_control.show_new_guild_main == true then
        self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,1030,126)
    else
        self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,830,145)
    end
    
    self.gridview.itemCreateEvent = function()
        local temp = GuildMemberNode.new():init()
        self.tempNode = temp
        self.GuildMemberTable["GuildMemberIndex"] = self.GuildMemberIndex;
        self.GuildMemberTable["OnSelf"] = self;
        self.GuildMemberTable["GuildType"] = self.GuildType --self.rData["rcvData"]["GuildType"];
        temp:setData(self.GuildMemberTable);
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    --print("curId == "..temp.curId)
                    --self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                end
            end
        end 

        return temp
    end
end

--注册自定义事件
function GuildMemberLayer:registerCustomEventListener()


    self.guildKickEventListener = lemon.EventManager:addCustomEventListener(EEventType.GUILD_KICK, function(data)
            print("GuildMemberLayer:registerCustomEventListener EEventType.GUILD_KICK callback ")

            self:handleGuildKick(data)
           
        end)
  
end



--移除注册自定义事件
function GuildMemberLayer:unRegisterCustomEventListener()

    if self.guildKickEventListener ~= nil then
        lemon.EventManager:removeEventListener(self.guildKickEventListener)
        self.guildKickEventListener = nil 
    end
    
end

--移除注册自定义事件
function GuildMemberLayer:handleGuildKick(data)

   self:ImageHighLight(self.GuildMemberIndex)
    
end

--/*显示公会成员 或  申请信息*/
function GuildMemberLayer:ShowGuildMember( ... )
    -- if self.gridview==nil then 

    -- end 
    if self.tempNode and self.GuildMemberTable then
        self.GuildMemberTable["GuildMemberIndex"] = self.GuildMemberIndex;
        self.GuildMemberTable["OnSelf"] = self;
        self.GuildMemberTable["GuildType"] = self.GuildType --self.rData["rcvData"]["GuildType"];
        self.tempNode:setData(self.GuildMemberTable);
    end
    self:refreshTale()
end
--/*时间转换成 什么什么 以前*/
function GuildMemberLayer:timeSwitch(ntime)
    -- body
    local now =UserDataMgr:getInstance().timeData:getCurrentTime()-- os.time()
    local dist = now - ntime
    local retv = nil
    if dist > 2592000 then
        retv = UITool.ToLocalization("1个月前")
    elseif dist > 604800 then
        retv = UITool.ToLocalization("1周前")
    elseif dist > 172800 then
        retv = UITool.ToLocalization("2天前")
    elseif dist > 86400 then
        retv = UITool.ToLocalization("1天前")
    elseif dist > 43800 then
        retv = UITool.ToLocalization("12小时前")
    elseif dist > 21600 then
        retv = UITool.ToLocalization("6小时前")
    elseif dist > 7200 then
        retv = UITool.ToLocalization("2小时前")
    elseif dist > 1800 then
        retv = UITool.ToLocalization("30分钟前")
    elseif dist > 300 then
        retv = UITool.ToLocalization("5分钟前")
    else
        retv = UITool.ToLocalization("刚刚")
    end

    return retv
end
-- 距返回时间24小时以内。  上次登录 *小时*分钟前
-- 距返回时间24小时以上。  上次登录 1天前
-- 距返回时间2天以上。  上次登录2天前

function GuildMemberLayer:lastLoginTimetoVisibleStr(lastloginTime,isSelf, online)
    lastloginTime = lastloginTime or -1
    local timeStr = ""
    if lastloginTime < 0 or isSelf == true or online == 2 then
        timeStr = Lang:toLocalization(1040134)

    else
        local nowTime  =UserDataMgr:getInstance().timeData:getCurrentTime()
        local dist = nowTime - lastloginTime
        local tableTime = UITool.ShowTime(dist)
        
        if tableTime["D"] < 1 then

            if tableTime["H"] < 1 then

                local minnute = math.max(1, tableTime["M"])
                timeStr = string.format(Lang:toLocalization(1040133), minnute)

            else

                timeStr = string.format(Lang:toLocalization(1040132), tableTime["H"], tableTime["M"])

            end
            
        else
            timeStr = string.format(Lang:toLocalization(1040131), tableTime["D"])

        end

    end
    
    return timeStr
   
end
--/*刷新成员列表*/
function GuildMemberLayer:refreshMember( ... )
    -- body
    self:memeberListSnd(self.guildId)
    self:ImageHighLight(self.GuildMemberIndex)
end
--/*名片*/
function GuildMemberLayer:toPalyinfo( tdata )
    -- body
    --index = tonumber(index)
    local tp  = nil
    if self.nType == 1 then
        tp = 3
    else
        tp = self.GuildMemberIndex
    end 
    -- if self.nType == 1 then
    --     tp = nil
    -- elseif self.nType == 2 then
    --     tp = 1
    -- elseif self.nType == 3 then
    --     tp = 2
    -- end

    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] = self.refreshMember--self.sManager:toGuildMemberLayer
    
    local info = {}
    if g_channel_control.b_XbPlayerInfoView == true then
        info["ui_from"] = PlayerInfoSys.EUiType.guild
        info["uid"] = tdata["uid"]
        info["m_position"] = self.pos
        rcvData["info"] =  info
    else
        info["fromType"] = tp   -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息
        info["m_position"] = self.pos   --self.GuildMemberTable["tab"][index]["position"], --自己的公会职位
        info["other_infos"] = {}    --要查看对象的信息
        info["other_infos"]["uid"] = tdata["uid"]
        info["other_infos"]["head"] = tdata["head"]
        rcvData["info"] =  info
    end
   self.sManager:toPlayerInfoLayer(rcvData)
end

function GuildMemberLayer:switchPlayerInfoLayer( id,head )
    -- body
    local tp  = nil
    if self.nType == 1 then
        tp = 3
    else
        tp = self.GuildMemberIndex
    end 

    local rcvData = {}
    local info = {}
    if g_channel_control.b_XbPlayerInfoView == true then
        info["ui_from"] = PlayerInfoSys.EUiType.guild
        info["uid"] = id
        info["m_position"] = self.pos
        rcvData["info"] =  info
    else
        info["fromType"] = tp   -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息
        info["m_position"] = self.pos   --self.GuildMemberTable["tab"][index]["position"], --自己的公会职位
        info["other_infos"] = {}    --要查看对象的信息
        info["other_infos"]["uid"] = id
        info[other_infos]["head"] = head
        rcvData["info"] =  info
    end

    rcvData["sDelegate"] =  self
    rcvData["sFunc"] = self.refreshMember--self.sManager:toGuildMemberLayer
    rcvData["info"] =  info
    rcvData["guild_id"] = self.guildId
    SceneManager:toPlayerInfoLayer(rcvData)
end

function GuildMemberLayer:friendChat()
    -- local data = {
    --     enterIndex = 5
    -- }
    -- SceneManager:toChatLayer(data)

    --lemon.EventManager:dispatchCustomEvent(EEventType.PLAY_INFO_CLOSE , {})
    local data = {
        enterIndex = 4
    }
    SceneManager:toChatLayer(data)
end

function GuildMemberLayer:addFriend(user_nim_id)
    local node = self.uiLayer:getChildByTag(2)
    local panel = node:getChildByName("Panel_1")
    local data = {
            user_nim_id = user_nim_id
        }
    print("user_nim_id",user_nim_id)

    local sData = {}
    sData["rcvData"] = data
    local layer = XbFriendsAddFriendConfirmLayer:create(sData)
    local rootLayer = layer:getRootNode()
    panel:addChild(rootLayer)
end

-- /*获取赠送的Ap*/
function GuildMemberLayer:getApSend( memberId ,sender)
    -- body
    local function reiceSthCallBack(data)
        print("获取AP")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        user_info["ap"] = t_data["data"]["ap"]
        if self.sManager ~= nil then
            self.sManager.menuLayer:RefshTopBar()
        end
        
        sender:setBright(false)
        sender:setEnabled(false)
        MsgManager:showSimpMsg(UITool.ToLocalization("成功获取赠送体力"))
    end

    local cjson = require "cjson"
    if self.sManager ~= nil then
        self.sManager:createWaitLayer()
    end
    
    local tempTable = {
        ["rpc"]       = "guild_get_ap",
        ["member_id"] = memberId , -- 推荐  2 排行
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- /*赠送AP*/
function GuildMemberLayer:giveApSend( memberId ,sender)
    if g_channel_control.UIVersion < 2 then

        self:giveApSendVersionOne(memberId ,sender)

    else 

        self:giveApSendVersionTow(memberId ,sender)

    end
end


function GuildMemberLayer:giveApSendVersionTow( memberId ,sender)

    local reqData = { 
        uid =  memberId
    }     
    FriendsSys:getInstance():reqGiveGuildAp(reqData, function(data)
            if self.exist == false then
                return
            end

            user_info["ap"] = data["ap"]
            self.GuildMemberTable["cur_give_num"] = data["cur_give_num"]
            if self.sManager ~= nil then
                self.sManager.menuLayer:RefshTopBar()
            end
            
            sender:setBright(false)
            sender:setEnabled(false)
            self:refreshGiveNum(self.GuildMemberTable["cur_give_num"])
            if self.GuildMemberTable["cur_give_num"] >= self.GuildMemberTable["max_give_num"] then
                self:ShowGuildMember()
            end
           
        end)


end

-- /*赠送AP*/
function GuildMemberLayer:giveApSendVersionOne( memberId ,sender)
    -- body
    local function reiceSthCallBack(data)
        print("获取AP")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        user_info["ap"] = t_data["data"]["ap"]
        self.GuildMemberTable["cur_give_num"] = t_data["data"]["cur_give_num"]
        if self.sManager ~= nil then
            self.sManager.menuLayer:RefshTopBar()
        end
        
        sender:setBright(false)
        sender:setEnabled(false)
        self:refreshGiveNum(self.GuildMemberTable["cur_give_num"])
        if self.GuildMemberTable["cur_give_num"] >= self.GuildMemberTable["max_give_num"] then
            self:ShowGuildMember()
        end
        MsgManager:showSimpMsg(UITool.ToLocalization("成功赠送体力"))
    end

    local cjson = require "cjson"
    if self.sManager ~= nil then
        self.sManager:createWaitLayer()
    end
    local tempTable = {
        ["rpc"]       = "guild_give_ap",
        ["member_id"] = memberId , -- 推荐  2 排行
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

-- /*获取成员列表*/
function GuildMemberLayer:memeberListSnd(guildId)
    -- body
        -- body
    local function reiceSthCallBack(data)
        print("获取成员列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
       if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            
             --MsgManager:showSimpMsg(t_data["data"]["warning"])
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end
        self.GuildMemberTable = {}
        -- self.GuildMemberTable["add_ap_num"]      = t_data["data"]["add_ap_num"]
        -- self.GuildMemberTable["max_ap_num"]      = t_data["data"]["max_ap_num"]
        self.GuildMemberTable["max_give_num"]    = t_data["data"]["max_give_num"]
        self.GuildMemberTable["cur_give_num"]    = t_data["data"]["cur_give_num"]
     
        self.GuildMemberTable["mem_num"]       = t_data["data"]["mem_num"]

        self.GuildMemberTable["tab"] = t_data["data"]["members"]
        GuildSingleton:getInstance():setGuildLeaderState(t_data["data"]["leader_state"])

        self:ShowGuildMember()
        self:ShowTex() 

        if g_channel_control.UIVersion >= 1 then

            GuildSys:getInstance():synGuildData(t_data["data"]) 

        end
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guild_members",
        ["guild_id"] = guildId , 
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- /*获取申请列表*/
function GuildMemberLayer:SQListSend( ... )
    -- body
    local function reiceSthCallBack(data)
        print("获取申请列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.GuildMemberTable = {}
        self.GuildMemberTable["tab"]        = t_data["data"]["applicants"]
        self.GuildMemberTable["mem_num"]    = t_data["data"]["mem_num"]
        self:ShowGuildMember()
        self:ShowTex() 
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guild_applicants",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)

end
-- /*确定取消通过申请按钮*/
function GuildMemberLayer:confrimToCancleSend(uid,index)
    -- body
    local function reiceSthCallBack(data)
        print("确定或取消按钮")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
         if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self:deleteItem(uid)
    end
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "guild_ratify",
        ["apply_uid"] = uid,
        ["ratify"]    = index,
    }
    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)
    self.sManager:createWaitLayer()
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function GuildMemberLayer:deleteItem( uid)
    -- body
   -- self.GuildMemberTable["tab"] = tdata["applicants"]
    for i = 1 , #self.GuildMemberTable["tab"] do
        if self.GuildMemberTable["tab"][i]["uid"] == uid then
            self.GuildMemberTable["tab"][i] = nil
        end
    end
    local test  = {}
    local index = 1
    for i = 1 , #self.GuildMemberTable["tab"] do
        if self.GuildMemberTable["tab"][i] then
            test[index] = self.GuildMemberTable["tab"][i]
            index = index + 1
        end
    end
    self.GuildMemberTable["tab"] = table.deepcopy(test)
    self:ShowGuildMember()

    self:ShowTex() 
end

--/*点击 成员 申请 图片换成高亮*/
function GuildMemberLayer:ImageHighLight( nIndex )
    -- body
    if self.uiLayer == nil then
        return
    end
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imageBg           = panel:getChildByName("Image_BgForm")
    local memeberBtn        = panel:getChildByName("Image_member")
    local shenqBtn          = panel:getChildByName("Image_shengqing")
    local titleName         = imageBg:getChildByName("Text_title")
    if nIndex == 1 then
        memeberBtn:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_b_005_2.png")
        if g_channel_control.show_new_guild_main == false then
            shenqBtn:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_b_006_1.png")
        end
        self:memeberListSnd(self.guildId)
        titleName:setString(UITool.ToLocalization("成员列表"))
    elseif nIndex == 2 then
        memeberBtn:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_b_005_1.png")
        if g_channel_control.show_new_guild_main == false then
            shenqBtn:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_b_006_2.png")
        end
        self:SQListSend()
        titleName:setString(UITool.ToLocalization("申请列表"))
    end
end
function GuildMemberLayer:returnBack( ... )
    -- -- body
    self.sManager:removeFromNavNodes(self)
    -- self.sData = {}
    
    self:unRegisterCustomEventListener()
    
    if self.backFunc then 
     self.backFunc(self.sManager,self.rData["rcvData"])
    end 
    self.exist = false
    self.sData = {}
    self.rData = {}
    self.gridview = nil
    self:clearEx()
    -- self.sManager:removeFromNavNodes(self)
    -- self.sData = {}
    -- self.backFunc(self.sManager,self.sData)
    -- self.exist = false
    -- self.sData = {}
    -- self.rData = {}
    -- self:clear()
end

function GuildMemberLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function GuildMemberLayer:create(rData)

     local login = GuildMemberLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login.lay_out   = login:initModel()
     login:init()
     return login   
end

function GuildMemberLayer:InitTopBarView()
    --topbar节点 
    local node = self.uiLayer:getChildByTag(2)
    local panel = node:getChildByName("Panel_1")
    topBarViewPanel = panel:getChildByName("TopBarPanel")
    self.topBarViews = XUIView.new():init(topBarViewPanel)
    local iteamDatas = {}
    local rcvData = {}
    rcvData["sIteamDatas"] = iteamDatas
    rcvData["bIsStartLayer"] = false
    rcvData["nInfoState"] = table.getValue("coinbar",coinbar,63,"coinbar_type")
    rcvData["nTitleNum"] = 7

    self.topBarView = TopBarView.new():init(rcvData)
    self.topBarViews:addSubView(self.topBarView)
    self:InitSociatyMemberTopBarView()
end

function GuildMemberLayer:InitSociatyMemberTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,63,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

-- 当货币栏中有不是金币，体力和星石时，需要单独刷洗数据 (根据不同的类型数据存入array_cointype中),具体类型参考cointype表 
function GuildMemberLayer:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
            if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end

function GuildMemberLayer:hideGiveTimes()
    local node = self.uiLayer:getChildByTag(2)
    local panel = node:getChildByName("Panel_1")
    local imageBg = panel:getChildByName("Image_BgForm")
    local GiveBg = imageBg:getChildByName("Image_give")
    GiveBg:setVisible(false)
end

function GuildMemberLayer:applyList( ... )
    local guildId = self.guildId

    if guildId == nil or guildId == "" then
        local tipStr = Lang:toLocalization(1040115)
        MsgManager:showSimpMsg(tipStr)
        return
    end
    local data = {
            guildId = guildId,
        }
    SceneManager:toGuildApplyLayer(data)

end

function GuildMemberLayer:initSearch()
    local node = self.uiLayer:getChildByTag(2)
    local panel = node:getChildByName("Panel_1")
    self.Panel_find = panel:getChildByName("Panel_find")
    self.TextField_find = self.Panel_find:getChildByName("TextField_find")
    self.TextField_find:setPlaceHolder(UITool.ToLocalization("输入关键字进行搜索"))
    self.Button_clear_key = self.Panel_find:getChildByName("Button_clear_key")
    self.Button_clear_key:setVisible(false)
    self.Panel_find:addClickEventListener(function()  
        print("点击输入框")
       self:popInputView()
    end)
    self.Button_clear_key:addClickEventListener(function()  
        self.TextField_find:setString("")
        self.Button_clear_key:setVisible(false)
        self.Panel_state:setVisible(true)
        self:refreshMemberList(1, self.GuildMemberTable["tab"])
    end)  
end

function GuildMemberLayer:popInputView( ... )
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    rcvData["confirmFunc"] =  function(self,text)
        self.TextField_find:setString(text)
        if text ~= nil and text ~= "" then
            self.Button_clear_key:setVisible(true)
        end
    end
    rcvData["defalutStr"] = self.TextField_find:getString()
    rcvData["maxLength"] = 8
    SceneManager:toInputModelLayer(rcvData)
end

--获得搜索的关键字
function GuildMemberLayer:getSearchKey()
    local key = self.TextField_find:getString()
    return key
end

function GuildMemberLayer:onBtnFindCallback(key)
    dump(self:getList(),"list = ")
    local filtList = self:searchByKey(self:getList(), key, true)

    if #filtList == 0 then
        local msg = Lang:toLocalization(1040118)
        MsgManager:showSimpMsg(msg)
        return
    end
    self.Panel_state:setVisible(false)
    self:refreshMemberList(1, filtList)
end

function GuildMemberLayer:refreshMemberList(ifRefresh, list)
    ifRefresh = ifRefresh or 1

    local friendList = list or {}
    local cloneList = clone(friendList)
    if ifRefresh == 1 then
         self.gridview:setDataSource(cloneList)
    elseif ifRefresh == 2 then
        self.gridview:refreshDataSource(cloneList, defaultAdjustValue)
    else 
        self.gridview:refreshDataSource(cloneList)
    end
end

--通过关键字在数组里面查询出来
function GuildMemberLayer:searchByKey(arr, key, bChairman)
    if type(arr) ~= "table" or key == nil then
        return {}
    end

    local list = {}
    for i = 1, #arr do
        local item = arr[i]
        local userId = table.getValue("XbFriendsPartLayer:searchByKey item", item, "uid") or ""
        local name = table.getValue("XbFriendsPartLayer:searchByKey item", item, "name") or ""
        local position = table.getValue("XbFriendsPartLayer:searchByKey item", item, "position")
        local chairmanStr = Lang:toLocalization(1010107)
        local viceChairmanStr = Lang:toLocalization(1010279)

        local bJoin = false
        if string.find(userId, key) 
            or string.find(name, key) then
            bJoin = true
        end
        if  bChairman then
            if (key == chairmanStr and position == 3) 
                or (key == viceChairmanStr and position == 2) then
                bJoin = true
            end
        end

        if bJoin then
            table.insert(list, item)
        end
        
    end

    return list
 
end

function GuildMemberLayer:getList()
    return self.GuildMemberTable["tab"] or {}
end
