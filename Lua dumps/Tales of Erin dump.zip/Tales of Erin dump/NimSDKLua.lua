--[[
    云信SDK在lua层的管理类
]]


NimSDKLua = {}
NimSDKLua.is_login = false
NimSDKLua.account_id = nil
NimSDKLua.callfunc_queue = {}

--无法同时多次执行的方法排队，
--警告：不是所有的方法都可以排队，如非必要避免使用
function NimSDKLua:CallfuncInQueue(func_id, params_jsonstr, callback)
    if not self.callfunc_queue[func_id] then
        self.callfunc_queue[func_id] = {
            loading = false,
            call_queue = {}
        }
    end

    table.insert(self.callfunc_queue[func_id].call_queue, {
        params_jsonstr = params_jsonstr,
        callback = callback
    })

    self:CallfuncNext(func_id)
end

function NimSDKLua:CallfuncNext(func_id)
    if not self.callfunc_queue[func_id] then return end

    if self.callfunc_queue[func_id].loading then return end
    
    if #self.callfunc_queue[func_id].call_queue == 0 then return end

    self.callfunc_queue[func_id].loading = true

    local temp_dic  = self.callfunc_queue[func_id].call_queue[1]
    table.remove(self.callfunc_queue[func_id].call_queue, 1)

    local params_jsonstr = temp_dic.params_jsonstr
    local callback = temp_dic.callback
    
    NimSDKBridge:getInstance():callFuncFromLua(func_id, params_jsonstr, function(result)
        self.callfunc_queue[func_id].loading = false
        if callback then
            callback(result)
        end

        --UITool.delayTask(0,function()
            self:CallfuncNext(func_id)
        --end
    end)

end


--[[
    登录
    result["login_step"]
    result["res_code"]
    result["relogin"]
    result["retrying"]
]]
function NimSDKLua:Login(accid, token, callback)
    self.account_id = accid

    local data_dic = {
        account = accid,
        password = token
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(1, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)
end

--[[
    登出
    result["res_code"]
]]
function NimSDKLua:Logout(callback)
    local data_dic = {
        logout_type = 1  --1 切换账号 ,2 被踢  3,程序退出  4, 重连操作  目前只支持一种退出方式
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(2, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        self.account_id = nil
        if callback then
            callback(data_res)
        end
    end)
end

--[[
    获取登录状态
]]
function NimSDKLua:GetLoginState()
    local data_res = {}
    NimSDKBridge:getInstance():callFuncFromLua(3, "{}", function(str_result)
        local cjsonsafe = require "cjson.safe"
        data_res = cjsonsafe.decode(str_result)
    end)
    return data_res["login_state"]
end

--[[
    修改玩家名片,按需求设置，可能会有头像用户名签名之类，还有ext
]]
function NimSDKLua:UpdateMyUserNameCard(accid, ext, callback)
    -- 10
    local data_dic = {
        accid = accid,
        ex = ext
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(10, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)

end

function NimSDKLua:GetUserNameCard(accids, callback)
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(11, cjson.encode(accids), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        
        if callback then
            callback(data_res)
        end
    end)
end

function NimSDKLua:GetUserNameCardOnline(accids, callback)
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(12, cjson.encode(accids), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)

        if callback then
            callback(data_res)
        end
    end)
end

--[[
    黑名单信息
    result["res_code"]
    result["black_info_list"][1] = {
        ["accid"] 
        ["set_black"] 
        ["create_timetag"]
        ["update_timetag"]
    }
]]
function NimSDKLua:GetBlackList(callback)
    NimSDKBridge:getInstance():callFuncFromLua(13, "{}", function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)
end

--[[
    添加(删除)黑名单
    result["res_code"]
    result["accid"]
    result["set_opt"]
]]
function NimSDKLua:SetBlack(accid, set_black, callback)
    local data_dic = {
        accid = accid, 
        set_black = set_black
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(14, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)
end

--[[
        result["res_code"] = (int)res_code;
        result["user_profile_list"] = [ "jsonstr" ];
]]
function NimSDKLua:GetFriendList(callback)
    NimSDKBridge:getInstance():callFuncFromLua(20, "{}", function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)

        if callback then
            callback(data_res)
        end
    end)
end

--[[
    请求好友
]]
function NimSDKLua:FriendRequest(accid, verify_type, message, callback)
    --[[
        verify_type
        kNIMVerifyTypeAdd		= 1, /**< 直接加好友 */
        kNIMVerifyTypeAsk		= 2, /**< 请求加好友 */
        kNIMVerifyTypeAgree		= 3, /**< 同意 */
        kNIMVerifyTypeReject	= 4, /**< 拒绝 */
    ]]
    local data_dic = {
        accid = accid, 
        verify_type = verify_type,
        msg = message
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(21, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)
end

--[[
    删除好友
]]
function NimSDKLua:FriendDelete(accid, callback)
    local data_dic = {
        accid = accid
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(22, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)
end

-- case 30:
-- chatroomGetInfoAsync(jsonParams, luaCallback);
-- break;
-- case 31:
-- chatroomGetGetLoginState(jsonParams, luaCallback);
-- break;
function NimSDKLua:ChatroomEnter(room_id, enter_token, nick , avatar)
    local data_dic = {
        room_id = tonumber(room_id),
        request_login_data = enter_token
        
        --后两个是保留参数，暂不使用
        -- ext = {},
        -- notify_ext = {}
    }

    if nick then
        data_dic["nick"] = nick
    end

    if avatar then
        data_dic["avatar"] = avatar
    end

    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(32, cjson.encode(data_dic),nil)

end

function NimSDKLua:ChatroomExit(room_id)
    local data_dic = {
        room_id = tonumber(room_id)
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(33, cjson.encode(data_dic),nil)
end

--[[
    请求聊天室登录token
    result["error_code"] 
    result["enter_token"]
]]
function NimSDKLua:ChatroomRequestToken(room_id, callback)
    local data_dic = {
        room_id = tonumber(room_id)
    }
    local cjson = require "cjson"
    self:CallfuncInQueue(90, cjson.encode(data_dic), function(str_result)
        local cjsonsafe = require "cjson.safe"
        local data_res = cjsonsafe.decode(str_result)
        if callback then
            callback(data_res)
        end
    end)
end

function NimSDKLua:AudioStartCapture()
    local data_dic = {
        audio_format = 0, -- 0 aac ,1 amr
        volume = 0
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(50, cjson.encode(data_dic), nil)
end
function NimSDKLua:AudioStopCapture()
    NimSDKBridge:getInstance():callFuncFromLua(51,nil,nil)
end
function NimSDKLua:AudioCancelCapture()
    NimSDKBridge:getInstance():callFuncFromLua(52,nil,nil)
end
function NimSDKLua:AudioPlayAudio(path)
    local data_dic = {
        audio_format = 0, -- 0 aac ,1 amr
        path = path
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(53, cjson.encode(data_dic), nil)
end

function NimSDKLua:QueryChatroomHistory(room_id, limit_count, msg_types, callback)
    local data_dic = {
        room_id = tonumber(room_id),
        limit_count = limit_count,
        msg_types = msg_types
    }
    local cjson = require "cjson"
    --36  这个固定是在线查询
    NimSDKBridge:getInstance():callFuncFromLua(36, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        --[[

            result["room_id"] = room_id;
            result["error_code"] = error_code;
            result["msg_list"] = msg_lst;
        ]]
        
        if callback then
            callback(data_dic)
        end
    end)

end

function NimSDKLua:QueryMessageByID(msg_id,callback)
    local data_dic = {
        client_msg_id = msg_id
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(81, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        if callback then
            callback(data_dic)
        end
    end)
    
end

function NimSDKLua:QueryMessageHistory(session_id, session_type, limit_count,callback)
    local data_dic = {
        session_id = session_id,
        session_type = session_type,
        limit_count = limit_count
    }
    local cjson = require "cjson"
    -- 80 是本地，82是在线，区别不明
    NimSDKBridge:getInstance():callFuncFromLua(82, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        --[[

            result["res_code"] 
            result["session_id"] 
            result["session_type"] 
            result["msg_count"] 
            result["msg_source"]
            result["msg_list"] = [
                "{xxxx:xxxx}",  --json字符串，需要解析
            ]
        ]]
                
        if callback then
            callback(data_dic)
        end
    end)
end

function NimSDKLua:SendChatroomMessage(room_id, json_msg)
    if json_msg ~= nil and json_msg ~= "" then
        local data_dic = {
            room_id = tonumber(room_id),
            json_msg = json_msg
        }
        local cjson = require "cjson"
        NimSDKBridge:getInstance():callFuncFromLua(35, cjson.encode(data_dic), nil)
    end
end

function NimSDKLua:CreateChatroomCustomMessage(attach_dic, callback)
    local cjson = require "cjson"
    local data_dic = {
        msg_type = 100,   -- 100 自定义消息
        msg_setting = {},
        attach = attach_dic
    }
    NimSDKBridge:getInstance():callFuncFromLua(34, cjson.encode(data_dic), callback)
end
function NimSDKLua:CreateChatroomTextMessage(message, ext, callback)
    local cjson = require "cjson"
    local data_dic = {
        msg_type = 0,   -- 0 文本消息
        msg_setting = {
            ext = ext,
            history_save = false
        },
        content = message
    }
    NimSDKBridge:getInstance():callFuncFromLua(34, cjson.encode(data_dic), callback)
end
function NimSDKLua:CreateChatroomAudioMessage(file_path, duration, ext, callback)
    local cjson = require "cjson"
    local data_dic = {
        msg_type = 2,   -- 2 语音消息
        msg_setting = {
            ext = ext
        },
        file_path = file_path,
        duration = duration
    }
    NimSDKBridge:getInstance():callFuncFromLua(34, cjson.encode(data_dic), callback)
end

function NimSDKLua:SendMessage(json_msg)
    if json_msg ~= nil and json_msg ~= "" then
        NimSDKBridge:getInstance():callFuncFromLua(41, json_msg, nil)
    end
end

function NimSDKLua:CreateCustomMessage(session_id, session_type, attach_dic, callback)
    local data_dic = {
        message_type = 100,   -- 100 自定义消息
        receiver_id = session_id,
        session_type = session_type,
        --content = message,
        --msg_setting = {},  -- 需要的话可以设置
        attach = attach_dic
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(40, cjson.encode(data_dic), callback)
end

function NimSDKLua:CreateTextMessage(session_id, session_type, message, ext, callback)
    local data_dic = {
        message_type = 0,   -- 0 文本消息
        receiver_id = session_id,
        session_type = session_type,
        content = message,
        msg_setting = {
            server_ext = ext
        }
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(40, cjson.encode(data_dic), callback)
end

function NimSDKLua:CreateAudioMessage(session_id, session_type, file_path, duration, ext, callback)
    local data_dic = {
        message_type = 2,   -- 2 语音消息
        receiver_id = session_id,
        session_type = session_type,
        file_path = file_path,
        duration = duration,
        msg_setting = {
            server_ext = ext,
            cloud_history = 0
        }
    }
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(40, cjson.encode(data_dic), callback)
end

function NimSDKLua:SubscribeEvent(event_type, ttl, accid_list, callback)
    local data_dic = {
        event_type = event_type,
        ttl = ttl,
        sync_type = 1,
        accid_list = accid_list
    }

    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(60, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        if callback then
            callback(data_dic)
        end
    end)
end

function NimSDKLua:UnSubscribeEvent(event_type, accid_list, callback)
    local data_dic = {
        event_type = event_type,
        accid_list = accid_list
    }
    
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(61, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        if callback then
            callback(data_dic)
        end
    end)
end

function NimSDKLua:QuerySubscribeEvent(event_type, accid_list, callback)
    local data_dic = {
        event_type = event_type,
        accid_list = accid_list
    }
    
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(62, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        if callback then
            callback(data_dic)
        end
    end)
end


function NimSDKLua:SystemMsgQueryList(limit,callback)
    local data_dic = {
        limit_count = limit,
        last_time = 0
    }
    
    local cjson = require "cjson"
    NimSDKBridge:getInstance():callFuncFromLua(70,  cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        if callback then
            callback(data_dic)
        end
    end)
end

function NimSDKLua:SystemMsgUnreadCount(callback)
    NimSDKBridge:getInstance():callFuncFromLua(71,  nil, function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        -- result["res_code"] = (int)res_code;
        -- result["unread_count"] = unread_count;
        if callback then
            callback(data_dic)
        end
    end)
end

function NimSDKLua:SystemRemoveById(msg_id, callback)
    local data_dic = {
        msg_id = msg_id
    }
    local cjson = require "cjson"

    self:CallfuncInQueue(72, cjson.encode(data_dic), function(result)
        local cjsonsafe = require "cjson.safe"
        local data_dic = cjsonsafe.decode(result)
        -- result["res_code"] = (int)res_code;
        -- result["unread_count"] = unread_count;
        if callback then
            callback(data_dic)
        end
    end)
end

--核心回调函数
function NimSDKLuaCallback(callback_id, jsonParams)
    --[[
        回调ID对应的详情
    ]]
    local cjsonsafe = require "cjson.safe"
    local data_dic = cjsonsafe.decode(jsonParams)
    if callback_id == 1030 then
        --[[
            NimSDKBridge::nimChatroomEnterCallback

            result["room_id"] = room_id;
            result["step"] = (int)step;
            result["error_code"] = error_code;
            result["room_info"] = info.ToJsonString();
            result["my_info"] = my_info.ToJsonString();
        ]]
                
        XBChatPlatform:getInstance():ChatroomLoginSuccess(data_dic)
    elseif callback_id == 1033 then
        --[[
            NimSDKBridge::nimChatroomExitCallback

            Json::Value result;
            Json::FastWriter writer;
            result["room_id"] = room_id;
            result["error_code"] = error_code;
            result["exit_reason"] = (int)exit_reason;
        ]]
                        
        XBChatPlatform:getInstance():ChatroomExitSuccess(data_dic)
    elseif callback_id == 1031 then
        -- result["room_id"] = room_id;
        -- result["message"]

        XBChatPlatform:getInstance():ChatroomRecvMessage(data_dic)
    elseif callback_id == 1040 then
        --收到单条消息
        XBChatPlatform:getInstance():FriendRecvMessage({data_dic})
    elseif callback_id == 1041 then
        --收到多条消息
        XBChatPlatform:getInstance():FriendRecvMessage(data_dic)        
    elseif callback_id == 1032 then
        --聊天室回执
        XBChatPlatform:getInstance():ChatroomMessageSent(data_dic)
    elseif callback_id == 1042 then
        --好友消息回执
        XBChatPlatform:getInstance():FriendMessageSent(data_dic)
    elseif callback_id == 1020 then
        --好友变更   这个是废的，傻逼网易
        -- result["event_type"] = (int)change_event.type_;
        -- result["res_code"] = 500;
        
        -- //    kNIMFriendChangeTypeRequest        = 1, /**< 加好友/处理好友请求 */
        -- //    kNIMFriendChangeTypeDel            = 2, /**< 删除好友 */
        -- //    kNIMFriendChangeTypeUpdate        = 3, /**< 更新好友 */
        -- //    kNIMFriendChangeTypeSyncList    = 5, /**< 好友列表同步与更新 */  为什么是5？
        if data_dic["res_code"] ~= 200 then return end

        if data_dic["event_type"] == 1 then
            -- data_dic["accid"]
            -- data_dic["add_type"]
            -- kNIMVerifyTypeAdd		= 1, /**< 直接加好友 */
            -- kNIMVerifyTypeAsk		= 2, /**< 请求加好友 */
            -- kNIMVerifyTypeAgree		= 3, /**< 同意 */
            -- kNIMVerifyTypeReject	= 4, /**< 拒绝 */
            -- data_dic["msg"]
            if data_dic["add_type"] == 3 then
                NIMSendCustomEvent(EEventType.CHAT_ON_FRIEND_CHANGE, { data_dic["accid"] })
            end
        elseif data_dic["event_type"] == 2 then
            NIMSendCustomEvent(EEventType.CHAT_ON_FRIEND_CHANGE, { data_dic["accid"] })
        elseif data_dic["event_type"] == 3 then
        elseif data_dic["event_type"] == 5 then
        end
    elseif callback_id == 1070 then
        --收到系统消息  主要是好友消息
        XBChatPlatform:getInstance():SystemNotificationRecv(data_dic)
    elseif callback_id == 1051 then
        --语音录制完成
        XBChatPlatform:getInstance():OnCaptureStoped(data_dic)
    end
end
