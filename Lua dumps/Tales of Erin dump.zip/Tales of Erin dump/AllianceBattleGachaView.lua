--require "XUIView"

AllianceBattleGachaView = class("AllianceBattleGachaView" , XUIView)
AllianceBattleGachaView.CS_FILE_NAME = "AllianceBattleGachaView.csb"
AllianceBattleGachaView.CS_BIND_TABLE = 
{
    btnClose = "/i:17/i:92",
    panelList = "/i:3/i:21",
    btnReset = "/i:3/i:6",
    numCoin = "/i:3/i:9",
    btnGa1 = "/i:3/i:10",
    btnGa1Num = "/i:3/i:10/i:15",
    btnGa1Text = "/i:3/i:10/i:14",
    btnGa10 = "/i:3/i:11",
    btnGa10Num = "/i:3/i:11/i:13",
    btnGa10Text = "/i:3/i:11/i:12",
    lbTitle = "/i:3/i:41",
}

AllianceBattleGachaView.ITEM_CS_FILE_NAME = "Act2GachaItemView.csb"
AllianceBattleGachaView.ITEM_CS_BIND_TABLE = {
    bgImg1 = "/i:24/i:25",
    bgImg2 = "/i:24/i:26",
    imgBG = "/i:24/i:38/s:imgBG",
    imgFace = "/i:24/i:38/s:imgFace",
    imgRarity = "/i:24/i:38/s:imgRarity",
    imgElement = "/i:24/i:38/s:imgElement",
    lbNum = "/i:24/i:38/s:lbNum",
    lbTitle = "/i:24/i:45",
    lbDesc = "/i:24/i:46",
    numCnt = "/i:24/i:48",
    numSlash = "/i:24/i:49",
    numMax = "/i:24/i:50",
}

function AllianceBattleGachaView:create(rData)
     local login     = AllianceBattleGachaView.new()
     login.rData     = rData
     login.sManager  = login.rData["sManager"]
     --login.nWarid    = login.rData["war_id"]
     self.nWarid = login.rData["war_id"]
     login:init()
     

     return login

end

function AllianceBattleGachaView:init()
    AllianceBattleGachaView.super.init(self)
    self:loadData()

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,374,126)
    self.gridview.itemCreateEvent = function()     ----创建Item
        local temp = XUICellView.new():init(nil,AllianceBattleGachaView.ITEM_CS_FILE_NAME,AllianceBattleGachaView.ITEM_CS_BIND_TABLE)
        temp.onResetData = function(self)
            local data = self._data

            if data.key_item == 1 then
                self.bgImg1:setVisible(false)
                self.bgImg2:setVisible(true)
            else
                self.bgImg1:setVisible(true)
                self.bgImg2:setVisible(false)
            end

            local info = UITool.getItemInfos(data.item_type,data.item_id)

            if data.item_num > 1 then
                self.lbNum:setString("x"..data.item_num)
            else
                self.lbNum:setString("")
            end

            self.imgBG:setTexture(info[4])
            self.imgRarity:setTexture(info[1])
            self.imgFace:setTexture(info[2])

            if info[3] ~= nil and string.len(info[3]) > 0 then
                self.imgElement:setVisible(true)
                self.imgElement:setTexture(info[3])
            else
                self.imgElement:setVisible(false)
            end

            self.lbTitle:setString(info[5])
            if g_channel_control.transform_AllianceBattleGachaView_lbTitle_Text_fontSize == true then
                local oldFontSize = 24
                local newFontSize = oldFontSize - 4
                self.lbTitle:setFontSize(newFontSize)
            end

            if g_channel_control.transform_AllianceBattleGachaView_ItemTitleFont == true then 
                self.lbTitle:setFontSize(22)
            end 

            self.lbDesc:setString(UITool.ToLocalization("库存: ")..data.now_num)

            self.numMax:setVisible(false)
            self.numSlash:setVisible(false)
            self.numCnt:setVisible(false)
            
            -- self.numMax:setString(data.total_num)
            -- self.numCnt:setString(data.now_num)

            -- if data.now_num <= 0 then
            --     self.numCnt:setTextColor(cc.c3b(255,46,46))
            -- else
            --     self.numCnt:setTextColor(cc.c3b(0,212,85))
            -- end

        end

        return temp
    end
    self.gridview.itemClickedEvent = function (sender,index)
        local data = self.item_list[index]
        --GameManagerInst:alert(data.item_id)
        if data.item_num > 1 then
            MsgManager:showSimpItemInfo(data.item_type,data.item_id,data.item_num)
        else
            MsgManager:showSimpItemInfo(data.item_type,data.item_id)
        end
    end

    self.btnReset:addClickEventListener(function()

        local  function callfuncForOK()
               self:resetPool()
        end
        local  function cancelFunc()
               print( "用户取消重置" )
        end
        
        MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("重置卡池将无法获得剩余的物品，是否确认重置？"),self,callfuncForOK,cancelFunc)
        
    end)

    self.btnGa1:addClickEventListener(function()
        self:btnGacha(1)
    end)

    self.btnGa10:addClickEventListener(function()
        self:btnGacha(2)
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    self:refresh()

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return  self
end

function AllianceBattleGachaView:refresh()
    if self.item_list then
        local percent = self.gridview:getCurrentPercent()
        self.gridview:setDataSource(self.item_list)
        self.gridview:jumpToPercent(percent)
        local poollast = self.lot_num_max - self.lot_num
        self.lbTitle:setString(""..self.pool_num)
        self.numCoin:setString(""..self.act_arms)

        -- self.btnGa1Num:setString(""..self.act_arms_use)
        -- self.btnGa1Text:setString("")

        local n1 = math.floor(self.act_arms / self.act_arms_use)
        local n1 = math.min(n1,10)
        local n1 = math.min(n1,poollast)
        --local cnnumbers = {"一","二","三","四","五","六","七","八","九","十"}
        if n1 < 1 then
            self.btnGa1:setTouchEnabled(false)
            self.btnGa1:setBright(false)
            self.btnGa1Num:setString("")
            self.btnGa1Text:setString(UITool.ToLocalization("无法抽取"))

            self.btnGa10:setTouchEnabled(false)
            self.btnGa10:setBright(false)
            self.btnGa10Num:setString("")
            self.btnGa10Text:setString(UITool.ToLocalization("无法抽取"))
        else
            self.btnGa1:setTouchEnabled(true)
            self.btnGa1:setBright(true)
            self.btnGa1Num:setString(""..self.act_arms_use)
            self.btnGa1Text:setString(UITool.ToLocalization("抽取1次"))

            self.btnGa10:setTouchEnabled(true)
            self.btnGa10:setBright(true)
            self.btnGa10Num:setString(""..(self.act_arms_use * n1))
            local str = string.format(UITool.ToLocalization("抽取%d次"), n1)
            self.btnGa10Text:setString(str)
        end

        self.gacha10_num = n1

        if self.can_reset == 1 then
            self.btnReset:setTouchEnabled(true)
            self.btnReset:setBright(true)
        else
            self.btnReset:setTouchEnabled(false)
            self.btnReset:setBright(false)
        end
    else
        self.lbTitle:setString("")
        self.numCoin:setString("0")
        self.gridview:setDataSource({})
        
        self.btnGa1:setTouchEnabled(false)
        self.btnGa1:setBright(false)
        self.btnGa1Num:setString("")
        self.btnGa1Text:setString("")

        self.btnGa10:setTouchEnabled(false)
        self.btnGa10:setBright(false)
        self.btnGa10Num:setString("")
        self.btnGa10Text:setString("")

        self.btnReset:setTouchEnabled(false)
        self.btnReset:setBright(false)
    end
end
--[[
        "act_arms":1000,#奖章个数
        "act_arms_use":150,#卡池消耗纹章的个数
        "can_reset":0,# 当前是否可以重置
        "lot_num":0,# 当前抽卡次数
        "lot_num_max":0,# 卡池总量
        "item_list": [
        {
            "id": 11,  # id
            "item_type": 2, # 道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
            "item_id":1 ,#物品id
            "item_num":1 ,#物品堆积数量
            "total_num":1,   # 总数量
             "now_num":1,   # 当前剩余数量
             "key_item":1,   # 是否是关键道具
        },
]]

function AllianceBattleGachaView:newData(data)
    user_info["gem"] = data["resource"]["gem"]
    user_info["gem_r"] = data["resource"]["gem_r"]
    user_info["beryl"] = data["resource"]["beryl"]
    user_info["gold"] = data["resource"]["gold"]

    self.act_arms = data["act_arms"]
    self.act_arms_use = data["act_arms_use"]
    self.can_reset = data["can_reset"]
    self.lot_num = data["lot_num"]
    self.lot_num_max = data["lot_num_max"]
    self.pool_num = data["pool_num"]

    self.item_list = table.deepcopy(data["item_list"])

    table.sort(self.item_list,function(x,y)
        if x.key_item ~= y.key_item then
            return x.key_item > y.key_item
        else
            return x.id < y.id
        end
    end)
end

function AllianceBattleGachaView:loadData()
    local tempData = { 
        rpc = "guildbattle_lottery_list",
        gb_id = tonumber(self.nWarid),
        }

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            self:newData(data)
            SceneManager.menuLayer:RefshTopBar()
            self:refresh()
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
        true)
end


function AllianceBattleGachaView:btnGacha(idx)
    if not self.item_list then return end

    local tempdata ={
        rpc = "guildbattle_lottery_draw",
        gb_id = tonumber(self.nWarid),
    }

    if idx == 1 then
        --1
        tempdata.lotto_num = 1
    elseif idx == 2 then
        --10
        tempdata.lotto_num = self.gacha10_num or 10
    else
        return
    end


    GameManagerInst:rpc(tempdata,
        3,
        function(data)
            --success
            -- data["resource"]["beryl"] = data["resource"]["beryl"] or 0
            -- local berylAdd = data["resource"]["beryl"] - self.cntBeryl
                        
            -- user_info["gem"] = self.cntGem
            -- user_info["beryl"] = self.cntBeryl
            
            local getdata = data["get"]

            if GameManagerInst.gameType == 2 then
                SceneManager:toDrawCardEndLayer({   itemList = getdata,
                                                    berylNum = nil,
                                                    finalFunc = function()
                                                        NoticeManager:startNotice()
                                                        self:loadData()
                                                    end
                                                    })
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
        end,
        true)
end

function AllianceBattleGachaView:resetPool()
    if not self.can_reset then return end

    if self.can_reset == 1 then
        local tempData = { 
            rpc = "guildbattle_lottery_reset",
            gb_id = tonumber(self.nWarid),
            }

        GameManagerInst:rpc(tempData,
            3,
            function(data)
                --success
                self:newData(data)
                SceneManager.menuLayer:RefshTopBar()
                self:refresh()
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText)
            end,
            true)
    else
        GameManagerInst:alert(UITool.ToLocalization("当前无法重置"))
    end
end

function AllianceBattleGachaView:onNavigateTo(isback)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    else
        self:loadData()
    end
end

function AllianceBattleGachaView:onNavigateFrom(isback)
end

function AllianceBattleGachaView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)

    if self._navigationView then
        self._navigationView:popView()
    end
end
