--require "XUIView"
--星盘加点首次弹窗
AstrolabeLockBoxLayer = class("AstrolabeLockBoxLayer",XUIView)
AstrolabeLockBoxLayer.CS_FILE_NAME = "AstrolabeLockBoxLayer.csb"
AstrolabeLockBoxLayer.CS_BIND_TABLE = 
{ 
    panle     = "/s:Panel_lockBox",
    imgBg     = "/s:Panel_lockBox/s:Image_bg",
    --图标
    icon      = "/s:Panel_lockBox/s:Image_bg/s:Image_icon",
    --技能名称
    skName    = "/s:Panel_lockBox/s:Image_bg/s:Text_name",
    --当前加点数量
    num       = "/s:Panel_lockBox/s:Image_bg/s:Text_num",
    --描述
    dec       = "/s:Panel_lockBox/s:Image_bg/s:Text_des",
    --解锁条件
    text1  = "/s:Panel_lockBox/s:Image_bg/s:Text_des_1",
    --自身条件最多显示两条
    text2  = "/s:Panel_lockBox/s:Image_bg/s:Text_des_2",
    text3  = "/s:Panel_lockBox/s:Image_bg/s:Text_des_3",
    --所需点数
    textPoint = "/s:Panel_lockBox/s:Image_bg/s:Text_point",
    --提升按钮
    upBtn     = "/s:Panel_lockBox/s:Image_bg/s:Button_2", 

}

function AstrolabeLockBoxLayer:init()
    AstrolabeLockBoxLayer.super.init(self)
    --公用弹窗
    self.panle:addClickEventListener(function(sender, eventType)  
        self:returnBack()
    end)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

function AstrolabeLockBoxLayer:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function AstrolabeLockBoxLayer:loadData(imageChild,baseSelf,Pself,hero_id)
    local name    = imageChild:getName()
    self.baseSelf = baseSelf
    self.Pself    = Pself
    self.hero_sub_id = getNumID(hero_id)
    --新盘Id
    local id   = tonumber(UITool.SubStringToInt( name,"_",2))

    --本地数据
    local curOnlyT  = self.baseSelf:getOnlyData(id)
    --技能表
    local skillTable = astrolabe_skill[self.hero_sub_id][curOnlyT["star_sk_id"]]
    --技能图标
    self.icon:loadTexture(skillTable["icon_checked"])

    --技能名称

    self.skName:setString(UITool.getUserLanguage(skillTable["name"]))

    --显示自己的加点
    local svLv  = self.baseSelf.serverData["stars"][tostring(id)]
    self.num:setString("【"..svLv.."/"..skillTable["max_lv"].."】")
    --描述
    local str3      = tonumber(svLv)*skillTable["prop_num"]
    local fvluae    = string.format("%.1f", str3)
    local str = string.format(UITool.getUserLanguage(skillTable["desc"]), fvluae)
    
    self.dec:setString(str)
    --解锁前置条件 根据是否达成显示颜色
    local isOk = self:getOrAndBool(curOnlyT,id)
    if isOk then
        self.text1:setColor(cc.c3b(184, 184, 184))
    else
        self.text1:setColor(cc.c3b(255, 0, 0))
    end
    --自身解锁条件 最多显示两条 多余的不处理
    local testTbab = self:asbLockStr(curOnlyT["star_unlock"])
    local tabLen = table_leng(testTbab)
    if tabLen > 0 then
        if tabLen == 1 then
            self.text2:setString(testTbab[1]["str"])
            self.text2:setColor(testTbab[1]["color"])
            self.text2:setVisible(true)
            self.text3:setVisible(false)
        elseif tabLen == 2 then
            self.text2:setVisible(true)
            self.text3:setVisible(true)
            self.text2:setString(testTbab[1]["str"])
            self.text2:setColor(testTbab[1]["color"])
            self.text3:setString(testTbab[2]["str"])
            self.text3:setColor(testTbab[2]["color"])
        end
    else
        self.text2:setVisible(false)
        self.text3:setVisible(false)
    end


    --升级一点所需点数
    if skillTable["asp_cost"] > self.baseSelf.rcvData["astrolabe"]["asp_left"] then
        self.textPoint:setColor(cc.c3b(255, 0, 0))
    else
        self.textPoint:setColor(cc.c3b(44, 238, 44))
    end
     self.textPoint:setString(skillTable["asp_cost"])

    if g_channel_control.transform_AstrolabeLockBoxLayer_textPoint_pos == true then 
        self.textPoint:setPosition(154,54)
    end 

    --技能点升满级提升按钮置灰
    if svLv >= skillTable["max_lv"] then
        self.upBtn:setTouchEnabled(false)
        self.upBtn:setBright(false)
        self.textPoint:setString("0")
        self.textPoint:setColor(cc.c3b(255, 255, 255))
    else
        self.upBtn:setTouchEnabled(true)
        self.upBtn:setBright(true)
    end



end
--获得或与与的条件是否双向达成
function AstrolabeLockBoxLayer:getOrAndBool(curOnlyT,_id)   
    --或的前置解锁条件
    local orTable  = curOnlyT["star_unlock_tree"]
    local orLen    = #orTable
    local onlySvLv =  self.baseSelf.serverData["stars"][tostring(_id)]    
    -- 如果orLen等于零代表不需要前置解锁条件(需要根据自身等级显示图片)
    print("orLen orLen == "..orLen)
    if orLen == 0 then
            return true
    end
    --需要前置解锁条件的
    -- 循环取出前置的解锁条件
    -- 跟服务器对比前置条件是否达成 前置是或的关系达成
    -- 因为是或的关系 又个达成就可以
    local isBool = false
    for i = 1 , orLen do
        local c_id    = orTable[i]["star_id"]
        local c_lv    = orTable[i]["star_lv"]
        local c_svLv  = self.baseSelf.serverData["stars"][tostring(c_id)] 
        if c_svLv >= c_lv then
             isBool = true
        --else
          --  return false
        end
    end 
    return isBool
end
--多属性的判断 注视调预留 以防后期改回来   看看才几天就改回来了
function AstrolabeLockBoxLayer:asbLockStr( _tabel )
 -- body
 local andTable = _tabel
 local index = 0
 local strTable = {}
 if  andTable.hero_lv  > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_lv,andTable.hero_lv)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2000]),andTable.hero_lv)
 end
 if andTable.hero_add > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_add,andTable.hero_add)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2001]),andTable.hero_add)
 end
 if andTable.feeling_lv > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.feeling_lv,andTable.feeling_lv)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2002]),andTable.feeling_lv)
 end
 if andTable.soul_lv > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.soul_lv,andTable.soul_lv)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2003]),andTable.soul_lv)
 end
 if andTable.astro_lv > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.rcvData["astrolabe"]["lv"],andTable.astro_lv)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2004]),andTable.astro_lv)
 end
 if andTable.hero_sk_add > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_sk_add,andTable.hero_sk_add)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2005]),andTable.hero_sk_add)
 end
 if andTable.astro_sk_add > 0 then
     index = index+1
     strTable[index] = {}
     strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.rcvData["astrolabe"]["used_items"],andTable.astro_sk_add)
     strTable[index]["str"] = string.format(UITool.getUserLanguage(desc_info[2006]),andTable.astro_sk_add)
 end
 return strTable
 
end
function AstrolabeLockBoxLayer:scalGetTextColor( a,b )
    -- body
    if a < b then
        return cc.c3b(255, 0, 0)
    else
        return cc.c3b(184, 184, 184)
    end
end
