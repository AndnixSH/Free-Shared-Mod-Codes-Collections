--战场信息
--created by kobejaw.2018.7.27
BattleRuntimeInfo = {}

--全局变量begin
G_IsInBattle = false;
G_GameState = 1; --0loading中。1.正常状态 2.开场动画中+切换场景跑动时。3.大招cutin中（cd不停止，其他停止） 4.暂停中（包括有弹窗的时候和神格技能视频播放的时候 5.战斗结束
G_STAGE_TYPE = 1;--全局变量，C++在收到战斗开始的协议时赋值。--0新手引导。1普通关卡 2多人战斗 3爬塔 .4PVP
G_IsMultiBattleWin = false  --多人战是否已经胜利。
G_IsAllDead = false --我方全体死亡

G_Roles = {};
G_Monsters = {};

G_NodesWithAction = {} --所有正在播放某个action的node的管理。用于cutin的时候暂停和继续。node:pause(),node:resume()
G_NodesWithSpine = {} --所有正在播放某个spine的node的管理。用于cutin的时候暂停和继续。node:pause(),node:resume()

G_BattleScene = nil;
G_BattleLayer = nil;
G_EntityLayer = nil;
G_EffectLayer = nil;--技能特效所在的层
G_BattleContainerLayer = nil;
G_BattleUILayer = nil;

G_IsJoinAgain = false; --多人战暂时撤退后，在此加入游戏。

G_EntityPlayingCutin = nil; --正在播放cutin的entity
--全局变量end

function BattleRuntimeInfo:init()
	G_IsInBattle = true
	G_Roles = {};
	G_Monsters = {};
	G_GameState = 2
	G_NodesWithAction = {}
	G_NodesWithSpine = {}
	G_EntityPlayingCutin = nil;

	self.teams = {}

	self.team1EntityNum = nil
	self.team2EntityNum = nil

	self.currentWaveNum = 1  --当前第几波
	self.totalWaveNum = #BattleDataManager.wavesArray  --总波数

	self.isMusicOn = true
	self.isSoundOn = true

	--多人战相关
	if G_STAGE_TYPE == 2 then
		self.isMulti = true--是否是多人战的boss。如果是，每2秒发送一次数据。
		self.isFirstSend = false --是否是第一次发送消息
		self.timeForMultiMsg = 2;

		self.sharedBossDebuff = {}  --团战共享的boss身上的debuff。

		self.msgData = {}
		self.msgData.multi_id = BattleDataManager.battleId
		self.msgData.dmgForMulti = 0; --2秒内对boss造成的总伤害
		self.msgData.bkForMulti = 0   --2秒内对boss的bk槽造成的总伤害
		self.msgData.odForMulti = 0   --2秒内对boss的od槽造成的总伤害
		self.msgData.buff_list = {}   --2秒内新增的团队共享的buff
		self.msgData.dmg_list = {} --这个字段暂时不用。
	end
end

function BattleRuntimeInfo:setTeam1Num(num)
	self.team1EntityNum = num
	if G_STAGE_TYPE == 2 then
		self.msgData.hero_num = num
		self.hero_num = num
	end
end

function BattleRuntimeInfo:update(dt)
	if self.isMulti then
		self.timeForMultiMsg = self.timeForMultiMsg - dt
		if self.timeForMultiMsg <= 0 then
			self.timeForMultiMsg = 2
			self:sendMsg()
		end
	end
end

--复活的时候调用一下
function BattleRuntimeInfo:onRevive()
end

--注：buff的生命周期前端管理，debuff的生命周期后端管理。

--刷新共享buff
function BattleRuntimeInfo:refreshSharedBuff(buffList)
	if type(buffList) ~= "table" then
		return
	end

	for k,v in pairs(buffList) do
	    --buffList[v.id] = v.buff_lv
	    ComponentCreator:createMultiBuff(v.id,v.buff_lv)
	end
end

--刷新boss身上的共享debuff
function BattleRuntimeInfo:refreshSharedDebuff(debuffList)
	if G_Monsters[1].isDead then
		return
	end

	--添加新的或者用更高级的替换低级的
	for id,lv in pairs(debuffList) do
		if not self.sharedBossDebuff[id] then
			ComponentCreator:createMultiDebuff(id,lv)
		elseif self.sharedBossDebuff[id] < lv then
			--删除旧的
			G_Monsters[1].componentManager:removeByComId(id) 
			--创建新的
			ComponentCreator:createMultiDebuff(id,lv)
		end
	end

	--删除不再存在的
	for id,lv in pairs(self.sharedBossDebuff) do
		if not debuffList[id] then
			G_Monsters[1].componentManager:removeByComId(id) 
		end
	end

	--同步sharedBossDebuff中的信息
	self.sharedBossDebuff = debuffList
end

function BattleRuntimeInfo:sendMsg()
	if G_IsMultiBattleWin then
		return
	end	

    if not self.isFirstSend then
		if self.hero_num == self.team1EntityNum then
			self.msgData.hero_num = -1
		else
			self.msgData.hero_num = self.team1EntityNum
			self.hero_num = self.team1EntityNum
		end
	end

	MutableBattleManager:sendMultiData(self.msgData)

	self.msgData.dmgForMulti = 0
	self.msgData.bkForMulti = 0
	self.msgData.odForMulti = 0
	self.msgData.buff_list = {}
	self.isFirstSend = false
end

function BattleRuntimeInfo:onReceiveMsg(data)
    --刷新角色buff数据。
    if data.buff and #data.buff > 0 then
	    self:refreshSharedBuff(data.buff)
	end
    
    BattleUIManager:showRanking(data["gx_rank"]) -- 刷新rank信息
    BattleUIManager:showAddMembers(data["add_members"]) --刷新有新角色入场等信息

	--刷新boss数据
	local monsterData = data.monster_mul[1]
	if monsterData then
		--血条
		if monsterData.hp then
			G_Monsters[1].attributeManager:setHPForMultiBoss(tonumber(monsterData.hp))
		end
		--ODBK槽
		G_Monsters[1]:refreshStateBarForMulti(monsterData)
		--boss身上的debuff
		local debuffList = {}
		if monsterData.debuff then
			if #monsterData.debuff > 0 then
				for k,v in pairs(monsterData.debuff) do
					debuffList[v.id] = v.debuff_lv
				end
			end
		end
		self:refreshSharedDebuff(debuffList)
	end
end

function BattleRuntimeInfo:clear()
	self.teams = {}
	G_Roles = {};
	G_Monsters = {};
	G_NodesWithAction = {}
	G_NodesWithSpine = {}
	if G_STAGE_TYPE == 2 then
		self.sharedBossDebuff = {}
		self.msgData = {}		
	end

	G_BattleScene = nil;
	G_BattleLayer = nil;
	G_EntityLayer = nil;
	G_EffectLayer = nil;--技能特效所在的层
	G_BattleContainerLayer = nil;
	G_BattleUILayer = nil;
	G_IsInBattle = false;
end