shakeSkill = {} 
shakeSkill[1] = {
   {shake_mode = 1,--震动的模式
    shake_t = 40,
    shake_x = 0,--持续的次数
    shake_y = -6,--等待的时间,乘以100
    shake_z = 0,
   },
   {shake_mode = 1,--震动的模式
       shake_t = 40,
       shake_x = 0,--持续的次数
       shake_y = 0,--等待的时间,乘以100
       shake_z = 0,
   }
}
shakeSkill[2] = {
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = -15,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 5,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = -10,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 4,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 0,--等待的时间,乘以100
        shake_z = 0,
    }
}
shakeSkill[3] = {
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 30,--持续的次数
        shake_y = -40,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 20,--持续的次数
        shake_y = 15,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = -10,--持续的次数
        shake_y = -30,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = -10,--持续的次数
        shake_y = 5,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = -15,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 5,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 0,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 3,--等待的时间,乘以100
        shake_z = 0,
    },
    {shake_mode = 1,--震动的模式
        shake_t = 40,
        shake_x = 0,--持续的次数
        shake_y = 0,--等待的时间,乘以100
        shake_z = 0,
    }
}
