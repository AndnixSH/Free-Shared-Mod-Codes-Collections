-- 星盘顶级天赋图标定义

astrolabe_climax = {}

astrolabe_climax[1] = {}
astrolabe_climax[1][1] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_006c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_006c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_006a.png",
    name = "50015",
    desc = "50064",
}

astrolabe_climax[2] = {}
astrolabe_climax[2][7000130] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50016",
    desc = "50065",
}
astrolabe_climax[2][7000135] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50017",
    desc = "50066",
}
astrolabe_climax[2][7000140] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50018",
    desc = "50067",
}
astrolabe_climax[2][7000145] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50019",
    desc = "50068",
}
astrolabe_climax[2][7000148] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50020",
    desc = "50069",
}
astrolabe_climax[2][7000150] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50021",
    desc = "50070",
}
astrolabe_climax[2][7000155] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_007c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_007a.png",
    name = "50022",
    desc = "50071",
}
astrolabe_climax[2][7000230] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50023",
    desc = "50072",
}
astrolabe_climax[2][7000235] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50024",
    desc = "50073",
}
astrolabe_climax[2][7000240] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50025",
    desc = "50074",
}
astrolabe_climax[2][7000245] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50026",
    desc = "50075",
}
astrolabe_climax[2][7000248] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50027",
    desc = "50076",
}
astrolabe_climax[2][7000250] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50028",
    desc = "50077",
}
astrolabe_climax[2][7000255] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_008c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_008a.png",
    name = "50029",
    desc = "50078",
}
astrolabe_climax[2][7000330] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50030",
    desc = "50079",
}
astrolabe_climax[2][7000335] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50031",
    desc = "50080",
}
astrolabe_climax[2][7000340] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50032",
    desc = "50081",
}
astrolabe_climax[2][7000345] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50033",
    desc = "50082",
}
astrolabe_climax[2][7000348] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50034",
    desc = "50083",
}
astrolabe_climax[2][7000350] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50035",
    desc = "50084",
}
astrolabe_climax[2][7000355] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_010c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_010a.png",
    name = "50036",
    desc = "50085",
}
astrolabe_climax[2][7000430] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50037",
    desc = "50086",
}
astrolabe_climax[2][7000435] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50038",
    desc = "50087",
}
astrolabe_climax[2][7000440] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50039",
    desc = "50088",
}
astrolabe_climax[2][7000445] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50040",
    desc = "50089",
}
astrolabe_climax[2][7000448] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50041",
    desc = "50090",
}
astrolabe_climax[2][7000450] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50042",
    desc = "50091",
}
astrolabe_climax[2][7000455] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_009c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_009a.png",
    name = "50043",
    desc = "50092",
}
astrolabe_climax[2][7000530] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50044",
    desc = "50093",
}
astrolabe_climax[2][7000535] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50045",
    desc = "50094",
}
astrolabe_climax[2][7000540] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50046",
    desc = "50095",
}
astrolabe_climax[2][7000545] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50047",
    desc = "50096",
}
astrolabe_climax[2][7000548] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50048",
    desc = "50097",
}
astrolabe_climax[2][7000550] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50049",
    desc = "50098",
}
astrolabe_climax[2][7000555] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_012c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_012a.png",
    name = "50050",
    desc = "50099",
}
astrolabe_climax[2][7000630] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50051",
    desc = "50100",
}
astrolabe_climax[2][7000635] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50052",
    desc = "50101",
}
astrolabe_climax[2][7000640] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50053",
    desc = "50102",
}
astrolabe_climax[2][7000645] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50054",
    desc = "50103",
}
astrolabe_climax[2][7000648] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50055",
    desc = "50104",
}
astrolabe_climax[2][7000650] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50056",
    desc = "50105",
}
astrolabe_climax[2][7000655] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_011c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_011a.png",
    name = "50057",
    desc = "50106",
}
astrolabe_climax[2][7384001] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_384c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_384c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_384a.png",
    name = "50058",
    desc = "50107",
}
astrolabe_climax[2][7364001] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_364c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_364c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_364a.png",
    name = "50059",
    desc = "50108",
}
astrolabe_climax[2][7362001] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_362c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_362c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_362a.png",
    name = "50060",
    desc = "50109",
}
astrolabe_climax[2][7412001] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_412c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_412c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_412a.png",
    name = "50061",
    desc = "50110",
}
astrolabe_climax[2][7375001] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_375c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_375c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_375a.png",
    name = "50062",
    desc = "50111",
}
astrolabe_climax[2][7378001] = {
    icon_locked = "res/uifile/n_UIShare/astrolabe/xp_b_378c.png",
    icon_unlock = "res/uifile/n_UIShare/astrolabe/xp_b_378c.png",
    icon_checked = "res/uifile/n_UIShare/astrolabe/xp_b_378a.png",
    name = "50063",
    desc = "50112",
}
