purchase = {}
--[[
	api:   fast_trade_buy 				
	param: fast_trade_id
]]--

-- 向服务器发送购买信息
function purchase:ItemBuy( callfunc,fast_trade_id,n_num)
    -- body
    local function reiceSthCallBack(data)
        print("purchase购买")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        SceneManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
    	if callfunc then
    		callfunc(t_data)
    	end

        --self:Send()
        --self.ShopTabe = t_data["data"]["good"]
    end

    local cjson = require "cjson"
    SceneManager:createWaitLayer()
    local tempTable = {
        ["rpc"]             = "fast_trade_buy",
        ["fast_trade_id"]   = fast_trade_id,
        ["buy_num"]         = n_num
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
    

end