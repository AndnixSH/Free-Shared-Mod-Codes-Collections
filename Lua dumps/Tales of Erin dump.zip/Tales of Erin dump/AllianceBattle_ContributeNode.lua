

AllianceBattle_ContributeNode = class("AllianceBattle_ContributeNode", XUICellView)
AllianceBattle_ContributeNode.CS_FILE_NAME = "AllianceBattle_ContributeNode.csb"
AllianceBattle_ContributeNode.skeletonNode = nil
AllianceBattle_ContributeNode.GuildMemberIndex = 1;
AllianceBattle_ContributeNode.OnSelf = nil;
AllianceBattle_ContributeNode.DataTest = nil;
AllianceBattle_ContributeNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}

function AllianceBattle_ContributeNode:init(...)
    self.skeletonNode = nil
    AllianceBattle_ContributeNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    return self
end
function AllianceBattle_ContributeNode:setType(_type)
    -- body

end
--/*时间转换成 什么什么 以前*/
function AllianceBattle_ContributeNode:timeSwitch(ntime)
    -- body
    local now = os.time()
    local dist = now - ntime
    local retv = nil
    if dist > 2592000 then
        retv = "1个月以前"
    elseif dist > 604800 then
        retv = "1周以前"
    elseif dist > 172800 then
        retv = "2天以前" 
    elseif dist > 86400 then
        retv = "1天以前"
    elseif dist > 43800 then
        retv = "12小时以前"
    elseif dist > 21600 then
        retv = "6小时以前"
    elseif dist > 7200 then
        retv = "2小时以前"
    elseif dist > 1800 then
        retv = "30分钟以前"
    elseif dist > 300 then
        retv = "5分钟以前"
    else
        retv = "刚刚"
    end

    return UITool.ToLocalization(retv)
end
function AllianceBattle_ContributeNode:onResetData()
	
	 if not self._data then return end


    --local iTable   = self.GuildMemberTable["tab"]
        local dtable = {
            ["id"]           = self._data["uid"],               -- ID
            ["Name"]         = self._data["name"],              -- 名字
            ["position"]     = self._data["position"],          -- 公会位置
            ["rank"]         = self._data["rank"],              -- 等级
            ["head"]         = self._data["head"],              -- 头像
            ["login_tm"]     = self._data["login_tm"],          -- 上次登录时间
            ["contribute"]   = self._data["contribution"]         -- 贡献度
 
        }

        ----------------------------------------------------------------------------

        local  panelP        = self.PanelList
     

        local  ItemBg        = panelP:getChildByName("Image_bg")

        -- /*自己的图标*/
        local  memberIcon    = ItemBg:getChildByName("Image_iconHead")
        local heroid  = tonumber(dtable["head"])
        memberIcon:setUnifySizeEnabled(true)
        memberIcon:loadTexture(hero[heroid].hero_bat_icon)
        -- /*自己的名字*/
        local  memberName    = ItemBg:getChildByName("Text_Name")
        memberName:setString(dtable["Name"])
        memberName:enableOutline(cc.c4b(0,0,0,255),1)
        memberName:setFontSize(22)
        memberName:setAnchorPoint(cc.p(0,0.5))
        memberName:setPosition(cc.p(135,82))
        memberName:setTextColor(cc.c4b(255,255,255,255))
        --称号
        local spineRoot = ItemBg:getChildByName("Node_spine")
        if self.skeletonNode then 
            self.skeletonNode:stopAllActions()
            self.skeletonNode:removeFromParent()
            self.skeletonNode = nil --todo
        end 
        if (self._data["title_id"]) then
            local id_str = title_conf[tonumber(self._data["title_id"])].res_spine
            if cc.FileUtils:getInstance():isFileExist(id_str) then 
                local end_pos = string.find(id_str,'atlas') - 1
                local spName = string.sub(id_str,0,end_pos)

                self.skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
                spineRoot:addChild(self.skeletonNode,1000)
                self.skeletonNode:setAnimation(1, "effect", true)
                local dt = cc.DelayTime:create(0.01)
                local cf = cc.CallFunc:create(function()
                     ---添加spine

                    local size=self.skeletonNode:getBoundingBox()
                    print("getBoundingBox width == "..size.width)
                    self.skeletonNode:setPosition(size.width/2,0)

                end)
                local seq = cc.Sequence:create(dt,cf)
                spineRoot:runAction(seq)
            else 
                print("文件不存在 error file not exist:"..id_str)
            end
        end

        -- /*公会 成员阶位 图标*/
        local  textureIcon   = ItemBg:getChildByName("Image_icon")
        textureIcon:setPosition(cc.p(313.50,textureIcon:getPositionY()))
        --textureIcon:setAnchorPoint(cc.p(0,0.5))
        textureIcon:setUnifySizeEnabled(true)
        if dtable["position"] == 1 then
            textureIcon:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_003.png")
        elseif dtable["position"] == 2 then
            textureIcon:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_002.png")
        elseif dtable["position"] == 3 then
            textureIcon:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_001.png") -- 会长
        end

        -- /*等级*/
        local  rank          = ItemBg:getChildByName("Text_rank")
        rank:setString(dtable["rank"])
        -- /*最后登录时间*/
        local  time          = ItemBg:getChildByName("Text_time")
        --  print("到底有没有 == "..dtable["login_tm"])
        local  strTime       = self:timeSwitch(tonumber(dtable["login_tm"]))
        time:setString(strTime)
        -- 贡献度
        local  contribute   = ItemBg:getChildByName("Text_contribute")
        contribute:setString(dtable["contribute"])

        --/*成员列表中的自己*/ 
        if user_info["id"] == dtable["id"] then
            ItemBg:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_009.png")
            memberName:setTextColor(cc.c4b(255,253,102,255))
        elseif user_info["id"] ~= dtable["id"] then
            ItemBg:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_006.png")
        end
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    self:switchPlayerInfoLayer(dtable.id,dtable.head) 
                end
            end
        end 
        self.PanelList:addTouchEventListener(touchCallBack)

        if self.resetDataEvent then
            self.resetDataEvent(self)
        end

end

function AllianceBattle_ContributeNode:switchPlayerInfoLayer( id,head )
    -- body
    local rcvData = {}
    local info = {}
    if g_channel_control.b_XbPlayerInfoView == true then
        info["ui_from"] = PlayerInfoSys.EUiType.guild
        info["uid"] = id
        rcvData["info"] =  info
    else
        info["fromType"] = 4   -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息
        info["m_position"] = nil   --self.GuildMemberTable["tab"][index]["position"], --自己的公会职位
        info["other_infos"] = {}    --要查看对象的信息
        info["other_infos"]["uid"] = id
        info[other_infos]["head"] = head
        rcvData["info"] =  info
    end
    SceneManager:toPlayerInfoLayer(rcvData)
end


