-- 灵装背包配置

eq_bag = {
    max_capacity = 400,  -- 灵装背包最大容量
    per_time = 10,  -- 每次扩充背包格数
    gem = 200  -- 每次扩充消耗星石
}