--战斗场景
--created by kobejaw.2018.3.8.
BattleScene = class("BattleScene", function()
	return cc.Scene:create();
end);	

BattleScene.isRevive = false --是否是复活

function BattleScene:ctor()
	self:initRootLayer();
	
	BattleStopBGM()

	self.isRevive = false --是否是复活
	G_BattleScene = self
	G_IsInBattle = true
	G_IsMultiBattleWin = false
	self.isNeedCheckBGM1Finish = nil --是否播放完了第一首背景音乐。

	--TODO，新手引导结束的情况。等新手引导lua化的时候再搞
	self.battleResult = nil; -- 1:单人战胜利，2.单人战失败。3.多人战胜利。4.多人战失败。5.多人战暂时撤退。6.爬塔战斗胜利。7.爬塔战斗失败。

	local loadingLayer = BattleLoadingLayer:create();
	loadingLayer:setName("loading_layer");
	self.rootLayer:addChild(loadingLayer)
end

function BattleScene:initRootLayer()
	
	self.rootLayer = cc.Layer:create()

	if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
		local rootPos = ScreenManager:getInstance():getRootPoint();
		self.rootLayer:setPosition(rootPos.x,rootPos.y);
		self.rootLayer:setName("root_layer");
		--添加屏幕适配层
		local screenfitLayer = ScreenFitMainLayer:create();
		self.rootLayer:addChild(screenfitLayer, 100000);
	end

	self:addChild(self.rootLayer);
end

--资源加载结束后调用
function BattleScene:onLoadFinished()
	G_GameState = 2

    local loadingLayer = self.rootLayer:getChildByName("loading_layer")
    if loadingLayer ~= nil then
    	loadingLayer:removeFromParent(true)
    end
    self.rootLayer:addChild(BattleContainerLayer:create())
    self.rootLayer:addChild(BattleUIRootLayer:create())

    --显示bossUI
    if BattleDataManager.isBoss then
    	local boss = G_Monsters[1]
    	BattleUIManager:showBossHPbar(boss.attr[AE.hp_max],boss.attr[AE.od_hp],boss.attr[AE.level],nil,boss.attr[AE.element],boss)
    	BattleUIManager:setMcountForBoss(0,boss.attr[AE.energy_max])
    	boss:initODBKBar()

    	if G_STAGE_TYPE == 3 then
    		local num = boss.attr[AE.hp_max] - boss.attr[AE.hp]
    		if num > 0 then
    			BattleUIManager:setHP(math.abs(num),false)
    		end
    	end
    else
    	BattleUIManager:setWave(1,BattleRuntimeInfo.totalWaveNum)
    end

    --神格技能
    if BattleDataManager.hasPrincess then
    	BattleUIManager:setTotalSP(1000)
    end

    --播放开场音乐
    self:startBGM()

    --播放开场动画
    if not BattleDataManager.isReJoin then
	    if BattleDataManager.isBoss then
	    	BattleUIManager:modeStateCall(2,self.startGame);
	    else
			BattleUIManager:modeStateCall(1,self.startGame);
	    end
	--多人战再次加入战斗的情况，所有角色死亡，弹出复活界面
	else
		self:startGame_JoinAgain()
	end
end

--播放完开场动画后开始游戏
function BattleScene:startGame()
	G_GameState = 1
	G_IsAllDead = false
	--切换到寻敌状态。
    for i = 1,#G_Monsters do
    	if not G_Monsters[i].isDead then
	        local data = {}
	        data.type = 1;
	        if G_Monsters[i].isBoss then
	            G_Monsters[i].fsm:changeState(StateEnum.Attacking_Boss)
	        else
	            G_Monsters[i].fsm:changeState(StateEnum.RunningToEnemy,data)
	        end

	        if BattleRuntimeInfo.currentWaveNum == 1 and not G_BattleScene.isRevive then
	        	--触发时机11.战斗开始时触发
	        	local option = {}
	        	G_Monsters[i].triggerManager:check(11,option)
		    	--触发时机7.
		    	G_Monsters[i].triggerManager:check(7,option)	        	
	    	end
    	end
    end
    for i = 1,#G_Roles do
    	if not G_Roles[i].isDead then
	        local data = {}
	        data.type = 1;        
	        G_Roles[i].fsm:changeState(StateEnum.RunningToEnemy,data)
	        
	        if BattleRuntimeInfo.currentWaveNum == 1 and not G_BattleScene.isRevive then
	        	--触发时机11.战斗开始时触发
	        	local option = {}
	        	G_Roles[i].triggerManager:check(11,option)	        	
	        end

	        --触发时机7.
		    G_Roles[i].triggerManager:check(7,option)	

	        --触发时机6.boss状态切换时。
	        if BattleRuntimeInfo.currentWaveNum == 1 and BattleDataManager.isBoss then
	        	local option = {}
				option.affectedEntity = G_Monsters[1]
	        	G_Roles[i].triggerManager:check(6,option)
	        end

	        --多人战时团队buff
	        if G_STAGE_TYPE == 2 and not G_BattleScene.isRevive then
	        	local debuffData = BattleDataManager.data.monster_mul[1].debuff
				local debuffList = {}
				for k,v in pairs(debuffData) do
					debuffList[v.id] = v.debuff_lv
				end
				BattleRuntimeInfo:refreshSharedDebuff(debuffList)
	        end
    	end
    end

    --多人战boss身上的debuff
    if G_STAGE_TYPE == 2 and not G_BattleScene.isRevive then
    	BattleRuntimeInfo:refreshSharedBuff(BattleDataManager.data.buff)
    end

    if not BattleDataManager.isBoss then
    	BattleCameraManager.cameraFixed = false
    end

    --G_BattleScene:testForComponent()--com测试
end

--多人战暂时撤退后再次加入战斗。
function BattleScene:startGame_JoinAgain()
	G_GameState = 5
	G_IsAllDead = true

	if not G_Monsters[1].isDead then
	    G_Monsters[1].fsm:changeState(StateEnum.Idling)
	end

    for i = 1,#G_Roles do
	    G_Roles[i].fsm:changeState(StateEnum.Dead)
	    G_Roles[i]:setVisible(false)
    end

    --多人战boss身上的debuff
    BattleRuntimeInfo:refreshSharedBuff(BattleDataManager.data.buff)

    BattleCameraManager.cameraFixed = true

    --隐藏技能栏
    ActiveSkillManager:hideSkillPanel()

    --弹出复活界面
    BattleUIManager:showPanelFH(self.onRevive)	--复活界面
end

function BattleScene:startBGM()
	--背景音乐
    local bgm1 = BattleDataManager.bgm1
    local bgm2 = BattleDataManager.bgm2

    if bgm1 and bgm2 then
        BattlePlayBGM(bgm1,false)
        self.isNeedCheckBGM1Finish = true
    else
        if bgm1 then
            BattlePlayBGM(bgm1,true)
        elseif bgm2 then
            BattlePlayBGM(bgm2,true)
        end
    end

    --开场语音
    if BattleDataManager.isBoss then
    	BattlePlaySound(G_Monsters[1].sound_battleStart,false,1)
    else
    	local num = #G_Roles
    	local random = GetRandomBetweenAB(1,num)
    	BattlePlaySound(G_Roles[random].sound_battleStart,false,1)
    end

    --boss的警报声音效
    if BattleDataManager.isBoss then
    	BattlePlaySound(BattleGlobals.Sound_BossShow,false,1)
    end
end

--暂停游戏(点击暂停按钮时调用)
function BattleScene:pauseGame()
	G_GameState = 4
	PauseNodesWithAction()
	PauseNodesWithSpine()
	for k,v in pairs(G_EntityLayer.entities) do
		if not v.isDead then
			v:pause()
			v.spineNode:setTimeScale(0.00000001)			
		end
	end
end
function BattleScene:resumeGame()
	G_GameState = 1
	ResumeNodesWithAction()
	ResumeNodesWithSpine()
	for k,v in pairs(G_EntityLayer.entities) do
		if not v.isDead then
			v:resume()
			v.spineNode:setTimeScale(1)
		end
	end	
end

--type: 1.单人战胜利。2.单人战弹出复活。3.单人战失败。4.多人战胜利。5.多人战弹出复活。6.多人战失败。7.多人战暂时撤退。8.爬塔胜利。9.爬塔失败。
function BattleScene:onBattleOver(type)
	G_IsAllDead = true

	if G_GameState == 5 and not (type == 4 or type == 6) then
		return
	end
	
	G_GameState = 5

	if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
		if type ~= 1 then
			type = 3
		end
	end

	BattleCameraManager:reset()
	self.battleResult = type

	local isType1Win = false
	if type == 1 then
		BattleRuntimeInfo.currentWaveNum = BattleRuntimeInfo.currentWaveNum + 1
		if BattleRuntimeInfo.currentWaveNum > BattleRuntimeInfo.totalWaveNum then
			isType1Win = true
			BattleUIManager:showVictor(self.quitBattleScene)
		else
			self:gotoNextMap() --跑到下一个场景
		end
	--弹出胜利界面
	elseif type == 4 or type == 8 then
		BattleUIManager:showVictor(self.quitBattleScene)
	--弹出复活界面
	elseif type == 2 or type == 5 then
		BattleUIManager:showPanelFH(self.onRevive)	--复活界面
	--弹出失败界面
	elseif type == 3 or type == 6 or type == 9 then
		BattleUIManager:showLose(self.quitBattleScene)
	--直接退出战斗
	elseif type == 7 then
		self:quitBattleScene()
	end

	--语音
	if type == 3 or type == 6 or type == 9 then
    	local num = #G_Roles
    	local random = GetRandomBetweenAB(1,num)
    	BattlePlaySound(G_Roles[random].sound_lose,false,1)
	elseif isType1Win or type == 4 or type == 8 then
		local roles = {}
		for k,v in pairs(G_Roles) do
			if not v.isDead then
				table.insert(roles,v) 
			end
		end
    	local num = #roles
    	local random = GetRandomBetweenAB(1,num)
    	if roles[random] then
    		BattlePlaySound(roles[random].sound_win,false,1)
    	end
	end	
end

function BattleScene:gotoNextMap()
	--角色涨20%的血量，并一起向前跑
	G_NodesWithSpine = {}

	G_GameState = 2
	for k,v in pairs(G_Roles) do
		if not v.isDead then
			local data = {}
			data.type = 1
			data.isEnter = true
			data.w = v.box_w + 1000
			data.h = v.box_h
			v.attributeManager:changeAttr(AE.hp,math.floor(v.attr[AE.hp_max]/5))
			v.fsm:changeState(StateEnum.RunningToPosition,data)
		end
	end

	local this = self

	--黑布拉开结束的时候
	local function onCurtainOpened()
		this:startGame()
	end
	--黑布挡上的时候，重置角色位置，创建下一波怪
	local function onCurtainClosed()
		BattleUIManager:removeBox()
		G_EntityLayer:clearEntities()
		G_EntityLayer:setNoOneChosen()
		G_EntityLayer:clearMonsters()
		BattleRuntimeInfo.teams[2]:clear()
		G_EntityLayer:createOneWaveMonster(BattleRuntimeInfo.teams[2])
		G_EntityLayer:resetEntities()
		G_BattleBGLayer:reset()
		G_BattleLayer:reset()
		BattleUIManager:setWave(BattleRuntimeInfo.currentWaveNum,BattleRuntimeInfo.totalWaveNum)
		G_BattleContainerLayer:onChangeWave()
		--拉开黑布
		BattleUIManager:modeStateCall(3,onCurtainOpened);
		G_EntityLayer:resetRolesPosition() --角色开始跑动，跑到目的地后原地idle
	end

	local function playCurtainAni()
		BattleUIManager:modeStateCall(4,onCurtainClosed);
	end
	--1秒后播放下一波怪的开场动画.(黑布遮起的动画)
	PerformWithDelayTime(playCurtainAni,1)	
end

--复活
function BattleScene:onRevive()
	G_IsAllDead = false

	BattlePlaySound(BattleGlobals.Sound_Revive,false,2)
	G_BattleScene.isRevive = true

	--清空所有buffdebuff
	for k,v in pairs(G_Roles) do
		v.componentManager:removeAllCom()
	end

	--神格技能100%
	BattleUIManager.princessManager:onRevive()

	--重置角色，并进入idle状态。同时播放复活特效，特效结束后开始战斗。
	for k,v in pairs(G_Roles) do
		v:revive()
	end

	BattleRuntimeInfo:setTeam1Num(#G_Roles)

	--重置技能
	ActiveSkillManager:onRevive()

	--特别靠左的怪物被击退(记得先把所有怪物的朝向改成朝左)。
	G_EntityLayer:onRevive()

end

--退出战斗场景
--type: 1.单人战胜利。2.单人战弹出复活。3.单人战失败。4.多人战胜利。5.多人战弹出复活。6.多人战失败。7.多人战暂时撤退。8.爬塔胜利。9.爬塔失败。
function BattleScene:quitBattleScene()
	G_IsInBattle = false

	cc.UserDefault:getInstance():setBoolForKey("AUTOBATTLE",ActiveSkillManager.isAuto)
	
	BattleStopBGM()
	local battleResult = G_BattleScene.battleResult

	local battleId = BattleDataManager.battleId
	local damage = {} 
	if battleResult == 8 or battleResult == 9 then
        for k,v in pairs(G_Monsters) do
        	local m_id = v.data.puid
       		local initialHP = BattleDataManager.towerData[m_id]
       		if initialHP then
       			damage[tostring(m_id-1)] = math.abs(initialHP - v.attr[AE.hp]) --注tostring千万不要漏，否则不堪设想。
       		end
        end		
	end

	G_BattleScene:removeAllChildren()
	cc.Director:getInstance():popScene()
	BattleCacheManager:clearCache()

	--战斗结算
	--除了爬塔，其他的战斗失败不需要告诉服务器。
	--type: 1.单人战胜利。2.单人战弹出复活。3.单人战失败。4.多人战胜利。5.多人战弹出复活。6.多人战失败。7.多人战暂时撤退。8.爬塔胜利。9.爬塔失败。
	
	if battleResult == 1 then
		singleBattleEndFunc(1,battleId,1)
	elseif battleResult == 3 then
		if BattleDataManager.isBoss then
			battleEndFuncFalse(1,1)
		else
			battleEndFuncFalse(2,1)
		end
	elseif battleResult == 4 then
		battleEndFunc(2)
	elseif battleResult == 6 then
		battleEndFuncFalse(2,2)
	elseif battleResult == 7 then
		battleEndFuncFalse(0,2)
	elseif battleResult == 8 or battleResult == 9 then
        local cjson = require "cjson"

        local tempTable = 
        {
            ["rpc"]       = "guild_tower_battle_result",
            ["tower_now"] = tonumber(battleId),
            ["total_dmg"] = damage
        }
        local mydata =  cjson.encode(tempTable)
		towerbattleEndFunc(mydata)
	end

	BattleDataManager:clear()
	BattleUIManager:clear()
	BattleRuntimeInfo:clear()
	
end

--战斗时间到的处理
function BattleScene:onTimeUp()
	--如果此时处在cutin中，变回cutend先
	if G_EntityPlayingCutin then
		SkillUtil:playEndCutIn(G_EntityPlayingCutin)
	end

	for k,v in pairs(G_EntityLayer.entities) do
		if not v.isDead and v.fsm.currentState.stateEnum ~= StateEnum.UnusualCondition then
			v.fsm:changeState(StateEnum.Idling)
		end
	end

    if G_STAGE_TYPE == 1 then
        G_BattleScene:onBattleOver(3)
    elseif G_STAGE_TYPE == 2 then
        G_BattleScene:onBattleOver(6)
    elseif G_STAGE_TYPE == 3 then
        G_BattleScene:onBattleOver(9)
    end	
end

--创建com的测试代码
function BattleScene:testForComponent()
	local attacker = G_Roles[1]
	local defender = G_Monsters[1]

	local option = {}
	option.affectedEntity = attacker

	local comData = {debuff_id =81036,debuff_hit = 100,lv = 15,target_type = 1,effect_type = 1 } --无敌

	--option.comId = 
	--ComponentCreator:createComponent(skill[4024106].skill_attack_hit[1].add_buff[1].skill_trig_effect[1],attacker,option)
	ComponentCreator:createComponent(passive_sk[5024203].trig_cdn[1].skill_trig_effect[1],defender,option) --生命护盾
	--ComponentCreator:createComponent(passive_sk[6378003].trig_cdn[1].skill_trig_effect[1],attacker,option)  --可叠加测试
	--ComponentCreator:createComponent(skill[4375202].skill_attack_hit[1].add_buff[1].skill_trig_effect[1],attacker,option)  --异常护盾
	--ComponentCreator:createComponent(passive_sk[5023202].trig_cdn[1].skill_trig_effect[1],attacker,option) --次数护盾
	--ComponentCreator:createComponent(passive_sk[5359101].trig_cdn[1].skill_trig_effect[1],G_Roles[1],option) --每秒回血
	--ComponentCreator:createComponent(passive_sk[5359101].trig_cdn[1].skill_trig_effect[1],G_Roles[2],option) --每秒回血
	--ComponentCreator:createComponent(passive_sk[5359101].trig_cdn[1].skill_trig_effect[1],G_Roles[3],option) --每秒回血
	--ComponentCreator:createComponent(passive_sk[5359101].trig_cdn[1].skill_trig_effect[1],G_Roles[4],option) --每秒回血
	--ComponentCreator:createComponent(skill[4375201].skill_attack_hit[1].add_buff[2].skill_trig_effect[1],attacker,option)--冻土封印
	
	ComponentCreator:createComponent(comData,defender,option) --无敌
	return
end

