
--------------------------------
-- @module LocalizationHelper
-- @parent_module 

--------------------------------
-- 
-- @function [parent=#LocalizationHelper] getCurrentManager 
-- @param self
-- @return ILocalizationManager#ILocalizationManager ret (return value: ccs.ILocalizationManager)
        
--------------------------------
-- 
-- @function [parent=#LocalizationHelper] isBinManager 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#LocalizationHelper] setCurrentManager 
-- @param self
-- @param #ccs.ILocalizationManager manager
-- @param #bool isBinary
-- @return LocalizationHelper#LocalizationHelper self (return value: ccs.LocalizationHelper)
        
return nil
