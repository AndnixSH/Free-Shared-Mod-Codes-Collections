guild_tower_reward = {} 
guild_tower_reward[1] = {
      name="NO.1-499", --奖励的名称
      reward_list={
		{
			reward_type=2, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=1, -- 奖励道具数量
		},		
		{
			reward_type=13, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=5, -- 奖励道具数量
		},
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=601,  -- 奖励道具id
			reward_num=2, -- 奖励道具数量
		},	
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=611,  -- 奖励道具id
			reward_num=2, -- 奖励道具数量
		},	
	}
 }

guild_tower_reward[2] = {
      name="NO.500-500", --奖励的名称
      reward_list={
		{
			reward_type=2, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=20, -- 奖励道具数量
		},		
		{
			reward_type=13, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=100, -- 奖励道具数量
		},
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=602,  -- 奖励道具id
			reward_num=5, -- 奖励道具数量
		},	
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=612,  -- 奖励道具id
			reward_num=5, -- 奖励道具数量
		},	
	}
 }

guild_tower_reward[3] = {
      name="NO.501-799", --奖励的名称
      reward_list={
		{
			reward_type=2, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=2, -- 奖励道具数量
		},		
		{
			reward_type=13, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=10, -- 奖励道具数量
		},
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=602,  -- 奖励道具id
			reward_num=1, -- 奖励道具数量
		},	
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=612,  -- 奖励道具id
			reward_num=1, -- 奖励道具数量
		},	
	}
 }

guild_tower_reward[4] = {
      name="NO.800-800", --奖励的名称
      reward_list={
		{
			reward_type=2, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=50, -- 奖励道具数量
		},		
		{
			reward_type=13, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=200, -- 奖励道具数量
		},
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=602,  -- 奖励道具id
			reward_num=10, -- 奖励道具数量
		},	
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=612,  -- 奖励道具id
			reward_num=10, -- 奖励道具数量
		},	
	}
 }

guild_tower_reward[5] = {
      name="NO.801-999", --奖励的名称
      reward_list={
		{
			reward_type=2, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=5, -- 奖励道具数量
		},		
		{
			reward_type=13, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=20, -- 奖励道具数量
		},
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=602,  -- 奖励道具id
			reward_num=2, -- 奖励道具数量
		},	
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=612,  -- 奖励道具id
			reward_num=2, -- 奖励道具数量
		},	
	}
 }

guild_tower_reward[6] = {
      name="NO.1000-1000", --奖励的名称
      reward_list={
		{
			reward_type=2, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=100, -- 奖励道具数量
		},		
		{
			reward_type=13, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=0,  -- 奖励道具id
			reward_num=500, -- 奖励道具数量
		},
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=602,  -- 奖励道具id
			reward_num=20, -- 奖励道具数量
		},	
		{
			reward_type=5, -- 奖励道具类型 1金币 2宝石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
			reward_id=612,  -- 奖励道具id
			reward_num=20, -- 奖励道具数量
		},	
	}
 }
