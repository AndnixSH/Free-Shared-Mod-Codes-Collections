
--商店系统


--商店类型
EShopType = {
    charge = 1,
    prop = 2,
    mimi = 3,
    cangyu = 4,
    hero = 5,
    act = 6,
    gift = 7,
}

ShopSys = class("ShopSys")

function ShopSys:getInstance()
   if self.s_instance == nil then

        self.s_instance = ShopSys.new()
        self.s_instance:initialize()

   end
   return self.s_instance;
end


function ShopSys:initialize()
    self.shop_type = EShopType.charge
end


-----------------------------------------------------------------------
------------------------      接口 开始   -------------------------------
-----------------------------------------------------------------------

function ShopSys:updateItemData( idx,data )
    -- body
    XbShopData:getInstance():updateItemData(idx,data)
end

function ShopSys:updateItemDataByTabIdx(tabIdx,idx,data )
    -- body
    XbShopData:getInstance():updateItemDataByTabIdx(tabIdx,idx,data)
end

function ShopSys:deleteItemDataByTabIdx( tabIdx,data )
    -- body
    XbShopData:getInstance():deleteItemDataByTabIdx(tabIdx,data)
end

function ShopSys:getData( ... )
    return XbShopData:getInstance():getData()
end

function ShopSys:getActOverTimeByTabIndex( index )
    -- body
    local over_time = XbShopData:getInstance():getActOverTimeByTabIndex(index)
    return over_time
end

function ShopSys:getRefreshNum( ... )
    -- body
    local refresh_num = XbShopData:getInstance():getRefreshNum()
    return refresh_num
end

function ShopSys:getRefreshMaxNum( ... )
    -- body
    local refresh_max = XbShopData:getInstance():getRefreshMaxNum()
    return refresh_max
end

function ShopSys:getRefreshData( ... )
    -- body
    local refresh_data = XbShopData:getInstance():getRefreshData()
    return refresh_data
end

function ShopSys:getUserAssetNum(cost_type)
    
    local assetNum = XbShopData:getInstance():getUserAssetNum(cost_type)
    print("ShopSys:getUserAssetNum  assetNum",assetNum)
    return assetNum
end

function ShopSys:getUserAssetConfig( shopType )
    -- body
    local iteamDatas = XbShopData:getInstance():getUserAssetConfig(shopType)
    return iteamDatas
end

function ShopSys:getTabCount( ... )
    -- body
    local count = XbShopData:getInstance():getTabCount()
    return count
end

function ShopSys:getTabData( ... )
    -- body
    local data = XbShopData:getInstance():getTabData()
    return data
end

function ShopSys:getTabItemDataByIndex( index )
    -- body
    local data = XbShopData:getInstance():getTabItemDataByIndex(index)
    return data
end

function ShopSys:getShopHelp( index )
    -- body
    local help = XbShopData:getInstance():getShopHelp(index)
    return help
end

function ShopSys:getInitTimeFormat( time,format,params )
    -- body
    local leftTime = time or 0
    local timeFormat = format
    local d = math.floor(leftTime / 60 / 60 / 24)
    if d < 0 then
      d = 0
    end

    local h = math.floor(leftTime / 3600) % 24
    if h < 0 then
        h = 0
    end
    local m = math.floor((leftTime / 60) % 60)
    if m < 0 then
        m = 0
    end
    local s = math.floor(leftTime % 60)--() 
    if s < 0 then
        s = 0
    end
    
    local timeStr = string.format("%02d:%02d:%02d",h,m,s)
    if timeFormat == 1 then

       timeStr = string.format(UITool.ToLocalization("%02d天%02d:%02d:%02d"),d,h,m,s)
       if params then
          timeStr = string.format("%02d天%02d:%02d:%02d",d,h,m,s)..Lang:toLocalization(1050031)
       end
    end
    
    return timeStr
end

function ShopSys:getTabConfigData( shopType )
    -- body
    local retData = nil
    local count = self:getTabCount()
    for i=1,count do
        local data = XbShopData:getInstance():getTabItemDataByIndex(i)
        local shop_type = data["shop_type"]
        if shop_type == shopType then
            retData = data
            break
        end
    end
    return retData
end

function ShopSys:getTabConfig( shopType )
    -- body
    local retData = nil
    local data = self:getTabConfigData(shopType)
    if data and data["tab_name"] then
        retData = UITool.getUserLanguage(data["tab_name"])
    end
    return retData
end

function ShopSys:setTabIndex( tabIdx )
    -- body
    XbShopData:getInstance():setTabIndex(tabIdx)
end

function ShopSys:getTabIndex( ... )
    -- body
    local tabIdx = XbShopData:getInstance():getTabIndex()
    return tabIdx
end

--是否是秘密商店
function ShopSys:isMiMi( shopType )
    -- body
    local bMiNi = false
    local shop_type =  shopType
    if shop_type == EShopType.mimi then
        bMiNi = true
    end
    return bMiNi
end

--是否是活动商店
function ShopSys:isAct( shopType )
    -- body
    local bAct = false
    local shop_type =  shopType
    if shop_type == EShopType.act then
        bAct = true
    end
    return bAct
end

function ShopSys:filterOverAct( tabData )
    -- body
    local tab_data = tabData
    if self.shop_type == EShopType.act then
        tab_data = XbShopData:getInstance():filterOverAct(tabData)
    end
    return tab_data
end

function ShopSys:isActOver( tabIdx )
    -- body
    local bOver = XbShopData:getInstance():isActOver(tabIdx)
    return bOver
end

function ShopSys:getActOverTime( tabIdx )
    -- body
    local time = XbShopData:getInstance():getActOverTime(tabIdx)
    return time
end

--是否是英雄圆桌商店
function ShopSys:isHeroShop( shopType )
    -- body
    local bHeroShp = false
    local shop_type = shopType
    if shop_type == EShopType.hero then
        bHeroShp = true
    end
    return bHeroShp
end

--商店是否带页签
function ShopSys:isWithTab( shopType )
    -- body
    local shop_type = shopType
    local bWithTab = false
    if shop_type == EShopType.charge or shop_type == EShopType.act or shop_type == EShopType.gift then
        bWithTab = true
    end
    return bWithTab
end

function ShopSys:initLocalData(shopType,data )
    -- body
    XbShopData:getInstance():initLocalData(shopType,data)
end

function ShopSys:getDataWithTabIndex( index )
    -- body
    local tabViewData = XbShopData:getInstance():getDataWithTabIndex(index)
    return tabViewData
end

function ShopSys:setShopType( shopType )
    -- body
    self.shop_type = shopType
end

function ShopSys:getShopType()
    -- body
    return self.shop_type
end

--获得购买个数需要消耗的货币
function ShopSys:getMoneyCostMax( cost_type,cost_num,stock_num )
    -- body
    local costMaxNum = XbShopData:getInstance():getMoneyCostMax(cost_type,cost_num,stock_num)
    return costMaxNum
end

function ShopSys:bRefreshCost()
    local bRefresh = XbShopData:getInstance():bRefreshCost()
    return bRefresh
end

function ShopSys:setRefreshNum( num )
    -- body
    XbShopData:getInstance():setRefreshNum(num)
end

function ShopSys:getActRedDotStatus()
    -- body
    local bRedDot = false
    local statusArr = XbShopData:getInstance():getActRedDotInfo()
    local count = #statusArr
    for i=1,count do
        local statusData = statusArr[i]
        if statusData then
            local shop_type = statusData["type"]
            if shop_type == self.shop_type then
                bRedDot = statusData["new"] == 1 and true or false
                break
            end
        end
    end
    return bRedDot
end


function ShopSys:checkActTimeOver( ... )
    -- body
    local bOver = XbShopData:getInstance():checkActTimeOver()
    return bOver
end

--检测活动是否结束
function ShopSys:startCheck( ... )
    -- body
    -- local curTime = 1546185399 - 60
    -- print("ShopSys:startCheck   actCount..,",actCount)
    local function callBackFunc()
        -- print("check........")
        local bOver = XbShopData:getInstance():checkActTimeOver()
        if bOver == true then
            local event_data = {}
            lemon.EventManager:dispatchCustomEvent(EEventType.SHOP_ACT_OVER_REMOVE,event_data)
            self:stopCheck()
            return
        end

        local curTime = UserDataMgr:getInstance().timeData:getCurrentTime()
        local act_over_time = XbShopData:getInstance():getActsOverTime() or {}

        table.sort(act_over_time , function(a , b)
          return a < b
        end)
        
        local actCount = #act_over_time or 0

        for i=1,actCount do
            local over_time = XbShopData:getInstance():getActOverTimeByTabIndex(i)
            local start_time = XbShopData:getInstance():getActStartTimeByTabIndex()
            -- print("ShopSys:startCheck  over_time,curTime..,"..i,over_time,curTime)
            if over_time and over_time > 0 and curTime < over_time and start_time and start_time > 0 and curTime > start_time then
                local tabIdx = XbShopData:getInstance():getTabIndex()
                if tabIdx and i == tabIdx then
                    local event_data = {}
                    event_data["tab_idx"] = i
                    lemon.EventManager:dispatchCustomEvent(EEventType.SHOP_REFRESH_ACT_TIME,event_data)
                end
                break
            end
        end
    end

    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerEntry = scheduler:scheduleScriptFunc(callBackFunc,1, false)
end

--停止检测
function ShopSys:stopCheck( ... )
    -- body
    -- print("stop check........")
    if self.schedulerEntry ~= nil then 
        local scheduler = cc.Director:getInstance():getScheduler()
        scheduler:unscheduleScriptEntry(self.schedulerEntry)
        self.schedulerEntry = nil
    end
end

function ShopSys:setRefreshOffset( bool )
    -- body
    XbShopData:getInstance():setRefreshOffset(bool)
end

function ShopSys:getRefreshOffset( ... )
    -- body
    local bRefreshOffset = XbShopData:getInstance():getRefreshOffset()
    return bRefreshOffset
end

--获取商品列表

function ShopSys:reqItemList(shopData,successCallback, failCallback)
    local tempData = {
        ["rpc"]       = "store_info",
        ["shop_type"] = self.shop_type or EShopType.charge,
    }
   local shopType = table.getValue("ShopSys:reqItemList data", shopData, "shopType")
    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            local sellDatas = {}
            local refresh_data = {}
            if data and data["shop"] then
                if data["shop"]["sells"] then
                    sellDatas = data["shop"]["sells"]
                end
                if data["shop"]["refresh"] then
                    refresh_data = data["shop"]["refresh"]
                end
            end
            -- local sellDatas = data["shop"]["sells"]
            -- local refresh_data = data["shop"]["refresh"]
            XbShopData:getInstance():initLocalData(shopType,sellDatas)
            if shopType == EShopType.mimi then
                -- print("ShopSys:reqItemList    refresh_num,refresh_max",refresh_num,refresh_max)  
                XbShopData:getInstance():setRefreshNum(data["refresh_num"])
                XbShopData:getInstance():setRefreshMaxNum(data["refresh_max"])
                XbShopData:getInstance():setRefreshData(refresh_data)                
            end

            if shopType == EShopType.act then
                user_info["medal_num"] = data["resource"]["medal_num"]
                if data["resource"]["mat_712"] ~= nil then
                    user_info["act_sugar"] = data["resource"]["mat_712"]
                end
                -- data["act_tm"] = {1546586516 + 500,1546586516 + 3000}--{1546580110 + 400}
                XbShopData:getInstance():setActsOverTime(data["act_tm"])
                XbShopData:getInstance():setActsStartTime(data["start_tm"])
                XbShopData:getInstance():initTabData()

                local event_data = {}
                lemon.EventManager:dispatchCustomEvent(EEventType.SHOP_Currenty_INCHARGE_REFRESH,event_data)
            end

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end

--请求购买
function ShopSys:reqBuyItem(itemData,successCallback, failCallback)
    dump(itemData, "ShopSys:reqBuyItem itemData")
    local shopType = table.getValue("ShopSys:reqBuyItem data", itemData, "shopType")
    local sell_id = table.getValue("ShopSys:reqBuyItem data", itemData, "sell_id")
    local buy_num = table.getValue("ShopSys:reqBuyItem data", itemData, "buy_num")
    
    local tempData = {
        ["rpc"]       = "store_buy",
        ["shop_type"] = shopType,
        ["sell_id"]   = sell_id,
        ["buy_num"]   = buy_num,
    }
   dump(tempData,"ShopSys:reqBuyItem   tempData")
    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end

--秘密商店刷新免费购买时间
function ShopSys:reqTimeForFree(shopData,successCallback, failCallback)
    dump(shopData, "ShopSys:reqItemList shopData")
    local shopType = table.getValue("ShopSys:reqTimeForFree data", shopData, "shopType")
    local tempData = {
        ["rpc"]       = "store_refresh",
        ["shop_type"] = shopType or EShopType.charge,
    }

    GameManagerInst:rpc(tempData,
        3,
        function(data)

            local updateData = data["update"]["sells"]
            local refresh_data = data["update"]["refresh"]
            XbShopData:getInstance():initLocalData(shopType,updateData)
            -- print("XbShopData:initTestData",shop_type)
            --XbShopData:getInstance():initTestData(shopType,updateData)
            dump(shopData,"ShopSys:reqItemList  shopData")
            print("ShopSys:reqItemList  shopType   ",shopType,EShopType.mini)
            if shopType == EShopType.mimi then
                XbShopData:getInstance():setRefreshData(refresh_data) 
            end

            user_info["gold"] = data["gold"]
            user_info["gem"] = data["gem"]
            user_info["gem_r"] = data["gem_r"]
            user_info["beryl"] = data["beryl"]
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end

--获取商店红点信息

function ShopSys:reqHotDotData(shopData,successCallback, failCallback)
    local tempData = {
        ["rpc"]       = "shop_status",
    }
   -- local shopType = table.getValue("ShopSys:reqItemList data", shopData, "shopType")
    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            XbShopData:getInstance():setActRedDotInfo(data["status"])
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
end
-----------------------------------------------------------------------
------------------------      接口 结束   -------------------------------
-----------------------------------------------------------------------









