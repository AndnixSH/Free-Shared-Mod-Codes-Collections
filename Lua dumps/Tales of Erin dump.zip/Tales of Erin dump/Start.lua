cc.FileUtils:getInstance():addSearchPath("src")
cc.FileUtils:getInstance():addSearchPath("res")
cc.FileUtils:getInstance():addSearchPath("src/ui")
cc.FileUtils:getInstance():addSearchPath("src/data")
cc.FileUtils:getInstance():addSearchPath("res/uifile")
cc.FileUtils:getInstance():addSearchPath("res/uifile/MaskUI")
cc.FileUtils:getInstance():addSearchPath("src/Act")
cc.FileUtils:getInstance():addSearchPath("res/Manifests")
cc.FileUtils:getInstance():addSearchPath("src/ddBattle")
cc.FileUtils:getInstance():addSearchPath("src/Act_2")
cc.FileUtils:getInstance():addSearchPath("src/lemon")
cc.FileUtils:getInstance():addSearchPath("src/lemon/util")
cc.FileUtils:getInstance():addSearchPath("src/userdata")
cc.FileUtils:getInstance():addSearchPath("src/ui/AllianceBattle")
cc.FileUtils:getInstance():addSearchPath("src/Chat")

function require_ex( module_name )
    local old_module = _G[module_name]
    package.loaded[module_name] = nil
    require (module_name)

    local new_module = _G[module_name]
    if  new_module~=nil and #new_module > 0 and old_module~=nil and #old_module > 0   then
       for k, v in pairs(new_module) do
           old_module[k] = v
       end
       package.loaded[module_name] = old_module
    end
    
    return old_module;
end

require "cocos.init"

cclog = function(...)
    print(string.format(...))
end

function __G__TRACKBACK__(msg)
    local strRes = "\n----------------------------------------\n"
    strRes = strRes.."LUA ERROR: " .. tostring(msg) .. "\n"
    strRes = strRes..debug.traceback().."\n"
    strRes = strRes.."----------------------------------------\n"
    
    cclog(strRes)
    
    local path = cc.FileUtils:getInstance():getWritablePath()
    path = path.."ErrorLog/"
    if not cc.FileUtils:getInstance():isDirectoryExist(path) then
        cc.FileUtils:getInstance():createDirectory(path)
    end
    
    local logfile = "LuaErr-"..os.date("%Y-%m-%d-%H:%M:%S")..".txt"
    
    local file = io.open(path..logfile,"w+")
    file:write(strRes)
    file:close()
    
    -- local listfile = path.."errlist.json"
    -- local listContent = nil

    -- local cjson  = require "cjson"
    
    -- if cc.FileUtils:getInstance():isFileExist(listfile) then
    --     -- body
    --     local str = cc.FileUtils:getInstance():getStringFromFile(listfile)
    --     listContent = cjson.decode(str)
    --     table.insert(listContent,1,logfile)
    -- else
    --     listContent = {}
    --     listContent[1] = logfile
    -- end 
    
    -- local fileContent = cjson.encode(listContent)
    
    -- local file1 = io.open(listfile,"w")
    -- file1:write(fileContent)
    -- file1:close()
    --添加腾讯bugly的crash日志收集功能
    require "sdk/ch_config"
    if CHANNEL.Android.CHANNEL_CODE_TX ~= GAME_CHANNEL then 
         buglyReportLuaException(tostring(strRes), debug.traceback())
    end  
   
    return msg
end

local function main()
    collectgarbage("collect")
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    --initialize director
    local director = cc.Director:getInstance()
    local glview = director:getOpenGLView()
    if nil == glview then
        glview = cc.GLView:createWithRect("HelloLua", cc.rect(0,0,1280,720))
        director:setOpenGLView(glview)
    end
    --glview:setDesignResolutionSize(1559, 720, cc.ResolutionPolicy.FIXED_WIDTH)
    -- require "ScreenManager"
    --ScreenManager:getInstance():autoFit();

--glview:setDesignResolutionSize(480, 320, cc.ResolutionPolicy.NO_BORDER)

--turn on display FPS
--director:setDisplayStats(true)

--set FPS. the default value is 1.0/60 if you don't call this
    director:setAnimationInterval(1.0 / 60)
    local schedulerID = 0
    --support debug
    -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    -- local size = glview:getFrameSize()
    local designSize = cc.size(1280.0, 720.0);
    -- if cc.PLATFORM_OS_IPHONE == targetPlatform    then
    --     if size.width>900 then
    --     designSize = cc.size(1280,720)
    --     end
    -- else
    --     if size.width ==2048 then
    --     designSize = cc.size(1280,720)
    --     else
    --     designSize = cc.size(1280,720)
    --     end
    -- end

    --glview:setDesignResolutionSize(designSize.width, designSize.height, cc.ResolutionPolicy.SHOW_ALL)


    removeUpdateFileSearchPath();

    local fileUtils = cc.FileUtils:getInstance()
    local searchPaths = fileUtils:getSearchPaths()
    table.insert(searchPaths, 1)

    if (designSize.height > 768) then

    table.insert(searchPaths, 1, "rhd");
    table.insert(searchPaths, 1, "rhd/UI");
    table.insert(searchPaths, 1, "res/hd");
    table.insert(searchPaths, 1, "res/hd/Resources");
    table.insert(searchPaths, 1, "sd/Resources");
    table.insert(searchPaths, 1, "res/hd/UI");
    table.insert(searchPaths, 1, "sd");

    elseif (designSize.width > 1280) then
    table.insert(searchPaths, 1, "sd/Resources");
    table.insert(searchPaths, 1, "res/hd/Resources");
    table.insert(searchPaths, 1, "sd");
    table.insert(searchPaths, 1, "sd/UI");
    table.insert(searchPaths, 1, "res/hd");
    table.insert(searchPaths, 1, "res/hd/UI");
    table.insert(searchPaths, 1, "res/hd/icon");
    table.insert(searchPaths, 1, "rhd");
    table.insert(searchPaths, 1, "rhd/UI");
    else
    table.insert(searchPaths, 1, "Resources");
    table.insert(searchPaths, 1, "res/hd");
    table.insert(searchPaths, 1, "res/hd/Resources");
    table.insert(searchPaths, 1, "res/hd/UI");
    table.insert(searchPaths, 1, "res/hd/icon");
    table.insert(searchPaths, 1, "sd");
    table.insert(searchPaths, 1, "sd/Resources");
    table.insert(searchPaths, 1, "rhd/Resources");
    end

    cc.FileUtils:getInstance():addSearchPath("res/hd/Resources")
    cc.FileUtils:getInstance():addSearchPath("res/hd/Resources/ui/share");
    cc.FileUtils:getInstance():addSearchPath("myRes");
    cc.FileUtils:getInstance():addSearchPath("music");
    cc.FileUtils:getInstance():addSearchPath("Script");

    cc.FileUtils:getInstance():addSearchPath("Script/Config");
    fileUtils:setSearchPaths(searchPaths)


    local write =  cc.FileUtils:getInstance():getWritablePath();
    ---todo 这个删除在 加载页面之前
    if cc.UserDefault:getInstance():getIntegerForKey("_Is_First_Start") == 0 then
        cc.UserDefault:getInstance():setIntegerForKey("_Is_First_Start", 1)
        FileUtilsEx:getInstance():deleteDir(write)
        cc.FileUtils:getInstance():createDirectory(write) 
    else 
        --cc.FileUtils:getInstance():removeDirectory(write.."update/")
        --cc.FileUtils:getInstance():removeDirectory(write.."xbreakfiles/")
    end  


    cc.FileUtils:getInstance():addSearchPath(write.."xbreakfiles",true);

-----update 更新路径 ---todo 在热更新策略的时候，需要判断下是不是要删除当前热更新的东西
---新包 删除热更新文件夹
---这个在Android不生效。需要测试下
    local updatePath = write.."update/" 
    if not (cc.FileUtils:getInstance():isDirectoryExist(updatePath)) then         
        cc.FileUtils:getInstance():createDirectory(updatePath)  
        cc.UserDefault:getInstance():setIntegerForKey("_Is_First_Start_update", 1)
    else 
        if cc.UserDefault:getInstance():getIntegerForKey("_Is_First_Start_update") == 0 then
            cc.UserDefault:getInstance():setIntegerForKey("_Is_First_Start_update", 1)
            --FileUtilsEx:getInstance():deleteDir(updatePath)
            cc.FileUtils:getInstance():createDirectory(updatePath) 
        end   
    end

    local searchPaths = cc.FileUtils:getInstance():getSearchPaths()
    local m_seach = {
        updatePath,
        updatePath .. "res",
        updatePath .. "src",
        "res/fonts",
        "res/hd/icon/",
        "res/hd/UI/",
        "res/hd/Resources/",
        "res/hd/",
        "Resources/",
        "res/testHero/testUI/",
        "res/testHero/",
        "src/ui/",
        "src/sdk/",
        "src/data/",
        "res/uifile/",
        "res/uifile/MaskUI/",
        "src/Act/",
        "src/Act_2/",
        "res/Manifests/",
        "src/ddBattle/",
        "src/lemon/",
        "src/lemon/util/",
        "src/userdata/",
       	"src/ui/AllianceBattle",
	"src/Chat"
       
    }
    for i=1,#m_seach do
    local path = m_seach[i]
    if i>3 then 
            path = updatePath..path
    end 
        table.insert(searchPaths, i, path) 
    end
    
    -- table.insert(searchPaths,#m_seach + 1, write.."voicedl/")
    -- table.insert(searchPaths,#m_seach + 2, write.."voicedl/voice/")
    table.insert(searchPaths,#m_seach + 1, write.."voicejp/")
    table.insert(searchPaths,#m_seach + 2, write.."voicejp/voice/")
     table.insert(searchPaths,#m_seach + 3, write.."voicekorea/")
    table.insert(searchPaths,#m_seach + 4, write.."voicekorea/voice/")
    table.insert(searchPaths,#m_seach + 5, "voice/manifests/")
    cc.FileUtils:getInstance():setSearchPaths(searchPaths)


    ccui.Button:insertEffectType(1,"music/ui/touchlong.mp3",false)
    ccui.Button:insertEffectType(2,"music/ui/touchlong.mp3",true)
    ccui.Button:insertEffectType(3,"music/ui/touchclose.mp3",false)

------------------------------------------------
    --require "main"
    require "UpdateManager"

    UpdateManager = UpdateManager.new()
    UpdateManager:checkUpdate()

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) or
    (cc.PLATFORM_OS_ANDROID == targetPlatform) or (cc.PLATFORM_OS_WINDOWS == targetPlatform) or
    (cc.PLATFORM_OS_MAC == targetPlatform) then
    cclog("result is ")
    end
end

--设置搜索路径前去掉多余的update路径
function removeUpdateFileSearchPath()
    -- body

    local searchPaths = cc.FileUtils:getInstance():getSearchPaths()
    local write =  cc.FileUtils:getInstance():getWritablePath();
    local updatePath = write.."update/"
    for i = #searchPaths, 1, -1 do
        local path = searchPaths[i]
        if path == updatePath then

            table.remove(searchPaths, i)
            break
        end

    end
    cc.FileUtils:getInstance():setSearchPaths(searchPaths)
end

function versionCallBack(data)
data = tolua.cast(data, "PassData");
print("callBack-----"..data:getData())

end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    error(msg)
end
