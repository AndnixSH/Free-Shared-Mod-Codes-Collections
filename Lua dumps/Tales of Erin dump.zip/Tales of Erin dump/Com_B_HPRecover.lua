--每X秒增加X血。
--created by kobejaw. 2018.6.8.
Com_B_HPRecover = class("Com_B_HPRecover",ComponentBase)

--81031，81054
function Com_B_HPRecover:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.HPRecover

	self.seconds_hpRecover = self.comData.effect1 --每几秒恢复一次
	self.remainTime_hpRecover = 0
end

function Com_B_HPRecover:update(dt)
	self.remainTime_hpRecover = self.remainTime_hpRecover - dt
	if self.remainTime_hpRecover <= 0 then
		--播放特效
		self:playSpineAnimation(false)

		self.remainTime_hpRecover = self.seconds_hpRecover

		local hp
		if self.target.componentManager.EGuiChanRen then
			hp = 0
		else
			hp = math.floor(self.comData.effect4/1000 * self.target.attr[AE.hp_max] * self.target.attributeManager:getRecover()/100)
			self.target.attributeManager:changeAttr(AE.hp,hp)

			--触发时机5.受治疗时
			local opt = {}
			opt.trig_time = 5
			opt.affectedEntity = self.target --注：受治疗时的affectedEntity在这里指被治疗者，在治疗技能里为治疗者。有点乱，暂时先这样。
			opt.isCrit = false
			self.target.triggerManager:check(5,opt)
		end
		
		--飘字
		BattleDamageDisplay:create(self.target:getDamageShowingPos(false),hp,DamageFontType.AddHP)
	end

	self.super.update(self,dt)
end
