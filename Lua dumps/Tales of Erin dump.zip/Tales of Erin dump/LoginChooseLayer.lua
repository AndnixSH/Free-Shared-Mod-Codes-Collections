--[[
info:
登录选择界面
]]



LoginChooseLayer = class("LoginChooseLayer")

function LoginChooseLayer:init()
   
    
    self:initView();
    self:addBtnListener();
    self:refreshView();
   
end

function LoginChooseLayer:initView()
    local  node = cc.CSLoader:createNode("LoginChooseLayer.csb");
    self.uiLayer:addChild(node,0,1);   
    self.uiLayer:setVisible(false)
    self._rootCSbNode = node:getChildByTag(62);
    
    self._Button_face_book = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_face_book");
    self._Button_google_play = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_google_play");
    self._Button_guest = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_guest");
    
      
end

function  LoginChooseLayer:refreshView()
    --self:refreshBtn();
    local userLoginType = XBConfigManager:getInstance():getGlobalStringByKey("LOGIN_PLATFORM_TYPE")
    -- local userLoginType = cc.UserDefault:getInstance():getStringForKey("LOGIN_PLATFORM_TYPE")
    if userLoginType == "googleplay" then

        self:loginGooglePlay();
    elseif userLoginType == "facebook" then

        self:loginFaceBook();
    else
        self.uiLayer:setVisible(true)
        self:refreshBtn();
    end
    
    
end

function  LoginChooseLayer:refreshBtn()
    -- body
    local targetPlatform = cc.Application:getInstance():getTargetPlatform();

     if (cc.PLATFORM_OS_IPHONE == targetPlatform) 
        or (cc.PLATFORM_OS_IPAD == targetPlatform) 
        or (cc.PLATFORM_OS_MAC == targetPlatform) then

        self._Button_google_play:setVisible(false);
        
    elseif cc.PLATFORM_OS_ANDROID == targetPlatform then
        
        self._Button_guest:setVisible(false);


    end


end


function LoginChooseLayer:addBtnListener()
   
    local this = self;
    self._Button_face_book:addClickEventListener(function (pSender)
        
        this:obBtnFaceBookCallBack(pSender);
    end);

    self._Button_google_play:addClickEventListener(function (pSender)
        
        this:obBtnGooglePlayCallBack(pSender);
    end);

    if self._Button_guest == nil then
        return
    end
    self._Button_guest:addClickEventListener(function (pSender)
        
        this:obBtnGuestCallBack(pSender);
    end);
end

function LoginChooseLayer:obBtnFaceBookCallBack(sender)
    print("点击按钮 FACE BOOK");
    self:loginFaceBook();
   
    
end



function LoginChooseLayer:loginFaceBook()
   
    local platform = cc.Application:getInstance():getTargetPlatform()
    if (cc.PLATFORM_OS_IPHONE == platform) 
        or (cc.PLATFORM_OS_IPAD == platform)
         or (cc.PLATFORM_OS_MAC == platform) then
     --todo 处理 ios sdk 登陆 
     
        SDKManagerLua:showLogin()
        self.uiLayer:setVisible(false)
        
    elseif cc.PLATFORM_OS_ANDROID == platform then
         --类型2是facebook
        SDKManagerLua.txType = 2
        SDKManagerLua:showLogin()
    end
   
    
end

function LoginChooseLayer:obBtnGooglePlayCallBack(pSender)
    print("点击按钮 GooglePlay");
    
    self:loginGooglePlay();
   
end

function LoginChooseLayer:loginGooglePlay(pSender)
    print("点击按钮 GooglePlay");
    local platform = cc.Application:getInstance():getTargetPlatform()
    --self.uiLayer:setVisible(false);
    if(cc.PLATFORM_OS_ANDROID == platform) then
        
         --类型1是google play
        SDKManagerLua.txType = 1
        SDKManagerLua:showLogin()



    end
   
end

function LoginChooseLayer:obBtnGuestCallBack(pSender)
    print("点击按钮 Guest");
    --self.uiLayer:setVisible(false);
    if (cc.PLATFORM_OS_IPHONE == platform) or (cc.PLATFORM_OS_IPAD == platform) then
     
    end


    
end






function LoginChooseLayer:create()
     local layer = LoginChooseLayer.new()
     layer.uiLayer = cc.Layer:create()
     layer:init();
     return layer;
end
