--require "XUIView"

SthLevelUpView = class("SthLevelUpView",XUIView)
SthLevelUpView.CS_FILE_NAME = "SthLevelUpView.csb"
SthLevelUpView.CS_BIND_TABLE = 
{
    panelEffect = "/i:432",
    effLevel = "/i:432/s:effLevel",
    effExpbar = "/i:432/s:effExpbar",
    effExpball = "/i:432/s:effExpball",

    lbCurLv = "/i:172/i:173",
    lbMaxLv = "/i:172/i:175",
    lbNextExp = "/i:172/i:176",
    spBarBg = "/i:172/i:177",
    lbAddLv = "/i:172/i:174",
    barCur = "/i:172/i:178",
    barAdd = "/i:172/i:199"
}

function SthLevelUpView:init(rootNode)
    SthLevelUpView.super.init(self,rootNode)

    -- self.expTable = {123,456,789}
    -- self.curExp = 0
    -- self.curLv = 123
    -- self.maxLv = 456
    -- self.addExp = 123467

    self.lbMaxLv:setString("")
    self.lbCurLv:setString("")
    self.lbAddLv:setString("")
    self.lbNextExp:setString("")
    self.barCur:setPercent(100 * 0)
    self.barAdd:setPercent(100 * 0)

    return self
end

function SthLevelUpView:setLevelInfo(expTable,curLv,maxLv,curExp)
    self.expTable = expTable
    self.curExp = curExp
    self.curLv = curLv
    self.maxLv = maxLv
    self.addExp = 0
    self.finalLevel = self.curLv

    self.finalExp = 0  --动画用
    self.finalExpNext = 0 --动画用

    self:setMaxLv(self.maxLv)
    self:setCurLv(self.curLv)
    --dump(self, "sthlevelUpView..setLevelInfo:"..curLv)
    self:refresh()
end

function SthLevelUpView:setAddExp(exp)
    self.addExp = exp
    self:refresh()
end

function SthLevelUpView:getFinalLevel()
    local tempMax = math.min(self.maxLv, #self.expTable)
    -- self.finalLevel = min(self.finalLevel,#self.expTable )
    return self.finalLevel , (self.finalLevel >= tempMax)
end

function SthLevelUpView:setMaxLv(lv)
    if lv > 0 then
        self.lbMaxLv:setString(string.format(UITool.ToLocalization("等级上限 %d"),lv))
    else
        self.lbMaxLv:setString("")
    end
end

function SthLevelUpView:setCurLv(lv)
    if lv > 0 then
        self.lbCurLv:setString(string.format(UITool.ToLocalization("等级 %d"),lv))
    else
        self.lbCurLv:setString("")
    end
end

function SthLevelUpView:setAddLv(lv)
    if self.lbAddLv and tolua.isnull(self.lbAddLv) == false then
        if lv > 0 then
            self.lbAddLv:setString("+"..lv)
        else
            self.lbAddLv:setString("")
        end
    end
end

function SthLevelUpView:setNextExp(exp)
    if exp > 0 then
        self.lbNextExp:setString(string.format(UITool.ToLocalization("离下一级：%d"),exp))
    else
        self.lbNextExp:setString("")
    end
end

function SthLevelUpView:playLVEffect(type)
	if type == 1 then
		self:stopLVEffect()
		--self.lvping_handle = cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvuping.mp3", true)
        self.lvping_handle = AudioManager:shareDataManager():playMusic("music/ui/lvuping.mp3",0, true)
	else
		--cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false)
        AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3",0, false)
	end
end
function SthLevelUpView:stopLVEffect()
	if self.lvping_handle ~= nil then
		--cc.SimpleAudioEngine:getInstance():stopEffect(self.lvping_handle)
        AudioManager:shareDataManager():stop(self.lvping_handle)
		self.lvping_handle = nil
	end
end

function SthLevelUpView:playEffect()
    self.panelEffect:setVisible(true)
    --
    self.barAdd:setPercent(0)
    self.barCur:setPercent(0)
    self.lbAddLv:setString("")
    self.lbNextExp:setString("")

    local addlv = self.finalLevel - self.curLv

    local once_time = 0.4

    --经验条
    local nodeExpbar = cc.CSLoader:createNode("EffSthExpbar.csb")
    local timelineExpbar =cc.CSLoader:createTimeline("EffSthExpbar.csb")
    local psize = self.effExpbar:getSize()

    --裁切
    local clipNode = cc.ClippingNode:create()
    local clipSprite = cc.Sprite:create()
    local clipLayer = cc.Layer:create()
    clipSprite:setTexture("n_UIShare/role/sth/qhzx_ui_004.png")
    clipSprite:setPosition(cc.p(psize.width / 2 , psize.height / 2))
    clipNode:setAlphaThreshold(0.5)
    clipNode:setStencil(clipSprite)
    clipNode:addChild(clipLayer)    

    ---
    local pos_y = psize.height / 2
    nodeExpbar:runAction(timelineExpbar)
    timelineExpbar:play("animation0",true)
    self.effExpbar:addChild(clipNode,1,123)    ---
    clipLayer:addChild(nodeExpbar)             ---

    --经验球
    local nodeBall = cc.CSLoader:createNode("EffSthBall.csb")
    local timelineBall = cc.CSLoader:createTimeline("EffSthBall.csb")       
    local psize2 = self.effExpball:getSize()
    local pos_y2 = psize2.height / 2
    nodeBall:runAction(timelineBall)
    timelineBall:play("animation0",true)
    self.effExpball:addChild(nodeBall,2,123)

    local function playExpBarBall(ratio,ratio2,endFunc)
        --经验条
        nodeExpbar:setVisible(true)        
        nodeExpbar:setPosition(cc.p(ratio * psize.width,pos_y))
        local moveby = cc.MoveBy:create(ratio2 * once_time,
                                        cc.p( ratio2 * psize.width ,  0)
                                        )
        local seq = cc.Sequence:create(moveby, cc.CallFunc:create(endFunc))
        nodeExpbar:runAction(seq)

        --球
        nodeBall:setVisible(true)
        nodeBall:setPosition(cc.p(ratio * psize2.width,pos_y2))
        local moveby2 = cc.MoveBy:create(ratio2 * once_time,
                                        cc.p( ratio2 * psize2.width ,  0)
                                        )
        nodeBall:runAction(moveby2)

    end

    --球消失
    local nodeBallFade = cc.CSLoader:createNode("EffSthBallFade.csb")
    local timelineBallFade = cc.CSLoader:createTimeline("EffSthBallFade.csb")
    nodeBallFade:setPosition(cc.p(psize2.width,pos_y2))
    nodeBallFade:runAction(timelineBallFade)
    self.effExpball:addChild(nodeBallFade,3,234)

    --经验条满
    local nodeExpFull = cc.CSLoader:createNode("EffSthExpFull.csb")
    local timelineExpFull = cc.CSLoader:createTimeline("EffSthExpFull.csb")
    nodeExpFull:setPosition(cc.p(psize2.width / 2,pos_y2))
    nodeExpFull:runAction(timelineExpFull)
    self.effExpball:addChild(nodeExpFull,1,345)
    
    --等级上升
    local nodeLvnum = cc.CSLoader:createNode("EffSthLvnum.csb")
    local timelineLvnum = cc.CSLoader:createTimeline("EffSthLvnum.csb")
    local psize3 = self.effLevel:getSize()
    nodeLvnum:setPosition(cc.p(psize3.width / 2,0))
    nodeLvnum:runAction(timelineLvnum)
    self.effLevel:addChild(nodeLvnum,1,123)
                                     
    if addlv == 0 then
        --没升级，播一次涨条

        local tempNextExp = self.expTable[self.curLv]  --满级经验
        local ratio =  self.curExp / tempNextExp   --开始百分比
        local ratio2 = self.addExp / tempNextExp   --涨多少

        self:playLVEffect(1)
        playExpBarBall(ratio,ratio2,function()
            self:stopLVEffect()
            self:onEffectEnd()
        end)
    else
        -- 1次当前经验到满条
        -- addlv - 1次满条 
        -- 1次最后部分
        local nowlv = self.curLv

        local runBarFull = nil 

        local function runOnce()
            --走一条经验到满级
            self:playLVEffect(1)
            playExpBarBall(0,1,function()
                runBarFull()
            end)
            --已满级则停止
            --未满级则继续下一级
        end
        runBarFull = function()
            self:stopLVEffect()
            nodeBall:setVisible(false)
            nodeExpbar:setVisible(false)
            --满级三个闪光
            --runOnce()
            nowlv = nowlv + 1
            self:setCurLv(nowlv)


            if nowlv == self.finalLevel then
                --升级完毕，播最后                
                --timelineExpFull:clearLastFrameCallFunc()
                timelineExpFull:setLastFrameCallFunc(function()
                    local tempMax = math.min(self.maxLv, #self.expTable)

                    if (self.finalLevel >= tempMax) then
                        --已满级，不博最后一条
                            self:onEffectEnd()
                    else
                        --未满级，播最后一条
                        self:playLVEffect(1)
                        playExpBarBall(0,self.finalExp / self.finalExpNext,function()
                            self:stopLVEffect()
                            self:onEffectEnd()
                        end)
                    end
                end)
            end
            
            timelineBallFade:play("animation0",false)
            timelineExpFull:play("animation0",false)
            timelineLvnum:play("animation0",false)
            self:playLVEffect(2)

            if self.levelUpEffectEvent then
                self.levelUpEffectEvent(self)
            end
        end

        timelineExpFull:setLastFrameCallFunc(runOnce)

        local tempNextExp = self.expTable[self.curLv]  --满级经验
        local ratio =  self.curExp / tempNextExp   --开始百分比
        self:playLVEffect(1)
        playExpBarBall(ratio,(1-ratio),runBarFull)
    end



    -- --第一次
    -- self.curExp ,
    -- (tempNextExp - self.curExp) / tempNextExp   ~~~~  1

    -- 0 ~~~~ 1

    -- --最后一次
    -- 0 ~~ self.finalExp / self.finalExpNext
end

function SthLevelUpView:onEffectEnd()
    if self.effectEndEvent then
        self.effectEndEvent(self)
    else
        self:stopEffect()
    end
end

function SthLevelUpView:stopEffect()
    --self.panelEffect:stopAllActions()

    local effs = {
        self.effLevel,
        self.effExpball,
        self.effExpbar
    }

    for i = 1,#effs do
        -- local e = effs[i]:getChildByTag(123)
        -- if e then e:stopAllActions() end
        effs[i]:removeAllChildren()
    end

    self:stopLVEffect()
    self.panelEffect:setVisible(false)
end

function SthLevelUpView:refresh()
    if self.curLv > 0 then
        self.spBarBg:setVisible(true)
        local tempMax = math.min(self.maxLv, #self.expTable)
        local tempExp = self.curExp + self.addExp
        local tempNextExp = self.expTable[self.curLv]
        
        self.finalLevel = self.curLv
        
        while tempExp >= tempNextExp do
            self.finalLevel = self.finalLevel + 1
            tempExp = tempExp - tempNextExp
            tempNextExp = self.expTable[self.finalLevel]
            
            if self.finalLevel >= tempMax then --最大等级不能超出 #self.expTable
                self.finalLevel = tempMax
                break
            end
            print("self.finalLevel:"..self.finalLevel..".....tempMax:"..tempMax)
        end
        print("self.finalLevel2222:"..self.finalLevel..".....tempMax:"..tempMax)

        local tempaddlv = self.finalLevel - self.curLv
        self:setAddLv(tempaddlv)

        if self.finalLevel >= tempMax then --满级
        
            self.finalExp = 100
            self.finalExpNext = 100

            self:setNextExp(0)
            if tempaddlv == 0 then
                self.barAdd:setPercent(0)
                self.barCur:setPercent(100)
            elseif tempaddlv == 1 then
                -- 这个经验值是取的下一等级  满级为空证明以到最顶级了
                if tempNextExp == nil then
                    self.barCur:setPercent(100)
                else
                    self.barCur:setPercent(self.curExp / tempNextExp * 100)
                end
                
                self.barAdd:setPercent(100)
            else
                self.barAdd:setPercent(100)
                self.barCur:setPercent(0)
            end

        else
            self.finalExp = tempExp
            self.finalExpNext = tempNextExp

            self:setNextExp(tempNextExp - tempExp)

            self.barAdd:setPercent(tempExp / tempNextExp  * 100)
            if tempaddlv == 0 then
                self.barCur:setPercent(self.curExp / tempNextExp * 100)
            else
                self.barCur:setPercent(0)
            end
        end
    else
        self:setAddLv(0)
        self:setNextExp(0)
        self.barAdd:setPercent(0)
        self.barCur:setPercent(0)
        self.spBarBg:setVisible(false)
    end
end