--require "XUIView"

ConsoleView = class("ConsoleView",XUIView)

function ConsoleView.createBtn( text,pos_x,pos_y,func )
    local btnTester = ccui.Button:create("n_UIShare/Global_UI/btn/qhzx_b_002_1.png", "n_UIShare/Global_UI/btn/qhzx_b_002_2.png")
    btnTester:setTitleText(text)
    btnTester:setTitleFontSize(26)
    btnTester:setTitleFontName(TEXT_FONT_NAME)
    btnTester:setPosition(pos_x,pos_y)
    btnTester:addClickEventListener(func)
    
    return btnTester
end

function ConsoleView:init()
    ConsoleView.super.init(self)
    self.rootLayer = nil
    self.errlogLayer = nil
    self.errlogFiles = nil
    self.dialogListLayer = nil
    self.dialogFiles = nil
    self.downloadFileLayer = nil
    self.downloadFilelist = nil
    self.downloadFileIndex = 0
    self.dlIp = nil
    self.dlPort = nil
    self.maskLayer = nil
    self.msgText = nil
    
    self:initUI()
    return self
end 


function ConsoleView:initUI(  )
    --cc.Director:getInstance():setDisplayStats(true)
    --根容器
    local layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0,0))
    layout:setPosition(0,0)
    layout:setContentSize(1280,720)
    layout:setBackGroundColor(cc.c3b(0,0,0))
    layout:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layout:setTouchEnabled(true)
    
    self._rootNode:addChild(layout)
    
    self.maskLayer = ccui.Layout:create()
    self.maskLayer:setAnchorPoint(cc.p(0,0))
    self.maskLayer:setPosition(0,0)
    self.maskLayer:setContentSize(1280,720)
    self.maskLayer:setTouchEnabled(true)
    self._rootNode:addChild(self.maskLayer,100)
    self.maskLayer:setVisible(false)
    
    --消息提示
    self.msgText = ccui.Text:create("控制台",TEXT_FONT_NAME,26)
    self.msgText:setAnchorPoint(cc.p(0,0.5))
    self.msgText:setPosition(30,30)
    layout:addChild(self.msgText)
    
    self:initDialogList(layout)
    self:initErrlogList(layout)
    self:initDownloadLayer(layout)
    
    self.errlogLayer:setVisible(false)
    self.downloadFileLayer:setVisible(false)
    
    layout:addChild(ConsoleView.createBtn("剧情",1190,670,function (sender,eventType)
        --self:showDialog("story/c1s1e1l0.json")
        self.errlogLayer:setVisible(false)
        self.downloadFileLayer:setVisible(false)
        self.dialogListLayer:setVisible(true)

    end))
    
    layout:addChild(ConsoleView.createBtn("日志",1190,600,function (sender,eventType)
        --self:showDialog("story/c1s1e1l1.json")
        self:reloadErrlogList()
        self.errlogLayer:setVisible(true)
        self.downloadFileLayer:setVisible(false)
        self.dialogListLayer:setVisible(false)
    end))
        
    layout:addChild(ConsoleView.createBtn("更新",1190,530,function (sender,eventType)
        --asdfasdf()
        self.errlogLayer:setVisible(false)
        self.downloadFileLayer:setVisible(true)
        self.dialogListLayer:setVisible(false)
    end))

    --剧情循环播放
    local starIdx = 1
    layout:addChild(ConsoleView.createBtn("下一个",1190,390,function (sender,eventType)
        if starIdx >#self.dialogFiles then 
            starIdx = 1
        end 
        self:showDialog(self.dialogFiles[starIdx].filename)
        starIdx = starIdx + 1
    end))
        
    --退出按钮
    layout:addChild(ConsoleView.createBtn("退出",1190,35,function (sender,eventType)
        self:returnBack()
    end))
    
    self:reloadErrlogList()
    self:reloadDialogList()


end

function ConsoleView:initErrlogList( parent )
    local tempLayer = ccui.Layout:create()
    tempLayer:setAnchorPoint(cc.p(0,0))
    tempLayer:setContentSize(1100,660)
    tempLayer:setPosition(0,60)
    tempLayer:setBackGroundColor(cc.c3b(255,0,0))
    tempLayer:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    
    self.errlogLayer = tempLayer    

    tempLayer:addChild(ConsoleView.createBtn("清空",150,50,function (  )
        local wpath = cc.FileUtils:getInstance():getWritablePath()
        wpath = wpath.."ErrorLog/"
        
        cc.FileUtils:getInstance():removeDirectory(wpath)
        self:reloadErrlogList()
        self:showMsg("日志清空完成")
    end))
    
    local listView = ccui.ListView:create()
    listView:setItemsMargin(10)
    listView:setContentSize(300,560)
    listView:setPosition(0,100)
    listView:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    listView:setBackGroundColor(cc.c3b(0,255,0))
    self.errlogLayer:addChild(listView,0,98)
    
    local model = ccui.Layout:create()
    model:setAnchorPoint(cc.p(0,1))
    model:setContentSize(300,60)
    model:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    model:setBackGroundColor(cc.c3b(0,0,255))
    model:setTouchEnabled(true)
    
    local label = ccui.Text:create()
    --label:setContentSize(800,200)
    label:setFontSize(20)
    label:setFontName(TEXT_FONT_NAME)
    --label:setAnchorPoint(cc.p(0,0.5))
    label:setTextColor(cc.c3b(255,0,0))
    label:setPosition(150,30)
    model:addChild(label,0,123)
    
    listView:setItemModel(model)
    
    local textArea = ccui.Text:create("",TEXT_FONT_NAME,26)
    --textArea:setTextAreaSize(cc.size(800,0))
    textArea:ignoreContentAdaptWithSize(false)
    textArea:setContentSize(800,660)
    textArea:setAnchorPoint(cc.p(0,1))
    textArea:setPosition(300,660)
    textArea:setTextColor(cc.c3b(0,255,0))
    self.errlogLayer:addChild(textArea,0,99)
    
    parent:addChild(self.errlogLayer)
end

function ConsoleView:reloadErrlogList(  )
    local listview = self.errlogLayer:getChildByTag(98)
    listview:removeAllChildren()

    local text = self.errlogLayer:getChildByTag(99)    
    text:setText("")

    self.errlogFiles = nil

    local path = cc.FileUtils:getInstance():getWritablePath()
    path = path.."ErrorLog/"
    if not cc.FileUtils:getInstance():isDirectoryExist(path) then
        return
    end
 
    local listfile = path.."errlist.json"
    if not cc.FileUtils:getInstance():isFileExist(listfile) then
        return
    end
    
    local cjson  = require "cjson"
    
    local str = cc.FileUtils:getInstance():getStringFromFile(listfile)
    self.errlogFiles = cjson.decode(str)
    
    local function btnFunc ( sender,eventType )
            if eventType == ccui.TouchEventType.ended then
            --self:showMsg(self.errlogFiles[sender:getTag()])
                self:showErrLog(sender:getTag())
            end
        end
    
    for i=1,#self.errlogFiles do
        listview:pushBackDefaultItem()
        local item = listview:getItem(i-1)
        local text = item:getChildByTag(123)
        text:setText(self.errlogFiles[i])        
        item:setTag(i)
        item:addTouchEventListener(btnFunc)
    end
    
end

function ConsoleView:showErrLog( index )
    local filename = self.errlogFiles[index]
    
    local path = cc.FileUtils:getInstance():getWritablePath()
    path = path.."ErrorLog/"..filename 
    
    local str = cc.FileUtils:getInstance():getStringFromFile(path)
    
    local text = self.errlogLayer:getChildByTag(99)
    
    text:setText(str)
end

function ConsoleView:initDialogList( parent )
    local tempLayer = ccui.Layout:create()
    tempLayer:setAnchorPoint(cc.p(0,0))
    tempLayer:setContentSize(1100,660)
    tempLayer:setPosition(0,60)
    tempLayer:setBackGroundColor(cc.c3b(0,255,0))
    tempLayer:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    
    self.dialogListLayer = tempLayer

    local listView = ccui.ListView:create()
    listView:setItemsMargin(10)
    listView:setContentSize(600,650)
    listView:setPosition(200,10)
    --listView:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    --listView:setBackGroundColor(cc.c3b(0,0,255))
    self.dialogListLayer:addChild(listView,0,98)
    
    local model = ccui.Layout:create()
    model:setAnchorPoint(cc.p(0,1))
    model:setContentSize(600,60)
    model:setBackGroundColor(cc.c3b(0,0,255))
    model:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    model:setTouchEnabled(true)
    
    local label = ccui.Text:create()
    --label:setContentSize(800,200)
    label:setTextColor(cc.c3b(255,0,0))
    label:setFontSize(26)
    label:setFontName(TEXT_FONT_NAME)
    label:setPosition(300,30)
    model:addChild(label,0,123)
    
    listView:setItemModel(model)
    
    parent:addChild(self.dialogListLayer)
end

function ConsoleView:reloadDialogList(  )
    local listview = self.dialogListLayer:getChildByTag(98)
    listview:removeAllChildren()
    self.dialogFiles = nil
    
    
    --local path = cc.FileUtils:getInstance():getWritablePath()
    --path = path.."xbreakfiles/dialoglist.json"
    local path = "xbreakfiles/dialoglist.json"
    
    --sample   [{"title":"第一章","filename":"story/c1s1e1l0.json"}]
        
    if not cc.FileUtils:getInstance():isFileExist(path) then
        return
    end
    
    local cjson  = require "cjson"
    
    local str = cc.FileUtils:getInstance():getStringFromFile(path)
    
    self.dialogFiles = cjson.decode(str)
    
    local function btnFunc( sender, eventType )
        if eventType == ccui.TouchEventType.ended then                
            local obj = self.dialogFiles[sender:getTag()]
            if obj.filename ~= nil then
                self:showDialog(obj.filename)
            end
        end
    end
    
    
    
    for i=1,#self.dialogFiles do
        listview:pushBackDefaultItem()
        local item = listview:getItem(i-1)
        local text = item:getChildByTag(123)
        
        if self.dialogFiles[i].title ~=nil then
           text:setText(self.dialogFiles[i].title)   
        elseif self.dialogFiles[i].filename then
            text:setText(self.dialogFiles[i].filename)  
        end 
             
        item:setTag(i)
        item:addTouchEventListener(btnFunc)
    end
end

function ConsoleView:showMsg( text )
    self.msgText:setText(text)
end

function ConsoleView:showDialog( filename )
    local param = {}
    param["rcvData"] = {}
    param["rcvData"]["filename"] = filename
    param["rcvData"]["callFunc"] = function ( obj )
        self._rootNode:removeChildByTag(999)
    end 
    param["rcvData"]["obj"] = self 
    self:showMsg(filename)
    self._rootNode:addChild(DialogLayer:create(param).uiLayer,10,999)
end

function ConsoleView:initDownloadLayer( parent )
    local tempLayer = ccui.Layout:create()
    tempLayer:setAnchorPoint(cc.p(0,0))
    tempLayer:setContentSize(1100,660)
    tempLayer:setPosition(0,60)
    tempLayer:setBackGroundColor(cc.c3b(30,30,30))
    tempLayer:setBackGroundColorType(LAYOUT_COLOR_SOLID)
        
    self.downloadFileLayer = tempLayer
    parent:addChild(tempLayer)
    
    local strip = cc.UserDefault:getInstance():getStringForKey("console_ip")
    local strport = cc.UserDefault:getInstance():getStringForKey("console_port")
    
    local textfiled = ccui.TextField:create("ip address",TEXT_FONT_NAME,26)
    -- textfiled:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    -- textfiled:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    -- textfiled:ignoreContentAdaptWithSize(true)
    textfiled:setTextAreaSize(cc.size(200,60))
    textfiled:setAnchorPoint(cc.p(0,0))
    textfiled:setPosition(0,0)
    if strip ~= "" then
        textfiled:setText(strip)
    else
        textfiled:setText("127.0.0.1")
    end
    textfiled:setTouchAreaEnabled(true)
    textfiled:setTouchSize(cc.size(200,60))
    
    local layer2 = ccui.Layout:create()
    layer2:setContentSize(200,60)
    layer2:setPosition(200,400)
    layer2:setBackGroundColor(cc.c3b(100,0,0))
    layer2:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layer2:addChild(textfiled,0,123)
    
    tempLayer:addChild(layer2,0,10)
    
    textfiled = nil
    layer2 = nil
    
    textfiled = ccui.TextField:create("port",TEXT_FONT_NAME,26)
    -- textfiled:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    -- textfiled:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    -- textfiled:ignoreContentAdaptWithSize(true)
    textfiled:setTextAreaSize(cc.size(200,60))
    textfiled:setAnchorPoint(cc.p(0,0))
    textfiled:setPosition(0,0)
    if strport ~= "" then
        textfiled:setText(strport)
    else
        textfiled:setText("8080")
    end
    textfiled:setTouchAreaEnabled(true)
    textfiled:setTouchSize(cc.size(200,60))
    
    layer2 = ccui.Layout:create()
    layer2:setContentSize(200,60)
    layer2:setPosition(200,300)
    layer2:setBackGroundColor(cc.c3b(100,0,0))
    layer2:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layer2:addChild(textfiled,0,123)
    
    tempLayer:addChild(layer2,0,11)
    
    tempLayer:addChild(ConsoleView.createBtn("开始",500,400,function (  )
        self:beginDownload()
    end))
    tempLayer:addChild(ConsoleView.createBtn("清空",500,200,function (  )
        local wpath = cc.FileUtils:getInstance():getWritablePath()
        wpath = wpath.."xbreakfiles/"
        
        cc.FileUtils:getInstance():removeDirectory(wpath)
        self:showMsg("清空数据完成，需重启游戏")
    end))

    tempLayer:addChild(ConsoleView.createBtn("播放",500,600,function (  )
        local str1 = "music/battle/"..self.downloadFileLayer:getChildByTag(11):getChildByTag(123):getString()..".mp3"
        --cc.SimpleAudioEngine:getInstance():stopMusic()
        AudioManager:shareDataManager():stopBGMusic();
        AudioManager:shareDataManager():playBGMusic(str1,true)
    end))
end

function ConsoleView:beginDownload(  )
    local tfIp = self.downloadFileLayer:getChildByTag(10):getChildByTag(123)
    local tfPort = self.downloadFileLayer:getChildByTag(11):getChildByTag(123)
    
    self.dlIp = tfIp:getString()
    self.dlPort = tfPort:getString()
    
    self.maskLayer:setVisible(true)
    self:showMsg("获取文件列表...")
    
    local xhr = cc.XMLHttpRequest:new()  
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON --返回数据类型  
    xhr:open("GET", "http://"..self.dlIp..":"..self.dlPort.."/filelist.json")      -- 地址  
    -- xhr:setRequestHeader("username", "xxxx")    -- 提交的参数  
    -- xhr:setRequestHeader("password", "xxxx")    -- 提交的参数  
      
    local function onReadyStateChange() 
        if xhr.status ~= 200 then
            self:showMsg("获取文件列表错误")
            self.maskLayer:setVisible(false)
            return  
        end
        
        cc.UserDefault:getInstance():setStringForKey("console_ip",self.dlIp)
        cc.UserDefault:getInstance():setStringForKey("console_port",self.dlPort)
    
        local str = xhr.response
            
        local cjson  = require "cjson"
        local templist = cjson.decode(str)

        self.downloadFilelist = templist["files"]
        self.downloadFileIndex = 0
        self:beginDownloadFile()
        
        
        
        -- local path = cc.FileUtils:getInstance():getWritablePath()
        -- path = path.."a.out"
        
        -- local file = io.open(path,"wb")
        -- file:write(data)
        -- file:close()
    end  
      
    xhr:registerScriptHandler(onReadyStateChange)  
    xhr:send()
end

function ConsoleView:beginDownloadFile(  )
    -- body
    self.downloadFileIndex = self.downloadFileIndex + 1
    if self.downloadFilelist == nil or self.downloadFileIndex > #self.downloadFilelist then
        self:showMsg("下载完成")
        self.maskLayer:setVisible(false)
        return
    end
    
    local index = self.downloadFileIndex
    local path = self.downloadFilelist[index].url
    local localpath = self.downloadFilelist[index].path
    local url = "http://"..self.dlIp..":"..self.dlPort.."/"..path
    
    self:showMsg("下载文件 : "..path)
    
    local xhr = cc.XMLHttpRequest:new()  
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_BLOB --返回数据类型 
    xhr:open("GET", url)      -- 地址   
    
    local function onReadyStateChange() 
        if xhr.status ~= 200 then
            self:showMsg("获取文件错误 : "..path)
            self.maskLayer:setVisible(false)
            return  
        end
        
        local wpath = cc.FileUtils:getInstance():getWritablePath()
        wpath = wpath.."xbreakfiles/"..localpath

        local ts = string.reverse(wpath)
        local i = string.find(ts, "/")
        local m = string.len(ts) - i + 1
        local dic = string.sub(wpath, 1, m)
        
        cc.FileUtils:getInstance():createDirectory(dic)
        
        local file = io.open(wpath,"wb")
        file:write(xhr.response)
        file:close()
        
        self:beginDownloadFile()
    end
    xhr:registerScriptHandler(onReadyStateChange)  
    xhr:send()
end

-- function ConsoleView:onNavigateTo(isback)
--     GameManagerInst:setTitleUIType(nil,3)
-- end
function ConsoleView:returnBack()

        if self._navigationView then
            self._navigationView:popView()
        elseif self._parentView then
            self:removeFromParentView()
        else
            self:getRootNode():removeFromParent()
        end
end