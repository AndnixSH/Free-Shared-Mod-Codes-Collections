--暂停界面

BattlePauseLayer = class("BattlePauseLayer", function()
    return cc.Layer:create();
end);

BattlePauseLayer.rootNode = nil

BattlePauseLayer.Player_UI_PATH  = "uifile/PlayerLIst.csb"

function BattlePauseLayer:ctor()
    self.rootNode = cc.CSLoader:createNode(self.Player_UI_PATH)
    self:addChild(self.rootNode)
    self:init()
end

function BattlePauseLayer:init()
    function touckCallBack(sender,eventType )
      	local tag = sender:getTag()
    	if eventType == ccui.TouchEventType.ended then
            sender:setEnabled(false)
    	    if tag == 21 then
                --放弃战斗
                if G_STAGE_TYPE == 1 then
                    G_BattleScene:onBattleOver(3)
                elseif G_STAGE_TYPE == 2 then
                    G_BattleScene:onBattleOver(6)
                elseif G_STAGE_TYPE == 3 then
                    G_BattleScene:onBattleOver(9)
                end
    	    elseif tag == 22 then
                G_BattleScene:resumeGame() 
                BattleUIManager:showPause(false)
    	    elseif tag == 23 then
                --暂时撤退
                G_BattleScene:onBattleOver(7)
    	    end
        end
    end

	for i = 21, 23 do
	   local btn = self.rootNode:getChildByTag(i)
       btn:addTouchEventListener(touckCallBack)
       if (G_STAGE_TYPE==1 or  G_STAGE_TYPE ==3 ) and i==23 then 
           btn:setVisible(false)
       end
	end

	if G_STAGE_TYPE == 2 then
       self:getPlayerInfoFromSever()
	end 	
end

function BattlePauseLayer:refshPlayers(plays)
	for i = 1, #plays do
		local img = self.rootNode:getChildByTag(i)
		img:setVisible(true)
        local hp = img:getChildByTag(i*100+1)
        local name = img:getChildByTag(i*100+3)
        local hp_num = plays[i]["hero_num"]
        local data_name = plays[i]["player_name"]
        local hpImg = "uifile/n_UIShare/zhandou/menue/drzd_ui_014.png"
        if hp_num < 2 then 
           hpImg = "uifile/n_UIShare/zhandou/menue/drzd_ui_017.png"
        elseif hp_num < 3 then
           hpImg = "uifile/n_UIShare/zhandou/menue/drzd_ui_016.png"   
         end 

         if hp_num <0 then
         	hp_num = 0
         end 
         hp:loadTexture(hpImg)
         hp:setPercent(hp_num*100/4)

         if data_name and name then
            name:setString(data_name)
         end
	end

end	

function BattlePauseLayer:getPlayerInfoFromSever()
	local function reiceSthCallBack(data)
		 data = tolua.cast(data, "PassData");
         print("callBack-----"..data:getData())
        if SceneManager ~= nil then
            SceneManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil or t_data["data"]["state_code"] ~=1 then           
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常,请点击确认尝试重新连接!"), self, self.getPlayerInfoFromSever)
            --todo 处理错误数据页面跳转逻辑
            return
        end
        self:refshPlayers(t_data["data"]["members"])
    end
   local cjson = require "cjson"
    SceneManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "multi_member"
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end