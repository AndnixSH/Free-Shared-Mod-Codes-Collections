--/*说明
	--星盘区处理
	--  星盘的基类 处理通用的部分
	--  新加的AstrolabeAreaScal 是缩略图的处理
	--  新加的AstrolabeAreaMian 是主区
--*/
AstrolabeAreaBase = {}
--[[ init
	_type:
		0 是缩略图   1 是主区
	node:
		每一区星盘的父节点
	svtable:
		服务器获取的星盘数据
	roleData：
		也是服务器，从角色详情中取出的数据整理成的表
	areaTable：
		本地表的数据
	curAreaIndex:
		当前选择的区域
	hero_id
	rcvData	_type,node,svtable,roleData,curAreaIndex
]]
function AstrolabeAreaBase:init(rcvData)
	if rcvData["asrMianLaSelf"] then
		self.asrMianLaSelf     = rcvData["asrMianLaSelf"]
	else
		self.asrMianLaSelf     = nil
	end
	self.rootNode       = rcvData["rootNode"]
	--回调函数
	self.refreshCallFunc    = rcvData["refreshCallFunc"]
	--当前区域
    self.curAreaIndex   = rcvData["curAreaIndex"]
    self.rcvData        = rcvData["severData"]
    -- 
    self.newRoleStarSelf = rcvData["newRoleStarSelf"]

    --服务器数据	  这是一段数据只取出跟星盘有管的数据    
    self.serverData   = rcvData["severData"]["astrolabe"]["astr_area"][tostring(self.curAreaIndex)]
    --角色详情星盘需要的数据 
    self.roleData     = rcvData["roleData"]
    --类型 
    self._type        = rcvData["_type"]

    self.hero_id      = rcvData["hero_id"]
    self.hero_sub_id = getNumID(self.hero_id)
    print("self.hero_sub_id  areaTable== "..self.hero_sub_id)
    print("self.curAreaIndex areaTable == "..self.curAreaIndex)
    --本地表数据
    self.areaTable  = hero_astrolabe[self.hero_sub_id]["areas"][self.curAreaIndex]
    --星盘属性长度
    self.len        = #self.areaTable["stars"]
   
    --解锁图片
    self.unLockImage     = "res/uifile/n_UIShare/astrolabe/xp_ui_061.png"
    --解锁升级过图片
    self.unLockAddImage  = "res/uifile/n_UIShare/astrolabe/xp_ui_062.png"
    --未解锁
    self.lockImage      = "res/uifile/n_UIShare/astrolabe/xp_ui_063.png"
    if self._type == 1 then
    	-- 解锁链接条
		self.unLockBar      = "res/uifile/n_UIShare/astrolabe/xp_ui_067.png"
		--未解锁链接条
		self.LockBar      = "res/uifile/n_UIShare/astrolabe/xp_ui_068.png"
    else
		-- 解锁链接条
		self.unLockBar      = "res/uifile/n_UIShare/astrolabe/xp_ui_069.png"
		--未解锁链接条
		self.LockBar      = "res/uifile/n_UIShare/astrolabe/xp_ui_070.png"
		--缩略图解锁条件
		self.panelLock        = self.rootNode:getChildByName("Panel_lock")
	end
    self:showArea()
end

function AstrolabeAreaBase:showArea( ... )
	for i = 1,self.len do
		self:unLockFunc(i)
    end
    if self._type == 0 then --缩略图
    	AstrolabeAreaScal:init(self)
    else
    	AstrolabeAreaMain:init(self)
    end
   -- self:scalShowScalEx()
end
--[[ 判断的两种情况 与 和 或
	或：
		每一项都有一个前置解锁条件表 star_unlock_tree 这是本地数据在 hero_astrolabe里
		取出前置表每一项，跟服务器数据进行对比（此条件是或的关系，但需要遍历所有，未达成和达成的链接线绘制不一样）
		前置是别项的等级，允许自项解锁（还需要与的判断）
	与：
		每一项有一个与的条件解锁表 star_unlock 这是本地数据在 hero_astrolabe里
		取出每一个字段和服务器数据进行对比（这个服务器数据是在角色详情界面传过来的）
		条件达成，才允许自项解锁

]]
function AstrolabeAreaBase:unLockFunc(_id)
	--获取node子项
	local imageChild = self.rootNode:getChildByName("Image_".._id)
	local imageFrom  = imageChild:getChildByName("Image_2")
	local textName   = imageChild:getChildByName("Text_1")
	local lvCM       = imageChild:getChildByName("Text_1_0")
	--本地数据
	local curOnlyT  = self:getOnlyData(_id)
	--本地数据 前置解锁条件表
	local orTable  = curOnlyT["star_unlock_tree"]
	--本地数据 自身解锁需要达成的条件
	local andTabel = curOnlyT["star_unlock"]
	local orLen    = #orTable 

	--服务器记录当前ID的等级
	local svLv  = self.serverData["stars"][tostring(_id)]
	local skillTable = astrolabe_skill[self.hero_sub_id][curOnlyT["star_sk_id"]]
	local idFrame = ""
	if skillTable["frame"] == 1 then
		idFrame = "res/uifile/n_UIShare/astrolabe/xp_ui_064.png"
	elseif skillTable["frame"] == 2 then
		idFrame = "res/uifile/n_UIShare/astrolabe/xp_ui_065.png"
	elseif skillTable["frame"] == 3 then
		idFrame = "res/uifile/n_UIShare/astrolabe/xp_ui_066.png"
	end
	imageFrom:loadTexture(idFrame)
	textName:setString(UITool.getUserLanguage(skillTable["name"]))
	lvCM:setString(""..svLv.."/"..skillTable["max_lv"])
	self:conditionalFunc(orLen,curOnlyT,_id,imageChild)
end
--[[
	根据前置解锁条件 和自身解锁条件 和服务器数据进行对比 显示自身状态 
	onlySvLv 或取服务器自身等级(根据自身等级显示对应图片)
	c_svLv   或取服务器前置解锁条件的等级

]]
function AstrolabeAreaBase:conditionalFunc(orLen,curOnlyT,_id,imageChild )

	local orTable  = curOnlyT["star_unlock_tree"]
	--本地数据 自身解锁需要达成的条件
	local andTabel = curOnlyT["star_unlock"]
	local skillTable  = astrolabe_skill[self.hero_sub_id][curOnlyT["star_sk_id"]]
	local image_icon  = imageChild:getChildByName("Image_icon")
	local onlySvLv   = self.serverData["stars"][tostring(_id)]

	local isTrue = self:andTrue(andTabel)
	-- 如果orLen等于零代表不需要前置解锁条件(需要根据自身等级显示图片)

	if orLen == 0 then
		if isTrue then
			--大于零是解锁升级过
			if onlySvLv > 0 then
				if onlySvLv >= skillTable["max_lv"] then
					imageChild:loadTexture(self.unLockAddImage)
					self:playSkillFullEffc(imageChild)
				else
					imageChild:loadTexture(self.unLockImage)
					
				end

			else
				imageChild:loadTexture(self.unLockImage)
			end
			if image_icon then
				image_icon:loadTexture(skillTable["icon_unlock"])
			end
		else
			if image_icon then
				image_icon:loadTexture(skillTable["icon_locked"])
			end
			imageChild:loadTexture(self.lockImage)
		end
		return
	end
	--需要前置解锁条件的
	-- 循环取出前置的解锁条件
	-- 跟服务器对比前置条件是否达成 前置是或的关系达成
	print("_id _id _id == ".._id)
	local isLocke  = false
	for i = 1 , orLen do

		local c_id    = orTable[i]["star_id"]
		local c_lv    = orTable[i]["star_lv"]
		local c_svLv  = self.serverData["stars"][tostring(c_id)]	

		--[[
			从本地表中读取前置解锁条件表，进行服务器数据对比，是否达成条件
			达成条件在进行与的比较 andTrue
		]]
		local catString = self:getSortID( c_id,_id)
	
		local imageBar = self.rootNode:getChildByName("Image_"..catString)
		--是否达成过条件
		
		if c_svLv >= c_lv then
			
			print("self.rootNode == "..self.rootNode:getName())
			print("imageBar imageBar == "..catString)
			--print("star_id === "..[curOnlyT["star_sk_id"])
			if isTrue then
				print("isTrue isTrue _id == ".._id)
				--大于零是解锁升级过(是根据自身等级显示自己状态图)
				if onlySvLv > 0 then
					print("onlySvLv > 0 == ".._id)
					print("name name == "..imageChild:getName())
					if onlySvLv >= skillTable["max_lv"] then
						imageChild:loadTexture(self.unLockAddImage)
						self:playSkillFullEffc(imageChild)
					else
						imageChild:loadTexture(self.unLockImage)
						
					end
				else
					print("onlySvLv == 0 == ".._id)
					print("onlySvLv == 0 name name == "..imageChild:getName())
					imageChild:loadTexture(self.unLockImage)
				end
				if image_icon then 
					image_icon:loadTexture(skillTable["icon_unlock"])
				end

				--根据条件是否达成显示连接线
				imageBar:loadTexture(self.unLockBar)
			else
				--没有解锁
				if image_icon then
					image_icon:loadTexture(skillTable["icon_locked"])
				end
				imageChild:loadTexture(self.lockImage)
				imageBar:loadTexture(self.LockBar)
			end
			isLocke = true
			--return
		else
			if isLocke  == true then
				return
			end
			if image_icon then
				image_icon:loadTexture(skillTable["icon_locked"])
			end
			imageChild:loadTexture(self.lockImage)
			imageBar:loadTexture(self.LockBar)
		end
	end 
end
--[[
	双向解锁，通用一条解锁条，最小的ID在前
]]
function AstrolabeAreaBase:getSortID( c_id,_id )
	-- body
	if c_id > _id then
		return "".._id.."_"..c_id
	else
		return ""..c_id.."_".._id
	end
end
--与的判断条件 ID的判断
function AstrolabeAreaBase:andTrue( _tabel )
	-- body
	local andTable = _tabel
	if self.roleData.hero_lv >= andTable.hero_lv and self.roleData.hero_add >= andTable.hero_add and
		self.roleData.feeling_lv >= andTable.feeling_lv and self.roleData.soul_lv >= andTable.soul_lv and
		self.rcvData["astrolabe"]["lv"]  >= andTable.astro_lv and self.roleData.hero_sk_add and andTable.hero_sk_add and
		self.rcvData["astrolabe"]["used_items"] >= andTable.astro_sk_add then
		return true
	else
		return false
	end
 
end
--播放满级技能特效
function AstrolabeAreaBase:playSkillFullEffc(spinNode)
    local spineRoot = spinNode
    if spineRoot:getChildByTag(123) then
    	spineRoot:getChildByTag(123):stopAllActions()
    	spineRoot:getChildByTag(123):removeFromParent()
    end

    local id_str = "res/uifile/n_UIShare/astrolabe/xing_pan_man_ji/xing_pan_man_ji.atlas"--title_conf[tonumber(item_id)].res_spine
    if cc.FileUtils:getInstance():isFileExist(id_str) then 
        local skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(id_str))
        local size = spineRoot:getSize()
        skeletonNode:setPosition(size.width/2+2,size.height/2)
        skeletonNode:registerSpineEventHandler(
            function (event) 
            	print(string.format("-------=====[spine] %d end:", event.trackIndex))
               -- self.baseSelf.refreshCallFunc(self.baseSelf.newRoleStarSelf)
        end, sp.EventType.ANIMATION_END)
        
        spineRoot:addChild(skeletonNode,123,123)
        skeletonNode:addAnimation(1,"effect",true)
        
    else 
          print("文件不存在 error file not exist:"..id_str)
    end
    
end
function AstrolabeAreaBase:clearEffe( ... )
	-- body
end
--数据表的结构需要遍历取，不支持数组形式封装次函数
-- 获取本地表每个id的解锁条件
function AstrolabeAreaBase:getOnlyData( id )
	print("id   == "..id)
	local len = #self.areaTable["stars"]
	print("len == "..len)
	for i = 1 , len do
		if id == self.areaTable["stars"][i]["star_id"] then
			return self.areaTable["stars"][i]
		end
	end
	return nil
end	




