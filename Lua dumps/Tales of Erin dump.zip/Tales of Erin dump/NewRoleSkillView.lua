--require "XUIView"

NewRoleSkillView = class("NewRoleSkillView",XUIView)
NewRoleSkillView.CS_FILE_NAME = "NewRoleSkillView.csb"
NewRoleSkillView.CS_BIND_TABLE = 
{
    --skill
    skill1 = "/i:950",
    skill2 = "/i:951",
    skill3 = "/i:952",
    skill4 = "/i:953",
    pSkillNormal = "/i:954",
    pSkillNormalButtons = "/i:954/i:548",
    btnBuySP = "/i:954/i:548/i:244",
    btnSkillReset = "/i:954/i:548/i:956",
    btnSkillResetText = "/i:954/i:548/i:956/i:1190",
    btnSkillAdd = "/i:954/i:548/i:958",
    pSkillAdd = "/i:955",
    btnSkillCancel = "/i:955/i:960",
    btnSkillCommit = "/i:955/i:962",
    spPanel = "/i:549",
    spLeft = "/i:549/i:551",

    skDescPanel = "/s:panelSkillDesc",
    skDescPos1 = "/s:panelSkillDesc/s:descpos1",
    skDescPos2 = "/s:panelSkillDesc/s:descpos2",
    skDescPos3 = "/s:panelSkillDesc/s:descpos3",
    skDescPos4 = "/s:panelSkillDesc/s:descpos4",
    skDescTouch1 = "/s:panelSkillDesc/s:skDesTouch1",
    skDescTouch2 = "/s:panelSkillDesc/s:skDesTouch2",
    skDescTouch3 = "/s:panelSkillDesc/s:skDesTouch3",
    skDescTouch4 = "/s:panelSkillDesc/s:skDesTouch4",
    skDesc = "/s:panelSkillDesc/s:skDesc",
    skDescTitle = "/s:panelSkillDesc/s:skDesc/s:Text_1",
    skDescDetail = "/s:panelSkillDesc/s:skDesc/s:Text_2",
    skDescCD = "/s:panelSkillDesc/s:skDesc/s:lbCD",
    skDescCDText = "/s:panelSkillDesc/s:skDesc/s:lbCDText",

}

NewRoleSkillView.SKILL_COLOR = cc.c4b(255,192,0,255)
NewRoleSkillView.PSKILL_COLOR = cc.c4b(0,232,255,255)
NewRoleSkillView.LastTab = 1
NewRoleSkillView.VoiceMap = {2,5,7,8,9}

function NewRoleSkillView:init(hero_id,SkillAddCallFunc,SkillChangeCallFunc,sDelegate)
    NewRoleSkillView.super.init(self)
    self.exist = true;
    self.galleryMode = 0
    --self.team_id = team_id
    self.hero_id = hero_id
    self.skillAddCallFunc = SkillAddCallFunc
    self.skillChangeCallFunc = SkillChangeCallFunc
    self.sDelegate = sDelegate

    --加载技能

    local skillBindTable =
    {
        skillIcon = "/i:902",
        skillName = "/i:903",
        skillCD = "/i:925",
        skillCDText = "/i:475",
        skillDesc = "/i:25",
        btnAdd = "/i:926",
        skillLevel = "/i:864",
        skillMaxLevel = "/i:244",
        skFromEquip = "/s:skFromEquip",
    }
    self.skillView1 = XUIView.new():init(self.skill1,"RoleInfoSkillItemView.csb",skillBindTable)
    self.skillView2 = XUIView.new():init(self.skill2,"RoleInfoSkillItemView.csb",skillBindTable)
    self.skillView3 = XUIView.new():init(self.skill3,"RoleInfoSkillItemView.csb",skillBindTable)
    self.skillView4 = XUIView.new():init(self.skill4,"RoleInfoSkillItemView.csb",skillBindTable)

    for i = 1,4 do
        self["skillView"..i].skFromEquip:setVisible(false)
        self["skillView"..i].btnAdd:addClickEventListener(function()
            self:onSkillAdd(i)
        end)

         if g_channel_control.transform_NewRoleSkillView_skillName_Alignment == true then 
            self["skillView"..i].skillName:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
            self["skillView"..i].skillName:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
            self["skillView"..i].skillName:ignoreContentAdaptWithSize(false);
            self["skillView"..i].skillName:setTextAreaSize(cc.size(280,60))
            self["skillView"..i].skillName:setPosition(cc.p(152,113))
            -- self.lbAwake:setFontSize(28)
        end 
        if g_channel_control.transform_NewRoleSkillView_skillDes_Alignment == true then 
            self["skillView"..i].skillDesc:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
            self["skillView"..i].skillDesc:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
            self["skillView"..i].skillDesc:ignoreContentAdaptWithSize(false);
            self["skillView"..i].skillDesc:setTextAreaSize(cc.size(375,80))
            self["skillView"..i].skillDesc:setPosition(cc.p(151,87))
            self["skillView"..i].skillDesc:setFontSize(20)
        end

        self["skDescTouch"..i]:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                self:onShowSkillDesc(i)
            end
        end)
        if g_channel_control.transform_RoleInfoView_skillDesc_contentSize == true then
            self["skillView"..i].skillDesc:setContentSize(375,80)
        end
    end

    self.pSkillAdd:setVisible(false)
    self.pSkillNormal:setVisible(true)

    self.btnBuySP:addClickEventListener(function()
        self:onSkillBuySP()
    end)

    self.btnSkillReset:addClickEventListener(function()
        --需要加重置技能确认提示        
        GameManagerInst:confirm(UITool.ToLocalization("重置技能点数花费")..G_SkillResetCost..UITool.ToLocalization("金币，\n是否重置？"),function()
            self:onSkillReset()
        end)
    end)
    self.btnSkillAdd:addClickEventListener(function()
        self:onSkillStartAdd()
    end)
    self.btnSkillCancel:addClickEventListener(function()
        self:onSkillCancel()
    end)
    self.btnSkillCommit:addClickEventListener(function()
        self:onSkillCommit()
    end)
    --skill end

    if g_channel_control.transform_NewRoleSkillView_btnSkillResetText_fontSize == true  then
        self.btnSkillResetText:setFontSize(16)
    end

    return self
end

function NewRoleSkillView:resetViewsState()
    if self.exist == false then
        return
    end
    self.curSkDescIdx = nil
    self.skDesc:setVisible(false)
end

function NewRoleSkillView:loadBagList(callback)
    if self.exist == false then
        return
    end
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
		DataManager:wAllBagData(data["bag"])
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

---以下为技能相关
function NewRoleSkillView:refreshSkill()
    if self.exist == false then
        return
    end
    if self.hero_data then         

        self.spLeft:setString(self.hero_data.tp.num)

        local ask1 = self.hero_data.active_sk["1"]  --主动技能
        local ask2 = self.hero_data.active_sk["2"]  --主动技能
        local psk1 = self.hero_data.passive_sk["1"]  --被动技能
        local psk2 = self.hero_data.passive_sk["2"]  --被动技能

        local skills = {ask1,ask2}

        for i = 1,2 do
            local v = self["skillView"..i]
            
            --[3] = skill[skill_info["id"]]["skill_des"], 255 192 00

            v.skillIcon:setVisible(true)
            v.skillIcon:setTexture(skill[skills[i].id].skill_icon)
            v.skillName:setString(UITool.ToLocalization("主动 ")..UITool.getUserLanguage(skill[skills[i].id].skill_name))--(UITool.ToLocalization("主动 ")..skill[skills[i].id].skill_name)
            v.skillName:setTextColor(NewRoleSkillView.SKILL_COLOR)
            v.skillCD:setString(""..skill[skills[i].id].skill_cd..UITool.ToLocalization("秒"))
            v.skillCDText:setVisible(true)
            v.skillLevel:setString(""..skills[i].lv)
            v.skillMaxLevel:setString(""..skills[i].max_lv)

            if skills[i].lv >= skills[i].max_lv then
                v.skillLevel:setTextColor(v.skillMaxLevel:getTextColor())
            else
                v.skillLevel:setTextColor(cc.c3b(255,255,255))
            end

            v.skillDesc:setString(UITool.getUserLanguage(skill[skills[i].id].skill_des))--(skill[skills[i].id].skill_des)
            v.btnAdd:setVisible(false)
            v.skFromEquip:setVisible(false)
        end

        skills={psk1,psk2}

        for i = 1,2 do
            local v = self["skillView"..(i+2)]
            --[3] = passive_sk[skill_info["id"]]["sk_des"], 8 225 251  --  

            v.skillIcon:setVisible(true)
            v.skillIcon:setTexture(passive_sk[skills[i].id].sk_icon)
            v.skillName:setString(UITool.ToLocalization("被动 ")..UITool.getUserLanguage(passive_sk[skills[i].id].sk_name))
            v.skillName:setTextColor(NewRoleSkillView.PSKILL_COLOR)
            v.skillCD:setString("")
            v.skillCDText:setVisible(false)
            v.skillLevel:setString(""..skills[i].lv)
            v.skillMaxLevel:setString(""..skills[i].max_lv)

            if skills[i].lv >= skills[i].max_lv then
                v.skillLevel:setTextColor(v.skillMaxLevel:getTextColor())
            else
                v.skillLevel:setTextColor(cc.c3b(255,255,255))
            end 

            v.skillDesc:setString(UITool.getUserLanguage(passive_sk[skills[i].id].sk_des))--(passive_sk[skills[i].id].sk_des)
            v.btnAdd:setVisible(false)
            v.skFromEquip:setVisible(false)

        end
    else
        --无数据
        for i = 1,4 do
            local v = self["skillView"..i]
            v.skillIcon:setVisible(false)
            v.skillName:setString("")
            v.skillCD:setString("")
            v.skillCDText:setVisible(false)
            v.skillLevel:setString("0")
            v.skillLevel:setTextColor(cc.c3b(255,255,255))
            v.skillMaxLevel:setString("10")
            v.skillDesc:setString("")
            v.btnAdd:setVisible(false)
            v.skFromEquip:setVisible(false)
        end

        self.spLeft:setString(0)
    end
end

--额外技能点
function NewRoleSkillView:onSkillBuySP()
    if self.exist == false then
        return
    end
    if not self.hero_data then return end
    if self.galleryMode ~= 2 then return end

    if self.hero_data.tp.from_other >= 10 then
        GameManagerInst:alert(UITool.ToLocalization("技能点已扩充至上限"))
    else
        local view = RoleInfoAddSPView.new():init()
        view.addSpEvent = function(sender,matCount)
            self:OnAddSp(matCount)
            sender:returnBack()
        end
        view:loadData(self.hero_data.tp.from_other)
        GameManagerInst:showModalView(view)
    end
end

--重置技能
function NewRoleSkillView:onSkillReset()
    if self.exist == false then
        return
    end
    if not self.hero_data then return end

    local tempTable = {
        ["rpc"] = "hero_sk_reset",
        ["hero_id"]=self.hero_id
    }
    
    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        for k,v in pairs(data["hero_info"]) do
            self.hero_data[k] = v
        end
        user_info["gold"] = data["gold"]
        self:onSkillCancel()
        if self.skillChangeCallFunc then
            self.skillChangeCallFunc(self.sDelegate)
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

--确认加点
function NewRoleSkillView:onSkillCommit()
    if self.exist == false then
        return
    end
    if not self.hero_data then return end

    local skTable = {}
    local reyun_str = ""
    for i = 1,4 do
        skTable[i] = self.skillAddInfo.nums[i].cur
        reyun_str = reyun_str..self.skillAddInfo.nums[i].cur..","
    end
    local tempTable = {
        ["rpc"] = "hero_sk_lv_up",
        ["hero_id"]=self.hero_id,
        ["sk_lv"] = skTable
    }
    
    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        for k,v in pairs(data["hero_info"]) do
            self.hero_data[k] = v
        end
        self:onSkillCancel()
        if self.skillChangeCallFunc then
            self.skillChangeCallFunc(self.sDelegate)
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

--取消加点
function NewRoleSkillView:onSkillCancel()
    if self.exist == false then
        return
    end
    if not self.hero_data then return end

    self.pSkillAdd:setVisible(false)
    self.pSkillNormal:setVisible(true)
    --self.skDescPanel:setVisible(true)

    self.skillAddInfo = nil 
    
    self.curSkDescIdx = nil
    self.skDesc:setVisible(false)
    self:refreshSkill()
    if self.skillAddCallFunc then
        self.skillAddCallFunc(self.sDelegate,true)
    end
end
--技能加点
function NewRoleSkillView:onSkillAdd(index)
    if self.exist == false then
        return
    end
    if self.skillAddInfo == nil or not self.skillAddInfo.alltp then
        return
    end
    if self.skillAddInfo.alltp == 0 then
        return
    end

    local temp = self.skillAddInfo.nums[index]
    temp.cur = temp.cur + 1
    if temp.cur > temp.max then
        temp.cur = temp.max
    else
        self.skillAddInfo.alltp = self.skillAddInfo.alltp - 1
    end
    
    self.spLeft:setString(self.skillAddInfo.alltp)

    local v = self["skillView"..index]
    v.skillLevel:setString(""..temp.cur)
    if index == 1 or index == 2 then
        v.skillDesc:setString(UITool.getUserLanguage(skill[temp.sid + temp.cur].skill_des))--(skill[temp.sid + temp.cur].skill_des)
    else
        v.skillDesc:setString(UITool.getUserLanguage(passive_sk[temp.sid + temp.cur].sk_des))--(passive_sk[temp.sid + temp.cur].sk_des)
    end
    self.curSkDescIdx = nil
    self:onShowSkillDesc(index)
end

--展示详情
function NewRoleSkillView:onShowSkillDesc(idx)
    if self.exist == false then
        return
    end
    if not self.hero_data then return end

    if self.curSkDescIdx == idx then
        self.curSkDescIdx = nil
        self.skDesc:setVisible(false)
    else
        self.curSkDescIdx = idx
        self.skDesc:setVisible(true)

        local skId = nil
        if self.skillAddInfo then
            local temp = self.skillAddInfo.nums[idx]
            skId = temp.sid + temp.cur
        end

        local posNode = self["skDescPos"..idx]

        local pos_x,pos_y = posNode:getPositionX(),posNode:getPositionY()
        self.skDesc:setPosition(pos_x,pos_y)

        if idx < 3 and idx > 0 then
            local sid = self.hero_data.active_sk[""..idx].id
            if skId then
                sid = skId
            end
            self.skDescTitle:setString(UITool.ToLocalization("主动技能：")..UITool.getUserLanguage(skill[sid].skill_name))--(UITool.ToLocalization("主动技能：")..skill[sid].skill_name)
            self.skDescTitle:setTextColor(NewRoleSkillView.SKILL_COLOR)
            self.skDescDetail:setString(UITool.getUserLanguage(skill[sid].sk_det_des))--(skill[sid].sk_det_des)    
            self.skDescCD:setVisible(true)
            self.skDescCD:setString(""..skill[sid].skill_cd..UITool.ToLocalization("秒"))
            self.skDescCDText:setVisible(true)  

        elseif idx > 2 and idx < 5 then
            local psid = self.hero_data.passive_sk[""..(idx - 2)].id
            if skId then
                psid = skId
            end
            self.skDescTitle:setString(UITool.ToLocalization("被动技能：")..UITool.getUserLanguage(passive_sk[psid].sk_name))
            self.skDescTitle:setTextColor(NewRoleSkillView.PSKILL_COLOR)
            self.skDescDetail:setString(UITool.getUserLanguage(passive_sk[psid].sk_det_des))--(passive_sk[psid].sk_det_des)      
            self.skDescCD:setVisible(false)
            self.skDescCDText:setVisible(false)  
        end
    end
end

--开始加点
function NewRoleSkillView:onSkillStartAdd()
    if self.exist == false then
        return
    end
    if not self.hero_data then return end


    local ask1 = self.hero_data.active_sk["1"]  --主动技能
    local ask2 = self.hero_data.active_sk["2"]  --主动技能
    local psk1 = self.hero_data.passive_sk["1"]  --被动技能
    local psk2 = self.hero_data.passive_sk["2"]  --被动技能

    local sss = {ask1,ask2,psk1,psk2}
    self.skillAddInfo = {}
    self.skillAddInfo.alltp = self.hero_data.tp.num
    self.skillAddInfo.nums = {}
    
    
    for i = 1,4 do
        local v = self["skillView"..i]
        v.btnAdd:setVisible(true)
        self.skillAddInfo.nums[i] = {
            sid = math.floor(sss[i].id / 100) * 100,
            cur = sss[i].lv,
            max = sss[i].max_lv
        }
    end

    self.pSkillAdd:setVisible(true)
    self.pSkillNormal:setVisible(false)
    --
    if self.skillAddCallFunc and self.sDelegate then
        self.skillAddCallFunc(self.sDelegate,false)
    end

    --结束加点新手引导
    XbTriggerGuideManager:finishGuide(TriggerGuideConfig.RoleSkill, self)

end
---以上为技能相关



function NewRoleSkillView:refreshStaticState()
    if self.exist == false then
        return
    end

    local time_id = getTimeNumID( self.hero_id )
    local h_id_num = getNumID( self.hero_id )

    if time_id > 10 then
        --已获取时界面状态
        if self.galleryMode ~= 2 then
            self.galleryMode = 2
            self.spPanel:setVisible(true)
            self.pSkillNormalButtons:setVisible(true)
        end   
    else
        --未获取时界面状态
        if self.galleryMode ~= 1 then
            self.galleryMode = 1
            self.spPanel:setVisible(false)            
            self.pSkillNormalButtons:setVisible(false)
        end       
    end
    ---

    self.currentVoiceIndex = 1

    --技能
    self.curSkDescIdx = nil
    self.skDesc:setVisible(false)
end



function NewRoleSkillView:refresh()
    if self.exist == false then
        return
    end
    self:refreshSkill()
end


function NewRoleSkillView:OnAddSp(matNum)
    if self.exist == false then
        return
    end
    if not self.hero_data then return end

    local tempData = {
        rpc = "hero_sk_point_add",
        hero_id = self.hero_id,
        add_num = matNum,
    }

    
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        if user_info["bag"]["mat"][ID_ROLE_ADDSK] then
            user_info["bag"]["mat"][ID_ROLE_ADDSK] = user_info["bag"]["mat"][ID_ROLE_ADDSK] - matNum
        end
        
        self.hero_data.tp = table.deepcopy(data["tp"])

        if user_info["hero"][self.hero_id] then
            user_info["hero"][self.hero_id].tp = table.deepcopy(data["tp"])
            DataManager:rfsHlist()
        end
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)

end

function NewRoleSkillView:OnAddProp(matNum)
    if self.exist == false then
        return
    end
    if not self.hero_data then return end

    local tempData = {
        rpc = "hero_extra_add",
        hero_id = self.hero_id,
        add_num = matNum,
    }

    
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        if user_info["bag"]["mat"][ID_ROLE_ADDPROP] then
            user_info["bag"]["mat"][ID_ROLE_ADDPROP] = user_info["bag"]["mat"][ID_ROLE_ADDPROP] - matNum
        end
        
        --self:loadInfo(true)
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleSkillView:DestroyHandle()
    self.exist = false
end

function NewRoleSkillView:onNavigateTo(isback)
    -- --GameManagerInst:setTitleUIType(nil,3)
    -- if isback then
    --     cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    --     --self:loadInfo(true)
    --     --self:refresh()
    -- else
    --     --self:loadInfo(false)
    -- end
end

function NewRoleSkillView:FillHeroData(rcvData)
    if self.exist == false then
        return
    end
    if rcvData then
        self.hero_data = nil
        self.hero_data = table.deepcopy(rcvData)
        self.hero_id = self.hero_data.id
        self:refresh()
        self:refreshStaticState()
    end
end
