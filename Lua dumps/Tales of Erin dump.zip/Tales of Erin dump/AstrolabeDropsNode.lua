--物品掉落查看，区域地图
--AstrolabeDropsNode.lua
require "BasicLayer"
--require "ConsoleLayer"

AstrolabeDropsNode = class("AstrolabeDropsNode",BasicLayer)
AstrolabeDropsNode.__index = AstrolabeDropsNode
AstrolabeDropsNode.lClass = 3
local LIST_ITEM_H = 104 --item高度
local LIST_COLUMN = 3   --一行显示几个
function AstrolabeDropsNode:init()
    local node = cc.CSLoader:createNode("AstrolabeDrops.csb")
    self.uiLayer:addChild(node,0,1)
    self._data = {}
    self._selectData = {}
    local root = node:getChildByTag(102) 
    self._uiRoot = root
    -- --策划要求 不需要关闭窗口，而且不吞噬点击事件
    -- local function rootTouchCallBack(sender,eventType)
    --     if eventType == TOUCH_EVENT_ENDED then
    --         --self:returnBack()
    --     end
    -- end 
    --策划需求可能变动，暂时保留当前代码
    root:setTouchEnabled(false)--不接受点击事件
    --root:setTouchEnabled(true)
    --root:setSwallowTouches(false)
    --root:addTouchEventListener(rootTouchCallBack)

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end

    --local backBtn  =  ccui.Helper:seekWidgetByName(root,"back_btn")
    --backBtn:addTouchEventListener(touchCallBack)

    --临时调整触摸区域，因暂时无法出美术图  gmy
    local touchBtn = ccui.Helper:seekWidgetByName(root,"touch_btn")
    touchBtn:addTouchEventListener(touchCallBack)

    local goBtn = ccui.Helper:seekWidgetByTag(root,267)
    local function touchGoCallBack(sender,eventType)
        if eventType == TOUCH_EVENT_ENDED then
            self:dealGoBtn()
        end
    end 
    goBtn:addTouchEventListener(touchGoCallBack)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    self.nowSelectAreaIndex = 1 
    self:initListView()
    self:reqAstrolabeHeroList()
end

function AstrolabeDropsNode:dealGoBtn()
    if self._selectData and self._selectData["area_list"] then
        local area_count = #self._selectData["area_list"]
        if area_count <= 0 then
            GameManagerInst:alert(UITool.ToLocalization("这个地区还未解锁!"))
            return
        end
    end
    local open_area =  self._selectData.area_list
    self.nowSelectAreaIndex = self.nowSelectAreaIndex+1
    if user_info["now_area"]== open_area[self.nowSelectAreaIndex] then 
       self.nowSelectAreaIndex = self.nowSelectAreaIndex+1 
    end
    if self.nowSelectAreaIndex>#open_area then
        self.nowSelectAreaIndex = 1
    end     
    if user_info["now_area"]== open_area[self.nowSelectAreaIndex] then 
    else 
        user_info["now_area"] = open_area[self.nowSelectAreaIndex]
        self.delegateFunc(self.sDelegate)
    end
end
function AstrolabeDropsNode:updateUI()
    local title  =  ccui.Helper:seekWidgetByTag(self._uiRoot,108)
    title:setString(UITool.getUserLanguage(self._selectData.title))
    local desc  =  ccui.Helper:seekWidgetByTag(self._uiRoot,266)
    desc:setString(UITool.getUserLanguage(self._selectData.desc))
end
--获取
function AstrolabeDropsNode:reqAstrolabeHeroList()
    local tempData = { 
        ["rpc"] = "ex_drop_info"
    }
    GameManagerInst:rpc(tempData,
        3,
        function(data)
            self._data = data.info
            local keys = table.keys(data.info)
            local key = keys[1]
            self._selectData = self._data[key] --目前只有一个，左右按钮扩展的，暂时不管
            self:updateUI()
            self:refreshListView()
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
        true)
end

function AstrolabeDropsNode:initListView()
    -- body
    local node = self.uiLayer:getChildByTag(1)
    local panel = node:getChildByTag(102) 
    self.listView = ccui.Helper:seekWidgetByTag(panel,"105")
    --set bar
    self.listView:setScrollBarEnabled(true)
    self.listView:setScrollBarWidth(20)
    self.listView:setScrollBarColor(cc.c3b(0, 0, 0))
    self.listView:setScrollBarOpacity(225*0.5)
    self.listView:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end
    local  item = cc.CSLoader:createNode("AstrolabeDropsDropsItem.csb")
    local  item_1 = item:getChildByTag(270)
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    for i=1,LIST_COLUMN do
        local item = item_1:clone()
        item:setPosition((i-1)*(100+2),0) 
        item:setName("item"..i)
        layout_list:addChild(item)
    end
    layout_list:setContentSize(306,104)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.listView:setItemModel(layout_list)
    self.listView:removeAllItems()
    self.listView:addEventListener(listViewEvent)

end
--返回
function AstrolabeDropsNode:returnBack()
   self.exist = false
   self:clearEx()
end

function AstrolabeDropsNode:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function AstrolabeDropsNode:refreshListView()
    self.listView:removeAllItems()
    local totalNum = #self._selectData.hero_list --总数
    local row = math.ceil(totalNum /LIST_COLUMN)  -- 行数
    if row<2 then 
        row=2 --最少两行，策划需求
    end 
    self.listView:setInnerContainerSize(cc.size(self.listView:getContentSize().width,LIST_ITEM_H*row))
    for i = 1,row do 
        self.listView:pushBackDefaultItem()
        local item = self.listView:getItem(i - 1)
        for m = 1 , LIST_COLUMN do  
            local node = item:getChildByName("item"..m)    
            local itme_info = node:getChildByName("item")
            local name = node:getChildByName("lab_info")
            local num = (i-1)*LIST_COLUMN + m

            if num > totalNum then
                name:setVisible(false)
                itme_info:setVisible(false)
            else
                local hero_id = self._selectData.hero_list[num]
                local tabs = UITool.getItemInfos(4, hero_id)

                local bg = itme_info:getChildByTag(1)
                local icon = itme_info:getChildByTag(2)
                local kuang = itme_info:getChildByTag(3)
                local element = itme_info:getChildByTag(4)
                kuang:loadTexture(tabs[1])
                icon:setUnifySizeEnabled(true)
                icon:loadTexture(tabs[2])
                name:setString(UITool.getUserLanguage(hero[hero_id].hero_name))--(hero[hero_id].hero_name)
                if tabs[3] == "" then 
                    element:setVisible(false)
                else
                    element:loadTexture(tabs[3])
                end
                if tabs[4]~= "" then 
                    bg:loadTexture(tabs[4])
                else

                end 
                --显示道具详情
                -- local function CallBackEvent( sender,eventType )
                --     if eventType == ccui.TouchEventType.ended then
                --         MsgManager:showSimpItemInfo(reward.type,reward.id)
                --     end
                -- end 
                -- icon:addTouchEventListener(CallBackEvent)
            end
        end
    end
    self.listView:jumpToTop()
end

function AstrolabeDropsNode:create(rData)
    local layer = AstrolabeDropsNode.new()
    layer.uiLayer = cc.Layer:create()
    layer.delegateFunc = rData["sFunc"]
    layer.sDelegate = rData["sDelegate"]
    layer:init()
    return layer
end