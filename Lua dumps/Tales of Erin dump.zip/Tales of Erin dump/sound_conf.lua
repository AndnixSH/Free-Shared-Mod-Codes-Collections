sound_conf = {}   
sound_conf[1] = {
    file_name = "1.daozhan.wav",
    des = "刀斩",
}    
sound_conf[2] = {
    file_name = "2.daji.wav",
    des = "打击",
}    
sound_conf[3] = {
    file_name = "3.gongjian.wav",
    des = "弓箭",
}    
sound_conf[4] = {
    file_name = "4.mofa.wav",
    des = "魔法",
}    
sound_conf[5] = {
    file_name = "5.beiji.wav",
    des = "被击",
}    
sound_conf[6] = {
    file_name = "6.gedang.wav",
    des = "格挡",
}    
sound_conf[7] = {
    file_name = "7.suilie.wav",
    des = "碎裂",
}    
sound_conf[8] = {
    file_name = "8.baozha.wav",
    des = "爆炸",
}    
sound_conf[9] = {
    file_name = "9.zhendong.wav",
    des = "震动",
}    
sound_conf[10] = {
    file_name = "10.faguang.wav",
    des = "发光",
}    
sound_conf[11] = {
    file_name = "11.baiguang.wav",
    des = "场景白光",
}    
sound_conf[12] = {
    file_name = "12.bianhei.wav",
    des = "场景变黑",
}   