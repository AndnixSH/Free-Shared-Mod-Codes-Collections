

NetErrorManager = class("NetErrorManager")
NetErrorManager.__index = NetErrorManager

require "NetErrorLayer"
require "UITool"



--[[
=============================================
  public start
============================================
]]

function NetErrorManager:getInstance(  )
  if self.instance == nil  then
    self.instance = NetErrorManager:new()
    self:init()
  end
  return self.instance
end

--开启网络检测
function NetErrorManager:openCheckNet()

   if self.open  == false then
      return;
    end
    self:setServerError(false);
    self:checkNet();
    self:openAutoCheckNet()

end

--销毁网络检测（包括，关闭网络检测，关闭定时，还有关闭之前显示的页面）
function NetErrorManager:destroyCheckNet()
   self:stopCheckNet();
   self:closeNetErrorScheduler();
end


----关闭网络检测
function NetErrorManager:stopCheckNet()
    if self.checkNetSchedulerEntry == nil then return end
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.checkNetSchedulerEntry)
    self.checkNetSchedulerEntry = nil
end


--设置网络状态
function NetErrorManager:setNetError(bRet, force)
  force = force or false
  -- body
  -- print("NetErrorManager:setNetError "..tostring(bRet))
  -- print("NetErrorManager:setNetError self.isServerError"..tostring(self.isServerError))
  -- print("NetErrorManager:setNetError self.isNetError"..tostring(self.isNetError))
  local lastNetError = self.isNetError;
  self.isNetError = bRet;
  if self.isNetError then
      self:showNetErrorLayer();
      cc.MyHttpHelper:shareMyHttpHelper():pauseGameFromExternal(true) 
  else
    if force  or (lastNetError and self.isServerError == false)  then
      self:hideNetErrorLayer();
      cc.MyHttpHelper:shareMyHttpHelper():pauseGameFromExternal(false) 
    end
     
  end
end


function NetErrorManager:setServerError(bRet)
  self.isServerError = bRet;
end

--获得网络状态
function NetErrorManager:getNetError()
  -- body
  return self.isNetError;
end

--[[
=============================================
  private start
============================================
]]


function NetErrorManager:init()
    print("NetErrorManager:init");
    --网络检测的总开关
    self.open = true;
    --是否是网络出错的状态
    self.isNetError = false;
    --服务器连接错误
    self.isServerError = false;

    --检测网络的间隔时间 单位：秒
    self.checkNetInterval = 5;
    self.netErrorLayer = nil;
    self.checkNetSchedulerEntry = nil;

    --网络出错的总时间，之后就会离开游戏
    self.netErrorTotalTime = 30;
    --网络出错的剩余时间
    self.netErrorElpaseTime = self.netErrorTotalTime;
    print("init netErrorElpaseTime = ", self.netErrorElpaseTime);
    


end

function NetErrorManager:openAutoCheckNet()
   if self.open  == false then
      return;
    end

    if self.checkNetSchedulerEntry ~= nil then return end
    
    local function checkNetCallback(time)
        self:checkNet();
    end
    local scheduler = cc.Director:getInstance():getScheduler()
    self.checkNetSchedulerEntry = scheduler:scheduleScriptFunc(checkNetCallback,self.checkNetInterval, false)

end





--检测网络
function NetErrorManager:checkNet()
  print("NetErrorManager:checkNet");
   if self.open  == false then
      return;
    end
  
   if self:hasNet() == false then
      --显示网络错误ui
      print("NetErrorManager self:setNetError(true)");
      self:setNetError(true)
   else
    --隐藏网络错误ui
      print("NetErrorManager self:setNetError(false)");
      self:setNetError(false)
  end

end

function NetErrorManager:hasNet()
  local netState = SDKManager:getInstance():getNetworkType();
  print("NetErrorManager net state ", tostring(netState));
  if netState ~= "wifi" and netState ~= "4G" and netState ~= "LTE" then
     return false;
  end
  return true;
end




--显示网络错误ui
function NetErrorManager:showNetErrorLayer()
    if self.open  == false then
      return;
    end
    self:openNetErrorScheduler();
    print("NetErrorManager:showNetErrorLayer");
    local data = {}
    data.desText = "网络连接不稳定,正在尝试恢复链接";
    data.showBtn = false;
    data.showTime = true;
    data.elpaseTime = self.netErrorElpaseTime;
    print("data.elpaseTime",data.elpaseTime);
    local sData = {}
    sData["sManager"] = self 
    sData["rcvData"] = data or nil
    if self.netErrorLayer == nil then
      print("NetErrorLayer:create");
        self.netErrorLayer = NetErrorLayer:create(sData);
    end
    self.netErrorLayer:refresh(sData);
    self.netErrorLayer.uiLayer:removeFromParent(true)
    local runScene = cc.Director:getInstance():getRunningScene();
    if runScene then
        local rootLayer = runScene:getChildByName("root_layer");
        if rootLayer then
          rootLayer:addChild(self.netErrorLayer.uiLayer,10000,10001)
        else
          runScene:addChild(self.netErrorLayer.uiLayer,10000,10001)
        end
    end
end



--隐藏网络错误ui
function NetErrorManager:hideNetErrorLayer()
  self:closeNetErrorScheduler()
   print("NetErrorManager:hideNetErrorLayer");
    if self.netErrorLayer ~= nil then
        self.netErrorLayer:clear();
        self.netErrorLayer = nil;
    end  
end

--
function NetErrorManager:resetNetErrorTime()
   self.netErrorElpaseTime = self.netErrorTotalTime;
   print("NetErrorManager resetNetErrorTime netErrorElpaseTime = ", self.netErrorElpaseTime);
end

--开启网络错误定时
function NetErrorManager:openNetErrorScheduler()

   if self.open  == false then
      return;
    end

    if self.netErrorSchedulerEntry ~= nil then return end

    self:resetNetErrorTime();
    local function netErrorTimeCallback(time)
      --print("netErrorTimeCallback time = ", time);
        self.netErrorElpaseTime = self.netErrorElpaseTime - time;
        print("NetErrorManager netErrorElpaseTime = ", self.netErrorElpaseTime);
        if self.netErrorLayer then
          self.netErrorLayer:refreshTime(self.netErrorElpaseTime)
        end
        if self.netErrorElpaseTime <= 0 then
          --去掉网络连接失败关闭游戏的逻辑，同步到韩服
          require "sdk/g_channel_control.lua"
          if g_channel_control.closeGameWithNetError == true then 
                
              self:closeNetErrorScheduler();
              --退出游戏
              UITool.delayTask(0.1, function ()
                cc.Director:getInstance():endToLua()
                self:stopCheckNet();
                self.open = false;
                -- if self.netErrorLayer then
                --   self.netErrorLayer:showBtn()
                -- end
                
              end);
          else
            self.netErrorElpaseTime = 30
          end
        

          
        end
    end
    local scheduler = cc.Director:getInstance():getScheduler()
    self.netErrorSchedulerEntry = scheduler:scheduleScriptFunc(netErrorTimeCallback,1, false)

end

----关闭网络错误定时
function NetErrorManager:closeNetErrorScheduler()
    if self.netErrorSchedulerEntry == nil then return end
    self:resetNetErrorTime();
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.netErrorSchedulerEntry)
    self.netErrorSchedulerEntry = nil
end

function NetErrorManager:testExchangeCheckNet()
 
    print("NetErrorManager testExchangeCheckNet")
    if self.testCheckNetSchedulerEntry ~= nil then return end
    local bRet = true;
    local function checkNetCallback(time)
      print("NetErrorManager checkNetCallback")
      self:setNetError(bRet);
      bRet = not bRet;
    end
    local scheduler = cc.Director:getInstance():getScheduler()
    self.testCheckNetSchedulerEntry = scheduler:scheduleScriptFunc(checkNetCallback,self.checkNetInterval, false)

end


