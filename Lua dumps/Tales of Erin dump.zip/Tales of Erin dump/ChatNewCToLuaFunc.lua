---NimSDKManager Call
---聊天调用第三方
function NIMSendCustomEvent( event_name,event_data )
  -- body
  local t_data = {}
  t_data["event_data"] = event_data
  lemon.EventManager:dispatchCustomEvent(event_name, t_data)
end
function NimLoginForBattle(  )
  -- body
  -- require "ChatLayer"
end
function NimLoginSuccess(  ) 
  -- body --废弃
  print("call ---chatLayer:loginNimSuccess")
  -- ChatDataManager:getInstance():loginNimSuccess()
end

function NimChatRoomhistoryCall( data )
  -- body--废弃
  -- ChatDataManager:getInstance():receiveChatRoomData(data)

end

function callNimSendMessageOK( data ) --消息发送成功回调
  -- body
  print("callNimSendMessageOK:"..tostring(data))
  NIMSendCustomEvent(EEventType.CHAT_SEND_MESSAGE_CB,data)

end

function callNimServerMessagesReturn( data )
   -- print("callNimServerMessagesReturn:"..tostring(data))
     NIMSendCustomEvent(EEventType.CHAT_RECEIVE_MSG_CB,data)

end

function callOnReceiveSystemNotification( data )
  print("callOnReceiveSystemNotification:"..tostring(data))
  NIMSendCustomEvent(EEventType.CHAT_REC_SYSTEM_NOTI,data)

end

function callOnReceiveCustomSystemNotification( data )
  print("callOnReceiveCustomSystemNotification:"..tostring(data))
  
end

function callOnRecvSubscribeEvents( data )
  -- body
  print("callOnRecvSubscribeEvents:"..tostring(data))
  NIMSendCustomEvent(EEventType.CHAT_OC_TO_LUA_FUNCTION,data)

end

--通用oc回调lua函数
function callOCToluaFuncion( data )
  print("callOCToluaFuncion:"..tostring(data))
  NIMSendCustomEvent(EEventType.CHAT_OC_TO_LUA_FUNCTION,data)

end

function onFriendChanged( data )
  -- body
  print("onFriendChanged:"..tostring(data))
  
  NIMSendCustomEvent(EEventType.CHAT_ON_FRIEND_CHANGE,data)

end

function onRecvSubscribeEvents( data )
  print("onRecvSubscribeEvents:"..tostring(data))
  
  NIMSendCustomEvent(EEventType.CHAT_USER_ONLINE_EVENT,data)
end

function callRecordOver( data )
  print("callRecordOver:"..tostring(data))
  NIMSendCustomEvent(EEventType.CHAT_RECORD_OVER,data)

end

function playAudioComplete( data )
  print("playAudioComplete:"..tostring(data))
  NIMSendCustomEvent(EEventType.CHAT_PLAY_AUDIO_OVER,data)
 
  -- ChatDataManager:getInstance():playAudioCompletedWithError(data)
end
function didAddRecentSession( data )
  print("didAddRecentSession:"..tostring(data))
  -- ChatDataManager:getInstance():didAddRecentSession(data)
end
function didUpdateRecentSession( data )
   print("didUpdateRecentSession:"..tostring(data))
 -- ChatDataManager:getInstance():didUpdateRecentSession(data)
end
function didRemoveRecentSession( data )
  print("didRemoveRecentSession:"..tostring(data))
  -- ChatDataManager:getInstance():didRemoveRecentSession(data)
end
