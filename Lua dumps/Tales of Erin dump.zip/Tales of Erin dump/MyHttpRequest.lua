
--------------------------------
-- @module MyHttpRequest
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#MyHttpRequest] creatLoginWithURL 
-- @param self
-- @param #char url
        
--------------------------------
-- 
-- @function [parent=#MyHttpRequest] creatRegistrationURL 
-- @param self
-- @param #char url
        
--------------------------------
-- 
-- @function [parent=#MyHttpRequest] creatHttpRequestWithURL 
-- @param self
-- @param #char url
-- @param #int urlType
        
--------------------------------
-- 
-- @function [parent=#MyHttpRequest] onHttpRequestCompleted 
-- @param self
-- @param #cc.network::HttpClient sender
-- @param #cc.network::HttpResponse response
        
return nil
