--[[
ExploreTeamSiftLayer.lua
--探索队伍排序页面
--todo 要不要写在MsgManager
--返回一个数组
--或者全部
]]
require "BasicLayer"

ExploreTeamSiftLayer = class("ExploreTeamSiftLayer",BasicLayer)
ExploreTeamSiftLayer.__index = ExploreTeamSiftLayer
ExploreTeamSiftLayer.lClass = 3
local RACE_TOTAL_NUM = 8 --一共有八种类型 

function ExploreTeamSiftLayer:init()
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.checkBoxs = {}
    local node = cc.CSLoader:createNode("ExploreTeamSift.csb")
    self.uiLayer:addChild(node,0,1)
    self._rootCSbNode = node:getChildByTag(102) 

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end

    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_confim")
    backBtn:addTouchEventListener(touchCallBack)
    self:initBtns()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
--绑定按钮
function  ExploreTeamSiftLayer:initBtns()
	--点击全部选中按钮
	local function onCickAllBtn(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            for i=1,#self.checkBoxs do
                local checkBox = self.checkBoxs[i]
                checkBox:setSelected(true)
            end
        end 
    end 
	local allBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_all")
    allBtn:addTouchEventListener(onCickAllBtn)

    local pos = cc.p(allBtn:getPositionX(),allBtn:getPositionY())
    local size = allBtn:getContentSize()
    local function selectedEvent(sender,eventType)
        if eventType == ccui.CheckBoxEventType.selected then
            print("Selected"..sender.raceType)
        elseif eventType == ccui.CheckBoxEventType.unselected then
            print("Unselected"..sender.raceType)
        end
    end 
    local intervalW = 30 + size.width
    local intervalH = 20 + size.height

    local imgs = {
		"n_UIShare/Global_UI/btn/explore_s_b_001_1.png",
		"n_UIShare/Global_UI/btn/explore_s_b_001_2.png"
	}
    for i=1,RACE_TOTAL_NUM do 
    	local cPos = cc.p(0,0)
    	if i < 3 then
			cPos = cc.p(intervalW*i,0)
    	elseif i<6 then 
    		cPos = cc.p(intervalW*(i-3),-intervalH)
    	else 
			cPos = cc.p(intervalW*(i-6),-2*intervalH)
    	end
    	cPos = cc.pAdd(pos,cPos)
    	local checkBox = self:initCheckBtnUI(imgs,cPos,i)
    	checkBox.raceType = i
    	checkBox:addEventListener(selectedEvent) 
  		self._rootCSbNode:addChild(checkBox)
        self.checkBoxs[i] = checkBox
    end 
end

function ExploreTeamSiftLayer:initCheckBtnUI(imgs,pos,race)
	local checkBox = ccui.CheckBox:create()
    checkBox:setTouchEnabled(true)
    checkBox:setSelected(false)
    checkBox:loadTextures(
			  imgs[1],--未选中 正常
              imgs[2],--未选中 点击
              imgs[2],--未选中 禁用 
              imgs[2],--选中 正常
              imgs[2] --选中 禁用
        )
    checkBox:setPosition(pos)

    local alert = ccui.Text:create()
    alert:setString(UITool.ToLocalization(HERO_RACE_NAME[race]))
    alert:setFontName("uifile/font/Microsoft Yahei.ttf")
    alert:setFontSize(22)
    alert:setColor(cc.c3b(255, 255, 255))
    alert:enableOutline(cc.c4b(0,0,0,255),1)
    alert:setPosition(cc.p(97,27))
    checkBox:addChild(alert)

    local spr = cc.Sprite:create(HERO_RACE_ICON[race])
    spr:setPosition(cc.p(35,28))
    checkBox:addChild(spr)

  	return checkBox
end

--返回
function ExploreTeamSiftLayer:returnBack()
    local selectRaces = {}
    for i=1,#self.checkBoxs do
        local checkBox =  self.checkBoxs[i]
        if checkBox:isSelected() ==true then
            selectRaces[#selectRaces+1] = checkBox.raceType
        end 
    end 
    --一个没选
    if #selectRaces <= 0 then

    else
        self.backFunc(self.sDelegate,selectRaces)
    end 
    self.exist = false
    self:clearEx()
end

function ExploreTeamSiftLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ExploreTeamSiftLayer:create(rData)
     local layer = ExploreTeamSiftLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
