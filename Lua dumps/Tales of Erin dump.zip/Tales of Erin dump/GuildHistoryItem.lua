GuildHistoryItem = class("GuildHistoryItem", XUICellView)
GuildHistoryItem.CS_FILE_NAME = "GuildHistoryItem.csb"
GuildHistoryItem.CS_BIND_TABLE = 
{
	panel_1 = "/i:1",
	heroImage = "/i:1/i:11",
	timeStr = 	"/i:1/i:12",
	des		= "/i:1/i:13",
}

function GuildHistoryItem:init(...)
	GuildHistoryItem.super.init(self,...)
	self.panel_1:setSwallowTouches(false)

	return self
end

function GuildHistoryItem:onResetData()
	if not self._data then return end 
	dump(self._data,"_data")

	self.heroImage:setUnifySizeEnabled(true)
    local heroid  = tonumber(self._data["heroId"])
    self.heroImage:loadTexture(hero[heroid].hero_list_icon)--hero_bat_icon

    self.timeStr:setString(self._data["timeStr"])
    self.des:setString(self._data["des"])
end