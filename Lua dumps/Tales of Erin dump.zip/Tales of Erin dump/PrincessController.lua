PrincessControllerStateNormal = 1
PrincessControllerStatePlaying = 2
PrincessControllerStateHiden = 3

DialogStateNormal = 1
DialogStatePlaying = 2

PrincessController = class("PrincessController")

function PrincessController:init()
    self.mainNode = cc.Node:create()

    self.actionList = {}
    self.couting = 1 --math.random(3, 5)

    self.princ_index = nil

    self.checkVoiceSchedulerEntry = nil

    if SceneManager.isStartLayerInit then
        self.timeCount = 5
    else
        self.timeCount = 1
    end

    self.dialogAnimeState = DialogStateNormal

    return self
end

function PrincessController:getNode()
    return self.mainNode
end

function PrincessController:createAnime()

    if ((not self.skeletonNode) and self.mainNode) then
        self.princ_index = user_info["signboard"]

        local pdata = princess_mainpage[self.princ_index]

        local sppath = pdata.spinepath

        local end_pos = string.find(sppath,'atlas') - 1
        local spName = string.sub(sppath,0,end_pos)
        --self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)

        self.skeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
        self.skeletonNode:setCompleteListener(function(trackIndex,loopCount)
            self:onSpineComplete(trackIndex,loopCount)
        end)
        self.skeletonNode:setPosition(pdata.origin_x,pdata.origin_y)
        self.mainNode:addChild(self.skeletonNode)
        self.skeletonNode:setAnimation(1, "loading", true)    

        local node = cc.CSLoader:createNode("BNDialogNode.csb")
        if node then
            self.skeletonNode:addChild(node,999,999)
            node:setPosition(20,-150)
            node:setScale(0)
            self.dialogNode = node
            self.dialogAnimeIndex = 1
        end    

        for i = 1,#pdata.touch do
            local inneri = i
            local pdesc = pdata.touch[i].paneldesc
            local pritouch = ccui.Layout:create()
            pritouch:setAnchorPoint(cc.p(0.5,0.5))
            pritouch:setPosition(pdesc.x,pdesc.y)
            pritouch:setContentSize(pdesc.width,pdesc.height)
            pritouch:setTouchEnabled(true)
            pritouch:setSwallowTouches(false)
            pritouch:addTouchEventListener(function(sender, eventType)
                if eventType == ccui.TouchEventType.ended then
                    self:playTouch(inneri)
                end
            end)
            self.mainNode:addChild(pritouch)
        end

        self.actionList = {}   
        self.couting = 1

        self:playLoading()
        self:resetDialogState()

        self.hero_id = pdata.hero_id
        self.intimacyNum = 0

        local bnType = princess_mainpage[self.princ_index].type
        self.skeletonNodeScaling = princess_mainpage[self.princ_index].scaling
        if self.skeletonNodeScaling then
            self.skeletonNode:setScale(self.skeletonNodeScaling)
        end
        if bnType == 2 then
            self:reloadHeroIntimacy()
        end
    end
end

function PrincessController:releaseAnime()
    if self.skeletonNode then
        local bnType = princess_mainpage[self.princ_index].type
        if bnType == 2 then
            self:stopCheckVoice()
        end
        print("-CrashTest-Info===PrincessController:releaseAnime===self.skeletonNode is not nil!!!")
        self.skeletonNode:clearTracks()
        if self.mainNode then
            print("-CrashTest-Info===PrincessController:releaseAnime===self.mainNode is not nil!!!")
            self.mainNode:removeAllChildren()
            self.skeletonNode = nil
        else
            print("-CrashTest-Info===PrincessController:releaseAnime===self.mainNode is nil!!!")
        end

        self.couting = princess_mainpage[self.princ_index].loadingcount
        self.animeState = PrincessControllerStateHiden
    else
        print("-CrashTest-Info===PrincessController:releaseAnime===self.skeletonNode is nil!!!")
    end
end

function PrincessController:onSpineComplete(trackIndex,loopCount)
    print("trackIndex = "..trackIndex.."   loopCount = "..loopCount)
    if trackIndex == 99 then
        --处理闲置
        self.couting = self.couting - 1
        if self.couting <= 0 then
            if #self.actionList > 0 then
                --有其他动作则播动作
                self:playNext()
            else
                self:playAction()
            end
        end
    else
        --恢复默认动作
        self.couting = princess_mainpage[self.princ_index].loadingcount
        self:playLoading()
    end
end

function PrincessController:playNext()
    if self.skeletonNode ~= nil and #self.actionList > 0 then
        local item = self.actionList[1]
        table.remove(self.actionList,1)

        self.animeState = PrincessControllerStatePlaying
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, item, false)

        self:playVoice(item)
        item = nil
    end
end

function PrincessController:playNextVoice()
    if #self.actionList > 0 then
        local voicemap = princess_mainpage[self.princ_index].voicemap_v2
        local item = self.actionList[1]
        if item == nil or string.len(item) <= 0 or voicemap == nil or voicemap[item] == nil then
            table.remove(self.actionList,1)
            item = nil
            return
        end
        
        local voiceTime = voicemap[item]["voiceTime"]
        local dialogIndex = voicemap[item]["dialog"]
        dump(voicemap,"playNextVoice--voicemap:")
        self.timeCount = voiceTime
        --local item = self.actionList[1]
        table.remove(self.actionList,1)

        self:showEventDialog(dialogIndex,voiceTime)
        self:playVoice(item)
        item = nil
    end
end

function PrincessController:playTouch(idx)
    --self.skeletonNode:setToSetupPose()
    if self.skeletonNode ~= nil and self.animeState == PrincessControllerStateNormal then
        local bnType = princess_mainpage[self.princ_index].type
        if bnType == 1 then
            local touchacts = princess_mainpage[self.princ_index].touch[idx].actions
            if #touchacts > 0 then        
                self.animeState = PrincessControllerStatePlaying
                self.skeletonNode:setToSetupPose()
                self.skeletonNode:clearTracks()

                local act = math.random(1, #touchacts)
                local actName = touchacts[act]
                self.skeletonNode:addAnimation(2, actName, false)
                self:playVoice(actName)
            end
        else
            if #self.actionList <= 0 then
                self:showTouchDialog()
            end
        end

    end
end

function PrincessController:playAction()
    if self.skeletonNode ~= nil and self.animeState == PrincessControllerStateNormal then
        local bnType = princess_mainpage[self.princ_index].type
        if bnType == 1 then
            local chance = princess_mainpage[self.princ_index].loadingchance * 100
            if math.random(1, 100) <= chance then        
                local waitacts = princess_mainpage[self.princ_index].waiting
                if #waitacts > 0 then   
                    self.animeState = PrincessControllerStatePlaying
                    self.skeletonNode:setToSetupPose()
                    self.skeletonNode:clearTracks()
                    local act = math.random(1, #waitacts)
                    local actName = waitacts[act]
                    self.skeletonNode:addAnimation(3, actName , false)  
                    self:playVoice(actName)
                else
                    self.couting = princess_mainpage[self.princ_index].loadingcount
                end
            else
                self.couting = princess_mainpage[self.princ_index].loadingcount
            end
        else

        end
    end
end

function PrincessController:playLoading()
    if self.skeletonNode then
        local bnType = princess_mainpage[self.princ_index].type
        if bnType == 1 then
            local  loadingact = princess_mainpage[self.princ_index].loading

            self.animeState = PrincessControllerStateNormal
            self.skeletonNode:setToSetupPose()
            self.skeletonNode:clearTracks()
            self.skeletonNode:addAnimation(99, loadingact , true)  
        else
            self.animeState = PrincessControllerStateNormal
            self.skeletonNode:setToSetupPose()
            self.skeletonNode:clearTracks()
            self.skeletonNode:addAnimation(1, "effect1", true)
        end

    end
end

function PrincessController:playVoice(actName)
    local voicemap = princess_mainpage[self.princ_index].voicemap
    local voicemap_v2 = princess_mainpage[self.princ_index].voicemap_v2
    local bnType = princess_mainpage[self.princ_index].type
    if bnType == 1 then
        if voicemap ~= nil and voicemap[actName] ~= nil and string.len(voicemap[actName]) > 0 then
            AudioManager:shareDataManager():playMusic(voicemap[actName], 1,false)
        end
    else
        if voicemap_v2 ~= nil and voicemap_v2[actName] ~= nil and string.len(voicemap_v2[actName]["voice"]) > 0 then
            AudioManager:shareDataManager():playMusic(voicemap_v2[actName]["voice"], 1,false)
        end
    end
    -- if voicemap ~= nil and voicemap[actName] ~= nil and string.len(voicemap[actName]) > 0 then
    --     AudioManager:shareDataManager():playMusic(voicemap[actName], 1,false)
    -- end
end

function PrincessController:addNamedEvent(ename)
    local nevents = princess_mainpage[self.princ_index].namedevent
    print("nevents[ename]1="..ename)
    print("nevents[ename]2="..nevents[ename])
    if nevents ~= nil and nevents[ename] ~= nil then
        table.insert(self.actionList,nevents[ename])
    end
end

function PrincessController:showDialog()
    if self.skeletonNode then
        if self.dialogNode then
            
            if self.dialogAnimeState == DialogStateNormal then
                if type(self.dialogs) ~= "table" then
                    LogManager.showSimpMsgDebug("self.dialogs error type",1)
                    return
                end
                local dialogTextIndex = self.dialogs[self.dialogAnimeIndex]
                local dialogText = UITool.getUserLanguage(princess_mainpage[self.princ_index].dialogs[dialogTextIndex])
                if not dialogText or dialogText == "" then--无配置则不显示dialog
                    self.dialogAnimeIndex = self.dialogAnimeIndex + 1
                    if self.dialogAnimeIndex > #self.dialogs then
                        self.dialogAnimeIndex = 1
                    end
                    return
                end
                self.dialogAnimeState = DialogStatePlaying
                --
                --local dialogTextIndex = self.dialogs[self.dialogAnimeIndex]
                --local dialogText = princess_mainpage[self.princ_index].dialogs[dialogTextIndex]
                local nDialogLength = UITool.getCharLength(dialogText)
                local nOneHangTextNum =  13
                if g_channel_control.transform_PrincessController_DialogWidthNum ~= nil then 
                    nOneHangTextNum = g_channel_control.transform_PrincessController_DialogWidthNum
                end

                local nHangNum = math.floor(nDialogLength/nOneHangTextNum) + 1
                if nHangNum < 3 then 
                    nHangNum = 3
                end 
                local h = 28
                local w = 500
                local lbDialogBg = self.dialogNode:getChildByTag(85)
                if lbDialogBg then
                    local n = nHangNum
                    lbDialogBg:setContentSize(w,h*n+60)
                end
                local lbDialog = self.dialogNode:getChildByTag(11)
                if lbDialog then
                    local n = nHangNum
                    lbDialog:setContentSize(w-60,h*n)
                    lbDialog:setString(dialogText)
                end
                self.dialogAnimeIndex = self.dialogAnimeIndex + 1
                if self.dialogAnimeIndex > #self.dialogs then
                    self.dialogAnimeIndex = 1
                end
                --
                self.dialogNode:stopAllActions()
                self.dialogNode:setScale(0)
                local scaleMax = 1
                if self.skeletonNodeScaling then
                    scaleMax = 1/self.skeletonNodeScaling
                    print("scaleMax:"..scaleMax)
                end
                local scaleIn = cc.ScaleTo:create(0.1,scaleMax)
                local fadein = cc.FadeIn:create(0.1)
                local show = cc.Spawn:create(scaleIn,fadein)
                --
                local delay1 = cc.DelayTime:create(3.0)
                local delay2 = cc.DelayTime:create(5.0)
                --
                local function resetDialogState()
                    self.dialogAnimeState = DialogStateNormal
                end
                --
                local scaleOut = cc.ScaleTo:create(0.1,0)
                local fadeout = cc.FadeOut:create(0.1)
                local hide = cc.Spawn:create(scaleOut,fadeout)

                local sequence = cc.Sequence:create(show, delay1,cc.CallFunc:create(resetDialogState),delay2, hide)
                self.dialogNode:runAction(sequence)
            end
        end
    end
end

function PrincessController:showEventDialog(dialog,timeCount)
    if self.skeletonNode then
        if self.dialogNode then
            if self.dialogAnimeState == DialogStateNormal then
                local dialogText = UITool.getUserLanguage(dialog)
                if not dialogText or dialogText == "" then--无配置则不显示dialog
                    return
                end
                self.dialogAnimeState = DialogStatePlaying
                --
                local nDialogLength = UITool.getCharLength(dialogText)
                local nOneHangTextNum = 18 --此字符长度（中文专用，其他服字符长度需要自己设定，庆伟已经改了，合并有冲突的话，需要请注意）
                local nHangNum = math.floor(nDialogLength/nOneHangTextNum) + 1
                if nHangNum < 3 then 
                    nHangNum = 3
                end 
                local h = 28
                local w = 500
                local lbDialogBg = self.dialogNode:getChildByTag(85)
                if lbDialogBg then
                    local n = nHangNum
                    lbDialogBg:setContentSize(w,h*n+60)
                end
                local lbDialog = self.dialogNode:getChildByTag(11)
                if lbDialog then
                    local n = nHangNum
                    lbDialog:setContentSize(w-60,h*n)
                    lbDialog:setString(dialogText)
                end
                --
                self.dialogNode:stopAllActions()
                self.dialogNode:setScale(0)
                local scaleMax = 1
                if self.skeletonNodeScaling then
                    scaleMax = 1/self.skeletonNodeScaling
                    print("scaleMax:"..scaleMax)
                end
                local scaleIn = cc.ScaleTo:create(0.1,scaleMax)
                local fadein = cc.FadeIn:create(0.1)
                local show = cc.Spawn:create(scaleIn,fadein)
                --
                local delay1 = cc.DelayTime:create(timeCount)
                --
                local function resetDialogState()
                    self.dialogAnimeState = DialogStateNormal
                end
                --
                local scaleOut = cc.ScaleTo:create(0.1,0)
                local fadeout = cc.FadeOut:create(0.1)
                local hide = cc.Spawn:create(scaleOut,fadeout)

                --local sequence = cc.Sequence:create(show, delay1,cc.CallFunc:create(resetDialogState), hide)
                local sequence = cc.Sequence:create(show, delay1, hide)
                self.dialogNode:runAction(sequence)
                --
                local delayShow = cc.DelayTime:create(timeCount)
                local sequenceVoice = cc.Sequence:create(delayShow,cc.CallFunc:create(resetDialogState))
                self.mainNode:runAction(sequenceVoice)
                --
            end
        end
    end
end

function PrincessController:showTouchDialog()
    if self.skeletonNode then
        if self.dialogNode then
            
            if self.dialogAnimeState == DialogStateNormal then
                if type(self.dialogs) ~= "table" then
                    LogManager.showSimpMsgDebug("self.dialogs error type",1)
                    return
                end

                local actionTouchs = princess_mainpage[self.princ_index].actionTouch
                local dialogTextIndex = self.dialogs[self.dialogAnimeIndex]
                local actionTouch = actionTouchs[dialogTextIndex]
                
                local dialogText = UITool.getUserLanguage(actionTouch.dialog)
                if not dialogText or dialogText == "" then--无配置则不显示dialog
                    self.dialogAnimeIndex = self.dialogAnimeIndex + 1
                    if self.dialogAnimeIndex > #self.dialogs then
                        self.dialogAnimeIndex = 1
                    end
                    return
                end
                self.dialogAnimeState = DialogStatePlaying
                --
                --local dialogTextIndex = self.dialogs[self.dialogAnimeIndex]
                --local dialogText = princess_mainpage[self.princ_index].dialogs[dialogTextIndex]
                local nDialogLength = UITool.getCharLength(dialogText)
                local nOneHangTextNum = 18 --此字符长度（中文专用，其他服字符长度需要自己设定，庆伟已经改了，合并有冲突的话，需要请注意）
                local nHangNum = math.floor(nDialogLength/nOneHangTextNum) + 1
                if nHangNum < 3 then 
                    nHangNum = 3
                end 
                local h = 28
                local w = 500
                local lbDialogBg = self.dialogNode:getChildByTag(85)
                if lbDialogBg then
                    local n = nHangNum
                    lbDialogBg:setContentSize(w,h*n+60)
                end
                local lbDialog = self.dialogNode:getChildByTag(11)
                if lbDialog then
                    local n = nHangNum
                    lbDialog:setContentSize(w-60,h*n)
                    lbDialog:setString(dialogText)
                end
                self.dialogAnimeIndex = self.dialogAnimeIndex + 1
                if self.dialogAnimeIndex > #self.dialogs then
                    self.dialogAnimeIndex = 1
                end
                --
                self.dialogNode:stopAllActions()
                self.dialogNode:setScale(0)
                local scaleMax = 1
                if self.skeletonNodeScaling then
                    scaleMax = 1/self.skeletonNodeScaling
                    print("scaleMax:"..scaleMax)
                end
                local scaleIn = cc.ScaleTo:create(0.1,scaleMax)
                local fadein = cc.FadeIn:create(0.1)
                local show = cc.Spawn:create(scaleIn,fadein)
                --
                local delay1 = cc.DelayTime:create(actionTouch.voiceTime)
                --
                local function resetDialogState()
                    print("TouchTest--resetDialogState")
                    self.dialogAnimeState = DialogStateNormal
                end
                --
                local scaleOut = cc.ScaleTo:create(0.1,0)
                local fadeout = cc.FadeOut:create(0.1)
                local hide = cc.Spawn:create(scaleOut,fadeout)

                --local sequence = cc.Sequence:create(show, delay1,cc.CallFunc:create(resetDialogState), hide)
                local sequence = cc.Sequence:create(show, delay1, hide)
                self.dialogNode:runAction(sequence)
                --
                local delayShow = cc.DelayTime:create(actionTouch.voiceTime)
                local sequenceVoice = cc.Sequence:create(delayShow,cc.CallFunc:create(resetDialogState))
                self.mainNode:runAction(sequenceVoice)
                --

                local actionTouchVoicePath = actionTouch.voice
                if actionTouchVoicePath ~= nil and string.len(actionTouchVoicePath) > 0 then
                    AudioManager:shareDataManager():playMusic(actionTouchVoicePath, 1,false)
                end
            end
        end
    end
end

function PrincessController:resetDialogState()
    
    local bnType = princess_mainpage[self.princ_index].type
    if bnType == 1 then
        print("TouchTest--PrincessController:resetDialogState")
        self.dialogAnimeState = DialogStateNormal
    end
end

function PrincessController:reloadHeroIntimacy()

    if not self.hero_id then return end

    local tempTable = {
        rpc = "like_feeling_detail",
        hero_id = self.hero_id
    }

    --
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            self.intimacy_data = table.deepcopy(data)
            local like_feeling_data = self.intimacy_data.like_feeling
            self.intimacyNum = like_feeling_data.lv
            ---
            local like_actions = princess_mainpage[self.princ_index].like_action
            local like_action_index = 1
            for i=1,#like_actions do
                if self.intimacyNum >= like_actions[i]["range"][1] and self.intimacyNum <= like_actions[i]["range"][2] then
                    like_action_index = i
                end
            end
            self.dialogs = princess_mainpage[self.princ_index]["like_action"][like_action_index].dialog

            function TimerUpdata()
                self:onVoiceComplete()
            end
            local bnType = princess_mainpage[self.princ_index].type
            if bnType ~= 1 then
                self.checkVoiceSchedulerEntry = cc.Director:getInstance():getScheduler():scheduleScriptFunc(TimerUpdata, 1, false)
            end

        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
        end,
        true)
end

----关闭定时器
function PrincessController:stopCheckVoice()
    if self.checkVoiceSchedulerEntry == nil then return end
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.checkVoiceSchedulerEntry)
    self.checkVoiceSchedulerEntry = nil
end

function PrincessController:onVoiceComplete()
    print("self.timeCount = "..self.timeCount)
    if self.timeCount > 0 then
        self.timeCount = self.timeCount - 1
    else
        --处理闲置
        if #self.actionList > 0 then
            --有其他动作则播动作
            self:playNextVoice()
        else
            --self.timeCount = 3
        end
    end
end
