--怪物技能组。每个技能组里包含若干个skillInfo.
--created by kobejaw.2018.4.23.
MonsterActiveSkill = class("MonsterActiveSkill")

function MonsterActiveSkill:ctor(monsterSkId,entity)
	self:init(monsterSkId,entity)
end

function MonsterActiveSkill:init(monsterSkId,entity)
	self.entity = entity
	self.monsterSkId = monsterSkId
	self.monsterSKData = monster_sk[monsterSkId]
	self.sk_lv = self.monsterSKData.sk_lv
	self.triggerData = self.monsterSKData.trig_cdn

	self.skillInfoList = {} --技能组中包含的skillInfo列表
	for k,v in pairs(self.monsterSKData.sk_skill_id) do
		local skillInfo = SkillUtil:createSkillInfo(v)
		table.insert(self.skillInfoList,skillInfo)
	end
	self.totalSkillNum = #self.skillInfoList
	self.skillInfoIdx = 1; --技能组中下一次释放的技能idx

	self:checkIsDisposible()
	self:checkIsNeedUpdate()
end

--获取下一次释放的技能Info
function MonsterActiveSkill:getNextSkillInfo()
	return self.skillInfoList[self.skillInfoIdx]
end

--检测是否是只执行一次的技能,执行完后从MonsterSkillManager里删除
function MonsterActiveSkill:checkIsDisposible()
	if self.triggerData.trig_cd >= 6000 then
		self.isDisposible = true
	else
		self.isDisposible = false
	end
end

function MonsterActiveSkill:checkIsNeedUpdate()
	if BattleDataManager.isBoss then
		self.isReady = true
		self.needUpdate = false
		return
	end

	if self.triggerData.trig_cd ~= 0 and self.triggerData.trig_cd < 6000 then
		self.needUpdate = true
		self.remainTime = self.triggerData.start_cd

		if self.remainTime == 0 then
			self.isReady = true
		else
			self.isReady = false
		end
	else
		self.needUpdate = false
		self.isReady = true
	end
end

function MonsterActiveSkill:update(dt)
	if self.needUpdate and not self.isReady then
		self.remainTime = self.remainTime - dt
		if self.remainTime < 0 then
			self.isReady = true
		end
	end
end

--释放技能时
function MonsterActiveSkill:onPlaySkill()
	--更新cd
	if self.needUpdate then
		self.isReady = false
		self.remainTime = self.triggerData.trig_cd
	end

	--技能组中下一次要释放的技能索引
	self.skillInfoIdx = self.skillInfoIdx + 1
	if self.skillInfoIdx > self.totalSkillNum then
		self.skillInfoIdx = 1
	end

	--更新boss身上的状态
	if BattleDataManager.isBoss then
		--特殊标识
		if self.triggerData.trig_num_1 == 81050 or self.triggerData.trig_num_1 == 81055 then
			self.entity:removeSpecialFlagCom()
		end

		--更新豆
		self.entity:refreshEnegyPoint(self)
	end
end

--技能释放后
function MonsterActiveSkill:onSkillFinished()
	--使用后删除
	if self.isDisposible or self.entity.skillManager:isParticularCase3(self.triggerData) then
		if not BattleDataManager.isBoss then
			self.isNeedRemove = true
		else
			self:removeFromSkillManager()
		end
	end	
end

function MonsterActiveSkill:removeFromSkillManager()
	local idx
	local skillList
	if BattleDataManager.isBoss then
		if self.sk_lv == 0 then
			skillList = self.entity.skillManager.ultimateSkillList
		elseif self.sk_lv == 1 then
			skillList = self.entity.skillManager.normalSkillList
		else
			skillList = self.entity.skillManager.bigSkillList
		end
	else
		skillList = self.entity.skillManager.normalSkillList
	end

	if skillList then
		for k,v in ipairs(skillList) do
			if self == v then
				idx = k
			end
		end
	end
	
	if idx then
		table.remove(skillList,idx)
	else
		print("出错了，MonsterActiveSkill:onPlaySkill()")
	end	
end

