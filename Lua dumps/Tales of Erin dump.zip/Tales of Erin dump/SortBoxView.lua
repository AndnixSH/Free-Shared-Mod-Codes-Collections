--require "XUIView"

SortBoxView = class("SortBoxView",XUIView)
SortBoxView.CS_FILE_NAME = "SortBoxView.csb"
SortBoxView.CS_BIND_TABLE = 
{
    btnHP = "/i:119/i:32/s:btnHP",
    btnATK = "/i:119/i:32/s:btnATK",
    btnFP = "/i:119/i:32/s:btnFP",
    btnElement = "/i:119/i:32/s:btnElement",
    btnRank = "/i:119/i:32/s:btnRank",
    btnLevel = "/i:119/i:32/s:btnLevel",
    btnRoleBrk = "/i:119/i:32/s:btnRoleBrk",
    btnEqBrk = "/i:119/i:32/s:btnEqBrk",
    btnEqsk = "/i:119/i:32/s:btnEqsk",
    btnOK = "/i:119/i:32/i:121",
}
SortBoxView.stypes = 
{
    { 101,UITool.ToLocalization("生命值")},
    { 301,UITool.ToLocalization("攻击力")},
    { 203,UITool.ToLocalization("战斗力")},
    { 601,UITool.ToLocalization("属性")},
    { 401,UITool.ToLocalization("稀有度")},
    { 502,UITool.ToLocalization("等级")},
    { 804,UITool.ToLocalization("解放次数")}
}
SortBoxView.stypes1 = 
{
    { 101,UITool.ToLocalization("生命值")},
    { 301,UITool.ToLocalization("攻击力")},
    { 203,UITool.ToLocalization("战斗力")},
    { 601,UITool.ToLocalization("属性")},
    { 401,UITool.ToLocalization("稀有度")},
    { 502,UITool.ToLocalization("等级")},
    { 804,UITool.ToLocalization("突破次数")},
    { 905,UITool.ToLocalization("灵装技能")},
}

function SortBoxView:init(reType)    --0 角色排序   1 装备排序
    SortBoxView.super.init(self)
    
    self.reType = reType
    self._CurSortMode = nil

    if reType == 0 then
        self.buttons = {
            self.btnHP,
            self.btnATK,
            self.btnFP,
            self.btnElement,
            self.btnRank,
            self.btnLevel,
            self.btnRoleBrk
        }
        self.btnEqBrk:setVisible(false)
        self.btnEqsk:setVisible(false)
    else
        self.buttons = {
            self.btnHP,
            self.btnATK,
            self.btnFP,
            self.btnElement,
            self.btnRank,
            self.btnLevel,
            self.btnEqBrk,
            self.btnEqsk
        }
        self.btnRoleBrk:setVisible(false)
    end

    local function btnFunc(sender)
        self:onBtnClick(sender:getTag())
    end

    for i = 1,#self.buttons do
        self.buttons[i]:setTag(i)
        self.buttons[i]:addClickEventListener(btnFunc)
    end

    local function returnBack()
        if self._CurSortMode ~= self.selectedSortMode then
            if self.beforeCloseEvent then
                self.beforeCloseEvent(self, self.selectedSortMode)
            end

            -- self:removeFromParentView()
        end
        KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
        self:removeFromParentView()
    end
    self.btnOK:addClickEventListener(function ()
        returnBack()
    end)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        returnBack()   
    end)

    return self
end

function SortBoxView:onBtnClick(index)
    local st = SortBoxView.stypes
    if self.reType == 1 then
        st = SortBoxView.stypes1
    end

    self.selectedSortMode = st[index][1]
    for i = 1,#self.buttons do
        self.buttons[i]:setTouchEnabled(i ~= index)
        self.buttons[i]:setBright(i ~= index)	
    end

end

function SortBoxView:setSortMode(sortMode)
    self._CurSortMode = sortMode
    local st = SortBoxView.stypes
    if self.reType == 1 then
        st = SortBoxView.stypes1
    end

    local num = math.floor(sortMode / 100) 
    for i = 1,#st do
        local num1 = math.floor(st[i][1]/100)
        if num == num1 then
            self:onBtnClick(i)
            break
        end
    end
end

function SortBoxView.GetSortName(sortMode,reType)
    local names = SortBoxView.stypes
    if reType == 1 then
        names = SortBoxView.stypes1
    end

    local num = math.floor(sortMode / 100) 

    for i = 1,#names do
        local num1 = math.floor(names[i][1]/100)
        if num == num1 then
            return UITool.ToLocalization(names[i][2])
        end
    end
    return nil
end

function SortBoxView.SortRole (dataSet, sortMode,sortInTeam)
   
    local num = math.floor(sortMode/10)
    
    local sort = num%10 --升降序
    
    local sort_type = math.floor(num/10) --属性类型

    local compFunc = nil
    if sort == 1 then
        compFunc = function(a,b) return a > b end
    else
        compFunc = function(a,b) return a < b end
    end

    local sor_s = nil

    if sort_type == 1 then     -- Hp
        sor_s = function (item) return item["hp"] end
    elseif sort_type == 3 then  -- ATk
        sor_s = function (item) return item["atk"] end
    elseif sort_type == 2 then  -- 战力
        sor_s = function (item) return item["fp_all"]["all"] end
    elseif sort_type == 6 then  -- 属性
        sor_s = function (item) return item["element"] end    
    elseif sort_type == 4 then  -- 稀有度
        sor_s = function (item) return item["rarity"] end 
    elseif sort_type == 5 then  -- 等级
        sor_s = function (item) return item["Lv"] end
    -- elseif sort_type == 7 then  -- 入手时间
    --     sor_s = function (item) return item["time_id"] end
    elseif sort_type == 8 then  -- 突破次数
        sor_s = function (item) return item["break_count"] end
    end

    if  sor_s == nil then
        return
    end
        
    if sortInTeam then
    --排队伍  队伍中在前，非队伍中在后
        table.sort(dataSet,function(x,y)
            if not ((#x["team_list"] == 0 and #y["team_list"] == 0) or (#x["team_list"] > 0 and #y["team_list"] > 0)) then
            return #x["team_list"] ~= 0
            elseif sor_s(x) ~= sor_s(y) then
            return compFunc(sor_s(x),sor_s(y))
            else
            return getNumID(x["id"]) > getNumID(y["id"])
            end
        end)
    else
    --不排队伍  无视编队
        table.sort(dataSet,function(x,y)
            if sor_s(x) ~= sor_s(y) then
                return compFunc(sor_s(x),sor_s(y))
            else
                return getNumID(x["id"]) > getNumID(y["id"])
            end
        end)
    end
    ----------------------新手引导相关的特殊排序
    --新手引导、男主角必须在第一位
    local  sID = 13
    local function guideSortFunc(sID)
        local function isManRole(c_id)
            local isIn = 0
            local iD = getNumID(c_id)
            if iD == sID then 
                isIn = 1
            end 
            return isIn
        end
        local function newGuideSort(a,b)
            local aisRole = isManRole(a.id)
            local bisRole = isManRole(b.id)
            return aisRole > bisRole
        end
        table.sort(dataSet, newGuideSort)
    end 
    ---男主在第一位
    if NewGuideManager._nowGuideID <= guide_id_config.Team then
        guideSortFunc(13)
    end
    -------------------------------------------------------
end


function SortBoxView.SortEquip(dataSet,str)
        local sor_s = nil
        local num = math.floor(str/10) 
        local sort = num%10 --升降序
        local sort_type = math.floor(num/10) --属性类型
        
        local compFunc = nil
        if sort == 1 then
          compFunc = function(a,b) return a > b end
        else
          compFunc = function(a,b) return a < b end
        end
        
        if sort_type == 1 then
            sor_s = function(item) return item["hp"] end
        elseif sort_type == 3 then
            sor_s = function(item) return item["atk"] end
        elseif sort_type == 2 then
            sor_s = function(item) return item["fp"] end
        elseif sort_type == 6 then
            sor_s = function(item) return item["element"] end    
        elseif sort_type == 4 then
            sor_s = function(item) return item["rarity"] end 
        elseif sort_type == 5 then
             sor_s = function(item) return item["Lv"] end
        -- elseif sort_type == 7 then
        --     sor_s = function(item) return item["time_id"] end
        elseif sort_type == 8 then
            sor_s = function(item) return item["brk_num"] end
        elseif sort_type == 9 then
            sor_s = function(item) return item["sk"]["Lv"] end
        end
        if sor_s == nil then
          return
        end
        
        table.sort(dataSet,function(x,y)
          if not ((x["owner"] == "0" and y["owner"] == "0") or (x["owner"] ~= "0" and y["owner"]~="0")) then
            return x["owner"] ~= "0"
          elseif sor_s(x) ~= sor_s(y) then
            return compFunc(sor_s(x),sor_s(y))
          else
            return getNumID(x["id"]) > getNumID(y["id"])
          end
        end)

        -----------------------新手引导特殊排序
       
        ---现在改成 固定ID 的装备
        local function guideSortFunc(s_e_iD)
            local function isSelect(c_e_iD)
                local isIn = 0
                if c_e_iD == s_e_iD then 
                    isIn = 1
                end 
                return isIn
            end
            local function newGuideSort(a,b)

                local _a = isSelect(getNumID(a.id))
                local _b = isSelect(getNumID(b.id))
                return _a > _b
            end
            table.sort(dataSet, newGuideSort)
        end 

        --穿装备 火属性在前
        if  NewGuideManager.isStartWeakGuide and  NewGuideManager._nowGuideID == guide_id_config.Equipment then
            local e_iD = 132300  -- 固定ID
            guideSortFunc(e_iD)
        end
end