
--聊天室私聊好友item

ChatNewFriendItem = class("ChatNewFriendItem",XUICellView)
ChatNewFriendItem.CS_FILE_NAME = "ChatNewFriendItem.csb"
ChatNewFriendItem.CS_BIND_TABLE = 
{

	name_bg =	"/s:name_bg",
	name 		= "/s:name_bg/s:roleName",
    onlineIcon 	= "/s:name_bg/s:online",
    unReadBg 	= "/s:name_bg/s:unReadBg",
    unReadText 	= "/s:name_bg/s:unReadBg/s:unReadNum",
}

ChatNewFriendItem.LogTag = "ChatNewFriendItem"

function ChatNewFriendItem:create(rData)
    local login = ChatNewFriendItem.new()
    login._data = rData
    login:initUI()
    return login
end

function ChatNewFriendItem:clear( )
	-- self:registEventDispatcher(false)

end

function ChatNewFriendItem:returnBack(  )
	self:clear()
end

function ChatNewFriendItem:initUI(  )
    ChatNewFriendItem.super.init(self)

	self:bindAllBtn()

end

function ChatNewFriendItem:bindAllBtn(  )
	
	local function touchCallBack( sender,eventType )
		if eventType == ccui.TouchEventType.ended then
			if self.itemCallBack then
				self.itemCallBack(self._data)
			end
		end
	end

	self.name_bg:addTouchEventListener(touchCallBack) 
	self.name_bg:setSwallowTouches(false)


end

function ChatNewFriendItem:onResetData()
	if self._data then
		local roleName = self._data["name"]
		if roleName ~= nil  then
		 	self.name:setString(tostring(roleName))
		end

		local bg_highLight = self._data["highLight"]
		if bg_highLight == true  then
			self.name_bg:loadTexture("n_UIShare/chatNew/lt_ui_014.png")
		else
			self.name_bg:loadTexture("n_UIShare/chatNew/lt_ui_013.png")
		end

		local onlineState = self._data["online"]
		if onlineState ~= nil and onlineState == 2 then --在线
			self.onlineIcon:loadTexture("n_UIShare/chatNew/lt_ui_027.png")
		else
			self.onlineIcon:loadTexture("n_UIShare/chatNew/lt_ui_028.png")
		end
		
		--云信SDK没有回调，所以强制隐藏在线状态
		self.onlineIcon:setVisible(false)

		local session_id = self._data["user_nim_id"]
		local session_type = 0
		local unReadNum = XBChatData:getInstance():getSessionUnreadNum( session_type,session_id )
		print("ChatNewFriendItem:onResetData:session_id:"..tostring(session_id))
		print("ChatNewFriendItem:onResetData:unReadNum:"..tostring(unReadNum))
		if unReadNum == 0 then
			self.unReadBg:setVisible(false)
		elseif unReadNum == 1 then
			self.unReadBg:setVisible(true)
			self.unReadBg:loadTexture("n_UIShare/chatNew/lt_ui_030.png")
			self.unReadText:setVisible(false)
		else
			self.unReadBg:setVisible(true)
			self.unReadBg:loadTexture("n_UIShare/chatNew/lt_ui_031.png")
			self.unReadText:setVisible(true)
			self.unReadText:setString(tostring(unReadNum))
		end

	end
end

-- function ChatNewFriendItem:getItemSize(  )
-- 	print("···------------")
-- 	return self.rootNode:getContentSize()
-- end
						  
-- function ChatNewFriendItem:getItemPosition(  )
-- 	-- body
-- 	return self.rootNode:getPosition()
-- end

-- function ChatNewFriendItem:setItemPosition( position )
-- 	self.rootNode:setPosition(position)
-- end

function ChatNewFriendItem:initData(  )

end

function ChatNewFriendItem:setItemCallback( itemCallback )
	self.itemCallBack = itemCallback 

end
