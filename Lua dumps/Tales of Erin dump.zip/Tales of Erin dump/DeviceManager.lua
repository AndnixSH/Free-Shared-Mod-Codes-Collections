--语音管理
--单例类


DeviceManager = {}
DeviceManager.nativeClassName = "org/cocos2dx/device/DeviceInterface"


function DeviceManager.luaBridgeCall(className,functionName,args,sigs)
    local platform = cc.Application:getInstance():getTargetPlatform()
    local ok = false
    local ret = nil
    if platform == cc.PLATFORM_OS_ANDROID then
        local luaj = require("src/cocos/cocos2d/luaj.lua")
        ok,ret  = luaj.callStaticMethod(className,functionName,args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        -- local luaoc = require_ex("src/cocos/cocos2d/luaoc.lua")
        -- ok,ret  = luaoc.callStaticMethod(className, functionName, args)
    end
    -- if not ok then
    --     print("luaoc error:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(functionName))
    -- else
    --     print("The oc ret is:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(functionName))
    -- end
    return ok, ret
end

--初始化
function DeviceManager:getLocalMacAddress()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getLocalMacAddress",args,sigs)
    if ok then
        return ret;
    end
    return ""

end

function DeviceManager:getIMEI()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getIMEI",args,sigs)
    if ok then
        return ret;
    end
    return ""

end


function DeviceManager:isExternalStorageAvailable()
    local sigs = "()Z"
    local args = {}
    
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "isExternalStorageAvailable",args,sigs)
    if ok then
        return ret;
    end
    return false

end


function DeviceManager:getDeviceIDString()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getDeviceIDString",args,sigs)
    if ok then
        return ret;
    end
    return ""

end

--总内存
function DeviceManager:getTotalMemory()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local totalMemory = 0;
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getTotalMemory",args,sigs)
    if ok then
        totalMemory = tonumber(ret)
    end
    return totalMemory

end

--可用内存
function DeviceManager:getAvailableMem()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local availMemory = 0;
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getTotalMemory",args,sigs)
    if ok then
        availMemory = tonumber(ret)
    end
    return availMemory

end

--sd卡总存储大小
function DeviceManager:getSDTotalSize()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local SDTotalSize = 0;
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getSDTotalSize",args,sigs)
    if ok then
        SDTotalSize = tonumber(ret)
    end
    return SDTotalSize

end

--sd卡可用存储大小
function DeviceManager:getSDAvailableSize()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local SDAvailableSize = -1;
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getSDAvailableSize",args,sigs)
    if ok then
        SDAvailableSize = tonumber(ret)
    else 
        SDAvailableSize = -1
    end
    return SDAvailableSize

end

--总机身存储大小
function DeviceManager:getRomTotalSize()
    local sigs = "()Ljava/lang/String;"
    local args = {}
    local romTotalSize = 0;
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getRomTotalSize",args,sigs)
    if ok then
        romTotalSize = tonumber(ret)
    end
    return romTotalSize

end

--机身可用存储大小
function DeviceManager:getRomAvailableSize()
   local sigs = "()Ljava/lang/String;"
    local args = {}
    local romAvailableSize = -1
    local ok, ret = DeviceManager.luaBridgeCall(DeviceManager.nativeClassName, "getRomAvailableSize",args,sigs)
    if ok then
        romAvailableSize = tonumber(ret)
    else 
        romAvailableSize = -1
    end
    return romAvailableSize

end

--检测是否有足够的机身存储空间(计算单位为M)
--现在仅仅在android下会真实计算，其他环境直接返回真
--国内版是存放到sdk卡，所以判断sd卡
function DeviceManager:checkEnoughRomAvailableSize(needSize)
    local platform = cc.Application:getInstance():getTargetPlatform()
   
    if platform == cc.PLATFORM_OS_ANDROID then

        local romAvailableSize = self:getRomAvailableSize()
        if romAvailableSize ==-1 then 
            return true --读取内存卡大小错误，直接返回true
        end 
        local freeSize = 100
        if tonumber(romAvailableSize) > tonumber(needSize) + freeSize then

            return true
        end
        return false
    else
        --kb->mb
        local deviceFreeSize = math.floor(cc.Application:getInstance():getDivceFreeSize()/1024)
        needSize = needSize + 20
        if tonumber(needSize) < deviceFreeSize then
            return true
        end
        return false
    end
end

--检测是否有足够的sdcard存储空间(计算单位为M)
--现在仅仅在android下会真实计算，其他环境直接返回真
function DeviceManager:checkEnoughSDAvailableSize(needSize)
    local platform = cc.Application:getInstance():getTargetPlatform()
   
    if platform == cc.PLATFORM_OS_ANDROID then

        local availableSize = self:getSDAvailableSize()
        local freeSize = 100;
        if tonumber(availableSize) > tonumber(needSize) + freeSize then

            return true
        end
        return false
    else
        return true
    end

    
end
--检测是否有足够的机身存储空间(计算单位为M)
--国内版是存放到sdk卡，所以判断sd卡
function DeviceManager:checkEnoughWirteAvailableSize(needSize)
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        local romAvailableSize
        if self:isExternalStorageAvailable() then 
            romAvailableSize = self:getSDAvailableSize()
        else 
            romAvailableSize = self:getRomAvailableSize()
        end 
        if romAvailableSize == -1 then 
            return false --读取内存卡大小错误，直接返回true
        end 
        local freeSize = 100
        if tonumber(romAvailableSize) > tonumber(needSize) + freeSize then
            return true
        end
        return false
    else
        --kb->mb
        local deviceFreeSize = math.floor(cc.Application:getInstance():getDivceFreeSize()/1024)
        needSize = needSize + 20
        if tonumber(needSize) < deviceFreeSize then
            return true
        end
        return false
    end
end











