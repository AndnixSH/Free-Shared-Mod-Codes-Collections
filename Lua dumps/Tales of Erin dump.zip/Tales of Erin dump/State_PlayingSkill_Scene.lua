--释放场景类技能中。（范围攻击,或者打全体）（神格技能一定是打全体，也归在这里）
--注：State_PlayingSkill_Scene和State_PlayingSkill_Target中打全体的区别，前者在场景播放特效，后者在目标身上或初始位置播放特效

--created by kobejaw.2018.4.27.
State_PlayingSkill_Scene = class("State_PlayingSkill_Scene",StateBase)

function State_PlayingSkill_Scene:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.PlayingSkill_Scene
	self.isSkill = true
end

function State_PlayingSkill_Scene:Enter(skillInfo)
	self.skillInfo = skillInfo;	
	self.super.Enter(self)
end

function State_PlayingSkill_Scene:Exit()
	if not self.skillInfo.isPrincess then
		self.super.Exit(self)
	end
end
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
function State_PlayingSkill_Scene:onSpineEventCallback(event)

	--震屏，闪烁等处理
	self:dealWithCommonEvents(event,self.skillInfo)

	--"attack"事件
	local result1,result2 = self:checkIsAttackEvent(event,self.skillInfo)
	if result1 then
		self:dealWithAttackEvent(event,result2)
	end

	--"autoplay"事件
	result1 = self:checkIsAutoplayEvent(event)
	if result1 then
		self:dealWithAutoplayEvent()
	end

	--"cutin"事件
	local result_cutin = self:checkIsCutInEvent(event)
	if result_cutin == 1 then
		G_GameState = 3
		SkillUtil:playCutIn(self.entity)
		if not self.entity.isBoss then
			ActiveSkillManager:refreshSkillWhenCutIn(self.entity.skill[2])
		end
	elseif result_cutin == 2 then
		SkillUtil:playEndCutIn(self.entity)
	end

end

--处理造成伤害事件
function State_PlayingSkill_Scene:dealWithAttackEvent(event,idx)
	local hitData = self.skillInfo.skillData.skill_attack_hit[idx]

	if not hitData then
		print("配表错误，State_PlayingSkill_Scene")
		return
	end

	local hit_rect_x,hit_rect_y,hit_rect_w,hit_rect_h

	local screenCenterInBattleLayer = G_BattleLayer:convertToNodeSpace(cc.p(640,360))

	hit_rect_x = hitData.hit_rec[1] + screenCenterInBattleLayer.x
	hit_rect_y = hitData.hit_rec[2] + screenCenterInBattleLayer.y
	hit_rect_w = hitData.hit_rec[3]
	hit_rect_h = hitData.hit_rec[4]

	local damageRange = cc.rect(hit_rect_x, hit_rect_y, hit_rect_w, hit_rect_h)

	local attackedList = self:generateAttackedList(damageRange,screenCenterInBattleLayer,self.skillInfo,hitData)

	for k,v in pairs(attackedList) do
		local type = 1
		if self.skillInfo.isPrincess then
			type = 2
		end
		self:onCauseDamage(type,self.entity,v,event,self.skillInfo.skillData,idx)
	end
end

function State_PlayingSkill_Scene:onSpineCompleteCallback(event)
	if not self.skillInfo.isPrincess then
		if self.entity.isBoss then
			self.entity.fsm:changeState(StateEnum.Attacking_Boss)
		else
			--技能释放完毕。切换到RunningToEnemy状态
			local data = {}
			data.type = 1;
			self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)		
		end
	end
end

