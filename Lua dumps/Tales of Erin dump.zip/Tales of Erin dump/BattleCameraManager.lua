--摄像机管理，处理镜头跟随
--created by kobejaw.2018.5.30.
BattleCameraManager = {}

function BattleCameraManager:init()
	self.isTouchMode = false;--手指拖动的模式

	self.touchedRole = nil;

    self.offset = 0;      --镜头总共需要移动的偏移量，同时是是否需要移动的标识

    --self.cdTime = 0.3;    --在所有队友都站定攻击的时候，每0.3秒检测一次是否需要镜头移动，在self.moveNum为0时有效，日后优化的时候再说。
    self.cameraFixed = false;  --每局结束后，执行一下
    self.isMellee = true;     --是否有近战英雄。
    self.moveType = 0

    self.isBigSkillMove = false --大招时镜头向施法者移动
end

function BattleCameraManager:update(dt)
	if self.cameraFixed then
		return
	end

	if G_BattleLayer:getPositionX() >= 100 then
		return
	end

	if self.isTouchMode then
		self:MoveCamera_TouchMode()
		return
	end

	local isMellee = self:checkHasMellee()
	if self.isMellee ~= isMellee then
		self.offset = 0
	end
	self.isMellee = isMellee

	if not self.isMellee then
		if self.offset <= 0 then
			if self:checkIsNeedMoveCamera_NoMellee() then
				self:MoveCameraOneStep()
			else
				self.moveType = 0
			end
		else
			self:MoveCameraOneStep()
		end		
	else
		local rightestRole = self:getRightestRole()
		if not rightestRole then
			return
		end

		if not self:checkIsAllMonstersOnTheRight(rightestRole) then
			return
		end

		if self.offset <= 0 then
			if self:checkIsNeedMoveCamera(rightestRole) then
				self:moveForwordOneStep()
			else
				self.moveType = 0
			end
		else
			self:moveForwordOneStep()
		end	
	end
end

function BattleCameraManager:MoveCameraOneStep()
	if self.moveType == 2 then
		self:moveForwordOneStep()
	elseif self.moveType == 3 then
		self:moveBackOneStep()
	elseif self.moveType == 4 then
		self:moveBackOneStep()
	end
end

--检测队伍中是否有近战角色
function BattleCameraManager:checkHasMellee()
	for k,v in pairs(G_Roles) do
		if not v.isDead and v.data.mellee then
			return true
		end
	end
end

function BattleCameraManager:setCameraFixed(isFixed)
	self.cameraFixed = isFixed
end


--手指拖动的角色开始移动时调用一下
--@destX.目的地的x值
--@initialX 初始位置的x值
function BattleCameraManager:setTouchMode(role,destX,initialX)
	self.isTouchMode = true
	self.touchedRole = role

	if destX >= initialX then
		self.isToRight = true
	else
		self.isToRight = false
	end

	self.initialX = initialX
	self.currentX = initialX
end

--手指拖动的角色停下来时调用一下
function BattleCameraManager:quitTouchMode()
	self.isTouchMode = false
	self.touchedRole = nil
end

--镜头向前跟随，每帧调用
function BattleCameraManager:moveForwordOneStep()
	--如果self.offset小于镜头移动速度，则按照self.offset的值移动，否则按照BattleGlobals.CameraSpeed移动
	if self.offset < BattleGlobals.CameraSpeed then
		G_BattleLayer:setPositionX(G_BattleLayer:getPositionX() - self.offset)
		G_BattleBGLayer:OnBattleLayerMoved(-self.offset)
		self.offset = 0
	else
		G_BattleLayer:setPositionX(G_BattleLayer:getPositionX() - BattleGlobals.CameraSpeed)
		G_BattleBGLayer:OnBattleLayerMoved(-BattleGlobals.CameraSpeed)
		self.offset = self.offset - BattleGlobals.CameraSpeed
	end
end
--镜头向后跟随，每帧调用
function BattleCameraManager:moveBackOneStep()
	--如果self.offset小于镜头移动速度，则按照self.offset的值移动，否则按照BattleGlobals.CameraSpeed移动
	if self.offset < BattleGlobals.CameraSpeed then
		G_BattleLayer:setPositionX(G_BattleLayer:getPositionX() + self.offset)
		G_BattleBGLayer:OnBattleLayerMoved(self.offset)
		self.offset = 0
	else
		G_BattleLayer:setPositionX(G_BattleLayer:getPositionX() + BattleGlobals.CameraSpeed)
		G_BattleBGLayer:OnBattleLayerMoved(BattleGlobals.CameraSpeed)
		self.offset = self.offset - BattleGlobals.CameraSpeed
	end
end

--手指拖动模式下检测是否需要镜头跟随
function BattleCameraManager:MoveCamera_TouchMode()
	if self.touchedRole == nil or self.touchedRole.isDead then
		self.isTouchMode = false
		self.touchedRole = nil
		return
	end

	if self.isToRight then
		return
	end	

	self.initialX = self.currentX
	self.currentX = self.touchedRole:getPositionX()

	if self.currentX <= BattleGlobals.CameraScroll_LeftX then
		return
	end

	local posInScreen = self.touchedRole:convertToWorldSpace(cc.p(0,0))
	if posInScreen.x >= BattleGlobals.CameraScroll_LeftX then
		return
	end

	local offset = self.currentX - self.initialX
	G_BattleLayer:setPositionX(G_BattleLayer:getPositionX() - offset)
	G_BattleBGLayer:OnBattleLayerMoved(-offset)
end


--如果不需要移动镜头，返回false;否则返回true，并设置offset。
--@role :我方最右侧的角色
function BattleCameraManager:checkIsNeedMoveCamera(role)
	local posInScreen = role:convertToWorldSpace(cc.p(0,0))
	if posInScreen.x > BattleGlobals.CameraScroll_RightX then
		self.offset = posInScreen.x - BattleGlobals.CameraScroll_RightX
		self.moveType = 1
		return true
	end
	return false
end

--没有近战时的检测
function BattleCameraManager:checkIsNeedMoveCamera_NoMellee()
	local rightestRole = self:getRightestRole()
	if not rightestRole then
		return false
	end
	
	local leftestMonster = self:getLeftestMonster()
	if not leftestMonster then
		return false
	end

	if leftestMonster:getPositionX() <= rightestRole:getPositionX() then
		return false
	end

	local posInScreen = rightestRole:convertToWorldSpace(cc.p(0,0))

	--先检测是否我方角色都特别靠右
	if posInScreen.x > BattleGlobals.CameraScroll_RightX_NoMellee then
		self.offset = posInScreen.x - BattleGlobals.CameraScroll_RightX_NoMellee
		self.moveType = 2;
		return true
	--再监测是否我方角色特别靠左
	elseif posInScreen.x < 200 then
		self.offset = 200 - posInScreen.x
		self.moveType = 3
		return true
	end

	--再监测是否怪物特别靠左
	local leftestMonster = self:getLeftestMonster()
	if not leftestMonster then
		return false
	end

	local posInScreen = leftestMonster:convertToWorldSpace(cc.p(0,0))
	if posInScreen.x < 400 then
		self.offset = 400 - posInScreen.x
		self.moveType = 4
		return true
	end
	return false
end

--获取最右侧的我方角色
function BattleCameraManager:getRightestRole()
	local potentialList = {}

	for k,v in pairs(G_Roles) do
		if not v.isDead then
			table.insert(potentialList,v)
		end
	end

	table.sort(potentialList,function (a,b)
		return a:getPositionX()>b:getPositionX()
	end)

	if potentialList[1] == nil then
		self:setCameraFixed()
	end

	return potentialList[1]
end

--获取最左侧的怪物
function BattleCameraManager:getLeftestMonster()
	local potentialList = {}

	for k,v in pairs(G_Monsters) do
		if not v.isDead then
			table.insert(potentialList,v)
		end
	end

	table.sort(potentialList,function (a,b)
		return a:getPositionX()<b:getPositionX()
	end)

	if potentialList[1] == nil then
		self:setCameraFixed()
	end

	return potentialList[1]
end

--检测是否所有怪物都在我方右侧
--@role :我方最右侧的角色
function BattleCameraManager:checkIsAllMonstersOnTheRight(role)
	for k,v in pairs(G_Monsters) do
		if not v.isDead and v:getPositionX()<=role:getPositionX() then
			return false
		end
	end
	return true
end

--切换下一波怪的时候调用一下。开打以后将cameraFixed置为false
function BattleCameraManager:reset()
	self.moveType = 0
	self.isTouchMode = false
	self.touchedRole = nil
	self.cameraFixed = true
end

function BattleCameraManager:clear()
	
end
