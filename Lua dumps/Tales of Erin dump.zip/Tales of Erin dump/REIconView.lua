--require "XUIView"

REIconView = class("REIconView", XUIView)

REIconView.CS_FILE_NAME = "REIconView.csb"
REIconView.CS_BIND_TABLE = 
{
    panelNoFace = "/i:1770/i:1765",
    panelIcon = "/i:1770/i:1776",
    panelName = "/i:1770/i:1767",
    lbName = "/i:1770/i:1767/i:1769",
    imgFace = "/i:1770/i:1776/i:1779",
    imgRarity = "/i:1770/i:1776/i:1778",
    imgBG = "/i:1770/i:1776/i:1780",
    imgElement = "/i:1770/i:1776/i:1777",
    intimacyNode = "/i:1770/i:1776/i:208",
    intimacyIconPos = "/i:1770/i:1776/i:207",
}

function REIconView:init(...)
    REIconView.super.init(self,...)

    self:showNoIcon()

    return self
end

function REIconView:startGMeffect(intimacyState)
    local effectFile = like_state[intimacyState].special_effect --特效资源路径

    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(effectFile) then
        local end_pos = string.find(effectFile,'atlas') - 1
        local spName = string.sub(effectFile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil

            local rps = self.intimacyIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2, rps.height / 2))
            roleIcon:setScale(1)
            self.intimacyIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect", true)
        end)
    end
end

function REIconView:stopGMeffect()
    if self.intimacyIconPos then
        self.intimacyIconPos:removeAllChildren()
    end
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
end

function REIconView:showNoIcon()
    self.panelName:setVisible(false)
    self.panelIcon:setVisible(false)
    self.panelNoFace:setVisible(true)
end

function REIconView:showHero(hid,icon_state,rarity,element)
    if not hid then
        self:showNoIcon()
        return
    end

    self.panelName:setVisible(true)
    self.panelIcon:setVisible(true)
    self.panelNoFace:setVisible(false)
    
    if not rarity then 
        rarity = hero[hid].hero_rank
    end

    if not element then 
        element = hero[hid].hero_atb
    end

    local frame = nil
    if g_channel_control.b_LikeState then
        frame = Rarity_Icon_New[rarity]  --外框
    else
        frame = Rarity_Icon[rarity]  --外框
    end
    if frame then
        self.imgRarity:setTexture(frame)
    end

    --Rarity_BG  --背景        
    local rbg = Rarity_E_BG[rarity]   --背景
    if rbg then
        self.imgBG:setTexture(rbg)
    end
    --self.imgBG:setVisible(false)

    local element = ATB_Icon[element] --属性球

    if element then
        self.imgElement:setTexture(element)
    end

    local face = hero[hid].hero_list_icon    
    if face then
        self.imgFace:setTexture(face)
    end

    if g_channel_control.b_LikeState then
        local intimacyState = icon_state or 1

        local intimacy = like_state[intimacyState].icon_min --亲密度
        if intimacy then
            self.intimacyNode:setVisible(true)
            self.intimacyNode:setTexture(intimacy)
        end
        local effectFile = like_state[intimacyState].special_effect --特效资源路径
        if effectFile ~= "" then
            self:startGMeffect(intimacyState)
        else
            self:stopGMeffect()
        end
    elseif self.intimacyNode~= nil then 
        self.intimacyNode:setVisible(false)
    end
    
    self.lbName:setString(UITool.getUserLanguage(hero[hid].hero_name))--(hero[hid].hero_name)    
end

function REIconView:showEquip(eid,rarity,element)
    if not eid then
        self:showNoIcon()
        return
    end
    
    self.panelName:setVisible(true)
    self.panelIcon:setVisible(true)
    self.panelNoFace:setVisible(false)

    if not rarity then
        rarity = equip[eid].equip_rank
    end

    if not element then
        element = equip[eid].equip_atb
    end
                
    local frame = Rarity_Icon[rarity]  --外框
    if frame then
        self.imgRarity:setTexture(frame)
    end

    local rbg = Rarity_E_BG[rarity]   --背景
    if rbg then
        self.imgBG:setTexture(rbg)
    end

    local element = ATB_Icon[element] --属性球
    if element then
        self.imgElement:setTexture(element)
    end

    local face = equip[eid].equip_list_icon    
    if face then
        self.imgFace:setTexture(face)
    end
    if g_channel_control.transform_REIconView_font == true then
        self.lbName:setFontSize(18)
    end
    if self.intimacyNode then
        self.intimacyNode:setVisible(false)
    end
    self:stopGMeffect()
    
    self.lbName:setString(UITool.getUserLanguage(equip[eid].equip_name))--(equip[eid].equip_name)  
end

REBaseIconView = class("REBaseIconView", XUIView)

REBaseIconView.CS_FILE_NAME = "REBaseIconView.csb"
REBaseIconView.CS_BIND_TABLE = 
{
    panelBase = "/i:27",
    imgBG = "/i:27/i:28",
    imgFace = "/i:27/i:29",
    imgRarity = "/i:27/i:30",
    imgElement = "/i:27/i:31",
    imgNew = "/i:27/i:41",
    lbNum = "/i:27/i:43",
}

function REBaseIconView:initHero(hid,isnew)
    REBaseIconView.super.init(self)
    self.lbNum:setString("")

    local rarity = hero[hid].hero_rank
    local element = hero[hid].hero_atb

    self.imgBG:setTexture(Rarity_E_BG[rarity])
    self.imgRarity:setTexture(Rarity_Icon[rarity])
    self.imgElement:setTexture(ATB_Icon[element])
    self.imgFace:setTexture(hero[hid].hero_list_icon)
    --self.imgNew:setVisible(true)
    if not isnew then
        self.imgNew:setScale(1)
        self.imgNew:setTexture("n_UIShare/gacha/ck_ui_016.png")
        
        self.imgNew:runAction(
            cc.RepeatForever:create(
                cc.Sequence:create(
                    cc.MoveBy:create(0.2,cc.p(0,3)),
                    cc.MoveBy:create(0.2,cc.p(0,-3))
                )))
    end

    return self
end


function REBaseIconView:initEquip(eid,isnew)
    REBaseIconView.super.init(self)
    self.lbNum:setString("")

    local rarity = equip[eid].equip_rank
    local element = equip[eid].equip_atb

    self.imgBG:setTexture(Rarity_E_BG[rarity])
    self.imgRarity:setTexture(Rarity_Icon[rarity])
    self.imgElement:setTexture(ATB_Icon[element])
    self.imgFace:setTexture(equip[eid].equip_list_icon)
    self.imgNew:setVisible(isnew)

    return self
end

function REBaseIconView:initMat(mid,num,isnew)
    REBaseIconView.super.init(self)
    self.imgElement:setVisible(false)

    local rarity = mat[mid].rarity
    
    self.imgBG:setTexture(Rarity_BG[rarity])
    self.imgRarity:setTexture(Rarity_mat[rarity])
    self.imgFace:setTexture("icons/mat/"..mat[mid].icon)

    self.imgNew:setVisible(isnew)

    if num then
        self.lbNum:setString("x"..num)
    else
        self.lbNum:setString("")
    end

    return self
end

function REBaseIconView:initCoin(cointype,rarity,num,isnew)
    REBaseIconView.super.init(self)
    self.imgElement:setVisible(false)
    
    self.imgBG:setTexture(Rarity_BG[rarity])
    self.imgRarity:setTexture(Rarity_mat[rarity])
    self.imgFace:setTexture(Coin_Icon[cointype])

    self.imgNew:setVisible(isnew)

    if num then
        self.lbNum:setString("x"..num)
    else
        self.lbNum:setString("")
    end

    return self
end


function REBaseIconView:initItem(itemType,itemId,num,isnew)
    REBaseIconView.super.init(self)
    self.imgElement:setVisible(false)

    local infoTable = UITool.getItemInfos(itemType,itemId)

    self.imgBG:setTexture(infoTable[4])
    self.imgRarity:setTexture(infoTable[1])
    self.imgFace:setTexture(infoTable[2])

    self.imgNew:setVisible(isnew)

    if num then
        self.lbNum:setString("x"..num)
    else
        self.lbNum:setString("")
    end

    return self
end

function REBaseIconView:addItemInfo(item_type,item_id,item_num,equipInfos)
    
    self.panelBase:setTouchEnabled(true)
    self.panelBase:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            MsgManager:showSimpItemInfo(item_type,item_id,item_num,nil, equipInfos)
        end
    end)
end