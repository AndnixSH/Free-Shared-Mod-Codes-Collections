TEXT_FONT_NAME = "font/Microsoft Yahei.ttf"
--注意：此文件 更新客户端之前不能热更新
DEBUG_MODE_LOGIN = tonumber(XBConfigManager:getInstance():getUseLoginType()) --0、自己的登录 1、第三方sdk登陆 

USE_LUA_BATTLE = false --开发中开关，true使用新的lua战斗，false使用之前的c++战斗

TabBarBtn_Icon = {
  [101] = "res/uifile/n_UIShare/newZhuye/ggsc_b_037_1.png",
  [201] = "res/uifile/n_UIShare/newZhuye/ggsc_b_037_2.png",
  [102] = "res/uifile/n_UIShare/newZhuye/ggsc_b_038_1.png",
  [202] = "res/uifile/n_UIShare/newZhuye/ggsc_b_038_2.png",
  [103] = "res/uifile/n_UIShare/newZhuye/ggsc_b_039_1.png",
  [203] = "res/uifile/n_UIShare/newZhuye/ggsc_b_039_2.png",
  [104] = "res/uifile/n_UIShare/newZhuye/ggsc_b_040_1.png",
  [105] = "res/uifile/n_UIShare/newZhuye/ggsc_b_041_1.png",
  [204] = "res/n_UIShare/newZhuye/ggsc_b_041_1.png",
  [205] = "res/uifile/n_UIShare/newZhuye/ggsc_b_041_2.png",
  [106] = "res/uifile/n_UIShare/newZhuye/ggsc_b_042_1.png",
  [206] = "res/uifile/n_UIShare/newZhuye/ggsc_b_042_2.png",
}


lua_musci = {
   huanying1  = "music/ui/banniang/1.mp3",
   huanying2  = "music/ui/banniang/2.mp3",
   zhuyeBGM  = "music/ui/jiemian.mp3",
   loginBGM  = "music/ui/login.mp3",
   zdks = "music/ui/banniang/3.mp3",
}

act_music_file = {
   IA = "music/ui/login_IA.mp3",
   Hanatan = "music/ui/login_hanatan.mp3"
}

Coin_Icon = {

  [1] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_217.png",--金币 掉落
  [2] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_076_1.png",--宝石 
  [3] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_209.png", -- 金币 一个金币 图标
  [4] = "uifile/n_UIShare/Global_UI/other/hdgq_ui_006.png", -- 金币 一坨的图标
  [5] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_218.png",--宝石
  [6] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_252.png",--信仰
  [7] = "uifile/n_UIShare/Global_UI/other/sc_ui_002.png",--人民币
  [8] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_089.png", -- 苍玉
  [9] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_tili.png", -- 体力
  [10] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_040.png", --这个专用 a1_1_2 送两个英雄的
  [11] = "res/hd/Resources/icons/mat/mat_655.png", --神之气息
  [12] = "res/hd/Resources/icons/mat/mat_412.png", --灵魂净化器
  [13] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_100.png", --公会币
  [14] = "res/hd/Resources/icons/mat/mat_630.png", --星光之尘
  [15] = "uifile/n_UIShare/Global_UI/other/ggsc_ui_22_1.png", --圣光之辉
}


BP_Icon = {
  [1] = "res/uifile/n_UIShare/main_page/ggsc_ui_104_1.png",
  [2] = "res/uifile/n_UIShare/main_page/ggsc_ui_104.png",
}

EQ_BG = {
  [1] = "res/uifile/n_UIShare/equip/NewEqInfo/xqzx_bg_002.png",
  [2] = "res/uifile/n_UIShare/equip/NewEqInfo/xqzx_bg_002.png",
  [3] = "res/uifile/n_UIShare/equip/NewEqInfo/xqzx_bg_002.png",
  [4] = "res/uifile/n_UIShare/equip/NewEqInfo/xqzx_bg_002.png",
  [5] = "res/uifile/n_UIShare/equip/NewEqInfo/xqzx_bg_002.png",
}

DC_MP4 = {
  [1] = "music/vedio/san_xing.mp4",
  [2] = "music/vedio/san_xing.mp4",
  [3] = "music/vedio/san_xing.mp4",
  [4] = "music/vedio/si_xing.mp4",
  [5] = "music/vedio/wu_xing.mp4",
}

GM_MP4 = {
  [1] = "music/vedio/gongming.mp4",
}

GM_BTN_IMG = {
  [1] = "uifile/n_UIShare/Intimacy/gmd_b_001a.png",
  [2] = "uifile/n_UIShare/Intimacy/gmd_b_001b.png",
  [3] = "uifile/n_UIShare/Intimacy/gmd_b_002a.png",
  [4] = "uifile/n_UIShare/Intimacy/gmd_b_002b.png",
  [5] = "uifile/n_UIShare/Intimacy/gmd_b_003a.png",
}

GM_JS_BTN_IMG = {
  [1] = "uifile/n_UIShare/Intimacy/gmd_ui_001.png",
  [2] = "uifile/n_UIShare/Intimacy/gmd_ui_002.png",
  [3] = "uifile/n_UIShare/Intimacy/gmd_ui_003.png",
  [4] = "uifile/n_UIShare/Intimacy/gmd_ui_004.png",
  [5] = "uifile/n_UIShare/Intimacy/gmd_ui_005.png",
  [6] = "uifile/n_UIShare/Intimacy/gmd_ui_011.png",
}

DC_MP3 = {
  [1] = "music/ui/choukasr.mp3",
  [2] = "music/ui/choukasr.mp3",
  [3] = "music/ui/choukasr.mp3",
  [4] = "music/ui/choukasr.mp3",
  [5] = "music/ui/choukassr.mp3",
  [6] = "music/ui/choukazhuanhuan.mp3",
}

Rarity_Icon = {
  [5] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_097.png",
  [4] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_098.png",
  [3] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_099.png",
  [2] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_100.png",
  [1] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_101.png",
}
Rarity_Icon_New = {
  [5] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_097_1.png",
  [4] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_098_1.png",
  [3] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_099_1.png",
  [2] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_100_1.png",
  [1] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_101_1.png",
}
Rarity_E_BG = {
  [5] = "uifile/n_UIShare/Global_UI/rarity/ggsc_x_005.png",
  [4] = "uifile/n_UIShare/Global_UI/rarity/ggsc_x_004.png",
  [3] = "uifile/n_UIShare/Global_UI/rarity/ggsc_x_003.png",
  [2] = "uifile/n_UIShare/Global_UI/rarity/ggsc_x_002.png",
  [1] = "uifile/n_UIShare/Global_UI/rarity/ggsc_x_002.png",

}

Rarity_Hero_Frame = {
    "n_UIShare/Global_UI/rarity/ggsc_ui_189.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_188.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_187.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_186.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_185.png"
}

Rarity_Hero_Frame_Sub = {
    "n_UIShare/role/team/jsbc_ui_004.png",
    "n_UIShare/role/team/jsbc_ui_004.png",
    "n_UIShare/role/team/jsbc_ui_003.png",
    "n_UIShare/role/team/jsbc_ui_002.png",
    "n_UIShare/role/team/jsbc_ui_001.png"
}

Rarity_Team_BG = {
    "n_UIShare/Global_UI/rarity/ggsc_ui_190_1.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_190_2.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_190_3.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_190_4.png",
    "n_UIShare/Global_UI/rarity/ggsc_ui_190_5.png"
}

Rarity_BG = {
  [5] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
  [4] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
  [3] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
  [2] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
  [1] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
}

ATB_Icon = {
  [6] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_130.png",
  [5] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_129.png",
  [4] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_128.png",
  [3] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_127.png",
  [2] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_125.png",
  [1] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_126.png",
  [0] = "uifile/n_UIShare/Global_UI/element/ggsc_ui_130.png",
}

Rarity_mat = {
  [5] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_203.png",
  [4] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_204.png",
  [3] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_205.png",
  [2] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_206.png",
  [1] = "uifile/n_UIShare/Global_UI/rarity/ggsc_ui_206.png",
}

EQ_ATB_Icon = {
  [5] = "uifile/n_UIShare/NewHero/eq/jszb_ui_005.png",
  [4] = "uifile/n_UIShare/NewHero/eq/jszb_ui_002.png",
  [3] = "uifile/n_UIShare/NewHero/eq/jszb_ui_004.png",
  [2] = "uifile/n_UIShare/NewHero/eq/jszb_ui_001.png",
  [1] = "uifile/n_UIShare/NewHero/eq/jszb_ui_003.png",
}

DC_KB = {
    [1] = "n_UIShare/chouka/newEffect/kabei/san_xing_ka_bei.png",
    [2] = "n_UIShare/chouka/newEffect/kabei/san_xing_ka_bei.png",
    [3] = "n_UIShare/chouka/newEffect/kabei/san_xing_ka_bei.png",
    [4] = "n_UIShare/chouka/newEffect/kabei/si_xing_ka_bei.png",
    [5] = "n_UIShare/chouka/newEffect/kabei/wu_xing_ka_bei.png",
}

DC_BGG = {
    [1] = "n_UIShare/chouka/newEffect/kabei/san_xing_guang.png",
    [2] = "n_UIShare/chouka/newEffect/kabei/san_xing_guang.png",
    [3] = "n_UIShare/chouka/newEffect/kabei/san_xing_guang.png",
    [4] = "n_UIShare/chouka/newEffect/kabei/si_xing_guang.png",
    [5] = "n_UIShare/chouka/newEffect/kabei/wu_xing_guang.png",
}

UI_BG = {
    [1] = "config/UI_BG/zyzx_bg_001.png",
    [2] = "config/UI_BG/bg_002.png",
    [3] = "config/UI_BG/bg_001.png",
    [5] = "config/UI_BG/drzd_bg_001.png",
    [4] = "config/UI_BG/bg_003_1.png",

    [150] = "uifile/EquipBgLayer.csb"
}

DC_ATB = {
    [101] = "n_UIShare/chouka/effect/ckjm_s2_01.png",
    [201] = "n_UIShare/chouka/effect/ckjm_s2_02.png",
    [301] = "n_UIShare/chouka/effect/ckjm_s2_03.png",
    [401] = "n_UIShare/chouka/effect/ckjm_s2_04.png",
    [501] = "n_UIShare/chouka/effect/ckjm_s2_05.png",
    [111] = "n_UIShare/chouka/effect/ckjm_s3_01.png",
    [211] = "n_UIShare/chouka/effect/ckjm_s3_02.png",
    [311] = "n_UIShare/chouka/effect/ckjm_s3_03.png",
    [411] = "n_UIShare/chouka/effect/ckjm_s3_04.png",
    [511] = "n_UIShare/chouka/effect/ckjm_s3_05.png",
    [121] = "n_UIShare/chouka/effect/ckjm_s1_01.png",
    [221] = "n_UIShare/chouka/effect/ckjm_s1_02.png",
    [321] = "n_UIShare/chouka/effect/ckjm_s1_03.png",
    [421] = "n_UIShare/chouka/effect/ckjm_s1_04.png",
    [521] = "n_UIShare/chouka/effect/ckjm_s1_05.png",
}

DC_BK = {
    [1] = "n_UIShare/chouka/effect/ckjm_ui_005.png",
    [2] = "n_UIShare/chouka/effect/ckjm_ui_006.png",
    [3] = "n_UIShare/chouka/effect/ckjm_ui_007.png",
    [4] = "n_UIShare/chouka/effect/ckjm_ui_005_1.png",
    [5] = "n_UIShare/chouka/effect/ckjm_ui_006_1.png",
    [6] = "n_UIShare/chouka/effect/ckjm_ui_007_1.png",
    [7] = "n_UIShare/chouka/effect/ckjm_ui_005_2.png",
    [8] = "n_UIShare/chouka/effect/ckjm_ui_006_2.png",
    [9] = "n_UIShare/chouka/effect/ckjm_ui_007_2.png"
}
DC_RA = {
    [1] = "n_UIShare/chouka/effect/ckjm_ui_017.png",
    [2] = "n_UIShare/chouka/effect/ckjm_ui_016.png",
    [3] = "n_UIShare/chouka/effect/ckjm_ui_015.png"
}
DC_XY= {
    [3] = "n_UIShare/chouka/effect/ckjm_ui_018.png",
    [2] = "n_UIShare/chouka/effect/ckjm_ui_019.png",
    [1] = "n_UIShare/chouka/effect/ckjm_ui_020.png"
}

RS_BK= {
    [1] = "n_UIShare/chouka/effect/ckjm_ui_022.png",
    [2] = "n_UIShare/chouka/effect/ckjm_ui_023.png",
    [3] = "n_UIShare/chouka/effect/ckjm_ui_024.png"
}


ATB_ACG= {
    -- 属性球 
    -- [5] = "EffElementAn.csb",
    -- [4] = "EffElementGuang.csb",
    -- [3] = "EffElementFeng.csb",
    -- [2] = "EffElementHuo.csb",
    -- [1] = "EffElementShui.csb"
}

RANK_ACG = {
    [5] = "EffInfoFrameWucai.csb",
    [4] = "EffInfoFrameJin.csb",
    [3] = "EffInfoFrameYin.csb",
    [2] = "EffInfoFrameYin.csb",
    [1] = "EffInfoFrameYin.csb"
}

SHOP_BUY_TYPE = {
   [1]    = "n_UIShare/AllMessgae/tc_ui_016.png",
   [2]    = "n_UIShare/AllMessgae/tc_ui_015.png",  -- 宝石
   [13]   = "n_UIShare/AllMessgae/tc_ui_014.png",  -- 苍玉
   [14]   = "n_UIShare/AllMessgae/tc_ui_018.png",
   [20] = "n_UIShare/AllMessgae/ck_ui_019.png", -- 公会币
   [22] = "n_UIShare/AllMessgae/ck_ui_022.png", -- 圣者之辉 
   [712] = "uifile/n_UIShare/xbmain/xbstart/xzy_ui_038.png", -- 糖果
   [901]  = "n_UIShare/AllMessgae/ghz_ui_027.png", -- 奖章  素材当做货币来使用
   [413]  = "n_UIShare/UltimateChallenge/jxtz_ui_017.png", -- 极限代币  素材当做货币来使用
   [1500] = "n_UIShare/guild/newGuild/gh_ui_002.png",      -- 公会代币  素材当做货币来使用
}

HERO_RACE_NAME = {
[1] = UITool.ToLocalization("人类"),
[2] = UITool.ToLocalization("虹晶灵"),
[3] = UITool.ToLocalization("龙之眷属"),
[4] = UITool.ToLocalization("恶魔"),
[5] = UITool.ToLocalization("大地之民"),
[6] = UITool.ToLocalization("妖精"),
[7] = UITool.ToLocalization("魂"),
[8] = UITool.ToLocalization("创造物"),
}

HERO_RACE_ICON = {
[1] = "n_UIShare/Global_UI/race_icon/zz_ui_rl_001.png",
[2] = "n_UIShare/Global_UI/race_icon/zz_ui_hjl_001.png",
[3] = "n_UIShare/Global_UI/race_icon/zz_ui_lzjs_001.png",
[4] = "n_UIShare/Global_UI/race_icon/zz_ui_em_001.png",
[5] = "n_UIShare/Global_UI/race_icon/zz_ui_ddzm_001.png",
[6] = "n_UIShare/Global_UI/race_icon/zz_ui_yj_001.png",
[7] = "n_UIShare/Global_UI/race_icon/zz_ui_g_001.png",
[8] = "n_UIShare/Global_UI/race_icon/zz_ui_czw_001.png",
}

--公会成员等级 会阶图片  1会员、2副会长、3会长
GUILD_MEMBER_RANK_ICON = {
  [1] = "n_UIShare/guild/guild_members/ghcy_ui_003.png",
  [2] = "n_UIShare/guild/guild_members/ghcy_ui_002.png",
  [3] = "n_UIShare/guild/guild_members/ghcy_ui_001.png",
}

--装备分签按钮状态
EQ_TITLE_BTN_IMG = {
  [1] = "n_UIShare/xbmain/xbworkshop/gfjm_b_005_1.png",--nor
  [2] = "n_UIShare/xbmain/xbworkshop/gfjm_b_005_2.png",--select
  [3] = "n_UIShare/xbmain/xbworkshop/gfjm_b_005_2.png",--disable
}

--筛选排序按钮状态
EQ_SORT_BTN_IMG = {
  [1] = "n_UIShare/bag/sx_b_001a.png",--nor
  [2] = "n_UIShare/bag/sx_b_001b.png",--select
  [3] = "n_UIShare/bag/sx_b_001c.png",--disable
}

--装备排序按钮背景图——正常态
EQ_SORT_BTN_BG_NOR = {
  [1] = "n_UIShare/role/sort/ggsc_b_003_1.png",--nor
  [2] = "n_UIShare/role/sort/ggsc_b_003_3.png",--select
  [3] = "n_UIShare/role/sort/ggsc_b_003_1.png",--disable
}

--装备排序按钮背景图——非正常态
EQ_SORT_BTN_BG_CHANGE = {
  [1] = "n_UIShare/role/sort/ggsc_b_003_7.png",--nor
  [2] = "n_UIShare/role/sort/ggsc_b_003_8.png",--select
  [3] = "n_UIShare/role/sort/ggsc_b_003_7.png",--disable
}

--角色详情界面子按钮状态
ROLE_INFO_BTN_IMG = {
  [1] = "n_UIShare/role/newrole/jsxqjm_b_001_1.png",--nor
  [2] = "n_UIShare/role/newrole/jsxqjm_b_001_2.png",--select
  [3] = "n_UIShare/role/newrole/jsxqjm_b_001_2.png",--disable
}

--魂灵装强化界面自动选择按钮状态
SOUL_STH_AUTO_BTN_IMG = {
  [1] = "n_UIShare/SoulEquip/Strengthen/hljm_b_004_1.png",--nor
  [2] = "n_UIShare/SoulEquip/Strengthen/hljm_b_004_2.png",--select
  [3] = "n_UIShare/SoulEquip/Strengthen/hljm_b_004_3.png",--disable
}

--魂灵装强化界面取消自动按钮状态
SOUL_STH_DISAUTO_BTN_IMG = {
  [1] = "n_UIShare/SoulEquip/Strengthen/hljm_b_002_1.png",--nor
  [2] = "n_UIShare/SoulEquip/Strengthen/hljm_b_002_2.png",--select
  [3] = "n_UIShare/SoulEquip/Strengthen/hljm_b_004_3.png",--disable
}

--新版工坊界面页签按钮状态
BAG_MAIN_BTN_IMG = {
  [1] ={"n_UIShare/xbmain/xbworkshop/gfjm_b_001_1.png","n_UIShare/xbmain/xbworkshop/gfjm_b_001_2.png"},
  [2] ={"n_UIShare/xbmain/xbworkshop/gfjm_b_002_1.png","n_UIShare/xbmain/xbworkshop/gfjm_b_002_2.png"},
  [3] ={"n_UIShare/xbmain/xbworkshop/gfjm_b_003_1.png","n_UIShare/xbmain/xbworkshop/gfjm_b_003_2.png"},
  [4] ={"n_UIShare/xbmain/xbworkshop/gfjm_b_004_1.png","n_UIShare/xbmain/xbworkshop/gfjm_b_004_2.png"},
}
--TopBar可消耗素材状态
TOP_BAR_ITEM_COIN_IMG = {
  [1] = "n_UIShare/xbmain/xbstart/xzy_ui_003.png",--体力
  [2] = "n_UIShare/xbmain/xbstart/xzy_ui_002.png",--星石
  [3] = "n_UIShare/xbmain/xbstart/xzy_ui_004.png",--金币
  [4] = "n_UIShare/xbmain/xbstart/xzy_ui_002.png",--苍玉
  [5] = "n_UIShare/xbmain/xbstart/xzy_ui_002.png",--王召之徽
}

--称号增幅不同等级spine
TITLE_EFFECT_SPINE = {
    "armatures/chenghao_star/chjm_ch_005/chjm_ch_005.atlas",
    "armatures/chenghao_star/chjm_ch_004/chjm_ch_004.atlas",
    "armatures/chenghao_star/chjm_ch_003/chjm_ch_003.atlas",
    "armatures/chenghao_star/chjm_ch_002/chjm_ch_002.atlas",
    "armatures/chenghao_star/chjm_ch_001/chjm_ch_001.atlas",  
}

ATTRIBUTE_INFOS = {
    atk = {   
        iconStr = "n_UIShare/role/newrole/sxtb_gjl.png",
        nameStr = UITool.ToLocalization("攻击力"),
        hStr ="+", 
        lStr = ""
    },
    crit = {   
        iconStr = "n_UIShare/role/newrole/sxtb_bj.png",
        nameStr = UITool.ToLocalization("暴击"),
        hStr ="+",
        lStr = "%"
    },
    hp = {   
        iconStr = "n_UIShare/role/newrole/sxtb_smz.png",
        nameStr = UITool.ToLocalization("生命力"),
        hStr ="+",
        lStr = ""
    },
    crit_dmg = {   
        iconStr = "n_UIShare/role/newrole/sxtb_bjsh.png",
        nameStr = UITool.ToLocalization("暴击伤害"),
        hStr ="+",
        lStr = "%" 
    },
    defence = {   
        iconStr = "n_UIShare/role/newrole/sxtb_fyl.png",
        nameStr = UITool.ToLocalization("防御力"),
        hStr ="+",
        lStr = ""
    },
    add_dmg = {   
        iconStr = "n_UIShare/role/newrole/sxtb_zzsh.png",
        nameStr = UITool.ToLocalization("最终伤害"), 
        hStr ="+",
        lStr = "%" 
    },
    hel = {   
        iconStr = "n_UIShare/role/newrole/sxtb_hfl.png",
        nameStr = UITool.ToLocalization("回复力"),
        hStr ="+",
        lStr = "" 
    },
    add_sk_dmg = {   
        iconStr = "n_UIShare/role/newrole/sxtb_gjsh.png",
        nameStr = UITool.ToLocalization("技能伤害"),
        hStr ="+",
        lStr = "%" 
    },
    aspd = {   
        iconStr = "n_UIShare/role/newrole/sxtb_gjjg.png",
        nameStr = UITool.ToLocalization("攻击间隔"),
        hStr ="-",
        lStr = "" 
    },
    pattack_rate = {   
        iconStr = "n_UIShare/role/newrole/sxtb_pgsh.png",
        nameStr = UITool.ToLocalization("普攻倍率"),
        hStr ="+",
        lStr = "%" 
    }
}

visibleSize    = cc.Director:getInstance():getVisibleSize()

ACTIVITY_MARK_MAP = {
   MULTI_BUTTLE  = 10001,--"多人战"
   TRIAL  = 10002,--"试炼之地"
   GUILD_TOWER  = 10003,--"公会塔"
   EXPLORE  = 10004,--"星界探索"
   HEI_CHAO = 10005,--"黑潮遗迹"
   MAIN_COPY = 10006,--"主线副本"
   STAR_COPY = 10007,--星盘关卡
}

TIP_POINT_TAG = 123456
CANG_YI_BG_LOGIN   = "n_UIShare/login/cangyidenglu/cangyibeijing.png"
SU_QING_BG_LOGIN   = "n_UIShare/login/cangyidenglu/suqingbeijing.png"
ZHOU_NIAN_BG_LOGIN = "n_UIShare/login/cangyidenglu/zhounianbeijing.png"
--- 一次引导 抽卡战斗  --不知道有没有用，没敢删
G_NewGuide       = false -- 新手引导   需要手动操作的值


function getEquipFrame(rank)  --- 1 装备人物背景 SS S 框   2 装备属性球   3 现在占时没用 可能作废
    
    local pre_name = "icons/equip/frame/"
    local pre_name1 = "icons/role/atb/"
    if rank == 1 then
       return "uifile/n_UIShare/hero/r_list/ggsc_ui_100_1.png",pre_name.."xllb_ui_008.png"
    elseif rank == 2 then 
       return "uifile/n_UIShare/hero/r_list/ggsc_ui_100.png",pre_name.."xllb_ui_008.png"
    elseif rank == 3 then
       return "uifile/n_UIShare/hero/r_list/ggsc_ui_099.png",pre_name.."xllb_ui_007.png"
    elseif rank == 4 then 
       return "uifile/n_UIShare/hero/r_list/ggsc_ui_098.png",pre_name.."xllb_ui_006.png"
    elseif rank ==5  then 
       return "uifile/n_UIShare/hero/r_list/ggsc_ui_097.png",pre_name.."xllb_ui_005.png"
    end
end

--属性 水火风光暗
function getEquipAtb(atb)  --- 装备属性球
    atb = tonumber(atb)
    if atb > 5 or atb < 1 then
        print("error  getEquipAtb(atb)  %d",atb)
        atb = 1
    end 
    return ATB_Icon[atb]
end 

function getEquipATKPrent(atk)
  local per2 = 0
	if atk <= 300 then
		per2 = atk * 5 / 3913
	else
		per2 = atk / 3913
	end 
  return per2
end

function getEquipHPPrent(hp) 
  local per3 = 0
	if hp <= 300 then
		per3 = hp * 5 / 4818
	else
		per3 = hp / 4818
	end
  return per3
end


function getRoleHPPrent(hp) 
   
 local x  = hp - 2000.0

   if x>0 then
     return 2000.0*3/16000.0 + x /22400.0
   else 
   
   return hp*3.0/16000.0 
   end

end


function getRoleATKPrent(atk) 
  if g_channel_control.NewAtkBarMax then
    local x  = atk - 9000.0

    if x>0 then
      return 9000.0*3/84000 + x /100000
    else 

      return atk*3.0/84000 
    end
  else
    local x  = atk - 2000.0

    if x>0 then
      return 2000.0*3/21000 + x /26610

    else 
      return atk*3.0/21000 
    end
  end
end


function getRoleRank(rank)  --- 角色稀有的
     local pre_name = "n_UIShare/Global_UI/rarity/"
    if rank == 1 then
       return pre_name.."ggsc_ui_246.png"
    elseif rank == 2 then
       return pre_name.."ggsc_ui_245.png"
    elseif rank == 3  then
       return pre_name.."ggsc_ui_244.png"
    elseif rank == 4 then 
       return pre_name.."ggsc_ui_243.png"
    elseif rank == 5 then 
       return pre_name.."ggsc_ui_242.png"
    end

end

function getNewRoleRank(rank)  --- 角色稀有的
  local pre_name = "n_UIShare/role/newrole/"
  if rank == 1 then
    return pre_name.."ggsc_ui_253.png"
  elseif rank == 2 then
    return pre_name.."ggsc_ui_253.png"
  elseif rank == 3  then
    return pre_name.."ggsc_ui_253.png"
  elseif rank == 4 then 
    return pre_name.."ggsc_ui_252.png"
  elseif rank == 5 then 
    return pre_name.."ggsc_ui_251.png"
  end
end 

function getGuildPos( pos )
  -- body
  local  name = "uifile/n_UIShare/Guild/"
  if pos == 6 then
    return name.."ghjm_ui_huizhang.png"
  elseif pos == 5 then
    return name.."ghjm_ui_fuhuizhang.png"
  else  
    return name.."ghjm_ui_cehngyuan.png"
  end
end


function getStrID(id_str)
    local end_pos = string.find(id_str,'*') - 1
    local id = string.sub(id_str,0,end_pos)
    return id
end

function getNumID(id_str)
    local end_pos = string.find(id_str,'*') - 1
    local id = string.sub(id_str,0,end_pos)
    id = tonumber(id)
    return id
end
function getStrTow( str )
  -- body
      local end_pos = string.find(str,',') - 1
      local id  = string.sub(str,0,end_pos)
      local len  = string.len(str)
      local id1 = string.sub(str,end_pos+2,len)
      return id,id1
end
function getTimeNumID(id_str)
    if id_str == nil or id_str == "" then
       return 0
    end
    local  lenS = string.len(id_str)
    local end_pos = string.find(id_str,'*')+1 
    local id = string.sub(id_str,end_pos,lenS)
    id = tonumber(id)
    return id
end
function table_leng(t)
  local leng=0
  for k, v in pairs(t) do
    leng=leng+1
  end
  return leng;
end

function getPSID(id_str)
local end_pos = string.find(id_str,'_') - 1
local id = string.sub(id_str,0,end_pos)
return id
end

function getMatID(id_str)
    local start_pos = string.find(id_str,'_') + 1
    local id = string.sub(id_str,start_pos,string.len(id_str))
    id = tonumber(id)
    return id
end 

function getSubStar( str ,separator)
  -- body
    local end_pos = string.find(str,separator) - 1
    local id  = string.sub(str,0,end_pos)
    local len  = string.len(str)
    local id1 = string.sub(str,end_pos+2,len)
    return id,id1
end

function table.removeif(tb,func)
  local count = #tb
  for i=count,1,-1 do
    if func(tb[i]) then
      table.remove( tb,i )
    end
  end
end

 function table.deepcopy(object)
     local lookup_table = {}
     local function _copy(object)
         if type(object) ~= "table" then
             return object
         elseif lookup_table[object] then
             return lookup_table[object]
         end
         local new_table = {}
         lookup_table[object] = new_table
         for index, value in pairs(object) do
             new_table[_copy(index)] = _copy(value)
         end
         return setmetatable(new_table, getmetatable(object))
     end
     return _copy(object)
 end


--从表中获取元素的值，可以是嵌套关系，依次从表中取值
-- @param table 一个表 类型table
-- @param tableName 表名 类型string
-- @param ... 可变参数 表示表中的key,类型string
function table.getValue(tableName, table, ...)
    local vType =type(table)
    tableName = tableName or "tableName"
    local errorStr = "== Error ==: DataManager:getValue "
    -- Handle strings
    if vType ~='table' then
        errorStr = errorStr.."tableName : "..tostring(tableName).." should be not nil or empty"
        -- print(errorStr)
        LogManager.__showErrorForGetTableValue(errorStr,tostring(tableName))

        return nil
    else
     

    end

    local function errorLog(...)
        -- body
        errorStr = errorStr.."table = "..tostring(tableName)
        local paramCount = select('#', ...)
        for i = 1, paramCount do
            local v = select(i, ...)
            errorStr = errorStr..", "..tostring(v);
        end

        --errorStr = errorStr.."error key is "..tostring(value)
        -- print(errorStr)
        LogManager.__showErrorForGetTableValue(errorStr,tostring(tableName))

    end 


    local value = table
    local paramCount = select('#', ...)
    for i = 1, paramCount do
        local v = select(i, ...)
        --print("k = "..tostring(v))
        if value == nil or type(value) ~= 'table' then
           errorLog(...)
           break
        end
        value = value[v]
    end


    return value;
end



local function graySprite(sprite)

    
      local program = cc.GLProgram:create("ui/shader/gray.vsh","ui/shader/gray.fsh")
      program:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION) 
      program:bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR)
      program:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS)
      program:link()
      program:updateUniforms()
      sprite:setGLProgram(program)

end 

local function removeGraySprite(sprite)
    

    local program = cc.GLProgramCache:getInstance():getGLProgram("ShaderPositionTextureColor_noMVP")
    sprite:setGLProgram(program)
    sprite:getGLProgram():bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION) 
    sprite:getGLProgram():bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR)
    sprite:getGLProgram():bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORDS)
    sprite:getGLProgram():link()
    sprite:getGLProgram():updateUniforms()
    
end 


function grayImageView(imageView)
    
    local sprite = imageView:getVirtualRenderer():getSprite()
      graySprite(sprite)
       
end 

function removeGrayImageView(imageView)
    local sprite = imageView:getVirtualRenderer():getSprite()
       removeGraySprite(sprite)
       
end

--------------------------装备升降序降序-----------------------
function EDSortBaseFun(str)
        print("装备排序 str == "..str)
        local sor_s = nil
        local num = math.floor(str/10) 
        print("装备排序 num == "..num)
        local sort = num%10 --升降序
        print("升降序 sort == "..sort)
        local sort_type = math.floor(num/10) --属性类型
        print("装备排序 sort_type == "..sort_type)
        
        local compFunc = nil
        if sort == 1 then
          compFunc = function(a,b) return a > b end
        else
          compFunc = function(a,b) return a < b end
        end
        
        if sort_type == 1 then
            sor_s = function(item) return item["hp"] end
        elseif sort_type == 3 then
            sor_s = function(item) return item["atk"] end
        elseif sort_type == 2 then
            sor_s = function(item) return item["fp"] end
        elseif sort_type == 6 then
            sor_s = function(item) return item["element"] end    
        elseif sort_type == 4 then
            sor_s = function(item) return item["equip_rank"] end 
        elseif sort_type == 5 then
             sor_s = function(item) return item["Lv"] end
        elseif sort_type == 7 then
            sor_s = function(item) return item["time_id"] end
        elseif sort_type == 8 then
            sor_s = function(item) return item["brk_num"] end
        end
        if sor_s == nil then
          return
        end
        
        table.sort(equip_list,function(x,y)
          if not ((x["owner"] == "0" and y["owner"] == "0") or (x["owner"] ~= "0" and y["owner"]~="0")) then
            return x["owner"] ~= "0"
          elseif sor_s(x) ~= sor_s(y) then
            return compFunc(sor_s(x),sor_s(y))
          else
            return getNumID(x["id"]) > getNumID(y["id"])
          end
        end)
end
--------------------------人物升降序排列-----------------------
function RSortBaseFun( str ,sortInTeam)
   
   local num = math.floor(str/10)
   
   local sort = num%10 --升降序
  
   local sort_type = math.floor(num/10) --属性类型
   
        local compFunc = nil
        if sort == 1 then
          compFunc = function(a,b) return a > b end
        else
          compFunc = function(a,b) return a < b end
        end
        
        local sor_s = nil
        
        if sort_type == 1 then     -- Hp
            sor_s = function (item) return item["hp"] end
        elseif sort_type == 3 then  -- ATk
            sor_s = function (item) return item["atk"] end
        elseif sort_type == 2 then  -- 战力
            sor_s = function (item) return item["fp_all"]["all"] end
        elseif sort_type == 6 then  -- 属性
            sor_s = function (item) return item["element"] end    
        elseif sort_type == 4 then  -- 稀有度
            sor_s = function (item) return item["hero_rank"] end 
        elseif sort_type == 5 then  -- 等级
            sor_s = function (item) return item["Lv"] end
        elseif sort_type == 7 then  -- 入手时间
            sor_s = function (item) return item["time_id"] end
        elseif sort_type == 8 then  -- 突破次数
            sor_s = function (item) return item["break_count"] end
        end
        
        if  sor_s == nil then
          return
        end
        
        if sortInTeam then
        print("--排队伍")
          table.sort(hero_list,function(x,y)
              if not ((#x["team_list"] == 0 and #y["team_list"] == 0) or (#x["team_list"] > 0 and #y["team_list"] > 0)) then
                return #x["team_list"] ~= 0
              elseif sor_s(x) ~= sor_s(y) then
                return compFunc(sor_s(x),sor_s(y))
              else
                return getNumID(x["id"]) > getNumID(y["id"])
              end
            end)
        else
        print("--不排队伍")
          table.sort(hero_list,function(x,y)
            if sor_s(x) ~= sor_s(y) then
              return compFunc(sor_s(x),sor_s(y))
            else
              return getNumID(x["id"]) > getNumID(y["id"])
            end
          end)
        end
    
end
