require "BasicLayer"

CreateGuildLayer = class("CreateGuildLayer",BasicLayer)
CreateGuildLayer.__index = CreateGuildLayer
CreateGuildLayer.lClass = 2 
CreateGuildLayer.selectIndex = 1
CreateGuildLayer.GuildName   = nil
CreateGuildLayer.GuildBulletin = UITool.ToLocalization("欢迎来到苍蓝境界")
CreateGuildLayer.GuildDateTable = nil
function CreateGuildLayer:init()
    local node =cc.CSLoader:createNode("CreateGuildLayer.csb")
    self.uiLayer:addChild(node,0,2) 
    self.exist = true;
        --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    self:initAttrbute()
    self:ShowHighlight(self.selectIndex)
    self:GuildSetBulletin(self.GuildBulletin)


    
end
--/*初始化公会的属性*/
function CreateGuildLayer:initAttrbute( ... )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_main")
    local imageBg           = panel:getChildByName("Image_bg")
    --/*创建公会*/
    local createBtn         = imageBg:getChildByName("Button_create")
    --/*需要申请*/
    local checkBtn          = imageBg:getChildByName("Image_check")
    --/*自动通过*/
    local autoBtn           = imageBg:getChildByName("Image_auto")
    --/*公会名字*/
    local guildName         = imageBg:getChildByName("Text_guildName_zhezhao")
    --/*公会公告*/
    local GuildBulletin     = imageBg:getChildByName("Text_bulletin_zhezhao")
    -- 公会话费
    local GuildCostText     = imageBg:getChildByName("Text_cost")
    GuildCostText:setString(UITool.ToLocalization("(花费星石"))
    --/*公会花费*/
    local GuildCost         = imageBg:getChildByName("Text_cost_1")
    GuildCost:setString(guild_basic_conf.create_cost_gold..")")
    local isCreate = false
    if  user_info["gem"] - guild_basic_conf.create_cost_gold < 0 then
        GuildCost:setColor(cc.c3b(255,0,0)) 
        isCreate = true
    end
    
    if g_channel_control.transform_CreateGuildLayer_Text_order == true then
        GuildCostText:setColor(cc.c3b(255,250,101))
        GuildCostText:setString("("..guild_basic_conf.create_cost_gold)
        GuildCost:setColor(cc.c3b(255,250,101))
        GuildCost:setString(UITool.ToLocalization("(花费星石"))
        if  user_info["gem"] - guild_basic_conf.create_cost_gold < 0 then
            GuildCostText:setColor(cc.c3b(255,0,0)) 
        end
    end

    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if name == "Button_create" then
                if isCreate == false then
                    self:creatGuildSend()
                else
                    MsgManager:showSimpMsg(UITool.ToLocalization("星石不足！"))
                end
            elseif name == "Image_auto" then
                self.selectIndex = 1
                self:ShowHighlight(self.selectIndex)
            elseif name == "Image_check" then
                self.selectIndex = 2
                self:ShowHighlight(self.selectIndex)
            elseif name == "Text_guildName_zhezhao" then
                self:EGuildName()
            elseif name == "Text_bulletin_zhezhao" then
                self:EGuildBulletin()
            else
                self:returnBack()
            end
        end
    end

    panel:addTouchEventListener(touchCallBack)
    createBtn:addTouchEventListener(touchCallBack)
    checkBtn:addTouchEventListener(touchCallBack)
    autoBtn:addTouchEventListener(touchCallBack)
    guildName:addTouchEventListener(touchCallBack)
    GuildBulletin:addTouchEventListener(touchCallBack)

end
-- /*创建成功 需要跳到那个界面*/
function CreateGuildLayer:CreateSuccess( ... )
    -- body
    print("创建成功的回调函数 ，需要跳转到什么界面")
    --self.GuildDateTable   创建成功获取的服务器数据
    self.rData["rcvData"]["callFunc"](self.rData["rcvData"]["self"])
    self:returnBack()
    
end
-- /*公会名字 EidtBox */
function CreateGuildLayer:EGuildName( ... )
    -- body
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.GuildSetName 
    rcvData["defalutStr"] = ""
    rcvData["maxLength"] = 8
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    self.inputLayer = self.sManager:toInputModelLayer(rcvData)
end
-- /*公会公告 EidtBox*/
function CreateGuildLayer:EGuildBulletin( ... )
    -- body
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.GuildSetBulletin 
    rcvData["defalutStr"] = ""
    rcvData["maxLength"] = 76
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    self.inputLayer = self.sManager:toInputModelLayer(rcvData)
end

-- /*公会自动 审核  被选择的更换高亮图片*/
function CreateGuildLayer:ShowHighlight( nindex )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_main")
    local imageBg           = panel:getChildByName("Image_bg")
    local checkBtn          = imageBg:getChildByName("Image_check")
    local autoBtn           = imageBg:getChildByName("Image_auto")
    if nindex == 1 then --自动通过
        checkBtn:loadTexture("uifile/n_UIShare/Global_UI/btn/explore_s_b_001_1.png")
        autoBtn:loadTexture("uifile/n_UIShare/Global_UI/btn/explore_s_b_001_2.png")
        autoBtn:setColor(cc.c3b(248,236,172)) 
        checkBtn:setColor(cc.c3b(214,209,191)) 
    elseif nindex == 2 then -- 申请通过
        checkBtn:loadTexture("uifile/n_UIShare/Global_UI/btn/explore_s_b_001_2.png")
        autoBtn:loadTexture("uifile/n_UIShare/Global_UI/btn/explore_s_b_001_1.png")
        checkBtn:setColor(cc.c3b(248,236,172)) 
        autoBtn:setColor(cc.c3b(214,209,191)) 
    end
end
--/*设置公会的名字*/
function CreateGuildLayer:GuildSetName( str )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_main")
    local imageBg           = panel:getChildByName("Image_bg")
    --/*公会名字*/
    local guildName         = imageBg:getChildByName("Text_guildName")
    guildName:setString(str)
    self.GuildName = str

end
-- /*设置公会的公告*/
function CreateGuildLayer:GuildSetBulletin( str )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_main")
    local imageBg           = panel:getChildByName("Image_bg")
     --/*公会公告*/
    local GuildBulletin     = imageBg:getChildByName("Text_bulletin")
    GuildBulletin:setAnchorPoint(cc.p(0,1))
    GuildBulletin:setPosition(cc.p(267,290))
    GuildBulletin:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    GuildBulletin:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    GuildBulletin:ignoreContentAdaptWithSize(false);
    GuildBulletin:setTextAreaSize(cc.size(430,100))


    GuildBulletin:setString(str)
    self.GuildBulletin = str
end
--/*创建公会 获取服务其消息*/
function CreateGuildLayer:creatGuildSend( ... )
    -- body
    if self.GuildName == nil then
        MsgManager:showSimpMsg(UITool.ToLocalization("请输入公会名字"))
        return
    end
    local function reiceSthCallBack(data)
        print("创建公会")
        
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end

        local str = string.format(UITool.ToLocalization("恭喜\n%s\n创建成功!"),self.GuildName)
        MsgManager:showSimpMsgWithCallFunc1(str,self,self.CreateSuccess)
        self.GuildDateTable = t_data["data"]

        --创建公会后，把公会id存到user_info 里面
        user_info["guild_id"] = table.getValue("CreateGuildLayer GuildDateTable",self.GuildDateTable, "guild_id")
        user_info["guild_notice"] = self.GuildBulletin

        --聊天同步公会信息
        -- XBChatSys:getInstance():saveMyGuideIdForChat()
    end

    local cjson = require "cjson"


    local tempTable = {
        ["rpc"]       = "guild_create",
        ["guild_name"] = self.GuildName,
        ["join_condition"] = self.selectIndex - 1,
        ["notice"] = self.GuildBulletin,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end


function CreateGuildLayer:returnBack( ... )
    -- body
    self.exist = false
   -- self.area = {}
    self:clearEx()
end

function CreateGuildLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function CreateGuildLayer:create(rData)

     local login = CreateGuildLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login
     -- local msgModel = MsgModelLayer.new()
     -- msgModel.rData = tdata 
     -- msgModel.sManager  = sManager
     -- msgModel.uiLayer = cc.Layer:create()
     -- msgModel:init()
     -- return msgModel
     
end
