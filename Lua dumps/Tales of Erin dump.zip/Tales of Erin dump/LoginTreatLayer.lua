--[[
info:
登录条款界面
]]



LoginTreatLayer = class("LoginTreatLayer")

function LoginTreatLayer:init()
   
    self.confirmCallback = nil;
    self:initView();
    self:addBtnListener();
    self:refreshView();

end

function LoginTreatLayer:initView()
    local  node = cc.CSLoader:createNode("LoginTreatLayer.csb");
    self.uiLayer:addChild(node,0,1);   

    self._rootCSbNode = node:getChildByTag(2197);
    
    self._ListView_agree = ccui.Helper:seekWidgetByName(self._rootCSbNode,"ListView_agree");
    self._ListView_person = ccui.Helper:seekWidgetByName(self._rootCSbNode,"ListView_person");
    
    self._CheckBox_1 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"CheckBox_1");
    self._CheckBox_1:setSelected(false);
    self._CheckBox_2 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"CheckBox_2");
    self._CheckBox_2:setSelected(false);

    self._CheckBox_3 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"CheckBox_3");

    
    self._Button_close = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_close");
      
end

function LoginTreatLayer:refreshView()
    self:initTreatAgreeList();
    self:initPersonInfoList();
    --self:initJPushBtn();

end



function LoginTreatLayer:addBtnListener()
   
    local this = self;
    self._Button_close:addClickEventListener(function (pSender)
        -- body
        print("点击按钮 agree close");

        --this:testJson();
        --this:getTable();

        this:confirmBtnCallBack(pSender);
    end);
end

function LoginTreatLayer:confirmBtnCallBack(sender)
    print("点击按钮 agree treat");
    if self:checkAgree() then
        self.uiLayer:setVisible(false);
         
        cc.UserDefault:getInstance():setBoolForKey("treat_agree", true);
        if self.confirmCallback ~= nil then
            self.confirmCallback();
        end
    else
        MsgManager:showSimpMsg(UITool.ToLocalization("服务条款 及 安全条款需要进行同意")) --基本的提示信息，单确定
    end
end

function LoginTreatLayer:setConfirmCallback(callback)
    -- body
    self.confirmCallback = callback;
end

--检测是否同意条款
function LoginTreatLayer:checkAgree()
    if self._CheckBox_1:isSelected() and self._CheckBox_2:isSelected() then
        return true;
    end
    return false;
    
end

--数据表中的数据格式
-- {
--     "str":"8) 회사가 회원에게 제 4항과 같이 고지하였음에도 회원이 변경된 약관에 대한 정보를 알지 못해 발생하는 피해에 대해서는 회사는 책임지지 않습니다.",
--     "color":"#ff0000",
--     "bold":0,
--     "size":20,
--     "align":"left"
-- }
function LoginTreatLayer:getTable()
    local data = JsonUtil.getTableFromFile("system_btn/treat_agree.json" );
    dump(data, "table: ");

end



--初始化 treat list
function LoginTreatLayer:initTreatAgreeList()
    
    --set bar
    self._ListView_agree:setScrollBarEnabled(true)
    self._ListView_agree:setScrollBarWidth(20)
    self._ListView_agree:setScrollBarColor(cc.c3b(0, 0, 0))
    self._ListView_agree:setScrollBarOpacity(225*0.5)
    self._ListView_agree:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end

    --local textArr = JsonUtil.getTableFromFile("system_btn/treat_agree.json" );
    local textArr = TREAT_AGREE_CONTENT;
    --dump(treat_agree_content, "treat_agree_content:")
    


    --技能
    for i=1,#textArr do
        

        local item_des = ccui.Layout:create();
        local desText = self:getLabelUI(textArr[i])
        local virtualSize = desText:getVirtualRendererSize();
        --dump(virtualSize, "virtualSize : ")
        item_des:setContentSize(cc.size(virtualSize.width , virtualSize.height+10));
        
        item_des:addChild(desText)
        self._ListView_agree:pushBackCustomItem(item_des)
        
    end
end

--初始化 person info list
function LoginTreatLayer:initPersonInfoList()
    
    --set bar
    self._ListView_person:setScrollBarEnabled(true)
    self._ListView_person:setScrollBarWidth(20)
    self._ListView_person:setScrollBarColor(cc.c3b(0, 0, 0))
    self._ListView_person:setScrollBarOpacity(225*0.5)
    self._ListView_person:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end

    --local textArr = JsonUtil.getTableFromFile("system_btn/treat_person_info.json" );
    local textArr = TREAT_PERSON_INFO_CONTENT;

    --技能
    for i=1,#textArr do
        

        local item_des = ccui.Layout:create();
        local desText = self:getLabelUI(textArr[i])
        local virtualSize = desText:getVirtualRendererSize();
        --dump(virtualSize, "virtualSize : ")
        item_des:setContentSize(cc.size(virtualSize.width , virtualSize.height+10));
        
        item_des:addChild(desText)
        self._ListView_person:pushBackCustomItem(item_des)
        
    end
end

function LoginTreatLayer:initJPushBtn()
    -- body
    -- s

     --0 未存储  2 取消推送  1 接受推送
    local pushAgree = 1;
    if cc.UserDefault:getInstance():getIntegerForKey("push_agree_") ~= 0 then
        pushAgree = cc.UserDefault:getInstance():getIntegerForKey("push_agree")
    end 
    if pushAgree == 1 then
        --判断手机后台是否开启推送
        local methodName = "isOpen"
        local args_android = {}
        local args_ios = {}
        local signs = "()Z"
        local ok,ret = jpushCallPlatform(methodName,args_ios,args_android,signs)
        if ok then
            if ret then 
                pushAgree = 1
            else
                pushAgree = 2
            end
            
        end
         cc.UserDefault:getInstance():setIntegerForKey("push_agree", pushAgree)
    end

    self._CheckBox_3:setSelected( pushAgree == 1 );

    local this = self;
    local function selectedEvent(sender,eventType)
        if eventType == ccui.CheckBoxEventType.selected then
            this:setJPushOpen(1);
            MsgManager:showSimpMsg(UITool.ToLocalization("开启推送"))
            
        elseif eventType == ccui.CheckBoxEventType.unselected then
            this:setJPushOpen(2);
            MsgManager:showSimpMsg(UITool.ToLocalization("关闭推送"))
        end
    end

    self._CheckBox_3:addEventListener(selectedEvent)

end

-- --设置开关
function LoginTreatLayer:setJPushOpen(openType)
    cc.UserDefault:getInstance():setIntegerForKey("push_agree", openType);
    openType = openType or 0
    local platform = cc.Application:getInstance():getTargetPlatform()
    if (cc.PLATFORM_OS_ANDROID == platform) then
        --调用SDK登录
        local args = {openType}
        local sigs = "(I)V"
        local className = "org/cocos2dx/lua/XBJpushControl"
        local ok ret = zc.luaBridgeCall(className,"setOpenPush",args,sigs)
        
    end
end



---label
--说明： 在创建的时候设置字体，比创建完成设置字体要快很多
function LoginTreatLayer:getLabelUI(info,addH)
    -- body
    info = info or {}
    addH = addH or 0


    local infoStr = info.str or "";
    local color16 = info.color or "#ffffff";
    local bold = info.bold ~= nil and info.bold ~= 0 and true or false;
    local size = info.size or 20;
    local align = cc.TEXT_ALIGNMENT_LEFT;
    if info.align == "left" then
        align = cc.TEXT_ALIGNMENT_LEFT;
    elseif info.align == "center" then
        align = cc.TEXT_ALIGNMENT_CENTER;
    elseif info.align == "right" then
        align = cc.TEXT_ALIGNMENT_RIGHT;
    end

    local color = lemon.ColorUtil.getRgb(color16)
    -- --缩进
    local indendtation = info.indendtation or 0;

    --描边颜色ß
    local outLineColor = cc.c4b(0,0,0,255);

    if bold then
        outLineColor = cc.c4b(color.r, color.g, color.b, 255);
    end


    

    --local row = math.ceil(UITool.getCharLength(infoStr)/25)
   -- local desText = ccui.Text:create("",TEXT_FONT_NAME,22)  
    local desText = ccui.Text:create()
    desText:setFontSize(size)
    desText:enableOutline(outLineColor,1)
    desText:ignoreContentAdaptWithSize(false)
    desText:setString(infoStr)
    desText:setTextHorizontalAlignment(align)
    desText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    desText:setColor(color)
    desText:setPosition(indendtation + 5,0)
    desText:setAnchorPoint(cc.p(0, 0))
    local textWidth = 440 - indendtation;
    local size = cc.size(textWidth, 0);
    desText:setTextAreaSize(size);
    local virtualSize = desText:getVirtualRendererSize();
    desText:setContentSize(virtualSize)
    return desText
end

function LoginTreatLayer:create()
     local layer = LoginTreatLayer.new()
     layer.uiLayer = cc.Layer:create()
     layer:init();
     return layer;
end
