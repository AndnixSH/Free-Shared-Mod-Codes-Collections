lemon = lemon or {}
lemon.ColorUtil =   {}
local ColorUtil = lemon.ColorUtil

--从16进制颜色转换为rgb格式的颜色
function ColorUtil.getRgb(color16)
	color16 = color16 or "#000000";
    if string.len(color16) ~= 7 then
        return cc.c3b(0,0,0)
    end
  
    local red16 = string.sub(color16, 2, 3)
    local green16 = string.sub(color16, 4, 5)
    local blue16 = string.sub(color16, 6, 7)
    

    local red10 = string.format("%d", "0x"..red16);
    local green10 = string.format("%d", "0x"..green16);
    local blue10 = string.format("%d", "0x"..blue16);

    return cc.c3b(tonumber(red10), tonumber(green10), tonumber(blue10))

   --return cc.c3b(255,255,255);
end

