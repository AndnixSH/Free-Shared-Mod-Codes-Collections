---NimSDKManager Call
---聊天调用第三方

function NimLoginForBattle(  )
  -- body
  -- require "ChatLayer"
end
function NimLoginSuccess(  )
  -- body
  print("call ---chatLayer:loginNimSuccess")
  ChatDataManager:getInstance():loginNimSuccess()
end

function NimChatRoomhistoryCall( data )
  -- body--废弃
  ChatDataManager:getInstance():receiveChatRoomData(data)

end

function callNimSendMessageOK( data ) --消息发送成功回调
  -- body
  ChatDataManager:getInstance():receiveSendMessageData(data)

end

function callNimServerMessagesReturn( data )
  ChatDataManager:getInstance():receiveNimServerMessageData(data)
end

function callOnReceiveSystemNotification( data )
  ChatDataManager:getInstance():onReceiveSystemNotification(data)
end

function callRecordOver( data )
  ChatDataManager:getInstance():callRecordOverFile(data)
end

function playAudioCompletedWithError( data )
  ChatDataManager:getInstance():playAudioCompletedWithError(data)
end
function didAddRecentSession( data )
  ChatDataManager:getInstance():didAddRecentSession(data)
end
function didUpdateRecentSession( data )
  ChatDataManager:getInstance():didUpdateRecentSession(data)
end
function didRemoveRecentSession( data )
  ChatDataManager:getInstance():didRemoveRecentSession(data)
end
