--所有角色和怪物基础类
--created by kobejaw.2018.3.22.
EntityBase = class("EntityBase", function()
    return cc.Node:create();
end);

function EntityBase:ctor(data,teamManager)
	self.idxForUpdate = 1   --优化。角色的组件和触发器在奇数帧更新，怪物的在偶数帧更新。
	self.deltaForUpdate = 0

	self.data = data;
	self.teamManager = teamManager
	self.teamManager:addEntity(self)

	self.attackData = data.attackData

	self:init()--初始化各种成员变量
	self:startUpdate();--启动update
end

function EntityBase:init()
	self.isDead = false;
	self.isBianshen = false; --目前只有玛欧用到。

	--角色当前所处的格子。
	self.box_w = nil;
	self.box_h = nil;

	--属性管理器
	self.attributeManager = AttributeManager.new(self)
	--组件管理器
	self.componentManager = ComponentManager.new(self)
	--触发器管理器
	self.triggerManager = TriggerManager.new(self)
	self.triggerManager:initTriggers()
	
end

function EntityBase:getTeamManager(teamManager)
	return self.teamManager;
end

function EntityBase:stopNodeAndSpineActions()
	self:stopAllActions();
    self.spineNode:stopAllActions();
end

function EntityBase:stopNodeActions()
	self:stopAllActions();
end

function EntityBase:stopSpineActions()
    self.spineNode:stopAllActions();
end

--设置地块信息
function EntityBase:setBoxDataByIdx(idx)
	self.box_w,self.box_h = GetWHByIdx(idx)
end

function EntityBase:setBoxDataByWH(w,h)
	self.box_w = w;
	self.box_h = h;
end

--获取当前所在格子的w，h值
function EntityBase:getBoxWH()
	if self.isBoss then
		return 15,1 --注：C++里也是这么写死的
	else
		return self.box_w,self.box_h
	end
end

--获取当前所在的格子的idx
function EntityBase:getBoxIdx()
	return self.box_w*3 + self.box_h
end

--获取怪物类型
function EntityBase:getMonsterEnum()
	if self.entityType == 1 then
		return 0
	else
		return self.data.monsterEnum
	end
end
--设置朝向
function EntityBase:setOrientation(enemy)
	local deltaX;
	if enemy  == nil then--如果为空就是对于我方角色修正为朝右,怪物修正为朝左
		if self.entityType == 1 then
			deltaX = 1;
		else
			deltaX = -1
		end
	else
		deltaX = enemy:getPositionX() - self:getPositionX()
	end

	if deltaX == 0 then
		return
	end

	if self.entityType == BattleGlobals.EntityType.Role then
		if deltaX < 0 then
			self.spineNode:setRotationSkewY(180)
			self.faceTo = BattleGlobals.FaceLeft
		else
			self.spineNode:setRotationSkewY(0)
			self.faceTo = BattleGlobals.FaceRight
		end		
	else
		if deltaX > 0 then
			self.spineNode:setRotationSkewY(180)
			self.faceTo = BattleGlobals.FaceRight
		else
			self.spineNode:setRotationSkewY(0)
			self.faceTo = BattleGlobals.FaceLeft
		end			
	end
end

--检测一下格子中是否有敌人。
function EntityBase:checkBoxOccupiedByEnemyWithIdx(idx)

	for k,v in ipairs(self.enemyList) do
		if not v.isDead and idx == v.box_w*3 + v.box_h then
			return true
		end
	end
	return false
end

--检测一下格子中是否有敌人。
function EntityBase:checkBoxOccupiedByEnemyWithWH(w,h)

	if BattleDataManager.isBoss then
		if w>=15 then
			return true
		end
	end

	for k,v in ipairs(self.enemyList) do
		if not v.isDead and w == v.box_w and h == v.box_h then
			return true
		end
	end
	return false
end

--！！must override
function EntityBase:onDead()
end

--设置队友和敌人列表
function EntityBase:setTeammateAndEnemyList()
	if self.entityType == 1 then
		self.enemyList = G_Monsters
		self.teammateList = G_Roles
	else
		self.enemyList = G_Roles
		self.teammateList = G_Monsters
	end
end

--设置touch_rect信息，体积和射程有关的内容
function EntityBase:setTouchRectInfo()
	if self.entityType == BattleGlobals.EntityType.Role then
		self.touchRect = hero[self.data.heroId].hero_touch
		self.shotRange = self.data.shotRange
		self.cubageType = 0
	else
		self.touchRect = monster[self.data.monsterId].monster_touch
		self.shotRange = self.data.shotRange
		self.cubageType = 0
		--怪物体积相关
		--体积类型。cubageType为1时是1*1，为2时是5*1,为3时是7*1。根据monster_touch这个字段的w值判定。
		if not BattleDataManager.isBoss then
			if self.touchRect[3] <= 150 then
				self.cubageType = 0
			elseif self.touchRect[3] <= 200 then
				self.cubageType = 2
			else
				self.cubageType = 3
			end
			self.shotRange = self.shotRange + self.cubageType
		end
	end

	--设置中心点坐标
	self.centerPoint = cc.p((self.touchRect[1] + self.touchRect[3])/2,(self.touchRect[2] + self.touchRect[4])/2)
end

--获取touch_rect，用于检测是否碰撞
function EntityBase:getTouchRect()
	return self.touchRect
end

--获取entity的中心点坐标(entity坐标系)
function EntityBase:getCenterPoint()
	return self.centerPoint
end

--获取entity的中心点坐标(BattleLayer坐标系)
function EntityBase:getCenterPointInBattleLayer()
	return cc.p(self.centerPoint.x + self:getPositionX(),self.centerPoint.y + self:getPositionY())
end

--获取飘字的位置(BattleLayer坐标系)
function EntityBase:getDamageShowingPos(isCrit)
	if isCrit and self.fsm.currentState.stateEnum == StateEnum.UnusualCondition and self.fsm.currentState.stateType<=2  then
		y = self.fsm.currentState.initial_y
	else
		y = self:getPositionY()
	end

	if not y then
		y = 360
	end

	return cc.p(self.centerPoint.x + self:getPositionX(),self.centerPoint.y + y)
end

--检测对手里是否有嘲讽，如果有，返回嘲讽者的entity
--每次普通攻击完成后检测一下。
--如果敌人中有多个人身上有嘲讽buff，新buff的优先级最高
function EntityBase:checkTaunt()
	local temp = {}

	for k,v in pairs(self.enemyList) do
		if not v.isDead and v.componentManager:getComById(81040) then
			table.insert(temp,v)
		end
	end

	if #temp > 1 then
		table.sort(temp,function (a,b)
			return a.gameTime > b.gameTime
		end)
		return temp[1]
	elseif #temp > 0 then
		return temp[1]
	end

	return nil
end

--检测魅惑的情况
function EntityBase:checkMeiHuo()
	if self.componentManager.MeiHuo then
		local rate = self.componentManager.MeiHuoCom.rate
		if rate then
			return CheckProbabilityEvent(rate)
		end
	end
	return false
end

--切换到技能状态。boss和带技能的小怪会用到。
function EntityBase:attackWithSkill(skillInfo)
	self.fsm:changeState(skillInfo.skillStateEnum,skillInfo)
end

function EntityBase:startUpdate()
	local this = self;
	local function update(dt)
		if this.isDead then
			return
		end
		--更新角色自身的update
		this:update(dt)
		--更新状态机中的update。
		this.fsm:update(dt)
	end
	this:scheduleUpdateWithPriorityLua(update,0)
end

--spine事件处理
function EntityBase:initSpineListeners()
	local this = self;

	local function eventCallback(event)
		self.fsm.currentState:onSpineEventCallback(event)
	end

	local function completeCallback(event)
		self.fsm.currentState:onSpineCompleteCallback(event)
	end	

	self.spineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
	self.spineNode:registerSpineEventHandler(completeCallback,sp.EventType.ANIMATION_COMPLETE)
end


--各种动画播放
function EntityBase:playIdleAnimation()
	self.spineNode:setToSetupPose()
	local aniName = "loading"
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,true)
	
end

function EntityBase:playRunAnimation()
	self.spineNode:setToSetupPose()
	local aniName = "run"
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,true)	
end

function EntityBase:playAttackAnimation()
	self.spineNode:setToSetupPose()
	local aniName = SpineAnimationName.Attack
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,false)
end

--使用技能
function EntityBase:playSkillAnimation(skillInfo)
	self.spineNode:setToSetupPose()

	local aniName = skillInfo.skillActionName
	if self.isBianshen then
		aniName = aniName.."2"
	end

	self.spineNode:setAnimation(0,aniName,false) 

	if self.entityType == 1 then
		--语音音效
		BattlePlaySound(skillInfo.skill_voice,false,1)
	end
end

--浮空动画
function EntityBase:playFloatAnimation()
	self.spineNode:setToSetupPose()
	local aniName = SpineAnimationName.Float
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,false)	
end
--普通摔+起身1
function EntityBase:playStandUp1Animation()
	self.spineNode:setToSetupPose()
	local aniName = SpineAnimationName.StandUp1
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,false)		
end
--重摔+起身2
function EntityBase:playStandUp2Animation()
	self.spineNode:setToSetupPose()
	local aniName = SpineAnimationName.StandUp2
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,false)		
end
function EntityBase:playBeHitAnimation()
	self.spineNode:setToSetupPose()
	local aniName = SpineAnimationName.BeHit
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,false)		
end
function EntityBase:playDeadAnimation()
	self.spineNode:setToSetupPose()
	local aniName = SpineAnimationName.Dead
	if self.isBianshen then
		aniName = aniName.."2"
	end
	self.spineNode:setAnimation(0,aniName,false)		
end
