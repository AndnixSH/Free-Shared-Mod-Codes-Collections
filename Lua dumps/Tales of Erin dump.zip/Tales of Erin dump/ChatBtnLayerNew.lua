require "BasicLayer"
ChatBtnLayerNew = class("ChatBtnLayerNew", BasicLayer)
ChatBtnLayerNew.__index = ChatBtnLayerNew
ChatBtnLayerNew.lClass  = 3   
ChatBtnLayerNew.rData = nil

-- user_id,user_name,user_icon,sessionType
  --世界频道 sessionType = 2，点击头像：加/删好友，加/删黑名单，私聊 
  --私聊 sessionType = 0 好友：删除好友,加/删黑名单 （黑名单状态无法加好友）
  --私聊 sessionType = 0 最近联系：加好友，加黑名单

function ChatBtnLayerNew:init()
	self:initData()
	self:bindAll()

end

function ChatBtnLayerNew:initData(  )
	self.chatDataMgr = ChatDataManager:getInstance()
	self.playerInfo = {}

	self.playerInfo["user_icon"] 	= self.rData["user_icon"]
	self.playerInfo["user_name"] 	= self.rData["user_name"]
	self.playerInfo["user_id"]	    = self.rData["user_id"]
	self.playerInfo["isFriend"] 	= self.chatDataMgr:isInFriends(self.playerInfo["user_id"]) --显示加/删 好友
	self.playerInfo["isBlack"]		= self.chatDataMgr:isInBlacks(self.playerInfo["user_id"])  --显示加/删 黑名单
	self.playerInfo["reportMsg"] 	= self.rData["reportMsg"]
end

function ChatBtnLayerNew:bindAll(  )
	local node  = cc.CSLoader:createNode("ChatBtnLayer.csb") 
	self.uiLayer:addChild(node,0, 2)

	local panel = node:getChildByName("panel")

	local roleFace = panel:getChildByName("roleFace")			--头像
	if self.playerInfo["user_icon"] then
		local heroinfo = hero[self.playerInfo["user_icon"]]
		roleFace:setTexture(heroinfo.hero_bat_icon)
	end

	local roleName = panel:getChildByName("roleName")			--名字
	if self.playerInfo["user_name"] then
		roleName:setString(self.playerInfo["user_name"])
	end

	local btn_addFriend = panel:getChildByName("btn_addFriend") --添加好友
	local btn_addBlack = panel:getChildByName("btn_addBlack")	--添加黑名单
	local btn_chat = panel:getChildByName("btn_chat")			--私聊   如果是黑名单，则变灰
	local btn_rm = panel:getChildByName("btn_rm")				--删除好友 --移除
	local btn_close = panel:getChildByName("btn_close") 		--关闭
	local btn_report = panel:getChildByName("btn_report")		--举报
	print("playerInfo...isMyFriend:"..tostring(self.playerInfo["isFriend"]))
	if self.playerInfo["isFriend"] == true then
		local text = btn_addFriend:getChildByName("Text_2")
		text:setString(UITool.ToLocalization("删除好友"))
	else 
		if self.playerInfo["isBlack"] == true then
			btn_addFriend:setEnabled(false)
			btn_addFriend:setBrightStyle(ccui.BrightStyle.none)	
		end
	end
	print("playerInfo...isback:"..tostring(self.playerInfo["isBlack"]))
	if self.playerInfo["isBlack"] == true then
		local text = btn_addBlack:getChildByName("Text_2")
		text:setString(UITool.ToLocalization("取消黑名单"))
	end
	local sessionType = self.rData["sessionType"]
	print("sessionType:"..tostring(sessionType))
	if sessionType == 0 or self.playerInfo["isBlack"] == true then --私聊，黑名单不显示私聊按钮
		btn_chat:setEnabled(false)
		btn_chat:setBrightStyle(ccui.BrightStyle.none)	
	end
	if self.playerInfo["reportMsg"] == nil or g_channel_control.chatShowReport ~= true then --没有内容不显示举报
		btn_report:setVisible(false)
	end

	btn_rm:setVisible(false)

	local function CallBack( sender,eventType )
		local t = {
		 pannel_name = sender:getName(),
		 user_id 	 = self.playerInfo["user_id"],
		 player_id   = self.playerInfo["player_id"],
		} 
		
	    if sender:getName() == "btn_close" then
			self:callClose()
		else
			print("---------------name:"..tostring(sender:getName()))
			if self.rData["callbackFunc"] then
	        	self.rData["callbackFunc"](t)
	   		 end
		 	self:clear()

		end

	end
	btn_addFriend:addClickEventListener(CallBack)
	btn_addBlack:addClickEventListener(CallBack)
	btn_chat:addClickEventListener(CallBack)
	btn_rm:addClickEventListener(CallBack)
	btn_close:addClickEventListener(CallBack)
	btn_report:addClickEventListener(CallBack)
end

function ChatBtnLayerNew:callClose( )
-- body
	print("------call close------")
    self:clear()
end


function ChatBtnLayerNew:create(tdata,sManager)

     local layer = ChatBtnLayerNew.new()
	 layer.rData = tdata 
	 layer.sManager  = sManager
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end