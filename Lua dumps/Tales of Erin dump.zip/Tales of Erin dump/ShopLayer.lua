require "BasicLayer"
-- 登陆奖励
ShopLayer = class("ShopLayer",BasicLayer)
ShopLayer.__index   = ShopLayer
ShopLayer.lClass    = 2 
ShopLayer.ShopTabe  = nil
ShopLayer.ListView  = nil;
ShopLayer.resPath   = "res/uifile/n_UIShare/shop/"
ShopLayer.imgBtnDJ  = nil
ShopLayer.imgBtnMM  = nil
ShopLayer.imaCY     = nil
ShopLayer.imgBtnXS  = nil
ShopLayer.Shopindex = 3;
ShopLayer.TestTable = nil   
ShopLayer.isDownTiem = false
ShopLayer.TestNumTable  = nil;
ShopLayer.TestCurBuy = nil;
ShopLayer.TestMaxBuy = nil;
ShopLayer.TestCurRes = nil;
ShopLayer.TestMaxRes = nil;
ShopLayer.GemBuyItemNum = nil;
ShopLayer.onlyBuy = false
ShopLayer.m_AudoId  = nil;
-- 函数  三种购买形式----
-- BuyTwo      -- 人民币购买
-- BuyDaojuTow -- 秘密商店购买，因为秘密商店需要多种消耗货币  所以进行判断之后调用ItemBuy
-- ItemBuy     -- 是一种消耗货币调用的   不用判断货币不足   服务器返回消息
-- 道具屋 弹出框不可选数量  因为现在价格是变动的
-- 二次改版的变动-----
-- BuyDaojuTow  除了人民币购买  其他的购买都走这个接口，先进行判断消耗货币，在弹窗

function ShopLayer:init()
    print("进入商店初始化函数")
    local node    = cc.CSLoader:createNode("ShopLayer.csb")
    
    self.uiLayer:addChild(node,0,2)
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    self.exist = true
    self.TestNumTable = node:getChildByName("Text_2");
    self.ListView = node:getChildByName("ListView_1")
    self.BeryNum = node:getChildByName("berylnum")
    self:refreshBerylNum()
    self:initMode()
    self:initBtn();
    if self.rData["rcvData"]["shopTypeIndex"] then
        self:ShopTypeCall(self.rData["rcvData"]["shopTypeIndex"])
    else
        self:SendShopTable(3)
        self:SwitchImage(self.Shopindex)
    end

    self:setNodeLockState()


    if g_channel_control.transform_ShopLayer_zhekText_fontSize == true  then
       
        local zhekou     = node:getChildByName("Image_zhekuo")
        local childrenArr = zhekou:getChildren()
        local zhekText   = zhekou:getChildByName("Text_11")
        zhekText:setFontSize(14)
    end

    if CHANNEL.Android.CHANNEL_CODE_CN == GAME_CHANNEL then
        ---sdk获取商品信息，获取失败，就弹窗提示
        local goodsStr = SDKManagerLua:getGoodsData()
        if goodsStr =="" then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("商品信息获取失败，请重试"), self, self.returnBack)
        end
    end
    
end

function ShopLayer:refreshBerylNum()
    local bn = user_info["beryl"] or 0
    self.BeryNum:setString(""..bn)
end

function ShopLayer:initBtn( ... )
    -- body

    print("到了这里面了")
    local node      = self.uiLayer:getChildByTag(2)
     --/*星石*/
    self.imgBtnXS   = node:getChildByName("Image_xingshi")

     --/*道具*/
    self.imgBtnDJ   = node:getChildByName("Image_daoju")
     --/*秘密商店*/
    self.imgBtnMM   = node:getChildByName("Image_mimi")
     --/*苍yu*/
    self.imaCY        = node:getChildByName("Image_canyu")
    local  btnRfrsh   = node:getChildByName("Button_rsf")
    local  btnClose   = node:getChildByName("Button_close")
    local  buttonInfo = node:getChildByName("Button_info")
    local panlTouch   = node:getChildByName("Panel_touch")

    local function btnCallBack( sender,eventType)
        -- body
        if eventType == ccui.TouchEventType.ended    then
             print("进入了点击的事件函数")
            if sender:getName()    == "Image_xingshi"then 
                self.Shopindex = 1;
                self:SwitchImage(self.Shopindex)
                self:SendShopTable(self.Shopindex)
                
            elseif sender:getName() == "Image_daoju" then
                self.Shopindex = 2;
                self:SwitchImage(self.Shopindex)
                self:SendShopTable(self.Shopindex)
               
            elseif sender:getName() == "Image_mimi"  then
                self.Shopindex = 3;
                self:SwitchImage(self.Shopindex)
                self:SendShopTable(self.Shopindex)
               
            elseif sender:getName() == "Image_canyu" then
                self.Shopindex = 4;
                self:SwitchImage(self.Shopindex)
                self:SendShopTable(self.Shopindex)
              
            elseif sender:getName() == "Button_rsf"  then
                self:eventRfrshBnt()
            elseif sender:getName() == "Button_info" then
                self:ShowUiInfo()
            elseif sender:getName() == "Button_close" then
                AudioManager:shareDataManager():playMusic("music/ui/banniang/likaishop.mp3", 1,false)
                self:returnBack()
            elseif sender:getName() == "Panel_touch" then

                if self.m_AudoId == nil then
                     self.m_AudoId =  AudioManager:shareDataManager():playMusic("music/ui/banniang/chumobanniang.mp3", 1,false)
                end
                if self.m_AudoId then
                    local id  = AudioManager:shareDataManager():MusicState(self.m_AudoId )
                    if id == -1 then
                        self.m_AudoId = nil;
                        self.m_AudoId =  AudioManager:shareDataManager():playMusic("music/ui/banniang/chumobanniang.mp3", 1,false)
                    end
                end
            end
        end
    end
    btnClose:addTouchEventListener(btnCallBack)
    btnRfrsh:addTouchEventListener(btnCallBack)
    self.imgBtnXS:addTouchEventListener(btnCallBack)
    self.imgBtnDJ:addTouchEventListener(btnCallBack)
    self.imgBtnMM:addTouchEventListener(btnCallBack)
    self.imaCY:addTouchEventListener(btnCallBack)
    buttonInfo:addTouchEventListener(btnCallBack)
    panlTouch:addTouchEventListener(btnCallBack)
    local function function_name( ... )
        -- body
         AudioManager:shareDataManager():playMusic("music/ui/banniang/inshop.mp3", 1,false)
    end 
    local delay = cc.DelayTime:create(0.5)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function_name))
   
    node:runAction(sequence)
   
end

function ShopLayer:checkPic()
    --首次进入 说明 key 统一用类名吧
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."ShopLayer_"..self.Shopindex) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."ShopLayer_"..self.Shopindex, 1)
        self:ShowUiInfo()
    end
    local keys = {RedDotPromptKey.Shop_1, RedDotPromptKey.Shop_2,RedDotPromptKey.Shop_3,RedDotPromptKey.Shop_4}
    --设置小红点状态
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..keys[self.Shopindex]) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..keys[self.Shopindex], 1)
    end
    self:updateRedDotPrompt()
end
-- /*说明按钮的回调函数*/
function ShopLayer:ShowUiInfo( ... )
    local pics = {
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_sd_001.png", --星石
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_sd_002.png", --道具屋
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_sd_003.png", --神秘商店
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_sd_004.png", --苍玉
    }
    local data = {}
    data.pictures = { --一张或者多张
        pics[self.Shopindex]
    }
    SceneManager:toGuidePictureLayer(data)
  

end
---/*根据index 来更换 商店选项的图片状态*/
function ShopLayer:SwitchImage( index ) 
    -- body
    if index == 1 then       --/*星石*/-- 其他还原
        self.imgBtnXS:loadTexture(self.resPath.."sc_b_001_2.png")
        self.imgBtnDJ:loadTexture(self.resPath.."sc_b_002_1.png")
        self.imgBtnMM:loadTexture(self.resPath.."sc_b_003_1.png")
        self.imaCY:loadTexture(self.resPath.."sc_b_004_1.png")
         if self.TestCurBuy ~= -1 or self.TestMaxBuy ~= -1 then
            self.TestNumTable:setVisible(false);
         else
            self.TestNumTable:setVisible(true);
         end
    elseif index == 2 then   --/*道具*/
        self.imgBtnXS:loadTexture(self.resPath.."sc_b_001_1.png")
        self.imgBtnDJ:loadTexture(self.resPath.."sc_b_002_2.png")
        self.imgBtnMM:loadTexture(self.resPath.."sc_b_003_1.png")
        self.imaCY:loadTexture(self.resPath.."sc_b_004_1.png")
        self.TestNumTable:setVisible(false);
    elseif index == 3 then   --/*秘密商店*/
        self.imgBtnXS:loadTexture(self.resPath.."sc_b_001_1.png")
        self.imgBtnDJ:loadTexture(self.resPath.."sc_b_002_1.png")
        self.imgBtnMM:loadTexture(self.resPath.."sc_b_003_2.png")
        self.imaCY:loadTexture(self.resPath.."sc_b_004_1.png")
        if self.TestCurRes ~= -1 or self.TestMaxRes ~= -1 then
            self.TestNumTable:setVisible(false);
         else
            self.TestNumTable:setVisible(true);
         end
    elseif index == 4 then   --/*苍玉*/
        self.imgBtnXS:loadTexture(self.resPath.."sc_b_001_1.png")
        self.imgBtnDJ:loadTexture(self.resPath.."sc_b_002_1.png")
        self.imgBtnMM:loadTexture(self.resPath.."sc_b_003_1.png")
        self.imaCY:loadTexture(self.resPath.."sc_b_004_2.png")
        self.TestNumTable:setVisible(false);
    end
end

---/*物品列表*/
--1金币 2星石 3装备 4英雄 5素材 6可使用道具 7礼包 8碎片 9钥匙 10信仰 11月卡 12勋章 13苍玉 14人民币
function ShopLayer:RefishList( ... )
    -- body
    if self.ShopTabe == nil then
        return
    end
    local iTable   = self.ShopTabe["sells"]
    local len      = #iTable
    local laoutLen = math.ceil(len / 2 )
    if self.onlyBuy then
        self.onlyBuy = false
        --self.TestTable["TableIndex"]
    else
        self.ListView:removeAllChildren()

        print("lenlenlenlen =="..len)
        print("laoutLen laoutLen =="..len)
        for i = 1,laoutLen do
            self.ListView:pushBackDefaultItem()
        end
    end

    for i = 1 , laoutLen do
        local item = self.ListView:getItem(i - 1)
        for m = 1,2 do
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)*2 +m
            --numIndex = num
            if num > len then
                itme_info:setVisible(false)
            else 

                local dtable = {
                    ["type"]      = iTable[num]["type"], 
                    ["id"]        = iTable[num]["id"],
                    ["vip"]       = iTable[num]["need_vip"],
                    ["costType"]  = iTable[num]["cost_type"],
                    ["num"]       = iTable[num]["item_num"],
                    ["costNum"]   = iTable[num]["cost_num"],
                    ["itemId"]    = iTable[num]["item_id"],
                    ["stock_num"] = iTable[num]["stock_num"],
                    ["TableIndex"]= num,
                    ["cold_down_time"] = iTable[num]["cold_down_time"],
                    ["first"]     = iTable[num]["double_recharge"], 
                    ["title"]     = iTable[num]["title"],
                    ["content"]   = iTable[num]["content"],
                    ["extra_num"] = iTable[num]["extra_num"] or 0,
                    ["product_id"]= iTable[num]["product_id"]
                }
                
                --月卡倒计时3天允许再次购买
                if dtable["type"] == 11 and dtable["itemId"] == 1 and dtable["cold_down_time"] ~= nil and g_channel_control.shopLayer_monthCardTime ~= nil then
                    if tonumber(dtable["cold_down_time"] )< tonumber(g_channel_control.shopLayer_monthCardTime) then 
                        dtable["stock_num"] = -1    
                    end
                end    
                -- 道具类型 1金币 2星石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
                local ImageBg  = itme_info:getChildByName("Image_bg")
                 --/*判断库存是否为零  如果是零的情况显示已购买 */
                local imaga     = ImageBg:getChildByName("Image_a")
                
                local imag_5     = ImageBg:getChildByName("Image_5")
                if dtable["stock_num"] == 0 then  
                    imaga:setVisible(true) 

                    imag_5:setVisible(false)

                else
                    imaga:setVisible(false)
                    imag_5:setVisible(true)
                end
                local e_bg     = ImageBg:getChildByName("Image_iconbg")
                local e_fr     = ImageBg:getChildByName("Image_form")
                local e_icon   = ImageBg:getChildByName("Image_icon")
                local itemCostIcon = ImageBg:getChildByName("Image_5")
                local costIcon = self:refCostIcon(self.Shopindex)
                itemCostIcon:loadTexture(costIcon)
                local prop     = {}
                e_icon:setUnifySizeEnabled(true)
                -- if dtable["type"]   == 1 then
                --     dtable["name"]  = "金币"

                --     dtable["dec"]   = "金币"

                --    prop = UITool.getItemInfos(1,1)
                -- elseif dtable["type"] == 2 then
                --     dtable["name"]  = "星石"

                --     dtable["dec"]   = "星石"
                --     prop = UITool.getItemInfos(2,2)
                -- else
                     prop = UITool.getItemInfos(dtable["type"],dtable["itemId"])
                --end
                if self.Shopindex == 2 then
                    local typeGem = ImageBg:getChildByName("Text_number_1_1")
                    typeGem:setVisible(true)
                    if dtable["costType"] and dtable["costType"]   == 17 then
                        typeGem:setString(UITool.ToLocalization("有偿星石"))
                    else
                        typeGem:setString(UITool.ToLocalization("免费星石"))
                    end
                end
                -------------设置显示的各种属性------------
 
                local image5  = ImageBg:getChildByName("Image_5") -- 显示的货币类型
                --print("cost type == "..dtable["costType"])
                image5:setUnifySizeEnabled(true)
                image5:loadTexture(UITool:Coin_type(dtable["costType"]))  
                


                local Name    = ImageBg:getChildByName("Text_Name")
                Name:setString(UITool.getUserLanguage(dtable["title"]))--prop[5]
                local dec     = ImageBg:getChildByName("Text_dec")
                -- 描述如果有倒计时就显示倒计时，没有倒计时就显示描述
                if dtable["cold_down_time"] == 0 or dtable["cold_down_time"] == nil or
                dtable["cold_down_time"] == "" then
                    dec:setString(UITool.getUserLanguage(dtable["content"]))--prop[6]
                else
                   
                  local tableTime = UITool.ShowTime(dtable["cold_down_time"])
                  local strFor = UITool.ToLocalization("剩余%s天 ")--空格要吗？？？
                  dec:setString(string.format(UITool.ToLocalization("剩余%d天%d小时%d分"),tableTime["D"],tableTime["H"],tableTime["M"]))
                end

                 --改变商品node 中的描述字体大小
                if g_channel_control.transform_ShopLayer_Text_dec_fontSize == true then
                    print("transform_ShopLayer_Text_dec_fontSize")
                    dec:setFontSize(18)
                    dec:setPosition(161,33)
                    dec:setContentSize(243,70)
                end

                local number  = ImageBg:getChildByName("Text_number")
                local number1 = ImageBg:getChildByName("Text_number_1")
                print("现在物品的数量 == "..dtable["num"])
                number:setFontSize(24);
                number:enableOutline(cc.c4b(0,0,0,255),2)
                number:setString("x"..dtable["num"])


                number1:setString(UITool.ToLocalization("库存:")..dtable["stock_num"])
                if dtable["stock_num"] == -1 then
                    --number:setVisible(false)
                    number1:setVisible(false)
                end

                -- 判断当前是否是首冲的奖励 只有在购买钻石界面才进行判断
                if self.Shopindex == 1 then
                    if dtable["first"] == 1 then
                        local  towI   = ImageBg:getChildByName("Image_tow")
                        towI:setVisible(true)
                    else
                        local  towI   = ImageBg:getChildByName("Image_tow")
                        towI:setVisible(false)
                    end
                    if dtable["extra_num"] > 0 then
                        --星石购买才显示额外赠送
                        number1:setVisible(false) -- 库存为-1的时候隐藏 但是首冲的时候是显示翻倍的数量 不能为false
                        local number2 = ImageBg:getChildByName("Text_number_1_0")
                        number2:setVisible(true)
                        if g_channel_control.transform_ShopLayer_Text_number_fontSize == true then
                            number2:setFontSize(20)
                        end
                        number2:setString(string.format(UITool.ToLocalization("赠%d星石"),dtable["extra_num"]))
                         
                    else
                        local  towI   = ImageBg:getChildByName("Image_tow")
                        towI:setVisible(false)
                    end
                end

                local  gold   = ImageBg:getChildByName("Text_gold")
                if dtable["stock_num"] == 0 then
                    gold:setString(UITool.ToLocalization("已购买") )
                    gold:setColor(cc.c3b(255,0,0))
                else
                   if self.Shopindex == 1 then
                        dtable["costNum"] = UITool.toCurrencyValue(dtable["costNum"])
                   end
                    gold:setString(dtable["costNum"])
                end
                e_bg:loadTexture(prop[4])
                e_fr:loadTexture(prop[1])
                              --属性球
              if prop[3] ~= "" then 
                print("prop[3] == "..prop[3])
                  local elementImg = cc.Sprite:create(prop[3])
                  elementImg:setAnchorPoint(cc.p(1,1))
                  elementImg:setPosition(e_fr:getContentSize().width,e_fr:getContentSize().height)
                  elementImg:setScale(0.8)
                  e_fr:addChild(elementImg)
              end 
                if self.Shopindex == 1 then
                    --购买宝石商店  根据策划需求显示不同数量的宝石图标  
                    -- 是根据1——6 显示图标的  因当时说100% 不变 (韩国版本只有5档)
                    -- 现在因为加上 月卡 和礼包 不能满足要求需加上判断 来显示图标

                    --由于有偿星石 的类型是 17，所以判断为有偿星石用 UITool:Shop_Gem_Icon() 去获取
                    -- if num <= 6 then

                    if dtable["type"] == 17 then
                        local tab = UITool:Shop_Gem_Icon()
                        local len = #tab 
                        if len < num then 
                            print("ziyuan mingcheng  缺少资源index:"..tostring(num).."，使用默认icon：== "..tab[len])
                            e_icon:loadTexture(tab[len])
                        else 
                            print("ziyuan mingcheng  == "..tab[num])
                            e_icon:loadTexture(tab[num])
                        end 
                    else
                        dump(prop,"prop")
                        e_icon:loadTexture(prop[2])
                    end
                else 
                    e_icon:loadTexture(prop[2])
                end
                local function callBack( sender,eventType )
                    -- body

                    if eventType == ccui.TouchEventType.ended then
                        self:ItemEvent(dtable)
                    end
                end
                ImageBg:addTouchEventListener(callBack)
            end

        end
    end
end
--/*点击商品控件  事件   */
function ShopLayer:ItemEvent( dtable )
    -- body
   -- self.TestTable = nil
    self.TestTable = dtable;
    self.GemBuyItemNum = dtable["TableIndex"]
    local Maxnum = 0; -- 这是算出购买个数需要消耗的货币
    if self.TestTable["costType"] == 1 then
        if self.TestTable ~= nil and self.TestTable["costNum"] > 0 then
            Maxnum = math.floor(user_info["gold"] / self.TestTable["costNum"])
            if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
                Maxnum = self.TestTable["stock_num"]
            end
        end
    elseif self.TestTable["costType"] == 2 then
        if self.TestTable ~= nil and self.TestTable["costNum"] > 0 then
            Maxnum = math.floor(user_info["gem"] / self.TestTable["costNum"])
            if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
                Maxnum = self.TestTable["stock_num"]
            end
        end
    elseif self.TestTable["costType"] ==  10 then
    elseif self.TestTable["costType"] == 13  then
        if self.TestTable ~= nil and self.TestTable["costNum"] > 0 then
            Maxnum = math.floor(user_info["beryl"] / self.TestTable["costNum"])
            if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
                Maxnum = self.TestTable["stock_num"]
            end
        end
    elseif self.TestTable["costType"] == 14 then
    end
    if self.TestTable["type"] == 7 then
            local stada = {}
            stada["gift_tyep"]      = self.TestTable["type"]
            stada["costType"]       = self.TestTable["costType"]
            stada["gift_id"]        = self.TestTable["itemId"]
            stada["oneSelf"]        = self
            stada["cost_num"]       = self.TestTable["costNum"]
            stada["num"]            = self.TestTable["num"]
            stada["stock_num"]      = self.TestTable["stock_num"]
            stada["content"]        = self.TestTable["content"]
            stada["Shopindex"]      = self.Shopindex
            stada["product_id"]     = self.TestTable["product_id"]
            self.sManager:toGiftShowListlayer(stada)
            return
    elseif self.TestTable["type"] == 11 then
            local stada = {}
            stada["gift_tyep"] = self.TestTable["type"]
            stada["costType"]  = self.TestTable["costType"]
            stada["gift_id"]   = self.TestTable["itemId"]
            stada["oneSelf"]   = self
            stada["cost_num"]  = self.TestTable["costNum"]
            stada["num"]       = self.TestTable["num"]
            stada["stock_num"]       = self.TestTable["stock_num"]
            stada["content"]       = self.TestTable["content"]
            stada["Shopindex"]      = self.Shopindex
            self.sManager:toGiftShowListlayer(stada)
            return
    end
    if self.Shopindex == 1 then    -- 注释礼包月卡类似于这样的功能只会出现在商店1，其他商店不会出现
            local curNum = self.TestTable["num"]
        if dtable["extra_num"] > 0 then
            
             curNum = curNum + dtable["extra_num"];
            
        end
        local function test()
            -- body
            dump("wocao")
            self:BuyTwo()
        end 
         print("self.TestTable conType == "..self.TestTable["costType"])
        if self.TestTable["type"] == 3 then
            MsgManager:ShopEquipInfo(self.TestTable["type"],self.TestTable["itemId"],curNum,self.TestTable["costType"],self.TestTable["costNum"],Maxnum,self,test)

        else
            MsgManager:shopBuyItemInfo(self.TestTable["type"],self.TestTable["itemId"],curNum,self.TestTable["costType"],self.TestTable["costNum"],self,test)
        end
    elseif self.Shopindex == 2 then
        --/*购买道具   self.BuyTwo 二次确认*/
        -- /*BuyDaojuTow  是对钻石和金币进行判断的 不会出现其他消耗货币*/
        -- /*已确定 苍玉不足是，客户端不用弹提示框 确认N变
        --1金币 2星石 3装备 4英雄 5素材 6可使用道具 7礼包 8碎片 9钥匙 10信仰 11月卡 12勋章 13苍玉 14人民币
        local function test(n_num)
            -- body
            self:BuyDaojuTow(n_num)
        end
        if self.TestTable["type"] == 3 then
            MsgManager:ShopEquipInfo(self.TestTable["type"],self.TestTable["itemId"],self.TestTable["num"],self.TestTable["costType"],self.TestTable["costNum"],Maxnum,self,test,true)
        else 
            MsgManager:shopBuyItemsInfo(self.TestTable["type"],self.TestTable["itemId"],self.TestTable["num"],self.TestTable["costType"],self.TestTable["costNum"],Maxnum,self,test,true)
        end
    elseif self.Shopindex == 3 then -- 秘密商店
        -- local function test( n_num )
        --     -- body
        --     self:BuyDaojuTow(n_num)
        -- end 
        if self.TestTable["type"] == 3 then
            MsgManager:ShopEquipInfo(self.TestTable["type"],self.TestTable["itemId"],self.TestTable["num"],self.TestTable["costType"],self.TestTable["costNum"],Maxnum,self,self.BuyDaojuTow)
        else
            MsgManager:shopBuyItemInfo(self.TestTable["type"],self.TestTable["itemId"],self.TestTable["num"],self.TestTable["costType"],self.TestTable["costNum"],self,self.BuyDaojuTow)
        end
    elseif self.Shopindex == 4 then -- 苍玉
        local function test( n_num )
            -- body
            self:BuyDaojuTow(n_num)
        end 
        if self.TestTable["type"] == 3 then
            MsgManager:ShopEquipInfo(self.TestTable["type"],self.TestTable["itemId"],self.TestTable["num"],self.TestTable["costType"],self.TestTable["costNum"],Maxnum,self,test)
        else
            MsgManager:shopBuyItemsInfo(self.TestTable["type"],self.TestTable["itemId"],self.TestTable["num"],self.TestTable["costType"],self.TestTable["costNum"],Maxnum,self,test)
        end

    end

end
---/****外界面的回调
function ShopLayer:ShopTypeCall( shopType )
    -- body
    self.Shopindex = shopType;
    self:SwitchImage(self.Shopindex)
    self:SendShopTable(self.Shopindex)
end
---/*购买的二次确认 这个是在秘密商店调用的因为只有秘密商店会有钻石和金币两种消耗道具 */
-- /*函数里边对消耗道具进行判断最后调用 ItemBuy*/
-- /*二次改版  加入苍玉的判断  苍玉购买也走这个接口*/
function ShopLayer:BuyDaojuTow( n_num )
    -- body
    if self.Shopindex == 3 or self.Shopindex == 4 then
        local cost = 0
        if self.TestTable["costType"] == 1 then
            cost = user_info["gold"]
        elseif self.TestTable["costType"] == 2 then
            cost = user_info["gem"]
        elseif self.TestTable["costType"] == 13 then
            cost = user_info["beryl"]
        end
        if cost - self.TestTable["costNum"] >=0 then  -- 购买道具的货币 满足
            self:ItemBuy(n_num)
        else
            local function callBack( ... )
                -- body
                self.Shopindex = 1;
                self:SwitchImage(self.Shopindex)
                self:SendShopTable(self.Shopindex)
            end
            -- 策划需求 不是bug 金币不足不跳转
            local function callBuyGold( ... ) 
                -- body

            end
            if self.TestTable["costType"] == 1 then
                if self.m_AudoIdJB == nil then
                     self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/banniang/huobibuzu.mp3", 1,false)
                end
                if self.m_AudoIdJB then
                    local id  = AudioManager:shareDataManager():MusicState(self.m_AudoIdJB )
                    if id == -1 then
                        self.m_AudoIdJB = nil;
                        self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/banniang/huobibuzu.mp3", 1,false)
                    end
                end
                
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("金币不足"),self,callBuyGold)
            elseif self.TestTable["costType"] == 2 then
                MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("星石不足是否购买"),self,callBack)
            elseif self.TestTable["costType"] == 13 then
                 MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("苍玉不足"),self,callBuyGold)
            end
            --MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("星石不足是否购买"),self,callBack)
        end
    elseif self.Shopindex == 2 then   -- 注释再三确定 其他类型的商店不会出现gem_r  只有道具屋已经确定N变
        local cost = 0
        if self.TestTable["costType"] == 1 then
            cost = user_info["gold"]
        elseif self.TestTable["costType"] == 2 then
            cost = user_info["gem"] + user_info["gem_r"]
        elseif self.TestTable["costType"] == 17 then
            cost = user_info["gem_r"] 
        elseif self.TestTable["costType"] == 13 then
            cost = user_info["beryl"]
        end
        if cost - self.TestTable["costNum"] >=0 then  -- 购买道具的货币 满足
            self:ItemBuy(n_num)
        else
            local function callBack( ... )
                -- body
                self.Shopindex = 1;
                self:SwitchImage(self.Shopindex)
                self:SendShopTable(self.Shopindex)
            end
            -- 策划需求 不是bug 金币不足不跳转
            local function callBuyGold( ... )
                -- body

            end
            if self.TestTable["costType"] == 1 then
                if self.m_AudoIdJB == nil then
                     self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/banniang/huobibuzu.mp3", 1,false)
                end
                if self.m_AudoIdJB then
                    local id  = AudioManager:shareDataManager():MusicState(self.m_AudoIdJB )
                    if id == -1 then
                        self.m_AudoIdJB = nil;
                        self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/banniang/huobibuzu.mp3", 1,false)
                    end
                end
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("金币不足"),self,callBuyGold)
            elseif self.TestTable["costType"] == 2 then
                MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("星石不足是否购买"),self,callBack)
            elseif self.TestTable["costType"] == 17 then
                MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("有偿星石不足是否购买"),self,callBack)
            elseif self.TestTable["costType"] == 13 then
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("苍玉不足"),self,callBuyGold)
            end
            
        end
    end
end
--/*购买需要二次确认的  是需要人民币购买的时候调用的*/
function ShopLayer:BuyTwo( oneSelf )
    local function payCallFunc(state)
        self.sManager:delWaitLayer()   ---对应关闭屏蔽层
        print("现金支付支付回调")
        if state == "SUCCESS" then 
            --真正的支付成功：
            --todo 处理shoplayer的相关逻辑吧，比如关闭只能买一次的
            -- 刷新界面和刷新体力金币货币
            -- self.sManager.menuLayer:RefshTopBar()
            -- self:refreshBerylNum()
            -- self:RefishList()
            -- self:refreshTimeBtn()
            -- dump(SDKPayData,"SDKPayData")
            local event = {
                payMoney        =  SDKPayData.price ,
                efunProductId   =  SDKPayData.product_id 
            }
            SysDot:eventPurchase(event)

            self:SendShopTable(1)

        else 
            print("支付回调"..state)
        end 
    end
    local function test(  )
        if oneSelf then
            oneSelf:Close()
        end
        --self:ItemBuy()
       local product = self.ShopTabe["sells"][self.GemBuyItemNum]
       self.sManager:createWaitLayer()----开启屏蔽层
       SDKManagerLua:buyItem(product,payCallFunc) 
    end 
    local platform = cc.Application:getInstance():getTargetPlatform()
    local currency_type = UITool.ToLocalization("美元")
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     --todo
    -- else
    --     currency_type = UITool.ToLocalization("美元")
    -- end

    MsgManager:showSimpMsgWithCallFunc(string.format(UITool.ToLocalization("是否花费%s%s购买星石"),tostring(self.TestTable["costNum"]),currency_type),self,test)
end
--/*商品购买  1 商店类型   sell 里的id  购买的数量*/
function ShopLayer:ItemBuy(n_num)
    -- body
    local tab = UITool.getItemInfos(self.TestTable["type"],self.TestTable["itemId"])
    if tab[7] >= 5 then
        if self.m_AudoIdBig == nil then
             self.m_AudoIdBig =  AudioManager:shareDataManager():playMusic("music/ui/banniang/goumaibig.mp3", 1,false)
        end
        if self.m_AudoIdBig then
            local id  = AudioManager:shareDataManager():MusicState(self.m_AudoIdBig )
            if id == -1 then
                self.m_AudoIdBig = nil;
                self.m_AudoIdBig =  AudioManager:shareDataManager():playMusic("music/ui/banniang/goumaibig.mp3", 1,false)
            end
        end
        
    else
        if self.m_AudoIdGM == nil then
             self.m_AudoIdGM =  AudioManager:shareDataManager():playMusic("music/ui/banniang/goumai.mp3", 1,false)
        end
        if self.m_AudoIdGM then
            local id  = AudioManager:shareDataManager():MusicState(self.m_AudoIdGM )
            if id == -1 then
                self.m_AudoIdGM = nil;
                self.m_AudoIdGM =  AudioManager:shareDataManager():playMusic("music/ui/banniang/goumai.mp3", 1,false)
            end
        end
        
    end
    if n_num then
        
    else
        n_num = self.TestTable["num"]
    end
    
    local function reiceSthCallBack(data)
        print("商店购买列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
           
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            if (self.Shopindex == 1) then
                self:addLabel("商品购买失败")
            end
           MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end   
        if t_data["data"]["state_code"]  == 1 then
            if self.TestTable["costType"] == 1 then -- 金币
            elseif self.TestTable["costType"] == 2 then -- 钻石
            elseif self.TestTable["costType"] == 13 then -- 藏于
            end
            print("消息进入了这里")
            user_info["gold"] = t_data["data"]["resource"]["gold"]
            user_info["gem"] = t_data["data"]["resource"]["gem"]
            user_info["gem_r"] = t_data["data"]["resource"]["gem_r"]

            user_info["beryl"] = t_data["data"]["resource"]["beryl"]
            if self.sManager ~= nil and self.sManager.menuLayer ~= nil then
                self.sManager.menuLayer:RefshTopBar()
            end
            self:refreshBerylNum()
            self.ShopTabe["sells"][self.TestTable["TableIndex"]] = t_data["data"]["refresh_item"]
            self.onlyBuy = true
            self:RefishList()
            self:refreshTimeBtn()
            self:addLabel(UITool.ToLocalization("商品购买成功"))
            
            --self.TestTable = nil
            if self.Shopindex == 1 then
                if self.TestCurBuy ~= -1 and self.TestMaxBuy ~= -1 then
                    if  self.TestCurBuy  < self.TestMaxBuy then
                        self.TestCurBuy = self.TestCurBuy + 1
                        self:addLabel(UITool.ToLocalization("商品购买成功"))
                    else
                        self.TestCurBuy = self.TestMaxBuy
                    end
                    self.TestNumTable:setString(UITool.ToLocalization("今日已购买次数")..self.TestCurBuy.."/"..self.TestMaxBuy)
                end
            end

        end
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "store_buy",
        ["shop_type"] = self.Shopindex,
        ["sell_id"]   = self.TestTable["id"],
        ["buy_num"]   = n_num,

    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励列表 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--/*每种商店的金币图标*/
function ShopLayer:refCostIcon( index )
    -- body
    --/*星石*/
    if index == 1 then
      return   Coin_Icon[7]
    elseif index  == 2 then --/*道具*/
      return  Coin_Icon[2]
    elseif index  == 3 then --/*秘密*/
      return Coin_Icon[1]
    elseif index  == 4 then --/*苍玉*/
      return  Coin_Icon[8]
    end
end
-- 根基Id从小到大排序
function ShopLayer:sortMinMaX( ... )
    -- -- body
    --     for i = 1 , #self.ShopTabe["sells"] do
    --    table.sort(self.ShopTabe["sells"] , function(a , b)
    --          return a["item_id"] <  b["item_id"] 
           
    --     end)
    -- end  -- 从小到大排序
end
--/*按钮的时间刷新*/
function ShopLayer:refreshTimeBtn( ... )
    print("进入了刷新按钮")
    -- body
    local node       = self.uiLayer:getChildByTag(2)
    local btn        = node:getChildByName("Button_rsf")
    local Gold       = btn:getChildByName("Text_gold")
    local minfei     = btn:getChildByName("Text_text_0")
    local zhekou     = node:getChildByName("Image_zhekuo")
    --local zhekText   = zhekou:getChildByName("Text_11")
    --bug modify
    local zhekText   = zhekou:getChildByName("Text_26")
    local GoldIcon   = btn:getChildByName("Image_12")
    local Tiembg     = node:getChildByName("Image_time_bg")

    --/*货币类型*/
    local GoldType   = nil;
    local costNumber = nil;

    
   
    if self.ShopTabe["refresh"]["refresh_cost"] then
        GoldType   = self.ShopTabe["refresh"]["refresh_cost"]["cost_type"]
        costNumber = self.ShopTabe["refresh"]["refresh_cost"]["cost_num"]
        zhekou:setVisible(true)
        btn:setVisible(true)
        Tiembg:setVisible(true)
    else  --/*不显示倒计时和按钮*/
        zhekou:setVisible(false)
        btn:setVisible(false)
        Tiembg:setVisible(false)
    end

    --/*获取显示时间的控件*/
    local  tiemBg = node:getChildByName("Image_time_bg")
    local  time   = tiemBg:getChildByName("Text_time")
    local function localMianfei( ... )
        -- body

        self:eventRfrshBnt()
       
    end
    if (self.ShopTabe["refresh"]["refresh_time"] ~= 0 and self.ShopTabe["refresh"]["refresh_cost"]) then
       
        if self.isDownTiem == false then
            UITool:schedule(tiemBg,1,self.ShopTabe["refresh"]["refresh_time"],time,localMianfei)
            self.isDownTiem = true
        end
    end
    --/*是否显示免费  或是金币   根据类型更换货币图标*/
    if self.ShopTabe["refresh"]["refresh_time"] == 0 then
        Gold:setVisible(false)
        minfei:setVisible(true)
        GoldIcon:setVisible(false)
        time:setString("_:_:_")
    else
        minfei:setVisible(false)
        Gold:setVisible(true)
        GoldIcon:setVisible(true)
        Gold:setString(costNumber)
    end

    --/*根据条件显示折扣信息*/
    -- /*暂时没有折扣功能 改了下jie*/
    if self.ShopTabe["refresh"]["refresh_time"] ~= 0 and self.ShopTabe["refresh"]["discount"] then
        if self.ShopTabe["refresh"]["discount"]["dst_msg"]  then  
            if self.ShopTabe["refresh"]["discount"]["dst_msg"] == "" then
                local text = zhekText:getString()
                zhekou:setVisible(false)  
            else
                print("zheText == "..self.ShopTabe["refresh"]["discount"]["dst_msg"])
                if zhekText then
                    zhekText:setString(self.ShopTabe["refresh"]["discount"]["dst_msg"])
                    zhekou:setVisible(true)  
                end

            end
        else
            zhekou:setVisible(false)
        end
    else
       
        print("刷新的条件不成了")
        zhekou:setVisible(false)
    end
end
--/*初始化List模板*/
function ShopLayer:initMode( ... )
    -- body
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("ShopItemNode.csb")
    local  item_1 = list_item:getChildByName("Panel_1")

    for i=1,2 do
        local item_c = item_1:clone()
        item_c:setPosition((i-1)*(412+7),0)
        local touchItem = ccui.Helper:seekWidgetByName(item_c,"Image_1")
        item_c:setName("item"..i)
        layout_list:addChild(item_c)
    end
    layout_list:setContentSize(858,164)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)
end
--/*从服务器拉取商店物品*/
function ShopLayer:SendShopTable( index )
    -- MsgManager:showSimpMsg("SendShopTable")
    self:checkPic()
    -- body
    local function reiceSthCallBack(data)

        print("获取登陆奖励列表")
        if data == nil then
             MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            
        end
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end   
        if t_data["data"]["state_code"]  == 1 then
            if self.ShopTabe then
                self.ShopTabe = nil
                self.ShopTabe = {}
            end
        
            self.ShopTabe = t_data["data"]["shop"]
            self:sortMinMaX()
            self:RefishList()
            self:refreshTimeBtn()

        end
        if index == 1 then
            if self.TestCurBuy ~= -1 and self.TestMaxBuy ~= -1 then
                print("store_info 购买次数限制 进入 1== ")
                self.TestCurBuy = t_data["data"]["buy_num"];
                self.TestMaxBuy = t_data["data"]["buy_max"]
                self.TestNumTable:setString(UITool.ToLocalization("今日已购买次数")..t_data["data"]["buy_num"].."/"..t_data["data"]["buy_max"]);--buy_max  buy_num  refresh_max  refresh_num
            else
                print("store_info 购买次数限制 进入 2== ")
                self.TestNumTable:setVisible(false)
            end
        elseif index == 3 then
            if self.TestCurRes ~= 1 and self.TestMaxRes ~= 1 then
                self.TestCurRes = t_data["data"]["refresh_num"]
                self.TestMaxRes = t_data["data"]["refresh_max"]
                self.TestNumTable:setString(UITool.ToLocalization("今日已刷新次数")..t_data["data"]["refresh_num"].."/"..t_data["data"]["refresh_max"]);
            else
                self.TestNumTable:setVisible(false);
            end
        else
            self.TestNumTable:setVisible(false);
        end
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "store_info",
        ["shop_type"] = index,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励列表 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

-- /*提示信息*/
function ShopLayer:addLabel(str)
  
    local label = cc.Label:createWithTTF(str, TEXT_FONT_NAME, 40)
    label:setPosition(cc.p(640,360))
    self.uiLayer:addChild(label, 1)
    local function removeThis()
       label:removeFromParent()
    end
    --After 1.5 second, self will be removed.
    local moveBy  = cc.MoveBy:create(1.5,cc.p(0,150))
    local fadeOut = cc.FadeOut:create(1.5)
    local spawn = cc.Spawn:create(moveBy,fadeOut)
    label:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(removeThis)))

end 
--/*点击刷新按钮的回调*/
function ShopLayer:eventRfrshBnt( sender,eventType )
    -- body
    local function reiceSthCallBack(data)
        print("刷新商店")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end   
        if t_data["data"]["state_code"]  == 1 then
            if self.ShopTabe then
                self.ShopTabe = nil
                self.ShopTabe = {}
            end
        if self.TestCurRes ~= -1 and self.TestMaxRes ~= -1 and self.TestCurRes ~= nil and self.TestMaxRes ~= nill then
          if  t_data["data"]["update"]["refresh"]["refresh_time"] ~= 0 and t_data["data"]["update"]["refresh"]["refresh_cost"] then
            if self.TestCurRes < self.TestMaxRes then
                self.TestCurRes = self.TestCurRes + 1
            else
                self.TestCurRes = self.TestMaxRes
            end
            self.TestNumTable:setString(UITool.ToLocalization("今日已刷新次数")..self.TestCurRes.."/"..self.TestMaxRes);
          end
        end
            
            
            print("消息进入了这里")
            self.ShopTabe = t_data["data"]["update"]
            user_info["gold"] = t_data["data"]["gold"]
            user_info["gem"] = t_data["data"]["gem"]
            user_info["gem_r"] = t_data["data"]["gem_r"]
            user_info["beryl"] = t_data["data"]["beryl"]
            if self.sManager ~= nil and self.sManager.menuLayer ~= nil then
                self.sManager.menuLayer:RefshTopBar()
            end
            self:refreshBerylNum()
            self:RefishList()
            self:refreshTimeBtn()

        end

    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "store_refresh",
        ["shop_type"] = self.Shopindex,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励列表 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function ShopLayer:returnBack( ... )
	self.ShopTabe  = nil
	self.ListView  = nil;
	self.resPath   = "res/uifile/n_UIShare/shop/"
	self.imgBtnDJ  = nil
	self.imgBtnMM  = nil
	self.imaCY     = nil
	self.imgBtnXS  = nil
	self.Shopindex = 3;
	self.TestTable = nil   
	self.isDownTiem = false
	self.TestNumTable  = nil;
	self.TestCurBuy = nil;
	self.TestMaxBuy = nil;
	self.TestCurRes = nil;
	self.TestMaxRes = nil;
	self.GemBuyItemNum = nil;
	self.onlyBuy = false
	self.m_AudoId  = nil;

    if self.uiLayer~=nil then
        self.uiLayer:removeFromParent()
        self.uiLayer = nil
    end
    self.TestNumTable = nil 
    self.imgBtnDJ = nil
    self.imgBtnMM= nil
    self.imaCY = nil
    self.ListView = nil
    self.sManager:removeFromNavNodes(self)
    self.sManager._shopLayer = nil
    if self.backFunc then 
        self.backFunc(self.sDelegate)
    end
    self.exist = false
    self:clearEx()
end

function ShopLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ShopLayer:create(rData)

     local login = ShopLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()

     return login

end

--设置按钮等级解锁状态
function ShopLayer:setNodeLockState()

    if g_channel_control.UIVersion < 2 then
        local curNodes = {self.imgBtnDJ, self.imgBtnMM, self.imaCY}
        for i=1,#curNodes do
            local config = guide_rank_config["ShopLayer"][i]
            local btn = curNodes[i]
            if config.unlock_level > tonumber(user_info["rank"]) then 
                if config.state == 0 then 
                    btn:setVisible(false)
                end 
            end 
        end

    else
        UnlockSys:getInstance():bindLock(29, self.imgBtnXS, true)   
        UnlockSys:getInstance():bindLock(30, self.imgBtnDJ, true)
        UnlockSys:getInstance():bindLock(31, self.imgBtnMM, true)
        UnlockSys:getInstance():bindLock(32, self.imaCY, true)

    end
   

   
end

--设置按钮等级解锁状态
function ShopLayer:updateRedDotPrompt()
    local btns = {self.imgBtnXS,self.imgBtnDJ, self.imgBtnMM ,self.imaCY}
    local keys = {RedDotPromptKey.Shop_1, RedDotPromptKey.Shop_2,RedDotPromptKey.Shop_3,RedDotPromptKey.Shop_4}
    for i=1,#btns do 
        local btn = btns[i]
        UITool.setCommmonBtnRedDop(btn,false)
        if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..keys[i]) == 0 
            and UnlockSys:getInstance():checkUnlock(31) then 
            UITool.setCommmonBtnRedDop(btn,true,cc.p(146,70))
        end  
    end 
end
