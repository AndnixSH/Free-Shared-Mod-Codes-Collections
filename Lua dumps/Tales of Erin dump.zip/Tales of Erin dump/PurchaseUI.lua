-- PuchaseUI 空UI，弹出购买页
-- 处理购买逻辑
-- 后续优化，添加切换购买方式功能
-- 
require "BasicLayer"
PurchaseUI = class("PurchaseUI", BasicLayer)

--[[
	两种方式购买
	1，根据id和type调用购买，可能有多种购买方式，默认不允许切换购买方式（取第一个）
	local purchase_data1 = {
		callFunc = purchaseBack,				--购买返回
		item_id = 5, 							--根据id和type选择购买方式，可能有多重
		item_type = 1100,
		multi_buy_purchase = true 				--是否可以切换购买方式

	}
	2,根据唯一ID调用购买
	local purchase_data2 = {
		callFunc = purchaseBack,				--购买返回
		fast_trade_id = 1 						--购买唯一ID
	}

]]--
function PurchaseUI:create(data)
     local purchase = PurchaseUI.new()
     purchase.uiLayer = cc.Layer:create() 
     purchase:init(data)
     return purchase
end

function PurchaseUI:init( data )

	self:initUI()


	self.fast_trade_id 	= data["fast_trade_id"] 					--交易ID
	self.callFunc 		= data["callFunc"]

	self.fast_trade_item_id = data["item_id"] 						--物品id
	self.fast_trade_item_type = data["item_type"] 					--物品type
	self.trade_id_list = nil  						 				--多种购买方式
	self.multi_buy_purchase = data["multi_buy_purchase"] or false 	--是否允许切换


	if self.fast_trade_id == nil and self.fast_trade_item_id ~= nil and self.fast_trade_item_type ~= nil then

		self.trade_id_list = table.getValue("quick_shop",quick_shop,self.fast_trade_item_type,self.fast_trade_item_id)

		self.fast_trade_id = self:getFastTradeId(1)
	end

	if self.multi_buy_purchase == true and self.trade_id_list ~= nil then
		self:displayToggleButton()
	end

	if self.fast_trade_id ~= nil  then
		self.fast_trade_table = nil 
		self:reqFastTradeInfo(self.fast_trade_id)	
	else
		LogManager.showSimpMsgDebug("self.fast_trade_id === nil")
		self:returnBack()
	end

end

function PurchaseUI:initUI(  )
	local layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0,0))
    layout:setPosition(0,0)
    layout:setContentSize(1280,720)
    -- layout:setBackGroundColor(cc.c3b(255,255,255))
    layout:setBackGroundColorType(LAYOUT_COLOR_NONE)
    layout:setTouchEnabled(true)
    self.uiLayer:addChild(layout)

end

function PurchaseUI:displayToggleButton(  ) --显示 购买类型 切换button
	local len = #self.trade_id_list --购买类型数量
	for i=1,len do
		local trade_table = self.trade_id_list[i]
		local cost_type = trade_table["cost_type"]
		local cost_id = trade_table["cost_id"]

		local item_data = UITool.getItemInfos(cost_type,cost_id)
		dump("item_data",item_data)
	end

end

function PurchaseUI:returnBack(  )
	self:clear()
end

function PurchaseUI:getFastTradeId( index )
	--[[ self.trade_id_list =
	[{
        goods_type = 1,
        goods_id = 0,
        cost_type = 2,
        cost_id = 0,
        trade_id = 3
    },{}...
    ]
    ]]--
    local trade_id = nil 
	if self.trade_id_list ~= nil and #self.trade_id_list >= index then 
		trade_id = table.getValue("self.trade_id_list",self.trade_id_list,index,"trade_id")
	end 
	return trade_id 

end

--[[
{"data": 
    {
        "state_code": 1, 
        "fast_trade_info" : { 
            "cost_type" : 10, # 消耗品类型
            "cost_id" : 10, # 消耗品ID
            "cost_have" : 10, # 当前拥有数量
            "goods_type" : 1,# 目标商品类型
            "goods_id" : 1,# 目标商品类型
            "goods_num":1,# 目标商品一次给几个
            "goods_have" 1: ,# 目标商品当前数量
            # "goods_max" 1: ,# 目标商品数量限制
            "count" : 10, # 已购买次数
            "count_max" : 10, # 购买次数上限 / 库存
            "refresh_type" : 1, # 刷新方式
            "price" : 10, # 默认价格
            "stage_price" : [ # 价格阶梯
                20,
                30,
                40
            ] 
        }
    }
}
]]-- 
function PurchaseUI:reqFastTradeInfo( trade_id )
	  local function reiceSthCallBack(data)
        print("purchase购买")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        SceneManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            self:returnBack()

            return
        end

        self.fast_trade_table = t_data["data"]["fast_trade_info"]
        self:showPurchaseLayer(self.fast_trade_table)
    end

    local cjson = require "cjson"
    SceneManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "fast_trade_info",
        ["fast_trade_id"]   = trade_id,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function PurchaseUI:getStagePrice( current_purchase_num,periodic_price_list )
	dump(periodic_price_list, "periodic_price_list")
	print("......"..type(periodic_price_list))
	if type(periodic_price_list) == "table"  then
		local len = #periodic_price_list
		if len < current_purchase_num then 
			current_purchase_num = len 
		end 

		if current_purchase_num == 0 then 
			current_purchase_num = 1
		end 
		local price = table.getValue("periodic_price_list",periodic_price_list,current_purchase_num)
		print("PurchaseUI:getStagePrice:purNum:"..tostring(current_purchase_num).."...price:"..tostring(price))
		return price
	end

	return nil 
end
--[[
--道具购买，
"fast_trade_info" : { 
            "cost_type" : 10, # 消耗品类型
            "cost_id" : 10, # 消耗品ID
            "cost_have" : 10, # 当前拥有数量

            "goods_type" : 1,# 目标商品类型
            "goods_id" : 1,# 目标商品id
            "goods_num":1,# 目标商品一次给几个
            "goods_have" 1: ,# 目标商品当前数量

            # "goods_max" 1: ,# 目标商品数量限制
            "count" : 10, # 已购买次数
            "count_max" : 10, # 购买次数上限 / 库存
            "refresh_type" : 1, # 刷新方式
            "price" : 10, # 默认价格
            "stage_price" : [ # 价格阶梯
                20,
                30,
                40
            ] 
        }
]]--
function PurchaseUI:showPurchaseLayer( data )
  	local item_type = data["goods_type"]
  	local item_id 	= data["goods_id"]

  	if item_type == 3 then 
  		self:showBuyEquipInfo(data)
  	else
  		self:showBuyItemInfo(data)
  	end
end

function PurchaseUI:showBuyEquipInfo( data )
	local item_type = data["goods_type"] or 0
  	local item_id 	= data["goods_id"] or 0
  	local item_num  = data["goods_num"] or 0
  	local cost_type = data["cost_type"] or 0
  	local cost_total= data["cost_have"] or 0

  	local buy_next_ebled = false --是否可以继续购买
  	local buy_count_current = data["count"] or 0--已购买次数 
  	local count_max = data["count_max"] or 0 --可购买上限

  	local periodic_price_list = data["stage_price"] --阶段性价格
  	local price_current = self:getStagePrice(buy_count_current+1,periodic_price_list) or data["price"]
  	local price_next = self:getStagePrice(buy_count_current+2,periodic_price_list) or data["price"]
  	if (count_max == 0 or count_max >= 1 + buy_count_current ) and cost_total >= price_current + price_next then 
  		buy_next_ebled = true
  	end 

  	local cost_num = price_current
  	print("price_current:"..tostring(price_current).."....price_next:"..tostring(price_next).."....cost_total:"..tostring(cost_total))

	local item_data = UITool.getItemInfos(item_type,item_id)

	if item_data == nil then
		LogManager.showSimpMsgDebug("error,itemType:"..tostring(item_type).."..item_id:"..tostring(item_id),"PurchaseUI:showBuyEquipInfo")
	end
  	local node = nil
    node = cc.CSLoader:createNode("MsgBoxNode_13.csb")
    local item_rarity_bg = node:getChildByName("Image_icon_bg")--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByName("Image_icon_form")--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
    local item_img = node:getChildByName("Image_icon")--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])

    local skillName = node:getChildByName("Text_skill_name_1")
    skillName:setString(item_data[9])
    local skillDec  = node:getChildByName("Text_dec_1")
    local des = string.gsub(item_data[10],"*","")
    skillDec:setString(des)

    local skillName_2 = node:getChildByName("Text_skill_name_2")
    local skillDec_2 = node:getChildByName("Text_dec_2")
    if item_data[11] == 0 then
      skillName:setAnchorPoint(0.5,0.5)
      skillName:setPosition(0,30)
      skillDec:setAnchorPoint(0.5,0.5)
      skillDec:setPosition(0,-30)
      skillName_2:setVisible(false)
      skillDec_2:setVisible(false)
    else
      skillName:setAnchorPoint(0,0.5)
      skillName:setPosition(-250,30)
      skillDec:setAnchorPoint(0,0.5)
      skillDec:setPosition(-80,30)
      skillName_2:setVisible(true)
      skillDec_2:setVisible(true)
      skillName_2:setString(UITool.getUserLanguage(table.getValue("passive_sk",passive_sk,item_data[12],"sk_name"))) --passive_sk[item_data[12]]["sk_name"])
      skillDec_2:setString(UITool.getUserLanguage(table.getValue("passive_sk",passive_sk,item_data[12],"sk_des")))--passive_sk[item_data[12]]["sk_des"])
    end

    local name_text = node:getChildByName("Text_name")--名称
    name_text:setString(item_data[5].."X"..item_num)
    if g_channel_control.transform_MsgManager_char_x == true then
      name_text:setString(item_data[5].."x"..item_num)
    end
    -- local des_text = node:getChildByName("Text_dec")--描述
    --  local des = string.gsub(item_data[6],"*","")
    -- des_text:setString(des)

    local property_node = node:getChildByName("Image_property")

    local hp_text = property_node:getChildByName("Text_hp")--最大hp
    hp_text:setString(item_data[8])
    local atk_text = property_node:getChildByName("Text_attck")--最大atk
    atk_text:setString(item_data[7])

    local cost_icon = node:getChildByName("Image_gem")--消耗类型icon
    cost_icon:setUnifySizeEnabled(true)
    cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

  local cost_text = node:getChildByName("Text_number")--消耗的数量
  cost_text:setString(cost_num)
    
    local buy_num_text = property_node:getChildByName("Text_tex_0")--购买的数量
    buy_num_text:setString(1)

    function touchCallBack(sender,eventType)
       if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Button_add" then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum +1
               buy_num_text:setString(nowNum)

               local nowCost = cost_text:getString()
               local price_current = self:getStagePrice(buy_count_current+nowNum,periodic_price_list) or data["price"]
               local price_next = self:getStagePrice(buy_count_current+nowNum+1,periodic_price_list) or data["price"]
               local nextCost = nowCost + price_current 
               cost_text:setString(nextCost)
               if (count_max ~= 0 and count_max <= nowNum + buy_count_current ) or cost_total < price_next + nextCost then
               	  sender:setTouchEnabled(false)
                  sender:setBright(false)
                  buy_next_ebled = false
               end   

               if nowNum > 1 then
                  local btn_bg = node:getChildByName("Image_numBg")
                  local delBtn = btn_bg:getChildByName("Button_Subtract")   
                  delBtn:setTouchEnabled(true)
                  delBtn:setBright(true)
               end
            elseif sender:getName() == "Button_Subtract" then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum - 1
               buy_num_text:setString(nowNum)

               local nowCost = cost_text:getString()
               price_current = self:getStagePrice(buy_count_current+nowNum+1,periodic_price_list) or data["price"]

               local lastCost = nowCost - price_current 
               cost_text:setString(lastCost)

               if nowNum < 2 then
                  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end  
               print("now"..nowNum) 
               if  nowCost  <= cost_total then
                  local btn_bg = node:getChildByName("Image_numBg")
                  local addBtn = btn_bg:getChildByName("Button_add")   
                  addBtn:setTouchEnabled(true)
                  addBtn:setBright(true)
               end

         end
       end
    end

    local btn_bg = node:getChildByName("Image_numBg")
    local addBtn = btn_bg:getChildByName("Button_add")--加号
    addBtn:addTouchEventListener(touchCallBack)
    local delBtn = btn_bg:getChildByName("Button_Subtract")--减号
    delBtn:addTouchEventListener(touchCallBack)
  
    delBtn:setTouchEnabled(false)
    delBtn:setBright(false)
    if buy_next_ebled ~= true then
       addBtn:setTouchEnabled(false)
       addBtn:setBright(false)
    end

    function buyItemCallBack()
        print("点击购买按钮回调")
   	    self:BuyDaojuTow(tonumber(buy_num_text:getString()),tonumber(cost_text:getString()))

    end

  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 3
  pop["titleName"]  = UITool.ToLocalization("物品信息")
  pop["OKBtnName"]  = UITool.ToLocalization("购买")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = buyItemCallBack
  SceneManager:showMsgMode(pop)
end

function PurchaseUI:showBuyItemInfo( data )
	local item_type = data["goods_type"]
  	local item_id 	= data["goods_id"]
  	local item_num  = data["goods_num"]
  	local cost_type = data["cost_type"]
  	local cost_total= data["cost_have"]

  	local buy_next_ebled = false --是否可以继续购买
  	local buy_count_current = data["count"] or 0--已购买次数 
  	local count_max = data["count_max"] or 0 --可购买上限

  	local periodic_price_list = data["stage_price"] --阶段性价格
  	local price_current = self:getStagePrice(buy_count_current+1,periodic_price_list) or data["price"]
  	local price_next = self:getStagePrice(buy_count_current+2,periodic_price_list) or data["price"]
  	if (count_max == 0 or count_max >= 1 + buy_count_current ) and cost_total >= price_current + price_next then 
  		print("count_max:"..tostring(count_max).."...buy_count_current:"..tostring(buy_count_current))
  		buy_next_ebled = true
  	end 
  	print("showBuyItemInfo:price_current:"..tostring(price_current).."....price_next:"..tostring(price_next).."....cost_total:"..tostring(cost_total))

  	local cost_num = price_current

	local item_data = UITool.getItemInfos(item_type,item_id)
	if item_data == nil then
		LogManager.showSimpMsgDebug("error,itemType:"..tostring(item_type).."..item_id:"..tostring(item_id),"PurchaseUI:showBuyItemInfo")
	end
	local node = nil
    node = cc.CSLoader:createNode("MsgBoxNode_7.csb")
    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
    --属性球
	if item_data[3] ~= "" then 
		local elementImg = cc.Sprite:create(item_data[3])
		elementImg:setAnchorPoint(cc.p(0.5,0.5))
		--elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
		elementImg:setPosition(134.5,113)
		elementImg:setScale(0.6)
		item_rarity_icon:addChild(elementImg)
	end  
    local item_img = node:getChildByTag(92)--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])
    
    local name_text = node:getChildByTag(93)--名称
    name_text:setString(item_data[5].."X"..item_num)

    local des_text = node:getChildByTag(94)--描述
     local des = string.gsub(item_data[6],"*","")
    des_text:setString(des)

    local cost_icon = node:getChildByTag(274)--消耗类型icon
    cost_icon:setUnifySizeEnabled(true)
    cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

	local cost_text = cost_icon:getChildByTag(238)--消耗的数量
	cost_text:setString(cost_num)
    
    local buy_num_text = node:getChildByTag(243)--购买的数量
    buy_num_text:setString(1)

    function touchCallBack(sender,eventType)
    	 if eventType == ccui.TouchEventType.ended then
            if sender:getTag() == 242 then  --+++++++
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum +1
               buy_num_text:setString(nowNum)

               local nowCost = tonumber(cost_text:getString())
               local price_current = self:getStagePrice(buy_count_current+nowNum,periodic_price_list) or data["price"]
               local price_next = self:getStagePrice(buy_count_current+nowNum+1,periodic_price_list) or data["price"]
               local nextCost = nowCost + price_current 
               cost_text:setString(tostring(nextCost))

               if (count_max ~= 0 and count_max <= nowNum + buy_count_current) or cost_total < price_next + nextCost then
               	  sender:setTouchEnabled(false)
                  sender:setBright(false)
                  buy_next_ebled = false
               end   
               if nowNum > 1 then
               	  local btn_bg = node:getChildByTag(239)
                  local delBtn = btn_bg:getChildByTag(241)   
				  delBtn:setTouchEnabled(true)
				  delBtn:setBright(true)
               end
            elseif sender:getTag() == 241 then -- ----
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum - 1
               buy_num_text:setString(tostring(nowNum))

               local nowCost = tonumber(cost_text:getString())
               price_current = self:getStagePrice(buy_count_current+nowNum+1,periodic_price_list) or data["price"]

               local lastCost = nowCost - price_current 
               cost_text:setString(tostring(lastCost))

               if nowNum < 2 then
               	  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end  
               print("now"..nowNum.."---max") 
               if  nowCost <= cost_total  then
               	  local btn_bg = node:getChildByTag(239)
                  local addBtn = btn_bg:getChildByTag(242)   
				  addBtn:setTouchEnabled(true)
				  addBtn:setBright(true)
               end

			end
	     end
    end
    
    local btn_bg = node:getChildByTag(239)
    local addBtn = btn_bg:getChildByTag(242)--加号
    addBtn:addTouchEventListener(touchCallBack)
    local delBtn = btn_bg:getChildByTag(241)--减号
    delBtn:addTouchEventListener(touchCallBack)

    delBtn:setTouchEnabled(false)
    delBtn:setBright(false)
    if buy_next_ebled ~= true then
       addBtn:setTouchEnabled(false)
       addBtn:setBright(false)
    end

    function buyItemCallBack()
   	    print("点击购买按钮回调")
   	    self:BuyDaojuTow(tonumber(buy_num_text:getString()),tonumber(cost_text:getString()))

    end
    function buyItemCancel(  )
    	self:returnBack()
    end
	local pop = {}
	pop["buttonType"] = 2
	pop["formType"]   = 3
	pop["titleName"]  = UITool.ToLocalization("物品信息")
	pop["OKBtnName"]  = UITool.ToLocalization("购买")
	pop["nodeCsb"]    = node
	pop["oneself"]    = self
  	pop["callFunc"]   = buyItemCallBack
  	pop["cancelFunc"] = buyItemCancel
	SceneManager:showMsgMode(pop)

end

function PurchaseUI:BuyDaojuTow(n_num ,n_cost)
    -- body
        print("PurchaseUI BuyDaojuTow == "..n_num)
        local cost = self.fast_trade_table["cost_have"]
		if self.fast_trade_table["cost_type"] == 2 then
            cost = user_info["gem"] + user_info["gem_r"]
        end
        
        print("PurchaseUI cost == "..tostring(cost))
        print("PurchaseUI cost_type == "..tostring(self.fast_trade_table["cost_type"]))
        print("PurchaseUI cost_num == "..tostring(self.fast_trade_table["price"]))
        if cost - n_cost >=0 then  -- 购买道具的货币 满足
            self:ItemBuy(n_num,n_cost)
        else
            local strDec = ""

            local callfunc = function (  )
            	self:returnBack()
            end
            local function callBuyGem( ... )
        	    if GameManagerInst.gameType == 2 then
                    local  sData = { shopTypeIndex = 1}
                    SceneManager:toShopLayer(sData) 
                    self:returnBack()
                end
            end 
            if self.fast_trade_table["cost_type"] == 1 then
                if self.m_AudoIdJB == nil then
                     self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/huobibuzu.mp3", 1,false)
                end
                if self.m_AudoIdJB then
                    local id  = AudioManager:shareDataManager():MusicState(self.m_AudoIdJB )
                    if id == -1 then
                        self.m_AudoIdJB = nil;
                        self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/huobibuzu.mp3", 1,false)
                    end
                end

               strDec = "金币不足"
            elseif self.fast_trade_table["cost_type"] == 2 then
                strDec = "星石不足是否购买"
                callfunc = callBuyGem
            elseif self.fast_trade_table["cost_type"] == 17 then
                strDec = "有偿星石不足是否购买"
                callfunc = callBuyGem
            elseif self.fast_trade_table["cost_type"] == 13 then
                strDec = "苍玉不足"
            elseif self.fast_trade_table["cost_type"] == 901 then
                strDec = "奖章不足"
            elseif self.fast_trade_table["cost_type"] == 413 then
                strDec = "古代回路不足"
            elseif self.fast_trade_table["cost_type"] == 20 then
                 strDec = "王召之徽不足"
            elseif self.fast_trade_table["cost_type"] == 1500 then
                strDec = "公会币不足"
            else
            	strDec = "货币类型未知："..tostring(self.fast_trade_table["cost_type"])
            end
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization(strDec),self,callfunc)
        end
end

function PurchaseUI:ItemBuy(n_num)
	local function purchaseCallback( data )
		if self.callFunc then
    		self.callFunc(data.data)
    	end
      SDKManagerLua:refreshUserCoin(nil)
    	self:returnBack()
	end
  
	purchase:ItemBuy(purchaseCallback,self.fast_trade_id,n_num)
end


--[[
	测试代码
]]--
function PurchaseUI:test(  )

	local function purchaseBack( data )
		print("buy ---callback")
		dump(data, "data")
		local goods_have = table.getValue("data",data,"fast_trade_info","goods_have")
		LogManager.showSimpMsgDebug("当前拥有数量："..tostring(goods_have),"PurchaseUI:test")
	end

	local purchase_data = {

		callFunc = purchaseBack,				--购买返回
		fast_trade_id = 1 						--购买唯一ID


	}

	-- 客户端可以直接用fast_trade_id，也可以传入item_id和item_type从客户端取值
	local purchase_data2 = {
		callFunc = purchaseBack,				--购买返回
		fast_trade_id = nil ,						--购买唯一ID

		item_id = 0, 							--根据id和type选择购买方式，可能有多重
		item_type = 1,
		multi_buyi_purchase = true 				--是否可以切换购买方式，默认只取一个

	}
	SceneManager:showPurchase( purchase_data )
end

