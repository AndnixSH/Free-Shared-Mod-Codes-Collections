--特殊状态类的组件。
--created by kobejaw.2018.6.30.
Com_D_SpecialState = class("Com_D_SpecialState",ComponentBase)

--82033。黑绞
--82994
function Com_D_SpecialState:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 2
	self.buffType = Com_DebuffEnum.SpecialState
end

