--[[
	CommonSortBoxLayer.lua
--]]

CommonSortBoxLayer = class("CommonSortBoxLayer",XUIView)
CommonSortBoxLayer.CS_FILE_NAME = "CommonSortBoxLayer.csb"
CommonSortBoxLayer.CS_BIND_TABLE = 
{
    btnReset = "/i:101/i:188/s:btnReset",
    btnCancel = "/i:101/i:188/s:btnCancel",
    btnOK = "/i:101/i:188/s:btnCommit",
    listView = "/i:101/i:188/s:listView",
}

CommonSortBoxLayer.titleSelected = cc.c3b(255, 239, 167)
CommonSortBoxLayer.titleNor = cc.c3b(255, 255, 255)

local SORT_COLUMN = 4

function CommonSortBoxLayer:init(manager, data)
    CommonSortBoxLayer.super.init(self)
    self._manager = manager
    self._boxTempData = table.deepcopy(data)
    self._imgBtns = {}

    self:initUI()

    self.btnReset:addClickEventListener(function ()
        self:onBtnReset()
    end)

    local function returnBack()
        KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
        self:removeFromParentView()
    end

    self.btnCancel:addClickEventListener(function ()
        returnBack()
    end)

    self.btnOK:addClickEventListener(function ()
        self._manager:siftBoxCallBack(self._boxTempData)
        returnBack()
    end)

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        returnBack()
    end)

    return self
end

function CommonSortBoxLayer:initUI()
    self.listRow = 0
    self.rowHeight = 0

    self.listView:setScrollBarEnabled(true)
    self.listView:setScrollBarWidth(20)
    self.listView:setScrollBarColor(cc.c3b(0, 0, 0))
    self.listView:setScrollBarOpacity(225*0.5)
    self.listView:setScrollBarPositionFromCorner(cc.p(2,2))

    local panel = cc.CSLoader:createNode("CommonSortSubBtnNode.csb")
    local templetPanel = panel:getChildByTag(1)

    for i=1,#self._boxTempData do
        self:addBtnsItem(templetPanel, self._boxTempData[i], i)
        if i==1 then 
            self:addLineItem()
        end 
    end

    self.listView:setInnerContainerSize(cc.size(self.listView:getContentSize().width,self.rowHeight*self.listRow))
    
    self:refreshBtnsState()
end

function CommonSortBoxLayer:addLineItem()
    local imgLine = ccui.ImageView:create("n_UIShare/bag/lzjm_ui_003.png")
    imgLine:setPositionX(0)
    imgLine:setAnchorPoint(cc.p(0, 0))
    self.listView:pushBackCustomItem(imgLine)
end

function CommonSortBoxLayer:addBtnsItem(templetPanel,data,typeIndex)
    self._imgBtns[typeIndex] = {}

    local size = templetPanel:getContentSize()
	local dataNum = #data.items
 	local row = math.ceil(dataNum/SORT_COLUMN) 

	self.listRow = self.listRow + row
    self.rowHeight = size.height

	local itemLayout = ccui.Layout:create()
	itemLayout:setAnchorPoint(cc.p(0, 0))
	itemLayout:setContentSize(cc.size(size.width, size.height*row))
	for i=1,row do
		local panel = templetPanel:clone()
        panel:setPosition(0,(row-i)*size.height)
        local title = panel:getChildByName("main_title")
        if i==1 then 
        	title:setVisible(true)
            title:setString(data.name..":")
        else 
        	title:setVisible(false)
        end 

        for t=1,SORT_COLUMN do
        	local imgBtn = panel:getChildByName("img_btn_"..t)
        	local subIndex = (i-1) * SORT_COLUMN + t
            if subIndex > dataNum then
                imgBtn:setVisible(false)
            else
            	imgBtn:setVisible(true)

            	imgBtn:addClickEventListener(function (sender)
                    local data = sender._myData
                    self:onImgBtnClick(data)
                end)

            	imgBtn._myData = {
                    index = typeIndex,
                    subIndex = subIndex
                }

        		local title = imgBtn:getChildByName("title")
                local specialJpAttrStr = "スキルダメージ"
                local specialCnAttrStr = "技能伤害倍率"
                if g_channel_control.transform_CommonSortBoxLayer_soutItem_Text_fontSize == true then
                    if data.items[subIndex].name == specialJpAttrStr or data.items[subIndex].name == specialCnAttrStr then
                        title:setFontSize(16)
                    end
                end
        		title:setString(data.items[subIndex].name)
                self._imgBtns[typeIndex][subIndex] = imgBtn
            end 
        end
        itemLayout:addChild(panel)
	end

	self.listView:pushBackCustomItem(itemLayout)
end

function CommonSortBoxLayer:onImgBtnClick(clickData)
    local index = clickData.index
    local subIndex = clickData.subIndex
    if index == 1 then
        self:onSortBtnClick(index,subIndex) 
    else 
        self:onSelectBtnClick(index,subIndex)
    end 
end

function CommonSortBoxLayer:refreshBtnsState()
   for i=1,#self._boxTempData do
       local items = self._boxTempData[i].items
       for t=1,#items do
           local btn = self._imgBtns[i][t]
            btn:setTouchEnabled(true)
           if btn then 
                if items[t].state == 1 then 
                    self:setBtnState(btn,1)
                    if i==1 then 
                        btn:setTouchEnabled(false)
                    end 
                else 
                    self:setBtnState(btn,0)
                end 
           end 
       end
   end
end

function CommonSortBoxLayer:onBtnReset()
    self._manager:resetData(self._boxTempData)
    self:refreshBtnsState()
end

function CommonSortBoxLayer:setBtnState(btn, state)
    if state==1 then 
        btn:loadTexture(EQ_SORT_BTN_IMG[2])
        btn:getChildByName("title"):setColor(self.titleSelected)
    else 
        btn:loadTexture(EQ_SORT_BTN_IMG[1])
        btn:getChildByName("title"):setColor(self.titleNor) 
    end 
end

--排序
function CommonSortBoxLayer:onSortBtnClick(index,subIndex)
    local items = self._boxTempData[index].items
    local btns = self._imgBtns[index]
    for i = 1,#btns do
        local btn = btns[i]
        if i == subIndex then
            self:setBtnState(btn, 1)
            items[i].state = 1
            btn:setTouchEnabled(false)
        else
            self:setBtnState(btn, 0)
            items[i].state = 0
            btn:setTouchEnabled(true)
        end
    end
end

--筛选按钮
function CommonSortBoxLayer:onSelectBtnClick(index,subIndex) 
    local items = self._boxTempData[index].items
    local btns = self._imgBtns[index]
    if subIndex > 1 then
        if items[subIndex].state > 0 then
            items[subIndex].state = 0
        else
            items[subIndex].state = 1
            items[1].state = 0
        end
        local isAll = true
        for i=2,#items do
            local state = items[i].state 
            if state ~= items[subIndex].state then 
                isAll = false
            end 
        end
        if isAll then 
            items[1].state = 1
            for i=2,#items do
                items[i].state = 0
            end
        end 
        self:refreshSelectBtnsState(index)
    else
        if items[1].state== 1 then 
            return 
        else
            items[1].state = 1
            for i=2,#items do
                items[i].state = 0
            end  
            self:refreshSelectBtnsState(index)  
        end 
    end
end

function CommonSortBoxLayer:refreshSelectBtnsState(index)
   local items = self._boxTempData[index].items
   for t=1,#items do
       local btn = self._imgBtns[index][t]
       if btn then 
            if items[t].state == 1 then 
                self:setBtnState(btn,1)
            else 
                self:setBtnState(btn,0)
            end 
       end 
   end
end
