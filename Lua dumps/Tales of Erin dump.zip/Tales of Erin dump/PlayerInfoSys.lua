PlayerInfoSys = {}

PlayerInfoSys.ETab_Config = {
    --个人信息
    person_info = 1,
    --系统设置
    sys_seting = 2,
    --队伍信息
    team_info = 3,
}

PlayerInfoSys.EUiType = {
    --主界面信息栏
    topBar = 1,
    --排行榜
    rank = 2,
    --公会
    guild = 3,
    --好友
    friend = 4,
}

PlayerInfoSys.EChangeType = {
    --更换头像
    changeHead = 1,
    --更换图鉴板娘
    changeTJBanNiang = 2,
}

PlayerInfoSys.ESoundControlType = {
    --声音开
    on = 0,
    --声音关
    off = 1,
}

PlayerInfoSys.titleMap = {
    lastIndex = 1,
    lastHigh = nil
}

PlayerInfoSys.guild_position = {}
PlayerInfoSys.guild_position[1] = {
    icon = "res/uifile/n_UIShare/player_info/xxjm_ui_008.png"
}
PlayerInfoSys.guild_position[2] = {
    icon = "res/uifile/n_UIShare/player_info/xxjm_ui_007.png"
}
PlayerInfoSys.guild_position[3] = {
    icon = "res/uifile/n_UIShare/player_info/xxjm_ui_005.png"
}

PlayerInfoSys.job = {
    G_P_Member = 1,
    G_P_Vice_President = 2,
    G_P_President = 3,
}

PlayerInfoSys.personInfo = nil

function PlayerInfoSys:getInstance(  )
    if self.instance == nil  then
        self.instance = self:new()
        self.instance:initPersonalInfo()
    end
    return self.instance
end

function PlayerInfoSys:new(o)  
    o = o or {}  
    setmetatable(o,self)  
    self.__index = self  
    return o  
end

function PlayerInfoSys:getTitleMap( ... )
    -- body
    return self.titleMap
end

function PlayerInfoSys:initPersonalInfo( data )
    self.personInfo = XbPlayerInfo:new(data)
end

function PlayerInfoSys:updatePersonalInfo( data )
    -- body
    self.personInfo:updateInfo(data)
end

function PlayerInfoSys:getPersonalInfo()
    -- body
    return self.personInfo
end

--是否是公会会长
function PlayerInfoSys:isChairman()
    local bChairman = false
    local guild_pos = self:getGuildPosition()
    if guild_pos == 3 then
        bChairman = true
    end
    return bChairman
end

function PlayerInfoSys:getGuildPosition( ... )
    -- body
    dump(self.personInfo,"PlayerInfoSys:getGuildPosition   personInfo")
    if self.personInfo and self.personInfo["guild_position"] then
        local guild_pos = self.personInfo["guild_position"]
        print("PlayerInfoSys:getGuildPosition   guild_pos ",guild_pos)
        return guild_pos
    end
end

function PlayerInfoSys:setTeamTitleId( id )
    -- body
    self.team_title_id = id
end

function PlayerInfoSys:getTeamTitleId( ... )
    -- body
    return self.team_title_id
end

function PlayerInfoSys:isFromGuild( parms )
    -- body
    local bGuild = false
    local from = parms
    if from == PlayerInfoSys.EUiType.guild then
        bGuild = true
    end
    return bGuild
end

--背景音乐开关 statue 0 为 开启 ，1 为关闭 ，默认为0 
function PlayerInfoSys:setBackMusicStatue(statue)
    XBConfigManager:getInstance():setGlobalIntegerByKey("Z_MUSIC_STATUE", statue)
    local nowState = XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE")
    --todo 停止或者恢复当前音乐
    if statue == 0 then --开启音乐
       -- cc.SimpleAudioEngine:getInstance():resumeMusic()
        AudioManager:shareDataManager():resumeBGMusic()
        if AudioManager:shareDataManager():getBGId() ~= -1 then 
    
        else 
            local fullpath = lua_musci["zhuyeBGM"]
           AudioManager:shareDataManager():preloadM(fullpath)
           AudioManager:shareDataManager():playBGMusic(fullpath, true)
        end

    else 
       AudioManager:shareDataManager():pauseBGMusic()
    end 
end

-- 恢复到当前的声音状态
function PlayerInfoSys:refreshCurAudioState()
    
    local musicState = XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE")

    PlayerInfoSys:setBackMusicStatue(musicState)

    local soundState = XBConfigManager:getInstance():getGlobalIntegerByKey("Z_EFFECT_STATUE")

    PlayerInfoSys:setEffectMusicStatue(soundState)

end


--todo是用暂停还是用恢复
--音效开关
function PlayerInfoSys:setEffectMusicStatue(statue)
    XBConfigManager:getInstance():setGlobalIntegerByKey("Z_EFFECT_STATUE", statue)
    local nowState = XBConfigManager:getInstance():getGlobalIntegerByKey("Z_EFFECT_STATUE")
    --todo 停止或者恢复特效
    if statue == 0 then --开启音乐
         --AudioManager:shareDataManager():resumeAll()
         AudioManager:shareDataManager():resumeAllEffects()
    else 
         --AudioManager:shareDataManager():pauseAll()
         AudioManager:shareDataManager():pauseAllEffects()
    end 
end

function PlayerInfoSys:refreshMusicVolum( volumView )
    local volum_bar = volumView
    if volum_bar == nil then
        return
    end
    --获取当前设置状态   0 为 开启 ，1 为关闭 ，默认为0
    if XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE") == 0 then
        volum_bar:setSelectedIndex(PlayerInfoSys.ESoundControlType.on)
    else
        volum_bar:setSelectedIndex(PlayerInfoSys.ESoundControlType.off)
    end
end

function PlayerInfoSys:refreshSndEffVolum( volumView )
    local volum_bar = volumView
    if volum_bar == nil then
        return
    end
    --获取当前设置状态  0 为 开启 ，1 为关闭 ，默认为0
    if XBConfigManager:getInstance():getGlobalIntegerByKey("Z_EFFECT_STATUE") == 0 then
        volum_bar:setSelectedIndex(PlayerInfoSys.ESoundControlType.on)
    else
        volum_bar:setSelectedIndex(PlayerInfoSys.ESoundControlType.off)
    end
end

function PlayerInfoSys:requestUpdateData( msg,callBack )
    -- body
    local function HandlerCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        SceneManager:delWaitLayer()
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())


        --local m_data = self:getJsonData()
        --local t_data = cjsonSafe.decode(m_data)
        --self.resultData = t_data["data"]

        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            if failesFunc ~= nil then
                MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,failesFunc)
            else
                MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            end
            return
        end
        callBack(t_data["data"])
    end

    local cjson = require "cjson"
    SceneManager:createWaitLayer()

    --HandlerCallBack()
    local mydata =  cjson.encode(msg)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),HandlerCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function PlayerInfoSys:getJsonData( ... )
    -- body
    -- local cjson = require "cjson"
    -- local filePath =  cc.FileUtils:getInstance():fullPathForFilename("test_conf.json")
    -- local file = io.open( filePath, "r" )
    -- local json_data = file:read( "*all" )
    -- file:close()
    -- return json_data
end