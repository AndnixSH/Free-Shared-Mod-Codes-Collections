--星盘扩展功能

AstrolabeAddSPView = class("AstrolabeAddSPView",XUIView)
AstrolabeAddSPView.CS_FILE_NAME = "AstrolabeAddSPView.csb"
AstrolabeAddSPView.CS_BIND_TABLE = 
{   --当前数量 最大数量
    numLv = "/i:295/i:296/i:339/s:numLv",
    --当前的数量
    numMat = "/i:295/i:296/i:339/s:numMat",
    --左
    btnLeft = "/i:295/i:296/i:339/s:btnLeft",
    --右
    btnRight = "/i:295/i:296/i:339/s:btnRight",
    --点击确定
    btnUp = "/i:295/i:296/i:339/s:btnUp",
    --点击背景框显示的事件
    m_panel = "/i:295/i:296/i:339/i:347",
    --背景框
    m_imgBG = "/i:295/i:296/i:339/i:347/s:imgBG",
    --素材图标
    m_imgFace = "/i:295/i:296/i:339/i:347/s:imgFace",
    --属性求
    m_imgRarity = "/i:295/i:296/i:339/i:347/s:imgRarity",
    --素材数量
    m_lbNum = "/i:295/i:296/i:339/i:347/s:lbNum",
    --显示最大扩展次数
    lbHint = "/i:295/i:296/i:352",
    --关闭按钮
    btnOk = "/i:295/i:296/i:353",
    --title
    textTitle = "/i:295/i:296/i:299",
}

function AstrolabeAddSPView:init()
    AstrolabeAddSPView.super.init(self)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end
function AstrolabeAddSPView:touchClick( ... )
    self.textTitle:setString(UITool.ToLocalization("使用道具 "))
    --点击确定按钮
    self.btnUp:addClickEventListener(function()
        if not self.mat_count then return end
        --当前扩充数为0
        if self.mat_count == 0 then
            GameManagerInst:alert(UITool.ToLocalization("请选择素材数量"))
            return
        end
        --可以扩充的情况
        local mid = getMatID(self.matName)
        local msg = "使用%d个%s提升星盘点数？"
        local msg1 = ""
        if g_channel_control.transform_AstrolabeAddSPView_msg_tip_order == true then
            msg1 = string.format(UITool.ToLocalization(msg),UITool.getUserLanguage(mat[mid].name), self.mat_count)
        else
            msg1 = string.format(UITool.ToLocalization(msg),self.mat_count,UITool.getUserLanguage(mat[mid].name))
        end
       
        GameManagerInst:confirm(msg1,function()
            --在外层定义的函数 
            if self.addSpEvent then
                self.addSpEvent(self,self.mat_count)
            end
        end)
    end)
    --点击素材弹出素材的信息框
    self.m_panel:setTouchEnabled(true)
    self.m_panel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local mid = getMatID(self.matName)
            MsgManager:showSimpItemInfo(5,mid)
        end
    end)

    -- self.btnLeft:addClickEventListener(function()
    --     self:setMatCount(-1)
    -- end)

    -- self.btnRight:addClickEventListener(function()
    --     self:setMatCount(1)
    -- end)

     self.btnLeft:addTouchEventListener(function(sender,eventType)

        print("AstrolabeAddSPView touch left btn")
        if eventType == ccui.TouchEventType.began then
            self:startAddSp(-1)
        elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
  
            self:stopAddSp()
        end
    end)


    self.btnRight:addTouchEventListener(function(sender,eventType)

        print("AstrolabeAddSPView touch right btn")
        if eventType == ccui.TouchEventType.began then
            self:startAddSp(1)
        elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
  
            self:stopAddSp()
        end
    end)

    self.btnOk:addClickEventListener(function()
        self:returnBack()
    end)
end

function AstrolabeAddSPView:startAddSp(opt)
    print("AstrolabeAddSPView:startAddSp")
    self:stopAddSp()
    
    local function addSpfunc(time)
        self:setMatCount(opt)
       
    end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerEntry = scheduler:scheduleScriptFunc(addSpfunc, 1/20 , false)
    
    addSpfunc(0) 
   
end

function AstrolabeAddSPView:stopAddSp()
    print("AstrolabeAddSPView:stopAddSp")
    if self.schedulerEntry == nil then 
        return 
    end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.schedulerEntry)
    self.schedulerEntry = nil
end

function AstrolabeAddSPView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
    self:stopAddSp();
end

function AstrolabeAddSPView:loadData(sp_add,maxEX,matmax,hero_id)

    self.hero_id     = hero_id
    self.hero_sub_id = getNumID(self.hero_id)
    self.matName     = hero_astrolabe[self.hero_sub_id]["mat_asp"]
    --服务器保存当前扩充次数
    self.curEX = sp_add
    --要扩充的次数
    self.mat_count = 0
    --素材最大数量
    self.mat_max = matmax--user_info["bag"]["mat"][ID_ASTROLABE_EX]
    if not self.mat_max then
        self.mat_max = 0
    end

    self.maxEX = maxEX    --额外技能点上限

    self.numLv:setString(""..sp_add.."/"..self.maxEX)

    local mid = getMatID(self.matName)
    local rarity = mat[mid].rarity
    
    self.m_imgBG:setTexture(Rarity_BG[rarity])
    self.m_imgRarity:setTexture(Rarity_mat[rarity])
    self.m_imgFace:setTexture("icons/mat/"..mat[mid].icon)
    self.m_lbNum:setString("x"..self.mat_max)

    local str = UITool.ToLocalization("提示： 每个角色最多使用%s%d次")
    local lbStr = string.format(str,UITool.getUserLanguage(mat[mid].name),self.maxEX);
    self.lbHint:setString(lbStr)
    self:touchClick()
    self:setMatCount(0)
end


function AstrolabeAddSPView:setMatCount(offect)
    self.mat_count = self.mat_count + offect
    local ll = false
    local lr = false

    if self.mat_count <= 0 then
        self.mat_count = 0
        ll = true
    end

    if self.mat_count + self.curEX >= self.maxEX then
        self.mat_count = self.maxEX - self.curEX
        lr = true
    end

    if  self.mat_count >= self.mat_max then
        self.mat_count = self.mat_max
        lr = true
    end

    --如果超过两边的边缘，就停止加点定时器
    if ll == true or lr == true then
        self:stopAddSp();
    end


    self.btnLeft:setTouchEnabled(not ll)
    self.btnLeft:setBright(not ll)
    self.btnRight:setTouchEnabled(not lr)
    self.btnRight:setBright(not lr)

    self.numMat:setString(""..self.mat_count)
end