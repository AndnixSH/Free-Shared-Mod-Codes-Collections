--角色主动技能管理器
--created by kobejaw.2018.4.20.
ActiveSkillManager = {}

local idxForSkillUpdate = 0;
local deltaForSKillUpdate = 0;
function ActiveSkillManager:init(rootNode)
	idxForSkillUpdate = 0
	deltaForSKillUpdate = 0
	self.rootNode = rootNode
	self.autoPlayList = {}
	self:initSkillPanel()
	self:initAutoBtn()
end

--初始化技能面板
function ActiveSkillManager:initSkillPanel()
	self.roleSkillPanel = {}

	local nodePanel = self.rootNode:getChildByTag(4)
	for i = 1,#G_Roles do
		local roleSkillNode = nodePanel:getChildByTag(403+i)
		roleSkillNode:setVisible(true)
		table.insert(self.roleSkillPanel,self:createOneRoleSkillPanel(roleSkillNode,G_Roles[i]))
	end
end

function ActiveSkillManager:initAutoBtn()
	local autoFlag = cc.UserDefault:getInstance():getBoolForKey("AUTOBATTLE") 
	self.autoBtn = self.rootNode:getChildByTag(944)

	if autoFlag then
		self.isAuto = true
		self.autoBtn:loadTextureNormal("n_UIShare/Global_UI/btn/zd_b_003_2.png")
	else
		self.isAuto = false
		self.autoBtn:loadTextureNormal("n_UIShare/Global_UI/btn/zd_b_003_1.png")
	end

	local level = user_info["rank"]--tonumber(cc.UserDefault:getInstance():getStringForKey("RoleRank"))	--玩家等级
	if level == nil or level == "" then
		level = 1
	end

	if level < 5 then
		self.autoBtn:setVisible(false)
		if IsTestMode then
			self.autoBtn:setVisible(true)
		end
	else
		self.autoBtn:setVisible(true)
		self.autoBtn:addClickEventListener(function()
			if self.isAuto then
				self.isAuto = false
				self.autoBtn:loadTextureNormal("n_UIShare/Global_UI/btn/zd_b_003_1.png")
			else
				self.isAuto = true
				self.autoBtn:loadTextureNormal("n_UIShare/Global_UI/btn/zd_b_003_2.png")
			end
		end)
	end	
end

--创建一个角色的技能面板
function ActiveSkillManager:createOneRoleSkillPanel(fatherNode,role)
	local oneRolePanel = {}

	local roleImg = fatherNode:getChildByTag(6)
	roleImg:loadTexture(hero[role.data.heroId].hero_bat_icon)
	roleImg:setOpacity(255)

	oneRolePanel.rootPanel = fatherNode
	oneRolePanel.skill = {}
	oneRolePanel.skill[1] = RoleActiveSkill.new(fatherNode,role,1)
	oneRolePanel.skill[2] = RoleActiveSkill.new(fatherNode,role,2)

	return oneRolePanel
end

function ActiveSkillManager:removeFromAutoPlayList(skill)
	for k,v in pairs(self.autoPlayList) do
		if v == skill then
			table.remove(self.autoPlayList,k)
		end
	end
end

function ActiveSkillManager:update(dt)
	idxForSkillUpdate = idxForSkillUpdate + 1
	deltaForSKillUpdate = deltaForSKillUpdate + dt

	--每隔一帧update一次
	if idxForSkillUpdate == 1 then
		table.foreachi(self.roleSkillPanel, function(k,v)
			v.skill[1]:update(deltaForSKillUpdate)
			v.skill[2]:update(deltaForSKillUpdate)
		end)

		idxForSkillUpdate = -1
		deltaForSKillUpdate = 0		
	end
end

function ActiveSkillManager:refreshSkillWhenCutIn(currentSkill)
	for k,v in pairs(self.roleSkillPanel) do
		local skill = v.skill[2]
		if skill ~= currentSkill then
			if skill.isReady then
				skill.isReady = false
				skill.remainTime = 4
				skill.cdType = 2
				self:removeFromAutoPlayList(skill)
			elseif skill.remainTime < 4 then
				skill.remainTime = 4
				skill.cdType = 2
			end
		end
	end
end

--改变某个角色的技能的cd
--@type :0所有技能 1小技能 2大技能
function ActiveSkillManager:changeSkillCD(target,type,t)
	if type == 0 then
		target.skill[1]:changeCD(t)
		target.skill[2]:changeCD(t)
	elseif type == 1 then
		target.skill[1]:changeCD(t)
	elseif type == 2 then
		target.skill[2]:changeCD(t)
	end
end

--重置某个角色的技能cd
--@type :0所有技能 1小技能 2大技能
function ActiveSkillManager:resetSkillCD(target,type)
	if type == 0 then
		target.skill[1]:resetCD()
		target.skill[2]:resetCD()
	elseif type == 1 then
		target.skill[1]:resetCD()
	elseif type == 2 then
		target.skill[2]:resetCD()
	end
end

--隐藏技能栏
function ActiveSkillManager:hideSkillPanel()
	for k,v in pairs(self.roleSkillPanel) do
		if v.rootPanel then
			v.rootPanel:setVisible(false)
		end
	end	
end

--复活时调用
function ActiveSkillManager:onRevive()
	self.autoPlayList = {}

	for k,v in pairs(self.roleSkillPanel) do
		v.rootPanel:setVisible(true)
		for i = 1,2 do
			local skill = v.skill[i]
			skill:onRevive()
			table.insert(self.autoPlayList,skill)
		end
	end
end
