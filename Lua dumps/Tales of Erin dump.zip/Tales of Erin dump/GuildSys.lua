
--好友系统




GuildSys = class("GuildSys")


function GuildSys:getInstance()
   if self.s_instance == nil then

        self.s_instance = GuildSys.new()
        self.s_instance:initialize()
   end
   return self.s_instance;
end

function GuildSys:initialize()

    self:reset()

end

function GuildSys:reset()
    print("GuildSys:reset")
    --当前成员数量
    self.curMem = 0
    --最大成员数量
    self.memMaxCount = 0
    --最大赠送体力数量
    self.max_give_num = 0
    --当前体力数量
    self.cur_give_num = 0
    --在公会中的职位
    self.position = 1

    self.join_condition = 1
    --存在公会
    self.haveGuild = false
end

   --在公会中的职位
function GuildSys:setPosition(position)
    -- print("GuildSys:setPosition ", position)
    self.position = position
    -- print("position",self.position)
end

  --在公会中的职位
function GuildSys:getPosition()
    return self.position
end

function GuildSys:checkOperAuth()

    if self.position > 1 then
        return true
    end
    
    return false

end

   --最大赠送体力数量
function GuildSys:setMaxGiveCount(count)
 
    self.max_give_num = count
end

  --最大赠送体力数量
function GuildSys:getMaxGiveCount()
    return self.max_give_num
end

   --当前体力数量
function GuildSys:setCurGiveCount(count)
 
    self.cur_give_num = count
end

  --当前体力数量
function GuildSys:getCurGiveCount()
    return self.cur_give_num
end

  --是检测加入公会
function GuildSys:isCheckJoinGuild()
    print("GuildSys:isCheckJoinGuild ", self.join_condition)
    return self.join_condition
end


--是否有公会
function GuildSys:isHaveGuild()
    print("GuildSys:isCheckJoinGuild ", self.haveGuild)
    return self.haveGuild
end


--获得公会成员列表
function GuildSys:reqMyGuildMemberList(reqData, successCallback, failCallback)
    
    dump(reqData, "GuildSys:reqGuildMemberList")
     
    -- local guildId = table.getValue("GuildSys:getGuildMemberList data", reqData, "guildId")

    -- if type(guildId) ~= "string" or guildId == "" then
    --     print("GuildSys:reqGuildMemberList guildId error", guildId)
    --     if failCallback then
    --         failCallback()
    --     end
    --     return
    -- end
    
    local tempData = {
        ["rpc"]       = "guild_members"
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            print("GuildSys:reqGuildMemberList success")
            dump(data, "GuildSys:reqGuildMemberList data")
            
            self:synGuildData(data) 
           
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            print("GuildSys:reqGuildMemberList failed")
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    

   
end

function GuildSys:synGuildData(guildData)
    guildData = guildData or {}
    -- dump(guildData, "GuildSys:synGuildData")
    local members = table.getValue("", guildData, "members")
 
    if type(members) == "table" and #members >= 1 then

        self.isHaveGuild = true
        self.guild_id = table.getValue("GuildSys:synGuildData", guildData, "guild_id") or 0
        self.cur_give_num = table.getValue("GuildSys:synGuildData", guildData, "cur_give_num") or 0
        self.max_give_num = table.getValue("GuildSys:synGuildData", guildData, "max_give_num") or 0
        self.join_condition = table.getValue("GuildSys:synGuildData", guildData, "join_condition") or 0
        self.position = table.getValue("GuildSys:synGuildData", guildData, "position") or 1

        if self.guild_id ~= nil and  self.guild_id ~= 0 then

            user_info["guild_id"] = self.guild_id
        end
       
        
    end

end


--获得公会申请列表
function GuildSys:reqGuildApplyList(reqData, successCallback, failCallback)

    dump(reqData, "FriendsSys:reqGuildApplyList")
     
    local guildId = table.getValue("FriendsSys:reqGuildApplyList data", reqData, "guildId")
    
    local tempData = {
        ["rpc"]       = "guild_applicants"
        
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)

    

   
end


--公会批准
function GuildSys:reqConfrimToCancleSend(reqData, successCallback, failCallback)
    
    -- print("position", self.position)
    if self:checkOperAuth() == false then
        local msgText = Lang:toLocalization(1040121)
        GameManagerInst:alert(msgText)
        if failCallback then
            failCallback()
        end
        return 
    end
    -- dump(reqData, "GuildSys:reqConfrimToCancleSend")
     
    local uid = table.getValue("GuildSys:reqConfrimToCancleSend data", reqData, "apply_uid")
    local ratify = table.getValue("GuildSys:reqConfrimToCancleSend data", reqData, "ratify")
    
    local tempData = {
        ["rpc"]       = "guild_ratify",
        ["apply_uid"] = uid,
        ["ratify"]    = ratify,
    }

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
   
end

--公会成员赠送体力
function GuildSys:reqGiveAp(reqData, successCallback, failCallback)

   
    local uid = table.getValue("GuildSys:reqGiveAp data", reqData, "uid")
    print("uid", uid)

   

    print("maxGiveCount", self.max_give_num)
    print("curGiveCount",  self.cur_give_num)

    if self.cur_give_num >= self.max_give_num then
        local msg = string.format(Lang:toLocalization(1040142), self.max_give_num, self.max_give_num)
        MsgTipSys:getInstance():addData(msg)

        if failCallback then
            failCallback()
        end
        return 
   
    end


    local tempData = {
        ["rpc"]       = "guild_give_ap",
        ["member_id"] = uid , 
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            local friendArr = {}
            table.insert(friendArr, uid)
            lemon.EventManager:getInstance():dispatchCustomEvent(EEventType.GUILD_GIVE_AP, friendArr)
           
            self.cur_give_num = self.cur_give_num + 1
            local msg = string.format(Lang:toLocalization(1040141),  self.cur_give_num, self.max_give_num)
            MsgTipSys:getInstance():addData(msg)

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end

--提出公会
function GuildSys:reqKickGuildMember(reqData, successCallback, failCallback)

    dump(reqData, "FriendsSys:reqKickGuildMember")

    if self:checkOperAuth() == false then

        if failCallback then
            failCallback()
        end
        return
    end
     
    local uid = table.getValue("FriendsSys:reqGuildApplyList data", reqData, "uid")
    
    local tempData = {
        ["rpc"] = "guild_kick",
        ["uid"] = uid,
    }

   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            local kickData = {}
            kickData["uid"] = uid
            lemon.EventManager:getInstance():dispatchCustomEvent(EEventType.GUILD_KICK, kickData)
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)

    

   
end

--修改公会申请条件
--# 参数: "condition": 1, 表示需要验证 。0 表示自动通过
function GuildSys:reqModifyJoinCondition(reqData, successCallback, failCallback)

    dump(reqData, "FriendsSys:reqKickGuildMember")
     
    local condition = table.getValue("FriendsSys:reqGuildApplyList data", reqData, "condition")
    
    local tempData = {
        rpc = "guild_join_condition",
        condition = condition
    }
   

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            self.join_condition = condition
            print("GuildSys:reqModifyJoinCondition", self.join_condition)
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)

    

   
end



