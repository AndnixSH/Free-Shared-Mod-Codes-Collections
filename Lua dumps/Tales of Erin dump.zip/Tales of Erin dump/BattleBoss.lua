--Boss类
--created by kobejaw.2018.3.22.
BattleBoss = class("BattleBoss",EntityBase)

local tempIdx = 0
function BattleBoss:ctor(data,x,y,teamManager)
	self.entityType = BattleGlobals.EntityType.Monster
	self.isBoss = true
	self.super.ctor(self,data,teamManager)

	self:initMemberVariables();
	self:createSpineNode(x,y);
	self:initSpineListeners() -- 初始化spine事件监听
end

function BattleBoss:initMemberVariables()
	self.faceTo = BattleGlobals.FaceLeft
	self:setTeammateAndEnemyList()
	self:setTouchRectInfo()

	--每个boss有多个monsterSkill，每个monsterSkill对应多个skillInfo
	self.skillManager = MonsterSkillManager.new(self)

	tempIdx = 0
	self.bkTime = 0    --bk时间(多人战开始战斗时bkTime也是0，服务器传过来的那个时间戳是错的，不用了，之前的客户端也没用到)

	--音效资源
	--boss特有：死亡
	--角色和小怪都有：普攻
	--角色和boss都有：战斗开始
	--角色特有：大招音效，大招语音，小招音效，战斗胜利，战斗失败。
	local monsterId = self.data.monsterId
	self.sound_normalAtk = monster[monsterId].monster_vce[1]
	self.sound_battleStart = monster[monsterId].monster_vce[4]
	self.sound_dead = monster[monsterId].monster_vce[3]

	--新手引导的标识
	local loginName = cc.UserDefault:getInstance():getStringForKey("login_name")
	self.finishTeach1 = cc.UserDefault:getInstance():getBoolForKey(loginName.."a1_1_4")
	self.finishTeach2 = cc.UserDefault:getInstance():getBoolForKey(loginName.."a1_1_4_0")

	self.fsm = EntityFSM.new(self);
end

function BattleBoss:initODBKBar()
	if G_STAGE_TYPE == 2 then
		self.bkDamage_multi = 0
		if self.attr[AE.state] == 0 then
			BattleUIManager:setODBKState(0)
			local perent = BattleDataManager.multiData.od_n_hp/self.attr[AE.od_hp] * 100
			if perent > 100 then
				perent = 100
			elseif perent < 0 then
				perent = 0
			end
			BattleUIManager:setOD(perent)
		else
			BattleUIManager:setODBKState(1)
			self.bkDamage_multi = math.abs(self.attr[AE.bk_hp] - BattleDataManager.multiData.bk_n_hp)
			local perent = self.bkDamage_multi/self.attr[AE.bk_hp] * 100
			if perent > 100 then
				perent = 100
			elseif perent < 0 then
				perent = 0
			end
			BattleUIManager:setBK(perent)
		end
	else
		self.bkDamage = 0  --bk状态下受到的总伤害。每次从od且到bk时清0.
		self.odDamage = 0  --od状态下受到的总伤害。每次从bk且到od时清0.
		BattleUIManager:setODBKState(0)
		BattleUIManager:setOD(100)
	end
end

function BattleBoss:createSpineNode(x,y)
	local spineData = BattleCacheManager:getData(self.data.spineFullPath)
	local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
	self.spineNode = spineNode;
	self:addChild(spineNode)

	local pos = GetCorrectedPoint(x,y)
	self:setPosition(cc.p(pos.x,y))	
	self.box_w,self.box_h = GetBoxWHByPoint(pos.x,pos.y)--设置位置信息

	--buff特效的父节点
	self.effectNode = cc.Node:create()
	self:addChild(self.effectNode)
	self.effectNode:setPosition(cc.p(0,(self.touchRect[2] + self.touchRect[4])/2))
end

function BattleBoss:update(dt)
	if G_GameState == 1 then
		self.deltaForUpdate = self.deltaForUpdate + dt
		self.idxForUpdate = self.idxForUpdate + 1

		if self.idxForUpdate == 3 then		
			--组件管理器更新
			self.componentManager:update(self.deltaForUpdate)
			--触发器管理器更新
			self.triggerManager:update(self.deltaForUpdate)

			self.idxForUpdate = 1
			self.deltaForUpdate = 0
		end
	end

	if G_GameState == 1 or G_GameState == 3 then
		if G_STAGE_TYPE ~= 2 and self.attr[AE.state] == 1 then    --单人战的刷新
			self:updateBkTime(dt)
		elseif G_STAGE_TYPE == 2 and self.attr[AE.state] == 1 then--多人战的刷新
			self:updateBkTime_Multi(dt)
		end
	end
end

function BattleBoss:playSkill()
	--检测魅惑，取消当前行动。
	if self:checkMeiHuo() then
		self.fsm:changeState(StateEnum.Attacking_Boss)
		return
	end

	local skillInfo = self.skillManager:getNextSkillInfo()
	if skillInfo then
		self:attackWithSkill(skillInfo)
	end	

	--满豆教学
	if not self.finishTeach2 and self:checkIsFullEP() then
		BattleUIManager:showXSYDMode(3)
		self.finishTeach2 = true
		local loginName = cc.UserDefault:getInstance():getStringForKey("login_name")
		cc.UserDefault:getInstance():setBoolForKey(loginName.."a1_1_4_0",true)
	--涨豆教学
	elseif not self.finishTeach1 then
		BattleUIManager:showXSYDMode(2)
		self.finishTeach1 = true
		local loginName = cc.UserDefault:getInstance():getStringForKey("login_name")
		cc.UserDefault:getInstance():setBoolForKey(loginName.."a1_1_4",true)
	end
end

function BattleBoss:onDead()
	self.fsm:changeState(StateEnum.Dead)
end

--监测是否所有敌人都死了
function BattleBoss:checkIsAllEnemiesDead()
	if BattleRuntimeInfo.team1EntityNum <= 0 then
		self.fsm:changeState(StateEnum.Idling)
		return true
	else
		return false
	end
end

--是否满豆
function BattleBoss:checkIsFullEP() --EP:EnergyPoint
	if self.attr[AE.energy] == self.attr[AE.energy_max] then
		return true
	else
		return false
	end
end

--od,bk状态切换时，通知所有玩家角色触发时机6
function BattleBoss:onBossStateChanged()
	--触发时机6.
	for k,v in pairs(G_Roles) do
		if not v.isDead then
			local option = {}
			option.affectedEntity = self
			v.triggerManager:check(6,option)
		end
	end
end

--删除特殊技能的标识
function BattleBoss:removeSpecialFlagCom()
	if self.specialFlagCom then
		self.componentManager:removeCom(self.specialFlagCom)
		BattleRuntimeInfo.sharedBossDebuff[self.specialFlagCom.comId] = nil;
		self.specialFlagCom = nil	
	end
end

--释放技能时更新能量点数
--@monsterSkill:MonsterActiveSkill对象。
function BattleBoss:refreshEnegyPoint(monsterSkill)
	--终极大招
	if monsterSkill.sk_lv == 0 then
		self.attr[AE.energy] = 0
		BattleUIManager:setMcountForBoss(0,self.attr[AE.energy_max])
	elseif self.attr[AE.state] == 0 then
		--普通大招
		if monsterSkill.sk_lv > 1 then
			self.attr[AE.energy] = 0
			BattleUIManager:setMcountForBoss(0,self.attr[AE.energy_max])				
		--普通技能
		else
			if not self.componentManager.DongTuFengYin then--冻土封印
				if not self:checkIsFullEP() then
					self.attr[AE.energy] = self.attr[AE.energy] + 1
				end
				BattleUIManager:setMcountForBoss(self.attr[AE.energy],self.attr[AE.energy_max])
			end				
		end
	end
end

--odbk相关
--单人战的boss的bk刷新
function BattleBoss:updateBkTime(dt)
	self.bkTime = self.bkTime + dt
	tempIdx = tempIdx + 1
	if tempIdx >= 6 then
		tempIdx = 0
		self:refreshBkBar()
	end
end

--多人战的boss的bk刷新
function BattleBoss:updateBkTime_Multi(dt)
	self.bkTime = self.bkTime + dt
	tempIdx = tempIdx + 1
	if tempIdx>=6 then
		tempIdx = 0 

		local damagePercent = self.bkDamage_multi/self.attr[AE.bk_hp]
		local timePercent = self.bkTime/self.attr[AE.bk_t]
		if damagePercent >= 1 or timePercent >= 1 then
			BattleUIManager:setBK(100) --等待服务器数据改变状态。
		else
			if damagePercent < timePercent then
				damagePercent = timePercent
			end
			BattleUIManager:setBK(damagePercent*100)
		end		
	end
end

--单人战刷新一下bk槽
function BattleBoss:refreshBkBar()
	local damagePercent = self.bkDamage/self.attr[AE.bk_hp]
	local timePercent = self.bkTime/self.attr[AE.bk_t]

	if damagePercent >= 1 or timePercent >= 1 then
		self.bkDamage = 0
		self.odDamage = 0
		self.attr[AE.state] = 0
		self.bkTime = 0
		self:onBossStateChanged()
		BattleUIManager:changeODBKState(0)
		BattleUIManager:setOD(100)	
	else
		if damagePercent < timePercent then
			damagePercent = timePercent
		end
		BattleUIManager:setBK(damagePercent*100)			
	end
end


--单人战刷新一下od槽。
function BattleBoss:refreshOdBar()
	if self.odDamage >= self.attr[AE.od_hp] then
		self.bkDamage = 0
		self.odDamage = 0
		self.attr[AE.state] = 1
		self.bkTime = 0
		self:onBossStateChanged()
		BattleUIManager:changeODBKState(1)
		BattleUIManager:setBK(0)	
	else
		local damagePercent = (self.attr[AE.od_hp] - self.odDamage)/self.attr[AE.od_hp]
		BattleUIManager:setOD(damagePercent * 100)	
	end
end

--受攻击时，更新一下od,bk值
function BattleBoss:onAttacked(dmg)
	if self.attr[AE.state] == 0 then
		if G_STAGE_TYPE == 2 then
			BattleRuntimeInfo.msgData.odForMulti = BattleRuntimeInfo.msgData.odForMulti + dmg
		else
			self.odDamage = self.odDamage + dmg
			if self.odDamage < 0 then
				self.odDamage = 0
			end
			self:refreshOdBar()			
		end
	else
		if G_STAGE_TYPE == 2 then
			BattleRuntimeInfo.msgData.bkForMulti = BattleRuntimeInfo.msgData.bkForMulti + dmg
		else
			self.bkDamage = self.bkDamage + dmg
			self:refreshBkBar()
		end
	end
end

--刷新odbk槽。多人战的时候用,每两秒刷新一次。
function BattleBoss:refreshStateBarForMulti(data)--data:monster_mul[1]
	local state = tonumber(data.mode)
	local percent

	if state == 0 then
		percent = data.od.od_n_hp/self.attr[AE.od_hp] * 100
	--else
		--percent = data.bk.bk_n_hp/self.attr[AE.bk_hp] * 100
	end

	if state == 0 then
		if state ~= self.attr[AE.state] then
			self.attr[AE.state] = state
			self:onBossStateChanged()
			BattleUIManager:changeODBKState(0)
		end
		BattleUIManager:setOD(percent)
	else
		if state ~= self.attr[AE.state] then
			self.attr[AE.state] = state
			self:onBossStateChanged()
			BattleUIManager:changeODBKState(1)
		end
		self.bkDamage_multi = math.abs(self.attr[AE.bk_hp] - data.bk.bk_n_hp)
		--BattleUIManager:setBK(percent)	
	end
end
