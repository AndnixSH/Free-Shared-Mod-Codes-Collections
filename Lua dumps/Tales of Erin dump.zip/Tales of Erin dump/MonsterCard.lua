MonsterCard = class("MonsterCard",BasicLayer)
MonsterCard.__index   = MonsterCard
MonsterCard.Sp = nil  --spine动画
MonsterCard.sound = nil
MonsterCard.HP = 0
MonsterCard.monsterEnum = 0
MonsterCard.manager = nil
MonsterCard.file = 0
MonsterCard.pos_x = 0
MonsterCard.pos_y = 0
MonsterCard.hit_x = 0
MonsterCard.hit_y = 0
MonsterCard.callBackFuc = nil


function MonsterCard:create(rData)
    local monsterCard = MonsterCard.new()
    monsterCard:init(rData)
    return monsterCard
end

function MonsterCard:init(rData)
    self.manager = rData["manager"]
    self.callBackFuc = rData["callBackFuc"]
    self.HP = rData["hp"]
	self.sound = rData["sound"]
	self.effect = rData["effect"]
	self.pos_x = rData["x"]
	self.pos_y = rData["y"]
	self.hit_x = rData["hit_x"]
	self.hit_y = rData["hit_y"]
	self.file = rData["file"]
	self.Sp = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(rData["file"]))
	self.Sp:setAnimation(1, "loading", true)
end

function MonsterCard:playAnimation(name)
	if self.Sp ==nil then
		return
	end
	if name~="loading" and name ~= "run" then
--		cc.SimpleAudioEngine:getInstance():playEffect(self.sound, false)
    AudioManager:shareDataManager():playMusic(self.sound, 0,true)
		self.Sp:addAnimation(1, name, false)
		self.Sp:addAnimation(1, "loading", true)
    else
		self.Sp:addAnimation(1, name, true)		
	end
end

function MonsterCard:playHit(data)
	 local hitEffect   = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(data["effect"]))
	 hitEffect:setAnimation(1, "effect", false)
	 self.Sp:addChild(hitEffect)
     local m =  math.random()%40 -20;
   hitEffect:setPosition(self.hit_x+m, self.hit_y)
	 hitEffect:registerSpineEventHandler(
	            function (event) 
	            print(string.format("[spine] %d end:", event.trackIndex))
	            local  delay = cc.DelayTime:create(0.1)
                local sequence = cc.Sequence:create(delay, cc.RemoveSelf:create())
	            hitEffect:runAction(sequence)
	end, sp.EventType.ANIMATION_END)

	local rootNode = cc.CSLoader:createNode("uifile/battleNum.csb")
  rootNode:setPosition(self.hit_x+m, self.hit_y)
  self.Sp:addChild(rootNode)
    local panel_1 = rootNode:getChildByTag(1)
    local m_label = ccui.Helper:seekWidgetByTag(panel_1 ,2)
    local action = cc.CSLoader:createTimeline("uifile/battleNum.csb")
	local function showCallBack() 
	      rootNode:stopAllActions()
	      rootNode:removeFromParent()
	end
    action:setLastFrameCallFunc(showCallBack)
    m_label:setString(tostring(data["dmg"]))
    rootNode:runAction(action)
    if data["mode"] == 0 then
       m_label:setFntFile("font/hit_pt.fnt")
       action:play("fly2", false)
    else
       m_label:setFntFile("font/hit_bj.fnt")
       action:play("fly", false)
    end
    


    self.Sp:stopActionByTag(1010)
    self.Sp:setPosition(self.pos_x, self.pos_y)

   local function playNext()
    	self.Sp:setPosition(self.pos_x, self.pos_y)
    end
   local moveby =  cc.MoveBy:create(0.1,cc.p(10,0)) 
   local sequence = cc.Sequence:create(moveby, cc.CallFunc:create(playNext))
   sequence:setTag(1010)
   self.Sp:runAction(sequence)
end

function MonsterCard:pruge()
         if self.Sp ~= nil then
            self.Sp:stopAllActions()
            self.Sp:removeFromParent()
            self.Sp = nil
         end
         self.manager = nil
         self.callBackFuc = nil
         SPCacheManager:removeSPFromCache(self.file)
         self.file = nil
end