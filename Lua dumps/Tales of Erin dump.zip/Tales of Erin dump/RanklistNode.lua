
RanklistNode = class("RanklistNode", XUICellView)
RanklistNode.CS_FILE_NAME = "RanklistNode.csb"
RanklistNode.curId = nil
RanklistNode.head  = nil
RanklistNode.b_robot = 1 -- 是否是机器人
RanklistNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}
function RanklistNode:init(...)
    AchievementNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    return self
end
function RanklistNode:onResetData()

		if not self._data then return end
       
        local dtable = {
            ["rank"]         = self._data[1],            -- 排名
            ["name"]         = self._data[2],            -- 玩家名称
            ["Id"]           = self._data[3],            -- 玩家ID
            ["iconId"]       = self._data[4],            -- 头像id
            ["score"]        = self._data[5],            -- 对应分数
            ["chID"]    = self._data[6],
            ["b_robot"]    = self._data[7] or 1,              --是否是机器人
        }
        self.curId = dtable["Id"]
        self.head  = dtable["iconId"]
        self.b_robot  = dtable["b_robot"]
        local  panelP     = self.PanelList
        local  Formbg     = panelP:getChildByName("Image_personal")
        print("user_info id == "..user_info["id"])
        if user_info["id"] == dtable["Id"] then
            Formbg:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_002.png")
        else
            Formbg:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_001.png")
        end
        --称号
                --称号
        local spineRoot = Formbg:getChildByName("Node_spine")
        if self.skeletonNode then 
            self.skeletonNode:stopAllActions()
            self.skeletonNode:removeFromParent()
        end 

        local id_str = title_conf[tonumber(dtable["chID"])].res_spine
        if cc.FileUtils:getInstance():isFileExist(id_str) then 
            local end_pos = string.find(id_str,'atlas') - 1
            local spName = string.sub(id_str,0,end_pos)

            self.skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
            self.skeletonNode:setAnchorPoint(0,0.5)
            self.skeletonNode:setPosition(0,0)
            spineRoot:setAnchorPoint(0,0.5)
            spineRoot:addChild(self.skeletonNode,1000)

            self.skeletonNode:setAnimation(1, "effect", true)
            local dt = cc.DelayTime:create(0.01)
            local cf = cc.CallFunc:create(function()
                 ---添加spine


                    local size=self.skeletonNode:getBoundingBox()
                    print("getBoundingBox width == "..size.width)
                    self.skeletonNode:setPosition(size.width/2,0)

            end)
            local seq = cc.Sequence:create(dt,cf)
            spineRoot:runAction(seq)
        else 
            print("文件不存在 error file not exist:"..id_str)
        end
        -- 头像
        local  icon       = Formbg:getChildByName("Image_icon")
        local heroid  = tonumber(dtable["iconId"])
        icon:setUnifySizeEnabled(true)
        icon:loadTexture(hero[heroid].hero_bat_icon)
        -- 玩家ID
        local  id         = Formbg:getChildByName("Text_ID")
        id:setString(dtable["Id"])
        -- 玩家名称
        local  naem       = Formbg:getChildByName("Text_name")
        naem:setString(dtable["name"])
        -- 分数
        local  score      = Formbg:getChildByName("Text_num")
        score:setString(dtable["score"])
        -- 排名  1——3 是图片  其他显示文本排名
        local  rank       = Formbg:getChildByName("Text_rank")
        local  iRank      = Formbg:getChildByName("Image_rank")
        if dtable["rank"]     == 1 then 
            iRank:setVisible(true)
            rank:setVisible(false)
            iRank:loadTexture("uifile/n_UIShare/guild/guild_pavilion/ghdg_ui_003.png")
        elseif dtable["rank"] == 2 then
        	rank:setVisible(false)
            iRank:setVisible(true)
            iRank:loadTexture("uifile/n_UIShare/guild/guild_pavilion/ghdg_ui_004.png")
        elseif dtable["rank"] == 3 then
        	rank:setVisible(false)
            iRank:setVisible(true)
            iRank:loadTexture("uifile/n_UIShare/guild/guild_pavilion/ghdg_ui_005.png")
        else
        	iRank:setVisible(false)
            rank:setVisible(true)
            rank:setString(dtable["rank"])
        end 

        local Type  = Formbg:getChildByName("Image_Type")
        if self.defaultIndex == 1 then
            Type:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_003.png")
        elseif self.defaultIndex == 2 then
            Type:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_004.png")
        elseif self.defaultIndex == 3 then
            Type:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_005.png")
        end
        --------------


        -- local function touchCallBack(sender,eventType)
        --     if eventType == ccui.TouchEventType.ended then
        --         local info = {
        --             fromType = 3,  -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息
        --             m_position = nil,--self.GuildMemberTable["tab"][index]["position"], --自己的公会职位
        --             other_infos = {                   --要查看对象的信息
        --                 uid  =  dtable["Id"],
        --                 head =  dtable["iconId"],
        --             }
        --         }
        --         local rcvData = {}
        --         rcvData["info"] =  info
        --         SceneManager:toPlayerInfoLayer(rcvData)
        --     end
        -- end
        -- panelP:addTouchEventListener(touchCallBack)

    

	if self.resetDataEvent then
    	self.resetDataEvent(self)
	end

end
