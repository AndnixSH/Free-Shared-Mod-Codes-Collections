--require "XUIView"

GachaResultView = class("GachaResultView",XUIView)
GachaResultView.CS_FILE_NAME = "GachaResultView.csb"
GachaResultView.CS_BIND_TABLE = {
    panelLight = "/s:panelLight",
    panelDark = "/s:panelDark",

    panelItems = "/s:panelItems",
    -- pitem1 = "/s:panelItems/s:pitem1",
    -- pitem2 = "/s:panelItems/s:pitem2",
    -- pitem3 = "/s:panelItems/s:pitem3",
    -- pitem4 = "/s:panelItems/s:pitem4",
    -- pitem5 = "/s:panelItems/s:pitem5",
    -- pitem6 = "/s:panelItems/s:pitem6",
    -- pitem7 = "/s:panelItems/s:pitem7",
    -- pitem8 = "/s:panelItems/s:pitem8",
    -- pitem9 = "/s:panelItems/s:pitem9",
    -- pitem10 = "/s:panelItems/s:pitem10",

    panelMain = "/s:panelMain",
    pHalo = "/s:panelMain/s:pHalo",
    nodeMain = "/s:panelMain/s:nodeMain",
    pShow = "/s:panelMain/s:pShow",
    pStar = "/s:panelMain/s:pStar",
    nodeLabel = "/s:panelMain/s:nodeLabel",

    nodeMain_Face = "/s:panelMain/s:nodeMain/i:173/i:174",
    nodeMain_New = "/s:panelMain/s:nodeMain/i:173/i:175",

    --nodeLabel_Icon = "/s:panelMain/s:nodeLabel/i:83/i:85"
    nodeLabel_numStone = "/s:panelMain/s:nodeLabel/i:66/i:14",
    nodeLabel_iconStone = "/s:panelMain/s:nodeLabel/i:66/i:15",

    nodeLabel_lbName = "/s:panelMain/s:nodeLabel/i:65/i:15",
    nodeLabel_numAddAtk = "/s:panelMain/s:nodeLabel/i:65/i:7",
    nodeLabel_numAddHP = "/s:panelMain/s:nodeLabel/i:65/i:8",
    nodeLabel_numAddDef = "/s:panelMain/s:nodeLabel/i:65/i:9",
    nodeLabel_numAddCri = "/s:panelMain/s:nodeLabel/i:65/i:10",
    nodeLabel_numAddCriDmg = "/s:panelMain/s:nodeLabel/i:65/i:11",
    nodeLabel_numAddHel = "/s:panelMain/s:nodeLabel/i:65/i:12",
    nodeLabel_panelArrow = "/s:panelMain/s:nodeLabel/i:65/i:13",

    panelDialog = "/s:panelDialog",

    panelResult1x = "/s:panelResult1x",
    num1x = "/s:panelResult1x/i:173/s:num1x",
    type1x = "/s:panelResult1x/i:173/i:155",
    res1x = "/s:panelResult1x/i:173",
    panelResult10x = "/s:panelResult10x",
    num10x = "/s:panelResult10x/i:175/s:num10x",
    type10x = "/s:panelResult10x/i:175/i:152",
    res10x = "/s:panelResult10x/i:175",

    btnSkipAll = "/i:52"
}

function GachaResultView:init(itemList,berylNum,CoinType,finalFunc)
    GachaResultView.super.init(self)

    self.nCoinType = CoinType

    self.videoPlayer = ccexp.VideoPlayer:create()
    self.videoPlayer:setAnchorPoint(cc.p(0.5, 0.5))
    self.videoPlayer:setPosition(640,360)
    self.videoPlayer:setContentSize(cc.size(1280, 720))
    local stoped = false
    self.videoPlayer:addEventListener(function(sender,eventType)
        local function stopfunc()
            if not stoped then
                stoped = true
                self.panelLight:setTouchEnabled(false)
                self.panelLight:setOpacity(255)     
                UITool.delayTask(0,function()  
                    self:nextStep()
                end)
            end
        end

        if eventType == ccexp.VideoPlayerEvent.PLAYING then
            print("ccexp.VideoPlayerEvent.PLAYING")
        elseif eventType == ccexp.VideoPlayerEvent.PAUSED then 
            print("ccexp.VideoPlayerEvent.PAUSED")
            stopfunc()
        elseif eventType == ccexp.VideoPlayerEvent.STOPPED then 
            print("ccexp.VideoPlayerEvent.STOPPED")            
        elseif eventType == ccexp.VideoPlayerEvent.COMPLETED  then 
            print("ccexp.VideoPlayerEvent.COMPLETED")
            local targetPlatform = cc.Application:getInstance():getTargetPlatform()
            if cc.PLATFORM_OS_ANDROID == targetPlatform then
                stopfunc()
            else 
                if self.videoPlayer.isPlaying then 
                else 
                    stopfunc()
                end 
            end
        end
    end)

    self:getRootNode():addChild(self.videoPlayer)

    self.panelLight:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:nextStep()
        end
    end)

    self.btnSkipAll:addClickEventListener(function()
        self:skipBtnCallBack()
    end)
    self.btnSkipAll:setVisible(false)
    --timeline
    
    --   effects/gacha/bo_wen   qiu    xing_xing    zhong_yang
    local psize = nil

    psize = self.pHalo:getSize()
    self.actHalo = sp.SkeletonAnimation:create("effects/gacha/bo_wen/effect.json", "effects/gacha/bo_wen/effect.atlas", 1.0)
    self.pHalo:addChild(self.actHalo)
    self.actHalo:setPosition(cc.p(psize.width/2,psize.height/2))

    self.actMain = cc.CSLoader:createTimeline("EffGaMain.csb")
    self.nodeMain:runAction(self.actMain)

    psize = self.pShow:getSize()
    self.actShow = sp.SkeletonAnimation:create("effects/gacha/zhong_yang/effect.json", "effects/gacha/zhong_yang/effect.atlas", 1.0)
    self.pShow:addChild(self.actShow)
    self.actShow:setPosition(cc.p(psize.width/2,psize.height/2))

    psize = self.pStar:getSize()
    self.actStar = sp.SkeletonAnimation:create("effects/gacha/xing_xing/effect.json", "effects/gacha/xing_xing/effect.atlas", 1.0)
    self.pStar:addChild(self.actStar)
    self.actStar:setPosition(cc.p(psize.width/2,70))

    self.actLabel = cc.CSLoader:createTimeline("EffGaLabel.csb")
    self.nodeLabel:runAction(self.actLabel)

    self.actLabel:play("reset",false)
    self.actMain:play("reset",false)

    self.actHalo:setAnimation(1, "reset", false) 
    self.actStar:setAnimation(1, "reset", false) 
    self.actShow:setAnimation(1, "reset", false) 

    self.dataSet = itemList

    self.isHadNewHero = self:IsHasNewHero()

    if #self.dataSet > 1 then
        --十连
        --EffGaBall.csb
        self.pitems = {}
        self.actItems = {}
        for i = 1,10 do
            local pitem = self.panelItems:getChildByName("pitem"..i)
            local psize = pitem:getSize()                    
            local ball = sp.SkeletonAnimation:create("effects/gacha/qiu/effect.json", "effects/gacha/qiu/effect.atlas", 1.0) 
            ball:setPosition(cc.p(psize.width / 2 ,psize.height / 2))
            pitem:addChild(ball,0,123)

            ball:setAnimation(1, "reset", false) 
            
            self.pitems[i] = pitem
            self.actItems[i] = ball
        end
    end

    if not berylNum then 
        self.res1x:setVisible(false)
        self.res10x:setVisible(false)
    else
        self.num1x:setString(berylNum)
        self.num10x:setString(berylNum)
    end

    if not CoinType then 
        self.res1x:setVisible(false)
        self.res10x:setVisible(false)
    else
        if CoinType == 2 then
            self.type1x:setTexture(UITool:Coin_type(20))
            self.type10x:setTexture(UITool:Coin_type(20))
        elseif CoinType == 1 then
            self.type1x:setTexture(UITool:Coin_type(13))
            self.type10x:setTexture(UITool:Coin_type(13))
        elseif CoinType == 3 then
            self.type1x:setTexture(UITool:Coin_type(22))
            self.type10x:setTexture(UITool:Coin_type(22))
        else
            self.res1x:setVisible(false)
            self.res10x:setVisible(false)
        end
    end

    if self.nodeLabel_iconStone then
        self.nodeLabel_iconStone:setVisible(false)
    end

    self.finalFunc = finalFunc
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        ---
        print("KeyboardManager GachaResultView not registeredKeyBoardEvent")
    end)

    return self
end

function GachaResultView:IsHasNewHero()
    if self.dataSet then
        self.newHeroList = {}
        local bHasNewHero = false
        if #self.dataSet > 0 then
            local n = 1
            for i=1,#self.dataSet do
                if self.dataSet[i].type == 4 then
                    if self.dataSet[i].is_new > 0 then
                        self.newHeroList[n] = i
                        bHasNewHero = true
                        n = n + 1
                    end
                end
            end
        end
        return bHasNewHero
    end
    return false
end

function GachaResultView:skipBtnCallBack()
    if #self.dataSet > 1 then
        if self.isHadNewHero then
            dump(self.newHeroList,"Mself.newHeroList=")
            if #self.newHeroList >= 1 then
                self.currentStep = self.newHeroList[1] * 10 + 1
                self:play10x(self.newHeroList[1])
                --table.remove(self.newHeroList, 1)
            else
                self:skipToResult()
            end
            
        else
            self:skipToResult()
        end
    else
        if self.isHadNewHero then
            dump(self.newHeroList,"Sself.newHeroList=")
            if #self.newHeroList >= 1 then
                self.currentStep = 1
                self:play1x()
                table.remove(self.newHeroList, 1)
            else
                self:skipToResult()
            end
            
        else
            self:skipToResult()
        end
    end
end

  
function GachaResultView:startPlay()
    --cc.SimpleAudioEngine:getInstance():stopAllEffects()
    if not self.dataSet then return end
    if #self.dataSet == 0 then return end

    local rarity = 1 

    for i = 1,#self.dataSet do  
        if self.dataSet[i].rarity > rarity then
            rarity = self.dataSet[i].rarity
        end
    end    

    self.currentStep = 0
    self.videoPlayer:setFileName(DC_MP4[rarity])   
    self.videoPlayer:play()
end

function GachaResultView:skipToResult()
    self.actLabel:stop()
    self.actMain:stop()
    self.actLabel:play("reset",false)
    self.actMain:play("reset",false)

    --  setToSetupPose()
    self.actHalo:clearTracks()
    self.actStar:clearTracks()
    self.actShow:clearTracks()
    self.actHalo:setToSetupPose()
    self.actStar:setToSetupPose()
    self.actShow:setToSetupPose()
    self.actHalo:setAnimation(1, "reset", false) 
    self.actStar:setAnimation(1, "reset", false) 
    self.actShow:setAnimation(1, "reset", false) 
    
    self.panelDark:setOpacity(255)

    self.currentStep = 999
    --评分
    if g_channel_control.openStoreView and SDKManagerLua.storeView then
        SDKManagerLua:storeView(self.dataSet)
    end
    if #self.dataSet > 1 then
        --十连

        for i = 1,10 do
            self.actItems[i]:clearTracks()
            self.actItems[i]:setToSetupPose()
            self.actItems[i]:setAnimation(1, "reset", false) 
        end

        self:showResult10x()
    else
        --其他
        self:showResult1x()
    end
end

function GachaResultView:nextStep()
    --currentStep 
    -- 0  播放视频
    -- 1  单抽第一阶段
    -- 2  单抽角色对话
    -- 3  角色淡出
    -- 10 十连中心爆炸
    -- 11,12,13
    -- 101,102,103 十连各阶段
    -- 999 最终结果

    if not self.currentStep or self.currentStep < 0 then
        self:startPlay()
    elseif self.currentStep == 0 then
        --播放特效
        self.videoPlayer:addEventListener(function()end)
        self.videoPlayer:stop()
        self.videoPlayer:removeFromParent()
        self.videoPlayer = nil

        self.panelLight:setOpacity(255)
        self.panelLight:setTouchEnabled(true)
        self.btnSkipAll:setVisible(true)
        
        --self.videoPlayer:stop()
        -- self.videoPlayer:setVisible(false)
        -- self.videoPlayer:addEventListener(function()end)
        --此处开始播特效
        if #self.dataSet > 1 then
            --十连
            self.currentStep = 10
            self.panelLight:runAction(cc.FadeOut:create(0.67))
            self:play10xReady()
        else
            self.currentStep = 1
            --self.panelDark:runAction(cc.FadeIn:create(0.15))
            self.panelDark:setOpacity(255)
            self.panelLight:runAction(cc.FadeOut:create(0.5))
            self:play1x()
        end
    elseif self.currentStep < 10 then
        --单抽各阶段
        self.actMain:stop()
        if self.currentStep == 1 then
            self.actHalo:clearTracks()            
            self.actHalo:setToSetupPose()
            self.actHalo:setAnimation(1, "reset", false) 
            self.actShow:clearTracks()
            self.actShow:setToSetupPose()
            self.actShow:setAnimation(1, "reset", false) 
            --有剧情则 放剧情 没剧情则放淡出
            --if self.dialogItems ~= nil then
            if self.dialogFileName ~= nil then
                self.currentStep = 2
                self.actMain:play("forceshow",false)
                --self.panelDialog:setVisible(true)
                --self:nextStep()
                self:playDialog(self.dialogFileName)
            else
                self.currentStep = 3
                self.actMain:play("fadeout",false)
            end
        elseif self.currentStep == 2 then
            --播放一句剧情，播放完则淡出
            -- self.dialogIndex = self.dialogIndex + 1 
            -- if self.dialogIndex > #self.dialogItems then
            --     self.panelDialog:setVisible(false)
                self.currentStep = 3
                self.actMain:play("fadeout",false)
            -- else
            --     self:playDialog()
            -- end
        elseif self.currentStep == 3 then
            --淡出结束，全体reset,展示结果页
            self:skipToResult()
            -- self.currentStep = 999
            -- self:showResult1x() 
        end
    elseif self.currentStep == 10 then
        --十连中心爆炸        
        self.actShow:setCompleteListener(function()end)
        self.actShow:clearTracks()
        self.actShow:setToSetupPose()
        self.actShow:setAnimation(1, "reset", false) 
        --self.actShow:clearFrameEventCallFunc()
        --self.panelDark:runAction(cc.FadeIn:create(0.15))
        self.panelDark:setOpacity(255)

        self.currentStep = 11
        self:play10x(1)
    elseif self.currentStep < 999 then
        --十连抽各个阶段
        local idx = math.floor(self.currentStep / 10)
        local step = self.currentStep % 10

        self.actMain:stop()
        if step == 1 then
            self.actHalo:clearTracks()
            self.actHalo:setToSetupPose()
            self.actHalo:setAnimation(1, "reset", false) 
            self.actShow:clearTracks()
            self.actShow:setToSetupPose()
            self.actShow:setAnimation(1, "reset", false) 
            self.actItems[idx]:clearTracks()
            self.actItems[idx]:setToSetupPose()
            self.actItems[idx]:setAnimation(1, "reset", false) 

            --有剧情则 放剧情 没剧情则放淡出
            --if self.dialogItems ~= nil then
            if self.dialogFileName ~= nil then
                self.currentStep = idx * 10 + 2
                self.actMain:play("forceshow",false)
                -- self.panelDialog:setVisible(true)
                -- self:nextStep()
                self:playDialog(self.dialogFileName)
            else
                self.currentStep = idx * 10 + 3
                self.actMain:play("fadeout",false)
            end
        elseif step == 2 then        
            -- self.dialogIndex = self.dialogIndex + 1 
            -- if self.dialogIndex > #self.dialogItems then
            --     self.panelDialog:setVisible(false)
                self.currentStep = idx * 10 + 3
                self.actMain:play("fadeout",false)
            -- else
            --     self:playDialog()
            -- end            
        elseif step == 3 then
            if idx < #self.dataSet then
                --播放下一个
                self.currentStep = (idx + 1) * 10 + 1
                self:play10x(idx + 1)
            else
                --显示结果
                self:skipToResult()
                -- self.currentStep = 999
                -- self:showResult10x()
            end
        end
    else
        if self.finalFunc then
            self.finalFunc()
        end
        
        self:returnBack()
    end
end

function GachaResultView:play1x()
    local dat = self.dataSet[1]
    local rarity = dat.rarity

    local ischange = nil
    local isshowstart = nil
    local strshow = nil
    local strhalo = nil
    local strstar = nil
    local strstarfadeout = nil
    local strstarend = nil
    local effpath = nil
    --隐藏是否为新
    
    if rarity == 5 then
        strshow = "PtShow"
        strhalo = "PtHalo"
        strstar = "PtStar"
        strstarend = "PtEnd"
        strstarfadeout = "PtFadeOut"
        effpath = "music/ui/gacha_r5.mp3"
    elseif rarity == 4 then
        strshow = "AuShow"
        strhalo = "AuHalo"
        strstar = "AuStar"
        strstarend = "AuEnd"
        strstarfadeout = "AuFadeOut"
        effpath = "music/ui/gacha_r4.mp3"
    else
        strshow = "AgShow"
        strhalo = "AgHalo"
        strstar = "AgStar"
        strstarend = "AgEnd"
        strstarfadeout = "AgFadeOut"
        effpath = "music/ui/gacha_r3.mp3"
    end

    ischange,isshowstart = self:fillContent(1)

    self.actMain:setFrameEventCallFunc(function(frame)
        local fn = frame:getEvent()
        
        if fn == "watingend" then
            self.actShow:clearTracks()
            self.actShow:setToSetupPose()
            self.actShow:setAnimation(2,strshow,false)  --
            self.actMain:play("show",false)
           -- cc.SimpleAudioEngine:getInstance():playEffect(effpath,false)
           AudioManager:shareDataManager():playMusic(effpath,0, false)

        elseif fn == "f14" then
            self.actHalo:clearTracks()
            self.actHalo:setToSetupPose()
            self.actHalo:setAnimation(2,strhalo,false)
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()
                self.actStar:setAnimation(2,strstar,false)
            end
            --如果是转化，则播放转化
            if ischange then
                self.actLabel:play("show"..ischange,false)
            end
        elseif fn == "f30" then
            -- if self.dialogItems ~= nil then
                self:nextStep()
            -- else
            --     self.actMain:play("fadeout",false)
            -- end
            -- 动画结束，展示剧情或淡出
        elseif fn == "lastframe" then
            --动画结束，进入下一阶段
            self:nextStep()
        elseif fn == "startfadeout" then
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()
                self.actStar:setAnimation(3,strstarfadeout,false)
            end
            if ischange then
                self.actLabel:play("fadeout"..ischange,false)
            end
        elseif fn == "forceshow" then        
            if isshowstart then
                self.actStar:setAnimation(4,strstarend,false)
            end
            if ischange then
                self.actLabel:play("showend"..ischange,false)
            end
        end
    end)

    -- self.actShow:play(strshow,false) 
    -- self.actMain:play("show",false)
    -- cc.SimpleAudioEngine:getInstance():playEffect(effpath,false)

    self.actMain:play("waiting3",false)

    self.actHalo:clearTracks()
    self.actHalo:setToSetupPose()
    self.actHalo:setAnimation(1,"reset",false)
    self.actStar:clearTracks()
    self.actStar:setToSetupPose()
    self.actStar:setAnimation(1,"reset",false)
    self.actLabel:play("reset",false)
end

function GachaResultView:play10xReady()
    for i = 1,#self.dataSet do
        self.actItems[i]:clearTracks()
        self.actItems[i]:setToSetupPose()
        if self.dataSet[i].rarity == 5 then
            self.actItems[i]:setAnimation(11,"PtBall",true)
        elseif self.dataSet[i].rarity == 4 then
            self.actItems[i]:setAnimation(11,"AuBall",true)
        else
            self.actItems[i]:setAnimation(11,"AgBall",true)
        end
    end
    self.actShow:setCompleteListener(function(trackIndex,loopCount)
        if trackIndex == 99 then
            self:nextStep()
        end
    end)
    self.actShow:clearTracks()
    self.actShow:setToSetupPose()
    self.actShow:setAnimation(99,"CenterExp",false)
end


function GachaResultView:play10x(idx)

    if self.newHeroList then
        if #self.newHeroList > 0 then
            for i=1,#self.newHeroList do
                if self.newHeroList[i] == idx then
                    table.remove(self.newHeroList, i)
                end
            end
        end
    end

    local dat = self.dataSet[idx]
    local rarity = dat.rarity

    local ischange = nil
    local isshowstart = nil
    local strshow = nil
    local strhalo = nil
    local strstar = nil
    local strstarfadeout = nil
    local strstarend = nil
    local strexp = nil
    local effpath = nil
    --隐藏是否为新
    
    if rarity == 5 then
        strshow = "PtShow"
        strhalo = "PtHalo"
        strstar = "PtStar"
        strstarend = "PtEnd"
        strstarfadeout = "PtFadeOut"
        strexp = "PtBallExp"
        effpath = "music/ui/gacha_r5.mp3"
    elseif rarity == 4 then
        strshow = "AuShow"
        strhalo = "AuHalo"
        strstar = "AuStar"
        strstarend = "AuEnd"
        strstarfadeout = "AuFadeOut"
        strexp = "AuBallExp"
        effpath = "music/ui/gacha_r4.mp3"
    else
        strshow = "AgShow"
        strhalo = "AgHalo"
        strstar = "AgStar"
        strstarend = "AgEnd"
        strstarfadeout = "AgFadeOut"
        strexp = "AgBallExp"
        effpath = "music/ui/gacha_r3.mp3"
    end

    ischange,isshowstart = self:fillContent(idx)

    self.actItems[idx]:clearTracks()
    self.actItems[idx]:setToSetupPose()
    self.actItems[idx]:setAnimation(8,strexp,false)

    self.actMain:setFrameEventCallFunc(function(frame)
        local fn = frame:getEvent()
        if fn == "watingend" then
            self.actShow:clearTracks()
            self.actShow:setToSetupPose()
            self.actShow:setAnimation(2,strshow,false)  --
            self.actMain:play("show",false)
            --cc.SimpleAudioEngine:getInstance():playEffect(effpath,false)
            AudioManager:shareDataManager():playMusic(effpath,0, false)

                    
            if idx < #self.dataSet then
                for i = idx + 1 , #self.dataSet do
                    self.pitems[i]:runAction(cc.FadeOut:create(0.3))
                end
            end
        elseif fn == "f14" then
            self.actHalo:clearTracks()
            self.actHalo:setToSetupPose()
            self.actHalo:setAnimation(3,strhalo,false)
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()
                self.actStar:setAnimation(3,strstar,false)
            end
            --如果是转化，则播放转化
            if ischange then
                self.actLabel:play("show"..ischange,false)
            end
        elseif fn == "f30" then
            -- if self.dialogItems ~= nil then
                self:nextStep()
            -- else
            --     self.actMain:play("fadeout",false)
            -- end
            -- 动画结束，展示剧情或淡出
        elseif fn == "lastframe" then
            --动画结束，进入下一阶段
            self:nextStep()
        elseif fn == "startfadeout" then
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()        
                self.actStar:setAnimation(4,strstarfadeout,false)
            end
            if ischange then
                self.actLabel:play("fadeout"..ischange,false)
            end         
            
            if idx < #self.dataSet then
                for i = idx + 1 , #self.dataSet do
                    self.pitems[i]:runAction(cc.FadeIn:create(0.3))
                end
            end
        elseif fn == "forceshow" then
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()   
                self.actStar:setAnimation(5,strstarend,false)
            end
            if ischange then
                self.actLabel:play("showend"..ischange,false)
            end         
        end
    end)

    if rarity >= 4 then
        self.actMain:play("waiting",false)
    else
        self.actMain:play("waiting3",false)
    end
    
    for i = 1 , #self.dataSet do
        self.pitems[i]:stopAllActions()
        self.pitems[i]:setOpacity(255)
    end

    self.actHalo:clearTracks()
    self.actHalo:setToSetupPose()   
    self.actHalo:setAnimation(1,"reset",false)
    self.actStar:clearTracks()
    self.actStar:setToSetupPose()   
    self.actStar:setAnimation(1,"reset",false)
    self.actLabel:play("reset",false)
end

--[[
  "get": [
    {
      "story": "hero_36",
      "id": 36,
      "type": 4,
      "is_new": 0,
      "change_to": {
          "is_full":0,
          "hero_add": {
              "atk":14,
              "hp":39,
              "def":13,
              "crit":0,
              "crit_dmg":0,
              "hel":0,
              },
            "add_beryl":0

      },
      "element": 2,
      "rarity": 4,
      "in_mail": 0
    }
  ],
  ]]
function GachaResultView:fillContent(idx)
    local dat = self.dataSet[idx]
    local ischange = nil
    local isshowstart = false
    if dat.change_to ~= nil
        and next(dat.change_to) ~= nil then

        if dat.change_to.is_full == 0 then
            --加了属性
            ischange = 1

            local temptable ={
                {
                    ctr = self.nodeLabel_numAddAtk,
                    num = dat.change_to.hero_add.atk
                },
                {
                    ctr = self.nodeLabel_numAddHP,
                    num = dat.change_to.hero_add.hp
                },
                {
                    ctr = self.nodeLabel_numAddDef,
                    num = dat.change_to.hero_add.def
                },
                {
                    ctr = self.nodeLabel_numAddCri,
                    num = dat.change_to.hero_add.crit
                },
                {
                    ctr = self.nodeLabel_numAddCriDmg,
                    num = dat.change_to.hero_add.crit_dmg
                },
                {
                    ctr = self.nodeLabel_numAddHel,
                    num = dat.change_to.hero_add.hel
                }
            }
            self.nodeLabel_panelArrow:removeAllChildren()

            for _, p in ipairs(temptable) do
            -- for i = 1,#temptable do
            --     local p = temptable[i]
                p.ctr:setString("+"..p.num)

                if p.num > 0 then
                    local sp = cc.Sprite:create()
                    local posx,posy = p.ctr:getPosition()
                    sp:setAnchorPoint(cc.p(0,0.5))
                    sp:setPosition(posx + 10, posy)
                    sp:setScale(0.8)
                    sp:setTexture("n_UIShare/gacha/ck_ui_016.png")
                    self.nodeLabel_panelArrow:addChild(sp)

                    sp:runAction(
                        cc.RepeatForever:create(
                            cc.Sequence:create(
                                cc.MoveBy:create(0.2,cc.p(0,3)),
                                cc.MoveBy:create(0.2,cc.p(0,-3))
                            )
                            )
                        )
                end
            end

        elseif dat.change_to.is_full == 1 then
            --加了苍玉
            ischange = 2
            if self.nCoinType == 1 then
                self.nodeLabel_numStone:setString(UITool.ToLocalization("转化为")..dat.change_to.add_beryl..UITool.ToLocalization("苍玉"))
                self.nodeLabel_iconStone:setTexture(UITool:Coin_type(13))
            else
                self.nodeLabel_numStone:setString(UITool.ToLocalization("转化为")..dat.change_to.add_dragon..UITool.ToLocalization("王召之徽"))
                self.nodeLabel_iconStone:setTexture(UITool:Coin_type(20))
            end
            if self.nodeLabel_iconStone then
                self.nodeLabel_iconStone:setVisible(false)
            end
        end
        -- if dat.type == 4 then
        --     ischange = true
        --     self.nodeLabel_Icon:setTexture(hero[dat.id].hero_lb_icon)
        -- end
        -- dat = dat.change_to
    end
    
    -- self.dialogIndex = nil
    -- self.dialogItems = nil
    self.dialogFileName = nil

    local facepath = nil
    if dat.type == 3 then
        --装备
        facepath = equip[dat.id].equip_vdw_icon
        isshowstart = true
    elseif dat.type == 4 then
        --英雄        
        self.nodeLabel_lbName:setString(UITool.getUserLanguage(hero[dat.id].hero_name)..UITool.ToLocalization("的能力额外提升了！"))--(hero[dat.id].hero_name..UITool.ToLocalization("的能力额外提升了！"))

        facepath = hero[dat.id].hero_vcw_icon
        if dat.is_new == 1 and dat.story ~= nil then
            -- self.dialogIndex = 0
            -- self.dialogItems = {"",""}
            local dialogfile = "story/"..dat.story..".json"
            self.dialogFileName = dialogfile
        end
        isshowstart = true
    else
        local infoTable = UITool.getItemInfos(dat.type,dat.id)
        facepath = infoTable[2]
    end

    if facepath and self.nodeMain_Face then
        self.nodeMain_Face:setTexture(facepath)
    end

    if dat.is_new == 1 then
        self.nodeMain_New:setVisible(true)
    else
        self.nodeMain_New:setVisible(false)
    end

    return ischange,isshowstart
end

function GachaResultView:playDialog(filename)
    --
    if GameManagerInst.gameType == 2 then
        local param = {}
        param["rcvData"] = {}
        param["rcvData"]["filename"] = filename
        param["rcvData"]["callFunc"] = function ( obj )
            self._rootNode:removeChildByTag(999)
            self:nextStep()
        end 
        param["rcvData"]["obj"] = self 
        self._rootNode:addChild(DialogLayer:create(param).uiLayer,10,999)
    end
end

function GachaResultView:showResult1x()
    self.btnSkipAll:setVisible(false)
    self.panelResult1x:setVisible(true)

    local dat = self.dataSet[1]
    local sprite = nil

    if dat.change_to ~= nil
        and next(dat.change_to) ~= nil
        and dat.change_to.is_full == 1 then

        if dat.change_to.add_beryl > dat.change_to.add_dragon then
            sprite = REBaseIconView:initCoin(8, 4, dat.change_to.add_beryl, false)
            sprite:addItemInfo(13,0,dat.change_to.add_beryl,nil)
        else
            sprite = REBaseIconView:initCoin(13, 4, dat.change_to.add_dragon, false)
            sprite:addItemInfo(20,0,dat.change_to.add_dragon,nil)
        end
    else

        if dat.type == 3 then
            --装备
            sprite = REBaseIconView.new():initEquip(dat.id,dat.is_new == 1)
            sprite:addItemInfo(3,dat.id,nil,{rsk = table.deepcopy(dat.rsk)})
            if dat.rarity > 4 then
                NoticeManager:insertEquipNotice(dat.id)
            end 

        elseif dat.type == 4 then
            --角色
            sprite = REBaseIconView.new():initHero(dat.id,dat.is_new == 1)
            sprite:addItemInfo(4,dat.id,nil,nil)            
            if dat.rarity > 4 and dat.is_new == 1 then
                NoticeManager:insertRoleNotice(dat.id)
            end 
            if g_channel_control.b_facebook then
                if dat.rarity >= fb_limit["rarity_max"] then
                    self:sendFacebookRate()
                end
            end
        else
            sprite = REBaseIconView.new():initItem(dat.type,dat.id,dat.num,dat.is_new == 1)
            if dat.num > 1 then
                sprite:addItemInfo(dat.type,dat.id,dat.num,nil)
            else
                sprite:addItemInfo(dat.type,dat.id,nil,nil)
            end
        end
    end

    if sprite then
        self.panelResult1x:getChildByName("icon0"):addChild(sprite:getRootNode())
    end
end

function GachaResultView:showResult10x()
    self.btnSkipAll:setVisible(false)
    self.panelResult10x:setVisible(true)
    local facebookNum = 1
    for i = 1,#self.dataSet do

        local dat = self.dataSet[i]
        local sprite = nil

        if dat.change_to ~= nil
            and next(dat.change_to) ~= nil 
            and dat.change_to.is_full == 1 then

            if dat.change_to.add_beryl > dat.change_to.add_dragon then
                sprite = REBaseIconView:initCoin(8, 4, dat.change_to.add_beryl, false)
                sprite:addItemInfo(13,0,dat.change_to.add_beryl,nil)
            else
                sprite = REBaseIconView:initCoin(13, 4, dat.change_to.add_dragon, false)
                sprite:addItemInfo(20,0,dat.change_to.add_dragon,nil)
            end
        else            
            if dat.type == 3 then
                --装备
                sprite = REBaseIconView.new():initEquip(dat.id,dat.is_new == 1)
                sprite:addItemInfo(3,dat.id,nil,{rsk = table.deepcopy(dat.rsk)})
                if dat.rarity > 4 then
                    NoticeManager:insertEquipNotice(dat.id)
                end 
            elseif dat.type == 4 then
                --角色
                sprite = REBaseIconView.new():initHero(dat.id,dat.is_new == 1)
                sprite:addItemInfo(4,dat.id,nil,nil)
                if dat.rarity > 4 and dat.is_new == 1 then
                    NoticeManager:insertRoleNotice(dat.id)
                end 
                if g_channel_control.b_facebook then
                    if dat.rarity >= fb_limit["rarity_max"] then
                        if facebookNum == 1 then
                            facebookNum = facebookNum +1
                            self:sendFacebookRate()
                        end
                    end
                    -- local sData = {}
                    -- sData["facebook_id"] = 6--t_data["data"]["facebook_id"]
                    -- SceneManager:fackBookShowBox(sData)
                end
            else
                sprite = REBaseIconView.new():initItem(dat.type,dat.id,dat.num,dat.is_new == 1)
                if dat.num > 1 then
                    sprite:addItemInfo(dat.type,dat.id,dat.num,nil)
                else
                    sprite:addItemInfo(dat.type,dat.id,nil,nil)
                end
            end
        end

        if sprite then
            self.panelResult10x:getChildByName("icon"..i):addChild(sprite:getRootNode())
        end
    end

end
--获取facebook评分数据
function GachaResultView:sendFacebookRate( ... )
    local function reiceSthCallBack(data)
        
        print("facebook 获取评分数据")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if SceneManager ~= nil then
            SceneManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["facebook_state"] == 1 then  -- 1是弹窗 0禁用
            print("进入了这里")
            local sData = {}
            sData["facebook_id"] = t_data["data"]["facebook_id"]
            SceneManager:fackBookShowBox(sData)
        end

    end

    local cjson = require "cjson"
    SceneManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_facebook_rate",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function GachaResultView:returnBack()
    if self._navigationView then
        self._navigationView:popView()
    end
end

function GachaResultView:onNavigateTo(isback)
    if not isback then
        self:startPlay()
    end
end
