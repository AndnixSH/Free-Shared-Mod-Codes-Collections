
--[[
    
    置灰工具类

    使用方法
    1、置灰
    local grayImage = ccui.ImageView:create("")
    lemon.GraphicsGrayUtil:setGray(lockImage)
    
    2、移除置灰
    local grayImage = ccui.ImageView:create("")
    lemon.GraphicsGrayUtil:setRemoveGray(lockImage)
]]
    







lemon = lemon or {}
lemon.GraphicsGrayUtil =   {}
local GraphicsGrayUtil = lemon.GraphicsGrayUtil



local ShaderEffect = {

        vertDefaultSource = "\n"..
        "attribute vec4 a_position; \n" ..
        "attribute vec2 a_texCoord; \n" ..
        "attribute vec4 a_color; \n"..                                                    
        "#ifdef GL_ES  \n"..
        "varying lowp vec4 v_fragmentColor;\n"..
        "varying mediump vec2 v_texCoord;\n"..
        "#else                      \n" ..
        "varying vec4 v_fragmentColor; \n" ..
        "varying vec2 v_texCoord;  \n"..
        "#endif    \n"..
        "void main() \n"..
        "{\n" ..
        "gl_Position = CC_PMatrix * a_position; \n"..
        "v_fragmentColor = a_color;\n"..
        "v_texCoord = a_texCoord;\n"..
        "}",

        pszFragSource2 = "#ifdef GL_ES \n" ..
        "precision mediump float; \n" ..
        "#endif \n" ..
        "uniform sampler2D u_texture; \n" ..
        "varying vec2 v_texCoord; \n" ..
        "varying vec4 v_fragmentColor;\n"..
        "uniform vec2 pix_size;\n"..
        "void main(void) \n" ..
        "{ \n" ..
        "vec4 sum = vec4(0, 0, 0, 0); \n" ..
        "sum += texture2D(u_texture, v_texCoord - 4.0 * pix_size) * 0.05;\n"..
        "sum += texture2D(u_texture, v_texCoord - 3.0 * pix_size) * 0.09;\n"..
        "sum += texture2D(u_texture, v_texCoord - 2.0 * pix_size) * 0.12;\n"..
        "sum += texture2D(u_texture, v_texCoord - 1.0 * pix_size) * 0.15;\n"..
        "sum += texture2D(u_texture, v_texCoord                 ) * 0.16;\n"..
        "sum += texture2D(u_texture, v_texCoord + 1.0 * pix_size) * 0.15;\n"..
        "sum += texture2D(u_texture, v_texCoord + 2.0 * pix_size) * 0.12;\n"..
        "sum += texture2D(u_texture, v_texCoord + 3.0 * pix_size) * 0.09;\n"..
        "sum += texture2D(u_texture, v_texCoord + 4.0 * pix_size) * 0.05;\n"..
        "gl_FragColor = sum;\n"..
        "}",

        --变灰 1
        psGrayShader = "#ifdef GL_ES \n" ..
        "precision mediump float; \n" ..
        "#endif \n" ..
        "varying vec4 v_fragmentColor; \n" ..
        "varying vec2 v_texCoord; \n" ..
        "void main(void) \n" ..
        "{ \n" ..
        "vec4 c = texture2D(CC_Texture0, v_texCoord); \n" ..
        "gl_FragColor.xyz = vec3(0.299*c.r + 0.587*c.g +0.114*c.b); \n"..
        "gl_FragColor.w = c.w; \n"..
        "}" ,

        --移除变灰
        psRemoveGrayShader = "#ifdef GL_ES \n" ..
        "precision mediump float; \n" ..
        "#endif \n" ..
        "varying vec4 v_fragmentColor; \n" ..
        "varying vec2 v_texCoord; \n" ..
        "void main(void) \n" ..
        "{ \n" ..
        "gl_FragColor = texture2D(CC_Texture0, v_texCoord); \n" ..
        "}" ,

        pszFragSource1 = "#ifdef GL_ES \n" ..
        "precision mediump float; \n" ..
        "#endif \n" ..
        "varying vec4 v_fragmentColor; \n" ..
        "varying vec2 v_texCoord; \n" ..
        "void main(void) \n" ..
        "{ \n" ..
        "vec4 c = texture2D(CC_Texture0, v_texCoord); \n" ..
        "gl_FragColor.xyz = vec3(0.3*c.r + 0.15*c.g +0.11*c.b); \n"..
        "gl_FragColor.w = c.w; \n"..
        "}" ,

}


--==============================================================
--======================= 公有函数 ===============================
--==============================================================



function GraphicsGrayUtil:setGray(node)
    if node == nil then
        print("GraphicsGrayUtil error: node should not be null")
        return
    end

    if node.getVirtualRenderer then
        local tSprite = nil;
        local virtualRender =  node:getVirtualRenderer();
        if virtualRender ~= nil then
            tSprite = virtualRender:getSprite()
        end
        if tSprite ~= nil then
             self:_addGrayNode(tSprite)  
        end
             
    elseif node.setGLProgram then
        self:_addGrayNode(node)
    end
    
end


--遍历取消变灰
function GraphicsGrayUtil:setRemoveGray(node)
    if node == nil then
        print("GraphicsGrayUtil error: node should not be null")
        return
    end

    if node.getVirtualRenderer then
        local tSprite = nil;
        local virtualRender =  node:getVirtualRenderer();
        if virtualRender ~= nil then
            tSprite = virtualRender:getSprite()
        end
        if tSprite ~= nil then
             self:removeGrayNode(tSprite)  
        end
        
    elseif node.setGLProgram then
        self:_removeGrayNode(node)
    end

end


--==============================================================
--======================= 私有函数 ===============================
--==============================================================

--创建 灰色 program
function GraphicsGrayUtil:_createGrayProgram()
    local pGrayProgram = cc.GLProgram:createWithByteArrays(ShaderEffect.vertDefaultSource,ShaderEffect.psGrayShader)
    pGrayProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION,cc.VERTEX_ATTRIB_POSITION)
    pGrayProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR,cc.VERTEX_ATTRIB_COLOR)
    pGrayProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD,cc.VERTEX_ATTRIB_FLAG_TEX_COORDS)
    pGrayProgram:link()
    pGrayProgram:use()
    pGrayProgram:updateUniforms()
    return pGrayProgram
end

--创建 移除灰色 program
function GraphicsGrayUtil:_createRemoveGrayProgram()
   
    local pRemoveGrayProgram = cc.GLProgram:createWithByteArrays(ShaderEffect.vertDefaultSource,ShaderEffect.psRemoveGrayShader)
    pRemoveGrayProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION,cc.VERTEX_ATTRIB_POSITION)
    pRemoveGrayProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR,cc.VERTEX_ATTRIB_COLOR)
    pRemoveGrayProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD,cc.VERTEX_ATTRIB_FLAG_TEX_COORDS)
    pRemoveGrayProgram:link()
    pRemoveGrayProgram:use()
    pRemoveGrayProgram:updateUniforms()
    return pRemoveGrayProgram
end

--获得 灰色 program
function GraphicsGrayUtil:_getGrayProgram()
    local pProgram = cc.GLProgramCache:getInstance():getGLProgram("pGrayProgram")
    dump(pProgram, "pProgram")
    if pProgram == nil then
        pProgram = self:_createGrayProgram()
        cc.GLProgramCache:getInstance():addGLProgram(pGrayProgram,"pGrayProgram")
    end
    return pProgram
end

--获得 移除灰色 program
function GraphicsGrayUtil:_getRemoveGrayProgram()
    local pProgram = cc.GLProgramCache:getInstance():getGLProgram("pRemoveGrayProgram")
    if pProgram == nil then
        pProgram = self:_createRemoveGrayProgram()
        cc.GLProgramCache:getInstance():addGLProgram(pGrayProgram,"pRemoveGrayProgram")
    end
    return pProgram
end


function GraphicsGrayUtil:_addGrayNode(node)
    local pProgram = self:_getGrayProgram()
    if node.setGLProgram then
        node:setGLProgram(pProgram)
    end
    
end

function GraphicsGrayUtil:_removeGrayNode(node)
    local pProgram = self:_getRemoveGrayProgram()
    if node.setGLProgram then
        node:setGLProgram(pProgram)
    end
end

