achi_act_8013_conf={} 
achi_act_8013_conf[1] = {
        id= 1,
        achi_name= "616238",
        achi_desc= "601084",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[2] = {
        id= 2,
        achi_name= "616239",
        achi_desc= "601085",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[3] = {
        id= 3,
        achi_name= "616240",
        achi_desc= "601086",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[4] = {
        id= 4,
        achi_name= "616241",
        achi_desc= "601087",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[5] = {
        id= 5,
        achi_name= "616242",
        achi_desc= "613311",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[6] = {
        id= 6,
        achi_name= "616243",
        achi_desc= "601088",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[7] = {
        id= 7,
        achi_name= "616244",
        achi_desc= "601089",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[8] = {
        id= 8,
        achi_name= "616245",
        achi_desc= "601090",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[9] = {
        id= 9,
        achi_name= "616246",
        achi_desc= "601091",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[10] = {
        id= 10,
        achi_name= "616463",
        achi_desc= "616252",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[11] = {
        id= 11,
        achi_name= "616464",
        achi_desc= "616455",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[12] = {
        id= 12,
        achi_name= "616465",
        achi_desc= "616456",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[13] = {
        id= 13,
        achi_name= "616247",
        achi_desc= "613312",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[14] = {
        id= 14,
        achi_name= "616248",
        achi_desc= "601095",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[15] = {
        id= 15,
        achi_name= "616249",
        achi_desc= "601096",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_8013_conf[16] = {
        id= 16,
        achi_name= "616251",
        achi_desc= "601097",
        achi_icon= "icons/achiv/cjxt_001.png",

} 