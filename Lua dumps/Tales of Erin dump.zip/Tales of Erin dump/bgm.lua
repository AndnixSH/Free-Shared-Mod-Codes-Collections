BGM = {}   
BGM[1] = {
        Name="日常",
        File="b1.mp3",
        TableName = "BGM"
    }    
BGM[2] = {
        Name="敌人来袭",
        File="b2.mp3",
        TableName = "BGM"
    }    
BGM[3] = {
        Name="战斗1",
        File="b3.mp3",
        TableName = "BGM"
    }    
BGM[4] = {
        Name="战斗2（帝国军）",
        File="b4.mp3",
        TableName = "BGM"
    }    
BGM[5] = {
        Name="沉静的斗志",
        File="b5.mp3",
        TableName = "BGM"
    }    
BGM[6] = {
        Name="帝国将军1 intro",
        File="b6.mp3",
        TableName = "BGM"
    }    
BGM[7] = {
        Name="帝国将军1 loop",
        File="b7.mp3",
        TableName = "BGM"
    }    
BGM[8] = {
        Name="战斗胜利",
        File="b8.mp3",
        TableName = "BGM"
    }    
BGM[9] = {
        Name="女主角",
        File="b9.mp3",
        TableName = "BGM"
    }    
BGM[10] = {
        Name="安国神",
        File="b10.mp3",
        TableName = "BGM"
    }    
BGM[11] = {
        Name="斯库尔",
        File="b11.mp3",
        TableName = "BGM"
    }    
BGM[12] = {
        Name="极冰王",
        File="b12.mp3",
        TableName = "BGM"
    }    
BGM[13] = {
        Name="霸道公",
        File="b13.mp3",
        TableName = "BGM"
    }    
BGM[14] = {
        Name="方舟天使",
        File="b14.mp3",
        TableName = "BGM"
    }    
BGM[15] = {
        Name="战斗（素材本）",
        File="b15.mp3",
        TableName = "BGM"
    }
BGM[16] = {
    Name="战斗（素材本）",
    File="b16.mp3",
    TableName = "BGM"
}
BGM[17] = {
    Name="战斗（素材本）",
    File="b17.mp3",
    TableName = "BGM"
}
BGM[18] = {
    Name="战斗（素材本）",
    File="b18.mp3",
    TableName = "BGM"
}
BGM[19] = {
    Name="战斗（素材本）",
    File="b19.mp3",
    TableName = "BGM"
}
BGM[20] = {
    Name="光BOSS",
    File="b20.mp3",
    TableName = "BGM"
}
BGM[21] = {
    Name="誓约音效",
    File="b21.mp3",
    TableName = "BGM"
}