--释放自身类技能中。（范围攻击）

--created by kobejaw.2018.4.27.
State_PlayingSkill_Self = class("State_PlayingSkill_Self",StateBase)

function State_PlayingSkill_Self:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.PlayingSkill_Self
	self.isSkill = true
	self.correctValue = 100 --修正值。hit_rec矩形边长扩充，否则大体积的怪经常打不到人。
end

function State_PlayingSkill_Self:Enter(skillInfo)
	self.skillInfo = skillInfo;
	self.super.Enter(self)
end

function State_PlayingSkill_Self:Exit()
	self.super.Exit(self)
end
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
function State_PlayingSkill_Self:onSpineEventCallback(event)
	
	--震屏，闪烁等处理
	self:dealWithCommonEvents(event,self.skillInfo)

	--突进
	result1,result2 = self:checkIsDart(event)
	if result1 then
		self:dealWithDartEvent(result2)
	end

	--"attack"事件
	local result1,result2 = self:checkIsAttackEvent(event,self.skillInfo)
	if result1 then
		self:dealWithAttackEvent(event,result2)
	end
	
	--"autoplay"事件
	result1 = self:checkIsAutoplayEvent(event)
	if result1 then
		self:dealWithAutoplayEvent()
	end

	--"cutin"事件
	local result_cutin = self:checkIsCutInEvent(event)
	if result_cutin == 1 then
		G_GameState = 3
		SkillUtil:playCutIn(self.entity)
		if not self.entity.isBoss then
			ActiveSkillManager:refreshSkillWhenCutIn(self.entity.skill[2])
		end
	elseif result_cutin == 2 then
		SkillUtil:playEndCutIn(self.entity)
	end
end

--检测是否是突进
function State_PlayingSkill_Self:checkIsDart(event)
	--如果是boss战，直接返回false
	if BattleDataManager.isBoss then
		return false
	end

	if string.find(event.eventData.name,"movex") then
		local x = string.sub(event.eventData.name,7)
		return true,tonumber(x);
	end
	return false
end

--处理造成伤害事件
function State_PlayingSkill_Self:dealWithAttackEvent(event,idx)
	local currXSelf,currYSelf = self.entity:getPosition()
	local hit_rect_x,hit_rect_y,hit_rect_w,hit_rect_h

	local hitData = self.skillInfo.skillData.skill_attack_hit[idx]

	if not hitData then
		return
	end

	hit_rect_y = hitData.hit_rec[2] + currYSelf
	hit_rect_w = hitData.hit_rec[3] + self.correctValue
	hit_rect_h = hitData.hit_rec[4] + self.correctValue

	local hit_rect_x
	if self.entity.faceTo == BattleGlobals.FaceLeft then
		hit_rect_x = -hitData.hit_rec[1] - hit_rect_w - self.correctValue + currXSelf
	else
		hit_rect_x = hitData.hit_rec[1] + self.correctValue + currXSelf
	end	

	local damageRange = cc.rect(hit_rect_x, hit_rect_y, hit_rect_w, hit_rect_h)

	local attackedList = self:generateAttackedList(damageRange,cc.p(currXSelf,currYSelf),self.skillInfo,hitData)

	for k,v in pairs(attackedList) do
		self:onCauseDamage(1,self.entity,v,event,self.skillInfo.skillData,idx)
	end
end

--处理突进事件（只有自身类有可能出现）
function State_PlayingSkill_Self:dealWithDartEvent(x)
	--将x四舍五入成50的倍数
	--local temp = math.floor(x/50 + 0.5)
	--local newX = temp * 50

	if self.entity.faceTo == BattleGlobals.FaceLeft then
		x = -x
	end
	self.entity:setPositionX(self.entity:getPositionX() + x)
	self.entity.box_w,self.entity.box_h = GetBoxWHByPoint(self.entity:getPositionX(),self.entity:getPositionY())
end

function State_PlayingSkill_Self:onSpineCompleteCallback(event)
	if self.entity.isBoss then
		self.entity.fsm:changeState(StateEnum.Attacking_Boss)
	else
		--技能释放完毕。切换到RunningToEnemy状态
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)		
	end
end

