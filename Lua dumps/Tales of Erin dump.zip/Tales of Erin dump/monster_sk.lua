monster_sk = {} 
monster_sk[70001] = { --技能的ID
    sk_name = "随机落一个大火球",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10001},--对应技能表的信息
} 
monster_sk[70002] = { --技能的ID
    sk_name = "身前3次范围伤害",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10002},--对应技能表的信息
} 
monster_sk[70003] = { --技能的ID
    sk_name = "近战一次伤害",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10003},--对应技能表的信息
} 
monster_sk[70004] = { --技能的ID
    sk_name = "近战一次伤害，带击倒",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10004},--对应技能表的信息
} 
monster_sk[70005] = { --技能的ID
    sk_name = "随机目标，一个地刺",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10005},--对应技能表的信息
} 
monster_sk[70006] = { --技能的ID
    sk_name = "身前范围伤害，带击退",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10006},--对应技能表的信息
} 
monster_sk[70007] = { --技能的ID
    sk_name = "近战一次伤害",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10007},--对应技能表的信息
} 
monster_sk[70008] = { --技能的ID
    sk_name = "近战一次伤害",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10008},--对应技能表的信息
} 
monster_sk[70009] = { --技能的ID
    sk_name = "目标脚下，爆炸一个火球。",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10009},--对应技能表的信息
} 
monster_sk[70010] = { --技能的ID
    sk_name = "贯通冰枪",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10010},--对应技能表的信息
} 
monster_sk[70011] = { --技能的ID
    sk_name = "目标范围6次伤害，范围越来越大",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10011},--对应技能表的信息
} 
monster_sk[70012] = { --技能的ID
    sk_name = "近战一次伤害，带击退",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10012},--对应技能表的信息
} 
monster_sk[70013] = { --技能的ID
    sk_name = "随机落一个大火球",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10013},--对应技能表的信息
} 
monster_sk[70014] = { --技能的ID
    sk_name = "随机落一个大火球",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10014},--对应技能表的信息
} 
monster_sk[70015] = { --技能的ID
    sk_name = "一个普通技能",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 50,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10015},--对应技能表的信息
} 
monster_sk[70016] = { --技能的ID
    sk_name = "一个普通技能",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 50,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10016},--对应技能表的信息
} 
monster_sk[80001] = { --技能的ID
    sk_name = "砸地，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20001},--对应技能表的信息
} 
monster_sk[80002] = { --技能的ID
    sk_name = "灼热爆炸，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20002},--对应技能表的信息
} 
monster_sk[80003] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20003,20005,20003,20005},--对应技能表的信息
} 
monster_sk[80004] = { --技能的ID
    sk_name = "砸地，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20001},--对应技能表的信息
} 
monster_sk[80005] = { --技能的ID
    sk_name = "灼热爆炸，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20002},--对应技能表的信息
} 
monster_sk[80006] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20003,20004,20005,20003,20004,20005},--对应技能表的信息
} 
monster_sk[80007] = { --技能的ID
    sk_name = "捶地两下，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20011},--对应技能表的信息
} 
monster_sk[80008] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20012},--对应技能表的信息
} 
monster_sk[80009] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20013,20014,20013,20014},--对应技能表的信息
} 
monster_sk[80010] = { --技能的ID
    sk_name = "捶地两下，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20011},--对应技能表的信息
} 
monster_sk[80011] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20012},--对应技能表的信息
} 
monster_sk[80012] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20013,20014,20015,20015,20014,20015},--对应技能表的信息
} 
monster_sk[80013] = { --技能的ID
    sk_name = "刀砍一个，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20024},--对应技能表的信息
} 
monster_sk[80014] = { --技能的ID
    sk_name = "枪射一个，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20025},--对应技能表的信息
} 
monster_sk[80015] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20026,20026,20027,20026,20026,20027},--对应技能表的信息
} 
monster_sk[80016] = { --技能的ID
    sk_name = "斩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20028},--对应技能表的信息
} 
monster_sk[80017] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20029},--对应技能表的信息
} 
monster_sk[80018] = { --技能的ID
    sk_name = "自身爆发黑色光柱，近战AOE",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20030,20031,20031,20030,20031,20031},--对应技能表的信息
} 
monster_sk[80019] = { --技能的ID
    sk_name = "近战斩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20032},--对应技能表的信息
} 
monster_sk[80020] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20034,20035,20034,20035},--对应技能表的信息
} 
monster_sk[80021] = { --技能的ID
    sk_name = "近战斩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20032},--对应技能表的信息
} 
monster_sk[80022] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20034,20033,20035,20034,20033,20035},--对应技能表的信息
} 
monster_sk[80023] = { --技能的ID
    sk_name = "捶地两下，AOE，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20036},--对应技能表的信息
} 
monster_sk[80024] = { --技能的ID
    sk_name = "随机打两个人，AOE，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20037},--对应技能表的信息
} 
monster_sk[80025] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20038,20038,20039,20038,20038,20039},--对应技能表的信息
} 
monster_sk[80026] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20040},--对应技能表的信息
} 
monster_sk[80027] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20041},--对应技能表的信息
} 
monster_sk[80028] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20042,20042,20043,20042,20042,20043},--对应技能表的信息
} 
monster_sk[80029] = { --技能的ID
    sk_name = "普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20044},--对应技能表的信息
} 
monster_sk[80030] = { --技能的ID
    sk_name = "搓个球炸一下，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20045},--对应技能表的信息
} 
monster_sk[80031] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20046,20047,20048,20046,20047,20048},--对应技能表的信息
} 
monster_sk[80032] = { --技能的ID
    sk_name = "皇子大招，不疼不痒的伤害。",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20049},--对应技能表的信息
} 
monster_sk[80033] = { --技能的ID
    sk_name = "装逼失败，给自己上了debuff",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20049,20049,20050,20049,20049,20050},--对应技能表的信息
} 
monster_sk[80034] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20051},--对应技能表的信息
} 
monster_sk[8003401] = { --技能的ID
    sk_name = "砍，远程",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20052},--对应技能表的信息
} 
monster_sk[80035] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20052,20053,20052,20053},--对应技能表的信息
} 
monster_sk[80036] = { --技能的ID
    sk_name = "随机最近，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20054},--对应技能表的信息
} 
monster_sk[80037] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20055,20056,20055,20056},--对应技能表的信息
} 
monster_sk[80038] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20057},--对应技能表的信息
} 
monster_sk[80039] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20058,20059,20058,20059},--对应技能表的信息
} 
monster_sk[80040] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20060,20058,20060,20058},--对应技能表的信息
} 
monster_sk[80041] = { --技能的ID
    sk_name = "近战斩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20061},--对应技能表的信息
} 
monster_sk[80042] = { --技能的ID
    sk_name = "能量飞镖，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20062},--对应技能表的信息
} 
monster_sk[80043] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20063,20064,20063,20064},--对应技能表的信息
} 
monster_sk[80044] = { --技能的ID
    sk_name = "激光眼，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20065},--对应技能表的信息
} 
monster_sk[80045] = { --技能的ID
    sk_name = "随机三球，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20066},--对应技能表的信息
} 
monster_sk[80046] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20067,20068,20067,20068},--对应技能表的信息
} 
monster_sk[80047] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20069},--对应技能表的信息
} 
monster_sk[80048] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20070},--对应技能表的信息
} 
monster_sk[80049] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20071,20072,20071,20072},--对应技能表的信息
} 
monster_sk[80050] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20073,20071,20073,20071},--对应技能表的信息
} 
monster_sk[80051] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20073,20073,20073},--对应技能表的信息
} 
monster_sk[80052] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20074},--对应技能表的信息
} 
monster_sk[80053] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20075},--对应技能表的信息
} 
monster_sk[80054] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20076,20076,20076},--对应技能表的信息
} 
monster_sk[80055] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20078,20076,20078,20076},--对应技能表的信息
} 
monster_sk[80056] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20077,20076,20078,20077,20076,20078},--对应技能表的信息
} 
monster_sk[80057] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20079},--对应技能表的信息
} 
monster_sk[80058] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20080},--对应技能表的信息
} 
monster_sk[80059] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20081,20081,20081},--对应技能表的信息
} 
monster_sk[80060] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20082,20081,20082,20081},--对应技能表的信息
} 
monster_sk[80061] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20083,20083,20083},--对应技能表的信息
} 
monster_sk[80062] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20084},--对应技能表的信息
} 
monster_sk[80063] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20085,20085,20085},--对应技能表的信息
} 
monster_sk[80064] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 20,--前端自己判断处理
    },
    sk_skill_id = {20087,20085,20087,20085},--对应技能表的信息
} 
monster_sk[80065] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20086,20087,20086,20087},--对应技能表的信息
} 
monster_sk[80066] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 0, -- 触发的时机
       trig_type = 0,--触发器的类型
       trig_rate = 0,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {},--对应技能表的信息
} 
monster_sk[80067] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 0, -- 触发的时机
       trig_type = 0,--触发器的类型
       trig_rate = 0,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {},--对应技能表的信息
} 
monster_sk[80068] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 0, -- 触发的时机
       trig_type = 0,--触发器的类型
       trig_rate = 0,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {},--对应技能表的信息
} 
monster_sk[80069] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 0, -- 触发的时机
       trig_type = 0,--触发器的类型
       trig_rate = 0,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {},--对应技能表的信息
} 
monster_sk[80070] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 0, -- 触发的时机
       trig_type = 0,--触发器的类型
       trig_rate = 0,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {},--对应技能表的信息
} 
monster_sk[80071] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20074},--对应技能表的信息
} 
monster_sk[80072] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20075},--对应技能表的信息
} 
monster_sk[80073] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20076},--对应技能表的信息
} 
monster_sk[80074] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20076},--对应技能表的信息
} 
monster_sk[80075] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20076},--对应技能表的信息
} 
monster_sk[80076] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20074},--对应技能表的信息
} 
monster_sk[80077] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20075},--对应技能表的信息
} 
monster_sk[80078] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20076},--对应技能表的信息
} 
monster_sk[80079] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20078,20076,20078,20076},--对应技能表的信息
} 
monster_sk[80080] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20078,20076,20078,20076},--对应技能表的信息
} 
monster_sk[80081] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20074},--对应技能表的信息
} 
monster_sk[80082] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20075},--对应技能表的信息
} 
monster_sk[80083] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20076,20076,20076},--对应技能表的信息
} 
monster_sk[80084] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20078,20076,20078,20076},--对应技能表的信息
} 
monster_sk[80085] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20077,20076,20078,20077,20076,20078},--对应技能表的信息
} 
monster_sk[80086] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20074},--对应技能表的信息
} 
monster_sk[80087] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20075},--对应技能表的信息
} 
monster_sk[80088] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20076,20076,20076},--对应技能表的信息
} 
monster_sk[80089] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20078,20076,20078,20076},--对应技能表的信息
} 
monster_sk[80090] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20077,20076,20078,20077,20076,20078},--对应技能表的信息
} 
monster_sk[80091] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20069},--对应技能表的信息
} 
monster_sk[80092] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20070},--对应技能表的信息
} 
monster_sk[80093] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20071},--对应技能表的信息
} 
monster_sk[80094] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20071},--对应技能表的信息
} 
monster_sk[80095] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20071},--对应技能表的信息
} 
monster_sk[80096] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20069},--对应技能表的信息
} 
monster_sk[80097] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20070},--对应技能表的信息
} 
monster_sk[80098] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20071,20072,20071,20072},--对应技能表的信息
} 
monster_sk[80099] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20071,20072,20071,20072},--对应技能表的信息
} 
monster_sk[80100] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20071,20072,20071,20072},--对应技能表的信息
} 
monster_sk[80101] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20069},--对应技能表的信息
} 
monster_sk[80102] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20070},--对应技能表的信息
} 
monster_sk[80103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20071,20072,20071,20072},--对应技能表的信息
} 
monster_sk[80104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20073,20071,20073,20071},--对应技能表的信息
} 
monster_sk[80105] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20073,20073,20073},--对应技能表的信息
} 
monster_sk[80106] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20069},--对应技能表的信息
} 
monster_sk[80107] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20070},--对应技能表的信息
} 
monster_sk[80108] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20071,20072,20071,20072},--对应技能表的信息
} 
monster_sk[80109] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20073,20071,20073,20071},--对应技能表的信息
} 
monster_sk[80110] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20073,20073,20073},--对应技能表的信息
} 
monster_sk[80111] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20079},--对应技能表的信息
} 
monster_sk[80112] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20080},--对应技能表的信息
} 
monster_sk[80113] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20081},--对应技能表的信息
} 
monster_sk[80114] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20081},--对应技能表的信息
} 
monster_sk[80115] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20081},--对应技能表的信息
} 
monster_sk[80116] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20079},--对应技能表的信息
} 
monster_sk[80117] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20080},--对应技能表的信息
} 
monster_sk[80118] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20081,20081,20081},--对应技能表的信息
} 
monster_sk[80119] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20082,20081,20082,20081},--对应技能表的信息
} 
monster_sk[80120] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20082,20081,20082,20081},--对应技能表的信息
} 
monster_sk[80121] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20079},--对应技能表的信息
} 
monster_sk[80122] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20080},--对应技能表的信息
} 
monster_sk[80123] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20081,20081,20081},--对应技能表的信息
} 
monster_sk[80124] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20082,20081,20082,20081},--对应技能表的信息
} 
monster_sk[80125] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20083,20083,20083},--对应技能表的信息
} 
monster_sk[80126] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20079},--对应技能表的信息
} 
monster_sk[80127] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20080},--对应技能表的信息
} 
monster_sk[80128] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20081,20081,20081},--对应技能表的信息
} 
monster_sk[80129] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20082,20081,20082,20081},--对应技能表的信息
} 
monster_sk[80130] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20083,20083,20083},--对应技能表的信息
} 
monster_sk[80131] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20084},--对应技能表的信息
} 
monster_sk[80132] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20085},--对应技能表的信息
} 
monster_sk[80133] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 20,--前端自己判断处理
    },
    sk_skill_id = {20085},--对应技能表的信息
} 
monster_sk[80134] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20085},--对应技能表的信息
} 
monster_sk[80135] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20084},--对应技能表的信息
} 
monster_sk[80136] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20085,20085,20085},--对应技能表的信息
} 
monster_sk[80137] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 20,--前端自己判断处理
    },
    sk_skill_id = {20087,20085,20087,20085},--对应技能表的信息
} 
monster_sk[80138] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20087,20085,20087,20085},--对应技能表的信息
} 
monster_sk[80139] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20084},--对应技能表的信息
} 
monster_sk[80140] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20085,20085,20085},--对应技能表的信息
} 
monster_sk[80141] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 20,--前端自己判断处理
    },
    sk_skill_id = {20087,20085,20087,20085},--对应技能表的信息
} 
monster_sk[80142] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20086,20087,20086,20087},--对应技能表的信息
} 
monster_sk[80143] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20084},--对应技能表的信息
} 
monster_sk[80144] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20085,20085,20085},--对应技能表的信息
} 
monster_sk[80145] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 20,--前端自己判断处理
    },
    sk_skill_id = {20087,20085,20087,20085},--对应技能表的信息
} 
monster_sk[80146] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20086,20087,20086,20087},--对应技能表的信息
} 
monster_sk[80147] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80148] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80149] = { --技能的ID
    sk_name = "狼嚎",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20104},--对应技能表的信息
} 
monster_sk[80150] = { --技能的ID
    sk_name = "",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80151] = { --技能的ID
    sk_name = "",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106,20105,20105},--对应技能表的信息
} 
monster_sk[80152] = { --技能的ID
    sk_name = "啃咬",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80153] = { --技能的ID
    sk_name = "脚踩",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80154] = { --技能的ID
    sk_name = "熔火炮",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20104},--对应技能表的信息
} 
monster_sk[80155] = { --技能的ID
    sk_name = "",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80156] = { --技能的ID
    sk_name = "",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106,20105,20105},--对应技能表的信息
} 
monster_sk[80157] = { --技能的ID
    sk_name = "啃咬",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80158] = { --技能的ID
    sk_name = "脚踩",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80159] = { --技能的ID
    sk_name = "熔火炮",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20104},--对应技能表的信息
} 
monster_sk[80160] = { --技能的ID
    sk_name = "狼嚎",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80161] = { --技能的ID
    sk_name = "激光炮",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106,20105,20105},--对应技能表的信息
} 
monster_sk[80162] = { --技能的ID
    sk_name = "啃咬",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80163] = { --技能的ID
    sk_name = "熔火炮",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80164] = { --技能的ID
    sk_name = "狼嚎",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20104},--对应技能表的信息
} 
monster_sk[80165] = { --技能的ID
    sk_name = "",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80166] = { --技能的ID
    sk_name = "激光炮",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106,20105,20105},--对应技能表的信息
} 
monster_sk[80167] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20088},--对应技能表的信息
} 
monster_sk[80168] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20089},--对应技能表的信息
} 
monster_sk[80169] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20090,20091,20090,20091},--对应技能表的信息
} 
monster_sk[80170] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20092},--对应技能表的信息
} 
monster_sk[80171] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20093},--对应技能表的信息
} 
monster_sk[80172] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20094},--对应技能表的信息
} 
monster_sk[80173] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20095,20094,20095,20094},--对应技能表的信息
} 
monster_sk[80174] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20094,20095,20095,20094,20095,20095},--对应技能表的信息
} 
monster_sk[80175] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20088},--对应技能表的信息
} 
monster_sk[80176] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20089},--对应技能表的信息
} 
monster_sk[80177] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20090,20090},--对应技能表的信息
} 
monster_sk[80178] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20091,20091},--对应技能表的信息
} 
monster_sk[80179] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20088},--对应技能表的信息
} 
monster_sk[80180] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20089},--对应技能表的信息
} 
monster_sk[80181] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20090,20090},--对应技能表的信息
} 
monster_sk[80182] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20091,20090,20091,20090},--对应技能表的信息
} 
monster_sk[80183] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20091,20091,20091,20091},--对应技能表的信息
} 
monster_sk[80184] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20088},--对应技能表的信息
} 
monster_sk[80185] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20089},--对应技能表的信息
} 
monster_sk[80186] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20090,20090},--对应技能表的信息
} 
monster_sk[80187] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20091,20090,20091,20090},--对应技能表的信息
} 
monster_sk[80188] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20091,20091,20091,20091},--对应技能表的信息
} 
monster_sk[80189] = { --技能的ID
    sk_name = "特殊文字杀",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20116},--对应技能表的信息
} 
monster_sk[80190] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20113},--对应技能表的信息
} 
monster_sk[80191] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20114},--对应技能表的信息
} 
monster_sk[80192] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20115,20117,20115,20117},--对应技能表的信息
} 
monster_sk[80193] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20117,20117},--对应技能表的信息
} 
monster_sk[80194] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20118},--对应技能表的信息
} 
monster_sk[80195] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20119},--对应技能表的信息
} 
monster_sk[80196] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20120,20121},--对应技能表的信息
} 
monster_sk[80197] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20121,20121},--对应技能表的信息
} 
monster_sk[80198] = { --技能的ID
    sk_name = "特殊文字杀",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20125},--对应技能表的信息
} 
monster_sk[80199] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20122},--对应技能表的信息
} 
monster_sk[80200] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20123},--对应技能表的信息
} 
monster_sk[80201] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20124,20126},--对应技能表的信息
} 
monster_sk[80202] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20126,20126},--对应技能表的信息
} 
monster_sk[80203] = { --技能的ID
    sk_name = "特殊文字杀",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20130},--对应技能表的信息
} 
monster_sk[80204] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20127},--对应技能表的信息
} 
monster_sk[80205] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20128},--对应技能表的信息
} 
monster_sk[80206] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20129,20131,20129,20131},--对应技能表的信息
} 
monster_sk[80207] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20131,20131},--对应技能表的信息
} 
monster_sk[80208] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20096},--对应技能表的信息
} 
monster_sk[80209] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20097},--对应技能表的信息
} 
monster_sk[80210] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20098,20099,20100,20101},--对应技能表的信息
} 
monster_sk[80211] = { --技能的ID
    sk_name = "特别回血",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20136},--对应技能表的信息
} 
monster_sk[80212] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20132},--对应技能表的信息
} 
monster_sk[80213] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20133},--对应技能表的信息
} 
monster_sk[80214] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20134,20135},--对应技能表的信息
} 
monster_sk[80215] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20134,20135,20137},--对应技能表的信息
} 
monster_sk[80216] = { --技能的ID
    sk_name = "真皇剑",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20112},--对应技能表的信息
} 
monster_sk[80217] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20107},--对应技能表的信息
} 
monster_sk[80218] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20108},--对应技能表的信息
} 
monster_sk[80219] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20109,20110,20111},--对应技能表的信息
} 
monster_sk[80220] = { --技能的ID
    sk_name = "幽冥死界葬",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20144},--对应技能表的信息
} 
monster_sk[80221] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20138},--对应技能表的信息
} 
monster_sk[80222] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20139},--对应技能表的信息
} 
monster_sk[80223] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20141,20142},--对应技能表的信息
} 
monster_sk[80224] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20141,20143,20142},--对应技能表的信息
} 
monster_sk[80225] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80226] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80227] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80228] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80229] = { --技能的ID
    sk_name = "75%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80230] = { --技能的ID
    sk_name = "50%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80231] = { --技能的ID
    sk_name = "25%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80232] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80233] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80234] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80235] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20105},--对应技能表的信息
} 
monster_sk[80236] = { --技能的ID
    sk_name = "75%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80237] = { --技能的ID
    sk_name = "50%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80238] = { --技能的ID
    sk_name = "25%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80239] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80240] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80241] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20104},--对应技能表的信息
} 
monster_sk[80242] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20104,20105,20104,20105},--对应技能表的信息
} 
monster_sk[80243] = { --技能的ID
    sk_name = "75%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80244] = { --技能的ID
    sk_name = "50%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80245] = { --技能的ID
    sk_name = "25%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20106},--对应技能表的信息
} 
monster_sk[80246] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20102},--对应技能表的信息
} 
monster_sk[80247] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20103},--对应技能表的信息
} 
monster_sk[80248] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20104},--对应技能表的信息
} 
monster_sk[80249] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20104,20105,20104,20105},--对应技能表的信息
} 
monster_sk[80250] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20145},--对应技能表的信息
} 
monster_sk[80251] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20146},--对应技能表的信息
} 
monster_sk[80252] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20147,20148,20149},--对应技能表的信息
} 
monster_sk[80253] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20145},--对应技能表的信息
} 
monster_sk[80254] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20146},--对应技能表的信息
} 
monster_sk[80255] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20147,20148,20149},--对应技能表的信息
} 
monster_sk[80256] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20146},--对应技能表的信息
} 
monster_sk[80257] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20145},--对应技能表的信息
} 
monster_sk[80258] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20146},--对应技能表的信息
} 
monster_sk[80259] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20152,20148,20153},--对应技能表的信息
} 
monster_sk[80260] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20152,20148,20153,20148,20153},--对应技能表的信息
} 
monster_sk[80261] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20156},--对应技能表的信息
} 
monster_sk[80262] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20146},--对应技能表的信息
} 
monster_sk[80263] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20145},--对应技能表的信息
} 
monster_sk[80264] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20146},--对应技能表的信息
} 
monster_sk[80265] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20154,20148,20154,20148},--对应技能表的信息
} 
monster_sk[80266] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 10,--前端自己判断处理
    },
    sk_skill_id = {20154,20148,20148,20155},--对应技能表的信息
} 
monster_sk[80267] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 10,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20148,20155,20148,20155},--对应技能表的信息
} 
monster_sk[80268] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80269] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80270] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20159,20160,20161},--对应技能表的信息
} 
monster_sk[80271] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80272] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80273] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20159,20159},--对应技能表的信息
} 
monster_sk[80274] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20159,20160},--对应技能表的信息
} 
monster_sk[80275] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20161},--对应技能表的信息
} 
monster_sk[80276] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80277] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80278] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 40,--前端自己判断处理
    },
    sk_skill_id = {20162,20162},--对应技能表的信息
} 
monster_sk[80279] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 40,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20162,20163},--对应技能表的信息
} 
monster_sk[80280] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20161},--对应技能表的信息
} 
monster_sk[80281] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20161},--对应技能表的信息
} 
monster_sk[80282] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80283] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20157},--对应技能表的信息
} 
monster_sk[80284] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20164,20164},--对应技能表的信息
} 
monster_sk[80285] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20164,20165},--对应技能表的信息
} 
monster_sk[80286] = { --技能的ID
    sk_name = "近战普攻1",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 80,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20166},--对应技能表的信息
} 
monster_sk[80287] = { --技能的ID
    sk_name = "近战普攻2，击退",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 20,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20167},--对应技能表的信息
} 
monster_sk[80288] = { --技能的ID
    sk_name = "远程普攻，击退",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20167},--对应技能表的信息
} 
monster_sk[80289] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20168,20168,20169},--对应技能表的信息
} 
monster_sk[80290] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20169,20168},--对应技能表的信息
} 
monster_sk[80291] = { --技能的ID
    sk_name = "50%文字杀",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20170},--对应技能表的信息
} 
monster_sk[80292] = { --技能的ID
    sk_name = "20%文字杀",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20170},--对应技能表的信息
} 
monster_sk[80293] = { --技能的ID
    sk_name = "近战普攻1",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 80,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20350},--对应技能表的信息
} 
monster_sk[80294] = { --技能的ID
    sk_name = "近战普攻2，击退",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 20,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20351},--对应技能表的信息
} 
monster_sk[80295] = { --技能的ID
    sk_name = "远程普攻，击退",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20351},--对应技能表的信息
} 
monster_sk[80296] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20352,20352,20353},--对应技能表的信息
} 
monster_sk[80297] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20353,20352},--对应技能表的信息
} 
monster_sk[80298] = { --技能的ID
    sk_name = "75%文字杀",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20354},--对应技能表的信息
} 
monster_sk[80299] = { --技能的ID
    sk_name = "50%文字杀",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20354},--对应技能表的信息
} 
monster_sk[80300] = { --技能的ID
    sk_name = "20%文字杀",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20354},--对应技能表的信息
} 
monster_sk[80301] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 30,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20167},--对应技能表的信息
} 
monster_sk[80302] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20166},--对应技能表的信息
} 
monster_sk[80303] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20167},--对应技能表的信息
} 
monster_sk[80304] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20168},--对应技能表的信息
} 
monster_sk[80305] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 10,--前端自己判断处理
    },
    sk_skill_id = {20169},--对应技能表的信息
} 
monster_sk[80306] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 10,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20171,20169},--对应技能表的信息
} 
monster_sk[80307] = { --技能的ID
    sk_name = "特殊开场文字杀",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20171},--对应技能表的信息
} 
monster_sk[80308] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20177},--对应技能表的信息
} 
monster_sk[80309] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20178},--对应技能表的信息
} 
monster_sk[80310] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20179,20179},--对应技能表的信息
} 
monster_sk[80311] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20179,20180},--对应技能表的信息
} 
monster_sk[80312] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20181},--对应技能表的信息
} 
monster_sk[80313] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20177},--对应技能表的信息
} 
monster_sk[80314] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20178},--对应技能表的信息
} 
monster_sk[80315] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20182,20182},--对应技能表的信息
} 
monster_sk[80316] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20182,20183},--对应技能表的信息
} 
monster_sk[80317] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20181},--对应技能表的信息
} 
monster_sk[80318] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20181},--对应技能表的信息
} 
monster_sk[80319] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20177},--对应技能表的信息
} 
monster_sk[80320] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20178},--对应技能表的信息
} 
monster_sk[80321] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20183,20184},--对应技能表的信息
} 
monster_sk[80322] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20183,20184},--对应技能表的信息
} 
monster_sk[81111] = { --技能的ID
    sk_name = "捶地两下，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20172},--对应技能表的信息
} 
monster_sk[81112] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20173},--对应技能表的信息
} 
monster_sk[81113] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20174,20175},--对应技能表的信息
} 
monster_sk[81114] = { --技能的ID
    sk_name = "捶地两下，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20172},--对应技能表的信息
} 
monster_sk[81115] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20173},--对应技能表的信息
} 
monster_sk[81116] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20174,20175,20176},--对应技能表的信息
} 
monster_sk[80323] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20191},--对应技能表的信息
} 
monster_sk[80324] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81055,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20192},--对应技能表的信息
} 
monster_sk[80325] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20186},--对应技能表的信息
} 
monster_sk[80326] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20187},--对应技能表的信息
} 
monster_sk[80327] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20188,20189,20188,20190,20188,20189},--对应技能表的信息
} 
monster_sk[80328] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20193},--对应技能表的信息
} 
monster_sk[80329] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20193},--对应技能表的信息
} 
monster_sk[80330] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20195},--对应技能表的信息
} 
monster_sk[80331] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20195,20196},--对应技能表的信息
} 
monster_sk[80332] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20197},--对应技能表的信息
} 
monster_sk[80333] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20193},--对应技能表的信息
} 
monster_sk[80334] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20193},--对应技能表的信息
} 
monster_sk[80335] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20198},--对应技能表的信息
} 
monster_sk[80336] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20198,20199},--对应技能表的信息
} 
monster_sk[80337] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20197},--对应技能表的信息
} 
monster_sk[80338] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20197},--对应技能表的信息
} 
monster_sk[80339] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20193},--对应技能表的信息
} 
monster_sk[80340] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20193},--对应技能表的信息
} 
monster_sk[80341] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20200},--对应技能表的信息
} 
monster_sk[80342] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20200,20201},--对应技能表的信息
} 
monster_sk[80343] = { --技能的ID
    sk_name = "特殊文字杀",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20214},--对应技能表的信息
} 
monster_sk[80344] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20211,20213},--对应技能表的信息
} 
monster_sk[80345] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20213},--对应技能表的信息
} 
monster_sk[80346] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20215,20215},--对应技能表的信息
} 
monster_sk[80347] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20215,20215,20214},--对应技能表的信息
} 
monster_sk[80348] = { --技能的ID
    sk_name = "大招",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 12000,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20221},--对应技能表的信息
} 
monster_sk[80349] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20216,20216,20217},--对应技能表的信息
} 
monster_sk[80350] = { --技能的ID
    sk_name = "远程贯穿普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20218},--对应技能表的信息
} 
monster_sk[80351] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20219,20220},--对应技能表的信息
} 
monster_sk[80352] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20219,20219,20221},--对应技能表的信息
} 
monster_sk[80353] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20235},--对应技能表的信息
} 
monster_sk[80354] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20235},--对应技能表的信息
} 
monster_sk[80355] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20236,20237},--对应技能表的信息
} 
monster_sk[80356] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20237},--对应技能表的信息
} 
monster_sk[80357] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20238},--对应技能表的信息
} 
monster_sk[80358] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20239},--对应技能表的信息
} 
monster_sk[80359] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20240,20241},--对应技能表的信息
} 
monster_sk[80360] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20240,20241,20242},--对应技能表的信息
} 
monster_sk[80361] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20240,20242},--对应技能表的信息
} 
monster_sk[80362] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20243},--对应技能表的信息
} 
monster_sk[80363] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20244},--对应技能表的信息
} 
monster_sk[80364] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20245,20246},--对应技能表的信息
} 
monster_sk[80365] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20245,20246,20247},--对应技能表的信息
} 
monster_sk[80366] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20245,20247},--对应技能表的信息
} 
monster_sk[80367] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20248},--对应技能表的信息
} 
monster_sk[80368] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20249},--对应技能表的信息
} 
monster_sk[80369] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20250,20251},--对应技能表的信息
} 
monster_sk[80370] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20250,20251,20252},--对应技能表的信息
} 
monster_sk[80371] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20250,20252},--对应技能表的信息
} 
monster_sk[80372] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20253},--对应技能表的信息
} 
monster_sk[80373] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20254,20255},--对应技能表的信息
} 
monster_sk[80374] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20254,20255,20255},--对应技能表的信息
} 
monster_sk[80375] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20254,20256},--对应技能表的信息
} 
monster_sk[80376] = { --技能的ID
    sk_name = "75%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20261},--对应技能表的信息
} 
monster_sk[80377] = { --技能的ID
    sk_name = "50%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20261},--对应技能表的信息
} 
monster_sk[80378] = { --技能的ID
    sk_name = "25%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20261},--对应技能表的信息
} 
monster_sk[80379] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20257},--对应技能表的信息
} 
monster_sk[80380] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20258},--对应技能表的信息
} 
monster_sk[80381] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20259,20260},--对应技能表的信息
} 
monster_sk[80382] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20259,20260,20261},--对应技能表的信息
} 
monster_sk[80383] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20259,20261},--对应技能表的信息
} 
monster_sk[80384] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20411},--对应技能表的信息
} 
monster_sk[80385] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20412},--对应技能表的信息
} 
monster_sk[80386] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20262,20413,20263},--对应技能表的信息
} 
monster_sk[80387] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20262,20263},--对应技能表的信息
} 
monster_sk[80388] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20243},--对应技能表的信息
} 
monster_sk[80389] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20264},--对应技能表的信息
} 
monster_sk[80390] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20245,20246,20265},--对应技能表的信息
} 
monster_sk[80391] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20245,20265},--对应技能表的信息
} 
monster_sk[80393] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20248},--对应技能表的信息
} 
monster_sk[80394] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20266},--对应技能表的信息
} 
monster_sk[80395] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20250,20251,20267},--对应技能表的信息
} 
monster_sk[80396] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20250,20267},--对应技能表的信息
} 
monster_sk[80398] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20253,20268},--对应技能表的信息
} 
monster_sk[80399] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20254,20255,20269},--对应技能表的信息
} 
monster_sk[80400] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20254,20269},--对应技能表的信息
} 
monster_sk[80401] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20254,20269},--对应技能表的信息
} 
monster_sk[80402] = { --技能的ID
    sk_name = "75%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20271},--对应技能表的信息
} 
monster_sk[80403] = { --技能的ID
    sk_name = "50%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20261},--对应技能表的信息
} 
monster_sk[80404] = { --技能的ID
    sk_name = "25%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20271},--对应技能表的信息
} 
monster_sk[80405] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20257},--对应技能表的信息
} 
monster_sk[80406] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20258},--对应技能表的信息
} 
monster_sk[80407] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20259,20259,20270},--对应技能表的信息
} 
monster_sk[80408] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20260,20270},--对应技能表的信息
} 
monster_sk[80410] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[80411] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[80412] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 30,--前端自己判断处理
    },
    sk_skill_id = {20274,20274},--对应技能表的信息
} 
monster_sk[80413] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 30,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20274,20275},--对应技能表的信息
} 
monster_sk[80414] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20276},--对应技能表的信息
} 
monster_sk[80415] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[80416] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[80417] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 40,--前端自己判断处理
    },
    sk_skill_id = {20277,20277},--对应技能表的信息
} 
monster_sk[80418] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 40,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20277,20278},--对应技能表的信息
} 
monster_sk[80419] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20276},--对应技能表的信息
} 
monster_sk[80420] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20276},--对应技能表的信息
} 
monster_sk[80421] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[80422] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[80423] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20279,20279},--对应技能表的信息
} 
monster_sk[80424] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20279,20280},--对应技能表的信息
} 
monster_sk[80431] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20281},--对应技能表的信息
} 
monster_sk[80432] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20282},--对应技能表的信息
} 
monster_sk[80433] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20283},--对应技能表的信息
} 
monster_sk[80434] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20283,20284},--对应技能表的信息
} 
monster_sk[80435] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20285},--对应技能表的信息
} 
monster_sk[80441] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20281},--对应技能表的信息
} 
monster_sk[80442] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20282},--对应技能表的信息
} 
monster_sk[80443] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20286},--对应技能表的信息
} 
monster_sk[80444] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20286,20287,20285},--对应技能表的信息
} 
monster_sk[80445] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20285},--对应技能表的信息
} 
monster_sk[80446] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20285},--对应技能表的信息
} 
monster_sk[80451] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20281},--对应技能表的信息
} 
monster_sk[80452] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20282},--对应技能表的信息
} 
monster_sk[80453] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20288,20288},--对应技能表的信息
} 
monster_sk[80454] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[80455] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20285},--对应技能表的信息
} 
monster_sk[80456] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20285},--对应技能表的信息
} 
monster_sk[80457] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20285},--对应技能表的信息
} 
monster_sk[70002] = { --技能的ID
    sk_name = "随机技能",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 10,
       start_cd = 3,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {10018},--对应技能表的信息
} 
monster_sk[8125001] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 70,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20290},--对应技能表的信息
} 
monster_sk[8125002] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 30,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20295},--对应技能表的信息
} 
monster_sk[8125003] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20291},--对应技能表的信息
} 
monster_sk[8125004] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20292,20292,20293},--对应技能表的信息
} 
monster_sk[8125005] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20293,20293,20292},--对应技能表的信息
} 
monster_sk[8125006] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20294},--对应技能表的信息
} 
monster_sk[8125007] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20294},--对应技能表的信息
} 
monster_sk[8126001] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296,20296,20302},--对应技能表的信息
} 
monster_sk[8126002] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126003] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20298,20299},--对应技能表的信息
} 
monster_sk[8126004] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20299},--对应技能表的信息
} 
monster_sk[8126011] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296,20296,20302},--对应技能表的信息
} 
monster_sk[8126012] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126013] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20298,20299},--对应技能表的信息
} 
monster_sk[8126014] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20299},--对应技能表的信息
} 
monster_sk[8126015] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126021] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296,20296,20302},--对应技能表的信息
} 
monster_sk[8126022] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126023] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20298,20298,20299},--对应技能表的信息
} 
monster_sk[8126024] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20299},--对应技能表的信息
} 
monster_sk[8126026] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126031] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296,20296,20302},--对应技能表的信息
} 
monster_sk[8126032] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126033] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20298,20298,20299},--对应技能表的信息
} 
monster_sk[8126034] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20299},--对应技能表的信息
} 
monster_sk[8126036] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126037] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126041] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296,20296,20302},--对应技能表的信息
} 
monster_sk[8126042] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126043] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20298,20298,20299},--对应技能表的信息
} 
monster_sk[8126044] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20299},--对应技能表的信息
} 
monster_sk[8126045] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126046] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126047] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20300},--对应技能表的信息
} 
monster_sk[8126051] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 70,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20303},--对应技能表的信息
} 
monster_sk[8126052] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 30,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20309},--对应技能表的信息
} 
monster_sk[8126053] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20304},--对应技能表的信息
} 
monster_sk[8126054] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20305,20305,20306},--对应技能表的信息
} 
monster_sk[8126055] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20305,20306},--对应技能表的信息
} 
monster_sk[8126056] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20307},--对应技能表的信息
} 
monster_sk[8126057] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20307},--对应技能表的信息
} 
monster_sk[8126058] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20307},--对应技能表的信息
} 
monster_sk[8126101] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296},--对应技能表的信息
} 
monster_sk[8126102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126103] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20298,20299,20300,20301,20302},--对应技能表的信息
} 
monster_sk[8126104] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8126105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126107] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126111] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296},--对应技能表的信息
} 
monster_sk[8126112] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126113] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20298,20299,20300,20301,20302},--对应技能表的信息
} 
monster_sk[8126114] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8126115] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126116] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126117] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126121] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20296},--对应技能表的信息
} 
monster_sk[8126122] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20297},--对应技能表的信息
} 
monster_sk[8126123] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20298,20299,20300,20301,20302},--对应技能表的信息
} 
monster_sk[8126124] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8126125] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126126] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8126127] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20302},--对应技能表的信息
} 
monster_sk[8127001] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20315},--对应技能表的信息
} 
monster_sk[8127002] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20320},--对应技能表的信息
} 
monster_sk[8127003] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20316},--对应技能表的信息
} 
monster_sk[8127004] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20317,20317,20318},--对应技能表的信息
} 
monster_sk[8127005] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20318,20317},--对应技能表的信息
} 
monster_sk[8127006] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20319},--对应技能表的信息
} 
monster_sk[8130001] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20333,20334,20339},--对应技能表的信息
} 
monster_sk[8130002] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 80,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20340},--对应技能表的信息
} 
monster_sk[8130003] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 20,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20338},--对应技能表的信息
} 
monster_sk[8130004] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20335,20335,20336},--对应技能表的信息
} 
monster_sk[8130005] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20336,20335},--对应技能表的信息
} 
monster_sk[8130006] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20337},--对应技能表的信息
} 
monster_sk[8130007] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20337},--对应技能表的信息
} 
monster_sk[8128001] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128002] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128003] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313,20314},--对应技能表的信息
} 
monster_sk[8128004] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8128005] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128006] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128007] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128011] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128012] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128013] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313,20314},--对应技能表的信息
} 
monster_sk[8128014] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8128015] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128016] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128017] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128021] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128022] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128023] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313,20314},--对应技能表的信息
} 
monster_sk[8128024] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8128025] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128026] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128027] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128031] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128032] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128033] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313,20314},--对应技能表的信息
} 
monster_sk[8128034] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20288,20289,20285},--对应技能表的信息
} 
monster_sk[8128035] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128036] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128037] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128101] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128103] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20312,20313},--对应技能表的信息
} 
monster_sk[8128104] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313},--对应技能表的信息
} 
monster_sk[8128105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128107] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128111] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128112] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128113] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20312,20313},--对应技能表的信息
} 
monster_sk[8128114] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313},--对应技能表的信息
} 
monster_sk[8128115] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128116] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128117] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128121] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128122] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128123] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20312,20313},--对应技能表的信息
} 
monster_sk[8128124] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313},--对应技能表的信息
} 
monster_sk[8128125] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128126] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128127] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128131] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20310},--对应技能表的信息
} 
monster_sk[8128132] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20311},--对应技能表的信息
} 
monster_sk[8128133] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20312,20313},--对应技能表的信息
} 
monster_sk[8128134] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20312,20313},--对应技能表的信息
} 
monster_sk[8128135] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128136] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8128137] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20314},--对应技能表的信息
} 
monster_sk[8129001] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129002] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129003] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20322},--对应技能表的信息
} 
monster_sk[8129004] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20324},--对应技能表的信息
} 
monster_sk[8129005] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20323,20324},--对应技能表的信息
} 
monster_sk[8129006] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129007] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129008] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129011] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129012] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129013] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20322},--对应技能表的信息
} 
monster_sk[8129014] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20324},--对应技能表的信息
} 
monster_sk[8129015] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20323,20324},--对应技能表的信息
} 
monster_sk[8129016] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129017] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129018] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129021] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129022] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129023] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20322},--对应技能表的信息
} 
monster_sk[8129024] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20324},--对应技能表的信息
} 
monster_sk[8129025] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20323,20324},--对应技能表的信息
} 
monster_sk[8129026] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129027] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129028] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129101] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129102] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129103] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20322},--对应技能表的信息
} 
monster_sk[8129104] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20324},--对应技能表的信息
} 
monster_sk[8129105] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20323,20323,20324},--对应技能表的信息
} 
monster_sk[8129106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129108] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20325},--对应技能表的信息
} 
monster_sk[8129201] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 60,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20327},--对应技能表的信息
} 
monster_sk[8129202] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 40,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20321},--对应技能表的信息
} 
monster_sk[8129203] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20328},--对应技能表的信息
} 
monster_sk[8129204] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20330},--对应技能表的信息
} 
monster_sk[8129205] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20329,20329,20330},--对应技能表的信息
} 
monster_sk[8129206] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 600000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20331},--对应技能表的信息
} 
monster_sk[8129207] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 600000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20331},--对应技能表的信息
} 
monster_sk[8129208] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 600000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20331},--对应技能表的信息
} 
monster_sk[8119101] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202101},--对应技能表的信息
} 
monster_sk[8119102] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202102},--对应技能表的信息
} 
monster_sk[8119103] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {202103,202103},--对应技能表的信息
} 
monster_sk[8119104] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {202505,202503,202503},--对应技能表的信息
} 
monster_sk[8119105] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202505,202503},--对应技能表的信息
} 
monster_sk[8119201] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202504},--对应技能表的信息
} 
monster_sk[8119202] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202506},--对应技能表的信息
} 
monster_sk[8119203] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {202503,202503},--对应技能表的信息
} 
monster_sk[8119204] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 10,--前端自己判断处理
    },
    sk_skill_id = {202505,202503},--对应技能表的信息
} 
monster_sk[8119205] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 10,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202505,202505},--对应技能表的信息
} 
monster_sk[8119206] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 5,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202505,202503,202505,202503},--对应技能表的信息
} 
monster_sk[8120101] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202601},--对应技能表的信息
} 
monster_sk[8120102] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {202602},--对应技能表的信息
} 
monster_sk[8036601] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20361},--对应技能表的信息
} 
monster_sk[8036602] = { --技能的ID
    sk_name = "地出，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20362},--对应技能表的信息
} 
monster_sk[8036603] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20363,20364},--对应技能表的信息
} 
monster_sk[8036604] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20363,20364,20365},--对应技能表的信息
} 
monster_sk[8036605] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20363,20365},--对应技能表的信息
} 
monster_sk[8025601] = { --技能的ID
    sk_name = "啃咬，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20371},--对应技能表的信息
} 
monster_sk[8025602] = { --技能的ID
    sk_name = "随机脚踩，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20372},--对应技能表的信息
} 
monster_sk[8025603] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20373,20374},--对应技能表的信息
} 
monster_sk[8025604] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 70,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20373,20374,20375},--对应技能表的信息
} 
monster_sk[8025605] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20373,20375},--对应技能表的信息
} 
monster_sk[8031601] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20381},--对应技能表的信息
} 
monster_sk[8031602] = { --技能的ID
    sk_name = "随机一个人，普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20382},--对应技能表的信息
} 
monster_sk[8031603] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20383,20384},--对应技能表的信息
} 
monster_sk[8031604] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20383,20384,20385},--对应技能表的信息
} 
monster_sk[8031605] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20383,20385},--对应技能表的信息
} 
monster_sk[8086601] = { --技能的ID
    sk_name = "随机一个人",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20391},--对应技能表的信息
} 
monster_sk[8086602] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20392,20393},--对应技能表的信息
} 
monster_sk[8086603] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20392,20393,20394},--对应技能表的信息
} 
monster_sk[8086604] = { --技能的ID
    sk_name = "技能序列3",--技能名称
    sk_lv = 4,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20392,20394},--对应技能表的信息
} 
monster_sk[8098601] = { --技能的ID
    sk_name = "75%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20405},--对应技能表的信息
} 
monster_sk[8098602] = { --技能的ID
    sk_name = "50%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20405},--对应技能表的信息
} 
monster_sk[8098603] = { --技能的ID
    sk_name = "25%净化",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 14, -- 触发的时机
       trig_type = 4,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 81050,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20405},--对应技能表的信息
} 
monster_sk[8098604] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20401},--对应技能表的信息
} 
monster_sk[8098605] = { --技能的ID
    sk_name = "远程普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20402},--对应技能表的信息
} 
monster_sk[8098606] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20403,20404},--对应技能表的信息
} 
monster_sk[8098607] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 25,--前端自己判断处理
    },
    sk_skill_id = {20403,20404,20405},--对应技能表的信息
} 
monster_sk[8098608] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20403,20405},--对应技能表的信息
} 
monster_sk[811701] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20272},--对应技能表的信息
} 
monster_sk[811702] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20273},--对应技能表的信息
} 
monster_sk[811703] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20279,20279,20280},--对应技能表的信息
} 
monster_sk[811704] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20279,20280},--对应技能表的信息
} 
monster_sk[811705] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20276},--对应技能表的信息
} 
monster_sk[811706] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 25,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20276},--对应技能表的信息
} 
monster_sk[8132101] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20456},--对应技能表的信息
} 
monster_sk[8132102] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20457},--对应技能表的信息
} 
monster_sk[8132103] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 50,--前端自己判断处理
    },
    sk_skill_id = {20458,20459,20460},--对应技能表的信息
} 
monster_sk[8132104] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20459,20459,20460},--对应技能表的信息
} 
monster_sk[8132105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20461},--对应技能表的信息
} 
monster_sk[8132106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20461},--对应技能表的信息
} 
monster_sk[8132201] = { --技能的ID
    sk_name = "砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20462},--对应技能表的信息
} 
monster_sk[8132202] = { --技能的ID
    sk_name = "随机砍，普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20463},--对应技能表的信息
} 
monster_sk[8132203] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 75,--前端自己判断处理
    },
    sk_skill_id = {20465,20465},--对应技能表的信息
} 
monster_sk[8132204] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 20,--前端自己判断处理
    },
    sk_skill_id = {20465,20465,20466},--对应技能表的信息
} 
monster_sk[8132205] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20465,20466},--对应技能表的信息
} 
monster_sk[8132206] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 75,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20467},--对应技能表的信息
} 
monster_sk[8132207] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20467},--对应技能表的信息
} 
monster_sk[8132208] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20467},--对应技能表的信息
} 
monster_sk[8133101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20470},--对应技能表的信息
} 
monster_sk[8133102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20471},--对应技能表的信息
} 
monster_sk[8133103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20472,20473,20474},--对应技能表的信息
} 
monster_sk[8133104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20472,20473,20474},--对应技能表的信息
} 
monster_sk[8133105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20475},--对应技能表的信息
} 
monster_sk[8133106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {20475},--对应技能表的信息
} 
monster_sk[8121101] = { --技能的ID
    sk_name = "近战普通攻击",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {312101},--对应技能表的信息
} 
monster_sk[8121102] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {312101},--对应技能表的信息
} 
monster_sk[8110302] = { --技能的ID
    sk_name = "技能序列",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 10000,
       start_cd = 5000,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {4397101,4397101,4397201},--对应技能表的信息
} 
monster_sk[8135101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21351},--对应技能表的信息
} 
monster_sk[8135102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21352},--对应技能表的信息
} 
monster_sk[8135103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21356,21355,21353},--对应技能表的信息
} 
monster_sk[8135104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21356,21355,21356,21353},--对应技能表的信息
} 
monster_sk[8135105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21354},--对应技能表的信息
} 
monster_sk[8135106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21354},--对应技能表的信息
} 
monster_sk[8136101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21361},--对应技能表的信息
} 
monster_sk[8136102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21362},--对应技能表的信息
} 
monster_sk[8136103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21363},--对应技能表的信息
} 
monster_sk[8136104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21363,21364,21365},--对应技能表的信息
} 
monster_sk[8136105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21366},--对应技能表的信息
} 
monster_sk[8136106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21366},--对应技能表的信息
} 
monster_sk[8136107] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21363,21364},--对应技能表的信息
} 
monster_sk[8136108] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21363,21364,21365},--对应技能表的信息
} 
monster_sk[8136109] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21363,21364,21364,21365},--对应技能表的信息
} 
monster_sk[8138101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21381},--对应技能表的信息
} 
monster_sk[8138102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21382},--对应技能表的信息
} 
monster_sk[8138103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21383,21384},--对应技能表的信息
} 
monster_sk[8138104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21383,21384,21383,21384,21385},--对应技能表的信息
} 
monster_sk[8138105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21386},--对应技能表的信息
} 
monster_sk[8138106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21386},--对应技能表的信息
} 
monster_sk[8139101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21391},--对应技能表的信息
} 
monster_sk[8139102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21392},--对应技能表的信息
} 
monster_sk[8139103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21393,21394},--对应技能表的信息
} 
monster_sk[8139104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21393,21394,21395},--对应技能表的信息
} 
monster_sk[8139111] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21391},--对应技能表的信息
} 
monster_sk[8139112] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21392},--对应技能表的信息
} 
monster_sk[8139113] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21393,21394},--对应技能表的信息
} 
monster_sk[8139114] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21393,21394,21395,21396},--对应技能表的信息
} 
monster_sk[8139115] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21397},--对应技能表的信息
} 
monster_sk[8139121] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21391},--对应技能表的信息
} 
monster_sk[8139122] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21392},--对应技能表的信息
} 
monster_sk[8139123] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21393,21394},--对应技能表的信息
} 
monster_sk[8139124] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21393,21395,21396},--对应技能表的信息
} 
monster_sk[8139125] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21397},--对应技能表的信息
} 
monster_sk[8139126] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21397},--对应技能表的信息
} 
monster_sk[7142101] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21422},--对应技能表的信息
} 
monster_sk[8144101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21441},--对应技能表的信息
} 
monster_sk[8144102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21442},--对应技能表的信息
} 
monster_sk[8144103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21443,21444},--对应技能表的信息
} 
monster_sk[8144104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21443,21444,21445},--对应技能表的信息
} 
monster_sk[8144105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21446},--对应技能表的信息
} 
monster_sk[8144106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21446},--对应技能表的信息
} 
monster_sk[8146101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21461},--对应技能表的信息
} 
monster_sk[8146102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21462},--对应技能表的信息
} 
monster_sk[8146103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21463,21464},--对应技能表的信息
} 
monster_sk[8146104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21463,21464,21465},--对应技能表的信息
} 
monster_sk[8146105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21466},--对应技能表的信息
} 
monster_sk[8146106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21466},--对应技能表的信息
} 
monster_sk[8151101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21511},--对应技能表的信息
} 
monster_sk[8151102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21512},--对应技能表的信息
} 
monster_sk[8151103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21513,21514},--对应技能表的信息
} 
monster_sk[8151104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21513,21514,21515},--对应技能表的信息
} 
monster_sk[8151105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21516},--对应技能表的信息
} 
monster_sk[8151106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21516},--对应技能表的信息
} 
monster_sk[8152101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21521},--对应技能表的信息
} 
monster_sk[8152102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21522},--对应技能表的信息
} 
monster_sk[8152103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21523,21524},--对应技能表的信息
} 
monster_sk[8152104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21523,21524,21525},--对应技能表的信息
} 
monster_sk[8152105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21526},--对应技能表的信息
} 
monster_sk[8152106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21526},--对应技能表的信息
} 
monster_sk[8153101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21531},--对应技能表的信息
} 
monster_sk[8153102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21532},--对应技能表的信息
} 
monster_sk[8153103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21533,21534},--对应技能表的信息
} 
monster_sk[8153104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21533,21534,21535},--对应技能表的信息
} 
monster_sk[8153105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21536},--对应技能表的信息
} 
monster_sk[8153106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21536},--对应技能表的信息
} 
monster_sk[8154101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21541},--对应技能表的信息
} 
monster_sk[8154102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21542},--对应技能表的信息
} 
monster_sk[8154103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21543,21544},--对应技能表的信息
} 
monster_sk[8154104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21543,21544,21544},--对应技能表的信息
} 
monster_sk[8154105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21545},--对应技能表的信息
} 
monster_sk[8154106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21545},--对应技能表的信息
} 
monster_sk[8155101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21551},--对应技能表的信息
} 
monster_sk[8155102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21552},--对应技能表的信息
} 
monster_sk[8155103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21553,21554},--对应技能表的信息
} 
monster_sk[8155104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21553,21554,21555},--对应技能表的信息
} 
monster_sk[8155105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21556},--对应技能表的信息
} 
monster_sk[8155106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21556},--对应技能表的信息
} 
monster_sk[8156101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21561},--对应技能表的信息
} 
monster_sk[8156102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21562},--对应技能表的信息
} 
monster_sk[8156103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21563,21564},--对应技能表的信息
} 
monster_sk[8156104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21563,21564,21565},--对应技能表的信息
} 
monster_sk[8156105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21566},--对应技能表的信息
} 
monster_sk[8156106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21566},--对应技能表的信息
} 
monster_sk[8122101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21221},--对应技能表的信息
} 
monster_sk[8122102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21222},--对应技能表的信息
} 
monster_sk[8122103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21223,21224},--对应技能表的信息
} 
monster_sk[8122104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21223,21224,21225},--对应技能表的信息
} 
monster_sk[8122105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21226},--对应技能表的信息
} 
monster_sk[8122106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21226},--对应技能表的信息
} 
monster_sk[8157101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21571},--对应技能表的信息
} 
monster_sk[8157102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21572},--对应技能表的信息
} 
monster_sk[8157103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21573,21574},--对应技能表的信息
} 
monster_sk[8157104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21573,21574,21575},--对应技能表的信息
} 
monster_sk[8157105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21576},--对应技能表的信息
} 
monster_sk[8157106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21576},--对应技能表的信息
} 
monster_sk[8158101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21581},--对应技能表的信息
} 
monster_sk[8158102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21582},--对应技能表的信息
} 
monster_sk[8158103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21583,21584},--对应技能表的信息
} 
monster_sk[8158104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21583,21584,21585},--对应技能表的信息
} 
monster_sk[8158105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21586},--对应技能表的信息
} 
monster_sk[8158106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21586},--对应技能表的信息
} 
monster_sk[8158101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21581},--对应技能表的信息
} 
monster_sk[8158102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21582},--对应技能表的信息
} 
monster_sk[8158103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21583,21584},--对应技能表的信息
} 
monster_sk[8158104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21583,21584,21585},--对应技能表的信息
} 
monster_sk[8158105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21586},--对应技能表的信息
} 
monster_sk[8158106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21586},--对应技能表的信息
} 
monster_sk[8159101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21591},--对应技能表的信息
} 
monster_sk[8159102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21592},--对应技能表的信息
} 
monster_sk[8159103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21593,21594},--对应技能表的信息
} 
monster_sk[8159104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21593,21594,21595},--对应技能表的信息
} 
monster_sk[8159105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21596},--对应技能表的信息
} 
monster_sk[8159106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21596},--对应技能表的信息
} 
monster_sk[8160101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21601},--对应技能表的信息
} 
monster_sk[8160102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21602},--对应技能表的信息
} 
monster_sk[8160103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21603,21604},--对应技能表的信息
} 
monster_sk[8160104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21603,21604,21605},--对应技能表的信息
} 
monster_sk[8160105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21603},--对应技能表的信息
} 
monster_sk[8160106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21603},--对应技能表的信息
} 
monster_sk[8161101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21611},--对应技能表的信息
} 
monster_sk[8161102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21612},--对应技能表的信息
} 
monster_sk[8161103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21613,21614},--对应技能表的信息
} 
monster_sk[8161104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21613,21614,21615},--对应技能表的信息
} 
monster_sk[8161105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21616},--对应技能表的信息
} 
monster_sk[8161106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21616},--对应技能表的信息
} 
monster_sk[8162101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21621},--对应技能表的信息
} 
monster_sk[8162102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21622},--对应技能表的信息
} 
monster_sk[8162103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21623,21624},--对应技能表的信息
} 
monster_sk[8162104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21623,21624,21625},--对应技能表的信息
} 
monster_sk[8162105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21626},--对应技能表的信息
} 
monster_sk[8162106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21626},--对应技能表的信息
} 
monster_sk[8163101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21631},--对应技能表的信息
} 
monster_sk[8163102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21632},--对应技能表的信息
} 
monster_sk[8163103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21633,21634},--对应技能表的信息
} 
monster_sk[8163104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21633,21634,21635},--对应技能表的信息
} 
monster_sk[8163105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21636},--对应技能表的信息
} 
monster_sk[8163106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21636},--对应技能表的信息
} 
monster_sk[8164101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21641},--对应技能表的信息
} 
monster_sk[8164102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21642},--对应技能表的信息
} 
monster_sk[8164103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21643,21644},--对应技能表的信息
} 
monster_sk[8164104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21643,21644,21645},--对应技能表的信息
} 
monster_sk[8164105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21646},--对应技能表的信息
} 
monster_sk[8164106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21646},--对应技能表的信息
} 
monster_sk[8165101] = { --技能的ID
    sk_name = "近战普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 15,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 520,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21651},--对应技能表的信息
} 
monster_sk[8165102] = { --技能的ID
    sk_name = "远程普攻",--技能名称
    sk_lv = 1,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 1,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 0,--前端自己判断处理
       trig_num_2 = 0,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21652},--对应技能表的信息
} 
monster_sk[8165103] = { --技能的ID
    sk_name = "技能序列1",--技能名称
    sk_lv = 2,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 100,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21653,21654},--对应技能表的信息
} 
monster_sk[8165104] = { --技能的ID
    sk_name = "技能序列2",--技能名称
    sk_lv = 3,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 0,--触发器判定的目标
       trig_cd = 0,
       start_cd = 0,
       trig_num_1 = 2,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21653,21654,21655},--对应技能表的信息
} 
monster_sk[8165105] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 50,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21656},--对应技能表的信息
} 
monster_sk[8165106] = { --技能的ID
    sk_name = "特殊技能",--技能名称
    sk_lv = 0,-- 技能的等级
    trig_cdn = {--触发的条件
       trig_time = 1, -- 触发的时机
       trig_type = 2,--触发器的类型
       trig_rate = 100,--触发的概率
       trig_target = 1,--触发器判定的目标
       trig_cd = 6000,
       start_cd = 0,
       trig_num_1 = 1,--前端自己判断处理
       trig_num_2 = 20,--前端自己判断处理
       trig_num_3 = 0,--前端自己判断处理
    },
    sk_skill_id = {21656},--对应技能表的信息
} 