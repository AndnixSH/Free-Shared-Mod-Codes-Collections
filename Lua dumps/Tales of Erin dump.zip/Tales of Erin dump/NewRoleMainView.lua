--require "XUIView"

NewRoleMainView = class("NewRoleMainView",XUIView)
NewRoleMainView.CS_FILE_NAME = "NewRoleMainView.csb"
NewRoleMainView.CS_BIND_TABLE = 
{
    vpanel="/i:1807",
    panelBG = "/s:panelBG",
    panelClose = "/i:125",
    panelRightBtn = "/i:22",
    
    btnTab1="/i:22/i:23",
    btnTab2="/i:22/i:24",
    btnTab2Tip="/i:22/i:24/i:414",
    btnTab3="/i:22/i:25",
    btnTab4="/i:22/i:26",
    btnTab5="/i:22/i:339",
    btnTab6="/i:22/i:480",

    btnClose = "/i:125/i:92",

    --all
    roleLeftInfo = "/i:137",
    roleTitleName = "/i:137/i:817",
    roleName = "/i:137/i:463",
    roleIconPos = "/i:137/s:roleIconPos",
    roleElement = "/i:137/i:77",
    roleFrameStar = "/i:137/i:112",
    roleNotGetImg = "/i:137/i:348",
    roleNotGetNode = "/i:137/i:3481",
    roleNotGetNum1 = "/i:137/i:3481/i:163",
    roleNotGetSlash = "/i:137/i:3481/i:164",
    roleNotGetNum2 = "/i:137/i:3481/i:162",
    roleNotGetBtn = "/i:137/i:3481/i:215",
    roleBtnProp = "/i:137/i:275",
    roleBtnPropText = "/i:137/i:275/i:207",
    btnVoice = "/i:137/s:btnVoice",
    btnShare = "/i:137/s:btnShare",
    btnPrevHero = "/i:529",
    btnNextHero = "/i:530",
    imgIntimacyBg = "/i:137/s:imgIntimacyBg",
    imgIntimacy = "/i:137/s:imgIntimacy",
    btnIntimacy = "/i:137/i:659",
    intimacyIconPos = "/i:137/i:570",

}


NewRoleMainView.SKILL_COLOR = cc.c4b(255,192,0,255)
NewRoleMainView.PSKILL_COLOR = cc.c4b(0,232,255,255)
NewRoleMainView.LastTab = 1
NewRoleMainView.VoiceMap = {2,5,7,8,9}

function NewRoleMainView:init(hero_id,other_ids,team_id,tab_pieceid)
    NewRoleMainView.super.init(self)
    self.exist = true;
    self.galleryMode = 0
    self.team_id = team_id
    self.hero_id = hero_id
    self.piece_id = -1
    self.tab_piece_id = {}
    if tab_pieceid then
        self.piece_id = tab_pieceid["piece_id"]
        self.tab_piece_id = tab_pieceid["allPieceId"]
    end
    

    if self.roleLeftInfo then
        self.roleLeftInfo:setVisible(false)
    end
    if self.panelRightBtn then
        self.panelRightBtn:setVisible(false)
    end

    SceneManager:createWaitLayer()
    UITool.delayTask(0.0167,function()  
        self:initSecond(hero_id,other_ids,team_id)
    end)

    return self
end

function NewRoleMainView:initSecond(hero_id,other_ids,team_id)

    self.views = XUIView.new():init(self.vpanel)
    self:InitRoleStateView()
    self:InitRoleSkillView()
    self:InitRoleEquipView()
    --self:InitRoleStarView()
    --self:InitRoleSoulView()
    self:InitRoleStoryView()

    if other_ids then
        self.other_ids = other_ids
        if #self.other_ids <= 1 then
            self.btnPrevHero:setTouchEnabled(false)
            self.btnPrevHero:setBright(false)

            self.btnNextHero:setTouchEnabled(false)
            self.btnNextHero:setBright(false)
        else
            self.other_ids_index = 0
            for i = 1,#self.other_ids do
                if self.hero_id == self.other_ids[i] then
                    self.other_ids_index = i
                    break
                end
            end
        end
        self.btnPrevHero:addClickEventListener(function()
            self:switchHero(-1)
        end)
        self.btnNextHero:addClickEventListener(function()
            self:switchHero(1)
        end)
    else
        self.btnPrevHero:setVisible(false)
        self.btnNextHero:setVisible(false)
    end

    if g_channel_control.b_LikeState then
        self.btnIntimacy:addClickEventListener(function()
            local roleIntimacyView = RoleIntimacyView.new():init(self.hero_id)
            self:addSubView(roleIntimacyView)
        end)
    end

    self.btnVoice:setEffectType(-1)
    self.btnVoice:addClickEventListener(function()
        self:playNestVoice()
    end)

    self.btnShare:setEffectType(-1)
    self.btnShare:setVisible(false)
    self.btnShare:addClickEventListener(function()
        self:toShareRole()
    end)
    ----------
    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)

    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.btnTab4:setPressedActionEnabled(false)
    self.btnTab4:addClickEventListener(function()
        self:switchView(4)
    end)

    self.btnTab5:setPressedActionEnabled(false)
    self.btnTab5:addClickEventListener(function()
        self:switchView(5)
    end)

    self.btnTab6:setPressedActionEnabled(false)
    self.btnTab6:addClickEventListener(function()
        self:switchView(6)
    end)

    self.btnTab1Pos = {self.btnTab1:getPosition()}
    self.btnTab2Pos = {self.btnTab2:getPosition()}
    self.btnTab3Pos = {self.btnTab3:getPosition()}
    self.btnTab4Pos = {self.btnTab4:getPosition()}
    self.btnTab5Pos = {self.btnTab5:getPosition()}
    self.btnTab6Pos = {self.btnTab6:getPosition()}

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:getRootNode():stopAllActions()
        
        if self.asyncHandler2 then
            self.asyncHandler2:cancel(true)
            self.asyncHandler2 = nil
        end

        self:returnBack()
    end)

    --开启角色
    self.roleNotGetBtn:addClickEventListener(function()
        self:confirmHeroOpen()
    end)

    ---

    --角色额外提升属性
    self.roleBtnProp:addClickEventListener(function()
        if self.galleryMode == 2 and self.hero_data ~= nil then
            local h_id_num = getNumID( self.hero_id )

            self.roleInfoPropView = RoleInfoPropView.new():init()

            self.roleInfoPropView.returnBack = function(s)
                s:removeFromParentView()
                self.roleInfoPropView = nil
            end

            self.roleInfoPropView.addPropEvent = function(s,matCount,pieceCount,RealPieceCount,f_call)
                self:OnAddProp(matCount,pieceCount,RealPieceCount,f_call)
            end
            self:addSubView(self.roleInfoPropView)
            self.roleInfoPropView:loadData(self.hero_data.hero_add_values,h_id_num,self.hero_data.hero_add,self.need_piece_id)
        end
    end)

    self.roleEAtb = cc.CSLoader:createNode("EffElementAll.csb")    
    self.roleEAtb:setPosition(self.roleElement:getPosition())
    self.roleElement:getParent():addChild(self.roleEAtb)

    self.roleEAtbAct = cc.CSLoader:createTimeline("EffElementAll.csb")
    self.roleEAtb:runAction(self.roleEAtbAct)
    self.roleEAtbAct:play("reset",false)
    --


    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self.bHadReloadSoul = true

    
    if self.roleLeftInfo then
        self.roleLeftInfo:setVisible(true)
    end
    if self.panelRightBtn then
        self.panelRightBtn:setVisible(true)
    end

    self:refreshStaticState()

    self:lastView()

    self:refresh()

    self:setNodeLockState()

    --

    local ctls = {
        {btn = self.btnTab1, view= self.roleStateView},
        {btn = self.btnTab2, view= self.roleSkillView},
        {btn = self.btnTab3, view= self.roleEquipView},
        {btn = self.btnTab4, view= self.roleStarView},
        {btn = self.btnTab5, view= self.roleSoulView},
        {btn = self.btnTab6, view= self.roleStoryView},
    }
    local time_id = getTimeNumID( self.hero_id )
    if time_id <= 10 then
        --未获取时界面状态
        for i = 3,5 do
            ctls[i].btn:setTouchEnabled(false)
            ctls[i].btn:setVisible(false)
        end
        ctls[6].btn:setTouchEnabled(true)
        ctls[6].btn:setVisible(true)
    end

    --请求背包数据
    self:loadBagList()

    --self:loadInfo(false)

    --SceneManager:delWaitLayer()

    -- return self
end

function NewRoleMainView:ReLoadHeroInfo()
    self:loadInfo(true)
end

function NewRoleMainView:InitRoleStateView()
    if not self.hero_id then
        return
    end

    self.roleStateView = NewRoleStateView.new():init(self.hero_id,self.ReLoadHeroInfo,self)
    self.views:addSubView(self.roleStateView)
end

function NewRoleMainView:InitRoleSkillView()
    if not self.hero_id then
        return
    end

    self.roleSkillView = NewRoleSkillView.new():init(self.hero_id,self.SkillAdd,self.ReLoadHeroInfo,self)
    self.views:addSubView(self.roleSkillView)
end

function NewRoleMainView:InitRoleEquipView()
    if not self.hero_id then
        return
    end

    self.roleEquipView = NewRoleEquipView.new():init(self.hero_id,self.ReLoadHeroInfo,self)
    self.views:addSubView(self.roleEquipView)
end

function NewRoleMainView:InitRoleSoulView()
    if not self.hero_id then
        return
    end

    self.roleSoulView = NewRoleSoulView.new():init(self.hero_id,self.ReLoadHeroInfo,self.reloadSoulFinish,self)
    self.views:addSubView(self.roleSoulView)
end

function NewRoleMainView:InitRoleStarView()
    if not self.hero_id then
        return
    end
    self.roleStarView = NewRoleStarView.new():init(self.ReLoadHeroInfo,self)
    self.views:addSubView(self.roleStarView)
end

function NewRoleMainView:InitRoleStoryView()
    if not self.hero_id then
        return
    end

    self.roleStoryView = NewRoleStoryView.new():init(self.hero_id)
    self.views:addSubView(self.roleStoryView)
end

function NewRoleMainView:lastView()
    local num = NewRoleMainView.LastTab or 1

    local ctls = {
        {btn = self.btnTab1, view= self.roleStateView},
        {btn = self.btnTab2, view= self.roleSkillView},
        {btn = self.btnTab3, view= self.roleEquipView},
        {btn = self.btnTab4, view= self.roleStarView},
        {btn = self.btnTab5, view= self.roleSoulView},
        {btn = self.btnTab6, view= self.roleStoryView},
    }

    local time_id = getTimeNumID( self.hero_id )
    if time_id <= 10 then
        --未获取时界面状态
        num = 1
    end

    if self.curTab ~= num then
        if num == 5 then
            self:InitRoleSoulView()
            if self.roleStarView then
                self.roleStarView:getRootNode():removeFromParent()
                self.roleStarView = nil
            end
        elseif num == 4 then
            self:InitRoleStarView()
            if self.roleStarView then
                self.roleStarView:FillHeroData(self.hero_data,self.hero_id )
            end
            if self.roleSoulView then
                self.roleSoulView:getRootNode():removeFromParent()
                self.roleSoulView = nil
            end
        else
            if self.roleSoulView then
                self.roleSoulView:getRootNode():removeFromParent()
                self.roleSoulView = nil
            end
            if self.roleStarView then
                self.roleStarView:getRootNode():removeFromParent()
                self.roleStarView = nil
            end
        end

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            ctls[i].btn:setBright(i ~= num)
            if i ~= 5 and i ~= 4 then
                ctls[i].view:getRootNode():setVisible(i == num)
            end
        end
        
        self.curTab = num

        if self.curTab == 5 then
            self.roleLeftInfo:setVisible(false)
        else
            self.roleLeftInfo:setVisible(true)
        end

        --切换页签隐藏子界面
        if self.roleStateView then
            self.roleStateView:resetViewsState()
        end
        if self.roleSkillView then
            self.roleSkillView:resetViewsState()
        end
        if self.roleEquipView then
            self.roleEquipView:resetViewsState()
        end

    end
    self:setNodeLockState()

    if  time_id > 10 then 
        self:dealTriggerGuide(self.curTab)
    end  
end

function NewRoleMainView:dealTriggerGuide(tab)
    --触发引导-角色技能+点
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.RoleSkill) then 
        if tab == 2 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 6, TriggerGuideConfig.RoleSkill)--技能加点按钮
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.RoleSkill)--技能标签
        end
    end 

    --触发引导-装备
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Equip) then 
        if tab == 3 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 6, TriggerGuideConfig.Equip)--灵装槽位
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.Equip)--装备标签
        end
    end 

    --触发引导-魂灵装
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.HunEquip) then 
        if tab == 5 then 
            XbTriggerGuideManager:finishGuide(TriggerGuideConfig.HunEquip, self)
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.HunEquip)
        end
    end 

    --触发引导-星盘
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Star) then 
        if tab == 4 then 
            XbTriggerGuideManager:finishGuide(TriggerGuideConfig.Star, self)
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.Star)
        end
    end 

end

function NewRoleMainView:switchView(tab)
    local num = tab or 1
    if self.galleryMode == 2 then
        num = tab or NewRoleMainView.LastTab
    end

    local ctls = {
        {btn = self.btnTab1, view= self.roleStateView},
        {btn = self.btnTab2, view= self.roleSkillView},
        {btn = self.btnTab3, view= self.roleEquipView},
        {btn = self.btnTab4, view= self.roleStarView},
        {btn = self.btnTab5, view= self.roleSoulView},
        {btn = self.btnTab6, view= self.roleStoryView},
    }

    local time_id = getTimeNumID( self.hero_id )

    if self.curTab ~= num then
        if num == 5 then
            self:InitRoleSoulView()
            self.roleSoulView:ResetHeroId(self.hero_id)
            if self.roleStarView then
                self.roleStarView:getRootNode():removeFromParent()
                self.roleStarView = nil
            end
        elseif num == 4 then
            self:InitRoleStarView()
            if self.roleStarView then
                self.roleStarView:FillHeroData(self.hero_data,self.hero_id )
            end
            if self.roleSoulView then
                self.roleSoulView:getRootNode():removeFromParent()
                self.roleSoulView = nil
            end
        else
            if self.roleSoulView then
                self.roleSoulView:getRootNode():removeFromParent()
                self.roleSoulView = nil
            end
            if self.roleStarView then
                self.roleStarView:getRootNode():removeFromParent()
                self.roleStarView = nil
            end
        end

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            ctls[i].btn:setBright(i ~= num)
            if i ~= 5 and i ~= 4 then
                ctls[i].view:getRootNode():setVisible(i == num)
            end
        end
        
        self.curTab = num

        if self.curTab == 5 then
            self.roleLeftInfo:setVisible(false)
        else
            self.roleLeftInfo:setVisible(true)
        end

        if self.galleryMode == 2 then
            NewRoleMainView.LastTab = num
            --self.roleBtnProp:setVisible(self.curTab ~= 2)
        end
        --切换页签隐藏子界面
        if self.roleStateView then
            self.roleStateView:resetViewsState()
        end
        if self.roleSkillView then
            self.roleSkillView:resetViewsState()
        end
        if self.roleEquipView then
            self.roleEquipView:resetViewsState()
        end

    end
    self:setNodeLockState()

    if  time_id > 10 then
        self:dealTriggerGuide(tab)  
    end   
end

function NewRoleMainView:switchHero(offect)
    if self.bHadReloadSoul then
        if self.curTab == 5 then
            self.bHadReloadSoul = false
        end
        
        self:getRootNode():stopAllActions()

        self.other_ids_index = self.other_ids_index + offect
        if self.other_ids_index < 1 then
            self.other_ids_index = #self.other_ids
        elseif self.other_ids_index > #self.other_ids then
            self.other_ids_index = 1
        end

        self.hero_id = self.other_ids[self.other_ids_index]
        self.piece_id = self.tab_piece_id[self.other_ids_index]
        self.hero_data = nil

        self:ReLoadHeroInfo()

        self:refreshStaticState()
        self:refresh()
        
        -- self:loadInfo(false)
        -- self.roleSoulView:ResetHeroId(self.hero_id)
    end
end

function NewRoleMainView:reloadSoulFinish()
    self.bHadReloadSoul = true
end

---上帝才知道是做什么用的
function NewRoleMainView:loadInfo1(tempTable)
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            self.hero_data = table.deepcopy(data["hero_info"])
            
            if data["fp_all_in_team"] ~= nil then
                self.hero_data.fp_all = table.deepcopy(data["fp_all_in_team"])
            end
            self.roleStateView:FillHeroData(self.hero_data)
            self.roleSkillView:FillHeroData(self.hero_data)
            self.roleEquipView:FillHeroData(self.hero_data)
            
            if self.roleSoulView then
                self.roleSoulView:ResetHeroId(self.hero_id)
            end
            --self.roleSoulView:LoadSoulEquipData()
            self.roleStoryView:FillHeroData(self.hero_data)
            if g_channel_control.b_Astrolabe then
                if self.roleStarView then
                    self.roleStarView:FillHeroData(self.hero_data,self.hero_id )--self.hero_id 
                end
            end

            if self.roleInfoPropView then
                local h_id_num = getNumID( self.hero_id )
                self.roleInfoPropView:loadData(self.hero_data.hero_add_values,h_id_num,self.hero_data.hero_add,self.need_piece_id)
            end

            if user_info["hero"][data["hero_info"].id] then
                for k,v in pairs(user_info["hero"][data["hero_info"].id]) do
                    user_info["hero"][data["hero_info"].id][k] = table.deepcopy(data["hero_info"][k])
                end
                DataManager:rfsHlist()
            end
            self:refresh()
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end

function NewRoleMainView:loadInfo(bRefresh)
    
    if not self.hero_id then return end

    --图鉴界面时，加载假数据
    local h_id_num = getNumID( self.hero_id )
    local time_id = getTimeNumID( self.hero_id )

    if time_id > 10 then
        local tempTable = {
                rpc = "hero_info",
                hero_id = self.hero_id
            }

        if self.team_id then
            tempTable["team_id"] = ""..self.team_id
        end

        if bRefresh and self.hero_data ~= nil and #self.hero_data.team_list > 0 then            
            self:loadTeamList(function()
                self:loadInfo1(tempTable)
            end)
            return
        end

        --已获得角色，读取数据
        GameManagerInst:rpc( 
            tempTable,
            3,
            function(data)
                --success
                if self.exist == false then
                    return
                end
                self.hero_data = table.deepcopy(data["hero_info"])
                dump(self.hero_data, "self.hero_data")
                self.need_piece_id = data["need_piece_id"]
                
                if data["fp_all_in_team"] ~= nil then
                    self.hero_data.fp_all = table.deepcopy(data["fp_all_in_team"])
                end
                if self.roleStateView then
                    self.roleStateView:FillHeroData(self.hero_data)
                end
                if self.roleSkillView then
                    self.roleSkillView:FillHeroData(self.hero_data)
                end
                if self.roleEquipView then
                    self.roleEquipView:FillHeroData(self.hero_data)
                end
                
                if self.roleSoulView then
                    self.roleSoulView:ResetHeroId(self.hero_id)
                end
                --self.roleSoulView:LoadSoulEquipData()
                if self.roleStoryView then
                    self.roleStoryView:FillHeroData(self.hero_data)
                end
                
                if g_channel_control.b_Astrolabe then
                    if self.roleStarView then
                        self.roleStarView:FillHeroData(self.hero_data,self.hero_id )--self.hero_id
                    end
                end

                if bRefresh then
                    if user_info["hero"][data["hero_info"].id] then
                        for k,v in pairs(user_info["hero"][data["hero_info"].id]) do
                            user_info["hero"][data["hero_info"].id][k] = table.deepcopy(data["hero_info"][k])
                        end
                        DataManager:rfsHlist()
                    end
                    self:refresh()
                else
                    self:refresh()
                end
                if self.roleInfoPropView then
                    local h_id_num = getNumID( self.hero_id )
                    self.roleInfoPropView:loadData(self.hero_data.hero_add_values,h_id_num,self.hero_data.hero_add,self.need_piece_id)
                end

            end,
            function(state_code,msgText)
                --failed
                if self.exist == false then
                    return
                end
                GameManagerInst:alert(msgText)
            end,
            true)
    else
        --未获得角色
        local tdata = {}
        
        tdata.id = self.hero_id
        tdata.piece_id = self.piece_id
        tdata.hero_add = 0
        tdata.Lv = 120
        tdata.Lv_max = 120
        tdata.exp = 0
        tdata.exp_max = 120
        tdata.hp = hero_upgrade[h_id_num][120][2]
        tdata.atk = hero_upgrade[h_id_num][120][3]
        tdata.def = hero_upgrade[h_id_num][120][4]
        tdata.crit = hero_upgrade[h_id_num][120][5]
        tdata.crit_dmg = hero_upgrade[h_id_num][120][6]
        tdata.hel = hero_upgrade[h_id_num][120][9]
        tdata.asp = hero_upgrade[h_id_num][120][7]
        -- tdata.add_sk_dmg = 0
        -- tdata.add_dmg = 0
        -- tdata.atk_rate = 0
        -- tdata.hp_rate = 0
        tdata.break_count = 5
        tdata.eq = {}
        tdata.eq["1"] = { eq_id = "", eq_info = {} }
        tdata.eq["2"] = { eq_id = "", eq_info = {} }
        tdata.eq["3"] = { eq_id = "", eq_info = {} }
        tdata.tp = { max_num = 40 , num = 0 , from_other = 0}
        tdata.fp_all = {
            all = 0 ,
            hp = tdata.hp,
            atk = tdata.atk,
            def = tdata.def,
            crit = tdata.crit,
            crit_dmg = tdata.crit_dmg,
            hel = tdata.hel,
            asp = tdata.asp,
            add_sk_dmg = 0,
            add_dmg = 0,
            atk_rate = 0,
            hp_rate = 0,
        }
        tdata.base_data = {
            atk = tdata.atk,
            hp = tdata.hp,
            def = tdata.def,
        }
        tdata.rarity = hero[h_id_num].hero_rank
        tdata.element = hero[h_id_num].hero_atb

        tdata.active_sk = {}
        tdata.active_sk["1"] = {lv = 10 ,max_lv = 10, id = (4000110 + h_id_num * 1000)}
        tdata.active_sk["2"] = {lv = 10 ,max_lv = 10, id = (4000210 + h_id_num * 1000)}

        tdata.passive_sk = {}
        tdata.passive_sk["1"] = {lv = 10 ,max_lv = 10, id = (5000110 + h_id_num * 1000)}
        tdata.passive_sk["2"] = {lv = 10 ,max_lv = 10, id = (5000210 + h_id_num * 1000)}

        local s_like_feel_state = {}  --好感度数据
        s_like_feel_state.id = 13
        s_like_feel_state.lv = 1
        s_like_feel_state.resonance = 1
        s_like_feel_state.icon_state = 1

        tdata.like_feel_state = s_like_feel_state

        self.hero_data = tdata
        local function f_call( ... )
            self:loadBagList()
        end
        self:refresh()
        self.roleStateView:FillHeroData(self.hero_data,f_call)
        self.roleSkillView:FillHeroData(self.hero_data)
        self.roleEquipView:FillHeroData(self.hero_data)
        self.bHadReloadSoul = true
        if self.roleSoulView then
            self.roleSoulView:ResetHeroId(self.hero_id)
        end
        if self.roleInfoPropView then
            local h_id_num = getNumID( self.hero_id )
            self.roleInfoPropView:loadData(self.hero_data.hero_add_values,h_id_num,self.hero_data.hero_add,self.need_piece_id)
        end
        --self.roleSoulView:LoadSoulEquipData()
        self.roleStoryView:FillHeroData(self.hero_data)
        if g_channel_control.b_Astrolabe then
            if self.roleStarView then
                self.roleStarView:FillHeroData(self.hero_data,self.hero_id )--self.hero_id 
            end
        end
    end
end

function NewRoleMainView:loadTeamList(callback)
    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success

        DataManager:wTeamData(data["team"])

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleMainView:refreshState()
    if self.hero_data then
        --有数据        
        local h_id_num = getNumID( self.hero_id )
        local time_id = getTimeNumID( self.hero_id )

        --重复抽卡加成，变色
        local tempTextColor = cc.c3b(255,255,255)
        local titlename = ""
        if self.hero_data.hero_add > 0 then
            for i = 1,#color_hero_bouns do
                local coloritem = color_hero_bouns[i]
                if self.hero_data.hero_add >= coloritem[1] then
                    tempTextColor = cc.c3b(coloritem[2], coloritem[3], coloritem[4])                    
                    if string.len(title_hero_conf[h_id_num]["title"][i]) > 0 then
                        titlename = title_hero_conf[h_id_num]["title"][i].." "
                    else
                        titlename = ""
                    end
                end
            end

            self.roleBtnPropText:setString(""..self.hero_data.hero_add)
        else
            self.roleBtnPropText:setString("0")
        end

        self.roleName:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))--(hero[h_id_num].hero_name)
        self.roleName:setTextColor(tempTextColor)

        self.roleTitleName:setString(UITool.getUserLanguage(titlename))
        --self.roleTitleName:setTextColor(tempTextColor)
        --
        self.btnTab2Tip:setVisible(self.hero_data.tp.num > 0)

        if g_channel_control.b_LikeState then
            --好感度
            if time_id > 10 then
                local intimacyState = self.hero_data.like_feel_state.icon_state
                self:startGMeffect(intimacyState)
                if intimacyState then
                    local intimacy = like_state[intimacyState].icon_max
                    if intimacy then
                        self.imgIntimacy:setTexture(intimacy)
                        self.imgIntimacy:setVisible(true)
                        self.imgIntimacyBg:setVisible(true)
                    end
                    self.btnIntimacy:setTouchEnabled(true)
                    self.btnIntimacy:setVisible(true)
                end
            else
                self.imgIntimacyBg:setVisible(false)
                self.imgIntimacy:setVisible(false)
                self.btnIntimacy:setTouchEnabled(false)
                self.btnIntimacy:setVisible(false)
            end
            -- local intimacyState = self.hero_data.like_feel_state.icon_state
            -- self:startGMeffect(intimacyState)
            -- if intimacyState then
            --     local intimacy = like_state[intimacyState].icon_max
            --     if intimacy then
            --         self.imgIntimacy:setTexture(intimacy)
            --         self.imgIntimacy:setVisible(true)
            --         self.imgIntimacyBg:setVisible(true)
            --     end
            --     self.btnIntimacy:setTouchEnabled(true)
            --     self.btnIntimacy:setVisible(true)
            -- end
        else
            self.imgIntimacyBg:setVisible(false)
            self.imgIntimacy:setVisible(false)
            self.btnIntimacy:setTouchEnabled(false)
            self.btnIntimacy:setVisible(false)
        end
    end
    
end

function NewRoleMainView:refreshStaticState()

    local time_id = getTimeNumID( self.hero_id )
    local h_id_num = getNumID( self.hero_id )

    --背景  effects/juesexiangqin
    --local bganimefile = nil

    if time_id > 10 then
        --已获取时界面状态
        if self.galleryMode ~= 2 then
            self.galleryMode = 2
            local platform = cc.Application:getInstance():getTargetPlatform()
            if (cc.PLATFORM_OS_ANDROID == platform) then
                self.btnShare:setVisible(false)--暂时屏蔽分享按钮
            else
                self.btnShare:setVisible(false)--暂时屏蔽分享按钮
            end
        end   
    else
        --未获取时界面状态
        if self.galleryMode ~= 1 then
            self.galleryMode = 1
            self.btnShare:setVisible(false)
        end
        self.imgIntimacyBg:setVisible(false)
        self.imgIntimacy:setVisible(false)
        self.btnIntimacy:setTouchEnabled(false)
        self.btnIntimacy:setVisible(false)       
    end

    if self.galleryMode == 1 then
        if time_id == 0 then --未获得
            self.roleNotGetImg:setVisible(true)
            self.btnVoice:setVisible(false)
            self:showHeroOpen(h_id_num)
        else
            self.roleNotGetImg:setVisible(false)
            self.btnVoice:setVisible(true)
            self.roleNotGetNode:setVisible(false)
        end

        self.roleBtnProp:setVisible(false)
    else
        self.roleNotGetImg:setVisible(false)
        self.roleNotGetNode:setVisible(false)
        -- self.roleBtnProp:setVisible(self.curTab ~= 2)
        -- self.roleBtnPropText:setString("")
        
        self.btnVoice:setVisible(true)
    end
    ---

    self.currentVoiceIndex = 1

    --动态模型，立绘
    local lihuifile = hero[h_id_num].hero_des_spi

    self.roleIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(lihuifile) then

        local end_pos = string.find(lihuifile,'atlas') - 1
        local spName = string.sub(lihuifile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil

            local rps = self.roleIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2 , rps.height / 2))
            self.roleIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect1", true)
            
            if time_id == 0 then
                --未获得
                roleIcon:setColor(cc.c3b(0,0,0))
            end
        end)
    end

    self.roleName:setString("")
    self.roleName:setTextColor(cc.c3b(255,255,255))
    self.roleTitleName:setString("")
    --self.roleTitleName:setTextColor(cc.c3b(255,255,255))
    --self.roleIcon:setTexture(hero[h_id_num].hero_xq_icon)  --立绘大图
    local hero_atb = hero[h_id_num].hero_atb

    self.roleElement:setTexture(ATB_Icon[hero_atb]) --属性球
    if hero_atb == 1 then
        self.roleEAtbAct:play("shui",true)
    elseif hero_atb == 2 then
        self.roleEAtbAct:play("huo",true)
    elseif hero_atb == 3 then
        self.roleEAtbAct:play("feng",true)
    elseif hero_atb == 4 then
        self.roleEAtbAct:play("guang",true)
    elseif hero_atb == 5 then
        self.roleEAtbAct:play("an",true)
    else
        self.roleEAtbAct:play("reset",false)
    end

    local hrank = hero[h_id_num].hero_rank
    self.roleFrameStar:setTexture(getNewRoleRank(hrank))

end

function NewRoleMainView:SkillAdd(bAdd)
    if bAdd then
        self.panelClose:setVisible(true)
        self.panelRightBtn:setVisible(true)

        if self.other_ids then        
            self.btnPrevHero:setVisible(true)
            self.btnNextHero:setVisible(true)
        end
    else
        self.panelClose:setVisible(false)
        self.panelRightBtn:setVisible(false)
        self.btnPrevHero:setVisible(false)
        self.btnNextHero:setVisible(false)
    end
end

--角色自选功能
function NewRoleMainView:showHeroOpen(h_id_num)
    if hero_open == nil or hero_open[h_id_num] == nil then
        self.roleNotGetNode:setVisible(false)
    end

    local hoinfo = hero_open[h_id_num]
    
    --[[{
        "need_mat_num": 50,
        "hero_id": 23,
        "can_choose": 0
    },]]

    if hoinfo.can_choose == 0 then
        self.roleNotGetNode:setVisible(false)
    else
        --之后 如果新增自选商店，点击也复用此处逻辑，再做处理
        if g_channel_control.open_NewHeroBookLayer then
            self.roleNotGetNode:setVisible(false)
        else 
            self.roleNotGetNode:setVisible(true)
            local mat_opt = user_info["bag"]["mat"][ID_HERO_OPT] or 0
            self.roleNotGetNum1:setString(""..mat_opt)
            self.roleNotGetNum2:setString(""..hoinfo.need_mat_num)
            
            if mat_opt < hoinfo.need_mat_num then
                self.roleNotGetNum1:setTextColor(cc.c3b(255,0,0))
            else
                self.roleNotGetNum1:setTextColor(cc.c3b(96,255,0))
            end

            self.roleNotGetSlash:setPosition(self.roleNotGetNum2:getPositionX() - self.roleNotGetNum2:getContentSize().width,self.roleNotGetNum2:getPositionY())
            self.roleNotGetNum1:setPosition(self.roleNotGetSlash:getPositionX() - self.roleNotGetSlash:getContentSize().width,self.roleNotGetSlash:getPositionY())  
        end 
    end

end

function NewRoleMainView:confirmHeroOpen()
    if not self.hero_id then return end
    local h_id_num = getNumID( self.hero_id )
    local hoinfo = hero_open[h_id_num]
    if hoinfo then
        local mat_id = getMatID( ID_HERO_OPT )
       -- local msg = UITool.ToLocalization("是否花费")..hoinfo.need_mat_num..UITool.ToLocalization("个")..mat[mat_id].name..UITool.ToLocalization("召唤 ")..hero[h_id_num].hero_name
        local msg = string.format(UITool.ToLocalization("是否花费%d个%s召唤%s"),hoinfo.need_mat_num,mat[mat_id].name,UITool.getUserLanguage(hero[h_id_num].hero_name))
        GameManagerInst:confirm(msg,function()
            local mat_opt = user_info["bag"]["mat"][ID_HERO_OPT] or 0
            if mat_opt < hoinfo.need_mat_num then
                GameManagerInst:alert(UITool.ToLocalization("您的道具不足，无法召唤角色。"))
            else
                self:sendHeroOpen()
            end
        end)
    end
end

function NewRoleMainView:sendHeroOpen()
    if not self.hero_id then return end
    
    local h_id_num = getNumID( self.hero_id )

    local tempData = {
        rpc = "hero_choose",
        static_id = h_id_num,
    }
    
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        -- {
        --     "state_code":  1,
        --     "opt_count":  12,
        --     "get_hero_id":  "13*123124121",  # 自选到的英雄id
        -- }
        if self.exist == false then
            return
        end
        if user_info["bag"]["mat"][ID_HERO_OPT] then
             user_info["bag"]["mat"][ID_HERO_OPT] = data.opt_count
        end

        if self.other_ids then
            for i = 1,#self.other_ids do
                if self.other_ids[i] == self.hero_id then
                    self.other_ids[i] = ""..h_id_num.."*1"
                end
            end
        end

        self.hero_id = ""..h_id_num.."*1"
        GalleryView.needReload = true

        local getdata = {
        {
            story = "hero_"..h_id_num,
            id = h_id_num,
            type = 4,
            is_new = 1,
            change_to = {},
            element = hero[h_id_num].hero_atb,
            rarity = hero[h_id_num].hero_rank,
            in_mail = 0
        }}

        if GameManagerInst.gameType == 2 then
            SceneManager:toDrawCardEndLayer({   itemList = getdata,
                                                finalFunc = function()
                                                        self:refreshStaticState()
                                                        self:loadInfo(true)
                                                end
                                                })
        end
        
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleMainView:refresh()
    self:refreshState()
    -- self.roleStateView:refresh()
    -- self.roleSkillView:refresh()
    -- self.roleEquipView:refresh()
    -- self.roleSoulView:refresh()
end

function NewRoleMainView:playNestVoice()
    if not self.hero_data then return end

    local h_id_num = getNumID( self.hero_id )

    local voiceIdx = NewRoleMainView.VoiceMap[self.currentVoiceIndex]
    local voicepath  = hero[h_id_num].hero_vce[voiceIdx]

    if self.voice_handle then        
        AudioManager:shareDataManager():stop(self.voice_handle)
    end

    --语音音效，type类型改为1，原来是0
    self.voice_handle = AudioManager:shareDataManager():playMusic( voicepath ,1, false)

    self.currentVoiceIndex = self.currentVoiceIndex + 1
    if self.currentVoiceIndex > #NewRoleMainView.VoiceMap then
        self.currentVoiceIndex = 1
    end

end

function NewRoleMainView:toShareRole()
    if not self.hero_data then return end
    local h_id_num = getNumID( self.hero_id )
    local heroID = h_id_num
    if not hero[heroID] then return end
    local rcvData = {}
    rcvData.heroID = heroID
    SceneManager:toShareRoleLayer(rcvData)
end

function NewRoleMainView:OnAddProp(matNum,pieceNum,RealPieceCount,f_call)
    if not self.hero_data then return end

    local tempData = {
        rpc = "hero_extra_add",
        hero_id = self.hero_id,
        add_num = matNum,
        piece_add_num = pieceNum
    }

    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        if f_call then
            f_call()
        end
        if user_info["bag"]["mat"][ID_ROLE_ADDPROP] then
            user_info["bag"]["mat"][ID_ROLE_ADDPROP] = user_info["bag"]["mat"][ID_ROLE_ADDPROP] - matNum
        end
        if user_info["bag"]["useprop"] and user_info["bag"]["useprop"][self.need_piece_id] and user_info["bag"]["useprop"][self.need_piece_id]["num"] then
            user_info["bag"]["useprop"][self.need_piece_id]["num"] = user_info["bag"]["useprop"][self.need_piece_id]["num"] - RealPieceCount
        end
        
        self:loadInfo(true)
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleMainView:returnBack()
    self.exist = false
    if g_channel_control.b_newRole then
        self:DestroyHandle()
    end

    if self.keyboardValue then
        KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    end
    if self._navigationView then
        self._navigationView:popView()
    end
end

function NewRoleMainView:onNavigateTo(isback)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        self:loadInfo(true)
        self:refresh()
    else
        --self:loadInfo(false)
    end
end

--设置按钮等级解锁状态
function NewRoleMainView:setNodeLockState()
    local btn5Limit = guide_rank_config["RoleInfoView"][4].unlock_level
    local time_id = 0
    if self.hero_id then
        local h_id_num = getNumID( self.hero_id )
        btn5Limit = hero_soul[h_id_num].open_lv
        time_id = getTimeNumID( self.hero_id )
    end

    local ctls = {self.btnTab1,self.btnTab2, self.btnTab3, self.btnTab4, self.btnTab5,self.btnTab6}

    local curNodes = {self.btnTab2, self.btnTab3, self.btnTab4, self.btnTab5}

    if g_channel_control.UIVersion < 2 then
        if time_id <= 10 then
            --未获取时界面状态
            for i = 3,5 do--隐藏装备、星盘、魂灵装页签
                ctls[i]:setVisible(false)
            end
            ctls[6]:setVisible(true)--显示故事页签
        else
            --已获取时界面状态
            local bStarShow = false--星盘是否符合显示等级
            for i=1,#curNodes do
                local config = guide_rank_config["RoleInfoView"][i]
                local btn = curNodes[i]
                if config.unlock_level > tonumber(user_info["rank"]) then 
                    if config.state == 0 then 
                        btn:setVisible(false)
                    end
                else
                    btn:setVisible(true)
                        if i == 3 then
                            --星盘符合显示等级
                            bStarShow = true
                        end
                end
                if i == 4 then
                    if tonumber(btn5Limit) > tonumber(user_info["rank"]) then
                        btn:setVisible(false)
                    else
                        btn:setVisible(true)
                    end
                end
            end
            if g_channel_control.b_Astrolabe and bStarShow then
                --已开启星盘
                ctls[4]:setVisible(true)
                ctls[5]:setPosition(self.btnTab5Pos[1],self.btnTab5Pos[2])
            else
                --未开启星盘
                ctls[4]:setVisible(false)
                ctls[5]:setPosition(self.btnTab4Pos[1],self.btnTab4Pos[2]) 
            end
            ctls[6]:setVisible(false)--隐藏故事页签
        end
    else

        if time_id <= 10 then
            --未获取时界面状态
            for i = 3,5 do--隐藏装备、星盘、魂灵装页签
                ctls[i]:setVisible(false)
            end
            ctls[6]:setVisible(true)--显示故事页签
        else
            for i = 3,5 do--隐藏装备、星盘、魂灵装页签
                ctls[i]:setVisible(true)
            end
            ctls[6]:setVisible(false)--隐藏故事页签
        end
        UnlockSys:getInstance():bindLock(7, self.btnTab1, true)
        UnlockSys:getInstance():bindLock(8, self.btnTab2, true)
        UnlockSys:getInstance():bindLock(9, self.btnTab3, true)
        UnlockSys:getInstance():bindLock(10, self.btnTab4, true)
        UnlockSys:getInstance():bindLock(11, self.btnTab5, true)
         
    end
end
--设置按钮等级解锁状态
function NewRoleMainView:setEquipNodeLockState()
    --local curNodes = {self.eqBtnSkill, self.eqBtnSth, self.eqBtnAwaken}
    local curNodes = {self.eqBtnSth}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleInfoView_Equip"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        else 
            btn:setVisible(true)
        end 
    end   
end

function NewRoleMainView:DestroyHandle()
    self.exist = false
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end
    if self.roleStateView then
        self.roleStateView:DestroyHandle()
    end
    if self.roleSoulView then
        self.roleStateView:DestroyHandle()
    end
    if self.roleEquipView then
        self.roleEquipView:DestroyHandle()
    end
    if self.roleSkillView then
        self.roleSkillView:DestroyHandle()
    end
end

--好感度新增动画 start
function NewRoleMainView:startGMeffect(intimacyState)
    --local effectFile = "Resources/armatures/intimacy/gong_ming_fen_2/gong_ming_fen_2.atlas" --特效资源路径
    local effectFile = like_state[intimacyState].detail_special_effect --特效资源路径

    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(effectFile) then
        local end_pos = string.find(effectFile,'atlas') - 1
        local spName = string.sub(effectFile,0,end_pos)
        self.asyncHandler1 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler1 = nil

            local rps = self.intimacyIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2, rps.height / 2))
            roleIcon:setScale(1)
            self.intimacyIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect", true)
        end)
    end
end

function NewRoleMainView:stopGMeffect()
    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end
end
--好感度新增动画 end

function NewRoleMainView:loadBagList()
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        DataManager:wAllBagData(data["bag"])
        self:loadInfo(false)
        --self:refreshPropNum()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end
