--/*说明

--*/
NewRoleStarView = class("NewRoleStarView",XUIView)
NewRoleStarView.CS_FILE_NAME = "NewRoleStateAstrolabeLayer.csb"
NewRoleStarView.CS_BIND_TABLE = 
{

    rootPanel    = "/s:Panel_1",
    --点击区域问题按钮事件
    leftBtn      = "/s:Panel_1/s:Button_left",
    rightBtn      = "/s:Panel_1/s:Button_right",
    leftBtnP      = "/s:Panel_1/s:Panel_left",
    rightBtnP      = "/s:Panel_1/s:Panel_right",
    --解锁spin播放父节点
    panel_spin   = "/s:Panel_1/s:Panel_spin",
    --缩略图移动点的背景
    movePointBg  = "/s:Panel_1/s:Image_ban",
   
    --星盘
    panelAsb1     = "/s:Panel_1/s:Panel_astrobe1",
    panelAsb2     = "/s:Panel_1/s:Panel_astrobe2",
    panelAsb3     = "/s:Panel_1/s:Panel_astrobe3",
    imageUp      = "/s:Panel_1/s:Image_up_bg",
    -- 显示当前等级
    textLevel    = "/s:Panel_1/s:Image_up_bg/s:Text_level",
    --等级上限
    textLimit    = "/s:Panel_1/s:Image_up_bg/s:Text_limit",
    --当前经验和最大经验
    textExp      = "/s:Panel_1/s:Image_up_bg/s:Text_2",
    -- 距离下一等级的经验条
    nextBarBg    = "/s:Panel_1/s:Image_up_bg/s:Image_bar_bg",
    nextBar      = "/s:Panel_1/s:Image_up_bg/s:Image_bar_bg/s:LoadingBar_1",
    --觉醒阶段
    Text_a       = "/s:Panel_1/s:Image_up_bg/s:Text_a",
    --显示突破次数
    textAwake    = "/s:Panel_1/s:Image_up_bg/s:Text_a_l",
    --------------------down
    imageDown    = "/s:Panel_1/s:Image_down",
    -- 基础攻击力
    akBar1       = "/s:Panel_1/s:Image_down/s:LoadingBar_ak_1",
    akText1      = "/s:Panel_1/s:Image_down/s:Text_jc_ak",
    -- 百分比攻击力
    akBar2       = "/s:Panel_1/s:Image_down/s:LoadingBar_ak_2",
    akText2      = "/s:Panel_1/s:Image_down/s:Text_bf_ak",
    -- 基础生命
    hpBar1       = "/s:Panel_1/s:Image_down/s:LoadingBar_hp_1",
    hpText1      = "/s:Panel_1/s:Image_down/s:Text_jc_hp",
    --百分比生命
    hpBar2       = "/s:Panel_1/s:Image_down/s:LoadingBar_hp_2",
    hpText2      = "/s:Panel_1/s:Image_down/s:Text_bf_hp",
    --基础防御力
    deBar1       = "/s:Panel_1/s:Image_down/s:LoadingBar_de_1",
    deText1      = "/s:Panel_1/s:Image_down/s:Text_jc_de",
    --百分比防御力
    deBar2       = "/s:Panel_1/s:Image_down/s:LoadingBar_de_2",
    deText2      = "/s:Panel_1/s:Image_down/s:Text_bf_de",
    --属性panel
    panelPro     = "/s:Panel_1/s:Image_down/s:Panel_property",
    --暴击
    bjText       = "/s:Panel_1/s:Image_down/s:Panel_property/s:Text_bj_1",
    --暴击伤害
    bjText1      = "/s:Panel_1/s:Image_down/s:Panel_property/s:Text_bj_a_1",
    --技能伤害
    jnText       = "/s:Panel_1/s:Image_down/s:Panel_property/s:Text_jn_a_1",
    --普工伤害
    pgText       = "/s:Panel_1/s:Image_down/s:Panel_property/s:Text_pt_1",
    --攻击间隔
    jgText       = "/s:Panel_1/s:Image_down/s:Panel_property/s:Text_jg_1",
    --恢复力
    hfText       = "/s:Panel_1/s:Image_down/s:Panel_property/s:Text_hf_1",
}
function NewRoleStarView:init(ReLoadCallFunc,sDelegate)
    NewRoleStarView.super.init(self)
    self.Text_a:setString(UITool.ToLocalization("星盘解锁"))
    self.exist = true;
    
    -- --五星潜能是否解锁
    -- self.awake_lock = awakeLock
    ----------

    self.ReLoadCallFunc = ReLoadCallFunc
    self.sDelegate = sDelegate
    -- 当前最大的解锁区域
    self.lockMaxArea = 0
    -- 当前选择的区域
    self.curAreaIndex = 1
    -- 一共有几去
    self.maxArea      = 0
--    self.addAsp     = 0
    self.severData   = {}
    self.roleData = {}
    self.skeletonNode = nil
    return self
end
--传入数据
function NewRoleStarView:FillHeroData(rcvData,hero_id)
    if rcvData then
        --讲与的条件整理成一个表
        local roleData = {}

        roleData["hero_lv"]      = rcvData["Lv"] --角色等级

        roleData["hero_add"]     = rcvData["hero_add"] --角色额外提升

      --  if rcvData["like_feeling_data"]["state"] == 0 then
            roleData["feeling_lv"]   = 0
        -- else
        --     roleData["feeling_lv"]   = rcvData["like_feeling_data"]["lv"] --好感度等级
        -- end
        if rcvData["soul"]["state"] == 0 then
            roleData["soul_lv"]      = 0 --魂灵装等级
        else
            roleData["soul_lv"]      = rcvData["soul"]["Lv"] --魂灵装等级
        end
        

       -- roleData["astro_lv"]     = rcvData["astrolabe"]["lv"]  --星盘等级

        roleData["hero_sk_add"]  = rcvData["tp"]["from_other"] --角色技能点数额外提升

        --roleData["astro_sk_add"] = rcvData["astrolabe"]["used_items"] --星盘点数额外提升

    
        --几次突破
        roleData["awakeNum"]    = rcvData["break_count"] 
        self.hero_id     = hero_id --getNumID(hero_id)
        self.hero_sub_id = getNumID(hero_id)
        self.severData   = rcvData
        self.roleData    = roleData
        self.maxArea     = table_leng(rcvData["astrolabe"]["astr_area"])--#rcvData["astrolabe"]["astr_area"]
        print("self.maxArea ======== "..self.maxArea)
        print("hero id == "..self.hero_id)
        self:AddAreaAsp(rcvData)
        self:setUiData(rcvData)
        self:touchClick()
        self:lrBtnCallBack(0)

    end
end
function NewRoleStarView:refreshData( ... )
    -- body

    if self and self.ReLoadCallFunc then
        print("非空函数")
        self.ReLoadCallFunc(self.sDelegate)
    else
        print("这是一个nil")
    end

end
--当前一共解锁几区
function NewRoleStarView:AddAreaAsp( _table )
    self.lockMaxArea = 0
    --self.addAsp     = 0
    self.curAreaIndex = 1
    local asTable = _table["astrolabe"]
    local area    = asTable["astr_area"]
    for i = 1 , self.maxArea do
        if asTable["astr_area"][tostring(i)]["state"] == 1 then
           self.lockMaxArea = self.lockMaxArea + 1
          -- self.addAsp     = self.addAsp + area[tostring(self.lockMaxArea)]["asp_cost"]
        end  
        print("astr_area == iiii == "..i)
        print("astr_area == iiii == state == "..asTable["astr_area"][tostring(i)]["state"])      
    end
    self.curAreaIndex = self.lockMaxArea
    if self.lockMaxArea == 0 then
        self.curAreaIndex = 1
    end
end
function NewRoleStarView:returnBack()
    self:clearFullEffec()
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
    end 
    self.exist = false
    if self._navigationView then
        self._navigationView:popView()
    end
end


--点击左右键 的回调
function NewRoleStarView:lrBtnCallBack(offect )
    --左右切换的判断
 
    self.curAreaIndex = self.curAreaIndex + offect
    local ll = false
    local lr = false
   print("ying gai  == 1  "..self.curAreaIndex)
   print("self.lockMaxArea  == "..self.lockMaxArea)
    if self.curAreaIndex <= 1 then
        self.curAreaIndex = 1
        ll = true
    end

    if self.curAreaIndex  >= self.maxArea then
        self.curAreaIndex = self.maxArea
        lr = true
    end
    --另一种 是当星盘一区未解锁是不能左右切换的
    if self.lockMaxArea == 0 then
        ll = true
        lr = true
    end

    self.leftBtnP:setTouchEnabled(not ll)
    self.leftBtnP:setBright(not ll)
    self.leftBtn:setBright(not ll)

    self.rightBtnP:setTouchEnabled(not lr)
    self.rightBtnP:setBright(not lr)
    self.rightBtn:setBright(not lr)
    self:showCurArea(self.curAreaIndex)
    self:setMovePoin(self.curAreaIndex)
end
--播放星盘背景特效
function NewRoleStarView:playBgEffc(spinNode)
    local spineRoot = spinNode
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
    end 
    local id_str = "res/uifile/n_UIShare/astrolabe/xing_pan_bei_jing/xing_pan_bei_jing.atlas"--title_conf[tonumber(item_id)].res_spine
    if cc.FileUtils:getInstance():isFileExist(id_str) then 
        self.skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(id_str))
        local size = spineRoot:getBoundingBox()--spineRoot:getSize()
        self.skeletonNode:setPosition(640,360)--size.width/2+2,size.height/2
        -- self.skeletonNode:registerSpineEventHandler(
        --     function (event) 
        --         self.baseSelf.refreshCallFunc(self.baseSelf.newRoleStarSelf)
        -- end, sp.EventType.ANIMATION_END)
        
        spineRoot:addChild(self.skeletonNode,123)
        self.skeletonNode:addAnimation(1,"effect",true)
        
    else 
          print("文件不存在 error file not exist:"..id_str)
    end
    
end
function NewRoleStarView:clearFullEffec( ... )
    for i = 1 ,self.maxArea  do
                --本地表数据
        local testTable  = hero_astrolabe[self.hero_sub_id]["areas"][i]
         --星盘属性长度
        local testLen     = #testTable["stars"]
        local node = self.rootPanel:getChildByName("Panel_astrobe"..i)
        for y = 1 , testLen do
            print("yyyyy == "..y)
            print("testLen == "..testLen)
            local imageChild = node:getChildByName("Image_"..y)
            if imageChild:getChildByTag(123) then
                print("打印的次数 === "..y)
                imageChild:getChildByTag(123):stopAllActions()
                imageChild:getChildByTag(123):removeFromParent()
            end
        end
    

    end
end
--设置缩略图上根据选择变化的豆
function NewRoleStarView:setMovePoin( _index )
    local _indicatorImgStr = {
        "n_UIShare/actBase/ldhd_ui_003.png",
        "n_UIShare/actBase/ldhd_ui_004.png",
    }
    for i = 1 ,3 do
        local mvPn = self.movePointBg:getChildByName("Image_"..i)
        if i == _index then
            mvPn:loadTexture(_indicatorImgStr[2])
        else
            mvPn:loadTexture(_indicatorImgStr[1])
        end
    end
    
    local mvPn2 = self.movePointBg:getChildByName("Image_2")
    local mvPn2 = self.movePointBg:getChildByName("Image_3")
end
-- 点击事件的回调
function NewRoleStarView:touchClick()
    -- body
    print("调用了按钮事件监听")
    self.leftBtnP:addClickEventListener(function()
        self:leftBtnCallBack()
    end)
    self.rightBtnP:addClickEventListener(function()
        self:rightBtnCallBack()
    end)
end
-- 显示当前的区域
function NewRoleStarView:showCurArea(_index)
    local node = nil
    for i = 1,self.maxArea do
        if i == _index then
            node = self.rootPanel:getChildByName("Panel_astrobe"..i)
            node:setVisible(true)
            local spinNode = node:getChildByName("Sprite_bg_1")
            self:clearFullEffec()
            self:playBgEffc(spinNode)
        else
             self.rootPanel:getChildByName("Panel_astrobe"..i):setVisible(false)
            
        end
    end
     self:toAstrobeAreaBase(node)
end
function NewRoleStarView:leftBtnCallBack( ... )

     self:lrBtnCallBack(-1)
end
function NewRoleStarView:rightBtnCallBack( ... )

    self:lrBtnCallBack(1)
end

function NewRoleStarView:toAstrobeAreaBase(node)
    print("yinggai == "..self.curAreaIndex)
    local sData = {}
    sData["curAreaIndex"]    = self.curAreaIndex
    sData["severData"]       = self.severData
    sData["roleData"]        = self.roleData
    sData["_type"]           = 0
    sData["hero_id"]         = self.hero_id
    sData["rootNode"]        = node
    sData["refreshCallFunc"] = self.refreshData
    sData["newRoleStarSelf"]      = self
    AstrolabeAreaBase:init(sData)
end

--星盘基础属性
function NewRoleStarView:porpertyBase( _table )
    -- 基础
    local baseTable = _table["base"]
    --攻击
    self.akText1:setString(baseTable["atk"]) 
    --self:setProColor(self.akText1,baseTable["atk"])
    --生命
    self.hpText1:setString(baseTable["hp"])
    --self:setProColor(self.hpText1,baseTable["hp"])
    --防御
    self.deText1:setString(baseTable["def"])
    --self:setProColor(self.deText1,baseTable["def"])
    --暴击
    --self.bjText:setString(baseTable["crit"])
    self:setProColor(self.bjText,baseTable["crit"],1,1)
    --暴击伤害
    --self.bjText1:setString(baseTable["crit_dmg"])
    self:setProColor(self.bjText1,baseTable["crit_dmg"],1,1)
    --技能
    --self.jnText:setString(baseTable["skill_dmg"])
    self:setProColor(self.jnText,baseTable["skill_dmg"],1,1)
    --普攻
    --self.pgText:setString(baseTable["atk_dmg"])
    self:setProColor(self.pgText,baseTable["atk_dmg"],1,1)
    --攻击间隔
    --self.jgText:setString(baseTable["atk_rate"])
    self:setProColor(self.jgText,baseTable["atk_rate"],1,2)
    --恢复
    --self.hfText:setString(baseTable["hel"])
    self:setProColor(self.hfText,baseTable["hel"],2,1)
end
--星盘百分比
function NewRoleStarView:porpertyPercent( _table )
    -- 额外
    local percent = _table["persent_value"]
    --攻击 
    --self.akText2:setString("+"..percent["atk"])
    self:hidePorPrt(self.akText2,percent["atk"])
    --生命值
    --self.hpText2:setString("+"..percent["hp"])
    self:hidePorPrt(self.hpText2,percent["hp"])
    --防御
    --self.deText2:setString("+"..percent["def"])
    self:hidePorPrt(self.deText2,percent["def"])
end
--百分比属性如果加零 隐藏
function NewRoleStarView:hidePorPrt(sender,value)
    if value > 0 then
        sender:setVisible(true)
        sender:setString("+"..value)
    else
        sender:setVisible(false)
    end
end
--设置基础属性为零白色字体 大于零绿色
--控制加减号 addType
function NewRoleStarView:setProColor( sender,value ,type_,addType)
    local srValue = ""
    if type_ == 1 then
        srValue = value.."%"
    elseif type_ == 2 then
        srValue = value
    end 
    if addType then
        if addType == 1 then
            srValue = "+"..srValue
        elseif addType == 2 then
            srValue = "-"..srValue
        end
    end
    if value > 0 then
        sender:setColor(cc.c3b(25, 214, 25)) 
        sender:setString(srValue)    
    else
        sender:setColor(cc.c3b(255, 255, 255))
        sender:setString(srValue)
    end
end
--设置基础百分比进度
function NewRoleStarView:setAddBar( _table )
    -- body
    local baseTable = _table["base"]
    local percent = _table["persent_value"]
    local atkAll  = hero_astrolabe[self.hero_sub_id]["atk_limit"]
    local hpAll  = hero_astrolabe[self.hero_sub_id]["hp_limit"]
    local defAll  = hero_astrolabe[self.hero_sub_id]["def_limit"]
    print("atkAll == "..atkAll)
     print("hpAll == "..hpAll)
      print("defAll == "..defAll)
    self:toolAddBar(self.akBar1,self.akBar2,baseTable["atk"],percent["atk"],atkAll)
    self:toolAddBar(self.hpBar1,self.hpBar2,baseTable["hp"],percent["hp"],hpAll)
    self:toolAddBar(self.deBar1,self.deBar2,baseTable["def"],percent["def"],defAll)
end

--星盘界面属性
function NewRoleStarView:porpertyUI( _table )
    -- body
    -- body
    -- 一共五个豆 是表示解锁区域
    -- 根据当前几个区域来解锁豆，现在版本是三个以后可能会加
    local asTable = _table["astrolabe"]
    local area    = asTable["astr_area"]
    for i = 1 , 5 do
        if i > self.maxArea then
            self.imageUp:getChildByName("Image_awake_"..i):setVisible(false)
        else
            if asTable["astr_area"][tostring(i)]["state"] == 1 then
                 self.imageUp:getChildByName("Image_awake_"..i):getChildByName("Image_3"):setVisible(true)
            else
                self.imageUp:getChildByName("Image_awake_"..i):getChildByName("Image_3"):setVisible(false)
            end
        end    
    end
    --当前等级
    self.textLevel:setString(UITool.ToLocalization("等级:")..asTable["lv"])--self:strCat(self.textLevel,asTable["lv"])
    --等级上限 就是upgrade的长度
    print("self.hero_sub_id self.hero_sub_id self.hero_sub_id == "..self.hero_sub_id)
    local lvLimit = #hero_astrolabe[self.hero_sub_id]["upgrade"]
    self.textLimit:setString(UITool.ToLocalization("等级上限:")..lvLimit)--self:strCat(self.textLimit,lvLimit)
    --等级经验条
    local exp    = asTable["exp"]
    local maxexp = hero_astrolabe[self.hero_sub_id]["upgrade"][asTable["lv"]][2]
    --local MaxLv  = hero_astrolabe[self.hero_sub_id]["areas"][self.maxArea]["level_max"]
    if asTable["lv"] >= lvLimit then
        self:toolBar(self.nextBar,100,100)
        self.textExp:setVisible(false)
    else
        self.textExp:setVisible(true)
        self:toolBar(self.nextBar,exp,maxexp)
        self.textExp:setString(tostring(exp).."/"..tostring(maxexp))
    end


    --潜能当前解放次数和最大次数
    self.textAwake:setString(self.lockMaxArea.."/"..self.maxArea)--(self.roleData["awakeNum"].."/"..5)
    if g_channel_control.transform_AstrolabeMainLayer_textAwake_fontSize == true then 
        print("transform_AstrolabeMainLayer_textAwake_fontSize============true")
        self.textAwake:setPosition(200,26)
    end 
end
function NewRoleStarView:setUiData( _table )
    local porp = _table["astrolabe"]["property"]
    self:porpertyBase(porp)
    self:porpertyPercent(porp)
    self:porpertyUI(_table)
    self:setAddBar(porp)

end

--进度条的封装
function NewRoleStarView:toolBar( selfNode,nowNum,totalNum )
    -- body
    local prent = nowNum*100/totalNum
    selfNode:setPercent(prent)
end
--带峰值的进度条 策划需求不需要阶梯进度
--[[
    基础属性
        selfNode  self
        nowNum    值
    百分比
        selfNode2 self  
        nowNum2   值
    峰值
        allNum
]]
function NewRoleStarView:toolAddBar(selfNode,selfNode2, nowNum,nowNum2,allNum)
    print("nowNum == "..nowNum)
    print("nowNum2 == "..nowNum2)
    -- body
    local perce1  = nowNum * 100 / allNum
    local perce2  = nowNum2 * 100 / allNum
    selfNode:setPercent(perce1)
    local allPer = perce1 + perce2
    selfNode2:setPercent(allPer)
end



