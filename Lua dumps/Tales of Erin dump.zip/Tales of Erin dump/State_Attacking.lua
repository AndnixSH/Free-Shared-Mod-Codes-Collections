--攻击状态。
--created by kobejaw.2018.4.12.
State_Attacking = class("State_Attacking",StateBase)

function State_Attacking:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.Attacking
	self.needUpdate = true;
	self.intervalTime =  self.entity.attributeManager:getAtkInterval()--攻击间隔
	self.cdTime = 0 --首次攻击没有cd
	self.isFirstAttack = true --是否是首次攻击
	self.isCDStart = false
	self.hitSound = self.entity.data.hitSound --远程和爆炸类的击中音效
	self.attackSound = self.entity.sound_normalAtk --出手音效
end

function State_Attacking:Enter(enemy)
	if self.entity.isDead then
		return
	end

	if G_GameState == 5 then
		self.entity.fsm:changeState(StateEnum.Idling)
		return
	end

	self.entity:playIdleAnimation()
	self.enemyEntity = enemy

	self:checkBeforeAttack()
end

function State_Attacking:Exit()
	self.super.Exit(self)
end

function State_Attacking:update(dt)
	if self.isCDStart then
		self.cdTime = self.cdTime - dt
		if self.cdTime <= 0 then
			self.isCDStart = false;

			--检测被攻击对象是否死亡
			if self.enemyEntity.isDead then
				local data = {}
				data.type = 1;
				self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
				return
			end

			--检测被攻击者是否超出射程。
			if not self:checkIsEnemyInRange(self.enemyEntity) then
				local data = {}
				data.type = 1;				
				self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
				return
			end

			--检测自动释放技能
			if self.entity.entityType == 1 and self:checkAutoplaySkill() then
				return
			end

			self.entity:setOrientation(self.enemyEntity)
			self:attack();
		else
			return
		end
	end	
end

--攻击前再检查一下是否在射程范围。如果被攻击者不在射程范围内或者已经死亡，切换到寻敌状态。
function State_Attacking:checkBeforeAttack()
	if self.enemyEntity.isDead then
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
		return
	end

	if not self:checkIsEnemyInRange(self.enemyEntity) then
		local data = {}
		data.type = 1;		
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
		return
	end
	self.isCDStart = true;
	if self.isFirstAttack then
		self.isFirstAttack = false
	else
		self.cdTime = self.entity.attributeManager:getAtkInterval()
	end

	--修正一下跑动造成的位置误差
	local currIdx = self.entity:getBoxIdx()
	self.entity:setPosition(GetPointByBoxIdx(currIdx))

	--修正一下位置。保证攻击者和被攻击者不再同一条竖线上,只修正玩家角色。
	if self.entity.entityType == 1 then
		local w_self,h_self = self.entity:getBoxWH()
		if w == w_self then
			local newW1 = w_self-1
			local newW2 = w_self+1

			if self.entity:checkBoxAvailableByWH(newW1,h_self) then
				self.entity:setBoxDataByWH(newW1,h_self)
				local newpoint = GetPointByBoxWH(newW1,h_self)
				self.entity:setPosition(newpoint)
			elseif self.entity:checkBoxAvailableByWH(newW2,h_self) then
				self.entity:setBoxDataByWH(newW2,h_self)
				local newpoint = GetPointByBoxWH(newW2,h_self)
				self.entity:setPosition(newpoint)			
			end
		end
	end

	--修正一下朝向
	self.entity:setOrientation(self.enemyEntity)
end

function State_Attacking:onSpineEventCallback(event)
	--震屏等
	self:dealWithCommonEvents(event)

	--注：比较特殊的是attackType为2的情况，可能触发击中，也可能触发攻击特效。
	if self:checkIsAutoplayEvent(event) then
		--显示远程攻击子弹。
		if self.entity.data.attackType == 3 then
			self:createBullet() 
		--远程爆炸效果。播放攻击特效。攻击特效中的attack事件触发击中
		elseif self.entity.data.attackType == 2 then
			self:playType2Effect()
		elseif self.entity.data.attackType == 1 then
			print("近战没有额外特效，不可能执行到这里！")
		end
	end

	local result1,result2 = self:checkIsAttackEvent(event)
	if result1 then
		if self.entity.data.attackType == 3 then
			print("远程的触发伤害事件不在这里，不可能执行到这里！")
		else
			--近战和远程爆炸都可能执行到这里。
			self:onCauseDamage(3,self.entity,self.enemyEntity,event,self.entity.attackData,result2)
		end
	end
end

--爆炸类的爆炸特效，在目标身上播放（有些没有爆炸特效）
function State_Attacking:playType2Effect()
	if self.enemyEntity.isDead then
		return
	end

	if self.entity.data.bulletRes == nil or self.entity.data.bulletRes == "" then
		return
	end

	local effectSpineNode = CreateEffectSpineNode(self.entity.data.bulletRes)
	table.insert(G_NodesWithSpine,effectSpineNode)

	self.enemyEntity:addChild(effectSpineNode)
	effectSpineNode:setPosition(self.enemyEntity.data.hitPosX,self.enemyEntity.data.hitPosY)

	if self.entity.faceTo == BattleGlobals.FaceLeft and self.entity.entityType == 1 then
		effectSpineNode:setRotationSkewY(180)
	end

	local this = self;
	local function eventCallback(event)
		local result1,result2 = this:checkIsAttackEvent(event)
		if result1 then
			this:onCauseDamage(3,this.entity,this.enemyEntity,event,this.entity.attackData,result2)
		end
	end

	RemoveEffectOnComplete(effectSpineNode)
	effectSpineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
end

--显示击中特效
function State_Attacking:playHitEffect()
	if self.entity.data.hitRes == nil or self.entity.data.hitRes == "" then
		return
	end

	local hitEffectSpineNode = CreateEffectSpineNode(self.entity.data.hitRes)
	table.insert(G_NodesWithSpine,hitEffectSpineNode)
	
	self.enemyEntity:addChild(hitEffectSpineNode)
	hitEffectSpineNode:setPosition(self.enemyEntity.data.hitPosX,self.enemyEntity.data.hitPosY)

	--设置朝向
	if self.entity.faceTo == BattleGlobals.FaceLeft and self.entity.entityType == 1 then
		hitEffectSpineNode:setRotationSkewY(180)
	end

	--远程和爆炸类的击中音效
	if self.entity.data.attackType ~= 1 then
		BattlePlaySound(self.hitSound,false,2)
	end

	RemoveEffectOnComplete(hitEffectSpineNode)
end

--生成普通攻击远程攻击的子弹，击中目标后删除自己（AttackType3）
function State_Attacking:createBullet()
	if self.entity.data.bulletRes == nil or self.entity.data.bulletRes == "" then
		return
	end

	--离的太近就不生成子弹了，直接计算伤害
	local self_x,self_y = self.entity:getPosition()
	local enemy_x,enemy_y = self.enemyEntity:getPosition()
	local deltaX = enemy_x - self_x
	local deltaY = enemy_y - self_y
	local dis = math.sqrt(deltaX*deltaX + deltaY*deltaY)
	if dis <= 250 then
		--计算伤害
		self:onCauseDamage(3,self.entity,self.enemyEntity,nil,self.entity.attackData,1)
		return;
	end

	local spineData = BattleCacheManager:getData(self.entity.data.bulletRes)
	local bulletSpineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
	bulletSpineNode:setAnimation(0,"effect",false)
	G_EffectLayer:addChild(bulletSpineNode)

	--计算初始位置
	if self.entity.faceTo == BattleGlobals.FaceRight then
		bulletSpineNode:setPosition(self_x + self.entity.data.bulletPos.x, self_y + self.entity.data.bulletPos.y)
	else
		bulletSpineNode:setPosition(self_x - self.entity.data.bulletPos.x, self_y + self.entity.data.bulletPos.y)
		if self.entity.entityType == 1 then
			bulletSpineNode:setRotationSkewY(180)
		end
	end
	
	--计算击中位置
	local posX
	if deltaX > 0 then
		posX = enemy_x + self.enemyEntity.data.hitLeftX
	else
		posX = enemy_x + self.enemyEntity.data.hitRightX
	end

	--计算时间
	local frames = dis/self.entity.data.bulletSpeed
	local time = frames/60

	local move = cc.MoveTo:create(time,cc.p(posX,bulletSpineNode:getPositionY()))
	bulletSpineNode:runAction(move)
	table.insert(G_NodesWithAction,bulletSpineNode)

	local this = self
	local function OnHit()
		RemoveFromNodesWithAction(bulletSpineNode)
		bulletSpineNode:removeFromParent();

		--计算伤害
		this:onCauseDamage(3,this.entity,this.enemyEntity,event,this.entity.attackData,1)
	end

	local seq = cc.Sequence:create(move, cc.CallFunc:create(OnHit))
	bulletSpineNode:runAction(seq)
end

function State_Attacking:onSpineCompleteCallback(event)
	--检测被攻击对象是否死亡
	if self.enemyEntity.isDead then
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
		return
	end

	--检测被攻击者是否超出射程,攻击状态下有任何动作结束就检测一次。
	if not self:checkIsEnemyInRange(self.enemyEntity) then
		local data = {}
		data.type = 1;				
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
		return
	end

	if event.animation == "singleattack" or event.animation == "singleattack2" then
		self.cdTime = self.entity.attributeManager:getAtkInterval()
		self.isCDStart = true;
		self.entity:playIdleAnimation();
	end
end

--自动释放技能的检测。播放动作之前和播完之后检测一下。
function State_Attacking:checkAutoplaySkill()
	if ActiveSkillManager.isAuto then
		for k,v in pairs(ActiveSkillManager.autoPlayList) do
			if v.role == self.entity and v:checkCanPlaySkill() then
				v:playSkill() --切换到使用技能的状态
				return true
			end
		end
	end
	return false
end

function State_Attacking:attack()

	--如果一个攻击有多段，则每段算一次攻击，所以攻击次数的统计放到onCauseDamage里。2019.1.28
	--self.entity.attr[AE.totalnum_atk] = self.entity.attr[AE.totalnum_atk] + 1

	--魅惑的特殊情况处理
	--TODO,做PVP的时候记得再技能里添加。
	if self.entity:checkMeiHuo() then
		self.cdTime = self.entity.attributeManager:getAtkInterval()
		self.isCDStart = true;
		return
	end

	--提线傀儡的特殊情况处理
	if self.entity.componentManager.TiXianKuiLei then
		--触发时机101。全队普通时(伤害计算前)。目前只有提线傀儡的情况用到。
		self.entity.teamManager:checkTeamTrigger(101,self.entity)
	end

	if self.entity.entityType == 1 then          --玩家角色
		self.entity:playAttackAnimation()
	else 
		if self.entity.monsterType == 1 then     --只会普通攻击的小怪
			self.entity:playAttackAnimation()
		elseif self.entity.monsterType == 2 then  --既能普攻又能技能攻击的小怪
			local skillInfo = self.entity.skillManager:getNextSkillInfo()
			if skillInfo then
				self.entity:attackWithSkill(skillInfo)
			else
				self.entity:playAttackAnimation()
			end
		elseif self.entity.monsterType == 3 then  --只会技能攻击的小怪
			local skillInfo = self.entity.skillManager:getNextSkillInfo()
			if skillInfo then
				self.entity:attackWithSkill(skillInfo)
			else
				self.isCDStart = true
				self.cdTime = 0.5
			end
		end
	end
end
