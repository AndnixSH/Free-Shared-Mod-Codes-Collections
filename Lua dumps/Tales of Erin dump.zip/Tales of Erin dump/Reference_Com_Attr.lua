--组件和属性的对照表
--created by kobejaw.2018.6.6.
AE = {} --AttributeEnum
Com_BuffEnum = {}  --buff类型
Com_DebuffEnum = {}  --debuff类型
NewRuleAttr = {}
AE_GreaterThan0 = {} --不能小于0的属性 

--新增记录
--20181008新增：204普攻攻击力加成，406暴抗，114格挡率，115破格率，116格挡值，117破格值。

--基础属性
AE.hp = 101                             --当前hp
AE.hp_max = 102                         --hp上限
AE.atk_interval = 103                   --攻击间隔（秒）
AE.reduce_interval = 104                --降低的攻击间隔百分比加成。
AE.level = 105                          --等级
AE.recover = 106                        --恢复力
AE.add_recover = 107                    --恢复力加成
AE.hit_rate = 108                       --命中率。默认是100。加成直接修改这个值。黑暗debuff修改这个值。
AE.dodge = 109                          --闪避率。默认是0。加成直接修改这个值。
AE.element = 110                        --元素值。1水2火3风4光5暗
AE.state = 111                          --od和bk状态。OD为0，BK为1.
AE.add_debuff_rate = 112                --释放debuff的命中率加成（异常命中率）
AE.add_debuff_dodge_rate = 113          --闪避debuff的加成(异常抗性)
AE.block_rate = 114                  --新增。格挡率
AE.reduce_block_rate = 115           --新增。破格率。格挡率为 114 - 115
AE.block_value = 116                 --新增。格挡值
AE.reduce_block_value = 117          --新增。破格值。格挡值为  116 - 117
--注：命中率和闪避相关的计算只有加法没有乘法。

--攻击力相关
AE.attack = 201                        --攻击力
AE.add_atk = 202                       --攻击力加成
AE.add_atk_winordie = 203              --背水攻击力加成。库拉夏的被动技能。
AE.add_atk_normal = 204                --新增。普通攻击攻击力加成。对应api中的pattack

--伤害加成相关
AE.add_dmg = 301                       --伤害加成
AE.add_dmg_skill = 302                 --技能伤害加成。注：是增伤，不是增加技能倍率。
AE.add_dmg_chimera = 303               --奇美拉诅咒伤害加成。黑鸦的被动技能。
AE.add_dmg_od = 304                    --对狂暴状态的敌人伤害加成
AE.add_dmg_bk = 305                    --对虚弱状态的敌人伤害加成
AE.add_dmg_normal = 306                --普攻固定伤害增加的数值。（灵剑乱舞这个buff）。注意：这个是数值，其他的是百分比。暂时没用到这个属性。目前使用81050的lv4做特殊处理。
AE.add_dmg_skill_1 = 307               --2019.2.22新增。小技能增伤
AE.add_dmg_skill_2 = 308               --2019.2.22新增。大技能增伤


--暴击相关
AE.crit_rate = 401                     --暴击率
AE.add_crit_rate = 402                 --暴击率的加成
AE.add_crit_rate_skill = 403           --技能暴击率的加成
AE.crit_multiplying = 404              --暴击倍率（初始值为面板暴击倍率）
AE.add_dmg_crit = 405                  --暴击倍率加成(与crit_multiplying相加)
AE.crit_resistance = 406               --新增。暴抗。暴击率为401+402-406
AE.add_dmg_skill_crit = 407            --技能暴击倍率加成（与crit_multiplying相加)

--防御力相关
AE.defence = 501                       --防御力
AE.add_defence = 502                   --防御力加成
AE.reduce_dmg = 503                    --减伤
AE.add_def_water = 504                 --水属性防御力加成
AE.add_def_fire  = 505                 --火属性防御力加成
AE.add_def_wind  = 506                 --风属性防御力加成
AE.add_def_light = 507                 --光属性防御力加成
AE.add_def_dark  = 508                 --暗属性防御力加成

--boss相关
AE.energy_max = 601                    --能量豆上限
AE.energy = 602                        --能量豆
AE.od_hp = 603                         --od值
AE.od_n_hp = 604                       --od状态下当前od值
AE.bk_hp = 605                         --bk值
AE.bk_t = 606                          --bk时间

--其他属性
AE.total_dmg = 701                     --累计收到伤害。会引发触发器
AE.totalnum_atked = 702                --累计受攻击次数。会引发触发器
AE.totalnum_atk = 703                  --累计攻击次数。会引发触发器
AE.total_dmg_2 = 704                   --每受到xx伤害值。2019.1.24新增

--以下属性不能小于0
AE_GreaterThan0[AE.hp] = true
AE_GreaterThan0[AE.hp_max] = true
AE_GreaterThan0[AE.atk_interval] = true
AE_GreaterThan0[AE.level] = true
AE_GreaterThan0[AE.recover] = true
AE_GreaterThan0[AE.element] = true
AE_GreaterThan0[AE.state] = true
AE_GreaterThan0[AE.attack] = true
AE_GreaterThan0[AE.crit_multiplying] = true
AE_GreaterThan0[AE.crit_rate] = true
AE_GreaterThan0[AE.defence] = true
AE_GreaterThan0[AE.energy_max] = true
AE_GreaterThan0[AE.energy] = true
AE_GreaterThan0[AE.od_hp] = true
AE_GreaterThan0[AE.bk_hp] = true
AE_GreaterThan0[AE.bk_t] = true

--buff类型
Com_BuffEnum.AttributeUp = 1; --属性上升类
Com_BuffEnum.SpecialState = 2;--无敌，变身，嘲讽，锁血，提线傀儡，boss下次必使用特殊技（81050）。
Com_BuffEnum.HPRecover = 3;   --每X秒回血
Com_BuffEnum.LifeShield = 4;  --生命护盾
Com_BuffEnum.NumShield = 5;   --次数护盾
Com_BuffEnum.AbnormalShield = 6; --异常护盾
Com_BuffEnum.ReduceDmg = 7;  --减免固定值的伤害
Com_BuffEnum.BaTiNumShield = 8;  --霸体次数护盾

--debuff类型
Com_DebuffEnum.AttributeDown = 1; --属性下降类
Com_DebuffEnum.SpecialState = 2;  --特殊标识。黑胶。
Com_DebuffEnum.Poison = 3;   --每X秒减血
Com_DebuffEnum.RelatedToBoss = 4;  --boss相关。增加豆上限，不增豆，延长虚弱时间等。
Com_DebuffEnum.Temptation = 5;   --魅惑
Com_DebuffEnum.Vertigo = 6; --麻痹，眩晕


--新规则中的属性值与AE的对照表
NewRuleAttr[3071] = AE.dodge
NewRuleAttr[3001] = AE.add_atk
NewRuleAttr[3011] = AE.add_defence
NewRuleAttr[3006] = AE.add_crit_rate
NewRuleAttr[3003] = AE.reduce_interval
NewRuleAttr[3004] = AE.add_dmg_skill --技能伤害加成，注：不是倍率。
NewRuleAttr[3008] = AE.add_crit_rate_skill
NewRuleAttr[3002] = AE.add_dmg
NewRuleAttr[3028] = AE.reduce_dmg
NewRuleAttr[3012] = AE.add_recover
NewRuleAttr[3046] = AE.add_dmg_od
NewRuleAttr[3045] = AE.add_dmg_bk
NewRuleAttr[3019] = AE.add_debuff_dodge_rate
NewRuleAttr[3020] = AE.add_def_water
NewRuleAttr[3021] = AE.add_def_fire
NewRuleAttr[3022] = AE.add_def_wind
NewRuleAttr[3023] = AE.add_def_light
NewRuleAttr[3024] = AE.add_def_dark
NewRuleAttr[3018] = AE.add_debuff_rate
NewRuleAttr[3074] = AE.crit_resistance --暴抗率
NewRuleAttr[3075] = AE.block_rate   --格挡率
NewRuleAttr[3076] = AE.block_value  --格挡值
NewRuleAttr[3077] = AE.reduce_block_rate  --破格率
NewRuleAttr[3078] = AE.reduce_block_value --破格值
NewRuleAttr[3079] = AE.add_atk_normal        --普攻攻击力加成
NewRuleAttr[3007] = AE.add_dmg_crit   --暴击伤害提升
NewRuleAttr[3009] = AE.add_dmg_skill_crit  --技能暴击伤害提升
NewRuleAttr[3080] = AE.add_dmg_skill_1  --小技能伤害提升
NewRuleAttr[3081] = AE.add_dmg_skill_2  --大技能伤害提升

--获取buff，debuff或者永久生效效果对应的属性ID，旧规则
--@lv 目前只用来应对81050中的lv4
function GetAttrIdByComId(comId,lv)
	--攻击力增加百分比
	if comId == 81001 or comId == 81002 or comId == 81003 or comId == 81004 or comId == 82001 or comId == 83001 or comId == 81065 then
		return AE.add_atk
	--伤害增加百分比
	elseif comId == 83002 then
		return AE.add_dmg
	--技能伤害增加百分比
	elseif comId == 81019 or comId == 81020 or comId == 82008 then
		return AE.add_dmg_skill
	--攻击间隔降低百分比。TODO,暂时屏蔽掉神格技能中配的83003，莫名其妙的配表。
	elseif comId == 83003 or comId == 81035 or comId == 82997 then
		return AE.reduce_interval
	--暴击率增加百分比
	elseif comId == 81021 or comId == 81022 or comId == 82996 or comId == 83006 then
		return AE.add_crit_rate
	--暴击伤害增加百分比
	elseif comId == 81023 or (comId == 81024 and lv <=30) or comId == 83007 then
		return AE.add_dmg_crit
	--技能暴击率增加百分比
	elseif comId == 83008 then
		return AE.add_crit_rate_skill
	--防御上升百分比
	elseif comId == 81009 or comId == 81010 or comId == 81011 or comId == 82009 or comId ==82010 or comId == 83011 then
		return AE.add_defence
	--释放debuff的命中率加成
	elseif comId == 83018 then
		return AE.add_debuff_rate
	--闪避debuff的加成
	elseif comId == 83019 or comId == 82016 then
		return AE.add_debuff_dodge_rate
	--水属性防御力加成
	elseif comId == 81012 or comId == 82011 or comId == 83020 then
		return AE.add_def_water
	--火属性防御力加成
	elseif comId == 81013 or comId == 82012 or comId == 83021 then
		return AE.add_def_fire	
	--风属性防御力加成
	elseif comId == 81014 or comId == 82013 or comId == 83022 then
		return AE.add_def_wind
	--光属性防御力加成
	elseif comId == 81015 or comId == 82014 or comId == 83023 then
		return AE.add_def_light
	--暗属性防御力加成
	elseif comId == 81016 or comId == 82015 or comId == 83024 or comId == 82998 then
		return AE.add_def_dark		
	--减伤百分比
    --2016.11.27新增81100，用于大招cutEnd结束后
	elseif comId == 81100 or comId == 81017 or comId == 81018 or comId == 83028 then
		return AE.reduce_dmg
	--恢复力提升
	elseif comId == 81029 or comId == 81030 or comId == 82017 or comId == 82018 then
		return AE.add_recover
	--闪避
	elseif comId == 81058 then
		return AE.dodge
	--对虚弱状态的敌人伤害加成（只针对boss）
	elseif comId == 83045 then
		return AE.add_dmg_bk
	--对狂暴状态的敌人伤害加成（只针对boss）
	elseif comId == 83046 then
		return AE.add_dmg_od		
	--普通攻击增加的固定伤害（81050的lv4......）
    elseif comId == 81050 and lv == 4 then
        return AE.add_dmg_normal
    --降低命中。黑暗。82025的介绍是普通命中，实际上对普攻和技能都生效。
    elseif comId == 82025 then
        return AE.hit_rate
    --生命最大值加成
    elseif comId == 81066 then
        return AE.hp_max
    end
end

--新规则获取属性id和提升的百分比值
function GetAttr_NewRule(param)--30010003这种值
    local id = tonumber(string.sub(tostring(param),1,4))
    local value = tonumber(string.sub(tostring(param),5,8))

    if NewRuleAttr[id] then
        return NewRuleAttr[id],value
    end
    return nil
end
