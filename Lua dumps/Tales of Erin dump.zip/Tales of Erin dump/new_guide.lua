new_guide = {}
--抽卡引导
-----统一处理没有剧情的是没有按钮的，现在有点乱
new_guide[guide_id_config.ThatCard] = {
    {   --去抽卡页面
        dialog = {
            "Alven is in danger now.\nDon’t worry, reliable friends will soon be coming to his aid.",
            "Please follow the guide and click the Summon button on the bottom right."
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_040_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_040_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 1187,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
        isShowBtnEffect = 1,  --按钮出现特效
    },
    {--点击单抽
        dialog = "",
        clipping = "n_UIShare/gacha/ck_b_002_2.png",
        clippingImg = "n_UIShare/gacha/ck_b_002_2.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 670,
            pos_Y = 59,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    { --点击返回主界面1
        dialog =  "",
        clipping = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        clippingImg = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 1200,
            pos_Y = 38,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
} 
--编队引导
new_guide[guide_id_config.Team] = {
    --     --这个是选择引导，现在改为强制的了
    -- {   --选择对话
    --     dialog = {
    --         "새로운 동료를 만났습니다. 어서 파티에 편성하세요.",
    --     },
    --     clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
    --     clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
    --     arrow = {
    --         pos = 1, --  1 2 3 4 对应上 下 左 右  
    --         img = "n_UIShare/newGuide/xsyd_ui_004.png",
    --         scale = 1.0,
    --     },
    --     btn = {
    --         pos_X = 93,
    --         pos_Y = 66,
    --         scale_X = 1,
    --         scale_Y = 1,
    --         rotation = 0,
    --     },
    --     --改成强制引导
    --     isSelectGuide = 1,
    --     acceptBtnStr = "好的",
    --     refusedBtnStr = "暂时不",
    --     refusedType = 1,--拒绝类型（1为 强制引导，2为弱引导）
    --     refusedDialog = {
    --         "동료 편성시，点选主页的“队伍”按钮，就可以进入队伍编成页面。",
    --     },
    -- },
    -- {   --选择对话   1
    --     dialog = {
    --         "邂逅了新的同伴，现在让她进入队伍吧。",
    --     },
    --     isNoBtn = 2,
    -- },
    { --主界面 点击 队伍 弹出四个按钮  2
        dialog = {
            "You’ve met a new friend. Invite her to your party now. ",
            "Please tap on the Party button on the bottom left. "
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
        isShowBtnEffect = 1,  --按钮出现特效
    },

    { --队伍编成页面 + 队伍按钮  3
        dialog = "",
        clipping = "n_UIShare/newGuide/x_xsyd_zz_003.png",
        clippingImg = "n_UIShare/newGuide/xsyd_zz_003.png",
        arrow = {
            pos = 4, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 622,
            pos_Y = 319,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { --队伍列表界面 +  4
        dialog = "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 4, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 310,
            pos_Y = 537,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {   --点击返回主界面  5
        dialog =  "",
        clipping = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        clippingImg = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 1200,
            pos_Y = 38,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {  --对话 6
        dialog = {
            "Ero the healer will be helpful in your party. Please continue your adventure. ",
            "Tap on Battle to start your adventure. You can also choose to make some preparations before you enter the stage." 
        },
        isNoBtn = 2, -- 没有按钮 ，1是直接结束，不会走下一步，2是会走下一步
    },
}

--第一场战斗 5
new_guide[guide_id_config.FB] = {
    {---1主界面出征按钮
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_043_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_043_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
            pos_X = 0,  --用于修正坐标 因为有的遮罩图片不是规则的
            pos_Y = - 23,
        },
        btn = {
            pos_X = 1140, 
            pos_Y = 429,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {--、2区域地图 按钮
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_006.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_006.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 310, 
            pos_Y = 192,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    },
    {--3列表
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_004.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_004.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 794, 
            pos_Y = 519,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {--4开始战斗
        dialog = "",
        clipping="n_UIShare/Nready/zqzb_b_001_1.png",
        clippingImg="n_UIShare/Nready/zqzb_b_001_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 640, 
            pos_Y = 42,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    }
}

--第二场战斗 6
new_guide[guide_id_config.SB] = {
    {---1主界面出征按钮
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_043_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_043_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
            pos_X = 0,  --用于修正坐标 因为有的遮罩图片不是规则的
            pos_Y = - 23,
        },
        btn = {
            pos_X = 1140, 
            pos_Y = 429,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {--、2区域地图 按钮
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_006.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_006.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 310, 
            pos_Y = 192,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    },
    {--3列表
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_004.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_004.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 794, 
            pos_Y = 519,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {--4开始战斗
        dialog = "",
        clipping="n_UIShare/Nready/zqzb_b_001_1.png",
        clippingImg="n_UIShare/Nready/zqzb_b_001_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 640, 
            pos_Y = 42,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    }
}
---角色强化
new_guide[guide_id_config.StHero] = {
    {   --选择对话   1
        dialog = {
            "You have 4 people in your party now. Your Fortune Chart must be pretty full. But it’s not time to celebrate just yet. The enemies up ahead will be even tougher.",
            "You earned some Fruits of Trial from the battle. Use them to enhance your characters.",
            "Give it to Leefa and see what happens. "
        },
        isNoBtn = 2,
    },
    { --2、主界面 点击 队伍 
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {  -- 3、 点击角色强化按钮
        dialog =  "",
        clipping = "n_UIShare/role/main/jsjm_b_007_1.png",
        clippingImg = "n_UIShare/role/main/jsjm_b_007_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1196,
            pos_Y = 280,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { --角色列表  4
        dialog = "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 705,
            pos_Y = 519,
            scale_X = 0.9,
            scale_Y = 0.9,
            rotation = 0,
        },
        bubble={
            text = "Please select a character to enhance",
            dir = 1, --1左边 2，右边
            pos_X = 690,
            pos_Y = 467,
        } 
    },
    { --+++号  5
        dialog = "",
        clipping = "n_UIShare/Global_UI/btn/tc_b_002_1.png",
        clippingImg = "n_UIShare/Global_UI/btn/tc_b_002_1.png",
        arrow = {
            pos = 4, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 570,
            pos_Y = 530,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
        bubble={
            text = "Please select enhancement fruit quantity",
            dir = 2, --1左边 2，右边
            pos_X = 560,
            pos_Y = 485,
        } 
    },
    { --按钮开始强化  6
        dialog = "",
        clipping = "n_UIShare/newGuide/x_xsyd_zz_002.png",
        clippingImg = "n_UIShare/newGuide/xsyd_zz_002.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 318,
            pos_Y = 77,
            scale_X = 1.05,
            scale_Y = 0.55,
            rotation = 0,
        },
    },
    {  --7
        dialog = {
            "This little fruit can enhance your body and increase your experience gained in battle. Isn’t it incredible? ",
            "More enemies have appeared. This time you’ll need to defeat them by yourself. I wish you luck. "
        },
        isNoBtn = 2,
    },
    {--回到首页 8
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_001_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_001_1.png",
        arrow = {
            pos = 2, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1220, 
            pos_Y = 696,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {---9
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_043_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_043_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
            pos_X = 0,  --用于修正坐标 因为有的遮罩图片不是规则的
            pos_Y = - 23,
        },
        btn = {
            pos_X = 1140, 
            pos_Y = 429,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {--、10区域地图 按钮
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_006.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_006.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 310, 
            pos_Y = 192,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    },
    {--11列表
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_004.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_004.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 794, 
            pos_Y = 519,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {-- 12开始战斗
        dialog = "",
        clipping="n_UIShare/Nready/zqzb_b_001_1.png",
        clippingImg="n_UIShare/Nready/zqzb_b_001_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 640, 
            pos_Y = 42,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    }
}

-- 角色技能 升级
new_guide[guide_id_config.RoleSkill] = {
    {   --1选择对话
        dialog = {
            "You earned a Pact Scroll from the battle. You may use it to summon a new character. ",
            "Your characters will get skill points after reaching specific levels. You may spend skill points to learn or upgrade your characters’ active and passive skills.",
            "Tap on the button to start the skill points tutorial.",
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
        isSelectGuide = 1,
        acceptBtnStr = "Learn Now", ---todo回到首页然后开启下步引导
        refusedBtnStr = "Refuse",
        refusedType = 2, --拒绝类型（1为 强制引导，2为弱引导）
        refusedDialog = {
            "If you want to learn a new skill or upgrade an existing one, please tap on the Party button on the main screen to view the character list. After selecting a character, you may learn/upgrade skills on the skill screen. ",
        },
    },
    { --2、主界面 点击 队伍 
        dialog = {
            "Please follow the guide and enter the Skill screen. ",
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {  -- 3、 点击角色预览 
        dialog =  "",
        clipping = "n_UIShare/role/main/jsjm_b_007_1.png",
        clippingImg = "n_UIShare/role/main/jsjm_b_007_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1196,
            pos_Y = 410,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {  --4、角色列表 
        dialog =  "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 4, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 140,
            pos_Y = 538,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {   --5、角色页面，技能按钮亮起 12
        dialog =  "",
        clipping = "n_UIShare/role/info/jsjm_b_002_1.png",
        clippingImg = "n_UIShare/role/info/jsjm_b_002_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 1209,
            pos_Y = 480,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {   --6、技能升级按钮亮起-> 效果图13  
        dialog =  "",
        clipping = "n_UIShare/Global_UI/btn/qhzx_b_001_1.png",
        clippingImg = "n_UIShare/Global_UI/btn/qhzx_b_001_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 980,
            pos_Y = 50,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {   --7、 加技能点 + 处理+事件  效果图 14
        dialog =  "",
        clipping = "n_UIShare/role/info/jsjn_b_001_1.png",
        clippingImg = "n_UIShare/role/info/jsjn_b_001_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.7,
        },
        btn = {
            pos_X = 1184,
            pos_Y = 460,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {   --8点击技能8、 强化技能引导->效果图15  
        dialog =  "",
        clipping = "n_UIShare/Global_UI/btn/qhzx_b_001_1.png",
        clippingImg = "n_UIShare/Global_UI/btn/qhzx_b_001_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 1060,
            pos_Y = 50,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { --对话 9
        dialog = {
            "Alven has learned a new skill. Try it out in your adventures." 
        },
        isNoBtn = 1, --1 没有按钮 --意思是剧情对话结束就进行下步操作，不需要点击按钮
    },
}

--灵装使用 第一个是选择按钮
new_guide[guide_id_config.Equipment] = {
    {   --1 选择对话
        dialog = {
            "You earned a Costume from the battle. Equip it on your character to greatly enhance their power. ",
            "Let me tell you how to use costumes. ",
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
        isSelectGuide = 1,
        acceptBtnStr = "Equip Now", ---todo回到首页然后开启下步引导
        refusedBtnStr = "Refuse",
        refusedType = 2,--拒绝类型（1为 强制引导，2为弱引导）
        refusedDialog = {
            "You may equip costumes on the Character Info screen.",
        },
    },
    { --2、主界面 点击 队伍
        dialog = {
            "Please follow the guide and enter the Costume screen. "
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { -- 3、 点击角色预览 
        dialog =  "",
        clipping = "n_UIShare/role/main/jsjm_b_007_1.png",
        clippingImg = "n_UIShare/role/main/jsjm_b_007_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1196,
            pos_Y = 410,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {  --4、角色列表 
        dialog =  "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 4, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 140,
            pos_Y = 538,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {   --5、装备按钮亮起 效果图 08
        dialog =  "",
        clipping = "n_UIShare/role/info/jsjm_b_003_1.png",
        clippingImg = "n_UIShare/role/info/jsjm_b_003_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 1210,
            pos_Y = 389,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {   --6、 效果图09 人物装备+
        dialog =  "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 663,
            pos_Y = 562,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {  --7、效果图10 装备列表
        dialog =  "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 4, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 140,
            pos_Y = 500,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { --对话 9
        dialog = {
            "Characters will become more powerful after equipping costumes. Don’t forget that costumes can also be enhanced.",
            "Costume enhancement is unlocked. Please feel free to enhance your costumes. "
        },
        isNoBtn = 2, --1 没有按钮 --意思是剧情对话结束就进行下步操作，不需要点击按钮
    },
}
---女主 神格
new_guide[guide_id_config.Godhead] = {
    {   --1 选择对话
        dialog = {
            "It seems 「The Other Me」has remembered the power of Divinity Presence. Divinity Presence can instantly turn the tide of the battle. ",
            "Start the Divinity System tutorial. ",
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",

        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },

        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },

        isSelectGuide = 1,
        acceptBtnStr = "Activate Now", ---todo回到首页然后开启下步引导
        refusedBtnStr = "Refuse",
        refusedType = 2,--拒绝类型（1为 强制引导，2为弱引导）

        refusedDialog = {
            "When you want to activate a Divinity, you may enter the Character screen and edit your Divinity. ",
        },
    },
    { --2、主界面 点击 队伍 弹出四个按钮  2
        dialog = {
            "Please follow the guide and enter the Divinity screen. "
        },
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },

    { --3、神格变更按钮
        dialog = "",
        clipping = "n_UIShare/Global_UI/btn/xqzx_b_001_1.png",
        clippingImg = "n_UIShare/Global_UI/btn/xqzx_b_001_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 290,
            pos_Y = 47,
            scale_X =1,
            scale_Y = 1,
            rotation = 0,
        },
    },

    { --4、选择第一个女主
        dialog = "",
        clipping = "n_UIShare/new_GZ/gzzy_ui_003.png",
        clippingImg = "n_UIShare/new_GZ/gzzy_ui_003.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 690,
            pos_Y = 526,
            scale_X = 1.0,
            scale_Y = 1,
            rotation = 0,
        },
    },

    { --5、获得
        dialog = "",
        clipping = "n_UIShare/princess/info/sg_b_002_1.png",
        clippingImg = "n_UIShare/princess/info/sg_b_002_1.png",

        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1040,
            pos_Y = 80,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { --6、 启用按钮
        dialog = "",
        clipping = "n_UIShare/princess/info/sg_b_002_1.png",
        clippingImg = "n_UIShare/princess/info/sg_b_002_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1040,
            pos_Y = 80,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {  --7对话 12
        dialog = {
            "You have activated a primary Divinity. Please head continue your adventure and experience the power of Divinity Presence."
        },
        isNoBtn = 2, --1 没有按钮 --意思是剧情对话结束就进行下步操作，不需要点击按钮
    },
}
---起名字引导
new_guide[guide_id_config.NewName] = {
    {  --7对话 12
        dialog = {
            "Please select a name for your party. I have a feeling that you’ll need it sooner or later. ",
            "Nickname should be within 1 to 12 characters. "
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
    {  --7对话 12
        dialog = {
            "%s,Login"
        },
        isNoBtn = 2, --1 没有按钮 --意思是剧情对话结束就进行下步操作，不需要点击按钮
    },
} 
--灵装强化
new_guide[guide_id_config.StEquip] = {
    {  --7对话 12
        dialog = {
            "You have acquired materials for costume enhancement. Use these materials to upgrade your costume. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--商店：道具屋，神秘商店
new_guide[guide_id_config.Shop] = {
    {  --7对话 12
        dialog = {
            "Shop is unlocked. You may purchase various items and materials from it.",
             "Mage Haiji has joined in your party. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--公会基础功能
new_guide[guide_id_config.Guild] = {
    {  --7对话 12
        dialog = {
            "Guilds are now unlocked. After joining a guild, you will enjoy additional support effects and can challenge the Guild Tower. ",
            "Defeat monsters in Guild Tower and all guild members will get valuable rewards. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--灵装融合
new_guide[guide_id_config.Equip2] = {
    {  --7对话 12
        dialog = {
            "You can select costumes above 3 stars as the fusion material to upgrade the target costume. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--星界探索
new_guide[guide_id_config.Explore] = {
    {  --7对话 12
        dialog = {
            "Star World is unlocked. You may send your heroes to explore the Star World and get rare items. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--公会塔
new_guide[guide_id_config.GuildTower] = {
    {  --7对话 12
        dialog = {
            "Guild members may challenge the Guild Tower to demonstrate their power and win valuable rewards. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--铸造功能
new_guide[guide_id_config.Casting] = {
    {  --7对话 12
        dialog = {
            "Costume crafting is unlocked. You can craft new costumes now. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--多人战斗
new_guide[guide_id_config.MoreBattle] = {
    {  --1对话 12
        dialog = {
            "The enemies have retreated...\nBut I can feel the presence of the Deposed God far away. ",
            "Don’t approach them recklessly. They may be man-made, but they each have their own unique power. They are extremely powerful. ",
            "If you really want to challenge him, please follow my guidance and find enough allies. "
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
    {   --2点击多人战按钮
        dialog =  "",
        clipping = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        clippingImg = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 636,
            pos_Y = 90,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {  --3对话 12
        dialog =  {
            "Players need to work together to defeat the Deposed God. Here you can see requests from other players. You may choose a request to join a battle. ",
            "It costs only gold (no stamina) to join in an existing multiplayer battle. There is no limit to the times that you can join in multiple battles. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
    {   --4 创建多人战按钮
        dialog = "",
        clipping = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        clippingImg = "n_UIShare/Global_UI/btn/ggsc_b_004_2.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 1174,
            pos_Y = 340,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {  --对话 5
        dialog = {
            "You can create your own multiplayer battle and request for help from other players. You can create 5 stages of each difficulty level per day.",
             "It costs Stamina to create a multiplayer battle. However, after the battle is won, the creator will get an additional reward. ",
             "Even if your party is defeated in a multiplayer battle, you can still get the rewards by waiting for the other players to defeat the enemies. The most powerful costumes are dropped from multiplayer battles. ",
             "You may earn Battle Contribution by inflicting damage or negative effects on enemies or granting buff effects to your allies. Higher contribution grants you a better chance to get rare items. "
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
    -- {--6列表
    --     dialog = "",
    --     clipping="n_UIShare/newGuide/x_xsyd_zz_004.png",
    --     clippingImg="n_UIShare/newGuide/x_xsyd_zz_004.png",
    --     arrow = {
    --         pos = 3, --  1 2 3 4 对应上 下 左 右  
    --         img = "n_UIShare/newGuide/xsyd_ui_004.png",
    --         scale = 1.0,
    --     },
    --     btn = {
    --         pos_X = 770, 
    --         pos_Y = 530,
    --         scale_X = 1,
    --         scale_Y = 1,
    --         rotation = 0,
    --     },
    -- },
    -- {--7开始战斗
    --     dialog = "",
    --     clipping="n_UIShare/Nready/zqzb_b_001_1.png",
    --     clippingImg="n_UIShare/Nready/zqzb_b_001_1.png",
    --     arrow = {
    --         pos = 3, --  1 2 3 4 对应上 下 左 右  
    --         img = "n_UIShare/newGuide/xsyd_ui_004.png",
    --         scale = 1.0,
    --     },
    --     btn = {
    --         pos_X = 640, 
    --         pos_Y = 42,
    --         scale_X = 1,
    --         scale_Y =  1,
    --         rotation = 0,
    --     },
    -- }
} 

--角色突破   
new_guide[guide_id_config.HeroBT] = {
    {   --选择对话   1
        dialog = {
            "You're working hard! Did you encounter a bottleneck in character's level up? Just find more Potential Unleashed Materials in Land of Trial, that may help you increase the character's level cap.",
            "Characters can be potential unleashed in any level. After that, the character level cap will be increased and your characters will get many skill points too. ",
        },
        isNoBtn = 2,
    },
    { --2、主界面 点击 队伍 
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_037_1.png",
        arrow = {
            pos = 1, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 93,
            pos_Y = 66,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {  -- 3、 点击角色突破按钮
        dialog =  "",
        clipping = "n_UIShare/role/main/jsjm_b_007_1.png",
        clippingImg = "n_UIShare/role/main/jsjm_b_007_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.8,
        },
        btn = {
            pos_X = 1196,
            pos_Y = 160,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    { --角色列表  4
        dialog = "",
        clipping = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        clippingImg = "n_UIShare/Global_UI/rarity/ggsc_ui_224.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 0.9,
        },
        btn = {
            pos_X = 705,
            pos_Y = 519,
            scale_X = 0.9,
            scale_Y = 0.9,
            rotation = 0,
        },
        bubble={
            text = "Select a character to unleash.",
            dir = 1, --1左边 2，右边
            pos_X = 690,
            pos_Y = 467,
        } 
    },
    { --开始突破  5
        dialog = "",
        clipping = "n_UIShare/newGuide/x_xsyd_zz_002.png",
        clippingImg = "n_UIShare/newGuide/xsyd_zz_002.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 320,
            pos_Y = 77,
            scale_X = 1.05,
            scale_Y = 0.55,
            rotation = 0,
        },
        bubble={
            text = "Related materials for Character Potential Unleashed.",
            dir = 1, --1左边 2，右边
            pos_X = 346,
            pos_Y = 450,
        } 
    },
    {  --6
        dialog = {
            "We may not see each other again. Please take care of Aisha and help her retrieve her memories...",
            "Soul Essence for persona WS-α is depleted. Sleep mode activated\nSystem down"
        },
        isNoBtn = 2,
    },
} 
--灵装突破  
new_guide[guide_id_config.EquipBT] = {
    {  --7对话 12
        dialog = {
            "To breakthrough a costume, it needs to consume another costume of the same name. After the breakthrough is complete, the costume’s level cap will be raised. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--大型活动
new_guide[guide_id_config.Act] = {
    {  --7对话 12
        dialog = {
            "A new grand event has started. Please refer to the Event screen for more info. By joining in grand events, players may get exclusive characters and awakening items as rewards. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--试炼按钮  
new_guide[guide_id_config.Trial] = {
    {  --1对话
        dialog = {
            "Was it a tough battle against the soldiers in the Frontline Fortress? The enemies ahead will be even more powerful. ",
            "Now let’s head for the Land of Trial. That’s the habitat of the elemental spirits. You can get lots of breakthrough materials there. ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
    {---2 主界面试炼之地
        dialog = "",
        clipping = "n_UIShare/newZhuye/ggsc_b_046_1.png",
        clippingImg = "n_UIShare/newZhuye/ggsc_b_046_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
            pos_X = 0,  --用于修正坐标 因为有的遮罩图片不是规则的
            pos_Y = 0,
        },
        btn = {
            pos_X = 943, 
            pos_Y = 390,
            scale_X = 1.0,
            scale_Y = 1.0,
            rotation = 0,
        },
    },
    {--3列表
        dialog = "",
        clipping="n_UIShare/newGuide/x_xsyd_zz_004.png",
        clippingImg="n_UIShare/newGuide/x_xsyd_zz_004.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 790, 
            pos_Y = 530,
            scale_X = 1,
            scale_Y = 1,
            rotation = 0,
        },
    },
    {--4开始战斗
        dialog = "",
        clipping="n_UIShare/Nready/zqzb_b_001_1.png",
        clippingImg="n_UIShare/Nready/zqzb_b_001_1.png",
        arrow = {
            pos = 3, --  1 2 3 4 对应上 下 左 右  
            img = "n_UIShare/newGuide/xsyd_ui_004.png",
            scale = 1.0,
        },
        btn = {
            pos_X = 640, 
            pos_Y = 42,
            scale_X = 1,
            scale_Y =  1,
            rotation = 0,
        },
    },
    {  --5对话 12
        dialog = {
            "In the Land of Trial, you can get not only Fruits of Trial, but also Potential Unleashed Materials for higher character level cap. Click tags on the left to select different stage types.  ",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 
--黑潮遗迹
new_guide[guide_id_config.HeiCao] = {
    {  --7对话 12
        dialog = {
            "The extremely dangerous Darktide Ruins has been discovered outside the border of Kradict Federal.",
            "The exploration of Darktide Ruins has started. Each investigation party contains a leader and 8 other mercenaries. ",
            "Choose your allies and help the leader defeat the infinite monsters in Darktide Ruins!",
        },
        isNoBtn = 2, --1 对话完成直接 调用endGuideFunc   2.是直接执行sub引导事件
    },
} 

