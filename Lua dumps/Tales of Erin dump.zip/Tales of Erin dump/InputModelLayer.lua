--[[
InputModelLayer.lua
测试版输入框 11.16
点击确定，回调一个str
。todo
回调成功之后，1、自动移除（不管修改成功不成功）  2、是修改成功之后手动移除
目前选中 1
说明 现在统一使用 editbox 11.15因为输入框 包含数字模式，这个地方可以直接设置模式 以后扩展
self.confirmFunc = self.rData["rcvData"]["confirmFunc"]
self.sDelegate = self.rData["rcvData"]["sDelegate"]
self.maxLength = self.rData["rcvData"]["maxLength"] or 10--最大限定符

self.isCheckWarnWord = self.rData["rcvData"]["isCheckWarnWord"] or false -- 是否检测关键词，默认为false
isCheckWarnWord true 有敏感词，无法点击确定
]]
require "BasicLayer"

InputModelLayer = class("InputModelLayer",BasicLayer)
InputModelLayer.__index = InputModelLayer
InputModelLayer.lClass = 3

function InputModelLayer:init()
    self.sManager = self.rData["sManager"]
    self.confirmFunc = self.rData["rcvData"]["confirmFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.maxLength = self.rData["rcvData"]["maxLength"] or 50--最大限定符
    self.isCheckWarnWord = self.rData["rcvData"]["isCheckWarnWord"] or false--是否检测关键词，默认为false
    self.autoCloseByMaxLength = self.rData["rcvData"]["autoCloseByMaxLength"] or false
    local defalutStr = self.rData["rcvData"]["defalutStr"]
    local node = cc.CSLoader:createNode("InputLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self._rootCSbNode = node:getChildByTag(101) 
    -----下面是两种输入框 android 用editbox ，ios用 textfied  统一只用editbox ，另一种留着吧，以后万一用哪
    --输入框
    self._inputDes = ccui.Helper:seekWidgetByName(self._rootCSbNode, "input_desc")
    -- if cc.PLATFORM_OS_ANDROID == targetPlatform then 
    --     self:initEditBox()
    -- else
    --     --这个是第一种输入框
    --     self._inputDes:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    --     self._inputDes:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    --     self._inputDes:setString(defalutStr)
    --     self._inputDes:setContentSize(cc.size(935,65))
    --     self._inputDes:setMaxLength(50) --这个地方最大输入字数为50，验证字数，放到后面了
    --     self._inputDes:attachWithIME() --默认开启键盘
    -- end
    self.exist = true
    self.willRemoved = false
    self:initEditBox()
    self:initBtn()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

end
--说明。隐藏输入框这里是按照颜色来隐藏的   请注意 self._editBoxDes:setFontColor(cc.c3b(0,0,0))
function InputModelLayer:initEditBox()

    local defalutStr = self.rData["rcvData"]["defalutStr"]
    local function editBoxTextEventHandle(strEventName,pSender)
        if self.willRemoved == true then
            return
        end
        if strEventName == "began" then
            self.showLabel:setVisible(false)
            self._editBoxDes:setFontColor(cc.c3b(0,0,0))
        elseif strEventName == "ended" then
            -- if pSender:getText()~= "" and pSender:getText()~= " " then 
            --     self.showLabel:setString(pSender:getText())
            -- end
            self.showLabel:setString(pSender:getText()) 
            self.showLabel:setVisible(true)
            self._editBoxDes:setFontColor(cc.c3b(255,255,255))
        elseif strEventName == "return" then
            -- if pSender:getText()~= "" and pSender:getText()~= " " then 
            --     self.showLabel:setString(pSender:getText())
            -- end 
            self.showLabel:setString(pSender:getText())
            self.showLabel:setVisible(true)
            self._editBoxDes:setFontColor(cc.c3b(255,255,255))
        elseif strEventName == "changed" then
       
            if self.autoCloseByMaxLength == true and self:checkMaxLengthStr(pSender:getText()) ~= true then
                print("InputModelLayer:initEditBox changed")
                self.willRemoved = true
                UITool.delayTask(0.01, function()
                        if self.exist == false then
                            return
                        end
                        self:returnBack()

                    end)
                
            end
            
        end 
        -- if pSender:getText()~= "" and pSender:getText()~= " " then 
        --     self.showLabel:setString(pSender:getText())
        -- end
        self.showLabel:setString(pSender:getText()) 
    end

    self._inputDes:setVisible(true)
    self._inputDes:removeFromParent()
    self._inputDes = nil

    local inputBG = ccui.Helper:seekWidgetByName(self._rootCSbNode, "Image_2")
    local img = "n_UIShare/Global_UI/other/dhjm_ui_3.png"
    local pos = cc.p(inputBG:getPositionX(),inputBG:getPositionY())
    self._editBoxDes = UITool.getEditBox(img, inputBG:getContentSize(), pos, 50, "")
    self._editBoxDes:setAnchorPoint(cc.p(0,0.5))
    self._editBoxDes:setFontColor(cc.c3b(0,0,0))
    self._editBoxDes:setFontSize(30)
    self._editBoxDes:setFontName(TEXT_FONT_NAME)
    self._editBoxDes:setPlaceholderFont(TEXT_FONT_NAME,30)
    self._editBoxDes:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    self._editBoxDes:setPlaceholderFontColor(cc.c3b(255,255,255))
    if g_channel_control.inputMaxLength == true then --不能使用？？？
        self._editBoxDes:setMaxLength(self.maxLength)
    else
        self._editBoxDes:setMaxLength(100)
    end
    local editbox_bg = ccui.Helper:seekWidgetByName(self._rootCSbNode, "editbox_bg")
    editbox_bg:addChild(self._editBoxDes,100)
    inputBG:removeFromParent()
    --默认开启键盘
    self._editBoxDes:setText(defalutStr)
    self._editBoxDes:registerScriptEditBoxHandler(editBoxTextEventHandle)

    local pos2 = cc.p(inputBG:getPositionX()+4,inputBG:getPositionY())
    self.showLabel = cc.Label:createWithTTF(defalutStr, TEXT_FONT_NAME, 30)
    if self.showLabel ~= nil then
        self.showLabel:setPosition(pos2)
        self.showLabel:setColor(cc.c3b(0,0,0))
        self.showLabel:setAnchorPoint(cc.p(0,0.5))
        local showLabel_bg = ccui.Helper:seekWidgetByName(self._rootCSbNode, "showLabelbg")
        showLabel_bg:addChild(self.showLabel,101)
    end
    self._editBoxDes:touchDownAction(self._editBoxDes,ccui.TouchEventType.ended)
end

function InputModelLayer:initBtn()
    -- body
    local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender:getTag() == 1000 then
                text = self.showLabel:getString()
                local isOK = self:checkStr(text) 
                if isOK then 
                    if self.isCheckWarnWord then
                        text = self:changeToSensitive(text) --检测敏感词
                    end
                    self.confirmFunc(self.sDelegate, text)
                    self:returnBack()
                end 
            elseif sender:getTag() == 1001 then
                self:returnBack()
            end 
        end
    end
    --确定
    local btn_1 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_confirm")
    btn_1:addTouchEventListener(onBtnEvent)
    btn_1:setTag(1000)
    --更改个性签名
    local btn_2 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_cancel")
    btn_2:addTouchEventListener(onBtnEvent)
    btn_2:setTag(1001)
end

--检测输入 内容
function InputModelLayer:checkStr(text)
    local isOK = false
    if text~="" then 
        ---处理屏蔽词
        local isNoWarn = self:isNoWarningStr(text)
        if isNoWarn then 
            ---字符串长度
            local isLengthOK = self:checkMaxLengthStr(text)
            if isLengthOK then
                isOK = true
            end 
        end 
    else 
        --local str = UITool.ToLocalization("不能为空")
        --SceneManager:showPromptLabel(str)
        isOK = true
    end 
    return isOK
end

function InputModelLayer:changeToSensitive( text )
    local textLower = string.lower(text)

    local textNew = WarnStrFuncManager:warningStrGsub(textLower)
    --print("======敏感字检测：原始："..text.."      转换："..textNew)
    if textLower == textNew then
        return text
    else
        return textNew
    end
    
end

---检测敏感词,有敏感词 返回false 没有敏感词返回OK
function InputModelLayer:isNoWarningStr(text)
    local isOK = true
    return isOK
end

---检测 字符串长度
function InputModelLayer:checkMaxLengthStr(text)
    --获取长度 如果别的地方也用 放到公共里面吧
    local function getCharLength(str)
        str = str or ""
        local strLength = 0
        local len = string.len(str)
        while str do
            local fontUTF = string.byte(str,1)

            if fontUTF == nil then
                break
            end
            --lua中字符占1byte,中文占3byte
            if fontUTF > 127 then 
                local tmp = string.sub(str,1,3)
                strLength = strLength+1
                str = string.sub(str,4,len)
            else
                local tmp = string.sub(str,1,1)
                strLength = strLength+0.5
                str = string.sub(str,2,len)
            end
        end
        return strLength
    end
    local isOK = true

    local nowLength = getCharLength(text)
    print("当前字符串长度  "..nowLength)
    if nowLength > self.maxLength then 
        local str =string.format(UITool.ToLocalization("你输入的内容长度已超出%d个字的限制，请重新输入"), self.maxLength)
        if g_channel_control.InputModelLayer_MaxX2 == true then 
            str =string.format(UITool.ToLocalization("你输入的内容长度已超出%d个字的限制，请重新输入"), self.maxLength*2)
        end
         SceneManager:showPromptLabel(str)
        -- if self.willRemoved == false then
        --     SceneManager:showPromptLabel(str)
        -- end

        -- if self.autoCloseByMaxLength == true and self.willRemoved == false then
        --     print("InputModelLayer:checkMaxLengthStr")
        --     self.willRemoved = true
            

        --     UITool.delayTask(0, function()
        --             if self.exist == false then
        --                 return
        --             end
        --             SceneManager:showPromptLabel(str)
        --             self:returnBack()

        --         end)
            
        -- end
        
        isOK = false 
    end
    return isOK
end

function InputModelLayer:changeToSensitive( text )
    local textLower = string.lower(text)

    local textNew = WarnStrFuncManager:warningStrGsub(textLower)
    print("======敏感字检测：原始："..text.."      转换："..textNew)
    if textLower == textNew then
        return text
    else
        return textNew
    end
    
end
--取消
function InputModelLayer:returnBack()
    --关闭键盘
    local director = cc.Director:getInstance()
    director:getOpenGLView():setIMEKeyboardState(false)
    self.exist = false
    self:clearEx()
end

function InputModelLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function InputModelLayer:create(rData)
    local layer = InputModelLayer.new()
    layer.rData = rData
    layer.uiLayer = cc.Layer:create()
    layer:init()
    return layer
end
