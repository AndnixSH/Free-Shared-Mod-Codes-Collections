
AllianceBattle_RankPublicLayer= class("AllianceBattle_RankPublicLayer",BasicLayer)
AllianceBattle_RankPublicLayer.__index        = AllianceBattle_RankPublicLayer
AllianceBattle_RankPublicLayer.lClass         = 2

---------self.curType  1 玩家排行  2 公会排行  3 贡献度
function AllianceBattle_RankPublicLayer:init()
	local node  = cc.CSLoader:createNode("AllianceBattle_RankPublicLayer.csb")
    self.uiLayer:addChild(node,0,2)
    
    self.table   = self.rData["table"]
    self.curType = self.rData["curType"]
    -- 玩家排行自己的显示
    if self.rData["myTable"] then
        self.myTable = self.rData["myTable"]
    else
        self.myTable = nil
    end

    self:initView(self.rData["width"],self.rData["height"],self.rData["itemNode"])



   
end
-- 初始化listView 也是公用的方法  -----根据类型来设置显示哪个底板
-- 为了保持这个函数的纯净这里只做 1 判断显示哪个板子  2 根据类型调用这只板子的函数 3 设置Node
-- [[ self.curType == 1 or self.curType == 2  框上显示列表  ，有自己数据的显示区域]]
-- [[ self.curType == 3  框上显示列表 ， 没有自己数据的显示区域]]
function AllianceBattle_RankPublicLayer:initView( w,h,itemNode )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    local panel = nil
    if self.curType == 1 or self.curType == 2 then
        panel = node:getChildByName("Image_BgForm_0"):getChildByName("Panel_List")
        node:getChildByName("Image_BgForm_0"):setVisible(true)
        node:getChildByName("Image_BgForm_1"):setVisible(false)
        self.curTitleType = 1
    elseif self.curType == 3 then
        panel = node:getChildByName("Image_BgForm_1"):getChildByName("Panel_List")
        node:getChildByName("Image_BgForm_0"):setVisible(false)
        node:getChildByName("Image_BgForm_1"):setVisible(true)
        self.curTitleType = 2
    end
    -- 设置板子的名字
    self:setTitle(self.rData["titleName"])
    -- 根据类型设置显示自己的数据
    if self.curType == 1 then 
        self:setUserSelf()
    elseif self.curType == 2  then
        self:setGuildSelf()
    elseif self.curType == 3 then
        self:setContribute()
    end
     
    self.panelList = panel
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,w,h)
    self.gridview.itemCreateEvent = function()
        local temp = itemNode.new():init()
        self.m_temp = temp
        temp:setType(self.curType)
        if self.rData["_showImageType"] then
            temp:showImageType(self.rData["_showImageType"])
        end
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                 
                end
            end
        end 
        return temp
    end
    self:refreshTale()
end
------------------------这是根据不同的界面设置不同的数据-------------
------------------------设置不同数据的地方同意写在这里
-- 设置贡献度板子的赠送次数
-- 代码中修改将其隐藏  策划需求
function AllianceBattle_RankPublicLayer:setContribute( ... )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local Image_Bg   = node:getChildByName("Image_BgForm_1")
    local Image_give = Image_Bg:getChildByName("Image_give")
    Image_give:setVisible(false)
    -- local cur        = Image_give:getChildByName("Text_curGivegive")
    -- local max        = Image_give:getChildByName("Text_maxGivegive")
    -- cur:setString(tostring(self.myTable["cur_give_num"]))
    -- max:setString("/"..self.myTable["max_give_num"])
end
-- 设置自己板子上的显示 和事件
function AllianceBattle_RankPublicLayer:setUserSelf( ... )
    -- body

    local node      = self.uiLayer:getChildByTag(2);
    local Image_Bg  = node:getChildByName("Image_BgForm_0")
    local persional = Image_Bg:getChildByName("Image_personal")
    local guild     = persional:getChildByName("Panel_guild")
    guild:setVisible(false)
    -- 头像
    local headImage = persional:getChildByName("Image_icon")
    -- 自己的id
    local userId    = persional:getChildByName("Text_ID")
    -- 排行
    local ranking   = persional:getChildByName("Text_rank")
    -- 贡献度
    local contribution    = persional:getChildByName("Text_con")

    -- [[1 个人积分  2 最高伤害]]
    local ImageType       = persional:getChildByName("Image_31")
    if self.rData["_showImageType"] == 1 then
        ImageType:loadTexture("n_UIShare/UltimateChallenge/jxtz_ui_002.png") 

    elseif self.rData["_showImageType"] == 2 then
        ImageType:loadTexture("n_UIShare/UltimateChallenge/jxtz_ui_001.png")
    else
    end


    --userId:setString(self.myTable.uid)
    userId:setString(self.myTable.name)
    ranking:setString(tostring(self.myTable.ranking))
    print("self.myTable.ranking == "..self.myTable.ranking)
    ranking:setVisible(true)
    if g_channel_control.transform_AllianceBattle_RankPublicLayer_Text_rank_pos == true then
        local oldX = 516.5
        local newX = oldX+40
        ranking:setPositionX(newX)
    end
    local heroid  = tonumber(self.myTable["head"])
    headImage:setUnifySizeEnabled(true)
    print("table table == "..self.myTable["head"])
    print("heroid heroid == "..heroid)
    headImage:loadTexture(hero[heroid].hero_bat_icon)
    -- 如果不为空证明是作为极限挑战的排行
    if self.myTable.attack_value then
        self.myTable.contribution = self.myTable.attack_value
    end
    contribution:setString(tostring(self.myTable.contribution))
end
function AllianceBattle_RankPublicLayer:setGuildSelf( ... )
    -- body

    local node      = self.uiLayer:getChildByTag(2);
    local Image_Bg  = node:getChildByName("Image_BgForm_0")
    local persional = Image_Bg:getChildByName("Image_personal")
    local guild     = persional:getChildByName("Panel_guild")
    guild:setVisible(true)
    local userId    = persional:getChildByName("Text_ID")
    local userIdt    = persional:getChildByName("Text_ID_title")
    userId:setVisible(false)
    userIdt:setVisible(false)
  
    
    
    -- 排行
    local ranking         = persional:getChildByName("Text_rank")
    -- 贡献度
    local contribution    = persional:getChildByName("Text_con")
    -- 公会名字
    local guildName       = guild:getChildByName("Text_guildName")    
    -- 会长名字  
    local chairman        = guild:getChildByName("Text_ID_title_0")
    -- 公会形象
    local headImage       = persional:getChildByName("Image_icon")

    local heroid  = tonumber(self.myTable["image"])
    headImage:setUnifySizeEnabled(true)
    headImage:loadTexture(hero[heroid].hero_bat_icon)

    guildName:setString(self.myTable.name)
    chairman:setString(self.myTable.chairman)
    ranking:setString(tostring(self.myTable.ranking))
    ranking:setVisible(true)
    if g_channel_control.transform_AllianceBattle_RankPublicLayer_Text_rank_pos == true then
        local oldX = 516.5
        local newX = oldX+40
        ranking:setPositionX(newX)
    end
    contribution:setString(tostring(self.myTable.contribution))
end
------------------------------公用的方法-----------------------
-- 传入数据
function AllianceBattle_RankPublicLayer:refreshTale()
    print("self.table self.table == "..#self.table)
    self.gridview:setDataSource(self.table)
end
-- 外不用来刷新的
function AllianceBattle_RankPublicLayer:refreshTaleTT(table)
    print("self.table self.table == "..#table)
    self.gridview:setDataSource(table)
end
-- 外部用来刷新自己的
function AllianceBattle_RankPublicLayer:refreshUser(table)
    self.myTable = table
    self:setUserSelf()
end
-- 设置板子上的名字
function AllianceBattle_RankPublicLayer:setTitle( name )
    -- body
    print("name name name == "..name)
    local node  = self.uiLayer:getChildByTag(2)
    local per_0 = node:getChildByName("Image_BgForm_0")
    local per_1 = node:getChildByName("Image_BgForm_1")
     local title = nil
    if per_0:isVisible() then
        title = per_0:getChildByName("Text_title")
    elseif per_1:isVisible() then
        title = per_1:getChildByName("Text_title")
    end
    title:setString(name)
end
-- 返回回调函数
function AllianceBattle_RankPublicLayer:returnBack( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    self.backFunc(self.sDelegate,self.sData)
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clear()

end

function AllianceBattle_RankPublicLayer:create(rData)
    local login    = AllianceBattle_RankPublicLayer.new()
    login.rData    = rData
    login.uiLayer  = cc.Layer:create()
    login:init()
    return login
end
