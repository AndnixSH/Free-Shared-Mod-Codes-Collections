require "BasicLayer"

ActManageLayer = class("ActManageLayer",BasicLayer)
ActManageLayer.__index = ActManageLayer
ActManageLayer.lClass = 2

-----------------说明新加的类型 facebook跳转网页
--[[
    ShowOnlyImageToFacebook() 显示新的类型
    sendFacebookGetaward()    获取奖励
    getBrightBtn()            获取禁用函数
    sendFacebookState()       同步btn_sate 状态
    添加新的参数
    ["act_show_type"]  = facebook
    ["parameter"]      = 网址
    ["btn_normal"]     = -- 跳转正常的按钮图片
    ["btn_click"]      = -- 跳转点击高亮图片
    ["btn_state"]      = 1,-- 状态 1 跳转状态  2 领取状态  3 领取过状态
    ["btn_time"]       = 20,--跳转变化成领取状态的时间

]]
--[[
    说明:
    ActManageLayer   活动的展示
    {
        sendData() 获取右边标签列表 和活动类型
            only_show      单一图片 没有子项(ShowOnlyImage()调用此函数 对活动进行展示)

            achieve        成就活动 带子项(带子项 sendDataOnly()调用此函数获取子项数据)
            landing_award  签到活动 带子项

            facebook       跳转网页(ShowOnlyImageToFacebook)

    }
    ActManageItemNode  右边标签（点击右标签，链接服务器获取数据）
    ActManageLongNode  子项显示（点击右标签，根据活动类型 链接服务器，获取里边子项的显示数据）

]] 
--/*对csb，和一些资源的备注*/
-- ActManageLayer 里面有两个listView（listView_1 是显示活动的条目）（listView_right 显示的是右边的活动选项）
-- 对应了两个node 一个是元素条目 ActManageLongNode    ActManageItemNode 这个是右边选项的node
-- ActManageLayer。csb 中image_from 这个集合是初始的显示 
-- image_info 是点击详细时候弹出的信息框 为了减少判断，直接单做出一个集合
-- image_whole 是显示整张图片的的原因和上边一样

-- /*  function      函数的注释 */--
-- inin              初始话函数
-- setPublicPor      设置面板上的公用属性 共有属性会根据选择不同的活动进行变化，放入ActManageItemNode中调用
-- showInfo          显示活动的详细界面点击详细按钮调用的
-- ShowOnlyImage     显示单个的图片
-- initPaneList      初始化pane_list
-- PassOnNode        将数据传入到ActManageNode
-- initPaneListRight 初始化右边的Pane_list
-- sendData          链接服务器获取服务器数据
-- sendDataOnly      链接服务器获取不同活动的数据 因为是点击不同活动是调用的所以需要在ItemNode中调用
-- sendGet           链接服务器获取活动奖励
-- ShowOnlyAch       显示图片的成就
-- initPaneList1     和 initPaneList 显示活动里边的条目是一样的模板  这里只是加了上边的图片和pane_list大小的变化
-- setNilPublicPor   置空image_form 上的text 
-- steUnLockLevel    因为解锁等级的数据放在最外层的接口 就是获取右边时候传入的  所以需要记录，
-- 每次点击或获取每个活动里的列表不是同一个接口
-- 初始化

-- /*变量*/
-- ActTablePublic   --保存共有的属性 和右边按钮控件的信息
-- selectIndex       用来记录当前右边的选择 默认是第一个
-- ActListTable     -- 保存当前每个活动的数据表
-- curActId         当前活动ID
-- 记录这个按钮传入到ActManageItemNode  在这里处理点击
-- UnLock_level     -- 保存当前的解锁等级

ActManageLayer.ActTablePublic = nil
ActManageLayer.selectIndex    = 1
ActManageLayer.curActId       = nil
ActManageLayer.UnLock_level   = 1
ActManageLayer.actId          = nil
function ActManageLayer:init( ... )
    -- body
    local node  = cc.CSLoader:createNode("ActManageLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true
    self:setNilPublicPor()
    self:sendData(false)
    self:initButton()
    self:hidePublic()

            --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
-- 一些主按钮 比如返回之类的写在此函数里面
function ActManageLayer:initButton( ... )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
            self:returnBack()
       end
    end
    local closeBtn   = node:getChildByName("Button_close")
    closeBtn:addTouchEventListener(touchCallBack)
end
function ActManageLayer:getActMangeActId(  )
    -- body
    
    return self.actId
end
-- Image_from 置空上边手动设置的text
-- 因为进入会有一闪的 所以初始化时候置空  
function ActManageLayer:setNilPublicPor( ... )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local image_from = node:getChildByName("Image_from")

    -- 主标题
    local title      = image_from:getChildByName("Text_title")
    title:setString("")
    -- 时间
    local time       = image_from:getChildByName("Text_time")
    time:setString("")
    -- 活动介绍
    local des        = image_from:getChildByName("Text_time_0")
    des:setString("")
end
--记录当前的解锁等级
function ActManageLayer:steUnLockLevel(level)
    -- body
    self.UnLock_level = level
end
function ActManageLayer:hidePublic( ... )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local image_info = node:getChildByName("Image_info")
    image_info:setVisible(false)

    local Image_whole = node:getChildByName("Image_whole")
    Image_whole:setVisible(false)

    local Image_image_ac = node:getChildByName("Image_image_ac")
    Image_image_ac:setVisible(false)

    local Image_facebook = node:getChildByName("Image_facebook")
    Image_facebook:setVisible(false)

    local image_from = node:getChildByName("Image_from")
    image_from:setVisible(false)
end

-- 设置面板上的公用属性 共有属性会根据选择不同的活动进行变化，放入ActManageItemNode中调用
function ActManageLayer:setPublicPor( data )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local image_info = node:getChildByName("Image_info")
    image_info:setVisible(false)

    local Image_whole = node:getChildByName("Image_whole")
    Image_whole:setVisible(false)

    local Image_image_ac = node:getChildByName("Image_image_ac")
    Image_image_ac:setVisible(false)

    local Image_facebook = node:getChildByName("Image_facebook")
    Image_facebook:setVisible(false)

    local image_from = node:getChildByName("Image_from")
    image_from:setVisible(true)
    -- 主标题
    local title      = image_from:getChildByName("Text_title")
    title:setString(data["title"])
    -- 时间
    local time       = image_from:getChildByName("Text_time")
    time:setString(data["tm_str"])
    -- 活动介绍
    local des        = image_from:getChildByName("Text_time_0")
    des:setString(data["title_des_s"])
    -- 点击主面板的详情按钮
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
            self:showInfo(data)
       end
    end
    local btnXQ      = image_from:getChildByName("Button_2")
    btnXQ:addTouchEventListener(touchCallBack)

end
-- 显示活动详细的界面
function ActManageLayer:showInfo( data )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local image_from = node:getChildByName("Image_from")
    image_from:setVisible(false)

    local Image_whole = node:getChildByName("Image_whole")
    Image_whole:setVisible(false)

    local Image_image_ac = node:getChildByName("Image_image_ac")
    Image_image_ac:setVisible(false)

    local Image_facebook = node:getChildByName("Image_facebook")
    Image_facebook:setVisible(false)

    local image_info = node:getChildByName("Image_info")
    image_info:setVisible(true)
    -- 主标题
    local title      = image_info:getChildByName("Text_title")
    title:setString(data["title"])
    -- 时间
    local time       = image_info:getChildByName("Text_time")
    time:setString(data["tm_str"])
    -- 活动介绍
    local des        = image_info:getChildByName("Text_time_0")
    des:setString(data["title_des"])
        -- 点击详细界面的返回按钮
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
            self:setPublicPor(data)
       end
    end
    local btnXQ      = image_info:getChildByName("Button_2")
    btnXQ:addTouchEventListener(touchCallBack)
end
-- 显示活动单一图片界面
function ActManageLayer:ShowOnlyImage( data )
    -- body
    print("单个tupian 活动的Id == "..data["id"])
    local node       = self.uiLayer:getChildByTag(2);
    local image_from = node:getChildByName("Image_from")
    image_from:setVisible(false)

    local image_info = node:getChildByName("Image_info")
    image_info:setVisible(false)

    local Image_image_ac = node:getChildByName("Image_image_ac")
    Image_image_ac:setVisible(false)

    local Image_facebook = node:getChildByName("Image_facebook")
    Image_facebook:setVisible(false)

    local Image_whole = node:getChildByName("Image_whole")
    Image_whole:setVisible(true)
    
    -- 主标题
    local title      = Image_whole:getChildByName("Text_title")
    title:setString(data["title"])
    -- 图片
    local iamge16       = Image_whole:getChildByName("Image_16")
    iamge16:loadTexture(data["main_pic"])

    local btn = Image_whole:getChildByName("Button_5")
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if tonumber(user_info["rank"])  >= self.UnLock_level then
                print("魔神活动 == "..data["ui_file"])
                if data["ui_file"] == "" then  
                else
                    self.actId = data["id"]
                    require_ex(data["ui_file"]) 

                end
                loadstring(data["parameter"])()
            else
                local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"), self.UnLock_level)
                SceneManager:showPromptLabel(str)
            end
        end
    end

    btn:addTouchEventListener(touchCallBack)
end
-- 显示单一的图片 跳转到facebook网页进行点赞和评分的功能
function ActManageLayer:ShowOnlyImageToFacebook( t_data )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local image_from = node:getChildByName("Image_from")
    image_from:setVisible(false)

    local image_info = node:getChildByName("Image_info")
    image_info:setVisible(false)

    local Image_whole = node:getChildByName("Image_whole")
    Image_whole:setVisible(false)

    local Image_image_ac = node:getChildByName("Image_image_ac")
    Image_image_ac:setVisible(false)

    local Image_facebook = node:getChildByName("Image_facebook")
    Image_facebook:setVisible(true)
    
    -- -- 主标题
    -- local title      = Image_facebook:getChildByName("Text_title")
    -- title:setString(t_data["title"])
    -- 图片
    local Image_16       = Image_facebook:getChildByName("Image_16")
    Image_16:loadTexture(t_data["main_pic"])
    -- 跳转按钮
    local  btn_to        = Image_facebook:getChildByName("Button_to")
    -- 领取按钮
    local  btn_get        = Image_facebook:getChildByName("Button_get")
    -- if t_data["btn_state"]  == 1 then      -- 跳转
    --     btn_to:loadTextures(t_data["btn_normal"],t_data["btn_click"],t_data["btn_click"])
    --     btn_get:setVisible(false)
    --     btn_to:setVisible(true)
    -- elseif t_data["btn_state"]  == 2 then  -- 领取
    --     btn_get:setVisible(true)
    --     btn_to:setVisible(false)
    -- elseif t_data["btn_state"]  == 3 then  -- 领取过
    --     btn_to:setVisible(false)
    --     btn_get:setTouchEnabled(false)
    --     btn_get:setBright(false)
    -- end
    self:setFaceBookBtnState(t_data["btn_state"],t_data)
    -- 记录跳转之前 和 回来之后的时间
    local time1  = 0
    local time2 = 0
    -- 跳转按钮回掉
    btn_to:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.began then
             time1  = os.time()
             cc.Application:getInstance():openURL(t_data["parameter"])
             btn_to:setTouchEnabled(false)
             btn_to:setBright(false)
            
             --[[
                   跳转网页的过程
                   1 跳转网页 游戏暂停（同时会执行下边的函数）
                   2 返回游戏 游戏恢复 (同时执行下边暂停的函数，恢复记时)
                   3 原因是因为 游戏跳转会后台运行状态 游戏回来不会执行(而是在执行后台时候进行，的调用后，暂停)

                   这样做，返回设置状态会有延时(为了避免c++代码处理 进行冷更)

             ]]
            local function TimeFunc( ... )
                btn_to:setTouchEnabled(true)
                btn_to:setBright(true)
                time2  = os.time()
                if time2 - time1 >= t_data["btn_time"] then
                    -- btn_get:setVisible(true)
                    -- btn_to:setVisible(false)
                    self:sendFacebookState(t_data)
                end 
            end  
            local delay    = CCDelayTime:create(0.00001)
            local callfunc = CCCallFunc:create(TimeFunc)
            local sequence = cc.Sequence:create(delay, callfunc)
            btn_to:runAction(sequence)
        end
    end)
    -- 领取奖励
    btn_get:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.began then            
            self:sendFacebookGetaward(t_data)
        end
    end)
end
-- 禁用领取按钮
function ActManageLayer:getBrightBtn( ... )
    -- body
    local node           = self.uiLayer:getChildByTag(2);
    local Image_facebook = node:getChildByName("Image_facebook")
    -- 跳转按钮
    local  btn_to        = Image_facebook:getChildByName("Button_to")
    -- 领取按钮
    local  btn_get        = Image_facebook:getChildByName("Button_get")
    btn_to:setVisible(false)
    btn_get:setTouchEnabled(false)
    btn_get:setBright(false)
end
--设置facebook跳转按钮状态
function ActManageLayer:setFaceBookBtnState(btnState,adata)
    -- body
    local node            = self.uiLayer:getChildByTag(2);
    local Image_facebook  = node:getChildByName("Image_facebook")

    local  btn_to         = Image_facebook:getChildByName("Button_to")
    local  btn_get        = Image_facebook:getChildByName("Button_get")
    print("btnState  btnState  btnState == "..btnState)
    if btnState  == 1 then      -- 跳转
        btn_to:loadTextures(adata["btn_normal"],adata["btn_click"],adata["btn_click"])
        btn_get:setVisible(false)
        btn_to:setVisible(true)
    elseif btnState  == 2 then  -- 领取
        btn_get:setVisible(true)
        btn_get:setBright(true)
        btn_get:setTouchEnabled(true)
        btn_to:setVisible(false)
    elseif btnState  == 3 then  -- 领取过
        btn_get:setVisible(true)
        btn_to:setVisible(false)
        btn_get:setTouchEnabled(false)
        btn_get:setBright(false)
    end
end
-- 同步服务器获取状态
function ActManageLayer:sendFacebookState( ddata )
    -- body
    local function reiceSthCallBack(data)
        
        print("sendFacebookState")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.ToLocalization(t_data["data"]["warning"]))
            return
        end
        if  t_data["data"]["btn_state"] then
            self:setFaceBookBtnState(t_data["data"]["btn_state"],ddata)
        end

    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "act_facebook_state",
        ["act_id"]    = ddata["id"],
    }
    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 获取facebook  点赞评论的奖励
function ActManageLayer:sendFacebookGetaward(ddata )
    local function reiceSthCallBack(data)
        
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.ToLocalization(t_data["data"]["warning"]))
            return
        end
        local sData = {}
        sData["naem"] = UITool.ToLocalization("获取成功")
        sData["AllData"] = t_data["data"]["reward"]
        self.sManager:toMailGetAllLayer(sData)
        if t_data["data"]["btn_state"]  == 1 then
            self:setFaceBookBtnState(t_data["data"]["btn_state"],ddata)
        else
            self:getBrightBtn()
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_facebook_get",
        ["act_id"]    = ddata["id"],
        ["is_pop"]    = 0
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 显示带图片的成就
function ActManageLayer:ShowOnlyAch( data )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local image_from = node:getChildByName("Image_from")
    image_from:setVisible(false)

    local image_info = node:getChildByName("Image_info")
    image_info:setVisible(false)

    local Image_whole = node:getChildByName("Image_whole")
    Image_whole:setVisible(false)

    local Image_facebook = node:getChildByName("Image_facebook")
    Image_facebook:setVisible(false)

    local Image_image_ac = node:getChildByName("Image_image_ac")
    Image_image_ac:setVisible(true)
    
    -- 主标题
    local title      = Image_image_ac:getChildByName("Text_title")
    title:setString(data["title"])
    -- 图片
    local Image_4       = Image_image_ac:getChildByName("Image_4")
    Image_4:loadTexture(data["main_pic"])
end
--初始化pane_list 需在右边绘制完之后点击调用
function ActManageLayer:initPaneList( ... )
    -- body
    if self.gridview1 == nil then
        local node       = self.uiLayer:getChildByTag(2);
        local image_from = node:getChildByName("Image_from")
        self.panelList1 = image_from:getChildByName("Panel_list")
        local psize = self.panelList1:getContentSize()
        self.gridview1 = XUIGridView.new():initWithNodeAndSize( self.panelList1 , psize.width, psize.height,986,136)
        self.gridview1.itemCreateEvent = function()
            local temp = ActManageNode.new():init()
            self.PorpertyTable = {}
            self.PorpertyTable["OnSelf"] = self;
            temp:setData(self.PorpertyTable);
            self.tempNode1 = temp;
            local function touchCallBack( sender,eventType )
                -- body
                if eventType == ccui.TouchEventType.ended then
                    local p1 = sender:getTouchBeganPosition()
                    local p2 = sender:getTouchEndPosition()

                    local l = cc.pGetDistance(p1,p2)
                    
                    if l < 30 then
                        --print("curId == "..temp.curId)
                        --self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                        print("rrrrrrrrrrrrrrrrrrr");
                    end
                end
            end 
            return temp
        end
    end
    self:PassOnNode()
end
--initPaneList1 需在右边绘制完之后点击调用  
-- 这个和initPaneList显示活动里边的条目是一样的模板  这类只是加了上边的图片和pane_list的大小
function ActManageLayer:initPaneList1( ... )
    -- body
    if self.gridview2 == nil then
        local node       = self.uiLayer:getChildByTag(2);
        local image_from = node:getChildByName("Image_image_ac")
        self.panelList2 = image_from:getChildByName("Panel_list")
        local psize = self.panelList2:getContentSize()
        self.gridview2 = XUIGridView.new():initWithNodeAndSize( self.panelList2 , psize.width, psize.height,986,136)
        self.gridview2.itemCreateEvent = function()
            local temp = ActManageNode.new():init()
            self.PorpertyTable = {}
            self.PorpertyTable["OnSelf"] = self;
            temp:setData(self.PorpertyTable);
            self.tempNode2 = temp;
            local function touchCallBack( sender,eventType )
                -- body
                if eventType == ccui.TouchEventType.ended then
                    local p1 = sender:getTouchBeganPosition()
                    local p2 = sender:getTouchEndPosition()

                    local l = cc.pGetDistance(p1,p2)
                    
                    if l < 30 then
                        --print("curId == "..temp.curId)
                        --self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                        print("rrrrrrrrrrrrrrrrrrr");
                    end
                end
            end 
            return temp
        end
    end
    self:PassOnNode1()
end
-- 初始化右边的活动按钮列表
function ActManageLayer:initPaneListRight( )

    if self.gridview == nil then
        if not self.uiLayer then
            self.uiLayer = cc.Layer:create()
        end
        local node       = self.uiLayer:getChildByTag(2)
        --local image_from = node:getChildByName("image_from")
        self.panelList = node:getChildByName("Panel_right")
        local psize = self.panelList:getContentSize()
        self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,164,100)
        self.gridview.itemCreateEvent = function()
            local temp = ActManageItemNode.new():init()
            self.PorpertyTable = {}
            self.PorpertyTable["OnSelf"] = self;
            temp:setData(self.PorpertyTable);
            self.tempNode = temp;
            local function touchCallBack( sender,eventType )
                -- body
                if eventType == ccui.TouchEventType.ended then
                    local p1 = sender:getTouchBeganPosition()
                    local p2 = sender:getTouchEndPosition()

                    local l = cc.pGetDistance(p1,p2)
                    
                    if l < 30 then
                        --print("curId == "..temp.curId)
                        --self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                        print("rrrrrrrrrrrrrrrrrrr");
                    end
                end
            end 
            return temp
        end
    end
    self:PassOnRightNode()
end
--将数据传送到Node
function ActManageLayer:PassOnNode()

    self.gridview1:setDataSource(self.ActListTable)
end
--将数据传送到Node
function ActManageLayer:PassOnNode1()
    -- body
    self.gridview2:setDataSource(self.ActListTable)
end
--将右边数据传送到Node
function ActManageLayer:PassOnRightNode()

    self.gridview:setDataSource(self.ActTablePublic)
end
-- 链接服务器获取数据
function ActManageLayer:sendData(isTrue)
    -- body
    local function reiceSthCallBack(data)
        
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.ActTablePublic = t_data["data"]["act_list"]
        
        -- 初始化右边按钮
        if isTrue then 
            local per = self.gridview:getCurrentPercent()
            self.gridview:setDataSource(self.ActTablePublic)
            self.gridview:jumpToPercent(per)
        else
            self:initPaneListRight()
        end 
        
        

    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_center_list",
        ["is_old_bee"] = self.rData["rcvData"]["is_old_bee"]
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--界面跳转返回刷新数据
function ActManageLayer:backRefresh()
    -- body
    self:sendDataOnly(self.curActId, self.callType)
end
-- 链接服务器获取不同活动的数据
function ActManageLayer:sendDataOnly( actId ,callType)
    -- body
    self.curActId = actId
    self.callType = callType
    local function reiceSthCallBack(data)
        
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.ActListTable = t_data["data"]["list"]
        -- dump(self.ActListTable, "self.ActListTable")
        --GameManagerInst:saveToFile("act_achieve_list.json",t_data)

        self.ActListTable["actId"] = actId
        if callType == "onlyImageAc" then
            self:initPaneList1()
        else      
            self:initPaneList()
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_achieve_list",
        ["act_id"]    = actId
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 链接服务器获取活动奖励
function ActManageLayer:sendGet( actAchiId,Allitem )
    -- body
    print("actIdactId == "..self.curActId)
    local function reiceSthCallBack(data)
        
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        local sData = {}
        sData["naem"] = UITool.ToLocalization("获取成功")
        sData["AllData"] = Allitem
        if self.sManager ~= nil then
            self.sManager:toMailGetAllLayer(sData)
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]         = "act_achieve_get",
        ["act_id"]      = self.curActId,
        ["act_achi_id"] = actAchiId
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function ActManageLayer:returnBack(  )
    -- -- body
    self.sManager:removeFromNavNodes(self)
    -- self.sData = {}
    if self.backFunc then 
        self.backFunc(self.sManager,self.rData["rcvData"])
    end 
    self.exist = false
    self.sData = {}
    self.rData = {}
    self.gridview  = nil
    self.gridview1 = nil
    self.gridview2 = nil
    self:clearEx()
    --将sceneManager的引用置空
    if self.sManager and self.sManager.sActManage then
        self.sManager.sActManage = nil
    end
    


end

function ActManageLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()


end

function ActManageLayer:create(rData)

     local login = ActManageLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login   
end