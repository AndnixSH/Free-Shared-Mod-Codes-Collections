hero = {}

hero[11] = {
    hero_name = "100001",
    hero_des = "100088",
    hero_des_all = "100175",
    hero_rank = 3,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_011.png",
    hero_lb_icon = "icons/role/chouka/clb_r_011.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_011.png",
    hero_bat_icon = "icons/role/fight/zd2_011.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_011.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_011.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_011.png",
    hero_xq_icon = "icons/role/xq/xq_r_011.png",
    hero_team_icon = "icons/role/team/bd_r_011.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_011.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_011.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Wulajimilu/Wulajimilu/Wulajimilu.atlas",
    hero_cv = "100404", --cv
    hero_author = "100317",  --画师
    hero_atk1 = 4,
    hero_atk2 = 5,
    position_name = "100491",
    position_desc = "100578",
    power_name = 15,
    power_str = "100284",
    get_method = "100665",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero11bs.wav","music/roleaudio/rs2-j-011.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-011.mp3","voice/jp/hero/hero_011.mp3","music/roleaudio/rb-j-011.mp3","music/roleaudio/rw-j-011.mp3","music/roleaudio/rl-j-011.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[13] = {
    hero_name = "100002",
    hero_des = "100089",
    hero_des_all = "100176",
    hero_rank = 3,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_013.png",
    hero_lb_icon = "icons/role/chouka/clb_r_013.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_013.png",
    hero_bat_icon = "icons/role/fight/zd2_013.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_013.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_013.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_013.png",
    hero_xq_icon = "icons/role/xq/xq_r_013.png",
    hero_team_icon = "icons/role/team/bd_r_013.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_013.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_013.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Nanzhu/Nanzhu/Nanzhu.atlas",
    hero_cv = "100405", --cv
    hero_author = "100318",  --画师
    hero_atk1 = 339,
    hero_atk2 = 5,
    position_name = "100492",
    position_desc = "100579",
    power_name = 15,
    power_str = "100284",
    get_method = "100666",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero13bs.wav","music/roleaudio/rs2-j-013.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-013.mp3","voice/jp/hero/hero_013.mp3","music/roleaudio/rb-j-013.mp3","music/roleaudio/rw-j-013.mp3","music/roleaudio/rl-j-013.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[23] = {
    hero_name = "100003",
    hero_des = "100090",
    hero_des_all = "100177",
    hero_rank = 4,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_023.png",
    hero_lb_icon = "icons/role/chouka/clb_r_023.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_023.png",
    hero_bat_icon = "icons/role/fight/zd2_023.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_023.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_023.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_023.png",
    hero_xq_icon = "icons/role/xq/xq_r_023.png",
    hero_team_icon = "icons/role/team/bd_r_023.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_023.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_023.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Sailasi/Sailasi/Sailasi.atlas",
    hero_cv = "100406", --cv
    hero_author = "100319",  --画师
    hero_atk1 = 363,
    hero_atk2 = 3,
    position_name = "100493",
    position_desc = "100580",
    power_name = 5,
    power_str = "100274",
    get_method = "100667",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero23bs.wav","music/roleaudio/rs2-j-023.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-023.mp3","voice/jp/hero/hero_023.mp3","music/roleaudio/rb-j-023.mp3","music/roleaudio/rw-j-023.mp3","music/roleaudio/rl-j-023.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[36] = {
    hero_name = "100005",
    hero_des = "100092",
    hero_des_all = "100179",
    hero_rank = 4,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_036.png",
    hero_lb_icon = "icons/role/chouka/clb_r_036.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_036.png",
    hero_bat_icon = "icons/role/fight/zd2_036.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_036.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_036.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_036.png",
    hero_xq_icon = "icons/role/xq/xq_r_036.png",
    hero_team_icon = "icons/role/team/bd_r_036.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_036.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_036.atlas",
    hero_shoot = { 130,130 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Niefeilu/Niefeilu/Niefeilu.atlas",
    hero_cv = "100408", --cv
    hero_author = "100321",  --画师
    hero_atk1 = 349,
    hero_atk2 = 0,
    position_name = "100495",
    position_desc = "100582",
    power_name = 1,
    power_str = "100270",
    get_method = "100669",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero36bs.wav","music/roleaudio/rs2-j-036.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-036.mp3","voice/jp/hero/hero_036.mp3","music/roleaudio/rb-j-036.mp3","music/roleaudio/rw-j-036.mp3","music/roleaudio/rl-j-036.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[37] = {
    hero_name = "100006",
    hero_des = "100093",
    hero_des_all = "100180",
    hero_rank = 3,
    hero_race = 2,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_037.png",
    hero_lb_icon = "icons/role/chouka/clb_r_037.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_037.png",
    hero_bat_icon = "icons/role/fight/zd2_037.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_037.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_037.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_037.png",
    hero_xq_icon = "icons/role/xq/xq_r_037.png",
    hero_team_icon = "icons/role/team/bd_r_037.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_037.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_037.atlas",
    hero_shoot = { 150,150 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Maou/Maou/Maou.atlas",
    hero_cv = "100409", --cv
    hero_author = "100322",  --画师
    hero_atk1 = 345,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 8,
    power_str = "100277",
    get_method = "100670",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero37bs.wav","music/roleaudio/rs2-j-037.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-037.mp3","voice/jp/hero/hero_037.mp3","music/roleaudio/rb-j-037.mp3","music/roleaudio/rw-j-037.mp3","music/roleaudio/rl-j-037.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[51] = {
    hero_name = "100007",
    hero_des = "100094",
    hero_des_all = "100181",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_051.png",
    hero_lb_icon = "icons/role/chouka/clb_r_051.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_051.png",
    hero_bat_icon = "icons/role/fight/zd2_051.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_051.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_051.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_051.png",
    hero_xq_icon = "icons/role/xq/xq_r_051.png",
    hero_team_icon = "icons/role/team/bd_r_051.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_051.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_051.atlas",
    hero_shoot = { 160,150 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xiluo/Xiluo/Xiluo.atlas",
    hero_cv = "100410", --cv
    hero_author = "100323",  --画师
    hero_atk1 = 351,
    hero_atk2 = 0,
    position_name = "100497",
    position_desc = "100584",
    power_name = 7,
    power_str = "100276",
    get_method = "100671",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero51bs.wav","music/roleaudio/rs2-j-051.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-051.mp3","voice/jp/hero/hero_051.mp3","music/roleaudio/rb-j-051.mp3","music/roleaudio/rw-j-051.mp3","music/roleaudio/rl-j-051.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[61] = {
    hero_name = "100008",
    hero_des = "100095",
    hero_des_all = "100182",
    hero_rank = 4,
    hero_race = 4,
    hero_atb = 2,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_061.png",
    hero_lb_icon = "icons/role/chouka/clb_r_061.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_061.png",
    hero_bat_icon = "icons/role/fight/zd2_061.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_061.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_061.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_061.png",
    hero_xq_icon = "icons/role/xq/xq_r_061.png",
    hero_team_icon = "icons/role/team/bd_r_061.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_061.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_061.atlas",
    hero_shoot = { 260,135 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Meiya2/Meiya2/Meiya2.atlas",
    hero_cv = "100411", --cv
    hero_author = "100324",  --画师
    hero_atk1 = 346,
    hero_atk2 = 103,
    position_name = "100498",
    position_desc = "100585",
    power_name = 10,
    power_str = "100279",
    get_method = "100672",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero61bs.wav","music/roleaudio/rs2-j-061.mp3","","","music/roleaudio/rs1-j-061.mp3","voice/jp/hero/hero_061.mp3","music/roleaudio/rb-j-061.mp3","music/roleaudio/rw-j-061.mp3","music/roleaudio/rl-j-061.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[62] = {
    hero_name = "100009",
    hero_des = "100096",
    hero_des_all = "100183",
    hero_rank = 3,
    hero_race = 2,
    hero_atb = 1,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_062.png",
    hero_lb_icon = "icons/role/chouka/clb_r_062.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_062.png",
    hero_bat_icon = "icons/role/fight/zd2_062.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_062.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_062.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_062.png",
    hero_xq_icon = "icons/role/xq/xq_r_062.png",
    hero_team_icon = "icons/role/team/bd_r_062.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_062.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_062.atlas",
    hero_shoot = { 120,139 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Lifa/Lifa/Lifa.atlas",
    hero_cv = "100412", --cv
    hero_author = "100325",  --画师
    hero_atk1 = 354,
    hero_atk2 = 103,
    position_name = "100499",
    position_desc = "100586",
    power_name = 8,
    power_str = "100277",
    get_method = "100673",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero62bs.wav","music/roleaudio/rs2-j-062.mp3","","","music/roleaudio/rs1-j-062.mp3","voice/jp/hero/hero_062.mp3","music/roleaudio/rb-j-062.mp3","music/roleaudio/rw-j-062.mp3","music/roleaudio/rl-j-062.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[76] = {
    hero_name = "100010",
    hero_des = "100097",
    hero_des_all = "100184",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_076.png",
    hero_lb_icon = "icons/role/chouka/clb_r_076.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_076.png",
    hero_bat_icon = "icons/role/fight/zd2_076.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_076.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_076.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_076.png",
    hero_xq_icon = "icons/role/xq/xq_r_076.png",
    hero_team_icon = "icons/role/team/bd_r_076.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_076.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_076.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Shaxia/Shaxia/Shaxia.atlas",
    hero_cv = "100413", --cv
    hero_author = "100326",  --画师
    hero_atk1 = 369,
    hero_atk2 = 3,
    position_name = "100500",
    position_desc = "100587",
    power_name = 1,
    power_str = "100270",
    get_method = "100674",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero76bs.wav","music/roleaudio/rs2-j-076.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-076.mp3","voice/jp/hero/hero_076.mp3","music/roleaudio/rb-j-076.mp3","music/roleaudio/rw-j-076.mp3","music/roleaudio/rl-j-076.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[101] = {
    hero_name = "100011",
    hero_des = "100098",
    hero_des_all = "100185",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_101.png",
    hero_lb_icon = "icons/role/chouka/clb_r_101.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_101.png",
    hero_bat_icon = "icons/role/fight/zd2_101.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_101.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_101.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_101.png",
    hero_xq_icon = "icons/role/xq/xq_r_101.png",
    hero_team_icon = "icons/role/team/bd_r_101.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_101.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_101.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Kulaxia/Kulaxia/Kulaxia.atlas",
    hero_cv = "100414", --cv
    hero_author = "100327",  --画师
    hero_atk1 = 367,
    hero_atk2 = 0,
    position_name = "100501",
    position_desc = "100588",
    power_name = 15,
    power_str = "100284",
    get_method = "100675",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero101bs.wav","music/roleaudio/rs2-j-101.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-101.mp3","voice/jp/hero/hero_101.mp3","music/roleaudio/rb-j-101.mp3","music/roleaudio/rw-j-101.mp3","music/roleaudio/rl-j-101.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[103] = {
    hero_name = "100012",
    hero_des = "100099",
    hero_des_all = "100186",
    hero_rank = 4,
    hero_race = 6,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_103.png",
    hero_lb_icon = "icons/role/chouka/clb_r_103.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_103.png",
    hero_bat_icon = "icons/role/fight/zd2_103.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_103.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_103.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_103.png",
    hero_xq_icon = "icons/role/xq/xq_r_103.png",
    hero_team_icon = "icons/role/team/bd_r_103.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_103.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_103.atlas",
    hero_shoot = { 93,134 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Awenna/Awenna/Awenna.atlas",
    hero_cv = "100415", --cv
    hero_author = "100328",  --画师
    hero_atk1 = 356,
    hero_atk2 = 0,
    position_name = "100502",
    position_desc = "100589",
    power_name = 8,
    power_str = "100277",
    get_method = "100676",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero103bs.wav","music/roleaudio/rs2-j-103.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-103.mp3","voice/jp/hero/hero_103.mp3","music/roleaudio/rb-j-103.mp3","music/roleaudio/rw-j-103.mp3","music/roleaudio/rl-j-103.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[116] = {
    hero_name = "100013",
    hero_des = "100100",
    hero_des_all = "100187",
    hero_rank = 3,
    hero_race = 6,
    hero_atb = 3,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_116.png",
    hero_lb_icon = "icons/role/chouka/clb_r_116.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_116.png",
    hero_bat_icon = "icons/role/fight/zd2_116.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_116.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_116.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_116.png",
    hero_xq_icon = "icons/role/xq/xq_r_116.png",
    hero_team_icon = "icons/role/team/bd_r_116.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_116.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_116.atlas",
    hero_shoot = { 110,150 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Weila/Weila/Weila.atlas",
    hero_cv = "100416", --cv
    hero_author = "100329",  --画师
    hero_atk1 = 350,
    hero_atk2 = 0,
    position_name = "100503",
    position_desc = "100590",
    power_name = 7,
    power_str = "100276",
    get_method = "100677",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero116bs.wav","music/roleaudio/rs2-j-116.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-116.mp3","voice/jp/hero/hero_116.mp3","music/roleaudio/rb-j-116.mp3","music/roleaudio/rw-j-116.mp3","music/roleaudio/rl-j-116.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[117] = {
    hero_name = "100014",
    hero_des = "100101",
    hero_des_all = "100188",
    hero_rank = 4,
    hero_race = 2,
    hero_atb = 3,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_117.png",
    hero_lb_icon = "icons/role/chouka/clb_r_117.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_117.png",
    hero_bat_icon = "icons/role/fight/zd2_117.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_117.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_117.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_117.png",
    hero_xq_icon = "icons/role/xq/xq_r_117.png",
    hero_team_icon = "icons/role/team/bd_r_117.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_117.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_117.atlas",
    hero_shoot = { 155,139 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Ailuwei/Ailuwei/Ailuwei.atlas",
    hero_cv = "100417", --cv
    hero_author = "100330",  --画师
    hero_atk1 = 355,
    hero_atk2 = 9,
    position_name = "100504",
    position_desc = "100591",
    power_name = 8,
    power_str = "100277",
    get_method = "100678",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero117bs.wav","music/roleaudio/rs2-j-117.mp3","music/heropugong/Ngong.mp3","","music/roleaudio/rs1-j-117.mp3","voice/jp/hero/hero_117.mp3","music/roleaudio/rb-j-117.mp3","music/roleaudio/rw-j-117.mp3","music/roleaudio/rl-j-117.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[142] = {
    hero_name = "100015",
    hero_des = "100102",
    hero_des_all = "100189",
    hero_rank = 3,
    hero_race = 6,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_142.png",
    hero_lb_icon = "icons/role/chouka/clb_r_142.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_142.png",
    hero_bat_icon = "icons/role/fight/zd2_142.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_142.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_142.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_142.png",
    hero_xq_icon = "icons/role/xq/xq_r_142.png",
    hero_team_icon = "icons/role/team/bd_r_142.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_142.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_142.atlas",
    hero_shoot = { 120,145 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Aikamu/Aikamu/Aikamu.atlas",
    hero_cv = "100418", --cv
    hero_author = "100331",  --画师
    hero_atk1 = 361,
    hero_atk2 = 0,
    position_name = "100505",
    position_desc = "100592",
    power_name = 1,
    power_str = "100270",
    get_method = "100679",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero142bs.wav","music/roleaudio/rs2-j-142.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-142.mp3","voice/jp/hero/hero_142.mp3","music/roleaudio/rb-j-142.mp3","music/roleaudio/rw-j-142.mp3","music/roleaudio/rl-j-142.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 5,
            },     
            {
                mat_id = "mat_17",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            {
                mat_id = "mat_18",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            {
                mat_id = "mat_19",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[156] = {
    hero_name = "100016",
    hero_des = "100103",
    hero_des_all = "100190",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_156.png",
    hero_lb_icon = "icons/role/chouka/clb_r_156.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_156.png",
    hero_bat_icon = "icons/role/fight/zd2_156.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_156.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_156.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_156.png",
    hero_xq_icon = "icons/role/xq/xq_r_156.png",
    hero_team_icon = "icons/role/team/bd_r_156.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_156.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_156.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Milafusi/Milafusi/Milafusi.atlas",
    hero_cv = "100419", --cv
    hero_author = "100332",  --画师
    hero_atk1 = 333,
    hero_atk2 = 0,
    position_name = "100506",
    position_desc = "100593",
    power_name = 15,
    power_str = "100284",
    get_method = "100680",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero156bs.wav","music/roleaudio/rs2-j-156.mp3","music/heropugong/hero156pg.mp3","","music/roleaudio/rs1-j-156.mp3","voice/jp/hero/hero_156.mp3","music/roleaudio/rb-j-156.mp3","music/roleaudio/rw-j-156.mp3","music/roleaudio/rl-j-156.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[157] = {
    hero_name = "100017",
    hero_des = "100104",
    hero_des_all = "100191",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_157.png",
    hero_lb_icon = "icons/role/chouka/clb_r_157.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_157.png",
    hero_bat_icon = "icons/role/fight/zd2_157.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_157.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_157.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_157.png",
    hero_xq_icon = "icons/role/xq/xq_r_157.png",
    hero_team_icon = "icons/role/team/bd_r_157.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_157.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_157.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Silaxia/Silaxia/Silaxia.atlas",
    hero_cv = "100420", --cv
    hero_author = "100333",  --画师
    hero_atk1 = 373,
    hero_atk2 = 3,
    position_name = "100507",
    position_desc = "100594",
    power_name = 15,
    power_str = "100284",
    get_method = "100681",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero157bs.wav","music/roleaudio/rs2-j-157.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-157.mp3","voice/jp/hero/hero_157.mp3","music/roleaudio/rb-j-157.mp3","music/roleaudio/rw-j-157.mp3","music/roleaudio/rl-j-157.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[181] = {
    hero_name = "100018",
    hero_des = "100105",
    hero_des_all = "100192",
    hero_rank = 4,
    hero_race = 2,
    hero_atb = 5,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_181.png",
    hero_lb_icon = "icons/role/chouka/clb_r_181.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_181.png",
    hero_bat_icon = "icons/role/fight/zd2_181.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_181.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_181.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_181.png",
    hero_xq_icon = "icons/role/xq/xq_r_181.png",
    hero_team_icon = "icons/role/team/bd_r_181.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_181.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_181.atlas",
    hero_shoot = { 250,145 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Daqisi/Daqisi/Daqisi.atlas",
    hero_cv = "100421", --cv
    hero_author = "100334",  --画师
    hero_atk1 = 344,
    hero_atk2 = 9,
    position_name = "100508",
    position_desc = "100595",
    power_name = 15,
    power_str = "100284",
    get_method = "100682",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero181bs.wav","music/roleaudio/rs2-j-181.mp3","","","music/roleaudio/rs1-j-181.mp3","voice/jp/hero/hero_181.mp3","music/roleaudio/rb-j-181.mp3","music/roleaudio/rw-j-181.mp3","music/roleaudio/rl-j-181.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 5,
            },     
            {
                mat_id = "mat_22",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            {
                mat_id = "mat_23",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            {
                mat_id = "mat_24",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[182] = {
    hero_name = "100019",
    hero_des = "100106",
    hero_des_all = "100193",
    hero_rank = 3,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_182.png",
    hero_lb_icon = "icons/role/chouka/clb_r_182.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_182.png",
    hero_bat_icon = "icons/role/fight/zd2_182.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_182.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_182.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_182.png",
    hero_xq_icon = "icons/role/xq/xq_r_182.png",
    hero_team_icon = "icons/role/team/bd_r_182.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_182.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_182.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Pililien/Pililien/Pililien.atlas",
    hero_cv = "100422", --cv
    hero_author = "100335",  --画师
    hero_atk1 = 371,
    hero_atk2 = 3,
    position_name = "100509",
    position_desc = "100596",
    power_name = 9,
    power_str = "100278",
    get_method = "100683",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero182bs.wav","music/roleaudio/rs2-j-182.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-182.mp3","voice/jp/hero/hero_182.mp3","music/roleaudio/rb-j-182.mp3","music/roleaudio/rw-j-182.mp3","music/roleaudio/rl-j-182.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 5,
            },     
            {
                mat_id = "mat_22",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            {
                mat_id = "mat_23",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            {
                mat_id = "mat_24",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[183] = {
    hero_name = "100020",
    hero_des = "100107",
    hero_des_all = "100194",
    hero_rank = 3,
    hero_race = 6,
    hero_atb = 5,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_183.png",
    hero_lb_icon = "icons/role/chouka/clb_r_183.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_183.png",
    hero_bat_icon = "icons/role/fight/zd2_183.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_183.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_183.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_183.png",
    hero_xq_icon = "icons/role/xq/xq_r_183.png",
    hero_team_icon = "icons/role/team/bd_r_183.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_183.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_183.atlas",
    hero_shoot = { 100,120 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Laimu/Laimu/Laimu.atlas",
    hero_cv = "100423", --cv
    hero_author = "100336",  --画师
    hero_atk1 = 377,
    hero_atk2 = 3,
    position_name = "100510",
    position_desc = "100597",
    power_name = 15,
    power_str = "100284",
    get_method = "100684",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero183bs.wav","music/roleaudio/rs2-j-183.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-183.mp3","voice/jp/hero/hero_183.mp3","music/roleaudio/rb-j-183.mp3","music/roleaudio/rw-j-183.mp3","music/roleaudio/rl-j-183.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 5,
            },     
            {
                mat_id = "mat_22",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            {
                mat_id = "mat_23",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            {
                mat_id = "mat_24",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[184] = {
    hero_name = "100021",
    hero_des = "100108",
    hero_des_all = "100195",
    hero_rank = 5,
    hero_race = 3,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_184.png",
    hero_lb_icon = "icons/role/chouka/clb_r_184.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_184.png",
    hero_bat_icon = "icons/role/fight/zd2_184.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_184.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_184.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_184.png",
    hero_xq_icon = "icons/role/xq/xq_r_184.png",
    hero_team_icon = "icons/role/team/bd_r_184.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_184.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_184.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Misaier/Misaier/Misaier.atlas",
    hero_cv = "100424", --cv
    hero_author = "100337",  --画师
    hero_atk1 = 374,
    hero_atk2 = 3,
    position_name = "100511",
    position_desc = "100598",
    power_name = 6,
    power_str = "100275",
    get_method = "100685",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero184bs.wav","music/roleaudio/rs2-j-184.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-184.mp3","voice/jp/hero/hero_184.mp3","music/roleaudio/rb-j-184.mp3","music/roleaudio/rw-j-184.mp3","music/roleaudio/rl-j-184.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[196] = {
    hero_name = "100022",
    hero_des = "100109",
    hero_des_all = "100196",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_196.png",
    hero_lb_icon = "icons/role/chouka/clb_r_196.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_196.png",
    hero_bat_icon = "icons/role/fight/zd2_196.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_196.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_196.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_196.png",
    hero_xq_icon = "icons/role/xq/xq_r_196.png",
    hero_team_icon = "icons/role/team/bd_r_196.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_196.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_196.atlas",
    hero_shoot = { 160,140 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Mileini/Mileini/Mileini.atlas",
    hero_cv = "100425", --cv
    hero_author = "100338",  --画师
    hero_atk1 = 347,
    hero_atk2 = 0,
    position_name = "100512",
    position_desc = "100599",
    power_name = 7,
    power_str = "100276",
    get_method = "100686",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero196bs.wav","music/roleaudio/rs2-j-196.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-196.mp3","voice/jp/hero/hero_196.mp3","music/roleaudio/rb-j-196.mp3","music/roleaudio/rw-j-196.mp3","music/roleaudio/rl-j-196.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 5,
            },     
            {
                mat_id = "mat_22",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            {
                mat_id = "mat_23",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            {
                mat_id = "mat_24",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[305] = {
    hero_name = "100023",
    hero_des = "100110",
    hero_des_all = "100197",
    hero_rank = 4,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_305.png",
    hero_lb_icon = "icons/role/chouka/clb_r_305.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_305.png",
    hero_bat_icon = "icons/role/fight/zd2_305.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_305.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_305.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_305.png",
    hero_xq_icon = "icons/role/xq/xq_r_305.png",
    hero_team_icon = "icons/role/team/bd_r_305.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_305.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_305.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Fulami/Fulami/Fulami.atlas",
    hero_cv = "100426", --cv
    hero_author = "100339",  --画师
    hero_atk1 = 205,
    hero_atk2 = 103,
    position_name = "100513",
    position_desc = "100600",
    power_name = 15,
    power_str = "100284",
    get_method = "100687",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero305bs.wav","music/roleaudio/rs2-j-305.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-305.mp3","voice/jp/hero/hero_305.mp3","music/roleaudio/rb-j-305.mp3","music/roleaudio/rw-j-305.mp3","music/roleaudio/rl-j-305.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[353] = {
    hero_name = "100024",
    hero_des = "100111",
    hero_des_all = "100198",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "icons/role/signin/qd_r_353.png",  -- 签到头像
    role_share_img = "icons/role/fx/fx_353.png",
    hero_lb_icon = "icons/role/chouka/clb_r_353.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_353.png",
    hero_bat_icon = "icons/role/fight/zd2_353.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_353.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_353.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_353.png",
    hero_xq_icon = "icons/role/xq/xq_r_353.png",
    hero_team_icon = "icons/role/team/bd_r_353.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_353.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_353.atlas",
    hero_shoot = { 120,130 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Labisi/Labisi/Labisi.atlas",
    hero_cv = "100427", --cv
    hero_author = "100340",  --画师
    hero_atk1 = 399,
    hero_atk2 = 0,
    position_name = "100514",
    position_desc = "100601",
    power_name = 7,
    power_str = "100276",
    get_method = "100688",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero353bs.wav","music/roleaudio/rs2-j-353.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-353.mp3","voice/jp/hero/hero_353.mp3","music/roleaudio/rb-j-353.mp3","music/roleaudio/rw-j-353.mp3","music/roleaudio/rl-j-353.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[354] = {
    hero_name = "100025",
    hero_des = "100112",
    hero_des_all = "100199",
    hero_rank = 3,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_354.png",
    hero_lb_icon = "icons/role/chouka/clb_r_354.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_354.png",
    hero_bat_icon = "icons/role/fight/zd2_354.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_354.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_354.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_354.png",
    hero_xq_icon = "icons/role/xq/xq_r_354.png",
    hero_team_icon = "icons/role/team/bd_r_354.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_354.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_354.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Yabang/Yabang/Yabang.atlas",
    hero_cv = "100428", --cv
    hero_author = "100341",  --画师
    hero_atk1 = 7,
    hero_atk2 = 5,
    position_name = "100515",
    position_desc = "100602",
    power_name = 1,
    power_str = "100270",
    get_method = "100689",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero354bs.wav","music/roleaudio/rs2-j-354.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-354.mp3","voice/jp/hero/hero_354.mp3","music/roleaudio/rb-j-354.mp3","music/roleaudio/rw-j-354.mp3","music/roleaudio/rl-j-354.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[356] = {
    hero_name = "100026",
    hero_des = "100113",
    hero_des_all = "100200",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_356.png",
    hero_lb_icon = "icons/role/chouka/clb_r_356.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_356.png",
    hero_bat_icon = "icons/role/fight/zd2_356.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_356.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_356.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_356.png",
    hero_xq_icon = "icons/role/xq/xq_r_356.png",
    hero_team_icon = "icons/role/team/bd_r_356.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_356.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_356.atlas",
    hero_shoot = { 155,139 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Weilian/Weilian/Weilian.atlas",
    hero_cv = "100429", --cv
    hero_author = "100342",  --画师
    hero_atk1 = 101,
    hero_atk2 = 9,
    position_name = "100516",
    position_desc = "100603",
    power_name = 15,
    power_str = "100284",
    get_method = "100690",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero356bs.wav","music/roleaudio/rs2-j-356.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-356.mp3","voice/jp/hero/hero_356.mp3","music/roleaudio/rb-j-356.mp3","music/roleaudio/rw-j-356.mp3","music/roleaudio/rl-j-356.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[357] = {
    hero_name = "100027",
    hero_des = "100114",
    hero_des_all = "100201",
    hero_rank = 4,
    hero_race = 4,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_357.png",
    hero_lb_icon = "icons/role/chouka/clb_r_357.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_357.png",
    hero_bat_icon = "icons/role/fight/zd2_357.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_357.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_357.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_357.png",
    hero_xq_icon = "icons/role/xq/xq_r_357.png",
    hero_team_icon = "icons/role/team/bd_r_357.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_357.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_357.atlas",
    hero_shoot = { 130,110 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Nayi2v/Nayi2/Nayi2/Nayi2.atlas",
    hero_cv = "100430", --cv
    hero_author = "100343",  --画师
    hero_atk1 = 348,
    hero_atk2 = 311,
    position_name = "100517",
    position_desc = "100604",
    power_name = 10,
    power_str = "100279",
    get_method = "100691",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero357bs.wav","music/roleaudio/rs2-j-357.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-357.mp3","voice/jp/hero/hero_357.mp3","music/roleaudio/rb-j-357.mp3","music/roleaudio/rw-j-357.mp3","music/roleaudio/rl-j-357.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 5,
            },     
            {
                mat_id = "mat_22",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            {
                mat_id = "mat_23",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            {
                mat_id = "mat_24",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[359] = {
    hero_name = "100028",
    hero_des = "100115",
    hero_des_all = "100202",
    hero_rank = 3,
    hero_race = 6,
    hero_atb = 1,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_359.png",
    hero_lb_icon = "icons/role/chouka/clb_r_359.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_359.png",
    hero_bat_icon = "icons/role/fight/zd2_359.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_359.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_359.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_359.png",
    hero_xq_icon = "icons/role/xq/xq_r_359.png",
    hero_team_icon = "icons/role/team/bd_r_359.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_359.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_359.atlas",
    hero_shoot = { 120,134 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Ailu/Ailu/Ailu.atlas",
    hero_cv = "100431", --cv
    hero_author = "100344",  --画师
    hero_atk1 = 358,
    hero_atk2 = 0,
    position_name = "100518",
    position_desc = "100605",
    power_name = 8,
    power_str = "100277",
    get_method = "100692",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero359bs.wav","music/roleaudio/rs2-j-359.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-359.mp3","voice/jp/hero/hero_359.mp3","music/roleaudio/rb-j-359.mp3","music/roleaudio/rw-j-359.mp3","music/roleaudio/rl-j-359.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[360] = {
    hero_name = "100029",
    hero_des = "100116",
    hero_des_all = "100203",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_360.png",
    hero_lb_icon = "icons/role/chouka/clb_r_360.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_360.png",
    hero_bat_icon = "icons/role/fight/zd2_360.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_360.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_360.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_360.png",
    hero_xq_icon = "icons/role/xq/xq_r_360.png",
    hero_team_icon = "icons/role/team/bd_r_360.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_360.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_360.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Fanghui/Fanghui/Fanghui.atlas",
    hero_cv = "100432", --cv
    hero_author = "100345",  --画师
    hero_atk1 = 370,
    hero_atk2 = 3,
    position_name = "100519",
    position_desc = "100606",
    power_name = 15,
    power_str = "100284",
    get_method = "100693",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero360bs.wav","music/roleaudio/rs2-j-360.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-360.mp3","voice/jp/hero/hero_360.mp3","music/roleaudio/rb-j-360.mp3","music/roleaudio/rw-j-360.mp3","music/roleaudio/rl-j-360.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[361] = {
    hero_name = "100030",
    hero_des = "100117",
    hero_des_all = "100204",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_361.png",
    hero_lb_icon = "icons/role/chouka/clb_r_361.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_361.png",
    hero_bat_icon = "icons/role/fight/zd2_361.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_361.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_361.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_361.png",
    hero_xq_icon = "icons/role/xq/xq_r_361.png",
    hero_team_icon = "icons/role/team/bd_r_361.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_361.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_361.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Bolier/Bolier/Bolier.atlas",
    hero_cv = "100433", --cv
    hero_author = "100346",  --画师
    hero_atk1 = 353,
    hero_atk2 = 0,
    position_name = "100520",
    position_desc = "100607",
    power_name = 9,
    power_str = "100278",
    get_method = "100694",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero361bs.wav","music/roleaudio/rs2-j-361.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-361.mp3","voice/jp/hero/hero_361.mp3","music/roleaudio/rb-j-361.mp3","music/roleaudio/rw-j-361.mp3","music/roleaudio/rl-j-361.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[362] = {
    hero_name = "100031",
    hero_des = "100118",
    hero_des_all = "100205",
    hero_rank = 5,
    hero_race = 4,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_362.png",
    hero_lb_icon = "icons/role/chouka/clb_r_362.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_362.png",
    hero_bat_icon = "icons/role/fight/zd2_362.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_362.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_362.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_362.png",
    hero_xq_icon = "icons/role/xq/xq_r_362.png",
    hero_team_icon = "icons/role/team/bd_r_362.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_362.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_362.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Nikelasi/Nikelasi/Nikelasi.atlas",
    hero_cv = "100434", --cv
    hero_author = "100347",  --画师
    hero_atk1 = 368,
    hero_atk2 = 0,
    position_name = "100521",
    position_desc = "100608",
    power_name = 10,
    power_str = "100279",
    get_method = "100695",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero362bs.wav","music/roleaudio/rs2-j-362.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-362.mp3","voice/jp/hero/hero_362.mp3","music/roleaudio/rb-j-362.mp3","music/roleaudio/rw-j-362.mp3","music/roleaudio/rl-j-362.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[363] = {
    hero_name = "100032",
    hero_des = "100119",
    hero_des_all = "100206",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_363.png",
    hero_lb_icon = "icons/role/chouka/clb_r_363.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_363.png",
    hero_bat_icon = "icons/role/fight/zd2_363.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_363.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_363.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_363.png",
    hero_xq_icon = "icons/role/xq/xq_r_363.png",
    hero_team_icon = "icons/role/team/bd_r_363.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_363.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_363.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Heiya/Heiya/Heiya.atlas",
    hero_cv = "100435", --cv
    hero_author = "100348",  --画师
    hero_atk1 = 366,
    hero_atk2 = 3,
    position_name = "100522",
    position_desc = "100609",
    power_name = 4,
    power_str = "100273",
    get_method = "100696",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero363bs.wav","music/roleaudio/rs2-j-363.mp3","music/heropugong/hero363pg.mp3","","music/roleaudio/rs1-j-363.mp3","voice/jp/hero/hero_363.mp3","music/roleaudio/rb-j-363.mp3","music/roleaudio/rw-j-363.mp3","music/roleaudio/rl-j-363.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 5,
            },     
            {
                mat_id = "mat_22",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            {
                mat_id = "mat_23",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            {
                mat_id = "mat_24",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[364] = {
    hero_name = "100033",
    hero_des = "100120",
    hero_des_all = "100207",
    hero_rank = 5,
    hero_race = 3,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_364.png",
    hero_lb_icon = "icons/role/chouka/clb_r_364.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_364.png",
    hero_bat_icon = "icons/role/fight/zd2_364.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_364.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_364.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_364.png",
    hero_xq_icon = "icons/role/xq/xq_r_364.png",
    hero_team_icon = "icons/role/team/bd_r_364.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_364.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_364.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Tiyamate/Tiyamate/Tiyamate.atlas",
    hero_cv = "100436", --cv
    hero_author = "100349",  --画师
    hero_atk1 = 340,
    hero_atk2 = 0,
    position_name = "100523",
    position_desc = "100610",
    power_name = 6,
    power_str = "100275",
    get_method = "100697",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero364bs.wav","music/roleaudio/rs2-j-364.mp3","music/heropugong/hero364pg.mp3","","music/roleaudio/rs1-j-364.mp3","voice/jp/hero/hero_364.mp3","music/roleaudio/rb-j-364.mp3","music/roleaudio/rw-j-364.mp3","music/roleaudio/rl-j-364.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[367] = {
    hero_name = "100035",
    hero_des = "100122",
    hero_des_all = "100209",
    hero_rank = 5,
    hero_race = 7,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_367.png",
    hero_lb_icon = "icons/role/chouka/clb_r_367.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_367.png",
    hero_bat_icon = "icons/role/fight/zd2_367.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_367.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_367.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_367.png",
    hero_xq_icon = "icons/role/xq/xq_r_367.png",
    hero_team_icon = "icons/role/team/bd_r_367.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_367.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_367.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Youxi/Youxi/Youxi.atlas",
    hero_cv = "100438", --cv
    hero_author = "100351",  --画师
    hero_atk1 = 14,
    hero_atk2 = 3,
    position_name = "100525",
    position_desc = "100612",
    power_name = 15,
    power_str = "100284",
    get_method = "100699",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero367bs.wav","music/roleaudio/rs2-j-367.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-367.mp3","voice/jp/hero/hero_367.mp3","music/roleaudio/rb-j-367.mp3","music/roleaudio/rw-j-367.mp3","music/roleaudio/rl-j-367.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[369] = {
    hero_name = "100036",
    hero_des = "100123",
    hero_des_all = "100210",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_369.png",
    hero_lb_icon = "icons/role/chouka/clb_r_369.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_369.png",
    hero_bat_icon = "icons/role/fight/zd2_369.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_369.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_369.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_369.png",
    hero_xq_icon = "icons/role/xq/xq_r_369.png",
    hero_team_icon = "icons/role/team/bd_r_369.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_369.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_369.atlas",
    hero_shoot = { 120,135 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Hongyu/Hongyu/Hongyu.atlas",
    hero_cv = "100439", --cv
    hero_author = "100352",  --画师
    hero_atk1 = 357,
    hero_atk2 = 0,
    position_name = "100526",
    position_desc = "100613",
    power_name = 1,
    power_str = "100270",
    get_method = "100700",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero369bs.wav","music/roleaudio/rs2-j-369.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-369.mp3","voice/jp/hero/hero_369.mp3","music/roleaudio/rb-j-369.mp3","music/roleaudio/rw-j-369.mp3","music/roleaudio/rl-j-369.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[370] = {
    hero_name = "100037",
    hero_des = "100124",
    hero_des_all = "100211",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_370.png",
    hero_lb_icon = "icons/role/chouka/clb_r_370.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_370.png",
    hero_bat_icon = "icons/role/fight/zd2_370.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_370.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_370.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_370.png",
    hero_xq_icon = "icons/role/xq/xq_r_370.png",
    hero_team_icon = "icons/role/team/bd_r_370.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_370.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_370.atlas",
    hero_shoot = { 134,141 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Meilutiya/Meilutiya/Meilutiya.atlas",
    hero_cv = "100440", --cv
    hero_author = "100353",  --画师
    hero_atk1 = 359,
    hero_atk2 = 0,
    position_name = "100527",
    position_desc = "100614",
    power_name = 9,
    power_str = "100278",
    get_method = "100701",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero370bs.wav","music/roleaudio/rs2-j-370.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-370.mp3","voice/jp/hero/hero_370.mp3","music/roleaudio/rb-j-370.mp3","music/roleaudio/rw-j-370.mp3","music/roleaudio/rl-j-370.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[373] = {
    hero_name = "100038",
    hero_des = "100125",
    hero_des_all = "100212",
    hero_rank = 5,
    hero_race = 7,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_373.png",
    hero_lb_icon = "icons/role/chouka/clb_r_373.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_373.png",
    hero_bat_icon = "icons/role/fight/zd2_373.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_373.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_373.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_373.png",
    hero_xq_icon = "icons/role/xq/xq_r_373.png",
    hero_team_icon = "icons/role/team/bd_r_373.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_373.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_373.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Wulian/Wulian/Wulian.atlas",
    hero_cv = "100441", --cv
    hero_author = "100354",  --画师
    hero_atk1 = 360,
    hero_atk2 = 3,
    position_name = "100528",
    position_desc = "100615",
    power_name = 15,
    power_str = "100284",
    get_method = "100702",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero373bs.wav","music/roleaudio/rs2-j-373.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-373.mp3","voice/jp/hero/hero_373.mp3","music/roleaudio/rb-j-373.mp3","music/roleaudio/rw-j-373.mp3","music/roleaudio/rl-j-373.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[374] = {
    hero_name = "100039",
    hero_des = "100126",
    hero_des_all = "100213",
    hero_rank = 3,
    hero_race = 6,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_374.png",
    hero_lb_icon = "icons/role/chouka/clb_r_374.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_374.png",
    hero_bat_icon = "icons/role/fight/zd2_374.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_374.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_374.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_374.png",
    hero_xq_icon = "icons/role/xq/xq_r_374.png",
    hero_team_icon = "icons/role/team/bd_r_374.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_374.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_374.atlas",
    hero_shoot = { 150,135 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Pan/Pan/Pan.atlas",
    hero_cv = "100442", --cv
    hero_author = "100355",  --画师
    hero_atk1 = 351,
    hero_atk2 = 0,
    position_name = "100529",
    position_desc = "100616",
    power_name = 11,
    power_str = "100280",
    get_method = "100703",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero374bs.wav","music/roleaudio/rs2-j-374.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-374.mp3","voice/jp/hero/hero_374.mp3","music/roleaudio/rb-j-374.mp3","music/roleaudio/rw-j-374.mp3","music/roleaudio/rl-j-374.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[375] = {
    hero_name = "100040",
    hero_des = "100127",
    hero_des_all = "100214",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_375.png",
    hero_lb_icon = "icons/role/chouka/clb_r_375.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_375.png",
    hero_bat_icon = "icons/role/fight/zd2_375.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_375.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_375.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_375.png",
    hero_xq_icon = "icons/role/xq/xq_r_375.png",
    hero_team_icon = "icons/role/team/bd_r_375.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_375.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_375.atlas",
    hero_shoot = { 150,161 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Haila/Haila/Haila.atlas",
    hero_cv = "100443", --cv
    hero_author = "100356",  --画师
    hero_atk1 = 351,
    hero_atk2 = 0,
    position_name = "100530",
    position_desc = "100617",
    power_name = 7,
    power_str = "100276",
    get_method = "100704",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero375bs.wav","music/roleaudio/rs2-j-375.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-375.mp3","voice/jp/hero/hero_375.mp3","music/roleaudio/rb-j-375.mp3","music/roleaudio/rw-j-375.mp3","music/roleaudio/rl-j-375.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[376] = {
    hero_name = "100041",
    hero_des = "100128",
    hero_des_all = "100215",
    hero_rank = 4,
    hero_race = 2,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_376.png",
    hero_lb_icon = "icons/role/chouka/clb_r_376.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_376.png",
    hero_bat_icon = "icons/role/fight/zd2_376.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_376.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_376.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_376.png",
    hero_xq_icon = "icons/role/xq/xq_r_376.png",
    hero_team_icon = "icons/role/team/bd_r_376.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_376.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_376.atlas",
    hero_shoot = { 105,165 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Kelisi/Kelisi/Kelisi.atlas",
    hero_cv = "100444", --cv
    hero_author = "100357",  --画师
    hero_atk1 = 364,
    hero_atk2 = 0,
    position_name = "100531",
    position_desc = "100618",
    power_name = 8,
    power_str = "100277",
    get_method = "100705",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero376bs.wav","music/roleaudio/rs2-j-376.mp3","music/heropugong/hero376pg.mp3","","music/roleaudio/rs1-j-376.mp3","voice/jp/hero/hero_376.mp3","music/roleaudio/rb-j-376.mp3","music/roleaudio/rw-j-376.mp3","music/roleaudio/rl-j-376.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[377] = {
    hero_name = "100042",
    hero_des = "100129",
    hero_des_all = "100216",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_377.png",
    hero_lb_icon = "icons/role/chouka/clb_r_377.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_377.png",
    hero_bat_icon = "icons/role/fight/zd2_377.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_377.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_377.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_377.png",
    hero_xq_icon = "icons/role/xq/xq_r_377.png",
    hero_team_icon = "icons/role/team/bd_r_377.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_377.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_377.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Kuluoyi/Kuluoyi/Kuluoyi.atlas",
    hero_cv = "100445", --cv
    hero_author = "100358",  --画师
    hero_atk1 = 400,
    hero_atk2 = 0,
    position_name = "100532",
    position_desc = "100619",
    power_name = 1,
    power_str = "100270",
    get_method = "100706",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero377bs.wav","music/roleaudio/rs2-j-377.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-377.mp3","voice/jp/hero/hero_377.mp3","music/roleaudio/rb-j-377.mp3","music/roleaudio/rw-j-377.mp3","music/roleaudio/rl-j-377.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[378] = {
    hero_name = "100043",
    hero_des = "100130",
    hero_des_all = "100217",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_378.png",
    hero_lb_icon = "icons/role/chouka/clb_r_378.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_378.png",
    hero_bat_icon = "icons/role/fight/zd2_378.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_378.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_378.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_378.png",
    hero_xq_icon = "icons/role/xq/xq_r_378.png",
    hero_team_icon = "icons/role/team/bd_r_378.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_378.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_378.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xinmaou/Xinmaou/Xinmaou.atlas",
    hero_cv = "100446", --cv
    hero_author = "100359",  --画师
    hero_atk1 = 383,
    hero_atk2 = 0,
    position_name = "100533",
    position_desc = "100620",
    power_name = 9,
    power_str = "100278",
    get_method = "100707",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero378bs.wav","music/roleaudio/rs2-j-378.mp3","music/heropugong/hero378pg.mp3","","music/roleaudio/rs1-j-378.mp3","voice/jp/hero/hero_378.mp3","music/roleaudio/rb-j-378.mp3","music/roleaudio/rw-j-378.mp3","music/roleaudio/rl-j-378.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[379] = {
    hero_name = "100044",
    hero_des = "100131",
    hero_des_all = "100218",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_379.png",
    hero_lb_icon = "icons/role/chouka/clb_r_379.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_379.png",
    hero_bat_icon = "icons/role/fight/zd2_379.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_379.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_379.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_379.png",
    hero_xq_icon = "icons/role/xq/xq_r_379.png",
    hero_team_icon = "icons/role/team/bd_r_379.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_379.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_379.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Jiaerkaisa/Jiaerkaisa/Jiaerkaisa.atlas",
    hero_cv = "100447", --cv
    hero_author = "100360",  --画师
    hero_atk1 = 375,
    hero_atk2 = 3,
    position_name = "100534",
    position_desc = "100621",
    power_name = 15,
    power_str = "100284",
    get_method = "100708",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero379bs.wav","music/roleaudio/rs2-j-379.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-379.mp3","voice/jp/hero/hero_379.mp3","music/roleaudio/rb-j-379.mp3","music/roleaudio/rw-j-379.mp3","music/roleaudio/rl-j-379.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[380] = {
    hero_name = "100045",
    hero_des = "100132",
    hero_des_all = "100219",
    hero_rank = 4,
    hero_race = 7,
    hero_atb = 2,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_380.png",
    hero_lb_icon = "icons/role/chouka/clb_r_380.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_380.png",
    hero_bat_icon = "icons/role/fight/zd2_380.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_380.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_380.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_380.png",
    hero_xq_icon = "icons/role/xq/xq_r_380.png",
    hero_team_icon = "icons/role/team/bd_r_380.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_380.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_380.atlas",
    hero_shoot = { 200,90 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Lianyue/Lianyue/Lianyue.atlas",
    hero_cv = "100448", --cv
    hero_author = "100361",  --画师
    hero_atk1 = 365,
    hero_atk2 = 3,
    position_name = "100535",
    position_desc = "100622",
    power_name = 15,
    power_str = "100284",
    get_method = "100709",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero380bs.wav","music/roleaudio/rs2-j-380.mp3","music/heropugong/hero380pg.mp3","","music/roleaudio/rs1-j-380.mp3","voice/jp/hero/hero_380.mp3","music/roleaudio/rb-j-380.mp3","music/roleaudio/rw-j-380.mp3","music/roleaudio/rl-j-380.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[381] = {
    hero_name = "100046",
    hero_des = "100133",
    hero_des_all = "100220",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_381.png",
    hero_lb_icon = "icons/role/chouka/clb_r_381.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_381.png",
    hero_bat_icon = "icons/role/fight/zd2_381.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_381.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_381.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_381.png",
    hero_xq_icon = "icons/role/xq/xq_r_381.png",
    hero_team_icon = "icons/role/team/bd_r_381.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_381.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_381.atlas",
    hero_shoot = { 175,5 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/mimilu/mimilu/mimilu.atlas",
    hero_cv = "100449", --cv
    hero_author = "100362",  --画师
    hero_atk1 = 376,
    hero_atk2 = 3,
    position_name = "100536",
    position_desc = "100623",
    power_name = 9,
    power_str = "100278",
    get_method = "100710",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero381bs.wav","music/roleaudio/rs2-j-381.mp3","music/heropugong/hero381pg.mp3","","music/roleaudio/rs1-j-381.mp3","voice/jp/hero/hero_381.mp3","music/roleaudio/rb-j-381.mp3","music/roleaudio/rw-j-381.mp3","music/roleaudio/rl-j-381.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[382] = {
    hero_name = "100047",
    hero_des = "100134",
    hero_des_all = "100221",
    hero_rank = 4,
    hero_race = 2,
    hero_atb = 1,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_382.png",
    hero_lb_icon = "icons/role/chouka/clb_r_382.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_382.png",
    hero_bat_icon = "icons/role/fight/zd2_382.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_382.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_382.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_382.png",
    hero_xq_icon = "icons/role/xq/xq_r_382.png",
    hero_team_icon = "icons/role/team/bd_r_382.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_382.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_382.atlas",
    hero_shoot = { 99,129 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Lijie/Lijie/Lijie.atlas",
    hero_cv = "100450", --cv
    hero_author = "100363",  --画师
    hero_atk1 = 386,
    hero_atk2 = 0,
    position_name = "100537",
    position_desc = "100624",
    power_name = 8,
    power_str = "100277",
    get_method = "100711",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero382bs.wav","music/roleaudio/rs2-j-382.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-382.mp3","voice/jp/hero/hero_382.mp3","music/roleaudio/rb-j-382.mp3","music/roleaudio/rw-j-382.mp3","music/roleaudio/rl-j-382.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[383] = {
    hero_name = "100048",
    hero_des = "100135",
    hero_des_all = "100222",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_383.png",
    hero_lb_icon = "icons/role/chouka/clb_r_383.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_383.png",
    hero_bat_icon = "icons/role/fight/zd2_383.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_383.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_383.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_383.png",
    hero_xq_icon = "icons/role/xq/xq_r_383.png",
    hero_team_icon = "icons/role/team/bd_r_383.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_383.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_383.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Huiya/Huiya/Huiya.atlas",
    hero_cv = "100451", --cv
    hero_author = "100364",  --画师
    hero_atk1 = 14,
    hero_atk2 = 0,
    position_name = "100538",
    position_desc = "100625",
    power_name = 4,
    power_str = "100273",
    get_method = "100712",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero383bs.wav","music/roleaudio/rs2-j-383.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-383.mp3","voice/jp/hero/hero_383.mp3","music/roleaudio/rb-j-383.mp3","music/roleaudio/rw-j-383.mp3","music/roleaudio/rl-j-383.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[384] = {
    hero_name = "100049",
    hero_des = "100136",
    hero_des_all = "100223",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 3,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_384.png",
    hero_lb_icon = "icons/role/chouka/clb_r_384.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_384.png",
    hero_bat_icon = "icons/role/fight/zd2_384.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_384.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_384.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_384.png",
    hero_xq_icon = "icons/role/xq/xq_r_384.png",
    hero_team_icon = "icons/role/team/bd_r_384.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_384.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_384.atlas",
    hero_shoot = { 110,142 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Zhenweila/Zhenweila/Zhenweila.atlas",
    hero_cv = "100452", --cv
    hero_author = "100365",  --画师
    hero_atk1 = 378,
    hero_atk2 = 3,
    position_name = "100539",
    position_desc = "100626",
    power_name = 7,
    power_str = "100276",
    get_method = "100713",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero384bs.wav","music/roleaudio/rs2-j-384.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-384.mp3","voice/jp/hero/hero_384.mp3","music/roleaudio/rb-j-384.mp3","music/roleaudio/rw-j-384.mp3","music/roleaudio/rl-j-384.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[385] = {
    hero_name = "100050",
    hero_des = "100137",
    hero_des_all = "100224",
    hero_rank = 5,
    hero_race = 2,
    hero_atb = 3,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_385.png",
    hero_lb_icon = "icons/role/chouka/clb_r_385.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_385.png",
    hero_bat_icon = "icons/role/fight/zd2_385.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_385.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_385.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_385.png",
    hero_xq_icon = "icons/role/xq/xq_r_385.png",
    hero_team_icon = "icons/role/team/bd_r_385.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_385.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_385.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Leiounai/Leiounai/Leiounai.atlas",
    hero_cv = "100453", --cv
    hero_author = "100366",  --画师
    hero_atk1 = 381,
    hero_atk2 = 0,
    position_name = "100540",
    position_desc = "100627",
    power_name = 1,
    power_str = "100270",
    get_method = "100714",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero385bs.wav","music/roleaudio/rs2-j-385.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-385.mp3","voice/jp/hero/hero_385.mp3","music/roleaudio/rb-j-385.mp3","music/roleaudio/rw-j-385.mp3","music/roleaudio/rl-j-385.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[386] = {
    hero_name = "100051",
    hero_des = "100138",
    hero_des_all = "100225",
    hero_rank = 3,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_386.png",
    hero_lb_icon = "icons/role/chouka/clb_r_386.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_386.png",
    hero_bat_icon = "icons/role/fight/zd2_386.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_386.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_386.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_386.png",
    hero_xq_icon = "icons/role/xq/xq_r_386.png",
    hero_team_icon = "icons/role/team/bd_r_386.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_386.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_386.atlas",
    hero_shoot = { 125,155 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/fuyin/Fuyin/Fuyin.atlas",
    hero_cv = "100454", --cv
    hero_author = "100367",  --画师
    hero_atk1 = 380,
    hero_atk2 = 0,
    position_name = "100541",
    position_desc = "100628",
    power_name = 7,
    power_str = "100276",
    get_method = "100715",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero386bs.wav","music/roleaudio/rs2-j-386.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-386.mp3","voice/jp/hero/hero_386.mp3","music/roleaudio/rb-j-386.mp3","music/roleaudio/rw-j-386.mp3","music/roleaudio/rl-j-386.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[387] = {
    hero_name = "100052",
    hero_des = "100139",
    hero_des_all = "100226",
    hero_rank = 4,
    hero_race = 5,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_387.png",
    hero_lb_icon = "icons/role/chouka/clb_r_387.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_387.png",
    hero_bat_icon = "icons/role/fight/zd2_387.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_387.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_387.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_387.png",
    hero_xq_icon = "icons/role/xq/xq_r_387.png",
    hero_team_icon = "icons/role/team/bd_r_387.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_387.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_387.atlas",
    hero_shoot = { 150,175 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Halubi/Halubi/Halubi.atlas",
    hero_cv = "100455", --cv
    hero_author = "100368",  --画师
    hero_atk1 = 379,
    hero_atk2 = 0,
    position_name = "100542",
    position_desc = "100629",
    power_name = 5,
    power_str = "100274",
    get_method = "100716",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero387bs.wav","music/roleaudio/rs2-j-387.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-387.mp3","voice/jp/hero/hero_387.mp3","music/roleaudio/rb-j-387.mp3","music/roleaudio/rw-j-387.mp3","music/roleaudio/rl-j-387.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 5,
            },     
            {
                mat_id = "mat_12",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            {
                mat_id = "mat_13",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            {
                mat_id = "mat_14",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[388] = {
    hero_name = "100053",
    hero_des = "100140",
    hero_des_all = "100227",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_388.png",
    hero_lb_icon = "icons/role/chouka/clb_r_388.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_388.png",
    hero_bat_icon = "icons/role/fight/zd2_388.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_388.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_388.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_388.png",
    hero_xq_icon = "icons/role/xq/xq_r_388.png",
    hero_team_icon = "icons/role/team/bd_r_388.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_388.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_388.atlas",
    hero_shoot = { 177,137 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Shenshina/Shenshina/Shenshina.atlas",
    hero_cv = "100456", --cv
    hero_author = "100369",  --画师
    hero_atk1 = 347,
    hero_atk2 = 0,
    position_name = "100543",
    position_desc = "100630",
    power_name = 4,
    power_str = "100273",
    get_method = "100717",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero388bs.wav","music/roleaudio/rs2-j-388.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-388.mp3","voice/jp/hero/hero_388.mp3","music/roleaudio/rb-j-388.mp3","music/roleaudio/rw-j-388.mp3","music/roleaudio/rl-j-388.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[389] = {
    hero_name = "100054",
    hero_des = "100141",
    hero_des_all = "100228",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 4,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_389.png",
    hero_lb_icon = "icons/role/chouka/clb_r_389.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_389.png",
    hero_bat_icon = "icons/role/fight/zd2_389.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_389.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_389.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_389.png",
    hero_xq_icon = "icons/role/xq/xq_r_389.png",
    hero_team_icon = "icons/role/team/bd_r_389.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_389.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_389.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Jierfude/Jierfude/Jierfude.atlas",
    hero_cv = "100457", --cv
    hero_author = "100370",  --画师
    hero_atk1 = 382,
    hero_atk2 = 0,
    position_name = "100544",
    position_desc = "100631",
    power_name = 1,
    power_str = "100270",
    get_method = "100718",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero389bs.wav","music/roleaudio/rs2-j-389.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-389.mp3","voice/jp/hero/hero_389.mp3","music/roleaudio/rb-j-389.mp3","music/roleaudio/rw-j-389.mp3","music/roleaudio/rl-j-389.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 5,
            },     
            {
                mat_id = "mat_17",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            {
                mat_id = "mat_18",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            {
                mat_id = "mat_19",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[390] = {
    hero_name = "100055",
    hero_des = "100142",
    hero_des_all = "100229",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_390.png",
    hero_lb_icon = "icons/role/chouka/clb_r_390.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_390.png",
    hero_bat_icon = "icons/role/fight/zd2_390.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_390.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_390.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_390.png",
    hero_xq_icon = "icons/role/xq/xq_r_390.png",
    hero_team_icon = "icons/role/team/bd_r_390.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_390.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_390.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Leinixiya/Leinixiya/Leinixiya.atlas",
    hero_cv = "100458", --cv
    hero_author = "100371",  --画师
    hero_atk1 = 384,
    hero_atk2 = 0,
    position_name = "100545",
    position_desc = "100632",
    power_name = 5,
    power_str = "100274",
    get_method = "100719",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero390bs.wav","music/roleaudio/rs2-j-390.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-390.mp3","voice/jp/hero/hero_390.mp3","music/roleaudio/rb-j-390.mp3","music/roleaudio/rw-j-390.mp3","music/roleaudio/rl-j-390.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[391] = {
    hero_name = "100056",
    hero_des = "100143",
    hero_des_all = "100230",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_391.png",
    hero_lb_icon = "icons/role/chouka/clb_r_391.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_391.png",
    hero_bat_icon = "icons/role/fight/zd2_391.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_391.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_391.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_391.png",
    hero_xq_icon = "icons/role/xq/xq_r_391.png",
    hero_team_icon = "icons/role/team/bd_r_391.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_391.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_391.atlas",
    hero_shoot = { 150,138 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xiaduo/Xiaduo/Xiaduo.atlas",
    hero_cv = "100459", --cv
    hero_author = "100372",  --画师
    hero_atk1 = 387,
    hero_atk2 = 0,
    position_name = "100546",
    position_desc = "100633",
    power_name = 1,
    power_str = "100270",
    get_method = "100720",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero391bs.wav","music/roleaudio/rs2-j-391.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-391.mp3","voice/jp/hero/hero_391.mp3","music/roleaudio/rb-j-391.mp3","music/roleaudio/rw-j-391.mp3","music/roleaudio/rl-j-391.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[394] = {
    hero_name = "100057",
    hero_des = "100144",
    hero_des_all = "100231",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 4,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_394.png",
    hero_lb_icon = "icons/role/chouka/clb_r_394.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_394.png",
    hero_bat_icon = "icons/role/fight/zd2_394.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_394.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_394.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_394.png",
    hero_xq_icon = "icons/role/xq/xq_r_394.png",
    hero_team_icon = "icons/role/team/bd_r_394.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_394.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_394.atlas",
    hero_shoot = { 176,146 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Anjilina/Anjilina/Anjilina.atlas",
    hero_cv = "100460", --cv
    hero_author = "100373",  --画师
    hero_atk1 = 10394,
    hero_atk2 = 0,
    position_name = "100547",
    position_desc = "100634",
    power_name = 1,
    power_str = "100270",
    get_method = "100721",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero394bs.wav","music/roleaudio/rs2-j-394.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-394.mp3","voice/jp/hero/hero_394.mp3","music/roleaudio/rb-j-394.mp3","music/roleaudio/rw-j-394.mp3","music/roleaudio/rl-j-394.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 5,
            },     
            {
                mat_id = "mat_17",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            {
                mat_id = "mat_18",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            {
                mat_id = "mat_19",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[397] = {
    hero_name = "100058",
    hero_des = "100145",
    hero_des_all = "100232",
    hero_rank = 5,
    hero_race = 7,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_397.png",
    hero_lb_icon = "icons/role/chouka/clb_r_397.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_397.png",
    hero_bat_icon = "icons/role/fight/zd2_397.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_397.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_397.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_397.png",
    hero_xq_icon = "icons/role/xq/xq_r_397.png",
    hero_team_icon = "icons/role/team/bd_r_397.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_397.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_397.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Shigui/Shigui/Shigui.atlas",
    hero_cv = "100461", --cv
    hero_author = "100374",  --画师
    hero_atk1 = 393,
    hero_atk2 = 0,
    position_name = "100548",
    position_desc = "100635",
    power_name = 5,
    power_str = "100274",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero397bs.wav","music/roleaudio/rs2-j-397.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-397.mp3","voice/jp/hero/hero_397.mp3","music/roleaudio/rb-j-397.mp3","music/roleaudio/rw-j-397.mp3","music/roleaudio/rl-j-397.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[398] = {
    hero_name = "100059",
    hero_des = "100146",
    hero_des_all = "100233",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_398.png",
    hero_lb_icon = "icons/role/chouka/clb_r_398.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_398.png",
    hero_bat_icon = "icons/role/fight/zd2_398.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_398.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_398.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_398.png",
    hero_xq_icon = "icons/role/xq/xq_r_398.png",
    hero_team_icon = "icons/role/team/bd_r_398.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_398.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_398.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Geye/Geye/Geye.atlas",
    hero_cv = "100462", --cv
    hero_author = "100375",  --画师
    hero_atk1 = 406,
    hero_atk2 = 0,
    position_name = "100549",
    position_desc = "100636",
    power_name = 5,
    power_str = "100274",
    get_method = "100723",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero398bs.wav","music/roleaudio/rs2-j-398.mp3","music/heropugong/hero398pg.mp3","","music/roleaudio/rs1-j-398.mp3","voice/jp/hero/hero_398.mp3","music/roleaudio/rb-j-398.mp3","music/roleaudio/rw-j-398.mp3","music/roleaudio/rl-j-398.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 8,
            },     
            {
                mat_id = "mat_7",
                mat_num = 8,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 30,
            },     
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            },
        }, 
        break_4 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[402] = {
    hero_name = "100060",
    hero_des = "100147",
    hero_des_all = "100234",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 3,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_402.png",
    hero_lb_icon = "icons/role/chouka/clb_r_402.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_402.png",
    hero_bat_icon = "icons/role/fight/zd2_402.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_402.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_402.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_402.png",
    hero_xq_icon = "icons/role/xq/xq_r_402.png",
    hero_team_icon = "icons/role/team/bd_r_402.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_402.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_402.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xuena/Xuena/Xuena.atlas",
    hero_cv = "100463", --cv
    hero_author = "100376",  --画师
    hero_atk1 = 402,
    hero_atk2 = 0,
    position_name = "100550",
    position_desc = "100637",
    power_name = 5,
    power_str = "100274",
    get_method = "100724",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero402bs.wav","music/roleaudio/rs2-j-402.mp3","music/heropugong/hero402pg.mp3","","music/roleaudio/rs1-j-402.mp3","voice/jp/hero/hero_402.mp3","music/roleaudio/rb-j-402.mp3","music/roleaudio/rw-j-402.mp3","music/roleaudio/rl-j-402.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 8,
            },     
            {
                mat_id = "mat_12",
                mat_num = 8,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 30,
            },     
            {
                mat_id = "mat_14",
                mat_num = 30,
            },     
            },
        }, 
        break_4 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[403] = {
    hero_name = "100061",
    hero_des = "100148",
    hero_des_all = "100235",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_403.png",
    hero_lb_icon = "icons/role/chouka/clb_r_403.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_403.png",
    hero_bat_icon = "icons/role/fight/zd2_403.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_403.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_403.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_403.png",
    hero_xq_icon = "icons/role/xq/xq_r_403.png",
    hero_team_icon = "icons/role/team/bd_r_403.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_403.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_403.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Wujiyuanxiongluo/Wujiyuanxiongluo/Wujiyuanxiongluo.atlas",
    hero_cv = "100464", --cv
    hero_author = "100377",  --画师
    hero_atk1 = 398,
    hero_atk2 = 0,
    position_name = "100551",
    position_desc = "100638",
    power_name = 5,
    power_str = "100274",
    get_method = "100725",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero403bs.wav","music/roleaudio/rs2-j-403.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-403.mp3","voice/jp/hero/hero_403.mp3","music/roleaudio/rb-j-403.mp3","music/roleaudio/rw-j-403.mp3","music/roleaudio/rl-j-403.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[404] = {
    hero_name = "100062",
    hero_des = "100149",
    hero_des_all = "100236",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_404.png",
    hero_lb_icon = "icons/role/chouka/clb_r_404.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_404.png",
    hero_bat_icon = "icons/role/fight/zd2_404.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_404.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_404.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_404.png",
    hero_xq_icon = "icons/role/xq/xq_r_404.png",
    hero_team_icon = "icons/role/team/bd_r_404.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_404.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_404.atlas",
    hero_shoot = { 112,139 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Wutejia/Wutejia/Wutejia.atlas",
    hero_cv = "100465", --cv
    hero_author = "100378",  --画师
    hero_atk1 = 391,
    hero_atk2 = 0,
    position_name = "100552",
    position_desc = "100639",
    power_name = 14,
    power_str = "100283",
    get_method = "100726",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero404bs.wav","music/roleaudio/rs2-j-404.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-404.mp3","voice/jp/hero/hero_404.mp3","music/roleaudio/rb-j-404.mp3","music/roleaudio/rw-j-404.mp3","music/roleaudio/rl-j-404.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[405] = {
    hero_name = "100063",
    hero_des = "100150",
    hero_des_all = "100237",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_405.png",
    hero_lb_icon = "icons/role/chouka/clb_r_405.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_405.png",
    hero_bat_icon = "icons/role/fight/zd2_405.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_405.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_405.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_405.png",
    hero_xq_icon = "icons/role/xq/xq_r_405.png",
    hero_team_icon = "icons/role/team/bd_r_405.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_405.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_405.atlas",
    hero_shoot = { 160,140 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Luoleilai/Luoleilai/Luoleilai.atlas",
    hero_cv = "100466", --cv
    hero_author = "100379",  --画师
    hero_atk1 = 392,
    hero_atk2 = 0,
    position_name = "100553",
    position_desc = "100640",
    power_name = 1,
    power_str = "100270",
    get_method = "100727",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero405bs.wav","music/roleaudio/rs2-j-405.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-405.mp3","voice/jp/hero/hero_405.mp3","music/roleaudio/rb-j-405.mp3","music/roleaudio/rw-j-405.mp3","music/roleaudio/rl-j-405.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[406] = {
    hero_name = "100064",
    hero_des = "100151",
    hero_des_all = "100238",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 2,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_406.png",
    hero_lb_icon = "icons/role/chouka/clb_r_406.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_406.png",
    hero_bat_icon = "icons/role/fight/zd2_406.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_406.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_406.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_406.png",
    hero_xq_icon = "icons/role/xq/xq_r_406.png",
    hero_team_icon = "icons/role/team/bd_r_406.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_406.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_406.atlas",
    hero_shoot = { 130,130 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Sala/Sala/Sala.atlas",
    hero_cv = "100467", --cv
    hero_author = "100380",  --画师
    hero_atk1 = 10406,
    hero_atk2 = 0,
    position_name = "100554",
    position_desc = "100641",
    power_name = 7,
    power_str = "100276",
    get_method = "100728",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero406bs.wav","music/roleaudio/rs2-j-406.mp3","music/heropugong/hero406pg.mp3","","music/roleaudio/rs1-j-406.mp3","voice/jp/hero/hero_406.mp3","music/roleaudio/rb-j-406.mp3","music/roleaudio/rw-j-406.mp3","music/roleaudio/rl-j-406.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[407] = {
    hero_name = "100065",
    hero_des = "100152",
    hero_des_all = "100239",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_407.png",
    hero_lb_icon = "icons/role/chouka/clb_r_407.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_407.png",
    hero_bat_icon = "icons/role/fight/zd2_407.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_407.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_407.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_407.png",
    hero_xq_icon = "icons/role/xq/xq_r_407.png",
    hero_team_icon = "icons/role/team/bd_r_407.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_407.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_407.atlas",
    hero_shoot = { 140,131 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Leila/Leila/Leila.atlas",
    hero_cv = "100468", --cv
    hero_author = "100381",  --画师
    hero_atk1 = 394,
    hero_atk2 = 0,
    position_name = "100555",
    position_desc = "100642",
    power_name = 7,
    power_str = "100276",
    get_method = "100729",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero407bs.wav","music/roleaudio/rs2-j-407.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-407.mp3","voice/jp/hero/hero_407.mp3","music/roleaudio/rb-j-407.mp3","music/roleaudio/rw-j-407.mp3","music/roleaudio/rl-j-407.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[408] = {
    hero_name = "100066",
    hero_des = "100153",
    hero_des_all = "100240",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 1,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_408.png",
    hero_lb_icon = "icons/role/chouka/clb_r_408.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_408.png",
    hero_bat_icon = "icons/role/fight/zd2_408.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_408.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_408.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_408.png",
    hero_xq_icon = "icons/role/xq/xq_r_408.png",
    hero_team_icon = "icons/role/team/bd_r_408.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_408.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_408.atlas",
    hero_shoot = { 100,155 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Shuangxing/Shuangxing/Shuangxing.atlas",
    hero_cv = "100469", --cv
    hero_author = "100382",  --画师
    hero_atk1 = 351,
    hero_atk2 = 0,
    position_name = "100556",
    position_desc = "100643",
    power_name = 11,
    power_str = "100280",
    get_method = "100730",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero408bs.wav","music/roleaudio/rs2-j-408.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-408.mp3","voice/jp/hero/hero_408.mp3","music/roleaudio/rb-j-408.mp3","music/roleaudio/rw-j-408.mp3","music/roleaudio/rl-j-408.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[409] = {
    hero_name = "100067",
    hero_des = "100154",
    hero_des_all = "100241",
    hero_rank = 4,
    hero_race = 8,
    hero_atb = 4,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_409.png",
    hero_lb_icon = "icons/role/chouka/clb_r_409.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_409.png",
    hero_bat_icon = "icons/role/fight/zd2_409.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_409.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_409.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_409.png",
    hero_xq_icon = "icons/role/xq/xq_r_409.png",
    hero_team_icon = "icons/role/team/bd_r_409.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_409.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_409.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Tianjingsi/Tianjingsi/Tianjingsi.atlas",
    hero_cv = "100470", --cv
    hero_author = "100383",  --画师
    hero_atk1 = 395,
    hero_atk2 = 0,
    position_name = "100557",
    position_desc = "100644",
    power_name = 7,
    power_str = "100276",
    get_method = "100731",
    sex_name = 3,
    sex_img = "icons/role/xqetc/jsgs_ui_008.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero409bs.wav","music/roleaudio/rs2-j-409.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-409.mp3","voice/jp/hero/hero_409.mp3","music/roleaudio/rb-j-409.mp3","music/roleaudio/rw-j-409.mp3","music/roleaudio/rl-j-409.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 5,
            },     
            {
                mat_id = "mat_17",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            {
                mat_id = "mat_18",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            {
                mat_id = "mat_19",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[410] = {
    hero_name = "100068",
    hero_des = "100155",
    hero_des_all = "100242",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 4,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_410.png",
    hero_lb_icon = "icons/role/chouka/clb_r_410.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_410.png",
    hero_bat_icon = "icons/role/fight/zd2_410.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_410.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_410.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_410.png",
    hero_xq_icon = "icons/role/xq/xq_r_410.png",
    hero_team_icon = "icons/role/team/bd_r_410.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_410.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_410.atlas",
    hero_shoot = { 160,140 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Younuo/Younuo/Younuo.atlas",
    hero_cv = "100471", --cv
    hero_author = "100384",  --画师
    hero_atk1 = 10410,
    hero_atk2 = 0,
    position_name = "100558",
    position_desc = "100645",
    power_name = 5,
    power_str = "100274",
    get_method = "100732",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero410bs.wav","music/roleaudio/rs2-j-410.mp3","music/heropugong/hero410pg.mp3","","music/roleaudio/rs1-j-410.mp3","voice/jp/hero/hero_410.mp3","music/roleaudio/rb-j-410.mp3","music/roleaudio/rw-j-410.mp3","music/roleaudio/rl-j-410.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[411] = {
    hero_name = "100069",
    hero_des = "100156",
    hero_des_all = "100243",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 4,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_411.png",
    hero_lb_icon = "icons/role/chouka/clb_r_411.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_411.png",
    hero_bat_icon = "icons/role/fight/zd2_411.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_411.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_411.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_411.png",
    hero_xq_icon = "icons/role/xq/xq_r_411.png",
    hero_team_icon = "icons/role/team/bd_r_411.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_411.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_411.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xigedelifa/Xigedelifa/Xigedelifa.atlas",
    hero_cv = "100472", --cv
    hero_author = "100385",  --画师
    hero_atk1 = 397,
    hero_atk2 = 0,
    position_name = "100559",
    position_desc = "100646",
    power_name = 14,
    power_str = "100283",
    get_method = "100733",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero411bs.wav","music/roleaudio/rs2-j-411.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-411.mp3","voice/jp/hero/hero_411.mp3","music/roleaudio/rb-j-411.mp3","music/roleaudio/rw-j-411.mp3","music/roleaudio/rl-j-411.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[412] = {
    hero_name = "100070",
    hero_des = "100157",
    hero_des_all = "100244",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_412.png",
    hero_lb_icon = "icons/role/chouka/clb_r_412.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_412.png",
    hero_bat_icon = "icons/role/fight/zd2_412.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_412.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_412.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_412.png",
    hero_xq_icon = "icons/role/xq/xq_r_412.png",
    hero_team_icon = "icons/role/team/bd_r_412.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_412.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_412.atlas",
    hero_shoot = { 95,151 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Youna/Youna/Youna.atlas",
    hero_cv = "100473", --cv
    hero_author = "100386",  --画师
    hero_atk1 = 396,
    hero_atk2 = 0,
    position_name = "100560",
    position_desc = "100647",
    power_name = 15,
    power_str = "100284",
    get_method = "100734",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero412bs.wav","music/roleaudio/rs2-j-412.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-412.mp3","voice/jp/hero/hero_412.mp3","music/roleaudio/rb-j-412.mp3","music/roleaudio/rw-j-412.mp3","music/roleaudio/rl-j-412.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[413] = {
    hero_name = "100071",
    hero_des = "100158",
    hero_des_all = "100245",
    hero_rank = 5,
    hero_race = 7,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_413.png",
    hero_lb_icon = "icons/role/chouka/clb_r_413.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_413.png",
    hero_bat_icon = "icons/role/fight/zd2_413.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_413.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_413.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_413.png",
    hero_xq_icon = "icons/role/xq/xq_r_413.png",
    hero_team_icon = "icons/role/team/bd_r_413.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_413.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_413.atlas",
    hero_shoot = { 75,141 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Tianmanyue/Tianmanyue/Tianmanyue.atlas",
    hero_cv = "100474", --cv
    hero_author = "100387",  --画师
    hero_atk1 = 396,
    hero_atk2 = 0,
    position_name = "100561",
    position_desc = "100648",
    power_name = 15,
    power_str = "100284",
    get_method = "100735",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero413bs.wav","music/roleaudio/rs2-j-413.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-413.mp3","voice/jp/hero/hero_413.mp3","music/roleaudio/rb-j-413.mp3","music/roleaudio/rw-j-413.mp3","music/roleaudio/rl-j-413.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[414] = {
    hero_name = "100072",
    hero_des = "100159",
    hero_des_all = "100246",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_414.png",
    hero_lb_icon = "icons/role/chouka/clb_r_414.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_414.png",
    hero_bat_icon = "icons/role/fight/zd2_414.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_414.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_414.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_414.png",
    hero_xq_icon = "icons/role/xq/xq_r_414.png",
    hero_team_icon = "icons/role/team/bd_r_414.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_414.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_414.atlas",
    hero_shoot = { 104,136 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/IA/IA/IA.atlas",
    hero_cv = "100475", --cv
    hero_author = "100388",  --画师
    hero_atk1 = 401,
    hero_atk2 = 0,
    position_name = "100562",
    position_desc = "100649",
    power_name = 15,
    power_str = "100284",
    get_method = "100736",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero414bs.wav","music/roleaudio/rs2-j-414.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-414.mp3","voice/jp/hero/hero_414.mp3","music/roleaudio/rb-j-414.mp3","music/roleaudio/rw-j-414.mp3","music/roleaudio/rl-j-414.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[451] = {
    hero_name = "100073",
    hero_des = "100160",
    hero_des_all = "100247",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_451.png",
    hero_lb_icon = "icons/role/chouka/clb_r_451.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_451.png",
    hero_bat_icon = "icons/role/fight/zd2_451.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_451.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_451.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_451.png",
    hero_xq_icon = "icons/role/xq/xq_r_451.png",
    hero_team_icon = "icons/role/team/bd_r_451.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_451.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_451.atlas",
    hero_shoot = { 112,139 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Aijiang/Aijiang/Aijiang.atlas",
    hero_cv = "100476", --cv
    hero_author = "100389",  --画师
    hero_atk1 = 389,
    hero_atk2 = 0,
    position_name = "100563",
    position_desc = "100650",
    power_name = 15,
    power_str = "100284",
    get_method = "100737",
    sex_name = 3,
    sex_img = "icons/role/xqetc/jsgs_ui_008.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero451bs.wav","music/roleaudio/rs2-j-451.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-451.mp3","voice/jp/hero/hero_451.mp3","music/roleaudio/rb-j-451.mp3","music/roleaudio/rw-j-451.mp3","music/roleaudio/rl-j-451.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[500] = {
    hero_name = "100074",
    hero_des = "100161",
    hero_des_all = "100248",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_500.png",
    hero_lb_icon = "icons/role/chouka/clb_r_500.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_500.png",
    hero_bat_icon = "icons/role/fight/zd2_500.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_500.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_500.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_500.png",
    hero_xq_icon = "icons/role/xq/xq_r_500.png",
    hero_team_icon = "icons/role/team/bd_r_500.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_500.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_500.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Mianhua/Mianhua/Mianhua.atlas",
    hero_cv = "100477", --cv
    hero_author = "100390",  --画师
    hero_atk1 = 10500,
    hero_atk2 = 0,
    position_name = "100564",
    position_desc = "100651",
    power_name = 7,
    power_str = "100276",
    get_method = "100738",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero500bs.wav","music/roleaudio/rs2-j-500.mp3","music/heropugong/hero500pg.mp3","","music/roleaudio/rs1-j-500.mp3","voice/jp/hero/hero_500.mp3","music/roleaudio/rb-j-500.mp3","music/roleaudio/rw-j-500.mp3","music/roleaudio/rl-j-500.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[501] = {
    hero_name = "100075",
    hero_des = "100162",
    hero_des_all = "100249",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_501.png",
    hero_lb_icon = "icons/role/chouka/clb_r_501.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_501.png",
    hero_bat_icon = "icons/role/fight/zd2_501.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_501.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_501.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_501.png",
    hero_xq_icon = "icons/role/xq/xq_r_501.png",
    hero_team_icon = "icons/role/team/bd_r_501.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_501.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_501.atlas",
    hero_shoot = { 130,130 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Yingshi/Yingshi/Yingshi.atlas",
    hero_cv = "100478", --cv
    hero_author = "100391",  --画师
    hero_atk1 = 10501,
    hero_atk2 = 0,
    position_name = "100565",
    position_desc = "100652",
    power_name = 3,
    power_str = "100272",
    get_method = "100749",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero501bs.wav","music/roleaudio/rs2-j-501.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-501.mp3","voice/jp/hero/hero_501.mp3","music/roleaudio/rb-j-501.mp3","music/roleaudio/rw-j-501.mp3","music/roleaudio/rl-j-501.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[950] = {
    hero_name = "100076",
    hero_des = "100163",
    hero_des_all = "100250",
    hero_rank = 3,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_950.png",
    hero_lb_icon = "icons/role/chouka/clb_r_950.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_950.png",
    hero_bat_icon = "icons/role/fight/zd2_950.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_950.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_950.png",
    hero_atb_icon = "icons/role/atb/ggsc_ui_226_1.png",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_950.png",
    hero_xq_icon = "icons/role/xq/xq_r_950.png",
    hero_team_icon = "icons/role/team/bd_r_950.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_950.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_950.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Lianji/Lianji.atlas",
    hero_cv = "100479", --cv
    hero_author = "100392",  --画师
    hero_atk1 = 342,
    hero_atk2 = 5,
    position_name = "100566",
    position_desc = "100653",
    power_name = 15,
    power_str = "100284",
    get_method = "100740",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero950bs.wav","music/roleaudio/rs2-j-950.mp3","music/heropugong/Njinzhan.mp3","music/heropugong/dajian.mp3","music/roleaudio/rs1-j-950.mp3","voice/jp/hero/hero_950.mp3","music/roleaudio/rb-j-950.mp3","music/roleaudio/rw-j-950.mp3","music/roleaudio/rl-j-950.mp3" },
    hero_break = {
        total_break = 4,
        break_1 = {
            break_gold = 500,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 8,
            },     
            {
                mat_id = "mat_7",
                mat_num = 8,
            },     
            },
        }, 
        break_2 = {
            break_gold = 500,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 2,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 500,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 2,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 30,
            },     
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            },
        }, 
        break_4 = {
            break_gold = 500,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 2,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[506] = {
    hero_name = "100077",
    hero_des = "100164",
    hero_des_all = "100251",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_506.png",
    hero_lb_icon = "icons/role/chouka/clb_r_506.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_506.png",
    hero_bat_icon = "icons/role/fight/zd2_506.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_506.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_506.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_506.png",
    hero_xq_icon = "icons/role/xq/xq_r_506.png",
    hero_team_icon = "icons/role/team/bd_r_506.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_506.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_506.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Maliounie/Maliounie/Maliounie.atlas",
    hero_cv = "100480", --cv
    hero_author = "100393",  --画师
    hero_atk1 = 10506,
    hero_atk2 = 0,
    position_name = "100567",
    position_desc = "100654",
    power_name = 9,
    power_str = "100278",
    get_method = "100741",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero506bs.wav","music/roleaudio/rs2-j-506.mp3","music/heropugong/hero506pg.mp3","","music/roleaudio/rs1-j-506.mp3","voice/jp/hero/hero_506.mp3","music/roleaudio/rb-j-506.mp3","music/roleaudio/rw-j-506.mp3","music/roleaudio/rl-j-506.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[600] = {
    hero_name = "100078",
    hero_des = "100165",
    hero_des_all = "100252",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_600.png",
    hero_lb_icon = "icons/role/chouka/clb_r_600.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_600.png",
    hero_bat_icon = "icons/role/fight/zd2_600.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_600.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_600.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_600.png",
    hero_xq_icon = "icons/role/xq/xq_r_600.png",
    hero_team_icon = "icons/role/team/bd_r_600.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_600.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_600.atlas",
    hero_shoot = { 104,136 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Leiqier/Leiqier/Leiqier.atlas",
    hero_cv = "100481", --cv
    hero_author = "100394",  --画师
    hero_atk1 = 10600,
    hero_atk2 = 0,
    position_name = "100568",
    position_desc = "100655",
    power_name = 15,
    power_str = "100284",
    get_method = "100742",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero600bs.wav","music/roleaudio/rs2-j-600.mp3","music/heropugong/hero600pg.mp3","","music/roleaudio/rs1-j-600.mp3","voice/jp/hero/hero_600.mp3","music/roleaudio/rb-j-600.mp3","music/roleaudio/rw-j-600.mp3","music/roleaudio/rl-j-600.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[601] = {
    hero_name = "100079",
    hero_des = "100166",
    hero_des_all = "100253",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_601.png",
    hero_lb_icon = "icons/role/chouka/clb_r_601.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_601.png",
    hero_bat_icon = "icons/role/fight/zd2_601.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_601.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_601.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_601.png",
    hero_xq_icon = "icons/role/xq/xq_r_601.png",
    hero_team_icon = "icons/role/team/bd_r_601.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_601.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_601.atlas",
    hero_shoot = { 104,136 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Nine/Nine/Nine.atlas",
    hero_cv = "100482", --cv
    hero_author = "100395",  --画师
    hero_atk1 = 10601,
    hero_atk2 = 0,
    position_name = "100569",
    position_desc = "100656",
    power_name = 15,
    power_str = "100284",
    get_method = "100743",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero601bs.wav","music/roleaudio/rs2-j-601.mp3","music/heropugong/Nbaozha.mp3","","music/roleaudio/rs1-j-601.mp3","voice/jp/hero/hero_601.mp3","music/roleaudio/rb-j-601.mp3","music/roleaudio/rw-j-601.mp3","music/roleaudio/rl-j-601.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[602] = {
    hero_name = "100080",
    hero_des = "100167",
    hero_des_all = "100254",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 1,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_602.png",
    hero_lb_icon = "icons/role/chouka/clb_r_602.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_602.png",
    hero_bat_icon = "icons/role/fight/zd2_602.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_602.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_602.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_602.png",
    hero_xq_icon = "icons/role/xq/xq_r_602.png",
    hero_team_icon = "icons/role/team/bd_r_602.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_602.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_602.atlas",
    hero_shoot = { 200,90 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Jin/Jin/Jin.atlas",
    hero_cv = "100483", --cv
    hero_author = "100396",  --画师
    hero_atk1 = 10602,
    hero_atk2 = 0,
    position_name = "100570",
    position_desc = "100657",
    power_name = 15,
    power_str = "100284",
    get_method = "100744",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero602bs.wav","music/roleaudio/rs2-j-602.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-602.mp3","voice/jp/hero/hero_602.mp3","music/roleaudio/rb-j-602.mp3","music/roleaudio/rw-j-602.mp3","music/roleaudio/rl-j-602.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[603] = {
    hero_name = "100081",
    hero_des = "100168",
    hero_des_all = "100255",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_603.png",
    hero_lb_icon = "icons/role/chouka/clb_r_603.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_603.png",
    hero_bat_icon = "icons/role/fight/zd2_603.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_603.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_603.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_603.png",
    hero_xq_icon = "icons/role/xq/xq_r_603.png",
    hero_team_icon = "icons/role/team/bd_r_603.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_603.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_603.atlas",
    hero_shoot = { 104,136 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Yixienamei/Yixienamei/Yixienamei.atlas",
    hero_cv = "100484", --cv
    hero_author = "100397",  --画师
    hero_atk1 = 10603,
    hero_atk2 = 0,
    position_name = "100571",
    position_desc = "100658",
    power_name = 15,
    power_str = "100284",
    get_method = "100745",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero603bs.wav","music/roleaudio/rs2-j-603.mp3","music/heropugong/hero603pg.mp3","","music/roleaudio/rs1-j-603.mp3","voice/jp/hero/hero_603.mp3","music/roleaudio/rb-j-603.mp3","music/roleaudio/rw-j-603.mp3","music/roleaudio/rl-j-603.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[604] = {
    hero_name = "100082",
    hero_des = "100169",
    hero_des_all = "100256",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_604.png",
    hero_lb_icon = "icons/role/chouka/clb_r_604.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_604.png",
    hero_bat_icon = "icons/role/fight/zd2_604.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_604.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_604.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_604.png",
    hero_xq_icon = "icons/role/xq/xq_r_604.png",
    hero_team_icon = "icons/role/team/bd_r_604.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_604.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_604.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Ragna/Ragna/Ragna.atlas",
    hero_cv = "100485", --cv
    hero_author = "100398",  --画师
    hero_atk1 = 10604,
    hero_atk2 = 0,
    position_name = "100572",
    position_desc = "100659",
    power_name = 15,
    power_str = "100284",
    get_method = "100746",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero604bs.wav","music/roleaudio/rs2-j-604.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-604.mp3","voice/jp/hero/hero_604.mp3","music/roleaudio/rb-j-604.mp3","music/roleaudio/rw-j-604.mp3","music/roleaudio/rl-j-604.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[605] = {
    hero_name = "100083",
    hero_des = "100170",
    hero_des_all = "100257",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 4,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_605.png",
    hero_lb_icon = "icons/role/chouka/clb_r_605.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_605.png",
    hero_bat_icon = "icons/role/fight/zd2_605.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_605.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_605.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_605.png",
    hero_xq_icon = "icons/role/xq/xq_r_605.png",
    hero_team_icon = "icons/role/team/bd_r_605.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_605.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_605.atlas",
    hero_shoot = { 200,90 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Muen/Muen/Muen.atlas",
    hero_cv = "100486", --cv
    hero_author = "100399",  --画师
    hero_atk1 = 10605,
    hero_atk2 = 0,
    position_name = "100573",
    position_desc = "100660",
    power_name = 15,
    power_str = "100284",
    get_method = "100747",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero605bs.wav","music/roleaudio/rs2-j-605.mp3","music/heropugong/hero605pg.mp3","","music/roleaudio/rs1-j-605.mp3","voice/jp/hero/hero_605.mp3","music/roleaudio/rb-j-605.mp3","music/roleaudio/rw-j-605.mp3","music/roleaudio/rl-j-605.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[527] = {
    hero_name = "100084",
    hero_des = "100171",
    hero_des_all = "100258",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_527.png",
    hero_lb_icon = "icons/role/chouka/clb_r_527.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_527.png",
    hero_bat_icon = "icons/role/fight/zd2_527.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_527.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_527.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_527.png",
    hero_xq_icon = "icons/role/xq/xq_r_527.png",
    hero_team_icon = "icons/role/team/bd_r_527.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_527.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_527.atlas",
    hero_shoot = { 150,161 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xiaoshu/Xiaoshu/Xiaoshu.atlas",
    hero_cv = "100487", --cv
    hero_author = "100400",  --画师
    hero_atk1 = 10527,
    hero_atk2 = 0,
    position_name = "100574",
    position_desc = "100661",
    power_name = 5,
    power_str = "100274",
    get_method = "100748",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero527bs.wav","music/roleaudio/rs2-j-527.mp3","music/heropugong/hero527pg.mp3","","music/roleaudio/rs1-j-527.mp3","voice/jp/hero/hero_527.mp3","music/roleaudio/rb-j-527.mp3","music/roleaudio/rw-j-527.mp3","music/roleaudio/rl-j-527.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[392] = {
    hero_name = "100085",
    hero_des = "100172",
    hero_des_all = "100259",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 4,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_392.png",
    hero_lb_icon = "icons/role/chouka/clb_r_392.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_392.png",
    hero_bat_icon = "icons/role/fight/zd2_392.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_392.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_392.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_392.png",
    hero_xq_icon = "icons/role/xq/xq_r_392.png",
    hero_team_icon = "icons/role/team/bd_r_392.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_392.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_392.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Ludi/Ludi/Ludi.atlas",
    hero_cv = "100488", --cv
    hero_author = "100401",  --画师
    hero_atk1 = 10392,
    hero_atk2 = 0,
    position_name = "100575",
    position_desc = "100662",
    power_name = 1,
    power_str = "100270",
    get_method = "100749",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero392bs.wav","music/roleaudio/rs2-j-392.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-392.mp3","voice/jp/hero/hero_392.mp3","music/roleaudio/rb-j-392.mp3","music/roleaudio/rw-j-392.mp3","music/roleaudio/rl-j-392.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[504] = {
    hero_name = "100086",
    hero_des = "100173",
    hero_des_all = "100260",
    hero_rank = 5,
    hero_race = 4,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_504.png",
    hero_lb_icon = "icons/role/chouka/clb_r_504.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_504.png",
    hero_bat_icon = "icons/role/fight/zd2_504.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_504.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_504.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_504.png",
    hero_xq_icon = "icons/role/xq/xq_r_504.png",
    hero_team_icon = "icons/role/team/bd_r_504.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_504.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_504.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Buladelei/Buladelei/Buladelei.atlas",
    hero_cv = "100489", --cv
    hero_author = "100402",  --画师
    hero_atk1 = 10504,
    hero_atk2 = 0,
    position_name = "100576",
    position_desc = "100663",
    power_name = 10,
    power_str = "100279",
    get_method = "100750",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero504bs.wav","music/roleaudio/rs2-j-504.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-504.mp3","voice/jp/hero/hero_504.mp3","music/roleaudio/rb-j-504.mp3","music/roleaudio/rw-j-504.mp3","music/roleaudio/rl-j-504.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 15000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 20000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[395] = {
    hero_name = "100087",
    hero_des = "100174",
    hero_des_all = "100261",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_395.png",
    hero_lb_icon = "icons/role/chouka/clb_r_395.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_395.png",
    hero_bat_icon = "icons/role/fight/zd2_395.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_395.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_395.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_395.png",
    hero_xq_icon = "icons/role/xq/xq_r_395.png",
    hero_team_icon = "icons/role/team/bd_r_395.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_395.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_395.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Aerfennv/Aerfennv/Aerfennv.atlas",
    hero_cv = "100490", --cv
    hero_author = "100403",  --画师
    hero_atk1 = 10395,
    hero_atk2 = 0,
    position_name = "100577",
    position_desc = "100664",
    power_name = 15,
    power_str = "100284",
    get_method = "100751",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero395bs.wav","music/roleaudio/rs2-j-395.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-395.mp3","voice/jp/hero/hero_395.mp3","music/roleaudio/rb-j-395.mp3","music/roleaudio/rw-j-395.mp3","music/roleaudio/rl-j-395.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 5,
            },     
            {
                mat_id = "mat_7",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            {
                mat_id = "mat_8",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            {
                mat_id = "mat_9",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[530] = {
    hero_name = "300000",
    hero_des = "301000",
    hero_des_all = "302000",
    hero_rank = 4,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_530.png",
    hero_lb_icon = "icons/role/chouka/clb_r_530.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_530.png",
    hero_bat_icon = "icons/role/fight/zd2_530.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_530.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_530.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_530.png",
    hero_xq_icon = "icons/role/xq/xq_r_530.png",
    hero_team_icon = "icons/role/team/bd_r_530.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_530.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_530.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xinnianxiluo/Xinnianxiluo/Xinnianxiluo.atlas",
    hero_cv = "304000", --cv
    hero_author = "303000",  --画师
    hero_atk1 = 10530,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 7,
    power_str = "100276",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero530bs.wav","music/roleaudio/rs2-j-530.mp3","music/heropugong/hero530pg.mp3","","music/roleaudio/rs1-j-530.mp3","voice/jp/hero/hero_530.mp3","music/roleaudio/rb-j-530.mp3","music/roleaudio/rw-j-530.mp3","music/roleaudio/rl-j-530.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 5,
            },     
            {
                mat_id = "mat_2",
                mat_num = 5,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            {
                mat_id = "mat_3",
                mat_num = 10,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            {
                mat_id = "mat_4",
                mat_num = 20,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 30,
            },     
            {
                mat_id = "mat_25",
                mat_num = 30,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 40,
            },     
            {
                mat_id = "mat_25",
                mat_num = 40,
            },     
            },
        }, 
    },
}
hero[531] = {
    hero_name = "300001",
    hero_des = "301001",
    hero_des_all = "302001",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_531.png",
    hero_lb_icon = "icons/role/chouka/clb_r_531.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_531.png",
    hero_bat_icon = "icons/role/fight/zd2_531.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_531.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_531.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_531.png",
    hero_xq_icon = "icons/role/xq/xq_r_531.png",
    hero_team_icon = "icons/role/team/bd_r_531.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_531.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_531.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xinnianpeituoliya/Xinnianpeituoliya/Xinnianpeituoliya.atlas",
    hero_cv = "304001", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10531,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 1,
    power_str = "100270",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero531bs.wav","music/roleaudio/rs2-j-531.mp3","music/heropugong/hero531pg.mp3","","music/roleaudio/rs1-j-531.mp3","voice/jp/hero/hero_531.mp3","music/roleaudio/rb-j-531.mp3","music/roleaudio/rw-j-531.mp3","music/roleaudio/rl-j-531.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[532] = {
    hero_name = "300002",
    hero_des = "301002",
    hero_des_all = "302002",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 4,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_532.png",
    hero_lb_icon = "icons/role/chouka/clb_r_532.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_532.png",
    hero_bat_icon = "icons/role/fight/zd2_532.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_532.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_532.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_532.png",
    hero_xq_icon = "icons/role/xq/xq_r_532.png",
    hero_team_icon = "icons/role/team/bd_r_532.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_532.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_532.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Xinniananjielina/Xinniananjielina/Xinniananjielina.atlas",
    hero_cv = "304002", --cv
    hero_author = "303000",  --画师
    hero_atk1 = 10532,
    hero_atk2 = 0,
    position_name = "100495",
    position_desc = "100582",
    power_name = 1,
    power_str = "100270",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero532bs.wav","music/roleaudio/rs2-j-532.mp3","music/heropugong/hero532pg.mp3","","music/roleaudio/rs1-j-532.mp3","voice/jp/hero/hero_532.mp3","music/roleaudio/rb-j-532.mp3","music/roleaudio/rw-j-532.mp3","music/roleaudio/rl-j-532.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[529] = {
    hero_name = "300003",
    hero_des = "301003",
    hero_des_all = "302003",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_529.png",
    hero_lb_icon = "icons/role/chouka/clb_r_529.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_529.png",
    hero_bat_icon = "icons/role/fight/zd2_529.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_529.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_529.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_529.png",
    hero_xq_icon = "icons/role/xq/xq_r_529.png",
    hero_team_icon = "icons/role/team/bd_r_529.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_529.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_529.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Daixi/Daixi/Daixi.atlas",
    hero_cv = "100437", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10529,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 7,
    power_str = "100276",
    get_method = "100686",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero529bs.wav","music/roleaudio/rs2-j-529.mp3","music/heropugong/hero529pg.mp3","","music/roleaudio/rs1-j-529.mp3","voice/jp/hero/hero_529.mp3","music/roleaudio/rb-j-529.mp3","music/roleaudio/rw-j-529.mp3","music/roleaudio/rl-j-529.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[528] = {
    hero_name = "300004",
    hero_des = "301004",
    hero_des_all = "302004",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 5,
    hero_job = 21,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_528.png",
    hero_lb_icon = "icons/role/chouka/clb_r_528.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_528.png",
    hero_bat_icon = "icons/role/fight/zd2_528.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_528.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_528.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_528.png",
    hero_xq_icon = "icons/role/xq/xq_r_528.png",
    hero_team_icon = "icons/role/team/bd_r_528.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_528.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_528.atlas",
    hero_shoot = { 176,146 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Gelanni/Gelanni/Gelanni.atlas",
    hero_cv = "304003", --cv
    hero_author = "100341",  --画师
    hero_atk1 = 10528,
    hero_atk2 = 0,
    position_name = "100495",
    position_desc = "100582",
    power_name = 7,
    power_str = "100276",
    get_method = "100686",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero528bs.wav","music/roleaudio/rs2-j-528.mp3","music/heropugong/hero528pg.mp3","","music/roleaudio/rs1-j-528.mp3","voice/jp/hero/hero_528.mp3","music/roleaudio/rb-j-528.mp3","music/roleaudio/rw-j-528.mp3","music/roleaudio/rl-j-528.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[525] = {
    hero_name = "300011",
    hero_des = "301011",
    hero_des_all = "302011",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_525.png",
    hero_lb_icon = "icons/role/chouka/clb_r_525.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_525.png",
    hero_bat_icon = "icons/role/fight/zd2_525.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_525.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_525.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_525.png",
    hero_xq_icon = "icons/role/xq/xq_r_525.png",
    hero_team_icon = "icons/role/team/bd_r_525.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_525.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_525.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Baersaierte/Baersaierte/Baersaierte.atlas",
    hero_cv = "304010", --cv
    hero_author = "100341",  --画师
    hero_atk1 = 10525,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 1,
    power_str = "100270",
    get_method = "100722",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero525bs.wav","music/roleaudio/rs2-j-525.mp3","music/heropugong/hero525pg.mp3","","music/roleaudio/rs1-j-525.mp3","voice/jp/hero/hero_525.mp3","music/roleaudio/rb-j-525.mp3","music/roleaudio/rw-j-525.mp3","music/roleaudio/rl-j-525.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[524] = {
    hero_name = "300012",
    hero_des = "301012",
    hero_des_all = "302012",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_524.png",
    hero_lb_icon = "icons/role/chouka/clb_r_524.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_524.png",
    hero_bat_icon = "icons/role/fight/zd2_524.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_524.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_524.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_524.png",
    hero_xq_icon = "icons/role/xq/xq_r_524.png",
    hero_team_icon = "icons/role/team/bd_r_524.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_524.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_524.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Saimisi/Saimisi/Saimisi.atlas",
    hero_cv = "100468", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10524,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 1,
    power_str = "100270",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero524bs.wav","music/roleaudio/rs2-j-524.mp3","music/heropugong/hero524pg.mp3","","music/roleaudio/rs1-j-524.mp3","voice/jp/hero/hero_524.mp3","music/roleaudio/rb-j-524.mp3","music/roleaudio/rw-j-524.mp3","music/roleaudio/rl-j-524.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[355] = {
    hero_name = "300014",
    hero_des = "301014",
    hero_des_all = "302014",
    hero_rank = 5,
    hero_race = 4,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_355.png",
    hero_lb_icon = "icons/role/chouka/clb_r_355.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_355.png",
    hero_bat_icon = "icons/role/fight/zd2_355.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_355.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_355.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_355.png",
    hero_xq_icon = "icons/role/xq/xq_r_355.png",
    hero_team_icon = "icons/role/team/bd_r_355.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_355.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_355.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Kanuonuo/Kanuonuo/Kanuonuo.atlas",
    hero_cv = "100471", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10355,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 5,
    power_str = "100274",
    get_method = "100686",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero355bs.wav","music/roleaudio/rs2-j-355.mp3","music/heropugong/hero355pg.mp3","","music/roleaudio/rs1-j-355.mp3","voice/jp/hero/hero_355.mp3","music/roleaudio/rb-j-355.mp3","music/roleaudio/rw-j-355.mp3","music/roleaudio/rl-j-355.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[700] = {
    hero_name = "300015",
    hero_des = "301015",
    hero_des_all = "302015",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 4,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_700.png",
    hero_lb_icon = "icons/role/chouka/clb_r_700.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_700.png",
    hero_bat_icon = "icons/role/fight/zd2_700.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_700.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_700.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_700.png",
    hero_xq_icon = "icons/role/xq/xq_r_700.png",
    hero_team_icon = "icons/role/team/bd_r_700.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_700.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_700.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Yalishanda/Yalishanda/Yalishanda.atlas",
    hero_cv = "304011", --cv
    hero_author = "100341",  --画师
    hero_atk1 = 10700,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 4,
    power_str = "100273",
    get_method = "615352",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero700bs.wav","music/roleaudio/rs2-j-700.mp3","music/heropugong/hero700pg.mp3","","music/roleaudio/rs1-j-700.mp3","voice/jp/hero/hero_700.mp3","music/roleaudio/rb-j-700.mp3","music/roleaudio/rw-j-700.mp3","music/roleaudio/rl-j-700.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[702] = {
    hero_name = "300016",
    hero_des = "301016",
    hero_des_all = "302016",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_702.png",
    hero_lb_icon = "icons/role/chouka/clb_r_702.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_702.png",
    hero_bat_icon = "icons/role/fight/zd2_702.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_702.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_702.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_702.png",
    hero_xq_icon = "icons/role/xq/xq_r_702.png",
    hero_team_icon = "icons/role/team/bd_r_702.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_702.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_702.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Heiyakaijia/Heiyakaijia/Heiyakaijia.atlas",
    hero_cv = "100435", --cv
    hero_author = "100341",  --画师
    hero_atk1 = 10702,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 4,
    power_str = "100273",
    get_method = "615352",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero702bs.wav","music/roleaudio/rs2-j-702.mp3","music/heropugong/hero702pg.mp3","","music/roleaudio/rs1-j-702.mp3","voice/jp/hero/hero_702.mp3","music/roleaudio/rb-j-702.mp3","music/roleaudio/rw-j-702.mp3","music/roleaudio/rl-j-702.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[703] = {
    hero_name = "300017",
    hero_des = "301017",
    hero_des_all = "302017",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_703.png",
    hero_lb_icon = "icons/role/chouka/clb_r_703.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_703.png",
    hero_bat_icon = "icons/role/fight/zd2_703.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_703.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_703.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_703.png",
    hero_xq_icon = "icons/role/xq/xq_r_703.png",
    hero_team_icon = "icons/role/team/bd_r_703.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_703.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_703.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Aoliweier/Aoliweier/Aoliweier.atlas",
    hero_cv = "304012", --cv
    hero_author = "100318",  --画师
    hero_atk1 = 10703,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 4,
    power_str = "100273",
    get_method = "615352",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero703bs.wav","music/roleaudio/rs2-j-703.mp3","music/heropugong/hero703pg.mp3","","music/roleaudio/rs1-j-703.mp3","voice/jp/hero/hero_703.mp3","music/roleaudio/rb-j-703.mp3","music/roleaudio/rw-j-703.mp3","music/roleaudio/rl-j-703.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[705] = {
    hero_name = "300019",
    hero_des = "301019",
    hero_des_all = "302019",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_705.png",
    hero_lb_icon = "icons/role/chouka/clb_r_705.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_705.png",
    hero_bat_icon = "icons/role/fight/zd2_705.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_705.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_705.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_705.png",
    hero_xq_icon = "icons/role/xq/xq_r_705.png",
    hero_team_icon = "icons/role/team/bd_r_705.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_705.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_705.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Alubeier/Alubeier/Alubeier.atlas",
    hero_cv = "304014", --cv
    hero_author = "303002",  --画师
    hero_atk1 = 10705,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 4,
    power_str = "100273",
    get_method = "615352",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero705bs.wav","music/roleaudio/rs2-j-705.mp3","music/heropugong/hero705pg.mp3","","music/roleaudio/rs1-j-705.mp3","voice/jp/hero/hero_705.mp3","music/roleaudio/rb-j-705.mp3","music/roleaudio/rw-j-705.mp3","music/roleaudio/rl-j-705.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[393] = {
    hero_name = "300020",
    hero_des = "301020",
    hero_des_all = "302020",
    hero_rank = 5,
    hero_race = 3,
    hero_atb = 4,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_393.png",
    hero_lb_icon = "icons/role/chouka/clb_r_393.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_393.png",
    hero_bat_icon = "icons/role/fight/zd2_393.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_393.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_393.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_393.png",
    hero_xq_icon = "icons/role/xq/xq_r_393.png",
    hero_team_icon = "icons/role/team/bd_r_393.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_393.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_393.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Niya/Niya/Niya.atlas",
    hero_cv = "304015", --cv
    hero_author = "303003",  --画师
    hero_atk1 = 10393,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 6,
    power_str = "100275",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero393bs.wav","music/roleaudio/rs2-j-393.mp3","music/heropugong/hero393pg.mp3","","music/roleaudio/rs1-j-393.mp3","voice/jp/hero/hero_393.mp3","music/roleaudio/rb-j-393.mp3","music/roleaudio/rw-j-393.mp3","music/roleaudio/rl-j-393.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[24] = {
    hero_name = "100004",
    hero_des = "100091",
    hero_des_all = "100178",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_024.png",
    hero_lb_icon = "icons/role/chouka/clb_r_024.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_024.png",
    hero_bat_icon = "icons/role/fight/zd2_024.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_024.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_024.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_024.png",
    hero_xq_icon = "icons/role/xq/xq_r_024.png",
    hero_team_icon = "icons/role/team/bd_r_024.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_024.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_024.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Aliote/Aliote/Aliote.atlas",
    hero_cv = "100407", --cv
    hero_author = "100320",  --画师
    hero_atk1 = 372,
    hero_atk2 = 3,
    position_name = "100491",
    position_desc = "100578",
    power_name = 15,
    power_str = "100284",
    get_method = "100685",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero24bs.wav","music/roleaudio/rs2-j-024.mp3","music/heropugong/Njinzhan.mp3","","music/roleaudio/rs1-j-024.mp3","voice/jp/hero/hero_024.mp3","music/roleaudio/rb-j-024.mp3","music/roleaudio/rw-j-024.mp3","music/roleaudio/rl-j-024.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[511] = {
    hero_name = "300021",
    hero_des = "301021",
    hero_des_all = "302021",
    hero_rank = 5,
    hero_race = 7,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_511.png",
    hero_lb_icon = "icons/role/chouka/clb_r_511.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_511.png",
    hero_bat_icon = "icons/role/fight/zd2_511.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_511.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_511.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_511.png",
    hero_xq_icon = "icons/role/xq/xq_r_511.png",
    hero_team_icon = "icons/role/team/bd_r_511.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_511.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_511.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Qiangui_2/Qiangui_2/Qiangui_2.atlas",
    hero_cv = "304014", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10511,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 3,
    power_str = "100272",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero511bs.wav","music/roleaudio/rs2-j-511.mp3","music/heropugong/hero511pg.mp3","","music/roleaudio/rs1-j-511.mp3","voice/jp/hero/hero_511.mp3","music/roleaudio/rb-j-511.mp3","music/roleaudio/rw-j-511.mp3","music/roleaudio/rl-j-511.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[503] = {
    hero_name = "300022",
    hero_des = "301022",
    hero_des_all = "302022",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_503.png",
    hero_lb_icon = "icons/role/chouka/clb_r_503.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_503.png",
    hero_bat_icon = "icons/role/fight/zd2_503.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_503.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_503.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_503.png",
    hero_xq_icon = "icons/role/xq/xq_r_503.png",
    hero_team_icon = "icons/role/team/bd_r_503.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_503.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_503.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Nidehuoge/Nidehuoge/Nidehuoge.atlas",
    hero_cv = "100437", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10503,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 14,
    power_str = "100283",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero503bs.wav","music/roleaudio/rs2-j-503.mp3","music/heropugong/hero503pg.mp3","","music/roleaudio/rs1-j-503.mp3","voice/jp/hero/hero_503.mp3","music/roleaudio/rb-j-503.mp3","music/roleaudio/rw-j-503.mp3","music/roleaudio/rl-j-503.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[534] = {
    hero_name = "300023",
    hero_des = "301023",
    hero_des_all = "302023",
    hero_rank = 5,
    hero_race = 3,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_534.png",
    hero_lb_icon = "icons/role/chouka/clb_r_534.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_534.png",
    hero_bat_icon = "icons/role/fight/zd2_534.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_534.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_534.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_534.png",
    hero_xq_icon = "icons/role/xq/xq_r_534.png",
    hero_team_icon = "icons/role/team/bd_r_534.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_534.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_534.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Kadeli/Kadeli/Kadeli.atlas",
    hero_cv = "615645", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10534,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 6,
    power_str = "100275",
    get_method = "616121",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero534bs.wav","music/roleaudio/rs2-j-534.mp3","music/heropugong/hero534pg.mp3","","music/roleaudio/rs1-j-534.mp3","voice/jp/hero/hero_534.mp3","music/roleaudio/rb-j-534.mp3","music/roleaudio/rw-j-534.mp3","music/roleaudio/rl-j-534.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[514] = {
    hero_name = "300024",
    hero_des = "301024",
    hero_des_all = "302024",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_514.png",
    hero_lb_icon = "icons/role/chouka/clb_r_514.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_514.png",
    hero_bat_icon = "icons/role/fight/zd2_514.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_514.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_514.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_514.png",
    hero_xq_icon = "icons/role/xq/xq_r_514.png",
    hero_team_icon = "icons/role/team/bd_r_514.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_514.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_514.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Lamuda/Lamuda/Lamuda.atlas",
    hero_cv = "616149", --cv
    hero_author = "100318",  --画师
    hero_atk1 = 10514,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 7,
    power_str = "100276",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero514bs.wav","music/roleaudio/rs2-j-514.mp3","music/heropugong/hero514pg.mp3","","music/roleaudio/rs1-j-514.mp3","voice/jp/hero/hero_514.mp3","music/roleaudio/rb-j-514.mp3","music/roleaudio/rw-j-514.mp3","music/roleaudio/rl-j-514.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[513] = {
    hero_name = "300025",
    hero_des = "301025",
    hero_des_all = "302025",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_513.png",
    hero_lb_icon = "icons/role/chouka/clb_r_513.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_513.png",
    hero_bat_icon = "icons/role/fight/zd2_513.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_513.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_513.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_513.png",
    hero_xq_icon = "icons/role/xq/xq_r_513.png",
    hero_team_icon = "icons/role/team/bd_r_513.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_513.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_513.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Aipuxilong/Aipuxilong/Aipuxilong.atlas",
    hero_cv = "616151", --cv
    hero_author = "616150",  --画师
    hero_atk1 = 10513,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 7,
    power_str = "100276",
    get_method = "616121",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero513bs.wav","music/roleaudio/rs2-j-513.mp3","music/heropugong/hero513pg.mp3","","music/roleaudio/rs1-j-513.mp3","voice/jp/hero/hero_513.mp3","music/roleaudio/rb-j-513.mp3","music/roleaudio/rw-j-513.mp3","music/roleaudio/rl-j-513.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[366] = {
    hero_name = "300026",
    hero_des = "301026",
    hero_des_all = "302026",
    hero_rank = 5,
    hero_race = 3,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_366.png",
    hero_lb_icon = "icons/role/chouka/clb_r_366.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_366.png",
    hero_bat_icon = "icons/role/fight/zd2_366.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_366.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_366.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_366.png",
    hero_xq_icon = "icons/role/xq/xq_r_366.png",
    hero_team_icon = "icons/role/team/bd_r_366.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_366.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_366.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Kuisha_1/Kuisha/Kuisha.atlas",
    hero_cv = "100437", --cv
    hero_author = "100318",  --画师
    hero_atk1 = 10366,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 6,
    power_str = "100275",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero366bs.wav","music/roleaudio/rs2-j-366.mp3","music/heropugong/hero366pg.mp3","","music/roleaudio/rs1-j-366.mp3","voice/jp/hero/hero_366.mp3","music/roleaudio/rb-j-366.mp3","music/roleaudio/rw-j-366.mp3","music/roleaudio/rl-j-366.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[519] = {
    hero_name = "300027",
    hero_des = "301027",
    hero_des_all = "302027",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_519.png",
    hero_lb_icon = "icons/role/chouka/clb_r_519.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_519.png",
    hero_bat_icon = "icons/role/fight/zd2_519.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_519.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_519.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_519.png",
    hero_xq_icon = "icons/role/xq/xq_r_519.png",
    hero_team_icon = "icons/role/team/bd_r_519.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_519.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_519.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Sikuer/Sikuer/Sikuer.atlas",
    hero_cv = "100435", --cv
    hero_author = "100341",  --画师
    hero_atk1 = 10519,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 14,
    power_str = "100283",
    get_method = "100722",
    sex_name = 1,
    sex_img = "icons/role/xqetc/jsgs_ui_006.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero519bs.wav","music/roleaudio/rs2-j-519.mp3","music/heropugong/hero519pg.mp3","","music/roleaudio/rs1-j-519.mp3","voice/jp/hero/hero_519.mp3","music/roleaudio/rb-j-519.mp3","music/roleaudio/rw-j-519.mp3","music/roleaudio/rl-j-519.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[520] = {
    hero_name = "300028",
    hero_des = "301028",
    hero_des_all = "302028",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 5,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_520.png",
    hero_lb_icon = "icons/role/chouka/clb_r_520.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_520.png",
    hero_bat_icon = "icons/role/fight/zd2_520.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_520.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_520.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_520.png",
    hero_xq_icon = "icons/role/xq/xq_r_520.png",
    hero_team_icon = "icons/role/team/bd_r_520.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_520.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_520.atlas",
    hero_shoot = { 160,140 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Hati/Hati/Hati.atlas",
    hero_cv = "615645", --cv
    hero_author = "303001",  --画师
    hero_atk1 = 10520,
    hero_atk2 = 0,
    position_name = "100499",
    position_desc = "100586",
    power_name = 14,
    power_str = "100283",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero520bs.wav","music/roleaudio/rs2-j-520.mp3","music/heropugong/hero520pg.mp3","","music/roleaudio/rs1-j-520.mp3","voice/jp/hero/hero_520.mp3","music/roleaudio/rb-j-520.mp3","music/roleaudio/rw-j-520.mp3","music/roleaudio/rl-j-520.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[502] = {
    hero_name = "300029",
    hero_des = "301029",
    hero_des_all = "302029",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 3,
    hero_job = 12,
    hero_landaward_icon = "icons/role/signin/qd_r_502.png",  -- 签到头像
    role_share_img = "icons/role/fx/fx_502.png",
    hero_lb_icon = "icons/role/chouka/clb_r_502.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_502.png",
    hero_bat_icon = "icons/role/fight/zd2_502.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_502.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_502.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_502.png",
    hero_xq_icon = "icons/role/xq/xq_r_502.png",
    hero_team_icon = "icons/role/team/bd_r_502.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_502.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_502.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Lingyijiang/Lingyijiang/Lingyijiang.atlas",
    hero_cv = "100477", --cv
    hero_author = "616883",  --画师
    hero_atk1 = 10502,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 7,
    power_str = "100276",
    get_method = "100688",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero502bs.wav","music/roleaudio/rs2-j-502.mp3","music/heropugong/hero502pg.mp3","","music/roleaudio/rs1-j-502.mp3","voice/jp/hero/hero_502.mp3","music/roleaudio/rb-j-502.mp3","music/roleaudio/rw-j-502.mp3","music/roleaudio/rl-j-502.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[535] = {
    hero_name = "300030",
    hero_des = "301030",
    hero_des_all = "302030",
    hero_rank = 5,
    hero_race = 6,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_535.png",
    hero_lb_icon = "icons/role/chouka/clb_r_535.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_535.png",
    hero_bat_icon = "icons/role/fight/zd2_535.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_535.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_535.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_535.png",
    hero_xq_icon = "icons/role/xq/xq_r_535.png",
    hero_team_icon = "icons/role/team/bd_r_535.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_535.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_535.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Bingyubachong/Bingyubachong/Bingyubachong.atlas",
    hero_cv = "100490", --cv
    hero_author = "100318",  --画师
    hero_atk1 = 10535,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 11,
    power_str = "100280",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero535bs.wav","music/roleaudio/rs2-j-535.mp3","music/heropugong/hero535pg.mp3","","music/roleaudio/rs1-j-535.mp3","voice/jp/hero/hero_535.mp3","music/roleaudio/rb-j-535.mp3","music/roleaudio/rw-j-535.mp3","music/roleaudio/rl-j-535.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[538] = {
    hero_name = "300031",
    hero_des = "301031",
    hero_des_all = "302031",
    hero_rank = 5,
    hero_race = 7,
    hero_atb = 2,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_538.png",
    hero_lb_icon = "icons/role/chouka/clb_r_538.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_538.png",
    hero_bat_icon = "icons/role/fight/zd2_538.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_538.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_538.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_538.png",
    hero_xq_icon = "icons/role/xq/xq_r_538.png",
    hero_team_icon = "icons/role/team/bd_r_538.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_538.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_538.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Wulianzhounian/Wulianzhounian/Wulianzhounian.atlas",
    hero_cv = "100441", --cv
    hero_author = "616150",  --画师
    hero_atk1 = 10538,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 15,
    power_str = "100284",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero538bs.wav","music/roleaudio/rs2-j-538.mp3","music/heropugong/hero538pg.mp3","","music/roleaudio/rs1-j-538.mp3","voice/jp/hero/hero_538.mp3","music/roleaudio/rb-j-538.mp3","music/roleaudio/rw-j-538.mp3","music/roleaudio/rl-j-538.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[540] = {
    hero_name = "300032",
    hero_des = "301032",
    hero_des_all = "302032",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_540.png",
    hero_lb_icon = "icons/role/chouka/clb_r_540.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_540.png",
    hero_bat_icon = "icons/role/fight/zd2_540.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_540.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_540.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_540.png",
    hero_xq_icon = "icons/role/xq/xq_r_540.png",
    hero_team_icon = "icons/role/team/bd_r_540.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_540.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_540.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Shaxiazhounian/Shaxiazhounian/Shaxiazhounian.atlas",
    hero_cv = "100413", --cv
    hero_author = "617131",  --画师
    hero_atk1 = 10540,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 1,
    power_str = "100270",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero540bs.wav","music/roleaudio/rs2-j-540.mp3","music/heropugong/hero540pg.mp3","","music/roleaudio/rs1-j-540.mp3","voice/jp/hero/hero_540.mp3","music/roleaudio/rb-j-540.mp3","music/roleaudio/rw-j-540.mp3","music/roleaudio/rl-j-540.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[539] = {
    hero_name = "300033",
    hero_des = "301033",
    hero_des_all = "302033",
    hero_rank = 5,
    hero_race = 2,
    hero_atb = 3,
    hero_job = 11,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_539.png",
    hero_lb_icon = "icons/role/chouka/clb_r_539.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_539.png",
    hero_bat_icon = "icons/role/fight/zd2_539.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_539.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_539.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_539.png",
    hero_xq_icon = "icons/role/xq/xq_r_539.png",
    hero_team_icon = "icons/role/team/bd_r_539.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_539.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_539.atlas",
    hero_shoot = { 160,140 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Ailuweizhounian/Ailuweizhounian/Ailuweizhounian.atlas",
    hero_cv = "100408", --cv
    hero_author = "617131",  --画师
    hero_atk1 = 10539,
    hero_atk2 = 0,
    position_name = "100499",
    position_desc = "100586",
    power_name = 8,
    power_str = "100277",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero539bs.wav","music/roleaudio/rs2-j-539.mp3","music/heropugong/hero539pg.mp3","","music/roleaudio/rs1-j-539.mp3","voice/jp/hero/hero_539.mp3","music/roleaudio/rb-j-539.mp3","music/roleaudio/rw-j-539.mp3","music/roleaudio/rl-j-539.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[541] = {
    hero_name = "300034",
    hero_des = "301034",
    hero_des_all = "302034",
    hero_rank = 5,
    hero_race = 4,
    hero_atb = 5,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_541.png",
    hero_lb_icon = "icons/role/chouka/clb_r_541.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_541.png",
    hero_bat_icon = "icons/role/fight/zd2_541.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_541.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_541.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_541.png",
    hero_xq_icon = "icons/role/xq/xq_r_541.png",
    hero_team_icon = "icons/role/team/bd_r_541.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_541.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_541.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Nikelasizhounian/Nikelasizhounian/Nikelasizhounian.atlas",
    hero_cv = "100434", --cv
    hero_author = "617427",  --画师
    hero_atk1 = 10541,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 10,
    power_str = "100279",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero541bs.wav","music/roleaudio/rs2-j-541.mp3","music/heropugong/hero541pg.mp3","","music/roleaudio/rs1-j-541.mp3","voice/jp/hero/hero_541.mp3","music/roleaudio/rb-j-541.mp3","music/roleaudio/rw-j-541.mp3","music/roleaudio/rl-j-541.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[537] = {
    hero_name = "300035",
    hero_des = "301035",
    hero_des_all = "302035",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 4,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_537.png",
    hero_lb_icon = "icons/role/chouka/clb_r_537.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_537.png",
    hero_bat_icon = "icons/role/fight/zd2_537.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_537.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_537.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_537.png",
    hero_xq_icon = "icons/role/xq/xq_r_537.png",
    hero_team_icon = "icons/role/team/bd_r_537.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_537.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_537.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Dageye/Dageye/Dageye.atlas",
    hero_cv = "617765", --cv
    hero_author = "617766",  --画师
    hero_atk1 = 10537,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 5,
    power_str = "100274",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero537bs.wav","music/roleaudio/rs2-j-537.mp3","music/heropugong/hero537pg.mp3","","music/roleaudio/rs1-j-537.mp3","voice/jp/hero/hero_537.mp3","music/roleaudio/rb-j-537.mp3","music/roleaudio/rw-j-537.mp3","music/roleaudio/rl-j-537.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_16",
                mat_num = 10,
            },     
            {
                mat_id = "mat_17",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_17",
                mat_num = 20,
            },     
            {
                mat_id = "mat_18",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_18",
                mat_num = 40,
            },     
            {
                mat_id = "mat_19",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_19",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_20",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[516] = {
    hero_name = "300036",
    hero_des = "301036",
    hero_des_all = "302036",
    hero_rank = 5,
    hero_race = 8,
    hero_atb = 3,
    hero_job = 1,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_516.png",
    hero_lb_icon = "icons/role/chouka/clb_r_516.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_516.png",
    hero_bat_icon = "icons/role/fight/zd2_516.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_516.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_516.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_516.png",
    hero_xq_icon = "icons/role/xq/xq_r_516.png",
    hero_team_icon = "icons/role/team/bd_r_516.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_516.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_516.atlas",
    hero_shoot = { 0,0 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Dashe/Dashe/Dashe.atlas",
    hero_cv = "617988", --cv
    hero_author = "303003",  --画师
    hero_atk1 = 10516,
    hero_atk2 = 0,
    position_name = "100491",
    position_desc = "100578",
    power_name = 14,
    power_str = "100283",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero516bs.wav","music/roleaudio/rs2-j-516.mp3","music/heropugong/hero516pg.mp3","","music/roleaudio/rs1-j-516.mp3","voice/jp/hero/hero_516.mp3","music/roleaudio/rb-j-516.mp3","music/roleaudio/rw-j-516.mp3","music/roleaudio/rl-j-516.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_11",
                mat_num = 10,
            },     
            {
                mat_id = "mat_12",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_12",
                mat_num = 20,
            },     
            {
                mat_id = "mat_13",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_13",
                mat_num = 40,
            },     
            {
                mat_id = "mat_14",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_14",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_15",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[542] = {
    hero_name = "300037",
    hero_des = "301037",
    hero_des_all = "302037",
    hero_rank = 5,
    hero_race = 5,
    hero_atb = 2,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_542.png",
    hero_lb_icon = "icons/role/chouka/clb_r_542.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_542.png",
    hero_bat_icon = "icons/role/fight/zd2_542.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_542.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_542.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_542.png",
    hero_xq_icon = "icons/role/xq/xq_r_542.png",
    hero_team_icon = "icons/role/team/bd_r_542.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_542.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_542.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Niefeiluyz/Niefeiluyz/Niefeiluyz.atlas",
    hero_cv = "100408", --cv
    hero_author = "617989",  --画师
    hero_atk1 = 10542,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 7,
    power_str = "100276",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero542bs.wav","music/roleaudio/rs2-j-542.mp3","music/heropugong/hero542pg.mp3","","music/roleaudio/rs1-j-542.mp3","voice/jp/hero/hero_542.mp3","music/roleaudio/rb-j-542.mp3","music/roleaudio/rw-j-542.mp3","music/roleaudio/rl-j-542.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_6",
                mat_num = 10,
            },     
            {
                mat_id = "mat_7",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_7",
                mat_num = 20,
            },     
            {
                mat_id = "mat_8",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_8",
                mat_num = 40,
            },     
            {
                mat_id = "mat_9",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_9",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_10",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[543] = {
    hero_name = "300038",
    hero_des = "301038",
    hero_des_all = "302038",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 1,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_543.png",
    hero_lb_icon = "icons/role/chouka/clb_r_543.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_543.png",
    hero_bat_icon = "icons/role/fight/zd2_543.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_543.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_543.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_543.png",
    hero_xq_icon = "icons/role/xq/xq_r_543.png",
    hero_team_icon = "icons/role/team/bd_r_543.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_543.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_543.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Maouyz/Maouyz/Maouyz.atlas",
    hero_cv = "304015", --cv
    hero_author = "618144",  --画师
    hero_atk1 = 10543,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 15,
    power_str = "100284",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero543bs.wav","music/roleaudio/rs2-j-543.mp3","music/heropugong/hero543pg.mp3","","music/roleaudio/rs1-j-543.mp3","voice/jp/hero/hero_543.mp3","music/roleaudio/rb-j-543.mp3","music/roleaudio/rw-j-543.mp3","music/roleaudio/rl-j-543.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_1",
                mat_num = 10,
            },     
            {
                mat_id = "mat_2",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_2",
                mat_num = 20,
            },     
            {
                mat_id = "mat_3",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_3",
                mat_num = 40,
            },     
            {
                mat_id = "mat_4",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_4",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_5",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}
hero[544] = {
    hero_name = "300039",
    hero_des = "301039",
    hero_des_all = "302039",
    hero_rank = 5,
    hero_race = 1,
    hero_atb = 5,
    hero_job = 12,
    hero_landaward_icon = "",  -- 签到头像
    role_share_img = "icons/role/fx/fx_544.png",
    hero_lb_icon = "icons/role/chouka/clb_r_544.png",
    hero_eqface_icon = "icons/role/eqface/lzyz_544.png",
    hero_bat_icon = "icons/role/fight/zd2_544.png",
    hero_cutin = "Resources/armatures/lihuispine/Lihui_544.atlas",
    hero_nc_icon= "icons/role/multileader/zdjs_r_544.png",
    hero_atb_icon = "",
    hero_cubageType = 1,
    hero_list_icon = "icons/role/list/lb_r_544.png",
    hero_xq_icon = "icons/role/xq/xq_r_544.png",
    hero_team_icon = "icons/role/team/bd_r_544.png",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_544.png",
    hero_des_spi = "Resources/armatures/lihuispine/Lihui_544.atlas",
    hero_shoot = { 178,160 },
    hero_touch = { -60,5,120,210 },
    hero_hit = { -20,110,50,90 },
    hero_bat = "armatures/role/Shenshina2/Shenshina2/Shenshina2.atlas",
    hero_cv = "100434", --cv
    hero_author = "618144",  --画师
    hero_atk1 = 10544,
    hero_atk2 = 0,
    position_name = "100496",
    position_desc = "100583",
    power_name = 4,
    power_str = "100273",
    get_method = "100722",
    sex_name = 2,
    sex_img = "icons/role/xqetc/jsgs_ui_007.png",
    hero_bd = { 0,110 },
    hero_hd = { -10,260 },
    --{ 大招音效,大招语音,普攻,重击,小招,抽卡,战斗开始，战斗胜利，战斗失败}
    hero_vce = { "music/herobs/hero544bs.wav","music/roleaudio/rs2-j-544.mp3","music/heropugong/hero544pg.mp3","","music/roleaudio/rs1-j-544.mp3","voice/jp/hero/hero_544.mp3","music/roleaudio/rb-j-544.mp3","music/roleaudio/rw-j-544.mp3","music/roleaudio/rl-j-544.mp3" },
    hero_break = {
        total_break = 5,
        break_1 = {
            break_gold = 1000,
            break_gem = 0,
            break_maxlv = 40,
            break_add_tp = 2,
            break_unlock_eq = 2,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_21",
                mat_num = 10,
            },     
            {
                mat_id = "mat_22",
                mat_num = 10,
            },     
            },
        }, 
        break_2 = {
            break_gold = 2000,
            break_gem = 0,
            break_maxlv = 60,
            break_add_tp = 4,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_22",
                mat_num = 20,
            },     
            {
                mat_id = "mat_23",
                mat_num = 20,
            },     
            },
        }, 
        break_3 = {
            break_gold = 4000,
            break_gem = 0,
            break_maxlv = 80,
            break_add_tp = 4,
            break_unlock_eq = 3,
            break_msg = "解锁第三个星之卵槽",
            break_mat = { 
            {
                mat_id = "mat_23",
                mat_num = 40,
            },     
            {
                mat_id = "mat_24",
                mat_num = 40,
            },     
            },
        }, 
        break_4 = {
            break_gold = 8000,
            break_gem = 0,
            break_maxlv = 100,
            break_add_tp = 8,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_24",
                mat_num = 60,
            },     
            {
                mat_id = "mat_25",
                mat_num = 60,
            },     
            },
        }, 
        break_5 = {
            break_gold = 10000,
            break_gem = 0,
            break_maxlv = 120,
            break_add_tp = 0,
            break_unlock_eq = -1,
            break_msg = "",
            break_mat = { 
            {
                mat_id = "mat_29",
                mat_num = 80,
            },     
            {
                mat_id = "mat_25",
                mat_num = 80,
            },     
            },
        }, 
    },
}