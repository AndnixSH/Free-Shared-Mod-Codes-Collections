--[[
    客服管理
]]


CustomerServiceManager = {} 

CustomerServiceManager.CUSTOMER_SERVICE_ANDROID_CLASS = "org/cocos2dx/lua/CustomerService"
CustomerServiceManager.CUSTOMER_SERVICE_IOS_CLASS = "CustomerServiceSDKManager"


-- 游戏登录成功后，进入游戏时调用，如果玩家过去有客服的请求，将客服运行在后台
function CustomerServiceManager:lauchCustomService()
    --MsgManager:showSimpMsg("CustomerServiceManager:lauchCustomService")
    local platform = cc.Application:getInstance():getTargetPlatform()
    
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = {  }
        local sigs = "()V"
        zc.luaBridgeCall(CustomerServiceManager.CUSTOMER_SERVICE_ANDROID_CLASS,"lauchCustomService",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        
    end
    
end


-- 显示客服界面
function CustomerServiceManager:showCustom()
    --玩家id
    local uid               = SDKManagerLua:getSdkUserId() or "1"
    --玩家名字
    local userName          = user_info["name"] or "username"
    --余额
    local balance           = user_info["gem"] or "0"
    --角色id
    local roleId            = user_info["uid"] or "1"
    --角色名字
    local roleName          = user_info["name"] or "username"
    --帮派
    local roleParty         = user_info["guild_name"] or ""
    --服务器名字
    local serverName        = "苍蓝镜界"
    --vip等级
    local vip               = user_info["vip"] or "0"
    local title             = "客服"
    local args = {
            uid           = tostring(uid),
            userName      = tostring(userName),
            balance       = tostring(balance),
            -- 角色id，暂时没用
            roleId        = tostring(roleId),
            roleName         = tostring(roleName),
            -- 玩家昵称
            roleParty      = tostring(roleParty),
            -- 服务器名字
            serverName    = tostring(serverName),         
            -- vip
            vip           = tostring(vip),
            title         = tostring(title),
            
        }
    --MsgManager:showSimpMsg("CustomerServiceManager:showCustom"..json.encode(args))
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(CustomerServiceManager.CUSTOMER_SERVICE_ANDROID_CLASS,"showCustom",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        local className = CustomerServiceManager.CUSTOMER_SERVICE_IOS_CLASS
        local sigs = "()V"
        ok,tempRet = zc.luaBridgeCall(className,"showCustom",args,sigs)       
    end
    
end


-- 显示客服浮标
function CustomerServiceManager:showFloatMenu()
    --MsgManager:showSimpMsg("CustomerServiceManager:showFloatMenu")
    local platform = cc.Application:getInstance():getTargetPlatform()
    
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = {  }
        local sigs = "()V"
        zc.luaBridgeCall(CustomerServiceManager.CUSTOMER_SERVICE_ANDROID_CLASS,"showFloatMenu",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        
    end
    
end


-- 显示客服浮标
function CustomerServiceManager:closeFloatMenu()
    --MsgManager:showSimpMsg("CustomerServiceManager:closeFloatMenu")
    local platform = cc.Application:getInstance():getTargetPlatform()
    
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = {  }
        local sigs = "()V"
        zc.luaBridgeCall(CustomerServiceManager.CUSTOMER_SERVICE_ANDROID_CLASS,"closeFloatMenu",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        
    end
    
end





    
    

