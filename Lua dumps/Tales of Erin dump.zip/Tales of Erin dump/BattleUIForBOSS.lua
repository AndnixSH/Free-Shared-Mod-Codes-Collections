BattleUIForBOSS = class("BattleUIForBOSS") 
BattleUIForBOSS.__index = BattleUIForBOSS

BattleUIForBOSS.BOOS_CD_PATH = "uifile/n_UIShare/zhandou/zd_ui_019.png"
BattleUIForBOSS.BATTLE_OD_PATH = "uifile/n_UIShare/zhandou/BOSS/zdzx_ui_016.png"
BattleUIForBOSS.BATTLE_BK_PATH = "uifile/n_UIShare/zhandou/BOSS/zdzx_ui_015.png"
BattleUIForBOSS.BATTLE_HP_PATH = "uifile/n_UIShare/zhandou/BOSS/zdjm_xt_"
BattleUIForBOSS.BATTLE_CD_PATH = "uifile/n_UIShare/zhandou/zdjm_ui_006.png"
BattleUIForBOSS.BATTLE_CD_PATH_sk  = "uifile/n_UIShare/zhandou/zdjm_ui_021.png"
BattleUIForBOSS.BATTLE_UI_OD = "uifile/ODEffect.csb"
BattleUIForBOSS.BATTLE_UI_XD = "uifile/BOSS_XD.csb"

BattleUIForBOSS.BOSS = nil
BattleUIForBOSS.rootNode = nil
BattleUIForBOSS.panelBOSS = nil
BattleUIForBOSS.totalHP = 0
BattleUIForBOSS.nowHP = 0
BattleUIForBOSS.totalOD = 0
BattleUIForBOSS.hpBar = nil --ODBK的进度条
BattleUIForBOSS.odBar = nil --ODBK的进度条
BattleUIForBOSS.odState = nil --ODBK的状态图
BattleUIForBOSS.timeText = nil  --行动倒计时时间
BattleUIForBOSS.bossHead = nil  --boss属性球
BattleUIForBOSS.bossIcon = nil  --boss的头像
BattleUIForBOSS.panel_od = nil 
BattleUIForBOSS.boosTimer = nil --倒计时遮罩
function BattleUIForBOSS:createWithMainUINode(node)
    local battleInfo = BattleUIForBOSS.new()
    battleInfo:init(node)
    return battleInfo
end

function BattleUIForBOSS:init(node)
	self.rootNode = node 
	self.panelBOSS = self.rootNode:getChildByTag(1)
	self.panelBOSS:setVisible(false)
    self.panel_debuff = self.rootNode:getChildByTag(20)
    self.panel_debuff:setLocalZOrder(1)  --盖到连击显示的上面去
    self.panel_debuff:setVisible(false)
    local panel_60 = self.rootNode:getChildByTag(60)
    panel_60:setVisible(false)
end

function BattleUIForBOSS:showBossHPbar(_totalHp,_totalOD,lv,name,batIcon,bCard)--总血量、OD总血量、等级、属性图标、BOSS实例
    local panel= self.rootNode:getChildByTag(2)
    panel:setVisible(false)--隐藏小怪战波数相关
    local panelWave = self.rootNode:getChildByTag(4000)
    panelWave:setVisible(false)
    if G_STAGE_TYPE ~= 2 then 
       panelWave:setVisible(true)
       for i = 2, 4 do
       	 panelWave:getChildByTag(4000+i):setVisible(false) --设置其他信息隐藏 只显示属性克制
       end
    end 
    self.panelBOSS:setVisible(true)
    self.totalHP =_totalHp
    self.nowHP = _totalHp
    self.totalOD = _totalOD
    self.hpBar = ccui.Helper:seekWidgetByTag(self.panelBOSS,106)
    self.odBar = ccui.Helper:seekWidgetByTag(self.panelBOSS,104)
    self.timeText = ccui.Helper:seekWidgetByTag(self.panelBOSS,108)
    self.timeText:setString("0")
    self.bossHead = ccui.Helper:seekWidgetByTag(self.panelBOSS,1001)
    self.odState = ccui.Helper:seekWidgetByTag(self.panelBOSS,110)
    self.odState:setUnifySizeEnabled(true)
    self.panel_od = ccui.Helper:seekWidgetByTag(self.panelBOSS,111)
    
    self.boosTimer = cc.ProgressTimer:create(cc.Sprite:create(self.BOOS_CD_PATH))
    self.boosTimer:setType(cc.PROGRESS_TIMER_TYPE_RADIAL);  --cc.ProgressTimer.Type::RADIAL
    self.boosTimer:setReverseProgress(true);
    self.boosTimer:setPercentage(0);
    self.boosTimer:setPosition(cc.p(33, 33))
    local bossImg  = ccui.Helper:seekWidgetByTag(self.panelBOSS,101)
    bossImg:addChild(self.boosTimer)

    if _totalOD < 1 then 
        self.odBar:setVisible(false);
        self.odState:setVisible(false);
        self.panel_od:setVisible(false);
        ccui.Helper:seekWidgetByTag(self.panelBOSS,102):setVisible(false);
        ccui.Helper:seekWidgetByTag(self.panelBOSS,103):setVisible(false);
    else
    	self.odBar:setPercent(100);
        self.odState:loadTexture(self.BATTLE_OD_PATH);
        self.panel_od:setVisible(true)
        local action = cc.CSLoader:createTimeline(self.BATTLE_UI_OD)
        local node =  self.panel_od:getChildByTag(112)
        node:stopAllActions()
        node:runAction(action)
        action:play("play", true)      
    end	
    self.hpBar:setPercent(100)

    local icon
    if batIcon == 1 then
        icon = "n_UIShare/Global_UI/element/ggsc_ui_126.png"
    elseif batIcon == 2 then
        icon = "n_UIShare/Global_UI/element/ggsc_ui_125.png"
    elseif batIcon == 3 then
        icon = "n_UIShare/Global_UI/element/ggsc_ui_127.png"
    elseif batIcon == 4 then
        icon = "n_UIShare/Global_UI/element/ggsc_ui_128.png"
    else
        icon = "n_UIShare/Global_UI/element/ggsc_ui_129.png"
    end
    self.bossHead:loadTexture(icon)

    self.BOSS = bCard
    self.timeText:setString(self.BOSS.attributeManager:getAtkInterval())
    self.boosTimer:setPercentage(100)    
end

function BattleUIForBOSS:startBOSSActInCD(callBackFuc)
	self.timeText:setString(self.BOSS.attributeManager:getAtkInterval())
    self.boosTimer:setPercentage(100)
    local firstAction= cc.ProgressFromTo:create(self.BOSS.attributeManager:getAtkInterval(), 100, 0)
    self.boosTimer:stopAllActions()
    self.boosTimer:runAction(firstAction)
    
    function callReset()
    	local num = tonumber(self.timeText:getString())
    	num = num -1
    	self.timeText:setString(num)
    	if num < 1 and callBackFuc ~=nil then 
    	   callBackFuc()
        end		
    end

    local callReset = cc.CallFunc:create(callReset)
    local time = cc.DelayTime:create(1)
    local actions = cc.Sequence:create(time,callReset,nil)
    
    local repeatAct = cc.Repeat:create(actions,self.BOSS.attributeManager:getAtkInterval())
    self.timeText:stopAllActions()
    self.timeText:runAction(repeatAct)
end	

function BattleUIForBOSS:setODBKState(state)
    if state == 0 then
        self.odState:loadTexture(self.BATTLE_OD_PATH)
        self.panel_od:setVisible(true)
        self.odBar:setVisible(false)
        self.panel_od:setContentSize(cc.size(545, 100))     
    else
        self.panel_od:setVisible(false)
        self.odBar:setVisible(true);
        self.odState:loadTexture(self.BATTLE_BK_PATH)        
    end   
end

function BattleUIForBOSS:changeODBKState(state)
    if state == 0 then
        self.odState:loadTexture(self.BATTLE_OD_PATH)
        self.panel_od:setVisible(true)
        self.odBar:setVisible(false)
        self.panel_od:setContentSize(cc.size(545, 100))
        local action = cc.CSLoader:createTimeline(self.BATTLE_UI_OD)
        function lastFrameCallFunc()
           local action1 = cc.CSLoader:createTimeline(self.BATTLE_UI_OD)
           local node1 = self.panel_od:getChildByTag(112)
           node1:stopAllActions()
           node1:runAction(action1)
           action1:play("play", true)
        end
        SetLastFrameCallFunc_AllPlatform(action,lastFrameCallFunc,0.2)
        local node = self.panel_od:getChildByTag(112)
        node:stopAllActions()
        node:runAction(action)
        action:play("play1", false)        
    else
        self.panel_od:setVisible(false)
        self.odBar:setVisible(true);
        self.odState:loadTexture(self.BATTLE_BK_PATH)        
    end
end

function BattleUIForBOSS:setOD(percent) 
    local width = 545
    self.odBar:setPercent(percent)
    width = (0.1+0.8* percent/100.0)*width --计算OD动画遮罩位置
    self.panel_od:setContentSize(cc.size(width, 100))
    self.odBar:setVisible(false)
    self.odState:loadTexture(self.BATTLE_OD_PATH) 	
end

function BattleUIForBOSS:setBK(percent) --BK百分比值
	self.odBar:setPercent(percent);
    self.odState:loadTexture(self.BATTLE_BK_PATH)
    self.panel_od:setVisible(false)
    self.odBar:setVisible(true)	
end

--刷新行动点数
function BattleUIForBOSS:setMcountForBoss(nowCount,maxCount) 
	local panel_60 = self.rootNode:getChildByTag(60)
    for i = 1, 6 do
    	local img = panel_60:getChildByTag(6000+i)
    	local action = cc.CSLoader:createTimeline(self.BATTLE_UI_XD)
    	if i <= maxCount then 
    		img:setVisible(true)
    		local file = "play1"
    		if i <= nowCount then 
    			file ="play2"
    			if nowCount >= maxCount then 
    			   file ="play"
    		    end		
    		end	
    		img:stopAllActions()
            img:runAction(action)
            action:play(file, true)
        else
             img:setVisible(false)      
        end

    end
   panel_60:setVisible(true)
end

--刷新buffdebuff
function BattleUIForBOSS:showbuff() 
    self.panel_debuff:setVisible(true)

    self.buffTable = {}
    self.comList = self.BOSS.componentManager.comList
	for i = 1, #self.comList do
		local v = self.comList[i]
		if v.comId < 82000 then 
			table.insert( self.buffTable , v)
	    elseif v.comId < 83000 and v.comId > 82000 then
	    	table.insert( self.buffTable ,1, v)	    
	    end		
	end
	for k,v in pairs(self.panel_debuff:getChildren()) do
		if	v ~=nil then 
			v:setVisible(false)
	    end 		
	end
    if #self.buffTable > 0 then 
		self.panel_debuff:setVisible(true)
        local this = self
		for i = 1, #self.buffTable do
		    local img = ccui.Helper:seekWidgetByTag(self.panel_debuff,2000+i)
		    if img == nil then 
		    	img = ccui.ImageView:create()
		    	img:setTag(2000+i)
		    	self.panel_debuff:addChild(img)
		    end  	
		    img:setVisible(true)
            img:setTouchEnabled(true)
		    img:addTouchEventListener(function(sender,eventType)
                local tag = sender:getTag()-2000

                if eventType == ccui.TouchEventType.began then --创建显示简短信息
                    local buff = self.buffTable[tag]
                    local buffNode = cc.CSLoader:createNode("uifile/BuffINfo.csb")
                    local icImg  =  buffNode:getChildByTag(2)
                    local text = buffNode:getChildByTag(3)
                    text:setString(GetStringAllPlatform(buff.comData["state_des"]))
                    icImg:loadTexture(buff.comData["state_icon"])
                    local point = cc.p(sender:getPosition())
                    point.x = point.x- 18 - 290
                    point.y = point.y- 20-94
                    buffNode:setPosition(point)
                    buffNode:setTag(10000+tag)
                    this.panel_debuff:addChild(buffNode);
                elseif eventType == ccui.TouchEventType.ended  then
                    this.panel_debuff:removeChildByTag(10000+tag) 
                elseif eventType ==ccui.TouchEventType.canceled then
                    this.panel_debuff:removeChildByTag(10000+tag)
                end 	
            end)
            if img:getChildByTag(100)==nil then
            	local text = ccui.Text:create("", "font/Microsoft Yahei.ttf", 28)
            	text:setTextColor(cc.BLACK)
	            text:enableOutline(cc.WHITE,2)
	            img:addChild(text)
	            text:setPosition(cc.p(18, 18))
	            text:setTag(100)
            end  	

            local text = img:getChildByTag(100)
            local buff = self.buffTable[i]
            if buff.canOverlay then
               text:setVisible(true)
               text:setString(buff.overlayNum)--叠加的层数
            else
             	text:setVisible(false)    
            end 	
            local  file = buff.comData["state_icon"]
            img:loadTexture(file)
            img:setPosition(cc.p(754-((i-1)%7)*40,695-50*math.floor((i-1)/7.0)))	
		end
    end 
end


function BattleUIForBOSS:setHP( HP, _increase)

    if _increase==true then 
        self.nowHP = self.nowHP +HP
    elseif _increase==false then
          self.nowHP=self.nowHP -HP
    end
    
    if self.nowHP>self.totalHP then 
        self.nowHP = self.totalHP
    end
    
    if self.nowHP<0 then 
        self.nowHP = 0
    end 

    local  nowPercentage =100.0*self.nowHP/self.totalHP;
    self.hpBar:setPercent(nowPercentage)
end

