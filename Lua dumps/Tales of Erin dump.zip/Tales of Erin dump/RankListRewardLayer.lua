
--[[
	排行榜奖励暂订版
]]
require "BasicLayer"

RankListRewardLayer = class("RankListRewardLayer",BasicLayer)
RankListRewardLayer.__index = RankListRewardLayer
RankListRewardLayer.lClass = 3

function RankListRewardLayer:create(rData)
     local layer = RankListRewardLayer.new()
     layer.rData = rData
     layer:init()
     return layer
end

function RankListRewardLayer:init()
	self.sManager = self.rData["sManager"]
	self.mType = self.rData.rcvData.mType --1、战力 2、黑潮 3、魔王歼灭
    self.uiLayer = cc.Layer:create()
    
	self.itemCsb = "GuildPRankRewardItem.csb" 
	self.data = nil 
	self.descri = UITool.ToLocalization("本周结束后奖励以邮件的形式发放")

    if self.mType == 7 then 
        self.descri = UITool.ToLocalization("奖励会在活动结束时发送到玩家邮箱。")
    end 

    local node = cc.CSLoader:createNode("GuildPavilionReward.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
	self._rootCSbNode = node:getChildByTag(102) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end
    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn")
    backBtn:addTouchEventListener(touchCallBack)

 	local desinfo = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"des")
 	desinfo:setString(self.descri)

  
    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")

	self:initListView()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    if self.rData.rcvData.guildbattle then 
        self:BattlereqRankReward()
    elseif self.rData.rcvData.UltimateChallenge then
        self:UltimateChaRankReward()
    else
        self:reqRankReward()
    end
	
end

function RankListRewardLayer:initListView()
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 435.00,116)
    self.gridview.itemCreateEvent = function()
        local temp = GuildPRankRewardItem.new():init()
        temp.ClickEvent = function(item)
        end
        temp.resetDataEvent = function(item)
        end
        temp.subType = 2
        return temp
    end
end

--刷新列表列表
function RankListRewardLayer:refreshListView()
    self.gridview:setDataSource(self.data)
end
--guild_tower_reward
--返回
function RankListRewardLayer:returnBack()
   self.exist = false
   self:clearEx()
end

function RankListRewardLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--获取排行奖励
function RankListRewardLayer:reqRankReward()
    local function ReqSuccess(data)
        self.data = data.reward
        self:refreshListView()
    end
    local tempTable = {
        ["rpc"] = "ranking_reward",
        ["ranking_type"] = self.mType
    }
    self:doReq(tempTable, ReqSuccess)  
end
--需要修改的接口工会站的排行奖励  1 成员的  2 公会的
function RankListRewardLayer:BattlereqRankReward()
    local function ReqSuccess(data)
        self.data = data.reward
        self:refreshListView()
    end
    local tempTable = {
        ["rpc"] = "guildbattle_ranking_reward",
        ["ranking_type"] = self.mType
    }
    self:doReq(tempTable, ReqSuccess)  
end
--极限挑战排行榜接口
function RankListRewardLayer:UltimateChaRankReward()
    local function ReqSuccess(data)
        self.data = data.reward
        self:refreshListView()
    end
    local tempTable = {
        ["rpc"] = "ultimetecha_ranking_reward",
        ["ranking_type"] = self.mType
    }
    self:doReq(tempTable, ReqSuccess)  
end


-----todo 发送请求的放到公共里面，现在不知道放哪，暂时放着。
function RankListRewardLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

