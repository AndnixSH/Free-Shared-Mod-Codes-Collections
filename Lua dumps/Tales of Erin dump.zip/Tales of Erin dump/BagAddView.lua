
BagAddView = class("BagAddView", XUIView)
BagAddView.CS_FILE_NAME = "BagAddView.csb"
BagAddView.CS_BIND_TABLE = 
{
    lb_bagCurNum = "/i:119/i:32/i:461",
    lb_bagAddNum = "/i:119/i:32/i:462",

    btnSubtract = "/i:119/i:32/i:451/i:452",
    btnAdd = "/i:119/i:32/i:451/i:453",

    lb_changeAddNum = "/i:119/i:32/i:463",
    sp_useBg = "/i:119/i:32/i:457",
    lb_useNum = "/i:119/i:32/i:464",
    btnCancel = "/i:119/i:32/i:97",
    btnBuy = "/i:119/i:32/i:121",
}

function BagAddView:init(nCurBagNum,addSucessFunc,sDelegate)
    BagAddView.super.init(self)

    self.nCurBagNum = nCurBagNum
    self.addSucessFunc = addSucessFunc
    self.sDelegate = sDelegate

    self.nCanAddNumMin = 1
    self.nCanAddNumMax = (eq_bag.max_capacity - self.nCurBagNum)/eq_bag.per_time

    self.nAddTimes = 1

    self.btnSubtract:addClickEventListener(function ()
        self:onBtnSubtract()
    end)

    self.btnAdd:addClickEventListener(function ()
        self:onBtnAdd()
    end)

    self.btnCancel:addClickEventListener(function ()
        self:returnBack()
    end)

    self.btnBuy:addClickEventListener(function ()
        self:onBuyBagNum()
    end)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()   
    end)

    self:refreshInfo()
    self:refreshBtnState()
    
    return self
end

function BagAddView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function BagAddView:onBuyBagNum()
    local cost = user_info["gem"] + user_info["gem_r"]
    if cost - (self.nAddTimes*eq_bag.gem) >=0 then  -- 购买道具的货币 满足
        --与后端交互
        self:CallRpcBagAdd()
    else
        local strDec = UITool.ToLocalization("您的星石不足，无法进行扩充，是否前往商店购买？")
        GameManagerInst:confirm(strDec,function()
            if GameManagerInst.gameType == 2 then
                local  sData = { shopTypeIndex = 1}
                sData["sFunc"] = self.buyCallBack
                SceneManager:toShopLayer(sData) 
            end
        end)
    end

end

function BagAddView:CallRpcBagAdd()
    --
    local tempData = { 
        rpc = "eq_bag_expand",
        expand_times = self.nAddTimes,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        user_info["eq_max"] =  data["eq_max"]
        if self.addSucessFunc then
            self.addSucessFunc(self.sDelegate)
        end
        KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
        self:removeFromParentView()
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function BagAddView:buyCallBack()

end

function BagAddView:onBtnSubtract()
    if self.nAddTimes > self.nCanAddNumMin then
        self.nAddTimes = self.nAddTimes - 1
        self:refreshInfo()
        self:refreshBtnState()
    end
end

function BagAddView:onBtnAdd()
    if self.nAddTimes < self.nCanAddNumMax then
        self.nAddTimes = self.nAddTimes + 1
        self:refreshInfo()
        self:refreshBtnState()
    end
end

function BagAddView:refreshBtnState()
    if self.nAddTimes <= self.nCanAddNumMin then
        self.btnSubtract:setTouchEnabled(false)
        self.btnSubtract:setBright(false)
    else
        self.btnSubtract:setTouchEnabled(true)
        self.btnSubtract:setBright(true)
    end

    if self.nAddTimes >= self.nCanAddNumMax then
        self.btnAdd:setTouchEnabled(false)
        self.btnAdd:setBright(false)
    else
        self.btnAdd:setTouchEnabled(true)
        self.btnAdd:setBright(true)
    end
end

function BagAddView:refreshInfo()
    self.lb_bagCurNum:setString(self.nCurBagNum)
    self.lb_bagAddNum:setString("+"..self.nAddTimes*eq_bag.per_time)
    self.lb_changeAddNum:setString(self.nAddTimes*eq_bag.per_time)
    self.lb_useNum:setString(self.nAddTimes*eq_bag.gem)
end











