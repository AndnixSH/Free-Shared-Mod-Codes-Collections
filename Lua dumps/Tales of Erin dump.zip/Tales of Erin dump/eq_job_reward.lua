eq_job_reward = {} 
eq_job_reward[1] = {
    atk_rate = 2,
    def_rate = 4,
} 
eq_job_reward[11] = {
    atk_rate = 4,
    def_rate = 2,
} 
eq_job_reward[12] = {
    atk_rate = 4,
    def_rate = 2,
} 
eq_job_reward[21] = {
    atk_rate = 2,
    def_rate = 2,
} 