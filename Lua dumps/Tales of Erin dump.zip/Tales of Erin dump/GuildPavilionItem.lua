--[[GuildPavilionItem.lua
	GuildPavilionItem.csb
]]

GuildPavilionItem = class("GuildPavilionItem", XUICellView)
GuildPavilionItem.CS_FILE_NAME = "GuildPavilionItem.csb"
GuildPavilionItem.CS_BIND_TABLE = 
{
    rootPanel = "/s:panel",
    touchPanel = "/s:panel"
}

function GuildPavilionItem:init(...)
    GuildPavilionItem.super.init(self,...)
    self.isSelect = false
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)
    return self
end

--重置UI
function GuildPavilionItem:onResetData()
    if not self._data then return end
    local data = self._data
    local rank = data.rank_num
    local root = self.rootPanel
    --name
    local title = ccui.Helper:seekWidgetByName(root,"title")
    title:setString(data.name)
    --icon head
    local icon = ccui.Helper:seekWidgetByName(root,"img_icon")

    local iconId =tonumber(data.head)
    icon:loadTexture(hero[iconId].hero_bat_icon)

    --score
    local lab_score = ccui.Helper:seekWidgetByName(root,"lab_score")
    lab_score:setString(UITool.ToLocalization("积分 ")..data.score)
    --level
    local lab_level = ccui.Helper:seekWidgetByName(root,"lab_level")
    lab_level:setString(string.format(UITool.ToLocalization("等级 %d"),data.rank))

    --rank icon 
    local rankImgs = {"ghdg_ui_003.png","ghdg_ui_004.png","ghdg_ui_005.png"}
    local imgRank = ccui.Helper:seekWidgetByName(root,"rank_img")
    local labRank = ccui.Helper:seekWidgetByName(root,"rank_lab")
    if rank>0 and rank <4 then 
    	imgRank:loadTexture("n_UIShare/guild/guild_pavilion/"..rankImgs[rank])
		labRank:setVisible(false)
        imgRank:setVisible(true)
    else 
    	imgRank:setVisible(false)
        labRank:setVisible(true)
    	labRank:setString(rank)
    end 

    --bg todo 
    local item_bg = ccui.Helper:seekWidgetByName(root,"item_bg")
    if data.uid == user_info["id"] then 
        item_bg:loadTexture("n_UIShare/guild/guild_pavilion/ghdg_ui_015.png")
        title:setColor(cc.c3b(255,237,120))
    else 
        item_bg:loadTexture("n_UIShare/guild/guild_pavilion/ghdg_ui_002.png")
        title:setColor(cc.c3b(255,255,255))
    end 
end
