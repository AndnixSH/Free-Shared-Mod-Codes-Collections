AwakenNum ={}
AwakenNum[1] = { 
    {lvmax = 40,gem = 0,gold = 500 },
    {lvmax = 60,gem = 0,gold = 500 },
    {lvmax = 80,gem = 0,gold = 500 },
    {lvmax = 100,gem = 0,gold = 500 },
}
AwakenNum[2] = { 
    {lvmax = 40,gem = 0,gold = 500 },
    {lvmax = 60,gem = 0,gold = 500 },
    {lvmax = 80,gem = 0,gold = 500 },
    {lvmax = 100,gem = 0,gold = 500 },
}
AwakenNum[3] = { 
    {lvmax = 40,gem = 0,gold = 500 },
    {lvmax = 60,gem = 0,gold = 500 },
    {lvmax = 80,gem = 0,gold = 500 },
    {lvmax = 100,gem = 0,gold = 500 },
}
AwakenNum[4] = { 
    {lvmax = 40,gem = 0,gold = 500 },
    {lvmax = 60,gem = 0,gold = 500 },
    {lvmax = 80,gem = 0,gold = 500 },
    {lvmax = 100,gem = 0,gold = 500 },
}
AwakenNum[5] = { 
    {lvmax = 40,gem = 0,gold = 500 },
    {lvmax = 60,gem = 0,gold = 500 },
    {lvmax = 80,gem = 0,gold = 500 },
    {lvmax = 100,gem = 0,gold = 500 },
}