challenge_limit_achi_conf={} 
challenge_limit_achi_conf[1] = {
        id= 1,
        achi_name= "绝望的片影",
        achi_desc= "创建20场极限挑战并完成",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[2] = {
        id= 2,
        achi_name= "不屈的斗志",
        achi_desc= "创建50场极限挑战并完成",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[3] = {
        id= 3,
        achi_name= "反击的狼烟",
        achi_desc= "创建100场极限挑战并完成",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[4] = {
        id= 4,
        achi_name= "百战精兵",
        achi_desc= "完成100场极限挑战",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[5] = {
        id= 5,
        achi_name= "历战强者",
        achi_desc= "完成200场极限挑战",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[6] = {
        id= 6,
        achi_name= "死战不退",
        achi_desc= "完成300场极限挑战",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[7] = {
        id= 7,
        achi_name= "鏖战无双",
        achi_desc= "完成500场极限挑战",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[8] = {
        id= 8,
        achi_name= "未能击穿",
        achi_desc= "极限挑战单轮累计获得3000点积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[9] = {
        id= 9,
        achi_name= "轻微破损",
        achi_desc= "极限挑战单轮累计获得5000点积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[10] = {
        id= 10,
        achi_name= "沉重伤痕",
        achi_desc= "极限挑战单轮累计获得8000点积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[11] = {
        id= 11,
        achi_name= "猛烈重创",
        achi_desc= "极限挑战全轮累计获得10000点积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[12] = {
        id= 12,
        achi_name= "贯穿破坏",
        achi_desc= "极限挑战全轮累计获得20000点积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[13] = {
        id= 13,
        achi_name= "摧枯拉朽",
        achi_desc= "极限挑战全轮累计获得35000点积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[14] = {
        id= 14,
        achi_name= "无息守望",
        achi_desc= "极限挑战期间，每轮都获得个人积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[15] = {
        id= 15,
        achi_name= "终结末日之人",
        achi_desc= "个人排行达到前100名",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[16] = {
        id= 16,
        achi_name= "撕裂绝望之人",
        achi_desc= "个人排行达到前200名",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[17] = {
        id= 17,
        achi_name= "抱持希冀之人",
        achi_desc= "个人排行达到前500名",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[18] = {
        id= 18,
        achi_name= "焚魔之火",
        achi_desc= "使用火属性角色在第一轮中单场达到60积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[19] = {
        id= 19,
        achi_name= "净污之水",
        achi_desc= "使用水属性角色在第二轮中单场达到60积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[20] = {
        id= 20,
        achi_name= "驱敌之风",
        achi_desc= "使用风属性角色在第三轮中单场达到60积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[21] = {
        id= 21,
        achi_name= "明澈之暗",
        achi_desc= "使用暗属性角色在第四轮中单场达到60积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[22] = {
        id= 22,
        achi_name= "审判之光",
        achi_desc= "使用光属性角色在第五轮中单场达到60积分",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
challenge_limit_achi_conf[23] = {
        id= 23,
        achi_name= "超越界限之人",
        achi_desc= "极限挑战第六轮排行达到前50名",
        achi_icon= "icons/achiv/cjxt_001.png",

} 