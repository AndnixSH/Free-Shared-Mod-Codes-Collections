--大型战斗
--[[
2018.6.6
新版本多人战 
g_channel_control.use_NewMulPassLayer 开关控制显示新旧版本
1、求援列表加入分签功能
2、加入快速战斗功能
todo：
其他服全部换成新版之后，需删除旧的
    MulPassLayer.lua
    MulPassLayer.csb
]]
require "BasicLayer"

require "actPass"

MulPassLayerNew = class("MulPassLayerNew",BasicLayer)
MulPassLayerNew.__index = MulPassLayerNew
MulPassLayerNew.lClass = 1

--初始化地图数据
function MulPassLayerNew:init()
    self.state = 1  -- 1 求援  2 创建列表 3加入
    self.scrollView = nil 
    self.click_point = 0
    self.tollgate = {}
    self.create_level_type =  2 ----创建列表关卡类型 水、火、凤、光、暗 默认显示2（火）
    --user_info["mul_help_type"]存储当前求援类型
    self.help_level_type = user_info["mul_help_type"] or 6   ----求援列表关卡类型 水、火、凤、光、暗、全部、活动 默认显示6全部

    self.sManager.menuLayer:hiddenUserInfo(false)
    self.sManager.menuLayer:RefshTopBar()

    self.isTouchRewerd = false
    local node =cc.CSLoader:createNode("MulBattleLayerNew.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    local panel = node:getChildByTag(1)
    local touchEventTable = {
     [101] = self.refreshList,
     [102] = self.refreshList,
     [103] = self.refreshList,
     [23] = self.menuCallBack,
     [206] = self.returnBack,
    }

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            local tag = sender:getTag()
            if tag==101 then
                self:refreshList(1)     ---求援列表
            elseif tag ==102 then
                self:refreshList(2)     ---创建列表
            elseif tag==103 then
                self:refreshList(3)     ---输入参战码
            elseif tag==204 then        ---刷新当前列表
                self:refreshList(self.state) 
            elseif tag==58 then         ---快速开始战斗
                self:reqQuickBattle()
            else
                touchEventTable[sender:getTag()](self)
            end
        end
    end 

    local panel_1 = node:getChildByTag(1)

    for i=1,3 do
      local button = ccui.Helper:seekWidgetByTag(panel_1,100+i)
      button:addTouchEventListener(touchCallBack)
    end

    local panel_3 = node:getChildByTag(2)
    --刷新按钮
    local button = ccui.Helper:seekWidgetByTag(panel_3,204)
    button:addTouchEventListener(touchCallBack)
    --快速战斗
    local quickBtn = ccui.Helper:seekWidgetByTag(panel_3,58)
    quickBtn:addTouchEventListener(touchCallBack)
    local button_1 = ccui.Helper:seekWidgetByTag(panel_3,206)
    button_1:addTouchEventListener(touchCallBack)
    button_1:setEffectType(3)
    self.scrollView = ccui.Helper:seekWidgetByTag(panel_3,202)
    self.scrollView:setScrollBarEnabled(true)
    self.scrollView:setScrollBarWidth(10)
    self.scrollView:setScrollBarColor(cc.c3b(255, 255, 255))
    self.scrollView:setScrollBarOpacity(225*0.5)
    self.scrollView:setScrollBarPositionFromCorner(cc.p(2,2))
    self.scrollView:setVisible(false)
    self.scrollView:setTouchTotalTimeThreshold(0.1)
    local panel_4 = panel_3:getChildByTag(203)
    panel_4:setVisible(false)
  
    local button_3 = ccui.Helper:seekWidgetByTag(panel_3,23)
    button_3:addTouchEventListener(touchCallBack)

    --点击说明按钮
    local function touchGuideBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:showGuidePicLayer()
        end
    end 
    local guideButton = ccui.Helper:seekWidgetByName(panel_3,"Button_guide")
    guideButton:addTouchEventListener(touchGuideBtnEvent)

    --首次进入 显示大型战斗的说明 key 统一用类名吧
    -- if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."MulPassLayerNew_1") == 0 then
    --     cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."MulPassLayerNew_1", 1)
    --     self:showGuidePicLayer()
    -- end
    --首次大型战斗
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.MoreBattle) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.MoreBattle, 1)
    end
    ---创建列表分签
    self.atbRoot = ccui.Helper:seekWidgetByName(panel_3,"Atb_root")
    ---求援列表分签
    self.atbRootHelp = ccui.Helper:seekWidgetByName(panel_3,"Atb_root_help")

    self:initBossAtbBtns(1)
    self:initBossAtbBtns(2)
    ---输入框

    self.inputText =  ccui.Helper:seekWidgetByName(panel_4,"input")
    --self.inputText:setPlaceHolder("请输入名字")
    self.inputText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.inputText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    self.inputText:setTouchEnabled(false)

    self.inputText:setTouchEnabled(false)
    self.inputPanel =  ccui.Helper:seekWidgetByName(panel_4,"input_top")
    self.inputPanel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:popInputView()
        end
    end)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    ---显示求援列表
    self:refreshList(1)
    if g_channel_control.quickMacroabled == true then 
        QuickMacroTools:getInstance():start(1)
    end 
end 

function MulPassLayerNew:popInputView()
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  function(self,text)
        self.inputText:setString(text)
    end
    rcvData["defalutStr"] = self.inputText:getString()
    rcvData["maxLength"] = 40
    SceneManager:toInputModelLayer(rcvData)
end

---初始化boss属性按钮
function MulPassLayerNew:initBossAtbBtns(_type)
    --水、火、风、光、暗
    local function touchAtbBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if _type == 1 then --求援
                self.help_level_type = sender.myTag
                user_info["mul_help_type"] = self.help_level_type
                self:updateSubList() 
            else
                if  sender.myTag == 4 and g_channel_control.mulPassLayer_boss_guang ~= true  then --光boss暂时未开发
                    MsgManager:showSimpMsg(UITool.ToLocalization("暂未开放，敬请期待"))
                else 
                    self.create_level_type = sender.myTag
                    self:updateSubList() 
                end 
            end 
        end
    end
    local numMax =  nil
    local rootNode = nil
    if _type == 1 then 
        numMax = 7
        rootNode = self.atbRootHelp
    else 
        numMax = 5
        rootNode = self.atbRoot
    end 
    for i=1,numMax do
        local btn = ccui.Helper:seekWidgetByName(rootNode,"touch_"..i)
        btn.myTag = i
        btn:addTouchEventListener(touchAtbBtnEvent)
    end
end

--根据关卡条目类型，刷新当前创建列表
function MulPassLayerNew:updateSubList()
    local numMax =  nil
    local rootNode = nil
    local nowType = nil
    if self.state == 1 then 
        numMax = 7
        nowType = self.help_level_type
        rootNode = self.atbRootHelp
    else 
        numMax = 5
        nowType = self.create_level_type
        rootNode = self.atbRoot
    end 
    --刷新按钮状态
    for i=1,numMax do
        local showbtn = ccui.Helper:seekWidgetByName(rootNode,"btn_atb_"..i)
        local touchBtn = ccui.Helper:seekWidgetByName(rootNode,"touch_"..i)
        if i == nowType  then 
            showbtn:setTouchEnabled(false)
            showbtn:setBright(false)
            touchBtn:setTouchEnabled(false)
        else 
            showbtn:setTouchEnabled(true)
            showbtn:setBright(true)
            touchBtn:setTouchEnabled(true)
        end 
    end
    if self.state == 1 then 
        self:reqMultiList()
    else 
        self:refreshSubCreateList()
    end
end

function MulPassLayerNew:showGuidePicLayer()
    local data = {}
    data.pictures = {
          "uifile/n_UIShare/newGuide/picture_guide/xsjx_drz_001.png",
      }
    self.sManager:toGuidePictureLayer(data)
end
--[[
    1.求援列表 
    2.创建列表
    3.输入参战码
]]
function MulPassLayerNew:refreshList(select_state)
    select_state = select_state or self.state
    self.state = select_state
    self.inputText:setString("")
    print("当前状态++++++"..self.state)
    local node = self.uiLayer:getChildByTag(1)
    local panel_1 = node:getChildByTag(1)
    local panel_3 = node:getChildByTag(2)
    local panel_4 = panel_3:getChildByTag(203)
    local button = panel_3:getChildByTag(204)
    local quickBtn = panel_3:getChildByTag(58)
    for i=1,3 do
      local button = ccui.Helper:seekWidgetByTag(panel_1,100+i)
      if i==self.state then
          button:setTouchEnabled(false)
          button:setBright(false)
      else 
          button:setTouchEnabled(true) 
          button:setBright(true)
      end
    end
    if self.state==1 then
        self:updateSubList()
        panel_4:setVisible(false)
        button:setVisible(true)
        quickBtn:setVisible(true)
        self.atbRoot:setVisible(false)
        self.atbRootHelp:setVisible(true)
     elseif self.state==2 then
        self:reqCreatList()
        panel_4:setVisible(false)   
        button:setVisible(false)  
        quickBtn:setVisible(false)  
        self.atbRoot:setVisible(true)
        self.atbRootHelp:setVisible(false)
     elseif self.state==3 then 
        panel_4:setVisible(true)
        button:setVisible(false)
        quickBtn:setVisible(false)
        self.scrollView:setVisible(false)
        self.atbRoot:setVisible(false)
        self.atbRootHelp:setVisible(false)
    end 
end

function MulPassLayerNew:refreshScrollView()
    self.scrollView:removeAllItems()
    self.scrollView:setVisible(false)
   
    local node = self.uiLayer:getChildByTag(1)
    local panel_1 = node:getChildByTag(1)
    local panel_3 = node:getChildByTag(2)
    
    if #self.tollgate > 0 then
        self.scrollView:setVisible(true)
    else
        self.scrollView:setVisible(false)
    end
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
            if  self.isTouchRewerd then --点击掉落查看直接返回
                do return end 
            end

            print("select child index = ",sender:getCurSelectedIndex())
            self.click_point = sender:getCurSelectedIndex()+1

            if self.state==1 then     --求援列表加入战斗
                self:helpToReadyLayer()
            elseif self.state==2 then --创建列表加入战斗
                ---说明：不确定为什么nil了。需要加个处理措施，写到本地吧，找到原因再处理 2017.0816
                if self.tollgate[self.click_point]["multi"] == nil then 
                    local errorStr = "MulPassLayerNew click_point:"..self.click_point.."  tollgate:"
                    local cjson = require "cjson"
                    local mydata =  cjson.encode(self.tollgate)
                    self:saveErrorLog(errorStr..mydata)
                    self:returnBack()
                    do return end 
                end 
                local totalValue = self.tollgate[self.click_point]["multi"]["total"] or 0
                local nowValue = self.tollgate[self.click_point]["multi"]["now"] or 0
                local nums = totalValue - nowValue
                local level_state = self.tollgate[(self.click_point)]["level_state"]
                if level_state == 2 then --加入进行中的
                    self:createToReadyLayer()
                else --创建
                    if nums >0 then
                        local msg = UITool.ToLocalization("今日还剩余挑战次数:")..nums
                        MsgManager:showSimpMsgWithCallFunc(msg,self,self.createToReadyLayer)
                    else
                        local msg = UITool.ToLocalization("你的挑战次数已用完")
                        MsgManager:showSimpMsg(msg)
                    end 
                end                          

            end        
        end
    end

    local layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    if self.state==1 then
        local  list_item = cc.CSLoader:createNode("mulpass_item.csb")
        local  item_1 = list_item:getChildByTag(174)
        local item_c = item_1:clone()
        item_c:setPosition(cc.p(0,0))
        item_c:setName("item")
        layout_list:addChild(item_c)
        layout_list:setContentSize(610,150)
        layout_list:setTouchEnabled(true) 
    elseif self.state==2 then
        local  list_item = cc.CSLoader:createNode("pass_item.csb")
        local  item_1 = list_item:getChildByTag(174)
        local item_c = item_1:clone()
        item_c:setPosition(cc.p(0,0))
        item_c:setName("item")
        layout_list:addChild(item_c)
        layout_list:setContentSize(610,160)
        layout_list:setTouchEnabled(true) 
    end
    local itme_info = layout_list:getChildByName("item")
    self.scrollView:setItemModel(layout_list)
    self.scrollView:addEventListener(listViewEvent)
end

--获取救援 
function MulPassLayerNew:reqMultiList()
    local function reiceAreaCallBack(data)
        print("收到事件点结果 不需要参数的")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end
        self.tollgate = {}
        self.tollgate = t_data["data"]["multi_list"]
        self:refreshScrollView()
        self:refreshHelpList()

        if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.MoreBattle) then 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.MoreBattle)
        end 
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    self.open_count = 0
    local tempTable = {
        ["rpc"] = "multi_sort_list",
        ["sort_type"] = self.help_level_type
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

     local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
     ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceAreaCallBack, cc.Handler.CALLFUNC);    
     dbhttp:creatHttpRequestWithURL(mydata,3)

end 
--战斗结束刷新数据
function MulPassLayerNew:SMapRefresh()
    NoticeManager:startNotice()
    self:refreshList(self.state)
end
--获取某一事件点详细信息  关卡列表
function MulPassLayerNew:reqCreatList()
    local function reicePointCallBack(data)
        print("收到事件点结果 关卡列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.create_tollgate = {}
        self.create_tollgate = t_data["data"]["multi_list"] or {}
        self:refreshScrollView()
        self:updateSubList()

        XbTriggerGuideManager:finishGuide(TriggerGuideConfig.MoreBattle, self)
        
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "multi_create_list",
        ["boss_atb"] = 1   --boss 属性
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

---根据当前的关卡类型，刷新关卡列表
function MulPassLayerNew:refreshSubCreateList()
    self.tollgate = {}

    local len = #self.create_tollgate or 0
    for i=1,len do
        local battleData = self.create_tollgate[i]
        if battleData.level_type == self.create_level_type then 
            self.tollgate[#self.tollgate+1] = battleData
        end 
    end
    self:refreshCreateList()
end

function MulPassLayerNew:refreshCreateList()
    --背景
    UITool.refreshPassList(self,"level_id")
end
--查看掉落或者魔王情报
function MulPassLayerNew:toMapItemDropsLayer(data)
    local rcvData = {}
    rcvData["data"] =  data
    ---todo 判断类型是普通掉落还是魔王情报
    if data.level_is_boss == 1 then 
         self.sManager:toBossInformationLayer(rcvData)
    else 
        self.sManager:toMapItemDropsLayer(rcvData)
    end 
end
--求援列表
function MulPassLayerNew:refreshHelpList()
    --这个type是判断状态的 。 # 类型: 0-野人, 1-公会, 2-参战中  "battle_type": 0,
    --todo参战中或者
    --添加活动期间图标
    local function addActInTimeIcon( actInTimeArr,image )
      -- body
      local actArr = actInTimeArr or {}
      local actNum = #actArr
      for c = 1,actNum do
          local actIndex = actArr[c]
          if actIndex ~= nil and image ~= nil then
             local imgIcon = double_drop_conf[actIndex]["icon_p"]
             if imgIcon ~= nil then
                image:setVisible(true)
                image:loadTexture("n_UIShare/ditu/CombatList/"..imgIcon..".png")
             end
          end
      end
    end


    --活动排序，多个一样的活动同时开启优先显示
    local function actInTimeSort( list )
      -- body
      local act_list = list or {}
      table.sort(act_list, function(a, b)
                  return a < b
              end)
      return act_list
    end

    local function getBg(type)
        if type == 0 then   --野人
             return "n_UIShare/ditu/CombatList/zdlb_ui_004.png"
        elseif type ==1 then  --工会
            return "n_UIShare/ditu/CombatList/zdlb_ui_004.png"
        elseif type ==2 then  --参战中
             return "n_UIShare/ditu/CombatList/zdlb_ui_009.png"
        end
    end
    local function getMaskBg(type)
        if type == 0 then   --野人
             return ""
        elseif type ==1 then  --工会
            return "n_UIShare/ditu/CombatList/zdlb_ui_007.png"
        elseif type ==2 then  --参战中
             return "n_UIShare/ditu/CombatList/zdlb_ui_008.png"
        end
    end

    local function getTime(time)
        local hour = math.floor(time/3600);
        local minute = math.fmod(math.floor(time/60), 60)
        local second = math.fmod(time, 60)
        if string.len(hour) == 1 then  
            hour = "0"..hour  
        end    
        if string.len(minute) == 1 then  
            minute = "0"..minute  
        end  
        if string.len(second) == 1 then  
            second = "0"..second  
        end 
        local rtTime = string.format("%s:%s:%s", hour, minute, second)
        return rtTime
    end

    local tnums = #self.tollgate
    self.scrollView:setInnerContainerSize(cc.size(self.scrollView:getContentSize().width,200*tnums))

     for i=1,#self.tollgate do
        local double_drop_list = self.tollgate[i]["double_drop_list"]
        local act_mark_list = actInTimeSort(double_drop_list)
        --防止数据为空，如果level_id为nil或者pLevelData为nil，就不执行
        local level_id = self.tollgate[i]["level_id"]
        if level_id == nil then
            print("error: MulPassLayerNew:refreshHelpList()  level_id == nil")
            break;
        end
        local pLevelData  = battlePass[level_id] or actPass[level_id]
        if pLevelData == nil then
            print("error: MulPassLayerNew:refreshHelpList()  pLevelData == nil")
            break;
        end

        self.scrollView:pushBackDefaultItem()
        print("添加默认Item"..i)
        local item = self.scrollView:getItem(i - 1)
        local itme_info = item:getChildByName("item")
       

        local dataTable = {
           [1] =  getBg(self.tollgate[i]["battle_type"]), --创建者类型
           [20] = getMaskBg(self.tollgate[i]["battle_type"]),
           [30] = pLevelData["level_icon"],  --图标
           --[31] = getType(battlePass[self.tollgate[i]["level_id"]]["level_lv"]),  --类型 story 
           [102] = UITool.getUserLanguage(pLevelData["level_name"]),--pLevelData["level_name"], --名字
           [1022] = UITool.getUserLanguage(pLevelData["level_num"]),--pLevelData["level_num"],--第几章第几话
           [103] = pLevelData["commend_lv"], --lv
           [101] = self.tollgate[i]["need_gold"],
           [82] = self.tollgate[i]["member_num"],--参加人数当前
           [81] = self.tollgate[i]["creator"],--创建者
           [79] = self.tollgate[i]["BOSS_HP"],--血量
           [235] = pLevelData["level_atb"],--关卡属性 
           [104] = getTime(self.tollgate[i]["level_time"]*60)--剩余时间 这地方是以分钟为单位，另一个区表的是以事件为单位
        }
        --求援列表背景
        local bgImageView = ccui.Helper:seekWidgetByTag(itme_info,20)
        if bgImageView ~= nil then
            bgImageView:loadTexture(dataTable[1])
        end
        --工会是黄  自己是红 野人不显示
        local bgImageView = ccui.Helper:seekWidgetByTag(itme_info,301)

        if bgImageView ~= nil then 
            if dataTable[20] =="" or dataTable[20] ==nil then
            bgImageView:setVisible(false)
            else
            bgImageView:loadTexture(dataTable[20])
             end 
        end    

        
      
        local iconImageView = ccui.Helper:seekWidgetByTag(itme_info,30)
        iconImageView:loadTexture(dataTable[30])
        --关卡奖励 
        local function rewardTouchCallBack(sender,eventType)
            if eventType == TOUCH_EVENT_BEGAN then
                self.isTouchRewerd = true
            end
            if eventType == TOUCH_EVENT_ENDED then
                self.isTouchRewerd = false 
                local data = {}
                data.title = UITool.getUserLanguage(pLevelData["level_name"])--pLevelData["level_name"]
                data.rewards = pLevelData["drop_reward"]
                data.level_is_boss = pLevelData["level_is_boss"]
                data.level_id = self.tollgate[i]["level_id"]
                self:toMapItemDropsLayer(data)
            end
        end 
        local rewardBtnImg = ccui.Helper:seekWidgetByTag(itme_info,50)
        rewardBtnImg:setTouchEnabled(true)
        rewardBtnImg:addTouchEventListener(rewardTouchCallBack)
        if pLevelData["level_is_boss"] == 1 then 
            rewardBtnImg:loadTexture("n_UIShare/bossAtbSort/cxbh_ui_003.png")
            rewardBtnImg:setUnifySizeEnabled(true)
        end 

        local ap = ccui.Helper:seekWidgetByTag(itme_info,101)
        ap:setString(dataTable[101])

        if self.tollgate[i]["battle_type"]==2 then
           ap:setVisible(false)
        end

        local title = ccui.Helper:seekWidgetByTag(itme_info,102)
        title:setString(dataTable[102])
        --主标题为 来自XXX的求援
        local title2str = string.format(UITool.ToLocalization("来自%s的求援"),dataTable[81])
        local title2 = ccui.Helper:seekWidgetByTag(itme_info,1022)
        title2:setString(title2str)
        --推荐等级
        local Lvtitle = ccui.Helper:seekWidgetByTag(itme_info,103)
        Lvtitle:setString(dataTable[103])
        --剩余时间
        local times = ccui.Helper:seekWidgetByTag(itme_info,104)
        times:setString(dataTable[104])
        --boss血量
        local hpLoading = ccui.Helper:seekWidgetByTag(itme_info,302)
        hpLoading:setPercent(dataTable[79])
        --参战人数
        local nums = ccui.Helper:seekWidgetByTag(itme_info,303)
        local numstr = string.format(UITool.ToLocalization("%s 参战"),dataTable[82])
        nums:setString(numstr)
        --关卡属性
        local elementView = ccui.Helper:seekWidgetByTag(itme_info,235)
        elementView:loadTexture(ATB_Icon[dataTable[235]])
        --活动标签
        local actMarkIcon = ccui.Helper:seekWidgetByTag(itme_info,73)
        actMarkIcon:setVisible(false)
        addActInTimeIcon(act_mark_list,actMarkIcon)
    end 
end
--创建列表中去战前准备页面
--多人战创建列表点击进去站前准备
--创建 消耗ap ，再次进入不消耗AP
function  MulPassLayerNew:createToReadyLayer()
    --如果是加入的话是id 创建的话是battle_id
    self.sData = {}
    local level_id = self.tollgate[self.click_point]["level_id"]
    local pLevelData  = battlePass[level_id] or actPass[level_id]

    self.sData["name"] = UITool.getUserLanguage(pLevelData["level_name"])--pLevelData["level_name"]
    self.sData["lv"] = pLevelData["commend_lv"]
    self.sData["level_id"] = level_id
    local state = self.tollgate[(self.click_point)]["level_state"]

    if state == 2 then --加入多人战
        self.sData["b_id"] = self.tollgate[(self.click_point)]["id"]
        self.sData["mode"] = "mutable1" --join
        self.sData["ap"] = 0
    else
        self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
        self.sData["mode"] = "mutable" --create
        self.sData["ap"] = self.tollgate[self.click_point]["need_ap"]
    end
    self.sManager:toReadyLayer(self.sData) 
end
--求援列表加入战斗（加入自己的求援或者别人的求援两种情况）
--自己的求援，不消耗金币
--如果是参加中的战斗才会出现1和2
function MulPassLayerNew:helpToReadyLayer()
    --"boss_state": 0,  # 0 进行中 1 成功 2 失败
    local boss_state =  self.tollgate[self.click_point]["boss_state"] 
    if boss_state == 0 then      --可以打
        self.sData = {}
        local level_id = self.tollgate[self.click_point]["level_id"]
        if level_id == nil then
            print("error: MulPassLayerNew:helpToReadyLayer()  level_id == nil")
            return
        end
        local pLevelData  = battlePass[level_id] or actPass[level_id]
        if pLevelData == nil then
            print("error: MulPassLayerNew:helpToReadyLayer()  pLevelData == nil")
            return;
        end
        self.sData["level_id"] = level_id
        self.sData["name"] = UITool.getUserLanguage(pLevelData["level_name"])--pLevelData["level_name"]
        self.sData["lv"] =  pLevelData["commend_lv"]
        self.sData["b_id"] = self.tollgate[self.click_point]["id"]
        self.sData["mode"] = "mutable1"
        if self.tollgate[self.click_point]["battle_type"] == 2 then
            self.sData["gold"] = 0
        else
            self.sData["gold"] = self.tollgate[self.click_point]["need_gold"]
        end 
        self.sManager:toReadyLayer(self.sData)     
    elseif boss_state == 1 then  --成功
        local sData = {}
        sData["mode"] = 2
        SceneManager:toBattleEndLayer(sData)
    else--失败
        local sData = {}
        sData["type"] = 2 -- 1、单人 2、BOSS
        sData["mode"] = 2 -- 1、单人战斗  2、多人战斗
        SceneManager:toBattleFailedLayer(sData)
    end 

end

function MulPassLayerNew:menuCallBack()

    local function reicePointCallBack(data)
        print("收到事件点结果 关卡列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.sData = {}

        local level_id = t_data["data"]["multi_info"]["level_id"]
        local pLevelData  = battlePass[level_id] or actPass[level_id]

        self.sData["level_id"] = level_id
        self.sData["name"] = UITool.getUserLanguage(pLevelData["level_name"])--pLevelData["level_name"]
        self.sData["lv"] = pLevelData["commend_lv"]
        self.sData["b_id"] = t_data["data"]["multi_info"]["id"]
        self.sData["ap"] = t_data["data"]["multi_info"]["ap"]
        self.sData["gold"] = t_data["data"]["multi_info"]["need_gold"]
        self.sData["mode"] = "mutable1"
        if self.sManager ~= nil then
            self.sManager:toReadyLayer(self.sData)
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "multi_join_info",
        ["id"] = self.inputText:getString(),
    }
    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--快速开始战斗
function MulPassLayerNew:reqQuickBattle()
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
             MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]), self, self.refreshList)
            return
        end
        local sData = {}
        sData["level_id"] = t_data["data"]["multi_info"]["level_id"]
        sData["b_id"] = t_data["data"]["multi_info"]["id"]
        sData["team_id"] = t_data["data"]["team_id"]
        sData["team"] = t_data["data"]["team"]

        AudioManager:shareDataManager():playMusic(lua_musci["zdks"],1, false)
        
        self:quickBattle(sData)
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "multi_quick_join",
        ["sort_type"] = self.help_level_type
    }

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function MulPassLayerNew:quickBattle(_sData)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end

        local boss_state = t_data["data"]["boss_state"] or 0
        boss_state = tonumber(boss_state)
        if boss_state == 1 then 
            local sData = {}
            sData["mode"] = 2
            SceneManager:toBattleEndLayer(sData)
            return
        end 
        if boss_state == 2 then 
            local sData = {}
            sData["type"] = 2 -- 1、单人 2、BOSS
            sData["mode"] = 2 -- 1、单人战斗  2、多人战斗
            SceneManager:toBattleFailedLayer(sData)
            return
        end 
   
        if t_data["data"]["warning"]~=nil then
           print("warning is="..t_data["data"]["warning"])
        else
            if t_data["data"]["ap"]~=nil then
                user_info["ap"] = t_data["data"]["ap"]
            end
            if t_data["data"]["gold"]~=nil then
               user_info["gold"] = t_data["data"]["gold"]
            end
            self.sManager.menuLayer:RefshTopBar()
            GameManagerInst:blackScreenOn()
            G_STAGE_TYPE = 2
            if g_channel_control.battleLua then
                PushBattleScene(t_data["data"])
            else
                cc.MyHttpHelper:shareMyHttpHelper():startGame() 
            end 
            KeyboardManager:setbattleState(true)
            UITool.delayTask(0.1,function ( ... )
            local scene = cc.Director:getInstance():getRunningScene()
            dump(scene, "ReadyLayer:runningScene    22222")
                if scene then
                    KeyboardManager:bindingAndroidKeyboard(scene,3)
                end
            end)
        end
    end

    NoticeManager:stopNotice()
    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    battle_data_cache.level_id = _sData["level_id"] or 0
    local tempTable = {
        ["rpc"] = "multi_join",
        ["id"] = _sData["b_id"],
        ["team_id"] = tostring(_sData["team_id"]),
        ["team"] = _sData["team"],
    }
    local str = self:checkSk(_sData["team_id"], _sData["team"])
    tempTable["check_sk"] = str
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    if g_channel_control.battleLua then
        dbhttp:creatHttpRequestWithURL(mydata,3)
    else    
        dbhttp:creatHttpRequestWithURL(mydata,105)
    end
end

function MulPassLayerNew:checkSk(team_id,team)
     local teamData = team["team"]
     local tablesk = {}
     for i = 1,#teamData  do
        if teamData[i]~=nil and teamData[i]["id"]~= "0" then
            local sk1  = teamData[i]["active_sk"][1]
            local sk2 =  teamData[i]["active_sk"][2]
            
            local nowD1 = 0;
            local nowD2 = 0;
            for m = 1,  #skill[tonumber(sk1)]["skill_attack_hit"]do
                  nowD1 =nowD1+ skill[tonumber(sk1)]["skill_attack_hit"][m]["hit_dmg"]
            end
            tablesk[tostring(sk1)] = {skill[tonumber(sk1)]["skill_dmg"],skill[tonumber(sk1)]["skill_cd"],nowD1}
           
            for m = 1,  #skill[tonumber(sk2)]["skill_attack_hit"]do
                  nowD2 =nowD2+ skill[tonumber(sk2)]["skill_attack_hit"][m]["hit_dmg"]
            end
             tablesk[tostring(sk2)] = {skill[tonumber(sk2)]["skill_dmg"],skill[tonumber(sk2)]["skill_cd"],nowD2}
       end
    end
    local skID =  math.random(20024,20095)
    local nowD = 0;
    for m = 1,  #skill[tonumber(skID)]["skill_attack_hit"]do
              nowD =nowD+ skill[tonumber(skID)]["skill_attack_hit"][m]["hit_dmg"]
        end
    tablesk[tostring(skID)] = {skill[tonumber(skID)]["skill_dmg"],skill[tonumber(skID)]["skill_cd"],nowD}

    return tablesk     
end

--返回
function MulPassLayerNew:returnBack()
    print("地图界面 点击返回")
    if g_channel_control.quickMacroabled == true then 
        QuickMacroTools:getInstance():backhome()
    end       
    self.sManager.menuLayer.pNums = 4
    self.sManager:removeFromNavNodes(self)
    self.backFunc(self.sDelegate)
    self.exist = false
    self:clearEx()
end

function MulPassLayerNew:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--todo
function MulPassLayerNew:setShow( )
  -- body
    self.sManager.menuLayer:hiddenUserInfo(false)
    self.sManager.menuLayer:RefshTopBar()
end

function MulPassLayerNew:create(rData)
    local  layer = MulPassLayerNew.new()
    layer.rData = rData
    layer.titleNum = 12
    layer.sManager = layer.rData["sManager"]
    layer.backFunc = layer.rData["rcvData"]["sFunc"]
    layer.sDelegate = layer.rData["rcvData"]["sDelegate"]
    layer.uiLayer = cc.Layer:create()
    layer:init()
    return layer
end
function MulPassLayerNew:saveErrorLog(saveStr)
    local path = cc.FileUtils:getInstance():getWritablePath()
    path = path.."ErrorLog/"
    if not cc.FileUtils:getInstance():isDirectoryExist(path) then
        cc.FileUtils:getInstance():createDirectory(path)
    end
    local logfile = "MulLuaErr-"..os.date("%Y-%m-%d-%H:%M:%S")..".txt"
    local file = io.open(path..logfile,"w+")
    file:write(saveStr)
    file:close()
end