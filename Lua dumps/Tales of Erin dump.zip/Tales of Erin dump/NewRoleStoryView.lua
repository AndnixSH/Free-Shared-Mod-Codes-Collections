--require "XUIView"

NewRoleStoryView = class("NewRoleStoryView",XUIView)
NewRoleStoryView.CS_FILE_NAME = "NewRoleStoryView.csb"
NewRoleStoryView.CS_BIND_TABLE = 
{
    panelStory ="/i:476",
    scorView ="/i:476/i:97",
    storyDetail="/i:476/i:97/i:98",
    storyHeroName="/i:476/i:452",
    storyRaceName="/i:476/i:443",
    storyRaceIcon="/i:476/i:450",
    storyPowerName="/i:476/i:444",
    storySexName="/i:476/i:455",
    storySexIcon="/i:476/i:456",
    storyCV="/i:476/i:453",
    storyArt="/i:476/i:454",
    btnExclusiveStory="/i:476/i:1510",
}

NewRoleStoryView.SKILL_COLOR = cc.c4b(255,192,0,255)
NewRoleStoryView.PSKILL_COLOR = cc.c4b(0,232,255,255)
NewRoleStoryView.LastTab = 1
NewRoleStoryView.VoiceMap = {2,5,7,8,9}

function NewRoleStoryView:init(hero_id)--,other_ids,team_id)
    NewRoleStoryView.super.init(self)
    self.exist = true;
    self.galleryMode = 0
    --self.team_id = team_id
    self.hero_id = hero_id

    if g_channel_control.transform_NewRoleStoryView_storyDetail_autoChangeLine == true then
        self.storyDetail:ignoreContentAdaptWithSize(true);
        self.storyDetail:setTextAreaSize(cc.size(480,0))
        --self.storyDetail:getVirtualRenderer():setLineSpacing(30);
    end
   
    if g_channel_control.transform_NewRoleStoryView_storyRaceIcon_hide == true then
        self.storyRaceIcon:setVisible(false)
    end

    if g_channel_control.transform_NewRoleStoryView_storySexIcon_hide == true then
        self.storySexIcon:setVisible(false)
    end

    if g_channel_control.transform_NewRoleStoryView_storyArt_pos == true then
        self.storyArt:setPosition(cc.p(410,36))
    end


    self:SetExclusiveStoryBtn(0)
    self.btnExclusiveStory:addClickEventListener(function()
        self:onExcluSiveStory()
    end)

    self:refresh()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end

--设置可滑动的区域
function NewRoleStoryView:refreshScrollAre(str)
    local pat = "(.-)" .. "\n" .. "()"
    local nTotalHangNum = 1+1--满滑状态下底部增加一行空行
    for part, pos in string.gfind(str, pat) do
        nTotalHangNum = nTotalHangNum + 1
    end
    local fontS = 22
    local innerWidth = 500
    local innerHeight = fontS * nTotalHangNum
    local initWidth = 20
    local initHeight = 300
    local maxHeight = innerHeight > initHeight and innerHeight or initHeight -- 两者中取较大值
    self.scorView:setInnerContainerSize(cc.size(innerWidth, innerHeight))
    self.storyDetail:setPosition(cc.p(initWidth,maxHeight-10))
end

--专属剧情按钮回调
function NewRoleStoryView:onExcluSiveStory()
    local sData = {}
    sData.nHeroId = tonumber(getNumID(self.hero_id))
    -- sData["sDelegate"] = self
    -- sData["sFunc"] =  self.LoadSoulEquipData
    sData["hid"] = self.hero_id
    SceneManager:toExclusiveStoryListLayer(sData)
end

function NewRoleStoryView:refreshExclusiveStoryBtn()
    if not self.hero_data.soul then
        return
    end
    local curSoulEquipId = tonumber(getNumID(self.hero_id))

    self:SetExclusiveStoryBtn(0)
    if self.hero_data.soul.state == 3 then
        --魂灵装已激活
        local hero_soul_info = hero_soul[curSoulEquipId]
        if hero_soul_info.enabled == 1 then
            if hero_soul_info.unlock_type == 2 then
                if self.hero_data.soul.story_point == 0 then
                    self:SetExclusiveStoryBtn(1)
                end
            end
        end
    end
end

function NewRoleStoryView:SetExclusiveStoryBtn(bOpen)
    if bOpen == 0 then
        self.btnExclusiveStory:setVisible(false)
        self.btnExclusiveStory:setTouchEnabled(false)
    elseif bOpen == 1 then
        self.btnExclusiveStory:setVisible(true)
        self.btnExclusiveStory:setTouchEnabled(true)
    end
end

function NewRoleStoryView:refreshStaticState()

    local time_id = getTimeNumID( self.hero_id )
    local h_id_num = getNumID( self.hero_id )

    --背景  effects/juesexiangqin
    --local bganimefile = nil

    if time_id > 10 then
        --已获取时界面状态
        self.panelStory:setPosition(cc.p(14.5,9))
        if self.galleryMode ~= 2 then
            self.galleryMode = 2
        end   
    else
        --未获取时界面状态
        self.panelStory:setPosition(cc.p(571.5,9))
        if self.galleryMode ~= 1 then
            self.galleryMode = 1
        end       
    end
    ---

    self.currentVoiceIndex = 1

    --故事
    local storypath = nil
    self:refreshScrollAre(UITool.getUserLanguage(hero[h_id_num].hero_des_all))
    self.storyDetail:setString(UITool.getUserLanguage(hero[h_id_num].hero_des_all))
    self.storyHeroName:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))

    --self.stateGetMethod:setString(hero[h_id_num].get_method)   --获取方式

    self.storyRaceName:setString(UITool.ToLocalization(HERO_RACE_NAME[hero[h_id_num].hero_race]))
    storypath = HERO_RACE_ICON[hero[h_id_num].hero_race]
    if storypath ~= nil and storypath ~= "" then
        self.storyRaceIcon:setTexture(storypath)
    else
        self.storyRaceIcon:setVisible(false)
    end

    self.storyPowerName:setString(UITool.getUserLanguage(hero[h_id_num].power_str))

    local sexNameStr = UITool.getSexName(hero[h_id_num].sex_name)
    self.storySexName:setString(sexNameStr)
    
    storypath = hero[h_id_num].sex_img
    if storypath ~= "" then
        self.storySexIcon:setTexture(storypath)
    else
        self.storySexIcon:setVisible(false)
    end

    self.storyCV:setString(UITool.getUserLanguage(hero[h_id_num].hero_cv))
    self.storyArt:setString(UITool.getUserLanguage(hero[h_id_num].hero_author))
end

function NewRoleStoryView:refresh()
end

function NewRoleStoryView:returnBack()
    self.exist = false
    if self._navigationView then
        self._navigationView:popView()
    end
end

function NewRoleStoryView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType(nil,3)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        --self:loadInfo(true)
        self:refresh()
    else
        --self:loadInfo(false)
    end
end

function NewRoleStoryView:FillHeroData(rcvData)
    if rcvData then
        self.hero_data = nil
        self.hero_data = table.deepcopy(rcvData)
        self.hero_id = self.hero_data.id
        self:refresh()
        self:refreshStaticState()
        self:refreshExclusiveStoryBtn()
    end
end
