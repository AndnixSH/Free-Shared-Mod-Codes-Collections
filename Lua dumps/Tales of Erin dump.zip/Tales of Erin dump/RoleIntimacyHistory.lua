--[[
	RoleIntimacyHistory.lua
]]


RoleIntimacyHistory = class("RoleIntimacyHistory",XUIView)
RoleIntimacyHistory.CS_FILE_NAME = "RoleIntimacyHistory.csb"
RoleIntimacyHistory.CS_BIND_TABLE = 
{
    listView = "/i:332/i:80"
}

function RoleIntimacyHistory:init(str,title)
    self.super.init(self)
    self.dataStr = str
    self.titleStr = title
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)

    self:refreshList()

    return self
end
function RoleIntimacyHistory:pushOtherItem()
    self.listView:setScrollBarEnabled(true)
    self.listView:setScrollBarWidth(20)
    self.listView:setScrollBarColor(cc.c3b(0, 0, 0))
    self.listView:setScrollBarOpacity(225*0.5)
    self.listView:setScrollBarPositionFromCorner(cc.p(2,2))
    ---标题
    local item = ccui.Layout:create()
    item:setContentSize(600, 50)

    local alert = ccui.Text:create(titleStr,TEXT_FONT_NAME,30)
    alert:setColor(cc.c3b(236, 218, 179))
    alert:enableOutline(cc.c4b(67,34,14,1),2)
    alert:setPosition(300, 25)
    alert:setString(self.titleStr)
    item:addChild(alert)

	local imageview = ccui.ImageView:create("n_UIShare/Intimacy/gmd_ui_010.png")

	self.listView:pushBackCustomItem(item)
	self.listView:pushBackCustomItem(imageview)
end

function RoleIntimacyHistory:refreshList()
	self.listView:removeAllItems()
	self:pushOtherItem()
    local item_des = ccui.Layout:create()
    local desText = self:getLabelUI(self.dataStr)
    item_des:setContentSize(cc.size(desText:getCustomSize().width , desText:getCustomSize().height))
    item_des:addChild(desText)
    self.listView:pushBackCustomItem(item_des)
    self.listView:jumpToTop()
end

function RoleIntimacyHistory:getLabelUI(infoStr,addH)
    addH = addH or 0
    local tempinfoStr = infoStr
    local _,num = string.gsub(tempinfoStr,"\n","")
    local row = math.ceil(UITool.getCharLength(infoStr)/25)+ num
    local desText = ccui.Text:create()
    desText:setFontSize(22)
    desText:ignoreContentAdaptWithSize(false)
    desText:setString(infoStr)
    desText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    desText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    desText:setColor(cc.c3b(236, 218, 179))
    desText:setPosition(10,0)
    desText:setAnchorPoint(cc.p(0, 0))
    desText:setContentSize(cc.size(560, 22 * row+50))
    return desText
end

function RoleIntimacyHistory:closeBack()
    self:onBeforeClose()
    self:returnBack()
end

function RoleIntimacyHistory:onBeforeClose()
    if self.beforeCloseEvent then
        self.beforeCloseEvent(self)
    end
end


function RoleIntimacyHistory:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function RoleIntimacyHistory:refresh(str,title)
	self.dataStr = str
    self.titleStr = title
	self:refreshList()
end
