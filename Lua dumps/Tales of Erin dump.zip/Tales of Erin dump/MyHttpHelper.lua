
--------------------------------
-- @module MyHttpHelper
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#MyHttpHelper] setGameURL 
-- @param self
-- @param #string url
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] getGameURL 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] getjson 
-- @param self
-- @param #map_table josnData
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] getGameToken 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] creatHttpRequestForLua 
-- @param self
-- @return MyHttpRequest#MyHttpRequest ret (return value: MyHttpRequest)
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] purg 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] startGame 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] setToken 
-- @param self
-- @param #string token
        
--------------------------------
-- 
-- @function [parent=#MyHttpHelper] shareMyHttpHelper 
-- @param self
-- @return MyHttpHelper#MyHttpHelper ret (return value: MyHttpHelper)
        
return nil
