--[[
info:
登录条款界面
]]



ShopRefundsLayer = class("ShopRefundsLayer")

function ShopRefundsLayer:init()
   
    
    self:initView();
    self:addBtnListener();
    self:refreshView();
    
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end

function ShopRefundsLayer:initView()
    local  node = cc.CSLoader:createNode("ShopRefundsLayer.csb");
    self.uiLayer:addChild(node,0,1);   

    self._rootCSbNode = node:getChildByTag(2197);
    
    self._ListView_info = ccui.Helper:seekWidgetByName(self._rootCSbNode,"ListView_info");
   
    
    self._Button_close = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_close");
      
end

function ShopRefundsLayer:refreshView()
    self:initInfoList();
    
end



function ShopRefundsLayer:addBtnListener()
   
    local this = self;
    self._Button_close:addClickEventListener(function (pSender)
        -- body
        print("点击按钮 detail info");

        self:returnBack()
        -- this:confirmBtnCallBack(pSender);
    end);
end

-- function ShopRefundsLayer:confirmBtnCallBack(sender)
--     print("点击按钮 detail info");
--     self.uiLayer:setVisible(false);
-- end




--数据表中的数据格式
-- {
--     "str":"8) 회사가 회원에게 제 4항과 같이 고지하였음에도 회원이 변경된 약관에 대한 정보를 알지 못해 발생하는 피해에 대해서는 회사는 책임지지 않습니다.",
--     "color":"#ff0000",
--     "bold":0,
--     "size":20,
--     "align":"left"
-- }


--初始化 treat list
function ShopRefundsLayer:initInfoList()
    
    --set bar
    self._ListView_info:setScrollBarEnabled(true)
    self._ListView_info:setScrollBarWidth(20)
    self._ListView_info:setScrollBarColor(cc.c3b(0, 0, 0))
    self._ListView_info:setScrollBarOpacity(225*0.5)
    self._ListView_info:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end

    --local textArr = JsonUtil.getTableFromFile("system_btn/treat_agree.json" );
    local textArr = data_refunds_details_info;
    --dump(treat_agree_content, "treat_agree_content:")
    


    --技能
    for i=1,#textArr do
        

        local item_des = ccui.Layout:create();
        local desText = self:getLabelUI(textArr[i])
        local virtualSize = desText:getVirtualRendererSize();
        --dump(virtualSize, "virtualSize : ")
        item_des:setContentSize(cc.size(virtualSize.width , virtualSize.height+10));
        
        item_des:addChild(desText)
        self._ListView_info:pushBackCustomItem(item_des)
        
    end
end
function ShopRefundsLayer:clear()
    if self.uiLayer~=nil then
      self.uiLayer:removeFromParent()
      self.uiLayer = nil
    end
end
function ShopRefundsLayer:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end


---label
--说明： 在创建的时候设置字体，比创建完成设置字体要快很多
function ShopRefundsLayer:getLabelUI(info,addH)
    -- body
    info = info or {}
    addH = addH or 0


    local infoStr = info.str or "";
    local color16 = info.color or "#ffffff";
    local bold = info.bold ~= nil and info.bold ~= 0 and true or false;
    local size = info.size or 20;
    local align = cc.TEXT_ALIGNMENT_LEFT;
    if info.align == "left" then
        align = cc.TEXT_ALIGNMENT_LEFT;
    elseif info.align == "center" then
        align = cc.TEXT_ALIGNMENT_CENTER;
    elseif info.align == "right" then
        align = cc.TEXT_ALIGNMENT_RIGHT;
    end

    local color = lemon.ColorUtil.getRgb(color16)
    -- --缩进
    local indendtation = info.indendtation or 0;

    --描边颜色ß
    local outLineColor = cc.c4b(0,0,0,255);

    if bold then
        outLineColor = cc.c4b(color.r, color.g, color.b, 255);
    end


    

    --local row = math.ceil(UITool.getCharLength(infoStr)/25)
   -- local desText = ccui.Text:create("",TEXT_FONT_NAME,22)  
    local desText = ccui.Text:create()
    desText:setFontSize(size)
    desText:enableOutline(outLineColor,1)
    desText:ignoreContentAdaptWithSize(false)
    desText:setString(infoStr)
    desText:setTextHorizontalAlignment(align)
    desText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    desText:setColor(color)
    desText:setPosition(indendtation + 5,0)
    desText:setAnchorPoint(cc.p(0, 0))
    local textWidth = 540 - indendtation;
    local size = cc.size(textWidth, 0);
    desText:setTextAreaSize(size);
    local virtualSize = desText:getVirtualRendererSize();
    desText:setContentSize(virtualSize)
    return desText
end





function ShopRefundsLayer:create()
     local layer = ShopRefundsLayer.new()
     layer.uiLayer = cc.Layer:create()
     layer:init();
     return layer;
end
