require "BasicLayer"
-- 登陆奖励
AllianceBattle_ApplyLayer = class("AllianceBattle_ApplyLayer",BasicLayer)
AllianceBattle_ApplyLayer.__index   = AllianceBattle_ApplyLayer
AllianceBattle_ApplyLayer.lClass    = 2 
 


function AllianceBattle_ApplyLayer:init()
    print("进入商店初始化函数")
    local node    = cc.CSLoader:createNode("AllianceBattle_ApplyLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.curTable = {}
    self:sendData()
    self:initProper()


end
-- 设置btn事件
function AllianceBattle_ApplyLayer:setBtnEvent( ... )
    -- body
    local function btnCallBack( sender,eventType)
        -- body
        if eventType == ccui.TouchEventType.ended  then
           if sender:getName() == "Button_close" then
                self:returnBack()
            elseif sender:getName() == "Button_apply" then
                self:ApplyEvent()   
            end
        end
    end

    self.m_close_btn:addTouchEventListener(btnCallBack)
    self.m_btnApply:addTouchEventListener(btnCallBack)
   
end
-- 点击报名
function AllianceBattle_ApplyLayer:ApplyEvent( ... )
    -- body
    -- 有公会
    if self.curTable["is_joined_guild"] == 1 then
        -- 副会长和会长点击的报名
        if self.curTable["postion"] > 1 then -- AllianceBattleInfo[1]
            
            MsgManager:showSimpMsgTime(UITool.ToLocalization(UITool.getUserLanguage(desc_info[1006])),self,self.callfunc,5,"LTOP")
        else
            -- 会员点击报名 -- AllianceBattleInfo[2]
            MsgManager:showSimpMsg(UITool.getUserLanguage(desc_info[1002]))
        end
    elseif self.curTable["is_joined_guild"] == 0 then -- 没有公会 -- AllianceBattleInfo[4]
        MsgManager:showSimpMsg(UITool.getUserLanguage(desc_info[1004]))
    end
end
-- 点击报名的回调函数
function AllianceBattle_ApplyLayer:callfunc( ... )
    -- body
    local function reiceSthCallBack(data)
        print("团战报名界面点击报名")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        MsgManager:showSimpMsg(self.curTable["guild_name"]..UITool.ToLocalization(",报名星界轮回大战成功"))
        self.curTable["is_apply"] = 1 
        self:showPer()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guildbattle_sign_up",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
     
end
-- 获取初始化显示的属性
function AllianceBattle_ApplyLayer:initProper( ... )
    -- body
    local node         = self.uiLayer:getChildByTag(2)
    self.m_panel       = node:getChildByName("Panel_1")
    self.m_per_bg      = self.m_panel:getChildByName("Image_pro_bg")
    -- 注意事项
    self.m_dec         = self.m_per_bg:getChildByName("Text_dec")
    -- 活跃人数
    self.m_active      = self.m_per_bg:getChildByName("Text_active")
    -- 公会总人数
    self.m_sum         = self.m_per_bg:getChildByName("Text_sum")
    -- 活动的名字
    self.m_activeName  = self.m_per_bg:getChildByName("Text_activeName")
    -- 报名按钮
    self.m_btnApply    = self.m_panel:getChildByName("Button_apply")
    --关闭按钮
    self.m_close_btn   = self.m_panel:getChildByName("Button_close")
    self:setBtnEvent()
    --self:showPer()
end
-- 根据状态显示属性
function AllianceBattle_ApplyLayer:showPer( ... )
    -- body
    self.m_dec:setString(UITool.getUserLanguage(desc_info[1003]))--AllianceBattleInfo[3]
    self.m_activeName:setPosition(cc.p(242,30))
    self.m_activeName:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.m_activeName:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    self.m_activeName:setAnchorPoint(cc.p(0.5,0.5))
    if self.curTable["is_joined_guild"] == 1 then -- 有公会

        self.m_activeName:setString(self.curTable["guild_name"])
        self.m_sum:setString(self.curTable["sum_num"])
        self.m_active:setString(self.curTable["active_num"])
        -- 已报名
        if self.curTable["is_apply"]  == 1 then
            self.m_btnApply:setTouchEnabled(false)
            self.m_btnApply:setBright(false)
        elseif self.curTable["is_apply"]  == 0 then -- 未报名
            self.m_btnApply:setTouchEnabled(true)
            self.m_btnApply:setBright(true) 
        end

    else -- 没有公会
        self.m_activeName:setString(UITool.ToLocalization("未加入公会"))
        self.m_sum:setString(UITool.ToLocalization("未加入公会"))
        self.m_active:setString(UITool.ToLocalization("未加入公会"))
        -- self.m_btnApply:setTouchEnabled(false)
        -- self.m_btnApply:setBright(false)
    end
    self.m_btnApply:setVisible(true)
end
-- 返回
function AllianceBattle_ApplyLayer:returnBack( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    if self.backFunc then
        self.backFunc(self.sDelegate,self.sData)
    end
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clear()

end
-- 获取数据
function AllianceBattle_ApplyLayer:sendData( ... )
    -- body
        -- body
    local function reiceSthCallBack(data)
        print("团战报名界面获取数据")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self and not self.sManager then
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        self.curTable = t_data["data"]
        self:showPer()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guildbattle_enter",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)

end

function AllianceBattle_ApplyLayer:create(rData)

     local login     = AllianceBattle_ApplyLayer.new()
     login.rData     = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()

     return login

end
