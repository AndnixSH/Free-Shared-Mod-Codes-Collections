--怪物主动技能管理器
--created by kobejaw.2018.4.20.
--[[
	对于boss：
	总共有如下几类技能：
	1. sk_lv = 0。终极大招，不受是否满豆限制，不受狂暴虚弱状态限制，释放完后豆清零。
	2. sk_lv > 1。普通大招。满豆释放。释放后豆清零。
	3. sk_lv = 1。小技能。狂暴状态释放。释放后涨豆。
	特殊情况：
	1. trig_cd >=6000 时表示该技能只释放一次。满足触发条件释放完后从技能列表里移除该技能。
	2. 81050和81055。身上有这个buff时释放（不一定是大招）
	3. 多人战  且  trig_type = 2 且 trig_num_1 = 1的情形。如果满足条件，对新进入战斗的玩家，在加入多人战时会把该技能从boss技能列表删掉。对于战斗中
	   的玩家，boss释放完一次该技能后，把该技能从boss技能列表移除。
	注意：boss战过程中程序会不用使用trig_time，trig_cd，start_cd字段。只会使用trig_type判定。

	对于小怪和精英怪：
	走常规战斗逻辑，会使用trig_time，trig_cd等字段。
]]
MonsterSkillManager = class("MonsterSkillManager")

function MonsterSkillManager:ctor(entity)
	self.entity = entity
	self:createMonsterSkillList()
end

--创建怪物的技能列表（小怪和boss都会用到）
function MonsterSkillManager:createMonsterSkillList()
	self.ultimateSkillList = {}  --sk_lv为0的终极大招列表，只有boss用
	self.bigSkillList = {}       --sk_lv>1的大招列表，只有boss用
	self.normalSkillList = {}    --普通技能列表，所有都怪都用

	for k,v in pairs(self.entity.data.activeSkillArray) do
		local triggerData = monster_sk[v].trig_cdn
		if triggerData.trig_time ~= 0 and not self:isParticularCase3(triggerData) then
			local monsterSkill = MonsterActiveSkill.new(v,self.entity)

			if BattleDataManager.isBoss then
				if monsterSkill.sk_lv == 0 then
					table.insert(self.ultimateSkillList,monsterSkill)
				elseif monsterSkill.sk_lv > 1 then
					table.insert(self.bigSkillList,monsterSkill)
				elseif monsterSkill.sk_lv == 1 then
					table.insert(self.normalSkillList,monsterSkill)
				end
			else
				table.insert(self.normalSkillList,monsterSkill)
			end
		end
	end

	table.sort(self.bigSkillList,function (a,b)
		return a.sk_lv > b.sk_lv
	end)

	if not BattleDataManager.isBoss then
		table.sort(self.normalSkillList,function (a,b)
			return a.sk_lv > b.sk_lv
		end)
	end
end

--获取即将释放的skillInfo
function MonsterSkillManager:getNextSkillInfo()
	--只有boss会用到
	for k,v in ipairs(self.ultimateSkillList) do
		if TriggerChecker:checkTriggerType(v.triggerData,v.entity) then
			self.currMonSkill = v
			return v:getNextSkillInfo()
		end
	end

	--只有boss会用到
	for k,v in ipairs(self.bigSkillList) do
		if v.entity:checkIsFullEP() and v.entity.attr[AE.state] == 0 and TriggerChecker:checkTriggerType(v.triggerData,v.entity) then
			self.currMonSkill = v
			return v:getNextSkillInfo()
		end
	end

	--所有怪物都会用到
	for k,v in ipairs(self.normalSkillList) do
		if v.isReady and TriggerChecker:checkTriggerType(v.triggerData,v.entity) then
			self.currMonSkill = v
			return v:getNextSkillInfo()
		end
	end
end

--检测特殊情况3.
function MonsterSkillManager:isParticularCase3(triggerData)
	if G_STAGE_TYPE ~= 2 then
		return false
	end

	if triggerData.trig_type == 2 and triggerData.trig_num_1 == 1 then
		local hpRatio = self.entity.attr[AE.hp]/self.entity.attr[AE.hp_max] * 100
		if hpRatio <= triggerData.trig_num_2 then
			return true
		end
	end

	return false
end

function MonsterSkillManager:update(dt)
	if not BattleDataManager.isBoss then
		local idx = 1;
		while idx <= #self.normalSkillList do
			local monsterSkill = self.normalSkillList[idx]
			if monsterSkill.isNeedRemove then
				table.remove(self.normalSkillList,idx)
			else
				monsterSkill:update(dt)
				idx = idx + 1
			end
		end
	end
end

--释放技能前
function MonsterSkillManager:onPlaySkill()
	if self.currMonSkill then
		self.currMonSkill:onPlaySkill()
	end
end

--技能释放后
function MonsterSkillManager:onSkillFinished()
	if self.currMonSkill then
		self.currMonSkill:onSkillFinished()
	end
end
