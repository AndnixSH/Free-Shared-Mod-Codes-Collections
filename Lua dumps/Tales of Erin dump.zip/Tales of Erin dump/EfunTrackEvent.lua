EfunTrackEvent = {}

--[[
	EfunSDK打点接入事件名
	id = {
		name,
		type：（android 无意义;;;; ios 中 1 使用eventName作为打点名字，调用自定义打点接口  2 升级打点，自定义+facebook打点，3 储值开始 （ios不接）4 储值完成（ios不接） , 其他  IOS不做打点）
	}

]]--

EfunTrackEvent["loginRole"] = {
    eventName_ios = "loginRole",                 --角色登陆事件
    eventName_android = "loginRole",                 --角色登陆事件
    eventType = 1
}

EfunTrackEvent["logoutRole"] = {
    eventName_ios = "logoutRole",                 --角色登出事件
    eventName_android = "logoutRole",                 --角色登出事件
    eventType = 1
}

EfunTrackEvent["chapter1_1_1"] = {
    eventName_ios = "chapter1_1_1",                 --完成第一章第一节-1
    eventName_android = "chapter1_1_1",                 --完成第一章第一节-1
    eventType = 1
}
EfunTrackEvent["lv3"] = {
    eventName_ios = "upgradeRole_lv3",                 
    eventName_android = "upgradeRole_lv3",                 
    eventType = 1
}
EfunTrackEvent["lv7"] = {
    eventName_ios = "upgradeRole_lv7",                
    eventName_android = "upgradeRole_lv7",                
    eventType = 1
}
EfunTrackEvent["lv8"] = {
    eventName_ios = "upgradeRole_lv8",                 
    eventName_android = "upgradeRole_lv8",                 
    eventType = 1
}
EfunTrackEvent["lv10"] = {
    eventName_ios = "upgradeRole_lv10",              
    eventName_android = "upgradeRole_lv10",              
    eventType = 1
}
EfunTrackEvent["lv20"] = {
    eventName_ios = "upgradeRole_lv20",                 
    eventName_android = "upgradeRole_lv20",                 
    eventType = 1
}
EfunTrackEvent["purchaseBegin"] = {
    eventName_ios = "fb_mobile_initiated_checkout",    --储值开始埋点
    eventName_android = "fb_mobile_initiated_checkout",    --储值开始埋点
    eventType = 3
}
EfunTrackEvent["purchaseEnd"] = {
    eventName_ios = "finish_purchase",                 --储值完成
    eventName_android = "finish_purchase",                 --储值完成
    eventType = 4
}
EfunTrackEvent["createRole"]  ={
    eventName_ios = "createdRole",
    eventName_android = "createdRole",
    eventType = 1
}
EfunTrackEvent["chapter3"] = { 
    eventName_ios = "chapter3",                         --完成章节3
    eventName_android = "chapter3",                         --完成章节3
    eventType = 1       
}
EfunTrackEvent["charactersummon10"] = {
    eventName_ios = "charactersummon10",                --角色十连抽
    eventName_android = "charactersummon10",                --角色十连抽
    eventType = 1       
}