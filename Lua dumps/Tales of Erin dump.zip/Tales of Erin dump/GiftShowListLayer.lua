require "BasicLayer"
-- 登陆奖励
GiftShowListLayer = class("GiftShowListLayer",BasicLayer)
GiftShowListLayer.__index   = GiftShowListLayer
GiftShowListLayer.ListView = nil
GiftShowListLayer.Table    = nil
GiftShowListLayer.gift_id  = nil
GiftShowListLayer.oneSelf  = nil
GiftShowListLayer.type     = nil

function GiftShowListLayer:init()
    print("进入GiftShowListLayer init")
    local node    = cc.CSLoader:createNode("GiftShowListLayer.csb")
    self.uiLayer:addChild(node,0,2)
    -- 获取到到ListView
    local panel      = node:getChildByName("Panel_1")
    local image_bg   = panel:getChildByName("Image_list_bg")
    -- ListView
    self.ListView    = image_bg:getChildByName("ListView_1")
    self.gift_id     = self.rData["rcvData"]["gift_id"]
    self.oneSelf     = self.rData["rcvData"]["oneSelf"]
    self.type        = self.rData["rcvData"]["gift_tyep"]
    self.costType    = self.rData["rcvData"]["costType"]
    self.item_num    = self.rData["rcvData"]["num"]
    self.isLoginShop = self.rData["rcvData"]["isLoginShop"] --付费登陆界面的标识

    if self.type == 7 then
        self.Table       = gift[tonumber(self.gift_id)]
    elseif self.type == 11 then
        self.Table       = month_card[tonumber(self.gift_id)]
    end
    self:initModel()
    self:SetShowForm()
    self:SetListView()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:Close()
    end)

end
-- 初始hua list模板
function GiftShowListLayer:initModel( ... )

    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("GiftShowListNode.csb")
    local  item_1 = list_item:getChildByName("Panel_1")
    local item_c = item_1:clone()
    item_c:setPosition(cc.p(0,0))
    item_c:setName("item")
    layout_list:addChild(item_c)
    layout_list:setContentSize(460,108)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)

end
-- 获取list的Item 设置item的属性信息
function GiftShowListLayer:SetListView( ... )
    -- body
    -- 获取装载Item的list长度
    local len = #self.Table["reward"]
    for i = 1 , len do
        self.ListView:pushBackDefaultItem()
    end
    -- 取出item 进行赋值
    for i = 1 , len do
        local tab     = self.Table["reward"][i]
        local itemEl  = self.ListView:getItem(i - 1)
        local item_1  = itemEl:getChildByName("item")

        local data  = {
            ["item_id"]   = self.Table["reward"][i]["id"],
            ["item_type"] = self.Table["reward"][i]["type"],
            ["item_num"]  = self.Table["reward"][i]["num"],
        }
        local popr      = UITool.getItemInfos(data.item_type,data.item_id)
        print("leixing == "..data["item_type"])
        print("id == "..data["item_id"])

        --获取item属性进行赋值
        --  BG 所有属性的父节点
        local  image_bg   = item_1:getChildByName("Image_bg")
        --icon 背景
        local  icon_bg    = image_bg:getChildByName("Image_iconbg")
        icon_bg:loadTexture(popr[4])
        -- 图片
        local  icon       = image_bg:getChildByName("Image_icon")
        icon:loadTexture(popr[2])
        icon:setUnifySizeEnabled(true)
        --图片属性框
        local  icon_form  = image_bg:getChildByName("Image_form")
        icon_form:loadTexture(popr[1])
        -- 名字
        local  icon_name  = image_bg:getChildByName("Text_Name")
        icon_name:setString(popr[5])
        -- 描述
        local  iocn_dec   = image_bg:getChildByName("Text_dec")

        --改变礼包node 中的描述字体大小
        if g_channel_control.transform_GiftShowListLayer_Text_dec_fontSize == true then
            print("transform_GiftShowListLayer_Text_dec_fontSize")
            iocn_dec:setFontSize(18)
            iocn_dec:setContentSize(280,45)
            iocn_dec:setPosition(122, 13)
        end

        iocn_dec:setString(popr[6])
        print("miaoshu -- "..popr[5])
        -- 属性求
        if popr[3] ~= "" then
            local elementImg = cc.Sprite:create(popr[3])
            elementImg:setAnchorPoint(cc.p(1,1))
            elementImg:setPosition(icon_form:getContentSize().width,icon_form:getContentSize().height)
            elementImg:setScale(0.7)
            icon_form:addChild(elementImg,100,100)
        elseif popr[3] == "" or popr[3] == nil or popr[3] == 0 then
            icon_form:removeChildByTag(100)
        end
        -- 数量
        local  num        = image_bg:getChildByName("Text_number")
        num:setString(data["item_num"])
    end

end
-- 弹出框上显示的 除了Item 以外的属性信息
function GiftShowListLayer:SetShowForm( ... )
    -- body
    local popr      = UITool.getItemInfos(self.type,tonumber(self.gift_id))
    local node       = self.uiLayer:getChildByTag(2)
    local panel      = node:getChildByName("Panel_1")
    -- 图标背景
    local icon_bg    = panel:getChildByName("Image_icon_bg")
    icon_bg:loadTexture(popr[4])
    print("self.gift_id == "..self.gift_id)
    print("-------"..popr[4])
    -- 图标
    local icon       = panel:getChildByName("Image_icon")
    icon:loadTexture(popr[2])
    print("popr[2]  == "..popr[2])
    icon:setUnifySizeEnabled(true)
    -- 图标属性框
    local icon_form  = panel:getChildByName("Image_icon_form")
    icon_form:loadTexture(popr[1])
    -- 消耗钻石数量
    local cost_gem   = panel:getChildByName("Text_number")
    cost_gem:setString(self.rData["rcvData"]["cost_num"])
    -- 消耗类型的图标
    local Image_cost =  panel:getChildByName("Image_gem")
    print("shen shen shen == "..self.item_num)
    Image_cost:setUnifySizeEnabled(true)
    Image_cost:loadTexture(UITool:Coin_type(self.costType) )
    -- 礼包的名字
    local gift_name  = panel:getChildByName("Text_gift_name")
    gift_name:setString(UITool.getUserLanguage(self.Table["name"]))
    -- 限购次数
    local buy_cishu  = panel:getChildByName("Text_buy_cishu")
    if self.isLoginShop then
        buy_cishu:setVisible(false)
    else
        if self.rData["rcvData"]["Shopindex"] == 2 then
            buy_cishu:setString(self.rData["rcvData"]["content"])
        else
            if self.rData["rcvData"]["stock_num"] == -1 then
                buy_cishu:setString(UITool.ToLocalization("无限次"))
            else
            local str = string.format(UITool.ToLocalization("限购%d次") , self.rData["rcvData"]["stock_num"])
             buy_cishu:setString(str)
            end
        end
        if g_channel_control.transform_GiftShowListLayer_Text_buy_cishu_Alignment == true then
            buy_cishu:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
            buy_cishu:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
            buy_cishu:ignoreContentAdaptWithSize(false);
            buy_cishu:setTextAreaSize(cc.size(250,50))
            buy_cishu:setPosition(cc.p(389,295))
        end         
    end

    -- 按钮事件
    local function touchCallBack1( sender,eventType )
        -- body
        if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Button_cancel" then
                 self:Close()
            elseif sender:getName() == "Button_buy" then
                 self:BuyCallback()
            end
        end
    end 
    -- 购买按钮
    local buy_btn    = panel:getChildByName("Button_buy")
    -- 取消按钮
    local cancle_btn = panel:getChildByName("Button_cancel")
    cancle_btn:addTouchEventListener(touchCallBack1)
    buy_btn:addTouchEventListener(touchCallBack1)

    --付费登陆的特殊处理。2018.12.14.
    if self.isLoginShop and self.replenishsign_num then
        local Image_cost_c = Image_cost:clone()
        local cost_gem_c = cost_gem:clone()

        Image_cost_c:setUnifySizeEnabled(true)
        Image_cost_c:loadTexture(UITool:Coin_type(self.replenishsign_costType))
        Image_cost_c:setPosition(cc.p(Image_cost:getPositionX(),Image_cost:getPositionY() - 27))
        Image_cost:getParent():addChild(Image_cost_c)

        cost_gem_c:setString(self.replenishsign_num)
    end
end
--点击购买按钮的回调
function GiftShowListLayer:BuyCallback( ... )
    if self.isLoginShop then
        

    else
        if self.costType == 14 then
            self.oneSelf:BuyTwo(self)
        else
            self.oneSelf:BuyDaojuTow(self.item_num)
            self:Close()
        end
    end
end
function GiftShowListLayer:Close( ... )
    -- body
    self.gift_id     = nil
    self.oneSelf     = nil
    self.type        = nil
    self.costType    = nil
    self.item_num    = nil
    self.exist = false
    self:clearEx()
end

function GiftShowListLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function GiftShowListLayer:create(rData)

     local login = GiftShowListLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login

end

