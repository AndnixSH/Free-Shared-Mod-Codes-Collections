
ChatNewPannelGuild = class("ChatNewPannelGuild",XUIView)
ChatNewPannelGuild.CS_FILE_NAME = "ChatPannelGuild.csb"
ChatNewPannelGuild.CS_BIND_TABLE = 
{

 	guildPannel 				= "/i:1",
	guild_bg 					= "/i:1/i:1",
    guild_pannel_name 			= "/i:1/i:2/i:1",
    guild_btn_toGuild 			= "/i:1/i:2/i:2",

    guild_chatList_pannel		= "/i:1/i:4",
    
}

ChatNewPannelGuild.LogTag = "ChatNewPannelGuild"

function ChatNewPannelGuild:create(rData)
    local login = ChatNewPannelGuild.new()

    login.uiLayer   = cc.Layer:create()
    login:initUI()
    return login
end

function ChatNewPannelGuild:clear( )
	self:registEventDispatcher(false)

end

function ChatNewPannelGuild:returnBack(  )
	self:clear()
end

function ChatNewPannelGuild:initUI(  )
	self:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)
	self:initData()


	self:bindAllBtn()

	-- self:registEventDispatcher(true) 	--启动通知事件
end

function ChatNewPannelGuild:initData(  )

	self.guildID = XBChatData:getInstance():getGuideID()

	self.guildName = XBChatData:getInstance():getGuideName()
end

function ChatNewPannelGuild:bindAllBtn(  )
	self.guild_bg:setVisible(false)

	self.guild_pannel_name:setString(tostring(self.guildName))

	self.inputNode = ChatInputNode:create()
	self.inputNode:setDelegate(self)
	self.inputNode:setSendCallback(function ( sender,message )
		self:sendMessage(message)
	end)
	self.guildPannel:addChild(self.inputNode:getRootNode())

	local psize = self.guild_chatList_pannel:getContentSize()
	self._scrollView = XBChatNewListView.new():initWithNodeAndSize(self.guild_chatList_pannel, psize.width, psize.height)
	self._scrollView:setItemCreateFunc(handler(self,self.createItem))
	self._scrollView:setItemRemoveFunc(handler(self,self.removeItem))

    self.guild_btn_toGuild:addTouchEventListener(handler(self,self.guildToGuildCallback))
	
end

function ChatNewPannelGuild:registEventDispatcher(bTrue)
	print("registEventDispatcher:::"..tostring(bTrue))
	if bTrue == false  then
		-- lemon.EventManager:getInstance():removeEventListener(self.chatroom_login_listener)
		return 
	end

	-- self.chatroom_login_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_SDK_LOGIN,handler(self,self.eventCbEnterChatroom))
end

function ChatNewPannelGuild:eventEnterChatroom( session_type,session_id,code ) --登陆结果通知回调
	if session_type ~= 2  then
		print("拒绝处理：类型不匹配。。eventEnterChatroom type："..tostring(session_type).."....id:"..tostring(session_id).."..guildID:"..tostring(self.guildID))
		return 
	end
	if code ~= 0 then
		-- print("聊天室登陆失败！！code:"..tostring(code)..",session_id:"..tostring(session_id)..",session_type:"..tostring(session_type))
		XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1031015))

		return
	end
	-- print("ChatNewPannelChatroom;;eventEnterGuideId====="..self.guildID.."....:"..session_id)
	if tostring(session_id) == tostring(self.guildID) then

		XBChatData:getInstance():setCurrentSession(self.guildID, 2)
		self:refreshChatListView()

	end 


end

function ChatNewPannelGuild:eventRefreshUI( session_type,session_id,scrollEnd )

	if session_type ~= 2 or session_id ~= self.guildID  then
		print("拒绝处理：类型不匹配。。eventRefreshUI: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self.guildID))
		return 
	end
	XBChatData:getInstance():setCurrentSession(self.guildID, 2)
	
	self:refreshChatListView(scrollEnd)

end
--
function ChatNewPannelGuild:eventFecthSession( session_type,session_id )
	if session_type ~= 2 or session_id ~= self.guildID  then
		print("拒绝处理：类型不匹配。。eventFecthSession: type："..tostring(session_type).."....id:"..tostring(session_id).."..guildId:"..tostring(self.guildID))
		return 
	end

	self.fetchMessage = true 

	self:refreshChatListView(true)
end



function ChatNewPannelGuild:createItem( data )
	data["size_type_small"] = false -- 是否为小item
	return XBChatListViewItemPool:getInstance():createItemByData(data)
end

function ChatNewPannelGuild:removeItem( item )
	return XBChatListViewItemPool:getInstance():removeItemToPool(item)
end

function ChatNewPannelGuild:channelDataRefresh( ... )
	self:initConcationChatRoom()
end

function ChatNewPannelGuild:initConcationChatRoom(  )
	if self.guildID == nil or self.guildID == "0"  then
		print("ChatNewPannelGuild:initConcationChatRoom=========未加入公会！！")
		return 
	end
	if  XBChatData:getInstance():getChatRoomEnterState(self.guildID) ~= true  then --世界
		print("initConcationChatRoom.....roomid:"..tostring(self.guildID))

		XBChatSys:getInstance():createChatWaitLayer();

		local t_data = {
			session_id = self.guildID,
		}
		XBChatSys:getInstance():enterChatRoom(t_data)
	else
		XBChatData:getInstance():setCurrentSession(self.guildID, 2)

		self:refreshChatListView()

	end
end

function ChatNewPannelGuild:removeScrollView( ... )
	if self._scrollView then
		self._scrollView:resetTempData()
	end
	self.fetchMessage 			= false 

end

function ChatNewPannelGuild:refreshChatListView( scrollEnd )
	if self.guildID == nil  then
		return 
	end

	if self.fetchMessage == true or self._scrollView:getDataSource() == nil  then
		if self.fetchMessage == true  then
			self.fetchMessage = false 
		end
		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self.guildID)
		self._scrollView:setDataSource(chatroom_datas)
	else
		self._scrollView:refreshDataSource(scrollEnd)
	end 


end

function ChatNewPannelGuild:sendMessage( message )
	
	print("sendBtnCallback:"..tostring(message).."...guildID:"..tostring(self.guildID))
	local channelIndex = 4
	XBChatPlatform:getInstance():sendmessage(channelIndex, self.guildID,2,tostring(message),"" ,function (  )
		self.inputNode:setInputString("")
	end)
end

function ChatNewPannelGuild:guildToGuildCallback( sender,eventType )
	-- body
	-- print("guildToGuildCallback:"..sender:getTag())
	if eventType == ccui.TouchEventType.ended then

		local toGuideMsg = Lang:toLocalization(1031014) 

        MsgManager:showSimpMsgWithCallFunc(toGuideMsg,self,function ( ... )
            -- body
			XBChatSys:getInstance():toGuild()
        end)


	end
end


