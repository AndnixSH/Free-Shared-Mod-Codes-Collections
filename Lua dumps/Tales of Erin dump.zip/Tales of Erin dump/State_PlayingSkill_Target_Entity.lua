--释放State_PlayingSkill_Target_Entity技能中。(打某个或全体的身上)
--注：State_PlayingSkill_Scene和State_PlayingSkill_Target中打全体的区别，前者在场景播放特效，后者在目标身上或初始位置播放特效
--created by kobejaw.2018.4.27.

--判定：
--target_type 1.自己。2.按条件从我方选择。3.按条件从敌方选择
--target_num 作用数量。0，表示全体。
--target_property 0.距离 1.血量 2.防御 3.攻击 4.随机
--target_p_type 0和1.选取目标所在的位置（范围攻击，使用hit_rect）。 3.选取目标(注意：如果不是target_type为1或者target_num为0的情况，优先判定这个，这个牵扯到场景或者飞行特效是在固定位置还是目标身上播放)
--sort_type 排序方式。0升序 1降序

--注：关于target_p_type，大部分需要配成3的地方都错误的配成了0或者1

State_PlayingSkill_Target_Entity = class("State_PlayingSkill_Target_Entity",StateBase)

function State_PlayingSkill_Target_Entity:ctor(entity) --处理方式类似于Attacking状态中的爆炸类型的普通攻击
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.PlayingSkill_Target
	self.entitiesEffected = {}       --受影响的entity列表
	self.isSkill = true
end

function State_PlayingSkill_Target_Entity:Enter(skillInfo)
	self.isHealSoundPlayed = false;--防止治疗音效多次播放
	self.entitiesEffected = {}       --受影响的entity列表

	self.skillInfo = skillInfo;
	self.super.Enter(self)
end

function State_PlayingSkill_Target_Entity:Exit()
	self.super.Exit(self)
end

--注：对于目标类技能，"attack"事件可能在技能动作里，例如"绊爱"的小技能，给队友加血。也可能在"autoplay"里，例如"米蕾妮"的大小技能，随机打一个敌人。
function State_PlayingSkill_Target_Entity:onSpineEventCallback(event)
	--震屏，闪烁等处理
	self:dealWithCommonEvents(event,self.skillInfo)

	--"attack"事
	local result1,result2 = self:checkIsAttackEvent(event,self.skillInfo)
	if result1 then
		self:dealWithAttackEvent_AllTargets(result2,event)
	end

	--"autoplay"事件
	result1 = self:checkIsAutoplayEvent(event)
	if result1 then
		if self.skillInfo.res_scene ~= "" then
			self:playSceneEffect_AllTargets()
		elseif self.skillInfo.res_fly ~= "" then
			self:playFlyEffect_AllTargets()
		end
	end

	--"cutin"事件
	local result_cutin = self:checkIsCutInEvent(event)
	if result_cutin == 1 then
		G_GameState = 3
		SkillUtil:playCutIn(self.entity)
		if not self.entity.isBoss then
			ActiveSkillManager:refreshSkillWhenCutIn(self.entity.skill[2])
		end
	elseif result_cutin == 2 then
		SkillUtil:playEndCutIn(self.entity)
	end

end

--角色动作里的attack事件
function State_PlayingSkill_Target_Entity:dealWithAttackEvent_AllTargets(idx,event)
	if self.entity.isDead then
		return
	end

	self.entitiesEffected = self:generateEffectedListForTargetSkill()

	for k,v in ipairs(self.entitiesEffected) do
		self:dealWithAttackEvent_OneTarget(idx,v,event)
	end
end

--一定在目标身上播放。
function State_PlayingSkill_Target_Entity:playSceneEffect_AllTargets()
	if self.skillInfo.res_scene == "" or self.entity.isDead then
		return
	end

	self.entitiesEffected = self:generateEffectedListForTargetSkill()

	for k,v in ipairs(self.entitiesEffected) do
		local effectSpineNode = CreateEffectSpineNode(self.skillInfo.res_scene)
		table.insert(G_NodesWithSpine,effectSpineNode)
		v:addChild(effectSpineNode)

		local this = self;
		local function eventCallback(event)
			--震屏，闪烁等处理
			this:dealWithCommonEvents(event,this.skillInfo)

			--"attack"事件
			local result1,result2 = this:checkIsAttackEvent(event)
			if result1 then
				this:dealWithAttackEvent_OneTarget(result2,v,event)
			end

			--"autoplay"事件，目标类技能的场景特效里只可能出现autoplay事件
			result1 = this:checkIsAutoplayEvent(event)
			if result1 then
				if this.skillInfo.res_fly ~= "" then
					this:playFlyEffect_OneTarget(v)
				else
					print("此时res_fly不能为空,playSceneEffect_AllTargets()")
				end
			end
		end

		effectSpineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
		RemoveEffectOnComplete(effectSpineNode)
	end
end

--一定在目标身上播放。
function State_PlayingSkill_Target_Entity:playFlyEffect_AllTargets()
	if self.skillInfo.res_fly == "" or self.entity.isDead then
		return
	end

	self.entitiesEffected = self:generateEffectedListForTargetSkill()

	for k,v in ipairs(self.entitiesEffected) do
		self:playFlyEffect_OneTarget(v)
	end
end

--一定在目标身上播放。
function State_PlayingSkill_Target_Entity:playFlyEffect_OneTarget(entity)
	local effectSpineNode = CreateEffectSpineNode(self.skillInfo.res_fly)
	table.insert(G_NodesWithSpine,effectSpineNode)
	
	entity.effectNode:addChild(effectSpineNode)

	local this = self;
	local function eventCallback(event)

		--震屏，闪烁等处理
		this:dealWithCommonEvents(event,this.skillInfo)

		--"attack"事件
		local result1,result2 = this:checkIsAttackEvent(event)
		if result1 then
			this:dealWithAttackEvent_OneTarget(result2,entity,event)
		end
	end

	effectSpineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
	RemoveEffectOnComplete(effectSpineNode)
end

function State_PlayingSkill_Target_Entity:dealWithAttackEvent_OneTarget(idx,target,event)
	--注：如果hit_num>1,则在目标身上爆炸，而且是范围攻击。治疗和buff类的一定是1.但是很多都配成了100.强制纠正成1.

	local hitData = self.skillInfo.skillData.skill_attack_hit[idx]
	if not hitData then
		print("配错表了，State_PlayingSkill_Target_Entity:dealWithAttackEvent_OneTarget")
		return
	end

	--治疗音效
	if hitData.hit_type == 1 and not self.isHealSoundPlayed then
		self.isHealSoundPlayed = true
		BattlePlaySound(BattleGlobals.Sound_Heal,false,0)
	end

	--治疗类或buffdebuff类
	if hitData.hit_type >= 1 then
		self:onCauseDamage(1,self.entity,target,event,self.skillInfo.skillData,idx)
		return
	end

	--伤害类
	local hit_num = hitData.hit_num
	if hit_num == 1 then
		self:onCauseDamage(1,self.entity,target,event,self.skillInfo.skillData,idx)
	else
		--在目标身上爆炸，范围攻击
		local attackedList = {}

		local posx,posy = target:getPosition()

		local hit_rect = hitData.hit_rec
		local hit_rect_x = posx-hit_rect[3]/2
		local hit_rect_y = posy-hit_rect[4]/2
		local hit_rect_w = hit_rect[3]
		local hit_rect_h = hit_rect[4]
		local damageRange = cc.rect(hit_rect_x, hit_rect_y, hit_rect_w, hit_rect_h)

		local attackedList = self:generateAttackedList(damageRange,cc.p(posx,posy),self.skillInfo,hitData)

		for k,v in pairs(attackedList) do
			self:onCauseDamage(1,self.entity,v,event,self.skillInfo.skillData,idx)
		end
	end
end

function State_PlayingSkill_Target_Entity:onSpineCompleteCallback(event)
	if self.entity.isBoss then
		self.entity.fsm:changeState(StateEnum.Attacking_Boss)
	else
		--技能释放完毕。切换到RunningToEnemy状态
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)		
	end
end