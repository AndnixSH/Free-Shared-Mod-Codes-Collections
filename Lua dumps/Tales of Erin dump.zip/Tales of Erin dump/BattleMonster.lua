--怪物类
--created by kobejaw.2018.3.22.
BattleMonster = class("BattleMonster",EntityBase)

function BattleMonster:ctor(data,x,y,teamManager)
	self.entityType = BattleGlobals.EntityType.Monster
	self.super.ctor(self,data,teamManager)

	self:initMemberVariables();
	self:createSpineNode(x,y);
	self:initSpineListeners() --初始化spine事件监听

	self.hpBar = HPBar:create(self)
	self:addChild(self.hpBar)	
end

function BattleMonster:initMemberVariables()

	self.faceTo = BattleGlobals.FaceLeft

	if #self.data.activeSkillArray > 0 then
		if self.attackData then
			self.monsterType = 2;--既能普通攻击又能技能攻击的小怪
		else
			self.monsterType = 3;--只会技能攻击的小怪
		end
		self.skillManager = MonsterSkillManager.new(self)
	else
		self.monsterType = 1;--只会普通攻击的小怪
	end

	self:setTeammateAndEnemyList()

	--设置触摸框信息和角色中心点坐标
	self:setTouchRectInfo()

	--音效资源
	--boss特有：死亡
	--角色和小怪都有：普攻
	--角色和boss都有：战斗开始
	--角色特有：大招音效，大招语音，小招音效，战斗胜利，战斗失败。
	local monsterId = self.data.monsterId

	if self.data.hitSound and self.data.hitSound ~= "" then
		self.sound_normalAtk = self.data.hitSound
	else
		self.sound_normalAtk = monster[monsterId].monster_vce[1]
	end

	self.fsm = EntityFSM.new(self);
end

function BattleMonster:createSpineNode(x,y)
	local spineData = BattleCacheManager:getData(self.data.spineFullPath)
	local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
	self.spineNode = spineNode;

	self:addChild(spineNode)
	
	local pos = GetCorrectedPoint(x,y)
	self:setPosition(pos)

	self.box_w,self.box_h = GetBoxWHByPoint(pos.x,pos.y)--设置位置信息

	self.fsm:changeState(StateEnum.Idling)

	--buff特效的父节点
	self.effectNode = cc.Node:create()
	self:addChild(self.effectNode)
	self.effectNode:setPosition(cc.p(0,(self.touchRect[2] + self.touchRect[4])/2))

end

function BattleMonster:update(dt)

	if G_GameState == 1 then
		self.deltaForUpdate = self.deltaForUpdate + dt
		self.idxForUpdate = self.idxForUpdate + 1

		if self.idxForUpdate == 3 then		
			--组件管理器更新
			self.componentManager:update(self.deltaForUpdate)
			--触发器管理器更新
			self.triggerManager:update(self.deltaForUpdate)
			--血条显示
			self.hpBar:update(self.deltaForUpdate)

			--更新怪物技能
			if self.skillManager then
				self.skillManager:update(self.deltaForUpdate)
			end

			self.idxForUpdate = 1
			self.deltaForUpdate = 0
		end
	end
end

function BattleMonster:onDead()
	if self.fsm.currentState.stateEnum == StateEnum.UnusualCondition and self.fsm.currentState.stateType ~= 5 and not self.fsm.currentState.isStandingUp then
		--do nothing,落地后再检测
	else
		self.fsm:changeState(StateEnum.Dead)
	end
end

--监测是否所有敌人都死了
function BattleMonster:checkIsAllEnemiesDead()
	if BattleRuntimeInfo.team1EntityNum <= 0 then
		self.fsm:changeState(StateEnum.Idling)
		return true
	else
		return false
	end
end

--检测一下格子是否可进入
--怪物可以重叠一次
--2018.11.26.个别关卡在同一个出生点配了无数小怪，为规避小怪无处可去的情况，调整为小怪可以无限重叠。
function BattleMonster:checkBoxAvailableByWH(w,h)
	for k,v in ipairs(G_Roles) do
		if not v.isDead and w == v.box_w and h == v.box_h then
			return false
		end
	end

	--[[
	local num = 0;
	for k,v in ipairs(G_Monsters) do
		if not v.isDead and w == v.box_w and h == v.box_h then
			num = num + 1
		end
	end
	if num >= 5 then
		return false
	end
	]]

	return true	
end

--2018.11.26.个别关卡在同一个出生点配了无数小怪，为规避小怪无处可去的情况，调整为小怪可以无限重叠。
function BattleMonster:checkBoxAvailableByIdx(idx)
	for k,v in ipairs(G_Roles) do
		if not v.isDead and idx == v.box_w*3 + v.box_h then
			return false
		end
	end

	--[[
	local num = 0;
	for k,v in ipairs(G_Monsters) do
		if not v.isDead and w == v.box_w and h == v.box_h then
			num = num + 1
		end
	end
	if num >= 5 then
		return false
	end
	]]

	return true
end