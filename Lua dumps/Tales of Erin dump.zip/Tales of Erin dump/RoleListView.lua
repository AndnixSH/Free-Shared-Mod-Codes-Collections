--require "XUIView"
--require "XUIGridView"
--require "RoleListItemView"
--require "BackgroundView"

RoleListView = class("RoleListView",XUIView)
RoleListView.CS_FILE_NAME = "RoleListView.csb"
RoleListView.CS_BIND_TABLE = 
{
    panelSort = "/i:332/s:panelSort",
    panelList = "/i:332/i:334"
}

function RoleListView.createWithBackBtn()
    local v = RoleListView.new():init()
    --local b = BackgroundView.new():initWithBackBtn(v,"n_UIShare/Global_UI/bg/bg_002.png")
    local b
    if g_channel_control.b_newRole then
        b = BackgroundView.new():initWithBackBtn(v)
    else
        b = BackgroundView.new():initWithCloseBtn(v)
    end
    return b,v
end

function RoleListView:init()
    RoleListView.super.init(self)
    
    self.bShowSkillPoint = false

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = RoleListItemView.new():init()

        temp:setShowSkillPoint(self.bShowSkillPoint)

        if self.drop_info_list ~= nil then
            temp:setDropList(self.drop_info_list)
        end

        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end

        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = self.sortBtnView:getSortMode() % 10
            item:setTitleMode(smode)

            self:onItemReset(item)
        end

        return temp
    end

    --排序
    self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_x",213,0)
    self.sortBtnView.sortModeChangedEvent = function()
        self:refresh()
    end
    --

    return self
end

function RoleListView:setShowSkillPoint(isShow)
    self.bShowSkillPoint = isShow
end

function RoleListView:onItemClicked(item)    
    if self.ItemClickedEvent then
        self.ItemClickedEvent(item)
    end
end

function RoleListView:onItemReset(item)    
    if self.ItemResetEvent then
        self.ItemResetEvent(item)
    end
end

function RoleListView:setDropList(dropInfoList)
    self.drop_info_list = nil
    self.drop_info_list = table.deepcopy(dropInfoList)
end

function RoleListView:getDataSource(sort_mode)
    if self.dataSourceEvent then
        return self.dataSourceEvent(self,sort_mode)
    else
        local dataset =  table.deepcopy(hero_list)
        SortBoxView.SortRole (dataset, sort_mode ,true)
        return dataset
    end
end

function RoleListView:refresh()
    --先排序，后刷列表  equip_list
    local ds = self:getDataSource(self.sortBtnView:getSortMode())

    self.currentDataSource = ds
    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(ds)
    self.gridview:jumpToPercent(percent)
end