--技能实体
--created by kobejaw.2018.4.23.
RoleActiveSkill = class("RoleActiveSkill")
RoleActiveSkill.BATTLE_SK_COM = "uifile/battle_eff_rolesk.csb"
RoleActiveSkill.BATTLE_SK_CD = "uifile/Battle_effect_sk_cd.csb"
--type,1.小技能。2.大招
function RoleActiveSkill:ctor(fatherNode,role,type)
	self:init(fatherNode,role,type)
end

function RoleActiveSkill:init(fatherNode,role,type)

	self.isChanged = false

	self.fatherNode = fatherNode
	self.role = role
	role.skill[type] = self
	role.skillPanel = fatherNode
	role.componentManager:setPanelNode(fatherNode)  --传到组件管理器里。
	self.type = type
	--传给技能状态的data必须包含以下数据
	local skillId = role.data.activeSkillArray[type];

	if self.type == 1 then
		self.skillInfo = SkillUtil:createSkillInfo(skillId)
	else
		self.skillInfo = SkillUtil:createSkillInfo(skillId,true)
	end

	self.changedSkillInfo = nil --变换后的技能信息。变技能的角色会用到。

	self.img = fatherNode:getChildByTag(2*type)
	self.maskSprite = cc.Sprite:create("uifile/n_UIShare/zhandou/newzd/ji_neng_cd.png")

	self.isReady = false;
	self.cdType = 1 --1:走自己的cd。2：走公共cd（只限大招）
	self.skillCD = role.data["skill_cd_"..type]--cd时间
	self.cdTime = self.skillInfo.start_cd
	self.remainTime = self.skillInfo.start_cd;           --cd剩余时间

	self.maskSprite:setAnchorPoint(cc.p(0.5,1))
	self.maskSprite:setPosition(39,78)
	self.maskSprite:setScaleY(0)
	self.img:addChild(self.maskSprite);
	self.img:loadTexture(self.skillInfo.skillData.skill_icon)
	self.img:setTouchEnabled(true)
    
    self.actionNode = self.fatherNode:getChildByTag(9+type)
    self.actionNode:setVisible(false)

    self.action = cc.CSLoader:createTimeline(self.BATTLE_SK_COM)
    if self.actionNode ~= nil then
		self.actionNode:runAction(self.action)
		self.action:play("play",true);
		self.action:pause();
    end

	--技能描述相关
	self.skillDesc = fatherNode:getChildByTag(12)

	self.isTouching = false         --是否点击
	self.isSkillDescShowing =false --技能描述展示中
	self.skillDesc_remainTime = BattleGlobals.TouchTimeForSkillInfoShow  --按下超过1秒弹出描述。

	local this = self;
    self.img:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.began then
        	this.isTouching = true
        elseif eventType == ccui.TouchEventType.ended  then
        	if not this.isSkillDescShowing then
	  			if this.isReady then
					if this:checkCanPlaySkill() then
						this:playSkill()
					end
				end   		
        	end

    	    this.isSkillDescShowing = false
    		this.isTouching = false
    		this.skillDesc:setVisible(false)
    		this.skillDesc_remainTime = BattleGlobals.TouchTimeForSkillInfoShow  

        elseif eventType ==ccui.TouchEventType.canceled then
    		self.isSkillDescShowing = false
    		self.isTouching = false
    		this.skillDesc:setVisible(false)
    		self.skillDesc_remainTime = BattleGlobals.TouchTimeForSkillInfoShow
        end 	
    end)
end

--释放技能
function RoleActiveSkill:playSkill()
	self.isReady = false
	if self.isChanged then
		if self.changedSkillInfo and self.changedSkillInfo.skill_cd then
			self.cdTime = self.changedSkillInfo.skill_cd
		else
			self.cdTime = self.skillCD
		end
	else
		self.cdTime = self.skillCD
	end
	
	self.remainTime = self.skillCD
	self.maskSprite:setScaleY(1)
	self.actionNode:setVisible(false)
	self.action:pause();
	if self.isChanged then
		self.role.fsm:changeState(self.changedSkillInfo.skillStateEnum,self.changedSkillInfo)
	else
		self.role.fsm:changeState(self.skillInfo.skillStateEnum,self.skillInfo)
	end

	ActiveSkillManager:removeFromAutoPlayList(self)
end

function RoleActiveSkill:update(dt)
	--弹出介绍
	if self.isTouching and not self.isSkillDescShowing then
		self.skillDesc_remainTime = self.skillDesc_remainTime - dt
		if self.skillDesc_remainTime <= 0 then
			local info
			if self.isChanged then
				info = self.changedSkillInfo
			else
				info = self.skillInfo
			end

			self.skillDesc:getChildByTag(123):setString(GetStringAllPlatform(info.skillData.skill_des)) --详细介绍
			self.skillDesc:getChildByTag(121):setString(GetStringAllPlatform(info.skillData.skill_name)) --名称

			local timeText = self.skillDesc:getChildByTag(122)
			if not self.skillDesc.isFirstShow then
				timeText:setPosition(cc.p(timeText:getPositionX() + 20,timeText:getPositionY()))
			end
			if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
				timeText:setString(info.skillData.skill_cd.."秒") --cd时间
			else
				timeText:setString(info.skillData.skill_cd .. Lang:toLocalization(1010073)) --cd时间
			end
			self.skillDesc.isFirstShow = true

			self.skillDesc:setVisible(true)
			self.isSkillDescShowing = true
			
		end
	end

	--cd
	if not self.isReady then
		self.remainTime = self.remainTime - dt
		if self.remainTime < 0 then
			self.isReady = true
			self.cdType = 1;
			self.maskSprite:setScaleY(0)
			table.insert(ActiveSkillManager.autoPlayList,self)

			self.action2Node = self.fatherNode:getChildByTag(12+self.type)
		    local action = cc.CSLoader:createTimeline(self.BATTLE_SK_CD)
		    self.action2Node:runAction(action)

		    local this = self
		    local function hiddenActionNode()
				this.action2Node:setVisible(false)
		    end
		    self.action2Node:setVisible(true)
		    self.actionNode:setVisible(true)
		    self.action:resume();
			
		    action:play("play",false);

		    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS  then
		    	action:setLastFrameCallFunc(hiddenActionNode)
		    else
		    	PerformWithDelayTime(hiddenActionNode,1.5)
		    end
		else
			if self.type == 1 then
				self.maskSprite:setScaleY(self.remainTime/self.cdTime)
			else
				if self.cdType == 1 then
					self.maskSprite:setScaleY(self.remainTime/self.cdTime)
				else
					self.maskSprite:setScaleY(self.remainTime/4)
				end
			end
		end
	end
end

--检测是否能放技能
function RoleActiveSkill:checkCanPlaySkill()
	if not self.isReady then
		return false
	end

	if G_GameState ~= 1 then
		return
	end
	--技能中或者摆pose中
	if self.role.fsm.currentState.isSkill or self.role.fsm.currentState.stateEnum == StateEnum.Posing then
		return false
	--在天上飞着
	elseif self.role.fsm.currentState.stateEnum == StateEnum.UnusualCondition then
		return false
	--眩晕中
	elseif self.role.componentManager:checkIsInVertigo() then
		return false
	end
	return true
end

--改变技能的cd时间。
function RoleActiveSkill:changeCD(t)
	self.remainTime = self.remainTime + t
end

--重置技能的cd时间
function RoleActiveSkill:resetCD()
	self.remainTime = 0
end

--变换技能
function RoleActiveSkill:changeSkill(skillId)
	self.isChanged = true
	
	if self.isReady then
		ActiveSkillManager:removeFromAutoPlayList(self)
		self.isReady = false
	end

	--if not self.changedSkillInfo then
	if self.type == 1 then
		self.changedSkillInfo = SkillUtil:createSkillInfo(skillId)
	else
		self.changedSkillInfo = SkillUtil:createSkillInfo(skillId,true)
	end
	--end
	self.actionNode:setVisible(false)
	self.action:pause();
	self.isReady = false
	self.remainTime = self.changedSkillInfo.start_cd
	self.cdTime = self.changedSkillInfo.skill_cd
	self.maskSprite:setScaleY(self.remainTime/self.cdTime)
	self.img:loadTexture(self.changedSkillInfo.skillData.skill_icon)
end

--变回以前的技能。
function RoleActiveSkill:changeBackSkill()
	self.isChanged = false
	if self.isReady then
		ActiveSkillManager:removeFromAutoPlayList(self)
		self.isReady = false
	end
	self.actionNode:setVisible(false)
	self.action:pause();	
	self.remainTime = self.skillInfo.skill_cd
	self.cdTime = self.skillCD
	self.maskSprite:setScaleY(self.remainTime/self.cdTime)
	self.img:loadTexture(self.skillInfo.skillData.skill_icon)
end

--复活时调用
function RoleActiveSkill:onRevive()
	self.isReady = false
	self.isChanged = false
	self.actionNode:setVisible(true)
	self.action:resume();
	self.remainTime = 0
end
