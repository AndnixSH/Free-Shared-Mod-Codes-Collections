--[[
	PlayerCardLayer.lua
	玩家信息卡片页面

    现在改成 一个子页面 去除背景 、去除返回按钮

    一个参数 sManager
    local sData = {}
    sData["sManager"] =  self
    local layer = PlayerCardLayer:create(sData)

]]
require "BasicLayer"
PlayerCardLayer = class("PlayerCardLayer",BasicLayer)
PlayerCardLayer.__index = PlayerCardLayer
PlayerCardLayer.lClass = 3

function PlayerCardLayer:create(rData)
    local layer = PlayerCardLayer.new()
    layer.rData = rData
    layer.uiLayer = cc.Layer:create()
    layer:init()
    return layer
end

function PlayerCardLayer:init()
    self.m_IconID = nil
    self.m_skeletonNode =nil 
    self.m_titleID = nil
    self.m_titleSkeletonNode =nil 
    self.sManager = self.rData["sManager"]
    self.nRenameCardNum = 0

    local node = cc.CSLoader:createNode("PlayerCardLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    self._rootCSbNode = node:getChildByTag(102) 

    self:initUIEmelent()
    self:addIconSpine() --添加头像
    self:refreshTitleUI()--添加称号

    --注册返回键
    --界面元素，不需要监听返回键
    -- KeyboardManager:registeredKeyBoardEvent(self,function ()
    --     -- body
        
    -- end)
    self:initJumpUpdateBtn();
end

--初始化控件
function PlayerCardLayer:initUIEmelent()
    --name
    self._labName = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_name")
    if g_channel_control.PlayerCardLayerUseName == true then 
        self._labName:setPosition(cc.p(150,496)) --欧美服右移名字
    end
    --id
    self._labID = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_id")
    --level冒险等级哦
    self._labLv = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_lv")
    --冒险经验
    self._labExp = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_exp")
    --expbar
    self._labExpBar = ccui.Helper:seekWidgetByName(self._rootCSbNode, "bar1")

    --level探索等级哦
    self._labExploreLv = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_lv_1")
    --探索经验
    self._labExploreExp = ccui.Helper:seekWidgetByName(self._rootCSbNode, "lab_exp_1")
    --expbar
    self._labExploreBar = ccui.Helper:seekWidgetByName(self._rootCSbNode, "bar1_1")

    --称号root
    self._spineTitleNode = ccui.Helper:seekWidgetByName(self._rootCSbNode, "spinetitleNode")
    

    local function onBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender:getTag() == 1000 then
                self:ReqGetChangeNameNum()
            elseif sender:getTag() == 1001 then 
                self:changeDescripthon()
            elseif sender:getTag() == 1003 then
                self:ExchangeCallBack()
            elseif sender:getTag() == 1004 then
                self:showSysCfg()
            else 
                self:changeImg()
            end 
        end
    end
    --更改名字
    local changeNameBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_changeName")
    changeNameBtn:addTouchEventListener(onBtnEvent)
    changeNameBtn:setTag(1000)
    if g_channel_control.playerCardlayerHideChangeName == true then
        changeNameBtn:setVisible(false)
    end
    --更改个性签名
    local changeDesBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_changeDes")
    changeDesBtn:addTouchEventListener(onBtnEvent)
    changeDesBtn:setTag(1001)
    self.changeDesBtn = changeDesBtn
    --self.changeDesBtn:setVisible(false)
    --更改图片
    local changeImgBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_changeImg")
    changeImgBtn:addTouchEventListener(onBtnEvent)
    changeImgBtn:setTag(1002)
    --礼品码兑换按钮
    local ExchangeBtn   = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_Exchange")
    ExchangeBtn:addTouchEventListener(onBtnEvent)  -- 
    ExchangeBtn:setTag(1003)

    local SysCfgBtn   = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_Syscfg")
    SysCfgBtn:addTouchEventListener(onBtnEvent)  -- 
    SysCfgBtn:setTag(1004)
    --描述
    self._inputDes = ccui.Helper:seekWidgetByName(self._rootCSbNode, "descrption")
    self._inputDes:setContentSize(cc.size(442,100))
    ---用户中心
    local function onBtnUserEvent(sender,eventType)

        if eventType == ccui.TouchEventType.ended then
            --SDKManagerLua:showUserCenter(1)
            SysCustomerService:showCustom()

            -- local testCenterUrl = "http://qa.mobileuser.playwith.co.kr/QNA/Write";
            -- local centerUrl = "http://mobileuser.playwith.co.kr/QNA/Write";
            -- local userId = user_info["id"];
            -- local userName = user_info["name"];
            -- local url = centerUrl.."?pAppId=1700A38C-BC13-4902-BADF-756EB01227C5"
            --         .."&pRegUserId="..userId.."&pNickName="..userName

            -- cc.Application:getInstance():openURL(url)

        end
    end

    local userCenterBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode, "btn_user_center")
    userCenterBtn:addTouchEventListener(onBtnUserEvent)

    if g_channel_control.b_show_cdkey_btn == false then
        ExchangeBtn:setVisible(false)
    end
    
    
    if CHANNEL.Android.CHANNEL_CODE_YJ ~= GAME_CHANNEL then
      local text =  userCenterBtn:getChildByTag(74)
      local serviceCenterName = g_channel_control.serviceCenterName
      text:setString(UITool.ToLocalization(serviceCenterName)) --注销登录
    end   

    if CHANNEL.Android.CHANNEL_CODE_XM == GAME_CHANNEL then
       userCenterBtn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_JL == GAME_CHANNEL then
       userCenterBtn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_HW == GAME_CHANNEL then
       userCenterBtn:setVisible(false)
    elseif CHANNEL.Android.CHANNEL_CODE_OP == GAME_CHANNEL then
       userCenterBtn:setVisible(false)
    ---cn 暂时全部隐藏
    elseif CHANNEL.Android.CHANNEL_CODE_CN == GAME_CHANNEL then
       userCenterBtn:setVisible(false)
    end

    ---修改称号
    local function onChangeTitleEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
           --todo 弹出称号修改版
            local rcvData = {}
            rcvData["sDelegate"] =  self
            rcvData["refreshFunc"] =  self.refreshTitleUI
            self.sManager:toSelectPlayerTitleLayer(rcvData)
        end
    end
    local changeTitleBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode, "btn_change_title")
    changeTitleBtn:addTouchEventListener(onChangeTitleEvent)

    self:updateUI()
end

--初始化跳转到热更页面的按钮
function PlayerCardLayer:initJumpUpdateBtn()
    if g_channel_control.isOpenJumpToUpdate and g_channel_control:isOpenJumpToUpdate() then
        print("isOpenJumpToUpdate")
        local jumpBtn = ccui.Button:create("uifile/n_UIShare/Global_UI/btn/cjxt_b_002_1.png","uifile/n_UIShare/Global_UI/btn/cjxt_b_002_2.png");
        jumpBtn:setPosition(830,670)
        self.uiLayer:addChild(jumpBtn,1000)
        jumpBtn:setTitleText("jump")
        jumpBtn:setTitleColor(cc.c3b(255, 255, 255))
        jumpBtn:setTitleFontSize(30)
        
        jumpBtn:addClickEventListener(function()
            print("click jumpBtn")
            --在登陆界面修复客户端的时候，sdk的处理方案
            SDKManagerLua:sdkHandleRepairClient()
            SceneManager:reset()
            UpdateManager:checkUpdate()
        end)
    end
end

--刷新称号
function PlayerCardLayer:refreshTitleUI()
    dump("刷新称号")
    local iconId = user_info["title_id"]
    if self.m_titleID == nil or self.m_titleID ~= iconId then 
        
        self.m_titleID = iconId

        local spineNameStr = title_conf[iconId].res_spine
        if self.m_titleSkeletonNode ~=nil then 
            self.m_titleSkeletonNode:stopAllActions()
            self.m_titleSkeletonNode:removeFromParent()
            self.m_titleSkeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local spineParent = ccui.Helper:seekWidgetByName(self._rootCSbNode,"spinetitleNode")
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            self.m_titleSkeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            spineParent:addChild(self.m_titleSkeletonNode)
            self.m_titleSkeletonNode:setAnimation(1, "effect", true)
            spineParent:setVisible(false)
            local dt = cc.DelayTime:create(0.01)
            local cf = cc.CallFunc:create(function()
                self.m_titleSkeletonNode:setPosition(self.m_titleSkeletonNode:getBoundingBox().width/2,-1)  
                spineParent:setVisible(true)
            end)
            local seq = cc.Sequence:create(dt,cf)
            spineParent:runAction(seq)
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 
end

--礼品码兑换回调函数    弹出输入框
function PlayerCardLayer:ExchangeCallBack( ... )
    -- body
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.ExchangeSend --确定按钮
    rcvData["defalutStr"]  = ""
    rcvData["maxLength"] = 42
    self.inputLayer = self.sManager:toInputModelLayer(rcvData)
end
-- 获取礼品兑换码  向服务器验证
function PlayerCardLayer:ExchangeSend(newNameStr)
    -- body
    self.ExchangeStr = newNameStr

    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            --MsgManager:showSimpMsg(t_data["data"]["warning"])
            --failesFunc()
            local color = cc.c3b(255,0,255)
            SceneManager:showPromptLabel(UITool.getUserLanguage(t_data["data"]["warning"]),color)
            return
        end
        local color = cc.c3b(255,0,255)
        local str = UITool.ToLocalization("恭喜您,兑换成功！\n已发送到您邮箱请查收。")
        SceneManager:showPromptLabel(str,color)
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "cdkey_get",
        ["cdkey_id"] = self.ExchangeStr,
    }

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
    -- 测试代码 需链接服务器
    

end

function PlayerCardLayer:updateUI()
    -- value
    local expStr = user_info["exp"].."/"..user_info["exp_max"]
    local lvStr = ""..user_info["rank"]
    --name
    self._labName:setString(user_info["name"])
    --id
    self._labID:setString(user_info["id"])
    --level冒险等级哦
    self._labLv:setString(lvStr)
    if g_channel_control.transform_PlayerCardLayer_lab_lv_pos == true then
        local labLvX = 146
        local newLabLvX = labLvX - 15
        self._labLv:setPositionX(newLabLvX)
    end
    --冒险经验200/300
    self._labExp:setString(expStr)
    --个性签名
    self:updateSignature()
    --expbar
    self._labExpBar:setPercent(100 * user_info["exp"]/user_info["exp_max"])
    --探索
    local explorelvStr = ""..user_info["explore_lv"] 
    local expPrecentValue = math.floor(user_info.explore_exp/user_info.explore_max_exp*100)
    local exploreStr = user_info["explore_exp"].."/"..user_info["explore_max_exp"]
    self._labExploreLv:setString(explorelvStr)
    if g_channel_control.transform_PlayerCardLayer_lab_lv_1_pos == true then
        local labExploreLvX = 146
        local newLabExploreLvX = labExploreLvX - 15
        self._labExploreLv:setPositionX(newLabExploreLvX)
    end
    self._labExploreExp:setString(exploreStr)
    self._labExploreBar:setPercent(expPrecentValue)

end
--更新签名
function PlayerCardLayer:updateSignature( ... )
    local desStr = UITool.ToLocalization("我来自苍蓝境界,请多关照")
    if user_info["signature"] ~= nil and user_info["signature"] ~= "" then
        desStr = user_info["signature"]
    end
    local strDes = UITool.ToLocalization("个性签名: \n")..desStr
    self._inputDes:setString(strDes)
end
--玩家头像spine 添加和刷新两种功能
function PlayerCardLayer:addIconSpine()
    -- body
    local iconId = user_info["pl_icon_id"]
    if self.m_IconID == nil or self.m_IconID ~= iconId then 
        self.m_IconID = iconId

        local spineNameStr =  hero[iconId].hero_des_spi
        --spineNameStr = "Resources/armatures/lihuispine/Lihui_156.atlas" --testCode
        if self.m_skeletonNode ~=nil then 
            self.m_skeletonNode:stopAllActions()
            self.m_skeletonNode:removeFromParent()
            self.m_skeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local spineParent = ccui.Helper:seekWidgetByName(self._rootCSbNode,"spineRoot")
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            self.m_skeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            self.m_skeletonNode:setAnimation(1, "effect1", true)
            spineParent:addChild(self.m_skeletonNode)
            self.m_skeletonNode:setPosition(0,0)  
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 

end

--弹出修改名字窗口
function PlayerCardLayer:ChangeNameInput()
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.ReqCheckNewName 
    rcvData["defalutStr"] = user_info["name"]
    rcvData["maxLength"] = 6
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    self.inputLayer = self.sManager:toInputModelLayer(rcvData)
end

--获取改名卡数量
function PlayerCardLayer:ReqGetChangeNameNum()

    local function callback ()
        self:ChangeNameInput()
    end

    local function ReqSuccess(data)
        --todo刷新数据
        if data["rename_cards_num"] ~= nil then
            self.nRenameCardNum = tonumber(data["rename_cards_num"])
            if self.nRenameCardNum > 0 then
                MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("是否消耗 改名卡*1 修改昵称")..string.format(UITool.ToLocalization("\n(改名卡剩余：%d枚"),self.nRenameCardNum)..")",self,callback,nil,true)
            else
                MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("是否消耗 改名卡*1 修改昵称")..string.format(UITool.ToLocalization("\n(改名卡剩余：%d枚"),self.nRenameCardNum)..")",self,callback,nil,false)
            end
        end

    end
    local tempTable = {
        ["rpc"] = "rename_cards_num",
    }
    self:doReq(tempTable, ReqSuccess)
end

--检测新昵称敏感词
function PlayerCardLayer:ReqCheckNewName(newNameStr)

    local function callback ()
        self:ReqChangeName(newNameStr)
    end

    local function ReqSuccess(data)
        --todo刷新数据
        if user_info["name"] ~= nil and newNameStr ~= user_info["name"] then--昵称变更
            GameManagerInst:confirm(UITool.ToLocalization("原昵称:")..user_info["name"]..UITool.ToLocalization("\n新昵称:")..newNameStr..UITool.ToLocalization("\n是否确认修改？"),callback)
        end
    end

    local function ReqFailed(data)
        --todo刷新数据
        self:ChangeNameInput()
    end
    local tempTable = {
        ["rpc"] = "user_name_check",
        ["name"] = newNameStr,
    }
    self:doReq(tempTable, ReqSuccess, ReqFailed)
end

--发送改名请求
function PlayerCardLayer:ReqChangeName(newNameStr)
    self.nowName = newNameStr

    local function ReqSuccess(data)
        --todo刷新数据
        user_info["name"] = self.nowName
        self:updateUI()
        self.sManager.menuLayer:RefshTopBar()
        local str = UITool.ToLocalization("昵称修改成功")
        SceneManager:showPromptLabel(str)
    end
    local tempTable = {
        ["rpc"] = "user_name_change",
        ["name"] = newNameStr,
    }
    self:doReq(tempTable, ReqSuccess)
end

--弹出输入框
function PlayerCardLayer:changeDescripthon()
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.reqChangeDescriptionCreate --确定按钮
    rcvData["defalutStr"] = user_info["signature"] or UITool.ToLocalization("我来自苍蓝境界,请多关照!")
    rcvData["maxLength"] = 42
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    self.inputLayer = self.sManager:toInputModelLayer(rcvData)
end

--到选中头像界面
function PlayerCardLayer:changeImg()
    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] =  self.addIconSpine
    self.sManager:toPlayerCardListLayer(rcvData)     
end

function PlayerCardLayer:reqChangeDescriptionCreate(newDesStr)
    -- body
    --获取数据成功
    local desStr = UITool.ToLocalization("我来自苍蓝境界,请多关照")
    if newDesStr ~= nil or newDesStr ~= "" then
        desStr = newDesStr
    end

    self.newDesStr = desStr
    local function ReqSuccess(data)
        user_info["signature"] = self.newDesStr 
        self:updateSignature()
        --self:updateUI()
        local str = UITool.ToLocalization("保存成功")
        SceneManager:showPromptLabel(str)
    end
    local tempTable = {
        ["rpc"] = "change_pl_sig",
        ["sig_info"] = desStr,
    }
    self:doReq(tempTable, ReqSuccess)
end

function  PlayerCardLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            if failesFunc ~= nil then
                MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,failesFunc)
            else
                MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            end
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function PlayerCardLayer:getEditBox(_img,_size,_pos)
    -- body
    local function editBoxTextEventHandle(strEventName,pSender)
        local edit = pSender
        local strFmt 
        if strEventName == "began" then
        elseif strEventName == "ended" then
            
        elseif strEventName == "return" then
            
        elseif strEventName == "changed" then
            --self.changeDesBtn:setVisible(true)
        end
    end

    local EditName = cc.EditBox:create(_size, _img)
    EditName:setPosition(_pos.x,_pos.y)
    -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    -- -- if kTargetIphone == targetPlatform or kTargetIpad == targetPlatform then
    -- --    EditName:setFontName("Paint Boy")
    -- -- else
    -- --     EditName:setFontName("fonts/Microsoft Yahei.ttf")
    -- -- end
    EditName:setFontName(TEXT_FONT_NAME)
    EditName:setFontSize(22)
    --EditName:setFontColor(cc.c3b(255,0,0))
    EditName:setPlaceHolder(UITool.ToLocalization("点击输入个性签名"))
    EditName:setPlaceholderFont(TEXT_FONT_NAME,22)
    EditName:setPlaceholderFontColor(cc.c3b(255,255,255))
    EditName:setMaxLength(42)
    EditName:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
    EditName:setReturnType(cc.KEYBOARD_RETURNTYPE_DONE)
    --Handler
    EditName:registerScriptEditBoxHandler(editBoxTextEventHandle)
    return EditName
end

function PlayerCardLayer:showSysCfg()
    local view = SysCfgView.new():init()
    GameManagerInst:showModalView(view)
end
