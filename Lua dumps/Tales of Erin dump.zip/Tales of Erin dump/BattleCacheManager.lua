--战斗资源缓存
--created by kobejaw.2018.3.19.
BattleCacheManager = {}

BattleCacheManager.data = {}             --全部

BattleCacheManager.data_Png = {}         --png和jpg资源缓存
BattleCacheManager.data_Atlas = {}       --spine资源缓存
BattleCacheManager.data_ExportJson = {}  --ExportJson资源缓存

--注：type一定要有
--type   1:png和jpg  2:atlas  3:ExportJson.
--data   type为2时才需要data。type1和type3的缓存数据交给cocos管理，传个空字符就行。
function BattleCacheManager:addToCache(name,data,type)
	if not type then
		return
	end

	if self.data[name] == nil then
		self.data[name] = data;
		if type == 1 then
			BattleCacheManager.data_Png[name] = data
		elseif type == 2 then
			if data then
				BattleCacheManager.data_Atlas[name] = data
				data:retain();
			end
		elseif type == 3 then
			BattleCacheManager.data_ExportJson[name] = data
		end
	end
end

function BattleCacheManager:getData(name)
	if self.data[name] then
		return self.data[name]
	else
		if string.find(name, ".atlas") then
			local jsonFilePath = string.gsub(name, ".atlas", ".json")
			local spine = sp.SkeletonAnimation:create(jsonFilePath, name, 1.0)
			self:addToCache(name,spine,2)
			return spine
		end
	end
end

function BattleCacheManager:getDataByType(name,type)
	if type == 1 then
		return BattleCacheManager.data_Png[name]
	elseif type == 2 then
		return BattleCacheManager.data_Atlas[name]
	else
		return BattleCacheManager.data_ExportJson[name]
	end
end

--退出战斗场景时调用
function BattleCacheManager:clearCache()
	for k,v in pairs(self.data_Png) do
		cc.Director:getInstance():getTextureCache():removeTextureForKey(k)
	end

	for k,v in pairs(self.data_Atlas) do
		v:release();
	end	

	for k,v in pairs(self.data_ExportJson) do
		ccs.ArmatureDataManager:getInstance():removeArmatureFileInfo(k)
	end		

	self.data = {}             
	self.data_ExportJson = {}
	self.data_Png = {} 
	self.data_Atlas = {}

	cc.Director:getInstance():getTextureCache():removeUnusedTextures()
end
