require "BasicLayer"

BattleFailedLayer = class("BattleFailedLayer",BasicLayer)
BattleFailedLayer.__index = BattleFailedLayer

function BattleFailedLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, BattleFailedLayer)
    return target
end

function BattleFailedLayer:reqBackInfo()

    local function reiceResultCallBack (data)
        
        data = tolua.cast(data, "PassData");
        if self ~= nil and self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end

        self.back_type = t_data["data"]["back_type"]
        --t_data["data"]["lose_mode"]
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "battle_lose",
        ["battle_mode"] = self.mode
    }

    local mydata =  cjson.encode(tempTable)


    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function BattleFailedLayer:init()

    local node =cc.CSLoader:createNode("BattleFailedLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true;
    self.rootNode = node
    self.type = self.rData["rcvData"]["type"]
    self.mode = self.rData["rcvData"]["mode"]
    
    local topguang = node:getChildByName("Top_guang")
    local acAction = cc.CSLoader:createTimeline("Top_guang.csb")
    topguang:runAction(acAction)
    acAction:play("play",true)

    local strs = {
                 UITool.ToLocalization("强化角色可以获得更多技能点数，多彩的技能才是角色真正的价值。"),
                UITool.ToLocalization("强化灵装，就能大幅提升角色和队伍的基础能力。"),
                UITool.ToLocalization("获得更多角色，能让你的队伍更加全面。召唤用的星石可以从很多地方免费获取。")
                }

    if self.type == 1 then
        --单人
        strs[4] = UITool.ToLocalization("合理使用攻击技能，甚至降临技。在敌人造成更多伤害前击溃他们。")
    else
        --多人
        strs[4] = UITool.ToLocalization("尽可能给魔王施加多种异常状态，并制定生存策略，可以让战斗变得轻松。")
    end

    local panel_1 = node:getChildByTag(2) 

    panel_1:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:returnBack(0)
        end
    end)

   local function touchCallBack(sender,eventType)
        self:returnBack(sender:getTag())
    end

    for i = 1,3 do
        local btn = panel_1:getChildByTag(100 + i)
        btn:addClickEventListener(touchCallBack)
    end

    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack(0)
    end)
    
    for i = 1,4 do
        local lb =  panel_1:getChildByTag(110 + i)
        lb:setString(strs[i])
    end
    self:reqBackInfo()
    self:setNodeLockState()
end 
-- #back_type 1、多人战创建者、2、多人战参加者 3、活动战创建者、
-- # 4、普通关卡无事件点开启 5、普通关卡有新事件点开启 6、素材狗粮本活动关卡
--返回
function BattleFailedLayer:returnBack(tag)
    self.exist = false;
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    if tag == 101 then
        --角色强化
          local sData = {tab = 2}
          DataManager:wAllHeroData({})
	        DataManager:wAllBagData({})
          self.sManager:toRole(sData)
    elseif tag == 102 then
        --装备强化
         user_info["eq"] = {}        
		       DataManager:wAllBagData({})
          local sData = {tab = 2}
           self.sManager:toEquip(sData)
    elseif tag == 103 then
        --抽卡
          self.sManager:toDrawCardLayer()
    elseif self.back_type==4 then
        if self.sManager:getRootNode().SMapRefresh then
            self.sManager:getRootNode():SMapRefresh(2,false)
        end 
    elseif self.back_type==5 then
        if self.sManager:getRootNode().SMapRefresh then
            self.sManager:getRootNode():SMapRefresh(1,false)
        end
    elseif self.back_type==6 then
        if self.sManager:getRootNode().SMapRefresh then
            self.sManager:getRootNode():SMapRefresh(3,false)
        end   
    elseif self.back_type==1 then
        if self.sManager:getRootNode().SMapRefresh then
            self.sManager:getRootNode():SMapRefresh()
        end
    elseif self.back_type==2 then
        if self.sManager:getRootNode().SMapRefresh then
            self.sManager:getRootNode():SMapRefresh()
        end          
    elseif self.back_type==3 then
       --self.sManager:toActLayer("ActPassLayer_1.lua")
        if self.sManager:getRootNode().SMapRefresh then
            self.sManager:getRootNode():SMapRefresh()
        end 
    elseif self.back_type== 7 or self.back_type == 8  then --活动战斗返回
    elseif self.back_type== 9 then --神魔活动
    else
        SceneManager.BattleEndLayer  = nil  
        SceneManager:toStartLayer()
    end
     
    self.sData = {}
    self:clear()
end

function BattleFailedLayer:create(rData)

     local layer = BattleFailedLayer.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end

--设置按钮等级解锁状态
function BattleFailedLayer:setNodeLockState()
    local panel_1 = self.rootNode:getChildByTag(2) 
    local btn = panel_1:getChildByTag(101)
    local btn2 = panel_1:getChildByTag(102)
    local curNodes = {btn, btn2}
    for i=1,#curNodes do
        local config = guide_rank_config["BattleFailedLayer"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        end 
    end  
    --新手引导不显示按钮
    if  NewGuideManager.isStart  == true then   
        for i = 1,3 do
            local btn = panel_1:getChildByTag(100 + i)
            if btn then 
                btn:setVisible(false)
            end 
        end
    end 

end