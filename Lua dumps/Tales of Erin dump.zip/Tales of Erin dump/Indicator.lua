

lemon = lemon or {}

lemon.Indicator = class("Indicator", function()
        return ccui.Layout:create()
    end)

local Indicator = lemon.Indicator


function Indicator:create(count)
    local indicator = Indicator.new()
    indicator:initialize(count)

    return indicator
end

function Indicator:initialize(count)
   self:initData(count)
   self:initUI()
end

function Indicator:initData( count )
    -- body
   self.indicatorMap = {}
   self.indicatorNormal = "n_UIShare/chatNew/lt_b_016b.png"
   self.indicatorSelect = "n_UIShare/chatNew/lt_b_016a.png"
   self.count = count or 0
   self.defaultSize = cc.size(200,20)
   self.defaultGap = 12
end

function Indicator:initUI( ... )
    -- body
    self:setContentSize(self.defaultSize)
    self:initElements()
end

function Indicator:initElements( ... )
    -- body
    local count = self.count
    for i=1,count do
        local normalImg = ccui.ImageView:create(self.indicatorNormal)
        self:addChild(normalImg)
        local normalImgW = normalImg:getContentSize().width
        local normalImgH = normalImg:getContentSize().height
        local deltaW = (count - 1) * self.defaultGap
        local normalImgX = (i - 1) * (normalImgW + self.defaultGap) + (self.defaultSize.width - deltaW)/2 - normalImgW
        local normalImgY = self.defaultSize.height - normalImgH * 3/2
        normalImg:setPosition(cc.p(normalImgX,normalImgY))

        table.insert(self.indicatorMap,normalImg)
    end
    self:setViewVisible()
end

function Indicator:setViewVisible( ... )
    -- body
    self:setVisible(true)
    if self.count <= 1 then
        self:setVisible(false) 
    end
end

function Indicator:setNormalImg(normalImg)
    -- body
    self.indicatorNormal = normalImg or self.indicatorNormal
end

function Indicator:setSelectImg( selectImg )
    -- body
    self.indicatorSelect = selectImg
end

function Indicator:setSelectIndex( index )
    -- body
    local count = #self.indicatorMap
    for i=1,count do
        local item = self.indicatorMap[i]
        if item then
            if index == i then
                item:loadTexture(self.indicatorSelect)
            else
                item:loadTexture(self.indicatorNormal)
            end
        end
    end
end

function Indicator:setIndicatorSize( size )
    -- body
    local indicatorSize = size or self.defaultSize
    self:setContentSize(indicatorSize)
end

function Indicator:setGap( gap )
    -- body
    self.defaultGap = gap
end




