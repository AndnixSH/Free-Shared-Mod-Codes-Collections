--require "XUIView"

NewRoleSoulView = class("NewRoleSoulView",XUIView)
NewRoleSoulView.CS_FILE_NAME = "NewRoleSoulView.csb"
NewRoleSoulView.CS_BIND_TABLE = 
{
    panelList = "/i:87/i:868",
    spSoulEquipIconImage = "/i:87/i:11",
    lbSoulEquipName = "/i:87/i:848/i:14",
    lbRoleName = "/i:87/i:848/i:527",
    --
    barAtk = "/i:87/i:808/i:109",
    barHP = "/i:87/i:808/i:110",
    barAtkAdd = "/i:87/i:808/i:1069",
    barHPAdd = "/i:87/i:808/i:1070",

    lbNumAtk = "/i:87/i:808/i:111",
    lbNumHP = "/i:87/i:808/i:112",
    lbNumAtkAdd = "/i:87/i:808/i:1071",
    lbNumHPAdd = "/i:87/i:808/i:1072",

    lbCurLv = "/i:87/i:808/i:113",
    lbExpNext = "/i:87/i:808/i:115",
    barExp = "/i:87/i:808/i:116",
    --
    spSublStage1 = "/i:87/i:808/i:102/i:202",
    spSublStage2 = "/i:87/i:808/i:103/i:204",
    spSublStage3 = "/i:87/i:808/i:104/i:206",
    spSublStage4 = "/i:87/i:808/i:105/i:208",
    spSublStage5 = "/i:87/i:808/i:106/i:210",
    --
    skDescPanel = "/i:87/i:1755",
    lbSkillDesc = "/i:87/i:1755/i:1758",

    btnSth = "/i:87/i:848/i:466",
    btnSubl = "/i:87/i:848/i:468",
    panelViews = "/i:682",
    --
    lockEffectPos = "/i:87/i:848/i:330",
    lbLockedPanel = "/i:87/i:808/i:50",
    lbLockedRoleName = "/i:87/i:808/i:50/i:49",
    lbLockedTitle = "/i:87/i:808/i:50/i:110",
    spInfoBg = "/i:87/i:808/i:101",
    --
    lbClickLock = "/i:87/i:848/i:378",
}

NewRoleSoulView.curClickedSkillId = 0
NewRoleSoulView.curSkillDescState = false

function NewRoleSoulView.createWithBackBtn()
    local v = NewRoleSoulView.new():init()
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function NewRoleSoulView:init(nHeroId,ReLoadCallFunc,reloadSoulFinish,sDelegate)
    NewRoleSoulView.super.init(self)
    self.exist = true
    
    self.hero_id = nHeroId
    --
    self.ReLoadCallFunc = ReLoadCallFunc
    self.reloadSoulFinish = reloadSoulFinish
    self.sDelegate = sDelegate
    self.sSoulDelegate = sDelegate
    --

    self.views = XUIView.new():init(self.panelViews)
    --self:InitSoulSthView()
    --self:InitSoulSublView()
    --

    self.spSoulEquipIconImage:setVisible(false)
    self.spSoulEquipIconImage:setColor(cc.c3b(127, 127, 127))
    self.lbSoulEquipName:setString("")
    self.lbRoleName:setString("")

    if g_channel_control.transform_NewRoleSoulView_lbSoulEquipName_Alignment == true then 
        self.lbSoulEquipName:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.lbSoulEquipName:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.lbSoulEquipName:ignoreContentAdaptWithSize(false);
        self.lbSoulEquipName:setTextAreaSize(cc.size(180,80))
        self.lbSoulEquipName:setPosition(cc.p(0,-280))
        self.lbSoulEquipName:setFontSize(28)

    end 

    if g_channel_control.transform_NewRoleSoulView_lbRoleName_pos == true then
        self.lbLockedRoleName:setVisible(false);
        self.lbLockedTitle:setPosition(170,15);
    end

    self.barAtk:setPercent(0)
    self.barHP:setPercent(0)
    self.barAtkAdd:setPercent(0)
    self.barHPAdd:setPercent(0)

    self.lbNumAtk:setString("")
    self.lbNumHP:setString("")
    self.lbNumAtkAdd:setString("")
    self.lbNumHPAdd:setString("")

    self.lbCurLv:setString("")
    self.lbExpNext:setString("")
    self.barExp:setPercent(0)
    
    for i = 1,5 do
        self["spSublStage"..i]:setVisible(false)
    end

    self.skDescPanel:setVisible(false)
    --
    self.lbLockedPanel:setVisible(false)

    self.lbClickLock:setString("")
    
    self.btnSth:addClickEventListener(function()
        self:onSoulSth()
    end)

    self.btnSubl:addClickEventListener(function()
        self:onSoulSubl()
    end)
    

    --魂灵装ID
    self.curSoulEquipId = tonumber(getNumID(self.hero_id))

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,560,100)
    self.gridview.itemCreateEvent = function()
        local temp = SoulEquipSkillItemView.new():init()

        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end
        temp.onResetData = function(self)
            local skilldata = _data
            local IsHave = self._data["isHaved"]
            local skillid = self._data["skillId"]
            local index = self._data["index"]
            temp:SetSkillId(skillid)
            temp:SetIsHavedSkill(IsHave)
            temp:SetSkillIndex(index)
        end
        return temp
    end

    self.spSoulEquipIconImage:addClickEventListener(function()
        if self.Se_info then
            local h_id_num = getNumID( self.hero_id )
            local strTitle = ""
            local hero_soul_info = hero_soul[self.curSoulEquipId]
            if hero_soul_info then
                strTitle = UITool.getUserLanguage(hero[h_id_num].hero_name)..string.format(UITool.ToLocalization("达到%d级解锁"),hero_soul_info["unlock_lv"])
                if hero_soul_info.unlock_type == 2 then
                    if hero_soul_info.enabled == 0 then
                        strTitle = UITool.getUserLanguage(hero[h_id_num].hero_name)..UITool.ToLocalization("未开启魂灵装")
                    end
                end
            end

            if self.Se_info.state == 3 then
                if hero_soul_info.unlock_type == 2 then--五星
                    self:onExcluSiveStory()
                end
            elseif self.Se_info.state == 2 then
                self:sendUnlockMsg()
            elseif self.Se_info.state == 1 then
                GameManagerInst:alert(strTitle)
            else
                GameManagerInst:alert(strTitle)            
            end
        end
        
    end)

    return self
end
--专属剧情跳转
function NewRoleSoulView:onExcluSiveStory()
    if self.exist == false then
        return
    end
    local keyTitleHide = "Soul_Title_Hide_"..getNumID(self.hero_id)
    XBConfigManager:getInstance():setGlobalIntegerByKey(keyTitleHide, 1)
    local sData = {}
    sData.nHeroId = tonumber(getNumID(self.hero_id))
    sData["sDelegate"] = self
    sData["sFunc"] =  self.LoadSoulEquipData
    sData["hid"] = self.hero_id
    SceneManager:toExclusiveStoryListLayer(sData)
    
end
function NewRoleSoulView:FillSoulEquipData(rcvData)
    if self.exist == false then
        return
    end
    if rcvData then
        self.Se_info = table.deepcopy(rcvData)
        self.skList = table.deepcopy(rcvData["skills"])
        self.Mat_info = table.deepcopy(rcvData["soul_brk_mat"]["5"])
        --self.soulSthView:FillSoulEquipData(self.Se_info)
        -- self.soulSublView:FillSoulEquipData(self.Se_info)
        -- self.soulSublView:FillMatData(self.Mat_info)
    end
end

function NewRoleSoulView:ResetHeroId(nheroid)
    if self.exist == false then
        return
    end
    if nheroid then
        self.hero_id = nheroid
        self.curSoulEquipId = tonumber(getNumID(self.hero_id))
        self:LoadSoulEquipData()
        --self.soulSthView:ResetHeroId(nheroid)
        --self.soulSublView:ResetHeroId(nheroid)
    end
end

function NewRoleSoulView:LoadSoulEquipData()
    if self.exist == false then
        return
    end
    if not self.hero_id then return end

    local time_id = getTimeNumID( self.hero_id )

    local h_id_num = getNumID( self.hero_id )
    local tempTable = {
                rpc = "hero_soul_info",
                hero_id = self.hero_id
    }
    if time_id > 10 then
        --已获得角色，读取数据
        GameManagerInst:rpc( 
            tempTable,
            3,
            function(data)
                --success
                if self.exist == false then
                    return
                end
                self.Se_info = table.deepcopy(data["hero_soul"][self.hero_id])
                self.skList = table.deepcopy(data["hero_soul"][self.hero_id]["skills"])
                self.Mat_info = table.deepcopy(data["soul_brk_mat"]["5"])
                if self.soulSthView then
                    self.soulSthView:FillSoulEquipData(self.Se_info)
                end
                if self.soulSublView then
                    self.soulSublView:FillSoulEquipData(self.Se_info)
                    self.soulSublView:FillMatData(self.Mat_info)
                end
                -- self.soulSthView:FillSoulEquipData(self.Se_info)
                -- self.soulSublView:FillSoulEquipData(self.Se_info)
                -- self.soulSublView:FillMatData(self.Mat_info)
                self:refresh()
                if self.reloadSoulFinish then
                    self.reloadSoulFinish(self.sSoulDelegate)
                end
            end,
            function(state_code,msgText)
                --failed
                if self.exist == false then
                    return
                end
                GameManagerInst:alert(msgText)
            end,
            true)
    end

end

--获取已有技能数据
function NewRoleSoulView:getDataSrouce()
    local ds = {}
    if self.skList then
        ds = self.skList
    end
    return ds
end

--获取全部技能数据
function NewRoleSoulView:getAllDataSrouce()
    local ds = {}
    local soul_break = table.deepcopy(self.hero_soul_info["soul_break"])
    if soul_break then
        local nTotalBreak = soul_break.total_break
        local nSkillId = 0
        for i=0,nTotalBreak do
            if soul_break["break_"..i] then
                nSkillId = soul_break["break_"..i].skill_unlock
                if nSkillId ~= 0 then
                    local data = {}
                    data["skillId"] = nSkillId
                    data["isHaved"] = self:IsHavedSkill(nSkillId)
                    data["index"] = i
                    table.insert(ds,data)
                end
            end
        end
    end
    return ds
end

--
function NewRoleSoulView:InitSoulSthView()
    if not self.hero_id then
        return
    end

    self.soulSthView = NewRoleSoulSthView.new():init(self.hero_id,self.HideChildView,self.ReLoadSoulData,self)
    SceneManager.rootLayer:addChild(self.soulSthView:getRootNode())
    self.soulSthView:getRootNode():setVisible(false)
end

function NewRoleSoulView:InitSoulSublView()
    if not self.hero_id then
        return
    end

    self.soulSublView = NewRoleSoulSublView.new():init(self.hero_id,self.HideChildView,self.ReLoadSoulData,self)

    SceneManager.rootLayer:addChild(self.soulSublView:getRootNode())
    self.soulSublView:getRootNode():setVisible(false)
end
--
function NewRoleSoulView:ReLoadSoulData()
    if self.ReLoadCallFunc then
        self.ReLoadCallFunc(self.sDelegate)
    end
end
--
function NewRoleSoulView:HideChildView()
    if self.soulSthView then
        self.soulSthView:getRootNode():removeFromParent()
        self.soulSthView = nil
    end
    if self.soulSublView then
        self.soulSublView:getRootNode():removeFromParent()
        self.soulSublView = nil
    end
    --self.soulSthView:getRootNode():setVisible(false)
    --self.soulSublView:getRootNode():setVisible(false)
end
--
function NewRoleSoulView:onSoulSth()
    self:InitSoulSthView()
    self.soulSthView:FillSoulEquipData(self.Se_info)
    self.soulSthView:getRootNode():setVisible(true)
    if g_channel_control.b_newEqBag then
        self.soulSthView:ReLoadData()
    else
        self.soulSthView:refresh()
    end
end

function NewRoleSoulView:onSoulSubl()
    self:InitSoulSublView()
    self.soulSublView:FillSoulEquipData(self.Se_info)
    self.soulSublView:FillMatData(self.Mat_info)
    --
    self.soulSublView:getRootNode():setVisible(true)
    self.soulSublView:refresh()
end
--
function NewRoleSoulView:IsHavedSkill(nSkillId)
    if not self.skList then
        return false
    end
    local IsHave = false
    local SkillsHaved = self.skList
    for i=1,#SkillsHaved do
        if SkillsHaved[i] == nSkillId then
            IsHave = true
        end
    end
    return IsHave
end

function NewRoleSoulView:SkillClicked(nSkillId)
    local id = item:getData().id
    if nSkillId ~= self.curClickedSkillId then
        self:refreshSkDescPanel(nSkillId,true)
    else
        if self.curSkillDescState then
            self:refreshSkDescPanel(nSkillId,false)
        end
    end
end

function NewRoleSoulView:onItemClicked(item)
    local nSkillId = item:getData()["skillId"]
    if nSkillId ~= self.curClickedSkillId then
        self:refreshSkDescPanel(nSkillId,true)
        self.curClickedSkillId = nSkillId
    else
        self:refreshSkDescPanel(nSkillId,false)
    end
end

function NewRoleSoulView:ShowSkDescPanel(bShow)
    if not self.skDescPanel then
        return 
    end
    self.skDescPanel:setVisible(bShow)
    self.curSkillDescState = bShow
    if bShow == false then
        self.curClickedSkillId = 0
    end
end

function NewRoleSoulView:refreshSkDescPanel(nSkillId,bShow)
    if self.exist == false then
        return
    end
    if not self.skDescPanel then
        return 
    end
    if passive_sk[nSkillId] then
        self.lbSkillDesc:setString(""..UITool.getUserLanguage(passive_sk[nSkillId].sk_det_des))
    end

    self:ShowSkDescPanel(bShow)
end

function NewRoleSoulView:refresh()
    if self.exist == false then
        return
    end
    self:refreshStates()
end

-- # ■ [装备详情]* hero_soul_info
-- #  "hero_id": "1*1299656990",  #对应的角色ID
-- #返回:
-- data = {
--  "state_code": 1,
--  "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":1,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
-- }

function NewRoleSoulView:refreshStates()
    if self.exist == false then
        return
    end
    if not self.Se_info then
        print("NewRoleSoulView:refreshStates not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("NewRoleSoulView:refreshStates not hero_soul[self.curSoulEquipId]")
        return
    end

    if self.Se_info.state == 3 then
        --升华阶段
        local nSublStageCount = tonumber(self.Se_info["break_count"])
        for i = 1,5 do
            self["spSublStage"..i]:setVisible(nSublStageCount >=i)
        end

        local h_id_num = getNumID( self.hero_id )
        
        --根据魂灵装ID取本地数据
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
        --魂灵装名称
        self.lbSoulEquipName:setString(UITool.getUserLanguage(self.hero_soul_info.name))
        --英雄名称
        self.lbRoleName:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))
        --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
        local face = self.hero_soul_info["soul_break"]["break_"..nSublStageCount].icon_big
        if face then
            self.spSoulEquipIconImage:loadTexture("hd/Resources/icons/soulequip/vdrawing/"..face)
            self.spSoulEquipIconImage:setVisible(true)
            self.spSoulEquipIconImage:setColor(cc.c3b(255, 255, 255))
        end

        --基本数据属性
        local nAtk = self.Se_info["atk"] + self.Se_info["add_atk"]
        local nHp = self.Se_info["hp"] + self.Se_info["add_hp"]
        local nHpMax = self.hero_soul_info["soul_break"]["break_"..nSublStageCount]["hp_max"]
        local nAtkMax = self.hero_soul_info["soul_break"]["break_"..nSublStageCount]["atk_max"]

        self.lbNumAtk:setString(nAtk)
        self.lbNumHP:setString(nHp)
        --
        -----======技能加成======-----
        if self.Se_info["ex_hp"] ~= nil then
            --服务器下发数据
            if self.Se_info["ex_hp"] > 0 then
                self.lbNumHPAdd:setString("+"..self.Se_info["ex_hp"])
                self.barHPAdd:setPercent((nHp + self.Se_info["ex_hp"])/ nHpMax * 100)
            else
                self.lbNumHPAdd:setString("")
                self.barHPAdd:setPercent(0)
            end
        else
            --服务器未下发数据
            self.lbNumHPAdd:setString("")
            self.barHPAdd:setPercent(0)
        end

        if self.Se_info["ex_atk"] ~= nil then
            --服务器下发数据
            if self.Se_info["ex_atk"] > 0 then
                self.lbNumAtkAdd:setString("+"..self.Se_info["ex_atk"])
                self.barAtkAdd:setPercent((nAtk + self.Se_info["ex_atk"])/ nAtkMax * 100)
            else
                self.lbNumAtkAdd:setString("")
                self.barAtkAdd:setPercent(0)
            end
        else
            --服务器未下发数据
            self.lbNumAtkAdd:setString("")
            self.barAtkAdd:setPercent(0)
        end
        -----======技能加成======-----
        self.barExp:setVisible(true)
        local lvcur = self.Se_info.Lv
        local lvmax = self.Se_info.Lv_max 
        self.lbCurLv:setString(string.format(UITool.ToLocalization("等级:%d"),self.Se_info["Lv"]))

        if lvcur >= lvmax  then  --已经满级
            self.barExp:setPercent(100)
            self.lbExpNext:setString("")
        else
            self.barExp:setPercent(self.Se_info["exp"] / self.Se_info["exp_max"] * 100)
            local nExpNeed = self.Se_info["exp_max"] - self.Se_info["exp"]
            self.lbExpNext:setString(UITool.ToLocalization("离下一级：")..nExpNeed)
        end


        self.barAtk:setPercent((self.Se_info["atk"] + self.Se_info["add_atk"]) / nAtkMax * 100) --
        self.barHP:setPercent((self.Se_info["hp"] + self.Se_info["add_hp"]) / nHpMax * 100) --

        --
        self.btnSth:setTouchEnabled(true)
        self.btnSth:setBright(true)
        self.btnSubl:setTouchEnabled(true)
        self.btnSubl:setBright(true)
        --
        self.lbLockedPanel:setVisible(false)
        --
        self.spInfoBg:setTexture("n_UIShare/role/newrole/hljm_ui_002.png")
        self.lbClickLock:setString("")
        if self.hero_soul_info.enabled == 1 then
            if self.hero_soul_info.unlock_type == 2 then
                if self.Se_info["story_point"] == 0 then
                    local keyTitleHide = "Soul_Title_Hide_"..getNumID(self.hero_id)
                    local nHasTiped = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey(keyTitleHide))
                    if (nHasTiped == nil) or (nHasTiped == 0) then
                        self.lbClickLock:setString(UITool.ToLocalization("点击进入魂灵装剧情"))
                    else
                        self.lbClickLock:setString(UITool.ToLocalization(""))
                    end
                end
            end
        end
        
    elseif self.Se_info.state == 2 then
        self:refreshStatesNoOpen()
        self.lbClickLock:setString(UITool.ToLocalization("点击解锁魂灵装"))
    elseif self.Se_info.state == 1 then
        self:refreshStatesNoOpen()
        self.lbClickLock:setString(UITool.ToLocalization("魂灵装未解锁"))
    else
        self:refreshStatesNoOpen()
        self.lbClickLock:setString(UITool.ToLocalization("魂灵装未解锁"))
    end

    --技能信息列表
    self.currentDataSource = nil
    self.currentDataSource = self:getAllDataSrouce()
    self.gridview:setDataSource(self.currentDataSource)

end

function NewRoleSoulView:refreshStatesNoOpen()
    if self.exist == false then
        return
    end
    --升华阶段
    local nSublStageCount = 0
    for i = 1,5 do
        self["spSublStage"..i]:setVisible(false)
    end

    local h_id_num = getNumID( self.hero_id )
    
    --根据魂灵装ID取本地数据
    self.hero_soul_info = hero_soul[self.curSoulEquipId]
    --魂灵装名称
    self.lbSoulEquipName:setString(UITool.getUserLanguage(self.hero_soul_info.name))
    --英雄名称
    self.lbRoleName:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))
    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    local face = self.hero_soul_info["soul_break"]["break_"..nSublStageCount].icon_big
    if face then
        self.spSoulEquipIconImage:loadTexture("hd/Resources/icons/soulequip/vdrawing/"..face)
        self.spSoulEquipIconImage:setColor(cc.c3b(127, 127, 127))
        self.spSoulEquipIconImage:setVisible(true)
    end

    --基本数据属性
    local nAtk = 0--self.Se_info["atk"] + self.Se_info["add_atk"]
    local nHp = 0--self.Se_info["hp"] + self.Se_info["add_hp"]
    local nHpMax = self.hero_soul_info["soul_break"]["break_"..nSublStageCount]["hp_max"]
    local nAtkMax = self.hero_soul_info["soul_break"]["break_"..nSublStageCount]["atk_max"]

    self.lbNumAtk:setString(nAtk)
    self.lbNumHP:setString(nHp)
    --
    -----======技能加成======-----
    if self.Se_info["ex_hp"] ~= nil then
        --服务器下发数据
        if self.Se_info["ex_hp"] > 0 then
            self.lbNumHPAdd:setString("+"..self.Se_info["ex_hp"])
            self.barHPAdd:setPercent((nHp + self.Se_info["ex_hp"])/ nHpMax * 100)
        else
            self.lbNumHPAdd:setString("")
            self.barHPAdd:setPercent(0)
        end
    else
        --服务器未下发数据
        self.lbNumHPAdd:setString("")
        self.barHPAdd:setPercent(0)
    end

    if self.Se_info["ex_atk"] ~= nil then
        --服务器下发数据
        if self.Se_info["ex_atk"] > 0 then
            self.lbNumAtkAdd:setString("+"..self.Se_info["ex_atk"])
            self.barAtkAdd:setPercent((nAtk + self.Se_info["ex_atk"])/ nAtkMax * 100)
        else
            self.lbNumAtkAdd:setString("")
            self.barAtkAdd:setPercent(0)
        end
    else
        --服务器未下发数据
        self.lbNumAtkAdd:setString("")
        self.barAtkAdd:setPercent(0)
    end
    -----======技能加成======-----
    self.barExp:setVisible(false)
    self.barExp:setPercent(0)
    self.lbCurLv:setString("")
    self.lbExpNext:setString("")

    self.barAtk:setPercent(0)
    self.barHP:setPercent(0)

    --
    self.btnSth:setTouchEnabled(false)
    self.btnSth:setBright(false)
    self.btnSubl:setTouchEnabled(false)
    self.btnSubl:setBright(false)
    --
    self.lbLockedPanel:setVisible(true)
    self.lbLockedRoleName:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))
    local strTitle = ""
    if self.hero_soul_info then
        strTitle = string.format(UITool.ToLocalization("达到%d级解锁"),self.hero_soul_info["unlock_lv"])
        if self.hero_soul_info.unlock_type == 2 then
            if self.hero_soul_info.enabled == 0 then
                strTitle = UITool.ToLocalization("未开放魂灵装")
            end
        end
        if self.hero_soul_info.unlock_type == 3 then--阿尔芬
            if self.Se_info["story_point"] == 0 then
                strTitle = hero[h_id_num].unlock_msg
            end
        end
    end
    self.lbLockedTitle:setString(strTitle)
    --
    self.spInfoBg:setTexture("n_UIShare/role/newrole/hljm_ui_004.png")
end

function NewRoleSoulView:sendUnlockMsg()
    if not self.hero_id then return end
    if not self.Se_info then return end

    if self.Se_info.state == 2 then
        local time_id = getTimeNumID( self.hero_id )

        local h_id_num = getNumID( self.hero_id )
        local tempTable = {
                    rpc = "hero_soul_status",
                    hero_id = self.hero_id
        }
        if time_id > 10 then
            --已获得角色，读取数据
            GameManagerInst:rpc( 
                tempTable,
                3,
                function(data)
                    --success
                    self:LoadSoulEquipData()
                    self:startCTeffect()
                end,
                function(state_code,msgText)
                    --failed
                    GameManagerInst:alert(msgText)
                end,
                true)
        end
    end
end

function NewRoleSoulView:DestroyHandle()
    self.exist = false
    self.lockEffectPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
end

function NewRoleSoulView:startCTeffect()
    local effectFile = "Resources/effects/hun_ling_jie_suo/hun_ling_jie_suo.atlas" --特效资源路径

    self.lockEffectPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(effectFile) then
        local end_pos = string.find(effectFile,'atlas') - 1
        local spName = string.sub(effectFile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            if self.lockEffectPos and tolua.isnull(self.lockEffectPos) == false then
                self.asyncHandler2 = nil
                local rps = self.lockEffectPos:getSize()
                roleIcon:setPosition(cc.p(rps.width / 2, rps.height / 2 + 5))
                roleIcon:setScale(1)
                self.lockEffectPos:addChild(roleIcon,0,123)
                roleIcon:setAnimation(1, "effect", false)
                --
                roleIcon:registerSpineEventHandler(
                    function (event) 
                        GameManagerInst:alert(""..event)
                end, sp.EventType.ANIMATION_EVENT)
            end
        end)
    end
end

function NewRoleSoulView:stopCTeffect()
    self.lockEffectPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
end

