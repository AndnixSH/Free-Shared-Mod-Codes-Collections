BattleUIManager = {}    --UI相关的manager的统一管理
BattleUIManager.uiLayer = nil --战斗的主UI界面
BattleUIManager.BOSSUIManager = nil--战斗中boss行为变化管理器
BattleUIManager.FHManager = nil--复活管理器
BattleUIManager.battleInfoManager = nil --界面信息管理器，主要负责刷新战斗时间，宝箱掉落，以及波数变化
BattleUIManager.expressionManager = nil --表情管理器
BattleUIManager.princessManager = nil --女主技能管理器
BattleUIManager.pauseLayer = nil --暂停界面
BattleUIManager.battleHelper = nil --多人战求援
BattleUIManager.rankerUIManager = nil --多人战排名以及加入战斗UI管理
BattleUIManager.battleStartLayer = nil

--创建各个管理器
function BattleUIManager:init()
	self.uiLayer = BattleUILayer:create()
	self.battleInfoManager = BattleUIInfo:createWithMainUINode(self.uiLayer.rootNode)
	self.BOSSUIManager = BattleUIForBOSS:createWithMainUINode(self.uiLayer.rootNode)
	self.princessManager = BattlePrincessManager:createWithMainUINode(self.uiLayer.rootNode)
	self.rankerUIManager = BattleRankerUIManager:createWithMainUINode(self.uiLayer.rootNode)
    self.battleStartLayer =  BattleStartLayer:create()
    self.uiLayer:addChild(self.battleStartLayer,1)
end 

function BattleUIManager:PauseUI(state) --屏蔽UI事件
	if self.uiLayer ~= nil then
	   self.uiLayer:PauseUI(state)
    end
end

function BattleUIManager:getUILayer()
	return self.uiLayer
end

function BattleUIManager:showPause(bRet) -- 暂停 
	self:showPauseLayer(bRet)
end	

function BattleUIManager:addHit()
	self.battleInfoManager:addHit()
end
--获取连击数
function BattleUIManager:getHitNum()
	return self.battleInfoManager.nowHit
end

function BattleUIManager:showPauseLayer(bRet)--显示暂停界面
	if bRet == true then 
		if self.pauseLayer == nil then
			self.pauseLayer = BattlePauseLayer:create()
			self.uiLayer:addChild(self.pauseLayer,10000)
		end
	else
		if self.pauseLayer ~= nil then
		   self.pauseLayer:removeFromParent()
		   self.pauseLayer = nil
		end  
	end	
end

function BattleUIManager:getRemainTime()
	return self.battleInfoManager:getRemainTime()
end

function BattleUIManager:showRanking(rankers) -- 刷新多人战排名信息并展示新玩家加入动画
	self.rankerUIManager:showRanking(rankers)
end

function BattleUIManager:showAddMembers(addMembers) -- 刷新多人战新玩家加入
	self.rankerUIManager:showAddMembers(addMembers)
end

function BattleUIManager:showFHbtn(state) -- 显示复活按钮
         self.uiLayer:showFHbtn(state)
end	
function BattleUIManager:showPanelFH(reliveCallBackFuc) --展示复活界面
	if self.FHManager == nil  then
		self.FHManager = BattleReliveManager:createWithMainUINode(self.uiLayer.rootNode,reliveCallBackFuc)
	end
	self.FHManager:sendShowReliveBoxData()
end

function BattleUIManager:showBQList()--展示表情
	if self.expressionManager == nil then 
		self.expressionManager = BattleExpressionManager:createWithMainUINode(self.uiLayer.rootNode)
	end
	self.expressionManager:showBQList() 	
end

function BattleUIManager:playNextBQ() --播放下一个表情
	if self.expressionManager == nil then 
		self.expressionManager = BattleExpressionManager:createWithMainUINode(self.uiLayer.rootNode)
	end
	self.expressionManager:playNextBQ() 
end

function BattleUIManager:sendBQUpdate(tag)--同步发送表情
	MutableBattleManager:sendBQUpdate(tag)
end

function BattleUIManager:setWave(nowWav,maxWav)--刷新wave信息
	self.battleInfoManager:setWave(nowWav,maxWav)
end

function BattleUIManager:showTime( timeStr ) -- 时间 xx:xx:xx
	self.battleInfoManager:showTime(timeStr)
end

function BattleUIManager:dropBox(count,beginPos,battleLayer) -- 箱子的数量，初始位置， 以及战斗场景
	self.battleInfoManager:dropBox(count,beginPos,battleLayer)
end

--场景切换的时候调用一下
function BattleUIManager:removeBox()
	self.battleInfoManager:removeBox()
end

function BattleUIManager:showBattleHelpLayer()--展示多人战求援界面
	if self.battleHelper == nil then
       self.battleHelper = BattleHelperUILayer:create()
       self.uiLayer:addChild(self.battleHelper,100000)
       self.battleHelper:showSelf()
	else
       self.battleHelper:showSelf()
	end	
end
--@batIcon 元素
--@bCard entity
--@name 传nil
function BattleUIManager:showBossHPbar(_totalHp,_totalOD,lv,name,batIcon,bCard)--设置boss信息
    self.BOSSUIManager:showBossHPbar(_totalHp,_totalOD,lv,name,batIcon,bCard)
end	

function BattleUIManager:startBOSSActInCD(callBackFuc)--BOSS行动进入CD状态.攻击动作完毕，调用，传进来执行下次攻击的回调。
    self.BOSSUIManager:startBOSSActInCD(callBackFuc)
end

function BattleUIManager:setMcountForBoss(nowCount,maxCount)--设置多人战boss行动点数
    self.BOSSUIManager:setMcountForBoss(nowCount,maxCount)
end

function BattleUIManager:refshBOSSBuff()--刷新bossBuff
    self.BOSSUIManager:showbuff()
end

function BattleUIManager:setBK(percent)--设置bk值
	self.BOSSUIManager:setBK(percent)
end

function BattleUIManager:setOD(percent)--设置OD值。
	self.BOSSUIManager:setOD(percent)
end

--设置ODBK状态，仅设置，无动画。
function BattleUIManager:setODBKState(state)
	self.BOSSUIManager:setODBKState(state)
end

--改变ODBK状态，带切换到狂暴时带动画。
function BattleUIManager:changeODBKState(state)
	self.BOSSUIManager:changeODBKState(state)
end

function BattleUIManager:setTotalSP(total)--设置总的SP
	self.princessManager:setTotalSP(total)
end	

function BattleUIManager:setSP(sp,increase) -- 设置女主sp increase bool true为增加 false 为减少
	self.princessManager:setMP(sp,increase)
end

function BattleUIManager:setHP(hp,increase) -- 设置BOSSHP increase bool true为增加 false 为减少
	self.BOSSUIManager:setHP(hp,increase)
end

function BattleUIManager:showVictor(callBackFuc) -- 战斗胜利
	local endEffect = BattleEndEffectUI:create()
	self.uiLayer:addChild(endEffect,10000)
	endEffect:victotyEffect(callBackFuc)
end

function BattleUIManager:showLose(callBackFuc) -- 战斗失败
	local endEffect = BattleEndEffectUI:create()
	self.uiLayer:addChild(endEffect,10000)
	endEffect:defeateEffect(callBackFuc)
end

--[[根据mode的值来调用指定的函数
    规则：
    mode =1:
        文字(准备，战斗开始，第n波） 动画(Start)        函数(playStart)   开始战斗调用
    mode =2: 
        文字(强敌出现）            动画(这是spine)     函数(playBoss)    路径 battleBossPath  boss战调用
    mode = 3:
        文字(遭遇战,第n波)         动画(scroll2)      函数(playScroll2) 在第二波或第三波调用。一般在mode = 4 之后调用
    mode = 4:
        场景过度动画 ，从右到左     动画(scroll1)      函数(playScroll1)  完成之后调用 mode = 3
    mode = 5:
         场景过度动画 ，从右到左    动画(scroll1)      函数(playScroll15) 没有动作完成回调 和不需要处理的，只是简单的播放
]]
function BattleUIManager:modeStateCall( mode  ,callBackFuc)
	self.battleStartLayer:modeStateCall(mode ,callBackFuc)
end	

function BattleUIManager:showXSYDMode(mode) -- 0、移除引导层 1、释放技能 2、增豆教学 3、满豆教学 4、女主技能教学
	self.uiLayer:showXSYDMode(mode)	 
end

function BattleUIManager:update(dt)
	self.battleInfoManager:update(dt)
end

function BattleUIManager:clear()
	self.uiLayer = nil;
	self.battleInfoManager = nil;
	self.BOSSUIManager = nil;
	self.princessManager = nil
	self.battleStartLayer = nil
	self.pauseLayer = nil
	self.rankerUIManager = nil
	self.battleHelper = nil
	self.FHManager = nil
	self.expressionManager = nil
end