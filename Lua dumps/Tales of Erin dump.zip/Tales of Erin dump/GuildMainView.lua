--require "XUIView"

GuildMainView = class("GuildMainView",XUIView)
GuildMainView.CS_FILE_NAME = "GuildMainView.csb"
GuildMainView.CS_BIND_TABLE = {
    panelMain = "/i:1140",
    gFace = "/i:1140/i:1141/s:gFace",
    gBoss = "/i:1140/i:1141/s:gBoss",
    gName = "/i:1140/i:1141/s:gName",
    gTop = "/i:1140/i:1141/s:gTop",
    gMan = "/i:1140/i:1141/s:gMan",
    gManMax = "/i:1140/i:1141/i:69",
    gPoint = "/i:1140/i:1141/s:gPoint",
    gDesc = "/i:1140/i:1141/s:gDesc",
    skills = "/i:1140/i:1143",  -- skicon  lvtext

    panelNoGuild = "/i:118",
    btnGuildList = "/i:118/i:48",

    panelNotActive = "/i:116",

    --成员列表
    btnMember = "/i:1140/i:65",
    --公会设施
    btnFacility = "/i:1140/i:66",
    --留言板
    btnBBS = "/i:1140/i:64",
    --塔
    btnTower = "/i:1140/i:63",
    --公会设定
    btnSetup = "/i:1140/i:1141/i:92",
    --公会排行
    btnTop = "/i:1140/i:1141/i:93",

    btnHelp = "/i:1140/i:1141/s:btnHelp",
    btnClose = "/i:1134/i:92",
}

function GuildMainView:init(guild_data)
    GuildMainView.super.init(self)
    self.exist = true
    self.guild_data = guild_data

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    self.btnSetup:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toGuildSetup({
                guild_data = table.deepcopy(self.guild_data),
                exitGuildFunc = function()
                    self.needReturnBack = true
                end})
        end
    end)

    self.btnTop:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            GuildInterface:GuildRanking()
        end
    end)

    self.btnBBS:setPressedActionEnabled(false)
    self.btnBBS:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toGuildBBS()
        end
    end)

    self.btnFacility:setPressedActionEnabled(false)
    self.btnFacility:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toGuildFacility()
        end
    end)

    self.btnMember:setPressedActionEnabled(false)
    self.btnMember:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            local rData = {}
            rData["nType"]       = 2
            rData["guild_id"]    = self.guild_data.guild_id
            rData["GuildType"]   = nil
            rData["selectIndex"] = 1
            rData["pos"]         = self.guild_data.position
            SceneManager:toGuildMemberLayer(rData)
        end
    end)

    self.btnTower:setPressedActionEnabled(false)
    self.btnTower:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then

            if tonumber(user_info["rank"]) >= UnlockGuildTowerRank then 
                SceneManager:toGuildPavilionLayer({})
            else 
              ---todo锁住 星界
                local str = string.format(UITool.ToLocalization("公会塔将在冒险等级到达%d级时开放。"),UnlockGuildTowerRank)
                SceneManager:showPromptLabel(str)
            end 
        end
    end)

    self.btnGuildList:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            -- local paramers = {}
            -- GuildInterface:GuildRecommend(paramers)
        end    
    end)

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)

    self:refresh()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

--    # 如果有公会, 会出现下面属性 <--可能出现的属性-->  
--     "guild_id": "1437719007",     # 公会ID
--     "name": u"蜀山",        # 公会名
--   #  "Lv": 1,                # 公会等级 1-M(从低到高)
--     "ranking":"100",#公会排行,注：字符串，以防后续出现文本描述
--     "score": 0,             # 公会积分
--     "notice": u"这是公会的公告文本",
--     "mem_num": "18/20",     # 公会成员数量
--     "chairman": u"清虚",    # 会长名字
--     "image": "xxxxxx.jpg",  # 公会形象-----暂为公会会长头像
--     "join_condition": 1,    # 加入条件: 0-需要审批, 1-自动通过
--     "position": 6,          # 自己处职位,1-6(6最高,会长) 
--     # 公会buff
--     "buff": {
--          {
--             "skill_id":1,#生效的buffID
--             "need_gold": 500,
--             "end_time": 1437384422,  

function GuildMainView:showGuidePicLayer( ... )
    local data = {}
    data.pictures = { --一张或者多张
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function GuildMainView:refresh()
    --have_guild   是否有公会       # 1-有公会, 0-已开启公会功能但未加入，-1，未达到开启公会的条件 
    if self.guild_data then
        if self.guild_data.have_guild == 1 then
            user_info["guild_id"] = self.guild_data.guild_id
            user_info["guild_name"] = self.guild_data.name

            self.panelMain:setVisible(true)
            self.panelNoGuild:setVisible(false)
            self.panelNotActive:setVisible(false)


            local npos = string.find(self.guild_data.mem_num,'/')
            local nlen = string.len(self.guild_data.mem_num)
            local nman = string.sub(self.guild_data.mem_num,0,npos - 1)
            local nmanmax = string.sub(self.guild_data.mem_num,npos + 1,nlen)

            self.gName:setString(self.guild_data.name)
            self.gTop:setString(self.guild_data.ranking)
            self.gBoss:setString(self.guild_data.chairman)
            self.gDesc:setString(self.guild_data.notice)
            self.gPoint:setString(""..self.guild_data.score)
            self.gMan:setString(nman)    
            self.gManMax:setString(nmanmax)

            --self.gFace:setVisible(false)
            local hinfo = hero[self.guild_data["image"]]
            if hinfo then
                self.gFace:setVisible(true)
                self.gFace:setTexture(hinfo.hero_bat_icon)
            -- elseif cc.FileUtils:getInstance():isFileExist(self.guild_data["image"]) then
            --     self.gFace:setVisible(true)
            --     self.gFace:setTexture(self.guild_data["image"])
            else
                self.gFace:setVisible(false)
            end

            for i = 1,3 do  
                local skdata = self.guild_data.buff[""..i]

                local panel = self.skills:getChildByName("sk"..i)
                local icon = panel:getChildByName("skicon")
                local lv = panel:getChildByName("lvtext")

                if passive_sk[skdata.skill_id] then
                    icon:setVisible(true)
                    icon:setTexture(passive_sk[skdata.skill_id].sk_icon)
                else
                    icon:setVisible(false)
                end

                lv:setString(skdata.lv)
                if skdata.lv > 0 then
                    panel:setColor(cc.c3b(255,255,255))
                else
                    panel:setColor(cc.c3b(127,127,127))
                end

            end

            --self.btnSetup:setVisible(self.guild_data.position > 1)
            --设置小红点状态  塔的小红点
            UITool.setCommmonBtnRedDop(self.btnTower,false)
            if tonumber(user_info["rank"]) >= UnlockGuildTowerRank then 
                self.btnTower:setTouchEnabled(true)
                self.btnTower:setBright(true)

                if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.GuildTower) == 0 then 
                    UITool.setCommmonBtnRedDop(self.btnTower, true, cc.p(508,125))
                end 
            else
                self.btnTower:setTouchEnabled(false)
                self.btnTower:setBright(false)
            end

            ---第一次进入公会，更改配置文件
            if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Guild) == 0 then
                cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Guild, 1)
            end

        elseif   self.guild_data.have_guild == 0 then
            self.panelMain:setVisible(false)
            self.panelNoGuild:setVisible(true)
            self.panelNotActive:setVisible(false)
        else
            self.panelMain:setVisible(false)
            self.panelNoGuild:setVisible(false)
            self.panelNotActive:setVisible(true)
        end 
    else
        self.panelMain:setVisible(false)
        self.panelNoGuild:setVisible(false)
        self.panelNotActive:setVisible(false)
        -- self.gFace:setVisible(false)
        -- self.gBoss:setString("")
        -- self.gName:setString("")
        -- self.gTop:setString("")
        -- self.gMan:setString("")
        -- self.gPoint:setString("")
        -- self.gDesc:setString("")
    end
end

function GuildMainView:loadData()
    GameManagerInst:rpc("{\"rpc\":\"guild_mine\"}",3,
    function(data)
        --success
        --GameManagerInst:saveToFile("guild_mine.json",data)
        if self.exist == false then
            return
        end
        self.guild_data = table.deepcopy(data)
        self:refresh()
    end,
    function(state_code,msgText)
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function GuildMainView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    if isback then
        if self.needReturnBack then
            self:returnBack()
        else
            cc.Director:getInstance():getTextureCache():removeUnusedTextures()
            self:loadData()
        end
    else
        if not self.guild_data then
            self:loadData()
        end
    end
end

function GuildMainView:returnBack()
    self.exist = true
    if self._navigationView then
        self._navigationView:popView()
    else
        self:removeFromParentView()
    end
end
