--require "XUIView"

MsgBoxView = class("MsgBoxView",XUIView)
MsgBoxView.CS_FILE_NAME = "MsgBoxView.csb"
MsgBoxView.CS_BIND_TABLE = {tbText="/i:11/i:13",btnOK="/i:11/i:14"}

function MsgBoxView:initWithMessage(title)
    MsgBoxView.super.init(self)
    
    self.tbText:setString(title or "")
    self.btnOK:addClickEventListener(function ()
        self:removeFromParentView()
    end)

    return self
end