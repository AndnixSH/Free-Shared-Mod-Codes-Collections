--require "XUIView"
--require "XUIGridView"

PrincessInfoView = class("PrincessInfoView",XUIView)
PrincessInfoView.CS_FILE_NAME = "PrincessInfoView.csb"
PrincessInfoView.CS_BIND_TABLE = 
{
    panelBG = "/s:panelBG",
    panelTouch = "/s:panelTouch",
    --base
    btnTab1 = "/s:panelRight/s:Button_1",
    btnTab2 = "/s:panelRight/s:Button_2",
    btnTab3 = "/s:panelRight/s:Button_3",
    btnClose = "/s:CloseBtn/s:btnClose",

    baseFace = "/s:panelBase/s:imgFace",
    baseName = "/s:panelBase/s:imgName",

    --state
    panelState = "/s:panelState",
    stateIcon = "/s:panelState/s:pTop/s:imgIcon",
    stateDesc = "/s:panelState/s:pTop/s:desc",
    stateVideo = "/s:panelState/s:pTop/s:video",
    stateVideoImg = "/s:panelState/s:pTop/s:video/s:vimg",
    --stateBtnPlayVideo
    stateBG = "/s:panelState/s:pBg/s:bottomBG",

    stateUnlocked = "/s:panelState/s:pUnlock",
    stateExpBar = "/s:panelState/s:pUnlock/s:LoadingBar_1",
    stateExpNext = "/s:panelState/s:pUnlock/s:lbExpNext",
    stateLevel = "/s:panelState/s:pUnlock/s:lbCurLv",
    stateLevelMax = "/s:panelState/s:pUnlock/s:lbMaxLv",
    stateBtnUse = "/s:panelState/s:pUnlock/s:Button_20",

    stateLocked = "/s:panelState/s:pLock",
    statePreFace = "/s:panelState/s:pLock/s:bottomFace",
    stateBtnLearn = "/s:panelState/s:pLock/s:Button_19",   --激活按钮
    statelbtext1 = "/s:panelState/s:pLock/s:Text_1",
    statelbtext2 = "/s:panelState/s:pLock/s:Text_1_0",    --多少/多少的字
    statelbNum1 = "/s:panelState/s:pLock/s:Text_1_0_0",    --需要多少信仰
    statelbNum2 = "/s:panelState/s:pLock/s:Text_1_0_1",    --有多少信仰  

    --skill    
    panelSkill = "/s:panelSkill",
    panelSkillItems = "/s:panelSkill/s:Panel_12",
    skDesc = "/s:panelSkill/s:skDesc",
    skDescTitle = "/s:panelSkill/s:skDesc/s:Text_1",
    skDescDesc = "/s:panelSkill/s:skDesc/s:Text_2",

    --story
    panelStory = "/s:panelStory",
    storyBG = "/s:panelStory/s:Sprite_20",
    storyTitle = "/s:panelStory/s:textName",
    storyShortDes = "/s:panelStory/s:textShortDes",
    storyDetail = "/s:panelStory/s:textStory",
}


function PrincessInfoView:init(princess_list_index,ps_list_index)
    PrincessInfoView.super.init(self)
    self.exist = true
    local bganime = sp.SkeletonAnimation:create("effects/nv_zhu/nvzhu.json", "effects/nv_zhu/nvzhu.atlas", 1.0)
    local psize = self.panelBG:getSize()
    self.panelBG:addChild(bganime)
    bganime:setPosition(cc.p(psize.width / 2, psize.height / 2))
    bganime:setAnimation(1, "effect", true)

    self.panelTouch:setVisible(false)
    self.panelTouch:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopVideo()
        end
    end)

    self.stateVideo:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:playVideo()
        end
    end)

    self.stateVideo:setVisible(false)

    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack(1)
    end)

    self.stateBtnLearn:addClickEventListener(function()
        self:sendLearn()
    end)

    self.stateBtnUse:addClickEventListener(function()
        self:sendUse()
    end)

    for i = 1,4 do
        local psk = self.panelSkillItems:getChildByName("skItem"..i)
        local psk_topPanel = psk:getChildByTag(222)  --顶层panel
        psk_topPanel:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                self:showSkillDesc(i)
            end
        end)
    end

    

    self.princess_list_index = princess_list_index
    self.ps_list_index = ps_list_index
    
    self:switchView(1)
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack(1)
    end)
    return self
end

function PrincessInfoView:switchView(idx)
    self.panelState:setVisible(idx == 1)
    self.btnTab1:setTouchEnabled(idx ~= 1)
    self.btnTab1:setBright(idx ~= 1)

    self.panelSkill:setVisible(idx == 2)
    self.btnTab2:setTouchEnabled(idx ~= 2)
    self.btnTab2:setBright(idx ~= 2)

    self.panelStory:setVisible(idx == 3)
    self.btnTab3:setTouchEnabled(idx ~= 3)
    self.btnTab3:setBright(idx ~= 3)

    self.curSkillDescIndex = nil
    self.skDesc:setVisible(false)

    --触发引导-女主神格
    self:dealTriggerGuide(idx)
end
---新手引导函数
function PrincessInfoView:dealTriggerGuide(idx)
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Godhead) then 
        if idx==1 then
            if princess_list[self.princess_list_index] ~= nil or
                princess_list[self.princess_list_index]["ps_list"][self.ps_list_index] ~= nil then
                local psdetail = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]  --小职业
                 --判断状态，加载  # 公主状态 0-未解锁, 1-已解锁（未获得状态）, 2-已学习（已获得未启用状态）, 3-使用中（启用状态）
                local psstates = psdetail["status"]
                if psstates < 2 then
                    XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.Godhead) --激活
                else 
                    XbTriggerGuideManager:showTriggerGuide(nil, 6, TriggerGuideConfig.Godhead) --启用
                end
            else 
                XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.Godhead) --激活
            end
        end 
    end   
end

function PrincessInfoView:playVideo()
    -- if self.videoPlayer then
    --     self:stopVideo()
    --     return
    -- end

    if princess_list[self.princess_list_index] == nil or
        princess_list[self.princess_list_index]["ps_list"][self.ps_list_index] == nil then
        --无数据
    else
        local psinfo = princess_list[self.princess_list_index]    --大职业 --大职业
        local psdetail = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]  --小职业
        local psdetid = psdetail["ps_id"]  --小职业id

        local psocp = princess_ocp[psinfo["career"]]
        local psocpdet = psocp[psdetid]

        self.panelTouch:setVisible(true)

        self.videoPlayer = ccexp.VideoPlayer:create()
        self.videoPlayer:setAnchorPoint(cc.p(0.5, 0.5))
        self.videoPlayer:setPosition(640, 360)
        self.videoPlayer:setContentSize(cc.size(1280, 720))
            
        local stoped = false
        self.videoPlayer:addEventListener(function(sender,eventType)
            local function stopfunc()
                if not stoped then
                    stoped = true                     
                    UITool.delayTask(0,function()  
                        self:stopVideo()
                    end) 
                end
            end


            if eventType == ccexp.VideoPlayerEvent.PLAYING then
            elseif eventType == ccexp.VideoPlayerEvent.PAUSED then   
                stopfunc()
            elseif eventType == ccexp.VideoPlayerEvent.STOPPED then                  
            elseif eventType == ccexp.VideoPlayerEvent.COMPLETED then 
                local targetPlatform = cc.Application:getInstance():getTargetPlatform()
                if cc.PLATFORM_OS_ANDROID == targetPlatform then
                    stopfunc()
                else 
                    if self.videoPlayer.isPlaying then 
                    else 
                        stopfunc()
                    end 
                end
            end
        end)
        
        self.panelTouch:addChild(self.videoPlayer)
        local vedioPath = AudioManager:shareDataManager():getCorrectPath(psocpdet.ps_vedio)
        self.videoPlayer:setFileName(vedioPath)   
        self.videoPlayer:play()
        
    end
end

function PrincessInfoView:stopVideo()
    if self.videoPlayer then
        self.videoPlayer:addEventListener(function()end)
        self.videoPlayer:stop()
        self.videoPlayer:removeFromParent()
        self.videoPlayer = nil
    end
    
    self.panelTouch:setVisible(false)
end

function PrincessInfoView:refresh()
    self.curSkillDescIndex = nil
    self.skDesc:setVisible(false)
    self.stateVideo:setVisible(false)

    if princess_list[self.princess_list_index] == nil or
        princess_list[self.princess_list_index]["ps_list"][self.ps_list_index] == nil then
        --没数据
        self.stateVideo:setVisible(false)
    else
        self.stateVideo:setVisible(true)

        local psinfo = princess_list[self.princess_list_index]    --大职业
        local psdetail = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]  --小职业
        local psdetid = psdetail["ps_id"]  --小职业id

        local psocp = princess_ocp[psinfo["career"]]
        local psocpdet = psocp[psdetid]

        --大职业背景
        self.stateBG:setTexture(psocp["p_jl"])
        self.storyBG:setTexture(psocp["p_sh"])

        --大图，名字，技能图标，技能描述
        self.baseFace:setTexture(psocpdet["ps_vdraw"])
        self.baseName:setTexture(psocpdet["ps_name"])
        self.stateIcon:setTexture(psocpdet["ini_skill"]["sk_icon"])
        self.stateDesc:setString(UITool.getUserLanguage(psocpdet["ini_skill"]["sk_des"]))
        self.stateVideoImg:setTexture(psocpdet["ps_short_vedio"])

        --被动技能
        for i = 1,4 do
            local psk = self.panelSkillItems:getChildByName("skItem"..i)
            local psk_topPanel = psk:getChildByTag(222)  --顶层panel
            local psk_title = psk_topPanel:getChildByTag(223) --标题
            local psk_desc = psk_topPanel:getChildByTag(224) --描述
            local psk_icon = psk_topPanel:getChildByTag(125) --技能图标
            local psk_locked = psk_topPanel:getChildByTag(621) 
            local psk_locked_msg = psk_locked:getChildByTag(126) 

            if g_channel_control.transform_PrincessInfoView_skillNameFont == true then 
                psk_locked_msg:setFontSize(22)
            end 

            local skinfo = psdetail["sk"][i]
            if skinfo ~= nil and skinfo.id ~= nil then
                psk:setVisible(true)
                psk_title:setString(UITool.getUserLanguage(passive_sk[skinfo.id]["sk_name"]))--(passive_sk[skinfo.id]["sk_name"])
                psk_desc:setString(UITool.getUserLanguage(passive_sk[skinfo.id]["sk_des"]))--(passive_sk[skinfo.id]["sk_des"])
                psk_icon:setTexture(passive_sk[skinfo.id]["sk_icon"])

                if skinfo["unlock_lv"] > psdetail["Lv"] then
                    psk_locked:setVisible(true)
                    local unlockStr = string.format(UITool.ToLocalization("%s级解锁"),tostring(skinfo["unlock_lv"])) 
                    psk_locked_msg:setString(unlockStr)
                    -- psk_locked_msg:setString(""..skinfo["unlock_lv"]..UITool.ToLocalization("级解锁"))
                else
                    psk_locked:setVisible(false)
                end
            else
                psk:setVisible(false)
            end
        end

        --背景故事
        self.storyTitle:setString(UITool.getUserLanguage(psocpdet["ps_desName"]))--(psocpdet["ps_desName"])
        self.storyShortDes:setString(UITool.getUserLanguage(psocpdet["ps_des"]))--(psocpdet["ps_des"])
        self.storyDetail:setString(UITool.getUserLanguage(psocpdet["ps_info"]))--(psocpdet["ps_info"])

        --判断状态，加载  # 公主状态 0-未解锁, 1-已解锁（未获得状态）, 2-已学习（已获得未启用状态）, 3-使用中（启用状态）
        local psstates = psdetail["status"]
        if psstates == 0 or psstates == 1 then
            --判断前置等级,判断信仰币
            self.stateUnlocked:setVisible(false)
            self.stateLocked:setVisible(true)


            -- local last_ps   = getPSID(unLockT[1]["pre_ps_id"])
            -- local imageIcon = princess_ocp[last_ps][unLockT[1]["pre_ps_id"]]["ps_icon"]

            local ps_unlock = psdetail["unlock"][1]
            if ps_unlock ~=nil and ps_unlock["pre_ps_id"] ~= nil then
                local ps_unlock_id = getPSID(ps_unlock["pre_ps_id"])
                self.statePreFace:setTexture(princess_ocp[ps_unlock_id][ps_unlock["pre_ps_id"]]["ps_ocp"])
                self.statePreFace:setVisible(true)

                self.statelbtext1:setVisible(true)
                self.statelbtext2:setVisible(true)
                self.statelbtext2:setString(""..ps_unlock["now_Lv"].."/"..ps_unlock["need_Lv"])
                
            else
                self.statePreFace:setVisible(false)
                self.statelbtext1:setVisible(false)
                self.statelbtext2:setVisible(false)
            end

            local faith = user_info["faith"]
            local need_faith = psdetail["need_faith"]
            self.statelbNum1:setString(need_faith)
            self.statelbNum2:setString(faith)

            if faith < need_faith then
                self.statelbNum2:setTextColor(cc.c3b(255,74,55))
            else
                self.statelbNum2:setTextColor(cc.c3b(255,255,255))
            end

            if psstates == 1 and
                --ps_unlock["now_Lv"] >= ps_unlock["need_Lv"] and
                faith >= need_faith then
                self.stateBtnLearn:setTouchEnabled(true)
                self.stateBtnLearn:setBright(true)
            else
                self.stateBtnLearn:setTouchEnabled(false)
                self.stateBtnLearn:setBright(false)
            end

        -- elseif psstates == 1 then
        --     --判断信仰币
        --     self.stateUnlocked:setVisible(false)
        --     self.stateLocked:setVisible(true)
        elseif psstates == 2 or psstates == 3 then
            --显示经验
            self.stateUnlocked:setVisible(true)
            self.stateLocked:setVisible(false)

            self.stateLevel:setString(string.format(UITool.ToLocalization("等级 %d"),psdetail["Lv"]))
            self.stateLevelMax:setString(string.format(UITool.ToLocalization("等级上限 %d"),psdetail["Lv_max"]))
            
            if psdetail["Lv"] >= psdetail["Lv_max"] then
                --已满级
                self.stateExpNext:setString("")
                self.stateExpBar:setPercent(100)
            else
                self.stateExpNext:setString(UITool.ToLocalization("离下一级：")..(psdetail["exp_max"] - psdetail["exp"]))
                self.stateExpBar:setPercent(100*(psdetail["exp"]/psdetail["exp_max"]))
            end

            self.stateBtnUse:setTouchEnabled(psstates == 2)
            self.stateBtnUse:setBright(psstates == 2)

        -- elseif psstates == 3 then
        --     --显示经验
        --     self.stateUnlocked:setVisible(true)
        --     self.stateLocked:setVisible(false)
        else
            GameManagerInst:alert(UITool.ToLocalization("发生未知错误"))
        end
    end

end

function PrincessInfoView:sendLearn()

    local gid = princess_list[self.princess_list_index]["career"]
    local oid = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]["ps_id"]
    local need_faith = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]["need_faith"]

    local confirmStr = string.format(UITool.ToLocalization("是否花费%d信仰学习%s？"), need_faith,UITool.getUserLanguage(princess_ocp[gid][oid]["ps_desName"]))
    -- UITool.ToLocalization("是否花费")..need_faith..UITool.ToLocalization("信仰学习 ")..(princess_ocp[gid][oid]["ps_desName"]).."?"
    GameManagerInst:confirm(confirmStr,function()
        local tempTable = {
            ["rpc"] = "princess_learn",
            ["ps_id"] = oid,
        }
        
        GameManagerInst:rpc(tempTable,3,
        function(data)
            if self.exist == false then
                return
            end
            local sgName = UITool.getUserLanguage(princess_ocp[gid][oid]["ps_desName"] )
            princess_list[self.princess_list_index]["ps_list"][self.ps_list_index] = data["princess"]
            user_info["faith"] = data["faith"]
            
            if self.listChangedEvent then
                self.listChangedEvent(self)
            end
            --神格
            local function backFunc()
                self:dealTriggerGuide(1)
            end
            MsgManager:showSimpMsgWithCallFunc1(sgName..UITool.ToLocalization("获得成功"),self, backFunc)

            self:refresh()

        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)    
    end)
end

function PrincessInfoView:showSkillDesc(idx)
    if self.curSkillDescIndex == idx or idx == nil then
        self.curSkillDescIndex = nil
        self.skDesc:setVisible(false)
    else
        local psinfo = princess_list[self.princess_list_index]    --大职业
        local psdetail = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]  --小职业
        local skinfo = psdetail["sk"][idx]
        if skinfo ~= nil and skinfo.id ~= nil then
            -- psk_title:setString(passive_sk[skinfo.id]["sk_name"])
            -- psk_desc:setString(passive_sk[skinfo.id]["sk_des"])
            local pos = self.panelSkill:getChildByName("skpos"..idx)
            local posx = pos:getPositionX()
            local posy = pos:getPositionY()

            self.skDescTitle:setString(UITool.getUserLanguage(passive_sk[skinfo.id]["sk_name"]))--(passive_sk[skinfo.id]["sk_name"])
            self.skDescDesc:setString(UITool.getUserLanguage(passive_sk[skinfo.id]["sk_des"]))--(passive_sk[skinfo.id]["sk_des"])
            self.curSkillDescIndex = idx
            self.skDesc:setVisible(true)
            self.skDesc:setPosition(posx,posy)
        else
            self.curSkillDescIndex = nil
            self.skDesc:setVisible(false)
        end

    end

end

function PrincessInfoView:sendUse()

    local gid = princess_list[self.princess_list_index]["career"]
    local oid = princess_list[self.princess_list_index]["ps_list"][self.ps_list_index]["ps_id"]

    --队伍id 
    local t_id = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
    if t_id==nil or t_id<1 then  --判断是否是第一次
        t_id = 1 
    end

    local tempTable = {
        ["rpc"] = "princess_use",
        ["ps_id"] = oid,
        ["team_id"] = t_id,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        if self.exist == false then
            return
        end
        local sgName = UITool.getUserLanguage(princess_ocp[gid][oid]["ps_desName"] )
        -- 神格启用成功
        if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Godhead)~=1 then 
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Godhead,1)
        end
        user_info["princess_list"] = {}
        user_info["princess_list"] = data["career_list"]
        DataManager:rfsPlist()

        if self.listChangedEvent then
            self.listChangedEvent(self)
        end

        self:refresh()

        local function backFunc()
            XbTriggerGuideManager:finishGuide(TriggerGuideConfig.Godhead, self)
        end
        MsgManager:showSimpMsgWithCallFunc1(sgName..UITool.ToLocalization(" 启用成功"),self, backFunc)

    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function PrincessInfoView:returnBack()
    self.exist = false
    if self._navigationView then
        self._navigationView:popView()
    end
end

function PrincessInfoView:onNavigateTo(isback)
    -- if isback then
    -- else
    -- end
    self:refresh()
end
