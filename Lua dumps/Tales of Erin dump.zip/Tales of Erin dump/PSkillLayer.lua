require "BasicLayer"
require "CoverView"
require "princess_ocp"
PSkillLayer= class("PSkillLayer",BasicLayer)
PSkillLayer.__index = PSkillLayer
PSkillLayer.lClass = 2 

PSkillLayer.resTable = {}

--流派id 

--职业id

local index = 1

function PSkillLayer:init()
    local node =cc.CSLoader:createNode("PSkillLayer.csb")
    self.uiLayer:addChild(node,0,2)

    local panelBG = node:getChildByName("panelBG")

    local bganime = sp.SkeletonAnimation:create("effects/nv_zhu/nvzhu.json", "effects/nv_zhu/nvzhu.atlas", 1.0)
    local psize = panelBG:getSize()
    panelBG:addChild(bganime)
    bganime:setPosition(cc.p(psize.width / 2, psize.height / 2))
    bganime:setAnimation(1, "effect", true)


    local panel_1 = node:getChildByTag(1)
    
    --点击说明按钮
    local function touchGuideBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:showGuidePicLayer()
        end
    end 
    local guideButton = ccui.Helper:seekWidgetByName(panel_1,"btnHelp")
    guideButton:addTouchEventListener(touchGuideBtnEvent)

      local touchEventTable = {
         [102] = self.returnBack,
         [101] = self.showMaster,
      }

      local function touchCallBack(sender,eventType)
            print("点击按钮"..sender:getTag())
            touchEventTable[sender:getTag()](self)
      end

    
    
    local panel_3 = node:getChildByTag(3)
    local mas_button = panel_3:getChildByTag(101)
    mas_button:addClickEventListener(touchCallBack)
    --mas_button:setEffectType(1)
    local bac_button = panel_3:getChildByTag(102)
    bac_button:addClickEventListener(touchCallBack)
    bac_button:setEffectType(3)

    local panel_2 = node:getChildByTag(2)
    local xtText = ccui.Helper:seekWidgetByTag(panel_2,204)
    xtText:setString(user_info["gem"])

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self:showRolist()

end
---神格说明图  缺失
function PSkillLayer:showGuidePicLayer()
    local data = {}
    data.pictures = {
          "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_017.png",
      }
    self.sManager:toGuidePictureLayer(data)
end
function PSkillLayer:showRolist()

  -- function initList()
      self:reqPrinInfo()
                          --self.sManager.newGuidMgr:getOnlySelf(self)
     --触发引导-女主神格
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Godhead) then 
        XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.Godhead)--切换女主按钮
    end                          

  -- end

  -- local node =self.uiLayer:getChildByTag(2)
  -- local panel_1 = node:getChildByTag(1)
  -- local panel_2 = node:getChildByTag(2)
  -- local panel_3 = node:getChildByTag(3)
  -- panel_1:setPositionX(-visibleSize.width)
  -- panel_2:setPositionX(-visibleSize.width)
  -- panel_3:setPositionX(visibleSize.width)


  -- local moveby = cc.MoveBy:create(0.3, cc.p(visibleSize.width, 0))
  -- local moveby2 = cc.MoveBy:create(0.3, cc.p(visibleSize.width, 0))
  -- local moveby3 = cc.MoveBy:create(0.3, cc.p(-visibleSize.width, 0))
 
  -- local delay =  cc.DelayTime:create(0.2)
  -- local seq = cc.Sequence:create(moveby,delay,cc.CallFunc:create(initList))
  -- panel_1:runAction(seq)
  -- panel_2:runAction(moveby2)
  -- panel_3:runAction(moveby3)

end

function PSkillLayer:removeRolist()

  function initList()
   --self.backFunc(self.sManager,self.sData)
    self.sManager:removeFromNavNodes(self)
   self.exist = false
   self:clear()
  end

  local node =self.uiLayer:getChildByTag(2)
  local panel_1 = node:getChildByTag(1)
  local panel_2 = node:getChildByTag(2)
  local panel_3 = node:getChildByTag(3)
  local moveby = cc.MoveBy:create(0.3, cc.p(-visibleSize.width, 0))
  local moveby2 = cc.MoveBy:create(0.3, cc.p(-visibleSize.width, 0))
  
  local moveby3 = cc.MoveBy:create(0.3, cc.p(visibleSize.width, 0))
 
  local seq = cc.Sequence:create(moveby,delay,cc.CallFunc:create(initList))
  panel_1:runAction(seq)
  panel_2:runAction(moveby2)
  panel_3:runAction(moveby3)
  
  self.sManager:fadeOutBGScene()

end



function PSkillLayer:initCover()
     local node =self.uiLayer:getChildByTag(2)
     local panel_1 = node:getChildByTag(1)
     local swRect = cc.rect(100,0,180,600)
     local slSize = cc.size(180,600)

     local disDistance = swRect.height/4.5
     local disScale = 0.23
     local coverView = CoverView:create(swRect,slSize,disDistance,disScale)
     CoverView.pslayer = self
    

      for i= 1,#princess_list do
         local imageView = ccui.ImageView:create()
         imageView:loadTexture(princess_ocp[princess_list[i]["career"]]["p_icon_h"])
         CoverView:addCard(imageView,i)
         print("coverView num"..#princess_list)
      end

      coverView:setPosition(cc.p(62,25))
      
      CoverView:setOffsetPosition(cc.p(0,(index-1)*disDistance))
      panel_1:addChild(coverView)

      print("当前选中的编号"..CoverView:getCurCardIndex())
      print("当前选中的编号====="..index)
      CoverView.cardTable[CoverView:getCurCardIndex()]:loadTexture(CoverView.resTable[2][CoverView:getCurCardIndex()])
      CoverView.lastIndex = CoverView:getCurCardIndex()


           
     -- local p_name = ccui.Helper:seekWidgetByTag(panel_1,288)
     -- print("name name =-="..princess_ocp[princess_list[CoverView.lastIndex]["career"]]["p_name"])
      
      -- p_name:setString(princess_ocp[princess_list[CoverView.lastIndex]["career"]]["p_name"])

end 

function PSkillLayer:setShow()
  if self.inited then
    self:refreshOccu(index)
  end
end

--刷新职业列表信息
function PSkillLayer:refreshOccu(idx)
    if idx ~= nil then 
       index = idx 
    end 
  
    print("select_index"..index)
    local node =self.uiLayer:getChildByTag(2)
    local panel_1 = node:getChildByTag(1)
   local function onTouch(sender,eventType)
       
        
        if eventType == ccui.TouchEventType.ended then

            print("touch")
            local tag = sender:getTag()

            --流派id 
            p_id =  princess_list[CoverView.lastIndex]["career"].."_"..sender:getName()


            --判断学没学 
               --判断职业状态是否解锁
          local rightIndex = tonumber(sender:getName())
          local leftIndex = CoverView.lastIndex
          if leftIndex == nil or rightIndex == nil then
            print("error:refreshOccu:leftIndex:"..tostring(leftIndex).."....rightIndex:"..tostring(rightIndex))
            return
          end
          if princess_list == nil then
            print("error:refreshOccu:princess_list == nil:")
            return
          end
          if princess_list[leftIndex] == nil  then
            print("error:refreshOccu:princess_list:lenth:"..tostring(#princess_list).."...index:"..tostring(leftIndex))
            return
          end
          if princess_list[leftIndex]["ps_list"] == nil then
            print("error:refreshOccu:princess_list[index][ps_list]==nil.....index:"..tostring(leftIndex))
            return
          end

          local princess_data =  princess_list[leftIndex]["ps_list"][rightIndex]
          if princess_data == nil then
            print("error:refreshOccu:princess_list[leftIndex][ps_list][rightIndex]==nil.....index:"..tostring(leftIndex).."....rigthIndex:"..tostring(rightIndex))
            return
          end

          local p_lv = princess_data["Lv"]
          local p_Maxlv = princess_data["Lv_max"]
          print("女主的最大等级是  == ",p_Maxlv)
          if princess_data["status"] == 0 then   --0 未解锁
                self.sData = {}
               
                self.sData = {["p_Maxlv"] = p_Maxlv,["id"]=p_id,["g_id"]=princess_list[CoverView.lastIndex]["career"],["status"]=0,["lv"]=p_lv,["index_1"]=CoverView.lastIndex,["callFunc_1"]=self.resetBack,["callFunc"]=self.returnBack,["ref"]=self,["index_3"]=index,["index_2"]=tonumber(sender:getName())}
                self.sManager:toPInfoLayer(self.sData)
          elseif princess_data["status"] == 1 then --已解锁 未学习
                self.sData = {}
                --self.sData["p_Maxlv"] = p_Maxlv
                self.sData = {["p_Maxlv"] = p_Maxlv,["id"]=p_id,["g_id"]=princess_list[CoverView.lastIndex]["career"],["status"]=1,["lv"]=p_lv,["index_1"]=CoverView.lastIndex,["callFunc_1"]=self.resetBack,["callFunc"]=self.returnBack,["ref"]=self,["index_3"]=index,["index_2"]=tonumber(sender:getName())}
                self.sManager:toPInfoLayer(self.sData)
        
          elseif princess_data["status"] == 2 then --已学习
                 self.sData = {}
                -- self.sData["p_Maxlv"] = p_Maxlv
                 self.sData = {["p_Maxlv"] = p_Maxlv,["id"]=p_id,["g_id"]=princess_list[CoverView.lastIndex]["career"],["lv"]=p_lv,["status"]=2,["index_1"]=CoverView.lastIndex,["index_3"]=index,["index_2"]=tonumber(sender:getName()),["callFunc_1"]=self.resetBack,["callFunc"]=self.returnBack,["ref"]=self}
                 self.sManager:toPInfoLayer(self.sData)
         
          elseif princess_data["status"] == 3 then --使用中
                --判断是否是当前队伍中使用的
                -- local t_id = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
                -- if t_id ==nil or t_id <1 then  --判断是否是第一次
                --   t_id = 1
                -- end 
                -- local status = nil 
                -- if team_list[tostring(t_id)]["ps"] == princess_list[CoverView.lastIndex]["ps_list"][tonumber(sender:getName())]["ps_id"] then
                --    status = 3 
                -- else 
                --    status = 2 
                -- end  
                self.sData = {}
                --self.sData["p_Maxlv"] = p_Maxlv
                self.sData = {["p_Maxlv"] = p_Maxlv,["id"]=p_id,["g_id"]=princess_list[CoverView.lastIndex]["career"],["lv"]=p_lv,["status"]=3,["index_1"]=CoverView.lastIndex,["index_2"]=tonumber(sender:getName()),["callFunc_1"]=self.resetBack,["callFunc"]=self.returnBack,["ref"]=self,}
                self.sManager:toPInfoLayer(self.sData)
          end
        end
     end

    --判断技能动态数据表
    if princess_list[index] ~= nil then 
      local node_1 =self.uiLayer:getChildByTag(2)
      local node = node_1:getChildByTag(1)
       for i=1,#princess_list[index]["ps_list"] do
           local pnode =cc.CSLoader:createNode("PSkillCard_1.csb")
           pnode:setPosition(cc.p(691.5,521 - (i-1)*196))
           if node:getChildByTag(i*100+i) ~=nil then 
              node:removeChildByTag(i*100+i) 
           end 
          node:addChild(pnode,2,i*100+i)
          local panel = pnode:getChildByTag(1)


          panel:setName(tostring(i))
          panel:addTouchEventListener(onTouch)
    

          local imageView = ccui.Helper:seekWidgetByTag(panel,101)
          imageView:setUnifySizeEnabled(true)
          imageView:setScale("0.4")
          imageView:loadTexture(princess_ocp[princess_list[index]["career"]][princess_list[index]["career"].."_"..i]["ini_skill"]["sk_icon"])
          local PrincessLen = #princess_ocp[princess_list[index]["career"]][princess_list[index]["career"].."_"..i]["pas_skill"]
          print("PrincessLen len = "..PrincessLen)
          for j=1,4 do 
            local imageView1 = ccui.Helper:seekWidgetByTag(panel,101+j)
            if j <= PrincessLen then
             
              imageView1:setUnifySizeEnabled(true)
              imageView1:setScale("0.5")
              print("公主技能..."..princess_list[index]["ps_list"][i]["sk"][j]["id"])
              imageView1:loadTexture(passive_sk[princess_list[index]["ps_list"][i]["sk"][j]["id"]]["sk_icon"])
            else
              imageView1:setVisible(false)
            end

          end

          local imageView_1 = ccui.Helper:seekWidgetByTag(panel,106)
          imageView_1:setUnifySizeEnabled(true)
          imageView_1:loadTexture(princess_ocp[princess_list[index]["career"]][princess_list[index]["career"].."_"..i]["ps_name"])

          local imageView_2 = ccui.Helper:seekWidgetByTag(panel,107)
          imageView_2:loadTexture(princess_ocp[princess_list[index]["career"]][princess_list[index]["career"].."_"..i]["ps_ocp"])

 
          local imageView_3 = ccui.Helper:seekWidgetByTag(panel,108)
          imageView_3:loadTexture("uifile/n_UIShare/n_GZ_ZY/gzzy_ui_00"..(2+i)..".png")
          print("这是啥 ==".."uifile/n_UIShare/n_GZ_ZY/gzzy_ui_00"..(2+i)..".png")

          local text = ccui.Helper:seekWidgetByTag(panel,141)
          text:setString(UITool.getUserLanguage(princess_ocp[princess_list[index]["career"]][princess_list[index]["career"].."_"..i]["ps_short_des"]))--(princess_ocp[princess_list[index]["career"]][princess_list[index]["career"].."_"..i]["ps_short_des"])
          if g_channel_control.transform_PSkillLayer_font == true then
              text:setFontSize(18) --神格短描述缩小字号
          end 
          
          local text = ccui.Helper:seekWidgetByTag(panel,142)
          text:setString(string.format(UITool.ToLocalization("等级 %d"),princess_list[index]["ps_list"][i]["Lv"]))
          

           local imageView_4 = ccui.Helper:seekWidgetByTag(panel,109)
          local imageView_3 = ccui.Helper:seekWidgetByTag(panel,109)
          local imageView_4 = ccui.Helper:seekWidgetByTag(panel,199)
          if princess_list[index]["ps_list"][i]["status"] == 0 then   --0 未解锁
            --text:setString("未学习")
            local imageView_2 = ccui.Helper:seekWidgetByTag(panel,107)
            imageView_3:setVisible(false)
            imageView_4:setVisible(false)

            imageView_3:setVisible(false)
            --------------------临时的-----------------------------
            local TestName= princess_list[index]["career"]
            if TestName == "shooter" or TestName == "mage" then
               for i=1,6 do  
                  local TimageView = ccui.Helper:seekWidgetByTag(panel,100+i)
                  TimageView:setVisible(false)
               end 
               ccui.Helper:seekWidgetByTag(panel,109):setVisible(false)
               ccui.Helper:seekWidgetByTag(panel,141):setVisible(false)
               ccui.Helper:seekWidgetByTag(panel,142):setVisible(false)
               ccui.Helper:seekWidgetByTag(panel,110):setVisible(false)
               ccui.Helper:seekWidgetByTag(panel,63):setVisible(false)
               local TimageView_2 = ccui.Helper:seekWidgetByTag(panel,107)
               TimageView_2:loadTexture("ui/share/gzzy_image_0.png")
               TimageView_2:setOpacity(150)
               local TimageView_3 = ccui.Helper:seekWidgetByTag(panel,108)
               TimageView_3:loadTexture("uifile/n_UIShare/n_GZ_ZY/gzzy_ui_008.png")
               
            end
            -----------------------------------------------------------
          elseif princess_list[index]["ps_list"][i]["status"] == 1 then --已解锁 未学习
            -- text:setString("可学习")
            imageView_3:setVisible(true)
            imageView_4:setVisible(false)
                        
            local imageView_2 = ccui.Helper:seekWidgetByTag(panel,107)
           -- imageView_2:setColor(cc.c3b(130,130,130))
  

          elseif princess_list[index]["ps_list"][i]["status"] == 2 then --已学习
             ccui.Helper:seekWidgetByTag(panel,110):setVisible(false)
            -- text:setString("已学习")
            imageView_3:setVisible(false)
            imageView_4:setVisible(false)
             
          elseif princess_list[index]["ps_list"][i]["status"] == 3 then --使用中
             
              local t_id = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
              if t_id==nil or t_id <1  then  --判断是否是第一次
                     t_id = 1 
              end
             ccui.Helper:seekWidgetByTag(panel,110):setVisible(false)
             --判断是否是当前队伍中使用的
            -- if team_list[tostring(t_id)]["ps"] == princess_list[index]["ps_list"][i]["ps_id"] then
                imageView_3:setVisible(false)
                imageView_4:setVisible(true)
           --  else 
            --    imageView_3:setVisible(false)
            --    imageView_4:setVisible(false)
            -- end  

          end 

       end 

       
       
         --隐藏处理 
        local pnode =cc.CSLoader:createNode("PSkillCard_1.csb")
        pnode:setPosition(cc.p(691.5,521 - (2)*196))
         if node:getChildByTag(3*100+3) ~=nil then 
              node:removeChildByTag(3*100+3) 
         end 
         node:addChild(pnode,2,3*100+3)
        local panel = pnode:getChildByTag(1)
        
          panel:setName(tostring(i))
          panel:addTouchEventListener(onTouch)

        for i=1,6 do  
          local imageView = ccui.Helper:seekWidgetByTag(panel,100+i)
          imageView:setVisible(false)
        end 
        ccui.Helper:seekWidgetByTag(panel,109):setVisible(false)
        ccui.Helper:seekWidgetByTag(panel,141):setVisible(false)
        ccui.Helper:seekWidgetByTag(panel,142):setVisible(false)
        ccui.Helper:seekWidgetByTag(panel,110):setVisible(false)
        ccui.Helper:seekWidgetByTag(panel,63):setVisible(false)
        local imageView_2 = ccui.Helper:seekWidgetByTag(panel,107)
        imageView_2:loadTexture("ui/share/gzzy_image_0.png")
        imageView_2:setOpacity(150)

    else 
      local node_1 =self.uiLayer:getChildByTag(2)
      local node = node_1:getChildByTag(1)

       for i=1,3 do
          local pnode = node:getChildByTag(196+i)
          if pnode then
            local panel = pnode:getChildByTag(1)
            pnode:setVisible(false)
            panel:setVisible(false)
          end
       end 
    end

end

--menu
function PSkillLayer:menuCallBack()
    print("菜单")
    if self.sManager ~= nil then
       self.sManager:pushStartLayer()
    end
end

--筛选
function PSkillLayer:screenCallBack()


end

--贩卖
function PSkillLayer:sellCallBack()

end


--返回刷新
function PSkillLayer:resetBack()
 print("刷新")
  self:refreshOccu(index)

  if self.rData["rcvData"].resetcallback then
    self.rData["rcvData"].resetcallback()
  end
end

--返回
function PSkillLayer:returnBack()
   print("返回")
   --self.backFunc(self.sManager)
   if self.sManager ~= nil then
      self.sManager:removeFromNavNodes(self)
   end
   self.exist = false
   self:clearEx()
end

function PSkillLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end
function PSkillLayer:showMaster()
  
    local function reiceTedCallBack(data)
        print("master 奖励是否精通")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        local sData = {}
        sData["MList"] = t_data["data"]["master_list"]
        if self.sManager ~= nil then
            self.sManager:toMasterLayer(sData)
        end
    end


    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"] = "princess_master_list",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)


    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceTedCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
   
end

--发送获取职业列表
function PSkillLayer:reqPrinInfo()
  if next(user_info["princess_list"]) ~=nil  then
       DataManager:rfsPlist()
      for i=1,#princess_list do
        for m=1,#princess_list[i]["ps_list"] do
        if princess_list[i]["ps_list"][m]["status"] == 3 then
          index = i
          print("当前使用种的id"..index)
          break
            end
          end
        end
       self:initCover()
       self:refreshOccu(index)
       self.inited = true
       return
  end
end
-- 拉取公主列表的请求
function PSkillLayer:repPList( ... )
  -- body

   local function reiceResultCallBack(data)
        print("收到拉取公主列表消息")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
       user_info["princess_list"] =  t_data["data"]["career_list"]
       --DataManager:rfsPlist()
       self:init()
       end
    local t_id = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
    if t_id==nil or t_id <1  then  --判断是否是第一次
        t_id = 1 
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"] = "princess_list",
        ["team_id"] = t_id
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function PSkillLayer:create(rData)
      local inst = PSkillLayer.new()
     inst.rData = rData 
     inst.exist = true
     inst.sManager = inst.rData["sManager"]
     inst.uiLayer = cc.Layer:create()
     --self:init()
     inst:repPList()
     return inst
end