exploerPass = {} 
exploerPass[104]={
  level_limit = 1799,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100782",                              -- 名称
  level_icon="icons/tollgate/ts_m_rkzc.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=1,
        id=0,
        num=3000,--奖励的数量
    },
  }
} 
exploerPass[105]={
  level_limit = 35999,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100783",                              -- 名称
  level_icon="icons/tollgate/ts_m_fqyps.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=6,
        id=2,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[106]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100784",                              -- 名称
  level_icon="icons/tollgate/ts_m_ydjhl.png",          -- 对应的关卡条目icon
  need_level=10,       -- 解锁等级
  drop_reward = {   
    {
        type=1,
        id=0,
        num=10000,--奖励的数量
    },
  }
} 
exploerPass[107]={
  level_limit = 71999,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100785",                              -- 名称
  level_icon="icons/tollgate/ts_m_xxjt.png",          -- 对应的关卡条目icon
  need_level=10,       -- 解锁等级
  drop_reward = {   
    {
        type=6,
        id=1,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[108]={
  level_limit = 172799,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100786",                              -- 名称
  level_icon="icons/tollgate/ts_m_xsjz.png",          -- 对应的关卡条目icon
  need_level=5,       -- 解锁等级
  drop_reward = {   
    {
        type=6,
        id=3,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[109]={
  level_limit = 86399,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100787",                              -- 名称
  level_icon="icons/tollgate/ts_m_xscj.png",          -- 对应的关卡条目icon
  need_level=15,       -- 解锁等级
  drop_reward = {   
    {
        type=2,
        id=0,
        num=50,--奖励的数量
    },
  }
} 
exploerPass[110]={
  level_limit = 259199,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100788",                              -- 名称
  level_icon="icons/tollgate/ts_m_qcwr.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=6,
        id=3,
        num=1,--奖励的数量
    },
    {
        type=2,
        id=0,
        num=80,--奖励的数量
    },
  }
} 
exploerPass[1]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100789",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=601,
        num=5,--奖励的数量
    },
  }
} 
exploerPass[2]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100790",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=611,
        num=5,--奖励的数量
    },
  }
} 
exploerPass[3]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100791",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=601,
        num=4,--奖励的数量
    },
    {
        type=5,
        id=602,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[4]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100792",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=611,
        num=4,--奖励的数量
    },
    {
        type=5,
        id=612,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[5]={
  level_limit = 21599,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100793",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=30,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=25,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[11]={
  level_limit = 1799,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100794",                              -- 名称
  level_icon="icons/tollgate/ts_m_lszj.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=2,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[12]={
  level_limit = 1799,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100795",                              -- 名称
  level_icon="icons/tollgate/ts_m_lyzj.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=7,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=6,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[13]={
  level_limit = 1799,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100796",                              -- 名称
  level_icon="icons/tollgate/ts_m_kfzj.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=12,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=11,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[14]={
  level_limit = 1799,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100797",                              -- 名称
  level_icon="icons/tollgate/ts_m_sgzj.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=17,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=16,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[15]={
  level_limit = 1799,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100798",                              -- 名称
  level_icon="icons/tollgate/ts_m_xwzj.png",          -- 对应的关卡条目icon
  need_level=1,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=22,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=21,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[16]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100799",                              -- 名称
  level_icon="icons/tollgate/ts_m_lszj.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=3,
        num=2,--奖励的数量
    },
    {
        type=5,
        id=4,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[17]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100800",                              -- 名称
  level_icon="icons/tollgate/ts_m_lyzj.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=8,
        num=2,--奖励的数量
    },
    {
        type=5,
        id=9,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[18]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100801",                              -- 名称
  level_icon="icons/tollgate/ts_m_kfzj.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=13,
        num=2,--奖励的数量
    },
    {
        type=5,
        id=14,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[19]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100802",                              -- 名称
  level_icon="icons/tollgate/ts_m_sgzj.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=18,
        num=2,--奖励的数量
    },
    {
        type=5,
        id=19,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[20]={
  level_limit = 3599,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100803",                              -- 名称
  level_icon="icons/tollgate/ts_m_xwzj.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=23,
        num=2,--奖励的数量
    },
    {
        type=5,
        id=24,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[31]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100804",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=8,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1082,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1081,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[32]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100805",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=8,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1086,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1085,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[33]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100806",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=8,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1090,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1089,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[34]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100807",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=12,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1094,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1093,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[35]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100808",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=12,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1098,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1097,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[36]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100809",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=12,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1102,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1101,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[37]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100810",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=16,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1106,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1105,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[38]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100811",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=16,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1110,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1109,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[39]={
  level_limit = 7199,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100812",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=16,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1114,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1113,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[40]={
  level_limit = 10799,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100813",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1118,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1117,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[41]={
  level_limit = 10799,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100814",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1122,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1121,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[42]={
  level_limit = 10799,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100815",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=20,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1126,
        num=1,--奖励的数量
    },
    {
        type=5,
        id=1125,
        num=2,--奖励的数量
    },
  }
} 
exploerPass[75]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100816",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=25,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1083,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[76]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100817",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=25,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1087,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[77]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 1,2,3 },                             -- 关卡推荐种族
  level_name="100818",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=25,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1091,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[78]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100819",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=30,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1095,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[79]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100820",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=30,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1099,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[80]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 3,4,5 },                             -- 关卡推荐种族
  level_name="100821",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=30,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1103,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[81]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100822",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=35,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1107,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[82]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100823",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=35,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1111,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[83]={
  level_limit = 14399,                              --限制时间 单位是秒
  level_race = { 6,7,1 },                             -- 关卡推荐种族
  level_name="100824",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=35,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1115,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[84]={
  level_limit = 17999,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100825",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=40,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1119,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[85]={
  level_limit = 17999,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100826",                              -- 名称
  level_icon="icons/tollgate/ts_m_slts.png",          -- 对应的关卡条目icon
  need_level=40,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1123,
        num=1,--奖励的数量
    },
  }
} 
exploerPass[86]={
  level_limit = 17999,                              --限制时间 单位是秒
  level_race = { 2,6,8 },                             -- 关卡推荐种族
  level_name="100827",                              -- 名称
  level_icon="icons/tollgate/ts_m_sctz.png",          -- 对应的关卡条目icon
  need_level=40,       -- 解锁等级
  drop_reward = {   
    {
        type=5,
        id=1127,
        num=1,--奖励的数量
    },
  }
} 