
ChatNewPannelFriend = class("ChatNewPannelFriend",XUIView)
ChatNewPannelFriend.CS_FILE_NAME = "ChatPannelFriend.csb"
ChatNewPannelFriend.CS_BIND_TABLE = 
{

    friendPannel 				= "/i:1",
	friend_bg 					= "/i:1/i:1",
	friend_chatName_pre 		= "/i:1/i:2/i:1051",
    friend_pannel_name 			= "/i:1/i:2/i:1",
    friend_chatName_back 		= "/i:1/i:2/i:1052",
    friend_btn_clear 			= "/i:1/i:2/i:3",
    friend_btn_info 			= "/i:1/i:2/i:2",

    friend_chatList_pannel 		= "/i:1/i:4",
    friend_chatList_notice 		= "/i:1/i:6",

    friend_members_pannel 		= "/i:1/i:5",
    friend_members_num			= "/i:1/i:5/i:1/i:2",
    friend_members_list_pannel 	= "/i:1/i:5/i:3620",
    
}

ChatNewPannelFriend.LogTag = "ChatNewPannelFriend"

function ChatNewPannelFriend:create(rData)
    local login = ChatNewPannelFriend.new()
    login.uiLayer   = cc.Layer:create()
    login:initUI()
    return login
end

function ChatNewPannelFriend:clear( )
	print("ChatNewPannelFriend:clear")
	self:registEventDispatcher(false)
	self.friend_chatList_notice:setVisible(true)

	self:clearFriendHighLight()
end

function ChatNewPannelFriend:returnBack(  )
	self:clear()
end

function ChatNewPannelFriend:initUI(  )
	self:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)
	
	self:initData()


	self:bindAllBtn()

	self:registEventDispatcher(true) 	--启动通知事件

end

function ChatNewPannelFriend:initData(  )
	self._session_id = nil --当前私聊对象 云信id
end

function ChatNewPannelFriend:bindAllBtn(  )
	--输入框组件
	self.inputNode = ChatInputNode:create()
	self.inputNode:setDelegate(self)
	self.inputNode:setSendCallback(function ( sender,message )
		self:sendMessage(message)
	end)
	self.friendPannel:addChild(self.inputNode:getRootNode())


	self.friend_bg:setVisible(false)
	self.friend_btn_info:addTouchEventListener(handler(self,self.friendBtnInfoCallback))
    self.friend_btn_clear:addTouchEventListener(handler(self,self.friendBtnClearCallback))

    self.friend_pannel_name:setString(Lang:toLocalization(1031006))
    self.friend_chatName_pre:setPosition(240.5, -30)
    self.friend_chatName_pre:setVisible(false)
    self.friend_chatName_back:setVisible(false)
    local psize = self.friend_members_list_pannel:getContentSize()
 
    self.friendScrollView = XUIGridView.new():initWithNodeAndSize( self.friend_members_list_pannel , psize.width, psize.height,142,58)
    self.friendScrollView.itemCreateEvent = function()
        local temp = self:createFriendItem(data)
       	temp:setItemCallback(handler(self,self.itemSelectedCallback))
        return temp
    end
end

function ChatNewPannelFriend:registEventDispatcher(bTrue)
	print("registEventDispatcher:::"..tostring(bTrue))
	if bTrue == false  then
		lemon.EventManager:getInstance():removeEventListener(self.friend_online_listener)
		self.friend_online_listener = nil 
		return 
	end

	if self.friend_online_listener == nil  then
		self.friend_online_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_USER_ONLINE_REFRESH,handler(self,self.eventFriendOnlineChange))
	end

end

function ChatNewPannelFriend:eventFriendOnlineChange( event_data )

	--如果当前UI在前台，则通知好友在线状态
	if self:isViewVisible() then
		self:refreshFriendList()
	end
end

function ChatNewPannelFriend:refreshFriendList(  )

	local friends =  XBChatSys:getInstance():getFriends()


	if friends == nil or type(friends) ~= "table"  then
		return 
	end
	local friendsSorted = FriendsSys:getInstance():sortFriendData(friends)

	-- dump(friends, "refreshFriendList")
	local len = #friendsSorted 

	self.friend_members_num:setString(string.format("(%d/100)", len))

	if self.friendScrollView ~= nil  then
		self.friendScrollView:refreshDataSource(friendsSorted)
	else
		--todo

	end

end



function ChatNewPannelFriend:channelDataRefresh( ... )
	print("channelDataRefresh=====")
	XBChatData:getInstance():setCurrentSession("", 0)

	self:refreshFriendList()
end

function ChatNewPannelFriend:eventEnterChatroom( ... )
	--不处理
end

function ChatNewPannelFriend:isCurrentSession( session_id )
	if session_id == nil or self._session_id == nil  then
		
		return false
	end

	return string.lower(session_id) == string.lower(self._session_id)


end

function ChatNewPannelFriend:eventRefreshUI( session_type,session_id,scrollEnd )
	if session_type ~= 0  then
		print("拒绝处理：类型不匹配。。eventRefreshUI: type："..tostring(session_type).."....id:"..tostring(session_id).."..session_id:"..tostring(self._session_id))
		return 
	end
	XBChatData:getInstance():setCurrentSession(session_id, 0)
	self.friend_chatList_notice:setVisible(false)
	

	if self:isCurrentSession(session_id) then
		--刷新当前listView	
		self:refreshChatListView(scrollEnd)
		XBChatData:getInstance():setSessionUnreadNum(0, session_id, 0)

	-- else 
	-- 	--判断红点
	-- 	print("判断红点=========")
	end

	self:refreshFriendList()

end

function ChatNewPannelFriend:eventFecthSession( session_type,session_id )
	if session_type ~= 0 then
		print("拒绝处理：类型不匹配。。eventFecthSession: type："..tostring(session_type).."....id:"..tostring(session_id).."..self._session_id:"..tostring(self._session_id))
		return 
	end
	--私聊信息变更

	if self:isCurrentSession(session_id) then
		--刷新当前listView	
		self:refreshChatListView()
		XBChatData:getInstance():setSessionUnreadNum(0, session_id, 0)

	else 
		--判断红点
		print("判断红点=========")
		-- self:setFriendStateRedDot(session_id)
	end

end

function ChatNewPannelFriend:createFriendItem( data )
	-- body
	return ChatNewFriendItem:create(data)

end

function ChatNewPannelFriend:createScrollViewItem( data )
	data["size_type_small"] = true -- 是否为小item
	return XBChatListViewItemPool:getInstance():createItemByData(data)
end

function ChatNewPannelFriend:removeScrollViewItem( item )

	return XBChatListViewItemPool:getInstance():removeItemToPool(item)

end


-- [LUA-print] - "itemSelectedCallback" = {
-- [LUA-print] -     "friend_can_give" = 1
-- [LUA-print] -     "head"            = 13
-- [LUA-print] -     "highLight"       = true
-- [LUA-print] -     "is_friend"       = 1
-- [LUA-print] -     "login_tm"        = 1542602011
-- [LUA-print] -     "name"            = "u_532D5J9UH"
-- [LUA-print] -     "rank"            = 3
-- [LUA-print] -     "readDot"         = false
-- [LUA-print] -     "refresh_time"    = 1542723338
-- [LUA-print] -     "team_score"      = 6279
-- [LUA-print] -     "title_id"        = 110000
-- [LUA-print] -     "uid"             = "532D5J9UH"
-- [LUA-print] -     "user_nim_id"     = "532D5J9UH_gf0"
-- [LUA-print] - }
--好友列表item点击事件
function ChatNewPannelFriend:itemSelectedCallback( data )
	-- body
	--好友列表刷新
	--切换当前高亮item，
	--切换聊天框内容
	dump(data,	"itemSelectedCallback")


	local session_id = data["user_nim_id"]
	local session_type = 0
	if self._scrollView == nil  then
		local psize = self.friend_chatList_pannel:getContentSize()
		self._scrollView = XBChatNewListView.new():initWithNodeAndSize(self.friend_chatList_pannel, psize.width, psize.height)
		self._scrollView:setItemCreateFunc(handler(self,self.createScrollViewItem))
		self._scrollView:setItemRemoveFunc(handler(self,self.removeScrollViewItem))
	end
	XBChatData:getInstance():setCurrentSession(self.session_id, 0)
	self.friend_chatList_notice:setVisible(false)

	if self._session_id ~= session_id then
		--切换好友高亮
		self:setSelectedFriendHighLight(session_id)
		self._session_id = session_id 

		--切换聊天室内容

		--获取历史消息
		if XBChatData:getInstance():getSessionHistoryState(session_type, session_id) ~= true  then
			local t_data = {
				session_id = session_id,
				session_type = session_type,
				limit = 100
			}
			XBChatSys:getInstance():fetchMessageHistory(t_data)
			--清空聊天列表，等待刷新
			-- local chatroom_datas = XBChatListViewDataMap:getInstance():(session_type, session_id)
			self._scrollView:setDataSource(nil)

		else
			local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(session_type, session_id)
			self._scrollView:setDataSource(chatroom_datas)
		end
		--清空当前item红点
		XBChatData:getInstance():setSessionUnreadNum(0, session_id, 0)

		--切换好友高亮
		self:refreshFriendList()
		--切换聊天室名字
		local name = data["name"]
		self.friend_chatName_pre:setVisible(true)
		self.friend_pannel_name:setString(name)
    	self.friend_chatName_back:setVisible(true)

    	local namePreContentSize = self.friend_chatName_pre:getContentSize()
    	local nameContentSize = self.friend_pannel_name:getContentSize()
    	local nameBackContentSize = self.friend_chatName_back:getContentSize()
    	-- print("ChatNewPannelFriend:itemSelectedCallback namePreContentSize ", namePreContentSize.width)
    	-- print("ChatNewPannelFriend:itemSelectedCallback nameContentSize ", nameContentSize.width)
    	-- print("ChatNewPannelFriend:itemSelectedCallback nameBackContentSize ", nameBackContentSize.width)
    	local centerX = 240
    	local namePosY = self.friend_pannel_name:getPositionY()

    	local totalWidth = namePreContentSize.width + nameContentSize.width + nameBackContentSize.width
    	-- print("ChatNewPannelFriend:itemSelectedCallback totalWidth ", totalWidth)
    	local namePrePosX = centerX - totalWidth/2
    	local namePosX = namePrePosX + namePreContentSize.width
    	local nameBackPosX = namePosX + nameContentSize.width

    	-- print("ChatNewPannelFriend:itemSelectedCallback namePrePosX ", namePrePosX)
    	-- print("ChatNewPannelFriend:itemSelectedCallback namePosX ", namePosX)
    	-- print("ChatNewPannelFriend:itemSelectedCallback nameBackPosX ", nameBackPosX)

    	self.friend_chatName_pre:setPosition(namePrePosX, namePosY)
    	self.friend_pannel_name:setPosition(namePosX, namePosY)
    	self.friend_chatName_back:setPosition(nameBackPosX, namePosY)


		self.uid = data["uid"]

		print("self._session_id === "..tostring(self._session_id).."....uid:"..self.uid)

	end

end


function ChatNewPannelFriend:clearFriendHighLight(  )
	local friends =  XBChatSys:getInstance():getFriends()
	for i=1,#friends do
		friends[i]["highLight"] = false 
	end
end
--设置红点
-- function ChatNewPannelFriend:setFriendStateRedDot( redDot_session_id )
-- 	if redDot_session_id == nil and self:isCurrentSession(redDot_session_id) then
-- 		XBChatData:getInstance():setSessionUnreadNum(0, redDot_session_id, 0)
-- 	end


-- end

--设置高亮，并移除红点
function ChatNewPannelFriend:setSelectedFriendHighLight( selected_session_id )

		local friends =  XBChatSys:getInstance():getFriends()
		for i=1,#friends do
			if friends[i]["user_nim_id"] == selected_session_id then
				friends[i]["highLight"] = true 
				friends[i]["readDot"] = false 
				XBChatData:getInstance():setCurrentSession(selected_session_id, 0)

			else
				friends[i]["highLight"] = false 
			end
		end


end


function ChatNewPannelFriend:removeScrollView( ... )
	if self._scrollView then
		self._scrollView:resetTempData()
	end
	self:clearFriendHighLight()

	self._session_id = nil 
	self.uid = nil 
	self.friend_pannel_name:setString("")
	self.friend_chatName_pre:setVisible(false)
    self.friend_chatName_back:setVisible(false)

	self.friend_chatList_notice:setVisible(true)


end
--刷新聊天内容
function ChatNewPannelFriend:refreshChatListView( scrollEnd )
	--如果当前session_id == null
	print("ChatNewPannelFriend===refreshChatListView==")
	if self._session_id == nil or self._scrollView == nil   then
		return 
	end

	if self.fetchMessage == true or self._scrollView:getDataSource() == nil  then
		if self.fetchMessage == true  then
			self.fetchMessage = false 
		end
		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(0, self._session_id)
		self._scrollView:setDataSource(chatroom_datas)
	else
		self._scrollView:refreshDataSource(scrollEnd)
	end 

end
--刷新好友列表
-- function ChatNewPannelFriend:refreshFriendListView( ... )
-- 	-- body
-- 	local friends =  XBChatSys:getInstance():getFriends()
-- 	self.friendScrollView:refreshDataSource(friends)

-- end

function ChatNewPannelFriend:sendMessage( message )
	-- body
	print("ChatNewPannelFriend  sendBtnCallback:"..tostring(message).."..._session_id:"..tostring(self._session_id))
	if self._session_id == nil  then
		
		return 
	end
	local channelIndex = 4
	XBChatPlatform:getInstance():sendmessage(channelIndex, self._session_id,0,tostring(message),"ext" ,function (  )
		self.inputNode:setInputString("")
	end)
end

function ChatNewPannelFriend:friendBtnInfoCallback( sender,eventType )
	-- body
	print("friendBtnInfoCallback:"..sender:getTag())
	if eventType == ccui.TouchEventType.ended then


		local userData = XBChatSys:getInstance():getUserInfoByUid(self.uid)
		if userData and userData["state"] ~= 0 then
			local t_data = {}
			local player_data = {}
			player_data["nim_id"] = userData["user_nim_id"]
			player_data["name"] = userData["name"]
			player_data["talk"] = userData["text"]
	        
	        t_data["event_data"] = player_data
	        lemon.EventManager:dispatchCustomEvent(EEventType.CHAT_SHOW_PLAYER_INFO, player_data)
  		end

	end


end

function ChatNewPannelFriend:friendBtnClearCallback( sender,eventType )
	-- body
	print("friendBtnClearCallback:"..sender:getTag())

	if eventType == ccui.TouchEventType.ended then
		if self._session_id == nil  then
			return 
		end
		XBChatListViewDataMap:getInstance():clearDataByType(0, self._session_id)

		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(0, self._session_id)
		-- self:removeScrollView()
		if self._scrollView then
			-- self._scrollView:resetTempData()
			self._scrollView:setDataSource(chatroom_datas)

		end


	end
end

