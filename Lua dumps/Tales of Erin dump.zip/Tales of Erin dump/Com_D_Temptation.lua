--魅惑的组件
--created by kobejaw.2018.6.30.
Com_D_Temptation = class("Com_D_Temptation",ComponentBase)

function Com_D_Temptation:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 2
	self.buffType = Com_DebuffEnum.Temptation
	self.rate = self.comData.effect1
end