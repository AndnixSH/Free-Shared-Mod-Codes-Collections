--[[
    DDBattleMainLayer.lua
    横向玩法1 、合战 UI主页
    --todo刷新队伍 UI等等
]]
require "BasicLayer"
DDBattleMainLayer = class("DDBattleMainLayer",BasicLayer)
DDBattleMainLayer.__index = DDBattleMainLayer
DDBattleMainLayer.lClass = 2

local DDBATTLE_MAX_TEAM_NUM = 8 --队伍最多八人

function DDBattleMainLayer:create(rData)
     local layer = DDBattleMainLayer.new()
     layer.rData = rData
     layer.titleNum = 5 --todo 标题都统一过一遍 合战
     layer:init()
     return layer
end

function DDBattleMainLayer:returnBack()
    self.sManager:removeFromNavNodes(self)
    if self.backFunc then
       self.backFunc(self.sDelegate)
    end
    self.exist = false
    self:clear()
end

function DDBattleMainLayer:clear()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:stopSelectPass()
    self.myExist =false
    self.sData = nil
    self.rData = nil
    self.sManager = nil
    self.ModelType = nil
    self.sDelegate  = nil
    if self.uiLayer~=nil then
        self.uiLayer:removeFromParent()
        self.uiLayer = nil
    end
   if self.sec~=nil then
    
   end
   self.ddbattleInfo = nil
   --清理所有缓存
   SPCacheManager:clearCache()
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
end

function DDBattleMainLayer:setShow( )
    -- body
    self.sManager.menuLayer:hiddenUserInfo(false)
end

function DDBattleMainLayer:init()
    self.myExist = true
    self.towerData = {} --存储塔的信息
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    ---当前关卡的数据
    self.curPassID = 1 --当前的关卡
    self.maxPassID = 1 --最大能选中的关卡
    self.minPassID = 1   --最小关卡
    self.ddbattleInfo = {} --存放当前关卡服务器的信息 

    self.uiLayer = cc.Layer:create()

    local node = cc.CSLoader:createNode("DDBattleMainLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
     --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    local panel = node:getChildByTag(101)
    self._rootCSbNode = panel
    local img_Bg  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"img_Bg")
    img_Bg:loadTexture("res/hd/Resources/scene/sc_pt_dixiacheng.jpg")
    
    self:initDefalutUI()
    local backBtn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:returnBack()
        end
    end)

    self.sManager.menuLayer:hiddenUserInfo(false)
    self.bReqBattleInfo = false  --没有获取到塔信息之前，不触发开始战斗事件    

    self:initBtnEvent()
    self:initLeftAndRightBtn()

    self:reqDDbattleInfo()
     --新手
    if XbTriggerGuideManager:isEndGuide(TriggerGuideConfig.HeiCao) then 
    else 
        self:showGuidePicLayer(true)
    end 
       
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.KRelics) ~= 1 then 
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.KRelics,1)
    end 
end

--默认UI状态。没有请求网络之前的
function DDBattleMainLayer:initDefalutUI()
    local lab_plancPic = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_time") --挑战圈
    local lab_fpValue =ccui.Helper:seekWidgetByName(self._rootCSbNode,"fpValue")   --总战力
    lab_plancPic:setString("x 0")
    lab_fpValue:setString(0)

    local plancPicIcon = ccui.Helper:seekWidgetByName(self._rootCSbNode,"mat_icon") --挑战圈
    plancPicIcon:loadTexture("icons/mat/"..useprop[4].icon)

end

function DDBattleMainLayer:initBtnEvent()
    --标签切换
    local function touchLabelBtnBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
           self:dealBtnEvent(sender.myTag)
        end
    end
    local btnkeys = {"btn_team","btn_start","btn_info","btn_see_reward"}
    for i=1,#btnkeys do
        local key = btnkeys[i]
        local btn = ccui.Helper:seekWidgetByName(self._rootCSbNode,key)
        btn.myTag = i --注：不用setTag 是为了防止tag值混乱
        btn:addTouchEventListener(touchLabelBtnBack)
    end
end

--1、队伍编成 2、开始战斗 3、说明
function DDBattleMainLayer:dealBtnEvent(selectTag)
    -- body
    local rData = {}
    if selectTag==1 then 
        self:toSelectTeamLayer()
    elseif selectTag == 2 then 
        self:toStartBattle()
    elseif selectTag == 3 then 
        self:showGuidePicLayer()
    elseif selectTag == 4 then 
        self:toMapItemDropsLayer(dd_battle[tonumber(self.curPassID)].drop_reward)
    end 
end

function DDBattleMainLayer:showGuidePicLayer(isShowGuide)
    local data = {}
    data.pictures = { --一张或者多张
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_027.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_028.png"
    }
    local function backFunc()
        XbTriggerGuideManager:finishGuide(TriggerGuideConfig.HeiCao)
    end
    data.sFunc = backFunc 
    data.sDelegate = nil 
    data.isShowGuide = isShowGuide or false  
    self.sManager:toGuidePictureLayer(data)
end
--处理左右按钮
function DDBattleMainLayer:initLeftAndRightBtn()
    self.btnLeft = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_left")
    self.btnRight = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_right")

    self.btnLeft:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.began then
            self:startSelectPass(-1)
        elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
            self:stopSelectPass()
        end
    end)

    self.btnRight:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.began then
            self:startSelectPass(1)
        elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
            self:stopSelectPass()
        end
    end)

    -- local bgRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode,"spine_node")
    -- local bganime = sp.SkeletonAnimation:create("effects/hezhan_t_1/hezhan_t_1.json", "effects/hezhan_t_1/hezhan_t_1.atlas", 1.0)
    -- bgRoot:addChild(bganime)
    -- bganime:setPosition(0, 0)
    -- bganime:setAnimation(1, "effect", true)
end

--刷新整个界面UI
function DDBattleMainLayer:refreshUI()
    print("刷新整个界面 UIDDBattleMainLayer:refreshUI")
    self:refreshTeamUI()
    self:refreshOtherUI()
    self.sManager.menuLayer:RefshTopBar()
end

--处理其他数据UI lab 
function DDBattleMainLayer:refreshOtherUI()
    self:refreshPassInfo()--刷新关卡信息
    local lab_plancPic = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_time") --挑战圈
    local lab_fpValue =ccui.Helper:seekWidgetByName(self._rootCSbNode,"fpValue")   --总战力
    lab_plancPic:setString("x "..self.ddbattleInfo.planc_pic)
    lab_fpValue:setString(self.ddbattleInfo.team_fp)

    local plancPicIcon = ccui.Helper:seekWidgetByName(self._rootCSbNode,"mat_icon") --挑战圈
    plancPicIcon:loadTexture("icons/mat/"..useprop[4].icon)
end

--todo 如果当前模型和旧的一模一样，不要重复处理
function DDBattleMainLayer:refreshTeamUI()
    local max = tonumber(DDBATTLE_MAX_TEAM_NUM)
    for i=1,max do
        local team_bg = ccui.Helper:seekWidgetByName(self._rootCSbNode,"team_bg_"..i) --队伍背景
        local id = self.ddbattleInfo.team_info[i]
        if id ~= nil and  id ~= "" and tostring(id) ~= "0" then 
             local hero_id = tonumber(getNumID(id))
            --当前模型的Spine没有、或者不相同，就删除旧的，重新加载
            if tonumber(team_bg.hero_id) ~= hero_id then --如果不同，就添加
                self:addLoadingUI(team_bg)
                self:addHeroSpine(team_bg, hero_id)
            end 
        else 
            --移除Spine，设置为没有状态
            self:removeHeroSpine(team_bg, hero_id)
        end 
    end
end
--加载UI 测试函数
function DDBattleMainLayer:addLoadingUI(partnerNode)
    local node = cc.Sprite:create("res/uifile/n_UIShare/daBattle/hz_ui_013.png")
    node:setAnchorPoint(cc.p(0.5,0))
    local rps = partnerNode:getSize()
    node:setPosition(cc.p(rps.width / 2 , rps.height / 2-20))
    node:setTag(66688)
    partnerNode:addChild(node)
end

--SPCacheManager
---todo 创建的加载缓存里面 SPCacheManager ,删除缓存
----todo 如果太卡，分批加载
function DDBattleMainLayer:addHeroSpine(partnerNode,hero_id)
    --删除旧的
    self:removeHeroSpine(partnerNode,hero_id)
    local lihuifile = hero[hero_id].hero_bat
    if cc.FileUtils:getInstance():isFileExist(lihuifile) then
        SPCacheManager:addAsyncSPToCache(lihuifile,function(backFile,spine)
                local isAdd = false
                if lihuifile==backFile then
                    if self.myExist  then 
                        if partnerNode~=nil then 
                            local rps = partnerNode:getSize()
                            spine:setPosition(cc.p(rps.width / 2 , rps.height / 2-20))
                            partnerNode:addChild(spine,0,111)
                            spine:setAnimation(1, "loading", true)
                            partnerNode.hero_id = hero_id
                            print("点点合战主页---加载spine "..lihuifile) 
                            local lab = partnerNode:getChildByTag(66688)
                            if lab ~= nil then 
                                partnerNode:removeChildByTag(66688)
                                lab = nil 
                            end 
                            isAdd = true
                        end 
                    end
                end 
                if isAdd then 
                else 
                    --测试
                    SPCacheManager:removeSPFromCache(backFile)
                    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                end 
        end)
    end

end

function DDBattleMainLayer:removeHeroSpine(partnerNode,hero_id)
    -- body
    if partnerNode.hero_id ~= nil and  tostring(partnerNode.hero_id) ~= "" and tostring(partnerNode.hero_id) ~= "0" then 
        partnerNode:removeAllChildren()
        local oldlihuifile = hero[tonumber(partnerNode.hero_id)].hero_bat
        --删除缓存
        local isNeedDelete = true
        for i=1,#self.ddbattleInfo.team_info do
            local id = self.ddbattleInfo.team_info[i]
            if id ~= nil and  id ~= "" and tostring(id) ~= "0" then  
                local hero_id = tonumber(getNumID(id))
                if hero_id == partnerNode.hero_id then 
                    isNeedDelete = false
                end 
            end

        end
        if isNeedDelete then 
            SPCacheManager:removeSPFromCache(oldlihuifile)
        else 
            print("不需要从缓冲中删除")
        end 
    end 
    partnerNode.hero_id = "0"
end

--开始战斗
function DDBattleMainLayer:toStartBattle()
    --剩余的挑战券 如果需要本地处理次数不足再判断
    --local nowPic = tonumber(self.ddbattleInfo.planc_pic)
    --当前选中关卡
    --todo 判断队伍信息没人的情况下不能进战斗
    self:reqStartDDbattle()
end

--显示战后结算页面
function DDBattleMainLayer:toDDBattleRewardLayer(data)
    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] =  self.reqDDbattleInfo
    rcvData["data"] =  data
    self.sManager:toDDBattleRewardLayer(rcvData)
end

--查看掉落
function DDBattleMainLayer:toMapItemDropsLayer(rewards)
    local data = {}
    data.title = UITool.ToLocalization("黑潮遗迹")
    data.rewards = rewards
    local rcvData = {}
    rcvData["data"] =  data
    rcvData["pos"] =  cc.p(40,-40)
    self.sManager:toMapItemDropsLayer(rcvData)
end

--去编队
function DDBattleMainLayer:toSelectTeamLayer()
    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] =  self.reqDDbattleInfo --刷新队伍 或者重新请求数据
    rcvData["team_info"] =  table.deepcopy(self.ddbattleInfo.team_info)
    self.sManager:toDDBattleRoleListView(rcvData)     
end

------------------------------左右选择关卡 按钮 相关处理函数start-------------------------
function DDBattleMainLayer:refreshPassInfo()
    if self.curPassID > self.minPassID then
        --可以减数
        self.btnLeft:setTouchEnabled(true)
        self.btnLeft:setBright(true)
    else
        self.btnLeft:setTouchEnabled(false)
        self.btnLeft:setBright(false)
    end

    if self.curPassID < self.maxPassID then
        --可以加数
        self.btnRight:setTouchEnabled(true)
        self.btnRight:setBright(true)
    else
        self.btnRight:setTouchEnabled(false)
        self.btnRight:setBright(false)
    end
    local passLabel = ccui.Helper:seekWidgetByName(self._rootCSbNode,"pass_lab")
    if self.curPassID < 10 then 
        passLabel:setString("00"..self.curPassID)
    elseif self.curPassID < 100 then 
        passLabel:setString("0"..self.curPassID)
    else 
        passLabel:setString(self.curPassID)
    end
end

--开始选关
function DDBattleMainLayer:startSelectPass(opt)
    self:stopSelectPass()
    --闭包变量
    local c_opt = opt
    local c_total_time = 10
    local c_cnt = 0
    
    local function addPassNumfunc(time)
        c_total_time = c_total_time + time
        c_cnt = c_cnt + 1
        
        local n = 1

        if c_total_time < 0.3 then
            return
        elseif c_total_time < 2 then 
            if c_cnt > 3.5 then
                c_cnt = 0
            else
                return
            end
        elseif c_total_time < 3 then
            if c_cnt > 2.5 then
                c_cnt = 0
            else
                return
            end
        elseif c_total_time < 4 then
            if c_cnt > 1.5 then
                c_cnt = 0
            else
                return
            end
        else
            c_cnt = 0
        end
            
        self.curPassID  = self.curPassID + n * c_opt
        
        if self.curPassID < self.minPassID then 
            self.curPassID = self.minPassID
            self:stopSelectPass()
        end

        if self.curPassID >  self.maxPassID then
            self.curPassID =  self.maxPassID
            self:stopSelectPass()
        end
        self:refreshPassInfo()
    end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerEntry = scheduler:scheduleScriptFunc(addPassNumfunc, 1/60 , false)
    
    addPassNumfunc(0) ---点击同时先加一次
    c_total_time = 0

end

--停止添加的计时器
function DDBattleMainLayer:stopSelectPass()
    if self.schedulerEntry == nil then return end
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.schedulerEntry)
    self.schedulerEntry = nil
end

--请求当前塔的信息
function DDBattleMainLayer:reqDDbattleInfo()
    self.bReqBattleInfo = false      

    local function ReqSuccess(data)
        self.ddbattleInfo = data
        self.bReqBattleInfo = true      --已经获取到新的塔信息
        self.curPassID = data.battle_num --当前的关卡--上次战斗的层数，注：如果有新解锁的层数，此出为新解锁的层数
        self.maxPassID = data.max_num --最大能选中的关卡
        self:refreshUI()
    end
    local tempTable = {
        ["rpc"] = "dd_battle_info",
    }
    self:doReq(tempTable, ReqSuccess,3) 
end

--请求开始战斗
function DDBattleMainLayer:reqStartDDbattle()
    if self.bReqBattleInfo == false then
        print("还没有获取到正确的塔信息")
        return
    end
    local function ReqSuccess(data)
        KeyboardManager:setbattleState(true)
        local scene = DDBattleACTMainLaye:create(data)
        cc.Director:getInstance():pushScene(scene)
    end
    local tempTable = {
        ["rpc"] = "dd_battle_start",
        ["tower_num"] = tonumber(self.curPassID),
    }
    self:doReq(tempTable, ReqSuccess,103)  --urlType 战斗的需要修改下，用多少就改成多少
end

--用于战斗胜利 调用这个接口
--请求战后结算
function DDBattleMainLayer:reqBattleResult()
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    local function ReqSuccess(data)
        --更新use数据
        user_info["beryl"] = data.beryl
        user_info["gold"] = data.gold
        user_info["gem"] = data.gem
        self.sManager.menuLayer:RefshTopBar()
        self:toDDBattleRewardLayer(data)
    end
    local tempTable = {
        ["rpc"] = "dd_battle_result",
        ["tower_num"] = tonumber(self.curPassID),
    }
    self:doReq(tempTable, ReqSuccess,3)
end

-----todo 发送请求的放到公共里面，现在不知道放哪，暂时放着。
function DDBattleMainLayer:doReq(tempTable, successFunc,urlType,failesFunc)
    urlType = urlType or 3
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager == nil then 
            print("DDBattleMainLayer :SManager is nil ")
            return 
        end 
        if self.sManager ~= nil then
          self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,urlType)
end