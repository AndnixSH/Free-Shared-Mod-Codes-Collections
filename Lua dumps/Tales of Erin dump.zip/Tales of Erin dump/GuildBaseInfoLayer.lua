require "BasicLayer"

GuildBaseInfoLayer = class("GuildBaseInfoLayer",BasicLayer)
GuildBaseInfoLayer.__index = GuildBaseInfoLayer
GuildBaseInfoLayer.lClass  = 3
GuildBaseInfoLayer.GuildBaseTable = nil



function GuildBaseInfoLayer:init()
    local node =cc.CSLoader:createNode("GuildBaseInfoLayer.csb")
    self.uiLayer:addChild(node,0,2) 
    self.exist = true
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self.GuildBaseTable = self.rData["rcvData"]["guildData"]  
    self.GuildBaseTable["guild_id"] = self.rData["rcvData"]["guild_id"] 
    self:initAttrbute()   
    

end
--/*初始化公会的属性*/
function GuildBaseInfoLayer:initAttrbute( ... )
    -- body
    local node              = self.uiLayer:getChildByTag(2)
    local panel             = node:getChildByName("Panel_1")
    local imagBg            = panel:getChildByName("Image_bg")
    --/*公会名字*/
    local guildName         = imagBg:getChildByName("Text_guildName")
    guildName:setString(self.GuildBaseTable["name"])

     --/*公会加入条件*/
    local guilConditon      = imagBg:getChildByName("Text_condition")
    local str = ""
    if self.GuildBaseTable["join_condition"] == 0 then
        str = UITool.ToLocalization("(自动通过)")
    else    
        str = UITool.ToLocalization("(需要审批)")
    end
    guilConditon:setString(str)

     --/*会长名字*/
    local chairmen          = imagBg:getChildByName("Text_chairmen")
    chairmen:setString(self.GuildBaseTable["chairman"])
    if g_channel_control.GuildBaseInfoLayerChairmen == true then
        chairmen:setPosition(cc.p(446,310)) --欧美服调整UI
    end
     --/*公会积分*/
    local guildScore        = imagBg:getChildByName("Text_score")
    guildScore:setString(self.GuildBaseTable["score"])

     --/*公会排行*/
    local guildRank         = imagBg:getChildByName("Text_rank")
    guildRank:setString(self.GuildBaseTable["ranking"])

     --/*公会当前成员数*/
    local membleCur         = imagBg:getChildByName("Text_cur")
    local  ncur       = UITool.SubStringToInt(self.GuildBaseTable["mem_num"],'/',1)
    if g_channel_control.transform_GuildBaseInfoLayer_Text_cur_pos_align == true then
        membleCur:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT)
        local oldX = 653
        local newX = oldX+10
        membleCur:setPositionX(newX)
    end
    membleCur:setString(ncur)

     --/*公会最大成员数*/
    local  nMax       = UITool.SubStringToInt(self.GuildBaseTable["mem_num"],'/',2)
    local membleMax         = imagBg:getChildByName("Text_Max")
    if g_channel_control.transform_GuildBaseInfoLayer_Text_Max_pos == true then
        local oldX = 652
        local newX = oldX+10
        membleMax:setPositionX(newX)
    end
    membleMax:setString("/"..nMax)

     --/*公会公告*/
    local Bulletin          = imagBg:getChildByName("Text_bulletin")
    Bulletin:setString(self.GuildBaseTable["notice"])

     --/*会长头像*/
    local chairmenIcon      = imagBg:getChildByName("Image_chairman")
    chairmenIcon:setUnifySizeEnabled(true)
    local heroid  = tonumber(self.GuildBaseTable["image"])
    chairmenIcon:loadTexture(hero[heroid].hero_bat_icon)
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if name == "Button_add" then
                self:AddGuildSend()
               -- self:returnBack()
            elseif name == "Button_memble" then
                local memberData = {}
                memberData["nType"]       = 1
                memberData["guild_id"]    = self.GuildBaseTable["guild_id"]
                memberData["GuildType"]   = self.rData["rcvData"]["GuildType"]
                memberData["selectIndex"] = 1
                memberData["pos"]         = nil
                self:returnBack()
                GuildInterface:GuildMember(memberData) 
            else
                self:returnBack()
            end
        end
    end
    -- /*加入按钮*/
    local addBtn            = imagBg:getChildByName("Button_add")
    if self.rData["rcvData"]["isGuild"] then
        addBtn:setTouchEnabled(false)
        addBtn:setBright(false)
    end
    -- /*成员按钮*/
    local MemeberBtn        = imagBg:getChildByName("Button_memble")
    panel:addTouchEventListener(touchCallBack)
    addBtn:addTouchEventListener(touchCallBack)
    MemeberBtn:addTouchEventListener(touchCallBack)

    -- local Button_memble = imagBg:getChildByName("Button_memble")
    -- local Text_bulletin_0 = Button_memble:getChildByName("Text_bulletin_0")
    -- if g_channel_control.transform_Text_bulletin_0_fontSizeAndPos == true then
    --     Text_bulletin_0:setFontSize(20)
    --     Text_bulletin_0:setPositionX(0)
    -- end
end
-- /*发送加入公会的结果*/
function GuildBaseInfoLayer:AddGuildSend(  )
    -- body
    local function reiceSthCallBack(data)
        print("加入公会")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["state"] == 0 then -- 需要申请
            local str = UITool.ToLocalization("您成功申请加入").."\n"..self.GuildBaseTable["name"]..UITool.ToLocalization("\n请耐心等待通过")
            MsgManager:showSimpMsg(str)
        elseif t_data["data"]["state"] == 1 then -- 直接通过
            local str = UITool.ToLocalization("您成功加入").."\n"..self.GuildBaseTable["name"]..UITool.ToLocalization("\n快去和大家打声招呼吧")
            -- local str = self.GuildBaseTable["name"]..UITool.ToLocalization("您成功加入")..UITool.ToLocalization("\n快去和大家打声招呼吧")
            MsgManager:showSimpMsgWithCallFunc1(str,self,self.AddSuccess)
          
           --聊天同步公会信息
            user_info["guild_notice"] = t_data["data"]["notice"] or ""
            -- XBChatSys:getInstance():saveMyGuideIdForChat(self.GuildBaseTable["guild_id"])
        end
    end
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "guild_join",
        ["guild_id"] = self.GuildBaseTable["guild_id"] , -- 推荐  2 排行
    }
    self.sManager:createWaitLayer()
    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- /*公会加入成功的回调*/
function GuildBaseInfoLayer:AddSuccess( ... )
    -- body
    print("公会加入成功，测试函数")
    if self.rData ~= nil then
        if self.rData["rcvData"] ~= nil then
            if self.rData["rcvData"]["callFunc"] ~= nil then
                local callFun = self.rData["rcvData"]["callFunc"]
                if self.rData["rcvData"]["self"] ~= nil then
                    local data = self.rData["rcvData"]["self"]
                    callFun(data)
                end
            end
        end
    end
    --self.rData["rcvData"]["callFunc"](self.rData["rcvData"]["self"])
    self:returnBack()
end

function GuildBaseInfoLayer:returnBack( ... )
    -- body
   --  self.exist = false
   -- -- self.area = {}
   --  self:clear()
    -- self.sManager:removeFromNavNodes(self)
    -- self.backFunc(self.sDelegate)
    self.exist = false
    self:clearEx()
end

function GuildBaseInfoLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function GuildBaseInfoLayer:create(rData)

     local login = GuildBaseInfoLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login
     -- local msgModel = MsgModelLayer.new()
     -- msgModel.rData = tdata 
     -- msgModel.sManager  = sManager
     -- msgModel.uiLayer = cc.Layer:create()
     -- msgModel:init()
     -- return msgModel
     
end
