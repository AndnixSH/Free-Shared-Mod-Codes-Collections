--require "XUIView"

RoleInfoPropView = class("RoleInfoPropView",XUIView)
RoleInfoPropView.CS_FILE_NAME = "NewRoleInfoPropView.csb"
RoleInfoPropView.CS_BIND_TABLE = 
{
    txtTitle = "/i:3/i:4/s:txtTitle",

    numAtk = "/i:3/i:4/s:numAtk",
    imgAtk = "/i:3/i:4/s:imgAtk",
    numCri = "/i:3/i:4/s:numCri",
    imgCri = "/i:3/i:4/s:imgCri",
    numCriDmg = "/i:3/i:4/s:numCriDmg",
    imgCriDmg = "/i:3/i:4/s:imgCriDmg",
    numHP = "/i:3/i:4/s:numHP",
    imgHP = "/i:3/i:4/s:imgHP",
    numHel = "/i:3/i:4/s:numHel",
    imgHel = "/i:3/i:4/s:imgHel",
    numDef = "/i:3/i:4/s:numDef",
    imgDef = "/i:3/i:4/s:imgDef",

    ----
    --panelM = "/i:3/i:4/i:271",
    m_roleName = "/i:3/i:4/i:271/s:roleName",
    m_numLv = "/i:3/i:4/i:271/s:numLv",
    m_numMat = "/i:3/i:4/i:271/s:numMat",
    btnLeft = "/i:3/i:4/i:271/s:btnLeft",
    btnRight = "/i:3/i:4/i:271/s:btnRight",
    btnUp = "/i:3/i:4/i:271/s:btnUp",
    --panelFace = "/i:3/i:4/i:271/i:287",
    m_panel = "/i:3/i:4/i:271/i:287",
    m_imgBG = "/i:3/i:4/i:271/i:287/s:imgBG",
    m_imgFace = "/i:3/i:4/i:271/i:287/s:imgFace",
    m_imgRarity = "/i:3/i:4/i:271/i:287/s:imgRarity",
    m_lbNum = "/i:3/i:4/i:271/i:287/s:lbNum",
    ----

    pskill = "/i:3/i:4/s:pskill",
    imgLock = "/i:3/i:4/s:pskill/s:imgLock",
    txtLock = "/i:3/i:4/s:pskill/s:txtLock",
    posTitle = "/i:3/i:4/s:pskill/s:posTitle",
    --txtDesc = "/i:3/i:4/s:pskill/s:txtDesc",

    pnoskill = "/i:3/i:4/s:pnoskill",

    btnOk = "/i:3/i:4/s:btnClose",
    slider = "/i:3/i:4/s:Slider_1",

    Panel_4 = "/i:3/i:4/i:5553",
    roleIconPos = "/i:3/i:4/i:5656",
    panelEffect = "/i:289",
    effMagic = "/i:289/s:effMagic",
    effNum = "/i:289/s:effNum",
    effNum2 = "/i:289/s:effNum2",
    Img_bg = "/i:3/i:4/i:5430",
}

--RoleInfoPropView.norTextColor = cc.c3b(255,255,255)
RoleInfoPropView.lackTextColor = cc.c3b(255,0,0)

function RoleInfoPropView:init()
    RoleInfoPropView.super.init(self)

    self.btnUp:addClickEventListener(function()
        if not self.mat_count then return end

        if self.hero_lv_add >= self.max_bouns then
            GameManagerInst:alert(UITool.ToLocalization("角色属性已提升至最高"))
            return
        end

        if self.mat_count == 0 and self.piece_count == 0 then
            GameManagerInst:alert(UITool.ToLocalization("请选择素材数量"))
            return
        end
        
        local mid = getMatID(ID_ROLE_ADDPROP)
        local _pieceId = getMatID(self.piece_id)
        local msg = "使用%d个%s提升角色属性？"
        local msg2 = "使用%d个%s和%d个%s提升角色属性？"
        local msg1 = ""

        if g_channel_control.order_RoleInfoPropView_enhangce_prop_msg == false then
            msg1 = string.format(UITool.ToLocalization(msg), self.mat_count,UITool.getUserLanguage(mat[mid].name)) 
        else

            --msg1 = string.format(UITool.ToLocalization(msg),tostring(UITool.getUserLanguage(mat[mid].name)) , tonumber(self.mat_count))
            if self.mat_count > 0 and self.piece_count > 0 then
                msg1 = string.format(UITool.ToLocalization(msg2),self.mat_count, tostring(UITool.getUserLanguage(mat[mid].name)),self.piece_count*self.combine_need,tostring(UITool.getUserLanguage(piece[_pieceId]["name"]))) 
            elseif self.mat_count > 0 and self.piece_count <= 0 then 
                msg1 = string.format(UITool.ToLocalization(msg), self.mat_count,tostring(UITool.getUserLanguage(mat[mid].name))) 
            elseif self.mat_count <= 0 and self.piece_count > 0 then
                msg1 = string.format(UITool.ToLocalization(msg), self.piece_count*self.combine_need,tostring(UITool.getUserLanguage(piece[_pieceId]["name"]))) 
            end
            print("msg1 = ",msg1)
        end
        local function f_call()
            self:playEffect()
        end
        -- UITool.ToLocalization("使用")..self.mat_count..UITool.ToLocalization("个")..mat[mid].name..UITool.ToLocalization("提升角色属性？")
        GameManagerInst:confirm(msg1,function()
            if self.addPropEvent then
                self.addPropEvent(self,self.mat_count,self.piece_count,self.piece_count * self.combine_need,f_call)
            end
        end)
    end)

    self.m_panel:setTouchEnabled(true)
    self.m_panel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local mid = getMatID(ID_ROLE_ADDPROP)
            MsgManager:showSimpItemInfo(5,mid)
        end
    end)
    self.Panel_4:getChildByName("Panel_16"):setTouchEnabled(true)
    self.Panel_4:getChildByName("Panel_16"):addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local mid = getMatID(self.piece_id)
            MsgManager:showSimpItemInfo(8,mid)
        end
    end)

    self.Img_bg:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:showTitleEffet()
        end
    end)

    self.btnLeft:addClickEventListener(function()
        self:setMatCount(-1)
    end)

    self.btnRight:addClickEventListener(function()
        self:setMatCount(1)
    end)

    self.btnOk:addClickEventListener(function()
        if self.returnBack then
            self.returnBack(self)
        end
    end)
    self.btn_piece_left = self.Panel_4:getChildByName("btnLeft")
    self.btn_piece_left:addClickEventListener(function()
        self:setPieceCount(-1)
    end)

    self.btn_piece_right = self.Panel_4:getChildByName("btnRight")
    self.btn_piece_right:addClickEventListener(function()
        self:setPieceCount(1)
    end)

    self.panelEffect:setVisible(false)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        if self.returnBack then
            self.returnBack(self)
        end
    end)

    return self
end

function RoleInfoPropView:loadData(data,hid,lv_add,piece_id)
    
    --基础属性
    self.prop_data = table.deepcopy(data)
    self.hero_id = hid
    self.hero_lv_add = lv_add

    self.mat_count = 0
    self.piece_count = 0
    self.piece_max = 0
    self.combine_need = 1
    self.mat_max = user_info["bag"]["mat"][ID_ROLE_ADDPROP]
    if not self.mat_max then
        self.mat_max = 0
    end

    local indexs = {
        { name = "Atk", key = "atk" },
        { name = "Cri", key = "crit" },
        { name = "CriDmg", key = "crit_dmg" },
        { name = "HP", key = "hp" },
        { name = "Hel", key = "hel" },
        { name = "Def", key = "def" },
    }

    for _,v in ipairs(indexs) do
        local name = v.name
        local key = v.key
        self["num"..name]:setString("+"..self.prop_data[key])
        self["img"..name]:setVisible(self.prop_data[key] > 0)
    end

    self.txtTitle:setString(""..UITool.getUserLanguage(hero[hid].hero_name)..UITool.ToLocalization("的额外能力提升"))
    
    local tempTextColor = cc.c3b(255,255,255)
    local titlename = ""
    for i = 1,#color_hero_bouns do
        local coloritem = color_hero_bouns[i]
        if lv_add >= coloritem[1] then
            tempTextColor = cc.c3b(coloritem[2], coloritem[3], coloritem[4])
            if string.len(title_hero_conf[hid]["title"][i]) > 0 then
                titlename = title_hero_conf[hid]["title"][i].." "
            else
                titlename = ""
            end
        end
    end

    --self.m_roleName:setTextColor(tempTextColor)
    --self.m_roleName:setString(UITool.getUserLanguage(titlename)..UITool.getUserLanguage(hero[hid].hero_name))

    self.max_bouns = color_hero_bouns[#color_hero_bouns][1]   --最大额外属性等级

    local htitle = title_hero_conf[hid]
    local skdesc = nil
    if htitle ~= nil then
        local title_id = htitle.title_id
        if title_id ~= nil and title_conf[title_id] ~= nil then
            skdesc = title_conf[title_id]
        end
    end

    self.pskill:removeChildByTag(10101)
    if skdesc ~= nil and skdesc.psk_id > 0 then
        self.pnoskill:setVisible(false)
        self.pskill:setVisible(true)
        
        --self.txtDesc:setString(UITool.getUserLanguage(skdesc.des))--(skdesc.des)


        local id_str = skdesc.res_spine
        if cc.FileUtils:getInstance():isFileExist(id_str) then         
            local end_pos = string.find(id_str,'atlas') - 1
            local spName = string.sub(id_str,0,end_pos)

            local skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
            skeletonNode:setPosition(self.posTitle:getPosition())
            self.pskill:addChild(skeletonNode,10101)
            skeletonNode:setAnimation(1, "effect", true)
        else 
            print("文件不存在 error file not exist:"..id_str)
        end


        --角色是否抽满
        if lv_add >= self.max_bouns then
            self.imgLock:setVisible(true)
            --self.txtLock:setVisible(false)
            --self.txtDesc:setTextColor(cc.c3b(245,233,207))
            self.txtLock:setString(UITool.ToLocalization("已觉醒"))
            self.txtLock:setTextColor(cc.c3b(255,243,94))
        else
            self.imgLock:setVisible(false)
            self.txtLock:setVisible(true)
            self.txtLock:setTextColor(cc.c3b(255,255,255))
            self.txtLock:setString(UITool.ToLocalization("10级觉醒解锁"))
            -- if g_channel_control.RoleInfoPropView_txtLockAnchor == true then 
            --     self.txtLock:setAnchorPoint(cc.p(0,1))
            --     self.txtLock:setPosition(cc.p(23,93)) --欧美服更新UI
            -- end
            --self.txtDesc:setTextColor(cc.c3b(161,161,161))
        end
    else
        self.pnoskill:setVisible(true)
        self.pskill:setVisible(false)
    end

    self.m_numLv:setString(""..lv_add.."/"..self.max_bouns)
    self.slider:setPercent(lv_add * 10)

    local mid = getMatID(ID_ROLE_ADDPROP)
    local rarity = mat[mid].rarity
    
    --self.m_imgBG:setTexture(Rarity_BG[rarity])
    self.m_imgRarity:setTexture(Rarity_mat[rarity])
    self.m_imgFace:setTexture("icons/mat/"..mat[mid].icon)
    self.m_lbNum:setString(self.mat_max)
    self.m_imgRarity:setScale(0.8)
    self.m_imgRarity:setVisible(false)
    self.m_imgFace:setScale(0.8)

    --碎片类型为8，暂时写死
    self.piece_id = piece_id
    local bag_useprop = user_info["bag"]["useprop"]
    if piece_id ~= 0 then
        local _pieceId = getMatID(piece_id)
        if bag_useprop and bag_useprop[piece_id] then
            local piece_count = bag_useprop[piece_id]["num"]
            self.Panel_4:getChildByName("Panel_16"):getChildByName("lbNum"):setString(tostring(piece_count))
            
            local _needPieceCount = piece[_pieceId]["combine_need"]
            self.combine_need = _needPieceCount
            self.piece_max = math.modf(piece_count / self.combine_need)
            if piece_count <  _needPieceCount then
                self.Panel_4:getChildByName("Panel_16"):getChildByName("lbNum"):setTextColor(self.lackTextColor)
            end
        else
            self.Panel_4:getChildByName("Panel_16"):getChildByName("lbNum"):setString(tostring(0))
            self.Panel_4:getChildByName("Panel_16"):getChildByName("lbNum"):setTextColor(self.lackTextColor)
        end
        self.Panel_4:getChildByName("roleName"):setString(UITool.getUserLanguage(piece[_pieceId]["name"]))
        local item_data = UITool.getItemInfos(8,_pieceId)
        --self.Panel_4:getChildByName("Panel_16"):getChildByName("imgBG"):setTexture(table.getValue("item_data",item_data,4))
        self.Panel_4:getChildByName("Panel_16"):getChildByName("imgFace"):setTexture(table.getValue("item_data",item_data,2))
        self.Panel_4:getChildByName("Panel_16"):getChildByName("imgRarity"):setTexture(table.getValue("item_data",item_data,1))
        self.Panel_4:getChildByName("Panel_16"):getChildByName("imgFace"):setScale(0.8)
        self.Panel_4:getChildByName("Panel_16"):getChildByName("imgRarity"):setScale(0.8)
        self.Panel_4:getChildByName("Panel_16"):getChildByName("imgRarity"):setVisible(false)
    end

    self:setMatCount(0)
    self:setPieceCount(0)
    self:initRoleSpine()
end

function RoleInfoPropView:setMatCount(offect)
    self.mat_count = self.mat_count + offect
    local ll = false
    local lr = false

    if self.mat_count <= 0 then
        self.mat_count = 0
        ll = true
    end

    if self.piece_count + self.mat_count + self.hero_lv_add >= self.max_bouns then
        lr = true
        self.btn_piece_right:setTouchEnabled(not lr)
        self.btn_piece_right:setBright(not lr)
    else
        if self.piece_count < self.piece_max and  self.piece_max >= 1 then
            self.btn_piece_right:setTouchEnabled(not lr)
            self.btn_piece_right:setBright(not lr)
        end
    end

    if self.mat_count + self.hero_lv_add >= self.max_bouns then
        self.mat_count = self.max_bouns - self.hero_lv_add
        lr = true
    end

    if  self.mat_count >= self.mat_max then
        self.mat_count = self.mat_max
        lr = true
    end


    self.btnLeft:setTouchEnabled(not ll)
    self.btnLeft:setBright(not ll)
    self.btnRight:setTouchEnabled(not lr)
    self.btnRight:setBright(not lr)

    self.m_numMat:setString(""..self.mat_count)
end

function RoleInfoPropView:setPieceCount(offect)
    self.piece_count = self.piece_count + offect
    local ll = false
    local lr = false

    if self.piece_count <= 0 then
        self.piece_count = 0
        ll = true
    end

    if self.piece_count + self.mat_count + self.hero_lv_add >= self.max_bouns then
        lr = true
        self.btnRight:setTouchEnabled(not lr)
        self.btnRight:setBright(not lr)
    else
        if self.mat_count < self.mat_max then
            self.btnRight:setTouchEnabled(not lr)
            self.btnRight:setBright(not lr)
        end
    end

    if self.piece_count + self.hero_lv_add >= self.max_bouns then
        self.piece_count = self.max_bouns - self.hero_lv_add
        lr = true
    end
    if  self.piece_count >= self.piece_max then
        self.piece_count = self.piece_max
        lr = true
    end

    if self.piece_max < 1 then
        lr = true
    end


    self.btn_piece_left:setTouchEnabled(not ll)
    self.btn_piece_left:setBright(not ll)
    self.btn_piece_right:setTouchEnabled(not lr)
    self.btn_piece_right:setBright(not lr)

    self.Panel_4:getChildByName("numMat"):setString(""..self.piece_count*self.combine_need)
end

function RoleInfoPropView:initRoleSpine()
    local h_id_num = self.hero_id 

    --动态模型，立绘
    local lihuifile = hero[h_id_num].hero_des_spi

    self.roleIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(lihuifile) then

        local end_pos = string.find(lihuifile,'atlas') - 1
        local spName = string.sub(lihuifile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil
            self.roleIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect1", true)
        end)
    end
end

function RoleInfoPropView:playEffect()
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)

    local effs = {
        {self.effMagic,"EffAwkMagic.csb"},
        {self.effNum,"EffAwkNum.csb"},
        {self.effNum2,"EffAwkNum.csb"}
    }

    for i = 1,#effs do
        local node_1 = cc.CSLoader:createNode(effs[i][2])
        local timeline_1 =cc.CSLoader:createTimeline(effs[i][2])
        node_1:setTag(123)
        local psize = effs[i][1]:getSize()
        node_1:setPosition(cc.p(psize.width/2,0))
        effs[i][1]:addChild(node_1)

        node_1:runAction(timeline_1)
        timeline_1:play("animation0",false) 
        timeline_1:setLastFrameCallFunc(function ()
            node_1:stopAllActions()
            node_1:removeFromParent()
        end)
    end
              
    AudioManager:shareDataManager():playMusic("music/ui/tupo.mp3",0, false)   
     
    local delay = cc.DelayTime:create(1.3)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:stopEffect()
    end))
    self.panelEffect:runAction(sequence)    
end

function RoleInfoPropView:stopEffect()
    KeyboardManager._isShowEffect = false
    self.panelEffect:stopAllActions()

    local effs = {
        self.effMagic,
        self.effNum,
        self.effNum2
    }

    for i = 1,#effs do
        local e = effs[i]:getChildByTag(123)
        if e then e:stopAllActions() end
        effs[i]:removeAllChildren()
    end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    
    if self.effectStopedEvent then
        self.effectStopedEvent(self)
    end
end

function RoleInfoPropView:showTitleEffet( ... )
    local temp = {
        rpc = "hero_title_info",
        hero_id = self.hero_id,
    }
    GameManagerInst:rpc(temp,3,
    function(data)
        if data["title_info"]["is_got"] == 1 then
            data["title_info"]["got"] = true
            data["title_info"]["collectValue"] = 1
        end
        local layer = TitleInfoLayer.new():init(data["title_info"])
        GameManagerInst:showModalView(layer)
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end
