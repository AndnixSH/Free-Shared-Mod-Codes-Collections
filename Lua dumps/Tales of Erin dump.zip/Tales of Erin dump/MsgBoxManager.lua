MsgBoxManager = class("MsgBoxManager")

MsgBoxManager.bgDes = 
{
	[1] = "res/uifile/n_UIShare/AllMessgae/tc_ui_010.png",
	[2] = "res/uifile/n_UIShare/AllMessgae/tc_ui_006.png",
	[3] = "res/uifile/n_UIShare/AllMessgae/tc_ui_002.png",
	[4] = "res/uifile/n_UIShare/AllMessgae/tc_ui_009.png",
}

--bgType:选择背景的大小（1:小图; 2:中图;3:大图;4:特大图
--boxType:弹窗的类型 （0:不带图片的详情界面(暂时没需求)；1:带产出的详情界面;2:先显示产出，然后跳转显示售卖的;3: 显示购买的;4:带产出，道具可以直接使用，适用于道具详情）
function MsgBoxManager:showMsgBox(bgType,boxType,tab_data)
	bgType = 3--默认用第三个（以后有需求再修改）
	local Tab_data = {}
	Tab_data["boxType"] = boxType
	Tab_data["bgDes"] = MsgBoxManager.bgDes[bgType]
	Tab_data["tab_data"] = self:GetTabData(boxType,tab_data)

	dump(Tab_data,"Tab_data:")
	SceneManager:showMsgBox(Tab_data)
end

-- _type == 2
-- {
-- 	道具贩卖，多用于背包进行出售素材等 fanmai.png
-- 	参数 item_type 道具类型
-- 	item_id 道具ID 
-- 	cost_type 贩卖获得货币的类型 1 金币  2 星石 13 苍玉
-- 	cost_num  单个贩卖所得的货币数
-- 	max_buy_num  最大贩卖的次数
-- 	oneSelf   代理者
-- 	callfunc  回调方法
-- 	costOnly  单价
-- 	itemNum   道具数量
-- 	sellType 贩卖类型  0 是不能贩卖
-- isCallFunc 是否回调callfunc
-- hideCallFunc 隐藏界面回调
-- reloadCallFunc 倒计时结束需要刷新界面的回调
-- }

function MsgBoxManager:GetTabData(_type,_data)
	if _data == nil then
		return nil
	end
	local tab = {}
	if _type == 0 then

	elseif _type == 1 then
		tab = 
		{
			["self"] 			= table.getValue("_data",_data,"self"),
			["item_id"]			= table.getValue("_data",_data,"item_id"),
			["item_type"] 		= table.getValue("_data",_data,"item_type"),
			["itemNum"]			= table.getValue("_data",_data,"itemNum"),
			["callFunc"] 		= table.getValue("_data",_data,"callFunc"),
			["img"]				= table.getValue("_data",_data,"img"),
			["dec"]				= table.getValue("_data",_data,"dec"),
			["name"]			= table.getValue("_data",_data,"name"),
		}
	elseif _type == 2 then
		tab = 
		{
			["self"] 			= table.getValue("_data",_data,"self"),
			["item_id"]			= table.getValue("_data",_data,"item_id"),
			["item_type"] 		= table.getValue("_data",_data,"item_type"),
			["cost_type"] 		= table.getValue("_data",_data,"cost_type"),
			["cost_num"] 		= table.getValue("_data",_data,"cost_num"),
			["max_buy_num"] 	= table.getValue("_data",_data,"max_buy_num"),
			["callFunc"] 		= table.getValue("_data",_data,"callFunc"),
			["costOnly"] 		= table.getValue("_data",_data,"costOnly"),
			["itemNum"] 		= table.getValue("_data",_data,"itemNum"),
			["sellType"] 		= table.getValue("_data",_data,"sellType"),
			["reloadCallFunc"] 	= table.getValue("_data",_data,"reloadCallFunc"),
			["refreshTopbar"]	= table.getValue("_data",_data,"refreshTopbar"),
		}
	elseif _type == 3 then
        tab = 
        {
        	["self"]			= table.getValue("_data",_data,"self"),
        	["item_id"]			= table.getValue("_data",_data,"item_id"),
        	["item_type"]		= table.getValue("_data",_data,"item_type"),
        	["itemNum"]			= table.getValue("_data",_data,"itemNum"),
        	["max_buy_num"]		= table.getValue("_data",_data,"max_buyNum"),
        	["cost_type"]		= table.getValue("_data",_data,"cost_type"),
        	["cost_num"]		= table.getValue("_data",_data,"cost_num"),
        	["callFunc"]		= table.getValue("_data",_data,"callFunc"),
        	["add_del_show"]	= table.getValue("_data",_data,"add_del_show"),
    	}
    elseif _type == 4 then
		tab = 
		{
			["self"] 			= table.getValue("_data",_data,"self"),
			["sTiem"]			= table.getValue("_data",_data,"sTime"),--没有就传nil
			["item_id"]			= table.getValue("_data",_data,"item_id"),
			["item_type"] 		= table.getValue("_data",_data,"item_type"),
			["itemNum"]			= table.getValue("_data",_data,"itemNum"),
			["callFunc"] 		= table.getValue("_data",_data,"callFunc"),
			["isCallFunc"]		= table.getValue("_data",_data,"isCallFunc"),
			["hideCallFunc"]	= table.getValue("_data",_data,"hideCallFunc"),
			["refreshTopbar"]	= table.getValue("_data",_data,"refreshTopbar"),
			["can_make"]        = table.getValue("_data",_data,"can_make"),
		}
	else
		print("error _type:",_type)
	end

	return tab
end























