
fb_limit = {}
fb_limit["rarity_max"] = 5