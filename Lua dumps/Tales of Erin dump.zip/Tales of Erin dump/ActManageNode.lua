ActManageNode = class("ActManageNode", XUICellView)
ActManageNode.CS_FILE_NAME = "ActManageLongNode.csb"
ActManageNode.actId = nil
ActManageNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}

function ActManageNode:init(...)

    NewMailNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
 
    return self
end
function ActManageNode:setData( tdad )
    -- body
    self.DataTest = tdad;
    self.OnSelf  = tdad["OnSelf"];
end

function ActManageNode:onResetData()
  
    if not self._data then return end
    local dtable = {
            ["state"]        = self._data["state"],    --0 去完成 1 可以领取 2 已领取              
            ["reward"]       = self._data["reward"] or {},   --条目列表 可能为空        
            ["id"]           = self._data["id"],       -- 条目id 
            ["name"]         = UITool.getUserLanguage(self._data["name"]),     -- 条目名字  
            ["parameter"]    = self._data["parameter"],  -- 跳转的功能
            ["ui_file"]      = self._data["ui_file"],    -- 跳转的功能
            ["act_id"]       = self._data["act_id"],     -- 跳转的功能
            ["finish_times"] = self._data["finish_times"], -- 最大数量
            ["curr_times"]   = self._data["curr_times"],   -- 当前数量
            ["unlock_lv"]    = self._data["unlock_lv"],    -- 解锁等级
    }
    local  panelP        = self.PanelList
    -- 条目的名字
    local  title         = panelP:getChildByName("Text_title")
    title:setString(dtable["name"])
    --  去完成
    local getBtn          = panelP:getChildByName("Button_get") 
    -- 可领取
    local OkBtn          = panelP:getChildByName("Button_OkGet") 
    -- 已领取
    local OverBtn          = panelP:getChildByName("Image_29") 

    -- 进度条

    local  barBg   = panelP:getChildByName("Image_loadbar_bg")
    if barBg ~= nil then
        local  bar     = barBg:getChildByName("LoadingBar_2")
        local  barTex  = barBg:getChildByName("Text_1")
        bar:setPercent(math.floor(100*dtable["curr_times"]/dtable["finish_times"]))
        print("数量是 curr_times == "..dtable["curr_times"])
        print("数量是 finish_times == "..dtable["finish_times"])
        barTex:setString(dtable["curr_times"].."/"..dtable["finish_times"])
    end
    
    if dtable["state"] == 0 then
        OverBtn:setVisible(false)
        OkBtn:setVisible(false)
        getBtn:setVisible(true)
        if dtable["parameter"] == "" then
            getBtn:getChildByName("Text_title_0"):setString(UITool.ToLocalization("未完成"))
        else
            getBtn:getChildByName("Text_title_0"):setString(UITool.ToLocalization("去完成"))
        end
    elseif dtable["state"] == 1 then
        OverBtn:setVisible(false)
        OkBtn:setVisible(true)
        getBtn:setVisible(false)
    elseif dtable["state"] == 2 then  
        OverBtn:setVisible(true)
        OkBtn:setVisible(false)
        getBtn:setVisible(false)
    end
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if name == "Button_get" then -- 去完成
                --跳转界面
                -- print("冒险等级达到 self.OnSelf.UnLock_level == "..self.OnSelf.UnLock_level)
                -- print("冒险等级达到 self.dtable.UnLock_level == "..dtable["unlock_lv"])
                -- print("跳转界面 =="..dtable["parameter"])
                if tonumber(user_info["rank"])  >= self.OnSelf.UnLock_level then   -- 判断外边是否达到解锁等级
                    if tonumber(user_info["rank"])  >= dtable["unlock_lv"] then  -- 外层 达到解锁等级在判断里层是否达到解锁等级
                        if dtable["ui_file"] == "" then
                        else
                            -- 正式后删除
                             self.OnSelf.actId = dtable["act_id"]
                             require_ex(dtable["ui_file"])
                        end
                        if dtable["parameter"] == "" then
                           SceneManager:showPromptLabel(UITool.ToLocalization("此项目未完成"))  
                        else
                          loadstring(dtable["parameter"])()-- 跳转
                        end
                    else
                        local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"), dtable["unlock_lv"])
                        SceneManager:showPromptLabel(str)  
                    end
                else
                    local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"), self.OnSelf.UnLock_level)
                    SceneManager:showPromptLabel(str)
                end
                --loadstring(dtable["parameter"])() -- 跳转
         
            elseif name == "Button_OkGet" then -- 领取
                -- 调用领取传入条目id  传入获取的ite
                self.OnSelf:sendGet(dtable["id"],dtable["reward"])
                -- 回来之后设置状态
                self._data["state"] = 2
                if self._data["state"] == 2 then  
                    OverBtn:setVisible(true)
                    OkBtn:setVisible(false)
                    getBtn:setVisible(false)
                end
            end
        end
    end

    OkBtn:addTouchEventListener(touchCallBack)
    getBtn:addTouchEventListener(touchCallBack)
    -----------分界线 对每个条目里边的小列表进行设置----
    -- 隐藏多余的
    local curMax = #dtable["reward"] or 0
    for y = 1 ,4 do
        local bg   = panelP:getChildByName("Image_1")
        -- 获取的这个modl也是背景
        local modl = bg:getChildByName("Image_Model_"..y)
        if y > curMax then

            modl:setVisible(false)
        else
            modl:setVisible(true)
        end
    end
    for i= 1,#dtable["reward"] do 
        local popr = {}
       
        popr       = UITool.getItemInfos(tonumber(dtable["reward"][i]["type"]),tonumber(dtable["reward"][i]["id"]))
        local bg   = panelP:getChildByName("Image_1")
        -- 获取的这个modl也是背景
        local modl = bg:getChildByName("Image_Model_"..i)
        -- icon
        local icon = modl:getChildByName("Image_icon")
        icon:setUnifySizeEnabled(true)
        -- 框
        local form = modl:getChildByName("Image_from")
        -- 数量
        local Texnum  = modl:getChildByName("Text_num")

        modl:loadTexture(popr[4])
        icon:loadTexture(popr[2])
        form:loadTexture(popr[1])
        print("现在的数量是== .."..dtable["reward"][i]["num"])
        print("现在的长度是== .."..#dtable["reward"])
        Texnum:setFontSize(32)
        Texnum:setString("x"..dtable["reward"][i]["num"])
        -- 设置属性求
        if popr[3] ~= "" and popr[3] ~= nil then 
            print("这个图片 == "..popr[3])
            local elementImg = cc.Sprite:create(popr[3])
            if elementImg ~= nil then
                elementImg:setAnchorPoint(cc.p(1,1))
                elementImg:setPosition(form:getContentSize().width,form:getContentSize().height)
                elementImg:setScale(0.8)
                form:addChild(elementImg)
            end
        else
            form:removeAllChildren()
        end 
        local function touchCallBack(sender,eventType)
            local name = sender:getName()
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()
                local l = cc.pGetDistance(p1,p2)
                if l < 30 then
                    MsgManager:showSimpItemInfo(tonumber(dtable["reward"][i]["type"]),tonumber(dtable["reward"][i]["id"]))
                end 
                
            end
        end
        form:setSwallowTouches(false)
        form:addTouchEventListener(touchCallBack)
        
    end
    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end
