--require "XUIView"

NewRoleSoulSthView = class("NewRoleSoulSthView",XUIView)
NewRoleSoulSthView.CS_FILE_NAME = "NewRoleSoulSthView.csb"
NewRoleSoulSthView.CS_BIND_TABLE = 
{
    panelEffect = "/i:632",
    effIcon = "/i:632/s:effIcon",

    panelSort = "/i:87/s:panelSort",
    panelList = "/i:87/i:111",
    panelLevel = "/i:87/i:107",
    panelIcon = "/i:87/i:213",
    --
    panelProp = "/i:87/i:173",
    --
    lbCurAtk = "/i:87/i:173/i:176",
    lbAddAtk = "/i:87/i:173/i:177",
    lbCurHP = "/i:87/i:173/i:180",
    lbAddHP = "/i:87/i:173/i:181",
    btnStartSth = "/i:87/i:282",
    lbMatNum = "/i:87/i:173/i:2476",
    btnAutoChoose = "/i:87/i:173/i:357",
    btnAutoChooseText = "/i:87/i:173/i:357/i:358",
    ImgBtnEq = "/i:87/i:522",
    ImgBtnNoEq = "/i:87/i:524",
    panelGray = "/i:733",
    btnClose="/i:154/i:156",
    spSubMax = "/i:87/i:1342",
}

NewRoleSoulSthView.IsHadSthMax = false
NewRoleSoulSthView.IsSthMax = false
NewRoleSoulSthView.bIsPlayingEffect = false
function NewRoleSoulSthView.createWithBackBtn()
    local v = NewRoleSoulSthView.new():init()
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function NewRoleSoulSthView:init(nHeroId,hideCallFunc,ReLoadCallFunc,sDelegate)
    NewRoleSoulSthView.super.init(self)

    self.hideCallFunc = hideCallFunc
    self.ReLoadCallFunc = ReLoadCallFunc
    self.sDelegate = sDelegate

    self.panelGray:setTouchEnabled(true)
    self.panelGray:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:returnBack()
        end
    end)

    self.CurTargetId = nHeroId
    if self.CurTargetId then
        self.curSoulEquipId = tonumber(getNumID(self.CurTargetId))--暂定魂灵装与角色ID一致（修改需要增加从角色ID转换为专属灵装ID的方法转换）
    end
    if hero_soul[self.curSoulEquipId] then
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
        print("NewRoleSoulSthView:init=====name:"..self.hero_soul_info.name)
    end

    self.spSubMax:setVisible(false)

    self.panelEffect:setVisible(false)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = EquipListItemView.new():init()

        temp.ClickEvent = function(item)
            self:equipClickEvent(item)
        end
        
        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = 0
            if g_channel_control.b_newEqBag then
                smode = self.sortBtnView:getSortMode() / 10
            else
                smode = self.sortBtnView:getSortMode() % 10
            end
            item:setTitleMode(smode)

            item:setSelected(item:getData()._isselected)
        end
        return temp
    end

    self.btnStartSth:addClickEventListener(function()
        self:onSoulEquipSth()
    end)

    self.btnAutoChoose:addClickEventListener(function()
        self:onAutoChoose()
    end)

    self.iconView = SEIconView.new():init(self.panelIcon,self.curSoulEquipId,1)

    --排序
    if g_channel_control.b_newEqBag then
        self.sortBtnView = EqSortButtonView.new():init(self.panelSort,"EqP_se",21,"EqS_Rank_se",0,"EqS_Ele_se",0,"EqS_Brk_se",0)
        self.sortBtnView.sortModeChangedEvent = function()
            self:ReLoadData()
        end
    else
        self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_q",512,1)
        self.sortBtnView.sortModeChangedEvent = function()
            self:refresh()
        end
    end
    --
    if g_channel_control.b_newEqBag then

        self.nSelectTitleNum = self.nDefaultSelect or 0 --1:已装。2:未装

        self.bEnableEqTitle = false   --已装灵装按钮是否有效
        self.bEnableNoEqTitle = true --未装灵装按钮是否有效

        self.ImgBtnEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableEqTitle then
                    self:onSelectTitle(1)
                end
            end
        end)
        self.ImgBtnEq:setSwallowTouches(true)

        self.ImgBtnNoEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableNoEqTitle then
                    self:onSelectTitle(0)
                end
            end
        end)
        self.ImgBtnNoEq:setSwallowTouches(true)
        
        self:onCallEqListByTitle(self.nSelectTitleNum)
    end
    --

    self.lvupView = SthLevelUpView.new():init(self.panelLevel)

    self.lvupView:setLevelInfo(nil,0,0,0)
        
    self.btnStartSth:setTouchEnabled(false)
    self.btnStartSth:setBright(false)
    self.lbMatNum:setString("0")


    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    return self
end

function NewRoleSoulSthView:ResetHeroId(nheroid)
    if nheroid then
        self.CurTargetId = nheroid
        if self.CurTargetId then
            self.curSoulEquipId = tonumber(getNumID(self.CurTargetId))--暂定魂灵装与角色ID一致（修改需要增加从角色ID转换为专属灵装ID的方法转换）
        end
        if hero_soul[self.curSoulEquipId] then
            self.hero_soul_info = hero_soul[self.curSoulEquipId]
        end

        if g_channel_control.b_newEqBag then
            self:ReLoadData()
        else
            self:refresh()
        end
    end
end

function NewRoleSoulSthView:onSelectTitle(nSelectNum)
    if self.nSelectTitleNum ~= nSelectNum then
        self.nSelectTitleNum = nSelectNum
        self:onCallEqListByTitle(self.nSelectTitleNum)
    end
end

function NewRoleSoulSthView:onCallEqListByTitle(nSelectNum)
    --与后端交互获取新的装备列表
    self:ReLoadData()
    --
    self:refreshTitleBtnState()
end

function NewRoleSoulSthView:refreshTitleBtnState()
    if self.nSelectTitleNum == 1 then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[2])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[1])
    else
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[1])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[2])
    end

    if not self.bEnableEqTitle then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
    if not self.bEnableNoEqTitle then
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
end

function NewRoleSoulSthView:FillSoulEquipData(rcvData)
    if rcvData then
        self.Se_info = nil
        self.Se_info = table.deepcopy(rcvData)
        if self.Se_info["state"] ~= 0 then
            self:refreshExpInfo()
        end
    end
end

function NewRoleSoulSthView:refreshStates()
    if not self.Se_info then
        print("NewRoleSoulSthView:refreshStates not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end
    if self.Se_info["state"] == 0 then
        return
    end

    --升华阶段
    local nSublStageCount = tonumber(self.Se_info["break_count"])
    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    if self.iconView then
        self.iconView:RefreshSeIcon(self.curSoulEquipId,nSublStageCount)
    end

    local bIsHadSelect = self:IsHadSelected()
    if bIsHadSelect then
        self.bCanAutoChoose = false
        self.btnAutoChoose:loadTextures(SOUL_STH_DISAUTO_BTN_IMG[1],SOUL_STH_DISAUTO_BTN_IMG[2],SOUL_STH_DISAUTO_BTN_IMG[3])
        self.btnAutoChooseText:setString(UITool.ToLocalization("取消添加"))
    else
        self.bCanAutoChoose = true
        self.btnAutoChoose:loadTextures(SOUL_STH_AUTO_BTN_IMG[1],SOUL_STH_AUTO_BTN_IMG[2],SOUL_STH_AUTO_BTN_IMG[3])
        self.btnAutoChooseText:setString(UITool.ToLocalization("自动添加"))
    end

    --self:refreshExpInfo()
    --self:refreshPropNum()

end

function NewRoleSoulSthView:refreshExpInfo()
    if not self.Se_info then
        print("NewRoleSoulSthView:refreshExpInfo not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end
    if self.Se_info["state"] == 0 then
        return
    end

    if self.bIsPlayingEffect then
        return
    end

    local data = self.Se_info
    if data["break_count"] >= hero_soul[self.curSoulEquipId]["soul_break"]["total_break"] then
        --满升华
        if data["Lv"] >= data["Lv_max"] then
            --满升华满突破
            self:refreshMax()
            return
        end
    end
    --升华阶段
    local nCurSublStageCount = tonumber(data["break_count"])

    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    if self.iconView then
        self.iconView:RefreshSeIcon(self.curSoulEquipId,nCurSublStageCount)
    end

    self.IsHadSthMax = data["Lv"] >= data["Lv_max"]
    
    --加载经验值
    local expTable = {}
    for i = 1,#hero_soul_upgrade[self.curSoulEquipId] do
        expTable[i] = hero_soul_upgrade[self.curSoulEquipId][i][1]
    end
    
    self.lvupView:setLevelInfo(expTable,data["Lv"],data["Lv_max"],data["exp"])
    local flv,ismax = self.lvupView:getFinalLevel()

    self.btnStartSth:setTouchEnabled(not ismax)
    self.btnStartSth:setBright(not ismax)

end

function NewRoleSoulSthView:refreshMax()
    if not self.Se_info then
        print("NewRoleSoulSthView:refreshPropNum not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end
    if self.Se_info["state"] == 0 then
        return
    end

    self.lbAddAtk:setString("")
    self.lbAddHP:setString("")

    local data = self.Se_info

    local nAtk = data["atk"] + data["add_atk"]
    local nHp = data["hp"] + data["add_hp"]
    self.lbCurAtk:setString(nAtk)
    self.lbCurHP:setString(nHp)

    self.btnStartSth:setTouchEnabled(false)
    self.btnStartSth:setBright(false)
    self.btnAutoChoose:setTouchEnabled(false)
    self.btnAutoChoose:setBright(false)
    self.lvupView:setLevelInfo(nil,0,0,0)

    --升华阶段
    local nCurSublStageCount = tonumber(data["break_count"])

    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    if self.iconView then
        self.iconView:RefreshSeIcon(self.curSoulEquipId,nCurSublStageCount)
    end

    self.currentDataSource = {}
    self.gridview:setDataSource(self.currentDataSource)
    self.gridview:refresh()
end

-- # ■ [装备详情]* hero_soul_info
-- #  "hero_id": "1*1299656990",  #对应的角色ID
-- #返回:
-- data = {
--  "state_code": 1,
--  "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":1,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
-- }

function NewRoleSoulSthView:refreshPropNum(flv)
    if not self.Se_info then
        print("NewRoleSoulSthView:refreshPropNum not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end
    if self.Se_info["state"] == 0 then
        return
    end

    local data = self.Se_info
    local e_id_num = self.curSoulEquipId

    local curStateAtk = data["atk"]
    local curStateHP = data["hp"]

    local curLv = data["Lv"]

    local addAtk = hero_soul_upgrade[e_id_num][flv][3] - curStateAtk
    local addHP = hero_soul_upgrade[e_id_num][flv][2] - curStateHP

    local nAtk = data["atk"] + data["add_atk"]
    local nHp = data["hp"] + data["add_hp"]
    self.lbCurAtk:setString(nAtk)
    self.lbCurHP:setString(nHp)

    --self.lbCurAtk:setString(curAtk)
    if addAtk > 0 then
        self.lbAddAtk:setString("+"..addAtk)
    else
        self.lbAddAtk:setString("")
    end

    --self.lbCurHP:setString(curHP)
    if addHP > 0 then
        self.lbAddHP:setString("+"..addHP)
    else
        self.lbAddHP:setString("")
    end
end

--
--计算选择的灵装提供的所有强化经验
function NewRoleSoulSthView:GetAllExp()

    local inum = 0
    local AllSkillExp = 0
        
    for i = 1,#self.currentDataSource do 
        local ld = self.currentDataSource[i]
        if ld._isselected then
            if ld.id then
                inum = inum + 1
                print("NewRoleSoulSthView==GetAllExp ld.id:"..ld.id)
                local eqId = tonumber(getNumID(ld.id))
                if equip[eqId] then
                    AllSkillExp = AllSkillExp + equip[eqId].hero_soul_exp
                end
            end
        end
    end
    self.lbMatNum:setString(inum)

    return AllSkillExp
end

function NewRoleSoulSthView:computExp()
    if not self.Se_info then
        return
    end
    if self.bIsPlayingEffect then
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end
    self.lvupView:setAddExp(self:GetAllExp())
    local flv,ismax = self.lvupView:getFinalLevel()
    self.IsSthMax = ismax
    self:refreshPropNum(flv)
end

function NewRoleSoulSthView:equipClickEvent(item)



    if not self.Se_info then
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end

    if self.IsHadSthMax then -- 已达到强化上限
        GameManagerInst:alert(UITool.ToLocalization("已达到等级上限"))
        return
    end



    local data = item:getData()

    if data then
        if data._isselected then
            data._isselected = false
        else
            if self.IsSthMax then
                GameManagerInst:alert(UITool.ToLocalization("本次强化后等级已可达上限，无需继续勾选"))
                return
            end
            local nselect = 0
            for i = 1,#self.currentDataSource do 
                if self.currentDataSource[i]._isselected then
                    nselect = nselect + 1
                end
            end
            if nselect < 20 then
                data._isselected = true
            else
                GameManagerInst:alert(UITool.ToLocalization("魂灵装强化素材勾选数量已达上限"))
            end
        end
        self.gridview:refresh()
    end

    --计算升级 
    self:computExp()
    --
    self:refreshStates()
end

function NewRoleSoulSthView:playEffect()
    self.panelEffect:setVisible(true)
    --
    local skeletonNode = sp.SkeletonAnimation:create("effects/hun_ling_zhuang/hun_ling_zhuang.json", "effects/hun_ling_zhuang/hun_ling_zhuang.atlas", 1.0)
    --skeletonNode:setAnimation(1, "effect", false)
    local psize = self.effIcon:getSize()
    skeletonNode:setPosition(cc.p(psize.width/2,psize.height/2))
    skeletonNode:setTag(123)   
    self.effIcon:addChild(skeletonNode,0,123)
    --

    -- local node_1 = cc.CSLoader:createNode("EffSthFrame.csb")
    -- local timeline_1 =cc.CSLoader:createTimeline("EffSthFrame.csb")
    -- local psize = self.effIcon:getSize()
    -- node_1:setPosition(cc.p(psize.width/2,0))
    -- node_1:runAction(timeline_1)
    -- self.effIcon:addChild(node_1,0,123)
    self.bIsPlayingEffect = true
    self.lvupView.levelUpEffectEvent = function()
        skeletonNode:setAnimation(1, "effect", false) 
    end
    self.lvupView.effectEndEvent = function()
        self:stopEffect()
    end
    self.lvupView:playEffect()

    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
end

function NewRoleSoulSthView:stopEffect()
    self.lvupView.levelUpEffectEvent = nil
    self.lvupView.effectEndEvent = nil
    self.lvupView:stopEffect()

    self.effIcon:removeAllChildren()

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    self.bIsPlayingEffect = false

    if not self.Se_info then
        print("NewRoleSoulSthView:refreshExpInfo not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end

    local data = self.Se_info
    if data["break_count"] >= hero_soul[self.curSoulEquipId]["soul_break"]["total_break"] then
        --满升华
        if data["Lv"] >= data["Lv_max"] then
            --满升华满突破
            self:refreshMax()
            return
        end
    end

    self:refresh()
    self:refreshExpInfo()

end

-- # -----------------------------------------------------
-- # ■ [魂灵装强化] 
-- # 接口名: hero_soul_lv_up
-- # 参数1 : target_id: "1*1299656994",  # 要强化升级的魂灵装ID
-- # 参数2 : eat_equips: [],   # 被消耗掉的装备列表,结构如下
-- eat_equips = [ 
--     "1*1299656994",
--     "1*1299656994",
--     "1*1299656994",
-- ]
-- #返回:
-- data = {
--     "state_code":  1,       #反馈结果 1-成功,
--     "message":["第一条信息","第二条信息"], # 数组形式的信息,用于前端弹出消息提示框
--     "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":3,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
-- }
function NewRoleSoulSthView:onSoulEquipSth()
    if self:IsSelectedFive() then
        MsgManager:showSimpMsgWithCallFunc2(UITool.ToLocalization("消耗灵装中包含五星灵装，是否继续"),self,self.SendSthMsg)
    else
        self:SendSthMsg()
    end
end

function NewRoleSoulSthView:SendSthMsg( ... )
    -- body
    if self.curSoulEquipId == nil then
        return
    end
    
    local ids = {}
    local datas = {}
    for i = 1,#self.currentDataSource do 
        local ld = self.currentDataSource[i]
        if ld._isselected then
            table.insert(ids,ld.id)
            table.insert(datas,ld)  --删除用
        end
    end

    if #ids == 0 then 
        GameManagerInst:alert(UITool.ToLocalization("请选择消耗的灵装"))
        return 
    end

    local tempTable = {
        ["rpc"] = "hero_soul_lv_up",
        ["target_id"] = self.CurTargetId,
        ["eat_equips"] = ids,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success

        local isLvUp = data["state_code"] == 1

        --local isLvUp = data["hero_soul"][self.curSoulEquipId]["Lv"] > self.Se_info["hero_soul"][self.curSoulEquipId]["Lv"]

        --self:FillSoulEquipData(data["hero_soul"][self.curSoulEquipId])
        self.IsHadSthMax = data["hero_soul"][self.CurTargetId]["Lv"] >= data["hero_soul"][self.CurTargetId]["Lv_max"] 

        DataManager:dEquipData(datas)
        -- DataManager:wEquipData(data["upgrade"])

        self:playEffect(isLvUp)

        if self.ReLoadCallFunc then
            self.ReLoadCallFunc(self.sDelegate)
        end
        
    end,
    function(state_code,msgText,hehe)
        GameManagerInst:alert(msgText)
    end,
    true)
end

-- -- 返回是否选择消耗的灵装中包含五星装备
function NewRoleSoulSthView:IsSelectedFive()
    for i=1,#self.currentDataSource do
        local ld = self.currentDataSource[i]
        if ld then
            if ld._isselected then
                if ld["equip_rank"] > 4 then
                    return true
                end
            end
        end
        
    end
    return false
end

-- -- 自动选择处理：
-- -- 规则：
function NewRoleSoulSthView:onAutoChoose()
    if self.bCanAutoChoose then
        if self.IsHadSthMax then -- 已达到强化上限
            GameManagerInst:alert(UITool.ToLocalization("已达到等级上限"))
            return
        end
        if self.IsSthMax then
            GameManagerInst:alert(UITool.ToLocalization("本次强化后等级已可达上限，无需继续勾选"))
            return
        end
        --重置已选数据
        for i=1,#self.currentDataSource do
            local ld = self.currentDataSource[i]
            if ld then
                ld._isselected = false
            end
        end

        local TargetDs = {}
        local sortDs = table.deepcopy(self.currentDataSource)

        local count = #sortDs
        for i=count,1,-1 do
            if sortDs[i] then
                if sortDs[i]["equip_rank"] > 4 then
                    table.remove(sortDs,i)
                else
                    if sortDs[i]["Lv"] > 1 then
                        table.remove(sortDs,i)
                    end
                end
            end
        end

        if #sortDs == 0 then
            GameManagerInst:alert(UITool.ToLocalization("没有低星级素材可用"))
        end

        local function AutoMatSort(a,b)
            if a["equip_rank"] == b["equip_rank"] then 
                return a["Lv"] < b["Lv"]
            else
                return a["equip_rank"] < b["equip_rank"]
            end
        end
        
        table.sort(sortDs, AutoMatSort)

        local AllSkillExp = 0
        local bNeedBreak = false

        local num = 20
        for i=1,#sortDs do
            local sd = sortDs[i]
            for m=1,#self.currentDataSource do
                if not bNeedBreak then
                    local ld = self.currentDataSource[m]
                    if sd.id == ld.id then
                        if num > 0 then
                            ld._isselected = true
                            num = num - 1
                            local eqId = tonumber(getNumID(ld.id))
                            if equip[eqId] then
                                AllSkillExp = AllSkillExp + equip[eqId].hero_soul_exp
                                self.lvupView:setAddExp(AllSkillExp)
                                local flv,ismax = self.lvupView:getFinalLevel()
                                if ismax then
                                    bNeedBreak = true
                                end
                            end
                        else
                            ld._isselected = false
                        end
                    end
                end
            end
        end
    else
        --重置已选数据
        if self.currentDataSource then
            for i=1,#self.currentDataSource do
                local ld = self.currentDataSource[i]
                if ld then
                    ld._isselected = false
                end
            end
        end
    end
    self.gridview:refresh()

    --计算升级 
    self:computExp()
    --
    self:refreshStates()
end

function NewRoleSoulSthView:ReLoadData()
    local rankVaules = table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = self.nSelectTitleNum,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        DataManager:rfsElist()       
        --DataManager:wAllBagData({mat = data["mat"]})

        --self.equipListView:setDataSource(equip_list)
        self.dataLoaded = true
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function NewRoleSoulSthView:getDataSrouce()
    local ds = {}

    if g_channel_control.b_newEqBag then
        for i = 1,#equip_list do
            if (not equip_list[i]["is_lock"]) then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end

        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        for i = 1,#equip_list do
            if (equip_list[i]["owner"] == "0") 
                and (not equip_list[i]["is_lock"]) then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end

        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end

    return ds
end

function NewRoleSoulSthView:IsHadSelected()
    for i=1,#self.currentDataSource do
        local ld = self.currentDataSource[i]
        if ld then
            if ld._isselected then
                return true
            end
        end
        
    end
    return false
end

function NewRoleSoulSthView:refresh()
    if not self.Se_info then
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end

    if self.Se_info["state"] == 0 then
        return
    end

    local data = self.Se_info
    if data["break_count"] >= hero_soul[self.curSoulEquipId]["soul_break"]["total_break"] then
        --满升华
        if data["Lv"] >= data["Lv_max"] then
            --满升华满突破
            self:refreshMax()
            self.btnAutoChoose:setTouchEnabled(false)
            self.btnAutoChoose:setBright(false)
            self.spSubMax:setVisible(true)
            self.panelProp:setVisible(false)
            return
        else
            --未满突破
            self.btnAutoChoose:setTouchEnabled(true)
            self.btnAutoChoose:setBright(true)
            self.spSubMax:setVisible(false)
            self.panelProp:setVisible(true)
        end
    end

    self.IsHadSthMax = data["Lv"] >= data["Lv_max"]

    self.currentDataSource = self:getDataSrouce()
    self.gridview:setDataSource(self.currentDataSource)
    self:refreshStates()
    self:computExp()
    
end

function NewRoleSoulSthView:returnBack()
    if self.hideCallFunc then
        self.hideCallFunc(self.sDelegate)
    end
    -- if self.ReLoadCallFunc then
    --     self.ReLoadCallFunc(self.sDelegate)
    -- end
end


