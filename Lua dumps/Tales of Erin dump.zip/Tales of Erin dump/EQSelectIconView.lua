--require "XUIView"

EQSelectIconView = class("EQSelectIconView", XUIView)

EQSelectIconView.CS_FILE_NAME = "EQSelectIconView.csb"
EQSelectIconView.CS_BIND_TABLE = 
{
    panelNoFace = "/i:1770/i:1765",
    panelIcon = "/i:1770/i:1776",
    panelName = "/i:1770/i:1767",
    lbName = "/i:1770/i:1767/i:1769",
    imgFace = "/i:1770/i:1776/i:1779",
    imgRarity = "/i:1770/i:1776/i:1778",
    imgBG = "/i:1770/i:1776/i:1780",
    imgElement = "/i:1770/i:1776/i:1777",
    panelTouch = "/i:1770/i:252",
}

function EQSelectIconView:init(...)
    EQSelectIconView.super.init(self,...)

    self.BtnSelectClick = nil

    self.panelTouch:addTouchEventListener(function (sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.BtnSelectClick then
                self.BtnSelectClick()
            end
        end
    end)

    self:showNoIcon()

    return self
end

function EQSelectIconView:showNoIcon()
    self.panelName:setVisible(false)
    self.panelIcon:setVisible(false)
    self.panelNoFace:setVisible(true)
end

function EQSelectIconView:showEquip(eid,rarity,element)
    if not eid then
        self:showNoIcon()
        return
    end
    
    self.panelName:setVisible(true)
    self.panelIcon:setVisible(true)
    self.panelNoFace:setVisible(false)

    if not rarity then
        rarity = equip[eid].equip_rank
    end

    if not element then
        element = equip[eid].equip_atb
    end
                
    local frame = Rarity_Icon[rarity]  --外框
    if frame then
        self.imgRarity:setTexture(frame)
    end

    local rbg = Rarity_E_BG[rarity]   --背景
    if rbg then
        self.imgBG:setTexture(rbg)
    end

    local element = ATB_Icon[element] --属性球
    if element then
        self.imgElement:setTexture(element)
    end

    local face = equip[eid].equip_list_icon    
    if face then
        self.imgFace:setTexture(face)
    end

    self.lbName:setString(UITool.getUserLanguage(equip[eid].equip_name)  )
end

