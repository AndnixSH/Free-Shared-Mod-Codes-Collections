SDKManagerLua = {} 

SDKManagerLua.inited = false
SDKManagerLua.paymentEvent = nil
SDKManagerLua.accountEvent = nil
SDKManagerLua.ReLoginState = 0
SDKManagerLua.loginStr = nil

--dataeye需要数据
SDKPayData = {}
SDKPayData.orderId = ""
SDKPayData.price = 0



--sdk的登陆状体
ESdkLoginState = {
    login = "login",
    loginOut = "loginOut"
}

function SDKManagerLua:init()
    if self.inited then return end
    -- if SDKManagerLua.sLoginState == nil then
    --     SDKManagerLua.sLoginState = ESdkLoginState.loginOut;
    -- end
    -- print("SDKManagerLua:init sLoginState"..tostring(SDKManagerLua.sLoginState));
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if cc.PLATFORM_OS_ANDROID == targetPlatform then

        require_ex("src/sdk/init.lua")

    else 
        SDKManager:getInstance():StartUP()
        SDKManager:getInstance():setAccountEventListener(function(...)
            self:onAccount(...)
        end)
        SDKManager:getInstance():setPaymentEventListener(function(...)
            self:onPayment(...)
        end)        
    end 
    self.inited = true
end

--公告
function SDKManagerLua:showNotice()
    dump(parm,"SDKManagerLua:showNotice111")
    function closeNoticeBack(parm)
        dump(parm,"SDKManagerLua:showNotice")
    end
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        zc.showNotice(closeNoticeBack)
    else 
        --todo
        --ios notice
    end
end

--登录、登出 回调
function SDKManagerLua:goReturnLogin(param)
    if param == "loginFail" then        --登录失败
        SDKManagerLua:showLogin()
    elseif param == "loginOut" then     --注销登录
        UITool.delayTask(0.1,function()
            cc.MyHttpHelper:shareMyHttpHelper():endGame()
            SceneManager:runLoginScene()        
        end)  
    elseif param == "logoutFail" then
        UITool.delayTask(0.1,function()
            SceneManager:showTipLayer(UITool.ToLocalization("logoutFail"))          
        end)   
    elseif param == "loginFail" then
        UITool.delayTask(0.1,function()
            SceneManager:showTipLayer(UITool.ToLocalization("loginFail"))
                    
        end) 
    else   
        --悬浮窗切换账户
        UITool.delayTask(0.1,function()
            SDK_ReLoginState = 1  --设置登录状态，不用重新登录
            SDKManagerLua:reLogin(param)
            cc.MyHttpHelper:shareMyHttpHelper():endGame()
            SceneManager:runLoginScene()    
        end)                     
    end
end

function SDKManagerLua:showLogin()
    --[[---zhangchao begin]]
     if self == nil then
        return
     end
    if SDK_ReLoginState == 1 then
        SDK_ReLoginState = 0
        return
    end  

    print("INFO_TEST:GAME_CHANNEL="..tostring(GAME_CHANNEL))
    local app = cc.Application:getInstance()
    local platform = app:getTargetPlatform()
    if (cc.PLATFORM_OS_IPHONE == platform) or (cc.PLATFORM_OS_IPAD == platform) then
        SDKManager:getInstance():doLogin()
    else   
        zc.setLogout( )
        --渠道登录成功后的回调
        function loginCallBack( param )
            dump(param,"sdk登录成功！")
            local json = require "cjson"
            local _param_ =  param
            if _param_ and _param_ ~= "" then
                local _user_data_ = _param_
                local platform = cc.Application:getInstance():getTargetPlatform()
                local tableStr = {}
                if (cc.PLATFORM_OS_ANDROID == platform) then
                    _user_data_ =  json.decode(_user_data_)
                end
                SDK_LoginData = self:dealLoginData(_user_data_)
            end
        end
        zc.login(loginCallBack)
    end
end

--浮窗内自动切换账号回调
function SDKManagerLua:reLogin(param)
    local json = require "cjson"
    local _param_ =  param
    if _param_ then
        local _user_data_ = _param_
        local platform = cc.Application:getInstance():getTargetPlatform()

        if (cc.PLATFORM_OS_ANDROID == platform) then
            _user_data_ =  json.decode(_user_data_)
        else

        end
        SDK_LoginData = self:dealLoginData(_user_data_)
    end  
end

function SDKManagerLua:dealLoginData(user_data)
    --公告 调用时机,修改为登录成功之后
    local platform = cc.Application:getInstance():getTargetPlatform()
    if (cc.PLATFORM_OS_ANDROID == platform) then
        if self._canShowNotice then 
            self:showNotice() --登陆成功显示公告
            self._canShowNotice = false
        end 
    end

    local loginData = {}
    loginData["platform_id_for_user_login"]      = GAME_CHANNEL
    loginData["userid"]                          = user_data["userid"]
    loginData["timestamp"]                       = user_data["timestamp"]
    loginData["sign"]                            = user_data["sign"]
    return loginData
end

function SDKManagerLua:getLoginStr()
    local str  = nil
    if DEBUG_MODE_LOGIN == 0 then
        local str_1 = cc.UserDefault:getInstance():getStringForKey("login_name")
        local str_2 = cc.UserDefault:getInstance():getStringForKey("login_password")
        str = "{".."\"login_name\":\""..str_1.."\",\"login_password\":\""..str_2.."\"".."}"
    else 
        if not SDK_LoginData then 
            return nil 
        end
        local cjson = require "cjson"
        str = cjson.encode(SDK_LoginData)
    end  
    return str
end

function SDKManagerLua:logout()
    SysDot:eventlogout()
    
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        --todo 判断当前方法是在修复客户端的时候处理吗？是的话，这个需要重新处理，先测试一下吧
        zc.ZCLogout()
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        SDKManager:getInstance():doLogout()
    end
end
function SDKManagerLua:setSDKLoginData(data)
    
    
end
--todo efunsdk pay
--[[    
    efunsdk支付
    String roleId = json.optString("roleId");// 角色id
    String roleName = json.optString("roleName");// 角色名称
    String roleLevel = json.optString("roleLevel");// 角色等级

    String userId = json.optString("efunID");// userid:efun用户id
    String serverCode = json.optString("serverCode");// 服务器code
    String remark = json.optString("remark");// 自定义字符串（选填）
    String efunProductId = json.optString("efunProductId");// 商品ID
    String payStone = json.optString("payStone");//发币数
    String payMoney = json.optString("payMoney");//商品售价]]
--]]

---todo重构，本方法就是处理sdk支付处理结果，返回到游戏逻辑
function SDKManagerLua:callSDKPayBack(resultStr,shopLayerCallBack)
    UITool.delayTask(0,function()  
        if resultStr =="SUCCESS" then 
            SDKManagerLua:paySynchResult(SDKPayData.orderId, shopLayerCallBack)
        elseif resultStr =="CANCEL" then 
            if shopLayerCallBack then 
                shopLayerCallBack("CANCEL")
            end 
        elseif resultStr =="FAIL" then 
            MsgManager:showSimpMsg(UITool.ToLocalization("支付失败"))
            if shopLayerCallBack then 
                shopLayerCallBack("FAIL")
            end 
        else 
            MsgManager:showSimpMsg(UITool.ToLocalization("支付失败"))
            if shopLayerCallBack then 
                shopLayerCallBack("FAIL")
            end 
        end 
    end)
end
--[[
    shopLayerCallBack这个是SDKManagerLua返回到商店layer的回调
]]
function SDKManagerLua:doSDKPay(_payDatas,shopLayerCallBack)
    local _rechargeSuccess = function(reslutStr)
        SDKManagerLua:callSDKPayBack(reslutStr,shopLayerCallBack)
    end
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        zc.pay(_payDatas,_rechargeSuccess)
    else 
        self.lastShopLayerCallBack = shopLayerCallBack
        zc.luaBridgeCall(EfunSDKManager.EFUNSDK_IOS_CLASS,"efunPay",_payDatas)    
    end 
end

---购买商品
function SDKManagerLua:buyItem(product,shopLayerCallBack)
    local function reiceResultCallBack(data)
        print("收到结算结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            shopLayerCallBack("FAIL")
            MsgManager:showSimpMsg(t_data["data"]["warning"])
            return
        end
        SDKPayData.orderId = t_data["data"]["order_id"]
        SDKPayData.price = t_data["data"].price
        SDKPayData.product = product
        SDKPayData.product_id = t_data["data"]["value"]["efun_product_id"]--//efun商品ID
        
        if SDKPayData.orderId == nil or SDKPayData.orderId == ""  then 
            if shopLayerCallBack then 
                shopLayerCallBack("FAIL")
                return
            end
        end   
        local _payData = {}
        _payData["roleId"] = tostring(user_info["id"])
        _payData["roleName"] = tostring(user_info["name"])
        _payData["roleLevel"] = tostring(user_info["level"])
        _payData["serverCode"] = tostring(user_info["server_id"]) --// 服务器code
        _payData["efunId"] = t_data["data"]["value"]["efun_id"]--// userid:efun用户id
        _payData["remark"] = t_data["data"]["value"]["remark"]--自定义字符串（选填）
        _payData["efunProductId"] = t_data["data"]["value"]["efun_product_id"]--//efun商品ID
        _payData["payStone"] = t_data["data"]["value"]["pay_stone"]--//发币数
        _payData["payMoney"] = t_data["data"]["value"]["pay_money"]--//商品售价]]

        self:doSDKPay(_payData, shopLayerCallBack)

        SysDot:eventPuchaseBegin(_payData)

    end
    local cjson             = require "cjson"
    local tempTable         = {}
    tempTable["product_id"] = product["product_id"]
    tempTable["user_id"]    = user_info["id"]
    tempTable["platform"]   = GAME_CHANNEL
    tempTable["rpc"]        = "pay_order_create"

    local mydata            = cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3) 

end

function SDKManagerLua:onAccount(eventType,param1,param2)
    print("onAccount:"..tostring(eventType).."   "..tostring(param1).."    "..tostring(param2))
    if eventType == 1 then  --登录成功
        print("onAccount eventType == 1 ");
        local paramJson =  json.decode(param1)
        local loginData = { 
            userid          = paramJson.efunUserid,
            sign            = paramJson.sign,
            timestamp       = paramJson.timestamp
        }
        SDK_LoginData = self:dealLoginData(loginData)

    elseif eventType == 2 then --登录失败
        print("onAccount eventType == 2 ");
        --SDKManagerLua.sLoginState = ESdkLoginState.loginOut;
        SDK_LoginData = nil
        self:showLogin()
    elseif eventType == 3 then --程序调用登出后的回调
        print("onAccount eventType == 3 ");
        --SDKManagerLua.sLoginState = ESdkLoginState.loginOut;
        SDK_LoginData = nil
        GameManagerInst:alert(UITool.ToLocalization("登出啦"))
    elseif eventType == 4 then --用户中心内点登出后的回调
        print("onAccount eventType == 4 ");
        SDKManagerLua.sLoginState = ESdkLoginState.loginOut;
        -- GameManagerInst:showWaiting() --此时SDKManager还没有，此处会报错
        UITool.delayTask(0.5,function()
            -- GameManagerInst:hideWaiting()
            SDK_LoginData = nil
            if SceneManager.mainScene == nil then 
                self:showLogin()
            else 
                SceneManager:runLoginScene()
            end 
        end)
    end

    --print("onAccount login state = "..tostring(SDKManagerLua.sLoginState))
end

function SDKManagerLua:refreshUserCoin(callback)

    local tempTable = {
        ["rpc"] = "refresh_user_coin"
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --user_info[]
        user_info["gold"] = data.gold
        user_info["gem"] = data.gem
        user_info["gem_r"] = data.gem_r
        user_info["beryl"] = data.beryl
        user_info["faith"] = data.faith
        if SceneManager.menuLayer ~= nil then
            SceneManager.menuLayer:RefshTopBar()
        end
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    false)
end

function SDKManagerLua:onPayment(eventType,message1)    
    -- PAYMENT_UNKNOW = 0,
    -- PAYMENT_START ,
    -- PAYMENT_SUCCESS ,
    -- PAYMENT_FAILED,
    -- PAYMENT_RESTORE,
    -- PAYMENT_INFO
    --MsgManager:showSimpMsg("onPayment eventType : "..tostring(eventType))
    message = UITool.ToLocalization(message1)
    if eventType == 1 then
    elseif eventType == 2 then
        -- zc.paySynchResult(SDKPayData.orderId, self.lastShopLayerCallBack)
        self:refreshUserCoin(function()
            if self.lastShopLayerCallBack then
                self.lastShopLayerCallBack("SUCCESS")
                self.lastShopLayerCallBack = nil
            end
            -- GameManagerInst:alert(message)
        end)
    elseif eventType == 3 then
        if self.lastShopLayerCallBack then
            self.lastShopLayerCallBack("FAILED")
            self.lastShopLayerCallBack = nil
        end
        -- GameManagerInst:alert(message)
    elseif eventType == 4 then
        if self.lastShopLayerCallBack then
            self.lastShopLayerCallBack("RESTORE")
            self.lastShopLayerCallBack = nil
        end
        -- GameManagerInst:alert(message)
    elseif eventType == 5 then --data
        
        local s,e = string.find(message,'_')
        local pid = string.sub(message,1,s - 1)
        local price = string.sub(message,e + 1)
        SDKPayData.orderId = pid
        SDKPayData.price = tonumber(price)
    end

end

--设置玩家数据
function SDKManagerLua:setRoleData(roleData)
    -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    -- if cc.PLATFORM_OS_ANDROID == targetPlatform then 
    --     zc.loginSuccessCallback(roleData)
    -- else 
    --     SDKManager:getInstance():StartPayment()
    -- end 
end

--设置创建新角色
function SDKManagerLua:setCreateRoleData(roleData)

end

----显示用户中心 fromType 1是 游戏内部的用户中心调用  2是 登陆页面的用户中心按钮调用     
----IOS和易接是调出 用户中心  其他渠道是直接登出
function SDKManagerLua:showUserCenter(fromType)
    SDKManagerLua:logout()
    -- fromType = fromType or 1
    -- local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    -- if cc.PLATFORM_OS_ANDROID == targetPlatform then
    --     --点击注销登录
    --     zc.ZCLogout()
    -- else 
    --      SDKManager:getInstance():doLogout()
    -- end 
end

--更新玩家信息
function SDKManagerLua:updateRoleInfo()
    EfunSDKManager:efunRoleLogin()
end

--facebook分享
function SDKManagerLua:callFacebookShare()
    print("enter facebook share....")
    -- local roleId            = user_info["id"] or "1"
    -- local serverId          = "1"
    
    -- local args = {
          
    --         -- 角色id，暂时没用
    --         roleId        = tostring(roleId),
    --          -- 等级
    --         serverId        = tostring(serverId),
           
            
    --     }
    -- local platform = cc.Application:getInstance():getTargetPlatform()
   
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     zc.callFacebookShare(args)
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     -- local className = "LuLuSDKManager"
    --     -- local sigs = "(Ljava/lang/String;)V"
    --     -- zc.luaBridgeCall(className,"callFacebookShare",args,sigs)
    -- end
    
end

--用户中心页面
function SDKManagerLua:callUserCenter()
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- local args = {  }

    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     zc.callUserCenter()
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     -- local className = "LuLuSDKManager"
    --     -- args = {
    --     --     serverId = g_channel_control.serverName,
    --     --     roleId = user_info["uid"] or "1",
    --     -- }
    --     -- local sigs = "()V"
    --     -- zc.luaBridgeCall(className,"callUserCenter",args,sigs)
    -- end
    
end
----------------悬浮窗----------
--创建平台悬浮按钮并显示
function SDKManagerLua:showFloatView()
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     zc.showFloatView()
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --    --todo
    --     -- local className = "LuLuSDKManager"
    --     -- local args = {bShow = bRet}
    --     -- local sigs = "()V"
    --     -- zc.luaBridgeCall(className,"showFloatView",args,sigs)       
    -- end 
end

--平台悬浮按钮隐藏 平台悬浮按钮显示
function SDKManagerLua:setFloatViewState(bRet)
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     zc.setFloatViewState(bRet)
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --    --todo
    --     -- local className = "LuLuSDKManager"
    --     -- local args = {bShow = bRet}
    --     -- local sigs = "()V"
    --     -- zc.luaBridgeCall(className,"showFloatView",args,sigs)       
    -- end 
end
-- 平台悬浮按钮销毁
function SDKManagerLua:destoryFloatView()
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     --在onDestroy()方法中或者退出游戏的时候调用，本游戏在onDestroy中处理
    --     zc.destoryFloatView()
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --    --todo
    --     -- local className = "LuLuSDKManager"
    --     -- local args = {bShow = bRet}
    --     -- local sigs = "()V"
    --     -- zc.luaBridgeCall(className,"showFloatView",args,sigs)       
    -- end 
end

--获取分包的ID
function SDKManagerLua:getChannelId()
    -- local ok = false
    -- local ret = ""
    -- local tempRet = ""
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     ok,tempRet  = zc.getChannelId()
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     -- local className = "LuLuSDKManager"
    --     -- local args = {}
    --     -- local sigs = "()V"
    --     -- ok,tempRet = zc.luaBridgeCall(className,"getChannelId",args,sigs)            
    -- end

    -- if ok then
    --     ret = tempRet;
    -- end
    -- return ret;
    
end

--获取设备号
function SDKManagerLua:getDeviceId()
    -- local ok = false
    -- local ret = ""
    -- local tempRet = ""
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     local args = { }
    --     local sigs = "()Ljava/lang/String;"
    --     ok,tempRet = zc.luaBridgeCall(LUA_BRIDGE_CLASS,"getDeviceId",args,sigs)

    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     -- local className = "LuLuSDKManager"
    --     -- local args = {}
    --     -- local sigs = "()V"
    --     -- ok,tempRet = zc.luaBridgeCall(className,"getDeviceId",args,sigs)           
    -- end
    -- if ok then
    --     ret = tempRet;
    -- end
    -- return ret;
    
end


--获取是否初始化
function SDKManagerLua:hasInit()
    local ok = false
    local ret = false
    local tempRet = false
    local platform = cc.Application:getInstance():getTargetPlatform()
    
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = { }
        local sigs = "()Z"
        ok,tempRet = zc.luaBridgeCall(LUA_BRIDGE_CLASS,"getInitResult",args,sigs)

    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        ret = true    
    end
    if ok then
        ret = tempRet;
    end
    return ret;
    
end

--获取sdk userid
--todo如果使用客服，需将self.loginStr重新处理
function SDKManagerLua:getSdkUserId()
    local userId = "1"
    if self.loginStr and self.loginStr.userId then
        userId = self.loginStr.userId
    end
    return userId;
end

--sdk是否登陆
function SDKManagerLua:isSdkLogin()
    local ok = false
    local ret = false
    local tempRet = false
    local platform = cc.Application:getInstance():getTargetPlatform()
    
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = { }
        local sigs = "()Z"
        ok,tempRet = zc.luaBridgeCall(LUA_BRIDGE_CLASS,"isLogin",args,sigs)

    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        ret = SDKManager:getInstance():isLogin();
    end
    if ok then
        ret = tempRet;
    end
    return ret;
    
end

---支付成功 刷新数据
--加钱成功结束，20次之后还没有成功，
--把错误订单号保存，然后联系客服
function SDKManagerLua:paySynchResult(order_id, shopLayerCallBack)
    local reqNum = 0
    local function saveErrorPay(order_id)
        -- body
        local path = cc.FileUtils:getInstance():getWritablePath()
        path = path.."error_remain/"
        if not cc.FileUtils:getInstance():isDirectoryExist(path) then
            cc.FileUtils:getInstance():createDirectory(path)
        end

        local content = "日期: "..os.date("%Y-%m-%d-%H:%M:%S").."  订单号: "..order_id.."\n"
        local logfile = "error_remain.txt"

        local file = io.open(path..logfile,"a+")
        file:write(content)
        file:close()
    end
    local function reqPaySdk()
        local function reicePointCallBack(data)
            data = tolua.cast(data, "PassData");
            print("callBack-----"..data:getData())
            local cjsonSafe = require "cjson.safe"
            local t_data = cjsonSafe.decode(data:getData())
            if t_data == nil then
                MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服")) 
                return
            end 
            if  t_data["data"]["state_code"] ~=1 then
                if shopLayerCallBack then 
                    shopLayerCallBack("FAIL")
                end 
                MsgManager:showSimpMsg(t_data["data"]["warning"])
                return
            end
            reqNum = reqNum + 1
            --同步成功
            if t_data["data"]["synchro_result"] == 1 then
                user_info["gold"] = t_data["data"].gold
                user_info["gem"] = t_data["data"].gem
                user_info["gem_r"] = t_data["data"].gem_r
                user_info["beryl"] = t_data["data"].beryl
                user_info["faith"] = t_data["data"].faith
                SceneManager.menuLayer:RefshTopBar()
                if shopLayerCallBack then
                    MsgManager:showSimpMsg(UITool.ToLocalization("购买成功"))
                    shopLayerCallBack("SUCCESS")
                end 
            else    
                --如果小于20次，重新请求
                if reqNum < 10 then 
                    UITool.delayTask(2.0,function()  
                        reqPaySdk()
                    end) 
                else 
                    saveErrorPay(order_id)
                    --todo 多语言处理
                    local str = UITool.ToLocalization("购买失败，请联系客服，订单号：\n") ..order_id
                    if  CHANNEL.Android.CHANNEL_CODE_UC == GAME_CHANNEL then 
                        str = UITool.ToLocalization("购买结果未知，若有异常，请联系客服，订单号：\n") ..order_id
                    end 
                    MsgManager:showSimpMsg(str)
                    if shopLayerCallBack then 
                        shopLayerCallBack("FAIL")
                    end 
                end 
            end  
        end

        local cjson = require "cjson"

        local tempTable = {
            ["rpc"] = "pay_order_check",
            ["order_id"] = order_id,
        }
        local mydata =  cjson.encode(tempTable)
        print("测试 mydata = "..mydata)

        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
        ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
        dbhttp:creatHttpRequestWithURL(mydata,3)
    end

    UITool.delayTask(2.0,function()  
        reqPaySdk()
    end) 
end

--sdk 在清理客户端的时候的处理
function SDKManagerLua:sdkHandleRepairClient()
   
    local platform = cc.Application:getInstance():getTargetPlatform()
    
    if platform == cc.PLATFORM_OS_ANDROID then
       

    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        SDKManagerLua:logout();
    end
   
    
end
    

