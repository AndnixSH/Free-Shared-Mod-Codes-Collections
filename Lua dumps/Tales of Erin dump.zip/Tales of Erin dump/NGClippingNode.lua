--NGClippingNode.lua
--新手引导高亮
--todo
NGClippingNode = class("NGClippingNode",function()
    return cc.Node:create()
end)
function NGClippingNode:ctor(data)
    -- body
    self:init(data)
end
function NGClippingNode:init(data)
    self.clipNode = cc.ClippingNode:create()
    self:addChild(self.clipNode, 0)
    self.data = data 
    self.data.isEnd = self.data.isEnd or 0 --
    local size = cc.Director:getInstance():getWinSize()

    local getSprite = function(texture,position)
        local sprite = cc.Sprite:create(texture)
        if sprite == nil then
            sprite = cc.Sprite:createWithSpriteFrameName(texture)
        end
        assert(not tolua.isnull(sprite),string.format("初始化精灵失败，加载的资源文件为%s",texture))
        sprite:setPosition(position.x,position.y)
        return sprite
    end
    --模板
    local rootPos = ScreenManager:getInstance():getRootPoint();
    local posX = data.btn.pos_X 
    local posY = data.btn.pos_Y 
    local stencilPosX = posX + rootPos.x
    local stencilPosY = posY + rootPos.y
    local stencilPosition = cc.p(stencilPosX, stencilPosY)

    local stencil = getSprite(data.clipping, stencilPosition)
    stencil:setScaleX(data.btn.scale_X)
    stencil:setScaleY(data.btn.scale_Y)
    stencil:setRotation(data.btn.rotation)
    self.stencil = stencil
    --蒙灰 %40
    --背景图层  ---》改为透明
   -- local layer = cc.LayerColor:create(cc.c4b(0,0,0,255*0.4),size.width,size.height)
    local layer = cc.LayerColor:create(cc.c4b(0,0,0,0),size.width,size.height)
    self.clipNode:setInverted(true)
    self.clipNode:setAlphaThreshold(0.5)
    self.clipNode:setStencil(stencil)
    self.clipNode:addChild(layer)

    --用于修正箭头坐标 
    self.data.arrow.pos_X = self.data.arrow.pos_X or 0 
    self.data.arrow.pos_Y = self.data.arrow.pos_Y or 0
    --箭头和阵法是不是显示 默认为1（显示）
    self.data.arrow.arrowVisible = self.data.arrow.arrowVisible or 1

    local effectPosition = cc.p(posX+self.data.arrow.pos_X, posY+self.data.arrow.pos_Y)

    -- --箭头
    self.tip = self:guideSprite()
    self:addChild(self.tip)
    --阵法
    local node = cc.CSLoader:createNode("NewGuideEffect_1.csb")
    node:setPosition(effectPosition)
    self:addChild(node,10)
    self.sprite = node
    self.tip:setVisible(false)
    self.sprite:setVisible(false)

    if self.data.bubble ~= nil then 
        self:addBubble()
    end 
end

function NGClippingNode:addBubble()
    --阵法s
    local node = cc.CSLoader:createNode("GuideBubblesView.csb")
    node:setPosition(self.data.bubble.pos_X, self.data.bubble.pos_Y)
    local leftNode = node:getChildByTag(1)
    local rightNode = node:getChildByTag(2)
    local showNode
    if self.data.bubble.dir == 1 then 
        rightNode:setVisible(false)
        showNode = leftNode
    else 
        leftNode:setVisible(false)
        showNode = rightNode
    end 
    local text = showNode:getChildByTag(102)
    text:setString(UITool.getUserLanguage(self.data.bubble.text))
    self:addChild(node,11)
end

--添加提示标志 箭头
function NGClippingNode:guideSprite()
    local posX = self.stencil:getPositionX()
    local posY = self.stencil:getPositionY()
    local size = self.stencil:getContentSize()
    local guideX = nil 
    local guideY = nil 
    local rot = 0
    --
    --local guide = cc.CSLoader:createNode("NewGuideEffect_2.csb")

    local guide = sp.SkeletonAnimation:create("effects/jiantou/jiantou.json", "effects/jiantou/jiantou.atlas", 1.0)

    local guideSize = cc.size(160, 60)
    local adjustValue = 20
    if self.data.arrow.pos == 1 then       --上
        guideX = posX 
        if self.data.btn.rotation == 0 then
            guideY = posY + size.height/2 *  self.data.btn.scale_Y -adjustValue + guideSize.width/2
        else 
            guideY = posY + size.width/2 * self.data.btn.scale_X  - adjustValue + guideSize.width/2
        end 
        rot = 90
    elseif self.data.arrow.pos ==2 then   --下
        guideX = posX 
        if self.data.btn.rotation == 0 then
            guideY = posY - size.height/2 *  self.data.btn.scale_Y +adjustValue - guideSize.width/2
        else 
            guideY = posY - size.width/2 * self.data.btn.scale_X  +adjustValue - guideSize.width/2
        end 
        rot = - 90
    elseif self.data.arrow.pos == 3 then   --左
        if self.data.btn.rotation == 0 then
            guideX = posX - size.width/2* self.data.btn.scale_X  +adjustValue - guideSize.width/2
        else
            guideX = posX - size.height/2* self.data.btn.scale_Y  +adjustValue - guideSize.width/2
        end 
        guideY = posY
        rot = 0
    elseif self.data.arrow.pos == 4 then  --右
        if self.data.btn.rotation == 0 then
            guideX = posX + size.width/2 * self.data.btn.scale_X  - adjustValue + guideSize.width/2
        else 
            guideX = posX + size.height/2 * self.data.btn.scale_Y  -adjustValue + guideSize.width/2
        end
        guideY = posY
        rot = 180
    end 
    local a_X = self.data.arrow.a_X or 0
    local a_Y = self.data.arrow.a_Y or 0
    local rootPos = ScreenManager:getInstance():getRootPoint();
    guide:setPosition(guideX+ self.data.arrow.pos_X - rootPos.x + a_X, guideY+ self.data.arrow.pos_Y - rootPos.y +a_Y)
    guide:setRotation(rot)

    return guide
end

function NGClippingNode:setStencilVisible(isVisible)
    if self.data.isEnd == 1 then 
        isVisible = false
    end 
    if isVisible and self.data.arrow.arrowVisible == 1 then 

        self.tip:stopAllActions()
        self.tip:setAnimation(1, "effect", true)
    
        local function deimeFunc()
            self:runZhenFaAction()
        end
        local delay    = CCDelayTime:create(0.2)
        local callfunc = CCCallFunc:create(deimeFunc)
        local sequence = cc.Sequence:create(delay, callfunc)
        self.sprite:runAction(sequence)
        
    end 
    self.stencil:setVisible(isVisible)
    self.sprite:setVisible(isVisible) --阵法
    self.tip:setVisible(isVisible)    --箭头
end

function NGClippingNode:runZhenFaAction()
    local function showCallBack() 
        local function deimeFunc()
            self:runZhenFaAction()
        end
        local delay    = CCDelayTime:create(3.0)
        local callfunc = CCCallFunc:create(deimeFunc)
        local sequence = cc.Sequence:create(delay, callfunc)
        self.sprite:runAction(sequence)
    end
    local actionZhenFa = cc.CSLoader:createTimeline("NewGuideEffect_1.csb")
    actionZhenFa:setLastFrameCallFunc(showCallBack)
    self.sprite:stopAllActions()
    self.sprite:runAction(actionZhenFa)
    actionZhenFa:play("play", false)  
end

function NGClippingNode:isStencilVisible()
    return self.stencil:isVisible()
end

function NGClippingNode:mClear()
    self.tip:stopAllActions()
    self.tip:removeFromParent(true)
    self.tip = nil 
    self.sprite:stopAllActions()
    self.sprite:removeFromParent(true)
    self.sprite = nil 
end

function NGClippingNode:getStencilRect()
	local pointX=self.stencil:getPositionX()
    local pointY=self.stencil:getPositionY()
    local size=self.stencil:getBoundingBox()
    return cc.rect(pointX-size.width/2,pointY-size.height/2,size.width,size.height)
end

function NGClippingNode:create(data)
    local clip = NGClippingNode.new(data)
    return clip
end
