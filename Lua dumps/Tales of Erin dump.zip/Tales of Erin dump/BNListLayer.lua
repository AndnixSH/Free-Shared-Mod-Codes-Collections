
require "BasicLayer"

BNListLayer = class("BNListLayer",BasicLayer)
BNListLayer.__index = BNListLayer
BNListLayer.lClass = 3

function BNListLayer:init()
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.exploreData = self.rData["rcvData"]["data"]

    local node = cc.CSLoader:createNode("BNList.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    self._rootCSbNode = node:getChildByTag(101) 
    --关闭
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack(false)
        end
    end
    self._rootCSbNode:addTouchEventListener(touchCallBack)
    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")
    self:initListView()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack(false)
    end)
    
    --请求列表数据
    self:requireListInfo()

end

function BNListLayer:initListView()
   	local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 173,215)
    self.gridview.itemCreateEvent = function()
        local temp = BNListItem.new():init()
        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end
        temp.resetDataEvent = function(item)
 			--self:onItemShow(temp)
        end
        return temp
    end
end

--刷新板娘列表
function BNListLayer:refreshListUI()
    self.gridview:setDataSource(self.bn_list)
end

--点击列表中的板娘
function BNListLayer:onItemClicked(item)
    --GameManagerInst:alert("onItemClicked"..item._data)
    if user_info["signboard"]~= item._data then 
    	self:requireChangeBN(item._data)
    end 
end

function BNListLayer:requireListInfo()
    local function ReqSuccess(data)
		dump(data)
		self.bn_list = data.list
        -- local fillData = {1,2,3,4,1011,1013,1023,1024,1036,1037,1051,1061,1062,1076,1101,1103,1116,1117,1142,1156,1157,1181,1182,1183,1184,1196,1305,1354,1356,1357,1359,1360,1361,1362,1363,1364,1367,1369,1370,1373,1374,1375,1376,1379,1380,1381,1384,1390,1387,1378,1386,1385,1389,1383,1382,1391,1366,1388,1451,1404,1405,1397,1408,1407,1409,1412,1403,1411,1413,1353,1377,1414}--TODO:需更新数据为真实数据
        -- self.bn_list = fillData
        --self.bn_list = data.list
		self:refreshListUI()
    end
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg("获取数据异常，请联系客服")
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "signboard_list",
    }
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--更换板娘接口
function BNListLayer:requireChangeBN(select_id)
    local function ReqSuccess(data)
		--返回 写入内存
		user_info["signboard"] = select_id
		self:returnBack(true)
    end
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg("获取数据异常，请联系客服")
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            --MsgManager:showSimpMsg(t_data["data"]["warning"])
            user_info["signboard"] = select_id
            self:returnBack(true)
            return
        end
        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "signboard_change",
        ["id"] = select_id
    }
    local mydata =  cjson.encode(tempTable)
    print("ssssssssssss")
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--返回
function BNListLayer:returnBack(isBackRefsh)
    --如果是派遣返回。舒刷新
    if isBackRefsh then 
        self.backFunc(self.sDelegate)
    end 
    self.exist = false
    self:clearEx()
end

function BNListLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function BNListLayer:create(rData)
     local layer = BNListLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end