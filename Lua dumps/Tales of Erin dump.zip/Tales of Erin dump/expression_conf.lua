-- 聊天表情配置

expression_conf = {}

expression_conf[1] = {
    name = "136009",
    index = 1,
    data = {
        {
            id = 1,
            expression_name = "135987",
            expression_path = "zdlt_bq_001.png",
            code = "",
            index = 1
        },
        {
            id = 1,
            expression_name = "135988",
            expression_path = "zdlt_bq_002.png",
            code = "",
            index = 2
        },
        {
            id = 1,
            expression_name = "135989",
            expression_path = "zdlt_bq_003.png",
            code = "",
            index = 3
        },
        {
            id = 1,
            expression_name = "135990",
            expression_path = "zdlt_bq_004.png",
            code = "",
            index = 4
        },
        {
            id = 1,
            expression_name = "135991",
            expression_path = "zdlt_bq_005.png",
            code = "",
            index = 5
        },
        {
            id = 1,
            expression_name = "135992",
            expression_path = "zdlt_bq_006.png",
            code = "",
            index = 6
        },
        {
            id = 1,
            expression_name = "135993",
            expression_path = "zdlt_bq_007.png",
            code = "",
            index = 7
        },
        {
            id = 1,
            expression_name = "135994",
            expression_path = "zdlt_bq_008.png",
            code = "",
            index = 8
        },
        {
            id = 1,
            expression_name = "135995",
            expression_path = "zdlt_bq_009.png",
            code = "",
            index = 9
        },
        {
            id = 1,
            expression_name = "135996",
            expression_path = "zdlt_bq_010.png",
            code = "",
            index = 10
        },
        {
            id = 1,
            expression_name = "135997",
            expression_path = "zdlt_bq_011.png",
            code = "",
            index = 11
        },
        {
            id = 1,
            expression_name = "135998",
            expression_path = "zdlt_bq_012.png",
            code = "",
            index = 12
        },
        {
            id = 1,
            expression_name = "135999",
            expression_path = "zdlt_bq_013.png",
            code = "",
            index = 13
        },
        {
            id = 1,
            expression_name = "136000",
            expression_path = "zdlt_bq_014.png",
            code = "",
            index = 14
        },
        {
            id = 1,
            expression_name = "136001",
            expression_path = "zdlt_bq_015.png",
            code = "",
            index = 15
        },
        {
            id = 1,
            expression_name = "136002",
            expression_path = "zdlt_bq_016.png",
            code = "",
            index = 16
        },
        {
            id = 1,
            expression_name = "136003",
            expression_path = "zdlt_bq_017.png",
            code = "",
            index = 17
        },
        {
            id = 1,
            expression_name = "136004",
            expression_path = "zdlt_bq_018.png",
            code = "",
            index = 18
        },
        {
            id = 1,
            expression_name = "136005",
            expression_path = "zdlt_bq_019.png",
            code = "",
            index = 19
        },
        {
            id = 1,
            expression_name = "136006",
            expression_path = "zdlt_bq_020.png",
            code = "",
            index = 20
        },
        {
            id = 1,
            expression_name = "136007",
            expression_path = "zdlt_bq_021.png",
            code = "",
            index = 21
        },
        {
            id = 1,
            expression_name = "136008",
            expression_path = "zdlt_bq_022.png",
            code = "",
            index = 22
        },
    }
}