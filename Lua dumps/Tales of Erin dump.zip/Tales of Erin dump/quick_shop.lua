
-- 星盘关卡 特殊体力购买
-- 道具类型 | 道具ID | ...
quick_shop = {}

quick_shop[102] = {  -- 道具类型
    [0] = {  -- 道具ID
        {
            goods_type = 102,
            goods_id = 0,
            cost_type = 2,
            cost_id = 0,
            trade_id = 1  -- 星光之尘
        },
    },
}