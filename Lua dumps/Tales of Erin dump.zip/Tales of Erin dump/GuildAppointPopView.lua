--[[
	公会成员任命弹窗
	GuildAppointPopView.lua
	self.rData

     "position": 6,          # 自己处职位,1-6(6最高,会长) 
     "name": u"杀阡陌",       # 玩家名
     "rank": 5,                  # 玩家等级
     "exp": 45,                  # 玩家当前经验
     "exp_max": 4500,            # 玩家升到下级所需经验
     "explore_lv":19,#当前的探索等级
     "explore_exp":1999,#当前的探索经验
     "explore_max_exp":2999,#等前升级所需的探索经验
     "signature":"我来自苍蓝境界,请多关照!",#玩家签名，默认是这个 可为空    

]]
require "BasicLayer"
GuildAppointPopView = class("GuildAppointPopView",BasicLayer)
GuildAppointPopView.__index = GuildAppointPopView
GuildAppointPopView.lClass  = 3 

function GuildAppointPopView:init()
	self.selectIndex = self.rData.info.position --默认选中的职务
	dump(self.rData.info)
    local node =cc.CSLoader:createNode("GuildAppointView.csb")
    self.uiLayer:addChild(node,0,2)
    self._rootCSbNode = node:getChildByTag(102) 
    --名字
 	local nameLab = ccui.Helper:seekWidgetByName(self._rootCSbNode, "name")
 	nameLab:setString(self.rData.info.name)
 	--当前等级
 	local img_level = ccui.Helper:seekWidgetByName(self._rootCSbNode, "img_level")
 	img_level:setUnifySizeEnabled(false)
    img_level:loadTexture(GUILD_MEMBER_RANK_ICON[self.selectIndex])

    local function CallBak( sender,eventType )
        -- body
       if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Button_confirm" then
                self:callCanfirm()
            elseif sender:getName() == "Button_cancle" then
                self:returnBack()
            end
       end
    end 
    local butConfirm = ccui.Helper:seekWidgetByName(self._rootCSbNode, "Button_confirm")
    local butCancle = ccui.Helper:seekWidgetByName(self._rootCSbNode, "Button_cancle")
    butConfirm:addTouchEventListener(CallBak)
    butCancle:addTouchEventListener(CallBak)

    self:initBtn()
    self:selectPos(self.selectIndex)
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

end

function  GuildAppointPopView:initBtn()
	 --标签切换
    local function touchLabelBtnBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:selectPos(sender.myTag)
        end
    end
    for i=1,3 do
    	local btn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Btn_l_"..i)
    	btn.myTag = i --注：不用setTag 是为了防止tag值混乱
    	btn:addTouchEventListener(touchLabelBtnBack)
    end
end
function GuildAppointPopView:selectPos(index)
	index = tonumber(index)
    self.selectIndex = index
    local function setBtnStatue(btn,statue)
		btn:setTouchEnabled(statue)
        btn:setBright(statue)
	end
	for i=1,3 do
		local btn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Btn_l_"..i)
		if i~=index then
			setBtnStatue(btn,true)
		else
			setBtnStatue(btn,false)
		end 
	end
end

function GuildAppointPopView:returnBack()
    self:clearEx()
end

function GuildAppointPopView:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function GuildAppointPopView:callCanfirm()
    if self.selectIndex == 3 then 
        --弹出确认窗
        local posName = {UITool.ToLocalization("会员"),UITool.ToLocalization("副会长"),UITool.ToLocalization("会长")}
        local msg = string.format(UITool.ToLocalization("%s 升为会长，您变成%s,可以吗"),self.rData.info.name, posName[self.rData.info.position])
        MsgManager:showSimpMsgWithCallFunc(msg,self,self.callCanfirmBack)
    else 
        self:callCanfirmBack()
    end 
end

function GuildAppointPopView:callCanfirmBack()
    if self.rData.callFunc then
        self.rData.callFunc(self.rData.sDelegate, self.selectIndex)
    end
    self:returnBack()
end

function GuildAppointPopView:create(tdata)
     local msgModel = GuildAppointPopView.new()
	 msgModel.rData = tdata 
	 msgModel.sManager  = tdata.sManager
     msgModel.uiLayer = cc.Layer:create()
     msgModel:init()
     return msgModel
end
