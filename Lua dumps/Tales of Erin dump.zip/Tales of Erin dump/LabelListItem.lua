
LabelListItem = class("LabelListItem", XUICellView)
LabelListItem.CS_FILE_NAME = "LabelListItem.csb"
LabelListItem.CS_BIND_TABLE = 
{
    lbTitle = "/i:11",
}

function LabelListItem:init(...)
    LabelListItem.super.init(self,...)
    return self
end

function LabelListItem:SetLabelStr(str)
    if self.lbTitle then
        self.lbTitle:setString(str)
    end
end

function LabelListItem:onResetData()
    if not self._data then return end
    self:SetLabelStr(self._data)
end

function LabelListItem:getItemWidth()
    if self.lbTitle then
        local psize = self.lbTitle:getContentSize()
        return psize.width
    else
        return 0
    end
end

function LabelListItem:getItemHeight()
    if self.lbTitle then
        local psize = self.lbTitle:getContentSize()
        return psize.height
    else
        return 0
    end
end
