LabelDataModel = {}
--个人信息界面列表数据模型
function LabelDataModel:getPersonalInfoDataModel( ... )
    local data_list = {}

    data_list["list_data1"] = {
        {
            {label = "昵称"},{label = "高大威猛"},
            {label = "UID"},{label = "353"}
        },
        {
            {label = "展示称号"},{label = "高大威猛"},
            {label = "冒险等级"},{label = "99"}
        },
        {
            {label = "称号收集度"},{label = "3435"},
            {label = "角色收集度"},{label = "993"}
        }
    }
    data_list["list_data2"] = {
        {
            {label = "所属公会"},{label = "rqwq"},
            {label = "公会排名"},{label = "32"}
        },
        {
            {label = "全服编队排名"},{label = "3435"},
            {label = "区域编队排名"},{label = "993"}
        },
        {
            {label = "玩家总战力"},{label = "3435"},
            {label = "最高编队总战力"},{label = "993"}
        }
    }
    return data_list
end

--系统设置界面列表数据模型
function LabelDataModel:getSysSettingDataModel( ... )
    local data_list = {
        {
            {label = "昵称"},{label = "高大威猛"},{label = "btn_change"}
        },
        {
            {label = "展示称号"},{label = "高大威猛"},{label = "btn_change"}
        },
        {
            {label = "看板娘"},{label = "3435"},{label = "btn_change"}
        },
        {
            {label = "图鉴板娘"},{label = "3435"},{label = "btn_change"}
        },
        {
            {label = "头像"},{label = "3435"},{label = "btn_change"}
        }
    }
    return data_list
end

function LabelDataModel:getLabelCount( data )
    local count = 0
    local label_data = data
    local label_keys = table.keys(label_data)
    local label_count = #label_keys
    for i=1,label_count do
        local item_data = label_data[i]
        local item_keys = table.keys(item_data)
        local item_count = #item_keys
        for j=1,item_count do
            count = count + 1
        end
    end
    return count
end
