achi_act_147_conf={} 
achi_act_147_conf[1] = {
        id= 1,
        achi_name= "Create Trial",
        achi_desc= "Create and complete Deposed God Assault 1 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[2] = {
        id= 2,
        achi_name= "Infinite Trial 1",
        achi_desc= "Win 1 times in Deposed God Assault",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[3] = {
        id= 3,
        achi_name= "Infinite Trial 2",
        achi_desc= "Win 5 times in Deposed God Assault",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[4] = {
        id= 4,
        achi_name= "Infinite Trial 3",
        achi_desc= "Win 15 times in Deposed God Assault",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[5] = {
        id= 5,
        achi_name= "Infinite Trial 4",
        achi_desc= "Win 30 times in Deposed God Assault",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[6] = {
        id= 6,
        achi_name= "God Betrayal 1",
        achi_desc= "Complete Deposed God Assault -  50 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[7] = {
        id= 7,
        achi_name= "God Betrayal 2",
        achi_desc= "Complete Deposed God Assault -  100 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[8] = {
        id= 8,
        achi_name= "God Betrayal 3",
        achi_desc= "Complete Deposed God Assault -  150 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[9] = {
        id= 9,
        achi_name= "God Betrayal 4",
        achi_desc= "Complete Deposed God Assault -  200 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[10] = {
        id= 10,
        achi_name= "God Betrayal 5",
        achi_desc= "Complete Deposed God Assault -  300 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[11] = {
        id= 11,
        achi_name= "God Betrayal 6",
        achi_desc= "Complete Deposed God Assault -  400 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[12] = {
        id= 12,
        achi_name= "God Betrayal 7",
        achi_desc= "Complete Deposed God Assault -  500 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[13] = {
        id= 13,
        achi_name= "Unknown Trial 1",
        achi_desc= "Complete Deposed God Assault - ∞ 1 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[14] = {
        id= 14,
        achi_name= "Unknown Trial 2",
        achi_desc= "Complete Deposed God Assault - ∞ 5 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[15] = {
        id= 15,
        achi_name= "Unknown Trial 3",
        achi_desc= "Complete Deposed God Assault - ∞ 10 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[16] = {
        id= 16,
        achi_name= "Ultimate Trial 1",
        achi_desc= "Complete Deposed God Assault (Lv. 100) 1 times by yourself",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[17] = {
        id= 17,
        achi_name= "Ultimate Trial 2",
        achi_desc= "Complete Deposed God Assault (Lv. 150) 1 times by yourself",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[18] = {
        id= 18,
        achi_name= "Ultimate Trial 3",
        achi_desc= "Complete Deposed God Assault (Lv. 175) 1 times by yourself",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[19] = {
        id= 19,
        achi_name= "Noble Warrior",
        achi_desc= "Challenge: Win 1 Time in The Thunder Trial",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[20] = {
        id= 20,
        achi_name= "Change Destiny 1",
        achi_desc= "Claim Sigrdrifa for 2 times in one Deposed God event",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[21] = {
        id= 21,
        achi_name= "Change Destiny 2",
        achi_desc= "Claim Sigrdrifa for 4 times in one Deposed God event",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[22] = {
        id= 22,
        achi_name= "Change Destiny 3",
        achi_desc= "Claim Sigrdrifa for 6 times in one Deposed God event",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[23] = {
        id= 23,
        achi_name= "Change Destiny 4",
        achi_desc= "Claim Sigrdrifa for 8 times in one Deposed God event",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[24] = {
        id= 24,
        achi_name= "Reincarnation of Valkyrie",
        achi_desc= "Claim Sigrdrifa for 10 times in one Deposed God event",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[25] = {
        id= 25,
        achi_name= "Deposed God Analysis 0.5%",
        achi_desc= "Deposed God Cognition Level exceeds 1",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[26] = {
        id= 26,
        achi_name= "Deposed God Analysis 1%",
        achi_desc= "Deposed God Cognition Level exceeds 2",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[27] = {
        id= 27,
        achi_name= "Deposed God Analysis 1.5%",
        achi_desc= "Deposed God Cognition Level exceeds 3",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[28] = {
        id= 28,
        achi_name= "Deposed God Analysis 2%",
        achi_desc= "Deposed God Cognition Level exceeds 4",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[29] = {
        id= 29,
        achi_name= "Deposed God Analysis 2.5%",
        achi_desc= "Deposed God Cognition Level exceeds 5",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[30] = {
        id= 30,
        achi_name= "Deposed God Analysis 3%",
        achi_desc= "Deposed God Cognition Level exceeds 6",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[31] = {
        id= 31,
        achi_name= "Deposed God Analysis 3.5%",
        achi_desc= "Deposed God Cognition Level exceeds 7",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[32] = {
        id= 32,
        achi_name= "Deposed God Analysis 4%",
        achi_desc= "Deposed God Cognition Level exceeds 8",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[33] = {
        id= 33,
        achi_name= "Deposed God Analysis 4.5%",
        achi_desc= "Deposed God Cognition Level exceeds 9",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[34] = {
        id= 34,
        achi_name= "Deposed God Analysis 5%",
        achi_desc= "Deposed God Cognition Level exceeds 10",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[35] = {
        id= 35,
        achi_name= "Deposed God Analysis 6%",
        achi_desc= "Deposed God Cognition Level exceeds 12",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[36] = {
        id= 36,
        achi_name= "Deposed God Analysis 7%",
        achi_desc= "Deposed God Cognition Level exceeds 14",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[37] = {
        id= 37,
        achi_name= "Deposed God Analysis 8%",
        achi_desc= "Deposed God Cognition Level exceeds 16",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[38] = {
        id= 38,
        achi_name= "Deposed God Analysis 9%",
        achi_desc= "Deposed God Cognition Level exceeds 18",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[39] = {
        id= 39,
        achi_name= "Deposed God Analysis 10%",
        achi_desc= "Deposed God Cognition Level exceeds 20",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[40] = {
        id= 40,
        achi_name= "Deposed God Analysis 11%",
        achi_desc= "Deposed God Cognition Level exceeds 22",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[41] = {
        id= 41,
        achi_name= "Deposed God Analysis 12.5%",
        achi_desc= "Deposed God Cognition Level exceeds 25",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[42] = {
        id= 42,
        achi_name= "Deposed God Analysis 14%",
        achi_desc= "Deposed God Cognition Level exceeds 28",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[43] = {
        id= 43,
        achi_name= "Deposed God Analysis 15%",
        achi_desc= "Deposed God Cognition Level exceeds 30",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[44] = {
        id= 44,
        achi_name= "Deposed God Analysis 16%",
        achi_desc= "Deposed God Cognition Level exceeds 32",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[45] = {
        id= 45,
        achi_name= "Deposed God Analysis 17.5%",
        achi_desc= "Deposed God Cognition Level exceeds 35",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[46] = {
        id= 46,
        achi_name= "Deposed God Analysis 19%",
        achi_desc= "Deposed God Cognition Level exceeds 38",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[47] = {
        id= 47,
        achi_name= "Deposed God Analysis 20%",
        achi_desc= "Deposed God Cognition Level exceeds 40",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[48] = {
        id= 48,
        achi_name= "Deposed God Analysis 21%",
        achi_desc= "Deposed God Cognition Level exceeds 42",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[49] = {
        id= 49,
        achi_name= "Deposed God Analysis 22.5%",
        achi_desc= "Deposed God Cognition Level exceeds 45",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[50] = {
        id= 50,
        achi_name= "Deposed God Analysis 24%",
        achi_desc= "Deposed God Cognition Level exceeds 48",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[51] = {
        id= 51,
        achi_name= "Deposed God Analysis 25%",
        achi_desc= "Deposed God Cognition Level exceeds 50",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[52] = {
        id= 52,
        achi_name= "Deposed God Analysis 26%",
        achi_desc= "Deposed God Cognition Level exceeds 52",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[53] = {
        id= 53,
        achi_name= "Deposed God Analysis 27.5%",
        achi_desc= "Deposed God Cognition Level exceeds 55",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[54] = {
        id= 54,
        achi_name= "Deposed God Analysis 29%",
        achi_desc= "Deposed God Cognition Level exceeds 58",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[55] = {
        id= 55,
        achi_name= "Deposed God Analysis 30%",
        achi_desc= "Deposed God Cognition Level exceeds 60",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[56] = {
        id= 56,
        achi_name= "Deposed God Analysis 31%",
        achi_desc= "Deposed God Cognition Level exceeds 62",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[57] = {
        id= 57,
        achi_name= "Deposed God Analysis 32.5%",
        achi_desc= "Deposed God Cognition Level exceeds 65",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[58] = {
        id= 58,
        achi_name= "Deposed God Analysis 34%",
        achi_desc= "Deposed God Cognition Level exceeds 68",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[59] = {
        id= 59,
        achi_name= "Deposed God Analysis 35%",
        achi_desc= "Deposed God Cognition Level exceeds 70",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[60] = {
        id= 60,
        achi_name= "Deposed God Analysis 36%",
        achi_desc= "Deposed God Cognition Level exceeds 72",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[61] = {
        id= 61,
        achi_name= "Deposed God Analysis 37.5%",
        achi_desc= "Deposed God Cognition Level exceeds 75",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[62] = {
        id= 62,
        achi_name= "Deposed God Analysis 39%",
        achi_desc= "Deposed God Cognition Level exceeds 78",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[63] = {
        id= 63,
        achi_name= "Deposed God Analysis 40%",
        achi_desc= "Deposed God Cognition Level exceeds 80",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[64] = {
        id= 64,
        achi_name= "Deposed God Analysis 41%",
        achi_desc= "Deposed God Cognition Level exceeds 82",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[65] = {
        id= 65,
        achi_name= "Deposed God Analysis 42.5%",
        achi_desc= "Deposed God Cognition Level exceeds 85",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[66] = {
        id= 66,
        achi_name= "Deposed God Analysis 44%",
        achi_desc= "Deposed God Cognition Level exceeds 88",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[67] = {
        id= 67,
        achi_name= "Deposed God Analysis 45%",
        achi_desc= "Deposed God Cognition Level exceeds 90",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[68] = {
        id= 68,
        achi_name= "Deposed God Analysis 46%",
        achi_desc= "Deposed God Cognition Level exceeds 92",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[69] = {
        id= 69,
        achi_name= "Deposed God Analysis 47.5%",
        achi_desc= "Deposed God Cognition Level exceeds 95",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[70] = {
        id= 70,
        achi_name= "Deposed God Analysis 49%",
        achi_desc= "Deposed God Cognition Level exceeds 98",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[71] = {
        id= 71,
        achi_name= "Deposed God Analysis 50%",
        achi_desc= "Deposed God Cognition Level exceeds 100",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[72] = {
        id= 72,
        achi_name= "Deposed God Analysis 52.5%",
        achi_desc= "Deposed God Cognition Level exceeds 105",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[73] = {
        id= 73,
        achi_name= "Deposed God Analysis 55%",
        achi_desc= "Deposed God Cognition Level exceeds 110",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[74] = {
        id= 74,
        achi_name= "Deposed God Analysis 57.5%",
        achi_desc= "Deposed God Cognition Level exceeds 115",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[75] = {
        id= 75,
        achi_name= "Deposed God Analysis 60%",
        achi_desc= "Deposed God Cognition Level exceeds 120",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[76] = {
        id= 76,
        achi_name= "Deposed God Analysis 62.5%",
        achi_desc= "Deposed God Cognition Level exceeds 125",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[77] = {
        id= 77,
        achi_name= "Deposed God Analysis 65%",
        achi_desc= "Deposed God Cognition Level exceeds 130",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[78] = {
        id= 78,
        achi_name= "Deposed God Analysis 67.5%",
        achi_desc= "Deposed God Cognition Level exceeds 135",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[79] = {
        id= 79,
        achi_name= "Deposed God Analysis 70%",
        achi_desc= "Deposed God Cognition Level exceeds 140",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[80] = {
        id= 80,
        achi_name= "Deposed God Analysis 72.5%",
        achi_desc= "Deposed God Cognition Level exceeds 145",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[81] = {
        id= 81,
        achi_name= "Deposed God Analysis 75%",
        achi_desc= "Deposed God Cognition Level exceeds 150",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[82] = {
        id= 82,
        achi_name= "Deposed God Analysis 77.5%",
        achi_desc= "Deposed God Cognition Level exceeds 155",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[83] = {
        id= 83,
        achi_name= "Deposed God Analysis 80%",
        achi_desc= "Deposed God Cognition Level exceeds 160",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[84] = {
        id= 84,
        achi_name= "Deposed God Analysis 82.5%",
        achi_desc= "Deposed God Cognition Level exceeds 165",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[85] = {
        id= 85,
        achi_name= "Deposed God Analysis 85%",
        achi_desc= "Deposed God Cognition Level exceeds 170",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[86] = {
        id= 86,
        achi_name= "Deposed God Analysis 87.5%",
        achi_desc= "Deposed God Cognition Level exceeds 175",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[87] = {
        id= 87,
        achi_name= "Deposed God Analysis 90%",
        achi_desc= "Deposed God Cognition Level exceeds 180",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[88] = {
        id= 88,
        achi_name= "Deposed God Analysis 92.5%",
        achi_desc= "Deposed God Cognition Level exceeds 185",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[89] = {
        id= 89,
        achi_name= "Deposed God Analysis 95%",
        achi_desc= "Deposed God Cognition Level exceeds 190",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[90] = {
        id= 90,
        achi_name= "Deposed God Analysis 97.5%",
        achi_desc= "Deposed God Cognition Level exceeds 195",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_147_conf[91] = {
        id= 91,
        achi_name= "Deposed God Analysis 100%",
        achi_desc= "Deposed God Cognition Level exceeds 200",
        achi_icon= "icons/achiv/cjxt_001.png",

} 