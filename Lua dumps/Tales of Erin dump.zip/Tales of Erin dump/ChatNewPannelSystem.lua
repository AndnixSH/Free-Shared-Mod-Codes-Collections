
ChatNewPannelSystem = class("ChatNewPannelSystem",XUIView)
ChatNewPannelSystem.CS_FILE_NAME = "ChatPannelSystem.csb"
ChatNewPannelSystem.CS_BIND_TABLE = 
{

   	systemPannel 				= "/i:1",
	system_bg 					= "/i:1/i:1",
    system_btn_set				= "/i:1/i:2/i:2",
    system_chatList_pannel 		= "/i:1/i:4",
    
}

ChatNewPannelSystem.LogTag = "ChatNewPannelSystem"

function ChatNewPannelSystem:create(rData)
    local login = ChatNewPannelSystem.new()
    login.uiLayer   = cc.Layer:create()
    login:initUI()
    return login
end

function ChatNewPannelSystem:clear( )
	self:registEventDispatcher(false)

end

function ChatNewPannelSystem:returnBack(  )
	self:clear()
end

function ChatNewPannelSystem:initUI(  )
	self:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)
	
	self:initData()

	self:bindAllBtn()

	self:initConcationSysRoom()--系统聊天默认开启
end

function ChatNewPannelSystem:initData(  )
	self._scrollView 			= nil 
	self._sysChatroom 			= XBChatData:getInstance():getSystemRoomID()
	self.fetchMessage 			= false 

end

function ChatNewPannelSystem:bindAllBtn(  )
	self.system_bg:setVisible(false)
	
    self.system_btn_set:addTouchEventListener(handler(self,self.sysBtnSetCallback))

	local psize = self.system_chatList_pannel:getContentSize()
	self._scrollView = XBChatNewListView.new():initWithNodeAndSize(self.system_chatList_pannel, psize.width, psize.height)
	self._scrollView:setItemCreateFunc(handler(self,self.createItem))
	self._scrollView:setItemRemoveFunc(handler(self,self.removeItem))
end

function ChatNewPannelSystem:registEventDispatcher(bTrue)
	-- print("registEventDispatcher:::"..tostring(bTrue))
	-- if bTrue == false  then
	-- 	-- lemon.EventManager:getInstance():removeEventListener(self.chatroom_login_listener)
	-- 	return 
	-- end

	-- self.chatroom_login_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_SDK_LOGIN,handler(self,self.eventCbEnterChatroom))
end

function ChatNewPannelSystem:eventEnterChatroom( session_type,session_id,code ) --登陆结果通知回调
	if session_type ~= 2  then
		print("拒绝处理：类型不匹配。。ChatNewPannelSystemeventEnterChatroom type："..tostring(session_type).."....id:"..tostring(session_id)..".._sysChatroom:"..tostring(self._sysChatroom))
		return 
	end

	if self._sysChatroom == nil or  session_id ~= self._sysChatroom then
		return 
	end 
	if code ~= 0 then
		-- print("聊天室登陆失败！！code:"..tostring(code)..",session_id:"..tostring(session_id)..",session_type:"..tostring(session_type))
		XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1031015))

		return
	end
	self:refreshChatListView()

end

function ChatNewPannelSystem:eventRefreshUI( session_type,session_id,scrollEnd )
	if session_type ~= 2 or self._sysChatroom == nil  or tostring(session_id) ~= tostring(self._sysChatroom)  then
		print("拒绝处理：类型不匹配。。eventRefreshUI: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._sysChatroom))
		return 
	end
	
	XBChatData:getInstance():setCurrentSession(self._sysChatroom, 2)
	self:refreshChatListView(scrollEnd)

end
--
function ChatNewPannelSystem:eventFecthSession( session_type,session_id )
	if session_type ~= 2 or tostring(session_id) ~= tostring(self._sysChatroom)  then
		print("拒绝处理：类型不匹配。。eventFecthSession: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._sysChatroom))
		return 
	end

	self.fetchMessage = true 

	self:refreshChatListView(true)
end



function ChatNewPannelSystem:channelDataRefresh(  )
	self:initConcationSysRoom(true)
end

function ChatNewPannelSystem:initConcationSysRoom( bShowView )
	print("initConcationSysRoom:"..tostring(self._sysChatroom))

	if self._sysChatroom == nil or self._sysChatroom == "0"  then
		print("ChatNewPannelGuild:initConcationChatRoom=========缺少系统频道ID！！")
		return 
	end

	if XBChatData:getInstance():getChatRoomEnterState(self._sysChatroom) ~= true  then --系统
		print("initConcationSysRoom2222222:"..tostring(self._sysChatroom))

		XBChatSys:getInstance():createChatWaitLayer();

		local t_data = {
			session_id = self._sysChatroom,
		}
		XBChatSys:getInstance():enterChatRoom(t_data)
	else
		if bShowView == true  then
			self:refreshChatListView()
		end
	end

end

function ChatNewPannelSystem:removeScrollView( ... )
	if self._scrollView then
		self._scrollView:resetTempData()
	end
	self.fetchMessage 			= false 

end

function ChatNewPannelSystem:refreshChatListView( scrollEnd )
	if self._sysChatroom == nil  then --or self._scrollView == nil
		return 
	end

	if self.fetchMessage == true or self._scrollView:getDataSource() == nil  then
		if self.fetchMessage == true  then
			self.fetchMessage = false 
		end
		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self._sysChatroom)
		self._scrollView:setDataSource(chatroom_datas)
	else
		self._scrollView:refreshDataSource(scrollEnd)
	end 

end

function ChatNewPannelSystem:createItem( data )
	data["size_type_small"] = false -- 是否为小item
	return XBChatListViewItemPool:getInstance():createItemByData(data)
end

function ChatNewPannelSystem:removeItem( item )
	return XBChatListViewItemPool:getInstance():removeItemToPool(item)
end

function ChatNewPannelSystem:sysBtnSetCallback( sender,eventType )
	-- body
	print("sysBtnSetCallback:"..sender:getTag())

	if eventType == ccui.TouchEventType.ended then
		-- local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self._sysChatroom)
		-- local list = chatroom_datas:getList()
		-- dump(list, "ChatNewPannelChatroom.."..tostring(self._sysChatroom))


		local settingLayer = XBChatNewSettingLayer:create(data)

		self:getRootNode():addChild(settingLayer:getRootNode())

	end

end



