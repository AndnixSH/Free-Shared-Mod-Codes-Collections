--[[
游戏公告测试
GameNoticeLayer.lua
--todo 内公告
需要处理
目前为测试类
 self._webView:goForward()
 self._webView:goBack()
 self._webView:loadFile("Test.html")--加载失败
]]
require "BasicLayer"

GameNoticeLayer = class("GameNoticeLayer",BasicLayer)
GameNoticeLayer.__index = GameNoticeLayer
GameNoticeLayer.lClass = 3

--[[
 --公告地址目前之后易接渠道和其他渠道包有区别。暂时不写到配置表，
 如果以后每个渠道都有单独的公共，需放到json中
]]
--local NOTICE_URL = "http://52.231.207.155:9375/static/notice/nineskyandroid/home.html"



--"http://dev.xbreak.cn/static/client_update/web_korea/pages/home.html"


function GameNoticeLayer:init()
    self._webView = nil 
    self._rootCSbNode = nil 
    KeyboardManager._isShowNotice = true 
    self.sManager = self.rData["sManager"]
    
    local node = cc.CSLoader:createNode("GameNoticeLayer.csb")
    self.uiLayer:addChild(node,0,1)
    local panel = node:getChildByTag(101)
    self._rootCSbNode = panel

    local backBtn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:returnBack()
        end
    end)

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        print("keyboard notice layer")
        self:returnBack()
    end)
    self:initWebView()
end

function GameNoticeLayer:initWebView()
    --partner
    local webPartner  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"html_panel")
    local size = webPartner:getContentSize()
    dump(size)
    self._webView = ccexp.WebView:create()
    self._webView:setAnchorPoint(cc.p(0,0))
    self._webView:setPosition(0, 0)
    self._webView:setContentSize(size.width, size.height)
    self._webView:setScalesPageToFit(true)
    self._webView:setTouchEnabled(false)
    local notice_url = self:getNoticeUrl();
    self._webView:loadURL(notice_url) --loadURl

    self._webView:setOnShouldStartLoading(function(sender, url)
        print("onWebViewShouldStartLoading, url is ", url)
        return true
    end)
    self._webView:setOnDidFinishLoading(function(sender, url)
        print("onWebViewDidFinishLoading, url is ", url)
    end)
    self._webView:setOnDidFailLoading(function(sender, url)
        print("onWebViewDidFinishLoading, url is ", url)
    end)
    webPartner:addChild(self._webView)

end

--获得url地址
function GameNoticeLayer:getNoticeUrl()
    local NOTICE_URL = g_channel_control:getNoticeUrl()

    --128.1.50.220:80
    -- local platform = cc.Application:getInstance():getTargetPlatform() 
    -- if platform == cc.PLATFORM_OS_ANDROID then
         
    --     NOTICE_URL = "http://9skypatch.playwith.co.kr/notice/nineskyandroid/home.html"  
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     NOTICE_URL = "http://9skypatch.playwith.co.kr/notice/nineskyios/home.html" 
    -- else
    --     NOTICE_URL = "http://9skypatch.playwith.co.kr/notice/nineskyandroid/home.html"  
    -- end
    print("notice url = ", NOTICE_URL)
    return NOTICE_URL
end

--返回
function GameNoticeLayer:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self.sManager.sceneNum = 1
    self.sManager.rootLocation = 1
    self.exist = false
    self:clearEx()
end

function GameNoticeLayer:clearEx()
    KeyboardManager._isShowNotice = false 
    self:clear()
end

function GameNoticeLayer:create(rData)
     local layer = GameNoticeLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
