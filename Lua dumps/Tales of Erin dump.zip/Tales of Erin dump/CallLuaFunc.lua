
function battleEndFunc(id)
    cclog("测试3")
    require "SceneManager"
    cclog("测试lua结算")
    --AudioManager:shareDataManager():stopAll()
    AudioManager:shareDataManager():resumeAll()
    SDKManagerLua:refreshUserCoin(nil)
    GameManagerInst:blackScreenOff(0.1)
    KeyboardManager:setbattleState(false)
    UITool.delayTask(0.1,function ( ... )
    local scene = cc.Director:getInstance():getRunningScene()
        dump(scene, "battleEndFunc    22222")
        if scene then
            KeyboardManager:bindingAndroidKeyboard(scene,2)
        end
    end)
    local sData = {}
    sData["mode"] = id
    SceneManager:toBattleEndLayer(sData)
end
function singleBattleEndFunc(id,battle_id,battle_state)
require "SceneManager"
    --AudioManager:shareDataManager():stopAll()
    AudioManager:shareDataManager():resumeAll()
    SDKManagerLua:refreshUserCoin(nil)
    GameManagerInst:blackScreenOff(0.1)
    KeyboardManager:setbattleState(false)
    UITool.delayTask(0.1,function ( ... )
    local scene = cc.Director:getInstance():getRunningScene()
        dump(scene, "battleEndFunc    22222")
        if scene then
            KeyboardManager:bindingAndroidKeyboard(scene,2)
        end
    end)
    local sData = {}
    sData["mode"] = id
    sData["battle_id"] = battle_id
    sData["battle_state"] = battle_state
    SceneManager:toBattleEndLayer(sData)
end
function towerbattleEndFunc(str)
    --AudioManager:shareDataManager():stopAll()
    AudioManager:shareDataManager():resumeAll()
   SDKManagerLua:refreshUserCoin(nil)
   local NowNode = SceneManager:getRootNode()
    print("战斗结算---"..str)
    GameManagerInst:blackScreenOff(0.1)
    
    KeyboardManager:setbattleState(false)
    UITool.delayTask(0.1,function ( ... )
        local scene = cc.Director:getInstance():getRunningScene()
            dump(scene, "towerbattleEndFunc    22222")
            if scene then
                KeyboardManager:bindingAndroidKeyboard(scene,2)
            end
        end)
    NowNode:reqGuildTowerBattleEnd(str)
end
function tobattleEndBInfoFunc(str)
      require "SceneManager"
      SceneManager:tobattleEndBInfo(str)
end
function battleEndFuncFalse(id,mode)
    cclog("测试3")
    require "SceneManager"
    cclog("测试lua结算")
    --AudioManager:shareDataManager():stopAll()
    AudioManager:shareDataManager():resumeAll()
    SDKManagerLua:refreshUserCoin(nil)
    GameManagerInst:blackScreenOff(0.1)
    KeyboardManager:setbattleState(false)

    UITool.delayTask(0.1,function ( ... )
        local scene = cc.Director:getInstance():getRunningScene()
            dump(scene, "battleEndFuncFalse    22222")
            if scene then
                KeyboardManager:bindingAndroidKeyboard(scene,2)
            end
        end)
    if id==0 then
      SceneManager:toStartLayer()
      return
    end
    local sData = {}
    sData["type"] = id -- 1、单人 2、BOSS
    sData["mode"] = mode -- 1、单人战斗  2、多人战斗
    SceneManager:toBattleFailedLayer(sData)
end


function conectBackFunc(id)
   GameManagerInst:blackScreenOff()
  local popData = {}
  print("错误ID"..id)
  local popData = {}
  popData["showButType"] = 1
  popData["showDecType"] = 1
  popData["texDec"]      = "ErroeCode:"..id
  popData["MsgType"]     = 5 
  SceneManager.msgMgr:showECastingMsg(popData)
  SceneManager:delWaitLayer()
end

function drawCardFunc(end_str)

    local str = string.sub(end_str,8,10)
    
    require "DrawCardLayer"


   if string.find(end_str,"poxiao://",0)~=nil then 
       
      if string.find(end_str,"Gacha",9)~= nil then 
         
         if string.find(end_str,"Type=one",10)~=nil then
             if allow_draw_card == true then
                allow_draw_card=false
                DrawCardLayer:reqDraw("gem",1)
             end
         elseif string.find(end_str,"Type=ten",10)~=nil then
             if allow_draw_card == true then
                allow_draw_card=false
                DrawCardLayer:reqDraw("gem",10)
             end
         end 
      end
      return 0;
   end
      return 1;
end

function changeUserInfoNum(num)
  user_info["gem"] = user_info["gem"] -num
end


function getPS(ps,ps_id,info_id)
print(ps..ps_id..info_id)
  local str =  princess_ocp[ps][ps_id][info_id]
  return str
end

function getGuideID()

  local str =  user_info["guide_id"]
  return str
end
function getUserRank( ... )
  -- body
  local str =  user_info["rank"]
  return str
end

function getBQNum()--获取表情的个数

  local str =  #expression
  return str
end

function getChannel()--获取渠道
    require "sdk/ch_config"
    local str =  GAME_CHANNEL
    return str
end

--返回登录界面
function toLoginLayer()
    SceneManager:runLoginScene()
end

--去掉loading遮罩
function removeWaitLayer()
SceneManager:delWaitLayer()
end


function NewGuideStart( id )
    NewGuideManager:dealFirstGuide(id)
end

function callAchiEfc(str)      
  local cjson = require "cjson"
  print("string sting == "..str)
  local t_data = cjson.decode(str)
  local tab = t_data
  if G_Efc_num > 0 then
      G_Efc_num = 0
  end
  print("t_data == "..tab["achi"][1][1] )
  require "SceneManager"
  ShowAchiEfc(tab["achi"])
  
  --AppsFlyer获得成就打点
  local function addAppsFlyerEvent(achi_name, achiveData)
      if achi_name == nil then
          return
      end
      SysDot:eventAchievementUnlock(achi_name, achiveData)
  end
  local achi_id = tab["achi"][1][1]
  local achi_name = UITool.getUserLanguage(achi_everyday_conf[achi_id]["achi_name"])--achi_everyday_conf[achi_id]["achi_name"]
  local achiveData = {
          achieveId = achi_id
        }
  addAppsFlyerEvent(achi_name, achiveData)
  print("aaaaaaa==>"..tostring(achi_name))
end

function g_showNetErrorLayer( )
  require "NetErrorManager"
  NetErrorManager:getInstance():setServerError(true)
  NetErrorManager:getInstance():setNetError(true)
end


function g_hideNetErrorLayer( )
  require "NetErrorManager"
  NetErrorManager:getInstance():setServerError(false)
  NetErrorManager:getInstance():setNetError(false, true)
end
