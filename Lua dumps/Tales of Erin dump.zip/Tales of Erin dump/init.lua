

zc = zc or {}

function zc.luaBridgeCall(className,functionName,args,sigs)
    local platform = cc.Application:getInstance():getTargetPlatform()
    local ok = false
    local ret = nil
    if platform == cc.PLATFORM_OS_ANDROID then
        local luaj = require("src/cocos/cocos2d/luaj.lua")
        ok,ret  = luaj.callStaticMethod(className,functionName,args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        -- local luaoc = require_ex("src/cocos/cocos2d/luaoc.lua")
        local luaoc = require "cocos.cocos2d.luaoc" 

        ok,ret  = luaoc.callStaticMethod(className, functionName, args)
    end
    if not ok then
        print("luaoc error:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(functionName))
    else
        print("The oc ret is:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(functionName))
    end
    return ok, ret
end

--登录、登出 回调
function zc.goReturnLogin( param )
    SDKManagerLua:goReturnLogin(param)
end

--login
function zc.login(loginCallBack)
    local args = {}
    local sigs = nil
    local platform = cc.Application:getInstance():getTargetPlatform()
    args = {loginCallBack}
    sigs = "(I)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"ZCLogin",args,sigs)
end
--点击注销登录
function zc.ZCLogout()
    SDK_LoginData = nil
    local arg = {callback = zc.goReturnLogin }
    local sig = nil
    arg = { zc.goReturnLogin }
    sig = "(I)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"ZCLogout",arg,sig)
end
---注册退出登录回调
function zc.setLogout( )
    local arg = {callback = zc.goReturnLogin }
    local sig = nil
    local platform = cc.Application:getInstance():getTargetPlatform()
    arg = { zc.goReturnLogin }
    sig = "(I)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"setLogout",arg,sig)
end
----公告
function zc.showNotice(closeNoticeBack)
    local args = {}
    local sigs = nil
    args = {closeNoticeBack}
    sigs = "(I)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"showNotice",args,sigs)
end
--事件上报(必接)，埋点
--定义参数类型
--[[
    Adjust埋点
    创建角色    createdRole
    角色登陆    loginRole
    角色登出    logoutRole
    完成第一章第一节    chapter1_1_1
    全部（Firebase、Adjust、FB）
    冒险等级达到3级    lv 3
    冒险等级达到7级    lv 7
    冒险等级达到8级        lv 8
    冒险等级达到10级   lv 10
    冒险等级达到20级   lv 20

    String efunEvents = json.optString("efunEvents"); //对应欧美提供的key
    String efunId = json.optString("efunId");
    String roleId = json.optString("roleId");
    String roleName = json.optString("roleName");
    String roleLevel = json.optString("roleLevel");
    String serverCode = json.optString("serverCode");
    String serverName = json.optString("serverName");
--]]
function zc.trackingEvent(datas)
    args = {json.encode(datas)};
    local sigs = "(Ljava/lang/String;)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"efunTrackEvent",args,sigs)
end

--[[
    efunsdk支付
    String roleId = json.optString("roleId");// 角色id
    String roleName = json.optString("roleName");// 角色名称
    String roleLevel = json.optString("roleLevel");// 角色等级
    String userId = json.optString("efunID");// userid:efun用户id
    String serverCode = json.optString("serverCode");// 服务器code
    String remark = json.optString("remark");// 自定义字符串（选填）
    String efunProductId = json.optString("efunProductId");// 商品ID
    String payStone = json.optString("payStone");//发币数
    String payMoney = json.optString("payMoney");//商品售价
--]]
function zc.pay(_payDatas , _paySDKCallBack)
    local sigs = "(Ljava/lang/String;I)V";
    local args = { json.encode(_payDatas) , _paySDKCallBack }
    zc.luaBridgeCall(LUA_BRIDGE_CLASS, "pay", args, sigs)
end

--share
--[[
    sharePlatformType:
        0 facebook,1 twitter分享,2 kakao分享,3 vk分享,4 line分享,5 naver的cafe分享
        6 whatsApp分享,7 wechat分享,8 wechat朋友圈分享,9 messenger分享,10 instagram分享
    shareType:
        facebook --> 1:facebookLocalPicShare 2:facebookOnlineShare
        wechat-----> 1:文字分享 2:图片分享 3: 在线链接分享
    特殊字端：
    shareTarget： 1 ：WxFriend 2: WxFriendCircle 3:WxFavorite

    facebook：本地图片
        local _shareDatas = {
            sharePlatformType   = 0,
            shareType           = 1,
            sharePicture        = "XXXXXX.png", ---本地图片
        }
    facebook：网络图片
        local _shareDatas = {
            sharePlatformType   = 0,
            shareType           = 2,
            shareLinkUrl        = "xxxxxx.com", ---// "https://www.facebook.com/";  //分享链接
            sharePictureUrl     = "xxx.com"--图片链接
            shareCaption        =  "caption"; //分享内容
            shareDescription    = "descrition";//分享描述
        }

    twitter分享
        local _shareDatas = {
            sharePlatformType   = 1,
            shareUrl            = shareUrl,
            sharePicture        = sharePicture, ---本地图片
            shareDescription    = shareDescription,
        }
    微信分享：
        文本：
            local _shareDatas = {
                sharePlatformType   = 7,
                shareType           = 1, --1文本、2、图片 3、在线链接分享
                shareTarget         = 1, --1 ：WxFriend 2: WxFriendCircle 3:WxFavorite
                shareCaption        = "分享内容",
                shareDescription    = "描述",
            }
        图片分享：
            local _shareDatas = {
                sharePlatformType   = 7,
                shareType           = 2, --1文本、2、图片 3、在线链接分享
                shareTarget         = 1, --1 ：WxFriend 2: WxFriendCircle 3:WxFavorite
                sharePicture        = sharePicture, ---本地图片
            }
        在线链接分享：
            local _shareDatas = {
                sharePlatformType   = 7,
                shareType           = 2, --1文本、2、图片 3、在线链接分享
                shareTarget         = 1, --1 ：WxFriend 2: WxFriendCircle 3:WxFavorite
                shareLinkUrl        = "xxxxxx.com", ---// "https://www.facebook.com/";  //分享链接
                shareTitle          = "title"
                sharePicture        = sharePicture, ---本地图片
                shareDescription    = "descrition";//分享描述
            }
]]

function zc.share(_shareDatas,_shareCallBack)
    _shareDatas.shareType = _shareDatas.shareType or 1
    _shareDatas.sharePlatformType = tonumber(_shareDatas.sharePlatformType)
    _shareDatas.shareType = tonumber(_shareDatas.shareType)
    local sharePlatformType = _shareDatas.sharePlatformType
    local shareType = _shareDatas.shareType --每个分享平台定义不同
    local sigs = "(Ljava/lang/String;I)V"
    local args = {json.encode(_shareDatas),_shareCallBack}
    local javaFuncName = ""
    if sharePlatformType == 0 then 
        if shareType == 1 then 
            javaFuncName = "facebookLocalPicShare"
        else 
            javaFuncName = "facebookOnlineShare"
        end 
    elseif sharePlatformType == 1 then 
        javaFuncName = "twitterShare"
    elseif sharePlatformType == 7 then
        javaFuncName = "wechatShare"
    end 
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,javaFuncName,args,sigs)
end
--[[
    打开粉丝页
    String url = json.optString("url");
    String uid = json.optString("efunuid");
    String roleId = json.optString("roleId");
    String serverCode =json.optString("serverCode");
    int mWebPageType = json.optInt("webPageType");
]]
function zc.openWebPage(_datas,_openCallBack)
    _datas.webPageType = _datas.webPageType or 1
    local sigs = "(Ljava/lang/String;I)V"
    local args = {json.encode(_datas),_openCallBack}
    local javaFuncName = "efunOpenWebPage" 
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,javaFuncName,args,sigs)
end

function zc.callUserCenter( )
    local sigs = "()V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"callUserCenter",args,sigs)
end
----悬浮窗---------
function zc.showFloatView()
    local args = { bRet }
    local sigs = "(Z)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"showFloatView",args,sigs)
end
function zc.setFloatViewState(bRet)
    local args = { bRet }
    local sigs = "(Z)V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"setFloatViewState",args,sigs)
end
function zc.destoryFloatView()
    local args = { bRet }
    local sigs = "()V"
    zc.luaBridgeCall(LUA_BRIDGE_CLASS,"destoryFloatView",args,sigs)
end