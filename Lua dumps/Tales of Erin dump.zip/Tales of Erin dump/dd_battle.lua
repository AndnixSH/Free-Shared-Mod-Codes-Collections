dd_battle={}

dd_battle[1]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6000
        },
        {
        type= 5,
        id=1089,
        num=1
        },
    }
}
dd_battle[2]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6000
        },
        {
        type= 5,
        id=1093,
        num=1
        },
    }
}
dd_battle[3]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6000
        },
        {
        type= 5,
        id=1105,
        num=1
        },
    }
}
dd_battle[4]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6000
        },
        {
        type= 5,
        id=1085,
        num=1
        },
    }
}
dd_battle[5]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6000
        },
        {
        type= 5,
        id=1097,
        num=1
        },
    }
}
dd_battle[6]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6200
        },
        {
        type= 5,
        id=1109,
        num=1
        },
    }
}
dd_battle[7]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6200
        },
        {
        type= 5,
        id=1081,
        num=1
        },
    }
}
dd_battle[8]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6200
        },
        {
        type= 5,
        id=1101,
        num=1
        },
    }
}
dd_battle[9]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6200
        },
        {
        type= 5,
        id=1113,
        num=1
        },
    }
}
dd_battle[10]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6200
        },
        {
        type= 5,
        id=1125,
        num=1
        },
    }
}
dd_battle[11]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6400
        },
        {
        type= 5,
        id=1121,
        num=1
        },
    }
}
dd_battle[12]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6400
        },
        {
        type= 5,
        id=1117,
        num=1
        },
    }
}
dd_battle[13]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6400
        },
        {
        type= 5,
        id=1089,
        num=1
        },
    }
}
dd_battle[14]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6400
        },
        {
        type= 5,
        id=1093,
        num=1
        },
    }
}
dd_battle[15]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6400
        },
        {
        type= 5,
        id=1105,
        num=1
        },
    }
}
dd_battle[16]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6600
        },
        {
        type= 5,
        id=1085,
        num=1
        },
    }
}
dd_battle[17]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6600
        },
        {
        type= 5,
        id=1097,
        num=1
        },
    }
}
dd_battle[18]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6600
        },
        {
        type= 5,
        id=1109,
        num=1
        },
    }
}
dd_battle[19]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6600
        },
        {
        type= 5,
        id=1081,
        num=1
        },
    }
}
dd_battle[20]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6600
        },
        {
        type= 5,
        id=1101,
        num=1
        },
    }
}
dd_battle[21]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6800
        },
        {
        type= 5,
        id=1113,
        num=1
        },
    }
}
dd_battle[22]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6800
        },
        {
        type= 5,
        id=1125,
        num=1
        },
    }
}
dd_battle[23]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6800
        },
        {
        type= 5,
        id=1121,
        num=1
        },
    }
}
dd_battle[24]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6800
        },
        {
        type= 5,
        id=1117,
        num=1
        },
    }
}
dd_battle[25]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=6800
        },
        {
        type= 5,
        id=1089,
        num=1
        },
    }
}
dd_battle[26]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7000
        },
        {
        type= 5,
        id=1093,
        num=1
        },
    }
}
dd_battle[27]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7000
        },
        {
        type= 5,
        id=1105,
        num=1
        },
    }
}
dd_battle[28]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7000
        },
        {
        type= 5,
        id=1085,
        num=1
        },
    }
}
dd_battle[29]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7000
        },
        {
        type= 5,
        id=1097,
        num=1
        },
    }
}
dd_battle[30]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7000
        },
        {
        type= 5,
        id=1109,
        num=1
        },
    }
}
dd_battle[31]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7200
        },
        {
        type= 5,
        id=1081,
        num=1
        },
    }
}
dd_battle[32]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7200
        },
        {
        type= 5,
        id=1101,
        num=1
        },
    }
}
dd_battle[33]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7200
        },
        {
        type= 5,
        id=1113,
        num=1
        },
    }
}
dd_battle[34]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7200
        },
        {
        type= 5,
        id=1125,
        num=1
        },
    }
}
dd_battle[35]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7200
        },
        {
        type= 5,
        id=1121,
        num=1
        },
    }
}
dd_battle[36]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7400
        },
        {
        type= 5,
        id=1117,
        num=1
        },
    }
}
dd_battle[37]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7400
        },
        {
        type= 5,
        id=1090,
        num=1
        },
    }
}
dd_battle[38]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7400
        },
        {
        type= 5,
        id=1094,
        num=1
        },
    }
}
dd_battle[39]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7400
        },
        {
        type= 5,
        id=1106,
        num=1
        },
    }
}
dd_battle[40]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7400
        },
        {
        type= 5,
        id=1086,
        num=1
        },
    }
}
dd_battle[41]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7600
        },
        {
        type= 5,
        id=1098,
        num=1
        },
    }
}
dd_battle[42]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7600
        },
        {
        type= 5,
        id=1110,
        num=1
        },
    }
}
dd_battle[43]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7600
        },
        {
        type= 5,
        id=1082,
        num=1
        },
    }
}
dd_battle[44]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7600
        },
        {
        type= 5,
        id=1102,
        num=1
        },
    }
}
dd_battle[45]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7600
        },
        {
        type= 5,
        id=1114,
        num=1
        },
    }
}
dd_battle[46]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7800
        },
        {
        type= 5,
        id=1126,
        num=1
        },
    }
}
dd_battle[47]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7800
        },
        {
        type= 5,
        id=1122,
        num=1
        },
    }
}
dd_battle[48]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7800
        },
        {
        type= 5,
        id=1118,
        num=1
        },
    }
}
dd_battle[49]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7800
        },
        {
        type= 5,
        id=1090,
        num=1
        },
    }
}
dd_battle[50]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=7800
        },
        {
        type= 5,
        id=1094,
        num=1
        },
    }
}
dd_battle[51]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8000
        },
        {
        type= 5,
        id=1106,
        num=1
        },
    }
}
dd_battle[52]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8000
        },
        {
        type= 5,
        id=1086,
        num=1
        },
    }
}
dd_battle[53]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8000
        },
        {
        type= 5,
        id=1098,
        num=1
        },
    }
}
dd_battle[54]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8000
        },
        {
        type= 5,
        id=1110,
        num=1
        },
    }
}
dd_battle[55]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8000
        },
        {
        type= 5,
        id=1082,
        num=1
        },
    }
}
dd_battle[56]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8200
        },
        {
        type= 5,
        id=1102,
        num=1
        },
    }
}
dd_battle[57]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8200
        },
        {
        type= 5,
        id=1114,
        num=1
        },
    }
}
dd_battle[58]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8200
        },
        {
        type= 5,
        id=1126,
        num=1
        },
    }
}
dd_battle[59]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8200
        },
        {
        type= 5,
        id=1122,
        num=1
        },
    }
}
dd_battle[60]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8200
        },
        {
        type= 5,
        id=1118,
        num=1
        },
    }
}
dd_battle[61]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8400
        },
        {
        type= 5,
        id=1090,
        num=1
        },
    }
}
dd_battle[62]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8400
        },
        {
        type= 5,
        id=1094,
        num=1
        },
    }
}
dd_battle[63]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8400
        },
        {
        type= 5,
        id=1106,
        num=1
        },
    }
}
dd_battle[64]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8400
        },
        {
        type= 5,
        id=1086,
        num=1
        },
    }
}
dd_battle[65]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8400
        },
        {
        type= 5,
        id=1098,
        num=1
        },
    }
}
dd_battle[66]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8600
        },
        {
        type= 5,
        id=1110,
        num=1
        },
    }
}
dd_battle[67]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8600
        },
        {
        type= 5,
        id=1082,
        num=1
        },
    }
}
dd_battle[68]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8600
        },
        {
        type= 5,
        id=1102,
        num=1
        },
    }
}
dd_battle[69]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8600
        },
        {
        type= 5,
        id=1114,
        num=1
        },
    }
}
dd_battle[70]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8600
        },
        {
        type= 5,
        id=1126,
        num=1
        },
    }
}
dd_battle[71]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8800
        },
        {
        type= 5,
        id=1122,
        num=1
        },
    }
}
dd_battle[72]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8800
        },
        {
        type= 5,
        id=1118,
        num=1
        },
    }
}
dd_battle[73]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8800
        },
        {
        type= 5,
        id=1090,
        num=1
        },
    }
}
dd_battle[74]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8800
        },
        {
        type= 5,
        id=1094,
        num=1
        },
    }
}
dd_battle[75]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=8800
        },
        {
        type= 5,
        id=1106,
        num=1
        },
    }
}
dd_battle[76]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9000
        },
        {
        type= 5,
        id=1086,
        num=1
        },
    }
}
dd_battle[77]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9000
        },
        {
        type= 5,
        id=1098,
        num=1
        },
    }
}
dd_battle[78]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9000
        },
        {
        type= 5,
        id=1110,
        num=1
        },
    }
}
dd_battle[79]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9000
        },
        {
        type= 5,
        id=1082,
        num=1
        },
    }
}
dd_battle[80]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9000
        },
        {
        type= 5,
        id=1102,
        num=1
        },
    }
}
dd_battle[81]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9200
        },
        {
        type= 5,
        id=1114,
        num=1
        },
    }
}
dd_battle[82]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9200
        },
        {
        type= 5,
        id=1126,
        num=1
        },
    }
}
dd_battle[83]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9200
        },
        {
        type= 5,
        id=1122,
        num=1
        },
    }
}
dd_battle[84]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9200
        },
        {
        type= 5,
        id=1118,
        num=1
        },
    }
}
dd_battle[85]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9200
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[86]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9400
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[87]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9400
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[88]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9400
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[89]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9400
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[90]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9400
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[91]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9600
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[92]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9600
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[93]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9600
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[94]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9600
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[95]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9600
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[96]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9800
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[97]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9800
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[98]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9800
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[99]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=9800
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[100]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[101]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[102]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[103]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[104]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[105]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[106]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[107]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[108]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[109]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[110]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[111]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[112]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[113]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[114]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[115]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[116]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[117]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[118]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[119]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[120]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[121]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[122]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[123]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[124]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[125]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[126]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[127]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[128]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[129]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[130]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[131]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[132]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[133]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[134]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[135]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[136]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[137]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[138]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[139]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[140]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[141]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[142]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[143]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[144]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[145]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[146]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[147]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[148]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[149]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[150]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[151]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[152]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[153]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[154]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[155]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[156]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[157]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[158]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[159]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[160]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[161]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[162]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[163]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[164]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[165]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[166]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[167]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[168]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[169]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[170]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[171]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[172]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[173]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[174]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[175]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[176]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[177]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[178]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[179]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[180]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[181]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[182]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[183]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[184]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[185]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[186]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[187]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[188]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1103,
        num=1
        },
    }
}
dd_battle[189]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}
dd_battle[190]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1119,
        num=1
        },
    }
}
dd_battle[191]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1123,
        num=1
        },
    }
}
dd_battle[192]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1127,
        num=1
        },
    }
}
dd_battle[193]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1083,
        num=1
        },
    }
}
dd_battle[194]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1095,
        num=1
        },
    }
}
dd_battle[195]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1107,
        num=1
        },
    }
}
dd_battle[196]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1087,
        num=1
        },
    }
}
dd_battle[197]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1099,
        num=1
        },
    }
}
dd_battle[198]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1111,
        num=1
        },
    }
}
dd_battle[199]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1091,
        num=1
        },
    }
}
dd_battle[200]={
    drop_reward = {  
        {
        type= 1,
        id=0,
        num=10000
        },
        {
        type= 5,
        id=1115,
        num=1
        },
    }
}

