--require "XUIView"
--星盘强化功能
Astrolabe_sth = class("Astrolabe_sth",XUIView)
Astrolabe_sth.CS_FILE_NAME = "Astrolabe_sth.csb"
Astrolabe_sth.CS_BIND_TABLE = 
{ 
    panle       = "/s:Panel_1",
    paneSth     = "/s:Panel_sth",
    icon        = "/s:Panel_sth/s:Image_icon",
    iconbg      = "/s:Panel_sth/s:Image_iconbg",
    name        = "/s:Panel_sth/s:Text_name",
    --显示持有数量
    matNum= "/s:Panel_sth/s:Text_num",
    --强化按钮
    sthBtn      = "/s:Panel_sth/s:Button_sth",
    leftBtn     = "/s:Panel_sth/s:Button_left_0",
    rightBtn    = "/s:Panel_sth/s:Button_right_0",
    --选择数量
    selectNum      = "/s:Panel_sth/s:Text_sel_num",
}

function Astrolabe_sth:init()
    Astrolabe_sth.super.init(self)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end
function Astrolabe_sth:touchClick( ... )
    --点击确定按钮
    self.sthBtn:addClickEventListener(function()
        if not self.mat_count then return end
        --当前扩充数为0
        if self.mat_count == 0 then
            if self.astoLv >= self.maxLvLimit then

                local  area1 = hero_astrolabe[self.hero_sub_id]["areas"][1]["level_max"]
                local  area2 = hero_astrolabe[self.hero_sub_id]["areas"][2]["level_max"]
                local  area3 = hero_astrolabe[self.hero_sub_id]["areas"][3]["level_max"]
                if self.astoLv >= area1 and self.astoLv < area2 then
                    GameManagerInst:alert(UITool.ToLocalization("解锁主序星开启120级上限"))
                elseif self.astoLv >= area2 and self.astoLv < area3 then
                    GameManagerInst:alert(UITool.ToLocalization("解锁极天星开启200级上限"))
                elseif self.astoLv >= area3 then
                    GameManagerInst:alert(UITool.ToLocalization("已达到满级"))
                end
            else
                GameManagerInst:alert(UITool.ToLocalization("请选择素材数量"))
            end
            return
        end
        --可以强化的情况
        -- local mid = getMatID(self.matName)
        -- local msg = "使用%d个%s强化星盘？"
        -- local msg1 = string.format(UITool.ToLocalization(msg),self.mat_count,mat[mid].name)
        -- GameManagerInst:confirm(msg1,function()
            --在外层定义的函数 
            if self.callBackSth then
                self.callBackSth(self,self.mat_count,mid)
            end
        --end)
    end)
    --点击素材弹出素材的信息框
    self.iconbg:setTouchEnabled(true)
    self.iconbg:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local mid = getMatID(self.matName)
            MsgManager:showSimpItemInfo(5,mid)
        end
    end)

    self.leftBtn:addTouchEventListener(function(sender,eventType)

       
        if eventType == ccui.TouchEventType.began then
             print("lelelelellele")

            if AstrolabeSthEff:getIsPlay() then
                return
            end
            --先要减一次
            --开始减小狗粮
            self:startIncreaseFood(-1)
        elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
            --停止减小狗粮
            print("lelelelellele false")
             self:stopFoodNum()
        end
    end)

    self.rightBtn:addTouchEventListener(function(sender,eventType)

       
        if eventType == ccui.TouchEventType.began then
             print("riririririiriirir")
            --开始加小狗粮
            if AstrolabeSthEff:getIsPlay() then
                return
            end
        self:startIncreaseFood(1)
        elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
            --停止加小狗粮
            print("riririririiriirir false")
            self:stopFoodNum()
        end
    end)
end

function Astrolabe_sth:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function Astrolabe_sth:loadData(matmax,hero_id,curAreaIndex,asLv)
    --选择素材的数量
    self.mat_count = 0
    --强化预览等级
    self.sthAddLv = 0
    self.hero_id   = hero_id
    self.hero_sub_id  = getNumID(self.hero_id)
    --选择的星盘
    self.curAreaIndex = curAreaIndex
    --星盘的等级上限
    self.maxLvLimit   = hero_astrolabe[self.hero_sub_id]["areas"][self.curAreaIndex]["level_max"]
    --星盘等级
    self.astoLv       = asLv
    --素材名字
    self.matName   = hero_astrolabe[self.hero_sub_id]["mat_exp"]
    --素材最大数量
    self.mat_max = matmax
    if not self.mat_max then
        self.mat_max = 0
    end
    print("self.mat_max self.mat_max == "..self.mat_max)

    local mid = getMatID(self.matName)
    print("---------  ".."icons/mat/"..mat[mid].icon)
    --素材提供的经验
    self.matExp  = mat[mid].mat_data
    print("self.matExp == self.matExp  .. "..self.matExp)
    self.icon:loadTexture("icons/mat/"..mat[mid].icon)
    self.name:setString(UITool.getUserLanguage(mat[mid].name))--(mat[mid].name)
    --显示持有数量
    self.matNum:setString(matmax)

    
    if g_channel_control.transform_Astrolabe_sth_matNum_pos == true then 
        self.matNum:setPosition(321.5,425.5)
    end 
    self:touchClick()
    self:refreshMatNum()

end
function Astrolabe_sth:refreshMatNum()
    local lb = false
    local rb = false
    if self.mat_count > 0 then
        --可以减数
        -- self.leftBtn:setTouchEnabled(true)
        -- self.leftBtn:setBright(true)
        lb = true
    else
        -- self.leftBtn:setTouchEnabled(false)
        -- self.leftBtn:setBright(false)
        -- self:stopFoodNum()
        lb = false
    end

    if ((self.sthAddLv + self.astoLv) < self.maxLvLimit) and (self.mat_count < self.mat_max ) then
        --可以加数
        -- self.rightBtn:setTouchEnabled(true)
        -- self.rightBtn:setBright(true)
        --  print("错的 执行这里")
        rb = true
    else
        -- print("应该执行这粒")
        -- self.rightBtn:setTouchEnabled(false)
        -- self.rightBtn:setBright(false)
        -- self:stopFoodNum()
        rb = false
    end
    if lb == false or rb == false then
        self:stopFoodNum()
    end
    self.leftBtn:setTouchEnabled(lb)
    self.leftBtn:setBright(lb)
    self.rightBtn:setTouchEnabled(rb)
    self.rightBtn:setBright(rb)
    self.selectNum:setString(""..self.mat_count)
    self.matNum:setString(""..(self.mat_max - self.mat_count))
end
--星盘等级限制 大于配置表等级 强化和加号禁用  现在需求更改对代码优化
--外部对里边等级的赋值 和达到条对外部的回调
function Astrolabe_sth:limitBtn( addlv ,func)
    local is = false
    self.sthAddLv = addlv
    if (addlv +self.astoLv) >= self.maxLvLimit then
        is = false
       
        --self:stopFoodNum()

        func()

    else
        is = true
   
    end
    -- self.rightBtn:setTouchEnabled(is)
    -- self.rightBtn:setBright(is)
end
function Astrolabe_sth:startIncreaseFood(opt)
    self:stopFoodNum()
    
    --闭包变量
    local c_opt = opt
    local c_total_time = 10
    local c_cnt = 0
    
    local function addfoodfunc(time)
        c_total_time = c_total_time + time
        c_cnt = c_cnt + 1
        
        local n = 1

        if c_total_time < 0.3 then
            return
        elseif c_total_time < 2 then 
            if c_cnt > 3.5 then
                c_cnt = 0
            else
                return
            end
        elseif c_total_time < 3 then
            if c_cnt > 2.5 then
                c_cnt = 0
            else
                return
            end
        elseif c_total_time < 4 then
            if c_cnt > 1.5 then
                c_cnt = 0
            else
                return
            end
        else
            c_cnt = 0
        end
        
        self.mat_count = self.mat_count or 0
        self.mat_count = self.mat_count + n * c_opt
        
        if self.mat_count < 0 then 
            self.mat_count = 0
            --self:stopFoodNum()
        end

        if self.mat_count >  self.mat_max then
            self.mat_count =  self.mat_max
            --self:stopFoodNum()
        end
        print("addfoodfunc 执行次数 == "..self.sthAddLv)
        self:setExp(self)
        self:refreshMatNum()
        
    end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerEntry = scheduler:scheduleScriptFunc(addfoodfunc, 1/60 , false)
    
    addfoodfunc(0) ---点击同时先加一次
    c_total_time = 0
end

function Astrolabe_sth:stopFoodNum()
    if self.schedulerEntry == nil then return end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.schedulerEntry)
    self.schedulerEntry = nil
end
