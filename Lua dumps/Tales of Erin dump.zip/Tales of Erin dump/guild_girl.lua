guild_girl={} 
guild_girl[1] ="56809"
  
guild_girl[2] ="56810"
  