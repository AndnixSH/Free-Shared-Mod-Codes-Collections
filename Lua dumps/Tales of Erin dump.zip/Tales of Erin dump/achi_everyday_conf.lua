achi_everyday_conf={} 
achi_everyday_conf[1] = {
        id= 1,
        achi_name= "136223",
        achi_desc= "136746",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[2] = {
        id= 2,
        achi_name= "136224",
        achi_desc= "136747",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[3] = {
        id= 3,
        achi_name= "136225",
        achi_desc= "136748",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[4] = {
        id= 4,
        achi_name= "136226",
        achi_desc= "136749",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5] = {
        id= 5,
        achi_name= "136227",
        achi_desc= "136750",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[6] = {
        id= 6,
        achi_name= "136228",
        achi_desc= "136751",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[7] = {
        id= 7,
        achi_name= "136229",
        achi_desc= "136752",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[8] = {
        id= 8,
        achi_name= "136230",
        achi_desc= "136753",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[9] = {
        id= 9,
        achi_name= "136231",
        achi_desc= "136754",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[10] = {
        id= 10,
        achi_name= "136232",
        achi_desc= "136755",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[11] = {
        id= 11,
        achi_name= "136233",
        achi_desc= "136756",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[12] = {
        id= 12,
        achi_name= "136234",
        achi_desc= "136757",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[13] = {
        id= 13,
        achi_name= "136235",
        achi_desc= "136758",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[14] = {
        id= 14,
        achi_name= "136236",
        achi_desc= "136759",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[15] = {
        id= 15,
        achi_name= "136237",
        achi_desc= "136760",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[16] = {
        id= 16,
        achi_name= "136238",
        achi_desc= "136761",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[17] = {
        id= 17,
        achi_name= "136239",
        achi_desc= "136762",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[18] = {
        id= 18,
        achi_name= "136240",
        achi_desc= "136763",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[20] = {
        id= 20,
        achi_name= "136241",
        achi_desc= "136764",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[21] = {
        id= 21,
        achi_name= "136242",
        achi_desc= "136765",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[22] = {
        id= 22,
        achi_name= "136243",
        achi_desc= "136766",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[23] = {
        id= 23,
        achi_name= "136244",
        achi_desc= "136767",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[24] = {
        id= 24,
        achi_name= "136245",
        achi_desc= "136768",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[25] = {
        id= 25,
        achi_name= "136246",
        achi_desc= "136769",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[26] = {
        id= 26,
        achi_name= "136247",
        achi_desc= "136770",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[27] = {
        id= 27,
        achi_name= "136248",
        achi_desc= "136771",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[28] = {
        id= 28,
        achi_name= "136249",
        achi_desc= "136772",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[29] = {
        id= 29,
        achi_name= "136250",
        achi_desc= "136773",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[30] = {
        id= 30,
        achi_name= "136251",
        achi_desc= "136774",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[31] = {
        id= 31,
        achi_name= "136252",
        achi_desc= "136775",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[32] = {
        id= 32,
        achi_name= "136253",
        achi_desc= "136776",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[33] = {
        id= 33,
        achi_name= "136254",
        achi_desc= "136777",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[34] = {
        id= 34,
        achi_name= "136255",
        achi_desc= "136778",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[35] = {
        id= 35,
        achi_name= "136256",
        achi_desc= "136779",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[36] = {
        id= 36,
        achi_name= "136257",
        achi_desc= "136780",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[37] = {
        id= 37,
        achi_name= "136258",
        achi_desc= "136781",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[38] = {
        id= 38,
        achi_name= "136259",
        achi_desc= "136782",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[39] = {
        id= 39,
        achi_name= "136260",
        achi_desc= "136783",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40] = {
        id= 40,
        achi_name= "136261",
        achi_desc= "136784",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[41] = {
        id= 41,
        achi_name= "136262",
        achi_desc= "136785",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[42] = {
        id= 42,
        achi_name= "136263",
        achi_desc= "136786",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[43] = {
        id= 43,
        achi_name= "136264",
        achi_desc= "136787",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[44] = {
        id= 44,
        achi_name= "136265",
        achi_desc= "136788",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50] = {
        id= 50,
        achi_name= "136266",
        achi_desc= "136789",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[51] = {
        id= 51,
        achi_name= "136267",
        achi_desc= "136790",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[52] = {
        id= 52,
        achi_name= "136268",
        achi_desc= "136791",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[53] = {
        id= 53,
        achi_name= "136269",
        achi_desc= "136792",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[54] = {
        id= 54,
        achi_name= "136270",
        achi_desc= "136793",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[55] = {
        id= 55,
        achi_name= "136271",
        achi_desc= "136794",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[56] = {
        id= 56,
        achi_name= "136272",
        achi_desc= "136795",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[57] = {
        id= 57,
        achi_name= "136273",
        achi_desc= "136796",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[58] = {
        id= 58,
        achi_name= "136274",
        achi_desc= "136797",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[59] = {
        id= 59,
        achi_name= "136275",
        achi_desc= "136798",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[60] = {
        id= 60,
        achi_name= "136276",
        achi_desc= "136799",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[61] = {
        id= 61,
        achi_name= "136277",
        achi_desc= "136800",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[62] = {
        id= 62,
        achi_name= "136278",
        achi_desc= "136801",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[63] = {
        id= 63,
        achi_name= "136279",
        achi_desc= "136802",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[64] = {
        id= 64,
        achi_name= "136280",
        achi_desc= "136803",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[65] = {
        id= 65,
        achi_name= "136281",
        achi_desc= "136804",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[66] = {
        id= 66,
        achi_name= "136282",
        achi_desc= "136805",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[67] = {
        id= 67,
        achi_name= "136283",
        achi_desc= "136806",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[68] = {
        id= 68,
        achi_name= "136284",
        achi_desc= "136807",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[69] = {
        id= 69,
        achi_name= "136285",
        achi_desc= "136808",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[70] = {
        id= 70,
        achi_name= "136286",
        achi_desc= "136809",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[71] = {
        id= 71,
        achi_name= "136287",
        achi_desc= "136810",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[72] = {
        id= 72,
        achi_name= "136288",
        achi_desc= "136811",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[73] = {
        id= 73,
        achi_name= "136289",
        achi_desc= "136812",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[74] = {
        id= 74,
        achi_name= "136290",
        achi_desc= "136813",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[75] = {
        id= 75,
        achi_name= "136291",
        achi_desc= "136814",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[80] = {
        id= 80,
        achi_name= "136292",
        achi_desc= "136815",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[81] = {
        id= 81,
        achi_name= "136293",
        achi_desc= "136816",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[82] = {
        id= 82,
        achi_name= "136294",
        achi_desc= "136817",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[83] = {
        id= 83,
        achi_name= "136295",
        achi_desc= "136818",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[84] = {
        id= 84,
        achi_name= "136296",
        achi_desc= "136819",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[85] = {
        id= 85,
        achi_name= "136297",
        achi_desc= "136820",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[86] = {
        id= 86,
        achi_name= "136298",
        achi_desc= "136821",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[87] = {
        id= 87,
        achi_name= "136299",
        achi_desc= "136822",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[88] = {
        id= 88,
        achi_name= "136300",
        achi_desc= "136823",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[100] = {
        id= 100,
        achi_name= "136301",
        achi_desc= "136824",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110] = {
        id= 110,
        achi_name= "136302",
        achi_desc= "136825",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111] = {
        id= 111,
        achi_name= "136303",
        achi_desc= "136826",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[112] = {
        id= 112,
        achi_name= "136304",
        achi_desc= "136827",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[113] = {
        id= 113,
        achi_name= "136305",
        achi_desc= "136828",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[114] = {
        id= 114,
        achi_name= "136306",
        achi_desc= "136829",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[130] = {
        id= 130,
        achi_name= "136307",
        achi_desc= "136830",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[131] = {
        id= 131,
        achi_name= "136308",
        achi_desc= "136831",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[132] = {
        id= 132,
        achi_name= "136309",
        achi_desc= "136832",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[133] = {
        id= 133,
        achi_name= "136310",
        achi_desc= "136833",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[134] = {
        id= 134,
        achi_name= "136311",
        achi_desc= "136834",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135] = {
        id= 135,
        achi_name= "136312",
        achi_desc= "136835",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136] = {
        id= 136,
        achi_name= "136313",
        achi_desc= "136836",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137] = {
        id= 137,
        achi_name= "136314",
        achi_desc= "136837",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138] = {
        id= 138,
        achi_name= "136315",
        achi_desc= "136838",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139] = {
        id= 139,
        achi_name= "136316",
        achi_desc= "136839",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140] = {
        id= 140,
        achi_name= "136317",
        achi_desc= "136840",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141] = {
        id= 141,
        achi_name= "136318",
        achi_desc= "136841",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[142] = {
        id= 142,
        achi_name= "136319",
        achi_desc= "136842",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[143] = {
        id= 143,
        achi_name= "136320",
        achi_desc= "136843",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[144] = {
        id= 144,
        achi_name= "136321",
        achi_desc= "136844",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[145] = {
        id= 145,
        achi_name= "136322",
        achi_desc= "136845",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[146] = {
        id= 146,
        achi_name= "136323",
        achi_desc= "136846",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[147] = {
        id= 147,
        achi_name= "136324",
        achi_desc= "136847",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[148] = {
        id= 148,
        achi_name= "136325",
        achi_desc= "136848",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[149] = {
        id= 149,
        achi_name= "136326",
        achi_desc= "136849",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150] = {
        id= 150,
        achi_name= "136327",
        achi_desc= "136850",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[151] = {
        id= 151,
        achi_name= "136328",
        achi_desc= "136851",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152] = {
        id= 152,
        achi_name= "136329",
        achi_desc= "136852",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153] = {
        id= 153,
        achi_name= "136330",
        achi_desc= "136853",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[154] = {
        id= 154,
        achi_name= "136331",
        achi_desc= "136854",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[155] = {
        id= 155,
        achi_name= "136332",
        achi_desc= "136855",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[156] = {
        id= 156,
        achi_name= "136333",
        achi_desc= "136856",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[157] = {
        id= 157,
        achi_name= "136334",
        achi_desc= "136857",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[158] = {
        id= 158,
        achi_name= "136335",
        achi_desc= "136858",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[159] = {
        id= 159,
        achi_name= "136336",
        achi_desc= "136859",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160] = {
        id= 160,
        achi_name= "136337",
        achi_desc= "136860",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[161] = {
        id= 161,
        achi_name= "136338",
        achi_desc= "136861",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[162] = {
        id= 162,
        achi_name= "136339",
        achi_desc= "136862",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[163] = {
        id= 163,
        achi_name= "136340",
        achi_desc= "136863",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[164] = {
        id= 164,
        achi_name= "136341",
        achi_desc= "136864",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[165] = {
        id= 165,
        achi_name= "136342",
        achi_desc= "136865",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[166] = {
        id= 166,
        achi_name= "136343",
        achi_desc= "136866",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[167] = {
        id= 167,
        achi_name= "136344",
        achi_desc= "136867",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[168] = {
        id= 168,
        achi_name= "136345",
        achi_desc= "136868",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[169] = {
        id= 169,
        achi_name= "136346",
        achi_desc= "136869",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[180] = {
        id= 180,
        achi_name= "136347",
        achi_desc= "136870",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[181] = {
        id= 181,
        achi_name= "136348",
        achi_desc= "136871",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[182] = {
        id= 182,
        achi_name= "136349",
        achi_desc= "136872",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[183] = {
        id= 183,
        achi_name= "136350",
        achi_desc= "136873",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[184] = {
        id= 184,
        achi_name= "136351",
        achi_desc= "136874",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[185] = {
        id= 185,
        achi_name= "136352",
        achi_desc= "136875",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[186] = {
        id= 186,
        achi_name= "136353",
        achi_desc= "136876",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[187] = {
        id= 187,
        achi_name= "136354",
        achi_desc= "136877",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[188] = {
        id= 188,
        achi_name= "136355",
        achi_desc= "136878",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[189] = {
        id= 189,
        achi_name= "136356",
        achi_desc= "136879",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[190] = {
        id= 190,
        achi_name= "136357",
        achi_desc= "136880",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[191] = {
        id= 191,
        achi_name= "136358",
        achi_desc= "136881",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[192] = {
        id= 192,
        achi_name= "136359",
        achi_desc= "136882",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[193] = {
        id= 193,
        achi_name= "136360",
        achi_desc= "136883",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[194] = {
        id= 194,
        achi_name= "136361",
        achi_desc= "136884",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[195] = {
        id= 195,
        achi_name= "136362",
        achi_desc= "136885",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[196] = {
        id= 196,
        achi_name= "136363",
        achi_desc= "136886",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[197] = {
        id= 197,
        achi_name= "136364",
        achi_desc= "136887",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[198] = {
        id= 198,
        achi_name= "136365",
        achi_desc= "136888",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[199] = {
        id= 199,
        achi_name= "136366",
        achi_desc= "136889",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[210] = {
        id= 210,
        achi_name= "136367",
        achi_desc= "136890",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[211] = {
        id= 211,
        achi_name= "136368",
        achi_desc= "136891",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[212] = {
        id= 212,
        achi_name= "136369",
        achi_desc= "136892",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[213] = {
        id= 213,
        achi_name= "136370",
        achi_desc= "136893",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[214] = {
        id= 214,
        achi_name= "136371",
        achi_desc= "136894",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[300] = {
        id= 300,
        achi_name= "136372",
        achi_desc= "136895",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[301] = {
        id= 301,
        achi_name= "136373",
        achi_desc= "136896",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[302] = {
        id= 302,
        achi_name= "136374",
        achi_desc= "136897",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[304] = {
        id= 304,
        achi_name= "136375",
        achi_desc= "136898",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[305] = {
        id= 305,
        achi_name= "136376",
        achi_desc= "136899",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[306] = {
        id= 306,
        achi_name= "136377",
        achi_desc= "136900",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[307] = {
        id= 307,
        achi_name= "136378",
        achi_desc= "136901",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[308] = {
        id= 308,
        achi_name= "136379",
        achi_desc= "136902",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[309] = {
        id= 309,
        achi_name= "136380",
        achi_desc= "136903",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[310] = {
        id= 310,
        achi_name= "136381",
        achi_desc= "136904",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[311] = {
        id= 311,
        achi_name= "136382",
        achi_desc= "136905",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[312] = {
        id= 312,
        achi_name= "136383",
        achi_desc= "136906",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[313] = {
        id= 313,
        achi_name= "136384",
        achi_desc= "136907",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[314] = {
        id= 314,
        achi_name= "136385",
        achi_desc= "136908",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[315] = {
        id= 315,
        achi_name= "136386",
        achi_desc= "136909",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[316] = {
        id= 316,
        achi_name= "136387",
        achi_desc= "136910",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[318] = {
        id= 318,
        achi_name= "136388",
        achi_desc= "136911",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[319] = {
        id= 319,
        achi_name= "136389",
        achi_desc= "136912",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[320] = {
        id= 320,
        achi_name= "136390",
        achi_desc= "136913",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[322] = {
        id= 322,
        achi_name= "136391",
        achi_desc= "136914",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[323] = {
        id= 323,
        achi_name= "136392",
        achi_desc= "136915",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[324] = {
        id= 324,
        achi_name= "136393",
        achi_desc= "136916",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[325] = {
        id= 325,
        achi_name= "136394",
        achi_desc= "136917",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[326] = {
        id= 326,
        achi_name= "136395",
        achi_desc= "136918",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[327] = {
        id= 327,
        achi_name= "136396",
        achi_desc= "136919",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[328] = {
        id= 328,
        achi_name= "136397",
        achi_desc= "136920",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[331] = {
        id= 331,
        achi_name= "136398",
        achi_desc= "136921",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[332] = {
        id= 332,
        achi_name= "136399",
        achi_desc= "136922",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[333] = {
        id= 333,
        achi_name= "136400",
        achi_desc= "136923",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[334] = {
        id= 334,
        achi_name= "136401",
        achi_desc= "136924",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[335] = {
        id= 335,
        achi_name= "136402",
        achi_desc= "136925",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[336] = {
        id= 336,
        achi_name= "136403",
        achi_desc= "136926",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[337] = {
        id= 337,
        achi_name= "136404",
        achi_desc= "136927",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[338] = {
        id= 338,
        achi_name= "136405",
        achi_desc= "136928",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[339] = {
        id= 339,
        achi_name= "136406",
        achi_desc= "136929",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[340] = {
        id= 340,
        achi_name= "136407",
        achi_desc= "136930",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[341] = {
        id= 341,
        achi_name= "136408",
        achi_desc= "136931",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[342] = {
        id= 342,
        achi_name= "136409",
        achi_desc= "136932",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[343] = {
        id= 343,
        achi_name= "136410",
        achi_desc= "136933",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[344] = {
        id= 344,
        achi_name= "136411",
        achi_desc= "136934",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[345] = {
        id= 345,
        achi_name= "136412",
        achi_desc= "136935",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[346] = {
        id= 346,
        achi_name= "136413",
        achi_desc= "136936",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[348] = {
        id= 348,
        achi_name= "136414",
        achi_desc= "136937",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[349] = {
        id= 349,
        achi_name= "136415",
        achi_desc= "136938",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[350] = {
        id= 350,
        achi_name= "136416",
        achi_desc= "136939",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[351] = {
        id= 351,
        achi_name= "136417",
        achi_desc= "136940",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[352] = {
        id= 352,
        achi_name= "136418",
        achi_desc= "136941",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[353] = {
        id= 353,
        achi_name= "136419",
        achi_desc= "136942",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[368] = {
        id= 368,
        achi_name= "136420",
        achi_desc= "136943",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141401] = {
        id= 141401,
        achi_name= "136421",
        achi_desc= "136944",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141201] = {
        id= 141201,
        achi_name= "136422",
        achi_desc= "136945",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141202] = {
        id= 141202,
        achi_name= "136423",
        achi_desc= "136946",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141203] = {
        id= 141203,
        achi_name= "136424",
        achi_desc= "136947",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[800] = {
        id= 800,
        achi_name= "136425",
        achi_desc= "136948",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[801] = {
        id= 801,
        achi_name= "136426",
        achi_desc= "136949",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[802] = {
        id= 802,
        achi_name= "136427",
        achi_desc= "136950",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[803] = {
        id= 803,
        achi_name= "136428",
        achi_desc= "136951",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[804] = {
        id= 804,
        achi_name= "136429",
        achi_desc= "136952",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[805] = {
        id= 805,
        achi_name= "136430",
        achi_desc= "136953",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[1201] = {
        id= 1201,
        achi_name= "136431",
        achi_desc= "136954",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[1202] = {
        id= 1202,
        achi_name= "136432",
        achi_desc= "136955",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[1203] = {
        id= 1203,
        achi_name= "136433",
        achi_desc= "136956",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[1204] = {
        id= 1204,
        achi_name= "136434",
        achi_desc= "136957",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[1205] = {
        id= 1205,
        achi_name= "136435",
        achi_desc= "136958",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136601] = {
        id= 136601,
        achi_name= "136436",
        achi_desc= "136959",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138801] = {
        id= 138801,
        achi_name= "136437",
        achi_desc= "136960",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118401] = {
        id= 118401,
        achi_name= "136438",
        achi_desc= "136961",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140401] = {
        id= 140401,
        achi_name= "136439",
        achi_desc= "136962",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140501] = {
        id= 140501,
        achi_name= "136440",
        achi_desc= "136963",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140801] = {
        id= 140801,
        achi_name= "136441",
        achi_desc= "136964",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[101104] = {
        id= 101104,
        achi_name= "136442",
        achi_desc= "136965",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[102304] = {
        id= 102304,
        achi_name= "136443",
        achi_desc= "136966",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[103604] = {
        id= 103604,
        achi_name= "136444",
        achi_desc= "136967",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[103704] = {
        id= 103704,
        achi_name= "136445",
        achi_desc= "136968",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[105104] = {
        id= 105104,
        achi_name= "136446",
        achi_desc= "136969",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[106104] = {
        id= 106104,
        achi_name= "136447",
        achi_desc= "136970",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[106204] = {
        id= 106204,
        achi_name= "136448",
        achi_desc= "136971",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[107604] = {
        id= 107604,
        achi_name= "136449",
        achi_desc= "136972",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110104] = {
        id= 110104,
        achi_name= "136450",
        achi_desc= "136973",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110304] = {
        id= 110304,
        achi_name= "136451",
        achi_desc= "136974",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111604] = {
        id= 111604,
        achi_name= "136452",
        achi_desc= "136975",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111704] = {
        id= 111704,
        achi_name= "136453",
        achi_desc= "136976",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[114204] = {
        id= 114204,
        achi_name= "136454",
        achi_desc= "136977",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115704] = {
        id= 115704,
        achi_name= "136455",
        achi_desc= "136978",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118104] = {
        id= 118104,
        achi_name= "136456",
        achi_desc= "136979",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118204] = {
        id= 118204,
        achi_name= "136457",
        achi_desc= "136980",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118304] = {
        id= 118304,
        achi_name= "136458",
        achi_desc= "136981",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[119604] = {
        id= 119604,
        achi_name= "136459",
        achi_desc= "136982",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[130504] = {
        id= 130504,
        achi_name= "136460",
        achi_desc= "136983",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135404] = {
        id= 135404,
        achi_name= "136461",
        achi_desc= "136984",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135704] = {
        id= 135704,
        achi_name= "136462",
        achi_desc= "136985",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135904] = {
        id= 135904,
        achi_name= "136463",
        achi_desc= "136986",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136004] = {
        id= 136004,
        achi_name= "136464",
        achi_desc= "136987",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136104] = {
        id= 136104,
        achi_name= "136465",
        achi_desc= "136988",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136304] = {
        id= 136304,
        achi_name= "136466",
        achi_desc= "136989",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137004] = {
        id= 137004,
        achi_name= "136467",
        achi_desc= "136990",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137404] = {
        id= 137404,
        achi_name= "136468",
        achi_desc= "136991",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137604] = {
        id= 137604,
        achi_name= "136469",
        achi_desc= "136992",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138004] = {
        id= 138004,
        achi_name= "136470",
        achi_desc= "136993",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138204] = {
        id= 138204,
        achi_name= "136471",
        achi_desc= "136994",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138304] = {
        id= 138304,
        achi_name= "136472",
        achi_desc= "136995",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138604] = {
        id= 138604,
        achi_name= "136473",
        achi_desc= "136996",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138704] = {
        id= 138704,
        achi_name= "136474",
        achi_desc= "136997",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138904] = {
        id= 138904,
        achi_name= "136475",
        achi_desc= "136998",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139404] = {
        id= 139404,
        achi_name= "136476",
        achi_desc= "136999",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140904] = {
        id= 140904,
        achi_name= "136477",
        achi_desc= "137000",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[101105] = {
        id= 101105,
        achi_name= "136478",
        achi_desc= "137001",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[102305] = {
        id= 102305,
        achi_name= "136479",
        achi_desc= "137002",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[103605] = {
        id= 103605,
        achi_name= "136480",
        achi_desc= "137003",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[103705] = {
        id= 103705,
        achi_name= "136481",
        achi_desc= "137004",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[105105] = {
        id= 105105,
        achi_name= "136482",
        achi_desc= "137005",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[106105] = {
        id= 106105,
        achi_name= "136483",
        achi_desc= "137006",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[106205] = {
        id= 106205,
        achi_name= "136484",
        achi_desc= "137007",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[107605] = {
        id= 107605,
        achi_name= "136485",
        achi_desc= "137008",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110105] = {
        id= 110105,
        achi_name= "136486",
        achi_desc= "137009",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110305] = {
        id= 110305,
        achi_name= "136487",
        achi_desc= "137010",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111605] = {
        id= 111605,
        achi_name= "136488",
        achi_desc= "137011",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111705] = {
        id= 111705,
        achi_name= "136489",
        achi_desc= "137012",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[114205] = {
        id= 114205,
        achi_name= "136490",
        achi_desc= "137013",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115705] = {
        id= 115705,
        achi_name= "136491",
        achi_desc= "137014",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118105] = {
        id= 118105,
        achi_name= "136492",
        achi_desc= "137015",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118205] = {
        id= 118205,
        achi_name= "136493",
        achi_desc= "137016",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118305] = {
        id= 118305,
        achi_name= "136494",
        achi_desc= "137017",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[119605] = {
        id= 119605,
        achi_name= "136495",
        achi_desc= "137018",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[130505] = {
        id= 130505,
        achi_name= "136496",
        achi_desc= "137019",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135405] = {
        id= 135405,
        achi_name= "136497",
        achi_desc= "137020",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135705] = {
        id= 135705,
        achi_name= "136498",
        achi_desc= "137021",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135905] = {
        id= 135905,
        achi_name= "136499",
        achi_desc= "137022",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136005] = {
        id= 136005,
        achi_name= "136500",
        achi_desc= "137023",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136105] = {
        id= 136105,
        achi_name= "136501",
        achi_desc= "137024",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136305] = {
        id= 136305,
        achi_name= "136502",
        achi_desc= "137025",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137005] = {
        id= 137005,
        achi_name= "136503",
        achi_desc= "137026",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137405] = {
        id= 137405,
        achi_name= "136504",
        achi_desc= "137027",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137605] = {
        id= 137605,
        achi_name= "136505",
        achi_desc= "137028",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138005] = {
        id= 138005,
        achi_name= "136506",
        achi_desc= "137029",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138205] = {
        id= 138205,
        achi_name= "136507",
        achi_desc= "137030",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138305] = {
        id= 138305,
        achi_name= "136508",
        achi_desc= "137031",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138605] = {
        id= 138605,
        achi_name= "136509",
        achi_desc= "137032",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138705] = {
        id= 138705,
        achi_name= "136510",
        achi_desc= "137033",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138905] = {
        id= 138905,
        achi_name= "136511",
        achi_desc= "137034",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139405] = {
        id= 139405,
        achi_name= "136512",
        achi_desc= "137035",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140905] = {
        id= 140905,
        achi_name= "136513",
        achi_desc= "137036",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[101106] = {
        id= 101106,
        achi_name= "136514",
        achi_desc= "137037",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[102306] = {
        id= 102306,
        achi_name= "136515",
        achi_desc= "137038",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[103606] = {
        id= 103606,
        achi_name= "136516",
        achi_desc= "137039",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[103706] = {
        id= 103706,
        achi_name= "136517",
        achi_desc= "137040",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[105106] = {
        id= 105106,
        achi_name= "136518",
        achi_desc= "137041",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[106106] = {
        id= 106106,
        achi_name= "136519",
        achi_desc= "137042",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[106206] = {
        id= 106206,
        achi_name= "136520",
        achi_desc= "137043",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[107606] = {
        id= 107606,
        achi_name= "136521",
        achi_desc= "137044",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110106] = {
        id= 110106,
        achi_name= "136522",
        achi_desc= "137045",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[110306] = {
        id= 110306,
        achi_name= "136523",
        achi_desc= "137046",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111606] = {
        id= 111606,
        achi_name= "136524",
        achi_desc= "137047",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[111706] = {
        id= 111706,
        achi_name= "136525",
        achi_desc= "137048",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[114206] = {
        id= 114206,
        achi_name= "136526",
        achi_desc= "137049",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115706] = {
        id= 115706,
        achi_name= "136527",
        achi_desc= "137050",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118106] = {
        id= 118106,
        achi_name= "136528",
        achi_desc= "137051",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118206] = {
        id= 118206,
        achi_name= "136529",
        achi_desc= "137052",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[118306] = {
        id= 118306,
        achi_name= "136530",
        achi_desc= "137053",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[119606] = {
        id= 119606,
        achi_name= "136531",
        achi_desc= "137054",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[130506] = {
        id= 130506,
        achi_name= "136532",
        achi_desc= "137055",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135406] = {
        id= 135406,
        achi_name= "136533",
        achi_desc= "137056",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135706] = {
        id= 135706,
        achi_name= "136534",
        achi_desc= "137057",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135906] = {
        id= 135906,
        achi_name= "136535",
        achi_desc= "137058",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136006] = {
        id= 136006,
        achi_name= "136536",
        achi_desc= "137059",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136106] = {
        id= 136106,
        achi_name= "136537",
        achi_desc= "137060",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136306] = {
        id= 136306,
        achi_name= "136538",
        achi_desc= "137061",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137006] = {
        id= 137006,
        achi_name= "136539",
        achi_desc= "137062",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137406] = {
        id= 137406,
        achi_name= "136540",
        achi_desc= "137063",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[137606] = {
        id= 137606,
        achi_name= "136541",
        achi_desc= "137064",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138006] = {
        id= 138006,
        achi_name= "136542",
        achi_desc= "137065",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138206] = {
        id= 138206,
        achi_name= "136543",
        achi_desc= "137066",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138306] = {
        id= 138306,
        achi_name= "136544",
        achi_desc= "137067",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138606] = {
        id= 138606,
        achi_name= "136545",
        achi_desc= "137068",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138706] = {
        id= 138706,
        achi_name= "136546",
        achi_desc= "137069",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138906] = {
        id= 138906,
        achi_name= "136547",
        achi_desc= "137070",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139406] = {
        id= 139406,
        achi_name= "136548",
        achi_desc= "137071",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140906] = {
        id= 140906,
        achi_name= "136549",
        achi_desc= "137072",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[220] = {
        id= 220,
        achi_name= "136550",
        achi_desc= "137073",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[221] = {
        id= 221,
        achi_name= "136551",
        achi_desc= "137074",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[222] = {
        id= 222,
        achi_name= "136552",
        achi_desc= "137075",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[223] = {
        id= 223,
        achi_name= "136553",
        achi_desc= "137076",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[224] = {
        id= 224,
        achi_name= "136554",
        achi_desc= "137077",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[225] = {
        id= 225,
        achi_name= "136555",
        achi_desc= "137078",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[226] = {
        id= 226,
        achi_name= "136556",
        achi_desc= "137079",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[230] = {
        id= 230,
        achi_name= "136557",
        achi_desc= "137080",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[231] = {
        id= 231,
        achi_name= "136558",
        achi_desc= "137081",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[232] = {
        id= 232,
        achi_name= "136559",
        achi_desc= "137082",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[233] = {
        id= 233,
        achi_name= "136560",
        achi_desc= "137083",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[234] = {
        id= 234,
        achi_name= "136561",
        achi_desc= "137084",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[235] = {
        id= 235,
        achi_name= "136562",
        achi_desc= "137085",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[236] = {
        id= 236,
        achi_name= "136563",
        achi_desc= "137086",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[237] = {
        id= 237,
        achi_name= "136564",
        achi_desc= "137087",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[240] = {
        id= 240,
        achi_name= "136565",
        achi_desc= "137088",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[241] = {
        id= 241,
        achi_name= "136566",
        achi_desc= "137089",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[242] = {
        id= 242,
        achi_name= "136567",
        achi_desc= "137090",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[243] = {
        id= 243,
        achi_name= "136568",
        achi_desc= "137091",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[244] = {
        id= 244,
        achi_name= "136569",
        achi_desc= "137092",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[245] = {
        id= 245,
        achi_name= "136570",
        achi_desc= "137093",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[246] = {
        id= 246,
        achi_name= "136571",
        achi_desc= "137094",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[247] = {
        id= 247,
        achi_name= "136572",
        achi_desc= "137095",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[248] = {
        id= 248,
        achi_name= "136573",
        achi_desc= "137096",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[249] = {
        id= 249,
        achi_name= "136574",
        achi_desc= "137097",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[250] = {
        id= 250,
        achi_name= "136575",
        achi_desc= "137098",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[251] = {
        id= 251,
        achi_name= "136576",
        achi_desc= "137099",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[252] = {
        id= 252,
        achi_name= "136577",
        achi_desc= "137100",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[253] = {
        id= 253,
        achi_name= "136578",
        achi_desc= "137101",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[254] = {
        id= 254,
        achi_name= "136579",
        achi_desc= "137102",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[255] = {
        id= 255,
        achi_name= "136580",
        achi_desc= "137103",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[256] = {
        id= 256,
        achi_name= "136581",
        achi_desc= "137104",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[260] = {
        id= 260,
        achi_name= "136582",
        achi_desc= "137105",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[261] = {
        id= 261,
        achi_name= "136583",
        achi_desc= "137106",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[262] = {
        id= 262,
        achi_name= "136584",
        achi_desc= "137107",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[263] = {
        id= 263,
        achi_name= "136585",
        achi_desc= "137108",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[264] = {
        id= 264,
        achi_name= "136586",
        achi_desc= "137109",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[265] = {
        id= 265,
        achi_name= "136587",
        achi_desc= "137110",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[266] = {
        id= 266,
        achi_name= "136588",
        achi_desc= "137111",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[267] = {
        id= 267,
        achi_name= "136589",
        achi_desc= "137112",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[270] = {
        id= 270,
        achi_name= "136590",
        achi_desc= "137113",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[271] = {
        id= 271,
        achi_name= "136591",
        achi_desc= "137114",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[272] = {
        id= 272,
        achi_name= "136592",
        achi_desc= "137115",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[273] = {
        id= 273,
        achi_name= "136593",
        achi_desc= "137116",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[274] = {
        id= 274,
        achi_name= "136594",
        achi_desc= "137117",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[275] = {
        id= 275,
        achi_name= "136595",
        achi_desc= "137118",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[276] = {
        id= 276,
        achi_name= "136596",
        achi_desc= "137119",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[277] = {
        id= 277,
        achi_name= "136597",
        achi_desc= "137120",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[278] = {
        id= 278,
        achi_name= "136598",
        achi_desc= "137121",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[279] = {
        id= 279,
        achi_name= "136599",
        achi_desc= "137122",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140701] = {
        id= 140701,
        achi_name= "136600",
        achi_desc= "137123",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140901] = {
        id= 140901,
        achi_name= "136601",
        achi_desc= "137124",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150601] = {
        id= 150601,
        achi_name= "136602",
        achi_desc= "137125",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136701] = {
        id= 136701,
        achi_name= "136603",
        achi_desc= "137126",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139701] = {
        id= 139701,
        achi_name= "136604",
        achi_desc= "137127",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135601] = {
        id= 135601,
        achi_name= "136605",
        achi_desc= "137128",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115602] = {
        id= 115602,
        achi_name= "136606",
        achi_desc= "137129",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115603] = {
        id= 115603,
        achi_name= "136607",
        achi_desc= "137130",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115604] = {
        id= 115604,
        achi_name= "136608",
        achi_desc= "137131",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[115606] = {
        id= 115606,
        achi_name= "136609",
        achi_desc= "137132",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40295] = {
        id= 40295,
        achi_name= "136610",
        achi_desc= "137133",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40296] = {
        id= 40296,
        achi_name= "136611",
        achi_desc= "137134",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40297] = {
        id= 40297,
        achi_name= "136612",
        achi_desc= "137135",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40298] = {
        id= 40298,
        achi_name= "136613",
        achi_desc= "137136",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40299] = {
        id= 40299,
        achi_name= "136614",
        achi_desc= "137137",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40300] = {
        id= 40300,
        achi_name= "136615",
        achi_desc= "137138",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40301] = {
        id= 40301,
        achi_name= "136616",
        achi_desc= "137139",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40302] = {
        id= 40302,
        achi_name= "136617",
        achi_desc= "137140",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40303] = {
        id= 40303,
        achi_name= "136618",
        achi_desc= "137141",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40304] = {
        id= 40304,
        achi_name= "136619",
        achi_desc= "137142",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40305] = {
        id= 40305,
        achi_name= "136620",
        achi_desc= "137143",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40306] = {
        id= 40306,
        achi_name= "136621",
        achi_desc= "137144",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40307] = {
        id= 40307,
        achi_name= "136622",
        achi_desc= "137145",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40308] = {
        id= 40308,
        achi_name= "136623",
        achi_desc= "137146",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40309] = {
        id= 40309,
        achi_name= "136624",
        achi_desc= "137147",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40310] = {
        id= 40310,
        achi_name= "136625",
        achi_desc= "137148",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40311] = {
        id= 40311,
        achi_name= "136626",
        achi_desc= "137149",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40312] = {
        id= 40312,
        achi_name= "136627",
        achi_desc= "137150",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40313] = {
        id= 40313,
        achi_name= "136628",
        achi_desc= "137151",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40314] = {
        id= 40314,
        achi_name= "136629",
        achi_desc= "137152",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40315] = {
        id= 40315,
        achi_name= "136630",
        achi_desc= "137153",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40316] = {
        id= 40316,
        achi_name= "136631",
        achi_desc= "137154",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40317] = {
        id= 40317,
        achi_name= "136632",
        achi_desc= "137155",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40318] = {
        id= 40318,
        achi_name= "136633",
        achi_desc= "137156",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40319] = {
        id= 40319,
        achi_name= "136634",
        achi_desc= "137157",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40320] = {
        id= 40320,
        achi_name= "136635",
        achi_desc= "137158",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40321] = {
        id= 40321,
        achi_name= "136636",
        achi_desc= "137159",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40322] = {
        id= 40322,
        achi_name= "136637",
        achi_desc= "137160",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40323] = {
        id= 40323,
        achi_name= "136638",
        achi_desc= "137161",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40324] = {
        id= 40324,
        achi_name= "136639",
        achi_desc= "137162",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40325] = {
        id= 40325,
        achi_name= "136640",
        achi_desc= "137163",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40326] = {
        id= 40326,
        achi_name= "136641",
        achi_desc= "137164",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40327] = {
        id= 40327,
        achi_name= "136642",
        achi_desc= "137165",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40328] = {
        id= 40328,
        achi_name= "136643",
        achi_desc= "137166",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40329] = {
        id= 40329,
        achi_name= "136644",
        achi_desc= "137167",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40330] = {
        id= 40330,
        achi_name= "136645",
        achi_desc= "137168",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40331] = {
        id= 40331,
        achi_name= "136646",
        achi_desc= "137169",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40332] = {
        id= 40332,
        achi_name= "136647",
        achi_desc= "137170",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40333] = {
        id= 40333,
        achi_name= "136648",
        achi_desc= "137171",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40334] = {
        id= 40334,
        achi_name= "136649",
        achi_desc= "137172",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40335] = {
        id= 40335,
        achi_name= "136650",
        achi_desc= "137173",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40336] = {
        id= 40336,
        achi_name= "136651",
        achi_desc= "137174",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40337] = {
        id= 40337,
        achi_name= "136652",
        achi_desc= "137175",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40338] = {
        id= 40338,
        achi_name= "136653",
        achi_desc= "137176",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40339] = {
        id= 40339,
        achi_name= "136654",
        achi_desc= "137177",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40340] = {
        id= 40340,
        achi_name= "136655",
        achi_desc= "137178",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40341] = {
        id= 40341,
        achi_name= "136656",
        achi_desc= "137179",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40342] = {
        id= 40342,
        achi_name= "136657",
        achi_desc= "137180",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40343] = {
        id= 40343,
        achi_name= "136658",
        achi_desc= "137181",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40344] = {
        id= 40344,
        achi_name= "136659",
        achi_desc= "137182",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40345] = {
        id= 40345,
        achi_name= "136660",
        achi_desc= "137183",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[40346] = {
        id= 40346,
        achi_name= "136661",
        achi_desc= "137184",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50347] = {
        id= 50347,
        achi_name= "136662",
        achi_desc= "137185",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50348] = {
        id= 50348,
        achi_name= "136663",
        achi_desc= "137186",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50349] = {
        id= 50349,
        achi_name= "136664",
        achi_desc= "137187",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50350] = {
        id= 50350,
        achi_name= "136665",
        achi_desc= "137188",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50351] = {
        id= 50351,
        achi_name= "136666",
        achi_desc= "137189",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50352] = {
        id= 50352,
        achi_name= "136667",
        achi_desc= "137190",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50353] = {
        id= 50353,
        achi_name= "136668",
        achi_desc= "137191",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50354] = {
        id= 50354,
        achi_name= "136669",
        achi_desc= "137192",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50355] = {
        id= 50355,
        achi_name= "136670",
        achi_desc= "137193",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50356] = {
        id= 50356,
        achi_name= "136671",
        achi_desc= "137194",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50357] = {
        id= 50357,
        achi_name= "136672",
        achi_desc= "137195",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50358] = {
        id= 50358,
        achi_name= "136673",
        achi_desc= "137196",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50359] = {
        id= 50359,
        achi_name= "136674",
        achi_desc= "137197",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50360] = {
        id= 50360,
        achi_name= "136675",
        achi_desc= "137198",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[50361] = {
        id= 50361,
        achi_name= "136676",
        achi_desc= "137199",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138502] = {
        id= 138502,
        achi_name= "136677",
        achi_desc= "137200",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[138503] = {
        id= 138503,
        achi_name= "136678",
        achi_desc= "137201",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5347] = {
        id= 5347,
        achi_name= "136679",
        achi_desc= "137202",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5348] = {
        id= 5348,
        achi_name= "136680",
        achi_desc= "137203",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5349] = {
        id= 5349,
        achi_name= "136681",
        achi_desc= "137204",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5350] = {
        id= 5350,
        achi_name= "136682",
        achi_desc= "137205",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5351] = {
        id= 5351,
        achi_name= "136683",
        achi_desc= "137206",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5352] = {
        id= 5352,
        achi_name= "136684",
        achi_desc= "137207",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5353] = {
        id= 5353,
        achi_name= "136685",
        achi_desc= "137208",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5354] = {
        id= 5354,
        achi_name= "136686",
        achi_desc= "137209",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5355] = {
        id= 5355,
        achi_name= "136687",
        achi_desc= "137210",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5356] = {
        id= 5356,
        achi_name= "136688",
        achi_desc= "137211",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5357] = {
        id= 5357,
        achi_name= "136689",
        achi_desc= "137212",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5358] = {
        id= 5358,
        achi_name= "136690",
        achi_desc= "137213",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5359] = {
        id= 5359,
        achi_name= "136691",
        achi_desc= "137214",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5360] = {
        id= 5360,
        achi_name= "136692",
        achi_desc= "137215",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5361] = {
        id= 5361,
        achi_name= "136693",
        achi_desc= "137216",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5362] = {
        id= 5362,
        achi_name= "136694",
        achi_desc= "137217",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5363] = {
        id= 5363,
        achi_name= "136695",
        achi_desc= "137218",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5364] = {
        id= 5364,
        achi_name= "136696",
        achi_desc= "137219",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5365] = {
        id= 5365,
        achi_name= "136697",
        achi_desc= "137220",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5366] = {
        id= 5366,
        achi_name= "136698",
        achi_desc= "137221",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5367] = {
        id= 5367,
        achi_name= "136699",
        achi_desc= "137222",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5368] = {
        id= 5368,
        achi_name= "136700",
        achi_desc= "137223",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5369] = {
        id= 5369,
        achi_name= "136701",
        achi_desc= "137224",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[5370] = {
        id= 5370,
        achi_name= "136702",
        achi_desc= "137225",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140301] = {
        id= 140301,
        achi_name= "136703",
        achi_desc= "137226",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141101] = {
        id= 141101,
        achi_name= "136704",
        achi_desc= "137227",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160001] = {
        id= 160001,
        achi_name= "136705",
        achi_desc= "137228",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160301] = {
        id= 160301,
        achi_name= "136706",
        achi_desc= "137229",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160006] = {
        id= 160006,
        achi_name= "136707",
        achi_desc= "137230",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160306] = {
        id= 160306,
        achi_name= "136708",
        achi_desc= "137231",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160004] = {
        id= 160004,
        achi_name= "136709",
        achi_desc= "137232",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160304] = {
        id= 160304,
        achi_name= "136710",
        achi_desc= "137233",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160005] = {
        id= 160005,
        achi_name= "136711",
        achi_desc= "137234",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160305] = {
        id= 160305,
        achi_name= "136712",
        achi_desc= "137235",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160201] = {
        id= 160201,
        achi_name= "136713",
        achi_desc= "137236",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160401] = {
        id= 160401,
        achi_name= "136714",
        achi_desc= "137237",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160206] = {
        id= 160206,
        achi_name= "136715",
        achi_desc= "137238",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160406] = {
        id= 160406,
        achi_name= "136716",
        achi_desc= "137239",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160204] = {
        id= 160204,
        achi_name= "136717",
        achi_desc= "137240",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160404] = {
        id= 160404,
        achi_name= "136718",
        achi_desc= "137241",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160205] = {
        id= 160205,
        achi_name= "136719",
        achi_desc= "137242",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160405] = {
        id= 160405,
        achi_name= "136720",
        achi_desc= "137243",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160101] = {
        id= 160101,
        achi_name= "136721",
        achi_desc= "137244",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160106] = {
        id= 160106,
        achi_name= "136722",
        achi_desc= "137245",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160104] = {
        id= 160104,
        achi_name= "136723",
        achi_desc= "137246",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160105] = {
        id= 160105,
        achi_name= "136724",
        achi_desc= "137247",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160501] = {
        id= 160501,
        achi_name= "136725",
        achi_desc= "137248",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160506] = {
        id= 160506,
        achi_name= "136726",
        achi_desc= "137249",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160504] = {
        id= 160504,
        achi_name= "136727",
        achi_desc= "137250",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[160505] = {
        id= 160505,
        achi_name= "136728",
        achi_desc= "137251",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152701] = {
        id= 152701,
        achi_name= "136729",
        achi_desc= "137252",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141301] = {
        id= 141301,
        achi_name= "136730",
        achi_desc= "137253",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140201] = {
        id= 140201,
        achi_name= "136731",
        achi_desc= "137254",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139201] = {
        id= 139201,
        achi_name= "136732",
        achi_desc= "137255",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140601] = {
        id= 140601,
        achi_name= "136733",
        achi_desc= "137256",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139504] = {
        id= 139504,
        achi_name= "136734",
        achi_desc= "137257",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139505] = {
        id= 139505,
        achi_name= "136735",
        achi_desc= "137258",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139506] = {
        id= 139506,
        achi_name= "136736",
        achi_desc= "137259",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140504] = {
        id= 140504,
        achi_name= "136737",
        achi_desc= "137260",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140506] = {
        id= 140506,
        achi_name= "136738",
        achi_desc= "137261",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139501] = {
        id= 139501,
        achi_name= "136739",
        achi_desc= "137262",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150401] = {
        id= 150401,
        achi_name= "136740",
        achi_desc= "137263",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141001] = {
        id= 141001,
        achi_name= "136741",
        achi_desc= "137264",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150001] = {
        id= 150001,
        achi_name= "136742",
        achi_desc= "137265",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150101] = {
        id= 150101,
        achi_name= "136743",
        achi_desc= "137266",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140704] = {
        id= 140704,
        achi_name= "136744",
        achi_desc= "137267",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140706] = {
        id= 140706,
        achi_name= "136745",
        achi_desc= "137268",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153001] = {
        id= 153001,
        achi_name= "603001",
        achi_desc= "603011",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153101] = {
        id= 153101,
        achi_name= "603002",
        achi_desc= "603012",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153201] = {
        id= 153201,
        achi_name= "603003",
        achi_desc= "603013",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152901] = {
        id= 152901,
        achi_name= "603004",
        achi_desc= "603014",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152801] = {
        id= 152801,
        achi_name= "603005",
        achi_desc= "603015",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153004] = {
        id= 153004,
        achi_name= "603016",
        achi_desc= "603019",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153006] = {
        id= 153006,
        achi_name= "603017",
        achi_desc= "603020",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153005] = {
        id= 153005,
        achi_name= "603018",
        achi_desc= "603021",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139704] = {
        id= 139704,
        achi_name= "603026",
        achi_desc= "603028",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139706] = {
        id= 139706,
        achi_name= "603027",
        achi_desc= "603029",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140304] = {
        id= 140304,
        achi_name= "603022",
        achi_desc= "603024",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140306] = {
        id= 140306,
        achi_name= "603023",
        achi_desc= "603025",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152501] = {
        id= 152501,
        achi_name= "601286",
        achi_desc= "300011",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152401] = {
        id= 152401,
        achi_name= "601287",
        achi_desc= "300012",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[135501] = {
        id= 135501,
        achi_name= "614560",
        achi_desc= "300014",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141304] = {
        id= 141304,
        achi_name= "614599",
        achi_desc= "614602",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[141305] = {
        id= 141305,
        achi_name= "614600",
        achi_desc= "614603",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[170001] = {
        id= 170001,
        achi_name= "614741",
        achi_desc= "300015",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[170201] = {
        id= 170201,
        achi_name= "614742",
        achi_desc= "300016",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[170301] = {
        id= 170301,
        achi_name= "614743",
        achi_desc= "300017",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[170501] = {
        id= 170501,
        achi_name= "614745",
        achi_desc= "300019",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[139301] = {
        id= 139301,
        achi_name= "614746",
        achi_desc= "300020",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[102401] = {
        id= 102401,
        achi_name= "615568",
        achi_desc= "100004",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[151101] = {
        id= 151101,
        achi_name= "615743",
        achi_desc= "300021",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150301] = {
        id= 150301,
        achi_name= "615744",
        achi_desc= "300022",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153401] = {
        id= 153401,
        achi_name= "615745",
        achi_desc= "300023",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[151401] = {
        id= 151401,
        achi_name= "616179",
        achi_desc= "300024",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[151301] = {
        id= 151301,
        achi_name= "616153",
        achi_desc= "300025",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[136610] = {
        id= 136610,
        achi_name= "616205",
        achi_desc= "300026",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152904] = {
        id= 152904,
        achi_name= "616507",
        achi_desc= "616509",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152906] = {
        id= 152906,
        achi_name= "616508",
        achi_desc= "616510",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[151910] = {
        id= 151910,
        achi_name= "616676",
        achi_desc= "300027",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152010] = {
        id= 152010,
        achi_name= "616677",
        achi_desc= "300028",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[150210] = {
        id= 150210,
        achi_name= "616928",
        achi_desc= "300029",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153510] = {
        id= 153510,
        achi_name= "616929",
        achi_desc= "300030",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152804] = {
        id= 152804,
        achi_name= "617067",
        achi_desc= "617069",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[152806] = {
        id= 152806,
        achi_name= "617068",
        achi_desc= "617070",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153810] = {
        id= 153810,
        achi_name= "617178",
        achi_desc= "300031",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[154010] = {
        id= 154010,
        achi_name= "617179",
        achi_desc= "300032",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153910] = {
        id= 153910,
        achi_name= "617475",
        achi_desc= "300033",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[154110] = {
        id= 154110,
        achi_name= "617476",
        achi_desc= "300034",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153710] = {
        id= 153710,
        achi_name= "617789",
        achi_desc= "300035",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153204] = {
        id= 153204,
        achi_name= "617790",
        achi_desc= "617794",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[153206] = {
        id= 153206,
        achi_name= "617791",
        achi_desc= "617795",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140604] = {
        id= 140604,
        achi_name= "617792",
        achi_desc= "617796",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[140606] = {
        id= 140606,
        achi_name= "617793",
        achi_desc= "617797",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[151610] = {
        id= 151610,
        achi_name= "618035",
        achi_desc= "300036",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[154210] = {
        id= 154210,
        achi_name= "618036",
        achi_desc= "300037",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[154310] = {
        id= 154310,
        achi_name= "618168",
        achi_desc= "300038",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_everyday_conf[154410] = {
        id= 154410,
        achi_name= "618211",
        achi_desc= "300039",
        achi_icon= "icons/achiv/cjxt_001.png",

} 