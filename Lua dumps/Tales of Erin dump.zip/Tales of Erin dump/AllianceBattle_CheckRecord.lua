
AllianceBattle_CheckRecord = class("AllianceBattle_CheckRecord", function()
    return cc.Node:create()
end)

function AllianceBattle_CheckRecord:ctor(datalist,guildName)
    local rootNode= cc.CSLoader:createNode("AllianceBattle_CheckRecordDialog.csb");
    self.rootPanel = rootNode:getChildByTag(51)
    self:addChild(rootNode)

    self:initListView(datalist,guildName);

    local closeBtn = self.rootPanel:getChildByTag(146);
    closeBtn:addClickEventListener(function()
        self:removeFromParent();
    end)
end

function AllianceBattle_CheckRecord:initListView(datalist,guildName)
    local listview = self.rootPanel:getChildByTag(52)

    for i = 1,#datalist do
        listview:pushBackCustomItem(self:createOneBlock(datalist[i],guildName));
    end
end

function AllianceBattle_CheckRecord:createOneBlock(data,guildName)
    local layout = ccui.Layout:create()
    layout:setContentSize(772,146);
    layout:setTouchEnabled(false);

    local item = cc.CSLoader:createNode("AllianceBattle_CheckRecordListBlock.csb");
    item:setPosition(10,0)
    layout:addChild(item)

    local winTable = {}
    local loseTable = {}

    winTable[1] = item:getChildByTag(65)
    winTable[2] = item:getChildByTag(66)
    loseTable[1] = item:getChildByTag(67)
    loseTable[2] = item:getChildByTag(68)

    if data.contribution_allience_self > data.contribution_allience_enemy then
        winTable[1]:setVisible(true)
        winTable[2]:setVisible(false)
        loseTable[1]:setVisible(false)
        loseTable[2]:setVisible(true)
    elseif data.contribution_allience_self < data.contribution_allience_enemy then
        winTable[1]:setVisible(false)
        winTable[2]:setVisible(true)
        loseTable[1]:setVisible(true)
        loseTable[2]:setVisible(false)
    else
        winTable[1]:setVisible(false)
        winTable[2]:setVisible(false)
        loseTable[1]:setVisible(true)
        loseTable[2]:setVisible(true)        
    end

    item:getChildByTag(58):setString(guildName);--我方公会名称
    item:getChildByTag(59):setString(data.name_enemy);--对手公会名称
    item:getChildByTag(76):setString(data.day);--第几回合
    item:getChildByTag(62):setString(data.contribution_allience_self);--我方贡献值
    item:getChildByTag(64):setString(data.contribution_allience_enemy);--对手贡献值
    item:getChildByTag(69):setString(user_info.name);--玩家昵称
    item:getChildByTag(74):setString(data.contribution_single);--玩家贡献值

    return layout
end