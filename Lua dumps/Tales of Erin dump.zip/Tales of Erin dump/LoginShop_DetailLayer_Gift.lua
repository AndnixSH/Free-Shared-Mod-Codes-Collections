--付费登陆的礼包详情界面
LoginShop_DetailLayer_Gift = class("LoginShop_DetailLayer_Gift", function()
    return cc.Layer:create();
end);

--@isAvailable,是否可购买
function LoginShop_DetailLayer_Gift:ctor(data,fatherLayer,isAvailable)
    self.data = data
    self.fatherLayer = fatherLayer
    self.isAvailable = isAvailable
    self:init()
end

function LoginShop_DetailLayer_Gift:init()
    self.rootNode = cc.CSLoader:createNode("LoginShop_DetailLayer_Gift.csb")
    self:addChild(self.rootNode)

    -- 获取到到ListView
    self.panel      = self.rootNode:getChildByName("Panel_1")
    -- ListView
    self.ListView    = self.panel:getChildByName("Image_list_bg"):getChildByName("ListView_1")

    self:SetListView()

    self:setPanelInfo()
end

-- 初始hua list模板
function LoginShop_DetailLayer_Gift:initModel()

    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("GiftShowListNode.csb")
    local  item_1 = list_item:getChildByName("Panel_1")
    local item_c = item_1:clone()
    item_c:setPosition(cc.p(0,0))
    item_c:setName("item")
    layout_list:addChild(item_c)
    layout_list:setContentSize(460,108)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)
end

-- 获取list的Item 设置item的属性信息
function LoginShop_DetailLayer_Gift:SetListView()
    self:initModel()

    self.Table = gift[tonumber(self.data.product_id_local)]
    -- 获取装载Item的list长度
    local len = #self.Table["reward"]
    for i = 1 , len do
        self.ListView:pushBackDefaultItem()
    end
    -- 取出item 进行赋值
    for i = 1 , len do
        local tab     = self.Table["reward"][i]
        local itemEl  = self.ListView:getItem(i - 1)
        local item_1  = itemEl:getChildByName("item")

        local data  = {
            ["item_id"]   = self.Table["reward"][i]["id"],
            ["item_type"] = self.Table["reward"][i]["type"],
            ["item_num"]  = self.Table["reward"][i]["num"],
        }
        local popr = UITool.getItemInfos(data.item_type,data.item_id)

        --获取item属性进行赋值
        --  BG 所有属性的父节点
        local  image_bg   = item_1:getChildByName("Image_bg")
        --icon 背景
        local  icon_bg    = image_bg:getChildByName("Image_iconbg")
        icon_bg:loadTexture(popr[4])
        -- 图片
        local  icon       = image_bg:getChildByName("Image_icon")
        icon:loadTexture(popr[2])
        icon:setUnifySizeEnabled(true)
        --图片属性框
        local  icon_form  = image_bg:getChildByName("Image_form")
        icon_form:loadTexture(popr[1])
        -- 名字
        local  icon_name  = image_bg:getChildByName("Text_Name")
        icon_name:setString(popr[5])
        -- 描述
        local  iocn_dec   = image_bg:getChildByName("Text_dec")

        --改变礼包node 中的描述字体大小
        if g_channel_control.transform_GiftShowListLayer_Text_dec_fontSize == true then
            iocn_dec:setFontSize(18)
            iocn_dec:setContentSize(280,45)
            iocn_dec:setPosition(122, 13)
        end

        iocn_dec:setString(popr[6])

        -- 属性求
        if popr[3] ~= "" then
            local elementImg = cc.Sprite:create(popr[3])
            elementImg:setAnchorPoint(cc.p(1,1))
            elementImg:setPosition(icon_form:getContentSize().width,icon_form:getContentSize().height)
            elementImg:setScale(0.7)
            icon_form:addChild(elementImg,100,100)
        elseif popr[3] == "" or popr[3] == nil or popr[3] == 0 then
            icon_form:removeChildByTag(100)
        end
        -- 数量
        local  num        = image_bg:getChildByName("Text_number")
        num:setString(data["item_num"])
    end
end

-- 弹出框上显示的 除了Item 以外的属性信息
function LoginShop_DetailLayer_Gift:setPanelInfo()

    local product = gift[self.data.product_id_local]

    -- 图标背景
    local icon_bg    = self.panel:getChildByName("Image_icon_bg")
    icon_bg:loadTexture(Rarity_BG[product.rarity])

    -- 图标
    local icon       = self.panel:getChildByName("Image_icon")
    icon:loadTexture("icons/mat/"..product.icon)
    icon:setUnifySizeEnabled(true)
    -- 图标属性框
    local icon_form  = self.panel:getChildByName("Image_icon_form")
    icon_form:loadTexture(Rarity_mat[product.rarity])
    -- 消耗人民币数量
    local cost_gem   = self.panel:getChildByName("Text_number")
    cost_gem:setString(self.data.cost)
    -- 消耗类型的图标
    local Image_cost =  self.panel:getChildByName("Image_gem")
    Image_cost:setUnifySizeEnabled(true)
    Image_cost:loadTexture(UITool:Coin_type(14))
    -- 礼包的名字
    local gift_name  = self.panel:getChildByName("Text_gift_name")
    gift_name:setString(UITool.getUserLanguage(self.Table["name"]))

    self.panel:getChildByName("Text_buy_cishu"):setVisible(false)

    --如果是补买，显示补买消耗的星石
    local cost_gem_0   = self.panel:getChildByName("Text_number_0")
    local Image_cost_0 =  self.panel:getChildByName("Image_gem_0")
    local isNotEnoughGem = false   --有偿钻石不够
    if self.data.product_state == 3 then
        cost_gem_0:setVisible(true)
        Image_cost_0:setVisible(true)
        cost_gem_0:setString(self.data.star_needed)
        -- 消耗类型的图标
        Image_cost_0:setUnifySizeEnabled(true)
        Image_cost_0:loadTexture(UITool:Coin_type(2))

        --如果有偿钻石不够
        if user_info["gem_r"] < self.data.star_needed then
            isNotEnoughGem = true
            cost_gem_0:setColor(cc.c3b(255, 0, 0))
        end
    else
        cost_gem_0:setVisible(false)
        Image_cost_0:setVisible(false)
    end

    -- 购买按钮
    local buy_btn    = self.panel:getChildByName("Button_buy")
    if not self.isAvailable or isNotEnoughGem then
        buy_btn:setEnabled(false)
    else
        buy_btn:addClickEventListener(function ()
            self:showConfirmDialog()
        end)
    end

    -- 取消按钮
    local cancle_btn = self.panel:getChildByName("Button_cancel")
    cancle_btn:addClickEventListener(function ()
        self:removeFromParent()
    end)

end

--点击购买按钮,弹出二次确认窗口
--二级弹窗：MsgWithTwoButtons.csb
function LoginShop_DetailLayer_Gift:showConfirmDialog()
    local confirmLayer = cc.CSLoader:createNode("MsgWithTwoButtons.csb")
    self:addChild(confirmLayer)

    local panel = confirmLayer:getChildByName("Panel")

    local contentText = panel:getChildByName("Text_dec")
    local currency_type = UITool.ToLocalization("美元")
    local str = string.format(UITool.ToLocalization("是否花费%s%s购买礼包"),tostring(self.data.cost),currency_type)
    contentText:setString(str)

    local this = self

    --付费后发送productIdx
    local function sendProductIdx()
        local tempTable = {}
        tempTable["rpc"] = "loginshop_deductingstars"
        tempTable["productidx"] = this.data.product_puid

        GameManagerInst:rpc(tempTable,
            3,
            function(data)
                --success
                print("扣除星石成功")
                this.fatherLayer:requestData(true)
                this:removeFromParent()
            end,
            function(state_code,msgText)
                --failed
                SceneManager:delWaitLayer()
                print("扣除星石失败")
                GameManagerInst:alert(msgText)
            end,
        true)        
    end

    --付费回调
    local function payCallback(state)
        if state == "SUCCESS" then 
            sendProductIdx()
        else
            SceneManager:delWaitLayer()
            print("付费登陆支付失败")
        end
    end
    --[[
    local function test()
       --测试
        local tempTable = {}
        tempTable["rpc"] = "loginshop_test"

        GameManagerInst:rpc(tempTable,
            3,
            function(data)
                --success
                print("付费成功")
                sendProductIdx()
                --this.fatherLayer:requestData(true)
            end,
            function(state_code,msgText)
                --failed
                SceneManager:delWaitLayer()
                print("付费失败")
                GameManagerInst:alert(msgText)
            end,
        true)
    end
    ]]

    -- 购买按钮
    local confirm_btn = panel:getChildByName("Button_confirm")
    confirm_btn:addClickEventListener(function ()
       local product = {}
       product.product_id = this.data.product_puid

       SceneManager:createWaitLayer()--开启屏蔽层
       SDKManagerLua:buyItem(product,payCallback)
       --test()
    end)

    -- 取消按钮
    local cancle_btn = panel:getChildByName("Button_cancle")
    cancle_btn:addClickEventListener(function ()
        confirmLayer:removeFromParent()
    end)
end