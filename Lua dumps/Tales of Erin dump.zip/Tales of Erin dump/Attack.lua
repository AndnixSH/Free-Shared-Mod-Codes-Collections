Attack = {} 
Attack[1] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound =""
} 
Attack[2] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjishui/Jinzhanzhongjishui.atlas",
    skill_sound =""
} 
Attack[3] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        25,25,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjishui/Jinzhanzhongjishui.atlas",
    skill_sound =""
} 
Attack[4] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound =""
} 
Attack[5] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjihuo/Jinzhanzhongjihuo.atlas",
    skill_sound =""
} 
Attack[6] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        25,25,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjihuo/Jinzhanzhongjihuo.atlas",
    skill_sound =""
} 
Attack[7] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanfeng/Jinzhanfeng.atlas",
    skill_sound =""
} 
Attack[8] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjifeng/Jinzhanzhongjifeng.atlas",
    skill_sound =""
} 
Attack[9] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        25,25,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjifeng/Jinzhanzhongjifeng.atlas",
    skill_sound =""
} 
Attack[10] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound =""
} 
Attack[11] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjiguang/Jinzhanzhongjiguang.atlas",
    skill_sound =""
} 
Attack[12] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        25,25,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjiguang/Jinzhanzhongjiguang.atlas",
    skill_sound =""
} 
Attack[13] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[14] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[15] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        25,25,50
    },
    skill_dmg = 300,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanzhongjian/Jinzhanzhongjian.atlas",
    skill_sound =""
} 
Attack[101] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongshui/Yuanchengpugongshui.atlas",
    skill_sound =""
} 
Attack[104] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugonghuo/Yuanchengpugonghuo.atlas",
    skill_sound =""
} 
Attack[107] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongfeng/Yuanchengpugongfeng.atlas",
    skill_sound =""
} 
Attack[110] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongguang/Yuanchengpugongguang.atlas",
    skill_sound =""
} 
Attack[113] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongan/Yuanchengpugongan.atlas",
    skill_sound =""
} 
Attack[124] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Jingjieshou/Jingjieshouenemyattackeffect/Jingjieshouenemyattackeffect.atlas",
    skill_sound =""
} 
Attack[201] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound =""
} 
Attack[202] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongshui/Yuanchengpugongshui.atlas",
    skill_sound =""
} 
Attack[205] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound =""
} 
Attack[206] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongshui/Yuanchengpugongshui.atlas",
    skill_sound =""
} 
Attack[209] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound =""
} 
Attack[210] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongfeng/Yuanchengpugongfeng.atlas",
    skill_sound =""
} 
Attack[213] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound =""
} 
Attack[217] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound =""
} 
Attack[301] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Naipugongjiaxue/Naipugongjiaxue.atlas",
    skill_sound =""
} 
Attack[314] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="",
    skill_sound =""
} 
Attack[315] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_feng/fly_feng.atlas", -- 飞行道具类的飞行特效
    res_hit ="",
    skill_sound =""
} 
Attack[320] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 10,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Xinghunlingyuancheng/Xinghunlingenemyattackeffect/Xinghunling_enemyattackeffect.atlas",
    skill_sound =""
} 
Attack[321] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Maou/Maouenemysingleattackeffect/Maouenemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[327] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Wangguoqiangbing/Wangguoqiangbingenemysingleattackeffect/Wangguoqiangbingenemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[328] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Xinghunlingyuancheng/Xinghunlingyuanchengenemyattackeffect/Xinghunlingyuanchengenemyattackeffect.atlas",
    skill_sound =""
} 
Attack[329] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound =""
} 
Attack[330] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Lifa/Lifaenemysingleattackeffect/Lifaenemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[331] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Shuguai/Shuguaienemysingleattackeffect/Shuguaienemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[332] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[333] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Milafusi/Milafusienemysingleattackeffect/Milafusienemysingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound =""
} 
Attack[334] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[335] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[337] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/monster/Longzhijuanshunv/Longzhijuanshunvenemysingleattackeffect/Longzhijuanshunvenemysingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound =""
} 
Attack[338] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/monster/Momv1/Monv1enemysingleattackeffect/Monv1enemysingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound =""
} 
Attack[339] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound =""
} 
Attack[340] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Tiyamate/Tiyamateenemysingleattackeffect/Tiyamateenemysingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongguang/Yuanchengpugongguang.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[341] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Meiya2/Meiya2enemysingleattackeffect/Meiya2enemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[342] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo1/Jinzhanhuo1.atlas",
    skill_sound =""
} 
Attack[344] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/flygong_an/flygong_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongan/Yuanchengpugongan.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[345] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[346] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/flygong_huo/flygong_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugonghuo/Yuanchengpugonghuo.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[347] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[348] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[349] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[350] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_feng/fly_feng.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[351] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_shui/fly_shui.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[352] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[353] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanfeng/Jinzhanfeng.atlas",
    skill_sound =""
} 
Attack[354] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/flygong_shui/flygong_shui.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongshui/Yuanchengpugongshui.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[355] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/flygong_feng/flygong_feng.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongfeng/Yuanchengpugongfeng.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[356] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_feng/fly_feng.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[357] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[358] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_shui/fly_shui.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[359] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[360] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound =""
} 
Attack[361] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_guang/fly_guang.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[362] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/flygong_guang/flygong_guang.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongguang/Yuanchengpugongguang.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[363] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound =""
} 
Attack[364] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Kelisi/Kelisiprojectsingleattackeffect/Kelisiprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[365] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Lianyue/Lianyueprojectsingleattackeffect/Lianyueprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound =""
} 
Attack[366] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[367] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanfeng/Jinzhanfeng.atlas",
    skill_sound =""
} 
Attack[368] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[369] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound =""
} 
Attack[370] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound =""
} 
Attack[371] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[372] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound =""
} 
Attack[373] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound =""
} 
Attack[374] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound =""
} 
Attack[375] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound =""
} 
Attack[376] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/mimilu/mimiluprojectilesingleattackeffect/mimiluprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound ="music/heropugong/hero381pg.mp3"
} 
Attack[377] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/flygong_an/flygong_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongan/Yuanchengpugongan.atlas",
    skill_sound =""
} 
Attack[378] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_feng/fly_feng.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[379] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Halubi/halubiprojectsingleattackeffect/halubiprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[380] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fuyin/fuyinprojectsingleattackeffect/fuyinprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[381] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanfeng/Jinzhanfeng.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[382] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound =""
} 
Attack[383] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/hero378pg.mp3"
} 
Attack[384] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound =""
} 
Attack[385] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/monster/Emoyuanchengbing/Emoyuanchengbingprojectsingleattackeffect/Emoyuanchengbingprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[386] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Lijie/Lijiesingleattackfeidao/Lijiesingleattackfeidao.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[387] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_feng/fly_feng.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[388] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Kuisha/Kuishaprojectsingleattackeffect/Kuishaprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[389] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Aijiang/Aijiangdandaoeffect/Aijiangdandaoeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Aijiang/Aijiangsinleattackeffect/Aijiangsinleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[390] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/monster/Tuzinubing/Tuzinubingprojectsingleattackeffect/Tuzinubingprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yuanchengpugongfeng/Yuanchengpugongfeng.atlas",
    skill_sound ="music/heropugong/yuanchengmingzhong.mp3"
} 
Attack[391] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Wutejia/Wutejiabossenemybigskilleffect2/Wutejiabossenemybigskilleffect2.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanfeng/Jinzhanfeng.atlas",
    skill_sound ="music/monsterskillaudio/a20114.mp3"
} 
Attack[392] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Luoleilai/Luoleilaiprojectsingleattackeffect/Luoleilaiprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[393] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound ="music/heropugong/hero397pg.mp3"
} 
Attack[394] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Leila/Leilaprojectsingleattackeffect/Leilaprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[395] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,25
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[396] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Youna/Younaprojectsingleattackeffect/Younaprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[397] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound ="music/heropugong/hero411pg.mp3"
} 
Attack[398] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanan/Jinzhanan.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[399] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Labisi/Labisiprojectsingleattackeffect/Labisiprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[400] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[401] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/IA/IAprojectsingleattackeffect/IAprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/IA/IAenemyattackeffect/IAenemyattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[402] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Xuena/Xuenaenemyattackeffect/Xuenaenemyattackeffect.atlas",
    skill_sound ="music/heropugong/hero402pg.mp3"
} 
Attack[10406] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Sala/Salaprojectsingleattackeffect/Salaprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10410] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 0,--害数量伤
    res_fly ="armatures/role/Younuo/Younuoprojectsingleattackeffect/Younuoprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10501] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Yingshi/Yingshiprojectsingleattackeffect/Yingshiprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10398] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10353] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10506] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10600] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Leiqier/Leiqierenemysingleattackeffect/Leiqierenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/hero600pg.mp3"
} 
Attack[10601] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        20
    },
    skill_dmg = 20,--害数量伤
    res_fly ="armatures/role/Nine/Nineprojectsingleattackeffect/Nineprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Nine/Nineenemybigskilleffect/Nineenemybigskilleffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10602] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jin/Jinenemysingleattackeffect/Jinenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10603] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Yixienamei/Yixienameiprojectilesingleattackeffect/Yixienameiprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/hero603pg.mp3"
} 
Attack[10604] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Ragna/Ragnaenemysingleattackeffect/Ragnaenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10605] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Muen/Muenprojectilesinleattackeffect/Muenprojectilesinleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="",
    skill_sound ="music/heropugong/hero605pg.mp3"
} 
Attack[10527] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Xiaoshu/Xiaoshuprojectilesingleattackeffect/Xiaoshuprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10392] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Ludi/Ludienemysingleattackeffect/Ludienemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10395] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10504] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Buladelei/Buladeleienemysingleattackeffect/Buladeleienemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10503] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10500] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Mianhua/Mianhuaprojectsingleattackeffect/Mianhuaprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10394] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_guang/fly_guang.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10528] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Gelanni/Gelannienemysingleattackeffect/Gelannienemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10529] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Daixi/Daixiprojectilesingleattackeffect/Daixiprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Daixi/Daixienemysingleattackeffect/Daixienemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10531] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10530] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Xinnianxiluo/Xinnianxiluoprojectilesingleattackeffect/Xinnianxiluoprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10532] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Xinniananjielina/Xinniananjielinaprojectilesingleattackeffect/Xinniananjielinaprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Xinniananjielina/Xinniananjielinaenemysingleattackeffect/Xinniananjielinaenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[20131] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Xinnianzhu/Xinnianzhuenemysingleattackeffect/Xinnianzhuenemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[20132] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        30,30,40
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="",
    skill_sound =""
} 
Attack[20133] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        30,30,40
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="",
    skill_sound =""
} 
Attack[10606] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_shui/fly_shui.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongshui/Fashipugongshui.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10607] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound ="music/heropugong/hero607pg.mp3"
} 
Attack[10608] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Weizi/weizisingleattack_an/Weizisingleattack_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10609] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanfeng/Jinzhanfeng.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10610] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_guang/fly_guang.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10611] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10524] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Saimisi/Saimisienemysingleattackeffect/Saimisienemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10525] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanhuo/Jinzhanhuo.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[20143] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[20145] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10355] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10132] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Miluku/Milukuenemysingleattackeffect/Milukuenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10700] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Yalishanda/Yalishandaenemysingleattackeffect/Yalishandaenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10702] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Heiyakaijia/Heiyakaijiaenemyattackeffect/Heiyakaijiaenemyattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10703] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanshui/Jinzhanshui.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[20147] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/S_shibing1/S_shibing1enemysingleattackeffect/S_shibing1enemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[20148] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Fashipugongguang/Fashipugongguang.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/S_shibing2/S_shibing2enemysingleattackeffect/S_shibing2enemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[20149] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Yinglingzhanshi/Yinglingzhanshienemysingleattackeffect/Yinglingzhanshienemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[20150] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/monster/Yinglingsheshou/Yinglingsheshouenemysingleattackeffect/Yinglingsheshouenemysingleattackeffect.atlas",
    skill_sound =""
} 
Attack[10704] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_huo/fly_huo.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10705] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Alubeier/Alubeierprojectilesingleattackeffect/Alubeierprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10393] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Jinzhanguang/Jinzhanguang.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10511] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Qiangui_2/Qiangui_2enemysingleattackeffect/Qiangui_2enemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/hero511pg.mp3"
} 
Attack[10534] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/fly_an/fly_an.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10513] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Aipuxilong/Aipuxilongprojectilesingleattackeffect/Aipuxilongprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Aipuxilong/Aipuxilongenemysingleattackeffect/Aipuxilongenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10514] = { --技能的ID
    attack_type = 2,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10366] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Kuisha_1/Kuishaprojectsingleattackeffect/Kuishaprojectsingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongfeng/Fashipugongfeng.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10519] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Sikuer/Sikuerenemysingleattackeffect/Sikuerenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10520] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Hati/Hatiprojectilesingleattackeffect/Hatiprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Hati/Hatienemysingleattackeffect/Hatienemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10535] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Bingyubachong/Bingyubachongprojectilesingleattackeffect/Bingyubachongprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Bingyubachong/Bingyubachongenemysingleattackeffect/Bingyubachongenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10502] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Lingyijiang/Lingyijiangprojectilesingleattackeffect/Lingyijiangprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Lingyijiang/Lingyijiangenemysingleattackeffect/Lingyijiangenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10502] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Lingyijiang/Lingyijiangprojectilesingleattackeffect/Lingyijiangprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Lingyijiang/Lingyijiangenemysingleattackeffect/Lingyijiangenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10538] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        50,50
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Wulianzhounian/Wulianzhounianenemyattackeffect/Wulianzhounianenemyattackeffect.atlas",
    skill_sound ="music/heropugong/Njinzhan.mp3"
} 
Attack[10540] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Shaxiazhounian/Shaxiazhounianenemysingleattackeffect/Shaxiazhounianenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10539] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Ailuweizhounian/Ailuweizhounianprojectilesingleattackeffect/Ailuweizhounianprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Ailuweizhounian/Ailuweizhounianenemysingleattackeffect/Ailuweizhounianenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10541] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Nikelasizhounian/Nikelasizhounianenemysingleattackeffect/Nikelasizhounianenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10537] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Dageye/Dageyeprojectilesingleattackeffect/Dageyeprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongguang/Fashipugongguang.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10516] = { --技能的ID
    attack_type = 1,--平砍类
    skill_speed = 0,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Dashe/Dasheenemyskilleffect/Dasheenemyskilleffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10542] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Niefeiluyz/Niefeiluyzprojectilesingleattackeffect/Niefeiluyzprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugonghuo/Fashipugonghuo.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10543] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Maouyz/Maouyzprojectilesingleattackeffect/Maouyzprojectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Maouyz/Maouyzenemysingleattackeffect/Maouyzenemysingleattackeffect.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
Attack[10544] = { --技能的ID
    attack_type = 3,--平砍类
    skill_speed = 75,--飞行道具移动的速度
    skill_hit ={
        100
    },
    skill_dmg = 100,--害数量伤
    res_fly ="armatures/role/Shenshina2/Shenshina2projectilesingleattackeffect/Shenshina2projectilesingleattackeffect.atlas", -- 飞行道具类的飞行特效
    res_hit ="armatures/role/Fashipugongan/Fashipugongan.atlas",
    skill_sound ="music/heropugong/Nbaozha.mp3"
} 
