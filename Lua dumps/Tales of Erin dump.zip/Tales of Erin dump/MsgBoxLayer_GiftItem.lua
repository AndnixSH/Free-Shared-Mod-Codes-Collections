MsgBoxLayer_GiftItem = class("MsgBoxLayer_GiftItem", XUICellView)
MsgBoxLayer_GiftItem.CS_FILE_NAME = "MsgBoxLayer_GiftItem.csb"
MsgBoxLayer_GiftItem.CS_BIND_TABLE = 
{
	panel_1 = "/i:5054",
	Image_icon_bg = "/i:90",
	Image_icon_form = "/i:92",
	Image_icon = "/i:91",
	Text_name = "/i:93",
	Text_dec = "/i:94",
	Button_Subtract = "/i:5091/i:241",
	Button_add = "/i:5091/i:242",
	Text_select = "/i:243",
	Text_num = "/i:5145",
}

function MsgBoxLayer_GiftItem:init(...)
	MsgBoxLayer_GiftItem.super.init(self,...)
	self.Button_add:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickAddEvent then
                    self.ClickAddEvent(self)
                end
            end
		end
	end)
	self.Button_Subtract:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickAddEvent then
                    self.ClickSubEvent(self)
                end
            end
		end
	end)
	self.panel_1:setSwallowTouches(false)

	return self
end

function MsgBoxLayer_GiftItem:onResetData()
	if not self._data then return end 
	local item_data = UITool.getItemInfos(self._data["type"],self._data["id"])
	self.Image_icon_bg:setUnifySizeEnabled(true)
	self.Image_icon_bg:loadTexture(table.getValue("item_data",item_data,4))
	self.Image_icon_form:setUnifySizeEnabled(true)
	self.Image_icon_form:loadTexture(table.getValue("item_data",item_data,1))
	self.Image_icon:setUnifySizeEnabled(true)
	self.Image_icon:loadTexture(table.getValue("item_data",item_data,2))

	self.Text_name:setString(table.getValue("item_data",item_data,5))
	self.Text_num:setString("X"..tostring(self._data["num"]))
	local des = string.gsub(table.getValue("item_data",item_data,6),"*","")
	self.Text_dec:setString(des)
	self.Text_select:setString(tostring(self._data["select"]))
	local b = self._data["IsTouch"]
	if not b then
		self.Button_add:setTouchEnabled(false)
		self.Button_add:setBright(false)
	else
		self.Button_add:setTouchEnabled(true)
		self.Button_add:setBright(true)
	end

	if self._data["select"] > 0 then
		self.Button_Subtract:setTouchEnabled(true)
    	self.Button_Subtract:setBright(true)
    else
    	self.Button_Subtract:setTouchEnabled(false)
    	self.Button_Subtract:setBright(false)
	end
end

function MsgBoxLayer_GiftItem:setButtonSubState(_touch)
	self.Button_Subtract:setTouchEnabled(_touch)
	self.Button_Subtract:setBright(_touch)
end

function MsgBoxLayer_GiftItem:setButtonAddState(_touch)
	self.Button_add:setTouchEnabled(_touch)
	self.Button_add:setBright(_touch)
end

function MsgBoxLayer_GiftItem:getSingleData()
	if not self._data then
		return false,nil
	end
	return true,self._data
end

function MsgBoxLayer_GiftItem:getIndex()
	return self._index
end

function MsgBoxLayer_GiftItem:setSelectText(_count)
	self.Text_select:setString(tonumber(_count))
end







