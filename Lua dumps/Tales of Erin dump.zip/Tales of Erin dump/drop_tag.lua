drop_tag = {} 
drop_tag[1] = {
     path_res = "res/uifile/n_UIShare/Global_UI/rarity/xdrz_ui_019.png",
}

drop_tag[2] = {
     path_res = "res/uifile/n_UIShare/Global_UI/rarity/xdrz_ui_020.png",
}
