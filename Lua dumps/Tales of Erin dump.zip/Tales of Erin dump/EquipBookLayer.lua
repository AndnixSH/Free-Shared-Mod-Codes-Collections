--[[
	EquipBookLayer.lua
]]

EquipBookLayer = class("EquipBookLayer",XUIView)
EquipBookLayer.CS_FILE_NAME = "EquipBookLayer.csb"
EquipBookLayer.CS_BIND_TABLE = 
{
    vpanel="/i:101/s:subView",
    panelSort = "/i:101/s:panelSort",
    _panelList = "/i:101/s:listPanel",
    cntGot = "/i:101/s:got_bg/s:cntGot",
}

function EquipBookLayer.createWithBackBtn(nSelectTitleNum)
    local v = EquipBookLayer.new():init()
    local b = BackgroundView.new():initWithBackBtn(v)
    return b,v
end

function EquipBookLayer:clear()
    self.views = nil
    self._cntGotNum = 0
    self._maxOpenNum = 0
    self._baseListData = nil 
    self._selectShowData = nil
end

function EquipBookLayer:init()
    EquipBookLayer.super.init(self)
    self._baseListData = nil 

    self.views = XUIView.new():init(self.vpanel)

    self:initListView()
    self:initSortUI()
    return self
end

function EquipBookLayer:initListView()
    local psize = self._panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self._panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = XUICellView.new():init(nil,"GalleryItemView.csb",{
            imgBG = "/i:29/i:30/s:imgBG",
            imgFace = "/i:29/i:30/s:imgFace",
            imgRarity = "/i:29/i:30/s:imgRarity",
            imgElement = "/i:29/i:30/s:imgElement",
            shadowCover = "/i:29/i:298",
            nameColor = "/i:29/i:42/i:50",
            nameGray = "/i:29/i:42/i:87",
            nameGrayBg = "/i:29/i:42/i:48",
        })

        temp.onResetData = function(self)
        --todo-----
            local nname = nil
            local face = nil

            local e_num_id = self._data.e_num_id
            face  = equip[e_num_id].equip_list_icon  
            nname = UITool.getUserLanguage(equip[e_num_id].equip_name)--equip[e_num_id].equip_name
            local natb  = equip[e_num_id].equip_atb
            local nrank = equip[e_num_id].equip_rank
            
            local frame = Rarity_Icon[nrank]  --外框   
            --Rarity_BG  --背景
            if frame then
                self.imgRarity:setTexture(frame)
            end

            local rbg = Rarity_E_BG[nrank]   --背景
            if rbg then
                self.imgBG:setTexture(rbg)
            end
            --face = hero[h_id_num].hero_list_icon  
            if face then
                self.imgFace:setTexture(face)
                if self._data.got then
                    self.imgFace:setColor(cc.c3b(255,255,255))
                else
                    self.imgFace:setColor(cc.c3b(0,0,0))
                end
            end

            local element = ATB_Icon[natb] --属性球

            if element then
                self.imgElement:setTexture(element)
            end
            if g_channel_control.transform_GalleryItemView_name == true then 
                self.nameColor:setPosition(cc.p(86,55))
                self.nameColor:setAnchorPoint(cc.p(0.5,1))
                self.nameColor:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                self.nameColor:ignoreContentAdaptWithSize(false);
                self.nameColor:setTextAreaSize(cc.size(130,50))

                self.nameGray:setPosition(cc.p(86,55))
                self.nameGray:setAnchorPoint(cc.p(0.5,1))
                self.nameGray:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                self.nameGray:ignoreContentAdaptWithSize(false);
                self.nameGray:setTextAreaSize(cc.size(130,50))

                self.nameGrayBg:setVisible(false)
            end

            self.nameColor:setString(nname)
            self.nameGray:setString(nname)

            self.nameColor:setVisible(self._data.got)

            --self.shadowCover:setVisible( not self._data.got )           
            self.shadowCover:setVisible(false) 
            self.nameColor:setVisible(self._data.got) 
            self.nameGray:setVisible( not self._data.got )
        end
        return temp
    end
    self.gridview.itemClickedEvent = function (sender,index)
        local data = sender:getDataSource()[index]
        self:showEquipGallery(index)
    end
end

function EquipBookLayer:showEquipGallery(index)
	--todo
    local tempds = {}
    for i = 1,#self._selectShowData do
        local j = self._selectShowData[i]
        if j.got then
            tempds[i] = ""..j.e_num_id.."*"..1 
        else
            tempds[i] = ""..j.e_num_id.."*"..0
        end
    end

    local eqinfo = self._selectShowData[index]
    if GameManagerInst.gameType == 2 then
        if eqinfo.got then    
            SceneManager:toEquipInfo({ eid = ""..eqinfo.e_num_id.."*"..1, elist = tempds,eb = true})
        else
            SceneManager:toEquipInfo({ eid = ""..eqinfo.e_num_id.."*"..0, elist = tempds,eb = true})
        end
    end

end

function EquipBookLayer:onItemClicked(item)    
    if self.ItemClickedEvent then
        self.ItemClickedEvent(item)
    end
end

function EquipBookLayer:onItemReset(item)    
    if self.ItemResetEvent then
        self.ItemResetEvent(item)
    end
end

function EquipBookLayer:refresh()
    if not self._baseListData then 
        self:reqBaseData()
    end 
end

function EquipBookLayer:refreshUI()
    self:refreshGotUI()
    self:refreshList()
end

--收集度
function EquipBookLayer:refreshGotUI()
    local value = self._cntGotNum.."/"..self._maxOpenNum
    local strFormat = UITool.ToLocalization("收集度: %s")
    local str = string.format(strFormat,value)
    self.cntGot:setPosition(cc.p(112,20))
    self.cntGot:setString(str)
end

function EquipBookLayer:refreshList()
    if not self._selectShowData then
        self.gridview:setDataSource(nil)
    else
        self.gridview:setDataSource(self._selectShowData)
    end
end

function EquipBookLayer:initBaseData(hero_ids)
	--todo
    self._cntGotNum = 0 -- 已拥有（收集）
    local temp = {} --字典
    for k,v in pairs(eq_open) do
        print("kkkkkkkkkkk == "..k)
        local hf = equip[k]
        if hf then
            temp[k] = {
                e_num_id = k,  
                --hero_add = 0,
                got = false
            }
            --添加排序所需数据
            temp[k][SortFunDataKey.ID] = v[SortFunDataKey.ID]
            temp[k][SortFunDataKey.ELEMENT] = hf.equip_atb
            temp[k][SortFunDataKey.RARITY]  = hf.equip_rank
        end
    end

    for k,v in pairs(hero_ids) do
        local tempobj = temp[v]
        if tempobj then
            temp[v].got = true
            --temp[v.id].hero_add = v.hero_add
            --temp[v.id].like_feel_state = v.like_feel_state
            self._cntGotNum = self._cntGotNum+1
        end
    end

    local ds = {}

    for k,v in pairs(temp) do
        table.insert(ds,v)
    end

    self._baseListData = table.deepcopy(ds)
    self._maxOpenNum = #self._baseListData
    self:siftAndSortData()
    self:refreshUI()
end

--请求数据
function EquipBookLayer:reqBaseData()
    GameManagerInst:rpc("{\"rpc\":\"gallery_eq_info\"}",3,
    function(data)
        --success
        local ho = data.eq_open
        eq_open = {}
        for i=1,#ho do
            local v = table.deepcopy(ho[i])
            v[SortFunDataKey.ID] = equip[v.id].order--i --默认添加一个序号id
            eq_open[v.id] = v
        end
        --说明：NewRoleSthView 的336行未 处理 mat表为nil逻辑，为不影响其他逻辑，此处默认处理一波
        local tempmat = {}
        DataManager:wAllBagData({mat = tempmat})

        self:initBaseData(data.equip)
    end,

    function(state_code,msgText)
        GameManagerInst:alert(msgText,function()
            SceneManager:toStartLayer()
        end)
    end,
    true)
end

-----------------------------------------排序相关 start----------------------------------
function EquipBookLayer:initSortUI()
    use_equipbook_sort_data = use_equipbook_sort_data or equipbook_sort_data --todo equipbook_sort_data
    self._sortComponent = CommonSortComponent.new():init(self, use_equipbook_sort_data) 
    self._sortComponent:addSortButtonUI(self.panelSort)
end
---登出游戏后重置筛选为默认排序
function EquipBookLayer:cachSortData()
    use_equipbook_sort_data = table.deepcopy(self._sortComponent._data) ---一定不要提别人保存
end

--生降序   发生变化
function EquipBookLayer:sortStateChangeFunc()
    self:sortData()
    self:refreshList()
end

--筛选及排序 发生变化
function EquipBookLayer:sortTypeChangeFunc()
    self:siftAndSortData()
    self:refreshList()
end

----此处可以本地排序、也可以服务器排序
function EquipBookLayer:sortData()
    local data = self._selectShowData
    local sortState = self._sortComponent:getSortState()
    local sort_typeValue = self._sortComponent:getSortTypeValue()
    ComSortData(data, sortState,sort_typeValue)
    self:cachSortData()
end

--先筛选、然后排序
function EquipBookLayer:siftAndSortData() 
    local selects = self._sortComponent:getSelectData()
    local tempData = SiftEquipBook(self._baseListData, selects)
    self._selectShowData = table.deepcopy(tempData)
    self:sortData()
end

-----------------------------------------排序相关 end----------------------------------

