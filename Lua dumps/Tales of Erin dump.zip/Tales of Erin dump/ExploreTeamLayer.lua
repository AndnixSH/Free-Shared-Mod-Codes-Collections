--[[
   ExploreTeamLayer.lua
info:
self.currentHeroNum ：
    标记当前组队人数
    重置 refreshLeftUI 0
    + refreshTeamUI
    - removeHeroFromTeam
]]
require "BasicLayer"

ExploreTeamLayer = class("ExploreTeamLayer",BasicLayer)
ExploreTeamLayer.__index = ExploreTeamLayer
ExploreTeamLayer.lClass = 3
local EXPLORE_MAX_NUM = 3 --队伍理论上最大人数

function ExploreTeamLayer:init()
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.exploreData = self.rData["rcvData"]["data"]

    local exploreId = self.exploreData.explore_id --探索Id
    self._exploreRaces = exploerPass[exploreId].level_race -- 关卡推荐种族

    self._teamUIs = {}         --编队中的ui数组
    self._selectItems = {}     --右侧列表选中item的字典 key 为ID

    self._exploreCache = {}
    self._heros = {}           --探索队伍中hero 数组，值为id
    self._hero_list = {}       --类别总数据,字典 （因为涉及到筛选、排序）
    self._showHeroListArry = {} --数组，当前列表显示的数据，因为涉及到筛选、排序，显示部分）
    
    self._dispatchMax = 0      --最多可以派遣的人数
    self.currentHeroNum = 0    --在探险队伍中英雄的数量
    self.sortHeroType = 1      -- 1 从高到低 0 是从低到高
    -- --新手引导、放在网络请求之前
    -- if user_info["guide_id"] == GuideID.Explore then 
    --     self.guideItem = nil 
    -- end 
   
    local node = cc.CSLoader:createNode("ExploreTeam.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    self._rootCSbNode = node:getChildByTag(102) 

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end
    self._rootCSbNode:addTouchEventListener(touchCallBack)

    local title = ccui.Helper:seekWidgetByName(self._rootCSbNode,"main_title")
    title:setString(UITool.getUserLanguage(exploerPass[exploreId].level_name))--(exploerPass[exploreId].level_name)

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:toStartExplore()
        end
    end
    local startBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_start")
    startBtn:addTouchEventListener(touchCallBack)

    --最适种族说明
    local function touchCallBack1(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        local data = {}
            data.pictures = { --一张或者多张
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_015.png",
        }
        SceneManager:toGuidePictureLayer(data)
        end
    end
    local btnInfo1 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_info_1")
    btnInfo1:addTouchEventListener(touchCallBack1)
    --推荐战力说明
   local function touchCallBack2(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        local data = {}
            data.pictures = { --一张或者多张
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_015.png",
        }
        SceneManager:toGuidePictureLayer(data)
        end
    end
    local btnInfo2 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_info_2")
    btnInfo2:addTouchEventListener(touchCallBack2)


    self:initLeftUI()

    self:initRightUI()

    -- --新手引导、放在网络请求之前
    -- if user_info["guide_id"] == GuideID.Explore then 
    --     NewGuideManager:startSubGuide(self, 4)
    -- end 
    self:requireExploreCacheInfo()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
--探索队伍
function ExploreTeamLayer:initLeftUI()
    for i=1,EXPLORE_MAX_NUM do
        local keyStr = "team_"..i
        local panel = ccui.Helper:seekWidgetByName(self._rootCSbNode,keyStr)
        local node = cc.CSLoader:createNode("ExploreTeamItem.csb")
        panel:addChild(node,0,1)
        self._teamUIs[i] = node
    end
end
--英雄列表
function ExploreTeamLayer:initRightUI()
	-- body
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:toSiftLayer()
        end
    end
    local siftBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_sift")
    siftBtn:addTouchEventListener(touchCallBack)
    
    local function touchSortBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.sortHeroType == 1 then
                self.sortHeroType = 0
                self.sortImg:setScaleY(1)
            else 
                self.sortImg:setScaleY(-1.0)
                self.sortHeroType = 1
            end
            self:sortHeroData()
            self:refreshRightUI()
        end
    end
    self.sortImg = ccui.Helper:seekWidgetByName(self._rootCSbNode,"sort_img")
    local sortBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"sort_btn")
    sortBtn:addTouchEventListener(touchSortBack)
    self.sortImg:setScaleY(-1.0)

	self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"listview2")
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = ExploreTeamItem.new():init()
        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end
        temp.resetDataEvent = function(item)
            self:onItemShow(temp)
        end
        return temp
    end
end
--点击列表中的英雄
function ExploreTeamLayer:onItemClicked(item)
    local id = item:getData().id
    if item:getData().is_dispatch == 1 then 
        if item.isSelect then
            print("移除已派遣的")
            self:removeHeroFromTeam(item._exploreLoction,id)
        else 
            print("已派遣")
        end
        do return end  
    end 
    if item.isSelect then
        self:removeHeroFromTeam(item._exploreLoction,id)
    else    
        if self.currentHeroNum >= self._dispatchMax then
            print("队伍已满")
            do return end 
        end
        local i = 1
        --遍历找到空位置，入队
        while i <= self._dispatchMax   do
            if self._heros[i]==nil or self._heros[i] == "" then 
                self:addItemToTeam(item,id,i)
                break
            end
            i = i + 1
        end    
    end
end
--item 显示的时候
function ExploreTeamLayer:onItemShow(item)
    local id = item:getData().id
    for i=1,#self._heros  do
        if self._heros[i] == id then 
            item:setSelectState(0)
            item._exploreLoction = i
            self._selectItems[id] = item
        end
    end
    for i=1,#self._exploreRaces  do
        local race = self._exploreRaces[i]
        if race ==  item:getData().hero_race then
            item.isBastRace = true
            item:setShowBastRace(true) 
        end
    end
    -- if user_info["guide_id"] == GuideID.Explore then 
    --     --只标记第一个
    --     if self.guideItem == nil then 
    --         self.guideItem = item
    --     end 
    -- end 
end
--新手引导函数
function ExploreTeamLayer:newGuideFunc2()
    -- body
    self:onItemClicked(self.guideItem )
end
--刷新
function ExploreTeamLayer:refreshUI()
    self:siftHeroData(true,nil)--筛选
    self.sortHeroType = 1
    self:sortHeroData()
    self:refreshRightUI()
    self:refreshLeftUI()
end
--刷新英雄列表
function ExploreTeamLayer:refreshRightUI()
    self._selectItems = {}
    self.gridview:setDataSource(self._showHeroListArry)
end
--刷新探索队伍列表及下面数据
function ExploreTeamLayer:refreshLeftUI()
    self.currentHeroNum = 0 --清空一下当前的数据
    for i=1,EXPLORE_MAX_NUM do
        local node = self._teamUIs[i]
        if  i<= self._dispatchMax  then
            if self._heros[i]== nil or self._heros[i] == "" then --空数据
                self:refreshTeamUI(node,2)
            else
                self:refreshTeamUI(node,3,self._heros[i],i) --在队伍中
            end
        else
            self:refreshTeamUI(node,1) --未解锁
        end
    end
    --推荐战力
    local recomFpValue = self._exploreCache.recom_fp
    local recomFp = ccui.Helper:seekWidgetByName(self._rootCSbNode,"recom_fp")
    recomFp:setString(0)
    -- 
    self:refreshOtherUI()
end
--战力显示、最适应种族等等UI的刷新
--数据来源于_hero_list
function ExploreTeamLayer:refreshOtherUI()
    local data = self:getOtherData()
    for i=1,EXPLORE_MAX_NUM do 
        local keyStr = "race_bg_"..i
        local node = ccui.Helper:seekWidgetByName(self._rootCSbNode,keyStr)
        if self._exploreRaces[i] ~= nil then 
            local name = ccui.Helper:seekWidgetByName(node,"race_name")
            name:loadTexture(HERO_RACE_ICON[self._exploreRaces[i]])
            local raceNum = data.raceNums[self._exploreRaces[i]] or 0
            for t=1,EXPLORE_MAX_NUM do 
                local imgStr = "num_"..t
                local numImg = ccui.Helper:seekWidgetByName(node,imgStr)
                if t<=raceNum then 
                    numImg:setVisible(true)
                else
                    numImg:setVisible(false)
                end
            end
            node:setVisible(true)
        else 
            node:setVisible(false)
        end
    end
    --战斗力
    -- local recomFpValue = self._exploreCache.recom_fp
    -- data.totalFp = data.totalFp  or 0
    -- local addValue = data.totalFp - recomFpValue
    -- local recomFpMore = ccui.Helper:seekWidgetByName(self._rootCSbNode,"recom_fp_more")
    -- if addValue > 0 then
    --     recomFpMore:setString("+"..addValue)
    --     recomFpMore:setTextColor(cc.c3b(18,234,2))
    -- elseif addValue==0 then 
    --     recomFpMore:setString("")
    -- else
    --     recomFpMore:setString("不足")
    --     recomFpMore:setTextColor(cc.c3b(255,0,0))
    -- end
    local recomFp = ccui.Helper:seekWidgetByName(self._rootCSbNode,"recom_fp")
    recomFp:setString(data.totalFp)

    local recomFpMore = ccui.Helper:seekWidgetByName(self._rootCSbNode,"recom_fp_more")
    recomFpMore:setVisible(false)
end
-- 1为锁住状态，2为未选状态 3为有英雄状态
--location 删除的第几个 当前UI的位置 ，对应 1 2 3
function ExploreTeamLayer:refreshTeamUI(_node,_type,_id,_location)
    local function setUI(root,iconImg,frameImg, elementImg,iconBG)
        self.currentHeroNum = self.currentHeroNum + 1
        local h_id_num = getNumID(_id)
        local h_id_str = getStrID( _id)
        --icon
        local iconStr = hero[h_id_num].hero_team_icon
        iconImg:loadTexture(iconStr)

        local function onCickItem( sender,eventType )
            if eventType == ccui.TouchEventType.ended then
                self:removeHeroFromTeam(_location,_id)
            end
        end 
        iconImg:addTouchEventListener(onCickItem)  
        local data = self._hero_list[_id]
        --frame
        local rarity = tonumber(data.rarity)
        local frameStr = Rarity_Hero_Frame[rarity]
        frameImg:loadTexture(frameStr)

        elementImg:loadTexture(getEquipAtb(hero[h_id_num].hero_atb))

        iconBG:loadTexture(Rarity_Team_BG[rarity])

        --种族
        -- local hero_race = hero[h_id_num].hero_race
        -- local raceLab = ccui.Helper:seekWidgetByName(root,"raceType")  
        -- raceLab:setString(UITool.ToLocalization(HERO_RACE_NAME[hero_race]))

          --种族 显示种族名字 或者 图标
        if g_channel_control.transform_ExploreResultLayer_raceType == false then
            print("g_channel_control.transform_ExploreResultLayer_raceType == false")
            local hero_race = hero[h_id_num].hero_race
            local raceLab = ccui.Helper:seekWidgetByName(root,"raceType")  
            raceLab:setString(UITool.ToLocalization(HERO_RACE_NAME[hero_race]))

        else
             print("g_channel_control.transform_ExploreResultLayer_raceType == true")
            local hero_race = hero[h_id_num].hero_race
            local raceLab = ccui.Helper:seekWidgetByName(root,"raceType")  
            raceLab:setVisible(false)


            local raceIcon = ccui.Helper:seekWidgetByName(root,"raceIcon")
            if raceIcon == nil then
                raceIcon = ccui.ImageView:create()
                raceIcon:setPosition(117,50)
                raceIcon:setName("raceIcon")
                root:addChild(raceIcon);
            end

            local hero_race = hero[h_id_num].hero_race
            raceIcon:loadTexture(HERO_RACE_ICON[hero_race])
            
           

        end

        --战力
        
        local powerLab = ccui.Helper:seekWidgetByName(root,"power")   
        powerLab:setString(data.fp_all)
        --已派遣
        local dispatchImg = ccui.Helper:seekWidgetByName(root,"isDis")
         dispatchImg:setVisible(true)   
        if tonumber(data.is_dispatch) == 1 then 
            dispatchImg:setVisible(true)
        else
            dispatchImg:setVisible(false)
        end    
    end

    local bgs = {
        "n_UIShare/explore/ts_ui_024.png",
        "n_UIShare/explore/ts_ui_014.png",
        "n_UIShare/explore/ts_ui_014.png"
    }
    if _node== nil then
        return 
    end
    local panel_1 = _node:getChildByTag(101) 
    local bgImg = ccui.Helper:seekWidgetByName(panel_1,"bg")
    bgImg:loadTexture(bgs[_type])

    local iconImg = ccui.Helper:seekWidgetByName(panel_1,"icon")
    local frameImg = ccui.Helper:seekWidgetByName(panel_1,"frame")
    local elementImg = ccui.Helper:seekWidgetByName(panel_1,"element")
    local iconBg = ccui.Helper:seekWidgetByName(panel_1,"icon_bg")
    
    local panel_2 = _node:getChildByTag(102)

    if _type ==1 then 
        panel_2:setVisible(false)
        iconImg:setVisible(false)
        frameImg:setVisible(false)
        elementImg:setVisible(false)
        iconBg:setVisible(false)
    elseif _type ==2 then 
        panel_2:setVisible(false) 
        iconImg:setVisible(false)
        frameImg:setVisible(false)
        elementImg:setVisible(false)
        iconBg:setVisible(false)
    elseif _type ==3 then
        panel_2:setVisible(true) 
        iconImg:setVisible(true)
        frameImg:setVisible(true)
        elementImg:setVisible(true)
        iconBg:setVisible(true)
        setUI(panel_2,iconImg,frameImg,elementImg,iconBg)
    end
end
--添加
function ExploreTeamLayer:addItemToTeam(item,id,location)
    self._heros[location] = id
    item:setSelectState(0)
    item._exploreLoction = location --记录在左侧队伍中的位置
    self._selectItems[id] = item
    self:refreshLeftUI()
end
--删除
function ExploreTeamLayer:removeHeroFromTeam(location,id)
    self._heros[location] = ""
    self.currentHeroNum = self.currentHeroNum - 1 
    local item = self._selectItems[id]
    if item~=nil then
        item:setSelectState(1)
        self._selectItems[id] = nil
    end
    self:refreshLeftUI()
end
--获取当前探索队伍中的战力和种族数量
--数据来源于_hero_list, 不依赖right
function ExploreTeamLayer:getOtherData()
    local backData = {}
    local totalFp = 0 --队伍总的战力
    local raceNums = {}--字典
    for i=1,#self._heros do
        if self._heros[i] == nil or self._heros[i] == "" then 
        else
            local id = self._heros[i]
            local data = self._hero_list[id]
            local h_id_num = getNumID(id)
            local nowRace =  hero[h_id_num].hero_race
            if data ~= nil and data["fp_all"] ~= nil then
                totalFp = totalFp + data["fp_all"]
            end
            for i=1,#self._exploreRaces do
                if self._exploreRaces[i] == nowRace then 
                    if raceNums[nowRace] == nil  or raceNums[nowRace] == 0 then
                        raceNums[nowRace] = 1
                    else 
                        raceNums[nowRace] = raceNums[nowRace] +1
                    end
                end
            end               
        end
    end
    backData.totalFp = totalFp
    backData.raceNums = raceNums
    return backData
end
--开始探索
function ExploreTeamLayer:toStartExplore()
    print("开始探索")
    local canStart = false
    local heros = {}
    for i=1,#self._heros do 
        local id = self._heros[i] 
        if id~=nil and id~="" then
            heros[#heros+1]=id
            canStart = true
        end
    end
    if canStart then
        self:requireStartExplore(heros)
    else
        MsgManager:showSimpMsg(UITool.ToLocalization("没有可以探索的角色"))
    end
end
-------------------------接口api---------------------
--[获取上次保存队伍信息及角色列表]
function ExploreTeamLayer:requireExploreCacheInfo()
    local function ReqSuccess(data)
        print("成功 收到上次保存队伍信息及角色列表")
        self._exploreCache = {}
        self._exploreCache = data
        self._heros = data.heros
        self._hero_list = data.hero_list
        self._dispatchMax = tonumber(data.dispatch_max)
        self:refreshUI()
    end
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end

        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "explore_cache",
        ["explore_id"] = self.exploreData.explore_id,
    }
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--[开始探索]
function ExploreTeamLayer:requireStartExplore(c_heros)
    --获取数据成功
    local function ReqSuccess(data)
        --返回刷新
        local exploreData = {}
        exploreData.explore_num = data.explore_num
        DataManager:refreshExploreData(exploreData)
        local backData = data.explore_info
        self:returnBack(true,backData)
    end
    local function reicePointCallBack(data)
        print("收到上次保存队伍信息及角色列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "explore_start",
        ["explore_id"] = self.exploreData.explore_id,
        ["heros"] = c_heros
    }
    --dump(tempTable)

    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--------------------------
--筛选页面
function ExploreTeamLayer:toSiftLayer()
    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] =  self.siftCallBack
    rcvData["data"] =  data
    self.sManager:toExploreTeamSiftLayer(rcvData)     
end
--筛选返回
function ExploreTeamLayer:siftCallBack(data)
    self:siftHeroData(false,data)
    self:sortHeroData()
    self:refreshRightUI()
end
--筛选排序
--[[
self._hero_list母本数据
先筛选
]]
function  ExploreTeamLayer:siftHeroData(isShowAll,c_selectRaces)
    --筛选条件
    local selectRaces = 1
    local function eligible(race)
        if isShowAll then
            return true
        end
        for i=1,#c_selectRaces do
            if c_selectRaces[i] == race then 
                return true
            end
        end
        return false
    end
    local temp_list = {}
    local index = 1
    for k,v in pairs(self._hero_list) do
        local nowRace = hero[getNumID(""..k)]["hero_race"]
        if eligible(nowRace) then
            temp_list[index] = v
            if temp_list[index]~=nil then
                temp_list[index]["id"] = k
                temp_list[index]["time_id"]   = getTimeNumID(""..k)
                temp_list[index]["hero_rank"] = hero[getNumID(""..k)]["hero_rank"]
                temp_list[index]["hero_name"] = UITool.getUserLanguage(hero[getNumID(""..k)]["hero_name"])--hero[getNumID(""..k)]["hero_name"] 
                temp_list[index]["hero_race"] = hero[getNumID(""..k)]["hero_race"]
                index = index +1
            end 
        end 
    end
    self._showHeroListArry = {}
    self._showHeroListArry = table.deepcopy(temp_list)
    temp_list = nil
end 
--排序
--[[
--排序优先级
    1.在队伍中  2.战斗力高到低 fp_all  3.id
todo 优化：
    目前实现是每次筛选 排序
    fp_all 从高到低，还是从低到高
    high to low
]]
function ExploreTeamLayer:sortHeroData()
    local comfuc = nil
    if self.sortHeroType == 1 then 
        comfuc = function(a,b) return tonumber(a) > tonumber(b) end
    else 
        comfuc = function(a,b) return tonumber(a) < tonumber(b) end
    end 
    local function qualitySort(a,b)
        a.is_in_team = self:isInTeam(a.id) 
        b.is_in_team = self:isInTeam(b.id) 
        if a.is_in_team == b.is_in_team then
            if tonumber(a.fp_all) == tonumber(b.fp_all) then 
                if tonumber(a.rarity) == tonumber(b.rarity) then 
                    return tonumber(a.time_id) > tonumber(b.time_id)
                else 
                    return tonumber(a.rarity) > tonumber(b.rarity)
                end 
            else 
                return comfuc(a.fp_all, b.fp_all)
            end    
        else
            return a.is_in_team > b.is_in_team
        end
    end
    --只有新手引导的时候用
    -- local function newGuideSort(a,b)
    --     local aisRole = self:isManRole(a.id)
    --     local bisRole = self:isManRole(b.id)
    --     if aisRole == bisRole then 
    --         return qualitySort(a,b)
    --     else
    --         return aisRole > bisRole
    --     end 
    -- end
    -- --新手引导、男主角必须在第一位
    -- if user_info["guide_id"] == GuideID.Explore then 
    --     table.sort(self._showHeroListArry, newGuideSort)
    -- else 
        table.sort(self._showHeroListArry, qualitySort)
    --end 
end
--判断在不在队伍中 0 不在 1 在
function ExploreTeamLayer:isInTeam(c_id)
    local isIn = 0
    for i=1,#self._heros  do
        if self._heros[i] == c_id then
            isIn = 1
        end
    end
    return isIn
end
--判断是不是男主
function ExploreTeamLayer:isManRole(c_id)
    local isIn = 0
    local iD = getNumID(c_id)
    if iD == 13 then 
        isIn = 1
    end 
    return isIn
end
--返回
function ExploreTeamLayer:returnBack(isBackRefsh,backData)
    --如果是派遣返回。舒刷新
    isBackRefsh = isBackRefsh or false
    self._exploreRaces ={}
    self._teamUIs = {}  
    self._selectItems = {}  
    self._exploreCache = {}
    self._heros = {}        
    self._hero_list = {} 
    self._showHeroListArry = {} 

    if isBackRefsh then 
        self.backFunc(self.sDelegate,backData)
        SceneManager:showPromptLabel(UITool.ToLocalization("探索出发成功"))
    end 
    self.exist = false
    self:clearEx() 
end

function ExploreTeamLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ExploreTeamLayer:create(rData)
     local layer = ExploreTeamLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
