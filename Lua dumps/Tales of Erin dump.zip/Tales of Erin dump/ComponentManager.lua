--组件管理类，注意不是单例，每个entity身上绑一个,随entity的update更新。
--created by kobejaw.2018.6.3.
ComponentManager = class("ComponentManager")
function ComponentManager:ctor(entity)
	self.entity = entity
	self.comList = {}
	self.comIdList = {}
	self.tempIdx = 1;--临时变量
	self.panelNode = nil --角色信息框

	--几种特殊buff或debuff的标识,为减少检测提升效率。
	self.WuDi = false          --无敌状态
	self.TiXianKuiLei = false  --提线傀儡
	self.EGuiChanRen = false--恶鬼缠刃的标识。无法回血。
	self.MeiHuo = false--魅惑
	self.ShengMingHuDun = false--生命护盾
	self.GeDangHuDun = false   --格挡护盾
	self.DongTuFengYin = false --冻土封印。只针对boss
	self.BaTi = false          --霸体
	self.LingJianLuanWu = false  --灵剑乱舞
	self.ShangHaiZhuanYi = false
end

function ComponentManager:setPanelNode(panel)
	self.panelNode = panel
end

function ComponentManager:update(dt)
	self.tempIdx = 1;
	while self.tempIdx <= #self.comList do
		local com = self.comList[self.tempIdx]
		com:update(dt)
		if com:checkIsNeedRemove() then
			self:removeCom(com,self.tempIdx)
		else
			self.tempIdx = self.tempIdx + 1
		end
	end
end

function ComponentManager:addCom(com)
	local oldCom = self.comIdList[com.comId]
	if oldCom and oldCom.level > com.level then
		return
	end

	--comId相同,等级相同而且可叠加的情况
	if oldCom and oldCom.level == com.level and oldCom.canOverlay then
		oldCom:takeEffect(false)
		oldCom.overlayNum = oldCom.overlayNum + 1
		if oldCom.overlayNum > oldCom.overlayMaxNum then
			oldCom.overlayNum = oldCom.overlayMaxNum
		end
		oldCom.remainTime = oldCom.comData.t
		oldCom:takeEffect(true)
		self:refreshInfoPanel()

		--触发时机14.获取某个buff时。
		local option = {}
		option.comId = com.comId
		self.entity.triggerManager:check(14,option)
		
		return
	end

	--其他情况都是移除旧的添加新的
	if oldCom then
		self:removeCom(oldCom)
	end

	--添加
	table.insert(self.comList,com)
	self.comIdList[com.comId] = com
	self:onAddCom(com)

	--生效
	com:takeEffect(true)
	self:refreshInfoPanel()

	--触发时机14.获取某个buff时。
	local option = {}
	option.comId = com.comId
	self.entity.triggerManager:check(14,option)
end

--移除com
function ComponentManager:removeCom(com,idx)
	if not self.entity.isDead then
		--触发时机13.失去buff或者debuff时
		local option = {}
		option.comId = com.comId
		self.entity.triggerManager:check(13,option)	

		--触发时机113
		self.entity.teamManager:checkTeamTrigger(113,self.entity,option)	
	end

	self:onRemoveCom(com)
	self.comIdList[com.comId] = nil
	com:takeEffect(false)

	if idx then
		table.remove(self.comList,idx)
	else
		local index = self:getComIdx(com)
		if index then
			table.remove(self.comList,index)
		end
	end
	self:refreshInfoPanel()
end

--添加com时，先调用这个函数，用于特殊情况处理。
function ComponentManager:onAddCom(com)
	--无敌
	if com.buffType == Com_BuffEnum.SpecialState and com.type == 1 then
		self.WuDi = true
	--提线傀儡
	elseif com.comId == 81997 then
		self.TiXianKuiLei = true
	--恶鬼缠刃
	elseif com.comId == 81038 then
		self.EGuiChanRen = true
	--魅惑
	elseif com.comId == 82028 then
		self.MeiHuo = true
		self.MeiHuoCom = com
	--生命护盾
	elseif com.comId == 81033 then
		self.ShengMingHuDun = true
		self.ShengMingHuDunCom = com
	--格挡护盾
	elseif com.comId == 81052 then
		self.GeDangHuDun = true
		self.GeDangHuDunCom = com
	--冻土封印
	elseif com.comId == 82032 then
		self.DongTuFengYin = true
	--霸体
	elseif com.comId == 81055 and com.level ~= 2 then
		self.BaTi = true
	--灵剑乱舞
	elseif com.comId == 81050 and com.level == 4 then
		self.LingJianLuanWu = true
	--伤害转移
	elseif com.comId == 81068 then
		self.ShangHaiZhuanYi = true
		self.ShangHaiZhuanYiCom = com		
	end

	--极限挑战的特殊处理
	if G_STAGE_TYPE == 2 and self.entity.isBoss then
		if com.buffType == Com_BuffEnum.SpecialState and com.type == 6 then
			self.entity.specialFlagCom = com
		end
	end
end

--移除com时，先调用这个函数，用于特殊情况处理。
function ComponentManager:onRemoveCom(com)
	if com.buffType == Com_BuffEnum.SpecialState and com.type == 1 then
		self.WuDi = false	
	--提线傀儡
	elseif com.comId == 81997 then
		self.TiXianKuiLei = false
	--恶鬼缠刃。无法回血。攻防上升。
	elseif com.comId == 81038 then
		self.EGuiChanRen = false
	--魅惑
	elseif com.comId == 82028 then
		self.MeiHuo = false
		self.MeiHuoCom = nil
	--生命护盾
	elseif com.comId == 81033 then
		self.ShengMingHuDun = false
		self.ShengMingHuDunCom = nil
	--格挡护盾
	elseif com.comId == 81052 then
		self.GeDangHuDun = false
		self.GeDangHuDunCom = nil
	--冻土封印
	elseif com.comId == 82032 then
		self.DongTuFengYin = false	
	--霸体
	elseif com.comId == 81055 and com.level ~= 2 then
		self.BaTi = false
	--灵剑乱舞
	elseif com.comId == 81050 and com.level == 4 then
		self.LingJianLuanWu = false
	--伤害转移
	elseif com.comId == 81068 then
		self.ShangHaiZhuanYi = false
		self.ShangHaiZhuanYiCom = nil
	end
end

--移除com
function ComponentManager:removeByComId(comId)
	local com = self:getComById(comId)
	if com then
		self:removeCom(com)
	end
end

function ComponentManager:refreshInfoPanel()
	if self.entity.isBoss then
		BattleUIManager:refshBOSSBuff()
		return
	end

	if self.entity.entityType == 2 then
		return
	end

	local panel_debuff = self.panelNode:getChildByTag(7)
	self.buffTable = {}

	for k,v in pairs(self.comList) do
		if v.comId < 82000 then 
			table.insert( self.buffTable , v)
	    elseif v.comId < 83000 and v.comId > 82000 then
	    	table.insert( self.buffTable ,1, v)	    
	    end			
	end

	for k,v in pairs(panel_debuff:getChildren()) do
		if	v ~=nil then 
			v:setVisible(false)
	    end
	end

	if #self.buffTable > 0 then 
		panel_debuff:setVisible(true)
		for i = 1, #self.buffTable do
		    local img = ccui.Helper:seekWidgetByTag(panel_debuff,70+i)
		    if img == nil then 
		    	img = ccui.ImageView:create()
		    	img:setTag(70+i)
		    	panel_debuff:addChild(img)
		    	img:setContentSize(cc.size(36, 36))
		    end  	
		    img:setVisible(true)
		    img:setTouchEnabled(true)
		    img:addTouchEventListener(function(sender,eventType)
                local tag = sender:getTag()-70
                local panel_debuff = self.panelNode:getChildByTag(7)

                if eventType == ccui.TouchEventType.began then --创建显示简短信息
                	
					local buff = self.buffTable[tag]
					local buffNode = cc.CSLoader:createNode("uifile/BuffINfo.csb")
					local icImg  =  buffNode:getChildByTag(2)
					local text = buffNode:getChildByTag(3)
					text:setString(GetStringAllPlatform(buff.comData["state_des"]))
					icImg:loadTexture(buff.comData["state_icon"])
					local point = cc.p(sender:getPosition())
					point.x = point.x+18
					point.y = point.y+20
					buffNode:setPosition(point)
					buffNode:setTag(2000+tag)
					panel_debuff:addChild(buffNode)
                elseif eventType == ccui.TouchEventType.ended  then
                    panel_debuff:removeChildByTag(2000+tag) 
                elseif eventType ==ccui.TouchEventType.canceled then
                    panel_debuff:removeChildByTag(2000+tag)
                end 	
            end)

            if img:getChildByTag(100)==nil then
            	local text = ccui.Text:create("", "font/Microsoft Yahei.ttf", 28)
            	text:setTextColor(cc.BLACK)
	            text:enableOutline(cc.WHITE,2)
	            img:addChild(text)
	            text:setPosition(cc.p(18, 18))
	            text:setTag(100)
            end  	

            local text = img:getChildByTag(100)
            local buff = self.buffTable[i]
            if buff.canOverlay then
               text:setVisible(true)
               text:setString(buff.overlayNum)--叠加的层数
            else
             	text:setVisible(false)    
            end 	
            local  file = buff.comData["state_icon"]
            img:loadTexture(file)
            img:setPosition(cc.p(21+((i-1)%6)*41,23+30*math.floor((i-1)/6.0)))	
		end
    end 
end

--检测某个com是否存在
function ComponentManager:getComById(comId)
	return self.comIdList[comId]
end

--获取某个com的索引值
function ComponentManager:getComIdx(com)
	for k,v in pairs(self.comList) do
		if v == com then
			return k
		end
	end
	return nil
end

--移除制定数量和类型的debuff,仅用于驱散行为
--comType 1:buff 2:debuff
--type:对应com中state_type字段
--num:数量。0：全部。其他：指定数量
function ComponentManager:removeComByTypeAndNum(comType,type,num)
	local temp = {}
	for k,v in pairs(self.comList) do
		if v.comType == comType and v:checkCanBeDispelled() then
			if type == 0 then
				table.insert(temp,v)
			elseif v.state_type == type then
				table.insert(temp,v)
			end
		end
	end

	if num == 0 then
		for k,v in pairs(temp) do
			self:removeCom(v)
		end
	else
		for i = 1,num do
			if temp[i] then
				self:removeCom(temp[i])
			end
		end
	end
end

--检测是否存在buff(任意buff)
function ComponentManager:checkIsBuffExist()
	for k,v in pairs(self.comIdList) do
		if k <82000 then
			return true
		end
	end
	return false
end

--检测是否存在debuff（任意debuff）
function ComponentManager:checkIsDebuffExist()
	for k,v in pairs(self.comIdList) do
		if k < 83000 and k > 82000 then
			return true
		end
	end
	return false	
end

--检测是否存在可驱散的buff
function ComponentManager:checkExist_CanBeDispel()
	for k,v in pairs(self.comList) do
		if v.state_dispel == 1 then
			return true
		end
	end
	return false
end


--检测是否存在不可驱散的buff
function ComponentManager:checkExist_CanNotBeDispel()
	for k,v in pairs(self.comList) do
		if v.state_dispel == 0 then
			return true
		end
	end
	return false
end

--检测是否处于眩晕状态
function ComponentManager:checkIsInVertigo()
	for k,v in pairs(self.comList) do
		if v.comType == 2 and v.buffType == Com_DebuffEnum.Vertigo then
			return true
		end
	end
	return false
end

--获取debuff数量
function ComponentManager:getDebuffNum()
	local ret = 0
	for k,v in pairs(self.comList) do
		if v.comType == 2 then
			ret = ret + 1
		end
	end
	return ret
end

--清除所有com
function ComponentManager:removeAllCom()
	for k,v in pairs(self.comList) do
		self:removeCom(v)
	end
	self.comList = {}
	self.comIdList = {}

end

--检测是否是无敌状态
function ComponentManager:checkIsWuDi()
	if self.WuDi or self.comIdList[81044] then
		return true
	else
		return false
	end
end

--死亡的时候掉用一下
function ComponentManager:onDead()
	for k,v in pairs(self.entity.effectNode:getChildren()) do
		v:setVisible(false)
	end

	self.comList = {}
	self.comIdList = {}

	if self.entity.entityType == 1 then
		local panel_debuff = self.panelNode:getChildByTag(7)
		for k,v in pairs(panel_debuff:getChildren()) do
			v:setVisible(false)
		end
	end

	self.WuDi = false	
	self.TiXianKuiLei = false
	self.EGuiChanRen = false
	self.MeiHuo = false
	self.MeiHuoCom = nil
	self.ShengMingHuDun = false
	self.ShengMingHuDunCom = nil
	self.GeDangHuDun = false
	self.GeDangHuDunCom = nil
	self.DongTuFengYin = false
	self.BaTi = false
	self.LingJianLuanWu = false
	self.ShangHaiZhuanYi = false
	self.ShangHaiZhuanYiCom = nil
end