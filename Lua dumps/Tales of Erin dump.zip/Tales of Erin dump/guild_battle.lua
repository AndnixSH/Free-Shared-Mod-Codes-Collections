-- id      : 逻辑地图点
-- area_id : 真实地图点

guild_battle = {}

guild_battle["resource"] = {}
guild_battle["resource"][1] = "n_UIShare/Global_UI/bg/ghz_bg_001.png"

guild_battle["event"] = {}

guild_battle["event"][1] = {}
guild_battle["event"][1]["id"] = 1
guild_battle["event"][1]["area_id"] = 1
guild_battle["event"][1]["no_select"] = ""
guild_battle["event"][1]["selected"] = ""
guild_battle["event"][1]["show_sort"] = 0
guild_battle["event"][1]["start_time"] = "15:00:00"
guild_battle["event"][1]["end_time"] = "23:00:00"
guild_battle["event"][1]["icon"] = "n_UIShare/AllianceBattle/ghz_ui_016.png"
guild_battle["event"][1]["title"] = "n_UIShare/AllianceBattle/ghz_ui_012.png"
guild_battle["event"][1]["background"] = "n_UIShare/AllianceBattle/ghzjm_bg_004.png"

guild_battle["event"][2] = {}
guild_battle["event"][2]["id"] = 2
guild_battle["event"][2]["area_id"] = 3
guild_battle["event"][2]["no_select"] = ""
guild_battle["event"][2]["selected"] = ""
guild_battle["event"][2]["show_sort"] = 0
guild_battle["event"][2]["start_time"] = "7:00:00"
guild_battle["event"][2]["end_time"] = "14:59:59"
guild_battle["event"][2]["icon"] = "n_UIShare/AllianceBattle/ghz_ui_029.png"
guild_battle["event"][2]["title"] = "n_UIShare/AllianceBattle/ghz_ui_030.png"
guild_battle["event"][2]["background"] = ""

guild_battle["event"][3] = {}
guild_battle["event"][3]["id"] = 3
guild_battle["event"][3]["area_id"] = 2
guild_battle["event"][3]["no_select"] = "n_UIShare/AllianceBattle/ghz_b_005_1.png"
guild_battle["event"][3]["selected"] = "n_UIShare/AllianceBattle/ghz_b_005_2.png"
guild_battle["event"][3]["show_sort"] = 1
guild_battle["event"][3]["start_time"] = "15:00:00"
guild_battle["event"][3]["end_time"] = "23:00:00"
guild_battle["event"][3]["icon"] = "n_UIShare/AllianceBattle/ghzjm_ui_004.png"
guild_battle["event"][3]["title"] = "n_UIShare/AllianceBattle/ghz_ui_013.png"
guild_battle["event"][3]["background"] = "n_UIShare/AllianceBattle/ghzjm_bg_004.png"