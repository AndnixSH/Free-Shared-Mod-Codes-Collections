--require "XUIView"

BackgroundView = class("BackgroundView",XUIView)
BackgroundView.CS_FILE_NAME = "BackgroundView.csb"
BackgroundView.CS_BIND_TABLE = 
{
    btnClose = "/i:417/i:420",
    btnBack = "/i:417/i:418",
    imgBackBG = "/i:417/i:419",
    imgBG = "/i:415",
    panelClose = "/i:417",
    panelGray = "/i:416"
}

function BackgroundView:initWithCloseBtn(childView)
    BackgroundView.super.init(self)
    self.uitype = 1
    self.imgBG:removeFromParent()
    self.imgBG = nil
    self.imgBackBG:removeFromParent()
    self.imgBackBG = nil
    self.btnBack:removeFromParent()
    self.btnBack = nil

    self.view = childView
    self.contView = XUIView.new():init(self.panelGray)
    self.contView:addSubView(childView)
        
    self.panelGray:setTouchEnabled(true)
    self.panelGray:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:onBeforeClose()
            self:returnBack()
        end
    end)

    self.btnClose:addClickEventListener(function()
        self:onBeforeClose()
        self:returnBack()
    end)
    -- self.btnClose:setEffectType(3)
    -- self.btnClose:setVisible(false)
    -- self.btnClose:setTouchEnabled(false)
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end

function BackgroundView:initWithBackBtn(childView)
    BackgroundView.super.init(self)
    self.uitype = 1
    self.imgBG:removeFromParent()
    self.imgBG = nil
    -- self.imgBackBG:removeFromParent()
    -- self.imgBackBG = nil
    -- self.btnBack:removeFromParent()
    -- self.btnBack = nil

    self.view = childView
    self.contView = XUIView.new():init(self.panelGray)
    self.contView:addSubView(childView)
        
    self.panelGray:setTouchEnabled(true)
    self.panelGray:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onBeforeClose()
            self:returnBack()
        end
    end)

    self.btnBack:setEffectType(3)
    self.btnBack:addClickEventListener(function() 
        self:onBeforeClose()
        self:returnBack()    
    end)

    self.panelGray:setSwallowTouches(true)

    self.btnClose:setEffectType(3)
    self.btnClose:setVisible(false)
    self.btnClose:setTouchEnabled(false)
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end

function BackgroundView:onBeforeClose()
    if self.beforeCloseEvent then
        self.beforeCloseEvent(self)
    end
end

function BackgroundView:returnBack()
     KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    if self.uitype == 1 then
        self:removeFromParentView()
        -- if self.AfterCloseEvent then
        --     self.AfterCloseEvent()
        -- end
    elseif self.uitype == 2 then
        if self._navigationView then
            self._navigationView:popView()

            -- if self.AfterCloseEvent then
            --     self.AfterCloseEvent()
            -- end
        end
    end
end