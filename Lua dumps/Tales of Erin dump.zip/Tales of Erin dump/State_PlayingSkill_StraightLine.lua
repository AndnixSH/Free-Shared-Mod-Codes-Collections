--释放贯穿类技能中。（横向发射，暂时全都做成全屏的，长度为1280）

--created by kobejaw.2018.4.27.
State_PlayingSkill_StraightLine = class("State_PlayingSkill_StraightLine",StateBase)

--贯穿类一定有击退，不在spine里，程序添加
function State_PlayingSkill_StraightLine:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.PlayingSkill_StraightLine
	self.isSkill = true
end

function State_PlayingSkill_StraightLine:Enter(skillInfo)
	self.skillInfo = skillInfo;
	self.super.Enter(self)	
end

function State_PlayingSkill_StraightLine:Exit()
	self.super.Exit(self)
end

function State_PlayingSkill_StraightLine:onHit(enemyEntity)
	--击飞
	if enemyEntity.fsm.currentState:checkCanChangeToUnusualState(4) then
		local data = {}
		data.stateType = 4
		data.arg = 3
		enemyEntity.fsm:changeState(StateEnum.UnusualCondition,data)
	end

	--计算伤害
	self:onCauseDamage(1,self.entity,enemyEntity,nil,self.skillInfo.skillData,1)
end

function State_PlayingSkill_StraightLine:onSpineCompleteCallback(event)
	if self.entity.isBoss then
		self.entity.fsm:changeState(StateEnum.Attacking_Boss)
	else
		--技能释放完毕。切换到RunningToEnemy状态
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)		
	end
end

function State_PlayingSkill_StraightLine:onSpineEventCallback(event)
	--震屏，闪烁等处理
	self:dealWithCommonEvents(event,self.skillInfo)

	if self:checkIsAutoplayEvent(event) then
		self:dealWithAutoplayEvent()
	end

	--"cutin"事件
	local result_cutin = self:checkIsCutInEvent(event)
	if result_cutin == 1 then
		G_GameState = 3
		SkillUtil:playCutIn(self.entity)
		if not self.entity.isBoss then
			ActiveSkillManager:refreshSkillWhenCutIn(self.entity.skill[2])
		end
	elseif result_cutin == 2 then
		SkillUtil:playEndCutIn(self.entity)
	end
	
end

function State_PlayingSkill_StraightLine:dealWithAutoplayEvent()
	if self.skillInfo.res_fly == "" or self.entity.isDead then
		return
	end

	local effectSpineNode = CreateEffectSpineNode(self.skillInfo.res_fly,true)

	local fatherNode = cc.Node:create()
	fatherNode:addChild(effectSpineNode)
	G_EffectLayer:addChild(fatherNode)

	local self_x,self_y = self.entity:getPosition()
	--fatherNode:setPosition(self_x + self.entity.data.bulletPos.x, self_y + self.entity.data.bulletPos.y)显示不太对，普通攻击需要考虑出手位置，技能不需要。
	fatherNode:setPosition(self_x, self_y)

	--计算时间
	local pixelsPerFrame = self.skillInfo.skillData.skill_speed
	if pixelsPerFrame == 0 then
		pixelsPerFrame = 80
	end

	local frames = 1280/pixelsPerFrame
	local time = frames/60

	local move,isFromLeftToRight
	if self.entity.faceTo == BattleGlobals.FaceLeft then
		isFromLeftToRight = false
		move = cc.MoveBy:create(time,cc.p(-1280,0))
		effectSpineNode:setRotationSkewY(180)
	else
		isFromLeftToRight = true
		move = cc.MoveBy:create(time,cc.p(1280,0))
	end

	local function removeSelf()
		fatherNode:removeFromParent()
	end

	local sequence = cc.Sequence:create(move, cc.CallFunc:create(removeSelf))
	fatherNode:runAction(sequence)

	local entitiesEffected = {}
	for k,v in pairs(self.entity.enemyList) do
		if not v.isDead then
			if isFromLeftToRight then
				if v:getPositionX() > self_x then
					table.insert(entitiesEffected,v)
				end					
			else
				if v:getPositionX() < self_x then
					table.insert(entitiesEffected,v)
				end		
			end
		end
	end

	local this = self
	local function update(dt)
		local i = 1;
		while i <= #entitiesEffected do
			local x = entitiesEffected[i]:getPositionX()
			local x_flyEffect = fatherNode:getPositionX()

			if isFromLeftToRight and x<=x_flyEffect then
				this:onHit(entitiesEffected[i])
				table.remove(entitiesEffected,i)
			elseif not isFromLeftToRight and x>=x_flyEffect then
				this:onHit(entitiesEffected[i])
				table.remove(entitiesEffected,i)
			else
				i = i + 1
			end
		end
	end
	fatherNode:scheduleUpdateWithPriorityLua(update,0)
end