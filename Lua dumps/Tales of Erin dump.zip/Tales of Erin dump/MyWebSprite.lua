
--------------------------------
-- @module MyWebSprite
-- @extend Sprite
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#MyWebSprite] loadTexTrueWithUrl 
-- @param self
-- @param #char url
-- @return MyWebSprite#MyWebSprite self (return value: MyWebSprite)
        
--------------------------------
-- 
-- @function [parent=#MyWebSprite] onHttpRequestCompleted 
-- @param self
-- @param #cc.network::HttpClient sender
-- @param #cc.network::HttpResponse response
-- @return MyWebSprite#MyWebSprite self (return value: MyWebSprite)
        
--------------------------------
-- 
-- @function [parent=#MyWebSprite] create 
-- @param self
-- @return MyWebSprite#MyWebSprite ret (return value: MyWebSprite)
        
return nil
