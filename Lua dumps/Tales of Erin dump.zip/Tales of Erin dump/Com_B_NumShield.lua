--次数护盾组件
--created by kobejaw. 2018.6.8.
Com_B_NumShield = class("Com_B_NumShield",ComponentBase)

--81032
function Com_B_NumShield:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.NumShield
end

--失去一层次数护盾时调用
function Com_B_NumShield:onLoseOneOverlay()
	self.overlayNum = self.overlayNum - 1
	if self.overlayNum <= 0 then
		self.target.componentManager:removeCom(self)
	else
		self.target.componentManager:refreshInfoPanel()
		--触发时机13.失去一层时。
		local option = {}
		option.tirg_time = 13
		option.comId = self.comId
		self.target.triggerManager:check(13,option)
	end
end