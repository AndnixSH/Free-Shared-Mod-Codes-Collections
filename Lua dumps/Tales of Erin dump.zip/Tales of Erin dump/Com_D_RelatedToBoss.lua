--boss相关的debuff组件
--created by kobejaw.2018.6.30.
Com_D_RelatedToBoss = class("Com_D_RelatedToBoss",ComponentBase)

--82027,82031,82032
function Com_D_RelatedToBoss:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 2
	self.buffType = Com_DebuffEnum.RelatedToBoss
end

--开始生效。
function Com_D_RelatedToBoss:takeEffect(isAdd)
	if not self.target.isBoss then
		return
	end

	--增加bk时间和增加解除虚弱状态的血量
	if self.comId == 82027 then
		if isAdd then
			local addedTime = self.comData.effect1 --增加的bk时间（秒）
			local addedHp = self.comData.effect2   --增加的bk血量百分比
			self.target.attr[AE.bk_t] = self.target.attr[AE.bk_t] + addedTime
			self.target.attr[AE.bk_hp] = self.target.attr[AE.bk_hp] + math.ceil(self.target.attr[AE.bk_hp] * addedHp/100)	
		else
			local addedTime = self.comData.effect1 
			local addedHp = self.comData.effect2
			self.target.attr[AE.bk_t] = self.target.attr[AE.bk_t] - addedTime
			self.target.attr[AE.bk_hp] = self.target.attr[AE.bk_hp] - math.ceil(self.target.attr[AE.bk_hp] * addedHp/100)
		end
	--增加行动点上限	
	elseif self.comId == 82031 then
		if isAdd then
			self.target.attr[AE.energy_max] = self.target.attr[AE.energy_max] + 1
			BattleUIManager:setMcountForBoss(self.target.attr[AE.energy],self.target.attr[AE.energy_max])
		else
			self.target.attr[AE.energy_max] = self.target.attr[AE.energy_max] - 1
			if self.target.attr[AE.energy_max] < 1 then
				self.target.attr[AE.energy_max] = 1
				if self.target.attr[AE.energy] > 1 then
					self.target.attr[AE.energy] = 1
				end
			end
			BattleUIManager:setMcountForBoss(self.target.attr[AE.energy],self.target.attr[AE.energy_max])
		end
	end

	self.super.takeEffect(self,isAdd)
end

