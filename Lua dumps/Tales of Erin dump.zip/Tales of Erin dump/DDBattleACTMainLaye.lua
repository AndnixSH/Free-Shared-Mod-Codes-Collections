DDBattleACTMainLaye = class("DDBattleACTMainLaye",function()
    return cc.Scene:create()
end)
DDBattleACTMainLaye.lClass = 1
DDBattleACTMainLaye.sData = nil
DDBattleACTMainLaye.heroTable = {}
DDBattleACTMainLaye.heroPos = {{460,330},{458,70},{400,200},{300,280},{298,90},{210,202},{130,88},{128,300}}
DDBattleACTMainLaye.monsterTable = {}
DDBattleACTMainLaye.nowMonster = nil
DDBattleACTMainLaye.nowHero = nil
DDBattleACTMainLaye.nowSpeed = nil
DDBattleACTMainLaye.nowHeroATK = 0
DDBattleACTMainLaye.nowHeroCrit = 0
DDBattleACTMainLaye.timeLimit = 0
DDBattleACTMainLaye.nowHerocritAdd = 1.5
DDBattleACTMainLaye.nowHeroEffect = nil
DDBattleACTMainLaye.loadingLayer = nil
DDBattleACTMainLaye.rootLayer = nil
DDBattleACTMainLaye.totalScene = 0
DDBattleACTMainLaye.nowScene = 0
DDBattleACTMainLaye.nowHP = 0
DDBattleACTMainLaye.totalHP = 0
DDBattleACTMainLaye.canTouch =  true 
DDBattleACTMainLaye.rootNode = nil
DDBattleACTMainLaye.loadingData = {}
DDBattleACTMainLaye.sound = nil
DDBattleACTMainLaye.file = nil
DDBattleACTMainLaye.animationSate = 1 --标示当前是否可以播放下个动作
DDBattleACTMainLaye.nowAction = 1 --标示当前是哪个动作
DDBattleACTMainLaye.timeScale = 1 --标示当前的播放速度
DDBattleACTMainLaye.lastName = nil --标示当前的播放速度
DDBattleACTMainLaye.battleend = false --战斗结束
DDBattleACTMainLaye.autobattle= 0 --战斗结束
function DDBattleACTMainLaye:create(rData)
    local DDBattleACT = DDBattleACTMainLaye.new()
    DDBattleACT:init(rData)
    return DDBattleACT
end

function DDBattleACTMainLaye:init(rData)
         self.sData = rData
         --添加场景适配层
         self.screenFitLayer = cc.Layer:create();
          local rootPos = ScreenManager:getInstance():getRootPoint();
          self.screenFitLayer:setPosition(rootPos.x,rootPos.y);
         self:addChild(self.screenFitLayer)

          --添加屏幕适配层
         local screenfitUILayer = ScreenFitMainLayer:create();
         self.screenFitLayer:addChild(screenfitUILayer, 100000);

         self.loadingLayer = cc.loadingLayer:create()
         --self:addChild(self.loadingLayer,121212)
         self.screenFitLayer:addChild(self.loadingLayer,121212)
         self.rootLayer = cc.Layer:create()
         self.rootNode = cc.CSLoader:createNode("DDBattleLayer.csb")
         local panel_4 = self.rootNode:getChildByTag(4)
         local BG_img = panel_4:getChildByTag(117)
         BG_img:setUnifySizeEnabled(true)
         BG_img:loadTexture(map[tonumber(rData["scene_id"])]["map_2"])

         
         local panel_5 = self.rootNode:getChildByTag(5)
         panel_4:addChild(self.rootLayer)
         --self:addChild(self.rootNode ,1)
         self.screenFitLayer:addChild(self.rootNode ,1)
         self.rootNode:setVisible(false)
         local function touchCallBack(sender,eventType)
         	  if eventType == ccui.TouchEventType.ended then
                 local tag = sender:getTag()
                 if tag ==6 then
                 panel_5:setVisible(true) 	
                 elseif tag==501 then
                 self:showLose()
                 elseif tag ==502 then
                 panel_5:setVisible(false) 	
                 end
              end
         end
         
         local btn = self.rootNode:getChildByTag(6)
         btn:addTouchEventListener(touchCallBack)

         for i=1,2 do
         	 local _btn = panel_5:getChildByTag(500+i)
         	 _btn:addTouchEventListener(touchCallBack)
         end
         AudioManager:shareDataManager():stopBGMusic()
         self.autobattle = self.sData["auto"]
         self:startGame()

end

function DDBattleACTMainLaye:attackMonster(data)
	
	if self.nowMonster ~=nil then
	   self.nowMonster:playHit(data)
	else
	   return	
	end
    if  self.battleend == true then
             return
    end 
    
    if self.nowHP == 0 then
       self:paseGame(1)
       self.nowMonster:pruge()
       self.nowMonster = nil
       self.nowScene = self.nowScene+1
       if self.nowScene < self.totalScene + 1 then
       	  self:showBattleStart(2)
       else 
          self:showVictor()	  
       end
       return	
    end

    self.nowHP = self.nowHP -  tonumber(data["dmg"]) 
    if self.nowHP < 0 then
    	self.nowHP = 0
    end
    
	local panel_3 = self.rootNode:getChildByTag(3)
	local text_3 = panel_3:getChildByTag(301)
	local loading = panel_3:getChildByTag(302)
	local prent = self.nowHP*100/self.totalHP
	loading:setPercent(prent)
	text_3:setString(self.nowHP.."/"..self.totalHP)
end

function DDBattleACTMainLaye:showVictor()
	self:stopAllActions()
	 AudioManager:shareDataManager():stopBGMusic()
	local skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache("effects/zhandoushengli/zhandoushengli.atlas"))
	skeletonNode:setPosition(640, 360)
	skeletonNode:registerSpineEventHandler(
	            function (event) 
	            print(string.format("[spine] %d end:", event.trackIndex))
	            self:exitGame()
	            local NowNode = SceneManager:getRootNode()
                NowNode:reqBattleResult()
	end, sp.EventType.ANIMATION_END)
	--self:addChild(skeletonNode,123)
  self.screenFitLayer:addChild(skeletonNode,123)
	skeletonNode:addAnimation(1,"effect",false)
	AudioManager:shareDataManager():playMusic("music/battle/b8.mp3",0, false)
    self:paseGame(1)

end


function DDBattleACTMainLaye:showLose()
	self:stopAllActions()
	self.battleend = true;
	AudioManager:shareDataManager():stopBGMusic()
	local skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache("effects/zhandoushibai/zhandoushibai.atlas"))
	skeletonNode:setPosition(0, 720)
	skeletonNode:registerSpineEventHandler(
	            function (event) 
	            print(string.format("[spine] %d end:", event.trackIndex))
	            self:exitGame()
	end, sp.EventType.ANIMATION_END)
	--self:addChild(skeletonNode,123)
  self.screenFitLayer:addChild(skeletonNode,123)
  
	skeletonNode:addAnimation(1,"effect",false)
	AudioManager:shareDataManager():playMusic("music/ui/battlefail.mp3",0, false)
    self:paseGame(1)

end


function DDBattleACTMainLaye:playAnimation(name)
	if self.nowHero ==nil then
		return
	end
	if name~="loading" and name ~= "run" then
			if self.lastName == "attack1" then
               name = "attack2"								
			end
			print("将要播放动作"..name.."当前速度"..self.timeScale)
			self.lastName = name
			self.nowHero:setToSetupPose()
			self.nowHero:clearTracks()
			self.nowHero:addAnimation(1, name, false)
			self.nowHero:addAnimation(1, "loading", true)
			self.animationSate = 2
		    --cc.SimpleAudioEngine:getInstance():playEffect(self.sound, false)
		    AudioManager:shareDataManager():playMusic(self.sound,0, false)
			local rNum = math.random(100)
			local mode = 0
				local dmg = self.nowHeroATK
				if rNum < self.nowHeroCrit then
				   mode = 1
                   dmg = math.ceil(self.nowHeroATK*self.nowHerocritAdd)
				end 
				local data = {}
				data["dmg"] = dmg
				data["mode"] = mode 
				data["effect"] = self.nowHeroEffect
				self:attackMonster(data)  
		--end
	else
		   self.nowHero:addAnimation(1, name, true)		
	end
end


function DDBattleACTMainLaye:showTimelimit()
         self:stopAllActions()
         if  self.battleend == true then
             return
         end 	
         local function showTime()
              self.timeLimit = self.timeLimit - 1
              local panel_1 = self.rootNode:getChildByTag(1)
              local textTime = panel_1:getChildByTag(101)
              textTime:setString(self.timeLimit)
              if self.timeLimit < 1  then
              	 self:stopAllActions()
              	 self:showLose()
              end
         end
         local  delay = cc.DelayTime:create(1)
		 local sequence = cc.Sequence:create(delay, cc.CallFunc:create(showTime))
		 local action = cc.RepeatForever:create(sequence) 
		 self:runAction(action)

end


function DDBattleACTMainLaye:addHero()
     self.nowHero = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(self.file))
	 self.nowHero:registerSpineEventHandler(
            function (event) 
            print(string.format("[spine] %d end:", event.trackIndex))
            self.animationSate = 1
            end, sp.EventType.ANIMATION_END)
	self.animationSate = 1 
	self.nowHero:setAnimation(1, "loading", true)
	self.nowHero:setPosition(640,200)
	self.rootLayer:addChild(self.nowHero,-200)

end
function DDBattleACTMainLaye:startDelayTouch( )
    if self.canTouch then 
        print("can touch, not delay")
    else 
        local function resetTouch()
            self.rootLayer:stopAllActions()
            self.canTouch = true
            print("resetTouch")
        end
        local  delayAction = cc.DelayTime:create(0.07)
        local sequence = cc.Sequence:create(delayAction, cc.CallFunc:create(resetTouch))
        self.rootLayer:runAction(sequence)   
    end 
end

-- function DDBattleACTMainLaye:testCode(str,posX)
--   -- body
--       local label = cc.Label:createWithTTF(str, TEXT_FONT_NAME, 24)
--     local label = ccui.Text:create(str,TEXT_FONT_NAME,24)
--     local label = ccui.Text:create()
--     label:setString(str)
--     label:setFontSize(24)
--     label:setPosition(cc.p(640+posX,360))
--     if color ~= nil then
--       label:setColor(color)
--     end
   
--     local function removeThis()
--         label:removeFromParent()
--     end

--     local moveBy  = cc.MoveBy:create(1.5,cc.p(0,200))
--     local fadeOut = cc.FadeOut:create(2.0)
--     local spawn = cc.Spawn:create(moveBy,fadeOut)
--     label:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(removeThis)))
--     self.rootLayer:addChild(label, 9999,888)
-- end

function DDBattleACTMainLaye:startGame()
        local function touchCallBack(sender,eventType)
         	  if eventType == ccui.TouchEventType.ended then
                --self:testCode("touch",-100)
                print("touch end ")
                if self.canTouch == false then
                    print("touch skip")
                 	  return
                end 
                --self:testCode("end",100)
                print("touch deal")
                self.canTouch = false

                self:startDelayTouch()

         	     self.nowHero:stopActionByTag(1010)
         	     self.timeScale = self.timeScale +0.4
         	     if self.timeScale > 4 then
         	     	self.timeScale = 4
         	     end
               self.nowHero:setTimeScale(self.timeScale)
         	     local function resetTime()
    				       self.timeScale = 1
    				       self.nowHero:setTimeScale(self.timeScale)
				       end
      				 local  delay = cc.DelayTime:create(0.4)
      				 local sequence = cc.Sequence:create(delay, cc.CallFunc:create(resetTime))
      				 sequence:setTag(1010)
      				 self.nowHero:runAction(sequence)
      				 self:playAnimation("attack1")
              end
          end
        


        local panel_4 = self.rootNode:getChildByTag(4)
        panel_4:addTouchEventListener(touchCallBack)
        panel_4:setTouchEnabled(true)

        self.totalScene = #self.sData["monster"]
        self.nowScene = 1
        self.heroTable= {}
         for k,v in pairs(self.sData["team_list"]) do
                  	print(k,v)
                    local hdata = {}
                    local heroId = tonumber(getStrID(v["hero_id"]))
                    print("英雄ID"..heroId)
                    hdata["file"] = hero[heroId]["hero_bat"]
                    hdata["sound"] = hero[heroId]["hero_vce"][3]
                    hdata["effect"] = Attack[hero[heroId]["hero_atk1"]]["res_hit"]
                    hdata["celerity"] = v["asp"]
					hdata["critRate"] = v["crit"]
					hdata["atk"] = v["atk"]
					hdata["start_celerity"] = 0.3*tonumber(k-1)
					hdata["manager"] = self
					hdata["callBackFuc"] = self.attackMonster
					local heroCard = HeroCard:create(hdata)
					heroCard.Sp:setPosition(cc.p(self.heroPos[k][1], self.heroPos[k][2]))
					self.rootLayer:addChild(heroCard.Sp,-self.heroPos[k][2])
					self.heroTable[k] = heroCard
					self.loadingData[k] = hdata["effect"]
         end 
        
         
         for k,v in pairs(self.sData["monster"]) do
                  	
                    local hdata = {}
                    local heroId = tonumber(v["m_id"])
                    hdata["file"] = monster[heroId]["monster_bat"]
                    print("boss的地址"..hdata["file"])
                   -- hdata["sound"] = hero[heroId]["hero_vce"][3]
                    hdata["sn_id"] =  v["sn_id"]
					hdata["HP"] = v["hp"]
					hdata["x"] = v["x"]
					hdata["y"] = v["y"]
					hdata["hit_x"] = monster[heroId]["monster_bd"][1]
					hdata["hit_y"] = monster[heroId]["monster_bd"][2]
					hdata["manager"] = self
					self.monsterTable[k] = hdata
         end 
       
        self.loadingData[#self.loadingData] = self.monsterTable[1]["file"]
        local heroId = self.sData["hero"]["hero_id"]
		self.file = hero[heroId]["hero_bat"]
		self.sound = hero[heroId]["hero_vce"][3]
		self.nowHeroEffect = Attack[hero[heroId]["hero_atk1"]]["res_hit"]
		self.nowHeroCrit = self.sData["hero"]["crit"]
		self.nowHeroATK = self.sData["hero"]["atk"]
        self.loadingData[#self.loadingData] = hero[heroId]["hero_bat"]
        self.nowScene =1
        self.timeLimit = tonumber(self.sData["time_limit"])
        local panel_1 = self.rootNode:getChildByTag(1)
        local textTime = panel_1:getChildByTag(101)
        textTime:setString(self.timeLimit)
        local loadNum = 0
		local function addNext()
		       loadNum = loadNum + 1
		       print("加载数据中"..loadNum)
		       SPCacheManager:getSPFromCache(self.loadingData[loadNum])  
		end
        
        local function addFinsh()
        	  print("加载结束")
              self:addHero()
        	  self.rootNode:setVisible(true)
        	  self.loadingLayer:setVisible(false)
              self:addNextBOSS()
              --cc.SimpleAudioEngine:getInstance():playMusic(map[tonumber( self.sData["scene_id"])]["voice_2"], true)
              AudioManager:shareDataManager():playMusic(map[tonumber( self.sData["scene_id"])]["voice_2"], 0,true)
		end

		local  delay = cc.DelayTime:create(0.1)
		local sequence = cc.Sequence:create(delay, cc.CallFunc:create(addNext))
		local action = cc.Repeat:create(sequence,#self.loadingData) 
		local seq = cc.Sequence:create(action, cc.CallFunc:create(addFinsh))  
		self:runAction(seq)
end



function DDBattleACTMainLaye:autoTouch()
    local function touch()
    if self.canTouch == false then
                    print("touch skip")
                    return
      end 
      --self:testCode("end",100)
      print("touch deal")
      self.canTouch = false

      self:startDelayTouch()

     self.nowHero:stopActionByTag(1010)
     self.timeScale = self.timeScale +0.4
     if self.timeScale > 4 then
      self.timeScale = 4
     end
     self.nowHero:setTimeScale(self.timeScale)
     local function resetTime()
         self.timeScale = 1
         self.nowHero:setTimeScale(self.timeScale)
     end
     local  delay = cc.DelayTime:create(0.4)
     local sequence = cc.Sequence:create(delay, cc.CallFunc:create(resetTime))
     sequence:setTag(1010)
     self.nowHero:runAction(sequence)
     self:playAnimation("attack1")
  end
  local  delay1 = cc.DelayTime:create(0.1)
  local sequence1 = cc.Sequence:create(delay1, cc.CallFunc:create(touch))
  local action_se = CCRepeatForever:create(sequence1)
  local panel_4 = self.rootNode:getChildByTag(4)
  panel_4:runAction(action_se)
end

function DDBattleACTMainLaye:showBattleStart(mode)
	local action = cc.CSLoader:createTimeline("uifile/BattleStart.csb")
	local actionNode = self.rootNode:getChildByTag(7)
	actionNode:stopAllActions()
	actionNode:runAction(action)
	actionNode:setVisible(true)
	self:stopAllActions()
	if mode ==1 then
	   local function showCallBack() 
	   	self:paseGame(0)
	   	self:showTimelimit()
	   	actionNode:setVisible(false)
      if self.autobattle==1  then
        self:autoTouch()
      end 
      
       end
       action:setLastFrameCallFunc(showCallBack)
       local m_text =actionNode:getChildByTag(3):getChildByTag(32)
        m_text:setString(self.nowScene.."/"..self.totalScene)
        action:play("Start", false)	
     elseif mode == 2 then
       local function showCallBack() 
	   	     self:addNextBOSS()
       end
       action:setLastFrameCallFunc(showCallBack) 
       action:play("scroll1", false)   
	end
end

function DDBattleACTMainLaye:addNextBOSS()
		self.nowMonster =  MonsterCard:create(self.monsterTable[self.nowScene])
		self.nowMonster.Sp:setPosition(cc.p(self.monsterTable[self.nowScene]["x"], self.monsterTable[self.nowScene]["y"]))
		self.rootLayer:addChild(self.nowMonster.Sp,-10000)
		self:resetTopBar(self.monsterTable[self.nowScene])
		self:showBattleStart(1)
end


function DDBattleACTMainLaye:resetTopBar(data)

     self.nowHP = tonumber(data["HP"]) 
     self.totalHP = tonumber(data["HP"]) 
	 local panel_3 = self.rootNode:getChildByTag(3)
	 local text_3 = panel_3:getChildByTag(301)
	 local loading = panel_3:getChildByTag(302)
	 loading:setPercent(100)
	 text_3:setString(data["HP"].."/"..data["HP"])

	 local panel_2 = self.rootNode:getChildByTag(2)
	 local text_1 = panel_2:getChildByTag(201)
	 local text_2 = panel_2:getChildByTag(202)

     text_1:setString(string.format(UITool.ToLocalization("第%d层"),self.sData["level_id"]))
	 text_2:setString(string.format(UITool.ToLocalization("第%d/%d波"),self.nowScene,self.totalScene))

end


function DDBattleACTMainLaye:paseGame(state)
	local panel_4 = self.rootNode:getChildByTag(4)
	if state==0 then
	    panel_4:setTouchEnabled(true)
	    self.canTouch = true
	    for k,v in pairs(self.heroTable) do
            print(k)
	    	v:start()
	    end
    else		
		panel_4:setTouchEnabled(false)
                panel_4:stopAllActions()
		for k,v in pairs(self.heroTable) do
	    	v:paseAttack()
	    end
        
        if self.nowHero ~=nil then
			self.animationSate = 2
			self.nowHero:setToSetupPose()
			self.nowHero:clearTracks()
			self.nowHero:setTimeScale(1)
			self.nowHero:addAnimation(1, "loading", true)
			self.nowAction = 1
            self.timeScale = 1
            self.lastName = nil
        end

	end
end

function DDBattleACTMainLaye:exitGame()
	self:stopAllActions()
	--cc.SimpleAudioEngine:getInstance():stopAllEffects()
	 AudioManager:shareDataManager():stopAll()
   local panel_4 = self.rootNode:getChildByTag(4)
   panel_4:stopAllActions()
	self.rootLayer:setTouchEnabled(false)
	for k,v in pairs(self.heroTable) do
    	v:pruge()
    end
    self.heroTable = {}
    if self.nowMonster ~= nil then
       self.nowMonster:pruge()
    end

   for k,v in pairs(self.loadingData) do
   	   SPCacheManager:removeSPFromCache(v)
   end

    cc.Director:getInstance():popScene()
     local fullpath = lua_musci["zhuyeBGM"]
      AudioManager:shareDataManager():preloadM(fullpath)
	  AudioManager:shareDataManager():playBGMusic(fullpath, true)
end

