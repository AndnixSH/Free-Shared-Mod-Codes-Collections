--require "XUIView"

EquipRskView = class("EquipRskView",XUIView)
EquipRskView.CS_FILE_NAME = "EquipRskView.csb"
EquipRskView.CS_BIND_TABLE = 
{
    lbTitle = "/i:3/i:4/s:lbTitle", -- 随机技能转换  请选择一个特性
    pLeft = "/i:3/i:4/s:pLeft", 
    -- lEqName = "/i:3/i:4/s:pLeft/s:eqName", 
    -- lSkLevel = "/i:3/i:4/s:pLeft/s:skLevel", 
    -- lSkDesc = "/i:3/i:4/s:pLeft/s:lbSkillDesc", 
    -- lPrsk1 = "/i:3/i:4/s:pLeft/s:pRsk1", 
    -- lRskDesc1 = "/i:3/i:4/s:pLeft/s:pRsk1/s:rskDesc",
    -- lPrsk2 = "/i:3/i:4/s:pLeft/s:pRsk2", 
    -- lRskDesc2 = "/i:3/i:4/s:pLeft/s:pRsk2/s:rskDesc", 
    lFrame = "/i:3/i:4/s:pLeft/s:frame",  

    pRightNo = "/i:3/i:4/s:pRightNo", 
    pRight = "/i:3/i:4/s:pRight", 
    -- rEqName = "/i:3/i:4/s:pRight/s:eqName", 
    -- rSkLevel = "/i:3/i:4/s:pRight/s:skLevel", 
    -- rSkDesc = "/i:3/i:4/s:pRight/s:lbSkillDesc", 
    -- rPrsk1 = "/i:3/i:4/s:pRight/s:pRsk1", 
    -- rRskDesc1 = "/i:3/i:4/s:pRight/s:pRsk1/s:rskDesc",
    -- rPrsk2 = "/i:3/i:4/s:pRight/s:pRsk2", 
    -- rRskDesc2 = "/i:3/i:4/s:pRight/s:pRsk2/s:rskDesc",   
    rFrame = "/i:3/i:4/s:pRight/s:frame",    

    lbMatTitle = "/i:3/i:4/s:pRightNo/i:40", 
    lbMatNum = "/i:3/i:4/s:pRightNo/i:174", 
    lbMatNum1 = "/i:3/i:4/s:pRightNo/i:175", 
    
    pButtons = "/i:3/i:4/s:pButtons", 
    btnCancel = "/i:3/i:4/s:pButtons/i:149", 
    btnRsk = "/i:3/i:4/s:pButtons/i:147", 
    btnOk = "/i:3/i:4/s:btnOk", 
}
--EquipRskView.updateInfoEvent = nil

function EquipRskView:initWithData(equip_id,old_data)
    EquipRskView.super.init(self)
    self.exist = true;
    self.equip_id = equip_id
    self.eq_old_data = old_data

    self:fillContent(self.pLeft,self.eq_old_data)

    self.lFrame:setVisible(false)
    self.rFrame:setVisible(false)
    self.btnOk:setVisible(false)
    self.pRight:setVisible(false)

    --self.pButtons:setVisible(true)
    --self.pRightNo:setVisible(true)
    --self.pLeft:setTouchEnabled(false)
    --self.pRight:setTouchEnabled(false)
    --self.lbTitle:setString("")
    
    local mid = getMatID(ID_EQUIP_RSK)
    local cnt = user_info["bag"]["mat"][ID_EQUIP_RSK]
    if not cnt then cnt = 0 end
    self.lbMatTitle:setString(UITool.getUserLanguage(mat[mid].name))--(mat[mid].name)
    self.lbMatNum:setPosition(10 + self.lbMatTitle:getPositionX() + self.lbMatTitle:getContentSize().width,self.lbMatTitle:getPositionY())
    self.lbMatNum:setString(""..cnt)
    if cnt < 1 then
        self.lbMatNum:setTextColor(cc.c3b(255,0,0))
    end
    self.lbMatNum1:setPosition(self.lbMatNum:getPositionX() + self.lbMatNum:getContentSize().width,self.lbMatNum:getPositionY())

    self.pRightNo:setTouchEnabled(true)
    self.pRightNo:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local mid = getMatID(ID_EQUIP_RSK)
            MsgManager:showSimpItemInfo(5,mid)
        end
    end)

    self.pLeft:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self.final_choice = 1
            self.lFrame:setVisible(true)
            self.rFrame:setVisible(false)
        end
    end)

    self.pRight:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self.final_choice = 2
            self.lFrame:setVisible(false)
            self.rFrame:setVisible(true)
        end
    end)

    self.btnCancel:addClickEventListener(function()
        self:returnBack()
    end)
    self.btnRsk:addClickEventListener(function()
        self:onBtnRsk()
    end)
    self.btnOk:addClickEventListener(function()
        if self.final_choice == 1 then
            --还原
            self:onEqRevert()
        else
            if self.beforeCloseEvent then
                self.beforeCloseEvent(self)
            end
            self:returnBack()
        end
    end)

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end

function EquipRskView:returnBack( )
    -- body
    self.exist = false;
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function EquipRskView:fillContent(panel,data)
    local e_id_num = getNumID(self.equip_id)
    
    panel:getChildByName("eqName"):setString(UITool.getUserLanguage(equip[e_id_num]["equip_name"]))--(equip[e_id_num]["equip_name"])
    -- panel:getChildByName("skLevel"):setString("技能等级"..data["sk"]["Lv"])

    -- local str_des = equip[e_id_num]["equip_skill"]["skill_des"]
    -- --str_des = string.gsub(str_des,"%*",""..(data["sk"]["add_atk_rate"]).."%%")
    -- str_des = UITool.stringForEqSK(str_des,data["sk"]["add_atk_rate"])
    -- panel:getChildByName("lbSkillDesc"):setString(str_des)
    
    for i = 1,2 do
        local prsk = panel:getChildByName("pRsk"..i)
        if data and data["rsk"] ~= nil and data["rsk"][i] ~= nil then
            prsk:setVisible(true)
            local strsrc = UITool.getUserLanguage(eq_random_sk[data["rsk"][i][1]])--eq_random_sk[data["rsk"][i][1]]
            strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][i][2]))
            prsk:getChildByName("rskDesc"):setString(strsrc)
        else
            prsk:setVisible(false)
        end
    end
end

function EquipRskView:afterRsk()
    self.pRightNo:setVisible(false)
    self.pRight:setVisible(true)
    self.pButtons:setVisible(false)

    self.btnOk:setVisible(true)

    self.pLeft:setTouchEnabled(true)
    self.pRight:setTouchEnabled(true)
    self.rFrame:setVisible(true)
    self.final_choice = 2

    self.lbTitle:setString(UITool.ToLocalization("请选择一个结果"))

    self:fillContent(self.pRight,self.eq_new_data)

end

function EquipRskView:onBtnRsk()
    if not self.equip_id then
        return
    end

    local mid = getMatID(ID_EQUIP_RSK)
    local cnt = user_info["bag"]["mat"][ID_EQUIP_RSK]
    if not cnt then
        cnt = 0
    end

    if cnt <= 0 then 
        GameManagerInst:alert(""..UITool.getUserLanguage(mat[mid].name)..UITool.ToLocalization("不足"))
        return
    end

    --GameManagerInst:confirm("是否消耗1个"..mat[mid].name.."(现有"..cnt.."个)",function()  
        local tempData = {
            rpc = "eq_rsk_change",
            eq_id = self.equip_id,
        } 
        GameManagerInst:rpc(tempData,3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            user_info["eq"][self.equip_id] = table.deepcopy(data["eq_data"])
            DataManager:rfsElist()
            --self:loadInfo()
            if user_info["bag"]["mat"][ID_EQUIP_RSK] then
                user_info["bag"]["mat"][ID_EQUIP_RSK] = user_info["bag"]["mat"][ID_EQUIP_RSK] - 1
            end
            self.eq_new_data = table.deepcopy(data["eq_data"])

            if self.updateInfoEvent then
                self.updateInfoEvent(self,data["eq_data"])
            end
            
            self:afterRsk()
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
    --end)
end

function EquipRskView:onEqRevert()
    local tempData = {
        rpc = "eq_rsk_rollback",
        eq_id = self.equip_id,
    } 
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        user_info["eq"][self.equip_id] = table.deepcopy(data["eq_data"])
        DataManager:rfsElist()
        --self.eq_new_data = table.deepcopy(data["eq_data"])
        if self.updateInfoEvent then
            self.updateInfoEvent(self,data["eq_data"])
        end

        if self.beforeCloseEvent then
            self.beforeCloseEvent(self)
        end
        self:returnBack()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end
