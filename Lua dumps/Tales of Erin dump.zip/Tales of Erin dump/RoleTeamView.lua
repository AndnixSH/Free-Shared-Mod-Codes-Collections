--require "XUIView"
--require "RoleTeamItemView"

RoleTeamView = class("RoleTeamView",XUIView)
RoleTeamView.CS_FILE_NAME = "RoleTeamView.csb"
RoleTeamView.CS_BIND_TABLE = 
{
    psPanel = "/i:364/i:27",
    psShortImg = "/i:364/i:27/i:26",
    psVdrawImg = "/i:364/i:190",

    lbTitle = "/i:364/i:344",
    btnLeft = "/i:364/i:378",
    btnRight = "/i:364/i:379",
    btnPSKill = "/i:364/i:367",
    panel1 = "/i:364/i:204/i:205",
    panel2 = "/i:364/i:204/i:206",
    panel3 = "/i:364/i:204/i:207",
    panel4 = "/i:364/i:204/i:208"
}


function RoleTeamView:init()
    RoleTeamView.super.init(self)
    self.items = {}
    
    self.currentTeamIndex = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
    if self.currentTeamIndex == 0 then
        self.currentTeamIndex = 1
    end    
    self.beginTeamIndex = self.currentTeamIndex

    for i = 1,4 do
        self.items[i] = RoleTeamItemView.new():init(self["panel"..i],i)
        self.items[i].BtnInfoClick = function(index)
            --GameManagerInst:alert("self:ItemInfo   "..index)
            self:ItemInfo(index)            
        end
        self.items[i].BtnAddClick = function(index)
            --GameManagerInst:alert("self:ItemAdd   "..index)
            self:ItemAdd(index)
        end
    end

    self.psPanel:setVisible(false)
    self.psVdrawImg:setVisible(false)

    self.btnPSKill:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toPSkillLayer({resetcallback = function()  
                self:loadTeamList()
            end})
        end
    end)
 
    self.btnLeft:addClickEventListener(function()
        self:changeTeam(0)
    end)

    self.btnRight:addClickEventListener(function()
        self:changeTeam(6)
    end)

    self:setNodeLockState()

    return self
end

function RoleTeamView:loadTeamList(callback)
    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success

        DataManager:wTeamData(data["team"])

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleTeamView:loadTeam()
    --["team_fp"]
    
    local teamInfo = team_list[""..self.currentTeamIndex]
    local teamInfoList = nil
    if teamInfo and teamInfo["team"] then
        teamInfoList = teamInfo["team"]
    end

    for i = 1,4 do
        local h = nil
        if teamInfoList and teamInfoList[i] then
            h = teamInfoList[i]
        end
        self.items[i]:setRoleInfo(h or {id="0"})
    end

    --左侧公主信息
    if teamInfo and teamInfo["ps"] then
        local oid =  teamInfo["ps"]  --公主职业id
        local end_pos = string.find(oid,'_') - 1
        local gid = string.sub(oid,0,end_pos)
        local psinfo = princess_ocp[gid][oid]

        if psinfo then
            local vdrawpath = psinfo.ps_vdraw
            if vdrawpath ~= nil and vdrawpath ~= "" then
                self.psVdrawImg:setVisible(true)
                self.psVdrawImg:setTexture(vdrawpath)
            else
                self.psVdrawImg:setVisible(false)
            end

            local namepath = psinfo.ps_name_short
            if namepath ~= nil and namepath ~= "" then
                self.psPanel:setVisible(true)
                self.psShortImg:setTexture(namepath)
            else
                self.psPanel:setVisible(false)
            end
        else
            self.psPanel:setVisible(false)
            self.psVdrawImg:setVisible(false)
        end
    end
    
    --GameManagerInst:alert(oid)

    --self.lbTitle:setString(""..num..","..oid)
    local titles = {UITool.ToLocalization("第一编队"),UITool.ToLocalization("第二编队"),UITool.ToLocalization("第三编队"),UITool.ToLocalization("第四编队"),UITool.ToLocalization("第五编队")}
    self.lbTitle:setString(titles[self.currentTeamIndex])
    
end

function RoleTeamView:changeTeam(idx)
    if idx < 1 then
        self.currentTeamIndex = self.currentTeamIndex - 1
    elseif idx > 5 then
        self.currentTeamIndex = self.currentTeamIndex + 1
    else
        self.currentTeamIndex = idx
    end

    if self.currentTeamIndex < 1 then
        self.currentTeamIndex = 5
    end

    if self.currentTeamIndex > 5 then
        self.currentTeamIndex = 1 
    end

    cc.UserDefault:getInstance():setIntegerForKey("teamIdx",self.currentTeamIndex)
    self:loadTeam()
end

function RoleTeamView:ItemAdd(index)
    --GameManagerInst:alert("添加"..index)    
    local b,v = RoleListView.createWithBackBtn()

    v.ItemClickedEvent = function(item)
        --GameManagerInst:alert("self:onEditTeam("..index..","..item:getData().id)   
        self:onEditTeam(index,item:getData().id)
        b:returnBack()
    end

    v.ItemResetEvent = function(item)
        local rdata = item:getData()
        if rdata.isCurrentRole then
            --当前点中的人
            item:showOutTeam()
        end
    end

    v.dataSourceEvent = function(sender,sort_mode)
        local ds = {}
        local outteam = {}       
            
        local temp_data = nil
        if team_list[""..self.currentTeamIndex] ~= nil and team_list[""..self.currentTeamIndex]["team"] ~= nil then
            temp_data = team_list[""..self.currentTeamIndex]["team"]
        end

        for i = 1,#hero_list do
            local rdata = table.deepcopy(hero_list[i])
            local notInTeam = true

            for j = 1,4 do
                if temp_data ~= nil and temp_data[j] ~= nil and temp_data[j].id == rdata.id then
                    --在队伍中
                    table.insert(ds,rdata)
                    --当前点中的人
                    rdata.isCurrentRole = (j == index)

                    notInTeam = false
                    break
                end
            end

            if notInTeam then
                rdata.team_list = {}
                table.insert(outteam,rdata)
            end
        end

        SortBoxView.SortRole (ds, sort_mode ,false)
        SortBoxView.SortRole (outteam, sort_mode ,false)

        for i = 1,#outteam do
            table.insert(ds,outteam[i])
        end
        return ds
    end

    v:refresh()

    --新手引导 编队 保存数据
    if user_info["guide_id"] == guide_id_config.Team then
        self.ng_b = b
        self.ng_needId = v.currentDataSource[2].id
    end

    --GameManagerInst:showModalView(b)
    self:addSubView(b)
end

function RoleTeamView:onEditTeam(index,hid)
    local temp_data = team_list[""..self.currentTeamIndex]

    --原始队伍信息
    local teamData = {}
    for i=1,4 do
        teamData[i] = temp_data["team"][i].id
    end    

    local nosame = true

    for i = 1,4 do
        if teamData[i] == hid then
            if i ~= index then
            --点了其他人
                teamData[i] = teamData[index]
                teamData[index] = hid
            else
                --点了自己
                teamData[index] = "0"
            end

            nosame = false
            break
        end
    end

    if nosame then
        teamData[index] = hid
    end

    local temp_team = {}
    temp_team["rpc"] = "team_edit"
    temp_team["team_id"] = self.currentTeamIndex
    temp_team["ps_id"] = temp_data["ps"]
    temp_team["team_info"] = teamData        

    GameManagerInst:rpc(temp_team,3,
    function(data)
        --success
        --第一次编队之后，更改下本地的配置
        if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam)~=1 then 
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam,1)
        end
        self.beginTeamIndex = self.currentTeamIndex
        DataManager:wTeamData(data["team"])

        for k,v in pairs(data["change_hero_list"]) do
            user_info["hero"][k] = table.deepcopy(v)
        end        
        DataManager:rfsHlist()

        self:refresh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleTeamView:saveTeamIndex(callback)
    if self.beginTeamIndex == self.currentTeamIndex then
        if callback then
            callback()
        end
        return
    end
    
    local temp_data = team_list[""..self.currentTeamIndex]
    local teamData = {}
    if temp_data then
        for i=1,4 do
            if temp_data["team"] and temp_data["team"][i] then
                teamData[i] = temp_data["team"][i].id
            end
        end 
    end
       
    local temp_team = {}
    temp_team["rpc"] = "team_edit"
    temp_team["team_id"] = self.currentTeamIndex
    if temp_data and temp_data["ps"] then
        temp_team["ps_id"] = temp_data["ps"]
    end
    temp_team["team_info"] = teamData       

    
    GameManagerInst:rpc(temp_team,3,
    function(data)
        --success
        self.beginTeamIndex = self.currentTeamIndex
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleTeamView:ItemInfo(index)
    --GameManagerInst:alert("详情"..index)
    local tempinfo = team_list[""..self.currentTeamIndex]["team"]
    local tempds = {}
    for i = 1,#tempinfo do
        if tempinfo[i].id ~= "0" then
            table.insert(tempds,tempinfo[i].id)
        end
    end

    local data = tempinfo[index]

    if GameManagerInst.gameType == 1 then
        if g_channel_control.b_newRole then
            GameManagerInst.view:pushView(NewRoleMainView.new():init(data.id,tempds,self.currentTeamIndex))
        else
            GameManagerInst.view:pushView(RoleInfoView.new():init(data.id,tempds,self.currentTeamIndex))
        end
    elseif GameManagerInst.gameType == 2 then
        SceneManager:toRoleInfo({ hid = data.id  , 
            hlist = tempds,
            teamidx = self.currentTeamIndex
            })
    end
end

function RoleTeamView:refresh()
    self:loadTeam()
    self:dealRedDotPrompt() 
end

--新手引导
function RoleTeamView:newGuideTeamFunc()
    --新手引导 编队
    self:onEditTeam(2,self.ng_needId)
    self.ng_b:returnBack()
end

--设置按钮等级解锁状态
function RoleTeamView:setNodeLockState()
    local curNodes = {self.btnPSKill}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleTeamView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        end 
    end  
    self:dealRedDotPrompt() 
end
---根据本地配置表处理按钮小红点的显示状态
function RoleTeamView:dealRedDotPrompt()
    local event_3 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Godhead)   --队伍按钮，神格按钮
     self:setbtnPSKillRedDop(false)
    if event_3 == 0 then --队伍按钮，神格按钮
        self:setbtnPSKillRedDop(true)
    end 
end
--神格小红点显示
function RoleTeamView:setbtnPSKillRedDop(_isShow)
    local oldTip = self.btnPSKill:getChildByTag(TIP_POINT_TAG)
    if _isShow then 
        if oldTip == nil then 
            local p = cc.p(self.btnPSKill:getContentSize().width,self.btnPSKill:getContentSize().height)
            UITool.addTipPoint(self.btnPSKill,p, TIP_POINT_TAG)
        end 
    else
        if oldTip ~= nil then 
            oldTip:removeFromParent(true)
            oldTip = nil 
        end 
    end  
end
--去 PSkillLayer
function RoleTeamView:toPSkillLayer()
    SceneManager:toPSkillLayer({resetcallback = function() 
        self:loadTeamList()
    end})
end
