BOX_EFF_COUNT = 0  --掉落宝箱特效数量 播放时加1  播放完成后减1

BoxItemNode = class("BoxItemNode", function()
    return cc.Node:create()
end)

function BoxItemNode:ctor( data )
    
end
function BoxItemNode:initialize(data)
    dump(data,"initialize")
    if data == nil then
        return
    end
    self._data = data
    self:initData()
    self:initUi()
end

function BoxItemNode:initUi( ... )
    -- body
    local node = cc.CSLoader:createNode("BattleEnd_item.csb")
    self:addChild(node)
    self.rootNode = node
    self.Panel_root = self.rootNode:getChildByTag(1)
    self.Panel_root:setSwallowTouches(false)
    self.Image_bg = self.Panel_root:getChildByTag(11)
    self.Image_icon = self.Panel_root:getChildByTag(12)
    self.Image_rarity = self.Panel_root:getChildByTag(13)
    self.Sprite_attr = self.Panel_root:getChildByTag(1872)
    self.Sprite_new = self.Panel_root:getChildByTag(407)
    self.Text_count = self.Panel_root:getChildByTag(14)
    self.Text_creater = self.Panel_root:getChildByTag(15)
    self.Sprite_box = self.rootNode:getChildByTag(2)
    self.panel_touch = self.rootNode:getChildByTag(1038)
    self.panel_touch:setSwallowTouches(false)
    self.Text_creater:setString("")

    self:setNodeScaleTo70()
    self.panel_touch:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended and BOX_EFF_COUNT == 0 then
            self:showComInfo(self.show_type,self.show_id,self.show_num,self.real_id)
        end
    end)
end

function BoxItemNode:initData()
    -- body
    local itemID = self._data["id"]
    local num = self._data["num"]
    local itemType = self._data["type"]
    self.index = 1
    self.aniType = "hong"  --1 红 2 金 3 银 4 铜
    self.aniTypeNum = self:initBoxAnimationType(itemID,itemType)
    if self._data == nil then
        return
    end
    if self._data["sp_type"] == 1 then  --创建者奖励
        --self.Text_creater:setString("创建者")
    elseif self._data["sp_type"] == 2 then  --贡献奖励
        --self.Text_creater:setString("贡献")
    elseif self._data["sp_type"] == 4 then
        self.aniType = "x_jin"
    else --if self.resultData["drop"][i]["sp_type"] == 3 then --普通奖励
        --self.Text_creater:setString("")
        if self.aniTypeNum == 5 then
            self.aniType = "jin"
        elseif self.aniTypeNum == 4 then
            self.aniType = "yin"
        else
            self.aniType = "tong"
        end
    end
    self.show_type = self._data["type"]
    self.show_id = self._data["id"]
    self.show_num = self._data["num"]
    self.real_id = self._data["real_id"]
end
function BoxItemNode:setNodeScaleTo70( ... )
    -- body
    self.rootNode:setScale(0.7)
end

function BoxItemNode:setIndex( index )
    -- body
    self.index = index
end

function BoxItemNode:getIndex( ... )
    -- body
    return self.index
end

function BoxItemNode:refershView( ... )
    -- body
    if not self._data then return end
    local itemID = self._data["id"]
    local num = self._data["num"]
    local itemType = self._data["type"]
    local dataConf = self:getItemDataConf(itemID,itemType,num)
    self:refreshItemView(dataConf)
end

--通关奖励窗口
function BoxItemNode:showComInfo(item_type,item_id,num,real_id)
    if item_type == 3 and real_id ~= nil then 
        GameManagerInst:rpc( 
            {
                rpc = "eq_info",
                eq_id = real_id
            },
            3,
            function(data)
                --success
                local equipInfos = {}
                equipInfos.rsk = data["eq"][real_id].rsk
                MsgManager:showRewardItem(item_type,item_id,num, equipInfos) 
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText)
            end,
        true)
    else 
         MsgManager:showRewardItem(item_type,item_id,num) 
    end 
end

function BoxItemNode:playAnim(time)
    -- body
    local delay = cc.DelayTime:create(time)
    local action_2 = cc.CSLoader:createTimeline("BattleEnd_item.csb")
    action_2:setLastFrameCallFunc(function()
        BOX_EFF_COUNT = BOX_EFF_COUNT - 1
    end)

    self.rootNode:runAction(action_2)
    action_2:play(self.aniType, false)
    action_2:pause()

    local playanime = cc.CallFunc:create(function ()
        if action_2 and tolua.isnull(action_2) == false then
            action_2:resume()
        end
    --cc.SimpleAudioEngine:getInstance():playEffect("music/ui/boxopeneff.mp3", false)  
    AudioManager:shareDataManager():playMusic("music/ui/boxopeneff.mp3", 0,false)
    end)

    local sequence = cc.Sequence:create(delay,playanime)
    --table.insert(drop_items_list,reItem)
    BOX_EFF_COUNT = BOX_EFF_COUNT + 1
    self.Panel_root:setVisible(true)
    self.Panel_root:runAction(sequence)
end

function BoxItemNode:stopAnim( ... )
    -- body
    self.rootNode:stopAllActions()
    self.Panel_root:stopAllActions()
    self.Sprite_box:setVisible(false)
    self.Panel_root:setOpacity(255) 
end

function BoxItemNode:refreshItemView( dataConf )
    -- body
      local isNew = self._data["new"] or 0
      if isNew == 1 then
        self.Sprite_new:setVisible(true)
      else
        self.Sprite_new:setVisible(false)
      end

      self.Text_count:setString(dataConf[14])

      if dataConf[10] ~= nil then
        self.Sprite_attr:setTexture(dataConf[10])
      else
        self.Sprite_attr:setVisible(false)
      end

      if dataConf[11] ~= nil then
          self.Image_bg:setUnifySizeEnabled(true)
          self.Image_bg:loadTexture(dataConf[11])
      end

      self.Image_icon:setUnifySizeEnabled(true)
      self.Image_icon:loadTexture(dataConf[12])

      self.Image_rarity:setUnifySizeEnabled(true)
      self.Image_rarity:loadTexture(dataConf[13])
end

function BoxItemNode:initBoxAnimationType( id,type)
  -- body
    local m_type = type
    local m_id = id
    local aniTypeNum = 0 
    if m_type == 3 then  --装备
        aniTypeNum = equip[m_id]["equip_rank"]
    elseif m_type == 4 then --英雄
        aniTypeNum = hero[m_id]["hero_rank"]
    elseif m_type == 5 then
        aniTypeNum = mat[m_id]["rarity"]
    elseif m_type == 6 then--可使用道具
        aniTypeNum = useprop[m_id]["rarity"]  --品质
    elseif m_type == 1 then --金币
        aniTypeNum = 3       
    elseif m_type == 2 then  --石头
        aniTypeNum = 5       
    elseif g_channel_control.b_drop_cangyu == true and m_type == 13 then
      aniTypeNum = 4    
    end
    return aniTypeNum
end

function BoxItemNode:getItemDataConf( id,type,num )
  -- body
    local m_type = type
    local m_id = id
    local m_num = num
    local reTable = {
      [14] = "x"..num
    }
    local aniTypeNum = 0
    local itemID = m_id 
    if m_type == 3 then  --装备
        aniTypeNum = equip[itemID]["equip_rank"]
        reTable[12] = equip[itemID]["equip_list_icon"]
        reTable[11] = Rarity_E_BG[aniTypeNum]
        reTable[10] = ATB_Icon[equip[itemID].equip_atb]
        reTable[13] = Rarity_Icon[aniTypeNum]
    elseif m_type == 4 then --英雄
        aniTypeNum = hero[itemID]["hero_rank"]
        reTable[13] = Rarity_Icon[hero[itemID]["hero_rank"]]
        reTable[12] = hero[itemID]["hero_list_icon"]
        reTable[10] = ATB_Icon[hero[itemID]["hero_atb"]]   --属性
        reTable[11] = Rarity_BG[aniTypeNum]
    elseif m_type == 5 then
        aniTypeNum = mat[itemID]["rarity"]
        reTable[12] = "icons/mat/"..mat[itemID]["icon"]
        reTable[11] = Rarity_BG[aniTypeNum]          
        reTable[13] = Rarity_mat[aniTypeNum]
    elseif m_type == 6 then--可使用道具
        aniTypeNum = useprop[itemID]["rarity"]  --品质
        reTable[13] = Rarity_mat[useprop[itemID]["rarity"]] --  --框  1
        reTable[12] = "icons/mat/"..useprop[itemID]["icon"]  --icon 2  
        reTable[11] = Rarity_BG[aniTypeNum]  --beijing  4
    elseif m_type == 1 then --金币
        aniTypeNum = 3     
        reTable[12] = Coin_Icon[1]   
        reTable[11] = Rarity_BG[aniTypeNum]
        reTable[13] = Rarity_mat[aniTypeNum]  
    elseif m_type == 2 then  --石头
        aniTypeNum = 5     
        reTable[12] = Coin_Icon[5]
        reTable[11] = Rarity_BG[aniTypeNum]
        reTable[13] = Rarity_mat[aniTypeNum]  
    elseif g_channel_control.b_drop_cangyu == true and m_type == 13 then
      aniTypeNum = 4    
      reTable[12] = Coin_Icon[8]
      reTable[11] = Rarity_BG[aniTypeNum]
      reTable[13] = Rarity_mat[aniTypeNum]  
    elseif g_channel_control.b_drop_cangyu == true and m_type == 8 then  --碎片
      aniTypeNum = piece[itemID]["rarity"]
      reTable[12] = "icons/mat/"..piece[tonumber(itemID)]["icon"]  
      reTable[11] = Rarity_BG[aniTypeNum]
      reTable[13] = Rarity_mat[aniTypeNum] 
    end
    self.aniTypeNum = aniTypeNum
    return reTable
end

function BoxItemNode:create(data)
    local node = BoxItemNode.new()
    node:initialize(data)
    return node
end
