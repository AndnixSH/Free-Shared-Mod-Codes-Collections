area_boss_info = {} 
area_boss_info["a1_1"] = {
    icon="icons/stageboss/dt_ui_bstx_74.png"
}
area_boss_info["a1_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1517.png"
}
area_boss_info["a2_2"] = {
    icon=""
}
area_boss_info["a2_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1527.png"
}
area_boss_info["a2_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1528.png"
}
area_boss_info["a3_2"] = {
    icon="icons/stageboss/dt_ui_bstx_1543.png"
}
area_boss_info["a3_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1520.png"
}
area_boss_info["a3_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1523.png"
}
area_boss_info["a4_2"] = {
    icon="icons/stageboss/dt_ui_bstx_1523.png"
}
area_boss_info["a4_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1565.png"
}
area_boss_info["a4_5"] = {
    icon="icons/stageboss/dt_ui_bstx_1520.png"
}
area_boss_info["a4_7"] = {
    icon="icons/stageboss/dt_ui_bstx_82.png"
}
area_boss_info["b1_1"] = {
    icon="icons/stageboss/dt_ui_bstx_74.png"
}
area_boss_info["b1_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1517.png"
}
area_boss_info["a2_2"] = {
    icon=""
}
area_boss_info["b2_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1527.png"
}
area_boss_info["b2_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1528.png"
}
area_boss_info["b3_2"] = {
    icon="icons/stageboss/dt_ui_bstx_1543.png"
}
area_boss_info["b3_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1520.png"
}
area_boss_info["b3_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1523.png"
}
area_boss_info["b4_2"] = {
    icon="icons/stageboss/dt_ui_bstx_1523.png"
}
area_boss_info["b4_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1565.png"
}
area_boss_info["b4_5"] = {
    icon="icons/stageboss/dt_ui_bstx_1520.png"
}
area_boss_info["b4_7"] = {
    icon="icons/stageboss/dt_ui_bstx_82.png"
}
area_boss_info["c1_1"] = {
    icon="icons/stageboss/dt_ui_bstx_74.png"
}
area_boss_info["c1_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1517.png"
}
area_boss_info["c2_2"] = {
    icon=""
}
area_boss_info["c2_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1527.png"
}
area_boss_info["c2_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1528.png"
}
area_boss_info["c3_2"] = {
    icon="icons/stageboss/dt_ui_bstx_1543.png"
}
area_boss_info["c3_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1520.png"
}
area_boss_info["c3_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1523.png"
}
area_boss_info["c4_2"] = {
    icon="icons/stageboss/dt_ui_bstx_1523.png"
}
area_boss_info["c4_3"] = {
    icon="icons/stageboss/dt_ui_bstx_1565.png"
}
area_boss_info["c4_5"] = {
    icon="icons/stageboss/dt_ui_bstx_1520.png"
}
area_boss_info["c4_7"] = {
    icon="icons/stageboss/dt_ui_bstx_82.png"
}
area_boss_info["l1_5"] = {
    icon="icons/stageboss/dt_ui_bstx_1595.png"
}
area_boss_info["l44_7"] = {
    icon="icons/stageboss/dt_ui_bstx_1701.png"
}
area_boss_info["a5_3"] = {
    icon="icons/stageboss/dt_ui_bstx_399.png"
}
area_boss_info["a5_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1607.png"
}
area_boss_info["a5_5"] = {
    icon="icons/stageboss/dt_ui_bstx_400.png"
}
area_boss_info["b5_3"] = {
    icon="icons/stageboss/dt_ui_bstx_399.png"
}
area_boss_info["b5_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1607.png"
}
area_boss_info["b5_5"] = {
    icon="icons/stageboss/dt_ui_bstx_400.png"
}
area_boss_info["c5_3"] = {
    icon="icons/stageboss/dt_ui_bstx_399.png"
}
area_boss_info["c5_4"] = {
    icon="icons/stageboss/dt_ui_bstx_1607.png"
}
area_boss_info["c5_5"] = {
    icon="icons/stageboss/dt_ui_bstx_400.png"
}