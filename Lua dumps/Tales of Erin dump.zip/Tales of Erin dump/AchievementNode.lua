

AchievementNode = class("AchievementNode", XUICellView)
AchievementNode.CS_FILE_NAME = "AchievementNode.csb"
AchievementNode.curId    = nil -- 成就Id
AchievementNode.ItemType = nil -- 获得物品类型
AchievementNode.ItemId   = nil -- 获得物品Id
AchievementNode.ItemNum  = nil -- 获得物品数量
AchievementNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}

function AchievementNode:init(...)
    AchievementNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    return self
end
function AchievementNode:onResetData()
	 print("第一步  执行 AchievementNode onResetData")
	 if not self._data then return end
	 print("没有 执行 AchievementNode onResetData")
        ----------------获取需要的资源-------------------------------------------------
             local dataT = {
                ["state"] = self._data["state"],         -- 状态 # 0 未完成 1 已完成 2 已领取
                ["num"]   = self._data["reward_num"],    -- 数量
                ["cur_n"] = self._data["curr_times"] ,   -- 次数
                ["max_n"] = self._data["finish_times"],  -- 最大次数
            }
            local rid      = tonumber(self._data["id"])  -- 成就ID
            self.curId     = rid
            print("rid rid == "..rid)
            dataT["id"]    = rid
            dataT["name"] = ""
            if achi_everyday_conf[rid] and achi_everyday_conf[rid]["achi_name"] then
                dataT["name"]  = UITool.getUserLanguage(achi_everyday_conf[rid]["achi_name"])--achi_everyday_conf[rid]["achi_name"]
            end
            dataT["dec"] = ""
            if achi_everyday_conf[rid] and achi_everyday_conf[rid]["achi_desc"] then
                dataT["dec"]   = UITool.getUserLanguage(achi_everyday_conf[rid]["achi_desc"])--achi_everyday_conf[rid]["achi_desc"]
            end
            dataT["icon"] = ""
            if achi_everyday_conf[rid] and achi_everyday_conf[rid]["achi_icon"] then
                dataT["icon"]  = achi_everyday_conf[rid]["achi_icon"] -- 任务图标
            end
            
            local rwid     = self._data["reward_id"]   -- 道具Id
            local rwType   = self._data["reward_type"] -- 道具类型
            dataT["itemId"]= rwid
            dataT["type"]  = rwType
            self.ItemId    = rwid
            self.ItemType  = rwType
            self.ItemNum   = dataT["num"]
            --print("itemId == "..rwid)
            --print("type  === "..rwType)
            local popr = {}
            if dataT["type"]   == 1 then
                 --dataT["rname"]  = "金币"

                popr = UITool.getItemInfos(1,1)
            elseif dataT["type"] == 2 then
                 --dataT["rname"]  = "星石"
                popr = UITool.getItemInfos(2,1)
            else
                popr = UITool.getItemInfos(dataT["type"],dataT["itemId"])
            end
            local itme_info = self.PanelList
            local tex_name  = itme_info:getChildByName("Text_name")  -- name
            local tex_dec   = itme_info:getChildByName("Text_dec")   -- 描述
            local icon      = itme_info:getChildByName("Image_icon") -- 物品图片
            icon:setUnifySizeEnabled(true)

            
            local icon_Achiv   = itme_info:getChildByName("Image_2")     -- 任务图标
            icon_Achiv:setUnifySizeEnabled(true)
            icon_Achiv:loadTexture( dataT["icon"] )

            local icon_bg   = itme_info:getChildByName("Image_icon_bg")     -- 物品背景
            local icon_fr   = itme_info:getChildByName("Image_icon_form")   -- 物品框
            local iconNum   = itme_info:getChildByName("BitmapFontLabel_1") -- 数量
            local bar_1     = itme_info:getChildByName("LoadingBar_1")  --  为完成的
            local bar_2     = itme_info:getChildByName("LoadingBar_2")  -- 完成的进度条
            local Text_f    = itme_info:getChildByName("Text_4")        -- 完成显示CLEAR  未完成 1/2
            local but_get   = itme_info:getChildByName("Button_get")    -- 获取按钮
           -- local image_s   = itme_info:getChildByName("Image_s")       -- 获取是特效框
            local imag_h_f  = itme_info:getChildByName("Image_panel")   -- 领取后显示
            local touch_panel = itme_info:getChildByName("Panel_touch")  --触摸区域
            touch_panel:setVisible(false)
            ------------------------------显示处理--------------------------------
            imag_h_f:setSwallowTouches(false)
            ----字体描边处理
            tex_name:enableOutline(cc.c4b(0,0,0,255),1)
            tex_dec:enableOutline(cc.c4b(0,0,0,255),1)
            Text_f:enableOutline(cc.c4b(0,0,0,255),1)
            itme_info:getChildByName("Text_3"):enableOutline(cc.c4b(0,0,0,255),1)

            if g_channel_control.transform_AchievementNode_text_bonus_pos == true then
                local text_3 = itme_info:getChildByName("Text_3")
               
                text_3:setPositionX(534)
            end
           -- but_get:getChildByName("Text_5"):enableOutline(cc.c4b(0,0,0,255),1)
            ----原尺寸大小
            --icon:setUnifySizeEnabled(true)
            tex_name:setString(dataT["name"])
            tex_dec:setString(dataT["dec"])

            icon_bg:loadTexture(popr[4])


            if rwType ~= 16 then -- 称号成就
                icon:loadTexture(popr[2])
                icon_fr:loadTexture(popr[1])
              
            end
              icon:setTouchEnabled(true)
  

            iconNum:setString("x"..dataT["num"])
            if dataT["state"] == 0 then -- 状态 # 0 未完成 1 已完成 2 已领取
                bar_1:setVisible(true)
                bar_2:setVisible(false)
                local  percent = math.ceil(dataT["cur_n"] / dataT["max_n"] * 100)
                bar_1:setPercent(percent)
                but_get:setVisible(false)
                touch_panel:setVisible(false)
                touch_panel:setTouchEnabled(false)
               -- image_s:setVisible(false)
                imag_h_f:setVisible(false)
                Text_f:setString( dataT["cur_n"].."/"..dataT["max_n"])
            elseif dataT["state"] == 1 then
                bar_1:setVisible(false)
                bar_2:setVisible(true)
                bar_2:setPercent(100)

                but_get:setVisible(true)
                touch_panel:setVisible(true)
                touch_panel:setTouchEnabled(true)
               -- image_s:setVisible(true)
                imag_h_f:setVisible(false)
                Text_f:setString(UITool.ToLocalization("已完成"))
            elseif dataT["state"] == 2 then
                bar_1:setVisible(false)
                bar_2:setVisible(true)
                bar_2:setPercent(100)
                but_get:setVisible(false)
                touch_panel:setVisible(false)
                touch_panel:setTouchEnabled(false)
               -- image_s:setVisible(false)
                imag_h_f:setVisible(true)
                Text_f:setString(UITool.ToLocalization("已完成"))
                -------------------
             
            end
            local function onCickItem( sender,eventType )
                if eventType == ccui.TouchEventType.ended then
                    --print("dataT state == "..dataT["state"]);
                    print("进入了这；i")
                    if dataT["type"] ~= 16 then
                        if dataT["state"] == 1 then
                            print("dataT state 11111 == "..dataT["state"]);
                        else
                            print("dataT state 2222 == "..dataT["state"]);
                            MsgManager:showSimpItemInfo(dataT["type"],dataT["itemId"])
                        end
                    else
                        if dataT["state"] == 1 then
                            print("dataT state 11111 == "..dataT["state"]);
                        else
                            print("dataT state 2222 == "..dataT["state"]);
                            MsgManager:showBaseSpine(dataT["itemId"])
                        end
                        
                    end

                end
            end 
            icon:addTouchEventListener(onCickItem)    
            -- local function touchCallBack( sender,eventType )
            --     -- body
            --     if eventType == ccui.TouchEventType.ended then
            --         self:sendGet(dataT)
            --     end
            -- end 
            -- but_get:addTouchEventListener(touchCallBack)
           -- image_s:addTouchEventListener(touchCallBack)
    	if self.resetDataEvent then
        	self.resetDataEvent(self)
    	end

end


