-- 聊天数据类
-- 与服务器交互:reqNimData,getChatRoomInfo
-- sdk 交互，lua发起：callLoginNim，sendChatMessage，enterChatRoom，exitChatRoom，getUserInfo，updateMyUserInfo,
--				getSystemNotification,removeSystemNotification,callAddFriend,callAddBlack,callRemoveFromBlack
--				getBlacks,getFriends,voiceRecord,sendChatVoice,playRecordVoice
-- sdk 交互，sdk返回：receiveSendMessageData，onReceiveSystemNotification
-- 聊天本地数据存取d

--后续计划，更新玩家账号ID（player_id），Android需要更新 updateUserInfo参数列表 
--语音，举报（参数：玩家ID，文字内容），公会群组（历史记录） 
-- 

ChatDataManager = class("ChatDataManager")
ChatDataManager.__index = ChatDataManager
ChatDataManager.instance = nil

-- ChatDataManager.TestMode = true ---开启测试模式
-- ChatDataManager.showconsole = true -- 控制台模式
function ChatDataManager:getInstance(  )
	if self.instance == nil then
		self.instance = self.new()
		self.instance:init()
	end
	return self.instance
end

function ChatDataManager:init( )
	self.uiDelegate = nil --UI代理
	self.user_list_all = {}
	self.p2p_list = {}
	self.worldChat_list = {}
	self.team_list = {}
	self.friends_list 	 		= nil
	self.black_list 			= nil
	self.recent_list 			= nil 
	self.loginNimOK = false
	self.chatroomState = {} --聊天室状态，是否已经进入
	-- list["index_max"] --数据层当前最大index
	self.chatroom_list_sava_len	= 100 --数据层列表存储上限
	self.sessionHistoryState = nil --[session_type][session_id] 历史记录状态
end

function ChatDataManager:reqNimData( callback )
	--每次进入都重新请求数据
	-- 请求服务器，获取登陆账号，密码
	-- {u'info': {u'accid': u'186fv8tvm_1', u'token': u'cbcdf3c5f189e65e6fc167b7c0aaf426'}, u'code': 200}
	-- {u'info': {u'accid': u'320ak5m7y_tw', u'token': u'8b9c37647caabfb2a84cc128317371f3'}, u'code': 200}
	-- {u'info': {u'accid': u'nim_id_test_1', u'token': u'a900bc257645b60454e1c18435fa2f73', u'name': u'name'}, u'code': 200}
	if self.showconsole == true then
		print("控制台模式，直接获取token，accid")
		chat_info = {
		 	accid = "nim_id_test_1",
		 	chat_token = "a900bc257645b60454e1c18435fa2f73",
		 	guild_group_id = 468222206, --群组ID
		 	world_chat_list = {22397593, 22484973, 22417122, 22417123, 22446756, 22397594, 22502038, 22437178, 22550573, 22540624, 22456555, 22387870, 22550574, 22550575, 22437179, 22358556, 22406994, 22358557, 22417124, 22417125, 22417126, 22417127, 22502039, 22510882, 22417128, 22406995, 22466591, 22446757, 22466592, 22446758, 22510883, 22417129, 22484974, 22484975, 22550576, 22406996, 22406997, 22550577, 22358558, 22484976, 22406998, 22358559, 22484977, 22387871, 22428442, 22417130, 22484978, 22428443, 22530524, 22417131, 22446759, 22502040, 22406999, 22417132, 22407000, 22494914, 22502041, 22407001, 22407002, 22358560, 22484979, 22407003, 22510884, 22397595, 22367843, 22446760, 22397596, 22417133, 22494915, 22367844, 22446761, 22446762, 22466593, 22484980, 22417134, 22407004, 22540625, 22428444, 22540626, 22358561, 22437180, 22378567, 22397597, 22358562, 22378568, 22378569, 22540627, 22407005, 22397598, 22437181, 22550578, 22428445, 22466594, 22466595, 22378570, 22466596, 22378571, 22502042, 22428446, 22446763},
		 	defalut_world_id = 1,
		 	default_world_chat = 1,
		 	chat_conf = {
		 		max_person = 1000,
		 		world_chat_limit = 1,
		 		guild_chat_limit = 1,
		 		fight_chat_limit = 1,
		 		private_chat_limit = 1,
		 		temp_user_can_join = 1,

		 	},
		}
		if callback then
        	callback()
        end
		return
	end
	local function receiveNIMCallBack( data )
		print("获取云信accid,token")
		data = tolua.cast(data,"PassData")
		print("callback----"..data:getData())

        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
        	SceneManager:delWaitLayer()
            return
        end 

		if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
        	SceneManager:delWaitLayer()
	 		return
        end 
        SceneManager:delWaitLayer()
        ----登陆云信
        if t_data["data"]["state_code"]  == 1 then
            chat_info["accid"]         		= t_data["data"]["accid"]		--云信账号
            chat_info["chat_token"]   	 	= t_data["data"]["chat_token"]	--云信token
            chat_info["guild_group_id"] 	= t_data["data"]["guild_group_id"]  --公会聊天室ID
            chat_info["world_chat_list"]	= t_data["data"]["world_chat_list"] --世界频道列表，用于玩家切换聊天室[输入1-max]
            -- chat_info["sys_chat_id"]		= t_data["data"]["sys_chat_id"]		--系统聊天室id 世界消息中的系统消息同时添加到此频道
            chat_info["defalut_world_id"]	= t_data["data"]["default_world_chat"]	--默认世界频道索引，
            chat_info["chat_conf"]			= t_data["data"]["chat_conf"]
            if chat_info["chat_conf"] ~= nil and type(chat_info["chat_conf"]) == type({}) then
            	chat_info["max_person"] = chat_info["chat_conf"]["max_person"]		--世界聊天人数上限
            	chat_info["world_chat_limit"] = chat_info["chat_conf"]["world_chat_limit"] --世界聊天时间间隔
            	chat_info["guild_chat_limit"] = chat_info["chat_conf"]["guild_chat_limit"]
            	chat_info["fight_chat_limit"] = chat_info["chat_conf"]["fight_chat_limit"]
            	chat_info["private_chat_limit"] = chat_info["chat_conf"]["private_chat_limit"]
            end

        	dump(chat_info["world_chat_list"], "chat_info[world_chat_list]")

        end
        if callback then
        	callback()
        end
	end

    SceneManager:createWaitLayer()
    dump(user_info,"user_info")
	local cjson = require "cjson"
    local tempTable = {
        ["rpc"]       = "chat_info",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  chatLayer mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),receiveNIMCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,10)
end

function ChatDataManager:getChatRoomInfo( _roomid,callfunc )
	print("---获取聊天室信息：roomid:".._roomid)

	local function receiveRoomInfoCallBack( data )
		local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            SceneManager:delWaitLayer()
            return
        end 

		if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            SceneManager:delWaitLayer()
	 		return
        end 

        SceneManager:delWaitLayer()
	    -- dump(t_data, "receiveRoomInfoCallBack")
	    if callfunc then
	    	callfunc(t_data["data"],_roomid)
	    end
	end
        
    SceneManager:createWaitLayer()

	local cjson = require "cjson"
    local tempTable = {
        rpc       = "get_person",
        roomid 	  = _roomid
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  chatLayer mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),receiveRoomInfoCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,10)
end

function ChatDataManager:translateMessage( source_text,source_lang,target_lang,callback )
	print("translate:source_text"..tostring(source_text).."...source_lang:"..tostring(source_lang).."....target_lang:"..tostring(target_lang))

	local languageCode = cc.Application:getInstance():getCurrentLanguageCode()
	if languageCode=="zh" then
		languageCode=""
	end
	local function translateCallback( data )
		local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            SceneManager:delWaitLayer()
            return
        end 
        -- dump(t_data,"translateMessageJson")
		if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(t_data["data"]["warning"])
            SceneManager:delWaitLayer()
	 		return
        end 

        SceneManager:delWaitLayer()
	    dump(t_data, "translateCallback")
	    if callback then
	    	callback(t_data["data"])
	    end
	end

	local cjson = require "cjson"
	local tempTable = {
		rpc = "translate_google",
		source_text = source_text,  --当前文字
		source_lang = "",	        --当前编码
		target_lang = tostring(languageCode),	--目标编码
	}
	local mydata = cjson.encode(tempTable)
	print("translate_google:source_text:"..tostring(source_text).."..source_lang"..tostring(source_lang).."....target_lang:"..tostring(target_lang))

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),translateCallback, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
	
	

end

function ChatDataManager:setDelegate( uiSender )
	self.uiDelegate = uiSender 
end
function ChatDataManager:clearUIDelegate(  )
	self.uiDelegate = nil 
end

function ChatDataManager:getNimId(  )
	return chat_info["accid"]
end

function ChatDataManager:isMyself( nid )
	local me = self:getNimId()
	if string.lower(me) == string.lower(nid) then
		return true
	end
	return false
end

function ChatDataManager:getChatRoomState( roomid )
	return self.chatroomState[roomid]
end

function ChatDataManager:setChatRoomState(roomid,state)
	self.chatroomState[roomid] = state
end

function ChatDataManager:getSessionHistoryState( session_type,session_id )
	if self.sessionHistoryState == nil then
		return false
	end
	if self.sessionHistoryState[session_type] == nil then
		return false
	end
	if self.sessionHistoryState[session_type][session_id] == nil then
		return false
	end
	print("getSessionHistoryState:...session_type:"..tostring(session_type).."...session_id:"..tostring(session_id).."...:"..tostring(self.sessionHistoryState[session_type][session_id]))
	return self.sessionHistoryState[session_type][session_id]
end

function ChatDataManager:setSessionHistoryState( session_type ,session_id,bTrue)
	print("setSessionHistoryState..session_type:"..tostring(session_type).."..session_id:"..tostring(session_id).."...:"..tostring(bTrue))
	if self.sessionHistoryState == nil then
		self.sessionHistoryState = {}
	end
	if self.sessionHistoryState[session_type] == nil then
		self.sessionHistoryState[session_type] = {}
	end
	self.sessionHistoryState[session_type][session_id] = bTrue
end

function ChatDataManager:isShowGuide(  )
	local isShow = false
    if chat_info["guild_group_id"] and tostring(chat_info["guild_group_id"]) ~= "-1" then
    	isShow = true
    else
    	isShow = false
    end
    return isShow
end

function ChatDataManager:getGuideID(  )
	return tostring(chat_info["guild_group_id"])
end

function ChatDataManager:addChannelRedDop( channleTag,childTag ) --
	if self.uiDelegate ~= nil then
		self.uiDelegate:addChannelRedDop(channleTag,childTag,true)
	end
end
function ChatDataManager:getRoomIndexDefault(  )
	local roomid_index = 1
	local default_world_index = tonumber(chat_info["defalut_world_id"])
	if default_world_index ~= nil then
		roomid_index = default_world_index
	end
	return roomid_index
end

function ChatDataManager:getRoomIDByIndex( index )
	local chatLen = #chat_info["world_chat_list"]
	if chatLen < index  then
		return "0"
	end
	return tostring(chat_info["world_chat_list"][index])--["roomid"])
end

function ChatDataManager:getSpeakInterval( index ) -- 2 世界 3 战斗，4 私聊5 公会
	local interval = 10
	if index == 2 then
		interval =  chat_info["world_chat_limit"]
	elseif index == 3 then
		interval = chat_info["fight_chat_limit"]
 	elseif index == 4 then
 		interval = chat_info["private_chat_limit"]
 	elseif index == 5 then
 		interval = chat_info["guild_chat_limit"]
	end
	if interval == nil then
		interval = 10
	end
	return interval
end

function ChatDataManager:getChatRoomLimitCount( ... )
	return tonumber(chat_info["max_person"])
end

function ChatDataManager:getListByType( sessionType,sessionId ) --类型，玩家ID/聊天室ID/群组ID
	print("sessionType:"..sessionType)
	local data_list = nil
	if sessionType == 0 then
		if self.p2p_list == nil then
			self.p2p_list = {}
		end
		if sessionId ~= nil  then	
			local lowSessionId = string.lower(sessionId)
			print("sessionId:"..lowSessionId)	
			if self.p2p_list[lowSessionId] ==nil then
				self.p2p_list[lowSessionId] = {}
				--将人添加到对应list中（好友，最近，黑名单）
			end
			data_list = self.p2p_list[lowSessionId]
		end
	elseif sessionType == 1 then 
		if self.team_list == nil then
			self.team_list = {}
		end
		if sessionId ~= nil  then	
			local lowSessionId = string.lower(sessionId)
			print("sessionId:"..lowSessionId)	
			if self.team_list[lowSessionId] ==nil then
				self.team_list[lowSessionId] = {}
			end
			data_list = self.team_list[lowSessionId]
		end
	elseif sessionType == 2 then --聊天室  根据sessionId int转string 判断
		if self.worldChat_list == nil then
			self.worldChat_list = {}
		end
		if self.worldChat_list[sessionId] == nil then
			self.worldChat_list[sessionId] = {}
		end
		data_list = self.worldChat_list[sessionId]
		-- print("data_list:.."..#data_list)
	else
		print("error.....pushChatItemData...sessionType:"..sessionType)
		return nil
	end

	return data_list
end

function ChatDataManager:saveUserInfo( nim_id ,nim_data,refrushUser) --保存/刷新 所有交互玩家信息 
	if nim_id == nil  then
		return
	end
	if self.user_list_all == nil then
		self.user_list_all = {}
	end
	if refrushUser or nim_data == nil then 
		local function callSaveUserInfo( t_data )
			-- for k,v in pairs(t_data) do
			-- 	print("saveUserInfo2222:",k,v)
			-- end
			local n_id = string.lower(nim_id)
			self.user_list_all[n_id] = t_data
		end
		self:getUserInfo(nim_id,callSaveUserInfo)
	else
		-- for k,v in pairs(nim_data) do
		-- 	print("saveUserInfo111111:",k,v)
		-- end
		local n_id = string.lower(nim_id)
		self.user_list_all[n_id] = nim_data
	end

end

function ChatDataManager:getMyUserInfo(  ) --加入玩家ID
	local playerInfo = {
		["user_icon"]  = user_info["pl_icon_id"],     
		["user_name"]  = user_info["name"],
		["user_id"]    = chat_info["accid"],  --sdk id
		["user_lv"]    = user_info["rank"],
		["player_id"]  = user_info["id"]      --玩家id
	}
	return playerInfo
end

function ChatDataManager:callLoginNim( callback1  )
	if self.loginNimOK then --已经登陆过云信了
  		if callback1 then
  			callback1("LoginNimSkip")
  		end
  		return
	end

	if chat_info["accid"] ~= nil and chat_info["chat_token"] ~= nil then
		local function callback(data1)
			print("loginNIM back ---:"..data1)
			if data1 == "fail" then
				print("login nim fail---")
				self:loginNimFailed()
			else
				self:loginNimSuccess()
		  		if callback1 then
		  			callback1("LoginNimSuccess")
		  		end
			end
		end
		local args_android = {
				chat_info["accid"],
				chat_info["chat_token"],
				callback
			}
		local args_ios = {
				accid 		= chat_info["accid"],
				chat_token 	= chat_info["chat_token"],
				callBack	= callback,
			}
		local methodName = "loginNimSDK"
		local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
		self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
	else
		--不可能的步骤1,服务器未返回accid和token
	end
end

function ChatDataManager:loginNimFailed( )
	print("loginNimFailed")
	self.loginNimOK = false
    MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("服务器连接失败，是否重连"),self,self.callLoginNim,self.BtnClose)
end

function ChatDataManager:loginNimSuccess(  )
	-- 第一次登陆nim成功
	self.loginNimOK = true

    self:updateMyUserInfo()			 --刷新自己的信息
	self:getFriends() 		 		 --请求玩家好友
	self:getBlacks()
	self:getSystemNotification()  	 --获取未处理系统消息
	if g_channel_control.chatRecentEabled == true then
		self:getAllRecentSessions()		 --获取最近回话
	end
end

function ChatDataManager:pushChatItemData( data ) --data是否已经被加入list中
	-- body
	print("pushChatItemData..."..tostring(data["text"]).."...sessionType:"..data["session"]["sessionType"])

	local session = data["session"] ~= nil and data["session"] or {}
	local sessionType = session["sessionType"]
	local sessionId = string.lower(session["sessionId"])
	local data_list = self:getListByType(sessionType,sessionId)
	if sessionType == 0 then --私聊数据，判断是否需要加入私聊成员列表中
		self:addChatUserToUserList(data)
	end
	if data_list == nil then
		print("error--pushChatItemData:找不到需要当前data需要加入的列表:"..sessionType)
		return
	end

	local room_item = {}
	room_item["data"] = data
	room_item["posX"] = 0
	room_item["posY"] = 0
	room_item["itemH"] = 0
	room_item["data"]["translate"] = 0 --翻译状态 0 未翻译，1 已翻译，2 翻译中
	-- local len = #data_list
	-- data_list[len+1] = room_item
	self:pushChatItemDataToList(data_list,room_item,true)


	local remoteExt = data["remoteExt"] --["message_type"]
	if remoteExt ~= nil and sessionType == 2  then 
		local message_type = remoteExt["message_type"]
		if message_type == 1 then  --系统消息,加入系统聊天室
			self.sysRoomID = self.sysRoomID or "sysRoomId"
			local sys_list = self:getListByType(sessionType,self.sysRoomID)
			if sys_list == nil then
				self.worldChat_list[self.sysRoomID] = {}
				sys_list = self.worldChat_list[self.sysRoomID]
			end

			-- local len = #sys_list
			-- sys_list[len+1] = table.deepcopy(room_item)
			self:pushChatItemDataToList(sys_list,room_item,true)

			self:addChannelRedDop(1,0,true)
		end
		self:addChannelRedDop(2,0,true)

	end	
	-- print("self.worldChat_list..len:"..#self.worldChat_list)
end

function ChatDataManager:pushChatItemDataToList( data_list,data ,bRemoveMin) --将数据data存入data_list[max]中，同时移除data_list[min]
	local len_max = data_list["len_max"] or 0
	data_list[len_max+1] = table.deepcopy(data)
	data_list["len_max"] = len_max+1
	data_list["show_red"] = true
	print("len_max = "..tostring(len_max).."......chatroom_list_sava_len:"..tostring(self.chatroom_list_sava_len))
	if bRemoveMin == true then --需要移除的数据并不执行UI操作，则直接移除
		if len_max - self.chatroom_list_sava_len > 0 and data_list[len_max - self.chatroom_list_sava_len] ~= nil and data_list[len_max - self.chatroom_list_sava_len]["isInUI"] ~= true then 
		-- if len_max - self.chatroom_list_sava_len > 0 and data_list[len_max - self.chatroom_list_sava_len]["isInUI"] ~= true then 
			data_list[len_max - self.chatroom_list_sava_len] = nil
 		end
	end
end

function ChatDataManager:sendChatMessage( sessionId,sessionType,message )
 	local cjson = require "cjson"
	local tempTable = table.deepcopy(self:getMyUserInfo()) 

	local mydata = cjson.encode(tempTable)

	print("send ChatCall:messge："..message.."..accid:"..sessionId.."..type:"..sessionType)
	local methodName = "sendChatMessagePlatform"
	local args_ios = {
		["sessionType"] 	= sessionType,
		["message"] 		= message,
		["sessionId"] 		= sessionId,
		["ext"] 			= mydata,
		-- ["callBack"] 	= callBack,
	}
	local args_android = {
		message, 
		sessionId,
		sessionType,
		mydata
		-- callBack,
	}
	local signs = "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:enterChatRoom( roomID,callback )
	local function receiveEnterChatRoom(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		if t_data["result"] ~= "0" then 
			self:setChatRoomState(roomID,true)
		end
		--获取聊天室历史
		if self:getSessionHistoryState(2, roomID) ~= true then
			self:fetchMessageHistory(roomID,2,nil)
		end
	    if callback then
	    	callback(t_data)
	    end
	end
	local args_ios = {
		roomid = roomID,
		callback = receiveEnterChatRoom,
	}
	local args_android = {roomID,receiveEnterChatRoom}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "enterChatRoom"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  
end

function ChatDataManager:exitChatRoom( roomid,callback1 )	--退出聊天室
	-- body
	print("exitChatRoom-------"..roomid)
	local function callback(data)
		print("exitChatRoom---BACK")
		self:setChatRoomState(roomid,false)
		if callback1 then
			callback1()
		end
	end
	local args_ios = {
		roomid = roomid,
		callback = callback,
	}
	local args_android = {roomid,callback}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "exitChatRoom"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  
end

function ChatDataManager:fetchMessageHistory( session_id,session_type,callback )
	if g_channel_control.chatHistoryEabled ~= true then
		return
	end
	if self:getSessionHistoryState(session_type, session_id) == true then
		-- print("getSessionHistoryState[%d][%s] == true ",session_type,session_id)
		return 
	end
	local function fetchMessageHistoryCallback(data)
	    -- local cjson = require "cjson"
	    -- local t_data = cjson.decode(data)
	    -- print("fetchMessageHistory:"..tostring(data))

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	    self:setSessionHistoryState(session_type, session_id, true)
	    self:receiveNimServerMessageData(data)

	end
	local limit = 100
	local args_ios = {
		session_id = tostring(session_id),
		session_type = session_type,
		limit = limit,
		callback = fetchMessageHistoryCallback,
	}
	local args_android = {session_id,session_type,limit,fetchMessageHistoryCallback}  --
	local signs = "(Ljava/lang/String;III)V"
   	local methodName = "fetchMessageHistory"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  

end

function ChatDataManager:enterTeamRoom( team_id,callback ) --未使用
	local function enterTeamRoomCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		if t_data["result"] ~= "0" then 
			self:setChatRoomState(team_id,true)
		end
	    if callback then
	    	callback(t_data)
	    end
	end
	local args_ios = {
		team_id = team_id,
		callback = enterTeamRoomCallback,
	}
	local args_android = {team_id,enterTeamRoomCallback}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "enterTeamRoom"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  
end

function ChatDataManager:isMyTeam( t_id )
	local function isMyTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		team_id = t_id,
		callback = isMyTeamCallback,
	}
	local args_android = {t_id,isMyTeamCallback}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "isMyTeam"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  
	return ret
end

function ChatDataManager:getAllTeams(  ) --获取所有群组 未使用
	local function getAllTeamsData(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo
		dump(t_data, "getAllTeams")
		local teams_count = #t_data
		for i=1,teams_count do
			local team_item = t_data[i]
			if team_item then
				print("team_id:"..tostring(team_item["team_id"]))
			end
		end
	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
			callback = getAllTeamsData,
	}
	local args_android = {getAllTeamsData}  --
	local signs = "(I)V"
   	local methodName = "getAllTeams"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  

end

function ChatDataManager:getTeamById( team_id ) --根据ID获取群组 未使用
	local function getTeamData(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		team_id = team_id,
		callback = getTeamData,
	}
	local args_android = {team_id,getTeamData}  --
	local signs = "(I)V"
   	local methodName = "getTeamById"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  
end

function ChatDataManager:createTeam( ... )--默认群主创建群，默认创建讨论组
	local n_id = chat_info["accid"]
	local t_type = 0 --群类型：讨论组（0默认）/高级群（1）
	-- local intro = "群简介"
	-- local announcement = "群公告"
	-- local clientCustomInfo = "客户端自定义消息"
	-- if t_type == 1 then --高级群权限
	-- 	local postscript = "邀请他人的附言"
	-- 	local joinMode = 0 --群验证模式 :0 不用验证，1 需要验证，2 不允许任何人加入 其他error
	-- 	local inviteMode = 0 --群邀请权限：0 群主和管理员可邀请，1 任何人可邀请
	-- 	local beInviteMode = 0 --被邀请权限：0 需要被邀请人同意，1 不需要被邀请人同意
	-- 	local updateInfoMode = 0 --群信息修改权限：0 群主和管理员可修改，1 任何人
	-- 	local updateClientCustomMode = 0 --客户端自定义信息修改权限：0，1
	-- end

	local function createTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end

	local args = {
		teamAdmin 	= n_id,
		teamType 	= t_type,
		-- teamName 	= "",
		callback = createTeamCallback,
	}

	local cjson = require "cjson"
    local extStr1 = cjson.encode(args)

    local args_android = {extStr1}
    local signs = "(Ljava/lang/String;)V"
    local args_ios = {args = extStr1}
    local methodName = "createTeam"

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)

end

function ChatDataManager:addUserToTeam( n_id,t_id ) --邀请入群
	local function addUserToTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local postscriptStr = "";--邀请附言
	local args_ios = {
		user_id = n_id,
		team_id = t_id,
		postscript = postscriptStr,
		callback = addUserToTeamCallback,
	}
	local args_android = {n_id,t_id,postscriptStr,addUserToTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "addUserToTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:acceptInviteWithTeam( t_id,invitor_id ) --H 接受入群邀请
	local function acceptInviteTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		invitorId = invitor_id,
		team_id = t_id,
		callback = acceptInviteTeamCallback,
	}
	local args_android = {invitor_id,t_id,acceptInviteTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "acceptInviteWithTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:rejectInviteWithTeam( t_id,invitor_id,rejectStr ) --H 拒绝入群邀请
	local function rejectInviteWithTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	rejectStr = rejectStr or "";
	local args_ios = {
		invitorId = invitor_id,
		team_id = t_id,
		rejectReason = rejectStr,
		callback = rejectInviteWithTeamCallback,
	}
	local args_android = {invitor_id,t_id,rejectStr,rejectInviteWithTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "rejectInviteWithTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:applyToTeam( t_id ,msg) --H（高级群功能） 申请入群 讨论组直接入群，
	local function applyToTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	msg = msg or ""
	local args_ios = {
		team_id = team_id,
		applyMessage = msg,
		callback = applyToTeamCallback,
	}
	local args_android = {team_id,msg,applyToTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "applyToTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs)  	
end

function ChatDataManager:passApplyToTeam( t_id,apply_id ) --H 通过入群申请
	local function passApplyToTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		apply_id = apply_id,
		team_id = t_id,
		callback = acceptInviteTeamCallback,
	}
	local args_android = {apply_id,t_id,passApplyToTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "passApplyToTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:rejectApplyToTeam( t_id,apply_id,rejectStr ) --H 拒绝入群申请
	local function rejectApplyToTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	rejectStr = rejectStr or "";
	local args_ios = {
		apply_id = apply_id,
		team_id = t_id,
		rejectReason = rejectStr,
		callback = rejectApplyToTeamCallback,
	}
	local args_android = {apply_id,t_id,rejectStr,rejectApplyToTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "rejectApplyToTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

-- function ChatDataManager:updateTeamUserInfo( nim_id,t_id,nickName ) -- 修改群成员昵称
-- 	-- body
-- end
function ChatDataManager:transferManagerWithTeam( t_id,newOwnerId,intLeave ) --H 转让群主 是否退群
	local function transferManagerWithTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	rejectStr = rejectStr or "";
	local args_ios = {
		new_admin = newOwnerId,
		team_id = t_id,
		isLeave = intLeave,
		callback = transferManagerWithTeamCallback,
	}
	local args_android = {newOwnerId,t_id,intLeave,transferManagerWithTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;II)V"
   	local methodName = "transferManagerWithTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:addManagerToTeam( t_id,manager_id ) -- H 添加管理员
	local function addManagerToTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	rejectStr = rejectStr or "";
	local args_ios = {
		manager_id = manager_id,
		team_id = t_id,
		callback = addManagerToTeamCallback,
	}
	local args_android = {manager_id,t_id,addManagerToTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "addManagerToTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:removeManagerFromTeam( t_id,manager_id ) --H 移除管理员
	local function removeManagerFromTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	rejectStr = rejectStr or "";
	local args_ios = {
		manager_id = manager_id,
		team_id = t_id,
		callback = removeManagerFromTeamCallback,
	}
	local args_android = {manager_id,t_id,removeManagerFromTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "removeManagerFromTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 	
end

function ChatDataManager:fetchTeamMembers( t_id ) --获取群成员
	local function fetchTeamMemberCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		team_id = t_id,
		callback = fetchTeamMemberCallback,
	}
	local args_android = {t_id,fetchTeamMemberCallback}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "fetchTeamMembers"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 		
end

function ChatDataManager:quitTeam( t_id ) --用户退群
	local function quitTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		team_id = t_id,
		callback = quitTeamCallback,
	}
	local args_android = {t_id,quitTeamCallback}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "quitTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 		
end

function ChatDataManager:kickUserFromTeam( n_id,t_id ) -- 踢人
	local function kickUserFromTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		team_id = t_id,
		kick_id = n_id,
		callback = kickUserFromTeamCallback,
	}
	local args_android = {t_id,n_id,kickUserFromTeamCallback}  --
	local signs = "(Ljava/lang/String;Ljava/lang/String;I)V"
   	local methodName = "kickUserFromTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 		

end

function ChatDataManager:dismissTeam( t_id ) -- 解散群
	local function dismissTeamCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		team_id = t_id,
		callback = kickUserFromTeamCallback,
	}
	local args_android = {t_id,kickUserFromTeamCallback}  --
	local signs = "(Ljava/lang/String;I)V"
   	local methodName = "dismissTeam"
	self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 		

end

function ChatDataManager:getUserInfo( nim_id ,callback )
	if nim_id == nil then
		print("error ------getUserInfo nim_id = nil")
		return 
	end
	if self.user_list_all == nil then
		self.user_list_all = {}
	end
	local n_id = string.lower(nim_id)

	if self.user_list_all[n_id] == nil  then
		local function receiveUserInfoCall( data )
			local cjson = require "cjson"
			local t_user = cjson.decode(data)
			self:saveUserInfo(nim_id,t_user)
			if callback then 
				callback(t_user)
			end
		end

		local methodName = "getUserInfo"
		local args_ios = {
			["user_id"] 	= nim_id,
			["callBack"] 	= receiveUserInfoCall,
		}
		local args_android = {
			nim_id,
			receiveUserInfoCall
		}
		local signs = "(Ljava/lang/String;I)V" 

		self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
	else
		local t_user = self.user_list_all[n_id]
		if callback then
			callback(t_user)
		end
	end
end

function ChatDataManager:updateMyUserInfo() --更新自己的信息到服务器
	
	local myInfo = self:getMyUserInfo()

	local methodName = "updateUserInfo"
	-- local args_ios = {
	-- 	["user_id"] 	= myInfo["user_id"],
	-- 	["user_name"] 	= myInfo["user_name"],
	-- 	["user_icon"] 	= myInfo["user_icon"],
	-- 	["user_lv"] 	= myInfo["user_lv"],
	-- 	["game_id"] 	= myInfo["player_id"],
	-- 	-- ["callBack"] 	= callBack,
	-- }
	-- local args_android = {
	-- 	myInfo["user_id"],
	-- 	myInfo["user_name"],
	-- 	myInfo["user_icon"],
	-- 	myInfo["user_lv"],
	-- 	-- myInfo["player_id"]
	-- }

 --     local signs = "(Ljava/lang/String;Ljava/lang/String;II)V" 
	print("updateMyUserInfo------")
	--改为直接传入json字符串，方便自定义数据
	local cjson = require "cjson"
    local extStr1 = cjson.encode(myInfo)

    local args_android = {extStr1}
    local signs = "(Ljava/lang/String;)V"
    local args_ios = {extString = extStr1}
	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:getSystemNotification(  ) --系统消息：群消息和好友消息
	local function callBack( data )
		print("getSystemNotification:"..data)
		local requestFriend_list = {} --好友邀请列表

		local cjson = require "cjson"
		t_datas = cjson.decode(data)
		local len = #t_datas
		for i=1,len do
			local t_data = t_datas[i]

			local sourceID = t_data["sourceID"]  --发送者ID
			local notificationType = t_data["notificationType"]
			local operationType = t_data["operationType"]
			if notificationType == 5 then --好友操作
			--添加到好友列表中 
				if operationType == 1 then 				 --对方直接添加，直接加入好友列表
					print("对方直接加我为好友，客户端不提供此接口")
				elseif operationType == 2 then 			 --对方请求添加，加入好友列表，显示（通过，拒绝）
					if self:isInFriends(sourceID) then
						print("----已经是好友了，需要删除此条通知！！！")
						self:removeSystemNotification(sourceID,notificationType,operationType)
					else
						table.insert(requestFriend_list, sourceID)
					end
				elseif operationType == 3 then 			 --对方通过了我的好友请求， 此消息会在用户登录nim时回调，此处不下发 不处理
					print("对方通过了我的好友请求，此处不应下发")
				elseif operationType == 4 then 			 --对方拒绝了我的好友请求，不下发，不处理（主动发起好友请求时，不加入好友列表
					print("对方拒绝了我的好友请求，此处不应下发")
				end

			else
				print("notificationType:"..notificationType)
			end
		end

		local friend_len = #requestFriend_list
		for i=1,friend_len do
			local user_id = requestFriend_list[i]
			self:addUserToUserList(user_id,1)	--加入好友列表中，类型为添加好友
		end
	end

	local methodName = "getSystemNotification"
	local args_ios = {
		["callBack"] 	= callBack,
	}
	local args_android = {
		callBack
	}
	local signs = "(I)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:removeSystemNotification( user_id,notificationType,operationType )
	local methodName = "removeSystemNotification"
	local args_ios = {
		["user_id"] 		= user_id,
		["notificationType"] 	= notificationType,
		["operation"] 	= operationType,
	}
	local args_android = {
		user_id,
		notificationType,
		operationType
	}
	local signs = "(Ljava/lang/String;II)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end
----------------》》》》》》》》》》 玩家关系处理》》》》》》----------------------
function ChatDataManager:callFriendOperation( playerInfo,tp ) ----1 直接添加，2 请求添加，3 通过对方请求，4 拒绝对方请求，5 删除好友
	local function callBack( data )
		print("--- callFriendOperation:"..data)
		local cjson = require "cjson"
		t_data = cjson.decode(data)

		local tp = t_data["type"]
		local code = t_data["code"] -- 0 成功  其他失败
		local temp_t = {}
		temp_t["user_name"] = playerInfo["user_name"] or playerInfo["user_id"]

		if code == 0 then
			if tp == 2 then --发起请求好友，客户端不做处理，等待onReceiveSystemNotification回调
				temp_t["type"] = 6
			elseif tp == 3 then --通过对方好友请求，刷新客户端
				self:addToFriends(playerInfo)
				self:addUserToUserList(playerInfo["user_id"], 0)
				temp_t["type"] = 11
			elseif tp == 4 then --拒绝对方好友请求
				temp_t["type"] = 0
				self:removeUserFromUserList(playerInfo["user_id"],1)
			elseif tp == 5 then  --删除好友
				temp_t["type"] = 14
				self:removeUserFromUserList(playerInfo["user_id"],1)
				self:removeFromFriends(playerInfo)
			end
		
		end
		self:chatAlert(temp_t);
	end
	local methodName = "AddOrRemoveFriend"
	local args_ios = {
		["type"] 		= tp,
		["user_id"] 	= playerInfo["user_id"],
		["callBack"] 	= callBack,
	}
	local args_android = {
		tp,
		playerInfo["user_id"],
		callBack
	}
	local signs = "(ILjava/lang/String;I)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:callAddBlack( playInfo ) --加入黑名单
	local function callBack( data )
		print("callAddBlack:"..data)
		local cjson = require "cjson"
		t_data = cjson.decode(data)
		if t_data["code"] == 0 then
			self:addToBlacks(playInfo)
			-- if self.curChatMember["sessionType"] == 0 then
			-- 	self:refreshChatroomUI()
			-- end
			if self.uiDelegate then
				self.uiDelegate:checkRefrushUserListFromBlack(0)
			end
		end
	end
	local methodName = "addToBlack"
	local args_ios = {
		["user_id"] 	= playInfo["user_id"],
		["callBack"] 	= callBack,
	}
	local args_android = {
		playInfo["user_id"],
		callBack
	}
	local signs = "(Ljava/lang/String;I)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:callRemoveFromBlack( playerInfo )
	local function callBack( data )
		print("removeFromBlack:"..data)
		local cjson = require "cjson"
		t_data = cjson.decode(data)
		if t_data["code"] == 0 then
			self:removeFromBlack(playerInfo)

			if self.uiDelegate then
				self.uiDelegate:checkRefrushUserListFromBlack(1)
			end
		end
	end
	local methodName = "removeFromBlack"
	local args_ios = {
		["user_id"] 	= playerInfo["user_id"],
		["callBack"] 	= callBack,
	}
	local args_android = {
		playerInfo["user_id"],
		callBack
	}
	local signs = "(Ljava/lang/String;I)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:getBlacks(  )
	local function callBack( datas )
		print("getBlacks:"..datas)
		if chat_info["blacks"] == nil or type(chat_info["blacks"]) ~= type({}) then
			chat_info["blacks"] = {}
		end
		if self.black_list == nil then
			self.black_list = {}
		end
		local cjson = require "cjson"
		local t_datas = cjson.decode(datas)

		if #t_datas < 1 then
			return
		end
		for i=1,#t_datas do
			local t_data = t_datas[i]

			local t_user = {}
			t_user["user_id"]   = t_data["user_id"] 		--ID
			t_user["user_name"] = t_data["user_name"] or t_data["user_id"]		--昵称
			t_user["user_icon"] = t_data["user_icon"] or 11		--头像
			t_user["user_lv"]  	= t_data["user_lv"]   or 99		--等级
			t_user["player_id"] = t_data["player_id"]
			self.black_list[i] = t_user
			self:saveUserInfo(t_user["user_id"],t_user,true)

		end
		chat_info["blacks"] = self.black_list
	end
	local methodName = "getBlacks"
	local args_ios = {
		["callBack"] 	= callBack,
	}
	local args_android = {
		callBack
	}
	local signs = "(I)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:getFriends() --初始化获取好友列表
	local function callBack( datas )
		print("getFriends:"..datas)
		if type(chat_info["friends"]) ~= type({}) then
			chat_info["friends"] = {}
		end
		if self.friends_list == nil then
			self.friends_list = {}
		end
		local t_list = {}
		local cjson = require "cjson"
		local t_datas = cjson.decode(datas)

		if #t_datas < 1 then
			return
		end
		for i=1,#t_datas do
			local t_data = t_datas[i]

			local t_user = {}
			t_user["user_id"]   = t_data["user_id"] 		--ID
			t_user["user_name"] = t_data["user_name"] or t_data["user_id"]		--昵称
			t_user["user_icon"] = t_data["user_icon"] or 11		--头像
			t_user["user_lv"]  	= t_data["user_lv"]   or 99		--等级
			t_user["player_id"] = t_data["player_id"]
			t_user["addToFriend"] = 0 					--默认0，1为加好友

			t_list[i] = t_user
			self.friends_list[i] = t_user
			self:saveUserInfo(t_user["user_id"],t_user,true)

		end
		chat_info["friends"] = t_list
	end

	local methodName = "getFriends"
	local args_ios = {
		["callBack"] = callBack,
	}
	local args_android = {
		callBack
	}
	local signs = "(I)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:removeFromBlack( playerInfo )
	local list_black = self:getTableVaule(chat_info, "blacks") --chat_info["blacks"]
	local index = self:findIndexOfTable(list_black, playerInfo, "user_id")
	if index == 0 then
		print("can not find playInfo in chat_info[friends]:"..playerInfo["user_id"])
	else
		table.remove(list_black,index)
	end
	self.black_list = chat_info["blacks"]
end

function ChatDataManager:removeFromFriends( playerInfo )
	local list_friend = self:getTableVaule(chat_info, "friends") --chat_info["friends"]
	local index = self:findIndexOfTable(list_friend, playerInfo, "user_id")
	if index == 0 then
		print("can not find playInfo in chat_info[friends]:"..playerInfo["user_id"])
	else
		table.remove(list_friend,index)
	end
end

function ChatDataManager:addToFriends( playInfo )
	print("addToFriends:"..playInfo["user_id"])
	local list_friend = self:getTableVaule(chat_info, "friends") --chat_info["friends"]
	local index = self:findIndexOfTable(list_friend, playInfo, "user_id")
	if index == 0 then
		table.insert(list_friend,playInfo)
	end
end

function ChatDataManager:addToBlacks( playInfo )
	print("addToBlacks:"..playInfo["user_id"])
	local list_black = self:getTableVaule(chat_info, "blacks") -- chat_info["blacks"]
	local index = self:findIndexOfTable(list_black, playInfo, "user_id")
	if index == 0 then
		table.insert(list_black,playInfo)
	end
	self.black_list = chat_info["blacks"]
end

function ChatDataManager:isInFriends( user_id )
	local list_friend = self:getTableVaule(chat_info, "friends") --chat_info["friends"]

	if list_friend ~= nil and type(list_friend) == type({}) then
		local len = #list_friend
		for i=1,len do
			local user = list_friend[i]
			if string.lower(user["user_id"]) == string.lower(user_id) then
				print("user_id:"..user_id.."  isMyFriend..true")
				return true
			end
		end
	end
	print("user_id:"..user_id.."  is not MyFriend")
	return false
end

function ChatDataManager:isInBlacks( user_id )
	local list_black = self:getTableVaule(chat_info, "blacks") --chat_info["blacks"]
	if list_black ~= nil and type(list_black) == type({}) then
		local len = #list_black
		for i=1,len do
			local user = list_black[i]
			if string.lower(user["user_id"]) == string.lower(user_id) then
				print("user_id:"..user_id.."  isInBlacks..true")
				return true
			end
		end
	end
	print("user_id:"..user_id.."  is not isInBlacks")

	return false
end

function ChatDataManager:getFriendNum(  )
	return self.friends_list == nil and 0 or #self.friends_list
end

function ChatDataManager:getBlackNum(  )
	return self.black_list == nil and 0 or #self.black_list
end

function ChatDataManager:getRecentNum(  )
	return self.recent_list == nil and 0 or #self.recent_list
end

function ChatDataManager:getUserList( userType ) --获取关系列表：好友/黑名单/最近聊天
	local user_list = self.friends_list
	if userType == 1 then
		if self.friends_list == nil then
			self.friends_list = {}
		end
		user_list = self.friends_list
	elseif userType == 2 then
		if self.recent_list == nil then
			self.recent_list = {}
		end
		user_list = self.recent_list
	elseif userType == 3 then
		if self.black_list == nil then
			self.black_list = {}
		end
		user_list = self.black_list
	end
	return user_list
end

function ChatDataManager:getTableVaule( tab,key )
	if tab == nil then
		print("error----getTableVaule--")
		return nil
	end
	local t = tab[key]
	if t == nil then
		tab[key] = {}
	end
	t = tab[key]
	return t
end

function ChatDataManager:findIndexOfTable( t,item,key) --table,item,用于比较的key
	-- body
	if t == nil or type(t) ~= type({}) then
		return 0
	end

	for i=1,#t do
		if string.lower(item[key]) == string.lower(t[i][key]) then
			return i
		end
	end
	return 0
end

function ChatDataManager:addOrMoveToUserListFront( userType,data ) --从世界进入私聊，添加或者加入到对应列表(好友/最近聊天
	local userList = self:getUserList(userType)
	local index = self:findIndexOfTable(userList ,data,"user_id")
	if  index == 0 then --列表不存在元素
		table.insert(userList, 1,data)
	else  --如果元素在第一位，不处理，否则交换到第一位
		if index > 1 then
			local temp_data = userList[1]
			userList[1] = userList[index]
			userList[index] = temp_data
		end
	end
end

function ChatDataManager:removeUserFromUserList( user_id,list_type )

	local userList = self:getUserList(list_type)
	local t = {}
	t["user_id"] = user_id
	local index = self:findIndexOfTable(userList, t, "user_id")
	if index == 0 then
		print("removeUserFromUserList not find item :"..user_id.."..in："..list_type)
		return
	else
		table.remove(userList,index)
		if self.uiDelegate ~= nil then
			self.uiDelegate:checkRefrushUserListFromRemove(index,list_type)
		end
	end
end

function ChatDataManager:addChatUserToUserList( data ) 		--来私聊消息，加入userList 判断是好友，还是最近聊天（黑名单）
	-- local user_id = data["from"]
	local session = data["session"]
	local session_id = session["sessionId"]
	if string.lower(session_id) == string.lower(chat_info["accid"]) then
		print("----addChatUserToUserList------is Myself----:"..session_id)
		return
	end
	self:addUserToUserList(session_id,-1)
end

function ChatDataManager:addUserDataToUserList(user_data,userList,userType) -- 玩家数据，对应列表，对应index
	local index = self:findIndexOfTable(userList ,user_data,"user_id")
	print("addUserDataToUserList:index:"..index)
	if index == 0 then
		table.insert(userList,1,user_data)
	else 
		local temp_data = userList[index]
		if user_data["addToFriend"] == -1 then
			user_data["addToFriend"] = temp_data["addToFriend"]
		end
		if index > 1 then
			for i=index,2,-1 do
				userList[i] = userList[i-1]
			end
			userList[1] = user_data
			print("userList[1].addToFriend:"..tostring(userList[1]["addToFriend"]))

		else 
			userList[index] = user_data
		end
	end

	if self.uiDelegate ~= nil then
		self.uiDelegate:checkRefrushUserListFromAdd(index,userType)
	end
	print("addUserDataToUserList:"..tostring(index).."..userList_refresh:"..tostring(self.userList_refresh))
end
--是好友
function ChatDataManager:addUserToUserList( user_id,isAddFriend ) --加到userlist中，判断是否为加好友操作，-1 消息，1 好友邀请 0 添加好友成功
	-- ，先获取玩家数据，然后在执行好友操作，
	-- {'user_lv': 99, 'user_name': 'name1', 'user_icon': 11, 'user_id': 'adc13'}
	local function callBack( t_data )
		print("addUserToUserList:"..user_id.."..isAddFriend:"..isAddFriend)

		local t_user = table.deepcopy(t_data)
		t_user["addToFriend"] = isAddFriend
		t_user["user_time"] =  UserDataMgr:getInstance().timeData:getCurrentTime()--os.time()

		local userListType = 2 		--默认最近聊天
		local isFriend = self:isInFriends(user_id)   
		local isBlack  = self:isInBlacks(user_id) 	 --黑名单不会收到消息
		if isFriend then
			print("如果已经是好友了，则不需要再次添加好友,同时需要删除此条通知"..tostring(isAddFriend))
			t_user["addToFriend"] = 0
		end
		self:saveUserInfo(user_id, t_user)
		if isAddFriend == 1 or isFriend then
			-- userList = self.friends_list
			userListType = 1
		elseif isBlack then
			-- userList = self.black_list
			userListType = 3
		end
		local userList = self:getUserList(userListType)
		print("addUserToUserList..userListType:"..userListType)
		self:addUserDataToUserList(t_user,userList,userListType)

		self:addChannelRedDop(3,userListType,true)

	end
	self:getUserInfo(user_id,callBack)

	print("addUserDataToUserList end")
end
----------------《《《《《《《 玩家关系处理《《《《----------------------
-------record and playAudio----------------------
function ChatDataManager:voiceRecord( type_ )
	local methodName = ""
	if type_ == 1 then
		methodName = "startAudioRecording"
	elseif type_ == 2 then
		methodName = "stopRecord"
	elseif type_ == 3 then
		methodName = "cancelRecord"
	end
	local args_ios,args_android = {}, {}
	local signs = "()V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end
-- /var/mobile/Containers/Data/Application/54B354D5-2BB2-4948-9BEA-623438480AD0/Documents/NIMSDK/325bb843f65271ff7fae16ae3b71de13/Global/Resources/3a21b30a-7ae4-4abf-966a-dbb6197b984120171102153837.aac
function ChatDataManager:sendChatVoice( filename,sessionId,sessionType ) --第三方回调录音结束，发送录音文件

	print("···"..tostring(filename))
	local cjson = require "cjson"
	local tempTable = table.deepcopy(self:getMyUserInfo()) 
	local ext = cjson.encode(tempTable)

	local methodName = "sendChatVoicePlatform"
	local args_ios = {
		["sessionType"] 	= sessionType,
		["voiceFile"] 		= filename,
		["sessionId"] 		= sessionId,
		["ext"] 			= ext,
		-- ["callBack"] 	= callBack,
	}
	local args_android = {
		filename,
		sessionId,
		sessionType,
		ext
		-- ["callBack"] 	= callBack,
	}
	local signs = "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:playRecordVoice( t_obj ) -- url,path,duration
	if t_obj ~= nil then
		local url = t_obj["url"]
		local path = t_obj["path"]
		local dur = t_obj["duration"]

		local methodName = "playAudio"
		local args_ios = {
			audioPath = path,
			audioUrl = url,
			duration = dur,
		}
		local args_android = {
			path,
			url,
			dur
		}
		local signs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V" 

		self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)

	end
end

function ChatDataManager:switchAudioOutputDevice( audioOutputDevice )
	local function switchAudioOutputDeviceCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		audioOutputDevice = audioOutputDevice, --0 听筒 1 扬声器
		callback = switchAudioOutputDeviceCallback,
	}
	local args_android = {audioOutputDevice,switchAudioOutputDeviceCallback}  --
	local signs = "(II)Z"
   	local methodName = "switchAudioOutputDevice"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret		
end

function ChatDataManager:isPlaying( ... )
	local function isPlayingCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = isPlayingCallback,
	}
	local args_android = {isPlayingCallback}  --
	local signs = "(I)Z"
   	local methodName = "isPlaying"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret	
end

function ChatDataManager:stopPlay( ... )
	local function stopPlayCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = stopPlayCallback,
	}
	local args_android = {audioFile,stopPlayCallback}  --
	local signs = "(I)V"
   	local methodName = "stopPlay"
	 self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
end

function ChatDataManager:playAudioCompletedWithError( datas ) --播放完成/中断/...
	local cjson = require "cjson"
	local t_data = cjson.decode(datas)
	local code = t_data["code"]
	local filePath = t_data["filePath"]
	print("playAudioCompletedWithError:..code:"..tostring(code).."....filePath:"..tostring(filePath))
	if self.uiDelegate then
		self.uiDelegate:stopPlayAudioAni(filePath)
	end
end

function ChatDataManager:isRecording( ... )
	local function isRecordingCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = isRecordingCallback,
	}
	local args_android = {isRecordingCallback}  --
	local signs = "(I)Z"
   	local methodName = "isRecording"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret	
end

function ChatDataManager:recordForDuration( ... )
	local function recordForDurationCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local duration_1 = 10
	local args_ios = {
		duration = duration_1,
		callback = recordForDurationCallback,
	}
	local args_android = {duration_1,recordForDurationCallback}  --
	local signs = "(FI)V"
   	local methodName = "recordForDuration"
	 self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
end

function ChatDataManager:recordAveragePower( ... )
	local function recordAveragePowerCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = recordAveragePowerCallback,
	}
	local args_android = {recordAveragePowerCallback}  --
	local signs = "(I)F"
   	local methodName = "recordAveragePower"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret	
end

function ChatDataManager:recordPeakPower( ... )
	local function recordPeakPowerCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = recordPeakPowerCallback,
	}
	local args_android = {recordPeakPowerCallback}  --
	local signs = "(I)F"
   	local methodName = "recordPeakPower"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret
end

function ChatDataManager:startAudioRecording( ... )
	local function startAudioRecordingCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = startAudioRecordingCallback,
	}
	local args_android = {startAudioRecordingCallback}  --
	local signs = "(I)V"
   	local methodName = "startAudioRecording"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret
end

function ChatDataManager:stopRecord( ... )
	local function stopRecordCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = stopRecordCallback,
	}
	local args_android = {stopRecordCallback}  --
	local signs = "(I)V"
   	local methodName = "stopRecord"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret
end

function ChatDataManager:cancelRecord( ... )
	local function cancelRecordCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo

	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		callback = cancelRecordCallback,
	}
	local args_android = {cancelRecordCallback}  --
	local signs = "(I)V"
   	local methodName = "cancelRecord"
	local ok,ret = self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
	return ret
end

-------record and playAudio----------------------
----> 最近回话----------------
function ChatDataManager:didAddRecentSession( data )
	dump(data, "didAddRecentSession	")
end
function ChatDataManager:didUpdateRecentSession( data )
	dump(data, "didUpdateRecentSession	")
end
function ChatDataManager:didRemoveRecentSession( data )
	dump(data, "didRemoveRecentSession	")
end
 
function ChatDataManager:getAllRecentSessions( ... )
	local function getAllRecentSessionsCallback(data)
	   local cjson = require "cjson"
	   local t_data = cjson.decode(data)
		--todo
		dump(t_data, "getAllRecentSessions")
	   local recentCount = #t_data
	   for i=1,recentCount do
	   		local recentSession = t_data[i]
	   		if recentSession["session"] ~= nil and recentSession["session"]["session_type"] == 0 then
	   		 	--私聊对象，加入到密聊列表
	   		 	self:fetchMessageHistory(recentSession["session"]["session_id"], recentSession["session"]["session_type"], nil)
	   		end		
	   end
	end
	local args_ios = {
		callback = getAllRecentSessionsCallback,
	}
	local args_android = {getAllRecentSessionsCallback}  --
	local signs = "(I)V"
   	local methodName = "getAllRecentSessions"
	 self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 
end

function ChatDataManager:markAllMessagesReadInSession( sessionID,sessionType )
	local function markAllMessagesReadInSessionCallback(data)
	    local cjson = require "cjson"
	    local t_data = cjson.decode(data)
		--todo
		dump(t_data, "markAllMessagesReadInSession")
	    -- if callback then
	    -- 	callback(t_data)
	    -- end
	end
	local args_ios = {
		session_id = sessionID,
		session_type = sessionType,
		callback = markAllMessagesReadInSessionCallback,
	}
	local args_android = {sessionID,sessionType,markAllMessagesReadInSessionCallback}  --
	local signs = "(Ljava/lang/String;II)V"
   	local methodName = "markAllMessagesReadInSession"
	 self:luaCallPlatFormMethod(methodName,args_ios,args_android,signs) 

end
-----< 最近回话 --------------
function ChatDataManager:getAlertData( data,alert_type )
	local t_alert = {
		["type"] 		 = alert_type,
		["user_name"] 	 = data["user_name"],
		["user_id"] 	 = data["user_id"],
		["player_id"]	 = data["player_id"]
	}
	return t_alert
end

function ChatDataManager:chatAlert( data )
	local p_type,p_name,p_id = data["type"],data["user_name"],data["user_id"]
	print("type:"..p_type.."..id:"..tostring(p_id).."..name:"..tostring(p_name))
	if p_type == nil or p_type == 0 then
	 	return
	end
	local msgs = {
		["friend1"] = "是否把 %s 加入黑名单",--"是否把 %s 加入黑名单"
		["friend2"] = "是否加 %s 为好友？",
		["friend3"] = "%s 已被加入黑名单。",
		["friend4"] = "%s 已在黑名单",
		["friend5"] = "是否删除 %s ？",	--删除好友
		["friend6"] = "好友申请已发送给 %s ,等待对方审核中",
		["friend7"] = "你的好友申请，被 %s 拒绝了",
		["friend8"] = "%s 同意了你的好友申请。",
		["friend9"] = "你拒绝了 %s 的好友申请。",
		["friend11"] = "你们已经是好友了！",
		["friend12"] = "已申请过，请耐心等待",
		["friend13"] = "因某些原因，无法添加此玩家为好友。",
		["friend14"] = "删除好友成功",
		["friend15"] = "因某些原因，无法与此玩家私聊。",
		["friend16"] = "体力赠送成功，你与好友获得5点体力",
		["friend17"] = "领取体力成功，获得5点体力。",
	}
	local key = string.format("friend%d", p_type)
	local msg1 = UITool.ToLocalization( msgs[key] )
	if p_type < 10 then
		 msg1 = string.format(msg1, p_name) 
	end
	print("msg1...."..msg1)
	-- 1,2,5 双按钮事件，其他单按钮

	local function callfunc()
		-- print("ChatAleart..callfunc..type:"..data["type"].."..id:"..data["id"].."...name:"..data["name"])
		--调SDK
		--1 加好友
		--2 加入黑名单
		--5 删除好友
		if p_type == 1 then
			self:callAddBlack(data )
		elseif p_type ==2 then
			self:callFriendOperation(data,2 )
		elseif p_type == 5 then
			self:callFriendOperation(data,5 ) 
		end

	end

	if p_type == 1 or p_type == 2 or p_type == 5 then 
		MsgManager:showSimpMsgWithCallFunc(msg1, self, callfunc) --带回调的提示信息，确定，取消
	else
		MsgManager:showSimpMsg(msg1) --基本的提示信息，单确定
	end
end

function ChatDataManager:sendFightMessageToSessionID( t_data,sessionId,sessionType) --id,类型:2 聊天室，1 群组，0 个人
    -- local fight = {fightID = 999,fightName = "测试多人战",fightMsg = "测试多人战  Lv 99",fightLv = 99}
	-- self:sendFightMessageToSessionID(fight,self.curChatMember["chatRoom"]["roomId"],2)
	sessionId = string.lower(sessionId)
    local str1 = t_data["fightMsg"]
   	local cjson = require "cjson"
	local tempTable = table.deepcopy(self:getMyUserInfo()) 
	tempTable["message_type"] = 2
	tempTable["fight_data"] = data

	local mydata = cjson.encode(tempTable)

	print("send ChatCall:messge："..str1.."..accid:"..sessionId.."..type:"..sessionType)
	-- NimSDKManager:getInstance():sendChatMessage(str1,sessionId,sessionType,mydata)
	local methodName = "sendChatMessagePlatform"
	local args_ios = {
		["sessionType"] 	= sessionType,
		["message"] 		= str1,
		["sessionId"] 		= sessionId,
		["ext"] 			= mydata,
		-- ["callBack"] 	= callBack,
	}
	local args_android = {
		str1, 
		sessionId,
		sessionType,
		mydata
		-- callBack,
	}
	local signs = "(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V" 

	self:luaCallPlatFormMethod(methodName, args_ios,args_android, signs)
end

function ChatDataManager:luaCallPlatFormMethod( method,args_ios,args_android,signs )  --args oc需要使用字典，java使用数组
    local platform = cc.Application:getInstance():getTargetPlatform()
    local ok,ret,className
    if platform == cc.PLATFORM_OS_ANDROID then
        local luaj = require "cocos.cocos2d.luaj"
        className = "org/cocos2dx/lua/XBNimSDKManager"
        ok,ret  = luaj.callStaticMethod(className,method,args_android,signs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        className = "NIMChatControl"
        luaoc = require "cocos.cocos2d.luaoc" 
        ok,ret  = luaoc.callStaticMethod(className, method, args_ios)
    end
    if not ok then
        print("luaoc error:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(method))
    else
        print("The oc ret is:"..tostring(ret)..",className="..tostring(className)..",methodName="..tostring(method))
    end
    return ok,ret
end

-------------------- sdk 交互，sdk返回-------------------
function ChatDataManager:receiveSendMessageData( data )--发送消息成功回调 单条消息-自身回调---刷新页面数据
	print("--- receiveSendMessageData:"..data)
	--test
	-- MsgManager:showSimpMsg("ChatLayer:--- receiveSendMessageData:");
        local cjsonSafe = require "cjson"
        local t_data = cjsonSafe.decode(data)
        local code = tonumber(t_data["code"])
        if code ~= nil then --7101 黑名单
   --  		local str = string.format(UITool.ToLocalization("因某些原因，无法与此玩家私聊。"))
			-- GameManagerInst:alert(str)
			local errormsg = t_data["message"]
			if errormsg ~= nil then
				GameManagerInst:alert(errormsg)
			end
			return
        end

		self:pushChatItemData(t_data)
		if self.uiDelegate ~= nil then
			self.uiDelegate:refreshTable(0)
		end		

	-- end
end

function ChatDataManager:onReceiveSystemNotification(data ) -- 接受群组，好友管理信息（好友邀请，删除，返回信息）
	print("onReceiveSystemNotification:data"..data)
	local cjson = require "cjson"
	t_data = cjson.decode(data)

	local postscript = t_data["postscript"]
	local sourceID = t_data["sourceID"]  --发送者ID
	local targetID = t_data["targetID"]		
	local notificationType = t_data["notificationType"]
	local operationType = t_data["operationType"]

	if notificationType == 5 then --好友操作
		--添加到好友列表中 
		if operationType == 1 then 				 --对方直接添加，直接加入好友列表
			print("对方直接加我为好友，暂时不提供此需求")
		elseif operationType == 2 then 			 --对方请求添加，加入好友列表，显示（通过，拒绝）
			self:delSysNotificationAddFriendRequest( sourceID ,notificationType,operationType)
		elseif operationType == 3 then 			 --对方通过了我的好友请求 
			self:delSysNotificationAddFriendAgree(sourceID)
		elseif operationType == 4 then 			 --对方拒绝了我的好友请求，不处理（主动发起好友请求时，不加入好友列表）
			self:delSysNotificationAddFriendRefused(sourceID)
		end

	else
		-- 0 申请入群 1 拒绝入群 2 邀请入群 3 拒绝入群邀请
		print("notificationType:"..notificationType)
	end

end

function ChatDataManager:delSysNotificationAddFriendRequest( sourceID ,notificationType,operationType)
	if self:isInFriends(sourceID) == false then
		self:addUserToUserList(sourceID,1)	--加入好友列表中，类型为添加好友
	else
		--直接删除此条通知
		self:removeSystemNotification(sourceID,notificationType,operationType)
		print("---------已经是好友了，需要删除此条通知！！！")
	end
end

function ChatDataManager:delSysNotificationAddFriendAgree( sourceID )
	local function callAddToFriend( t_data )
		self:addToFriends(t_data)
		self:addUserToUserList(sourceID,0)	--加入好友列表中，类型为添加好友
		local t_alert = {}
		t_alert["user_name"] = t_data["user_name"]
		t_alert["user_id"] = t_data["user_id"]
		t_alert["type"] = 8
		self:chatAlert(t_alert)
	end
	self:getUserInfo(sourceID,callAddToFriend)
end

function ChatDataManager:delSysNotificationAddFriendRefused( sourceID )
	local function callRejectFriend( t_data )
		local t_alert = {}
		t_alert["user_name"] = t_data["user_name"]
		t_alert["user_id"] = t_data["user_id"]
		t_alert["type"] = 7
		self:chatAlert(t_alert)
	end
	self:getUserInfo(sourceID,callAddToFriend)			
end

function ChatDataManager:receiveNimServerMessageData( data )
	-- body
	print("--- receiveNimServerMessageData:"..tostring(data))
	
	local cjson = require "cjson"
	local t_datas = cjson.decode(data)

	for i=1,#t_datas do
		local t_data = t_datas[i]
		local msgType = t_data["messageType"]
		if msgType == 0 or msgType == 2 then
			self:pushChatItemData(t_data)
		end
	end
	if self.uiDelegate then
		self.uiDelegate:refreshTable(0)
	end
end

function ChatDataManager:callRecordOverFile( fileName )
	if self.uiDelegate then
		self.uiDelegate:callRecordOverFile(fileName)
	end 
end


function ChatDataManager:testPushSchedule(  )
	if self.testNum ~= nil or self.TestMode ~= true then
		return
	end
	local function scheduleCallfunc( time )
		print("self：TestPushData")
		self:TestPushData()
	end

    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:scheduleScriptFunc(scheduleCallfunc,5, false)
end

function ChatDataManager:TestPushData(  )

  	self.testNum = self.testNum or 1
	self.testNum = self.testNum + 1
  	local t_data = {
	  	["messageId"] = "e220bd22-1378-4b96-a514-e525a2202d1e",
	    ["messageType"] = 0,
	    ["from"] = "253z5fvd9_gf",
	    ["isOutgoingMsg"] = false,
	    ["text"] = "testNUM:  "..self.testNum.."    time2:"..os.time(),
	    ["session"] = {
	      ["sessionId"] = "22397593",
	      ["sessionType"] = 2
	    },
	    ["isReceivedMsg"] = true,
	    ["senderName"] = "开心药师巴q",
	    ["timestamp"] = os.time(),
	    ["remoteExt"] = {
	      ["user_icon"] = 13,
	      ["user_id"] = "253Z5FVD9_gf",
	      ["user_lv"] = 7,
	      ["user_name"] = "开心药师巴q"
	  	}
	  }

	local msgType = t_data["messageType"]
	if msgType == 0 then
		self:pushChatItemData(t_data)
	end
	if self.uiDelegate then
		self.uiDelegate:refreshTable(0)
	end
end






