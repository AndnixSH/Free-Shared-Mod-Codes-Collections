-- 按键精灵坐标数据


QuickMacroData = class("QuickMacroData")
QuickMacroData.__index = QuickMacroData
QuickMacroData.MAX_POINT_NUM = 50 --单个数据包含坐标上限
function QuickMacroData:compare( qm_data )
	if qm_data == nil then 
		print ("-------------------------数据无效1------------")
		return false
	end

	if qm_data.length == 0  then 
		print ("-------------------------数据无效2------------")
		return false 
	end 

	if  qm_data.length ~= self.length  then 
		print("----------------------数据长度不匹配 ")
		return false 
	end 

	for i=1,self.length do
		local pos1 = self.dataVec[i]
		local pos2 = qm_data.dataVec[i]
		if cc.pGetDistance(pos1,pos2) > 10 then 
			-- print("i:"..i.."..pos1:"..pos1.x..","..pos1.y.."......pos2:"..pos2.x..","..pos2.y)
			return false
		end
	end


	return true 
end

function QuickMacroData:saveTouchPoint( point )
	print("self.length:"..tonumber(self.length)..",...QuickMacroData.MAX_POINT_NUM:"..tonumber(QuickMacroData.MAX_POINT_NUM))
	if self.length >= QuickMacroData.MAX_POINT_NUM then 
		print("warnning---------当前数据已达上限："..tonumber(QuickMacroData.MAX_POINT_NUM))
		return 
	end 
	-- print("saveTouchPoint:"..point.x..","..point.y)
	self.length = self.length + 1
	self.dataVec[self.length] = point

end

function QuickMacroData:init( ... )
	self.length = 0
	self.dataVec = {} 		--数据数组
end

function QuickMacroData:create( ... )	
	local qm_data = QuickMacroData.new()
	qm_data:init()
	return qm_data 
end

