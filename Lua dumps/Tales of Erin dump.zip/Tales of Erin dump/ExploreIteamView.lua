--[[
	ExploreIteamView.lua
	探索主界面的item
]]
ExploreIteamView = class("ExploreIteamView", XUICellView)
ExploreIteamView.CS_FILE_NAME = "ExploreItem.csb"
ExploreIteamView.CS_BIND_TABLE = 
{ 
	rootNode = "/s:panel",
}

function ExploreIteamView:init(...)
	ExploreIteamView.super.init(self,...)
    return self
end
--重置UI
function ExploreIteamView:onResetData()
    if not self._data then return end
    local exploreId = self._data.explore_id --探索Id
    local exploreState = tonumber(self._data.explore_state) -- #0未解锁 1、可进行 2、进行中 3、已完成
    local exploreTime =  self._data.explore_time -- 单位S
    local act_tpye = self._data.act_type or 0 -- 活动类型
    local dataTable = {
       name = UITool.getUserLanguage(exploerPass[exploreId].level_name),--名字
       icon = exploerPass[exploreId].level_icon,--icon
       needTime = exploerPass[exploreId].level_limit,--所需时间
       dropRewards = exploerPass[exploreId].drop_reward,--奖励掉落
       needELevel = exploerPass[exploreId].need_level--奖励掉落
    }
    --标题
    local title = ccui.Helper:seekWidgetByName( self.rootNode,"title")
    title:setString(dataTable.name)

    --活动
    local actImg = ccui.Helper:seekWidgetByName( self.rootNode,"act_img")
    if act_tpye == 0 then 
        actImg:setVisible(false)
    else 
        actImg:setVisible(true)
    end 

    --icon 
    local imgIcon = ccui.Helper:seekWidgetByName( self.rootNode,"level_icon")
    imgIcon:loadTexture(dataTable.icon)
    --奖励掉落
    local rewarduis = {}
    for i=1,3 do
        local rewardBG = ccui.Helper:seekWidgetByName(self.rootNode,"reward_bg_"..i)
        rewardBG:setVisible(false)
        rewarduis[#rewarduis+1] = rewardBG
    end
    self:dealDropReward(dataTable.dropRewards,rewarduis)

    local showNode = nil
    local ii = exploreState+1 --从0 状态开始的。
    for i=1,4 do
        local node = ccui.Helper:seekWidgetByName(self.rootNode,"state_"..i)
        if i==ii then 
            node:setVisible(true)
            showNode = ccui.Helper:seekWidgetByName(self.rootNode,"state_"..i)
        else 
            node:setVisible(false)
        end
    end
    ---三个方法带多去
    local function onCickStartBtn(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
		    if self.onCickStartBtn then
		        self.onCickStartBtn(self)
		    end
        end
    end 
    local function onCickQucikDoBtn(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.onCickQucikDoBtn then
		        self.onCickQucikDoBtn(self)
		    end
        end
    end 
    local function onGetRewardBtn(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if self.onGetRewardBtn then
		        self.onGetRewardBtn(self)
		    end
        end
    end 
    local node3 =  ccui.Helper:seekWidgetByName(self.rootNode,"state_"..3)
    local lastTimeTab = ccui.Helper:seekWidgetByName(node3,"last_time")
    lastTimeTab:stopAllActions()
    --#0未解锁 1、可进行 2、进行中 3、已完成
    if exploreState == 0 then 
        local levelTab = ccui.Helper:seekWidgetByName(showNode,"need_level")
        local str =  string.format(UITool.ToLocalization("探索等级%s解锁"),dataTable.needELevel)
        levelTab:setString(str)
    elseif exploreState == 1 then 
        local needTimeTab = ccui.Helper:seekWidgetByName(showNode,"need_time")
        local str = UITool.getFormatTime(dataTable.needTime)
        needTimeTab:setString(str)
        local btn = ccui.Helper:seekWidgetByName(self.rootNode,"btn")
        btn:addTouchEventListener(onCickStartBtn)
    elseif exploreState == 2 then
    	local lastTimeTab = ccui.Helper:seekWidgetByName(showNode,"last_time")
        local str = UITool.getFormatTime(exploreTime)
        lastTimeTab:setString(str) 
        local btn = ccui.Helper:seekWidgetByName(showNode,"btn")
        btn:addTouchEventListener(onCickQucikDoBtn)
        --开启倒计时，倒计时结束，请求数据
        self:countDownTime(lastTimeTab,exploreTime)
        --todo 请求倒计时
    elseif exploreState == 3 then
        local btn = ccui.Helper:seekWidgetByName(showNode,"btn")
        btn:addTouchEventListener(onGetRewardBtn)
    end
    --刷新数据回调
    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end

--处理奖励掉落
--info奖励UI默认是隐藏的
function ExploreIteamView:dealDropReward(rewards,uis)
    for i=1,#rewards do
        local rootNode = uis[i]
        local reward = rewards[i]
        rootNode:setVisible(true)
    
        local icon = ccui.Helper:seekWidgetByName(rootNode,"icon")
        local numtab = ccui.Helper:seekWidgetByName(rootNode,"num")
        
        local tabs = UITool.getItemInfos(reward.type,reward.id)

        icon:setUnifySizeEnabled(true)
        icon:loadTexture(tabs[2])
        numtab:setString(reward.num)

        local function onCickItem( sender,eventType )
            if eventType == ccui.TouchEventType.ended then
                print("to show item")
                MsgManager:showSimpItemInfo(reward.type,reward.id)
            end
        end 
        icon:addTouchEventListener(onCickItem)      
    end
end
-----倒计时重新处理 
--倒计时
function ExploreIteamView:countDownTime(lab)
    local function TimeFunc()
        if self._data.explore_time then 
            if self._data.explore_time < 0 then 
                if lab ~= nil then 
                    lab:setString(UITool.getFormatTime(0))
                    lab:stopAllActions()
                end 
            else 
                if lab ~= nil then 
                    lab:setString(UITool.getFormatTime(self._data.explore_time))
                end
            end 
        else 
            if lab ~= nil then 
                lab:setString(UITool.getFormatTime(0))
                lab:stopAllActions()
            end 
        end 
    end
    local delay    = CCDelayTime:create(1.0)
    local callfunc = CCCallFunc:create(TimeFunc)
    local sequence = cc.Sequence:create(delay, callfunc)
    local action   = CCRepeatForever:create(sequence)
    lab:runAction(action)
end
