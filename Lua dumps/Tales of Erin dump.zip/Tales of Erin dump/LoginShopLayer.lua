LoginShopLayer = class("LoginShopLayer", function()
    return cc.Layer:create();
end);

function LoginShopLayer:ctor()

    self.rootNode = cc.CSLoader:createNode("LoginShop_Main.csb")
    self.rootPanel = self.rootNode:getChildByTag(26)
    self:addChild(self.rootNode)
    self.exist = true

    self.initial_gem_not_r = user_info["gem"] - user_info["gem_r"]  --无偿星石

    local closeBtn = self.rootPanel:getChildByTag(82)
    closeBtn:addClickEventListener(function()
        self.exist = false
        user_info["gem"] = self.initial_gem_not_r + user_info["gem_r"]
        SceneManager.menuLayer:RefshTopBar()
        self:removeFromParent()
    end)

    self:requestData()
end

--@isRefreshAfterRecharge.是否是购买成功后的刷新
function LoginShopLayer:requestData(isRefreshAfterRecharge)
    if not isRefreshAfterRecharge then
        SceneManager:createWaitLayer()
    end

    local tempTable = {}
    tempTable["rpc"] = "loginshop_info"

    local this = self
    GameManagerInst:rpc(tempTable,
        3,
        function(data)
            --success
            if not self.exist then
                return
            end
            SceneManager:delWaitLayer()
            self.serverData = data
            self:refreshByServerData()
        end,
        function(state_code,msgText)
            --failed
            SceneManager:delWaitLayer()
            GameManagerInst:alert(msgText)
        end,
    true)
end

function LoginShopLayer:refreshByServerData()    
    user_info["gem_r"] = self.serverData.stone_num
    self.rootPanel:getChildByTag(10):setString(self.serverData.stone_num)

    --活跃度
    local ratio = self.serverData.liveness/self.serverData.liveness_max
    local length = ratio * 532
    local sprite_liveness = cc.Sprite:create("n_UIShare/loginshop/ffqd_ui_005.png",cc.rect(0,0,length,12));
    if sprite_liveness then
        sprite_liveness:setAnchorPoint(cc.p(0,0.5))
        sprite_liveness:setPosition(self.rootPanel:getChildByTag(83):getPosition())
        self.rootPanel:addChild(sprite_liveness)
    end

    --活跃度宝箱
    for i = 1,2 do
        local sprite_close = self.rootPanel:getChildByTag(234+i)
        local sprite_open = self.rootPanel:getChildByTag(236+i)

        local shadow = self.rootPanel:getChildByTag(800 + i)
        local light = self.rootPanel:getChildByTag(900 + i)

        if self.serverData.box_list[i].opened_state == 0 then
            sprite_close:setVisible(true)
            sprite_open:setVisible(false)

            --是否可领取
            local openable = false
            if self.serverData.liveness >= self.serverData.box_list[i].liveness_needed then
                openable = true
            else
                if shadow then
                    shadow:removeFromParent()
                end
                if light then
                    light:removeFromParent()
                end
            end

            if openable then
                if not shadow and not light then
                    local sprite_shadow = cc.Sprite:create("n_UIShare/loginshop/loginshop_boxeffect/hou_0001.png");
                    local frames_shadow = {};
                    for i = 1,15 do
                        frames_shadow[i] = cc.Sprite:create(string.format("n_UIShare/loginshop/loginshop_boxeffect/hou_%04d.png",i)):getSpriteFrame();
                    end
                    local animation_shadow = cc.Animation:createWithSpriteFrames(frames_shadow, 0.1)
                    sprite_shadow:runAction(cc.RepeatForever:create(cc.Animate:create(animation_shadow)))
                    sprite_shadow:setPosition(sprite_open:getPosition())
                    self.rootPanel:addChild(sprite_shadow,-1,800 + i)

                    local sprite_light = cc.Sprite:create("n_UIShare/loginshop/loginshop_boxeffect/qian_0001.png");
                    local frames_light = {};
                    for i = 1,15 do
                        frames_light[i] = cc.Sprite:create(string.format("n_UIShare/loginshop/loginshop_boxeffect/qian_%04d.png",i)):getSpriteFrame();
                    end
                    local animation_light = cc.Animation:createWithSpriteFrames(frames_light, 0.1)
                    sprite_light:runAction(cc.RepeatForever:create(cc.Animate:create(animation_light)))
                    sprite_light:setPosition(sprite_open:getPosition())
                    self.rootPanel:addChild(sprite_light,1,900 + i)
                end
            end

            local btn = self.rootPanel:getChildByTag(202+i)
            btn:addClickEventListener(function ()
                --弹出宝箱详情界面
                local detailLayer = LoginShop_DetailLayer_Box:create(self.serverData.box_list[i],self.serverData.liveness,self)
                self:addChild(detailLayer)
            end)
        else
            sprite_close:setVisible(false)
            sprite_open:setVisible(true)
            if shadow then
                shadow:removeFromParent()
            end
            if light then
                light:removeFromParent()
            end            
        end
    end

    --商品列表
    --1金币 2宝石 3装备 4英雄 5素材 6可使用道具 7礼包 8碎片 9钥匙 10信仰 11月卡 12勋章 13苍玉 14人民币
    table.sort(self.serverData.product_list,function (a,b)
        return a.product_idx < b.product_idx
    end)

    --获取显示特效的位置
    local this = self
    local function getEffectIdx()
        local purchaseNum = 0
        for k,v in ipairs(this.serverData.product_list) do
            if v.product_state == 1 or v.product_state == 4 then
                purchaseNum = purchaseNum + 1
            else
                break;
            end
        end

        local totalNum = #this.serverData.product_list
        if purchaseNum == totalNum then
            return nil
        elseif this.serverData.product_list[purchaseNum + 1].product_state == 0 then
            return nil
        else
            return purchaseNum + 1
        end
    end

    local effectIdx = getEffectIdx()  --显示特效的位置.可能为空。

    for k,v in ipairs(self.serverData.product_list) do
        local itemNode = self.rootPanel:getChildByName("FileNode_"..k)
        if itemNode then
            itemNode:setVisible(true)

            local sprite_bg  --背景图片
            local sprite_frame --边框图片
            local sprite_icon
            local isDataAvailable = true --防止配错表
            if v.product_type == 7 then
                local product = gift[v.product_id_local]
                if product then
                    sprite_bg = cc.Sprite:create(Rarity_BG[product.rarity])     
                    sprite_frame = cc.Sprite:create(Rarity_mat[product.rarity])
                    sprite_icon = cc.Sprite:create("icons/mat/"..product.icon)
                else
                    isDataAvailable = false
                end
            else
                local itemInfo = UITool.getItemInfos(v.product_type,v.product_id_local)
                if itemInfo then
                    sprite_bg = cc.Sprite:create(itemInfo[4])
                    sprite_frame = cc.Sprite:create(itemInfo[1])
                    sprite_icon = cc.Sprite:create(itemInfo[2])
                else
                    isDataAvailable = false
                end
            end

            if isDataAvailable then
                sprite_bg:setScale(0.62)
                sprite_frame:setScale(0.62)
                sprite_icon:setScale(0.6)

                itemNode:addChild(sprite_bg,-1)
                itemNode:addChild(sprite_frame,-1)
                itemNode:addChild(sprite_icon,-1)
            end

            local reSignFlagSprite = itemNode:getChildByTag(1)
            local btn = itemNode:getChildByTag(3)

            --补签
            if v.product_state == 3 then
                reSignFlagSprite:setVisible(true)
            else
                reSignFlagSprite:setVisible(false)
            end

            --如果是非礼包，显示数量
            if v.product_type ~= 7 and v.product_num and v.product_num >= 1 then
                local text = itemNode:getChildByTag(2)
                text:setString(v.product_num)
            end

            --可购买的位置
            if effectIdx and k == effectIdx then
                local sprite = cc.Sprite:create("n_UIShare/loginshop/loginshop_effect/loginshop_effect_0001.png");
                local frames = {};
                for i = 1,15 do
                    frames[i] = cc.Sprite:create(string.format("n_UIShare/loginshop/loginshop_effect/loginshop_effect_%04d.png",i)):getSpriteFrame();
                end
                local animation = cc.Animation:createWithSpriteFrames(frames, 0.1)
                sprite:runAction(cc.RepeatForever:create(cc.Animate:create(animation)))
                itemNode:addChild(sprite)
            end

            --锁定状态
            if v.product_state == 4 then
                local sprite = cc.Sprite:create("n_UIShare/loginshop/ffqd_ui_007.png");
                sprite:setScaleX(0.9)
                itemNode:addChild(sprite)
            end

            --当前进度
            if v.product_state == 2 then
                local sprite = cc.Sprite:create("n_UIShare/loginshop/ffqd_ui_008.png");
                sprite:setScaleX(0.9)
                sprite:setPosition(cc.p(0,26.25))
                itemNode:addChild(sprite)
            end

            --按钮响应
            btn:setEnabled(true)
            btn:setVisible(true)
            if v.product_state == 1 or v.product_state == 4 then --已购买，提示无法购买
                btn:setOpacity(255*0.45)
                btn:addClickEventListener(function ()
                    GameManagerInst:alert(UITool.ToLocalization("无法购买"))
                end)
            elseif v.product_state == 2 or v.product_state == 3 then  --补买或购买
                btn:addClickEventListener(function ()
                    if effectIdx and k == effectIdx then
                        self:showProductDetailLayer(v,true)
                    else
                        self:showProductDetailLayer(v,false)
                    end
                end)                
            elseif v.product_state == 0 then  --未开启
                btn:addClickEventListener(function ()
                    self:showProductDetailLayer(v,false)
                end)
            end
        end
    end
end

--商品详情弹窗
--@isAvailable:是否可购买
function LoginShopLayer:showProductDetailLayer(productData,isAvailable)
    --两种情况，一种是礼包，一种是单品
    --点击后显示购买界面。如果是礼包类，使用GiftShowListLayer.csb改。如果是单品类，使用MsgBoxNode_9改。
    if productData.product_type == 7 then
        local detailLayer = LoginShop_DetailLayer_Gift:create(productData,self,isAvailable)
        self:addChild(detailLayer)
    else
        local detailLayer = LoginShop_DetailLayer_Item:create(productData,self,isAvailable)
        self:addChild(detailLayer)
    end
end