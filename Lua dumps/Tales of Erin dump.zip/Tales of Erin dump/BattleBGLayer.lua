--背景Layer。
--共四层。前景，场景，中景，远景。常用的是场景和中景。
--前景，场景：正常的速度移动。中景 1/4的速度  远景：1/10的速度移动
--created by kobejaw.2018.3.19.
BattleBGLayer = class("BattleBGLayer", function()
    return cc.Layer:create();
end);

--如果是boss战，加载一张背景图就可以了
--如果是pve，加载2张首尾相连的背景图
--如果是pvp，加载3张首尾相连的背景图，不过最好是pvp镜头不需要移动。

function BattleBGLayer:ctor()
	self:initMemberVariables()
	self:initBGSprites()
end

function BattleBGLayer:initMemberVariables()
	G_BattleBGLayer = self

	self.battleData = BattleDataManager:getData()

	if BattleDataManager.isBoss then
		self.type = 1 --boss战
	elseif G_STAGE_TYPE == 4 then
		self.type = 3 --pvp
	else
		self.type = 2 --普通pve
	end

	self.layers = {}
	for i = 4,1,-1 do
		self.layers[i] = cc.Layer:create();
		self:addChild(self.layers[i])
	end

	self.layerNum = 0;  --图层数
	self.pathArray = {}  --每一层的资源路径
	self.widthArray = {} --每一层的宽度
	self.posIdxArray = {}   --位置
	self.bgTypeArray = {}  --每一层对应的前中远景的type。1.前。2.场景。3.中景。4.远景。

	self.centerPointX = 640; --当前屏幕的中心点在BattleBGLayer上的x值。
end

function BattleBGLayer:initBGSprites()
	local mapId = tonumber(self.battleData.scene_id)
	for i = 4,1,-1 do
		local path = map[mapId]["map_"..i]
		if path ~= "" then
			if string.find(path, ".atlas") then --只有一处用到，而且一定是boss战，boss战的地图不会滚动，所以不必做额外处理了
				local spine = sp.SkeletonAnimation:createWithSkeletonAnimation(BattleCacheManager:getData(path))
				spine:setAnimation(1,"effect" , true);
				spine:setPosition(cc.p(640,400))
				self.layers[i]:addChild(spine)
			else
				self.layerNum = self.layerNum + 1
				table.insert(self.pathArray,path)
				table.insert(self.bgTypeArray,i)
				local sprite = self:createOneSprite(self.layerNum)
				table.insert(self.widthArray,sprite:getContentSize().width)
			end
		end
	end

	--如果是pve，加载2张首尾相连的背景图
	if self.type == 2 then
		for i = 1,self.layerNum do
			self:createOneSprite(i,1)
			self.posIdxArray[i] = 1;

			--补充，左侧额外再加一张防止漏边
			self:createOneSprite(i,-1)
		end
	end
end

function BattleBGLayer:createOneSprite(layerIdx,posIdx)
	print("BGSprite LayerIdx = "..layerIdx.."   Name =  "..self.pathArray[layerIdx])
	local texture = cc.Director:getInstance():getTextureCache():addImage(self.pathArray[layerIdx])
	local sprite = cc.Sprite:createWithTexture(texture)
	sprite:getTexture():setAliasTexParameters();
	sprite:setAnchorPoint(cc.p(0.5,0.5))

	local mapType = self.bgTypeArray[layerIdx]
	self.layers[mapType]:addChild(sprite)

	if posIdx == nil then
		sprite:setPosition(640,400)
	else
		sprite:setPosition(640 + posIdx*self.widthArray[layerIdx],400)
	end

	return sprite
end


function BattleBGLayer:update(dt)
	if self.type == 2 then		
		self.centerPointX = G_BattleLayer:convertToNodeSpace(cc.p(640,360)).x
		for i = 1,self.layerNum do
			local mapType = self.bgTypeArray[i]
			self.centerPointX = self.layers[mapType]:convertToNodeSpace(cc.p(640,360)).x
			if (self.centerPointX - 640)/self.widthArray[i] > self.posIdxArray[i] then
				self.posIdxArray[i] = self.posIdxArray[i] + 1
				self:createOneSprite(i,self.posIdxArray[i])
			end
		end
	elseif self.type == 3 then
		
	end
end

--随battleLayer的移动而更新
function BattleBGLayer:OnBattleLayerMoved(deltaX)
	for i = 1,self.layerNum do
		local mapType = self.bgTypeArray[i]
		if mapType <= 2 then
			self.layers[mapType]:setPositionX(self.layers[mapType]:getPositionX() + deltaX)
		elseif mapType == 3 then
			self.layers[mapType]:setPositionX(self.layers[mapType]:getPositionX() + deltaX /4)
		else
			self.layers[mapType]:setPositionX(self.layers[mapType]:getPositionX() + deltaX /10)
		end
	end
end

--切换下一波怪的时候调用一下
function BattleBGLayer:reset()
	self:removeAllChildren()
	self:initMemberVariables()
	self:initBGSprites()
end