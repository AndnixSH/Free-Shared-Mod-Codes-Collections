--战斗Layer。各种layer的父layer。
--created by kobejaw.2018.3.16.
BattleLayer = class("BattleLayer", function()
    return cc.Layer:create();
end);

function BattleLayer:ctor()
    G_BattleLayer = self;

    --成员变量
    self:initMemberVariables()

    --各种manager
    self:initManagers()

    --各种layer
    self:initLayers()

    --启动update
    self:startUpdate()
end

function BattleLayer:initMemberVariables()
    self.isNeedCheckBGM1Finish = nil
end

function BattleLayer:initManagers()
    if not BattleDataManager.isBoss then
         BattleCameraManager:init();
    end
    BattleRuntimeInfo:init() 
    TriggerChecker:init();
    BattleDamageDisplay:init();
end

function BattleLayer:initLayers()

    --EntityLayer
    local entityLayer = BattleEntityLayer:create()
    self:addChild(entityLayer,BattleZOrder.Entity)
    --队伍
    BattleRuntimeInfo.teams[1] = TeamManager.new(1)
    BattleRuntimeInfo.teams[2] = TeamManager.new(2)
    --创建怪物
    entityLayer:createOneWaveMonster(BattleRuntimeInfo.teams[2])
    --创建我方角色
    entityLayer:createRoles(BattleRuntimeInfo.teams[1])

    entityLayer:resetEntities()
    entityLayer:resetZOrder()

    --技能特效layer
    local effectlayer = BattleEffectLayer:create()
    self:addChild(effectlayer,BattleZOrder.Effect)
end

function BattleLayer:startUpdate()
    local function update(dt)
        --切换到第二首背景音乐
        if BattleRuntimeInfo.isMusicOn and G_BattleScene.isNeedCheckBGM1Finish and BattleIsBGMPlaying() then
            G_BattleScene.isNeedCheckBGM1Finish = nil
            if BattleDataManager.bgm2 then
                BattlePlayBGM(BattleDataManager.bgm2,true)
            end
        end
        --更新UI
        if G_STAGE_TYPE >= 2 then
            BattleUIManager:update(dt)
        elseif G_GameState == 1 or G_GameState == 3 then
            BattleUIManager:update(dt)
        end

        if G_GameState == 4 or G_GameState == 2 then
            return
        end

        --更新主动技能
        ActiveSkillManager:update(dt)
        --更新背景
        G_BattleBGLayer:update(dt)

        --多人战同步信息
        if G_STAGE_TYPE == 2 then
            BattleRuntimeInfo:update(dt)
        end

        --camera
        if G_GameState ~= 3 and not BattleDataManager.isBoss then
            --更新镜头位置
            BattleCameraManager:update(dt)
            --镜头缩放
            G_BattleContainerLayer:checkZoom()
        end
    end
    self:scheduleUpdateWithPriorityLua(update,0)
end

--切换下一波怪的时候调用
function BattleLayer:reset()
    self:setPositionX(0)
end