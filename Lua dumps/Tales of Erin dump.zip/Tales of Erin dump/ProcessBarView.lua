--require "XUIView"

ProcessBarView = class("ProcessBarView", XUIView)

ProcessBarView.CS_FILE_NAME = "ProcessBarView.csb"
ProcessBarView.CS_BIND_TABLE = 
{
    lbTitle = "/i:4/i:5/i:11",
    lbMessage = "/i:4/i:5/i:9",
    lbProcess = "/i:4/i:5/i:10",
    barProcess = "/i:4/i:5/i:7",
    panelBG = "/i:4",
}
ProcessBarView.onBgTouchedEvent = nil

function ProcessBarView:init(...)
    ProcessBarView.super.init(self,...)

    self.lbTitle:setString("")
    self.lbMessage:setString("")
    self.lbProcess:setString("")
    self.barProcess:setPercent(0)

    return self
end

function ProcessBarView:setTitle(title)
    self.lbTitle:setString(title)
end

function ProcessBarView:setMessage(title)
    self.lbMessage:setString(title)
end

function ProcessBarView:setPercent(percent)
    self.barProcess:setPercent(percent)
end

function ProcessBarView:setProcessMsg(title)
    self.lbProcess:setString(title)
end