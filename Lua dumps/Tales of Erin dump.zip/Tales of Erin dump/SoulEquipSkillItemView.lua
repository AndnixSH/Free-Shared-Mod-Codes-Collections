--require "XUICellView"

SoulEquipSkillItemView = class("SoulEquipSkillItemView", XUICellView)
SoulEquipSkillItemView.CS_FILE_NAME = "SoulEquipSkillItemView.csb"
SoulEquipSkillItemView.CS_BIND_TABLE = 
{
    skillIcon = "/i:29/i:114",
    skillName = "/i:29/i:243",
    skillDesc = "/i:29/i:115",
    touchPanel = "/i:2475",
    lockedText = "/i:2487",
}

function SoulEquipSkillItemView:init(...)
    SoulEquipSkillItemView.super.init(self,...)
    if g_channel_control.transform_SoulEquipSkillItemView_lockedText_pos == true then
        local oldX = 57
        local newX = oldX - 8
        self.lockedText:setPositionX(newX)
    end
    self.touchPanel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)


    return self
end

function SoulEquipSkillItemView:refresh()
    if not self.skillId then
        return
    end
    if passive_sk[self.skillId] then
        self.skillData = passive_sk[self.skillId]
    end
    self:RefreshName()
    self:RefreshDesc()
    self:RefreshIcon()
    self:RefreshState()
end

function SoulEquipSkillItemView:RefreshIcon()
    if not self.skillId then
        return
    end
    if not self.skillData then
        return
    end
    local iconImagePath = self.skillData.sk_icon
    if iconImagePath then
        self.skillIcon:setTexture(iconImagePath)
    end
end

function SoulEquipSkillItemView:RefreshDesc()
    if not self.skillId then
        return
    end
    if not self.skillData then
        return
    end
    local sDesc = UITool.getUserLanguage(self.skillData.sk_des)
    if sDesc then
        self.skillDesc:setString(sDesc)
    end
end

function SoulEquipSkillItemView:RefreshName()
    if not self.skillId then
        return
    end
    if not self.skillData then
        return
    end
    local sName = UITool.getUserLanguage(self.skillData.sk_name)
    if sName then
        self.skillName:setString(sName)
    end
end

function SoulEquipSkillItemView:RefreshState()
    if not self.skillId then
        return
    end
    if not self.skillData then
        return
    end
    if not self.index then
        return
    end

    local nIndex = self.index
    local str = string.format(UITool.ToLocalization("升华%d次后\n     解锁"), nIndex)
    if nIndex == 1 and g_channel_control.transform_SoulEquipSkillItemView_skillName == true then 
        str = UITool.ToLocalization("升华1次后\n     解锁")
    end 
    self.lockedText:setString(str)--"升华"..nIndex.."次后".."\n".."     解锁")

    local bIsHaved = self.isHaved
    if bIsHaved then
        self.lockedText:setVisible(false)
        self.skillIcon:setColor(cc.c3b(255, 255, 255))
        self.skillName:setColor(cc.c3b(255, 255, 255))
        self.skillDesc:setColor(cc.c3b(255, 255, 255))

    else
        self.lockedText:setVisible(true)
        self.skillIcon:setColor(cc.c3b(127, 127, 127))
        self.skillName:setColor(cc.c3b(127, 127, 127))
        self.skillDesc:setColor(cc.c3b(127, 127, 127))

    end
end

function SoulEquipSkillItemView:SetSkillId(nSkillId)
    self.skillId = nSkillId
    self:refresh()
end

function SoulEquipSkillItemView:SetIsHavedSkill(bIsHaved)
    self.isHaved = bIsHaved
    self:refresh()
end

function SoulEquipSkillItemView:SetSkillIndex(nIndex)
    self.index = nIndex
    self:refresh()
end



