MsgBoxLayer = class("MsgBoxLayer",XUIView)
MsgBoxLayer.CS_FILE_NAME = "MsgBoxLayer.csb"
MsgBoxLayer.CS_BIND_TABLE = 
{
	Panel_1 		= "/i:1",
	Image_bg 		= "/i:1/i:101",
	Text_title 		= "/i:1/i:102",
	Text_dec 		= "/i:1/i:103",
	Button_close 	= "/i:1/i:296",

	Node_GoodsInfo 		= "/i:1/i:104",
	Image_icon_bg 		= "/i:1/i:104/i:10401",
	Image_icon_form 	= "/i:1/i:104/i:10403",
	Image_icon 			= "/i:1/i:104/i:10402",
	Text_name 			= "/i:1/i:104/i:10404",
	Text_num 			= "/i:1/i:104/i:10405",
	Text_state 			= "/i:1/i:104/i:10406",
	Image_superscript	= "/i:1/i:104/i:10407",

	Node_outPut = "/i:1/i:105",
	btn_outPut1 = "/i:1/i:105/i:10501",
	btn_outPut2 = "/i:1/i:105/i:10502",
	btn_outPut3 = "/i:1/i:105/i:10503",
	Text_outPut3 = "/i:1/i:105/i:10503/i:105031",
	Image_out1	= "/i:1/i:105/i:10501/i:105012",
	Image_out2	= "/i:1/i:105/i:10502/i:105022",
	Text_out1 	= "/i:1/i:105/i:10501/i:105011",
	Text_out2	= "/i:1/i:105/i:10502/i:105021",

	Node_sell 			= "/i:1/i:106",
	Image_gembg 		= "/i:1/i:106/i:10601",
	Text_cost_title 	= "/i:1/i:106/i:10601/i:106011",
	Text_cost 			= "/i:1/i:106/i:10601/i:106012",
	
	Image_numBg 	= "/i:1/i:106/i:10602",
	Button_del 		= "/i:1/i:106/i:10602/i:106021",
	Button_add 		= "/i:1/i:106/i:10602/i:106022",
	Text_Buy_num 	= "/i:1/i:106/i:10602/i:106023",
	Button_cancle 	= "/i:1/i:106/i:10604",
	Button_confirm 	= "/i:1/i:106/i:10605",
	Text_confirm 	= "/i:1/i:106/i:10605/i:106051",

	Node_buy 			= "/i:1/i:107",
	Image_buy_bg		= "/i:1/i:107/i:10701",
	Text_Buy_cost		= "/i:1/i:107/i:10702",
	Button_buy_ok 		= "/i:1/i:107/i:10704",
	Button_buy_del 		= "/i:1/i:107/i:10703/i:107031",
	Button_buy_add 		= "/i:1/i:107/i:10703/i:107032",
	Text_buy_count 		= "/i:1/i:107/i:10703/i:107033",

	Node_details 		= "/i:1/i:108",
	Button_use			= "/i:1/i:108/i:10801",
}

function MsgBoxLayer:init(tab)
	MsgBoxLayer.super.init(self)
	if tab == nil then
		return nil
	end 
	self._data = tab
	self.callFunc = nil
	self:initUI()
	self:initBtn()

	self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)

	return self
end

function MsgBoxLayer:initUI()
	self.Image_bg:setUnifySizeEnabled(true)
	self.Image_bg:loadTexture(table.getValue("self._data",self._data,"bgDes"))

	self.Node_sell:setVisible(false)
	self.Node_outPut:setVisible(false)
	self.Node_buy:setVisible(false)
	self.Node_details:setVisible(false)

	--公用部分
	local item_type = table.getValue("self._data",self._data,"tab_data","item_type")
	local item_id = table.getValue("self._data",self._data,"tab_data","item_id")
	local itemNum = table.getValue("self._data",self._data,"tab_data","itemNum")
	local item_data = UITool.getItemInfos(item_type,item_id)

	self.Image_icon_bg:setUnifySizeEnabled(true)
	self.Image_icon_bg:loadTexture(table.getValue("item_data",item_data,4))
	self.Image_icon_form:setUnifySizeEnabled(true)
	self.Image_icon_form:loadTexture(table.getValue("item_data",item_data,1))
	self.Image_icon:setUnifySizeEnabled(true)
	self.Image_icon:loadTexture(table.getValue("item_data",item_data,2))
	if item_data[3] ~= "" then
		local elementImg = cc.Sprite:create(item_data[3])
        elementImg:setAnchorPoint(cc.p(0.5,0.5))
        elementImg:setPosition(134.5,113)
      	elementImg:setScale(0.6)
      	self.Image_icon_form:addChild(elementImg)
	end

	self.Text_name:setString(table.getValue("item_data",item_data,5))
	local des = string.gsub(table.getValue("item_data",item_data,6),"*","")
	self.Text_dec:setString(des)
	local textNumStr = Lang:toLocalization(1040016)..tostring(itemNum)
	self.Text_num:setString(textNumStr)
	if itemNum == 0 then
		--self.Text_num:setString("")
	end
	self.Text_state:setString("")

	--判断是否限时
	self.sTime = 0
	self.isShowTime = false
	if mat[item_id] and item_type ~= 6 and item_type ~= 7 and item_type ~= 8 and item_type ~= 21 then
		local str_img = mat[item_id]["superscript"]
		if str_img == "" then
			self.Image_superscript:setVisible(false)
		else
			self.Image_superscript:loadTexture(str_img)--显示左上角的角标
		end

		local ret,rTime = UITool.getRemainTimes(mat[item_id]["expiration_date_type"],mat[item_id]["expiration_date"])
		if ret == true then
			self.sTime = rTime
			self.isShowTime = ret
		end
	else
		self.Image_superscript:setVisible(false)
	end

	dump(self._data,"self._data:")
	dump(item_data,"item_data:")

	local diff_count = table.getValue("self._data",self._data,"boxType")
	local switch = 
	{
		[0] = function()
			print("不带图片的详情界面")
		end,
		[1] = function()
			print("详情界面的弹窗")
			self.Node_details:setVisible(true)
			self:setDetails()
		end,
		[2] = function()
			print("带售卖的弹窗")
			self.Node_outPut:setVisible(true)
			self:setSell(item_id,item_type)
		end,
		[3] = function()
			print("带购买的弹窗")
			self.Node_buy:setVisible(true)
			self:setBuy(item_id,item_type)
		end,
		[4] = function()
			print("不带售卖的产出界面")
			self.Node_outPut:setVisible(true)
			self:setOutPut(item_id,item_type)
		end
	}

	local f = switch[diff_count]
	if f then
		f()
	else
		print("参数错误")
	end
end

function MsgBoxLayer:setDetails()
	local img = table.getValue("self._data",self._data,"tab_data","img")
	local callf = table.getValue("self._data",self._data,"tab_data","callFunc")
	if img ~= nil then
		self.Image_icon_form:setUnifySizeEnabled(true)
		self.Image_icon_form:loadTexture(img)
		
		local dec = table.getValue("self._data",self._data,"tab_data","dec")
		self.Text_dec:setString(dec)
		local name = table.getValue("self._data",self._data,'tab_data',"name")
		self.Text_name:setString(name)
	end
	self.Text_title:setString("提示")

	self.callFunc = nil
	self.callFunc = callf
end

function MsgBoxLayer:initOutPut(item_id,item_type,onself,callFunc)
	local _tab = {}
	if item_type == 6 then
		_tab = useprop 
	elseif item_type == 7 or item_type == 21 then
		_tab = gift
	elseif item_type == 8 then
		_tab = piece
	else
		_tab = mat
	end
	print("@initOutPut item_id:",item_id)
    local name1 = table.getValue("_tab",_tab,item_id,"jump_name1")
    local name2 = table.getValue("_tab",_tab,item_id,"jump_name2")
    self.Text_out1:setString(name1)
    self.Text_out2:setString(name2)
    local pass_drop_state = false
    local exploer_drop_state = false
    local tab_drop = _tab[item_id]["drop_list"]
    -- if item_type == 6 then--临时添加，因为道具没有在mat表中，等策划定好规则再修改 
    -- 	tab_drop[1] = -1
    -- 	tab_drop[2] = -1
    -- end
    if tab_drop[1] ~= -1 then
    	pass_drop_state = true
    end
    if tab_drop[2] ~= -1 then
    	exploer_drop_state = true
    end
    local function toShopLayer(_Index)
		print("去商店1")
		local rcvData = {}
		rcvData["shopTypeIndex"] = _Index
		SceneManager:hideMsgMode()
		SceneManager:toShopLayer(rcvData)
	end
    function touchCallBack(sender,eventType)
    	if eventType == ccui.TouchEventType.ended then
    	--1:关卡；2:星界;3:成就
    		local switch = 
    		{
    			[1] = function()
    				print("去关卡")
		            SceneManager:hideMsgMode()
		            local rcvData = {}
		            rcvData["item_type"] = item_type
		            rcvData["item_id"] = item_id
		            rcvData["callFunc"]   = callFunc
		            rcvData["self"]       = onself
		            SceneManager:toBattlePassListLayer(rcvData)
    			end,
    			[2] = function()
    				if tonumber(user_info["rank"]) >= UnlockExploreRank then
	                  	SceneManager:hideMsgMode()
	                  	local rcvData = {}
	                  	rcvData.isBackStartLayer = 0
	                  	rcvData["callFunc"]   = callFunc
	                  	rcvData["self"]       = onself
	                  	SceneManager:toExploreLayer(rcvData)
	                  	print("去探索")
		         	else 
		              	---todo锁住 星界
		                local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),UnlockExploreRank)
		                SceneManager:showPromptLabel(str)
		     			
		        	end
    			end,
    			[3] = function()
    				if tonumber(user_info["rank"]) >= UnlockGongGaoRank then
	    				SceneManager:hideMsgMode()
	    				local rcvData = {}
	    				rcvData["self"] = onself
	    				SceneManager:toAchievement(rcvData)
	    			else
	    				---todo锁住 
		                local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),UnlockGongGaoRank)
		                SceneManager:showPromptLabel(str)
	    			end
    			end,
    			--4——10类型是跳转商店的功能，最好是配表，现在策划不想增加一列配表，暂时写死在代码里（PS:心里想说tmd）
    			[4] = function()
    				toShopLayer(1)
    			end,
    			[5] = function()
    				toShopLayer(2)
    			end,
    			[6] = function()
    				toShopLayer(3)
    			end,
    			[7] = function()
    				toShopLayer(4)
    			end,
    			[8] = function()
    				toShopLayer(5)
    			end,
    			[9] = function()
    				toShopLayer(6)
    			end,
    			[10] = function()
    				toShopLayer(7)
    			end,
    		}
    		
	        if sender:getTag() == 10501 then
	        	if pass_drop_state == true then
	        		local f = switch[tab_drop[1]]
		        	if f then
		        		f()
		        	end
	        	end	
	        elseif sender:getTag() == 10502 then
	        	if exploer_drop_state == true then
	        		local f = switch[tab_drop[2]]
		        	if f then
		        		f()
		        	end
	        	end
	        end 
        end
    end
    self.btn_outPut1:addTouchEventListener(touchCallBack)
    self.btn_outPut2:addTouchEventListener(touchCallBack)
    if pass_drop_state == false then
    	self.btn_outPut1:setTouchEnabled(false)
    	self.Image_out1:loadTexture("n_UIShare/AllMessgae/tc_ui_011_2.png")
    	self.Text_out1:setTextColor(cc.c4b(200,200,200,255))
    end
    if exploer_drop_state == false then
    	self.btn_outPut2:setTouchEnabled(false)
    	self.Image_out2:loadTexture("n_UIShare/AllMessgae/tc_ui_011_2.png")
    	self.Text_out2:setTextColor(cc.c4b(200,200,200,255))
    end
end
function MsgBoxLayer:setSell(item_id,item_type)
	local item_data = UITool.getItemInfos(item_type,item_id)
	local cost_num = table.getValue("self._data",self._data,"tab_data","cost_num")
	local costOnly = table.getValue("self._data",self._data,"tab_data","costOnly")
	local max_buy_num = table.getValue("self._data",self._data,"tab_data","max_buy_num")
	local oneSelf = table.getValue("self._data",self._data,"tab_data","self")
	local callfunc = table.getValue("self._data",self._data,"tab_data","callFunc")
	local sellType = table.getValue("self._data",self._data,"tab_data","sellType")
	local cost_type = table.getValue("self._data",self._data,"tab_data","cost_type")
	local reloadCallFunc = table.getValue("self._data",self._data,"tab_data","reloadCallFunc")
	local refreshTopbar = table.getValue("self._data",self._data,"tab_data","refreshTopbar")

	self:initOutPut(item_id,item_type,oneSelf)
	self.Text_title:setString(UITool.ToLocalization("物品详细"))

	if sellType and sellType == 0 then
        self.Button_confirm:setTouchEnabled(false)
        self.Button_confirm:setBright(false)
        self.btn_outPut3:setTouchEnabled(false)
        self.btn_outPut3:setBright(false)
    end

	local showRTime = function()
		if not self.label then
			self.label = self.Text_state:clone()
			self.label:setAnchorPoint(cc.p(0,0.5))
			self.label:setPosition(cc.p(533,472.67))
			self.Node_GoodsInfo:addChild(self.label)
		end
		local function function_name()
			if reloadCallFunc then
				reloadCallFunc(oneSelf)
			end
			self:removeFromParentView()
		end
		self:schedule(self.Node_GoodsInfo,1,self.sTime,self.label,function_name,"贩卖")
	end
	if self.isShowTime == true then
		showRTime()--如果有限时才调用 
	elseif sellType and sellType == 0 then
		self.Text_state:setString(UITool.ToLocalization("该物品无法出售"))
	elseif sellType and sellType == 1 then
		self.Text_state:setString(UITool.ToLocalization("单价:")..costOnly)
	end

	self.btn_outPut3:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			self.Node_outPut:setVisible(false)
			self.Node_sell:setVisible(true)
			self.Text_title:setString(UITool.ToLocalization("物品贩卖"))
			if self.isShowTime == true then
				self.label:setVisible(false)
				self.Text_state:setString(UITool.ToLocalization("单价:")..costOnly)
			end
		end
	end)
	self.Button_cancle:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			self.Node_outPut:setVisible(true)
			self.Node_sell:setVisible(false)
			self.Text_title:setString(UITool.ToLocalization("物品详细"))
			if self.isShowTime == true then
				self.label:setVisible(true)
				self.Text_state:setString("")
			end
		end
	end)

	self.Image_gembg:setUnifySizeEnabled(true)
	self.Image_gembg:loadTexture(SHOP_BUY_TYPE[cost_type])
	self.Text_cost:setString(cost_num)
	self.Text_Buy_num:setString(1)
	self.Text_cost_title:setString(UITool.ToLocalization("获得"))

	local dataTable = {
      ["btnLeft"]    = self.Button_del,
      ["btnRight"]   = self.Button_add,
      ["maxMatNum"]  = max_buy_num,
      ["lbCurNum"]   = self.Text_Buy_num,
      ["cost_text"]  = self.Text_cost,
      ["cost_num"]   = cost_num,
      ["curMatNum"]  = 1,
      ["longclickT"] = 1,
  	}
	local LongClick = Longclick_num.new():init(dataTable)
	local buyItemCallBack = function()
		print("点击购买按钮回调")
		callfunc(tonumber(LongClick:getCurMatNum()),refreshTopbar,oneSelf)
		-- if refreshTopbar then
		-- 	refreshTopbar()
		-- end
	end
	self.callFunc = nil
	self.callFunc = buyItemCallBack
end

function MsgBoxLayer:setBuy(item_id,item_type)
	local item_data = UITool.getItemInfos(item_type,item_id)
	local itemNum = table.getValue("self._data",self._data,"tab_data","itemNum")
	local cost_type = table.getValue("self._data",self._data,"tab_data","cost_type")
	local oneSelf = table.getValue("self._data",self._data,"tab_data","self")
	local cost_num = table.getValue("self._data",self._data,"tab_data","cost_num")
	local callfunc = table.getValue("self._data",self._data,"tab_data","callFunc")
	local max_buy_num = table.getValue("self._data",self._data,"tab_data","max_buy_num")
	local add_del_show = table.getValue("self._data",self._data,"tab_data","add_del_show")

	--物品描述
	self.Text_title:setString(UITool.ToLocalization("物品信息"))

	self.Image_buy_bg:loadTexture(SHOP_BUY_TYPE[cost_type])
	self.Text_Buy_cost:setString(cost_num)
	self.Text_buy_count:setString(1)
	if add_del_show == false or max_buy_num < 2 then
		self.Button_buy_del:setVisible(false)
		self.Button_buy_add:setVisible(false)
	end
	local dataTable = {
      ["btnLeft"]    = self.Button_buy_del,
      ["btnRight"]   = self.Button_buy_add,
      ["maxMatNum"]  = max_buy_num,
      ["lbCurNum"]   = self.Text_buy_count,
      ["cost_text"]  = self.Text_Buy_cost,
      ["cost_num"]   = cost_num,
      ["curMatNum"]  = 1,
      ["longclickT"] = 1,
  	}
	local LongClick = Longclick_num.new():init(dataTable)
	local buyItemCallBack = function()
		print("点击购买按钮回调")
		callfunc(tonumber(LongClick:getCurMatNum()),oneSelf)
	end
	self.callFunc = nil
	self.callFunc = buyItemCallBack
end

function MsgBoxLayer:setOutPut(item_id,item_type)
	local item_data = UITool.getItemInfos(item_type,item_id)
	local oneSelf = table.getValue("self._data",self._data,"tab_data","self")
	local sTime = table.getValue("self._data",self._data,"tab_data","sTime")
	local callfunc = table.getValue("self._data",self._data,"tab_data","callFunc")
	local refreshTopbar = table.getValue("self._data",self._data,"tab_data","refreshTopbar")
	local can_make = table.getValue("self._data",self._data,"tab_data","can_make")

	self:initOutPut(item_id,item_type,oneSelf,callfunc)
	self.Text_title:setString(UITool.ToLocalization("物品详细"))

	self.Text_outPut3:setString(UITool.ToLocalization("使用"))
	if item_type == 7 or item_type == 21 then
		self.Text_outPut3:setString(UITool.ToLocalization("使用"))
	elseif item_type == 8 then
		self.Text_outPut3:setString(UITool.ToLocalization("合成"))
		self.btn_outPut3:setTouchEnabled(can_make == 1)
		self.btn_outPut3:setBright(can_make == 1)
	end
	self.btn_outPut3:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			print("点击按钮,回调函数")
			if item_type == 6 then--6可使用道具
				local function fCall()
					callfunc(oneSelf)
				end
				local sData = {}
				if item_id == 1 then
					sData["item_type"] = 1
					SceneManager:ReqUseAp(sData,fCall,refreshTopbar)
				elseif item_id == 2 then
					sData["item_type"] = 2
					SceneManager:ReqUseAp(sData,fCall,refreshTopbar)
				elseif item_id == 3 then
					if tonumber(user_info["rank"]) >= 0 then
						SceneManager:toDrawCardLayer(sData)
					else
						---todo锁住 
		                local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),0)
		                SceneManager:showPromptLabel(str)
					end
				elseif item_id == 4 then
					if tonumber(user_info["rank"]) >= UnlockKRelicsRank then
						SceneManager:toDDBattleMainLayer(sData)
					else
						---todo锁住 
		                local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),UnlockKRelicsRank)
		                SceneManager:showPromptLabel(str)
					end
				elseif item_id == 5 then
					SceneManager:showPlayerCard(oneSelf,fCall)
				end
				self:removeFromParentView()
			elseif item_type == 8 then
				local function fCall()
					callfunc(oneSelf)
				end
				print("合成碎片")
				GameManagerInst:confirm(string.format(UITool.ToLocalization("是否消耗%d个碎片合成%s"),piece[item_id]["combine_need"],UITool.getUserLanguage(hero[piece[item_id]["combine_id"]]["hero_name"])),function()
					self:Synthesis(item_id,fCall)
				end)
				--self:Synthesis(item_id,fCall)
			elseif item_type == 7 then
				local function fCall()
					callfunc(oneSelf)
				end
				print("打开普通礼包")
				self:GiftUse(item_id,fCall)
			elseif item_type == 21 then
				local function fCall()
					callfunc(oneSelf)
				end
				print("打开自选礼包")
				local _data = {
					["item_id"] = item_id,
					["item_type"] = item_type,
					["fCall"] = fCall,
				}
				self:SelectGiftUI(_data)
				self:removeFromParentView()
			end
			-- self:removeFromParentView()
		end
	end)
end

-- 倒计时
--/*倒计时   1执行动作的node 2 间隔时间   3 倒计时总时间   4 时间需设置Text文本*/  5 callf 回调函数
function MsgBoxLayer:schedule(node, delay,Countdown ,str,callf,text)
    local  funcCountdown = Countdown
   local function TimeFunc( )
   		if funcCountdown > 0 then
   			funcCountdown = funcCountdown - 1
   		
	        if funcCountdown == 0 then
	          if callf then
	            callf()
	            return
	          end
	        end
	        local time = string.format("%d",funcCountdown)
	        print("remainTimes = ",time)
	        str:setString(self:getTimeStr(funcCountdown))
	    end
    end

    local delay    = CCDelayTime:create(delay)
    local callfunc = CCCallFunc:create(TimeFunc)
    local sequence = cc.Sequence:create(delay, callfunc)
    local action   = CCRepeatForever:create(sequence)
    node:runAction(action)
    return action
end

function MsgBoxLayer:getTimeStr(time)
	local day = 0
	local hour = 0
	local min  = 0
	local sec = 0
	local allSec = time
	local daySec = 86400
	local hourSec = 3600
	local minSec = 60
	if allSec >= daySec then
		day = allSec / daySec
		allSec = allSec % daySec
		if allSec >= hourSec then
			hour = allSec / hourSec
			allSec = allSec % hourSec
		end
		if allSec >= minSec then
			min = allSec / minSec
			allSec = allSec % minSec
		end
		if allSec >= 1 then
			sec = allSec
		end
		return string.format("%d:%d:%d:%d",day,hour,min,sec)
	else
		if allSec >= hourSec then
			hour = allSec / hourSec
			allSec = allSec % hourSec
		end
		if allSec >= minSec then
			min = allSec / minSec
			allSec = allSec % minSec
		end
		if allSec >= 1 then
			sec = allSec
		end
		print("hout = ",hour)
		return string.format("%d:%d:%d",hour,min,sec)
	end
end

function MsgBoxLayer:initBtn()
	local function CallBak( sender,eventType )
       if eventType == ccui.TouchEventType.ended then
       print("点击按钮,回调函数")
            if sender:getTag() == 10605 then
                self:callCanfirm()
            elseif sender:getTag() == 296 then
                self:removeFromParentView()
            elseif sender:getTag() == 10704 then
                self:callCanfirm()
            elseif sender:getTag() == 10801 then
            	self:callCanfirm()
            end
       end
    end
    self.Button_confirm:addTouchEventListener(CallBak)
    self.Button_close:addTouchEventListener(CallBak)
    self.Button_buy_ok:addTouchEventListener(CallBak)
    self.Button_use:addTouchEventListener(CallBak)
end

function MsgBoxLayer:returnBack( ... )
	KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
	if self._data and self._data["tab_data"]["cancelFunc"] then
		self._data["tab_data"]["cancelFunc"](table.getValue("self._data",self._data,"tab_data","self"))
	end
	if self then
		self:removeFromParentView()
	end
end

function MsgBoxLayer:callCanfirm( ... )
    if self.callFunc then
        print("进入回调")
        self.callFunc(table.getValue("self._data",self._data,"tab_data","self"))
    end
    self:returnBack()
end

--合成
function MsgBoxLayer:Synthesis(_item_id,f_call)
	local tempTable = {
                ["rpc"]       = "item_piece_use",
                ["item_id"]   = "piece_".._item_id,
            }
    GameManagerInst:rpc(tempTable,3,
        function(data)
            if data == nil then
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.sDelegate)
                return
            end
            if data["state_code"] == 1 then
            	dump(data,"data === ")
            	self:ShowItemInfo(data["get"],data["new_heroes"])
            	if f_call then
            		f_call()
            	end
				self:removeFromParentView()
            end
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true)
end

--显示碎片合成时的人物动画
function MsgBoxLayer:showHeroEffects(_data)
	print("展示合成人物特效动画")
    self.getdata = {} 
    for i,v in ipairs(_data) do
        local test = {}
        local id = v["id"]
        print("id ==== ",id)
        test["id"] = tonumber(id)
        test["story"] = v["story"]
        test["rarity"] = hero[tonumber(id)].hero_rank
        table.insert(self.getdata,test)
    end
    dump(self.getdata,"getdata:")
    if GameManagerInst.gameType == 2 then

        local function resumeBGMusic(  )
            print("resumeBGMusic-----")
            AudioManager:shareDataManager():resumeAll()
            --AudioManager:shareDataManager():stopAll()--抽卡音效超过上限，导致无法播放新音效
            local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
            --todo 停止或者恢复当前音乐
            if musicState == 0 then --开启音乐
                
                if AudioManager:shareDataManager():getBGId() ~= -1 then 
                    AudioManager:shareDataManager():resumeBGMusic()
                else 
                    local fullpath = lua_musci["zhuyeBGM"]
                    AudioManager:shareDataManager():preloadM(fullpath)
                    AudioManager:shareDataManager():playBGMusic(fullpath, true)
                end
            end 

        end
        SceneManager.menuLayer:RefshTopBar()
        SceneManager:toGetNewHeroView({   itemList = self.getdata,
                                            finalFunc = function()
                                                resumeBGMusic()
                                                NoticeManager:startNotice()
                                                cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                                                --self:loadData()
                                            end
                                            })
    end
end


--展示获得的物品
function MsgBoxLayer:ShowItemInfo(itemGainData,_heroData)
    local function fCall()
    	if _heroData and #_heroData > 0 then
    		self:showHeroEffects(_heroData)
    	end
    end
    local tableLen = #itemGainData
    local sData = {}
    if tableLen <= 1 then
        itemType = table.getValue("itemGainData", itemGainData, 1, "item_type")
        Itemid   = table.getValue("itemGainData", itemGainData, 1, "id")
        Itemnum  = table.getValue("itemGainData", itemGainData, 1, "num")
        local oneMailData  ={}
        local oneMailItemData = {}
        oneMailItemData["id"]        = Itemid
        oneMailItemData["item_type"] = itemType
        oneMailItemData["num"]       = Itemnum
        
        table.insert(oneMailData,oneMailItemData)

        
        sData["AllData"] = oneMailData
    else
        sData["AllData"] = itemGainData
    end

    sData["fCall"] = fCall
    SceneManager:toMailGetAllLayer(sData)
    
end

function MsgBoxLayer:GiftUse(_item_id,f_call)
	local tempTable = {
                ["rpc"]       = "item_gift_use",
                ["item_id"]   = "gift_".._item_id,
            }
    GameManagerInst:rpc(tempTable,3,
        function(data)
            if data == nil then
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.sDelegate)
                return
            end
            if data["state_code"] == 1 then
            	self:ShowItemInfo(data["get"])
            	if f_call then
            		f_call()
            	end
				self:removeFromParentView()
            end
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true)
end

function MsgBoxLayer:SelectGiftUI(_data)
	SceneManager:toShowMsgBoxGift(_data)
end




