--手动拖动某个角色到某个地块，或位置修正。状态正常结束时切换到RunningToEnemy状态。
--created by kobejaw.2018.3.29.
State_RunningToPosition = class("State_RunningToPosition",StateBase)

function State_RunningToPosition:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.RunningToPosition
	self.needUpdate = false;
end

--data.type  1.手指拖动。过程中要检测是否与敌人碰撞。2.位置修正。过程中不检测碰撞。
--data.isEnter 开场的跑动动画
--data.w
--data.h
function State_RunningToPosition:Enter(data)
	if self.entity.isDead then
		return
	end	

	if G_GameState == 5 then
		self.entity.fsm:changeState(StateEnum.Idling)
		return
	end

	self.data = data;
	self.entity:playRunAnimation();

	self.destinationBoxIdx = nil;
	self.frames = nil;
	self.deltaXPerFrame = nil;
	self.deltaYPerFrame = nil;
	self.needUpdate = false;
	self.isWaiting = false; --手指拖动时，到达目的地后，停顿一会。
	self.haltFrames = nil;  --到达目的地后停顿的帧数

	if self.data.type == 1 and self.entity.entityType == 1 and not self.data.isEnter then
		BattleCameraManager:setTouchMode(self.entity,data.w*50+25,self.entity:getPositionX())
		self.haltFrames = -70
	else
		self.haltFrames = -10
	end

	self:setDestination();
end


function State_RunningToPosition:setDestination()
	--设置移动的角度和速度
	self.destinationBoxIdx = self.data.w * 3 + self.data.h

	local destPoint = GetPointByBoxIdx(self.destinationBoxIdx)
	local deltaX = destPoint.x - self.entity:getPositionX()
	local deltaY = destPoint.y - self.entity:getPositionY()
	local distance = math.sqrt(deltaX * deltaX + deltaY * deltaY)

	local pixelsPerFrame = self.entity.data.speed/100
	self.frames = math.ceil(distance/pixelsPerFrame)

	self.deltaXPerFrame = deltaX/self.frames 
	self.deltaYPerFrame = deltaY/self.frames

	--设置朝向
	if self.entity.entityType == BattleGlobals.EntityType.Role then
		if deltaX < 0 then
			self.entity.spineNode:setRotationSkewY(180)
			self.entity.faceTo = BattleGlobals.FaceLeft
		else
			self.entity.spineNode:setRotationSkewY(0)
			self.entity.faceTo = BattleGlobals.FaceRight
		end		
	else
		if deltaX > 0 then
			self.entity.spineNode:setRotationSkewY(180)
			self.entity.faceTo = BattleGlobals.FaceRight
		else
			self.entity.spineNode:setRotationSkewY(0)
			self.entity.faceTo = BattleGlobals.FaceLeft
		end			
	end
	self.needUpdate = true
end

function State_RunningToPosition:Exit()

	self.super.Exit(self)

	if self.entity.entityType ~= 1 or self.data.type ~= 1 or self.data.isEnter then
		return
	end

	--如果只剩自己处在RunningToPosition状态了，退出镜头跟随的touchMode
	local isNeedQuitCameraTouchMode = true

	for k,v in pairs(G_Roles) do
		if not v.isDead and v ~= self.entity then
			if v.fsm.currentState.stateEnum == StateEnum.RunningToPosition and v.fsm.currentState.data.type == 1 then
				isNeedQuitCameraTouchMode = false
			end
		end
	end

	if isNeedQuitCameraTouchMode then
		BattleCameraManager:quitTouchMode()
	end
end

function State_RunningToPosition:update()
	if self.frames == nil then
		print("不可能执行到这里_State_RunningToPosition:update()")
		return
	end

	--更新所属地块
	self.entity.box_w,self.entity.box_h = GetBoxWHByPoint(self.entity:getPositionX(),self.entity:getPositionY())
	self.frames = self.frames - 1

	--跑动中
	if self.frames >= 0 then
		self.nextPosX = self.entity:getPositionX() + self.deltaXPerFrame
		self.nextPosY = self.entity:getPositionY() + self.deltaYPerFrame

		if self.data.type == 2 then
			self.entity:setPosition(self.nextPosX,self.nextPosY)
		else
			--检测下一帧是否换了格子，新格子里是否有敌人。
			self.nextW,self.nextH = GetBoxWHByPoint(self.nextPosX,self.nextPosY)
			if (self.nextW ~= self.entity.box_w or self.nextH ~= self.entity.box_h) then
				--检测下一个格子中是否有敌人。如果有，在当前格子停下来并修正位置。
				if self.entity:checkBoxOccupiedByEnemyWithWH(self.nextW,self.nextH) then
					--修正位置
					self:correctPosWithRunning()
					return
				else
					self.entity:setPosition(self.nextPosX,self.nextPosY)
				end
			else
				self.entity:setPosition(self.nextPosX,self.nextPosY)
			end
		end
	else
		if self.data.isEnter then
			self.entity.fsm:changeState(StateEnum.Idling)
			return
		end

		G_EntityLayer:resetZOrder()

		if not self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h) then
			--修正位置
			self:correctPosWithRunning()
		else
			if not self.isWaiting then
				self.entity:playIdleAnimation()
				if self.entity.entityType == 1 and self.entity:checkEnemyNumInRange() ~= 0 then
					self.haltFrames = -10
				end
				self.isWaiting = true
			elseif self.frames <= self.haltFrames then
				self.entity:playRunAnimation()
				local data = {}
				data.type = 1
				self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
			end				
		end
	end
end
