--require "XUIView"
--require "XUIGridView"
--require "EquipListItemView"
--require "REIconView"

EquipSthView = class("EquipSthView",XUIView)
EquipSthView.CS_FILE_NAME = "EquipSthView.csb"
EquipSthView.CS_BIND_TABLE = 
{
    panelEffect = "/i:632",
    effIcon = "/i:632/s:effIcon",

    panelSort = "/i:87/s:panelSort",
    panelList = "/i:87/i:111",
    panelMatL = "/i:87/i:110",
    panelMatM = "/i:87/i:109",
    panelLevel = "/i:87/i:107",
    panelIcon = "/i:87/i:213",
    lbCurAtk = "/i:87/i:173/i:176",
    lbAddAtk = "/i:87/i:173/i:177",
    lbCurHP = "/i:87/i:173/i:180",
    lbAddHP = "/i:87/i:173/i:181",
    btnStartSth = "/i:87/i:282",
    btnHelp = "/i:87/s:btnHelp",
    ImgBtnEq = "i:87/i:503",
    ImgBtnNoEq = "i:87/i:501",
}

function EquipSthView.createWithBackBtn(nSelectTitleNum)
    local v = EquipSthView.new():init()
    --local b = BackgroundView.new():initWithBackBtn(v,"n_UIShare/Global_UI/bg/bg_003_1.png")
    local b = BackgroundView.new():initWithCloseBtn(v)
    v.nSelectTitleNum = nSelectTitleNum
    return b,v
end

function EquipSthView:init()
    EquipSthView.super.init(self)

    self.exist = true

    self.panelEffect:setVisible(false)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = EquipListItemView.new():init()

        temp.ClickEvent = function(item)
            local i = item:getIndex()
            self:setSelectedEquip(i)
        end
        
        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = 0
            if g_channel_control.b_newEqBag then
                smode = math.floor(self.sortBtnView:getSortMode() / 10)
            else
                smode = self.sortBtnView:getSortMode() % 10
            end
            item:setTitleMode(smode)

            item:setSelected(item:getIndex() == self.currentIndex )
        end
        return temp
    end

    self.btnStartSth:addClickEventListener(function()
        self:onEquipSth()
    end)

    self.iconView = REIconView.new():init(self.panelIcon)

    self.matViewL = SthMatNumView.new():init(self.panelMatL)
    self.matViewL:setMatInfo(ID_E_L,0)
    self.matViewL.CurNumChangedEvent = function()
        self:computExp()
        self.matViewM:refresh()
    end
    self.matViewL.iconClickEvent = function()
        local nid = getMatID(ID_E_L)
        if GameManagerInst.gameType == 2 then
            MsgManager:showSimpItemInfoAndDropInfo(5,nid,true,self.onMatChanged,self)
        end
    end

    self.matViewM = SthMatNumView.new():init(self.panelMatM)
    self.matViewM:setMatInfo(ID_E_M,0)
    self.matViewM.CurNumChangedEvent = function()
        self:computExp()
        self.matViewL:refresh()
    end
    self.matViewM.iconClickEvent = function()
        local nid = getMatID(ID_E_M)
        if GameManagerInst.gameType == 2 then
            MsgManager:showSimpItemInfoAndDropInfo(5,nid,true,self.onMatChanged,self)
        end
    end

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)

    --排序
    if g_channel_control.b_newEqBag then
        self.sortBtnView = EqSortButtonView.new():init(self.panelSort,"EqP_q",41,"EqS_Rank_q",0,"EqS_Ele_q",0,"EqS_Brk_q",0)
    else
        self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_q",512,1)
    end
    if g_channel_control.b_newEqBag then
        self.sortBtnView.sortModeChangedEvent = function()
            self:ReLoadData()
        end
    else
        self.sortBtnView.sortModeChangedEvent = function()
            self:refresh()
        end
    end
    --

    self.lvupView = SthLevelUpView.new():init(self.panelLevel)

    self:setSelectedEquip()

    if g_channel_control.b_newEqBag then
        self.nSelectTitleNum = self.nDefaultSelect or 1 --1:已装。0:未装

        self.bEnableEqTitle = true   --已装灵装按钮是否有效
        self.bEnableNoEqTitle = true --未装灵装按钮是否有效

        self.ImgBtnEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableEqTitle then
                    self:onSelectTitle(1)
                end
            end
        end)
        self.ImgBtnEq:setSwallowTouches(true)

        self.ImgBtnNoEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableNoEqTitle then
                    self:onSelectTitle(0)
                end
            end
        end)
        self.ImgBtnNoEq:setSwallowTouches(true)
        
        --self:onCallEqListByTitle(self.nSelectTitleNum)
        --
        if g_channel_control.b_XbWorkShopView then
            self.ImgBtnEq:setVisible(false)
            self.ImgBtnNoEq:setVisible(false)
        else
            self.ImgBtnEq:setVisible(true)
            self.ImgBtnNoEq:setVisible(true)
        end
        --
    else
        self.ImgBtnEq:setVisible(false)
        self.ImgBtnEq:setSwallowTouches(false)
        self.ImgBtnNoEq:setVisible(false)
        self.ImgBtnNoEq:setSwallowTouches(false)
    end

    return self
end

function EquipSthView:onSelectTitle(nSelectNum)
    if self.exist ==  false then 
        return
    end
    if self.nSelectTitleNum ~= nSelectNum then
        self.nSelectTitleNum = nSelectNum
        self:onCallEqListByTitle(self.nSelectTitleNum)
    end
end

function EquipSthView:onCallEqListByTitle(nSelectNum)
    if self.exist ==  false then 
        return
    end
    --与后端交互获取新的装备列表
    self:ReLoadData()
    self.currentIndex = nil
    --
    --self:refreshTitleBtnState()
end

function EquipSthView:refreshTitleBtnState()
    if self.exist ==  false then 
        return
    end
    if self.nSelectTitleNum == 1 then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[2])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[1])
    else
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[1])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[2])
    end

    if not self.bEnableEqTitle then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
    if not self.bEnableNoEqTitle then
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
end

--强化
function EquipSthView:showGuidePicLayer( ... )
    if self.exist ==  false then 
        return
    end
    local data = {}
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_lzqh_001.png",
    }
    SceneManager:toGuidePictureLayer(data)
end


function EquipSthView:onMatChanged()
    if self.exist ==  false then 
        return
    end
    if self.matChangedEvent then
        self.matChangedEvent(self)
    end
end

function EquipSthView:computExp()
    if self.exist ==  false then 
        return
    end
    if self.currentIndex then
        local midm = getMatID(ID_E_M)
        local midl = getMatID(ID_E_L)
        local expm = mat[midm].mat_data
        local expl = mat[midl].mat_data
        
        local n = self.matViewM:getCurMatNum()
        local n2 = self.matViewL:getCurMatNum()

        self.lvupView:setAddExp(n * expm + n2 * expl)
        local flv,ismax = self.lvupView:getFinalLevel()
        --刷新属性区域
        self:refreshPropNum(flv)

        self.matViewL:setIsMaxLevel(ismax)
        self.matViewM:setIsMaxLevel(ismax)
    end
end

function EquipSthView:setSelectedEquip(i)
    if self.exist ==  false then 
        return
    end
    if  i then    
        self.currentIndex = i
        self.gridview:refresh()

        local data = self.currentDataSource[self.currentIndex]
        local e_id_num = getNumID( data["id"] )
        --local e_id_str = getStrID( data["id"] )

        --------------------------------showicon      data["rarity"]   data["element"]
        self.iconView:showEquip(e_id_num)
        
        --加载经验值
        local expTable = {}
        for i = 1,#equip_upgrade[e_id_num] do
            expTable[i] = equip_upgrade[e_id_num][i][1]
        end
        
        self.lvupView:setLevelInfo(expTable,data["Lv"],data["Lv_max"],data["exp"])
        local flv,ismax = self.lvupView:getFinalLevel()

        self.matViewL:setIsMaxLevel(ismax)
        self.matViewM:setIsMaxLevel(ismax)

        self.matViewL:setCurMatNum(0)
        self.matViewM:setCurMatNum(0)

        self:refreshPropNum(flv)

        self.btnStartSth:setTouchEnabled(not ismax)
        self.btnStartSth:setBright(not ismax)

    else
        self.currentIndex = nil
        
        self.iconView:showNoIcon()

        self.matViewL:setIsMaxLevel(true)
        self.matViewM:setIsMaxLevel(true)

        self.matViewL:setCurMatNum(0)
        self.matViewM:setCurMatNum(0)

        self.lvupView:setLevelInfo(nil,0,0,0)
        self:refreshPropNum()
        
        self.btnStartSth:setTouchEnabled(false)
        self.btnStartSth:setBright(false)
    end
end

function EquipSthView:refreshPropNum(flv)
    if self.exist ==  false then 
        return
    end
    if self.currentIndex then
        local data = self.currentDataSource[self.currentIndex]
        local e_id_num = getNumID( data["id"] )
        local e_id_str = getStrID( data["id"] )

        local curAtk = data["atk"]
        local curHP = data["hp"]

        local curLv = data["Lv"]

        local addAtk = equip_upgrade[e_id_num][flv][3] - curAtk
        local addHP = equip_upgrade[e_id_num][flv][2] - curHP

        self.lbCurAtk:setString(""..curAtk)
        if addAtk > 0 then
            self.lbCurAtk:setTextColor(cc.c3b(255,255,255))
            self.lbAddAtk:setString("+"..addAtk)
        else
            self.lbCurAtk:setTextColor(cc.c3b(171,171,171))
            self.lbAddAtk:setString("")
        end
        
        self.lbCurHP:setString(""..curHP)
        if addHP > 0 then
            self.lbCurHP:setTextColor(cc.c3b(255,255,255))
            self.lbAddHP:setString("+"..addHP)
        else
            self.lbCurHP:setTextColor(cc.c3b(171,171,171))
            self.lbAddHP:setString("")
        end

    else
        self.lbCurAtk:setString("")
        self.lbAddAtk:setString("")
        self.lbCurHP:setString("")
        self.lbAddHP:setString("")
    end
end

function EquipSthView:playEffect()
    if self.exist ==  false then 
        return
    end
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)

    local node_1 = cc.CSLoader:createNode("EffSthFrame.csb")
    local timeline_1 =cc.CSLoader:createTimeline("EffSthFrame.csb")
    local psize = self.effIcon:getSize()
    node_1:setPosition(cc.p(psize.width/2,0))
    node_1:runAction(timeline_1)
    self.effIcon:addChild(node_1,0,123)

    self.lvupView.levelUpEffectEvent = function()
        timeline_1:play("animation0",false) 
    end
    self.lvupView.effectEndEvent = function()
        self:stopEffect()
    end
    self.lvupView:playEffect()

    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
end

function EquipSthView:stopEffect()
    if self.exist ==  false then 
        return
    end
    KeyboardManager._isShowEffect = false
    self.lvupView.levelUpEffectEvent = nil
    self.lvupView.effectEndEvent = nil
    self.lvupView:stopEffect()

    self.effIcon:removeAllChildren()

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    if g_channel_control.b_newEqBag then
        self:ReLoadData()
    else
        self:refresh()
    end
end


function EquipSthView:onEquipSth()
    if self.exist ==  false then 
        return
    end
    if  not self.currentIndex then return end

    local matnum1 = self.matViewL:getCurMatNum()
    local matnum2 = self.matViewM:getCurMatNum()

    if matnum1 + matnum2 == 0 then
        GameManagerInst:alert(UITool.ToLocalization("请选择强化素材"))
        return
    end

    
    local dd = self.currentDataSource[self.currentIndex]
    local eid = dd.id
    
    local tempTable = {
        ["rpc"] = "eq_lv_up",
        ["target_id"] = eid,
        ["eat_mats"] = {},
    }


    if matnum1 > 0 then 
      table.insert(tempTable["eat_mats"],{mat_id = ID_E_L, mat_nums = matnum1})
    end
    
    if matnum2 > 0 then 
      table.insert(tempTable["eat_mats"],{mat_id = ID_E_M, mat_nums = matnum2})
    end


    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        DataManager:wEquipData(data["upgrade"])
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end
        --第一次强化之后，更改下本地的配置
        if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.StEquip)~=1 then 
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.StEquip,1)
        end
        self:playEffect()
        
        if self.infoChangedEvent then
            self.infoChangedEvent(self)
        end
        
    end,
    function(state_code,msgText)
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
    
end

function EquipSthView:lockSthTargetID(id,nEquiped)
    if self.exist ==  false then 
        return
    end
    if g_channel_control.b_newEqBag then
        self.lockedEid = id
        self.nCurLockTargetEquiped = nEquiped
        --self:ReLoadDataInLocked(id,nEquiped)
    else
        self.lockedEid = id
    end
end

function EquipSthView:ReLoadData()
    if self.exist ==  false then 
        return
    end
    if self.lockedEid and self.nCurLockTargetEquiped then
        self:ReLoadDataInLocked(self.lockedEid,self.nCurLockTargetEquiped)
        return
    end
    local rankVaules = table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = self.nSelectTitleNum,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()       
        --DataManager:wAllBagData({mat = data["mat"]})
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end

        --self.equipListView:setDataSource(equip_list)
        
        self.dataLoaded = true
        self:refresh()
        self:refreshTitleBtnState()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
            --self:returnBack()
        end)
    end,
    true)
end

function EquipSthView:ReLoadDataInLocked(target_id,nInEquiped)
    if self.exist ==  false then 
        return
    end
    local rankVaules = {3,4,5}
    local eleVaules = {1,2,3,4,5,0}
    local brkVaules = {1,2,3,4,0}
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    self.nSelectTitleNum = nInEquiped
    --self.nCurLockTargetEquiped = nInEquiped
    if self.nSelectTitleNum == 0 then
        self.bEnableEqTitle = false
        self.bEnableNoEqTitle = true
    else
        self.bEnableEqTitle = true
        self.bEnableNoEqTitle = false
    end

    self:refreshTitleBtnState()
    self.sortBtnView:setDisableSortBtn(true)

    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = self.nSelectTitleNum,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()

        self.currentIndex = nil
        self:refresh()
        self:refreshTitleBtnState()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
            --self:returnBack()
        end)
    end,
    true)
end

function EquipSthView:getDataSrouce()
    if self.exist ==  false then 
        return
    end
    local ds = {}
    
    if self.lockedEid then
        --固定强化目标
        for i=1,#equip_list do
            if equip_list[i].id == self.lockedEid then
                ds = {
                    table.deepcopy(equip_list[i])
                }
                break
            end
        end
    else
        ds = table.deepcopy(equip_list)
        -- for i = 1,#equip_list do
        --     if equip_list[i]["owner"] == "0" then
        --         table.insert(ds,table.deepcopy(equip_list[i]))
        --     end
        -- end
    end
    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end

    return ds
end

function EquipSthView:selectItemById(eid)
    if self.exist ==  false then 
        return
    end
    if self.currentDataSource then
        for i = 1,#self.currentDataSource do
            if self.currentDataSource[i].id == eid then
                self:setSelectedEquip(i)
                return
            end
        end
    end

    self:setSelectedEquip(nil)
end

function EquipSthView:refresh()
    if self.exist ==  false then 
        return
    end
    local tempid = nil
    if self.currentIndex then
        tempid = self.currentDataSource[self.currentIndex].id
    end

    --先排序，后刷列表  
    self.currentDataSource = self:getDataSrouce()
    self.gridview:setDataSource(self.currentDataSource)

    if self.lockedEid then
        self:selectItemById(self.lockedEid)
    elseif tempid then
        self:selectItemById(tempid)
    else
        self:setSelectedEquip(nil)
    end

    local nl = user_info["bag"]["mat"][ID_E_L]
    local nm = user_info["bag"]["mat"][ID_E_M]

    if nl == nil then nl = 0 end
    if nm == nil then nm = 0 end

    self.matViewL:setMatInfo(ID_E_L,nl)
    self.matViewM:setMatInfo(ID_E_M,nm)
    
end

function EquipSthView:DestroyHandle()
    self.exist = false
end