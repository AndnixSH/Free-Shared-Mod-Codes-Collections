coinbar = {}
coinbar[1] = {
    name = "主界面",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[2] = {
    name = "队伍编成",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[3] = {
    name = "角色一栏",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[4] = {
    name = "角色强化",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[5] = {
    name = "潜能解放",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[6] = {
    name = "状态",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[7] = {
    name = "技能",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[8] = {
    name = "灵装",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[9] = {
    name = "星盘",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[10] = {
    name = "魂灵",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[11] = {
    name = "灵装背包",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[12] = {
    name = "道具背包",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[13] = {
    name = "铸造兑换",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[14] = {
    name = "轮回重铸",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[15] = {
    name = "图鉴",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[16] = {
    name = "大型战斗",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[17] = {
    name = "求援列表",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[18] = {
    name = "创建战斗",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[19] = {
    name = "加入战斗",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[20] = {
    name = "公会信息",
    coin_list = { 3,2,0,0,0},
    coinbar_type = 2,
}
coinbar[21] = {
    name = "公会设施",
    coin_list = { 3,7,0,0,0},
    coinbar_type = 2,
}
coinbar[22] = {
    name = "公会商店",
    coin_list = { 3,2,4,0,0},
    coinbar_type = 2,
}
coinbar[23] = {
    name = "公会排行",
    coin_list = { 3,2,0,0,0},
    coinbar_type = 2,
}
coinbar[24] = {
    name = "苍蓝之塔",
    coin_list = { 3,1,0,0,0},
    coinbar_type = 2,
}
coinbar[25] = {
    name = "购买星石",
    coin_list = { 3,2,7,0,0},
    coinbar_type = 2,
}
coinbar[26] = {
    name = "道具屋",
    coin_list = { 3,2,7,0,0},
    coinbar_type = 2,
}
coinbar[27] = {
    name = "秘密商店",
    coin_list = { 3,2,7,0,0},
    coinbar_type = 2,
}
coinbar[28] = {
    name = "苍玉兑换",
    coin_list = { 3,2,7,0,0},
    coinbar_type = 2,
}
coinbar[29] = {
    name = "召唤",
    coin_list = { 3,8,7,0,0},
    coinbar_type = 2,
}
coinbar[30] = {
    name = "英雄圆桌",
    coin_list = { 3,8,7,0,0},
    coinbar_type = 2,
}
coinbar[31] = {
    name = "活动中心",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[32] = {
    name = "区域编队战力",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[33] = {
    name = "全服编队战力",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[34] = {
    name = "魔王歼灭排行",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[35] = {
    name = "黑潮遗迹排行",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[36] = {
    name = "区域总和战力",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[37] = {
    name = "全服总和战力",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[38] = {
    name = "签到",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[39] = {
    name = "每日任务",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[40] = {
    name = "本周任务",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[41] = {
    name = "伟大足迹",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[42] = {
    name = "好友邮件",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[43] = {
    name = "系统邮件",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[44] = {
    name = "消息中心",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[45] = {
    name = "游戏好友",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[46] = {
    name = "寻找好友",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[47] = {
    name = "公会成员",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[48] = {
    name = "出征",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[49] = {
    name = "剧情活动",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[50] = {
    name = "角色剧情",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[51] = {
    name = "剧情回顾",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[52] = {
    name = "星界轮回大战",
    coin_list = { 6,5,1,0,0},
    coinbar_type = 1,
}
coinbar[53] = {
    name = "试练",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 1,
}
coinbar[54] = {
    name = "星界探索",
    coin_list = { 3,2,0,0,0},
    coinbar_type = 0,
}
coinbar[55] = {
    name = "信息设置",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[57] = {
    name = "系统",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[58] = {
    name = "世界",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[59] = {
    name = "私聊",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[60] = {
    name = "战斗",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 0,
}
coinbar[61] = {
    name = "神格",
    coin_list = { 0,0,0,0,0},
    coinbar_type = 3,
}
coinbar[62] = {
    name = "公会设定",
    coin_list = { 3,2,4,0,0},
    coinbar_type = 2,
}
coinbar[63] = {
    name = "公会成员列表",
    coin_list = { 3,1,4,0,0},
    coinbar_type = 2,
}
coinbar[64] = {
    name = "留言板",
    coin_list = { 3,2,4,0,0},
    coinbar_type = 2,
}
coinbar[65] = {
    name = "公会推荐（创建）",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[66] = {
    name = "公会排行（创建）",
    coin_list = { 3,2,1,0,0},
    coinbar_type = 2,
}
coinbar[67] = {
    name = "活动商店",
    coin_list = { 3,26,27,0,0},
    coinbar_type = 2,
}
coinbar[68] = {
    name = "礼包商店",
    coin_list = { 3,2,0,0,0},
    coinbar_type = 2,
}