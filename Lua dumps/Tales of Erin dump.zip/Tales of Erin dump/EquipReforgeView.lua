--require "XUIView"

EquipReforgeView = class("EquipReforgeView",XUIView)
EquipReforgeView.CS_FILE_NAME = "EquipReforgeView.csb"
EquipReforgeView.CS_BIND_TABLE = 
{
    panelData = "/i:87",
    panelBg = "/i:20",
    panelNoDataL = "/i:30",
    panelNoDataR = "/i:40",
    spSelectPlease = "/i:30/i:4549",

    panelEffect = "/i:930",
    effMagic = "/i:930/s:effMagic",
    effIcon1 = "/i:930/s:effIcon1",
    effIcon2 = "/i:930/s:effIcon2",

    panelSort = "/s:panelSort",
    panelList = "/s:panelList",
    panelIconReforgeBy = "/i:87/i:213",
    panelIconReforgeTo = "/i:87/i:4316",

    btnForge = "/i:282",
    btnCompare = "/i:87/i:4150",

    MatNodePanel1 = "/i:87/i:4300",
    MatNodePanel2 = "/i:87/i:4311",

    panelProp = "/i:87/i:4018",
    panelProp_SkillIcon = "/i:87/i:4018/i:386",
    panelProp_Atk = "/i:87/i:4018/i:397",
    panelProp_Hp = "/i:87/i:4018/i:398",

    panelProp_Name = "/i:87/i:4018/i:439",
    panelProp_Lv = "/i:87/i:4018/i:438",

    skillDescPanel = "/i:87/i:4018/i:390",
    panelProp_randSkill1 = "/i:87/i:4018/i:391",
    panelProp_randSkill1Dec = "/i:87/i:4018/i:391/i:393",
    panelProp_randSkill2 = "/i:87/i:4018/i:394",
    panelProp_randSkill2Dec = "/i:87/i:4018/i:394/i:396",

    panel_CompareResult = "/i:840",
    panel_CompareResultIcon1 = "/i:840/i:845",
    panel_CompareResultIcon2 = "/i:840/i:846",
    panel_CompareResultBtnSure = "/i:840/i:876",

    panel_CRPanelProp_1 = "/i:840/i:847",
    panel_CRPanelProp_2 = "/i:840/i:862",

    lbMainEqLvBy = "/i:87/i:878",
    lbMainEqLvTo = "/i:87/i:880",
    lbCREqLvBy = "/i:840/i:881",
    lbCREqLvTo = "/i:840/i:882",
}

function EquipReforgeView.createWithBackBtn()
    local v = EquipReforgeView.new():init()
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function EquipReforgeView:init(rcvData)
    EquipReforgeView.super.init(self)

    self.sManager  = rcvData["sManager"]
    self.backFunc  = rcvData["rcvData"]["sFunc"]
    self.sDelegate = rcvData["rcvData"]["sDelegate"]

    self.panelEffect:setVisible(false)

    self.ShowReforgeCorR = 1

    -- 初始化按钮的状态
    local btnReforge  = self.panelBg:getChildByName("Image_Reforge")
    btnReforge:loadTexture("res/uifile/n_UIShare/equip/Reforge/xlzz_b_005_2.png")

    self:initBtn()

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = EquipListItemView.new():init()

        temp.ClickEvent = function(item)            
            self:equipClicked(item)
        end
        
        temp.resetDataEvent = function(item)
            --设置展示模式
            local smode = self.sortBtnView:getSortMode() % 10
            item:setTitleMode(smode)

            local data = item:getData()
            item:setSelected(item:getData().id == self.reforgeByEquipID)
        end
        return temp
    end

    self:loadData()
    
    --排序
    self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_t",814,1)
    self.sortBtnView.sortModeChangedEvent = function()
        self:refresh()
    end
    --

    self.btnForge:addClickEventListener(function()
        self:onEquipReforge()
    end)

    self.btnCompare:addClickEventListener(function()
        self:onDataCompare()
    end)

    self.panel_CompareResultBtnSure:addClickEventListener(function()
        self:showCompareResultView(false,0)
    end)

    self.iconView1 = REIconView.new():init(self.panelIconReforgeBy)
    self.iconView2 = REIconView.new():init(self.panelIconReforgeTo)

    self:showCompareResultView(false,0)

    self.CompareResultIconView1 = REIconView.new():init(self.panel_CompareResultIcon1)
    self.CompareResultIconView2 = REIconView.new():init(self.panel_CompareResultIcon2)

    

    self:refreshReforgeByInfo()

    self.MatNodePanel1:setTouchEnabled(true)
    self.MatNodePanel2:setTouchEnabled(true)

    return self
end

-- 初始化 按钮
function EquipReforgeView:initBtn( ... )

    local btnBag = self.panelBg:getChildByName("Image_bag")
    local btnForge = self.panelBg:getChildByName("Image_forge")
    local btnExchange = self.panelBg:getChildByName("Image_Exchange")
    local btnClose   = self.panelBg:getChildByName("Button_close")
    local function btnCallBack( sender,eventType)
        if eventType == ccui.TouchEventType.ended     then
            if sender:getName() == "Button_close" then
                self:returnBack()
            elseif sender:getName() == "Image_bag"  then
                self:callBag()
            elseif sender:getName() == "Image_forge"  then
                self:callForge()
            elseif sender:getName() == "Image_Exchange" then
                self:callExchange()
            end
        end
    end
    btnClose:addTouchEventListener(btnCallBack)
    btnClose:setEffectType(3)
    btnBag:addTouchEventListener(btnCallBack)
    btnForge:addTouchEventListener(btnCallBack)
    btnExchange:addTouchEventListener(btnCallBack)

    if g_channel_control.reforgeView_hideExchange == true then
        btnExchange:setVisible(false)
    end
end

-- 去往铸造
function EquipReforgeView:callForge( ... )
    -- body
    self:beforeReturnBack()
    local sData = {}
    sData["back"] = "Reforge"
    SceneManager:toECastingLayer(sData)--self.rData

end

-- 去往兑换
function EquipReforgeView:callExchange( ... )
    -- body
    self:beforeReturnBack()
    local sData = {}
    sData["back"] = "Reforge"
    SceneManager:toExchangeLayer(sData)--self.rData

end

-- 去往背包
function EquipReforgeView:callBag( ... )
    -- body
    self:beforeReturnBack()
    local sData = {}
    sData["back"] = "Reforge"
    SceneManager:toBagLayer(sData)--self.rData
end

function EquipReforgeView:beforeReturnBack()
    -- body
    self.exist = false
    SceneManager:removeFromNavNodes(self)
    self:clear()
end

function EquipReforgeView:returnBack()
    -- body
    self.exist = false
    self:beforeReturnBack()
    SceneManager:toStartLayer()
end

function EquipReforgeView:equipClicked(item)
    local data = item:getData()
    local e_id_num = getNumID( data["id"] )
    self.reforgeByEquipIDSend = data["id"]
    self.reforgeByEquipID = e_id_num
    self.luaData = {}
    --GameManagerInst:alert("click reforgeByEquipID:"..self.reforgeByEquipID)
    self.luaData = table.deepcopy(reforge[self.reforgeByEquipID])

    self.reforgeEquipData = {}
    for i=1,#self.canReforgeEqList do
        if self.canReforgeEqList[i].id == data["id"] then
            self.reforgeEquipData = table.deepcopy(self.canReforgeEqList[i])
        end
    end
    --GameManagerInst:saveToFile("reforgeEquipData.json",self.reforgeEquipData)
    self.reforgeToEquipID = self.luaData["eq_change"]
    --GameManagerInst:alert("click reforgeToEquipID:"..self.reforgeToEquipID)
    self.gridview:refresh()
    self:refreshReforgeByInfo()
end

function EquipReforgeView:showCompareResultView(bShow,nIndex)
    
    if self.panel_CompareResult then
        
        self.panel_CompareResult:setVisible(bShow)
        if bShow then
            self.ShowReforgeCorR = nIndex
            self:refreshCompareResultInfo()
            if nIndex == 1 then
                --属性对比
                self.panel_CompareResult:getChildByName("lbTitle"):setString(UITool.ToLocalization("属性对比(满级属性)"))
            elseif nIndex == 2 then
                --重铸结果
                self.panel_CompareResult:getChildByName("lbTitle"):setString(UITool.ToLocalization("轮回重铸结果"))
            else

            end
        end
    end
end

function EquipReforgeView:playEffect()
    self.panelEffect:setVisible(true)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
    
    local effs = {
        {self.effIcon1,"EffAwkFrame.csb"},
        {self.effIcon2,"EffAwkFrame.csb"},
        {self.effMagic,"EffAwkMagic.csb"}
    }

    for i = 1,#effs do
        local node_1 = cc.CSLoader:createNode(effs[i][2])
        local timeline_1 =cc.CSLoader:createTimeline(effs[i][2])
        node_1:setTag(123)
        local psize = effs[i][1]:getSize()
        node_1:setPosition(cc.p(psize.width/2,0))
        effs[i][1]:addChild(node_1)

        node_1:runAction(timeline_1)
        timeline_1:play("animation0",false) 
        timeline_1:setLastFrameCallFunc(function ()
            node_1:stopAllActions()
            node_1:removeFromParent()
        end)
    end
        
--    cc.SimpleAudioEngine:getInstance():playEffect("music/ui/tupo.mp3", false)          
     AudioManager:shareDataManager():playMusic("music/ui/tupo.mp3",0, false)
    local delay = cc.DelayTime:create(1.3)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:stopEffect()
    end))
    self.panelEffect:runAction(sequence)              
end

function EquipReforgeView:stopEffect()
    self.panelEffect:stopAllActions()

    local effs = {
        self.effIcon1,
        self.effIcon2,
        self.effMagic,
    }

    for i = 1,#effs do
        local e = effs[i]:getChildByTag(123)
        if e then e:stopAllActions() end
        effs[i]:removeAllChildren()
    end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    self:ResetReforgeUI()

end

--轮回重铸成功后，播放完动画效果后回调：重置界面数据
function EquipReforgeView:ResetReforgeUI( ... )
    self:showCompareResultView(true,2)--动画播放完展示轮回重铸结果界面
    self.reforgeByEquipID = nil
    self.reforgeToEquipID = nil
    self:loadData()--重新读取数据
    --self:refresh()
end


--刷新素材装备界面信息
function EquipReforgeView:refreshReforgeByInfo( ... )
    if self.bHasCanReforge then
        self:onHaveTargetList()
    else
        self:onNoTargetList()
    end

    if self.reforgeByEquipID then
        local eid = self.reforgeByEquipID
        self.iconView1:showEquip(eid)
        
        self:onHadSelectTarget()
    else
        self.iconView1:showNoIcon()
        self.reforgeToEquipID = nil
        self:onNoSelectTarget()
    end

    if self.reforgeToEquipID then
        local eid = self.reforgeToEquipID
        self.iconView2:showEquip(eid)
    else
        self.iconView2:showNoIcon()
    end

    self:refreshEqSkillInfo()
    self:refreshMatInfo()
    --self:refreshCompareResultInfo()
end

--刷新装备技能信息
function EquipReforgeView:refreshEqSkillInfo( ... )
    self.skillDescPanel:removeAllChildren()

    if self.reforgeToEquipID then
        local eq_num_id = self.reforgeToEquipID

        local data = nil
        if self.reforgeEquipData == nil then
            GameManagerInst:alert("self.reforgeEquipData == nil")
            return
        else
            data = self.reforgeEquipData --
        end

        --装备等级
        self.lbMainEqLvBy:setVisible(true)
        self.lbMainEqLvTo:setVisible(true)
        self.lbMainEqLvBy:setString(UITool.ToLocalization("等级")..data["Lv"].."/"..data["Lv_max"])
        self.lbMainEqLvTo:setString(UITool.ToLocalization("等级").."1".."/"..data["Lv_max"])
        

        self.panelProp_SkillIcon:setTexture(equip[eq_num_id]["equip_skill"]["skill_img"])
        self.panelProp_SkillIcon:setVisible(true)

        self.panelProp_Name:setString(UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_name"]))
        self.panelProp_Lv:setString(UITool.ToLocalization("等级 ")..1)
        
        self.panelProp_Atk:setString(equip_upgrade[eq_num_id][1][2])
        self.panelProp_Hp:setString(equip_upgrade[eq_num_id][1][3])

        --随机技能继承
        for i = 1,2 do
            local prsk = self["panelProp_randSkill"..i]
            if data["rsk"] ~= nil and data["rsk"][i] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[data["rsk"][i][1]])
                strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][i][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end

        --新装备技能
        local detail_size = self.skillDescPanel:getSize()

        local richText = ccui.RichText:create()
        richText:ignoreContentAdaptWithSize(false)
        richText:setContentSize(detail_size)
        richText:setPosition(detail_size.width / 2,detail_size.height / 2)

        self.skillDescPanel:addChild(richText)

        --技能描述-当前等级
        local str_des = UITool.getUserLanguage((self.luaData["eq_sk_1_desc"]))
        richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 20) )
    else

        self.lbMainEqLvBy:setVisible(false)
        self.lbMainEqLvTo:setVisible(false)

        self.panelProp_SkillIcon:setVisible(false)

        self.panelProp_Name:setString("")
        self.panelProp_Lv:setString(UITool.ToLocalization("等级 ")..1)

        self.panelProp_Atk:setString("")
        self.panelProp_Hp:setString("")

        --skill
        self.panelProp_randSkill1:setVisible(false)
        self.panelProp_randSkill2:setVisible(false)
    end
end

--刷新需要素材信息
function EquipReforgeView:refreshMatInfo( ... )
    if self.reforgeByEquipID then
        local data = nil
        if self.reforgeEquipData == nil then
            GameManagerInst:alert("self.reforgeEquipData == nil")
            return
        else
            data = self.reforgeEquipData 
        end
        dump(self.reforgeEquipData, "self.reforgeEquipData")
        --随机技能继承
        for i = 1,2 do
            local pMatPanel = self["MatNodePanel"..i]
            if data["curr_mat_list"] ~= nil and data["curr_mat_list"][i] ~= nil then

                local nMatId = self.luaData["need_mat"][i][1]
                local nMatType = self.luaData["need_mat"][i][3]

                pMatPanel:setVisible(true)
                local mat_had_num = data["curr_mat_list"][i]
                pMatPanel:getChildByName("lbHad"):setString(mat_had_num)
                pMatPanel:getChildByName("lbNeed"):setString(self.luaData["need_mat"][i][2])
                pMatPanel:getChildByName("MatIcon"):setTexture("icons/mat/"..mat[nMatId]["icon"])

                pMatPanel:addTouchEventListener(function(sender,eventType)
                    if eventType == ccui.TouchEventType.ended then
                        if GameManagerInst.gameType == 2 then
                            MsgManager:showSimpItemInfoAndDropInfo(nMatType,nMatId,true,self.loadData,self)
                        end
                    end
                end)
            else
                pMatPanel:setVisible(false)
            end
        end
    else
        self.MatNodePanel1:setVisible(false)
        self.MatNodePanel2:setVisible(false)
    end
end

--刷新对比结果信息
function EquipReforgeView:refreshCompareResultInfo( ... )
    if self.reforgeByEquipID and self.reforgeToEquipID then
        self:refreshCRSkillInfo()
    end
end

--刷新对比结果装备信息
function EquipReforgeView:refreshCRSkillInfo( ... )
    self.panel_CRPanelProp_1:getChildByName("Panel_3"):removeAllChildren()
    self.panel_CRPanelProp_2:getChildByName("Panel_3"):removeAllChildren()

    --重铸结果装备信息
    if self.reforgeToEquipID then
        local eq_num_id = self.reforgeToEquipID

        if self.CompareResultIconView2 then
            self.CompareResultIconView2:showEquip(eq_num_id)
        end
        

        local data = nil
        if self.reforgeEquipData == nil then
            GameManagerInst:alert("self.reforgeEquipData == nil")
            return
        else
            data = self.reforgeEquipData
        end


        self.panel_CompareResult:getChildByName("lbEqToLv_0"):setString(UITool.ToLocalization("等级").."100".."/".."100")
        

        self.panel_CRPanelProp_2:getChildByName("skillIcon"):setTexture(equip[eq_num_id]["equip_skill"]["skill_img"])
        self.panel_CRPanelProp_2:getChildByName("skillIcon"):setVisible(true)

        self.panel_CRPanelProp_2:getChildByName("lbName"):setString(UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_name"]))
        self.panel_CRPanelProp_2:getChildByName("lbLv"):setString(UITool.ToLocalization("等级 ")..data["sk"]["Lv_max"])
        
        self.panel_CRPanelProp_2:getChildByName("lbNextAtk_0"):setString(equip_upgrade[eq_num_id][100][2])
        self.panel_CRPanelProp_2:getChildByName("lbNextHp_0"):setString(equip_upgrade[eq_num_id][100][3])



        --随机技能继承
        for i = 1,2 do
            local prsk = self.panel_CRPanelProp_2:getChildByName("pRsk"..i)
            if data["rsk"] ~= nil and data["rsk"][i] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[data["rsk"][i][1]])
                strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][i][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end

        --新装备技能
        local detail_size = self.panel_CRPanelProp_2:getChildByName("Panel_3"):getSize()

        local richText = ccui.RichText:create()
        richText:ignoreContentAdaptWithSize(false)
        richText:setContentSize(detail_size)
        richText:setPosition(detail_size.width / 2,detail_size.height / 2)

        self.panel_CRPanelProp_2:getChildByName("Panel_3"):addChild(richText)

        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(self.luaData["eq_sk_desc"])

        if self.ShowReforgeCorR == 2 then
            --local nEqRealyLv = data["Lv"]
            --重铸完成获得的新装备显示1级数据
            self.panel_CompareResult:getChildByName("lbEqToLv_0"):setString(UITool.ToLocalization("等级").."1".."/".."100")

            self.panel_CRPanelProp_2:getChildByName("lbLv"):setString(UITool.ToLocalization("等级 ")..1)

            self.panel_CRPanelProp_2:getChildByName("lbNextAtk_0"):setString(equip_upgrade[eq_num_id][1][2])
            self.panel_CRPanelProp_2:getChildByName("lbNextHp_0"):setString(equip_upgrade[eq_num_id][1][3])

            str_des = UITool.getUserLanguage(self.luaData["eq_sk_1_desc"])
        end

        richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 20) )

    else
        self.CompareResultIconView2:showNoIcon()
        self.panel_CRPanelProp_2:getChildByName("skillIcon"):setVisible(false)

        self.panel_CRPanelProp_2:getChildByName("lbName"):setString("")
        self.panel_CRPanelProp_2:getChildByName("lbLv"):setString(UITool.ToLocalization("等级 ")..1)

        self.panel_CRPanelProp_2:getChildByName("lbNextAtk_0"):setString("")
        self.panel_CRPanelProp_2:getChildByName("lbNextHp_0"):setString("")

        --skill
        self.panel_CRPanelProp_2:getChildByName("panelProp_randSkill1"):setVisible(false)
        self.panel_CRPanelProp_2:getChildByName("panelProp_randSkill2"):setVisible(false)
    end


    --重铸素材装备信息
    if self.reforgeByEquipID then
        local eq_num_id = self.reforgeByEquipID

        if self.CompareResultIconView1 then
            self.CompareResultIconView1:showEquip(eq_num_id)
        end
        

        local data = nil
        if self.reforgeEquipData == nil then
            GameManagerInst:alert("self.reforgeEquipData == nil")
            return
        else
            data = self.reforgeEquipData
        end
        
        self.panel_CompareResult:getChildByName("lbEqByLv_0"):setString(UITool.ToLocalization("等级").."100".."/".."100")

        self.panel_CRPanelProp_1:getChildByName("skillIcon"):setTexture(equip[eq_num_id]["equip_skill"]["skill_img"])
        self.panel_CRPanelProp_1:getChildByName("skillIcon"):setVisible(true)

        self.panel_CRPanelProp_1:getChildByName("lbName"):setString(UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_name"]))
        self.panel_CRPanelProp_1:getChildByName("lbLv"):setString(UITool.ToLocalization("等级 ")..data["sk"]["Lv_max"])
        
        self.panel_CRPanelProp_1:getChildByName("lbNextAtk_0"):setString(equip_upgrade[eq_num_id][100][2])
        self.panel_CRPanelProp_1:getChildByName("lbNextHp_0"):setString(equip_upgrade[eq_num_id][100][3])


        --随机技能继承
        for i = 1,2 do
            local prsk = self.panel_CRPanelProp_1:getChildByName("pRsk"..i)
            if data["rsk"] ~= nil and data["rsk"][i] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[data["rsk"][i][1]])
                strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][i][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end

        --新装备技能
        local detail_size = self.panel_CRPanelProp_1:getChildByName("Panel_3"):getSize()

        local richText = ccui.RichText:create()
        richText:ignoreContentAdaptWithSize(false)
        richText:setContentSize(detail_size)
        richText:setPosition(detail_size.width / 2,detail_size.height / 2)

        self.panel_CRPanelProp_1:getChildByName("Panel_3"):addChild(richText)

        --素材装备显示真实数据
        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_des"])
        str_des = UITool.stringForEqSK(str_des,data["sk"]["add_atk_rate"])

        richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 20) )


        --重铸成功后重铸材料装备显示真实数据
        if self.ShowReforgeCorR == 2 then
            local nEqRealyLv = data["Lv"]
            self.panel_CompareResult:getChildByName("lbEqByLv_0"):setString(UITool.ToLocalization("等级")..data["Lv"].."/"..data["Lv_max"])

            self.panel_CRPanelProp_1:getChildByName("lbLv"):setString(UITool.ToLocalization("等级 ")..data["sk"]["Lv"])

            self.panel_CRPanelProp_1:getChildByName("lbNextAtk_0"):setString(equip_upgrade[eq_num_id][nEqRealyLv][2])
            self.panel_CRPanelProp_1:getChildByName("lbNextHp_0"):setString(equip_upgrade[eq_num_id][nEqRealyLv][3])

            -- str_des = equip[eq_num_id]["equip_skill"]["skill_des"]
            -- str_des = UITool.stringForEqSK(str_des,data["sk"]["add_atk_rate"])
        end
        
    else
        self.CompareResultIconView1:showNoIcon()
        self.panel_CRPanelProp_1:getChildByName("skillIcon"):setVisible(false)

        self.panel_CRPanelProp_1:getChildByName("lbName"):setString("")
        self.panel_CRPanelProp_1:getChildByName("lbLv"):setString(UITool.ToLocalization("等级 ")..1)

        self.panel_CRPanelProp_1:getChildByName("lbNextAtk_0"):setString("")
        self.panel_CRPanelProp_1:getChildByName("lbNextHp_0"):setString("")

        --skill
        self.panel_CRPanelProp_1:getChildByName("panelProp_randSkill1"):setVisible(false)
        self.panel_CRPanelProp_1:getChildByName("panelProp_randSkill2"):setVisible(false)
    end
end

--没有选择素材装备目标
function EquipReforgeView:onNoSelectTarget( ... )
    self.panelData:setVisible(false)
    self.spSelectPlease:setVisible(true)
    self.panelNoDataL:setVisible(true)
    self.btnForge:setTouchEnabled(false)
    self.btnForge:setBright(false)
end

--已选择素材装备目标
function EquipReforgeView:onHadSelectTarget( ... )
    self.panelData:setVisible(true)
    self.spSelectPlease:setVisible(false)
    self.panelNoDataL:setVisible(false)
    self.btnForge:setTouchEnabled(true)
    self.btnForge:setBright(true)
end

--没有可选择装备
function EquipReforgeView:onNoTargetList( ... )
    self.panelNoDataR:setVisible(true)
end

--有可选择装备
function EquipReforgeView:onHaveTargetList( ... )
    self.panelNoDataR:setVisible(false)
end

--属性对比按钮回调
function EquipReforgeView:onDataCompare( ... )
    self:showCompareResultView(true,1)
end

--重铸回调
function EquipReforgeView:onEquipReforge()
    --
    local tempTable = {
        ["rpc"] = "eq_reforge",
        ["id"] = self.reforgeByEquipIDSend,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        self:playEffect()

        print("重铸请求成功 TODO:处理数据")
        if data["eq_list"] ~= nil then
            self.reforge_ids = table.deepcopy(data["reforge_ids"])
            self.mats = table.deepcopy(data["mat"])
        else
            self.reforge_ids = {}
            self.mats = {}
        end
    end,
    function(state_code,msgText,hehe)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipReforgeView:getDataSource()
    local ds = {}
    self.bHasCanReforge = false
    if self.canReforgeEqList then
        for i = 1,#self.canReforgeEqList do
            table.insert(ds,table.deepcopy(self.canReforgeEqList[i]))
            self.bHasCanReforge = true
        end
    else
        return
    end

    SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())

    return ds
end

function EquipReforgeView:refresh()
    self.currentDataSource = self:getDataSource()
    self.gridview:setDataSource(self.currentDataSource)
    self.gridview:refresh()

    self:refreshReforgeByInfo()
end

function EquipReforgeView:loadData()
    --
    local tempTable = {
        ["rpc"] = "reforge_list",
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if data["eq_list"] ~= nil then
            local temp_list = {}
            local index = 1
            for k,v in pairs(data["eq_list"]) do
              temp_list[index] = v
              if temp_list[index]~=nil then
                temp_list[index]["id"] = k
                index = index +1
              end
            end
            self.canReforgeEqList = {}
            self.canReforgeEqList = table.deepcopy(temp_list)
        else
            self.canReforgeEqList = {}
        end
        --GameManagerInst:saveToFile("reforge_list.json",data)
        self:refresh()
    end,
    function(state_code,msgText,hehe)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipReforgeView:onNavigateTo(isback)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    else
    end
end