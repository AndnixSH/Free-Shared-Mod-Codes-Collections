--[[
    新手引导 空实现
]]



local MaxGuide = 20
local MaxMandatoryGuide = guide_id_config.SB --强制引导最大ID 
local isFineshFirst = false

GuideImplNull = class("GuideImplNull")


function GuideImplNull:ctor()
    self:resetState()
end
function GuideImplNull:resetState()
    self.isStart = false 
    self.guideLayer = nil 
    self.sManager = nil 
    self._nowGuideID = 0
    self._curIndex = 1
    self.guideEffect_1 = nil 
    self.guideEffect_2 = nil 
    self.isStartWeakGuide = false
    self.curUnlockType = nil  --
    self.backDeleagte = nil  --用于弱引导的返回回调
    self.backFun = nil      --用于弱引导的返回回调
end

function GuideImplNull:setManager(manager)
    self.sManager = manager
    self._nowGuideID = user_info["guide_id"]
end
--每次登陆之后调用新手引导
function GuideImplNull:startGuide()
    print("GuideImplNull:startGuide()")
    self._nowGuideID = user_info["guide_id"]
    local isStart = true 
    local guide_id = user_info["guide_id"] or 1
-------------testCode 跳过战斗新手引导   记得上传的时候备注上
    -- if guide_id < 30 then 
    --     NewGuideManager:reqSendGuide(guide_id_config.FB)
    --     return 
    -- end
-- -----------------------------------  
    print("GuideImplNull:startGuide() guide_id", guide_id)      
    if guide_id == 0 then 
        print("请服务器默认初始新手引导为1")
    elseif guide_id <= 2 then 
        self:startBattleGuide()
    elseif guide_id <= MaxMandatoryGuide then 
        -- self.sManager:addTouchMask() --屏蔽触摸
        if self.sManager.isStartLayerInit then 
            self.sManager:toStartLayer()
        end 
        self:startMenuGuide()
    else
        isStart = false
    end

    local user_soft_guide = user_info["user_soft_guide"] or 0

    --user_soft_guide = unlock_type_17 --testCode 

    if tonumber(user_soft_guide) ~= 0 then 
        print("触发引导 ID:"..user_soft_guide)
        if self.sManager.isStartLayerInit then 
            self.sManager:toStartLayer()
        end 
        self:startWeakGuide(tonumber(user_soft_guide))
        isStart = true
    end 

    self.isStart = isStart
    return isStart
end
--------新手战斗引导
function GuideImplNull:startBattleGuide()
    print("GuideImplNull:startBattleGuide()")
    local guide_id = user_info["guide_id"] or 0
    	if user_info["guide_id"] == 1 then
        cc.MyHttpHelper:shareMyHttpHelper():startGame()
        KeyboardManager:setbattleState(true)

        UITool.delayTask(0.1,function ( ... )
            local scene = cc.Director:getInstance():getRunningScene()
                dump(scene, "GuideImplNull:startBattleGuide    22222")
                if scene then
                    KeyboardManager:bindingAndroidKeyboard(scene,3)
                end
            end)

    elseif user_info["guide_id"] ==2 then
        if isFineshFirst == false then
        local sData = {}
        sData["filename"] = "story/c0s0e0l2.json"
        sData["callBack"] = 5
        SceneManager:toDialogLayer(sData)
        end
    end
end 
----todo重新处理！！！！
--处理第一阶段和c++层交互引导Id 业务逻辑拿到这边处理
function GuideImplNull:dealFirstGuide(id)
    print("GuideImplNull:dealFirstGuide()")
    print("Guide id == "..id)
    if id == 1 then
        -- self.sManager:addTouchMask() --屏蔽触摸
        GuideImplNull:reqSendGuide(3)
    end
    
end 
----新手引导界面阶段
function GuideImplNull:startMenuGuide()
     print("GuideImplNull:startMenuGuide()")
   
end

--弱引导。剧情触发引导
function GuideImplNull:startWeakGuide(_type)
    print("GuideImplNull:startWeakGuide()")
    if self.guideLayer ~= nil then 
        self:nilGuideLayer()
    end

    self:weakGuideCallBack()
end

function GuideImplNull:startSubGuide(delegate, curIndex,guide_id)
    print("GuideImplNull:startSubGuide()")
    return false
end

function GuideImplNull:nilGuideLayer()
    print("GuideImplNull:nilGuideLayer()")
    self.guideLayer = nil 
end

--处理按钮点击事件
function GuideImplNull:dealMenuGuide(guide_id,curIndex)
    print("GuideImplNull:dealMenuGuide()")
    self:finshNowGuide()
end
--3抽卡 
function GuideImplNull:dealGuideThatCard(guide_id,curIndex)
    print("GuideImplNull:dealGuideThatCard()")
end
--4、编队
function GuideImplNull:dealGuideTeam(guide_id,curIndex)
    print("GuideImplNull:dealGuideTeam()")
end

--5、第一次出征
function GuideImplNull:dealGuideFB(guide_id,curIndex)
    print("GuideImplNull:dealGuideFB()")
end

--6 第二次战斗
function GuideImplNull:dealGuideSB(guide_id,curIndex)
    print("GuideImplNull:dealGuideSB()")
end

--7、强化角色
function GuideImplNull:dealGuideStHero(guide_id,curIndex)
     print("GuideImplNull:dealGuideStHero()")
end

--5、角色技能升级
function GuideImplNull:dealGuideRoleSkill(guide_id,curIndex)
    print("GuideImplNull:dealGuideRoleSkill()")
end
--灵装使用
function GuideImplNull:dealGuideEquipment(guide_id,curIndex)
    print("GuideImplNull:dealGuideEquipment()")
end
--女主神格
function GuideImplNull:dealGuideGodhead(guide_id,curIndex)
    print("GuideImplNull:dealGuideGodhead()")
end
--起名字引导
function GuideImplNull:dealGuideNewName(guide_id,curIndex)
    print("GuideImplNull:dealGuideNewName()")
end
----多人战引导
function GuideImplNull:dealGuideMoreBattle(guide_id,curIndex)
    print("GuideImplNull:dealGuideMoreBattle()")
end
--、角色突破（潜能解放）
function GuideImplNull:dealGuideHeroBT(guide_id,curIndex)
    print("GuideImplNull:dealGuideHeroBT()")
end
----试炼之地引导
function GuideImplNull:dealGuideTrial(guide_id,curIndex)
    print("GuideImplNull:dealGuideTrial()")
end
--后面的对话引导
function GuideImplNull:dealOtherGuide(guide_id,curIndex)
    print("GuideImplNull:dealOtherGuide()")
end
---BattleEndLayer:showPlayerUp
function GuideImplNull:weakGuideCallBack()
    print("GuideImplNull:weakGuideCallBack()")
    self.isStartWeakGuide = false
    self.isStart = false

    if self.backFun~=nil then 
        self.backFun(self.backDeleagte)
    end 
    self.backDeleagte = nil
    self.backFun = nil

    ---如果在主界面 显示女主2
    if SceneManager.sceneNum == 1 then
        SceneManager.menuLayer.princessController:createAnime()
    end 
end
--对话最后一步显示
--暂时不用了
function GuideImplNull:playGuideEffect(dialogLayer,num)
    print("GuideImplNull:playGuideEffect()")
end
--去显示选择引导UI
function GuideImplNull:showTeamSelectUI(dialogLayer)
	print("GuideImplNull:showTeamSelectUI()")
end
--通知服务器完成当前引导
function GuideImplNull:finshNowGuide()
    print("GuideImplNull:finshNowGuide()")

    local nowGuideId = user_info["guide_id"]
    local nextGuideId = nowGuideId + 1
    self:reqSendGuide(nextGuideId)   
end
--启动网络的时候新手引导隐藏掉
function GuideImplNull:setGuideLayerVisibele(isVisible)
    if isVisible == true then
        print("GuideImplNull:setGuideLayerVisibele()  true") 

    else
        print("GuideImplNull:setGuideLayerVisibele()  false") 
    end
    
    if self.isStart and self.guideLayer ~= nil and self.guideLayer.uiLayer ~=nil then 
        self.guideLayer.uiLayer:setVisible(isVisible)   
    end 
end
--向服务器发送新手引导进度
function GuideImplNull:reqSendGuide(id)
    print("GuideImplNull:reqSendGuide()") 
  -- body
    local function reiceSthCallBack(data)
        print("收到新手引导结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        print("reiceSthCallBack guide_id", user_info["guide_id"])
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if user_info["guide_id"] < guide_id_config.ThatCard then 
        	user_info["guide_id"] = t_data["data"]["guide_id"]
            self._nowGuideID = user_info["guide_id"]
        	self:startGuide()
        else 
        	self.nextGuide = t_data["data"]["guide_id"]
            if user_info["guide_id"] == guide_id_config.FB  then 
                self:dealGuideFB(guide_id_config.FB, 5)
            end 
            if user_info["guide_id"] == guide_id_config.SB then 
                user_info["guide_id"] = t_data["data"]["guide_id"]
                self:endGuideFunc() --结束强制引导
            end 
        end 
        --保存ID
        cc.UserDefault:getInstance():setIntegerForKey("GuideId", tonumber(t_data["data"]["guide_id"]))
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]      = "guide",
        ["guide_id"] = id
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--向服务器发送新手引导进度
function GuideImplNull:reqSendGuideWithCallBack(delegate,callback)
    print("GuideImplNull:reqSendGuideWithCallBack()")

    local nowGuideId = user_info["guide_id"]
    id = nowGuideId + 1
  -- body
    local function reiceSthCallBack(data)
        print("收到新手引导结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        user_info["guide_id"] = t_data["data"]["guide_id"]
        --保存ID
        cc.UserDefault:getInstance():setIntegerForKey("GuideId", tonumber(t_data["data"]["guide_id"]))

        if callback ~=nil then 
        	callback(delegate)
        end 
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]      = "guide",
        ["guide_id"] = id
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
------------下面是处理按钮显示特效 的相关方法
--去显示选择引导UI
function GuideImplNull:showBtn()
    print("GuideImplNull:showBtn()")
    -- body
    --抽卡出现特效
    if self._nowGuideID == guide_id_config.ThatCard and self._curIndex == 1 then 
        self.sManager.menuLayer:showCardBtn()
    end 
    --编队出现特效
    if self._nowGuideID == guide_id_config.Team then 
        self.sManager.menuLayer:showTeamBtn(1)
    end   
end
--处理拒绝引导之后的刷新
function GuideImplNull:dealRefused()
    print("GuideImplNull:dealRefused()")
    -- body
   -- dump("GuideImplNull:dealRefused111")
    --新加 热云统计
    self:dealReyunEventRefuse()

    if self._nowGuideID == guide_id_config.Team then 
        self.sManager.menuLayer:showTeamBtn(0)
    end  
    self._nowGuideID=user_info["guide_id"] 
    self.isStartWeakGuide = false 
    self.isStart = false
    if self.backFun~=nil then 
        self.backFun(self.backDeleagte)
    end 
    self.backDeleagte = nil
    self.backFun = nil
    ---如果在主界面 显示女主
    if SceneManager.sceneNum == 1 then
        SceneManager.menuLayer.princessController:createAnime()
    end 
end
---强制引导结束函数
function GuideImplNull:endGuideFunc()
    print("GuideImplNull:endGuideFunc()")
    -- body
    if self._nowGuideID == guide_id_config.Team then 
        self.sManager.menuLayer:showFirghtBtn()
        self.isStart = false
        if self.sManager.sceneNum == 1 then
            self.sManager.menuLayer.princessController:createAnime()
        end 
    end   
    self._nowGuideID = user_info["guide_id"] 
    self.isStartWeakGuide = false
    self.isStart = false
end

----告诉服务器完成 弱引导
function GuideImplNull:reqSoftGuidePass(callBack)
    print("GuideImplNull:reqSoftGuidePass()")
  -- body
    local function reiceSthCallBack(data)
        print("收到新手引导结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        user_info["user_soft_guide"] = 0
        if callBack then 
            callBack()
        end 
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]      = "user_soft_guide_pass",
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

---热云选择拒绝引导
function  GuideImplNull:dealReyunEventRefuse()
    print("GuideImplNull:dealReyunEventRefuse()")
    -- body
    if self._nowGuideID == guide_id_config.Team then 
    elseif self._nowGuideID == guide_id_config.RoleSkill then 
    elseif self._nowGuideID == guide_id_config.Equipment then 
    elseif self._nowGuideID == guide_id_config.Godhead then 
    end
end

---热云 一句话引导 新手引导9 灵装强化教学-- 新手引导22 黑潮遗迹
--说明：目前eventId 是 event00 +当前引导ID，所以代码拼接，如果有变化，直接整表吧
function  GuideImplNull:dealReyunGuideOtherEvent(guide_id)
    print("GuideImplNull:dealReyunGuideOtherEvent()")
end