--SiftSortArithmetic.lua
-----角色图鉴、称号薄 等 排序
function ComSortData(data, sortState, sort_typeValue)
    local compFunc = nil
    local compReversalFunc = nil --特殊情况，id 降序,实际ID是从小到大，生序，id是从大到小

	if sortState == SortStateEnum.DOWN then
        --降序 
        compFunc = function(a,b) return tonumber(a) > tonumber(b) end
        compReversalFunc = function(a,b) return tonumber(a) < tonumber(b) end
    else 
        --生序
        compFunc = function(a,b) return tonumber(a) < tonumber(b) end
        compReversalFunc = function(a,b) return tonumber(a) > tonumber(b) end
    end
    
    local idFunc  = function (item) return item[SortFunDataKey.ID]      end -- 序号
    local eleFunc = function (item) return item[SortFunDataKey.ELEMENT] end -- 属性
    local rarFunc = function (item) return item[SortFunDataKey.RARITY]  end -- 稀有度

    local sor_s = nil
    local compSelectFunc = compFunc
    if sort_typeValue == ComSortValue.EXCELID then       
        sor_s = idFunc
        compSelectFunc = compReversalFunc
    elseif sort_typeValue == ComSortValue.ELEMENT then  
       sor_s =  eleFunc 
    elseif sort_typeValue == ComSortValue.RARITY then    
        sor_s = rarFunc
    else
        sor_s = idFunc
    end
        
    table.sort(data,function(x,y)
        if sor_s(x) == sor_s(y) then 
            ---属性>稀有度>排序ID 后续排序优先级，只是降序，不产生生降序关系
            if x[SortFunDataKey.ELEMENT]== y[SortFunDataKey.ELEMENT] then
                if x[SortFunDataKey.RARITY]== y[SortFunDataKey.RARITY] then 
                    return x[SortFunDataKey.ID] < y[SortFunDataKey.ID] ----特殊情况，id 降序,实际ID是从小到大，生序，id是从大到小
                else 
                    return x[SortFunDataKey.RARITY] > y[SortFunDataKey.RARITY]
                end 
            else
                return x[SortFunDataKey.ELEMENT] > y[SortFunDataKey.ELEMENT]
            end 
        else 
            return compSelectFunc(sor_s(x),sor_s(y))
        end
    end)
end

-----------------------------筛选
---todo 以下筛选，可以提炼公共方法，暂时不做
---todo 筛选算法，数量不多，暂时用for if 不优化。优化方向：forkey
---角色图鉴 筛选算法
function SiftHeroBook(data, selects)
    local tempData = {}
    local raritys = selects[SiftSortMainType.RARITY]
    local elements = selects[SiftSortMainType.ELEMENT]
    local heroraces = selects[SiftSortMainType.HERO_RACE]
    local heropowers = selects[SiftSortMainType.HERO_POWER]
    for i=1,#data do
        local v = data[i]
        local h_num_id = v.h_num_id
        local nAtb   = hero[h_num_id].hero_atb
        local nRank  = hero[h_num_id].hero_rank
        local nRace  = hero[h_num_id].hero_race
        local nPower = hero[h_num_id].power_name

        local isRar = IsInTabel(nRank,raritys)
        local isEle = IsInTabel(nAtb,elements)
        local isRace = IsInTabel(nRace,heroraces)
        local isPower = IsInTabel(nPower,heropowers)

        if isRar and isEle and isRace and isPower then 
            tempData[#tempData+1] = data[i]
        end 
    end
    return tempData
end

--筛选称号
--如果选择页面也想使用此方法，collectValue直接默认全给1即可
--todo selects 某个具体的，如果是nil，应该赋值为全部全部，但是慎用
function SiftTitleBook(data, selects)
    local tempData = {}
    local raritys  = selects[SiftSortMainType.RARITY]
    local elements = selects[SiftSortMainType.ELEMENT] 
    local actTypes = selects[SiftSortMainType.ACT_TYPE]
    local collects = selects[SiftSortMainType.IS_HAVE] or {1,2} 
    for i=1,#data do
        local v = data[i]
        local id = v.id
        local nAtb  = title_conf[id].element
        local nRank = title_conf[id].rarity
        local nType = title_conf[id].type
        local nCollect = v.collectValue

        local isRar = IsInTabel(nRank,raritys)
        local isEle = IsInTabel(nAtb,elements)
        local isType = IsInTabel(nType,actTypes)  
        local isCollect = IsInTabel(nCollect,collects)   
        if isRar and isEle and isType and isCollect then 
            tempData[#tempData+1] = data[i]
        end 
    end
    return tempData
end
-----------------------------筛选
---todo 以下筛选，可以提炼公共方法，暂时不做
---todo 筛选算法，数量不多，暂时用for if 不优化。优化方向：forkey
---角色图鉴 筛选算法
function SiftEquipBook(data, selects)
    local tempData = {Equip}
    local raritys    = selects[SiftSortMainType.RARITY]          --稀有
    local elements   = selects[SiftSortMainType.ELEMENT]         -- 属性
    local targetType = selects[SiftSortMainType.TARGET_TYPE]     -- 作用类型
    local targetRity = selects[SiftSortMainType.TARGET_RARITY]   -- 作用属性
    local skill_     = selects[SiftSortMainType.SKILL_]          -- 技能
    for i=1,#data do
        local v = data[i]
        local id = v.e_num_id
        local nAtb       = equip[id].equip_atb
        local nRank      = equip[id].equip_rank
        local ta_type    = equip[id].skill_effect_type
        local ta_rarity  = equip[id].skill_effect
        local ta_skill   = equip[id].sk_two_for_sort
        

        local isRar     = IsInTabel(nRank,raritys) --稀有度
        local isEle     = IsInTabel(nAtb,elements) --属性
        local isTarType = IsInTabel(ta_type,targetType)   --作用类型
        local isTarRity = IsInTabel(ta_rarity,targetRity) -- 作用属性
        local isSkill   = IsInTabel(ta_skill,skill_)        -- 技能
        if isRar and isEle and isTarType and isTarRity and isSkill then 
            tempData[#tempData+1] = data[i]
        end 
    end
    return tempData
end

function IsInTabel(value, table)
    if table.selectAll then 
        return true
    end 
    for i=1,#table do
        if value == table[i] then 
            return true
        end 
    end
   
end
