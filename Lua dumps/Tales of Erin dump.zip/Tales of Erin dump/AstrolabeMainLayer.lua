--/*说明
    --星盘主界面
--*/
AstrolabeMainLayer = class("AstrolabeMainLayer",XUIView)
AstrolabeMainLayer.CS_FILE_NAME = "AstrolabeMainLayer.csb"
AstrolabeMainLayer.CS_BIND_TABLE = 
{
    panel_1   = "/s:Panel_1",
    btnHelp   = "/s:btnHelp",
    --星盘
    aslPanel1        = "/s:Panel_astrobe1",
    aslPanel2        = "/s:Panel_astrobe2",
    aslPanel3        = "/s:Panel_astrobe3",
    mainBg           = "/s:Panel_1/i:237",

    panelEffcet      = "/s:panelEffect",
    panelMain = "/s:Panel_mian",
    --星盘等级
    lv        = "/s:Panel_mian/i:238",
    lvEx      = "/s:Panel_mian/i:239",
    --待分配星点
    point     = "/s:Panel_mian/s:Image_point_bg/i:252",
    pointText = "/s:Panel_mian/s:Image_point_bg/s:Text_pint1",
    --可扩张星点
    pointEx   = "/s:Panel_mian/s:Image_point_bg/i:255",
    --扩张按钮
    exBtn     = "/s:Panel_mian/s:Image_point_bg/i:256",
    --经验条
    expBar    = "/s:Panel_mian/s:Image_bar_bg/i:241",
    --吃狗粮的经验条
    expBar2   = "/s:Panel_mian/s:Image_bar_bg/s:LoadingBar_2",
    --经验text
    expText   = "/s:Panel_mian/s:Image_bar_bg/i:243",
    --强化按钮
    sthBtn    = "/s:Panel_mian/i:244",
    --取消强化按钮
    sthCclBtn   = "/s:Panel_mian/i:246",
    --重制按钮
    retBtn      = "/s:Panel_mian/i:248",
    -- 星盘区域按钮
    aslBtn1        = "/s:Panel_mian/i:251",
    aslBtn2        = "/s:Panel_mian/i:252",
    aslBtn3        = "/s:Panel_mian/i:253",
    closeBtn       = "/s:Panel_mian/s:Button_close",
}
function AstrolabeMainLayer:init(rcvData)

    AstrolabeMainLayer.super.init(self)

    self.exist = true;
    self.m_AudoId = nil
    --每次扩充的固定点数
    self.pointAdd = 5
    self.rcvData = rcvData
    self.curAreaIndex  = self.rcvData["curAreaIndex"]
    self.skeletonNode = nil
    --强化预览等级
    self.sthAddLv      = 0
    --控制可以解锁未解锁的区域
    self.curLoakArea   = 0
    print(" self.curAreaIndex == ".. self.curAreaIndex)
    self.serverData   = self.rcvData["severData"]
    self.sthUI        = nil
    self.hero_id      = self.rcvData["hero_id"]
    self.hero_sub_id  = getNumID(self.hero_id)
    self.roleData     = self.rcvData["roleData"]
    self.maxArea      = table_leng(self.serverData["astrolabe"]["astr_area"]) 
    self.refreshCallFunc = self.rcvData["refreshCallFunc"]
    self.newRoleStarSelf      = self.rcvData["newRoleStarSelf"]
    self.sManager = rcvData["sManager"]
    self:showImageTl()
    self:setUiData()
    -- --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    return self
end
function AstrolabeMainLayer:showImageTl( ... )
    self.imageTable = {}
    self.imageTable[1] = {}
    self.imageTable[2] = {}
    self.imageTable[3] = {}
    self.imageTable[1]["lock_image"]    = "res/uifile/n_UIShare/astrolabe/xp_b_003c.png"
    self.imageTable[1]["unlock_image"]  = "res/uifile/n_UIShare/astrolabe/xp_b_003a.png"
    self.imageTable[1]["checked"]       = "res/uifile/n_UIShare/astrolabe/xp_b_003b.png"
    self.imageTable[2]["lock_image"]    = "res/uifile/n_UIShare/astrolabe/xp_b_004c.png"
    self.imageTable[2]["unlock_image"]  = "res/uifile/n_UIShare/astrolabe/xp_b_004a.png"
    self.imageTable[2]["checked"]       = "res/uifile/n_UIShare/astrolabe/xp_b_004b.png"
    self.imageTable[3]["lock_image"]    = "res/uifile/n_UIShare/astrolabe/xp_b_005c.png"
    self.imageTable[3]["unlock_image"]  = "res/uifile/n_UIShare/astrolabe/xp_b_005a.png"
    self.imageTable[3]["checked"]       = "res/uifile/n_UIShare/astrolabe/xp_b_005b.png"
end
function AstrolabeMainLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    
end
--播放点击的音效
function AstrolabeMainLayer:playMusicBtn( ... )
    
    self.m_AudoId =  AudioManager:shareDataManager():playMusic("music/ui/touchlong.mp3", 2,false)
end
function AstrolabeMainLayer:clearFullEffec( ... )
    for i = 1 ,self.maxArea  do
                --本地表数据
        local testTable  = hero_astrolabe[self.hero_sub_id]["areas"][i]
         --星盘属性长度
        local testLen     = #testTable["stars"]
        local node = self._csNode:getChildByName("Panel_astrobe"..i)
        for y = 1 , testLen do
            print("yyyyy == "..y)
            print("testLen == "..testLen)
            local imageChild = node:getChildByName("Image_"..y)
            if imageChild:getChildByTag(123) then
                print("打印的次数 === "..y)
                imageChild:getChildByTag(123):stopAllActions()
                imageChild:getChildByTag(123):removeFromParent()
            end
        end
    

    end
end
function AstrolabeMainLayer:returnBack()

    --删除背景特效
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
    end 
    self:clearFullEffec()
    self.refreshCallFunc(self.newRoleStarSelf)
    self.exist = false
    self:clearEx()
    if self.sManager then
        self.sManager:removeFromNavNodes(self)
    end
    self:removeFromParentView()
end
-- 点击事件
function AstrolabeMainLayer:touchClick( ... )
    --一区
    self.aslBtn1:addClickEventListener(function()
       -- changeBtn:setEffectType(1)
        self:playMusicBtn()
        self:checkedArea(1)
    end)
    self.aslBtn2:addClickEventListener(function()
        --changeBtn:setEffectType(1)
        self:playMusicBtn()
        self:checkedArea(2)
    end)
    self.aslBtn3:addClickEventListener(function()
       -- changeBtn:setEffectType(1)
        self:playMusicBtn()
        self:checkedArea(3)
    end)
    --关闭
    self.closeBtn:setEffectType(3)
    self.closeBtn:addClickEventListener(function()

        self:returnBack()
    end)
    --扩充按钮
    self.exBtn:addClickEventListener(function()

        self:toAstrolabeAddSPView()
    end)
    --强化按钮
    self.sthBtn:addClickEventListener(function()
        self.sthBtn:setVisible(false)
        self.sthCclBtn:setVisible(true)
        self:toAstrolabe_sth()
    end)  
    --帮助按钮
    self.btnHelp:addClickEventListener(function()
        local data = {}
        data.pictures = { --一张或者多张
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_xp_001.png",
        }
        local sData = {}
        sData["prefix"] = "xp"
        sData["fontSize"] = 20
        sData["Iamgdata"] = data
        SceneManager:toPublicHelpText(sData)
    end)
end

--星盘强化
function AstrolabeMainLayer:toAstrolabe_sth()

    --点击链接服务器
    local view = Astrolabe_sth.new():init()
    local function function_name( ... )
        self:toolBar(self.expBar2,100,100)
        local maxLvLimit   = hero_astrolabe[self.hero_sub_id]["areas"][self.curAreaIndex]["level_max"]
        local exPMax = hero_astrolabe[self.hero_sub_id]["upgrade"][maxLvLimit - 1][2]
        self.expText:setString(exPMax.."/"..exPMax)
        return
    end
    --设置强化根据经验提供的等级
    view.setExp   = function ( sender )
        --选择素材提供的经验
        local addExp = sender.matExp * sender.mat_count
        self.matAddExp = addExp
        print("AstrolabeMainLayer setExp addExp addExp == "..addExp)
        --等于0证明没有选择素材
        if sender.mat_count == 0 then
            self:setLvExp()
            -- view.rightBtn:setTouchEnabled(true)
            -- view.rightBtn:setBright(true)
            return
        end
        --当前等级的经验
        local exp    = self.serverData["astrolabe"]["exp"]
        self:setMatAddLv(addExp,exp,0)
        print("AstrolabeMainLayer self.sthAddLv =="..self.sthAddLv)
        view:limitBtn(self.sthAddLv,function_name)
        
    end
    --点击强化的回调
    view.callBackSth = function (sender,mat_count,mid)
        if AstrolabeSthEff:getIsPlay() then
            return
        end
        local tempData = { 
            rpc = "hero_astrolabe_lv_up",
            hero_id = self.hero_id,
            mat_id  = mid,
            mat_num = mat_count,
        }
        GameManagerInst:rpc(tempData,3,
        function(data)
            --刷新次界面
            self.serverData = data
            print("  ======== "..data["astrolabe"]["lv"])
            AstrolabeSthEff:init(self,data["astrolabe"]["lv"])
            AstrolabeSthEff.refrshAsMainLa = function ()
                self.lvEx:setString("")
                self:refreshData()
                self.sthCclBtn:setVisible(false)
                self.sthBtn:setVisible(true) 
                self.lvEx:setVisible(false)

                view:returnBack() 
            end

        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText,function()
               
            end)
        end,
        true)
    end
    --点击背景关闭此界面
    view.panle:addClickEventListener(function()
        if AstrolabeSthEff.isPlayB then
            AstrolabeSthEff:onEffectEnd()
        else
            self.sthCclBtn:setVisible(false)
            self.sthBtn:setVisible(true) 
            self.lvEx:setVisible(false)
            self:setLvExp()
            view:returnBack()  
        end

    end)
    print("sth  mat == "..hero_astrolabe[self.hero_sub_id]["mat_exp"])
    local matMax = self.serverData["astrolabe"]["astr_mat"][hero_astrolabe[self.hero_sub_id]["mat_exp"]]
    local asLv = self.serverData["astrolabe"]["lv"]
    view:loadData(matMax,self.hero_id,self.curAreaIndex,asLv)
    GameManagerInst:showModalView(view)
    
end

--设置素材提供的经验 换算成等级
function AstrolabeMainLayer:setMatAddLv( addExp,exp,adLv )
    self.expBar:setVisible(false)
    self.expBar2:setVisible(true)

    --吃素材提供的经验
    local  matAddExp = addExp
    --控制要升几级
    local addLv    = adLv
    --当前的星盘等级
    self.asLv     = self.serverData["astrolabe"]["lv"]
    --当前经验
    local curExp      = exp--self.serverData["astrolabe"]["exp"]
    --当前等级最大经验
    local maxexp   = hero_astrolabe[self.hero_sub_id]["upgrade"][self.asLv+addLv][2]

    -- --当前等级差多少经验升级
    local cExp  = maxexp - curExp 
    print(" addLv  addLv == "..addLv)
    if matAddExp < cExp then
        self.lvEx:setVisible(true)
        if addLv <= 0 then
            self.lvEx:setString("")
        else
            self.lvEx:setString("+"..addLv)
        end
        if g_channel_control.transform_lvEx_pos == true then
            local oldX = 208.5
            local newX = oldX+30
            self.lvEx:setPositionX(newX)
        end
        self.sthAddLv = addLv
        self:toolBar(self.expBar2,curExp+matAddExp,maxexp)
        self.expText:setString(tostring(curExp+matAddExp).."/"..tostring(maxexp))
        self.finalExp = matAddExp
        self.finalExpNext = maxexp
        return 
    else
        matAddExp = matAddExp - cExp
        addLv = addLv + 1
        self.expText:setString(tostring(curExp+matAddExp).."/"..tostring(maxexp))
        self:toolBar(self.expBar2,curExp+matAddExp,maxexp)
    end
    self:setMatAddLv(matAddExp,0,addLv)

end
--星盘点扩充
function AstrolabeMainLayer:toAstrolabeAddSPView( ... )
    if self.serverData["astrolabe"]["used_items"] >= hero_astrolabe[self.hero_sub_id]["use_item_max"]  then
        GameManagerInst:alert(UITool.ToLocalization("星盘点已扩充至上限"))
    else
        --点击链接服务器
        local view = AstrolabeAddSPView.new():init()
        view.addSpEvent = function(sender,matCount)
            local tempData = { 
                rpc      = "hero_astrolabe_asp_up",
                hero_id  = self.hero_id,
                item_num = matCount,
            }
            GameManagerInst:rpc(tempData,3,
            function(data)
                --刷新次界面
                    self.serverData = data
                    self:refreshData()
                    view:returnBack()
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText,function()
                   
                end)
            end,
            true)
            -- sender:returnBack()
        end
        local curEx  = self.serverData["astrolabe"]["used_items"]
        local maxEx  = hero_astrolabe[self.hero_sub_id]["use_item_max"]
        local matMax = self.serverData["astrolabe"]["astr_mat"][hero_astrolabe[self.hero_sub_id]["mat_asp"]]
        view:loadData(curEx,maxEx,matMax,self.hero_id)
        GameManagerInst:showModalView(view)
    end
end
--点击事件的回调
function AstrolabeMainLayer:checkedArea( index )
    local is_full = self.serverData["astrolabe"]["astr_area"][tostring(index)]["star_up_enabled"]
    local curTable  = hero_astrolabe[self.hero_sub_id]["areas"][index]

    local asB       = self:andTrue(curTable["astro_unlock"])
    --额外
    local colorTabl  = self:AsbLockStr(curTable["astro_unlock"])
    --等级
    local colorTabl1 = self:AsbLockStrLv(curTable["astro_unlock"])
    --加满所有技能
    local colorTabl2 = self:AsbLockStrSkill(index,is_full)
    --icon
    local icon      = curTable["icon_small"]
    --bg
    local uiimBg      = curTable["ui_msg_bg"]

    local imge      = self.panelMain:getChildByName("Image_"..index)

    local state     = self.serverData["astrolabe"]["astr_area"][tostring(index)]["state"]
   
    if asB then
        if is_full == 0 then
          
            MsgManager:shwoAstrolabeBox(self,0,nil,colorTabl,colorTabl1,colorTabl2,uiimBg,icon)
        else
            
            if state == 0 then
                imge:loadTexture(self.imageTable[index]["lock_image"])
                self.curLoakArea = index
                MsgManager:shwoAstrolabeBox( self,1,self.lockCall,colorTabl,colorTabl1,colorTabl2,uiimBg,icon)
            else
                imge:loadTexture(self.imageTable[index]["checked"])
                self.curAreaIndex = index
            end
        end
    else
            imge:loadTexture(self.imageTable[index]["lock_image"])
            MsgManager:shwoAstrolabeBox( self,0,nil,colorTabl,colorTabl1,colorTabl2,uiimBg,icon)
    end
    self:setLabelImage()
end
--点击解锁的回调
function AstrolabeMainLayer:lockCall( ... )
    print("AstrolabeMainLayer:lockCall")
    local tempData = { 
        rpc      = "hero_astrolabe_area_unlock",
        hero_id  = self.hero_id,
        area_id =  self.curLoakArea ,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --刷新次界面
            self.curAreaIndex = self.curLoakArea
            self.serverData = data
            self:refreshData()
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
           
        end)
    end,
    true)
end

function AstrolabeMainLayer:setUiData( ... )
    self:setLvExp()
    self:setPoint()
    self:setLabelImage()
    self:touchClick()
end
--设置等级和经验条
function AstrolabeMainLayer:setLvExp( ... )
    self.lvEx:setVisible(false)
    self.expBar2:setVisible(false)
    self.expBar:setVisible(true)
    self.lv:setString(UITool.ToLocalization("星盘等级")..self.serverData["astrolabe"]["lv"])
       --等级经验条
    local exp    = self.serverData["astrolabe"]["exp"]
    local maxexp = hero_astrolabe[self.hero_sub_id]["upgrade"][self.serverData["astrolabe"]["lv"]][2]
    local maxLvLimit   = hero_astrolabe[self.hero_sub_id]["areas"][self.curAreaIndex]["level_max"]
    local exPMax = hero_astrolabe[self.hero_sub_id]["upgrade"][maxLvLimit - 1][2]
    if self.serverData["astrolabe"]["lv"] >= maxLvLimit then
        self:toolBar(self.expBar,100,100)
       -- self.expText:setString(exPMax.."/"..exPMax)
       self.expText:setVisible(false)
    else
        self.expText:setVisible(true)
        self:toolBar(self.expBar,exp,maxexp)
        self.expText:setString(tostring(exp).."/"..tostring(maxexp))
    end

end
--进度条的封装
function AstrolabeMainLayer:toolBar( selfNode,nowNum,totalNum )
    local prent = nowNum*100/totalNum
    selfNode:setPercent(prent)
end
--设置待分配点数和扩张点数
function AstrolabeMainLayer:setPoint( ... )
    self.pointText:setAnchorPoint(cc.p(0,0.5))
    self.pointText:setPositionX(15)
    self.point:setString(""..self.serverData["astrolabe"]["asp_left"])
    --最大扩充次数*固定增加点数  - 吃道具加的点数  = 等于剩余的点数
    local exPt = hero_astrolabe[self.hero_sub_id]["use_item_max"]* self.pointAdd - self.serverData["astrolabe"]["asp_add"]
    self.pointEx:setString(tostring(exPt))
end
--设置标签页显示的图片状态
function AstrolabeMainLayer:setLabelImage( ... )
    for i = 1,  self.maxArea do
        local curTable  = hero_astrolabe[self.hero_sub_id]["areas"][i]
        local asB       = self:andTrue(curTable["astro_unlock"])
        local imge      = self.panelMain:getChildByName("Image_"..i)
        imge:setTouchEnabled(true)
        local state     = self.serverData["astrolabe"]["astr_area"][tostring(i)]["state"]
        if asB then
            if state == 0 then
                imge:loadTexture(self.imageTable[i]["lock_image"])
            else
                if self.curAreaIndex == i then
                    imge:loadTexture(self.imageTable[i]["checked"])
          
                    self:showCurArea(self.curAreaIndex)
                else
                    imge:loadTexture(self.imageTable[i]["unlock_image"])
                end
            end
        else
            imge:loadTexture(self.imageTable[i]["lock_image"])
        end

    end
    
end
-- 显示当前的区域
function AstrolabeMainLayer:showCurArea(_index)
    local node = nil
    for i = 1,self.maxArea do
        if i == _index then
            local maxLvLimit = hero_astrolabe[self.hero_sub_id]["areas"][_index]["level_max"]
            local exPMax     = hero_astrolabe[self.hero_sub_id]["upgrade"][maxLvLimit - 1][2]
            local exp        = self.serverData["astrolabe"]["exp"]
            local maxexp     = hero_astrolabe[self.hero_sub_id]["upgrade"][self.serverData["astrolabe"]["lv"]][2]
            if self.serverData["astrolabe"]["lv"] >= maxLvLimit then
                self:toolBar(self.expBar,100,100)
                --self.expText:setString(exPMax.."/"..exPMax)
                self.expText:setVisible(false)
            else
                self.expText:setVisible(true)
                self:toolBar(self.expBar,exp,maxexp)
                self.expText:setString(tostring(exp).."/"..tostring(maxexp))
            end
            node = self._csNode:getChildByName("Panel_astrobe"..i)
            node:setVisible(true)
            local spinNode = node:getChildByName("Image_bg")
            self:clearFullEffec()
            self:playBgEffc(spinNode)
        else
             self._csNode:getChildByName("Panel_astrobe"..i):setVisible(false)
            
        end
    end
    self:toAstrobeAreaBase(node)
end
--播放星盘背景特效
function AstrolabeMainLayer:playBgEffc(spinNode)
    local spineRoot = spinNode
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
    end 
    if self.skeletonNode then
        print("播放的视频错误 值没清空")
    else
        print("播放的视频正确 从新复制")
    end
    local id_str = "res/uifile/n_UIShare/astrolabe/xing_pan_bei_jing/xing_pan_bei_jing.atlas"--title_conf[tonumber(item_id)].res_spine
    if cc.FileUtils:getInstance():isFileExist(id_str) then 
        self.skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(id_str))
        local size = spineRoot:getSize()
        self.skeletonNode:setPosition(640,360)--size.width/2+2,size.height/2
        -- self.skeletonNode:registerSpineEventHandler(
        --     function (event) 
        --         self.baseSelf.refreshCallFunc(self.baseSelf.newRoleStarSelf)
        -- end, sp.EventType.ANIMATION_END)
        
        spineRoot:addChild(self.skeletonNode,123)
        self.skeletonNode:addAnimation(1,"effect",true)
        
    else 
          print("文件不存在 error file not exist:"..id_str)
    end
    
end
--本界面的刷新
function AstrolabeMainLayer:refreshData( ... )
    self:showImageTl()
    self:setUiData()
end
--其他界面有操作 需要要刷新数据的调用此函数
function AstrolabeMainLayer:refreshServer( ... )
        local tempData = { 
            rpc = "hero_astrolabe_info",
            hero_id = self.hero_id,
        }
        GameManagerInst:rpc(tempData,3,
        function(data)
            --刷新次界面

            self.serverData = data
            self:refreshData()
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText,function()
               
            end)
        end,
        true)
end
function AstrolabeMainLayer:toAstrobeAreaBase(node)
    print("toAstrobeAreaBase  toAstrobeAreaBase")
    local sData = {}
    sData["curAreaIndex"]    = self.curAreaIndex
    sData["severData"]       = self.serverData
    sData["roleData"]        = self.roleData
    sData["_type"]           = 1
    sData["hero_id"]         = self.hero_id
    sData["rootNode"]        = node
    sData["refreshCallFunc"] = self.refreshServer
    sData["asrMianLaSelf"]   = self
    sData["newRoleStarSelf"] = self.newRoleStarSelf
    AstrolabeAreaBase:init(sData)
end
--等级是否达成
function AstrolabeMainLayer:AsbLockStrLv( _tabel )
    local andTable = _tabel
    local strTable = {}
    if  andTable.astro_lv  > 0 then

        strTable["color"] = self:GetTextColor( self.serverData["astrolabe"]["lv"],andTable.astro_lv)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2004]),andTable.astro_lv)
        return strTable
    end
    return nil
end
--每区的技能点是否加满
function AstrolabeMainLayer:AsbLockStrSkill(areaIndex,isfull)
    local  isfull = isfull
    if areaIndex == 1 then  -- 一区不需要此条件
        return nil
    else

        local str = hero_astrolabe[self.hero_sub_id]["areas"][areaIndex -1 ]["name"]
        --local catstr = UITool.ToLocalization("解锁")..UITool.getUserLanguage(str)..UITool.ToLocalization("所有属性")
        local catstr = string.format(UITool.ToLocalization("解锁%s所有属性"),UITool.getUserLanguage(str))
        local strTable = {}
        print("fffffffffffffff")
        if isfull == 0 then
            strTable["color"] = cc.c3b(197, 37, 37)
        else
            strTable["color"] = cc.c3b(255, 231, 145)
        end
        strTable["str"] = catstr
        return strTable
    end
end
--拼接字符
function AstrolabeMainLayer:AsbLockStr( _tabel )
    -- body
    local andTable = _tabel

    local strTable = {}
    if  andTable.hero_lv  > 0 then

        strTable["color"] = self:GetTextColor( self.roleData.hero_lv,andTable.hero_lv)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2000]),andTable.hero_lv)
        return strTable
    end

    if andTable.hero_lv > 0 then
        strTable["color"] = self:GetTextColor( self.roleData.hero_lv,andTable.hero_lv)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2000]),andTable.hero_lv)
        return strTable
    end

    if andTable.hero_add > 0 then

        strTable["color"] = self:GetTextColor( self.roleData.hero_add,andTable.hero_add)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2001]),andTable.hero_add)
        return strTable
    end
    if andTable.feeling_lv > 0 then

        strTable["color"] = self:GetTextColor( self.roleData.feeling_lv,andTable.feeling_lv)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2002]),andTable.feeling_lv)
        return strTable
    end
    if andTable.soul_lv > 0 then
        strTable["color"] = self:GetTextColor( self.roleData.soul_lv,andTable.soul_lv)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2003]),andTable.soul_lv)
        return strTable
    end
    if andTable.astro_lv > 0 then

        strTable["color"] = self:GetTextColor( self.serverData["astrolabe"]["lv"],andTable.astro_lv)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2004]),andTable.astro_lv)
        return strTable
    end
    if andTable.hero_sk_add > 0 then

        strTable["color"] = self:GetTextColor( self.roleData.hero_sk_add,andTable.hero_sk_add)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2005]),andTable.hero_sk_add)
        return strTable
    end
    if andTable.astro_sk_add > 0 then

        strTable["color"] = self:GetTextColor( self.serverData["astrolabe"]["used_items"],andTable.astro_sk_add)
        strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2006]),andTable.astro_sk_add)
        return strTable
    end
    return nil
 
end
function AstrolabeMainLayer:GetTextColor( a,b )
    -- body
    if a < b then
        return cc.c3b(197, 37, 37)
    else
        return cc.c3b(255, 231, 145)
    end
end

--与的判断条件 ID的判断
function AstrolabeMainLayer:andTrue( _tabel )
    -- body
    local andTable = _tabel
    if self.roleData.hero_lv >= andTable.hero_lv and self.roleData.hero_add >= andTable.hero_add and
        self.roleData.feeling_lv >= andTable.feeling_lv and self.roleData.soul_lv >= andTable.soul_lv and
        self.serverData["astrolabe"]["lv"] >= andTable.astro_lv and self.roleData.hero_sk_add and andTable.hero_sk_add and
        self.serverData["astrolabe"]["used_items"] >= andTable.astro_sk_add then
        return true
    else
        return false
    end
 
end

