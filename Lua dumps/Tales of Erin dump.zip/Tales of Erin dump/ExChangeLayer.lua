require "BasicLayer"

ExChangeLayer= class("ExChangeLayer",BasicLayer)
ExChangeLayer.__index      = ExChangeLayer
ExChangeLayer.lClass       = 2
ExChangeLayer.ListView     = nil
ExChangeLayer.tableItem    = nil


function ExChangeLayer:init()

    local node =cc.CSLoader:createNode("ExChangeLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.sManager.rootStop = self

    local btnExchange  = node:getChildByName("Image_Exchange")
    btnExchange:loadTexture("res/uifile/n_UIShare/forge/xlzz_b_006_2.png")
    self:initSend()

    local node   = self.uiLayer:getChildByTag(2)

    local listName = node:getChildByName("Text_num")    -- 列表名称
    listName:setString("")

    local Goldbg = node:getChildByName("Image_goldbg") 
    local gold   = Goldbg:getChildByName("Text_goldnum") -- 金币
    gold:setString("")
    local gemBg  = node:getChildByName("Image_gembg")    -- 星石
    local gem    = gemBg:getChildByName("Text_gemNum")
    gem:setString("")
end

function ExChangeLayer:refreshtable( ... )
    -- body

     self:initSend()
end
function ExChangeLayer:initSend( ... )
    -- body
    --self.tableItem  = nil
    local function reiceSellCallBack(data)
        print("收到兑换列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())

        --GameManagerInst:saveToFile("ExChangeLayer.json",t_data)

        if t_data == nil then 
           MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
           --MsgManager:showSimpMsg(t_data["data"]["warning"])
           MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
        return
        end
        self.tableItem  = t_data["data"]["list"]
        self:initPro()
        self:sortCasting()
        --self:initCastingItem()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "exchange_shop_list",

    }


    local mydata =  cjson.encode(tempTable)
    print(":********************")
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSellCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 显示红点
function ExChangeLayer:showHongdian( ... )
    -- body
    local ishsow = false
    print("#self.tableItem  == "..#self.tableItem )
    for i = 1 ,#self.tableItem do
        if self.tableItem[i]["building_state"] == 2 then
            ishsow = true
        end
        print("self.tableItem[i] building_state == "..self.tableItem[i]["building_state"] )
    end
    local node   = self.uiLayer:getChildByTag(2)
    local btnForge  = node:getChildByName("Image_forge")
    if ishsow == true then
        UITool.setCommmonBtnRedDop(btnForge,true,cc.p(137,66))
    else
         UITool.setCommmonBtnRedDop(btnForge,false)
    end
end
function ExChangeLayer:initPro( ... )
	-- body
	local node   = self.uiLayer:getChildByTag(2)

	local listName = node:getChildByName("Text_num")    -- 列表名称
    listName:setString(UITool.ToLocalization("兑换列表"))

	local Goldbg = node:getChildByName("Image_goldbg") 
	local gold   = Goldbg:getChildByName("Text_goldnum") -- 金币
	gold:setString(user_info["gold"])
	local gemBg  = node:getChildByName("Image_gembg")    -- 星石
	local gem    = gemBg:getChildByName("Text_gemNum")
	gem:setString(user_info["gem"])
	self.ListView = node:getChildByName("ListView_1")
    local function touchCallBack(sender,eventType)
       if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Image_bag"  then
               self:callBag()
            elseif sender:getName() == "Button_info" then
               self:ShowUiInfo()
            elseif sender:getName() == "Image_forge" then
               self:callForge()
           elseif sender:getName() == "Image_Reforge" then
               self:callReforge()
            else
               self:returnBack()
            end
       end
    end
    local btn    = node:getChildByName("Button_close")
    btn:addTouchEventListener(touchCallBack)
    btn:setEffectType(3)

    local btnBag  = node:getChildByName("Image_bag")
    btnBag:addTouchEventListener(touchCallBack)

    local btnForge  = node:getChildByName("Image_forge")
    btnForge:addTouchEventListener(touchCallBack)

    local btnReforge  = node:getChildByName("Image_Reforge")
    btnReforge:addTouchEventListener(touchCallBack)

    local ButtonInfo = node:getChildByName("Button_info")
    ButtonInfo:addTouchEventListener(touchCallBack)
    ButtonInfo:setVisible(false) --铸造界面没有帮助页面，隐藏
end
-- /*说明按钮的回调函数*/
function ExChangeLayer:ShowUiInfo( ... )
    -- -- body
    --     --铸造
    --     local data = {}
    --     data.pictures = { --一张或者多张
    --         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_024.png",
    --     }
    --     SceneManager:toGuidePictureLayer(data)
end

function ExChangeLayer:callBag( ... )
    -- body
    local sData = {}
    sData["back"] = "Exchange"
    --self.rData["back"] = "forge"
    SceneManager:toBagLayer(sData)--self.rData
    self:beforeReturnBack()
end

function ExChangeLayer:callForge( ... )
    -- body
    local sData = {}
    sData["back"] = "Exchange"
    --self.rData["back"] = "forge"
    SceneManager:toECastingLayer(sData)--self.rData
    self:beforeReturnBack()
end

-- 去往轮回重铸
function ExChangeLayer:callReforge( ... )
    -- body

    --self.rData["back"] = "bag"
    local sData = {}
    sData["back"] = "Exchange"
    SceneManager:toReforgeLayer(sData)--self.rData
    self:beforeReturnBack()

end

function ExChangeLayer:beforeReturnBack()
    -- body
    self.exist = false
    SceneManager:removeFromNavNodes(self)
    self.sData = {}
    self.rData = {}
    self.sManager.rootStop = nil
    self.ListView   = nil
    self.tableItem  = nil
    self.tag = nil 
    self:clear()
end

function ExChangeLayer:SendExChange(nTargetId)
    -- body
    local function reiceSellCallBack(data)
        print("兑换完成,收取道具")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())

        --GameManagerInst:saveToFile("exchange_shop_get.json",t_data)

        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            
             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))     
            return
        end
        self.sData = {}
        self.rData = {}
        self.ListView   = nil
        self.tableItem  = nil
        self:refreshtable()

        GameManagerInst:alert(UITool.ToLocalization("兑换成功"))
        -- 
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"] = "exchange_shop_get",
        ["item_id"]  = nTargetId

    }
    local mydata =  cjson.encode(tempTable)
    print(":********************")
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSellCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function ExChangeLayer:initCastingItem( ... )
	-- body
	local layout_list = ccui.Layout:create()
	local item        = cc.CSLoader:createNode("ExChangeNode.csb")
	local itemMode    = item:getChildByName("Panel_2")
	layout_list:setContentSize(694,164)
    layout_list:setHighlighted(false)
	layout_list:setTouchEnabled(true)
	local itemModeC   = itemMode:clone()
	layout_list:addChild(itemModeC)
    self.ListView:setItemModel(layout_list)

    local len = #self.tableItem
    for i = 1 , len do
    	self.ListView:pushBackDefaultItem()
    end

    for i = 1 , len do
    	local tab     = self.tableItem[i]
    	local itemEl  = self.ListView:getItem(i - 1)
        local item_1  = itemEl:getChildByName("Panel_2")
    	-----------------铸造物品显示的属性--------------

        local TagetMatData = mat[tab.reward_id]

        local TargetIconPanel = item_1:getChildByName("TargetIconPanel")   -- 兑换目标图片
    	local ImageIcon = TargetIconPanel:getChildByName("Image_icon")   -- 图片



        -- 兑换目标图片
        local iconImagePath = TagetMatData.icon
        if iconImagePath then
            local path = "icons/mat/"..iconImagePath
            if ImageIcon then
                ImageIcon:loadTexture(path)

            end       
        end

        local targetImageRarity= TargetIconPanel:getChildByName("Image_upFrame")
        local targetRarityPath = Rarity_mat[TagetMatData["rarity"]]   --外框
        if targetRarityPath then
            if targetImageRarity then
                targetImageRarity:loadTexture(targetRarityPath)
            end
        end
        -------------------兑换目标物品框响应事件---------------
        local function TargetCallBackEvent( sender,eventType )
          -- body
            if eventType == ccui.TouchEventType.ended then
                MsgManager:showSimpItemInfoAndDropInfo(tab.reward_type,tab.reward_id,true,self.refreshtable,self)
            end
        end
        ImageIcon:addTouchEventListener(TargetCallBackEvent)
        -- 兑换按钮
        local Button_ExChange = item_1:getChildByName("Button_ExChange")   -- 兑换按钮
        Button_ExChange:addClickEventListener(function()
            self:SendExChange(i)
        end)




        -- 兑换目标名称
    	local dec       = item_1:getChildByName("lbDec")
        local sName = UITool.getUserLanguage(TagetMatData.name) --TagetMatData.name
        if sName then
            dec:setString(sName)
        end
        -- 库存
        local lbStock = item_1:getChildByName("lbStock")
        lbStock:setString(UITool.ToLocalization("库存：")..tab.can_change_num)

        -----
        -- "need_list":[[5,1001,1],[5,1005,1],[5,1009,1],[5,1013,1],[5,1017,1]], # 需要的素材类型以及数量
        --兑换需求列表
        local needList = table.deepcopy(tab["need_list"])

        -- "curr_list": [0,1,1,2,3],# 当前拥有与的素材数量
        --本地当前数据
        local curr_list = table.deepcopy(tab["curr_list"])

        local lenNeed = #needList
        local lenCur = #curr_list
        if lenCur ~= lenNeed then
            --数据数量不一致为非法数据 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack1)
            return
        end
        for m=1,lenNeed do
            local curMatNum = curr_list[m]
            local needMatIData = needList[m]
            local needMatNum = needMatIData[3]
            local matId = needMatIData[2]
            local matType = needMatIData[1]

            local Text_mat_num = item_1:getChildByName("Text_mat_"..m)
            if Text_mat_num then
                Text_mat_num:setString(curMatNum.."/"..needMatNum)
            end

            local needIconNode = item_1:getChildByName("matPanel_"..m)
            local needImageIcon = needIconNode:getChildByName("Image_3")
            
            local needMatData = mat[matId]
            local iconImagePath = needMatData.icon
            if iconImagePath then
                local path = "icons/mat/"..iconImagePath
                if needImageIcon then

                    needImageIcon:setUnifySizeEnabled(true)
                    needImageIcon:loadTexture(path)

                    local function CallBackEvent( sender,eventType )
                      -- body
                       if eventType == ccui.TouchEventType.ended then
                         print("素材 matType == "..matType)
                         MsgManager:showSimpItemInfoAndDropInfo(matType,matId,true,self.refreshtable,self)
                       end
                    end 
                    needImageIcon:addTouchEventListener(CallBackEvent)
                end       
            end

            local needImageRarity= needIconNode:getChildByName("Image_2")
            local iconRarityPath = Rarity_mat[needMatData["rarity"]]   --外框
            if iconRarityPath then
                if needImageRarity then
                    needImageRarity:loadTexture(iconRarityPath)
                end
            end


        end

        -- 添加显示加号
        for m=1,5 do
            local addIcon = item_1:getChildByName("spAdd_"..m)
            if m < lenNeed then
                if addIcon then
                    addIcon:setVisible(true)
                end
            else
                if addIcon then
                    addIcon:setVisible(false)
                end
            end

            local needIconNode = item_1:getChildByName("matPanel_"..m)
            local Text_mat_num = item_1:getChildByName("Text_mat_"..m)
            if m <= lenNeed then
                needIconNode:setVisible(true)
                Text_mat_num:setVisible(true)
            else
                needIconNode:setVisible(false)
                Text_mat_num:setVisible(false)
            end
        end
    end
end

function  ExChangeLayer:sortCasting( ... )
    -- body
    --self:showHongdian()
    self.ListView:removeAllChildren()
    self:initCastingItem()

end
-------------------刷新金币----------
function ExChangeLayer:rfsGold( ... )
    -- body
    local node   = self.uiLayer:getChildByTag(2)
    local Goldbg = node:getChildByName("Image_goldbg") 
    local gold   = Goldbg:getChildByName("Text_goldnum") -- 金币
    gold:setString(user_info["gold"])

end

function ExChangeLayer:returnBack( ... )
	-- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    -- if self.backFunc then
    --     self.backFunc(self.sManager,self.sData)
    -- end
    self.exist = false
    self.sData = {}
    self.rData = {}
    self.sManager.rootStop = nil
    self.ListView   = nil
    self.tableItem  = nil
    self.tag = nil 
    self:clear()
    SceneManager:toStartLayer()
    
end
-- 数据出错调用这个函数 ，直接返回首页
function ExChangeLayer:returnBack1( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    self.exist = false
    self.sData = {}
    self.rData = {}
    self.sManager.rootStop = nil
    self.ListView   = nil
    self.tableItem  = nil
    self.tag = nil 
    self:clear()
    SceneManager:toStartLayer()
end

function ExChangeLayer:create(rData)
    local login = ExChangeLayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end