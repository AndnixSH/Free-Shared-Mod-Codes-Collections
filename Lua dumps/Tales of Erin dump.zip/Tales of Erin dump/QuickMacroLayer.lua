--按键精灵 layer

-- require "QuickMacroTools"


QuickMacroLayer = class("QuickMacroLayer")

QuickMacroLayer.__index = QuickMacroLayer


function QuickMacroLayer:init( sData )
	self.uiLayer = cc.Layer:create()

    -- local sp = cc.Sprite:create("uifile/login/dlui006.png")
    -- self.uiLayer:addChild(sp)
    -- sp:setPosition(200,200)
    -- print("-----------QuickMacroLayer---init----------")
    
	-- self:addChild(self.uiLayer)
    local function onTouchBegin(touch,event)
        return true
    end

    local function onTouchMoved(touch,event)

    end

    local function onTouchEnded(touch,event)
        --获取点击位置，存储到当前检测数据类中
        local location = touch:getLocation()  
        print("-----------QuickMacroLayer..touch:---------------")
        QuickMacroTools:getInstance():addTouchPoint(location)

    end
    local listener = cc.EventListenerTouchOneByOne:create()
    --listener:setSwallowTouches(true)
    listener:registerScriptHandler(onTouchBegin,cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local dispacher = cc.Director:getInstance():getEventDispatcher()
    dispacher:addEventListenerWithSceneGraphPriority(listener,self.uiLayer)

end

function QuickMacroLayer:clear( ... )
	if self.uiLayer then 
		self.uiLayer:removeFromParent()
		self.uiLayer = nil 
	end 
end

function QuickMacroLayer:create( sData )
	local qm_layer = QuickMacroLayer.new()
	qm_layer:init()

	return qm_layer 
end