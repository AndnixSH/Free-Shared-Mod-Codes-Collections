--属性提升类的组件
--created by kobejaw.2018.6.8.
Com_B_AttributeUp = class("Com_B_AttributeUp",ComponentBase)

function Com_B_AttributeUp:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.AttributeUp
end

--开始生效。
--@isAdd 是否正向生效
function Com_B_AttributeUp:takeEffect(isAdd)
	--新规则
	if self.comId >= 81200 then
		print("新规则的buff组件，buffId =  "..self.comId)

		for i = 1,4 do
			local param = self.comData["effect"..i]
			if param ~= 0 and param ~= 1 then
				local attrId,attrValue = GetAttr_NewRule(param)
				if attrId then
					attrValue = attrValue * self.overlayNum
					if not isAdd then
						attrValue = -attrValue
					end
					self.target.attributeManager:changeAttr(attrId,attrValue)	
				else
					print("程序未实现这个组件.comID:  "..self.comId)
					return
				end
			end
		end
		--TODO,新规则那个表里的第一条，免疫的debuff列表。以后新英雄技能用到了再加。
		
	 --旧规则	
	else
		local attrId = GetAttrIdByComId(self.comId,self.level)
		--一个buff对应单属性的情况
		if attrId then 
			local attrValue = self.comData.effect1 * self.overlayNum
			if not isAdd then
				attrValue = -attrValue
			end
			self.target.attributeManager:changeAttr(attrId,attrValue)	
		--一个buff对应多个属性的情况
		else
			--高昂
			if self.comId == 81027 or self.comId == 81028 then
				local attrId1 = AE.add_atk
				local attrId2 = AE.add_defence
				local value1 = self.comData.effect1 * self.overlayNum
				local value2 = self.comData.effect2 * self.overlayNum
				if not isAdd then
					value1 = -value1 
					value2 = -value2 
				end
				self.target.attributeManager:changeAttr(attrId1,value1)	
				self.target.attributeManager:changeAttr(attrId2,value2)	
			--提升攻击力和暴击伤害
			elseif self.comId == 81049 then
				local attrId1 = AE.add_atk
				local attrId2 = AE.add_dmg_crit
				local value1 = self.comData.effect1 * self.overlayNum
				local value2 = self.comData.effect2 * self.overlayNum
				if not isAdd then
					value1 = -value1
					value2 = -value2
				end
				self.target.attributeManager:changeAttr(attrId1,value1)	
				self.target.attributeManager:changeAttr(attrId2,value2)	
			else
				print("程序未实现这个组件.comID:  "..self.comId)
				return				
			end
		end
	end

	self.super.takeEffect(self,isAdd)
end
