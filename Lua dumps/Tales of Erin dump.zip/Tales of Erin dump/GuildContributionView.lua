
--require "XUIView"

GuildContributionView = class("GuildContributionView" , XUIView)
GuildContributionView.CS_FILE_NAME = "GuildContributionView.csb"
GuildContributionView.CS_BIND_TABLE = 
{
    btnOK = "/i:292/i:295",
    panelList = "/i:292/s:panelList",
}
GuildContributionView.ITEM_FILE = "GuildContributionItemView.csb"
GuildContributionView.ITEM_TABLE = 
{
    panelMe = "/s:panelMe",
    lbNameMe = "/s:panelMe/s:lbNameMe",
    panelSB = "/s:panelSB",
    lbName = "/s:panelSB/s:lbName",
    lbLevel = "/i:280/s:lbLevel",
    imgFace = "/i:280/s:imgFace",
    lbGold = "/i:280/s:lbGold",
    imgPosition = "/i:280/s:imgPosition",
}

function GuildContributionView:initWithData(data)
    GuildContributionView.super.init(self)

    self.members_data = data
    self.btnOK:addClickEventListener(function()
        self:returnBack()
    end)
    
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,730,120)

    self.gridview.itemCreateEvent = function()
        local temp = XUICellView.new():init(nil,GuildContributionView.ITEM_FILE,GuildContributionView.ITEM_TABLE)
        
        temp.onResetData = function(self)
            --{"position":3,"uid":"user03","contribution":0,"rank":1,"name":"姬神天使马利","head":"13"}
                        
            self.imgFace:setVisible(true)
            self.imgPosition:setVisible(true)

            local hinfo = hero[tonumber(self._data["head"])]
            if hinfo then
                self.imgFace:setTexture(hinfo.hero_bat_icon)
            else
                self.imgFace:setVisible(false)
            end

            if self._data["position"] == 1 then
                self.imgPosition:setTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_003.png")
            elseif self._data["position"] == 2 then
                self.imgPosition:setTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_002.png")
            elseif self._data["position"] == 3 then
                self.imgPosition:setTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_001.png") -- 会长
            else
                self.imgPosition:setVisible(false)
            end
            
            if self._data["uid"] == user_info["id"] then
                self.panelMe:setVisible(true)
                self.panelSB:setVisible(false)
                self.lbNameMe:setString(self._data["name"])
            else
                self.panelMe:setVisible(false)
                self.panelSB:setVisible(true)
                self.lbName:setString(self._data["name"])
            end

            self.lbLevel:setString(""..self._data["rank"])
            if g_channel_control.transform_GuildContributionView_lbLevel_pos == true then
                local x = 392
                local y = 80
                self.lbLevel:setPosition(cc.p(x,y))
            end
            self.lbGold:setString(""..self._data["contribution"]..UITool.ToLocalization("积分"))

        end

        return temp
    end
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self.gridview:setDataSource(self.members_data)

    return  self
end

function GuildContributionView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end
