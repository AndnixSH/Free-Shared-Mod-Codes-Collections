--状态机
--created by kobejaw.2018.3.29.
EntityFSM = class("EntityFSM")

function EntityFSM:ctor(entity)
	self.entity = entity

	self:initAllStates(entity);

	self.currentState = self.stateList[StateEnum.Idling]
	self.previousState = self.stateList[StateEnum.Idling]		
end

function EntityFSM:initAllStates(entity)
	self.stateList = {}
	--注册各种状态实例，为防止频繁在脚本中创建和删除状态影响运行效率，这里保存所有状态
	
	self.stateList[StateEnum.PlayingSkill_Self] = State_PlayingSkill_Self.new(entity)
	self.stateList[StateEnum.PlayingSkill_Scene] = State_PlayingSkill_Scene.new(entity)
	self.stateList[StateEnum.PlayingSkill_StraightLine] = State_PlayingSkill_StraightLine.new(entity)
	self.stateList[StateEnum.PlayingSkill_Target_Entity] = State_PlayingSkill_Target_Entity.new(entity)
	self.stateList[StateEnum.PlayingSkill_Target_Pos] = State_PlayingSkill_Target_Pos.new(entity)
	self.stateList[StateEnum.UnusualCondition] = State_UnusualCondition.new(entity)
	self.stateList[StateEnum.Idling] = State_Idling.new(entity)
	self.stateList[StateEnum.Dead] = State_Dead.new(entity)

	--摆pose，目前只有尤娜用到了。
	if self.entity.entityType == 1 then
		self.stateList[StateEnum.Posing] = State_Posing.new(entity)
	end

	if self.entity.isBoss then
		self.stateList[StateEnum.Attacking_Boss] = State_Attacking_Boss.new(entity)
	else
		self.stateList[StateEnum.RunningToPosition] = State_RunningToPosition.new(entity)
		self.stateList[StateEnum.RunningToEnemy] = State_RunningToEnemy.new(entity)		
		self.stateList[StateEnum.Attacking] = State_Attacking.new(entity)
	end
end

--[[
@stateEnum  状态类型
@data 新状态所需数据
]]
function EntityFSM:changeState(enum,data)
	if self.entity.isDead then
		return
	end
	self.currentState:Exit();
	self.previousState = self.currentState
	self.currentState = self.stateList[enum]
	self.currentState:Enter(data);
end

--返回到上一个状态。（例如指定位置的移动过程中被打倒就会切换到异常状态，爬起来后回到移动状态）
function EntityFSM:revertToPreviousState()
	
end

--msg的结构：msg.data为需要用到的数据，msg.code为MsgType
function EntityFSM:onRecieveMessage(msg)
	if  msg.code == MsgType.RunToPos then
		local data = {}
		data.type = 1
		data.w,data.h = GetBoxWHByPoint(msg.data.x,msg.data.y)
		self:changeState(StateEnum.RunningToPosition,data)
	elseif msg.code == MsgType.RunToEnemy then
		local data = {}
		data.type = 2
		data.enemyEntity = msg.data
		self:changeState(StateEnum.RunningToEnemy,data)
	end
end

function EntityFSM:update(dt)
	if self.currentState.needUpdate and G_GameState < 3 then
		self.currentState:update(dt)
	end
end
