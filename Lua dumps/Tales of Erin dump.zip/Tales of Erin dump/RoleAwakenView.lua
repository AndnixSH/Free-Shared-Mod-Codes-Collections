--require "XUIView"
--require "REIconView"

RoleAwakenView = class("RoleAwakenView",XUIView)
RoleAwakenView.CS_FILE_NAME = "RoleAwakenView.csb"
RoleAwakenView.CS_BIND_TABLE = 
{
    panelEffect = "/i:118",
    effMagic = "/i:118/s:effMagic",
    effIcon = "/i:118/s:effIcon",
    effNum = "/i:118/s:effNum",
    effNum2 = "/i:118/s:effNum2",

    panelList = "/i:283/i:286",
    panelIcon = "/i:283/i:94",

    panelSort = "/i:283/s:panelSort",
    sortTitle = "/i:283/s:lbTitle",

    spAwakeLimit = "/i:283/i:1758",
    spAwakeMax = "/i:283/i:1757",
    panelLvUpInfo = "/i:283/i:1742",

    lbLvNow = "/i:283/i:1742/i:63/i:83",
    lbLvNew = "/i:283/i:1742/i:63/i:84",
    lbSP = "/i:283/i:1742/i:64/i:85",

    lbGoldCost = "/i:283/i:1742/i:105",
    lbGoldMax = "/i:283/i:1742/i:104",

    btnAwaken = "/i:283/i:301",
    btnHelp = "/i:283/s:btnHelp",

    matPanel1 = "/i:283/i:287",
    matIcon1 = "/i:283/i:287/i:290",
    matCurNum1 = "/i:283/i:287/i:1439",
    matNeedNum1 = "/i:283/i:287/i:1438",

    matPanel2 = "/i:283/i:292",
    matIcon2 = "/i:283/i:292/i:295",
    matCurNum2 = "/i:283/i:292/i:1441",
    matNeedNum2 = "/i:283/i:292/i:1440"
}

function RoleAwakenView:init()
    RoleAwakenView.super.init(self)

    self.panelEffect:setVisible(false)

    self.panelLvUpInfo:setVisible(true)
    self.spAwakeMax:setVisible(false)
    self.spAwakeLimit:setVisible(false)
    
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = RoleListItemView.new():init()
        
        temp.ClickEvent = function(item)
            local i = item:getIndex()
            self:setSelectedHero(i)

            if XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.RoleTP) then 
                XbTriggerGuideManager:showTriggerGuide(nil, 5, TriggerGuideConfig.RoleTP)
            end

        end

        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = self.sortBtnView:getSortMode() % 10
            item:setTitleMode(smode)
        end
        return temp
    end

    self.iconView = REIconView.new():init(self.panelIcon)
    self.iconView:showNoIcon()
    
    self:setSelectedHero()

    self.lbGoldMax:setString(""..user_info["gold"])
    
    self.btnAwaken:addClickEventListener(function()
        self:onRoleAwaken()
    end)

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)
    --排序
    self.sortBtnView = SortButtonView.new():init(self.panelSort,"role_t",814,0)
    self.sortBtnView.sortModeChangedEvent = function()
        self:refresh()
    end
    --
    self.matPanel1:setTouchEnabled(true)
    self.matPanel2:setTouchEnabled(true)


    if g_channel_control.transform_RoleAwakenView_lbTitle_fontSize == true  then
        self.sortTitle:setFontSize(20)
    end

    return self
end
--角色突破。潜能解放说明
function RoleAwakenView:showGuidePicLayer( ... )
    local data = {}
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_jsjf_001.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function RoleAwakenView:setSelectedHero(i)
    if  i then    
        self.currentIndex = i
        if self.currentDataSource and self.currentDataSource[self.currentIndex] then
            local data = self.currentDataSource[self.currentIndex]
            local h_id_num = getNumID( data["id"] )
            --local h_id_str = getStrID( data["id"] )
            if g_channel_control.b_LikeState then
                self.iconView:showHero(h_id_num,data["like_feel_state"]["icon_state"])
            else
                self.iconView:showHero(h_id_num)
            end
        end  
        self:refreshPropNum()
    else
        self.currentIndex = nil
        
        self.iconView:showNoIcon()

        self:refreshPropNum()
    end
end

function RoleAwakenView:AwakenMaxLimit(bMax,bLimit)--参数1:是否满解放，参数2:是否达到4解放
    if bMax then
        self.panelLvUpInfo:setVisible(false)
        self.spAwakeMax:setVisible(true)
        self.spAwakeLimit:setVisible(false)
    else
        self.spAwakeMax:setVisible(false)
        if bLimit then
            local bLimit5 = 0
            local hero_data = self.currentDataSource[self.currentIndex]
            if hero_data then
                bLimit5 = hero_data.break5_unlocked
            end
            if bLimit5 and bLimit5 == 1 then
                self.spAwakeLimit:setVisible(false)
                self.panelLvUpInfo:setVisible(true)
            else
                self.spAwakeLimit:setVisible(true)
                self.panelLvUpInfo:setVisible(false)
                --
                self.bCanAwaken = false
                self.btnAwaken:setTouchEnabled(false)
                self.btnAwaken:setBright(false)
            end
        else
            self.panelLvUpInfo:setVisible(true)
            self.spAwakeLimit:setVisible(false)
        end
    end
end

function RoleAwakenView:refreshPropNum()
    --FFECA0

    self.matPanel1:setVisible(false)
    self.matPanel1:addTouchEventListener(function()end)
    self.matPanel2:setVisible(false)
    self.matPanel2:addTouchEventListener(function()end)

    self.lbLvNew:setString("")
    self.lbLvNow:setString("")
    self.lbSP:setString("")

    if self.currentIndex then
        local data = self.currentDataSource[self.currentIndex]
        local h_id_num = getNumID( data["id"] )

        local break_count = data.break_count
        local break_limit = hero[h_id_num]["hero_break"].total_break

        --
        

        if break_count == break_limit then
            --满破
            -- self.matPanel1:setVisible(false)
            -- self.matPanel2:setVisible(false)
            self.bCanAwaken = false
            self.lbLvNow:setString("")
            self.lbLvNew:setString("")
            self.lbSP:setString("")
            
            --self.btnAwaken:setVisible(false)

            self.btnAwaken:setTouchEnabled(false)
            self.btnAwaken:setBright(false)

            self.lbGoldCost:setString("0")
        else
            local brkInfo = hero[h_id_num]["hero_break"]["break_"..(break_count + 1)]
	        local mat_count = #brkInfo["break_mat"]
            --if mat_count > 2 then mat_count = 2 end
            for i = 1,mat_count do

                self["matPanel"..i]:setVisible(true)
                local mat_id = brkInfo["break_mat"][i].mat_id
                local mat_id_num = getMatID(mat_id)
                local mat_num = brkInfo["break_mat"][i].mat_num

                self["matPanel"..i]:addTouchEventListener(function(sender,eventType)
                    if eventType == ccui.TouchEventType.ended then
                        if GameManagerInst.gameType == 2 then
                            MsgManager:showSimpItemInfoAndDropInfo(5,mat_id_num,true,self.onMatChanged,self)
                        end
                    end
                end)

                local mat_face = mat[mat_id_num]["icon"]
                if mat_face then
                    self["matIcon"..i]:setTexture("icons/mat/"..mat_face)
                end
                self["matNeedNum"..i]:setString(""..mat_num)

                local have_count = user_info["bag"]["mat"][mat_id]
                if have_count == nil then have_count = 0 end

                self["matCurNum"..i]:setString(""..have_count)
                if have_count < mat_num then
                    --不够
                    self["matCurNum"..i]:setTextColor(cc.c3b(255,0,0))
                else
                    self["matCurNum"..i]:setTextColor(cc.c3b(255,236,160))
                end
            end

            self.bCanAwaken = true
            self.lbLvNow:setString(""..data["Lv_max"])
            self.lbLvNew:setString(""..brkInfo["break_maxlv"])
            self.lbSP:setString(""..brkInfo["break_add_tp"])
            
            --self.btnAwaken:setVisible(true)

            self.btnAwaken:setTouchEnabled(true)
            self.btnAwaken:setBright(true)

            --显示钱

            self.lbGoldCost:setString(""..brkInfo["break_gold"])

        end
        self:AwakenMaxLimit((break_count >= break_limit),(break_count >= 4))

    else
        self.bCanAwaken = nil
        --未选择角色
        self.lbLvNow:setString("")
        self.lbLvNew:setString("")
        self.lbSP:setString("")

        --self.btnAwaken:setVisible(false)

        self.btnAwaken:setTouchEnabled(false)
        self.btnAwaken:setBright(false)

        self.lbGoldCost:setString("0")
    end

end

function RoleAwakenView:onMatChanged()
    if self.matChangedEvent then
        self.matChangedEvent(self)
    end
end

function RoleAwakenView:playEffect()
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)

    local effs = {
        {self.effIcon,"EffAwkFrame.csb"},
        {self.effMagic,"EffAwkMagic.csb"},
        {self.effNum,"EffAwkNum.csb"},
        {self.effNum2,"EffAwkNum.csb"}
    }

    for i = 1,#effs do
        local node_1 = cc.CSLoader:createNode(effs[i][2])
        local timeline_1 =cc.CSLoader:createTimeline(effs[i][2])
        node_1:setTag(123)
        local psize = effs[i][1]:getSize()
        node_1:setPosition(cc.p(psize.width/2,0))
        effs[i][1]:addChild(node_1)

        node_1:runAction(timeline_1)
        timeline_1:play("animation0",false) 
        timeline_1:setLastFrameCallFunc(function ()
            node_1:stopAllActions()
            node_1:removeFromParent()
        end)
    end
              
    --    cc.SimpleAudioEngine:getInstance():playEffect("music/ui/tupo.mp3", false)  
    AudioManager:shareDataManager():playMusic("music/ui/tupo.mp3",0, false)   
     
    local delay = cc.DelayTime:create(1.3)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:stopEffect()
    end))
    self.panelEffect:runAction(sequence)    
end

function RoleAwakenView:stopEffect()
    KeyboardManager._isShowEffect = false
    self.panelEffect:stopAllActions()

    local effs = {
        self.effIcon,
        self.effMagic,
        self.effNum,
        self.effNum2
    }

    for i = 1,#effs do
        local e = effs[i]:getChildByTag(123)
        if e then e:stopAllActions() end
        effs[i]:removeAllChildren()
    end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    
    if self.effectStopedEvent then
        self.effectStopedEvent(self)
    end
    
    self:refresh()
    
    XbTriggerGuideManager:finishGuide(TriggerGuideConfig.RoleTP, self)

end

function RoleAwakenView:onRoleAwaken()
    if not self.bCanAwaken then return end

    if self.currentIndex then
        local ddd = self.currentDataSource[self.currentIndex]
        local tempId = ddd.id
        
        GameManagerInst:rpc(
            {
                rpc = "hero_brk",
                target_hero_id = tempId
            },3,
            function(data)            
                --success
                DataManager:roleBthEnd(tempId, data) 
                -- self.sManager.menuLayer:RefshTopBar()
                -- hero_info[self.n_h_id] = t_data["data"]["data"][self.n_h_id]
                -- self.eMsg = nil	

                if  #data["data"][tempId]["team_list"] > 0  then
                    self:loadTeamList(function()
                        self:playEffect()
                    end)
                else
                    self:playEffect()
                end
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText)
            end,
            true)
    end
end

function RoleAwakenView:loadTeamList(callback)

    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success
        DataManager:wTeamData(data["team"])   

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleAwakenView:getDataSource()
    local ds = {}

    for i = 1,#hero_list do
        local data = hero_list[i]
        local h_id_num = getNumID( data["id"] )
        local break_count = data.break_count
        local break_limit = hero[h_id_num]["hero_break"].total_break
        if break_count < break_limit then
            table.insert(ds,hero_list[i])
        end
    end

    SortBoxView.SortRole (ds, self.sortBtnView:getSortMode(),true)

    return ds
end

function RoleAwakenView:refresh()
    --先排序，后刷列表 
    local tempid = nil

    if self.currentDataSource and self.currentIndex and self.currentDataSource[self.currentIndex] then
        tempid = self.currentDataSource[self.currentIndex].id
    end
    
    self.currentDataSource = self:getDataSource()
    self.gridview:setDataSource(self.currentDataSource)

    local tempindex = nil

    if tempid then
        for i = 1,#self.currentDataSource do
            if self.currentDataSource[i].id == tempid then
                tempindex = i
                break
            end
        end
    end

    self:setSelectedHero(tempindex)

    
    self.lbGoldMax:setString(""..user_info["gold"])
end