key = {}   
key[1] = {
    name = "强化钥匙",
    rarity = 4,
    icon = "mat_406.png",
    desc = "散发着七彩光芒的神秘钥匙",
    desc_simple = "这个东西长智商",
    sell_type = 0,
    sell_num = -1,
}    
key[2] = {
    name = "金币钥匙",
    rarity = 4,
    icon = "mat_407.png",
    desc = "散发着七彩光芒的神秘钥匙",
    desc_simple = "这个东西长智商",
    sell_type = 0,
    sell_num = -1,
}   