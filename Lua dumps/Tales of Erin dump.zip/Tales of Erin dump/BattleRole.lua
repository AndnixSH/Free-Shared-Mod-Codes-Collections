--角色类
--created by kobejaw.2018.3.22.
BattleRole = class("BattleRole",EntityBase)

function BattleRole:ctor(data,teamManager)
	self.entityType = BattleGlobals.EntityType.Role
	self.super.ctor(self,data,teamManager)

	self:initMemberVariables(data)
	self:createSpineNode();
	self:initSpineListeners() -- 初始化spine事件监听

	self.hpBar = HPBar:create(self)
	self:addChild(self.hpBar)
end

function BattleRole:initMemberVariables(data)
	self.faceTo = BattleGlobals.FaceRight
	self:setTeammateAndEnemyList()
	
	self.skill = {} --控制面板上的两个技能
	--设置触摸框信息和角色中心点坐标
	self:setTouchRectInfo()
	
	--音效资源
	--boss特有：死亡
	--角色和小怪都有：普攻
	--角色和boss都有：战斗开始
	--角色特有：战斗胜利，战斗失败。

	local heroId = data.heroId
	if self.data.hitSound and self.data.hitSound ~= "" then
		self.sound_normalAtk = self.data.hitSound
	else
		self.sound_normalAtk = hero[heroId].hero_vce[3]
	end

	self.sound_battleStart = hero[heroId].hero_vce[7]
	self.sound_win = hero[heroId].hero_vce[8]
	self.sound_lose = hero[heroId].hero_vce[9]

	self.fsm = EntityFSM.new(self);
end

function BattleRole:createSpineNode()
	local spineData = BattleCacheManager:getData(self.data.spineFullPath)
	local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
	self.spineNode = spineNode;

	self:addChild(spineNode)
	self:setPosition(cc.p(self.data.initialPos.x,self.data.initialPos.y))

	self.box_w,self.box_h = GetBoxWHByPoint(self.data.initialPos.x,self.data.initialPos.y)--设置位置信息

	self.fsm:changeState(StateEnum.Idling)

	--buff特效的父节点
	self.effectNode = cc.Node:create()
	self.effectNode:setPosition(cc.p(0,(self.touchRect[2] + self.touchRect[4])/2))
	self:addChild(self.effectNode)
end

function BattleRole:update(dt)
	if G_GameState == 1 then
		self.deltaForUpdate = self.deltaForUpdate + dt
		self.idxForUpdate = self.idxForUpdate + 1

		if self.idxForUpdate == 2 then
			--组件管理器更新
			self.componentManager:update(self.deltaForUpdate)
			--触发器管理器更新
			self.triggerManager:update(self.deltaForUpdate)

			self.idxForUpdate = 0
			self.deltaForUpdate = 0
		end
	end
end

function BattleRole:onDead()
	--如果此时处于变技能状态，先变回初始技能
	for i = 1,2 do
		if self.skill[i].isChanged then
			self.skill[i]:changeBackSkill()
		end
	end

	self.skillPanel:setVisible(false)
	G_EntityLayer:setNoOneChosen()

	if self.fsm.currentState.stateEnum == StateEnum.UnusualCondition and self.fsm.currentState.stateType ~= 5 and not self.fsm.currentState.isStandingUp then
		--do nothing,落地后再检测
	else
		self.fsm:changeState(StateEnum.Dead)
	end
end

--监测是否所有敌人都死了
function BattleRole:checkIsAllEnemiesDead()
	if BattleRuntimeInfo.team2EntityNum <= 0 then
		self.fsm:changeState(StateEnum.Idling)
		return true
	else
		return false
	end
end

--格子是否可进入
function BattleRole:checkBoxAvailableByWH(w,h)
	for k,v in ipairs(G_Monsters) do
		if not v.isDead and w == v.box_w and h == v.box_h then
			return false
		end
	end

	for k,v in ipairs(G_Roles) do
		if v ~= self and not v.isDead and w == v.box_w and h == v.box_h then
			if v.fsm.currentState.stateEnum ~= StateEnum.RunningToEnemy and v.fsm.currentState.stateEnum ~= StateEnum.RunningToPosition then
				return false
			end
		end
	end

	return true	
end
--格子是否可进入
function BattleRole:checkBoxAvailableByIdx(idx)

	local num = 0;
	local isCurrentWH = false
	if w == self.box_w and h == self.box_h then
		isCurrentWH = true
	end

	for k,v in ipairs(G_Monsters) do
		if not v.isDead and w == v.box_w and h == v.box_h then
			num = num + 1
		end
	end

	if isCurrentWH and num >= 3 then
		return false
	elseif not isCurrentWH and num >= 2 then
		return false
	end

	for k,v in ipairs(G_Roles) do
		if not v.isDead and idx == v.box_w*3 + v.box_h then
			return false
		end
	end

	return true
end
--检测射程内的敌人数量
function BattleRole:checkEnemyNumInRange()
	local num = 0;
	for k,v in ipairs(G_Monsters) do
		if not v.isDead and self.fsm.currentState:checkIsEnemyInRange(v) then
			num = num + 1;
		end
	end
	return num;
end

--复活
function BattleRole:revive()
	self.deltaForUpdate = 0
	self.idxForUpdate = 1

	self.isDead = false;
	self.isTruelyDead = false
	self.isBianshen = false; --目前只有玛欧用到。

	--角色当前所处的格子。
	self.box_w = -1000;
	self.box_h = -1000;

	--属性管理器
	self.attributeManager = AttributeManager.new(self)

	--触发器管理器
	self.triggerManager = TriggerManager.new(self)
	self.triggerManager:initTriggers()

	self.hpBar:onRevive()

	self.fsm.stateEnum = StateEnum.Idling
	self.fsm:changeState(StateEnum.Idling)
	self:setVisible(true)

	self:setOrientation()
	self:setPosition(cc.p(self.data.initialPos.x,self.data.initialPos.y))
	self.box_w,self.box_h = GetBoxWHByPoint(self.data.initialPos.x,self.data.initialPos.y)--设置位置信息

	local reviveEffect = cc.CSLoader:createNode("uifile/Battle_fh.csb")
	self:addChild(reviveEffect)

	local action = cc.CSLoader:createTimeline("uifile/Battle_fh.csb")
	reviveEffect:runAction(action)
	action:play("play", false);

	--2019.2.13新增，复活后有2秒的无敌时间
	self.FuHuoWuDi = true
	local this = self

	local function removeEffect()
		reviveEffect:removeFromParent()
	end

	local function callback()
		PerformWithDelayTime(removeEffect,0.01)

		local totalNum = #G_Roles
		local reviveNum = 0
		for k,v in pairs(G_Roles) do
			if not v.isDead then
				reviveNum = reviveNum + 1
			end
		end

		if reviveNum == totalNum then
			for i = 1,totalNum do
				G_Roles[i].FuHuoWuDi = false
			end

			G_BattleScene:startGame()
		end
	end

	SetLastFrameCallFunc_AllPlatform(action,callback,2)
end