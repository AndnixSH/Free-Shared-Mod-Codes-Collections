--require "XUIView"

GuildBBSView = class("GuildBBSView",XUIView)
GuildBBSView.CS_FILE_NAME = "GuildBBSView.csb"
GuildBBSView.CS_BIND_TABLE = {
    panelBG = "/s:panelBG",
    spriteBg = "/s:panelBG//s:Sprite_1",
    panelList = "/s:Panel_1/s:panelList",
    panelInput = "/s:Panel_1/s:Panel_3",
    textInput =  "/s:Panel_1/s:Panel_3/s:TextField_1",
    btnSend = "/s:Panel_1/s:Button_2",
    btnClose = "/i:132/i:92",
    topBarViewPanel = "/i:606",
}

GuildBBSView.ITEM_FILE = "GuildBBSItemView.csb"
GuildBBSView.ITEM_TABLE = {
    panelSB = "/s:panelSB",
    sbRoleFace = "/s:panelSB/s:roleFace",
    sbRoleName = "/s:panelSB/s:roleName",
    sbMsgTime = "/s:panelSB/s:msgTime",    
    panelMe = "/s:panelMe",
    meRoleFace = "/s:panelMe/s:roleFace",
    meRoleName = "/s:panelMe/s:roleName",
    meMsgTime = "/s:panelMe/s:msgTime", 
    msgText = "/s:msgText",
}

-- data = {
--     "state_code":  1,
--     "chat_board" = [
--         # 每一条聊天信息
--         {
--             "uid": "10086",         # 发言人的ID
--             "name": u"撒斯姆",      # 发言人的名称
--             "time": 1437384422,     # 发言时间(等同于msg_id)
--             "head": 111,   # 发言人形象 
--             "msg": u"晚上团战",     # 说了什么 
--         }
--     ]
-- }

function GuildBBSView.formatTime(time)
    local now = UserDataMgr:getInstance().timeData:getCurrentTime()--os.time()
    local dist = now - time
    local retv = nil
    if dist > 2592000 then
        retv = UITool.ToLocalization("1个月前")
    elseif dist > 604800 then
        retv = UITool.ToLocalization("1周前")
    elseif dist > 172800 then
        retv = UITool.ToLocalization("2天前")
    elseif dist > 86400 then
        retv = UITool.ToLocalization("1天前")
    elseif dist > 43800 then
        retv = UITool.ToLocalization("12小时前")
    elseif dist > 21600 then
        retv = UITool.ToLocalization("6小时前")
    elseif dist > 7200 then
        retv = UITool.ToLocalization("2小时前")
    elseif dist > 1800 then
        retv = UITool.ToLocalization("30分钟前")
    elseif dist > 300 then
        retv = UITool.ToLocalization("5分钟前")
    else
        retv = UITool.ToLocalization("刚刚")
    end

    return retv
end

function GuildBBSView:init()
    GuildBBSView.super.init(self)
    self.exist = true

    self.textInput:setPlaceHolder(UITool.ToLocalization("请输入您想要留言的内容"))
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,1020,130)

    self.gridview.itemCreateEvent = function()
        local temp = XUICellView.new():init(nil,GuildBBSView.ITEM_FILE,GuildBBSView.ITEM_TABLE)

        temp.onResetData = function(self)
            --self._data
            self.msgText:setString(self._data["msg"])

            if self._data["uid"] == user_info["id"] then
                --自己发的
                self.panelSB:setVisible(false)
                self.panelMe:setVisible(true)

                --self.meRoleName:setString(self._data["name"])
                self.meMsgTime:setString(GuildBBSView.formatTime(self._data["time"]))
                local hinfo = hero[self._data["head"]]
                if hinfo then
                    self.meRoleFace:setVisible(true)
                    self.meRoleFace:setTexture(hinfo.hero_bat_icon)
                else
                    self.meRoleFace:setVisible(false)
                end
            else
                --其他人发的
                self.panelSB:setVisible(true)
                self.panelMe:setVisible(false)

                self.sbRoleName:setString(self._data["name"])
                self.sbMsgTime:setString(GuildBBSView.formatTime(self._data["time"]))

                local hinfo = hero[self._data["head"]]
                if hinfo then
                    self.sbRoleFace:setVisible(true)
                    self.sbRoleFace:setTexture(hinfo.hero_bat_icon)
                else
                    self.sbRoleFace:setVisible(false)
                end
                
            end

        end
        return temp
    end

    self.btnSend:addClickEventListener(function()
        self:sendMessage()
    end)

    self.panelInput:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:popInputView()
        end
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    if g_channel_control.show_new_guild_main == true then
        self.spriteBg:initWithFile("uifile/n_UIShare/guild/Guild_add/xgh_bg_001.png")
        self.spriteBg:setAnchorPoint(0,0)
        self:InitTopBarView()
    end
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

function GuildBBSView:loadData()
    GameManagerInst:rpc("{\"rpc\":\"guild_chat_open\"}",3,
    function(data)
        --success
        --GameManagerInst:saveToFile("guild_chat_open.json",data)

        self.msg_data = data["chat_board"]
        self:refresh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function GuildBBSView:refresh()
    if not self.msg_data then self.msg_data = {} end

    self.gridview:setDataSource(self.msg_data)

    --滚动到最底端
    self.gridview:getScrollView():jumpToBottom()
    self.textInput:setString("")
end

function GuildBBSView:sendMessage()
    local str1 = self.textInput:getString()

    if str1 == nil or str1 == "" then
        GameManagerInst:alert(UITool.ToLocalization("请输入留言内容"))
        return
    end

    local tempTable = {
        rpc = "guild_chat",
        msg = str1
    }

    GameManagerInst:rpc( tempTable ,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        --GameManagerInst:saveToFile("guild_chat.json",data)
        self.msg_data = table.deepcopy(data["chat_board"])

        self:refresh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function GuildBBSView:popInputView()
    if GameManagerInst.gameType == 2 then
        local rcvData = {}
        rcvData["sDelegate"] = self
        rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
        rcvData["confirmFunc"] =  function(self,text)
            self.textInput:setString(text)
        end
        rcvData["defalutStr"] = self.textInput:getString()
        rcvData["maxLength"] = 40
        SceneManager:toInputModelLayer(rcvData)
    end
end


function GuildBBSView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    self:loadData()
end

function GuildBBSView:returnBack()
    self.exist = false;
    if self._navigationView then
        self._navigationView:popView()
    else
        self:removeFromParentView()
    end
end

function GuildBBSView:InitTopBarView()
    self.topBarViews = XUIView.new():init(self.topBarViewPanel)
    local iteamDatas = {}
    local rcvData = {}
    rcvData["sIteamDatas"] = iteamDatas
    rcvData["bIsStartLayer"] = false
    rcvData["nInfoState"] = table.getValue("coinbar",coinbar,64,"coinbar_type")
    rcvData["nTitleNum"] = 7

    self.topBarView = TopBarView.new():init(rcvData)
    self.topBarViews:addSubView(self.topBarView)
    self:InitSociatyBBSTopBarView()
end

function GuildBBSView:InitSociatyBBSTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,64,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

-- 当货币栏中有不是金币，体力和星石时，需要单独刷洗数据 (根据不同的类型数据存入array_cointype中),具体类型参考cointype表 
function GuildBBSView:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
            if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end
