cointype = {}
cointype[1] = {
    name = "60778",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_003.png",
    desc_simple = "51631",
    desc_type = 2,
    b_add = 1,
    mat_id = 15,
}
cointype[2] = {
    name = "60779",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_004.png",
    desc_simple = "51632",
    desc_type = 1,
    b_add = 1,
    mat_id = 1,
}
cointype[3] = {
    name = "60780",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51633",
    desc_type = 2,
    b_add = 1,
    mat_id = 2,
}
cointype[4] = {
    name = "60043",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_037.png",
    desc_simple = "51634",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[5] = {
    name = "612357",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51635",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[6] = {
    name = "60783",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51636",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[7] = {
    name = "60784",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_040.png",
    desc_simple = "51637",
    desc_type = 1,
    b_add = 0,
    mat_id = 13,
}
cointype[8] = {
    name = "60785",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_039.png",
    desc_simple = "51638",
    desc_type = 1,
    b_add = 0,
    mat_id = 20,
}
cointype[9] = {
    name = "60786",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51639",
    desc_type = 2,
    b_add = 1,
    mat_id = 102,
}
cointype[10] = {
    name = "60787",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51640",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[11] = {
    name = "60788",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51641",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[12] = {
    name = "60789",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51642",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[13] = {
    name = "60790",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51643",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[14] = {
    name = "60791",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51644",
    desc_type = 1,
    b_add = 0,
    mat_id = 0,
}
cointype[15] = {
    name = "60792",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51645",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[16] = {
    name = "60793",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51646",
    desc_type = 1,
    b_add = 0,
    mat_id = 0,
}
cointype[17] = {
    name = "60794",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51647",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[18] = {
    name = "60795",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51648",
    desc_type = 1,
    b_add = 0,
    mat_id = 0,
}
cointype[19] = {
    name = "60796",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51649",
    desc_type = 2,
    b_add = 1,
    mat_id = 100,
}
cointype[20] = {
    name = "60797",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51650",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[21] = {
    name = "60798",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51651",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[22] = {
    name = "60799",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51652",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[23] = {
    name = "60800",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51653",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[24] = {
    name = "60801",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51654",
    desc_type = 2,
    b_add = 1,
    mat_id = 5,
}
cointype[25] = {
    name = "60802",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_002.png",
    desc_simple = "51655",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[26] = {
    name = "617208",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_038.png",
    desc_simple = "617209",
    desc_type = 1,
    b_add = 0,
    mat_id = 5,
}
cointype[27] = {
    name = "615274",
    coinbg = "res/uifile/n_UIShare/xbmain/xbstart/xzy_ui_038_4.png",
    desc_simple = "615275",
    desc_type = 2,
    b_add = 0,
    mat_id = 22,
}