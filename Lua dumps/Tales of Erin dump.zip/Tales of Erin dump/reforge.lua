reforge={}
reforge[182310] = {
    eq_change=202010,
    eq_sk_desc="51677",
    eq_sk_1_desc="51687",
    need_mat = {
    -- ID 数量 类型
    { 706,40,5 },
    { 25,80,5 },
    },
}
reforge[182210] = {
    eq_change=204010,
    eq_sk_desc="51678",
    eq_sk_1_desc="51688",
    need_mat = {
    -- ID 数量 类型
    { 706,40,5 },
    { 25,80,5 },
    },
}
reforge[182110] = {
    eq_change=201010,
    eq_sk_desc="51679",
    eq_sk_1_desc="51689",
    need_mat = {
    -- ID 数量 类型
    { 706,40,5 },
    { 25,80,5 },
    },
}
reforge[182410] = {
    eq_change=200010,
    eq_sk_desc="51680",
    eq_sk_1_desc="51690",
    need_mat = {
    -- ID 数量 类型
    { 706,40,5 },
    { 25,80,5 },
    },
}
reforge[182510] = {
    eq_change=203010,
    eq_sk_desc="51681",
    eq_sk_1_desc="51691",
    need_mat = {
    -- ID 数量 类型
    { 706,40,5 },
    { 25,80,5 },
    },
}
reforge[201010] = {
    eq_change=301010,
    eq_sk_desc="51682",
    eq_sk_1_desc="51692",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[204010] = {
    eq_change=302010,
    eq_sk_desc="51683",
    eq_sk_1_desc="51693",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[202010] = {
    eq_change=303010,
    eq_sk_desc="51684",
    eq_sk_1_desc="51694",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[200010] = {
    eq_change=304010,
    eq_sk_desc="51685",
    eq_sk_1_desc="51695",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[203010] = {
    eq_change=305010,
    eq_sk_desc="51686",
    eq_sk_1_desc="51696",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[182121] = {
    eq_change=182122,
    eq_sk_desc="601042",
    eq_sk_1_desc="601047",
    need_mat = {
    -- ID 数量 类型
    { 635,50,5 },
    { 636,10,5 },
    },
}
reforge[182221] = {
    eq_change=182222,
    eq_sk_desc="601043",
    eq_sk_1_desc="601048",
    need_mat = {
    -- ID 数量 类型
    { 635,50,5 },
    { 636,10,5 },
    },
}
reforge[182321] = {
    eq_change=182322,
    eq_sk_desc="601044",
    eq_sk_1_desc="601049",
    need_mat = {
    -- ID 数量 类型
    { 635,50,5 },
    { 636,10,5 },
    },
}
reforge[182421] = {
    eq_change=182422,
    eq_sk_desc="601045",
    eq_sk_1_desc="601050",
    need_mat = {
    -- ID 数量 类型
    { 635,50,5 },
    { 636,10,5 },
    },
}
reforge[182521] = {
    eq_change=182522,
    eq_sk_desc="601046",
    eq_sk_1_desc="601051",
    need_mat = {
    -- ID 数量 类型
    { 635,50,5 },
    { 636,10,5 },
    },
}
reforge[164502] = {
    eq_change=264502,
    eq_sk_desc="350046",
    eq_sk_1_desc="350050",
    need_mat = {
    -- ID 数量 类型
    { 635,40,5 },
    { 636,8,5 },
    },
}
reforge[111502] = {
    eq_change=211502,
    eq_sk_desc="350047",
    eq_sk_1_desc="350051",
    need_mat = {
    -- ID 数量 类型
    { 635,40,5 },
    { 636,8,5 },
    },
}
reforge[164501] = {
    eq_change=264501,
    eq_sk_desc="350048",
    eq_sk_1_desc="350052",
    need_mat = {
    -- ID 数量 类型
    { 635,40,5 },
    { 636,8,5 },
    },
}
reforge[123503] = {
    eq_change=223503,
    eq_sk_desc="350049",
    eq_sk_1_desc="350053",
    need_mat = {
    -- ID 数量 类型
    { 635,40,5 },
    { 636,8,5 },
    },
}
reforge[181160] = {
    eq_change=281160,
    eq_sk_desc="616603",
    eq_sk_1_desc="616608",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[181260] = {
    eq_change=281260,
    eq_sk_desc="616602",
    eq_sk_1_desc="616607",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[181360] = {
    eq_change=281360,
    eq_sk_desc="616601",
    eq_sk_1_desc="616606",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[181460] = {
    eq_change=281460,
    eq_sk_desc="616604",
    eq_sk_1_desc="616609",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}
reforge[181560] = {
    eq_change=281560,
    eq_sk_desc="616605",
    eq_sk_1_desc="616610",
    need_mat = {
    -- ID 数量 类型
    { 707,20,5 },
    { 635,100,5 },
    },
}