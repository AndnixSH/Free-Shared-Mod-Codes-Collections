lemon = lemon or {}
lemon.JsonUtil = {}
JsonUtil  = lemon.JsonUtil 

require "json"


--从json文件中直接获得转化为lua table格式的数据
function JsonUtil.getTableFromFile(fileName)
    local fileTable = {}
    if cc.FileUtils:getInstance():isFileExist(fileName) then
        local jsonStr = cc.FileUtils:getInstance():getStringFromFile(fileName);
        --print("jsonStr = "..tostring(jsonStr))

        if jsonStr ~= nil and jsonStr ~= "" then
            fileTable = json.decode(jsonStr)
        end
    end

    return fileTable
end