guild_battle_achi_conf={} 
guild_battle_achi_conf[1] = {
        id= 1,
        achi_name= "56655",
        achi_desc= "56696",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[2] = {
        id= 2,
        achi_name= "56656",
        achi_desc= "56697",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[3] = {
        id= 3,
        achi_name= "56657",
        achi_desc= "56698",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[4] = {
        id= 4,
        achi_name= "56658",
        achi_desc= "56699",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[5] = {
        id= 5,
        achi_name= "56659",
        achi_desc= "56700",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[6] = {
        id= 6,
        achi_name= "56660",
        achi_desc= "56701",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[7] = {
        id= 7,
        achi_name= "56661",
        achi_desc= "56702",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[8] = {
        id= 8,
        achi_name= "56662",
        achi_desc= "56703",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[9] = {
        id= 9,
        achi_name= "56663",
        achi_desc= "56704",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[10] = {
        id= 10,
        achi_name= "56664",
        achi_desc= "56705",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[11] = {
        id= 11,
        achi_name= "56665",
        achi_desc= "56706",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[12] = {
        id= 12,
        achi_name= "56666",
        achi_desc= "56707",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[13] = {
        id= 13,
        achi_name= "56667",
        achi_desc= "56708",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[14] = {
        id= 14,
        achi_name= "56668",
        achi_desc= "56709",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[15] = {
        id= 15,
        achi_name= "56669",
        achi_desc= "56710",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[16] = {
        id= 16,
        achi_name= "56670",
        achi_desc= "56711",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[17] = {
        id= 17,
        achi_name= "56671",
        achi_desc= "56712",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[18] = {
        id= 18,
        achi_name= "56672",
        achi_desc= "56713",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[19] = {
        id= 19,
        achi_name= "56673",
        achi_desc= "56714",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[20] = {
        id= 20,
        achi_name= "56674",
        achi_desc= "56715",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[21] = {
        id= 21,
        achi_name= "615613",
        achi_desc= "56716",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[22] = {
        id= 22,
        achi_name= "56676",
        achi_desc= "56717",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[23] = {
        id= 23,
        achi_name= "56677",
        achi_desc= "56718",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[24] = {
        id= 24,
        achi_name= "615612",
        achi_desc= "56719",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[25] = {
        id= 25,
        achi_name= "56679",
        achi_desc= "56720",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[26] = {
        id= 26,
        achi_name= "56680",
        achi_desc= "56721",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[27] = {
        id= 27,
        achi_name= "56681",
        achi_desc= "56722",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[28] = {
        id= 28,
        achi_name= "56682",
        achi_desc= "56723",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[29] = {
        id= 29,
        achi_name= "56683",
        achi_desc= "56724",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[30] = {
        id= 30,
        achi_name= "56684",
        achi_desc= "56725",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[31] = {
        id= 31,
        achi_name= "56685",
        achi_desc= "56726",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[32] = {
        id= 32,
        achi_name= "56686",
        achi_desc= "56727",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[33] = {
        id= 33,
        achi_name= "615604",
        achi_desc= "56728",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[34] = {
        id= 34,
        achi_name= "56688",
        achi_desc= "56729",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[35] = {
        id= 35,
        achi_name= "617816",
        achi_desc= "56730",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[36] = {
        id= 36,
        achi_name= "56690",
        achi_desc= "56731",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[37] = {
        id= 37,
        achi_name= "56691",
        achi_desc= "56732",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[38] = {
        id= 38,
        achi_name= "56692",
        achi_desc= "56733",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[39] = {
        id= 39,
        achi_name= "56693",
        achi_desc= "56734",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[40] = {
        id= 40,
        achi_name= "56694",
        achi_desc= "56735",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
guild_battle_achi_conf[41] = {
        id= 41,
        achi_name= "56695",
        achi_desc= "56736",
        achi_icon= "icons/achiv/cjxt_001.png",

} 