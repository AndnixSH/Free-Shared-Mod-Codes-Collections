--require "XUIView"
--星盘顶级天赋
AstrolabeClimaxBoxLayer = class("AstrolabeClimaxBoxLayer",XUIView)
AstrolabeClimaxBoxLayer.CS_FILE_NAME = "AstrolabeClimaxBoxLayer.csb"
AstrolabeClimaxBoxLayer.CS_BIND_TABLE = 
{ 
    panle     = "/s:Panel_lockBox_2",
    imgBg     = "/s:Panel_lockBox_2/s:Image_bg",
    --图标
    icon      = "/s:Panel_lockBox_2/s:Image_bg/s:Image_climax_0",
    --技能名称
    skName    = "/s:Panel_lockBox_2/s:Image_bg/s:Text_name",
    --当前加点数量
    num       = "/s:Panel_lockBox_2/s:Image_bg/s:Text_num",
    --解锁条件
    textLock  = "/s:Panel_lockBox_2/s:Image_bg/s:Text_des_1",
    --所需点数
    textPoint = "/s:Panel_lockBox_2/s:Image_bg/s:Text_point",
    --描述
    des       = "/s:Panel_lockBox_2/s:Image_bg/s:Text_des_2",

    cancleBtn  = "/s:Panel_lockBox_2/s:Image_bg/s:Button_cancle",
    confrimBtn = "/s:Panel_lockBox_2/s:Image_bg/s:Button_confirm",
}

function AstrolabeClimaxBoxLayer:init()
    AstrolabeClimaxBoxLayer.super.init(self)

    self.cancleBtn:setEffectType(3)
    self.cancleBtn:addClickEventListener(function()
        self:returnBack()
    end)

    if g_channel_control.transform_AstrolabeClimaxBoxLayer_textPoint_pos == true then 
        self.textPoint:setPosition(151,112)    
    end 
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

function AstrolabeClimaxBoxLayer:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end




function AstrolabeClimaxBoxLayer:loadData(baseSelf,Pself)
    self.baseSelf = baseSelf
    self.Pself    = Pself

    local astTable = hero_astrolabe[self.baseSelf.hero_sub_id]["areas"][self.baseSelf.curAreaIndex]
    local climaxType = astTable["climax_type"]  -- 顶级天赋类型
    local climaxId   = astTable["climax_id"]    -- 顶级天赋Id
    local climaxTa   = astrolabe_climax[climaxType][climaxId]

    --图标
   
    self.icon:loadTexture(climaxTa["icon_checked"])

    --技能名称
    self.skName:setString(UITool.getUserLanguage(climaxTa["name"]))
    --解锁前置条件
    local strTable  = self.Pself:AsbLockStr(astTable["climax_unlock"])
    local allStr    = ""
    for i = 1, #strTable do
        allStr = allStr..strTable[i]["str"].." "    
    end
    self.textLock:setString(allStr)
    --当前等级的描述
    self.des:setString(UITool.getUserLanguage(climaxTa.desc))
    --解锁条件是否达成  前置条件必须是一个 并非多个
    local isTrue   =  self.baseSelf:andTrue(astTable["climax_unlock"])
    --顶级天赋服务器状态
    local  climax  =  self.baseSelf.serverData["climax"]

    if isTrue then
        local isB = false
        if climax == 1 then
            self.icon:loadTexture(climaxTa["icon_checked"])
            isB = false
        else
            self.icon:loadTexture(climaxTa["icon_unlock"])
            isB = true
        end
        print("climax  climax == "..climax)
        self.confrimBtn:setTouchEnabled(isB)
        self.confrimBtn:setBright(isB)
        self.textLock:setColor(cc.c3b(184, 184, 184))
    else
        self.confrimBtn:setTouchEnabled(false)
        self.confrimBtn:setBright(false)
        self.textLock:setColor(cc.c3b(255, 0, 0))
        self.icon:loadTexture(climaxTa["icon_locked"])
    end

end


