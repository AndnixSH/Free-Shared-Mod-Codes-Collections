--require "XUIView"
--require "NewRoleTeamItemView"

NewRoleTeamChangeView = class("NewRoleTeamChangeView",XUIView)
NewRoleTeamChangeView.CS_FILE_NAME = "NewRoleTeamChangeView.csb"
NewRoleTeamChangeView.CS_BIND_TABLE = 
{
    panel1 = "/i:364/i:204/i:205",
    panel2 = "/i:364/i:204/i:206",
    panel3 = "/i:364/i:204/i:207",
    panel4 = "/i:364/i:204/i:208",
    --
    panelGray = "/i:364/i:147",
    btnChangeTeam = "/i:364/i:145",
}

function NewRoleTeamChangeView:init(returnBackCallFunc,sDelegate)
    NewRoleTeamChangeView.super.init(self)

    self.returnBackCallFunc = returnBackCallFunc
    self.sDelegate = sDelegate

    self.items = {}
    
    self.currentTeamIndex = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
    if self.currentTeamIndex == 0 then
        self.currentTeamIndex = 1
    end    
    self.beginTeamIndex = self.currentTeamIndex

    for i = 1,4 do
        self.items[i] = NewRoleTeamItemView.new():init(self["panel"..i],i)
        self.items[i].BtnInfoClick = function(index)
        end
        self.items[i].BtnAddClick = function(index)
            self:ItemAdd(index)
        end
        self.items[i]:startCTeffect()
    end

    --
    self.panelGray:addClickEventListener(function()
        self:returnBack()
    end)
    self.btnChangeTeam:addClickEventListener(function()
        self:returnBack()
    end)
    --
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    --
    self:refresh()

    return self
end

function NewRoleTeamChangeView:returnBack()
    if self.returnBackCallFunc then
        self.returnBackCallFunc(self.sDelegate,self.beginTeamIndex)
    end
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function NewRoleTeamChangeView:loadTeamList(callback)
    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success

        DataManager:wTeamData(data["team"])

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleTeamChangeView:loadTeam()
    --["team_fp"]
    
    local teamInfo = team_list[""..self.currentTeamIndex]
    local teamInfoList = nil
    if teamInfo and teamInfo["team"] then
        teamInfoList = teamInfo["team"]
    end

    for i = 1,4 do
        local h = nil
        if teamInfoList and teamInfoList[i] then
            h = teamInfoList[i]
        end
        self.items[i]:setRoleInfo(h or {id="0"})
    end
    
end

function NewRoleTeamChangeView:ItemAdd(index)
    --GameManagerInst:alert("添加"..index)    
    local b,v = RoleListView.createWithBackBtn()

    v.ItemClickedEvent = function(item)
        --GameManagerInst:alert("self:onEditTeam("..index..","..item:getData().id)   
        self:onEditTeam(index,item:getData().id)
        b:returnBack()
    end

    v.ItemResetEvent = function(item)
        local rdata = item:getData()
        if rdata.isCurrentRole then
            --当前点中的人
            item:showOutTeam()
        end
    end

    v.dataSourceEvent = function(sender,sort_mode)
        local ds = {}
        local outteam = {}       
            
        local temp_data = nil
        if team_list[""..self.currentTeamIndex] ~= nil and team_list[""..self.currentTeamIndex]["team"] ~= nil then
            temp_data = team_list[""..self.currentTeamIndex]["team"]
        end

        for i = 1,#hero_list do
            local rdata = table.deepcopy(hero_list[i])
            local notInTeam = true

            for j = 1,4 do
                if temp_data ~= nil and temp_data[j] ~= nil and temp_data[j].id == rdata.id then
                    --在队伍中
                    table.insert(ds,rdata)
                    --当前点中的人
                    rdata.isCurrentRole = (j == index)

                    notInTeam = false
                    break
                end
            end

            if notInTeam then
                rdata.team_list = {}
                table.insert(outteam,rdata)
            end
        end

        SortBoxView.SortRole (ds, sort_mode ,false)
        SortBoxView.SortRole (outteam, sort_mode ,false)

        for i = 1,#outteam do
            table.insert(ds,outteam[i])
        end
        return ds
    end

    v:refresh()

    --GameManagerInst:showModalView(b)
    self:addSubView(b)
end

function NewRoleTeamChangeView:onEditTeam(index,hid)
    local temp_data = team_list[""..self.currentTeamIndex]

    --原始队伍信息
    local teamData = {}
    for i=1,4 do
        teamData[i] = temp_data["team"][i].id
    end    

    local nosame = true

    for i = 1,4 do
        if teamData[i] == hid then
            if i ~= index then
            --点了其他人
                teamData[i] = teamData[index]
                teamData[index] = hid
            else
                --点了自己
                teamData[index] = "0"
            end

            nosame = false
            break
        end
    end

    if nosame then
        teamData[index] = hid
    end

    local temp_team = {}
    temp_team["rpc"] = "team_edit"
    temp_team["team_id"] = self.currentTeamIndex
    temp_team["ps_id"] = temp_data["ps"]
    temp_team["team_info"] = teamData        

    GameManagerInst:rpc(temp_team,3,
    function(data)
        --success
        --第一次编队之后，更改下本地的配置
        if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam)~=1 then 
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam,1)
        end
        self.beginTeamIndex = self.currentTeamIndex
        DataManager:wTeamData(data["team"])

        for k,v in pairs(data["change_hero_list"]) do
            user_info["hero"][k] = table.deepcopy(v)
        end        
        DataManager:rfsHlist()

        self:refresh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleTeamChangeView:refresh()
    self:loadTeam() 
end



