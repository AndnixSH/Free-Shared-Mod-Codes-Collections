
EqSortButtonView = class("EqSortButtonView", XUIView)
EqSortButtonView.CS_FILE_NAME = "SortButtonView.csb"
EqSortButtonView.CS_BIND_TABLE = 
{
    sortBtnSort = "/i:169/s:btnSort",
    sortBtnSortTitle = "/i:169/s:btnSort/s:btnSortTitle",
    sortBtnAsc = "/i:169/s:btnAsc",
    sortBtnDesc = "/i:169/s:btnDesc"
}
--筛选多选数组与前端按钮状态映射表--稀有度
EqSortButtonView.RANK_STATE_TO_SEND = 
{
    {5,4,3},
    5,
    4,
    3,
}
--筛选多选数组与前端按钮状态映射表--属性
EqSortButtonView.ELE_STATE_TO_SEND = 
{
    {1,2,3,4,5,0},
    3,
    2,
    1,
    4,
    5,
}
--筛选多选数组与前端按钮状态映射表--突破次数
EqSortButtonView.BRK_STATE_TO_SEND = 
{
    {4,3,2,1,0},
    4,
    3,
    2,
    1,
    0,
}
EqSortButtonView.bDisableSortBtn = false
function EqSortButtonView:init(rootNode,strkey,defmode,strRankkey,defRank,strElekey,defEle,strBrkkey,defBrk)
    EqSortButtonView.super.init(self,rootNode)

    self.defmode = defmode
    --
    self.defRank = defRank
    self.defEle = defEle
    self.defBrk = defBrk

    --升序按钮
    self.sortBtnAsc:setPressedActionEnabled(false)
    self.sortBtnAsc:addClickEventListener(function()
        if self.bDisableSortBtn then
            GameManagerInst:alert(UITool.ToLocalization("当前界面无法进行筛选"))
            return
        end    
        local num = math.floor(self.sortMode/10)
        local num1 = num * 10 + 1
        if num1 ~= self.sortMode then
            self:setSortMode(num1)
            if self.sortModeChangedEvent then
                self.sortModeChangedEvent(self,self.sortMode)
            end
        end
    end)
    --降序按钮
    self.sortBtnDesc:setPressedActionEnabled(false)
    self.sortBtnDesc:addClickEventListener(function()
        if self.bDisableSortBtn then
            GameManagerInst:alert(UITool.ToLocalization("当前界面无法进行筛选"))
            return
        end
        local num = math.floor(self.sortMode/10)
        local num1 = num * 10 
        if num1 ~= self.sortMode then
            self:setSortMode(num1)
            if self.sortModeChangedEvent then
                self.sortModeChangedEvent(self,self.sortMode)
            end
        end
    end)

    self.sortBtnSort:setPressedActionEnabled(false)
    self.sortBtnSort:addClickEventListener(function()
        --self.sortbiew = nil
        if self.bDisableSortBtn then
            GameManagerInst:alert(UITool.ToLocalization("当前界面无法进行筛选"))
            return
        end
        local sortbiew = EqSortBoxView.new():init(self.defmode)
        sortbiew.beforeCloseEvent = function(sender,stype,nRankVaule,nEleVaule,nBrkVaule)
            if stype or nRankVaule or nEleVaule or nBrkVaule then
                self.sortRev = self.sortMode%10 --升降序

                self:setSortMode(stype + self.sortRev)
                self:setFilterMode(nRankVaule,nEleVaule,nBrkVaule)

                if self.sortModeChangedEvent then
                    self.sortModeChangedEvent(self,self.sortMode)
                end
            else
                --没选择，不处理
                return
            end
        end
        sortbiew:setSortMode(self.sortMode)
        sortbiew:setFilterMode(self.rankMode,self.eleMode,self.brkMode)
        GameManagerInst:showModalView(sortbiew)
    end)

    self:setSortKey(strkey,defmode)
    self:setRankKey(strRankkey,defRank)
    self:setEleKey(strElekey,defEle)
    self:setBrkKey(strBrkkey,defBrk)
    --
    self:RefreshRootBtnState()
    
    return self
end

function EqSortButtonView:setDisableSortBtn(able)
    self.bDisableSortBtn = able
end

function EqSortButtonView:setSortKey(strkey,defmode)

    self.sortKey = strkey

    if not self.sortKey then return end

    self.sortMode = cc.UserDefault:getInstance():getIntegerForKey(self.sortKey)
    if self.sortMode == 0 then
        self.sortMode = defmode
    end
    
    self.sortRev = self.sortMode%10 --升降序

    self.sortBtnAsc:setVisible(self.sortRev ~= 1)
    self.sortBtnDesc:setVisible(self.sortRev == 1)

    self.sortBtnSortTitle:setString(EqSortBoxView.GetSortName(self.sortMode))
end

function EqSortButtonView:setRankKey(strRankkey,defRank)

    self.rankKey = strRankkey

    if not self.rankKey then return end

    self.rankMode = cc.UserDefault:getInstance():getIntegerForKey(self.rankKey)
    if self.rankMode == 0 then
        self.rankMode = defRank
    end
end

function EqSortButtonView:setEleKey(strElekey,defEle)

    self.eleKey = strElekey

    if not self.eleKey then return end

    self.eleMode = cc.UserDefault:getInstance():getIntegerForKey(self.eleKey)
    if self.eleMode == 0 then
        self.eleMode = defEle
    end
end

function EqSortButtonView:setBrkKey(strBrkkey,defBrk)

    self.brkKey = strBrkkey

    if not self.brkKey then return end

    self.brkMode = cc.UserDefault:getInstance():getIntegerForKey(self.brkKey)
    if self.brkMode == 0 then
        self.brkMode = defBrk
    end
end

function EqSortButtonView:getSortVaule()
    return EqSortBoxView.GetSortVaule(self.sortMode)
end

function EqSortButtonView:getSortMode()
    return self.sortMode
end

function EqSortButtonView:getRankMode()
    local nVaule = self.rankMode
    local vStates = {1,0,0,0,}
    local senderStates = {}--后端交互API数组
    for i=#vStates,2,-1 do
        vStates[i] = math.floor(nVaule/(math.pow(10,i-2)))
        if vStates[i] > 0 then
            nVaule = nVaule - math.pow(10,i-2)
        end
    end
    if vStates[2] == vStates[3] and vStates[2] == vStates[4] then --其他几个多选子选项状态统一 则全部为是 其他为非
        vStates[1] = 1
        for i=2,#vStates do--全部是状态其他选项为非状态
            vStates[i] = 0
        end
    else--其他状态不一致则全部非状态
        vStates[1] = 0
    end
    --从映射表中更新API数组
    if vStates[1] > 0 then--全部
        senderStates = nil
        senderStates = self.RANK_STATE_TO_SEND[1]
    else
        --非全部
        local senderIndex = 1
        for i=2,#vStates do
            if vStates[i] > 0 then
                senderStates[senderIndex] = self.RANK_STATE_TO_SEND[i]
                senderIndex = senderIndex + 1
            end
        end
    end

    return senderStates
end

function EqSortButtonView:getEleMode()
    local nVaule = self.eleMode
    local vStates = {1,0,0,0,0,0}
    local senderStates = {}--后端交互API数组
    for i=#vStates,2,-1 do
        vStates[i] = math.floor(nVaule/(math.pow(10,i-2)))
        if vStates[i] > 0 then
            nVaule = nVaule - math.pow(10,i-2)
        end
    end
    if vStates[2] == vStates[3] and vStates[2] == vStates[4] and vStates[2] == vStates[5] and vStates[2] == vStates[6] then --其他几个多选子选项状态统一 则全部为是 其他为非
        vStates[1] = 1
        for i=2,#vStates do--全部是状态其他选项为非状态
            vStates[i] = 0
        end
    else--其他状态不一致则全部非状态
        vStates[1] = 0
    end
    --从映射表中更新API数组
    if vStates[1] > 0 then--全部
        senderStates = nil
        senderStates = table.deepcopy(self.ELE_STATE_TO_SEND[1])
    else
        --非全部
        local senderIndex = 1
        for i=2,#vStates do
            if vStates[i] > 0 then
                senderStates[senderIndex] = self.ELE_STATE_TO_SEND[i]
                senderIndex = senderIndex + 1
            end
        end
    end

    return senderStates
end

function EqSortButtonView:getBrkMode()
    local nVaule = self.brkMode
    local vStates = {1,0,0,0,0,0}
    local senderStates = {}--后端交互API数组
    for i=#vStates,2,-1 do
        vStates[i] = math.floor(nVaule/(math.pow(10,i-2)))
        if vStates[i] > 0 then
            nVaule = nVaule - math.pow(10,i-2)
        end
    end
    if vStates[2] == vStates[3] and vStates[2] == vStates[4] and vStates[2] == vStates[5] and vStates[2] == vStates[6] then --其他几个多选子选项状态统一 则全部为是 其他为非
        vStates[1] = 1
        for i=2,#vStates do--全部是状态其他选项为非状态
            vStates[i] = 0
        end
    else--其他状态不一致则全部非状态
        vStates[1] = 0
    end
    --从映射表中更新API数组
    if vStates[1] > 0 then--全部
        senderStates = nil
        senderStates = self.BRK_STATE_TO_SEND[1]
    else
        --非全部
        local senderIndex = 1
        for i=2,#vStates do
            if vStates[i] > 0 then
                senderStates[senderIndex] = self.BRK_STATE_TO_SEND[i]
                senderIndex = senderIndex + 1
            end
        end
    end

    return senderStates
end

function EqSortButtonView:getSortRev()--升降序
    return self.sortRev
end

function EqSortButtonView:setSortMode(sort_mode)
    if self.sortMode ~= sort_mode then --  提升效率 排序模式非变化不走此刷新逻辑
        self.sortMode = sort_mode
        cc.UserDefault:getInstance():setIntegerForKey(self.sortKey,self.sortMode)
    
        self.sortRev = self.sortMode%10 --升降序

        self.sortBtnAsc:setVisible(self.sortRev ~= 1)
        self.sortBtnDesc:setVisible(self.sortRev == 1)

        self.sortBtnSortTitle:setString(EqSortBoxView.GetSortName(self.sortMode))
    end
    
end

function EqSortButtonView:setFilterMode(nRankVaule,nEleVaule,nBrkVaule)
    if self.rankMode ~= nRankVaule then --  提升效率 筛选规则不变不走此逻辑
        self.rankMode = nRankVaule
        cc.UserDefault:getInstance():setIntegerForKey(self.rankKey,self.rankMode)
    end
    if self.eleMode ~= nEleVaule then --  提升效率 筛选规则不变不走此逻辑
        self.eleMode = nEleVaule
        cc.UserDefault:getInstance():setIntegerForKey(self.eleKey,self.eleMode)
    end
    if self.brkMode ~= nBrkVaule then --  提升效率 筛选规则不变不走此逻辑
        self.brkMode = nBrkVaule
        cc.UserDefault:getInstance():setIntegerForKey(self.brkKey,self.brkMode)
    end
    self:RefreshRootBtnState()
end

function EqSortButtonView:RefreshRootBtnState()
    if (self.rankMode ~= self.defRank) or (self.eleMode ~= self.defEle) or (self.brkMode ~= self.defBrk) then
        self.sortBtnSort:loadTextures(EQ_SORT_BTN_BG_CHANGE[1],EQ_SORT_BTN_BG_CHANGE[2],EQ_SORT_BTN_BG_CHANGE[3])
    else
        self.sortBtnSort:loadTextures(EQ_SORT_BTN_BG_NOR[1],EQ_SORT_BTN_BG_NOR[2],EQ_SORT_BTN_BG_NOR[3])
    end
end

