require "BasicLayer"

RanklistLayer = class("RanklistLayer",BasicLayer)
RanklistLayer.__index = RanklistLayer
RanklistLayer.lClass = 2 
RanklistLayer.defaultIndex   = 1   -- 1 战力  phb_ui_003  2 黑潮遗迹  phb_ui_004 3 魔王歼灭 phb_ui_005
RanklistLayer.selectIndex   = nil  -- 当前选择页签索引
RanklistLayer.rootNode      = nil -- 根节点
RanklistLayer.but_list_len   = 3   -- button 的个数 以后修改此项就可以了
RanklistLayer.but_listview   = nil -- 控制but的listView
RanklistLayer.ranklist_table = nil
RanklistLayer.panelList      = nil
RanklistLayer.region_t      = nil
RanklistLayer.butHelp  = nil --帮助按钮
RanklistLayer.butClose = nil -- 关闭按钮
RanklistLayer.regionRefresh = true -- 区域或服务器名称是否需要刷新
RanklistLayer.tabDataConf = nil -- 排行榜页签配置
local defaultConf = { 
    { 1, "玩家战力", "phb_b_007_2", "phb_b_007_1", "phb_ui_003", "玩家战力值取自编队中的最\n强战力,以更高更强的队伍\n实力为目标而努力吧。" ,1},
    { 2, "黑潮遗迹", "phb_b_002_2", "phb_b_002_1", "phb_ui_004", "黑潮遗迹排行榜是玩家所能到\n达黑潮遗迹最高层数的排行。" ,0},
    { 3, "魔王歼灭", "phb_b_003_2", "phb_b_003_1", "phb_ui_005", "本周击败魔王次数排行是玩\n家本周进行的多人战胜利总\n次数排行。" ,0}
}

function RanklistLayer:init()
    self:initTabDataConf()
    self:initView()
    self:initEvent()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)
end
--初始化页签配置
function RanklistLayer:initTabDataConf()
    if g_channel_control.useRankConfig == true then
        --self.tabDataConf = rank_reward_list
        self.tabDataConf = RankSys:getInstance():getRankDataByType(self.from)--rank_reward_list 
    else
        self.tabDataConf = defaultConf
    end
end
function RanklistLayer:initView( ... )
    local node =cc.CSLoader:createNode("RanklistLayer.csb")
    self.uiLayer:addChild(node,0)
    -- 获取 buttonList 的ListView  和 排行成员的ListView 
    self.but_listview  = node:getChildByName("ListView_2")
    self.btnReward  = node:getChildByName("btn_reward")
    self.butHelp  = node:getChildByName("Button_help")
    self.butClose = node:getChildByName("Button_close")
    self.rootNode = node 

    self:initTabItemMode()
    self:initTabItem()
    self:initRankListView()

    self.exist = true
end

-- 初始化 button 事件
function RanklistLayer:initEvent( ... )
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Button_help" then
                self:showHelp()
            elseif sender:getName() == "Button_close" then
                self:returnBack()
            elseif sender:getName() == "btn_reward" then
                self:showRewardLayer()
            end
        end
    end
    self.butHelp:addTouchEventListener(touchCallBack)
    self.butClose:addTouchEventListener(touchCallBack)
    self.btnReward:addTouchEventListener(touchCallBack)
    self.butClose:setEffectType(3)
end
--初始化页签ui
function RanklistLayer:initTabItem( ... )
    -- body
    self.but_listview:removeAllChildren()
    local tabData = self.tabDataConf
    local tablen = #tabData
    self.tabItemNum = tablen
    for i = 1,tablen do
        self.but_listview:pushBackDefaultItem()
    end
    
    local function touchCallBack( sender,eventType)
        -- body
        if eventType == ccui.TouchEventType.ended then
             local tabItemIndex = sender:getTag()
             self:selectButtonByIndex(tabItemIndex)
        end
    end

    for m = 1,tablen do
        local tab_item = self.but_listview:getItem(m - 1)
        tab_item:setTag(m)
        tab_item:addTouchEventListener(touchCallBack)
        local configId = m+36
        UnlockSys:getInstance():bindLock(configId, tab_item, true)
    end
    --默认选中第一个
    self:selectButtonByIndex(self.defaultIndex)
end

-- Button_help 回调函数
function RanklistLayer:showHelp()
    local helpObj = self.tabDataConf[self.selectIndex]
    if helpObj and helpObj[6] then
        local help_str = UITool.ToLocalization(UITool.getUserLanguage(helpObj[6]))
        MsgManager:showSimpMsg(help_str)
    end
end

-- btn_reward 回调函数
function RanklistLayer:showRewardLayer()
    local rData = {}
    rData.mType =  self.tabDataConf[self.selectIndex][1]
    self.sManager:toRankListRewardLayer(rData)
end

--选中某页签
function RanklistLayer:selectButtonByIndex( btn_index )
    self.btnReward:setVisible(false)
    self.selectIndex = btn_index or 1
    local tab_index = btn_index or 1
    self:sendData(tab_index)
    for i = 1,self.tabItemNum do
        local selectIcon = self.tabDataConf[i][3]
        local unSelectIcon = self.tabDataConf[i][4]
        local item = self.but_listview:getItem(i - 1)
        if i == tab_index then
            if selectIcon ~= nil then
                item:loadTexture("uifile/n_UIShare/Ranklist/"..selectIcon..".png")
            end
        else
            if unSelectIcon ~= nil then
                item:loadTexture("uifile/n_UIShare/Ranklist/"..unSelectIcon..".png")
            end
        end
    end
end

--/*设置排行榜list 显示的数据*/
function RanklistLayer:initRankListView()
    local bg        = self.rootNode:getChildByName("Image_BgForm")
    self.region_t = bg:getChildByName("Panel_region"):getChildByName("Text_region")
    self.panelList  = bg:getChildByName("Panel_List")
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width-10, psize.height,1006,114)
    self.gridview.itemCreateEvent = function()
        local temp = RanklistNode.new():init()
        local function touchCallBack( sender,eventType )
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()
                local l = cc.pGetDistance(p1,p2)
                if l < 30 then
                    local b_robot = temp.b_robot
                    if b_robot == 1 then
                        return
                    else
                        self:switchPlayerInfoLayer(temp.curId,temp.head)
                    end
                end
            end
        end 
        local Formbg =  temp.PanelList:getChildByName("Image_personal")
        temp.PanelList:setSwallowTouches(false)
        -- temp.PanelList:getChildByName("Image_panel")setSwallowTouches(false)
        temp.PanelList:addTouchEventListener(touchCallBack)
        local Type  = Formbg:getChildByName("Image_Type")
        local rankTypeObj = self.tabDataConf[self.selectIndex]
        if rankTypeObj and rankTypeObj[5] then
            local rankTypeImg = rankTypeObj[5]
            Type:loadTexture("uifile/n_UIShare/Ranklist/"..rankTypeImg..".png")
        end
        return temp
    end

end

function RanklistLayer:switchPlayerInfoLayer( id,head )
    -- body
    local rcvData = {}
    local info = {}
    if g_channel_control.b_XbPlayerInfoView == true then
        info["ui_from"] = PlayerInfoSys.EUiType.rank
        info["uid"] = id
        rcvData["info"] =  info
    else
        info["fromType"] = 4   -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息
        info["m_position"] = nil   --self.GuildMemberTable["tab"][index]["position"], --自己的公会职位
        info["other_infos"] = {}    --要查看对象的信息
        info["other_infos"]["uid"] = id
        info[other_infos]["head"] = head
        rcvData["info"] =  info
    end
    SceneManager:toPlayerInfoLayer(rcvData)
end
--初始化排行榜页签模板
function RanklistLayer:initTabItemMode()
    local layout_type_shop = ccui.Layout:create();
    local bg_img = ccui.ImageView:create("n_UIShare/shop/sc_b_001_1.png");
    bg_img:setContentSize(164,100) 
    bg_img:setHighlighted(false)
    bg_img:setTouchEnabled(true)
    self.but_listview:setItemModel(bg_img)
    self.but_listview:setItemsMargin(15)
end
-- /*链接服务器 获取服务器数据*/
function RanklistLayer:sendData( btnIdx)

    -- 测试数据
    local function reiceSthCallBack(data)
        print("获取排行榜List")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.ranklist_table = t_data["data"]
        for i,v in ipairs(self.ranklist_table["ranking_list"]) do
            if v and #v > 2 and v[#v] == 1 then
                v[2] = UITool.getUserLanguage(v[2])
            end
        end
        if self.regionRefresh == true then
            self.regionRefresh = false
            self:refreshRegion()
        end 
        self:refreshRankView()
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "user_ranking_list",
        ["ranking_type"] = self.tabDataConf[btnIdx][1],
        ["act_id"] = self.act_id
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--刷新区域或服务器名称
function RanklistLayer:refreshRegion()
    local region_name = UITool.ToLocalization("【No 区】")
    local regionId = self.ranklist_table.partition or 0
    if regionId then
        region_name = string.format(UITool.ToLocalization("【%s区】"),tostring(regionId))--"【"..regionId.."区】"
    end
    self.region_t:setString(region_name)
end

function RanklistLayer:refreshRankView()
    print("self.ranklist_table self.ranklist_table "..#self.ranklist_table["ranking_list"])
    self.ranklist_table.is_show = self.ranklist_table.is_show or 0
    if self.ranklist_table.is_show == 1 then 
        self.btnReward:setVisible(true)
    else 
        self.btnReward:setVisible(false)
    end

    local rankTypeObj = self.tabDataConf[self.selectIndex]
    if rankTypeObj and rankTypeObj[7] then
        if rankTypeObj[7] > 0 then
            self.region_t:setVisible(true)
        else
            self.region_t:setVisible(false)
        end
    end 
    
   -- self.ranklist_table["ranking_list"]["defaultIndex"] = self.defaultIndex
    self.gridview:setDataSource(self.ranklist_table["ranking_list"])
    local perdtable = {
            ["rank"]         = self.ranklist_table["my_ranking"][1],            -- 排名
            ["name"]         = self.ranklist_table["my_ranking"][2],            -- 玩家名称
            ["Id"]           = self.ranklist_table["my_ranking"][3],            -- 玩家ID
            ["iconId"]       = self.ranklist_table["my_ranking"][4],            -- 头像id
            ["score"]        = self.ranklist_table["my_ranking"][5],            -- 对应分数
        }
    -- 获取当前自己的的显示出来
    local bg       = self.rootNode:getChildByName("Image_BgForm")
    local personal = bg:getChildByName("Image_personal")
    -- 头像
    local  icon       = personal:getChildByName("Image_icon")
    local heroid  = tonumber(perdtable["iconId"])
    icon:setUnifySizeEnabled(true)
    icon:loadTexture(hero[heroid].hero_bat_icon)
    -- 玩家ID
    local  id         = personal:getChildByName("Text_ID")
    --print("自己的ID == "..perdtable["Id"])
    id:setVisible(false)
    id:setString(perdtable["Id"])
    -- -- 玩家名称
    -- local  naem       = personal:getChildByName("Text_name")
    -- naem:setString(perdtable["name"])
    -- 分数
    local  score      = personal:getChildByName("Text_num")
    score:setString(perdtable["score"])
    -- 排名  1——3 是图片  其他显示文本排名
    local  rank       = personal:getChildByName("Text_rank")
    local  iRank      = personal:getChildByName("Image_rank")
    if  tonumber(perdtable["rank"])     == 1 then
        iRank:setVisible(true)
        rank:setVisible(false)
        iRank:loadTexture("uifile/n_UIShare/guild/guild_pavilion/ghdg_ui_003.png")
    elseif tonumber(perdtable["rank"]) == 2 then
        iRank:setVisible(true)
        rank:setVisible(false)
        iRank:loadTexture("uifile/n_UIShare/guild/guild_pavilion/ghdg_ui_004.png")
    elseif tonumber(perdtable["rank"]) == 3 then
        iRank:setVisible(true)
        rank:setVisible(false)
        iRank:loadTexture("uifile/n_UIShare/guild/guild_pavilion/ghdg_ui_005.png")
    else
        iRank:setVisible(false)
        rank:setVisible(true)
        rank:setString(perdtable["rank"])
    end 
    local Type  = personal:getChildByName("Image_Type")
    local rankTypeObj = self.tabDataConf[self.selectIndex]
    if rankTypeObj and rankTypeObj[5] then
        local rankTypeImg = rankTypeObj[5]
        Type:loadTexture("uifile/n_UIShare/Ranklist/"..rankTypeImg..".png")
    end
end

function RanklistLayer:returnBack(  )
    -- -- body
    self.sManager:removeFromNavNodes(self)
    -- self.sData = {}
    if self.backFunc then 
        self.backFunc(self.sManager,self.rData["rcvData"])
    end 
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clearEx()
end

function RanklistLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()


end
function RanklistLayer:create(rData)
     dump(rData,"RanklistLayer:create  rData")
     local login = RanklistLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.from = login.rData["rcvData"]["from"]
     login.act_id = login.rData["rcvData"]["params"] or 0
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login   
end