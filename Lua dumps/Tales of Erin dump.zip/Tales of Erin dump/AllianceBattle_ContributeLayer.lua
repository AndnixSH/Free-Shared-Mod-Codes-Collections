--- 团站排行的基类根据类型 来设置公用的显示框

AllianceBattle_ContributeLayer= class("AllianceBattle_ContributeLayer",BasicLayer)
AllianceBattle_ContributeLayer.__index        = AllianceBattle_ContributeLayer
AllianceBattle_ContributeLayer.lClass         = 2


function AllianceBattle_ContributeLayer:init()
	local node  = cc.CSLoader:createNode("AllianceBattle_ContributeLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self:SendGet()
    self:initBtn()  
    --SceneManager:showAllianceShop(self.uiLayer )
end
-- 初始btn
function AllianceBattle_ContributeLayer:initBtn( ... )
    -- -- body
    local node     = self.uiLayer:getChildByTag(2)
    local panel    = node:getChildByName("Panel_1")
    local closeBtn = panel:getChildByName("Button_close")
    local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
               -- SceneManager:hideAllianceShop()
               self:returnBack()
            end
    end 
    closeBtn:addTouchEventListener(touchCallBack)

end
-- 向服务器获取数据
function AllianceBattle_ContributeLayer:SendGet( ... )
    -- body
 


    local function reiceSthCallBack(data)
        print("团长公会成员排行")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
         local members = t_data["data"]["members"]
         local table = { }
         table["mem_num"] = t_data["data"]["mem_num"]
         self:setOnlyPer(table)
        self:toPublic(members,table)
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guildbattle_memberrank",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
    --members["table"] = table
    --设置自己应该显示的
    -- self:setOnlyPer(members)
    -- self:toPublic(table,members)

    
end
-- 公用的处理部分
function AllianceBattle_ContributeLayer:toPublic( members,table )
    -- body
    local sData = {}
    sData["table"]    = members
    sData["width"]    = 996
    sData["height"]   = 116
    sData["curType"]  = 3
    sData["itemNode"] = AllianceBattle_ContributeNode
    sData["myTable"]  = table
    sData["titleName"] = UITool.ToLocalization("成员积分")
    self.uiLayer:removeChildByTag(777)
    self.publicRank = AllianceBattle_RankPublicLayer:create(sData)
    self.uiLayer:addChild(self.publicRank.uiLayer,9991,777)
end
-- 设置自己的属性
function AllianceBattle_ContributeLayer:setOnlyPer( dtable )
    -- body
    local node   = self.uiLayer:getChildByTag(2)
    local panel  = node:getChildByName("Panel_1")
    local bg     = panel:getChildByName("Image_memberBg")
    local curNum = bg:getChildByName("Text_curNum")
    local maxNum = bg:getChildByName("Text_curNum_0")
    local nCurNum  = UITool.SubStringToInt( dtable["mem_num"],"/",1)
    local nMaxNum  = UITool.SubStringToInt( dtable["mem_num"],"/",2)
    curNum:setString(tostring(nCurNum))
    maxNum:setString("/"..nMaxNum)
end

function AllianceBattle_ContributeLayer:returnBack( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    self.backFunc(self.sDelegate,self.sData)
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clear()

end
function AllianceBattle_ContributeLayer:create(rData)
    local login = AllianceBattle_ContributeLayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end
