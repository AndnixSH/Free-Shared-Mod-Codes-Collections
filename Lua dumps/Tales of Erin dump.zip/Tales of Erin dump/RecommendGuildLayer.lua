require "BasicLayer"
--[[原 公会推荐 和 公会排行是根据 GuildType 1 推荐 2 排行 
公会改版 （时间）4.10 排行原是二级界面现在需要标签页
所以需要改的排行 需要隐藏]]

RecommendGuildLayer = class("RecommendGuildLayer",BasicLayer)
RecommendGuildLayer.__index = RecommendGuildLayer
RecommendGuildLayer.lClass = 2 
RecommendGuildLayer.ListView     = nil  
RecommendGuildLayer.GuildListTable = nil
RecommendGuildLayer.defaultSelectBtn = nil   -- 1是推荐公会  2  排行按钮
RecommendGuildLayer.isGuild = nil


function RecommendGuildLayer:init()
    local node = nil
    if g_channel_control.show_new_guild_main == true then
        node = cc.CSLoader:createNode("GuildRecommendLayer_new.csb")
    else
        node = cc.CSLoader:createNode("RecommendGuildLayer.csb")
    end
    self.uiLayer:addChild(node,0,2) 
    self.exist = true
            --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)
    
    self:BtnHeighLIght(self.rData["rcvData"]["GuildType"])
    self.defaultSelectBtn = self.rData["rcvData"]["GuildType"]
    self:initWidget();  
    self:initListItem();   
    if g_channel_control.show_new_guild_main == true then
        self:InitTopBarView()
    end
    self:initSearch()
    
  --  self:GuildRecommendSend(self.rData["rcvData"]["GuildType"])
    
    if self.rData["rcvData"]["GuildType"] == 2 then  -- 如果初始化时候获取是2 那么就证明有公会
        self.isGuild = true
    end
    ---第一次进入公会，更改配置文件
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Guild) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Guild, 1)
    end

    --首次进入 显示说明 key 统一用类名吧
    -- if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."RecommendGuildLayer_2") == 0 then
    --     cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."RecommendGuildLayer_2", 1)
    --     self:showNewGuildPic()
    -- end
    --新手
    if XbTriggerGuideManager:isEndGuide(TriggerGuideConfig.Guild) then 
    else 
        self:showNewGuildPic(true)
    end 

end
function RecommendGuildLayer:refreshUI( ... )
    -- body
    self.isNeedRefsh = false
    self:returnBack()
    SceneManager:toGuildMain({})
end
function RecommendGuildLayer:initWidget( ... )
    -- body
    local node            = self.uiLayer:getChildByTag(2)
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
            if name == "Image_Recommend" then -- 推荐
                self.defaultSelectBtn = 1
                self:BtnHeighLIght(self.defaultSelectBtn)
                if g_channel_control.show_new_guild_main == true then
                    self:refreshTopBar(1)
                end
            elseif name == "Image_Rank" then  -- 排行
                self.defaultSelectBtn = 2
                self:BtnHeighLIght(self.defaultSelectBtn)
                if g_channel_control.show_new_guild_main == true then
                    self:refreshTopBar(2)
                end
            elseif name == "Button_CreateGuild" then  -- 创建公会
                local sData = {}
                sData["callFunc"] = self.refreshUI
                sData["self"]     = self
                SceneManager:toCreateGuildLayer(sData)
                if g_channel_control.show_new_guild_main == true then
                    self:refreshTopBar(3)
                end
            elseif name == "Button_Search" then -- 搜索公会
                if g_channel_control.show_new_guild_main == true then
                    self:refreshTopBar(4)
                    self:SearchSend()
                else
                    local sData = {}
                    sData["GuildType"] = self.rData["rcvData"]["GuildType"]
                    sData["callFunc"] = self.refreshUI
                    sData["self"]     = self
                    SceneManager:toSearchGuildLayer(sData)
                end
            elseif name == "Button_close" then  -- 返回按钮
                self:returnBack()
            elseif name == "Button_info"  then  -- 说明按钮
                self:ShowUiInfo() 
            end
       end
    end

   
    local bgMin           = node:getChildByName("Panel_GuildMain")
    self.ListView         = bgMin:getChildByName("ListView_2")
    -- 推荐公会
    local Recommend_Btn    = bgMin:getChildByName("Image_Recommend")
    -- 公会排行
    local Rank_Btn         = bgMin:getChildByName("Image_Rank") 
    -- 公会创建
    local createGuild_Btn  = bgMin:getChildByName("Button_CreateGuild") 
    -- 公会搜索
    local Search_Btn       = bgMin:getChildByName("Button_Search")
    -- 返回按钮
    local  Close_Btn       = bgMin:getChildByName("Button_close")
    Close_Btn:setEffectType(3)
    -- 说明按钮 
    local  buttonInfo      = bgMin:getChildByName("Button_info")

    if self.rData["rcvData"]["GuildType"] == 2 then  -- 公会排行  这是有公会  需要隐藏 创建 和 推荐公会按钮  公会排行按钮
        Rank_Btn:setPosition(Recommend_Btn:getPosition())
        Recommend_Btn:setVisible(false)
        createGuild_Btn:setVisible(false)
        Rank_Btn:setVisible(false)
    end
 
    Recommend_Btn:addTouchEventListener(touchCallBack)
    Rank_Btn:addTouchEventListener(touchCallBack)
    createGuild_Btn:addTouchEventListener(touchCallBack)
    Search_Btn:addTouchEventListener(touchCallBack)
    Close_Btn:addTouchEventListener(touchCallBack)
    if g_channel_control.show_new_guild_main == true then
        buttonInfo:setVisible(false)
    else
        buttonInfo:addTouchEventListener(touchCallBack)
    end
    if self.defaultSelectBtn == 1 then
        Recommend_Btn:loadTexture("uifile/n_UIShare/guild/guild_rank/ghph_b_002_2.png")
    end
    
end
function RecommendGuildLayer:showNewGuildPic(isShowGuide)
    local data = {}
    data.pictures = { --一张或者多张
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
    }
    local function backFunc()
        XbTriggerGuideManager:finishGuide(TriggerGuideConfig.Guild)
    end
    data.sFunc = backFunc 
    data.sDelegate = nil
    data.isShowGuide = isShowGuide or false
    SceneManager:toGuidePictureLayer(data)
end
-- /*说明按钮的回调函数*/
function RecommendGuildLayer:ShowUiInfo( ... )
    -- body
    ---todo 缺图

        -- local data = {}
        -- data.pictures = { --一张或者多张
        --     "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
        --     "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
        --     "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
        -- }
        -- SceneManager:toGuidePictureLayer(data)

        local data = {}
        data.pictures = { --一张或者多张
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
        }
        local sData = {}
        sData["prefix"] = "gh"
        sData["fontSize"] = 20
        sData["Iamgdata"] = data
        SceneManager:toPublicHelpText(sData)
end
--/*初始化公会模板*/
function RecommendGuildLayer:initListItem( ... )
    -- body
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = nil 
    if g_channel_control.show_new_guild_main == true then
        list_item = cc.CSLoader:createNode("GuildItemNode_new.csb")
    else
        list_item = cc.CSLoader:createNode("GuildItemNode.csb")
    end
    
    local  item_1 = list_item:getChildByName("Panel_1")
    local item_c = item_1:clone()
    item_c:setName("item1")
    layout_list:addChild(item_c)
    layout_list:setContentSize(1006,114)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)

end
--/*显示所有或推荐的公会*/
function RecommendGuildLayer:ShowAllGuild( ... )
    -- body
    if self.GuildListTable == nil then
        return
    end
    self.ListView:removeAllChildren()
    local iTable   = self.GuildListTable
    local len      = #iTable
    print("lenlenlenlen =="..len)
    for i = 1,len do
        self.ListView:pushBackDefaultItem()
    end
    for i = 1,len do
        local item = self.ListView:getItem(i - 1)
        local dtable = {
            ["Guildid"]      = self.GuildListTable[i]["id"],            -- 公会ID
            ["GuildName"]    = self.GuildListTable[i]["name"],          -- 公会名字
            ["ranking"]      = self.GuildListTable[i]["ranking"],       -- 公会排行
            ["score"]        = self.GuildListTable[i]["score"],         -- 公会积分
            ["chairman"]     = self.GuildListTable[i]["chairman"],      -- 会长名字
            ["image"]        = self.GuildListTable[i]["image"],         -- 公会形象
            ["mem_num"]      = self.GuildListTable[i]["mem_num"],       -- 公会成员数量      
        }
        ----------------------------------------------------------------------------
        local  panelP     = item:getChildByName("item1")
        local  ItemBg     = panelP:getChildByName("Image_bg")
        local  GuildName  = ItemBg:getChildByName("Text_guildName")
        GuildName:setString(dtable["GuildName"])
        local  chairman   = ItemBg:getChildByName("Text_CDRName")
        chairman:setString(UITool.ToLocalization("会长:")..dtable["chairman"])
        if g_channel_control.RecommendGuildLayer_chairman == true then 
            chairman:setPosition(cc.p(300,31)) --欧美服右移会长名字
        end
        --rank排名
        local GuildRankBg = ItemBg:getChildByName("Panel_rank")
        local  GuildRank  = GuildRankBg:getChildByName("Text_rank")
        GuildRank:setString(dtable["ranking"])

        if g_channel_control.transform_RecommendGuildLayer_GuildRank_pos == true then

            GuildRank:setPosition(cc.p(40 + 80, 14))
      
        end

        local  GuildScore = ItemBg:getChildByName("Text_jifen")
        local str = string.format(UITool.ToLocalization("积分: %d"),dtable["score"])
        GuildScore:setString(str)
        --显示成员的数量
        local  menmberBg  = panelP:getChildByName("Image_1")
        local  guildCur   = menmberBg:getChildByName("Text_cur")
        local  ncur       = UITool.SubStringToInt(dtable["mem_num"],'/',1)
        guildCur:setString(ncur)
        local  guildMax   = menmberBg:getChildByName("Text_Max")
        local  nMax       = UITool.SubStringToInt(dtable["mem_num"],'/',2)
        guildMax:setString("/"..nMax)
        local  ImageIcon  = ItemBg:getChildByName("Image_icon")
        ImageIcon:setUnifySizeEnabled(true)
        local heroid  = tonumber(dtable["image"])
        print("heroid heroid == "..heroid)
        ImageIcon:loadTexture(hero[heroid].hero_bat_icon)

        if self.defaultSelectBtn == 1 then  -- 公会推荐
            GuildRankBg:setVisible(false)
            menmberBg:setVisible(true)
        elseif self.defaultSelectBtn == 2 then -- 公会排行
            menmberBg:setVisible(false)
            GuildRankBg:setVisible(true)
        else
            menmberBg:setVisible(true)
            GuildRankBg:setVisible(true)
        end
        print("self.defaultSelectBtn == "..self.defaultSelectBtn)
        local function touchCallBack(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                self:BaseInfoSend(dtable["Guildid"])
            end
        end
        panelP:addTouchEventListener(touchCallBack)

    end
end
-- /*获取选择公会的最基本信息*/
function RecommendGuildLayer:BaseInfoSend( guildId  )
    -- body
    local function reiceSthCallBack(data)
        print("获取推荐公会单一的最基本信息")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        --t_data = nil
        if t_data == nil then 
           
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        self.rData["guildData"] = t_data["data"]  
        self.rData["guild_id"]  = guildId
        self.rData["GuildType"] = self.defaultSelectBtn -- 1 推荐公会  2 公会排行
        self.rData["callFunc"]  = self.refreshUI
        self.rData["self"]      = self
        if self.rData["rcvData"]["GuildType"] == 2 then -- 如果初始化时候获取是2 那么就证明有公会
            if self.isGuild then
                self.rData["isGuild"]  = true
            end
        end  
      
        SceneManager:toGuildBaseInfoLayer(self.rData)
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "guild_basic",
        ["guild_id"] = guildId , -- 推荐  2 排行
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--/*控制排行 推荐那个高亮*/
function RecommendGuildLayer:BtnHeighLIght( CurIndex )
    -- body
    local node            = self.uiLayer:getChildByTag(2)
    local bgMin           = node:getChildByName("Panel_GuildMain")
    -- 推荐公会
    local Recommend_Btn    = bgMin:getChildByName("Image_Recommend")
    -- 公会排行
    local Rank_Btn         = bgMin:getChildByName("Image_Rank") 
    local TitleName        = bgMin:getChildByName("Text_title")
    if CurIndex == 1 then   -- 公会推荐
        Recommend_Btn:loadTexture("uifile/n_UIShare/guild/guild_rank/ghph_b_002_2.png")
        Rank_Btn:loadTexture("uifile/n_UIShare/guild/guild_rank/ghph_b_001_1.png")
        self:GuildRecommendSend(1)
        TitleName:setString(UITool.ToLocalization("公会推荐"))
    elseif CurIndex == 2 then -- 排行
        Recommend_Btn:loadTexture("uifile/n_UIShare/guild/guild_rank/ghph_b_002_1.png")
        Rank_Btn:loadTexture("uifile/n_UIShare/guild/guild_rank/ghph_b_001_2.png")
        self:GuildRecommendSend(2)
        TitleName:setString(UITool.ToLocalization("公会排行"))
    end
end
----/*公会推荐  获取服务器数据*/
function RecommendGuildLayer:GuildRecommendSend( ntype )
    -- body
    local function reiceSthCallBack(data)
        print("获取推荐公会List")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            
             MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end
        self.GuildListTable = t_data["data"]["guild_list"]
        self:ShowAllGuild() 
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guild_list",
        ["list_type"] = ntype , -- 推荐  2 排行
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
function RecommendGuildLayer:returnBack( param )
    -- body
     -- self.sManager:removeFromNavNodes(self)
     -- self.backFunc(self.sDelegate)
     -- self.exist = false
     -- self:clear()
    if self.sManager ~= nil then
        self.sManager:removeFromNavNodes(self)
    end
    
    self.sData = {}
    -- self.backFunc = self.sManager.toTestGuildMainLayer
    -- self.backFunc(self.sManager,self.sData)

    --说明：这个地方用于加入公会的时候回调，不加入公会，或者无操作，直接返回。
    --先这样吧，到时候公会主界面没有公会状态出来再说
    --local isNeedRefsh = true
    if self.isNeedRefsh  then 
        if self.backFunc then 
            self.backFunc(self.sDelegate)
        end 
    end 

    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clearEx()
end

function RecommendGuildLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function RecommendGuildLayer:create(rData)

     local login = RecommendGuildLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     --[[公会排行 需要标签页的形式]]
     if login.rData["rcvData"]["GuildType"] == 2 then 

     else
        login.backFunc  = login.rData["rcvData"]["sFunc"]
        login.sDelegate = login.rData["rcvData"]["sDelegate"] 
     end

     login.uiLayer   = cc.Layer:create()
     login:init()
     login.isNeedRefsh = true
     return login
     
end

function RecommendGuildLayer:InitTopBarView()
    --topbar节点 
    local node = self.uiLayer:getChildByTag(2)
    topBarViewPanel = node:getChildByName("TopBarPanel")
    self.topBarViews = XUIView.new():init(topBarViewPanel)
    local iteamDatas = {}
    local rcvData = {}
    rcvData["sIteamDatas"] = iteamDatas
    rcvData["bIsStartLayer"] = false
    rcvData["nInfoState"] = table.getValue("coinbar",coinbar,65,"coinbar_type")
    rcvData["nTitleNum"] = 7

    self.topBarView = TopBarView.new():init(rcvData)
    self.topBarViews:addSubView(self.topBarView)
    self:InitSociatyRecommendTopBarView()
end

function RecommendGuildLayer:InitSociatyRecommendTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,65,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

function RecommendGuildLayer:InitSociatyRankTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,66,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

function RecommendGuildLayer:InitSociatyCreateTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,65,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

function RecommendGuildLayer:InitSociatySearchTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,65,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

-- 当货币栏中有不是金币，体力和星石时，需要单独刷洗数据 (根据不同的类型数据存入array_cointype中),具体类型参考cointype表 
function RecommendGuildLayer:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
            if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end

function RecommendGuildLayer:refreshTopBar(_type)
    local switch = 
    {
        [1] = function()
            self:InitSociatyRecommendTopBarView()
        end,
        [2] = function()
            self:InitSociatyRankTopBarView()
        end,
        [3] = function()
            self:InitSociatyCreateTopBarView()
        end,
        [4] = function()
            self:InitSociatySearchTopBarView()
        end
    }
    local f = switch[_type]
    if f then
        f()
    else
        print("调用TopBar错误")
    end
end

function RecommendGuildLayer:initSearch()
    if g_channel_control.show_new_guild_main == true then
        local node = self.uiLayer:getChildByTag(2)
        local bgMin = node:getChildByName("Panel_GuildMain")
        self.Panel_find = bgMin:getChildByName("Panel_find")
        self.TextField_find = self.Panel_find:getChildByName("TextField_find")
        self.TextField_find:setString(UITool.ToLocalization("输入关键字进行搜索"))
        self.Button_clear_key = self.Panel_find:getChildByName("Button_clear_key")
        self.Button_clear_key:setVisible(false)

        self.Panel_find:addClickEventListener(function()  
            print("点击输入框")
           self:popInputView()
        end)
        self.Button_clear_key:addClickEventListener(function()  
           self.TextField_find:setString("")
           self.Button_clear_key:setVisible(false)
        end)  
    end
end

function RecommendGuildLayer:popInputView( ... )
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    rcvData["confirmFunc"] =  function(self,text)
        self.TextField_find:setString(text)
        if text ~= nil and text ~= "" then
            self.Button_clear_key:setVisible(true)
        end
    end
    rcvData["defalutStr"] = self.TextField_find:getString()
    rcvData["maxLength"] = 8
    SceneManager:toInputModelLayer(rcvData)
end

--获得搜索的关键字
function RecommendGuildLayer:getSearchKey()
    local key = self.TextField_find:getString()
    return key
 
end

function RecommendGuildLayer:SearchSend( ... )
    -- body
    if self.TextField_find:getString() == "" then
        MsgManager:showSimpMsg(UITool.ToLocalization("请输入搜索公会名字"))
        return
    end
    local function reiceSthCallBack(data)
        print("搜索公会")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
             MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

              MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["guild_list"][1] then   -- 有值证明找到了公会
            local sData = {}
            sData["guildData"] = t_data["data"]["guild_list"][1]  -- 1 推荐公会  2 公会排行
            sData["guild_id"]  = t_data["data"]["guild_list"][1]["id"]
            sData["GuildType"] = self.rData["rcvData"]["GuildType"]
            sData["callFunc"] = self.refreshUI
            sData["self"]      = self
            SceneManager:toGuildBaseInfoLayer(sData)
        else -- 没有搜索到
            MsgManager:showSimpMsg(UITool.ToLocalization("您输入的公会不存在"))
            return
        end
    end
    self.sManager:createWaitLayer()
    local cjson = require "cjson"


    local tempTable = {
        ["rpc"]       = "guild_search",
        ["guild_name"] = self.TextField_find:getString(),
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
