--格挡护盾组件（减免固定值伤害）
--created by kobejaw. 2018.6.8.
Com_B_ReduceDmg = class("Com_B_ReduceDmg",ComponentBase)

--81052
function Com_B_ReduceDmg:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.ReduceDmg
	
	--格挡的数值
	self.blockNum = self.comData.effect1
end
