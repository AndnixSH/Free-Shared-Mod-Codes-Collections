--特殊状态的buff组件。例如无敌，嘲讽，锁血，变身，提线傀儡，特殊标识（81050中除lv4之外，81055的lv2）,忘我之境（81024中lv大于30的），恶鬼缠刃
--created by kobejaw. 2018.6.8.
Com_B_SpecialState = class("Com_B_SpecialState",ComponentBase)

function Com_B_SpecialState:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.SpecialState
	self:init()
end

function Com_B_SpecialState:init()
	local comId = self.comId
	local lv = self.level
	--无敌
	if comId == 81036 or comId == 81037 or (comId == 81044 and lv == 11) then
		self.type = 1
	--嘲讽
	elseif comId == 81040 then
		self.type = 2
		self.gameTime = BattleUIManager.battleInfoManager.gameTime or 0 --当前游戏时间，用来排序
	--血量锁定为1，可以被加血
	elseif comId == 81043 then
		self.type = 3
	--血量锁定为1，无敌，可以被加血，增加100%暴击率
	elseif comId == 81044 and lv <= 10 then
		self.type = 4
	--提线傀儡
	elseif comId == 81997 then
		self.type = 5
	--boss下次攻击必使用特殊技的标识
	elseif (comId == 81050 and lv ~= 4) or (comId == 81055 and lv == 2) then
		self.type = 6
	--忘我之境。只是一个可叠加的标识
	elseif comId == 81024 and lv > 30 then --目前没用到，告诉策划以后也别用
		self.type = 7
	--恶鬼缠刃。恢复力变为0。攻击力，暴击率上升，攻击间隔下降。
	elseif comId == 81038 then
		self.type = 8
	--玛欧的变身。(唯一一个既换技能又改动角色动作的。其他的所谓变身其实只是换技能)
	elseif comId == 81042 then
		self.type = 9
	--灵魂色谱.只是一个可叠加的标识。
	elseif comId == 81977 then
		self.type = 10
	--霸体
	elseif comId == 81055 and lv ~= 2 then
		self.type = 11
	--灵剑乱舞
	elseif comId == 81050 and lv == 4 then
		self.type = 12
	--伤害转移
	elseif comId == 81068 then
		self.type = 13
	end
end

--开始生效。
function Com_B_SpecialState:takeEffect(isAdd)
	if self.type == 3 then
		if isAdd then
			if self.target.attr[AE.hp] <= 1 then
				self.target.attributeManager:changeAttr(AE.hp,1)
			end
		end
	elseif self.type == 4 then
		if isAdd then
			if self.target.attr[AE.hp] <= 1 then
				self.target.attributeManager:changeAttr(AE.hp,1)
			end
			self.target.attributeManager:changeAttr(AE.add_crit_rate,100)
		else
			self.target.attributeManager:changeAttr(AE.add_crit_rate,-100)
		end
	elseif self.type == 8 then
		local value1 = self.comData.effect2
		local value2 = self.comData.effect3
		local value3 = self.comData.effect4
		if not isAdd then			
			value1 = -value1
			value2 = -value2
			value3 = -value3
		end
		self.target.attributeManager:changeAttr(AE.add_atk,value1)
		self.target.attributeManager:changeAttr(AE.add_crit_rate,value2)
		self.target.attributeManager:changeAttr(AE.reduce_interval,value3)		
	elseif self.type == 9 then
		local value1 = self.comData.effect1
		local value2 = self.comData.effect2		

		if isAdd then
			self.target.isBianshen = true
			if value1 ~= 0 then
				self.target.skill[1]:changeSkill(value1)
			elseif value2 ~= 0 then
				self.target.skill[2]:changeSkill(value2)
			end
		else
			self.target.isBianshen = false
			if value1 ~= 0 then
				self.target.skill[1]:changeBackSkill()
			elseif value2 ~= 0 then
				self.target.skill[2]:changeBackSkill()
			end
		end
	end
	self.super.takeEffect(self,isAdd)
end