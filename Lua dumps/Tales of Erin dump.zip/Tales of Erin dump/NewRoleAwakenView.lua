--require "XUIView"

NewRoleAwakenView = class("NewRoleAwakenView",XUIView)
NewRoleAwakenView.CS_FILE_NAME = "NewRoleAwakenView.csb"
NewRoleAwakenView.CS_BIND_TABLE = 
{
    panelEffect = "/i:118",
    effMagic = "/i:118/s:effMagic",
    effNum = "/i:118/s:effNum",
    effNum2 = "/i:118/s:effNum2",

    awk1 = "/i:283/i:858",
    awk2 = "/i:283/i:859",
    awk3 = "/i:283/i:860",
    awk4 = "/i:283/i:861",
    awk5 = "/i:283/i:862",
    lbAwkNum = "/i:283/i:865",
    lbAwake = "/i:283/i:864",

    --
    spAwakeLimit = "/i:283/i:873",
    spAwakeMax = "/i:283/i:869",

    panelLvUpInfo = "/i:283/i:857",

    lbLvNow = "/i:283/i:857/i:63/i:83",
    lbLvNew = "/i:283/i:857/i:63/i:84",
    lbSP = "/i:283/i:857/i:64/i:85",

    lbGoldCost = "/i:283/i:857/i:105",
    lbGoldMax = "/i:283/i:857/i:104",

    btnAwaken = "/i:283/i:301",

    matPanel1 = "/i:283/i:287",
    matIcon1 = "/i:283/i:287/i:290",
    matCurNum1 = "/i:283/i:287/i:1439",
    matNeedNum1 = "/i:283/i:287/i:1438",

    matPanel2 = "/i:283/i:292",
    matIcon2 = "/i:283/i:292/i:295",
    matCurNum2 = "/i:283/i:292/i:1441",
    matNeedNum2 = "/i:283/i:292/i:1440"
}

function NewRoleAwakenView:init(hero_id,ReLoadCallFunc,sDelegate)
    NewRoleAwakenView.super.init(self)

    self.hero_id = hero_id

    self.ReLoadCallFunc = ReLoadCallFunc
    self.sDelegate = sDelegate

    self.panelEffect:setVisible(false)

    self.btnAwaken:addClickEventListener(function()
        self:onRoleAwaken()
    end)

    --
    self.matPanel1:setTouchEnabled(true)
    self.matPanel2:setTouchEnabled(true)
    --
    self.panelLvUpInfo:setVisible(true)
    self.spAwakeMax:setVisible(false)
    self.spAwakeLimit:setVisible(false)

     if g_channel_control.transform_NewRoleAwakenView_lbAwake_Alignment == true then 
        self.lbAwake:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.lbAwake:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.lbAwake:ignoreContentAdaptWithSize(false);
        self.lbAwake:setTextAreaSize(cc.size(180,64))
        self.lbAwake:setPosition(cc.p(475,380))
        -- self.lbAwake:setFontSize(28)

    end 

    self:loadBagList()

    return self
end

function NewRoleAwakenView:FillHeroData(rcvData)
    if rcvData then
        self.hero_data = nil
        self.hero_data = table.deepcopy(rcvData)
        self.hero_id = self.hero_data.id
        self:refreshPropNum()
    end
end

function NewRoleAwakenView:ResetHeroId(hero_id)
    if hero_id then
        self.hero_id = hero_id
        self:loadBagList()
    end
end

function NewRoleAwakenView:AwakenMaxLimit(bMax,bLimit)--参数1:是否满解放，参数2:是否达到4解放
    if bMax then
        self.panelLvUpInfo:setVisible(false)
        self.spAwakeMax:setVisible(true)
        self.spAwakeLimit:setVisible(false)
    else
        self.spAwakeMax:setVisible(false)
        if bLimit then
            local bLimit5 = 0
            if self.hero_data then
                print("self.hero_data.break5_unlocked", self.hero_data.break5_unlocked)
                bLimit5 = self.hero_data.break5_unlocked
            end
            if bLimit5 and bLimit5 == 1 then
                self.spAwakeLimit:setVisible(false)
                self.panelLvUpInfo:setVisible(true)
            else
                self.spAwakeLimit:setVisible(true)
                self.panelLvUpInfo:setVisible(false)
                --
                self.bCanAwaken = false
                self.btnAwaken:setTouchEnabled(false)
                self.btnAwaken:setBright(false)
            end
        else
            self.panelLvUpInfo:setVisible(true)
            self.spAwakeLimit:setVisible(false)
        end
    end
end

function NewRoleAwakenView:refreshPropNum()

    self.matPanel1:setVisible(false)
    self.matPanel1:addTouchEventListener(function()end)
    self.matPanel2:setVisible(false)
    self.matPanel2:addTouchEventListener(function()end)

    self.lbLvNew:setString("")
    self.lbLvNow:setString("")
    self.lbSP:setString("")
    self.lbGoldMax:setString(""..user_info["gold"])

    if self.hero_data then
        local h_id_num = getNumID( self.hero_id )
        local data = self.hero_data

        local break_count = data.break_count
        local break_limit = hero[h_id_num]["hero_break"].total_break

        --突破次数
        for i = 1,5 do
            if break_count>= i then
                self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_145.png")
            else
                self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
            end
        end
        if g_channel_control.b_Astrolabe then
            if break_limit >= 5 then
                self["awk5"]:setVisible(true)
            else
                self["awk5"]:setVisible(false)
            end
        else
            self["awk5"]:setVisible(false)
        end
        self.lbAwkNum:setString(break_count.."/"..break_limit)
        --
        
        if break_count == break_limit then
            --满破
            self.bCanAwaken = false
            self.lbLvNow:setString("")
            self.lbLvNew:setString("")
            self.lbSP:setString("")

            self.btnAwaken:setTouchEnabled(false)
            self.btnAwaken:setBright(false)

            self.lbGoldCost:setString("0")
        else
            local brkInfo = hero[h_id_num]["hero_break"]["break_"..(break_count + 1)]
            local mat_count = #brkInfo["break_mat"]
            for i = 1,mat_count do

                self["matPanel"..i]:setVisible(true)
                local mat_id = brkInfo["break_mat"][i].mat_id
                local mat_id_num = getMatID(mat_id)
                local mat_num = brkInfo["break_mat"][i].mat_num

                self["matPanel"..i]:addTouchEventListener(function(sender,eventType)
                    if eventType == ccui.TouchEventType.ended then
                        if GameManagerInst.gameType == 2 then
                            MsgManager:showSimpItemInfoAndDropInfo(5,mat_id_num,true,self.onMatChanged,self)
                        end
                    end
                end)

                local mat_face = mat[mat_id_num]["icon"]
                if mat_face then
                    self["matIcon"..i]:setTexture("icons/mat/"..mat_face)
                end
                self["matNeedNum"..i]:setString(""..mat_num)

                local have_count = user_info["bag"]["mat"][mat_id]
                if have_count == nil then have_count = 0 end

                self["matCurNum"..i]:setString(""..have_count)
                if have_count < mat_num then
                    --不够
                    self["matCurNum"..i]:setTextColor(cc.c3b(255,0,0))
                else
                    self["matCurNum"..i]:setTextColor(cc.c3b(255,236,160))
                end
            end

            self.bCanAwaken = true
            self.lbLvNow:setString(""..data["Lv_max"])
            self.lbLvNew:setString(""..brkInfo["break_maxlv"])
            self.lbSP:setString(""..brkInfo["break_add_tp"])
            

            self.btnAwaken:setTouchEnabled(true)
            self.btnAwaken:setBright(true)

            --显示钱

            self.lbGoldCost:setString(""..brkInfo["break_gold"])

        end
        self:AwakenMaxLimit((break_count >= break_limit),(break_count >= 4))--TODO：limit参数改为读取luadata
    else
        self.bCanAwaken = nil
        --未选择角色
        self.lbLvNow:setString("")
        self.lbLvNew:setString("")
        self.lbSP:setString("")

        self.btnAwaken:setTouchEnabled(false)
        self.btnAwaken:setBright(false)

        self.lbGoldCost:setString("0")
        --
        --突破次数
        for i = 1,5 do
            self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
        end
        self.lbAwkNum:setString("0/5")
    end
end

function NewRoleAwakenView:onMatChanged()
    if self.matChangedEvent then
        self.matChangedEvent(self)
    end
    self:loadBagList()
end

function NewRoleAwakenView:playEffect()
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)

    local effs = {
        {self.effMagic,"EffAwkMagic.csb"},
        {self.effNum,"EffAwkNum.csb"},
        {self.effNum2,"EffAwkNum.csb"}
    }

    for i = 1,#effs do
        local node_1 = cc.CSLoader:createNode(effs[i][2])
        local timeline_1 =cc.CSLoader:createTimeline(effs[i][2])
        node_1:setTag(123)
        local psize = effs[i][1]:getSize()
        node_1:setPosition(cc.p(psize.width/2,0))
        effs[i][1]:addChild(node_1)

        node_1:runAction(timeline_1)
        timeline_1:play("animation0",false) 
        timeline_1:setLastFrameCallFunc(function ()
            node_1:stopAllActions()
            node_1:removeFromParent()
        end)
    end
              
    AudioManager:shareDataManager():playMusic("music/ui/tupo.mp3",0, false)   
     
    local delay = cc.DelayTime:create(1.3)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:stopEffect()
    end))
    self.panelEffect:runAction(sequence)    
end

function NewRoleAwakenView:stopEffect()
    KeyboardManager._isShowEffect = false
    self.panelEffect:stopAllActions()

    local effs = {
        self.effMagic,
        self.effNum,
        self.effNum2
    }

    for i = 1,#effs do
        local e = effs[i]:getChildByTag(123)
        if e then e:stopAllActions() end
        effs[i]:removeAllChildren()
    end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    
    if self.effectStopedEvent then
        self.effectStopedEvent(self)
    end
    
    self:refreshPropNum()
end

function NewRoleAwakenView:onRoleAwaken()
    if not self.bCanAwaken then return end

    if self.hero_id then
        local tempId = self.hero_id
        
        GameManagerInst:rpc(
            {
                rpc = "hero_brk",
                target_hero_id = tempId
            },3,
            function(data)            
                --success
                if self.ReLoadCallFunc then
                    self.ReLoadCallFunc(self.sDelegate)
                end
                DataManager:roleBthEnd(tempId, data) 

                if  #data["data"][tempId]["team_list"] > 0  then
                    self:loadTeamList(function()
                        self:playEffect()
                    end)
                else
                    self:playEffect()
                end
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText)
            end,
            true)
    end
end

function NewRoleAwakenView:loadBagList()
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        DataManager:wAllBagData(data["bag"])
        self:refreshPropNum()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleAwakenView:loadTeamList(callback)

    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success
        DataManager:wTeamData(data["team"])   

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end