--require "XUIView"
--require "RoleAwakenView"
--require "RoleSthView"
--require "RoleTeamView"
--require "RoleListView"
--require "SortBoxView"

GalleryView = class("GalleryView",XUIView)
GalleryView.CS_FILE_NAME = "GalleryView.csb"
GalleryView.CS_BIND_TABLE = 
{
    panelBG = "/s:panelBG",
    panelButtons = "/s:panelButtons",
    panelRole = "/s:panelRole",
    panelRoleList = "/s:panelRole/s:panelList",
    panelViews = "/s:panelViews",
    cntNum1 = "/s:panelRole/s:panelPer/s:Text_1_0",
    cntNum2 = "/s:panelRole/s:panelPer/s:Text_1",
    titleName = "/s:panelRole/s:Text_7",
    --cntNumS = "/s:panelRole/s:panelPer/s:Text_1_1",

    panelNumMat = "/s:panelRole/i:685",
    cntNumMat = "/s:panelRole/i:685/i:688",
    
    btnTab1 = "/i:190/i:55",
    btnTab2 = "/i:190/i:191",
    btnTab3 = "/i:190/i:22",
    
    btnClose="/i:205/i:92",
}
GalleryView.needReload = false

function GalleryView:init()
    GalleryView.super.init(self)

    -- local bganime = sp.SkeletonAnimation:create("effects/Diban/Diban.json", "effects/Diban/Diban.atlas", 1.0)
    -- local psize = self.panelBG:getSize()
    -- self.panelBG:addChild(bganime)
    -- bganime:setPosition(cc.p(psize.width / 2, psize.height / 2))
    -- bganime:setAnimation(1, "effect", true)

    self.cntNum1:setString("0")
    self.cntNum2:setString("0")

    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)
    
    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    self.cntNumMat:setString("")

    local psize = self.panelRoleList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelRoleList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = XUICellView.new():init(nil,"GalleryItemView.csb",{
            imgBG = "/i:29/i:30/s:imgBG",
            imgFace = "/i:29/i:30/s:imgFace",
            imgRarity = "/i:29/i:30/s:imgRarity",
            imgElement = "/i:29/i:30/s:imgElement",
            shadowCover = "/i:29/i:298",
            nameColor = "/i:29/i:42/i:50",
            nameGray = "/i:29/i:42/i:87",
            nameGrayBg = "/i:29/i:42/i:48",
        })

        temp.onResetData = function(self)
            local nname = nil
            local face = nil

            if self._data.h_num_id then
                --角色
                local h_id_num = self._data.h_num_id
                face = hero[h_id_num].hero_list_icon  
                nname = UITool.getUserLanguage(hero[h_id_num].hero_name)--hero[h_id_num].hero_name
            elseif self._data.eq_num_id then
                --装备
                local eq_num_id = self._data.eq_num_id
                face = equip[eq_num_id].equip_list_icon
                nname = UITool.getUserLanguage(equip[eq_num_id].equip_name)--equip[eq_num_id].equip_name
            else
                return
            end

            local natb = self._data.atb
            local nrank = self._data.rank

            
            local frame = Rarity_Icon[nrank]  --外框
            --Rarity_BG  --背景
            if frame then
                self.imgRarity:setTexture(frame)
            end

            local rbg = Rarity_E_BG[nrank]   --背景
            if rbg then
                self.imgBG:setTexture(rbg)
            end

            local element = ATB_Icon[natb] --属性球

            if element then
                self.imgElement:setTexture(element)
            end

            if face then
                self.imgFace:setTexture(face)
                if self._data.got then
                    self.imgFace:setColor(cc.c3b(255,255,255))
                else
                    self.imgFace:setColor(cc.c3b(0,0,0))
                end
            end

            if g_channel_control.transform_GalleryItemView_name == true then 
                self.nameColor:setPosition(cc.p(86,55))
                self.nameColor:setAnchorPoint(cc.p(0.5,1))
                self.nameColor:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                self.nameColor:ignoreContentAdaptWithSize(false);
                self.nameColor:setTextAreaSize(cc.size(130,50))

                self.nameGray:setPosition(cc.p(86,55))
                self.nameGray:setAnchorPoint(cc.p(0.5,1))
                self.nameGray:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                self.nameGray:ignoreContentAdaptWithSize(false);
                self.nameGray:setTextAreaSize(cc.size(130,50))

                self.nameGrayBg:setVisible(false)
            end

            self.nameColor:setString(nname)
            self.nameGray:setString(nname)
            if g_channel_control.transform_GalleryView_nameGray_fontSize == true then 
                self.nameGray:setFontSize(16)
                self.nameColor:setFontSize(16)
            end
            --self.shadowCover:setVisible( not self._data.got )           
            self.shadowCover:setVisible(false)
            self.nameColor:setVisible(self._data.got) 
            self.nameGray:setVisible( not self._data.got )
        end

        return temp
    end
    self.gridview.itemClickedEvent = function (sender,index)
        local data = sender:getDataSource()[index]
        if data.h_num_id then
            self:showRoleGallery(index)
        elseif data.eq_num_id then
            self:showEquipGallery(index)
        end
    end
    
    self.panelButtons:setLocalZOrder(1)
    --玩家信息
    local sData = {}
    sData["sManager"] =  SceneManager
    sData["rcvData"]  =  {} 
    self.playerCard = PlayerCardLayer:create(sData)
    self.panelViews:addChild(self.playerCard.uiLayer)
    --

    self:switchView()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    
    return self
end 

function GalleryView:switchView(tab)
    local num = tab or 1
    if self.curTab ~= num then
        self.curTab = num
    
        if num == 1 then
            --玩家信息
            self.panelRole:setVisible(false)
            self.playerCard.uiLayer:setVisible(true)
        elseif num == 2 then
            --角色图鉴
            self.panelRole:setVisible(true)
            self.playerCard.uiLayer:setVisible(false)
            self.titleName:setString(UITool.ToLocalization("角色图鉴"))
            self:refreshRoleList()
            if not self.roleDataSource then
                self:loadGalleryInfo()
            end

            self.panelNumMat:setVisible(true)

        elseif num == 3 then  
            -- 灵装图鉴
            self.panelRole:setVisible(true)
            self.playerCard.uiLayer:setVisible(false)
            self.titleName:setString(UITool.ToLocalization("灵装图鉴"))

            self:refreshEquipList()
            if not self.equipDataSource then
                self:loadGalleryInfo()
            end

            self.panelNumMat:setVisible(false)
        end

        self.btnTab1:setTouchEnabled(num ~= 1)
        self.btnTab1:setBright(num ~= 1)

        self.btnTab2:setTouchEnabled(num ~= 2)
        self.btnTab2:setBright(num ~= 2)

        self.btnTab3:setTouchEnabled(num ~= 3)
        self.btnTab3:setBright(num ~= 3)
        
    end
end

function GalleryView:refreshRoleList()
    if not self.roleDataSource then
        self.gridview:setDataSource(nil)
        self.cntNum1:setString("")
        self.cntNum2:setString("")
        self.cntNumMat:setString("")
    else
        self.gridview:setDataSource(self.roleDataSource)
        
        local cntgot = 0
        for k,v in pairs(self.roleDataSource) do  
            if v.got then
                cntgot = cntgot + 1
            end
        end

        self.cntNum1:setString(""..cntgot)
        self.cntNum2:setString(""..#self.roleDataSource)

        local nmat = user_info["bag"]["mat"][ID_HERO_OPT] or 0

        self.cntNumMat:setString(""..nmat)
    end
end

function GalleryView:showRoleGallery(index)
    local tempds = {}
    for i = 1,#self.roleDataSource do
        local j = self.roleDataSource[i]
        if j.got then
            tempds[i] = ""..j.h_num_id.."*"..1 
        else
            tempds[i] = ""..j.h_num_id.."*"..0
        end
    end

    local roleinfo = self.roleDataSource[index]
    if GameManagerInst.gameType == 2 then
        if roleinfo.got then    
            SceneManager:toRoleInfo({ hid = ""..roleinfo.h_num_id.."*"..1 ,hlist = tempds})
        else
            SceneManager:toRoleInfo({ hid = ""..roleinfo.h_num_id.."*"..0 ,hlist = tempds})
        end
    end
end

function GalleryView:refresh()
    if self.curTab == 2 then
        self:refreshRoleList()
    elseif self.curTab == 3 then
        self:refreshEquipList()
    end
end

function GalleryView:makeRoleDS(hero_ids)
    local temp = {}
    for k,v in pairs(hero_open) do
        local hf = hero[k]
        if hf then
            temp[k] = { 
                h_num_id = k, 
                atb = hf.hero_atb,
                rank = hf.hero_rank,
                got = false}
        end
    end

    for k,v in pairs(hero_ids) do
        local tempobj = temp[v]
        if tempobj then
            tempobj.got = true
        end
    end

    local ds = {}

    for k,v in pairs(temp) do
        table.insert(ds,v)
    end

    table.sort(ds,function(a,b)
        if a.atb ~= b.atb then
            return a.atb < b.atb
        elseif a.rank ~= b.rank then
            return a.rank > b.rank
        else
            return a.h_num_id < b.h_num_id
        end
    end)

    self.roleDataSource = ds
end

function GalleryView:loadGalleryInfo(callback)
    GameManagerInst:rpc("{\"rpc\":\"gallery_info\"}",3,
    function(data)
        --success

        local ho = data.hero_open

        hero_open = {}
        for _,v in pairs(ho) do
            hero_open[v.hero_id] = table.deepcopy(v)
        end

        local eo = data.eq_open

        eq_open = {}
        if eo then
            for _,v in pairs(eo) do
                eq_open[v.id] = table.deepcopy(v)
            end
        end

        local tempmat = {}
        tempmat[ID_HERO_OPT] = data.opt_count
        DataManager:wAllBagData({mat = tempmat})

        self:makeRoleDS(data.hero)
        self:makeEquipDS(data.equip)
        self:refresh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function GalleryView:makeEquipDS(eq_ids)
    local temp = {}
    for k,v in pairs(eq_open) do
        local ef = equip[k]
        if ef then
            temp[k] = { 
                eq_num_id = k, 
                atb = ef.equip_atb,
                rank = ef.equip_rank,
                got = false}
        end
    end

    for k,v in pairs(eq_ids) do   
        local tempobj = temp[v]
        if tempobj then
            tempobj.got = true
        end
    end

    local ds = {}

    for k,v in pairs(temp) do
        table.insert(ds,v)
    end

    table.sort(ds,function(a,b)
        if a.atb ~= b.atb then
            return a.atb < b.atb
        elseif a.rank ~= b.rank then
            return a.rank > b.rank
        else
            return a.eq_num_id < b.eq_num_id
        end
    end)

    self.equipDataSource = ds
end

function GalleryView:showEquipGallery(index)    
    local tempds = {}
    for i = 1,#self.equipDataSource do
        local j = self.equipDataSource[i]
        if j.got then
            tempds[i] = ""..j.eq_num_id.."*"..1 
        else
            tempds[i] = ""..j.eq_num_id.."*"..0
        end
    end

    local eqinfo = self.equipDataSource[index]
    if GameManagerInst.gameType == 2 then
        if eqinfo.got then    
            SceneManager:toEquipInfo({ eid = ""..eqinfo.eq_num_id.."*"..1, elist = tempds})
        else
            SceneManager:toEquipInfo({ eid = ""..eqinfo.eq_num_id.."*"..0, elist = tempds})
        end
    end
end

function GalleryView:refreshEquipList()
    if not self.equipDataSource then
        self.gridview:setDataSource(nil)
        self.cntNum1:setString("")
        self.cntNum2:setString("")
    else
        self.gridview:setDataSource(self.equipDataSource)
        
        local cntgot = 0
        for k,v in pairs(self.equipDataSource) do  
            if v.got then
                cntgot = cntgot + 1
            end
        end

        self.cntNum1:setString(""..cntgot)
        self.cntNum2:setString(""..#self.equipDataSource)
    end
end

function GalleryView:returnBack()
    -- 定义在 SceneManager
end

function GalleryView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        if GalleryView.needReload then
            GalleryView.needReload = false
            self:loadGalleryInfo()
        end
    else
        GalleryView.needReload = false
    end
end