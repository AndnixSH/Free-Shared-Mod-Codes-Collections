--require "XUIView"
--require "XUIGridView"
--require "RoleListItemView"
--require "BackgroundView"

RoleIntimacyView = class("RoleIntimacyView",XUIView)
RoleIntimacyView.CS_FILE_NAME = "RoleIntimacyView.csb"
RoleIntimacyView.CS_BIND_TABLE = 
{
    btnClose = "/i:513/i:58",
    spRoleName = "/i:332/i:357",
    roleIconPos = "/i:332/s:roleIconPos",
    lbIntimacyNum = "/i:332/i:529",
    lbAddAtkNum = "/i:332/i:531",
    lbAddHpNum = "/i:332/i:532",
    
    btn_1 = "/i:332/i:514",
    btn_2 = "/i:332/i:515",
    btn_3 = "/i:332/i:516",
    btnGM = "/i:332/i:533",

    btnEffectPos = "/i:332/i:209",

    --好感度新增特效 start
    btnGMEffectPos = "/i:332/i:613",
    btnGMEffectPosOnce = "/i:614",
    --好感度新增特效 end

    panelTouch = "/s:panelTouch",
}

RoleIntimacyView.effectFile = "Resources/armatures/intimacy/gong_ming_jie_suo/gong_ming_jie_suo.atlas" --解锁特效资源路径

function RoleIntimacyView:init(hero_id)
    RoleIntimacyView.super.init(self)

    self.exist = true

    self.hero_id = hero_id
    local h_id_num = getNumID( self.hero_id )
    --
    self.intimacyNum = 0 --

    self.unlockStates = {0,0,0} --

    self.intimacyId = 0 --
    self.max_lv = 0 --
    self.resonance = 0 --是否共鸣 0-否 1-是
    self.resonance_lv = 0 --可以共鸣的等级

    self.atk_rate = 0 --属性1加成百分比
    self.hp_rate = 0 --属性2加成百分比

    self.resonance_prop_num = 0 --共鸣道具数量
    self.resonance_prop_lv = 0 --共鸣要求好感度等级

    self.resonance_enabled = 0--是否开放共鸣功能 0为未开放 1为开放
    --
    self.selectIndex = nil 

    self.panelTouch:setTouchEnabled(false)

    self.btnClose:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if not self.isPlaying then
                self:onBeforeClose()
                self:returnBack()
            end
        end
    end)

    self.btn_1:addClickEventListener(function()
        self:btnClicked(1)
    end)
    self.btn_2:addClickEventListener(function()
        self:btnClicked(2)
    end)
    self.btn_3:addClickEventListener(function()
        self:btnClicked(3)
    end)

    self.btnGM:addClickEventListener(function()
        self:btnGMClicked()
    end)
    

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self:initRoleSpine()

    self:refreshBtnState()
    self:refreshRoleState()
    
    self:loadData()

    return self
end

function RoleIntimacyView:btnClicked(nIndex)
    local h_id_num = getNumID( self.hero_id )
    local btnState = self.unlockStates[nIndex]
    if btnState == 0 then--未解锁
        self:reqUnlocked(nIndex)
    elseif btnState == 1 then--已解锁
        self:dealLabelList(nIndex)
    end
end

function RoleIntimacyView:dealLabelList(nIndex)
    local function isSelect(btn, isS) 
        local img = btn:getChildByTag(10000)
        if isS then 
            if img  == nil then 
                local img = cc.Sprite:create(GM_JS_BTN_IMG[6])
                img:setAnchorPoint(cc.p(0.5,0.5))
                img:setPosition(btn:getContentSize().width/2, btn:getContentSize().height/2)
                img:setTag(10000)
                btn:addChild(img)
            end 
        else 
            if img then 
                img:removeFromParent()
                img = nil
            end 
        end 
    end

    if  nIndex == self.selectIndex then 
        self.labelListView:closeBack()
        isSelect(self["btn_"..nIndex], false)
        self.selectIndex = nil
        self.labelListView = nil
    else 
        if self.selectIndex then
            isSelect(self["btn_"..self.selectIndex], false)
        end 
        isSelect(self["btn_"..nIndex], true)
        self.selectIndex = nIndex
        local h_id_num = getNumID( self.hero_id )
        local str = UITool.getUserLanguage(likedialog[h_id_num][nIndex].content)
        local title = UITool.getUserLanguage(likedialog[h_id_num][nIndex].title)

        if self.labelListView then 
            self.labelListView:refresh(str,title)
        else 
            self.labelListView = RoleIntimacyHistory.new():init(str,title)
            self:addSubView(self.labelListView)
        end 
    end 
end

function RoleIntimacyView:startUnlockeffect(nIndex)

    self.btnEffectPos:removeAllChildren()
    self.btnEffectPos:setPosition(self["btn_"..nIndex]:getPosition())
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(self.effectFile) then
        local end_pos = string.find(self.effectFile,'atlas') - 1
        local spName = string.sub(self.effectFile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(effectSp)
            self.asyncHandler2 = nil

            local rps = self.btnEffectPos:getSize()
            effectSp:setPosition(cc.p(rps.width / 2, rps.height / 2))
            effectSp:setScale(1)
            self.btnEffectPos:addChild(effectSp,0,123)
            effectSp:setAnimation(1, "effect", false)
        end)


    end
end

function RoleIntimacyView:stopUnlockeffect()
    self.btnEffectPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
end

function RoleIntimacyView:startGMBtneffect(intimacyState)
    local effectFile = like_state[intimacyState].resonance_special_effect --特效资源路径

    self.btnGMEffectPos:removeAllChildren()
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(effectFile) then
        local end_pos = string.find(effectFile,'atlas') - 1
        local spName = string.sub(effectFile,0,end_pos)
        self.asyncHandler1 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler1 = nil

            local rps = self.btnGMEffectPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2, rps.height / 2))
            roleIcon:setScale(1)
            self.btnGMEffectPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect", true)
        end)
    end
end

function RoleIntimacyView:stopGMBtneffect()
    self.btnGMEffectPos:removeAllChildren()
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end
end

function RoleIntimacyView:startGMBtneffectOnce()
    local skeletonNode = sp.SkeletonAnimation:create("Resources/armatures/intimacy/gong_ming_ti_shi/gong_ming_ti_shi.json", "Resources/armatures/intimacy/gong_ming_ti_shi/gong_ming_ti_shi.atlas", 1.0)
    skeletonNode:setAnimation(1, "effect", false)
    local psize = self.btnGMEffectPosOnce:getSize()
    skeletonNode:setPosition(cc.p(1080,150))
    skeletonNode:setTag(123)   
    self.btnGMEffectPosOnce:addChild(skeletonNode,0,123)
end

-- # -----------------------------------------------------
-- # ■ [共鸣] 
-- # 接口名: like_feeling_break
-- # 功能: 结婚
-- # 参数: like_feeling_id  # 好感度id
-- # 返回: 
-- {
--     "data": {
--         "state_code": 1
--     }
-- }

function RoleIntimacyView:reqGM()
    if not self.hero_id then
        return 
    end

    local tempTable = {
        rpc = "like_feeling_break",
        like_feeling_id = self.intimacyId
    }

    --
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            self:playGMEffect()--调试界面 直接播放效果 TODO：API接口驱动

            self.panelTouch:setTouchEnabled(true)
            --GameManagerInst:alert("共鸣请求成功")
            --TODO 需要故事动画资源补齐
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end

-- # -----------------------------------------------------
-- # ■ [解锁对话] 
-- # 接口名: like_feeling_dialog_unlock
-- # 功能: 好感度详情界面解锁对话
-- # 参数: hero_id  # 英雄id
-- # 参数: dialog_id  # 对话序列id
-- # 返回: 
-- {
--     "data": {
--         "state_code": 1
--     }
-- }

function RoleIntimacyView:reqUnlocked(nIndex)

    if not self.hero_id then return end

    --
    local h_id_num = getNumID( self.hero_id )

    local tempTable = {
        rpc = "like_feeling_dialog_unlock",
        hero_id = self.hero_id,
        dialog_id = nIndex
    }

    --
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            self:startUnlockeffect(nIndex)
            UITool.delayTask(0.3,function()
                self:loadData()
            end)
        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end

function RoleIntimacyView:btnGMClicked()

    if not self.resonance_enabled or self.resonance_enabled ~= 1 then--如果配置未开放共鸣功能则不处理
        GameManagerInst:alert(UITool.ToLocalization("此角色暂时不能共鸣，敬请期待"))
        return
    end

    local h_id_num = getNumID( self.hero_id )

    local function callback ()
        self:reqGM()
    end
    if self.intimacyNum >= self.resonance_lv and self.resonance_prop_num >= 1 then
        MsgManager:showGMInfo(self,callback,self.intimacyNum,self.resonance_prop_num,true)
    else
        MsgManager:showGMInfo(self,callback,self.intimacyNum,self.resonance_prop_num,false)
    end
end

function RoleIntimacyView:playGMEffect()
    AudioManager:shareDataManager():stopBGMusic()
    local function resumeBGMusic(  )
        print("resumeBGMusic-----")
        AudioManager:shareDataManager():resumeAll()
        --AudioManager:shareDataManager():stopAll()--音效超过上限，导致无法播放新音效
        local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
        --todo 停止或者恢复当前音乐
        if musicState == 0 then --开启音乐
            
            if AudioManager:shareDataManager():getBGId() ~= -1 then 
                AudioManager:shareDataManager():resumeBGMusic()
            else 
                local fullpath = lua_musci["zhuyeBGM"]
                AudioManager:shareDataManager():preloadM(fullpath)
                AudioManager:shareDataManager():playBGMusic(fullpath, true)
            end
        end 

    end

    SceneManager.menuLayer:RefshTopBar()
    SceneManager:toGMEffectLayer({  nHeroId = self.hero_id,
                                    finalFunc = function()
                                    resumeBGMusic()
                                    NoticeManager:startNotice()
                                    cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                                    self:GMEffectCallBack()
                                end
                                })
end

function RoleIntimacyView:GMEffectCallBack()
    self:loadData()
    self.panelTouch:setTouchEnabled(false)
    self:startGMBtneffectOnce()
end

function RoleIntimacyView:onBeforeClose()
    if self.beforeCloseEvent then
        self.beforeCloseEvent(self)
    end
end

function RoleIntimacyView:returnBack()
    self.exist = false
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end
    self:removeFromParentView()
end

function RoleIntimacyView:refreshBtnState()
    local h_id_num = getNumID( self.hero_id )
    for i=1,3 do
        local limit_bg = self["btn_"..i]:getChildByName("limit_bg")
        local limit_icon = self["btn_"..i]:getChildByName("limit_icon")
        local lbTitle = self["btn_"..i]:getChildByName("lbTitle")
        local lbLimit = self["btn_"..i]:getChildByName("lbLimit")
        local btnState = self.unlockStates[i]
        if btnState == 0 then--未解锁
            --
            if limit_bg then
                limit_bg:setVisible(true)
            end
            if lbTitle then
                lbTitle:setVisible(false)
            end
            if likedialog[h_id_num][i].unlockable and likedialog[h_id_num][i].unlockable == 1 then
                if self.intimacyNum >= likedialog[h_id_num][i].unlock_lv then--可解锁
                    if limit_icon then
                        limit_icon:setVisible(false)
                    end
                    if lbLimit then
                        lbLimit:setString(UITool.ToLocalization("可解锁"))
                        lbLimit:setColor(cc.c3b(129,255,95))
                    end
                    self["btn_"..i]:setTouchEnabled(true)
                else--不可解锁
                    if limit_icon then
                        limit_icon:setVisible(true)
                    end
                    if lbLimit then
                        local limitText = string.format(UITool.ToLocalization("%d/%d解锁"),self.intimacyNum,likedialog[h_id_num][i].unlock_lv)
                        lbLimit:setString(limitText)
                        lbLimit:setColor(cc.c3b(255,255,255))
                    end
                    self["btn_"..i]:setTouchEnabled(false)
                end
                --
            else
                if limit_icon then
                    limit_icon:setVisible(true)
                end
                if lbLimit then
                    lbLimit:setString(UITool.ToLocalization("不可解锁"))
                    lbLimit:setColor(cc.c3b(255,255,255))
                end
                self["btn_"..i]:setTouchEnabled(false)
            end

        elseif btnState == 1 then--已解锁
            --
            if limit_bg then
                limit_bg:setVisible(false)
            end
            if limit_icon then
                limit_icon:setVisible(false)
            end
            if lbLimit then
                lbLimit:setVisible(false)
            end
            if lbTitle then
                lbTitle:setString(UITool.getUserLanguage(likedialog[h_id_num][i].title))
                lbTitle:setVisible(true)
            end
            self["btn_"..i]:loadTextures(GM_JS_BTN_IMG[5],GM_JS_BTN_IMG[5],GM_JS_BTN_IMG[5])
            self["btn_"..i]:setTouchEnabled(true)
            --
        end
    end
    if self.resonance == 1 then
        --已共鸣
        self.btnGM:loadTextures(GM_BTN_IMG[3],GM_BTN_IMG[4],GM_BTN_IMG[5])
        self.btnGM:setTouchEnabled(false)
        self.btnGM:setBright(false)
    else
        --未共鸣
        if self.intimacyNum == self.resonance_lv then
            --可激活共鸣
            self.btnGM:loadTextures(GM_BTN_IMG[3],GM_BTN_IMG[4],GM_BTN_IMG[5])
            self.btnGM:setTouchEnabled(true)
            self.btnGM:setBright(true)
        else
            --不可激活共鸣
            self.btnGM:loadTextures(GM_BTN_IMG[1],GM_BTN_IMG[2],GM_BTN_IMG[2])
            self.btnGM:setTouchEnabled(true)
            self.btnGM:setBright(true)
        end
    end

    if self.icon_state then
        self:startGMBtneffect(self.icon_state)
    end
end

function RoleIntimacyView:initRoleSpine()
    local h_id_num = getNumID( self.hero_id )

    --动态模型，立绘
    local lihuifile = hero[h_id_num].hero_des_spi

    self.roleIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(lihuifile) then

        local end_pos = string.find(lihuifile,'atlas') - 1
        local spName = string.sub(lihuifile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil
            self.roleIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect1", true)
        end)
    end
end

function RoleIntimacyView:refreshRoleState()
    local h_id_num = getNumID( self.hero_id )

    -- --动态模型，立绘
    -- local lihuifile = hero[h_id_num].hero_des_spi

    -- self.roleIconPos:removeAllChildren()
    -- if self.asyncHandler2 then
    --     self.asyncHandler2:cancel(true)
    --     self.asyncHandler2 = nil
    -- end

    -- if cc.FileUtils:getInstance():isFileExist(lihuifile) then

    --     local end_pos = string.find(lihuifile,'atlas') - 1
    --     local spName = string.sub(lihuifile,0,end_pos)
    --     self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
    --         self.asyncHandler2 = nil

    --         local rps = self.roleIconPos:getSize()
    --         roleIcon:setPosition(cc.p(rps.width / 2 + 30, rps.height / 2))
    --         roleIcon:setScale(0.8)
    --         self.roleIconPos:addChild(roleIcon,0,123)
    --         roleIcon:setAnimation(1, "effect1", true)
    --     end)
    -- end

    --好感度名称
    if self.spRoleName then
        self.spRoleName:setTexture(like_feeling_conf[h_id_num][1])
    end
    --好感度数值
    if self.lbIntimacyNum then
        local strIntimacyNum = string.format(UITool.ToLocalization("%d/%d"),self.intimacyNum,self.max_lv)
        self.lbIntimacyNum:setString(strIntimacyNum)
    end
    --属性加成1
    if self.lbAddAtkNum then
        local strAddAtkNum = string.format(UITool.ToLocalization("攻击提升 %d"),self.atk_rate)
        self.lbAddAtkNum:setString(strAddAtkNum.."%")
    end
    --属性加成2
    if self.lbAddHpNum then
        local strAddHpNum= string.format(UITool.ToLocalization("生命提升 %d"),self.hp_rate)
        self.lbAddHpNum:setString(strAddHpNum.."%")
    end
end

-- # -----------------------------------------------------
-- # ■ [好感度详情] 
-- # 接口名: like_feeling_detail
-- # 功能: 点击好感度状态图案的出现的二级界面
-- # 参数: hero_id  # 英雄id
-- # 返回: 
-- {
--     "data": {
--         "like_feeling": {
--             "id": 101,
--             "lv": 1,
--             "max_lv": 100,
--             "resonance": 0,  # 是否共鸣 0-否 1-是
--             "resonance_lv": 100,  # 可以共鸣的等级
--             "atk": 10,  # atk加成百分比
--             "hp": 10, # HP加成百分比
--             "icon_state": 1  # 图标
--         },
--         "resonance_prop_num": 1,  # 共鸣道具数量
--         "like_dialog": {  # 对话
--             "1": {
--                 "unlocked": 1,  # 是否已解锁 0-否 1-是
--                 "unlock_lv": 49  # 解锁等级
--             },
--             "2": {
--                 "unlocked": 1,  # 是否已解锁 0-否 1-是
--                 "unlock_lv": 99  # 解锁等级
--             },
--             "3": {
--                 "unlocked": 1,  # 是否已解锁 0-否 1-是
--                 "unlock_lv": 199  # 解锁等级
--             }
--         },
--         "state_code": 1
--     }
-- }

function RoleIntimacyView:loadData()
    if not self.hero_id then return end

    --
    local h_id_num = getNumID( self.hero_id )

    local tempTable = {
        rpc = "like_feeling_detail",
        hero_id = self.hero_id
    }

    --
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            if self.exist == false then
                return
            end
            self.intimacy_data = table.deepcopy(data)
            --GameManagerInst:saveToFile("like_feeling_detail.json",data)
            local like_feeling_data = self.intimacy_data.like_feeling
            self.intimacyId = like_feeling_data.id
            self.intimacyNum = like_feeling_data.lv
            self.max_lv = like_feeling_data.max_lv
            self.resonance = like_feeling_data.resonance --是否共鸣 0-否 1-是
            self.resonance_lv = like_feeling_data.resonance_lv --可以共鸣的等级

            self.atk_rate = like_feeling_data.atk --属性1加成百分比
            self.hp_rate = like_feeling_data.hp --属性2加成百分比

            self.resonance_prop_num = self.intimacy_data.resonance_prop_num --共鸣道具数量
            self.resonance_lv = like_feeling_data.resonance_lv --共鸣要求好感度等级

            self.resonance_enabled = self.intimacy_data.resonance_enabled--是否开放共鸣功能 0为未开放 1为开放

            print("resonance_prop_num:"..self.intimacy_data.resonance_prop_num)
            print("resonance_lv:"..like_feeling_data.resonance_lv)
            for i=1,3 do
                self.unlockStates[i] = self.intimacy_data.like_dialog[tostring(i)].unlocked
            end

            self.icon_state = like_feeling_data.icon_state

            self:refreshBtnState()
            self:refreshRoleState()

        end,
        function(state_code,msgText)
            --failed
            if self.exist == false then
                return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
end
