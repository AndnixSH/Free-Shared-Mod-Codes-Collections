--- 团站排行的基类根据类型 来设置公用的显示框

AllianceBattle_RankBaseayer= class("AllianceBattle_RankBaseayer",BasicLayer)
AllianceBattle_RankBaseayer.__index        = AllianceBattle_RankBaseayer
AllianceBattle_RankBaseayer.lClass         = 2


function AllianceBattle_RankBaseayer:init()
	local node  = cc.CSLoader:createNode("AllianceBattle_RankBaseayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.btn_index = 1
    self.publicRank = nil
    self:initBtn()
    if self.rData["rcvData"]["ShowType"] == nil then
        self.rData["rcvData"]["ShowType"] = 1
    end
    -- 初始化显示
    if self.rData["rcvData"]["ShowType"] == 1 then
        self.usrRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_007_2.png")
        self.guildRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_008_1.png")
        self:UserRankSend()
    elseif self.rData["rcvData"]["ShowType"] == 2 then
        self.usrRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_007_1.png")
        self.guildRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_008_2.png")
        self:GuildRankSend()
    end
   
end
-- 初始btn
function AllianceBattle_RankBaseayer:initBtn( ... )
    -- -- body
    local node          = self.uiLayer:getChildByTag(2)
    --玩家排行
    self.usrRank_btn   = node:getChildByName("Image_userRank") 
    --公会排行
    self.guildRank_btn = node:getChildByName("Image_guildRank") 
    -- 奖励
    self.reward_btn    = node:getChildByName("btn_reward")
    -- 帮助
    self.help_btn      = node:getChildByName("btn_help")
    -- 关闭
    self.close_btn     = node:getChildByName("Button_close")
    -- 点击按钮的回调函数
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then

            if name == "Button_close" then
                self:returnBack()
            elseif name == "Image_userRank" then
                self.usrRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_007_2.png")
                self.guildRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_008_1.png")
                self:UserRankSend()
                self.btn_index = 1
            elseif name == "Image_guildRank" then
                self.usrRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_007_1.png")
                self.guildRank_btn:loadTexture("uifile/n_UIShare/AllianceBattle/ghz_b_008_2.png")
                self:GuildRankSend()
                self.btn_index = 2
            elseif name == "btn_reward" then
                self:rewardCallBack()
            elseif name == "btn_help" then
                self:helpCallBack()

            end
       end
    end  
    -- btn添加点击事件调用函数
    self.close_btn:addTouchEventListener(touchCallBack)
    self.usrRank_btn:addTouchEventListener(touchCallBack)
    self.guildRank_btn:addTouchEventListener(touchCallBack)
    self.reward_btn:addTouchEventListener(touchCallBack)
    self.help_btn:addTouchEventListener(touchCallBack)
end
-- 点击帮助的函数回调
function AllianceBattle_RankBaseayer:helpCallBack( ... )
    -- body
    if self.btn_index == 1 then
        MsgManager:showSimpMsg(UITool.ToLocalization("本次星界的轮回大战玩家累计积分排行"))
    elseif self.btn_index == 2 then
        MsgManager:showSimpMsg(UITool.ToLocalization("本次星界的轮回大战公会累计积分排行"))
    end
end
-- 排行榜奖励的回调
function AllianceBattle_RankBaseayer:rewardCallBack( ... )
    -- body
    local rData = {}  -- 成员
    if self.btn_index == 1 then
        rData.mType = 1   -- 暂时传一  定接口时候定义一个类型
    elseif self.btn_index == 2 then
        rData.mType = 2
    end
    rData["guildbattle"] = 1
    self.sManager:toRankListRewardLayer(rData)
end
-- 玩家排行链接服务器
function AllianceBattle_RankBaseayer:UserRankSend( ... )
    -- body
  
    local function reiceSthCallBack(data)
        print("团战玩家排行")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
         local members = t_data["data"]["members"]
         local myTable = t_data["data"]["my_ranking"]
         self:UserType(members,myTable)
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guildbattle_worldmemberrank",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
     
   

end
-- 点击玩家排行的设置
function AllianceBattle_RankBaseayer:UserType( table , myTable)
    -- body
    -- 传入玩家排行的列表
    -- node 宽高
    -- 传入类型 
    -- node 
    -- 显示自己的数据
    -- 板子上的名字
    local sData = {}
    sData["table"]    = table
    sData["width"]    = 1006
    sData["height"]   = 120
    sData["curType"]  = 1
    sData["titleName"] = UITool.ToLocalization("贡献排行")
    sData["itemNode"] = AllianceBattle_RankListNode
    sData["myTable"]  = myTable --{["uid"] = "186AZK7ZW",["name"] = "Sakuya8",["position"] = 2,["rank"] = "11",["head"] = "13",["ranking"] = 18,["contribution"] = 900,["title_id"] = 100013}
    sData["titleName"] = UITool.ToLocalization("贡献排行")
    self.uiLayer:removeChildByTag(777)
    self.publicRank = AllianceBattle_RankPublicLayer:create(sData)
    self.uiLayer:addChild(self.publicRank.uiLayer,9991,777)
end
-- 点击公会排行的设置
function AllianceBattle_RankBaseayer:GuildType( table , myTable )
        -- body
    -- 传入玩家排行的列表
    -- node 宽高
    -- 传入类型 
    -- node 
    -- 显示自己的数据
    -- 板子上的名字
    local sData = {}
    sData["table"]    = table
    sData["width"]    = 1006
    sData["height"]   = 120
    sData["curType"]  = 2
    sData["itemNode"] = AllianceBattle_RankListNode
    sData["myTable"]  = myTable--{["id"] = "186AZK7ZW",["name"] = "七杀派8",["image"] = 388,["ranking"] = 18,["contribution"] = 900,["chairman"] = "杀阡陌"}
    sData["titleName"] = UITool.ToLocalization("贡献排行")
    self.uiLayer:removeChildByTag(777)
    self.publicRank = AllianceBattle_RankPublicLayer:create(sData)
    self.uiLayer:addChild(self.publicRank.uiLayer,9991,777)
end
-- 公会排行链接服务器
function AllianceBattle_RankBaseayer:GuildRankSend( ... )
    -- body
-- local members = {
--     {["id"] = "g192WU3MXL",["name"] = "七杀派",["image"]  = 388,["ranking"] = 10,["contribution"] = 100,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 10},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派1",["image"] = 388,["ranking"] = 11,["contribution"] = 200,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 20},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派2",["image"] = 388,["ranking"] = 12,["contribution"] = 300,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 30},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派3",["image"] = 388,["ranking"] = 13,["contribution"] = 400,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 40},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派4",["image"] = 388,["ranking"] = 14,["contribution"] = 500,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 50},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派5",["image"] = 388,["ranking"] = 15,["contribution"] = 600,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 60},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派6",["image"] = 388,["ranking"] = 16,["contribution"] = 700,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 70},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派7",["image"] = 388,["ranking"] = 17,["contribution"] = 800,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 80},
--     {["id"] = "g192WU3MXL",["name"] = "七杀派8",["image"] = 388,["ranking"] = 18,["contribution"] = 900,["chairman"]  = "杀阡陌",["mem_num"] = "18/20",["score"] = 90},

--     }
    local function reiceSthCallBack(data)
        print("团长公会排行")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
         local members = t_data["data"]["guild_rankList"]
         local myTable = t_data["data"]["my_ranking"]
          self:GuildType(members,myTable)
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "guildbattle_rank",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
   
 
end
function AllianceBattle_RankBaseayer:returnBack( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    self.backFunc(self.sDelegate,self.sData)
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clear()

end
function AllianceBattle_RankBaseayer:create(rData)
    local login = AllianceBattle_RankBaseayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["rcvData"]["sFunc"]
    login.sDelegate = login.rData["rcvData"]["sDelegate"]
    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end
