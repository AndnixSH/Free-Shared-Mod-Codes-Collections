rank_tab_config = {}

rank_tab_config[1] = { 1,2,3,4,5,6 }

rank_tab_config[2] = { 7 }

