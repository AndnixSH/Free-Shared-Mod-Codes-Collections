--[[战斗选关页面
--BattlePassListLayer.lua
--物品在哪些关卡掉落 列表
--2016.8.12
--参数 
--物品item_id  物品item_type
--后期功能扩展，因无法满足。需将 item_type -1 定义为 跳转到指定关卡
--SceneManager:toBattlePassListLayer({item_type = -1, item_id = 'a1_1_1,a1_1_2'})
--]]
require "BasicLayer"
BattlePassListLayer = class("BattlePassListLayer",BasicLayer)
BattlePassListLayer.__index = BattlePassListLayer
BattlePassListLayer.lClass = 2

function BattlePassListLayer:init()
    self.sManager.menuLayer:hiddenUserInfo(false)
    self.sManager.menuLayer:RefshTopBar()
    local data = self.rData["rcvData"]
  	self.isTouchRewerd = false
  	self.tollgate = {}--数据容器
   	self.click_point = nil  --点击的关卡

    self.item_id = data.item_id 
    self.item_type = data.item_type -- 道具类型 1金币 2星石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片 9key 10 星梯 11苍玉
    self.isGetItem = false ---如果获得东西就为true
   
    local node = cc.CSLoader:createNode("BattlePassListLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true;
    local panel = node:getChildByTag(101) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end
    local backBtn  =  ccui.Helper:seekWidgetByName(panel,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(touchCallBack)
    local guideButton = ccui.Helper:seekWidgetByName(panel,"Button_guide")
    guideButton:setVisible(false)
    self:initListView()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self:reqDropInfo()

end

--初始化列表
function BattlePassListLayer:initListView()
    local node = self.uiLayer:getChildByTag(1)
    local panel = node:getChildByTag(101)
    self.scrollView = ccui.Helper:seekWidgetByName(panel,"listview")
    --set bar
    self.scrollView:setScrollBarEnabled(false)
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
              if  self.isTouchRewerd then 
                 do return end 
              end 
              self.click_point = sender:getCurSelectedIndex() + 1
              local levelState = self.tollgate[self.click_point]["level_state"]
              if levelState ~= 0 then
                  if self.tollgate[self.click_point]["type"] ~= 3 then --type  3-多人BOSS
                      self:onClickOtherPass()
                  else
                      self:onClickMullPass()
                  end               
              end 
          end
    end
    self.scrollView:removeAllItems()
    self.scrollView :addEventListener(listViewEvent)
    self.scrollView:setScrollBarEnabled(false)

    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("pass_item.csb")
    local  item_1 = list_item:getChildByTag(174)
    local item_c = item_1:clone()
    item_c:setPosition(cc.p(0,0))
    item_c:setName("item")
    layout_list:addChild(item_c)
    layout_list:setContentSize(610,160)
    layout_list:setTouchEnabled(true)
    self.scrollView:setItemModel(layout_list)
end

--返回
function BattlePassListLayer:returnBack()
    if self.sManager ~= nil then
        self.sManager:removeFromNavNodes(self)
    end
    
    if self.backFunc then
        self.backFunc(self.sManager)
    end
    if self.isGetItem  then 
        if self.rData["rcvData"]["isCallFunc"] then
          self.rData["rcvData"]["callFunc"](self.rData["rcvData"]["self"])
       end
    end 
    if self.item_type == -1 then 
        SceneManager:toStartLayer()
    end 
    self.exist = false
    self:clearEx()
end

function BattlePassListLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end
--刷新列表
function BattlePassListLayer:refreshPassList()
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
              if  self.isTouchRewerd then 
                 do return end 
              end 
              self.click_point = sender:getCurSelectedIndex() + 1
              local levelState = self.tollgate[self.click_point]["level_state"]
              if levelState ~= 0 then
                  if self.tollgate[self.click_point]["type"] ~= 3 then --type  3-多人BOSS
                      self:onClickOtherPass()
                  else
                      self:onClickMullPass()
                  end               
              end 
          end
    end
    self.scrollView:removeAllItems()
    self.scrollView :addEventListener(listViewEvent)
    UITool.refreshPassList(self,"level_id")
    self.scrollView:jumpToTop()
end

function BattlePassListLayer:toReadyLayer()
  	self.sData = {} 
  	self.sData["name"] =  UITool.getUserLanguage(battlePass[self.tollgate[(self.click_point)]["level_id"]]["level_name"])--battlePass[self.tollgate[(self.click_point)]["level_id"]]["level_name"]
  	self.sData["lv"] = battlePass[self.tollgate[(self.click_point)]["level_id"]]["level_lv"]
  	self.sData["ap"] = self.tollgate[self.click_point]["need_ap"]
  	local type_ = self.tollgate[(self.click_point)]["type"]
  	 --创建多人战表里面的  和 参加多人战的区别（返回的Id）
  	local state = self.tollgate[(self.click_point)]["level_state"]
  	if type_ == 3 then
  	    if state == 2 then --加入多人战
  	        self.sData["b_id"] = self.tollgate[(self.click_point)]["id"]
  	        self.sData["mode"] = "mutable1" --join
            self.sData["ap"] =  0
  	    else
  	        self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
  	        self.sData["mode"] = "mutable" --create
  	    end
  	else
  	    self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
  	end   
  	self.sManager:toReadyLayer(self.sData) 
end
--点击非多人战类型的关卡
function BattlePassListLayer:onClickOtherPass()
    self:toReadyLayer()
end
--刷新
function BattlePassListLayer:SMapRefresh()
  self.isGetItem = true
  self:reqDropInfo()
end


--点击多人战类型的关卡
function BattlePassListLayer:onClickMullPass()
    --多人战创建
    local state = self.tollgate[(self.click_point)]["level_state"]
    if state == 2 then --加入 不消耗次数
        self:toReadyLayer()
    else               --新建 消耗次数
        local totalValue = self.tollgate[self.click_point]["multi"]["total"]
        local nowValue = self.tollgate[self.click_point]["multi"]["now"]
        local nums = totalValue - nowValue
        if nums >0 then
            local msg = UITool.ToLocalization("今日还剩余挑战次数:")..nums
            MsgManager:showSimpMsgWithCallFunc(msg,self,self.toReadyLayer)
        else
            local msg = UITool.ToLocalization("你的挑战次数已用完")
           MsgManager:showSimpMsg(msg)
        end
    end 
end
--获取
function BattlePassListLayer:reqDropInfo()
    local function reicePointCallBack(data)
        print("收到事件点结果 关卡列表")
        
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end

        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end

        self.tollgate = {}
        self.tollgate = t_data["data"]["level_list"]
        self:refreshPassList()
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"] = "drop_info",
        ["item_id"] = self.item_id,
        ["item_type"] = self.item_type, -- 道具类型 1金币 2星石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片 9key 10 星梯 11苍玉
    }
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--查看掉落
function BattlePassListLayer:toMapItemDropsLayer(data)
    local rcvData = {}
    rcvData["sDelegate"] =  self
    rcvData["sFunc"] =  self.refresh
    rcvData["data"] =  data
    --self.sManager:toMapItemDropsLayer(rcvData)
    if data.level_is_boss == 1 then 
         self.sManager:toBossInformationLayer(rcvData)
    else 
        self.sManager:toMapItemDropsLayer(rcvData)
    end 
end

function BattlePassListLayer:setShow( )
	-- body
    self.sManager.menuLayer:hiddenUserInfo(false)
end

function BattlePassListLayer:create(rData)
     local layer = BattlePassListLayer.new()
     layer.rData = rData
     layer.titleNum = 8
     layer.sManager = layer.rData["sManager"]
     layer.backFunc = layer.rData["rcvData"]["sFunc"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
