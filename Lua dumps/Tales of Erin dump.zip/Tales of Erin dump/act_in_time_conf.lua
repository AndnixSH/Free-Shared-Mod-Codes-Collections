act_in_time_conf = {} 

act_in_time_conf[10001] = {
    remark = "多人战",
    act_type = "2.0",
}

act_in_time_conf[10002] = {
    remark = "试炼之地",
    act_type = "3.0",
}

act_in_time_conf[10003] = {
    remark = "公会塔",
    act_type = "4.0",
}

act_in_time_conf[10004] = {
    remark = "星界探索",
    act_type = "5.0",
}

act_in_time_conf[10005] = {
    remark = "黑潮遗迹",
    act_type = "6.0",
}

act_in_time_conf[10006] = {
    remark = "主线副本",
    act_type = "8.0",
}

act_in_time_conf[10007] = {
    remark = "星盘关卡",
    act_type = "9.0",
}