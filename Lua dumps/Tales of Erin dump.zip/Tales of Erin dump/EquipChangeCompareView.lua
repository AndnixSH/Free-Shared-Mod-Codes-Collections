--require "XUIView"

EquipChangeCompareView = class("EquipChangeCompareView",XUIView)
EquipChangeCompareView.CS_FILE_NAME = "EquipChangeCompareView.csb"
EquipChangeCompareView.CS_BIND_TABLE = 
{
    btnCancel = "/i:11/i:757",
    btnSure = "/i:11/i:1056",

    panelIconChnageBy = "/i:11/i:1061/i:1063",
    panelIconChnageTo = "/i:11/i:738/i:1059",

    panelMain = "/i:11",
}

function EquipChangeCompareView:init(nChangeById,nChangeToId,callBackCancel,callBackSure)
    EquipChangeCompareView.super.init(self)

    self.callBackCancel = callBackCancel
    self.callBackSure = callBackSure

    self.btnCancel:addClickEventListener(function()
        self:onEquipChangeCancel()
    end)

    self.btnSure:addClickEventListener(function()
        self:onEquipChangeSure()
    end)

    self.iconView1 = REIconView.new():init(self.panelIconChnageBy)
    self.iconView2 = REIconView.new():init(self.panelIconChnageTo)

    self:refreshCompareInfo(nChangeById,nChangeToId)

    return self
end

--刷新对比结果装备信息
function EquipChangeCompareView:refreshCompareInfo(nChangeById,nChangeToId)

    local data = {}

    local panelMainNode = self.panelMain

    for i=1,2 do
        data = user_info["eq"][nChangeById]
        local eq_num_id = getNumID(nChangeById)
        if i == 2 then
            data = user_info["eq"][nChangeToId]
            eq_num_id = getNumID(nChangeToId)
        end
        self["iconView"..i]:showEquip(eq_num_id)

        local panelProp = panelMainNode:getChildByName("panelProp_"..i)
        local lbEqLv = panelProp:getChildByName("lbEqLv")
        local lbAtk = panelProp:getChildByName("lbAtk")
        local lbHp = panelProp:getChildByName("lbHp")
        local lbSkillName = panelProp:getChildByName("lbSkillName")
        local lbSkillLv = panelProp:getChildByName("lbSkillLv")

        local lbEqLvStr = UITool.ToLocalization("等级 ")..tostring(data["Lv"])
        lbEqLv:setString(lbEqLvStr)--调试数据 TODO: 
        lbAtk:setString(data["atk"])--调试数据 TODO: 
        lbHp:setString(data["hp"])--调试数据 TODO: 
        lbSkillName:setString(UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_name"]))--(equip[eq_num_id]["equip_skill"]["skill_name"])
        local lbSkillLvStr = UITool.ToLocalization("等级 ")..tostring(data["sk"]["Lv"])
        lbSkillLv:setString(lbSkillLvStr)--调试数据 TODO:

        ---
        --装备固定技能-----------------------
        local pSkill = panelProp:getChildByName("pSkill")
        pSkill:removeAllChildren()
        local detail_size = pSkill:getSize()

        local richText = ccui.RichText:create()
        richText:ignoreContentAdaptWithSize(false)
        richText:setContentSize(detail_size)
        richText:setPosition(detail_size.width / 2,detail_size.height / 2)
        pSkill:addChild(richText)
        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_des"])--equip[eq_num_id]["equip_skill"]["skill_des"]
        --str_des = string.gsub(str_des,"%*",""..(data["sk"]["add_atk_rate"]).."%%")
        str_des = UITool.stringForEqSK(str_des,data["sk"]["add_atk_rate"])
        richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 20) )
        ------------------------------------

        --随机技能---------------------------
        for j = 1,2 do
            local prsk = panelProp:getChildByName("pRsk"..j)
            if data["rsk"] ~= nil and data["rsk"][j] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[data["rsk"][j][1]])--eq_random_sk[data["rsk"][j][1]]
                strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][j][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end
        -----------------------------------

        --装备二技能-----------------------
        local pSkill_Name_2 = panelProp:getChildByName("lbSkillName_2")
        local pSkill_Lv_2 = panelProp:getChildByName("lbSkillLv_2")
        local pSkill_Des_2 = panelProp:getChildByName("pSkill_2")
        if equip[eq_num_id]["is_there_sk_two"] == 0 then
            --没有二技能
            pSkill_Name_2:setVisible(false)
            pSkill_Lv_2:setVisible(false)
            pSkill_Des_2:setVisible(false)
        else
            --有二技能
            pSkill_Name_2:setVisible(true)
            pSkill_Lv_2:setVisible(true)
            pSkill_Des_2:setVisible(true)
            local skill_two_name = UITool.getUserLanguage(passive_sk[data["sk_two"]["provide_sk_id"]]["sk_name"])--passive_sk[data["sk_two"]["provide_sk_id"]]["sk_name"]
            pSkill_Name_2:setString(skill_two_name)
            pSkill_Lv_2:setString(UITool.ToLocalization("等级 ")..data["sk_two"]["Lv"])

            --技能描述
            pSkill_Des_2:removeAllChildren()
            local detail_size = pSkill_Des_2:getSize()

            local richText2 = ccui.RichText:create()
            richText2:ignoreContentAdaptWithSize(false)
            richText2:setContentSize(detail_size)
            richText2:setPosition(detail_size.width / 2,detail_size.height / 2)
            pSkill_Des_2:addChild(richText2)
            --技能描述-当前等级
            local strSkillTwo_des = UITool.getUserLanguage(passive_sk[data["sk_two"]["provide_sk_id"]]["sk_des"])
            richText2:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,strSkillTwo_des, TEXT_FONT_NAME, 20) )
        end
        ------------------------------------
    end
end

--背包分签优化 新处理
function EquipChangeCompareView:initEx(vChangeByData,vChangeToData,callBackCancel,callBackSure)
    EquipChangeCompareView.super.init(self)

    self.callBackCancel = callBackCancel
    self.callBackSure = callBackSure

    self.btnCancel:addClickEventListener(function()
        self:onEquipChangeCancel()
    end)

    self.btnSure:addClickEventListener(function()
        self:onEquipChangeSure()
    end)

    self.iconView1 = REIconView.new():init(self.panelIconChnageBy)
    self.iconView2 = REIconView.new():init(self.panelIconChnageTo)

    self:refreshCompareInfoEx(vChangeByData,vChangeToData)

    return self
end

--背包分签优化 新处理
--刷新对比结果装备信息
function EquipChangeCompareView:refreshCompareInfoEx(vChangeByData,vChangeToData)

    local data = {}

    local panelMainNode = self.panelMain

    for i=1,2 do
        data = table.deepcopy(vChangeByData)
        local eq_num_id = getNumID(vChangeByData.id)
        if i == 2 then
            data = table.deepcopy(vChangeToData)
            eq_num_id = getNumID(vChangeToData.id)
        end
        self["iconView"..i]:showEquip(eq_num_id)

        local panelProp = panelMainNode:getChildByName("panelProp_"..i)
        local lbEqLv = panelProp:getChildByName("lbEqLv")
        local lbAtk = panelProp:getChildByName("lbAtk")
        local lbHp = panelProp:getChildByName("lbHp")
        local lbSkillName = panelProp:getChildByName("lbSkillName")
        local lbSkillLv = panelProp:getChildByName("lbSkillLv")

        local lbEqLvStr = UITool.ToLocalization("等级 ")..tostring(data["Lv"])
        lbEqLv:setString(lbEqLvStr)--调试数据 TODO: 
        lbAtk:setString(data["atk"])--调试数据 TODO: 
        lbHp:setString(data["hp"])--调试数据 TODO: 
        lbSkillName:setString(UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_name"]))--(equip[eq_num_id]["equip_skill"]["skill_name"])
        local lbSkillLvStr = UITool.ToLocalization("等级 ")..tostring(data["sk"]["Lv"])
        lbSkillLv:setString(lbSkillLvStr)--调试数据 TODO:

        ---
        --装备固定技能-----------------------
        local pSkill = panelProp:getChildByName("pSkill")
        pSkill:removeAllChildren()
        local detail_size = pSkill:getSize()

        local richText = ccui.RichText:create()
        richText:ignoreContentAdaptWithSize(false)
        richText:setContentSize(detail_size)
        richText:setPosition(detail_size.width / 2,detail_size.height / 2)
        pSkill:addChild(richText)
        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(equip[eq_num_id]["equip_skill"]["skill_des"])--equip[eq_num_id]["equip_skill"]["skill_des"]
        --str_des = string.gsub(str_des,"%*",""..(data["sk"]["add_atk_rate"]).."%%")
        str_des = UITool.stringForEqSK(str_des,data["sk"]["add_atk_rate"])
        richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 20) )
        ------------------------------------

        --随机技能---------------------------
        for j = 1,2 do
            local prsk = panelProp:getChildByName("pRsk"..j)
            if data["rsk"] ~= nil and data["rsk"][j] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[data["rsk"][j][1]])--eq_random_sk[data["rsk"][j][1]]
                strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][j][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end
        -----------------------------------

        --装备二技能-----------------------
        local pSkill_Name_2 = panelProp:getChildByName("lbSkillName_2")
        local pSkill_Lv_2 = panelProp:getChildByName("lbSkillLv_2")
        local pSkill_Des_2 = panelProp:getChildByName("pSkill_2")
        if equip[eq_num_id]["is_there_sk_two"] == 0 then
            --没有二技能
            pSkill_Name_2:setVisible(false)
            pSkill_Lv_2:setVisible(false)
            pSkill_Des_2:setVisible(false)
        else
            --有二技能
            pSkill_Name_2:setVisible(true)
            pSkill_Lv_2:setVisible(true)
            pSkill_Des_2:setVisible(true)
            local skill_two_name = UITool.getUserLanguage(passive_sk[data["sk_two"]["provide_sk_id"]]["sk_name"]) --passive_sk[data["sk_two"]["provide_sk_id"]]["sk_name"]
            pSkill_Name_2:setString(skill_two_name)
            pSkill_Lv_2:setString(UITool.ToLocalization("等级 ")..data["sk_two"]["Lv"])

            --技能描述
            pSkill_Des_2:removeAllChildren()
            local detail_size = pSkill_Des_2:getSize()

            local richText2 = ccui.RichText:create()
            richText2:ignoreContentAdaptWithSize(false)
            richText2:setContentSize(detail_size)
            richText2:setPosition(detail_size.width / 2,detail_size.height / 2)
            pSkill_Des_2:addChild(richText2)
            --技能描述-当前等级
            local strSkillTwo_des = UITool.getUserLanguage(passive_sk[data["sk_two"]["provide_sk_id"]]["sk_des"])
            richText2:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,strSkillTwo_des, TEXT_FONT_NAME, 20) )
        end
        ------------------------------------
    end
end

--取消更换
function EquipChangeCompareView:onEquipChangeCancel()
    if self.callBackCancel then
        self.callBackCancel(self)
    end
end

--确定更换
function EquipChangeCompareView:onEquipChangeSure()
    if self.callBackSure then
        self.callBackSure(self)
    end
end

function EquipChangeCompareView:onNavigateTo(isback)

end
