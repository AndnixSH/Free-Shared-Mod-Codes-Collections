
data_refunds_info = {}

data_refunds_info[1] = "청약철회는 구매일로부터 7일이내에 신청가능합니다.";
		

data_refunds_info[2] = "단, 상품을 우편에서 수령하거나 사용한 경우 청약철회가 불가합니다.";
		

data_refunds_details_info = {
	{
		str ="청약철회는 구매일로부터 7일이내에 신청가능합니다.",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
	},
	{
		str ="단, 상품을 우편에서 수령하거나 사용한 경우 청약철회가 불가합니다.",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
	},
	{
		str ="신청은 게임 내 문의하기 기능을 통해 양식에 맞춰",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
	},
	{
		str ="작성하여 접수해 주시면 담당자 확인 후 안내해 드립니다.",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
	},
	{
		str ="구매 즉시 효과가 적용되는 상품",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	},
	{
		str ="및 구매 후 부가 상품을 사용한 경우에는",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	},
	{
		str ="청약철회 신청이 불가합니다.",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	},
	{
		str ="",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	},
	{
		str ="미성년자가 법정대리인의 동의 없이 결제한 경우에는",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	},
	{
		str ="취소 신청이 가능합니다. 단, 결제 수단의 명의가",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	},
	{
		str ="성인인 경우에는 취소할 수 없습니다.",
		color ="#ffffff",
		bold =0,
		size =22,
		align ="left",
		indendtation =15
		
	}
	
}
	