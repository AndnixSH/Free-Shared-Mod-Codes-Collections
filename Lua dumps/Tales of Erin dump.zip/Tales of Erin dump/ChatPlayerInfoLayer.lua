--[[
    ChatPlayerInfoLayer.lua
    聊天界面玩家信息
]]
require "BasicLayer"
ChatPlayerInfoLayer = class("ChatPlayerInfoLayer",BasicLayer)

function ChatPlayerInfoLayer:create(data)
    local layer = ChatPlayerInfoLayer.new()
    layer.uiLayer = cc.Layer:create()
    layer:init(data)
    return layer
end

function ChatPlayerInfoLayer:init(data)
    local node = cc.CSLoader:createNode("XbChatPlayerIInfo.csb")
    self.uiLayer:addChild(node,0,1)
    self.rootNode = node
    self:initData(data)
    self:initView()
    self:initEvent()
    self:registerCustomEventListener()
    self:reqPlayerInfo()
    self.exist = true
end

function ChatPlayerInfoLayer:initData( data )
    -- body
    self.user_nim_id = data["nim_id"]
    self.user_uid = XBChatSys:getInstance():getUidFromNimId( self.user_nim_id )
    self.user_name = data["name"]
    self.talk = data["talk"]

    dump(data, "ChatPlayerInfoLayer.data")
end

function ChatPlayerInfoLayer:initView( ... )
    self.Panel_root = self.rootNode:getChildByName("Panel_root")
    self.Image_bg = self.Panel_root:getChildByName("Image_bg")

    self.Panel_head = self.Panel_root:getChildByName("Panel_head")
    self.Image_border = self.Panel_head:getChildByName("Image_border")
    self.Image_head_icon = self.Panel_head:getChildByName("Image_head_icon")

    self.Panel_nick = self.Panel_root:getChildByName("Panel_nick")
    self.nick_valut_t = self.Panel_nick:getChildByName("nick_valut_t")

    self.Panel_level = self.Panel_root:getChildByName("Panel_level")
    self.level_valut_t = self.Panel_level:getChildByName("level_valut_t")

    self.Panel_title = self.Panel_root:getChildByName("Panel_title")
    self.Panel_title_spine = self.Panel_title:getChildByName("Panel_title_spine")

    self.Panel_power = self.Panel_root:getChildByName("Panel_power")
    self.power_valut_t = self.Panel_power:getChildByName("power_valut_t")

    self.Panel_guild = self.Panel_root:getChildByName("Panel_guild")
    self.guild_valut_t = self.Panel_guild:getChildByName("guild_valut_t")
    self.Image_commer = self.Panel_guild:getChildByName("Image_commer")

    self.Panel_buttons = self.Panel_root:getChildByName("Panel_buttons")

    self.btn_addForChat = self.Panel_buttons:getChildByName("btn_addForChat")
    self.btnLabelForFriend = self.btn_addForChat:getChildByName("title")

    self.btn_look = self.Panel_buttons:getChildByName("btn_look")

    self.btn_shield = self.Panel_buttons:getChildByName("btn_shield")
    self.btnLabelForShield = self.btn_shield:getChildByName("title")

    self.btn_report = self.Panel_buttons:getChildByName("btn_report")

    self.Panel_touch = self.Panel_root:getChildByName("Panel_touch")

    self:refreshView({})
end

function ChatPlayerInfoLayer:initEvent( ... )
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "btn_addForChat" then
                self:handlerAddFriendOrSendMsg()
            elseif sender:getName() == "btn_look" then
                self:handlerLookInfo()
            elseif sender:getName() == "btn_shield" then
                self:handlerShieldtUser()
            elseif sender:getName() == "btn_report" then
                self:handlerReportUser()
            elseif sender:getName() == "Panel_touch" then
                self:returnBack()
            end
        end
    end
    self.btn_addForChat:addTouchEventListener(touchCallBack)
    self.btn_look:addTouchEventListener(touchCallBack)
    self.btn_shield:addTouchEventListener(touchCallBack)
    self.btn_report:addTouchEventListener(touchCallBack)
    self.Panel_touch:addTouchEventListener(touchCallBack)
end

function ChatPlayerInfoLayer:handlerAddFriendOrSendMsg( ... )
    local friendUnlockIndex = 52
    local unlockLevel = table.getValue("", UnlockConfig, friendUnlockIndex, "unlockLevel")
  
    if UnlockSys:getInstance():checkUnlock(friendUnlockIndex) == false then
        local msg = string.format(Lang:toLocalization(1040146),unlockLevel)
        MsgManager:showSimpMsg(msg)
        return 

    end

    -- body
    local user_name = self.user_name
    local user_nim_uid = self.user_nim_id

    local bFriend = XBChatSys:getInstance():isMyFriendById(self.user_uid)
    if bFriend == true then

        local data = {
            enterIndex = 4
        }
        -- SceneManager:toChatLayer(data)

        lemon.EventManager:dispatchCustomEvent(EEventType.CHAT_CHANNEL_CHANGE , data) --跳转聊天频道

        self:returnBack()
    else
        local data = {
            user_nim_id = user_nim_uid
        }
        SceneManager:toAddFriendConfirmLayer(data)
    end
end

function ChatPlayerInfoLayer:handlerLookInfo( ... )
    -- body
    local rcvData = {}
    local info = {}
    info["ui_from"] = PlayerInfoSys.EUiType.friend
    info["uid"] = self.user_uid
    rcvData["info"] =  info
    SceneManager:toPlayerInfoLayer(rcvData)
end

function ChatPlayerInfoLayer:handlerShieldtUser( ... )
    -- body
    local user_name = self.user_name
    local user_nim_id = self.user_nim_id
    local tisStr = string.format(Lang:toLocalization(1050019),user_name)
    GameManagerInst:confirm(tisStr,function()
            local reqData = {
                user_nim_id = user_nim_id
            }
            XBChatSys:getInstance():addToBlackSys(reqData)
        end)
end

function ChatPlayerInfoLayer:handlerReportUser( ... )
    -- body 是否举报%s的发言?
    local owner = self
    local user_name = self.user_name
    local tisStr = string.format(Lang:toLocalization(1050020),user_name)
    GameManagerInst:confirm(tisStr,function()
            owner:reqReportUser()
        end)
end

function ChatPlayerInfoLayer:reqReportUser( ... )
    -- body
    local user_id = self.user_uid
    local talk = self.talk
    local tempData = { 
        rpc = "report_state",
        report_id = user_id,
        msg = talk or ""
    }
    local owner = self
    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --success
            if owner.exist == false then
                return
            end
            GameManagerInst:alert(Lang:toLocalization(1050021))
        end,
        function(state_code,msgText)
            --failed
            if owner.exist == false then
                return
            end
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
        true)
end

function ChatPlayerInfoLayer:registerCustomEventListener()
   
   self.addBlackEventListener = lemon.EventManager:addCustomEventListener(EEventType.FRIEND_ADD_BLACK, function(data)
            self:refreshShieldBtn()
        end)

   self.friendAddEventListener = lemon.EventManager:addCustomEventListener(EEventType.FRIEND_ADD, function(data)
            self:refreshFriendBtn()
        end)

   self.friendDeleteEventListener = lemon.EventManager:addCustomEventListener(EEventType.FRIEND_DELETE, function(data)
            self:refreshFriendBtn() 
        end)
end


function ChatPlayerInfoLayer:unRegisterCustomEventListener()
   
    
    if self.addBlackEventListener ~= nil then
        lemon.EventManager:removeEventListener(self.addBlackEventListener)
        self.addBlackEventListener = nil 
    end

    if self.friendAddEventListener ~= nil then
        lemon.EventManager:removeEventListener(self.friendAddEventListener)
        self.friendAddEventListener = nil 
    end

    if self.friendDeleteEventListener ~= nil then
        lemon.EventManager:removeEventListener(self.friendDeleteEventListener)
        self.friendDeleteEventListener = nil 
    end
end

function ChatPlayerInfoLayer:reqPlayerInfo()
    -- body
    local owner = self
    local user_uid = self.user_uid
    local tempData = { 
        rpc = "someone_info",
        the_uid = user_uid,
    }

    GameManagerInst:rpc(tempData,
        3,
        function(data)
            --success
            if owner.exist == false then
                return
            end
            owner:refreshView(data)
        end,
        function(state_code,msgText)
            --failed
            if owner.exist == false then
                return
            end
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
        true)
end

function ChatPlayerInfoLayer:refreshBtnView( ... )
    -- body
    self:refreshFriendBtn()
    self:refreshShieldBtn()
end

function ChatPlayerInfoLayer:refreshFriendBtn()
    local user_uid = self.user_uid
    local bFriend = XBChatSys:getInstance():isMyFriendById(user_uid)
    local bBlack = XBChatSys:getInstance():isInBlacks(user_uid)

    if bFriend == true then
        self.btnLabelForFriend:setString(Lang:toLocalization(1050022))
    else
        self.btnLabelForFriend:setString(Lang:toLocalization(1050023))
    end

    --黑名单状态不能加好友，也不能私聊
    if bBlack == true  then
        self.btn_addForChat:setTouchEnabled(false)
        self.btn_addForChat:setBright(false)
    end 
end

function ChatPlayerInfoLayer:refreshShieldBtn( ... )
    -- body
    local bBlack = XBChatSys:getInstance():isInBlacks(self.user_uid)
    if bBlack == true then
        self.btn_shield:setTouchEnabled(false)
        self.btn_shield:setBright(false)
        self.btnLabelForShield:setString(Lang:toLocalization(1050024))

        --同时屏蔽密聊/加好友 按钮
        self.btn_addForChat:setTouchEnabled(false)
        self.btn_addForChat:setBright(false)
    else
        self.btn_shield:setTouchEnabled(true)
        self.btn_shield:setBright(true)
        self.btnLabelForShield:setString(Lang:toLocalization(1050025))
    end
end

function ChatPlayerInfoLayer:refreshView( data )
    -- body
    local playerInfo = data
    if playerInfo["name"] then
        self.nick_valut_t:setString(playerInfo["name"])
    end

    if playerInfo["rank"] then
        self.level_valut_t:setString(playerInfo["rank"])
    end

    if playerInfo["fp_all"] then
        self.power_valut_t:setString(playerInfo["fp_all"])
    end

    if playerInfo["guild_name"] then
        self.guild_valut_t:setString(playerInfo["guild_name"])
    else
        self.guild_valut_t:setString(playerInfo[""])
    end
    self.Image_commer:setVisible(false)

    -- if playerInfo["guild_position"] == 3 or playerInfo["guild_position"] == 2 then
    --     self.Image_commer:setVisible(true)
    --     local guild_pos = playerInfo["guild_position"]
    --     local commander_icon = PlayerInfoSys.guild_position[guild_pos]["icon"]
    --     if commander_icon then
    --         self.Image_commer:loadTexture(commander_icon)
    --     end

    -- else
    --     self.Image_commer:setVisible(false)
    -- end

    if playerInfo["title_id"] then
        self:refreshTitle(playerInfo["title_id"])
    end
    if playerInfo["pl_icon"] then
        local heroIconID = playerInfo["pl_icon"]
        local head_info = hero[heroIconID]
        if head_info and head_info["hero_list_icon"] then
            local head_icon = head_info["hero_list_icon"]
            self.Image_head_icon:loadTexture(head_icon)
        end   
    end
    self:refreshBtnView()
end

function ChatPlayerInfoLayer:refreshTitle( title_id )
    -- body
    local titleId = title_id or 110000
    if self.m_titleID == nil or self.m_titleID ~= titleId then 
        self.m_titleID = titleId
        local spineNameStr = ""
        if title_conf[titleId] and title_conf[titleId].res_spine then
            spineNameStr = title_conf[titleId].res_spine
        end

        if self.m_titleSkeletonNode ~=nil then 
            self.m_titleSkeletonNode:stopAllActions()
            self.m_titleSkeletonNode:removeFromParent()
            self.m_titleSkeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            local title_png = ccui.ImageView:create(spName.."png")
            self.m_titleSkeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            self.m_titleSkeletonNode:setAnchorPoint(self.Panel_title_spine:getAnchorPoint())
            local size = title_png:getContentSize()
            local titleSpineX = (self.Panel_title_spine:getContentSize().width - size.width)/2 + size.width/2
            local titleSpineY = (self.Panel_title_spine:getContentSize().height - size.height)/2 + size.height/2
            self.m_titleSkeletonNode:setPosition(cc.p(titleSpineX,titleSpineY))
            self.Panel_title_spine:addChild(self.m_titleSkeletonNode)
            self.m_titleSkeletonNode:setAnimation(1, "effect", true)
            self.Panel_title_spine:setVisible(false)
            local dt = cc.DelayTime:create(0.01)
            local cf = cc.CallFunc:create(function()  
                self.Panel_title_spine:setVisible(true)
            end)
            local seq = cc.Sequence:create(dt,cf)
            self.Panel_title_spine:runAction(seq)
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 
end

function ChatPlayerInfoLayer:returnBack()
    if self.uiLayer:getParent() then
        self.uiLayer:removeFromParent()
        self.uiLayer = nil
    end
    self.exist = false
    self:clearEx()
end

function ChatPlayerInfoLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:unRegisterCustomEventListener()
    self:clear()
end

