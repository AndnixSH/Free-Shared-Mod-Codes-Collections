ChatUILayer = class("ChatUILayer",BasicLayer)
ChatUILayer.__index = ChatUILayer


function ChatUILayer:create( rData )
	local chatUI =  ChatUILayer.new()
	chatUI.rData = rData
    chatUI.sManager  = chatUI.rData["sManager"]
    chatUI.backFunc  = chatUI.rData["rcvData"]["sFunc"]
    chatUI.sDelegate = chatUI.rData["rcvData"]["sDelegate"]
    chatUI.uiLayer   = cc.Layer:create()	
    chatUI:init()
	return chatUI
end

function ChatUILayer:init(  )
	local node  = cc.CSLoader:createNode("ChatLayer.csb")
	self.uiLayer:addChild(node,0, 2)

	self:initData()
	self.chatDataMgr:setDelegate(self)
	if self.rData["enterIndex"] ~= nil then
		self.default_index = tonumber(self.rData["enterIndex"])
	end
	if self.default_index > 5 or self.default_index < 0 then
		self.default_index = 2
	end
	if self.default_index == 3 then 
		self.showBattleChannel = true
	end
	
	self:bindAllBtn()
    --注册返回键
    -- self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
    --     self:returnBack()
    -- end)

    local function callLoginNim(  )
        self.showGuideChannel = self.chatDataMgr:isShowGuide()
    	self:loginNim()
    end
    self.chatDataMgr:reqNimData(callLoginNim)

end

function ChatUILayer:initData(  )
	self.chatDataMgr 			= ChatDataManager:getInstance()
	self.default_index 			= 2 --默认切换世界聊天频道
	self.showBattleChannel 		= false
	self.showGuideChannel 		= false

	self.isPrivateChat 			= false 
	self.isOpenVoice 			= false
	self.sendAudio 				= false
	self.playVoiceTag			= 0 --当前音频Tag

	self.default_userType 		= 1 --私聊频道默认展开子频道
	self.default_userListIndex  = 1 --私聊频道子频道默认显示列表index
	

	self.curChatMember 			= {}

	self.chatRoomIndex 			= 1 --世界聊天默认index
	self.wordRooomID 			= nil --当前世界频道ID
	self.sysRoomID 				= nil
	self.battleRoomID 			= nil 
	self.guideTeamID 			= nil

	self._scrollView 			= nil 
	self.userList_refresh  		= false
	self.chatroom_maxY 			= nil
	self.curChatList 			= nil
	self.chatroom_isRefresh 	= false
	self.chatroom_index_min 	= 1 
	self.chatroom_index_max 	= 0 
	self.init_min_index 		= 0
	self.scrollPosMinY 			= 0
	self.chatroom_index_count   = 10  --UI层显示数据量
	self.chatroom_index_array 	= {}  --ui层显示的数据下标集合
end

function ChatUILayer:bindAllBtn(  )
	--绑定频道按钮组
    self.isPrivateChat = false
    local node = self.uiLayer:getChildByTag(2)
	local channelNode = node:getChildByTag(4)--频道按钮组
	local function touchChannelEvent(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			self:channelItemCallBack(sender,eventType)
		end
	end
    for i=1,5 do
    	local  tabBTN = channelNode:getChildByTag(i)
   		tabBTN:addTouchEventListener(touchChannelEvent)
    end

    --绑定返回按钮
    local zhezhao = node:getChildByTag(1)
    local left_mask = node:getChildByName("left_mask") --加载频道遮罩
    left_mask:setOpacity(0)

    --绑定密聊
	local private_node = node:getChildByTag(3)--密聊组件
	local privateItem1 = private_node:getChildByName("privateItem1")
	local privateItem2 = private_node:getChildByName("privateItem2")
	local privateItem3 = private_node:getChildByName("privateItem3")
	privateItem1:addTouchEventListener(handler(self,self.channelPriChatItemCallBack))
	privateItem2:addTouchEventListener(handler(self,self.channelPriChatItemCallBack))
	privateItem3:addTouchEventListener(handler(self,self.channelPriChatItemCallBack))

	local recordNode = node:getChildByTag(6) --录音组件
	recordNode:setVisible(false)

    --绑定聊天室按钮
	local chatRoom_node = node:getChildByTag(2) --聊天组件
	self.chatRoom_panelNode = chatRoom_node:getChildByName("panel_list")

	local videoBtn = chatRoom_node:getChildByTag(3)  --语音切换按钮
	local imgBtn = chatRoom_node:getChildByTag(5) 	 -- 表情按钮
	local sendBtn = chatRoom_node:getChildByTag(6) 	 -- 发送
	local videoNode = chatRoom_node:getChildByTag(4) -- 按住说话
	local inputNode = chatRoom_node:getChildByTag(7) --输入框组
	self.textInput = inputNode:getChildByTag(1) 	 -- 输入框
	self.textInput:setPlaceHolder("")
	
	local mask_1 = chatRoom_node:getChildByTag(11) --顶部屏蔽
	mask_1:setVisible(false)
	mask_1:setTouchEnabled(false)
	local changeChannel = chatRoom_node:getChildByTag(123) --切换聊天室

	local room_menu = chatRoom_node:getChildByTag(50) --弹出好友/黑名单 按钮
	if room_menu then
		room_menu:addClickEventListener(handler(self,self.clickRoomMenuCall))
		room_menu:setVisible(false)
	end

	local chatMask = chatRoom_node:getChildByTag(10) --聊天室遮罩，默认不显示，系统频道/好友聊天没有好友屏蔽
	chatMask:setVisible(false)

	local function touchCallBack(sender,eventType)
		print("touch node tag:"..sender:getTag())
		local tag = sender:getTag()
		if eventType == ccui.TouchEventType.ended then
			if tag == 3 then --语音切换
				--暂时不加语音功能
				if g_channel_control.chatVoiceOpen ~= true then
					return
				end
				local file = "n_UIShare/chat/sjlt_b_007a.png"
				if self.isOpenVoice == true then
					self.isOpenVoice = false
					videoNode:setVisible(false)
					inputNode:setVisible(true)
				else
					self.isOpenVoice = true
					file = "n_UIShare/chat/sjlt_b_006a.png"
					videoNode:setVisible(true)
					inputNode:setVisible(false)
				end
				local filePath = cc.FileUtils:getInstance():fullPathForFilename(file)
				if filePath ~= nil then
					videoBtn:loadTexture(filePath)
				end	
			elseif tag == 5 then 					 --自定义表情
				print("chatLayer-------自定义表情")
				-- self:sendFightMessageToSessionID({fightID = 999,fightName = "测试多人战",fightMsg = "测试多人战  Lv 99",fightLv = 99},self.curChatMember["chatRoom"]["roomId"],2)
			elseif tag == 7 then 					 --弹出输入框
				print("chatLayer--------弹出输入框")
				self:popInputView()
			elseif tag == 1 then
				self:BtnClose()
			elseif tag == 155 then 					 --切换聊天标签，等待数据时，屏蔽点击
				print("进入聊天室遮罩")
			   	GameManagerInst:alert(UITool.ToLocalization("加载信息中..."))
			elseif tag == 10 then 			 		 --好友聊天如果玩家列表为空，需要屏蔽聊天室按钮
				if self.default_index == 1 then --系统
					GameManagerInst:alert(UITool.ToLocalization("当前频道不允许发言"))
				else --好友
					GameManagerInst:alert(UITool.ToLocalization("请选择聊天对象..."))
				end
			elseif tag == 123 then --切换聊天室（世界频道才有）
				self:popChangeChannelInputView()
			end
			--todo
		end

	end
	left_mask:addTouchEventListener(touchCallBack) 
	zhezhao:addTouchEventListener(touchCallBack)
	videoBtn:addTouchEventListener(touchCallBack)
	imgBtn:addTouchEventListener(touchCallBack)
	inputNode:addTouchEventListener(touchCallBack)
	chatMask:addTouchEventListener(touchCallBack)
	changeChannel:addTouchEventListener(touchCallBack)

	videoNode:addTouchEventListener(handler(self,self.touchVoiceCallBack))
	sendBtn:addClickEventListener(handler(self,self.sendChatCallBack))
end

function ChatUILayer:addChannelRedDop( channelTag,childChannelTag,bShow )--添加红点：主频道（系1，世2，战3，私4，公5），私聊子频道（好友1/最近2/黑名单3）
  	
  	local node = self.uiLayer:getChildByTag(2)
	local channelNode = node:getChildByTag(4)	--频道按钮组
	local private_node = node:getChildByTag(3)--密聊组件

	local channelIndexNode = channelNode:getChildByTag(channelTag)

	if channelIndexNode ~= nil  then
		if bShow == true and self.default_index ~= channelTag then
			UITool.setCommmonBtnRedDop(channelIndexNode,bShow)
		elseif bShow ~= true and self.default_index == channelTag then
			UITool.setCommmonBtnRedDop(channelIndexNode,bShow)
		end
	end

	if channelTag == 4 then --私聊频道
		--绑定密聊
		local tagName = "privateItem"..tostring(childChannelTag)
		local privateItem = private_node:getChildByName(tagName);

		if privateItem then
			if bShow == true and self.default_userType ~= childChannelTag then
				UITool.setCommmonBtnRedDop(privateItem,bShow)
			elseif bShow ~= true and self.default_userType == childChannelTag then
				UITool.setCommmonBtnRedDop(privateItem,bShow)
			end
		end

	end

end
function ChatUILayer:popInputView()  			--弹出输入框
    -- if GameManagerInst.gameType == 2 then
        local rcvData = {}
        rcvData["sDelegate"] = self
        rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
        rcvData["confirmFunc"] =  function(self,text)
            self.textInput:setString(text)
        end
        rcvData["defalutStr"] = self.textInput:getString()
        rcvData["maxLength"] = 80
        SceneManager:toInputModelLayer(rcvData)
    -- end
end

function ChatUILayer:popChangeChannelInputView(  )
	print("切换世界聊天室----")
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    rcvData["confirmFunc"] =  function(self,text)
        print("切换聊天室:"..text)
        self:changeChatRoomByRoomId(text)
    end
    rcvData["defalutStr"] = tostring(self.chatRoomIndex)
    rcvData["maxLength"] = 10
    SceneManager:toInputModelLayer(rcvData)
end

function ChatUILayer:sendChatCallBack(sender) --点击发送

	print("sendCall---"..sender:getTag().." ..time:"..UserDataMgr:getInstance().timeData:getCurrentTime())

	local sessionType = self.curChatMember["sessionType"]
	local sessionId = string.lower(self.curChatMember["sessionId"])

    local str1 = self.textInput:getString()

    local tm = UserDataMgr:getInstance().timeData:getCurrentTime()-- os.time()
	local banTimeEnd = UserDataMgr:getInstance().chatData:getBanSpeakTimeEnd()
	if banTimeEnd ~= nil and banTimeEnd > tm  then --禁言中
		local timeStr = os.date("%Y-%m-%d %H:%M:%S",math.ceil(banTimeEnd))
		local str = string.format(UITool.ToLocalization("禁言结束时间：%s"),timeStr)
		GameManagerInst:alert(str)
		return
	end

	if sessionType == 0 and self.chatDataMgr:isInBlacks(sessionId) then
		local str = string.format(UITool.ToLocalization("请先移出黑名单"))
		GameManagerInst:alert(str)
		return
	end

	if str1 == nil or str1 == "" then
        GameManagerInst:alert(UITool.ToLocalization("请输入内容"))
        return
    end
    local interval = self.chatDataMgr:getSpeakInterval(self.default_index)
    if self.last_time == nil then
    	self.last_time = {}
    end
    print("tm:"..tostring(tm)..".....last："..tostring(self.last_time[self.default_index	]).."......interval:"..tostring(interval))
    if self.last_time[self.default_index] ~= nil and tm - self.last_time[self.default_index] < interval then
    	GameManagerInst:alert(UITool.ToLocalization("发言不要过快"))
        return
    end
    self.last_time[self.default_index] = tm

    self.textInput:setString("")
   
    self.chatDataMgr:sendChatMessage(sessionId,sessionType,str1)
end

function ChatUILayer:touchVoiceCallBack(sender,eventType) --语音触摸
	-- print("videoNode--------------------------"..sender:getTag())
	if eventType ==ccui.TouchEventType.began then
		print("touchVoice----Began------")
		self:createVoiceProgressTimer()
		self.chatDataMgr:voiceRecord(1)
		self:pauseOrResumeBGMusic(false)
	elseif eventType == ccui.TouchEventType.ended then
		print("touchVoice-----end")
		local onfile = "n_UIShare/chat/sjlt_b_009a.png"	
		sender:loadTexture(onfile)
		self:removeVoiceProgressTimer()
		--跨平台回调录音完成 ，执行发送音频文件操作
		self.chatDataMgr:voiceRecord(2)
		self:pauseOrResumeBGMusic(true)

	elseif eventType == ccui.TouchEventType.canceled then
		print("touchVoice -----cancel")
		self:pauseOrResumeBGMusic(true)
  	elseif eventType == ccui.TouchEventType.moved then
        local p2 = sender:getTouchMovePosition()
        local t = cc.rectContainsPoint(sender:getBoundingBox(),p2)
        if t == false and self.sendAudio ==true then --离开按钮
       	 	print("手指上滑，取消发送:"..tostring(t).."...p2："..p2.x..".."..p2.y)
       	 	self.sendAudio = false
    	 	self:removeVoiceProgressTimer()
			self.chatDataMgr:voiceRecord(3)
			self:pauseOrResumeBGMusic(true)
        end

	end
end

function ChatUILayer:pauseOrResumeBGMusic( bResume ) --恢复/暂停背景音乐
	if bResume == true then
		AudioManager:shareDataManager():resumeBGMusic()
        if AudioManager:shareDataManager():getBGId() ~= -1 then 
    
        else 
            local fullpath = lua_musci["zhuyeBGM"]
           AudioManager:shareDataManager():preloadM(fullpath)
           AudioManager:shareDataManager():playBGMusic(fullpath, true)
        end
   	else
       	AudioManager:shareDataManager():pauseBGMusic()
	end
end

function ChatUILayer:removeVoiceProgressTimer( )

	local node = self.uiLayer:getChildByTag(2)
	local recordNode = node:getChildByTag(6)
	recordNode:setVisible(false)

	local chatRoom_node = node:getChildByTag(2)
	local videoNode = chatRoom_node:getChildByTag(4) -- 按住说话
	local onfile = "n_UIShare/chat/sjlt_b_009a.png"	
	videoNode:loadTexture(onfile)
end

function ChatUILayer:createVoiceProgressTimer(  )
	self.sendAudio = true  

	local node = self.uiLayer:getChildByTag(2)
	local chatRoom_node = node:getChildByTag(2)
	local videoNode = chatRoom_node:getChildByTag(4) -- 按住说话
	local onfile = "n_UIShare/chat/sjlt_b_009b.png"	
	videoNode:loadTexture(onfile)

	local recordNode = node:getChildByTag(6)
	recordNode:setVisible(true)

	local progressBg = recordNode:getChildByName("progressBg") 
	progressBg:setVisible(false)


	local voiceProgress = recordNode:getChildByTag(1001)
	if voiceProgress == nil then
		voiceProgress = cc.ProgressTimer:create(cc.Sprite:create("n_UIShare/chat/sjlt_ui_012.png"))
		voiceProgress:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
		voiceProgress:setReverseDirection(false)
		voiceProgress:setPosition(cc.p(progressBg:getPosition()))
		recordNode:addChild(voiceProgress, 10, 1001)
	else
		voiceProgress:setPercentage(0)
	end
	local act1 = cc.ProgressTo:create(10,100) --10s转弯
	voiceProgress:runAction(act1)	
end

function ChatUILayer:callRecordOverFile( filename )
	print("···"..tostring(filename))
	local isFileExist = cc.FileUtils:getInstance():isFileExist(filename)
	print("isFileExist:"..tostring(isFileExist))
	if  self.sendAudio == true then --发送音频文件--isFileExist and
		self.sendAudio = false

		local sessionType = self.curChatMember["sessionType"]
		local sessionId = string.lower(self.curChatMember["sessionId"])

		self.chatDataMgr:sendChatVoice(filename,sessionId,sessionType)

		-- print("sendChatVoice:"..filename.."..accid:"..sessionId.."..type:"..sessionType)
	end
end

function ChatUILayer:sendFightMessageToSessionID(  )
	--测试代码，未做实现
	local fight = {
		fightID = 999,
		fightName = "测试多人战",
		fightMsg = "测试多人战  Lv 99",
		fightLv = 99
	}
	local sessionType = self.curChatMember["sessionType"]
	local sessionId = string.lower(self.curChatMember["sessionId"])

	self.chatDataMgr:sendFightMessageToSessionID(fight,sessionId,sessionType)
end

function ChatUILayer:changeChatRoomByRoomId( index_str )
	local index = tonumber(index_str)
	local function changeRoomFunc( roomid )
		local function getRoomInfoCall( t_data,roomid )
			local userCount = tonumber(t_data["onlineusercount"]) --当前聊天室人数
	        local max_limit_count = self.chatDataMgr:getChatRoomLimitCount()--tonumber(chat_info["max_person"])
			if userCount ~= nil and max_limit_count~= nil and  userCount >= max_limit_count then
				GameManagerInst:alert(UITool.ToLocalization("当前频道已满员"))
		 		return
			end

			local function enterNewRoomCall( last_roomid )
				self.chatRoomIndex = index
				self.chatDataMgr:exitChatRoom(last_roomid)
			end
			self:changeChatRoom(index,roomid,enterNewRoomCall)

		end
		self.chatDataMgr:getChatRoomInfo(roomid,getRoomInfoCall)
	end
	self:checkChatRoomId(index,changeRoomFunc)
end

function ChatUILayer:changeChatRoom(roomIndex, roomid ,callback)

	local function changeRoomCall( t_data )
		-- dump(t_data, "receive.....changeRoomCall")
		if t_data["result"] == "0" then --进入聊天室失败，之后切换频道时重新进入
			print("changeRoomCall failed error---"..tostring(roomid))
			GameManagerInst:alert(UITool.ToLocalization("切换频道失败"))
		else

			local last_roomid = self.wordRooomID
			self.wordRooomID = roomid
			local data_list = self.chatDataMgr:getListByType(2,self.wordRooomID)
			if data_list == nil then
				print("error----------------changeRoomCall")
				-- self.worldChat_list[self.wordRooomID] = {}
			end
			self.chatRoomIndex = roomIndex
			self.curChatMember["type"] = "chatRoom"
		   	self.curChatMember["sessionType"] = 2
		   	self.curChatMember["sessionId"] = t_data["chatRoom"]["roomId"]
		   	self.curChatMember["chatRoom"] = t_data["chatRoom"]
		   	self.curChatMember["member"] = t_data["member"]

		   	self:refreshChatroomUI()

			if callback then
				callback(last_roomid)
			end

		 end		
	end

	self.chatDataMgr:enterChatRoom(roomid,changeRoomCall)
end

function ChatUILayer:checkChatRoomId( index ,callfunc)
	if index and index >=1 and index <= 100 then
		local roomid = self.chatDataMgr:getRoomIDByIndex(index)
		if roomid == "0" then
			GameManagerInst:alert(UITool.ToLocalization("聊天频道未找到")..tostring(index))
			return
		end
		if roomid == self.wordRooomID then
			GameManagerInst:alert(UITool.ToLocalization("已在此频道中"))
			return
		end
		
		if callfunc then
			callfunc(roomid)
		end
	else
		GameManagerInst:alert(UITool.ToLocalization("请输入频道ID(1-100)"))
	end
end

function ChatUILayer:channelItemCallBack(sender,eventType )
	local tag = sender:getTag()
	local node = self.uiLayer:getChildByTag(2)
	local channelNode = node:getChildByTag(4)
	print("channelIndex:"..tag)
	self:addChannelRedDop(tag,0,false)
	self.default_index = tag
	-- for i = 1,5 do 
	-- 	local btnNode = channelNode:getChildByTag(i)
	-- 	if i == tag then
	-- 		btnNode:setEnabled(false)
 --    		btnNode:setBrightStyle(ccui.BrightStyle.highlight)
	-- 	else
	-- 		--战斗频道默认不可点击，公会频道需要加入公会
	--    		if (i == 3 and self.showBattleChannel ~= true ) or (i == 5 and self.showGuideChannel ~= true) then
	--    			btnNode:setEnabled(false)
	--     		btnNode:setBrightStyle(ccui.BrightStyle.none)
	--     	else
	--     		btnNode:setEnabled(true)
	-- 			btnNode:setBrightStyle(ccui.BrightStyle.normal)
	--     	end

	-- 	end
	-- end
    for i=1,5 do
		local btnNode = channelNode:getChildByTag(i)
		local fileName1 = "uifile/n_UIShare/chat/sjlt_b_00%d%s.png"
		local fileName = string.format(fileName1,i,"a")
         if i == tag then 
            btnNode:setEnabled(false)
            fileName = string.format(fileName1,i,"b") --高亮
        else 
	   		if (i == 3 and self.showBattleChannel ~= true ) or (i == 5 and self.showGuideChannel ~= true) then
	            btnNode:setEnabled(false)
	            fileName = string.format(fileName1,i,"c") --灰

	        else
	            btnNode:setEnabled(true)
	            fileName = string.format(fileName1,i,"a") --normal
	        end
        end 
        btnNode:loadTexture(fileName)
    end

	local private_node = node:getChildByTag(3)
	local chatRoom_node = node:getChildByTag(2)
	if tag == 4 then
		--密聊 展开密聊列表，聊天列表右移
		self.isPrivateChat = true
		local move = cc.MoveTo:create(0.1,	cc.p(private_node:getPositionX() + 148,private_node:getPositionY()))
		private_node:runAction(move)
		local move2 = cc.MoveTo:create(0.1, cc.p(chatRoom_node:getPositionX()+148,chatRoom_node:getPositionY()))
		chatRoom_node:runAction(move2)

		local privateItem = private_node:getChildByName(string.format("privateItem%d", self.default_userType))
		self:channelPriChatItemCallBack(privateItem,ccui.TouchEventType.ended)
	else 
		--如果之前为密聊，则左移
		if self.isPrivateChat == true then
			self.isPrivateChat = false
			local move = cc.MoveTo:create(0.1,	cc.p(private_node:getPositionX()-148,private_node:getPositionY()))
			private_node:runAction(move)
			local move2 = cc.MoveTo:create(0.1, cc.p(chatRoom_node:getPositionX()-148,chatRoom_node:getPositionY()))
			chatRoom_node:runAction(move2)
		end
		self:getChannelData(self.default_index)
	end
end

function ChatUILayer:channelPriChatItemCallBack( sender,eventType  )
	local tag = sender:getTag()--68,70,72  好友，最近联系，黑名单，
	local private_node = sender:getParent()
	local list = private_node:getChildByTag(2)
	list:removeAllChildren()
	local privateItem1 = private_node:getChildByName("privateItem1")
	local privateItem2 = private_node:getChildByName("privateItem2")
	local privateItem3 = private_node:getChildByName("privateItem3")
	local friendNum = self.chatDataMgr:getFriendNum() 
	local blackNum =  self.chatDataMgr:getBlackNum() 
	local recentNum = self.chatDataMgr:getRecentNum() 
	local text1 = privateItem1:getChildByName("text_0")
	text1:setString(string.format("%d/%d", friendNum,ChatDataCache.friendMax))
	local text2 = privateItem2:getChildByName("text_0")
	text2:setString(string.format("%d/%d", recentNum,ChatDataCache.recentChatMax))
	local text3 = privateItem3:getChildByName("text_0")
	text3:setString(string.format("%d/%d", blackNum,ChatDataCache.blackMax))

	local maxH = privateItem1:getContentSize().height
	local maxList = list:getContentSize().height
	--2,移动到x,3/2 maxH + (maxList)
	--3移动到 x,1/2 maxH + (maxList)
	--list移动到 2 maxH
	if eventType == ccui.TouchEventType.ended then
		-- local userList= nil
		if tag == privateItem1:getTag() then
			print("privateItem1:"..privateItem1:getTag())
			self:addChannelRedDop(3,1,false)
			if privateItem2:getPositionY() ~= maxH*3/2 then
				privateItem2:setPosition(cc.p(privateItem2:getPositionX(),maxH*3/2))
			end
			if privateItem3:getPositionY() ~= maxH/2 then
				privateItem3:setPosition(cc.p(privateItem3:getPositionX(),maxH/2))
			end
			if list:getPositionY() ~= maxH*2 then
				list:setPosition(cc.p(list:getPositionX(),maxH*2))
			end
			self.default_userType = 1

		elseif tag == privateItem2:getTag() then
			print("privateItem2:"..privateItem2:getTag())
			self:addChannelRedDop(3,2,false)
			if privateItem2:getPositionY() ~= maxH*3/2 + maxList then
				privateItem2:setPosition(cc.p(privateItem2:getPositionX(),maxH*3/2 + maxList))
			end
			if privateItem3:getPositionY() ~= maxH/2 then
				privateItem3:setPosition(cc.p(privateItem3:getPositionX(),maxH/2))
			end
			if list:getPositionY() ~= maxH then
				list:setPosition(cc.p(list:getPositionX(),maxH))
			end
			self.default_userType = 2

		elseif  tag == privateItem3:getTag() then
			print("privateItem3:"..privateItem3:getTag())
			self:addChannelRedDop(3,3,false)
			if privateItem2:getPositionY() ~= maxH*3/2 + maxList then
				privateItem2:setPosition(cc.p(privateItem2:getPositionX(),maxH*3/2 + maxList))
			end
			if privateItem3:getPositionY() ~= maxH/2 + maxList then
				privateItem3:setPosition(cc.p(privateItem3:getPositionX(),maxH/2 + maxList))
			end
			if list:getPositionY() ~= 0 then
				list:setPosition(cc.p(list:getPositionX(),0))
			end
			self.default_userType = 3
		end
		--刷新成员数据
		self.curChatMember["type"] = "p2p"
		self.curChatMember["sessionType"] = 0
		self.default_userListIndex = 1
		self:refresh_userList()
		-- --刷新聊天数据
		self:refreshChatroomUI()

	end
end

function ChatUILayer:initChannelCall( index ) --
	if self.uiLayer == nil then
		return
	end
	
	local node = self.uiLayer:getChildByTag(2)
	local channelNode = node:getChildByTag(4)--频道按钮组
    local  tabBTN = channelNode:getChildByTag(index)
	self:channelItemCallBack(tabBTN,nil)
end

function ChatUILayer:getChannelData( channelIndex ) 
	local sessionId = ""
	local chatType = ""
	local sessionType = 0
	local callfunc = nil
	if channelIndex  == 1 then
		sessionId = self.sysRoomID
		chatType = "sysRoom"
		sessionType = 2
		callfunc = self.initConcationSysRoom
	elseif channelIndex == 2 then
		sessionId = self.wordRooomID
		sessionType = 2
		chatType = "chatRoom"
		callfunc = self.initConcationChatRoom
	elseif channelIndex == 3 then
		sessionId = self.battleRoomID
		sessionType = 2
		chatType = "battleRoom"
		callfunc = self.initConcationBattleRoom
	elseif channelIndex == 5 then
		sessionId = self.guideTeamID
		sessionType = 2
		chatType = "guideRoom"
		callfunc = self.initConcationGuideTeam
		if g_channel_control.chatTeamUsed == true then
			sessionType = 1
			callfunc = self.initConcationGuideTeam2
		end
	end
	-- self:initConcationGuideTeam(true)
	print("sessionId:"..tostring(sessionId).."   callfunc:"..tostring(callfunc))
	if sessionId == nil or sessionId == "" then
		callfunc(self,true)
	else
		self.curChatMember["type"] = chatType
		self.curChatMember["sessionType"] = sessionType
		self.curChatMember["sessionId"] = sessionId
	   	self:refreshChatroomUI()
	end
end
-- Error parsing snippet xml: Error document empty. 
-- In file Packages/User/QuickXDev.cache/f84729111e3c4b9dd4dcf42915f60578/checkRefrushUserListFromBlack-type_1.sublime-snippet
function ChatUILayer:loginNim(  )
	local function loginSuccessCall( type_ )
		if type_ == "LoginNimSuccess" then --第一次登陆云信成功
			self:initChannelCall(self.default_index)   
		elseif type_ == "LoginNimSkip" then --云信已经登陆过
			self:initConcationGuideTeam(false)
			self:initChannelCall(self.default_index)   
		end

	end
	self.chatDataMgr:callLoginNim(loginSuccessCall)
end

function ChatUILayer:initConcationSysRoom( refreshRoom ) --系统聊天室没有ID，本地定义
	if self.sysRoomID == nil then
		self.sysRoomID = "sysRoomId"
	end
	if refreshRoom then
		local t_data = {
			chatRoom = {
				roomId = self.sysRoomID,
				name   = UITool.ToLocalization("系统") 
			},
			member = {}
		}

		self.curChatMember["type"] = "sysRoom"
	   	self.curChatMember["sessionType"] = 2
	   	self.curChatMember["sessionId"] = t_data["chatRoom"]["roomId"]
	   	self.curChatMember["sysRoom"] = t_data["chatRoom"]
	   	self.curChatMember["member"] = t_data["member"]

	   	self:refreshChatroomUI()
	end
end

function ChatUILayer:initConcationChatRoom( refreshRoom )
	if self.wordRooomID == nil then --世界
		local roomid_index = self.chatDataMgr:getRoomIndexDefault()
		local roomid  = self.chatDataMgr:getRoomIDByIndex(roomid_index)
		print("default_world_index:"..tostring(default_world_index)..".....roomid:"..tostring(roomid))

		if roomid == "0" then
			GameManagerInst:alert(UITool.ToLocalization("聊天频道未找到"));
			return
		end

		local function enterChatRoomCall( t_data )
			dump(t_data, "receive.....wordRooomID")
			if t_data["result"] == "0" then --进入聊天室失败，之后切换频道时重新进入
				self.wordRooomID = nil
				print("initChannelCall wordRooomID error---")
				if self.default_index == 2 and refreshRoom == true  then
					local function reEnterCall(  )
						self:initConcationChatRoom( refreshRoom )
					end
					MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("进入频道失败，是否重新连接"),self,reEnterCall,self.BtnClose)

				end
			else
				self.wordRooomID = roomid
				self.chatRoomIndex = roomid_index
				self.curChatMember["chatRoom"] = t_data["chatRoom"]
				if refreshRoom then
					self.curChatMember["type"] = "chatRoom"
				   	self.curChatMember["sessionType"] = 2
				   	self.curChatMember["sessionId"] = t_data["chatRoom"]["roomId"]
				   	self.curChatMember["member"] = t_data["member"]

				   	self:refreshChatroomUI()
				end
				--测试代码，手动添加聊天数据
				self.chatDataMgr:testPushSchedule()
			end
		end

		self.chatDataMgr:enterChatRoom(roomid,enterChatRoomCall)
	else
		if refreshRoom then
			self.curChatMember["type"] = "chatRoom"
	   		self.curChatMember["sessionType"] = 2
	   		self.curChatMember["chatRoom"] = self.curChatMember["chatRoom"] or {}
	   		self.curChatMember["sessionId"] = self.wordRooomID
	   		self:refreshChatroomUI()
	   	end

	end
end

function ChatUILayer:initConcationBattleRoom( refreshRoom )
	local battleID = self.rData["battle_chat_id"] 
	if self.battleRoomID ~= nil and battleID ~= nil and self.battleRoomID == battleID then
		if refreshRoom then
			self.curChatMember["type"] = "battleRoom"
		   	self.curChatMember["sessionType"] = 2
	   		self.curChatMember["battleRoom"] = self.curChatMember["battleRoom"] or {}
		   	self.curChatMember["sessionId"] = self.battleRoomID
		   	self:refreshChatroomUI()
		end
	else
		print("initConcationBattleRoom...roomID:"..battleID)
		if battleID == nil then
			GameManagerInst:alert(UITool.ToLocalization("聊天频道未找到"));
			return
		end
		local function receiveEnterChatRoom(t_data)
		    -- local cjson = require "cjson"
		    -- local t_data = cjson.decode(data)
		    dump(t_data, "receive.....battleRoomID")
			if t_data["result"] == "0" then --进入聊天室失败，之后切换频道时重新进入
				self.battleRoomID = nil
				print("initChannelCall battleRoomID error ---")
				if self.default_index == 3 and refreshRoom == true  then
					local function reEnterCall(  )
						self:initConcationBattleRoom( refreshRoom )
					end
					MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("进入频道失败，是否重新连接"),self,reEnterCall,self.BtnClose)

				end
				return
			else
				self.battleRoomID = battleID

				t_data["chatRoom"]["name"] = UITool.ToLocalization("战斗") 
				self.curChatMember["battleRoom"] = t_data["chatRoom"]
				if refreshRoom then
					self.curChatMember["type"] = "battleRoom"
				   	self.curChatMember["sessionType"] = 2
				   	self.curChatMember["sessionId"] = t_data["chatRoom"]["roomId"]
				   	self.curChatMember["member"] = t_data["member"]

				   	self:refreshChatroomUI()
				end
			 end

		end
		self.chatDataMgr:enterChatRoom(battleID, receiveEnterChatRoom)


	end
end

function ChatUILayer:initConcationGuideTeam2 ( refreshRoom )

	if self.guideTeamID == nil and self.showGuideChannel == true then
		local guideId = self.chatDataMgr:getGuideID()--tostring(chat_info["guild_group_id"]) 
		print("initConcationGuideTeam...roomID:"..guideId)
		if self.chatDataMgr:isMyTeam(guideId) ~= true then
			LogManager.showSimpMsgDebug("GuideId:"..tostring(guideId)..",is not a teamId or is not my Team")
			self.guideTeamID = nil
			return
		end
		self.chatDataMgr:fetchMessageHistory(guideId, 1, nil)
		self.guideTeamID = guideId
		local t_data= {
		chatRoom = {
			roomId = self.guideTeamID,
			name = UITool.ToLocalization("公会") ,
			}
		}
		self.curChatMember["guideRoom"] = t_data["chatRoom"]
		if refreshRoom then
			self.curChatMember["type"] = "guideRoom"
		   	self.curChatMember["sessionType"] = 1
		   	self.curChatMember["sessionId"] = t_data["chatRoom"]["roomId"]
		   	self.curChatMember["member"] = t_data["member"]

		   	self:refreshChatroomUI()
		end
	elseif self.guideTeamID ~= nil and self.showGuideChannel == false then --退出聊天室
		self.chatDataMgr:quitTeam(self.guideTeamID)
		self.guideTeamID = nil
	else
		if refreshRoom then
			self.curChatMember["type"] = "guideRoom"
		   	self.curChatMember["sessionType"] = 1
	   		self.curChatMember["guideRoom"] = self.curChatMember["guideRoom"] or {}
		   	self.curChatMember["sessionId"] = self.guideTeamID
		   	self:refreshChatroomUI()	
		end

	end		--todo
end

function ChatUILayer:initConcationGuideTeam( refreshRoom )
	if self.guideTeamID == nil and self.showGuideChannel == true then
		local guideId = self.chatDataMgr:getGuideID()--tostring(chat_info["guild_group_id"]) 
		print("initConcationGuideTeam...roomID:"..guideId)

		local function receiveEnterChatRoom(t_data)
		    -- local cjson = require "cjson"
		    -- local t_data = cjson.decode(data)
		    dump(t_data, "receive.....guideTeamID")
			if t_data["result"] == "0" then --进入聊天室失败，之后切换频道时重新进入
				self.guideTeamID = nil
				print("initChannelCall guideTeamID error ---")
				if self.default_index == 5 and refreshRoom == true  then
					local function reEnterCall(  )
						self:initConcationGuideTeam( refreshRoom )
					end
					MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("进入频道失败，是否重新连接"),self,reEnterCall,self.BtnClose)
				end
				return
			else
				self.guideTeamID = guideId
				t_data["chatRoom"]["name"] = UITool.ToLocalization("公会") 
				self.curChatMember["guideRoom"] = t_data["chatRoom"]
				if refreshRoom then
					self.curChatMember["type"] = "guideRoom"
				   	self.curChatMember["sessionType"] = 2
				   	self.curChatMember["sessionId"] = t_data["chatRoom"]["roomId"]
				   	self.curChatMember["member"] = t_data["member"]

				   	self:refreshChatroomUI()
				end
			 end

		end
		self.chatDataMgr:enterChatRoom(guideId, receiveEnterChatRoom)

	elseif self.guideTeamID ~= nil and self.showGuideChannel == false then --退出聊天室
		self.chatDataMgr:exitChatRoom(self.guideTeamID)
		self.guideTeamID = nil
	else
		if refreshRoom then
			self.curChatMember["type"] = "guideRoom"
		   	self.curChatMember["sessionType"] = 2
	   		self.curChatMember["guideRoom"] = self.curChatMember["guideRoom"] or {}
		   	self.curChatMember["sessionId"] = self.guideTeamID
		   	self:refreshChatroomUI()	
		end

	end
end

function ChatUILayer:chatBtnCall(sessionId, sessionType ,chatMsg)
	local function callback(t_data)
		for k,v in pairs(t_data) do
			print("t_data:",k,v)
		end
		local function touchMemberCallback(data) 
			local pannel_name = data["pannel_name"]
			-- for k,v in pairs(data) do
			-- 	print(k,v)
			-- end
			print("----touchChatListMember----pannel_name:"..tostring(pannel_name))
			if pannel_name == "btn_addFriend" then
				self:callAddFriend(data)
			elseif pannel_name == "btn_addBlack" then
				self:callAddBlack(data)
			elseif pannel_name == "btn_chat" then
				self:callChat(data)	
			elseif pannel_name == "btn_rm" then
				self:callAddFriend(data)  
			elseif pannel_name == "btn_report" then
				data["reportMsg"] = chatMsg
				self:reportPlayer(data)
			end
		end	

		local t_user = table.deepcopy(t_data)
		t_user["sessionType"] = sessionType
		t_user["callbackFunc"] = touchMemberCallback
		t_user["reportMsg"] = chatMsg
		SceneManager:toShowChatBtn( t_user )
	end
	self.chatDataMgr:getUserInfo(sessionId,callback)
end

function ChatUILayer:clickRoomMenuCall( sender,eventType )
	local sessionId = self.curChatMember["sessionId"]
	local sessionType = self.curChatMember["sessionType"]
	print("···id:"..tostring(sessionId).."....type:"..tostring(self.curChatMember["sessionType"]))
	if sessionId ~= "" then
		self:chatBtnCall(sessionId,sessionType,nil)
	end
end

function ChatUILayer:touchChatListMember(sender,eventType) --触摸聊天人物头像 展开聊天按钮（加好友、黑名单、私聊）（删除好友）
	
	local tag = sender:getParent():getParent():getTag()

	if eventType ==ccui.TouchEventType.ended then
		local p1 = sender:getTouchBeganPosition()
        local p2 = sender:getTouchEndPosition()

        local l = cc.pGetDistance(p1,p2)
        if l < 30 then
			print("touch ...item..tag："..tag)
			local item_Table = self.curChatList[tag]
			local t_data = item_Table["data"]
			-- dump(t_data, "touchChatListMember:")
			if t_data ~= nil then
				local t_ext = t_data["remoteExt"] or {}
				if type(t_ext) ~= type({}) then
				    t_ext = {}
				end
				local t_session = t_data["session"]
				local t_id = t_data["from"]


				local m_id = self.chatDataMgr:getNimId() 
				if string.lower(t_id) == string.lower(m_id) then
					print("touch myself----")
				else
					local msg = t_data["text"]
					self:chatBtnCall(t_id,t_session["sessionType"],msg)
				end
			end
        end
 
	end
end

function ChatUILayer:reportPlayer( data ) --举报玩家
	local nim_id = data["user_id"]
	local player_id = data["player_id"]
	local reportMsg = data["reportMsg"]
	local showMsg = "举报玩家：id："..tostring(player_id).."....举报内容："..tostring(reportMsg)
	LogManager.showSimpMsgDebug(showMsg)

end
function ChatUILayer:callAddFriend( data) --2 添加/ 5 删除好友
	local nim_id = data["user_id"] 
	local isFriend = self.chatDataMgr:isInFriends(nim_id) --self.data["isFriend"]
	local alert_type = isFriend == true and 5 or 2
	local function callback( t_data )
		local t_alert = self.chatDataMgr:getAlertData(t_data,alert_type)
		self.chatDataMgr:chatAlert(t_alert)
	end
	self.chatDataMgr:getUserInfo(nim_id,callback)

end

function ChatUILayer:callAddBlack(data )
	local nim_id = data["user_id"] 
	local isBlack = self.chatDataMgr:isInBlacks(nim_id) --self.data["isBlack"] 

	if isBlack == false then
		local function callback( t_data )
			local alert_type = 1
			local t_alert = self.chatDataMgr:getAlertData(t_data,alert_type)
			self.chatDataMgr:chatAlert(t_alert)
		end
		self.chatDataMgr:getUserInfo(nim_id,callback)
	else
		local t = {}
		t["user_id"] = data["user_id"]
		self.chatDataMgr:callRemoveFromBlack(t )
	end
end

function ChatUILayer:callChat(data  )
	-- 黑名单能否私聊
	print("callChat:"..(data["user_name"] or data["user_id"]).."..:"..data["user_id"])
	local nim_id = data["user_id"]
	local isFriend = self.chatDataMgr:isInFriends(nim_id) --self.data["isFriend"]

	local function callback( t_data )
		local t = table.deepcopy(t_data)
		t["isFriend"] = isFriend
		self:changeToChatItem(t)
	end
	self.chatDataMgr:getUserInfo(nim_id,callback)

end

function ChatUILayer:touchUserListMember( sender,eventType ) --触摸好友玩家 切换聊天内容
	local tag = sender:getParent():getTag()
	print("touchUserListMember tag :"..tag.."...self.default_userListIndex:"..self.default_userListIndex)
	if tag == self.default_userListIndex then
		print("touchUserListMember....myself")
		return
	end
	self.default_userListIndex = sender:getParent():getTag()
	self:refresh_userList()
	self:refreshChatroomUI()
end

function ChatUILayer:touchChatlistVoice( sender,eventType )
	local tag = sender:getParent():getParent():getTag()
	print("touchChatlistVoice:"..tag)
	if eventType ==ccui.TouchEventType.ended then
		local item_Table = self.curChatList[tag]
		local t_data = item_Table["data"]
		if t_data ~= nil then
			local t_obj = t_data["messageObject"]
			self.chatDataMgr:playRecordVoice(t_obj)

		end
	end
end
--翻译是否屏蔽当前操作
--如果不屏蔽，需要在返回时判断当前UI是否为调用者所在UI
--如果屏蔽，直接刷新当前node
function ChatUILayer:touchChatTranslate( sender,eventType )
	local tag = sender:getParent():getParent():getTag()
	local sessionType = self.curChatMember["sessionType"]
   	local sessionId = self.curChatMember["sessionId"]

	print("touchChatTranslate:"..tag)
	local function translateCallback( t_data )
		-- dump(t_data,"touchChattranslate..translateCallback")
		local target_text = t_data["message"]
		if target_text ~= nil then 
			local target_list  = self.chatDataMgr:getListByType(sessionType,sessionId)
			if target_list ~= nil then
				--刷新数据
				local item_Table = target_list[tag]
				local t_data = item_Table["data"]
				t_data["text"] = target_text
				t_data["translate"] = 1
				--刷新UI
				local sessionType2 = self.curChatMember["sessionType"]
   				local sessionId2 = self.curChatMember["sessionId"]
   				if sessionId == sessionId2 and sessionType == sessionType2 then
					local child = self._scrollView:getChildByTag(tag)
					self:refresh_ChildItemData(child,t_data)
   				end
			end
		
		else
			LogManager.showSimpMsgDebug("error:服务器未返回message属性")
		end
	end

	if eventType ==ccui.TouchEventType.ended then
		local translate_img = sender:getChildByName("translate")
		if translate_img~= nil then
			print("--------------")
			local translate_icon = "n_UIShare/chat/sjlt_ui_098.png"
			translate_img:loadTexture(translate_icon)
    		local rotate = cc.RotateBy:create(2.0, 360)
    		local action = cc.RepeatForever:create(rotate)
    		translate_img:runAction(action)
		end
		local item_Table = self.curChatList[tag]
		-- dump(item_Table,"touchChatTranslate")
		local t_data = item_Table["data"]
		if t_data ~= nil then
			local source_text = t_data["text"]
			local source_lang = ""
			local target_lang = ""
			self.chatDataMgr:translateMessage(source_text,source_lang,target_lang,translateCallback)
		end
	end
end

function ChatUILayer:touchChatListFightMember( sender,eventType ) --触摸聊天列表多人战按钮
	local tag = sender:getParent():getParent():getParent():getTag()
	print("touchChatListFightMember:tag:"..tag)
end

function ChatUILayer:changeToChatItem( data )			--点击头像，主动发起私聊 从其他频道进入私聊
	local user_id  = data["user_id"]
	local t_friend = data["isFriend"] --是否直接进入好友，还是统一进入最近联系
	print("changeToChatItem:"..user_id)
	--加入最近联系中
	if self.curChatMember["sessionType"] == 0 then
		print("changeToChatItem-------sessionType == 0")
		return
	end

	self.default_userType = 2
	if self.chatDataMgr:isInFriends(user_id) then
		self.default_userType = 1
	end
	self.chatDataMgr:addOrMoveToUserListFront(self.default_userType,data)

	self.default_userListIndex = 1
	print("...default_userType:"..self.default_userType)

	local node = self.uiLayer:getChildByTag(2)
	local channelNode = node:getChildByTag(4)
	local private_node = channelNode:getChildByTag(4)
	self:channelItemCallBack(private_node,nil) --点击私聊
	-- 加载遮罩，更新聊天室名字，更新密聊列表
end

function ChatUILayer:refresh_userList(  ) 	-- 刷新用户列表,刷新数量
	print("refresh_userList++++self.default_userType:"..self.default_userType.."..self.default_userListIndex:"..self.default_userListIndex)
	local sessionType = self.curChatMember["sessionType"]
	if self.uiLayer == nil  then -- 页面在后台时获取数据 或者当前不是私聊界面
		return
	end
	self.userList_refresh = false

	local userType = self.default_userType 			--当前展示标签
	-- local user_list = nil 							--数据表
	local user_list = self.chatDataMgr:getUserList(userType)

	print("refresh_userList-------user_list_len:"..#user_list)
	local node = self.uiLayer:getChildByTag(2)
	local private_node = node:getChildByTag(3)
	local userScrollView = private_node:getChildByTag(2) --UI列表
	local listH = userScrollView:getContentSize().height
	userScrollView:removeAllChildren()
	if self.default_userListIndex > #user_list or self.default_userListIndex < 1 then
		self.default_userListIndex = 1
	end
	for i=1,#user_list do
		local user_data = user_list[i]
		local node = cc.CSLoader:createNode("ChatFriendUserNode.csb")

		local name = node:getChildByName("name")
		name:setString(user_data["user_name"])

		local bg = node:getChildByName("itemBg")
		local file = "n_UIShare/chat/sjlt_ui_008.png"
		local sizeH = bg:getContentSize().height
		bg:addTouchEventListener(handler(self,self.touchUserListMember))	
		if i == self.default_userListIndex then
			bg:loadTexture(file)
			user_data["show_red"] = false
		end
		UITool.setCommmonBtnRedDop(node,user_data["show_red"])

		userScrollView:addChild(node)
		node:setTag(i)
		node:setPosition(cc.p(0,listH - i*sizeH))

	end

	local sessionId,name,accid
	if #user_list > 0  then
		sessionId = string.lower(user_list[self.default_userListIndex]["user_id"])
		name = user_list[self.default_userListIndex]["user_name"]
		accid = user_list[self.default_userListIndex]["user_id"]
		print("accid:"..tostring(accid).."..name:"..name.."..sessionId:"..sessionId)
	end
	self.curChatMember["type"] = "p2p"
	self.curChatMember["sessionType"] = 0
	self.curChatMember["sessionId"] = sessionId
	local t_user = {
		["name"] = name,
		["accid"] = accid
	}
	self.curChatMember["p2p"] = t_user
	print("refresh_userList:type:"..self.curChatMember["type"])
end

function ChatUILayer:refreshChatroomUI()
	--修改聊天室名字
	print("refreshChatroomUI:type:"..self.curChatMember["type"].."....chatRoomIndex:"..tostring(self.chatRoomIndex))
	-- dump(self.curChatMember, "self.curChatMember")
	if self.uiLayer == nil then -- 页面在后台时获取数据
		return
	end
	local node = self.uiLayer:getChildByTag(2)
	local chatRoom_node = node:getChildByTag(2) 			 --聊天组件
	local chatRoom_lable = chatRoom_node:getChildByTag(1) 	 --世界频道ID：99999
	local chatMask = chatRoom_node:getChildByTag(10)		 --聊天室遮罩
	local changeChannel = chatRoom_node:getChildByTag(123)   --切换聊天室
   	local room_menu = chatRoom_node:getChildByTag(50)		 --私聊玩家按钮

   	local left_mask = node:getChildByName("left_mask");
   	left_mask:setVisible(false)

	local sessionType = self.curChatMember["sessionType"]
   	local sessionId = self.curChatMember["sessionId"]
   	if sessionId ~= nil then
   		sessionId =  string.lower( sessionId)
   	end
   	local chatRoomName = nil;
   	if self.curChatMember[self.curChatMember["type"]] ~= nil then
   		chatRoomName = self.curChatMember[self.curChatMember["type"]]["name"]
   	end

   	if self.default_index == 2 then --世界聊天频道名拱顶
   		changeChannel:setVisible(true)
   		chatRoomName = string.format(UITool.ToLocalization("频道%d"),self.chatRoomIndex)
   	else
   		changeChannel:setVisible(false)
   	end

   	if sessionType == 0 and chatRoomName ~= nil then
		room_menu:setVisible(true)
	else
		room_menu:setVisible(false)
   	end

	if chatRoomName == nil  then --好友列表如果为空 and sessionType == 0 
		chatRoomName = "..."
		chatMask:setVisible(true)	
	elseif self.curChatMember["sessionId"] == self.sysRoomID then
		chatMask:setVisible(true)	
	else
		chatMask:setVisible(false)
	end
	print("chatRoomName:"..chatRoomName)
	chatRoom_lable:setString(chatRoomName)

	if chatRoom_node:getChildByName("friendBtnNode") then --移除好友/黑名单操作UI
		chatRoom_node:removeChildByName("friendBtnNode", true)
	end
	local isShowFriendNode = false
   	if sessionType == 0 then --同时刷新私聊
   		isShowFriendNode = self:refreshPrivateUI()
   	end
   	if isShowFriendNode then
   		room_menu:setVisible(false)
   	end
   	local curList  = self.chatDataMgr:getListByType(sessionType,sessionId)
   	if self.curChatList == nil or self.curChatList ~= curList or sessionType == 0 then
   		print("begin--------initChatRoom----------")
   		self:initChatRoom()
   		self.curChatList = curList
   		-- if sessionType == 0 and (self.default_userType == 3 or isAddFriend)then --黑名单 或者好友列表加好友
   		if isShowFriendNode then
   			self.curChatList = nil	
   		end

   		self:initTable()
   	end
end

function ChatUILayer:refreshPrivateUI( ... )
	local node = self.uiLayer:getChildByTag(2)
	local chatRoom_node = node:getChildByTag(2) 			 --聊天组件
	local private_node = node:getChildByTag(3)
	local privateItem1 = private_node:getChildByName("privateItem1")
	local privateItem2 = private_node:getChildByName("privateItem2")
	local privateItem3 = private_node:getChildByName("privateItem3")
	local friendNum = self.chatDataMgr:getFriendNum() 
	local blackNum =  self.chatDataMgr:getBlackNum() 
	local recentNum = self.chatDataMgr:getRecentNum() 
	local text1 = privateItem1:getChildByName("text_0")
	text1:setString(string.format("%d/%d", friendNum,ChatDataCache.friendMax))
	local text2 = privateItem2:getChildByName("text_0")
	text2:setString(string.format("%d/%d", recentNum,ChatDataCache.recentChatMax))
	local text3 = privateItem3:getChildByName("text_0")
	text3:setString(string.format("%d/%d", blackNum,ChatDataCache.blackMax))

	--删除加好友/黑名单按钮页面

	local userType = self.default_userType 			--当前展示标签
	local user_list = self.chatDataMgr:getUserList(userType)
	
	local isShowFriend = false
	if userType == 3 then
		isShowFriend = true
	end
	--如果是好友，并且类型为加好友，则显示加好友页面
	if userType == 1 and friendNum > 0 then
		--如果是好友，如果是添加好友，显示按钮，否则显示领取/赠送体力按钮
		-- print("refreshChatroomUI:self.default_userListIndex:.."..self.default_userListIndex.."..addToFriend:"..user_list[self.default_userListIndex]["addToFriend"])
		if user_list[self.default_userListIndex]["addToFriend"] == 1 then 
			isShowFriend = true
			local friendBtnNode = self:getUserFriendNode(user_list[self.default_userListIndex],1)
			if friendBtnNode then
				chatRoom_node:addChild(friendBtnNode, 10,1001)
				friendBtnNode:setName("friendBtnNode")	
				self:refurshFriendNode(user_list[self.default_userListIndex])
			end
		else
			print("判断是否可赠送体力，判断是否可领取体力")
		end
	end
	if userType == 3 and blackNum > 0 then --如果是黑名单，显示黑名单按钮
		local friendBtnNode = self:getUserFriendNode(user_list[self.default_userListIndex],2)
		if friendBtnNode then
			chatRoom_node:addChild(friendBtnNode, 10,1001)
			friendBtnNode:setName("friendBtnNode")
			self:refurshFriendNode(user_list[self.default_userListIndex])

		end
	end
	return isShowFriend
end

function ChatUILayer:refurshFriendNode( data )
	local nim_id = data["user_id"]
	local function refrushFriendNode( t_data )
		print("refrushFriendNode:"..tostring(t_data))
		-- for k,v in pairs(t_data) do
		-- 	print("refrushFriendNode-------------:",k,v)
		-- end
		local user_icon = t_data["user_icon"] or 11
		local user_name = t_data["user_name"] or "user_name"
		local user_lv 	= t_data["user_lv"] or 999
		local user_time = t_data["user_time"] or 0

		local rootNode = self.uiLayer:getChildByTag(2)
		local chatRoom_node = rootNode:getChildByTag(2) 			 --聊天组件
		local node = chatRoom_node:getChildByName("friendBtnNode")
		if node then
			local roleFace = node:getChildByName("roleFace") 
			local heroinfo = hero[user_icon]
			roleFace:loadTexture(heroinfo.hero_bat_icon)
			roleFace:ignoreContentAdaptWithSize(true)
			local friendNode = node:getChildByTag(104)	--好友操作（同意/拒绝）
			local roleName = friendNode:getChildByName("roleName")
			roleName:setString(user_name)

			local time = friendNode:getChildByName("time")
			local timeStr = os.date("%Y-%m-%d %H:%M:%S",math.ceil(user_time))
			time:setString(timeStr)
			local rolelv1 = friendNode:getChildByName("rolelv1")
			local rolelv = friendNode:getChildByName("roleLv")
			rolelv:setString(tostring(user_lv))
		end
	end
	self.chatDataMgr:getUserInfo(nim_id,refrushFriendNode) 
end

function ChatUILayer:getUserFriendNode( data ,isAddFriend) --是黑名单或者好友
	print("getUserFriendNode:"..tostring(data))
	if data == nil then
		return nil
	end

	-- local user_icon = data["user_icon"] or 11
	-- local user_name = data["user_name"] or "user_name"
	-- local user_lv 	= data["user_lv"] or 999
	-- local user_id   = data["user_id"] or "user_id"
	-- local user_time = data["user_time"] or 0
	-- local user_msgType = data["user_msgType"] or 1
	local node = cc.CSLoader:createNode("ChatFriendAddNode.csb")

	-- local roleFace = node:getChildByName("roleFace") 
	-- local heroinfo = hero[user_icon]
	-- roleFace:loadTexture(heroinfo.hero_bat_icon)
	-- roleFace:ignoreContentAdaptWithSize(true)
	local friendNode = node:getChildByTag(104)	--好友操作（同意/拒绝）
	-- local roleName = friendNode:getChildByName("roleName")
	-- roleName:setString(user_name)

	-- local time = friendNode:getChildByName("time")
	-- local timeStr = os.date("%Y-%m-%d %H:%M:%S",math.ceil(user_time))
	-- time:setString(timeStr)
	-- local rolelv1 = friendNode:getChildByName("rolelv1")
	-- local rolelv = friendNode:getChildByName("roleLv")
	-- rolelv:setString(tostring(user_lv))

	local btn_addFriend = friendNode:getChildByName("btn_addFriend")
	local btn_rejectFriend = friendNode:getChildByName("btn_addFriend_0")  

	local blackNode = node:getChildByTag(105)  --黑名单操作（取消黑名单）
	local btn_cancelBlack = blackNode:getChildByName("btn_close")

	if isAddFriend == 1 then
		btn_addFriend:setVisible(true)
		btn_rejectFriend:setVisible(true)
		btn_cancelBlack:setVisible(false)
	elseif isAddFriend == 2 then --黑名单
		time:setVisible(false)
		rolelv1:setVisible(false)
		rolelv:setVisible(false)
		roleName:setVisible(false)

		btn_addFriend:setVisible(false)
		btn_rejectFriend:setVisible(false)
		btn_cancelBlack:setVisible(true)

	end


	local function CallBack( sender,eventType )
		if sender:getName() == "btn_addFriend" then 		 --同意好友申请
			self.chatDataMgr:callFriendOperation(data,3)
		elseif sender:getName() == "btn_addFriend_0" then 	 --拒绝
			self.chatDataMgr:callFriendOperation(data,4)
		elseif sender:getName() == "btn_close" then 		 --取消黑名单
			self:callAddBlack(data)	
		end
	end
	btn_addFriend:addClickEventListener(CallBack)
	btn_rejectFriend:addClickEventListener(CallBack)
	btn_cancelBlack:addClickEventListener(CallBack)

	return node 
end

function ChatUILayer:initChatRoom( )
	local node = self.uiLayer:getChildByTag(2)
	local chatRoom_node = node:getChildByTag(2) --聊天组件
	local panel_node = chatRoom_node:getChildByName("panel_list")
	local pSize = panel_node:getContentSize()
	local panel_posX,panel_posY = panel_node:getPosition()
	if self._scrollView == nil then
		self._direction = SCROLLVIEW_DIR_VERTICAL
		self._scrollView = ccui.ScrollView:create()
		chatRoom_node:addChild(self._scrollView)
		self._scrollView:setPosition(panel_node:getPosition())
	    self._scrollView:setDirection(self._direction)
	    self._scrollView:setBounceEnabled(true)
	    self._scrollView:setTouchTotalTimeThreshold(0.1)
	    self._scrollView:setContentSize(pSize.width,pSize.height)

	    self._scrollView:setScrollBarEnabled(false)
	    self._scrollView:addEventListener(handler(self, self.onScrollEvent))
	    self._scrollView:addTouchEventListener(handler(self, self.onTouchEventCall))
	else
	  	self._scrollView:removeAllChildren()
	end
	self._scrollView:setInnerContainerSize(cc.size(pSize.width,pSize.height))

    self.chatroom_maxY = self._scrollView:getContentSize().height
	self.curChatList = nil
	self.chatroom_isRefresh = false
	self.chatroom_index_min = 1 
	self.chatroom_index_max = 0 
	self.init_min_index = 0
end

function ChatUILayer:onTouchEventCall(touch, eventType)
	if eventType == ccui.TouchEventType.ended then
	    --todo
	elseif eventType == ccui.TouchEventType.began then
       	self.touchScrollPos =cc.p(self._scrollView:getInnerContainer():getPosition()) 
	      print("touch  began-------"..self.touchScrollPos.x,self.touchScrollPos.y)
	end
end

function ChatUILayer:onScrollEvent( sender,eventType )
	-- body
	local curScrollPos =cc.p(self._scrollView:getInnerContainer():getPosition()) 
	print("onScrollEvent-------------------Y:"..curScrollPos.y..".....self.scrollPosMinY:"..self.scrollPosMinY)
	if curScrollPos.y < self.scrollPosMinY and self.scrollPosMinY ~= 0 then
		local scrollPos = cc.p(0,self.scrollPosMinY)
		self._scrollView:setInnerContainerPosition(scrollPos)
		return
	end
	if self.touchScrollPos ~= nil and curScrollPos.y < 0 and curScrollPos.y > self.chatroom_maxY then
		-- print("·onScrollEvent:·self.touchEndScrollPosY:"..self.touchScrollPos.y..".....listVIewPos:"..self._scrollView:getInnerContainer():getPositionY())
		local scrollDis = curScrollPos.y - self.touchScrollPos.y
		local scrollDic = scrollDis > 0 and 1 or 2
		if math.abs(scrollDis) > 50 then
			print("onScrollEvent refruesh---began:"..self.touchScrollPos.y.."..end:"..curScrollPos.y.."...scrollPosMinY:"..self.scrollPosMinY)
			self.touchScrollPos = curScrollPos
			self:refreshTable(scrollDic)
		end
	end
end

function ChatUILayer:initTable() --初始刷新
	--初始加载list ，
	--如果缓存列表不足count，则全部加载
	--否则，加载末尾count位
	--上行刷新时，每次加载count位，直到init_min_index = 0

	if self.curChatList == nil  then
		print("initTable...self.curChatList ===nil  ")
		return
	end

	local data_len_max = self.curChatList["len_max"] or 0 --数据层数据index最大值，如果小于max则为当前数据层数量，
	print("initTable...data_len_max:"..data_len_max)

	self.chatroom_index_array= {}
	self.init_min_index = data_len_max - self.chatroom_index_count + 1
	self.init_min_index = self.init_min_index > 0 and self.init_min_index or 1
	self.chatroom_index_max , self.chatroom_index_min = self.init_min_index - 1,self.init_min_index
	self:refreshTable(0)
end

function ChatUILayer:initMore() --新增缓存数据最多count条，更新
	local data_len_max = self.curChatList["len_max"] or 0
	print("initmore...data_len_max:"..data_len_max.."..self.init_min_index:"..self.init_min_index.."..")
	local data_len_min = data_len_max - self.chatDataMgr.chatroom_list_sava_len + 1 --数据层最小值 
	local add_up_index = self.init_min_index --上限
	self.init_min_index = self.init_min_index - self.chatroom_index_count+1
	self.init_min_index = self.init_min_index > data_len_min and self.init_min_index or data_len_min
	local add_low_index = self.init_min_index > 0 and self.init_min_index or 1 --下限
	print("initMore:add_up_index:"..add_up_index.."..add_low_index:"..add_low_index)
	if add_up_index <= add_low_index then
		print("缓存数据已经全部加载完------")
		self.chatroom_isRefresh = false

		return
	end
    --加载更多item位置数据，扩大scrollView,调整scrollView位置
	local curScrollSize = self._scrollView:getContentSize()
	local innerSizeH =  self._scrollView:getInnerContainerSize().height --当前滚动视图高度
   	local ssize = self._scrollView:getContentSize()
	local list_maxY = ssize.height

	local len = add_up_index - add_low_index
	for i=1,len do
			local index = add_low_index 
			local item_Table = self.curChatList[index]
			if item_Table ~= nil then
				local data = item_Table["data"]
				local node = self:getChildBydata(data)
				if node ~= nil then 
					local nodeSize = node:getContentSize()
					node:setTag(index)

					print("init_more:addChild(CCNode_*_child):"..list_maxY.."..tag:"..index.."")
					add_low_index = index+1
					self.curChatList[index]["posX"] = 0
					self.curChatList[index]["posY"] = list_maxY
					self.curChatList[index]["itemH"] = nodeSize.height
					-- self.curChatList[index]["isInUI"] = true
					list_maxY = list_maxY - nodeSize.height
					-- table.insert(self.chatroom_index_array,i,index)--起始位置添加
					-- for k,v in pairs(self.chatroom_index_array) do
					-- 	print("init_more..chatroom_index_array:",k,v)
					-- end
				end
			end
			
		end

	local newSizeH = ssize.height - list_maxY --新加载item高度
	local array_len = #self.chatroom_index_array
	for i=1,array_len do
		local index = self.chatroom_index_array[i]
		if self.curChatList[index] ~= nil then
			local lastY = self.curChatList[index]["posY"]
			local nowY = self.curChatList[index]["posY"] - newSizeH
			self.curChatList[index]["posY"] = self.curChatList[index]["posY"] - newSizeH
		end
	end
	self.chatroom_maxY = self.chatroom_maxY - newSizeH
	-- self.chatroom_index_min = self.init_min_index 

	local innerSize = self._scrollView:getInnerContainerSize()
	local scrollPos =cc.p(self._scrollView:getInnerContainer():getPosition()) 

	self.chatroom_isRefresh = false
	print("initMore ---end--curScrollPos:"..scrollPos.y.."...inneSize:"..innerSize.height.."....newH:"..newSizeH.."....chatroom_index_min:"..self.chatroom_index_min)
end

function ChatUILayer:refreshTable( refreshType ) -- 0 初始刷新，1 下滑刷新，2上滑刷新
    --优化：最多存在chatroom_index_count=10条消息，超过10条时，取最底或最上item，刷新item
    --上滑：删除max，添加min
    --下滑：删除min,添加max
    print("self.userList_refresh:"..tostring(self.userList_refresh).."..sessionType:"..tostring(self.curChatMember["sessionType"]))
    if self.userList_refresh == true and self.curChatMember["sessionType"] == 0 then
    	self:refresh_userList() --刷新当前子列表
    	self:refreshChatroomUI() --如果之前聊天室为空，则刷新
    end
    if self.curChatList == nil then
    	return
    end
   	local data_len_max = self.curChatList["len_max"] or 0
	print("refreshTable："..refreshType.."..data_len_max:"..data_len_max.."chatroom_isRefresh:"..tostring(self.chatroom_isRefresh))
	if self.uiLayer == nil then -- 页面在后台时获取数据
		return
	end
	if data_len_max == 0 then
   		return
   	end
    if self.chatroom_isRefresh == true then
    	return
    end
   	self.chatroom_isRefresh = true
	--需要刷新最大数量  0表示刷新，否则增加(有可能max与min之间断层)
	local refresh_len = self.chatroom_index_count - #self.chatroom_index_array  --(self.chatroom_index_max - self.chatroom_index_min + 1)
	if refresh_len < 0 then
		print("error---------self.chatroom_index_array.len:"..#self.chatroom_index_array.."   chatroom_index_count:"..self.chatroom_index_count)
	end
	if refresh_len ==0 then --list中已存在count个元素，更新首位元素以及坐标
		local listPosY = self._scrollView:getInnerContainer():getPositionY() 
		if refreshType == 1 or refreshType == 0 then --下滑 maxIndex-1 minIndex-1
			self:refresh_MaxIndex(listPosY)
		elseif refreshType ==2 then
			self:refresh_MinIndex(listPosY)
		end
	else --list没有加载足够count元素，继续加载 --初始如果元素数大于count需要
		print("addChild:..refresh_len:"..refresh_len.."..data_len_max:"..data_len_max)
		for i=1,refresh_len or data_len_max do
			local index = self.chatroom_index_max + 1
			local item_Table = self.curChatList[index]
			if item_Table ~= nil then
				local data = item_Table["data"]
				local node = self:getChildBydata(data)
				if node ~= nil then
					self._scrollView:addChild(node)
					local ssize = self._scrollView:getContentSize()
					local nodeSize = node:getContentSize()
					node:setPosition(0,self.chatroom_maxY)
					node:setTag(index)

					print("addChild(CCNode_*_child):"..self.chatroom_maxY.."..tag:"..index.."")
					self.chatroom_index_max = index
					self.curChatList[index]["posX"] = 0
					self.curChatList[index]["posY"] = self.chatroom_maxY
					self.curChatList[index]["itemH"] = nodeSize.height
					self.curChatList[index]["isInUI"] = true
					self.chatroom_maxY = self.chatroom_maxY - nodeSize.height

					table.insert(self.chatroom_index_array,index) --末尾追加
					-- for k,v in pairs(self.chatroom_index_array) do
					-- 	print("chatroom_index_array:",k,v)
					-- end

				end
			end
			if i == refresh_len or i == data_len_max then
				self.chatroom_isRefresh = false
			end
		end
	end

	self:adjustListView()
end

function ChatUILayer:refresh_MaxIndex( listPosY ) --下行刷新 list当前坐标
	--min
	local maxNode = self._scrollView:getChildByTag(self.chatroom_index_max)
	local maxPosY = maxNode:getPositionY()
	local innerSizeH =  self._scrollView:getInnerContainerSize().height
	local scrollH = self._scrollView:getContentSize().height
	print("refresh_maxIndex:"..self.chatroom_index_max.."..maxPosY:"..maxPosY.."..listPosy:"..listPosY.."..innersizeH:"..innerSizeH)
	print("min:"..self.chatroom_index_min.."..max:"..self.chatroom_index_max)
		--如果当前max超出屏幕则停止刷新
	if maxPosY + listPosY  <  -50 then
		--todo
		print("refresh_MaxIndex----当前max超出屏幕则停止刷新")
		self.chatroom_isRefresh = false
		return
	end
	--如果当前数据层最小值已经超过UI层最大值，
	local next_index = self.chatroom_index_max + 1
	local data_len_max = self.curChatList["len_max"]
	local len_min = data_len_max - self.chatDataMgr.chatroom_list_sava_len + 1 
	if len_min > 0 and self.chatroom_index_max < len_min then 
		print("refresh_maxIndex:-----len_min"..tostring(len_min).."....chatroom_index_max:"..tostring(self.chatroom_index_max))
		next_index = len_min 
	end

	local nextNode = self._scrollView:getChildByTag(next_index)
	local nextData = self.curChatList[next_index] 
	local minNode = self._scrollView:getChildByTag(self.chatroom_index_min)

	if minNode ~= nil and nextNode == nil and nextData ~= nil then
		self.curChatList[self.chatroom_index_min]["isInUI"] = false
		self.curChatList[next_index]["isInUI"] = true
		
		minNode:setTag(next_index)
		self:refresh_ChildItemData(minNode,nextData["data"])

		local node_size = minNode:getContentSize()
		local last_posY = self.curChatList[self.chatroom_index_max]["posY"]
		local last_H = self.curChatList[self.chatroom_index_max]["itemH"]
		local now_posY = self.curChatList[next_index]["posY"]
		print("now_posY:"..now_posY.."..last_posY:"..last_posY.."..last_H:"..last_H.."...self.chatroom_maxY:"..self.chatroom_maxY)
		if now_posY == 0 then
			now_posY = last_posY - last_H 
			self.curChatList[next_index]["posY"] = now_posY
			self.curChatList[next_index]["itemH"] = node_size.height
			if self.chatroom_maxY > now_posY - node_size.height then
				self.chatroom_maxY = now_posY - node_size.height
			end
		end
		local now_posX = self.curChatList[next_index]["posX"]
		minNode:setPosition(cc.p(now_posX,now_posY-self.chatroom_maxY))

		if len_min > self.chatroom_index_min then
			self.curChatList[self.chatroom_index_min] = nil
		end

		--移除max_index,添加min_index
		table.remove(self.chatroom_index_array,1)
		table.insert(self.chatroom_index_array,next_index)

		self.chatroom_index_max = next_index
		self.chatroom_index_min = self.chatroom_index_array[1]--self.chatroom_index_min + 1
		print("refresh_maxIndex..chatroom_index_min:"..self.chatroom_index_min.."......chatroom_index_max:"..self.chatroom_index_max)
		-- for k,v in pairs(self.chatroom_index_array) do
		-- 	print("chatroom_index_array:",k,v)
		-- end
		self:refresh_MaxIndex(listPosY) --循环直到max超出屏幕以外
	else
		self.touchScrollPos = nil 
		self.chatroom_isRefresh = false
	end
end

function ChatUILayer:refresh_MinIndex( listPosY ) --上行刷新
	--max
	local minNode = self._scrollView:getChildByTag(self.chatroom_index_min)
	local minPosY = minNode:getPositionY()
	local scrollH = self._scrollView:getContentSize().height
	local innerSizeH =  self._scrollView:getInnerContainerSize().height
	print("refresh_MinIndex:"..self.chatroom_index_max.."..maxPosY:"..minPosY.."..listPosy:"..listPosY.."...scrollH:"..scrollH.."..innersizeH:"..innerSizeH)
	print("min:"..self.chatroom_index_min.."..max:"..self.chatroom_index_max.."..init_min_index:"..self.init_min_index)
		--如果当前min距离屏幕较远
	if minPosY + listPosY >  scrollH + 50 or self.chatroom_index_min ==0 then
		--todo
		print("refresh_MinIndex  当前min距离屏幕较远  return")
		self.chatroom_isRefresh = false
		return
	end
	local next_min_index = self.chatroom_index_min - 1
	local data_len_max = self.curChatList["len_max"]
	local len_min = data_len_max - self.chatDataMgr.chatroom_list_sava_len + 1
	if len_min > 0 and self.chatroom_index_min <= len_min then  --数据层最小值已经超过可刷新值
		local listPosY1 = self._scrollView:getInnerContainer():getPositionY() 
		local scrollPos = cc.p(0,listPosY1)
		self.scrollPosMinY = scrollPos.y
		print("数据层最小值已经超过可刷新值：：minPosY:"..tostring(minPosY).."    scrollPos:"..listPosY1.."....self.scrollPosMinY:"..self.scrollPosMinY)
		-- self._scrollView:setInnerContainerPosition(scrollPos)
		-- self.touchScrollPos = nil 
		self.chatroom_isRefresh = false

		return
	end

	if self.init_min_index == self.chatroom_index_min   then
		self:initMore()
		return
	end

	local nextNode = self._scrollView:getChildByTag(next_min_index)
	local nextData = self.curChatList[next_min_index]
	local maxNode = self._scrollView:getChildByTag(self.chatroom_index_max)

	if maxNode ~= nil and nextNode == nil and nextData ~= nil then
		self.curChatList[self.chatroom_index_max]["isInUI"] = false
		self.curChatList[self.chatroom_index_max]["posY"] = 0 --
		self.curChatList[next_min_index]["isInUI"] = true

		maxNode:setTag(next_min_index)
		self:refresh_ChildItemData(maxNode,nextData["data"])
	
		local node_size = maxNode:getContentSize()
		local last_posY = self.curChatList[self.chatroom_index_min]["posY"]
		local now_posY = self.curChatList[next_min_index]["posY"]
		print("now_posY:"..now_posY.."..last_posY:"..last_posY.."..self.chatroom_maxY:"..self.chatroom_maxY)
		if now_posY == 0 then 
			assert(now_posY == 0,"error------不应当执行的代码")
			now_posY = last_posY + node_size.height
			self.curChatList[next_min_index]["posY"] = now_posY
		end
		local now_posX = self.curChatList[next_min_index]["posX"]
		maxNode:setPosition(cc.p(now_posX,now_posY-self.chatroom_maxY))
		--移除max_index,添加min_index
		table.remove(self.chatroom_index_array,#self.chatroom_index_array)
		table.insert(self.chatroom_index_array,1,next_min_index)

		self.chatroom_index_max = self.chatroom_index_array[#self.chatroom_index_array]--self.chatroom_index_max - 1
		self.chatroom_index_min = next_min_index
		print("refresh_MinIndex..chatroom_index_min:"..self.chatroom_index_min.."......chatroom_index_max:"..self.chatroom_index_max)
		-- for k,v in pairs(self.chatroom_index_array) do
		-- 	print("chatroom_index_array:",k,v)
		-- end
		self:refresh_MinIndex(listPosY) --循环直到max超出屏幕以外
	else
		-- for k,v in pairs(self.chatroom_index_array) do
		-- 	print("chatroom_index_array:",k,v)
		-- end
		self.chatroom_isRefresh = false
	end
end

function ChatUILayer:adjustListView( )
	local ssize = self._scrollView:getContentSize()
	local innerSize = self._scrollView:getInnerContainerSize()
	local scrollPos =cc.p(self._scrollView:getInnerContainer():getPosition()) 
	print("adjustListView:innierSIZE.height:"..innerSize.height.."...self.chatroom_maxY:"..self.chatroom_maxY.."..scrollPos:",scrollPos.y)
	local newSizeH = ssize.height - self.chatroom_maxY
	if self.chatroom_maxY < 0 and newSizeH > innerSize.height then
		innerSize.height = newSizeH

		self._scrollView:setInnerContainerSize(cc.size(innerSize.width,innerSize.height))
		self._scrollView:setInnerContainerPosition(scrollPos)
		self.scrollPosMinY = 0
		
		local len = #self.chatroom_index_array--self.curChatList["len_max"]
		for i=1,len do 			 --or self.chatroom_index_count 
			local index = self.chatroom_index_array[i]--self.chatroom_index_min + i - 1
			local node = self._scrollView:getChildByTag(index)
			if node ~= nil then
				if  self.curChatList[index] == nil  then 
					print("------数据层已经移除的节点:"..index)
				end
				local posX,posY,itemH = 0,self.curChatList[index]["posY"],self.curChatList[index]["itemH"]
				if node:getPositionY() ~= posY-self.chatroom_maxY then
					node:setPosition(cc.p(posX,posY-self.chatroom_maxY))
					print("adjusnt:index:"..index.."posY:"..posY.."..setY:"..(posY-self.chatroom_maxY))
				end
			end
		end
	end
end

function ChatUILayer:getChildBydata(messageData) -- 创建子组件
	print( "getChildByData:...messagetType:"..messageData["messageType"]..".. text:"..tostring(messageData["text"]))
	if messageData ==nil then
		return nil
	end
	local messageType = messageData["messageType"] --消息类型  0 文字，1 图片，2 声音
	local translate_state = messageData["translate"] or 0 --翻译状态

	local t_user = messageData["remoteExt"]
	if type(t_user) ~= type({}) then
		t_user = {}
	end
	local t_obj = messageData["messageObject"] --非文字类型包含属性
	if t_obj == nil then
		t_obj = {}
	end

	local ext_msg_type = t_user["message_type"] or 0 --自定义消息类型 0 默认为普通消息 ，1 系统消息 ,2 多人战 
	
	local node = cc.CSLoader:createNode("ChatLayerItemNode.csb")

	local panelSB = node:getChildByName("panelSB") --对方
	local panelMe = node:getChildByName("panelMe") --自己
	local panelSys = node:getChildByName("panelSys") --系统消息
	panelMe:setAnchorPoint(cc.p(0,0))
	panelSB:setAnchorPoint(cc.p(0,0))
	panelSys:setAnchorPoint(cc.p(0,0))
	local icon_id = t_user["user_icon"] or 11 
	local text = messageData["text"]
	local curTime = messageData["timestamp"]
	local name = t_user["user_name"] or messageData["from"] or "unKnowName"
	local from = messageData["from"]
	local isMyself = self.chatDataMgr:isMyself(from)
	if isMyself then
		icon_id = user_info["pl_icon_id"]
	end
	local heroinfo = hero[icon_id]
	local timeStr = os.date("%Y-%m-%d %H:%M:%S",math.ceil(curTime or 0))
	local voiceDuration = t_obj["duration"] --录音时长 
	local bgImgSize = cc.size(380,50) --默认文字bgsize
	local itemSize = cc.size(520,130) --默认item尺寸

	if ext_msg_type == 1 then
		panelSys:setVisible(true)
		panelMe:setVisible(false)
		panelSB:setVisible(false)

		local sysItmeSize = cc.size(520,100)
		local time = panelSys:getChildByName("msgTime")
		time:setString(timeStr)

		local ldata = t_user
        local noticebody = UITool.buildWorldNoticeToChat(ldata.notice_type,ldata.item_type,ldata.item_id,ldata.item_num,ldata.name,500)
        local msgNode = panelSys:getChildByName("msgNode")
        if msgNode == nil then
        	print("no msgNode")
        end
        if noticebody == nil then
        	print("no noticeBody")
        end
        if msgNode and noticebody then
        	print("----------------------addddddd")
        	panelSys:addChild(noticebody)
        	noticebody:setPosition(cc.p(msgNode:getPosition()))
        end
        itemSize.height = sysItmeSize.height
        node:setContentSize(itemSize)
		node:setAnchorPoint(cc.p(0,1))
        return node
	end
	panelSys:setVisible(false)
	if  isMyself ~= true then --消息通过接收获得,messageData["isReceivedMsg"] == true
		panelMe:setVisible(false)
		panelSB:setVisible(true)
		if panelSB:getTag() ~= 101 then --设置Tag值用于刷新时判断pannelSB是否已经加载过
			panelSB:setTag(101)
		end
		local meRoleFace = panelSB:getChildByName("roleFace")
		meRoleFace:loadTexture(heroinfo.hero_bat_icon)
		meRoleFace:addTouchEventListener(handler(self,self.touchChatListMember))
		meRoleFace:ignoreContentAdaptWithSize(true)

		local meTime = panelSB:getChildByName("msgTime")
		meTime:setString(timeStr)

		local meName = panelSB:getChildByName("roleName")
		meName:setString(name)

		local translateNode = panelSB:getChildByName("translateNode") --翻译节点默认隐藏
		translateNode:setVisible(false)
		local translateImg = translateNode:getChildByName("translate")
		translateImg:stopAllActions()
		translateImg:setRotation(0)

		local mesBg = panelSB:getChildByName("bgImg")
		local mesLable = panelSB:getChildByName("msgText")
		local meVoice = panelSB:getChildByName("voice")
		local meVoiceDuration = panelSB:getChildByName("voiceDuration")

		local fightNode = panelSB:getChildByName("fightNode")
		if ext_msg_type == 2 then --多人战斗	
			mesLable:setVisible(false)
			mesBg:setVisible(false)
			local mesLable2 = fightNode:getChildByName("text_lable") 
			mesLable2:setString(text)

			local clickLable = fightNode:getChildByName("touch_lable") --点击进入
			clickLable:addTouchEventListener(handler(self,self.touchChatListFightMember))

		else
			fightNode:setVisible(false) 
			if messageType == 0 then --普通消息
				--翻译组件
				translateNode:setVisible(true) --普通消息显示翻译
				translateNode:setPosition(cc.p(meName:getPositionX()+ meName:getContentSize().width,translateNode:getPositionY()))
				local translate_img = "n_UIShare/chat/sjlt_ui_099.png"
				if translate_state == 0 then --未翻译
					translateNode:addTouchEventListener(handler(self,self.touchChatTranslate))
					translate_img = "n_UIShare/chat/sjlt_ui_097.png"
				end
				translateImg:loadTexture(translate_img)
				
				meVoice:setVisible(false)
				meVoiceDuration:setVisible(false)

				mesLable:ignoreContentAdaptWithSize(true);
				mesLable:setTextAreaSize(cc.size(355,0))
				mesLable:setString(text)

				local lableSize = mesLable:getContentSize()
				if lableSize.height > 30	 then  --文字高：单行22，两行44 ，bg高：单行50，两行59，。。
					bgImgSize.height = lableSize.height + 15
				end
			elseif messageType == 2 then --音频
				mesLable:setVisible(false)
				local voiceSize = cc.size(60,40)
				voiceSize.width = voiceDuration*20 + 60
				meVoice:setContentSize(voiceSize)
				meVoice:addTouchEventListener(handler(self,self.touchChatlistVoice))
				meVoiceDuration:setString(tostring(voiceDuration).."S")
				meVoiceDuration:setPosition(cc.p(meVoice:getPositionX() + voiceSize.width+10,meVoice:getPositionY()))
			end
			mesBg:setContentSize(bgImgSize)

		end

		local offY = bgImgSize.height - 50 

		itemSize.height = itemSize.height + offY

		node:setContentSize(itemSize)
		print("BBBBBBBBB......BgsizeSB:".."..offY："..offY.."..panelSB isFirstAdd")

		for k,v in pairs(panelSB:getChildren()) do
			v:setPosition(cc.p(v:getPositionX(),v:getPositionY()+offY))
		end
	else
		panelSB:setVisible(false)
		panelMe:setVisible(true)
		if panelMe:getTag() ~= 102 then
			panelMe:setTag(102)
		end
		local meRoleFace = panelMe:getChildByName("roleFace")
		meRoleFace:loadTexture(heroinfo.hero_bat_icon)
		meRoleFace:ignoreContentAdaptWithSize(true)
		-- meRoleFace:addTouchEventListener(handler(self,self.touchChatListMember)) --是自己不加触摸

		local meTime = panelMe:getChildByName("msgTime")
		meTime:setString(timeStr)

		local meName = panelMe:getChildByName("roleName")
		meName:setString(name)

		local mesLable = panelMe:getChildByName("msgText")
		local mesBg = panelMe:getChildByName("bgImg")
		local meVoice = panelMe:getChildByName("voice")
		local meVoiceDuration = panelMe:getChildByName("voiceDuration")

		local fightNode = panelMe:getChildByName("fightNode")

		if ext_msg_type == 2 then --多人战斗	
			mesLable:setVisible(false)
			mesBg:setVisible(false)
			local mesLable2 = fightNode:getChildByName("text_lable")
			mesLable2:setString(text)

			local clickLable = fightNode:getChildByName("touch_lable")
			clickLable:addTouchEventListener(handler(self,self.touchChatListFightMember))

		else
			fightNode:setVisible(false)
			if messageType == 0 then --普通消息
				meVoice:setVisible(false)
				meVoiceDuration:setVisible(false)

				mesLable:ignoreContentAdaptWithSize(true);
				mesLable:setTextAreaSize(cc.size(355,0))
				mesLable:setString(text)

				local lableSize = mesLable:getContentSize()
				if lableSize.height > 30	 then  --文字高：单行22，两行44 ，bg高：单行50，两行59，。。
					bgImgSize.height = lableSize.height + 15
				end
			elseif messageType ==2 then
				mesLable:setVisible(false)
				local voiceSize = cc.size(60,40)
				voiceSize.width = voiceDuration*20 + 60
				meVoice:setContentSize(voiceSize)
				meVoice:addTouchEventListener(handler(self,self.touchChatlistVoice))
				meVoiceDuration:setString(tostring(voiceDuration).."S")
				meVoiceDuration:setPosition(cc.p(meVoice:getPositionX() - voiceSize.width - 50,meVoice:getPositionY()))
			end

			mesBg:setContentSize(bgImgSize)

		end

		local offY = bgImgSize.height - 50 
		itemSize.height = itemSize.height + offY
		node:setContentSize(itemSize)
		print("MMMMMMMMMMMMM......BgsizeME:".."..offY："..offY.."..panelME isFirstAdd")

		for k,v in pairs(panelMe:getChildren()) do
			v:setPosition(cc.p(v:getPositionX(),v:getPositionY()+offY))
		end
	end
	node:setAnchorPoint(cc.p(0,1))

	return node 
end

function ChatUILayer:refresh_ChildItemData(child,table_data )
	-- body
	print( "refresh_ChildItemData:...table_data[timestamp]："..tostring(table_data["text"]))
	if table_data ==nil or child == nil then
		return nil
	end
	local node = child

	local panelSB = node:getChildByName("panelSB") --对方
	local panelMe = node:getChildByName("panelMe") --自己
	local panelSys = node:getChildByName("panelSys") --系统
	local t_user = table_data["remoteExt"]
	if type(t_user) ~= type({}) then
		t_user = {}
	end

	local translate_state = table_data["translate"] or 0 --翻译状态
	local t_obj = table_data["messageObject"]
	if t_obj == nil then
		t_obj = {}
	end
	local ext_msg_type = t_user["message_type"] or 0 --消息类型 0 默认为普通消息 ，1 系统消息 ,2 多人战 
	local messageType = table_data["messageType"] --消息类型  0 文字，1 图片，2 声音

	local icon_id = t_user["user_icon"] or 11
	local text = table_data["text"]
	local curTime = table_data["timestamp"]
	local name = t_user["user_name"] or table_data["from"] or "unKnowName"
	local isMyself = self.chatDataMgr:isMyself(table_data["from"])
	if isMyself then
		icon_id = user_info["pl_icon_id"]
	end
	local heroinfo = hero[icon_id]
	local timeStr = os.date("%Y-%m-%d %H:%M:%S",math.ceil(curTime or 0))
	local voiceDuration = t_obj["duration"] --录音时长 

	local bgImgSize = cc.size(380,50) --默认文字bgsize
	local itemSize = cc.size(520,130) --默认item尺寸

	if ext_msg_type == 1 then
		panelSys:setVisible(true)
		panelMe:setVisible(false)
		panelSB:setVisible(false)
		local sysItmeSize = cc.size(520,100)

		panelSys:removeChildByTag(1001, true) --如果有系统富文本消息，删除
		local time = panelSys:getChildByName("msgTime")
		time:setString(timeStr)

		local ldata = t_user
        local noticebody = UITool.buildWorldNoticeToChat(ldata.notice_type,ldata.item_type,ldata.item_id,ldata.item_num,ldata.name,500)
        local msgNode = panelSys:getChildByName("msgNode")
        if msgNode and noticebody then
        	panelSys:addChild(noticebody)
        	noticebody:setTag(1001)
        	noticebody:setPosition(cc.p(msgNode:getPosition()))
        end

        itemSize.height = sysItmeSize.height
        node:setContentSize(itemSize)
		node:setAnchorPoint(cc.p(0,1))
        return node
	end
	panelSys:setVisible(false)
	if  isMyself ~= true then --消息通过接收获得table_data["isReceivedMsg"]
		panelMe:setVisible(false)
		panelSB:setVisible(true)
		local isFirstVisit = false -- 是否为第一次加载组件
		if panelSB:getTag() ~= 101 then
			panelSB:setTag(101)
			isFirstVisit = true
		end

		local meRoleFace = panelSB:getChildByName("roleFace")
		meRoleFace:loadTexture(heroinfo.hero_bat_icon)
		meRoleFace:addTouchEventListener(handler(self,self.touchChatListMember))
		meRoleFace:ignoreContentAdaptWithSize(true)

		local meTime = panelSB:getChildByName("msgTime")
		meTime:setString(timeStr)

		local meName = panelSB:getChildByName("roleName")
		meName:setString(name)
		
		local translateNode = panelSB:getChildByName("translateNode") --翻译节点默认隐藏
		translateNode:setVisible(false)
		local translateImg = translateNode:getChildByName("translate")
		translateImg:stopAllActions()
		translateImg:setRotation(0)

		local mesLable = panelSB:getChildByName("msgText")
		local mesBg = panelSB:getChildByName("bgImg")
		local meVoice = panelSB:getChildByName("voice")
		local meVoiceDuration = panelSB:getChildByName("voiceDuration")

		local fightNode = panelSB:getChildByName("fightNode")
	
		local last_bgSize = mesBg:getContentSize() --上个组件中bg是否变化

		if ext_msg_type == 2 then
			fightNode:setVisible(true)
			mesLable:setVisible(false)
			mesBg:setVisible(false)
			meVoiceDuration:setVisible(false)
			meVoice:setVisible(false)


			local mesLable2 = fightNode:getChildByName("text_lable")
			mesLable2:setString(text)

			local clickLable = fightNode:getChildByName("touch_lable")
			clickLable:addTouchEventListener(handler(self,self.touchChatListFightMember))
			
		else
			fightNode:setVisible(false)
			mesBg:setVisible(true)
			if messageType == 0 then
				meVoiceDuration:setVisible(false)
				meVoice:setVisible(false)
				mesLable:setVisible(true)

				mesLable:ignoreContentAdaptWithSize(true);
				mesLable:setTextAreaSize(cc.size(355,0))
				mesLable:setString(text)

				--翻译组件
				translateNode:setVisible(true) --普通消息显示翻译
				translateNode:setPosition(cc.p(meName:getPositionX()+ meName:getContentSize().width,translateNode:getPositionY()))
				local translate_img = "n_UIShare/chat/sjlt_ui_099.png"
				if translate_state == 0 then --未翻译
					translateNode:addTouchEventListener(handler(self,self.touchChattranslate))
					translate_img = "n_UIShare/chat/sjlt_ui_097.png"
				end
				translateImg:loadTexture(translate_img)

				local lableSize = mesLable:getContentSize()
				-- local size
				if lableSize.height > 30	 then 
					bgImgSize.height = lableSize.height + 15
				end

			elseif messageType == 2 then
				mesLable:setVisible(false)
				meVoiceDuration:setVisible(true)
				meVoice:setVisible(true)

				local voiceSize = cc.size(60,40)
				voiceSize.width = voiceDuration*20 + 60
				meVoice:setContentSize(voiceSize)
				meVoice:addTouchEventListener(handler(self,self.touchChatlistVoice))
				meVoiceDuration:setString(tostring(voiceDuration).."S")
				meVoiceDuration:setPosition(cc.p(meVoice:getPositionX() - voiceSize.width - 50,meVoice:getPositionY()))
			end

			mesBg:setContentSize(bgImgSize)
	
		end

		local offY = bgImgSize.height - 50 

		itemSize.height = itemSize.height + offY
		node:setContentSize(itemSize)
		-- node:setColor()
		-- node:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
		-- node:setBackGroundColor(cc.c3b(math.random(0,255), math.random(0,255), math.random(0,255)))
		local finalY =  bgImgSize.height - last_bgSize.height
		if isFirstVisit == true then
			finalY = offY
		end
		print("BBBBBBB......BgsizeSB:"..itemSize.width..".."..itemSize.height.."..finalY"..finalY.."..offY："..offY.."..panelSB isFirst:"..tostring(isFirstVisit))
		for k,v in pairs(panelSB:getChildren()) do
			v:setPosition(cc.p(v:getPositionX(),v:getPositionY()+finalY))
		end
	else
		panelSB:setVisible(false)
		panelMe:setVisible(true)
		local isFirstVisit = false
		if panelMe:getTag() ~= 102 then
			--表示第一次显示
			panelMe:setTag(102)
			isFirstVisit = true
		end
		local meRoleFace = panelMe:getChildByName("roleFace")
		meRoleFace:loadTexture(heroinfo.hero_bat_icon)
		-- meRoleFace:addTouchEventListener(handler(self,self.touchChatListMember))
		meRoleFace:ignoreContentAdaptWithSize(true)

		local meTime = panelMe:getChildByName("msgTime")
		meTime:setString(timeStr)

		local meName = panelMe:getChildByName("roleName")
		meName:setString(name)

		local mesBg = panelMe:getChildByName("bgImg")
		local mesLable = panelMe:getChildByName("msgText")
		local meVoice = panelMe:getChildByName("voice")
		local meVoiceDuration = panelMe:getChildByName("voiceDuration")

		local fightNode = panelMe:getChildByName("fightNode")
		local last_bgSize = mesBg:getContentSize() --上个组件中bg是否变化

		if ext_msg_type == 2 then
			fightNode:setVisible(true)
			mesLable:setVisible(false)
			mesBg:setVisible(false)
			meVoice:setVisible(false)
			meVoiceDuration:setVisible(false)

			local mesLable2 = fightNode:getChildByName("text_lable")
			mesLable2:setString(text)

			local clickLable = fightNode:getChildByName("touch_lable")
			clickLable:addTouchEventListener(handler(self,self.touchChatListFightMember))
		else
			fightNode:setVisible(false)
			mesBg:setVisible(true)
			if messageType == 0 then
				mesLable:setVisible(true)	
				meVoice:setVisible(false)
				meVoiceDuration:setVisible(false)
				
				mesLable:ignoreContentAdaptWithSize(true);
				mesLable:setTextAreaSize(cc.size(355,0))
				mesLable:setString(text)

				local lableSize = mesLable:getContentSize()

				if lableSize.height > 30	 then  
					bgImgSize.height = lableSize.height + 15
				end			

			elseif messageType == 2 then
				mesLable:setVisible(false)
				meVoice:setVisible(true)
				meVoiceDuration:setVisible(true)

				local voiceSize = cc.size(60,40)
				voiceSize.width = voiceDuration*20 + 60
				meVoice:setContentSize(voiceSize)
				meVoice:addTouchEventListener(handler(self,self.touchChatlistVoice))
				meVoiceDuration:setString(tostring(voiceDuration).."S")
				meVoiceDuration:setPosition(cc.p(meVoice:getPositionX() + voiceSize.width+10,meVoice:getPositionY()))
			end


			mesBg:setContentSize(bgImgSize)

		end


		local offY = bgImgSize.height - 50 

		itemSize.height = itemSize.height + offY
		node:setContentSize(itemSize)

		local finalY = bgImgSize.height - last_bgSize.height 
		if isFirstVisit == true then
			finalY = offY
		end
		print("MMMMMMMMMM......BgsizeME:"..itemSize.width..".."..itemSize.height.."..finalY"..finalY.."..offY:"..offY.."..panelMe isFirst:"..tostring(isFirstVisit))
		for k,v in pairs(panelMe:getChildren()) do
			v:setPosition(cc.p(v:getPositionX(),v:getPositionY()+finalY))
		end
	end
end

function ChatUILayer:checkRefrushUserListFromAdd( index ,userType) --收到好友/私聊时刷新玩家列表
	self.default_userListIndex = self.default_userListIndex or 1

	if index == 0 then
		if self.default_userType == userType then
			self.userList_refresh = true
			self.default_userListIndex  = self.default_userListIndex + 1
		end
	else 
		if index > 1 then
			if self.default_userType == userType then
				self.userList_refresh = true
				if self.default_userListIndex == index then
					self.default_userListIndex = 1
				elseif self.default_userListIndex < index then
					self.default_userListIndex = self.default_userListIndex + 1
				end
			end
		else -- index == 1
			if self.default_userType == userType then
				self.userList_refresh = true
			end
		end
	end

	if self.curChatMember["sessionType"] == 0 then
		if self.userList_refresh == true then
			self:refresh_userList()
		end
		self:refreshChatroomUI()
	end
end

function ChatUILayer:checkRefrushUserListFromRemove( index,list_type ) --从好友/黑名单删除时刷新玩家列表
	if self.default_userListIndex == index then
		self.default_userListIndex = index - 1
	elseif self.default_userListIndex < index then
		self.default_userListIndex = self.default_userListIndex + 1
	end
	if self.curChatMember["sessionType"] == 0 and self.default_userType == list_type then
		self.userList_refresh = true
	end
	if self.userList_refresh == true then
		self:refresh_userList()
		self:refreshChatroomUI()
	end
end

function ChatUILayer:checkRefrushUserListFromBlack( type_ ) --加入黑名单时判断是否刷新私聊按钮 (1 删除，）
	if self.curChatMember["sessionType"] == 0 then
		self:refreshChatroomUI()
		if type_ == 1 then 
			self:refresh_userList()
		end
	end
end
function ChatUILayer:clearEx()
    -- KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ChatUILayer:returnBack( )
	-- body
 	self.exist = false
    self.sData = {}
    self.rData = {}
    self.curChatList = nil
    self._scrollView = nil
    self.default_index = nil
    self:clearEx()

end

function ChatUILayer:BtnClose( ... )
	self:returnBack()   
end



