-- log输出管理

LogManager = {}


LogManager.COCOS_DEBUG_MODE = XBConfigManager:getInstance():getCocosDebugModel() -- cocos_debug 模式 bool


function LogManager.print( ... )
	-- body
	print(...)
end

function LogManager.dump( value, desciption, nesting )
	-- body
	dump(value, desciption, nesting)

end

----只有简单的信息展示， 带一个按钮 回调
function LogManager.showSimpMsgDebug( msg,tag )
	if LogManager.COCOS_DEBUG_MODE then

		local title = tag ~= nil and tostring(tag) or "TIP"
		title = "Debug info: "..tostring(title)
		msg = msg or ""

		print("tag", title)
		print("msg", msg)

		local pop = {}
		pop["buttonType"] = 1
		pop["formType"]   = 1
		pop["titleName"]  = title
		pop["basicDec"]   = msg
		pop["oneself"]    = nil
		pop["callFunc"]   = nil
		SceneManager:showMsgMode(pop)

	end 

	
end




























-- **************************************************自用方法**************************************
--[[
	此方法只在table.getValue 使用，其他地方不要调用！！！！
	弹出错误信息，如果debug：弹出提示，不打断游戏；如果release：直接报错
	取表值时使用table.getValue(”表名“，表，key1,key2,key3,...）

	local t = {}
	t["a"] = "aaa"
	table.getValue("t",t,"a")
	table.getValue("t",t,"a","bb") --error  会弹出LogManager.__showErrorForGetTableValue(msg,tag) 
]]--
LogManager.TABLE_MSG_NUM = 0 		--
LogManager.TABLE_MSG_NUM_MAX = 10 

function LogManager.__showErrorForGetTableValue( msg,tag )
	--
	if LogManager.COCOS_DEBUG_MODE then
		--弹出提示框
		if LogManager.TABLE_MSG_NUM >= LogManager.TABLE_MSG_NUM_MAX then 
			return 
		end 

		local function callfunc( ... )
			LogManager.TABLE_MSG_NUM = LogManager.TABLE_MSG_NUM - 1 
			if LogManager.TABLE_MSG_NUM < 0 then 
				print("error-------")
				LogManager.TABLE_MSG_NUM = 0
			end 
		end

		LogManager.TABLE_MSG_NUM = LogManager.TABLE_MSG_NUM + 1 

		local title = tag ~= nil and tostring(tag) or "TIP"

		local pop = {}
		pop["buttonType"] = 1
		pop["formType"]   = 1
		pop["titleName"]  = LogManager.TABLE_MSG_NUM.." "..title
		pop["basicDec"]   = msg
		pop["oneself"]    = nil
		pop["callFunc"]   = callfunc
		SceneManager:showMsgMode(pop)

	else 
		---直接报错
		LogManager.getUnExistFunc() --直接调用不存在的方法，触发崩溃
	end 

end
-- **************************************************自用方法**************************************
