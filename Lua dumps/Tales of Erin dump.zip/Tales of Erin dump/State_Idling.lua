--Idle状态。
--created by kobejaw.2018.3.29.
State_Idling = class("State_Idling",StateBase)


function State_Idling:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.Idling
end

function State_Idling:Enter()
	if self.entity.isDead then
		return
	end
	
	self.entity:playIdleAnimation();
end

function State_Idling:Exit()
	self.super.Exit(self)
end