BattlePrincessManager = class("BattlePrincessManager") 
BattlePrincessManager.__index = BattlePrincessManager
BattlePrincessManager.rootNode = nil
BattlePrincessManager.panel_MP = nil
BattlePrincessManager.spark = nil --遮罩
BattlePrincessManager.nzSkText = nil 
BattlePrincessManager.battleData = nil
BattlePrincessManager.mp4File = nil
BattlePrincessManager.btn = nil
BattlePrincessManager.askID = 0
BattlePrincessManager.nowMP = 0
BattlePrincessManager.totalMP = 1000
BattlePrincessManager.BATTLE_UI_PS = "uifile/battle_effect.csb"
BattlePrincessManager.BATTLE_UI_PS_UP = "uifile/battle_eff_nzsk_up.csb"
function BattlePrincessManager:createWithMainUINode(node)
    local battleInfo = BattlePrincessManager.new()
    battleInfo:init(node)
    return battleInfo
end

function BattlePrincessManager:init(node)
    self.isPrincess = true 
    self.skillInfo = SkillUtil:createSkillInfo(BattleDataManager.ps_skillID,false,true)
    self.state_PlayingSkill = State_PlayingSkill_Scene.new(self)

    self.isReady = false
    self.rootNode = node
    self.panel_MP = self.rootNode:getChildByTag(4)
    self.nzSkText = ccui.Helper:seekWidgetByTag(self.panel_MP,1095)
    self.nzSkText:setString("0")
    self.btn = ccui.Helper:seekWidgetByTag(self.panel_MP,41)
    function touchCallBack( sender,eventType  )
        if eventType == ccui.TouchEventType.ended then
            local tag = sender:getTag()
            if tag == 41 then
                if G_GameState ~= 1 or G_IsAllDead then
                    return
                end
                --释放女主技能
                if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
                    G_BattleScene:pauseGame()
                    self:playSKMP4()
                else
                    self:playSkill()
                end
		    elseif tag == 11111 then
                self._videoPlayer:stop()
                self._videoPlayer:setVisible(false)
                self.layer:setVisible(false)
                AudioManager:shareDataManager():resumeBGMusic()
                AudioManager:shareDataManager():resumeAll()
                G_BattleScene:resumeGame()
                self:playSkill() 
		    end 
        end
    end

    self.btn:addTouchEventListener(touchCallBack)
    self.btn:setTouchEnabled(false) --设置初始状态不能点击
    self.battleData = BattleDataManager:getData()
    local a_skill_id = self.battleData["ps"]["a_skill"]
    if  a_skill_id == 0 then 
        return 
    end 

    local ps_id = self.battleData["ps"]["p_id"]
    local ps = getPSID(ps_id)
    self.mp4File = princess_ocp[ps][ps_id]["ps_vedio"]
    self.askID  = tonumber( self.battleData["ps"]["a_skill"] ) 
    self.iconFile = skill[self.battleData["ps"]["a_skill"]]["skill_icon"]

    self.btn:loadTextureNormal(self.iconFile)
    self.btn:loadTexturePressed(self.iconFile)

    local action = cc.CSLoader:createTimeline(self.BATTLE_UI_PS)
    local acNode = self.panel_MP:getChildByTag(408)
    self.panel_MP:getChildByTag(410):setVisible(false)
    acNode:setZOrder(30)
    acNode:stopAllActions()
    acNode:runAction(action)
    action:play("up", true)

    local  nvSK_act = cc.CSLoader:createTimeline(self.BATTLE_UI_PS_UP)
    local  nvSK_Node = self.panel_MP:getChildByTag(422)
    self.spark = nvSK_Node:getChildByTag(1097)
    self.spark:setContentSize(cc.size(200,0))
    nvSK_Node:stopAllActions()
    nvSK_Node:runAction(nvSK_act)
    nvSK_act:play("up", true)

    local function VideoEventCallback(sener, eventType)
        if eventType == ccexp.VideoPlayerEvent.PLAYING then

        elseif eventType == ccexp.VideoPlayerEvent.PAUSED then
            self._videoPlayer:stop()
            self._videoPlayer:setVisible(false)
            self.layer:setVisible(false)
            AudioManager:shareDataManager():resumeAll()
            AudioManager:shareDataManager():resumeBGMusic()
            G_BattleScene:resumeGame()
            self:playSkill()
        elseif eventType == ccexp.VideoPlayerEvent.STOPPED then
       
        elseif eventType == ccexp.VideoPlayerEvent.COMPLETED then
            self._videoPlayer:stop()
            self._videoPlayer:setVisible(false)
            self.layer:setVisible(false)
            AudioManager:shareDataManager():resumeBGMusic()
            AudioManager:shareDataManager():resumeAll()
            G_BattleScene:resumeGame()
            self:playSkill()
        end
    end

    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        self._videoPlayer = ccexp.VideoPlayer:create()
        self._videoPlayer:setPosition(cc.p(640,360))
        self._videoPlayer:setAnchorPoint(cc.p(0.5,0.5))
        self._videoPlayer:setContentSize(cc.size(1280,720))

        self._videoPlayer:setVisible(false)

        self._videoPlayer:addEventListener(VideoEventCallback)
        self._videoPlayer:setTouchEnabled(false);
    end

    self.layer = ccui.Layout:create()--cc.Layer:create();
    self.layer:setName("touchLayer")
    self.rootNode:addChild(self.layer,1000000)
    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        self.layer:addChild(self._videoPlayer,9999)
    end
    self.layer:setContentSize(cc.size(1280,720))
    self.layer:setPosition(cc.p(0,0))
    self.layer:setVisible(false)
    self.layer:setTouchEnabled(true)
    self.layer:setTag(11111)
    self.layer:addTouchEventListener(touchCallBack)

    --新手教学
    local loginName = cc.UserDefault:getInstance():getStringForKey("login_name")
    self.finishTeach = cc.UserDefault:getInstance():getBoolForKey(loginName.."a1_2_1")    
end

function BattlePrincessManager:changeToDefault()
	local action = cc.CSLoader:createTimeline(self.BATTLE_UI_PS)
    local acNode =self.panel_MP:getChildByTag(408)
    self.panel_MP:getChildByTag(410):setVisible(false)
    acNode:setZOrder(30)
    acNode:stopAllActions()
    acNode:runAction(action)
    action:play("up", true)

    local  nvSK_act = cc.CSLoader:createTimeline(self.BATTLE_UI_PS_UP)
    local  nvSK_Node = self.panel_MP:getChildByTag(422)
    self.spark:setContentSize(cc.size(200,0))
    nvSK_Node:stopAllActions()
    nvSK_Node:runAction(nvSK_act)
    nvSK_act:play("up", true)
    self.nzSkText:setString("0")
    self.nowMP = 0
    self:setMP(self.totalMP,false)
end

function BattlePrincessManager:playSKMP4()
    self.btn:setTouchEnabled(false)
    local action = cc.CSLoader:createTimeline(self.BATTLE_UI_PS)
    local acNode =self.panel_MP:getChildByTag(408)
    self.panel_MP:getChildByTag(410):setVisible(false)
    acNode:setZOrder(30)
    acNode:stopAllActions()
    acNode:runAction(action)
    action:play("play", false)
    self.layer:setVisible(true)
    self._videoPlayer:setVisible(true)
    AudioManager:shareDataManager():pauseBGMusic()
    AudioManager:shareDataManager():pauseAll()
    self._videoPlayer:setFileName(self.mp4File)
    self._videoPlayer:play()

end	

function BattlePrincessManager:setTotalSP(total)--设置总的SP
    self.totalMP = total
end   

function BattlePrincessManager:playSkill()
    if G_GameState ~= 1 then
        return
    end

    self.isReady = false
    self:changeToDefault()
    self.state_PlayingSkill:Enter(self.skillInfo)
end

function BattlePrincessManager:setMP( MP,_increase) --设置女主蓝量
    if self.askID == 0 then 
        return 
    end 	

    if self.isReady then
        self.nowMP = 1000
        self.nzSkText:setString(100)
        return
    end

    if _increase == true then 
        self.nowMP = self.nowMP + MP
        if self.nowMP > 1000 then
            self.nowMP = 1000
        end
    else
    	  self.nowMP = self.nowMP - MP
    end	

    if self.nowMP < 0 then
        self.nowMP = 0
    end	

    local prent = math.floor(self.nowMP*100/self.totalMP)

    local  totalH = 170

    local  nowH = totalH * prent/100

    self.spark:setContentSize(cc.size(200,nowH)) --设置遮罩大小
    self.nzSkText:setString(prent)

    if prent >= 100 then
        self.isReady = true
        local action = cc.CSLoader:createTimeline(self.BATTLE_UI_PS)
        local acNode =self.panel_MP:getChildByTag(408)
        acNode:setZOrder(30)
        acNode:stopAllActions()
        acNode:runAction(action)
        action:play("com", true)

        local  nvSK_act = cc.CSLoader:createTimeline(self.BATTLE_UI_PS_UP)
        local  nvSK_Node = self.panel_MP:getChildByTag(422)
        self.spark = nvSK_Node:getChildByTag(1097)
        self.spark:setContentSize(cc.size(200,140))
        nvSK_Node:stopAllActions()
        nvSK_Node:runAction(nvSK_act)
        nvSK_act:play("com", true)
        self.btn:setTouchEnabled(true)

        --新手教学
        if not self.finishTeach and BattleDataManager.battleId == "a1_2_1" then
            self.finishTeach = true
            local loginName = cc.UserDefault:getInstance():getStringForKey("login_name")
            cc.UserDefault:getInstance():setBoolForKey(loginName.."a1_2_1",true)
            BattleUIManager:showXSYDMode(4)           
        end
    else
        self.btn:setTouchEnabled(false)
    end	
end

--复活的时候调用
function BattlePrincessManager:onRevive()
    if not self.isReady then
        self.nowMP = 1000
        self:setMP(0,true)
    end
end

function BattlePrincessManager:getPrincessPoint()
    return self.nowMP
end
