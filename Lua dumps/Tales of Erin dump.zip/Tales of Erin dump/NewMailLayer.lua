--/*说明
    -- NewMailLayer   改版的邮件 
    -- Panel_list  邮件的列表  利用的分布加载的功能
    -- 右下角的十个icon 是限时邮件的内容
--*/

--/*  函数
    -- init            初始化函数
    -- refreshTale     是将数据传入封装的分布加载列表
    -- ShowMailMember  显示邮件里边的元素   就是调用封装好的分布加载列表  和设置一些参数 写法基本固定
    -- senDataList     链接服务器  从服务器获取邮件列表数据
    -- NodeCallBack    这个是在node里边的回调  将选中高亮的邮件数据传送回来
    -- CallSetCurMail  获取到当前文件的数据  根据数据对右板块就行设置
    -- setMailEle      传入邮件里面的元素进行显示最多十个
    ----- 这是一组获取单个邮件的功能函数
    -- getMailOnly     链接服务器获取单个邮件
    -- DeleOnlyItem     获取邮件手动删除  删除单一的文件
    -- MessageOnly     获取单个邮件的弹窗
    ------ 这是删除多个文件的一组功能函数
    -- DeleAllItem     删除多个邮件   
    -- AllCalllBack    链接服务器获取多个邮件
    -- 
--*/

--/* 变量
    -- mail_list         保存从服务器获取的邮件列表数据
    -- MialTable         一些想出入node的数据放到这个列表里面传入过去
    -- cur_select_mailD  保存当前选中的邮件的数据
    -- cur_sele_index    保存当前选择的邮件的下标
    -- tempNode          保存NewMailNode 的变量
--*/

NewMailLayer = class("NewMailLayer",BasicLayer)
NewMailLayer.__index = NewMailLayer
NewMailLayer.lClass = 2 
NewMailLayer.mail_list  = nil
NewMailLayer.cur_select_mailD = nil
function NewMailLayer:init()
    local node =cc.CSLoader:createNode("NewMailLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true
    -- 手动初始将描述内容清空 ，防止界面显示时候会闪现编辑器测试的文本
    local right_panel  = node:getChildByName("Image_right")
    local Content      = right_panel:getChildByName("Text_Time_0")
    Content:setString("");
    -- 手动将显示的图片隐藏 ，防止界面显示显现测试的邮件icon 图片
    local Panel_ele  = node:getChildByName("Panel_mailNeirong")
    for i= 1 , 10 do
        local image_bg  = Panel_ele:getChildByName("Image_icon_bg_"..i) 
        image_bg:setVisible(false)
    end
    self:ininListView()
    self:senDataList();
    self:initBtn()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:CallClose()
    end)

-- --   
end
function NewMailLayer:initBtn( ... )
    -- body
    local node        = self.uiLayer:getChildByTag(2);
    local btn_getOnly = node:getChildByName("Button_get")
    local btn_all     = node:getChildByName("Button_all")
    local btn_mat     = node:getChildByName("Button_mat")
    local btn_close   = node:getChildByName("Button_close")
    local function touchCallBack(sender,eventType)
        local name = sender:getName()
        if eventType == ccui.TouchEventType.ended then
            if name == "Button_get" then
              self:getMailOnly()  
            elseif name == "Button_all" then
                self:AllCalllBack(1)
            elseif name == "Button_mat" then
                self:AllCalllBack(2)
            elseif name == "Button_close" then
                self:CallClose()
            end
        end
    end
    btn_getOnly:addTouchEventListener(touchCallBack)
    btn_all:addTouchEventListener(touchCallBack)
    btn_mat:addTouchEventListener(touchCallBack)
    btn_close:addTouchEventListener(touchCallBack)
    btn_close:setEffectType(3)
end
-- 没有邮件的时候调用次函数
function NewMailLayer:NotMail( ... )
    -- body
    local node        = self.uiLayer:getChildByTag(2);
    local right       = node:getChildByName("Image_right")
    right:getChildByName("Text_name"):setVisible(false)
    right:getChildByName("Text_Timename"):setVisible(false)
    right:getChildByName("Text_Time"):setVisible(false)
    right:getChildByName("Text_Time_0"):setVisible(false)
    --right:setVisible(false)
    local panel       = node:getChildByName("Panel_mailNeirong")
    panel:setVisible(false)
    local text_msg    = node:getChildByName("Text_msg")
    text_msg:setVisible(true)
   -- local node        = self.uiLayer:getChildByTag(2);
    local btn_getOnly = node:getChildByName("Button_get")
    local btn_all     = node:getChildByName("Button_all")
    local btn_mat     = node:getChildByName("Button_mat")
   btn_getOnly:setTouchEnabled(false)
    btn_getOnly:setBright(false)
   btn_all:setTouchEnabled(false)
    btn_all:setBright(false)
    btn_mat:setTouchEnabled(false)
    btn_mat:setBright(false)
end
--将数据传送到Node
function NewMailLayer:refreshTale()

    self.gridview:setDataSource(self.mail_list["Mail"])
end
-- /*初始化listView*/
function NewMailLayer:ininListView( ... )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    self.panelList = node:getChildByName("Panel_list")
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,482,120)
    self.gridview.itemCreateEvent = function()
        local temp = NewMailNode.new():init()
        -- self.GuildMemberTable["GuildMemberIndex"] = self.GuildMemberIndex;
        self.MialTable = {}
         self.MialTable["OnSelf"] = self;
        --}
        -- self.GuildMemberTable["GuildType"] = self.rData["rcvData"]["GuildType"];
        --temp:setSelectIndex();
        temp:setData(self.MialTable);
        self.tempNode = temp;
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    --print("curId == "..temp.curId)
                    --self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                    print("rrrrrrrrrrrrrrrrrrr");
                end
            end
        end 
        return temp
    end
end
--/*显示邮件列表里边元素*/
function NewMailLayer:ShowMailMember( ... )


    self:refreshTale()
    self:reNum(self.mail_list["mail_now"],self.mail_list["mail_max"])
end
-- 此函数现在是测试使用的
function NewMailLayer:senDataList( ... )
    -- body
    local function reiceSthCallBack(data)
        print("收到邮件")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager == nil then
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常"), self, self.CallClose)
        end
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
           MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.CallClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
             MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.CallClose)
            return
        end
        self.mail_list = {}
        self.mail_list["Mail"]     = t_data["data"]["mail_list"]
        self.mail_list["mail_now"] = t_data["data"]["mail_now"]
        self.mail_list["mail_max"] = t_data["data"]["mail_max"]
        print("Mail_YInfo mail_now == "..self.mail_list["mail_now"])
        print("Mail_YInfo mail_max == "..self.mail_list["mail_max"])
        if self.mail_list["mail_now"] == 0 then
            self:NotMail()
        end
        self:ShowMailMember()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()


    local tempTable = {
        ["rpc"] = "mail_list",
        -- ["mail_type"] = 1,
        -- ["item_rarity"] = 0,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 邮件 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--  node 调用此函数  将选中高亮的数据传回来
function NewMailLayer:NodeCallBack( data ,index)
    -- body
    self.cur_sele_index = index;
    self.cur_select_mailD = data
    self:CallSetCurMail()
    self:setMailEle(data)
end
--  设置显示当前邮件的一些属性  
function NewMailLayer:CallSetCurMail( ... )
    -- body
    local dtable = {
            ["mail_id"]      = self.cur_select_mailD["mail_id"],               
            ["alive_time"]   = self.cur_select_mailD["alive_time"],     --邮件过期时间         
            ["item_rarity"]  = self.cur_select_mailD["item_rarity"],               
            ["item_id"]      = self.cur_select_mailD["item_id"],              
            ["num"]          = self.cur_select_mailD["num"],
            ["mail_type"]    = self.cur_select_mailD["alive_time"] ,
            ["msg_content"]  = self.cur_select_mailD["msg_content"], 
            ["msg_title"]    = self.cur_select_mailD["msg_title"], 

    }
    local node         = self.uiLayer:getChildByTag(2);
    local right_panel  = node:getChildByName("Image_right")
    local textName     = right_panel:getChildByName("Text_name")
    textName:setString(UITool.getUserLanguage(dtable["msg_title"]))
    local TimeName     = right_panel:getChildByName("Text_Timename")
    local Time         = right_panel:getChildByName("Text_Time")
    if g_channel_control.newMailTimeNameAnchorPoint == true then
        TimeName:setAnchorPoint(cc.p(1,0.5)) --us修改锚点
        TimeName:setPosition(cc.p(341,558))
    end
    if dtable["mail_type"] == -1 then
        TimeName:setString(UITool.ToLocalization("永久"))
        Time:setVisible(false)
    else
        Time:setVisible(true)
         TimeName:setString(UITool.ToLocalization("限时"))
         local now  =UserDataMgr:getInstance().timeData:getCurrentTime()-- os.time()
         local dist = dtable.alive_time - now 
         local tableTime = UITool.ShowTime(dist)
         --local  time          = panelP:getChildByName("Text_tiam")
        if g_channel_control.newMailTimeFormat == true then
            Time:setString(string.format("%d%s %02d:%02d:00",tableTime["D"],UITool.ToLocalization("天"),tableTime["H"],tableTime["M"]))   --us缩短内容     
        else
            Time:setString(tableTime["D"]..UITool.ToLocalization("天")..tableTime["H"]..UITool.ToLocalization("时")..tableTime["M"]..UITool.ToLocalization("分"))
        end
    end
    local Content      = right_panel:getChildByName("Text_Time_0")
    Content:setString("     "..dtable["msg_content"])
    if g_channel_control.transform_NewMailLayer_String_Del_Trim == true then
        Content:setString(dtable["msg_content"])
    end
end
-- 测试数据  显示一个邮件里面的内容
function NewMailLayer:setMailEle( _tData )
    -- body
    local node       = self.uiLayer:getChildByTag(2);
    local Panel_ele  = node:getChildByName("Panel_mailNeirong")
    for i = 1 , 10 do
        if i <= #_tData["item_list"]  then
            print("item_list len == "..#_tData["item_list"])
            --数据错乱引起的表错误
            local DataType  = type(#_tData["item_list"])
            if DataType ~= "number" then
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常"), self, self.CallClose)
            else
                print("正确的数据 应该是一个 number")
            end
            local ItemType = _tData["item_list"][i][2] 
            local e_id = tonumber(_tData["item_list"][i][1])
            print("Mail table.item_id == ".._tData["item_list"][1][1])
            local popr = nil
            if ItemType == 1 then
                name     = UITool.ToLocalization("金币")
                 popr = UITool.getItemInfos(1,1)
            elseif ItemType == 2 then
                name     = UITool.ToLocalization("宝石")
                popr = UITool.getItemInfos(2,1)
            else
                popr = UITool.getItemInfos(ItemType,e_id)
            end

            local image_bg  = Panel_ele:getChildByName("Image_icon_bg_"..i) 
            image_bg:setVisible(true)
            local icon      = image_bg:getChildByName("Image_icon")  -- 图标
            local imageForm = image_bg:getChildByName("Image_icon_form") -- 框
            local imageE    = image_bg:getChildByName("Image_12") -- 属性图标
            local num       = image_bg:getChildByName("Text_1")--  数量
            num:setString(_tData["item_list"][i][3])
            local function touchCallBack(sender,eventType)
            local name = sender:getName()
                if eventType == ccui.TouchEventType.ended then
                    if ItemType == 16 then -- 称号
                        MsgManager:showBaseSpine(e_id)
                    else
                     MsgManager:showSimpItemInfo(ItemType,e_id)
                    end
     
                end
            end
            image_bg:addTouchEventListener(touchCallBack)

            --print("icon == "..popr[2])
            icon:setUnifySizeEnabled(true)
            if popr then
                icon:loadTexture(popr[2])
                -- 背景
                image_bg:loadTexture(popr[4])
                -- 图框
                imageForm:loadTexture(popr[1])
                -- 是否显示属性球
                if popr[3] == "" then
                    imageE:setVisible(false)
                else
                    imageE:setVisible(true)
                    imageE:loadTexture(popr[3])
                end
            end
        else
             local image_bg  = Panel_ele:getChildByName("Image_icon_bg_"..i) 
             image_bg:setVisible(false)
        end
    end

    
end
--获取单个邮件
function NewMailLayer:getMailOnly( ... )
    -- body
    if  self.cur_select_mailD  == nil then
        return
    end
    if self.cur_select_mailD["mail_id"] == nil then
        return
    end
    
    local function reiceSthCallBack(data)
        print("获取g单个 邮件")
        -- print("000"..self.cur_select_mailD["item_id"])
        --  print(self.cur_select_mailD["index"])
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.CallClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
          
            return
        end

        ---if t_data["data"]["warning"] == "装备数量已达上限！
        --print("t_data len == "..#t_data["data"]["get"])
        if t_data["data"]["state_code"]  == 1 then

            if not g_channel_control.b_newEqBag then
                local TableLen = #t_data["data"]["get"]
                local Type   = nil
                local Itemid = nil
                local Itemnum = nil
                local real_id = nil
                local len = #t_data["data"]["get"]
                if len <= 1 then
                    Type = t_data["data"]["get"][1]["item_type"]
                    Itemid   = t_data["data"]["get"][1]["id"]
                    Itemnum  = t_data["data"]["get"][1]["num"]
                    real_id  = t_data["data"]["get"][1]["real_id"]
                    self:MessageOnly(Itemid,Itemnum,Type,real_id)
                else
                    local sData = {}
                    sData["AllData"] = t_data["data"]["get"]
                    -- print("gggggggggg == "..#t_data["data"]["get"])
                    if self.sManager ~= nil then
                        self.sManager:toMailGetAllLayer(sData)
                    end      
                end
                -- for i = 1, #t_data["data"]["get"] do 
                --     Type = t_data["data"]["get"][i]["item_type"]
                --     Itemid   = t_data["data"]["get"][i]["id"]
                --     Itemnum  = t_data["data"]["get"][i]["num"]
                --     real_id  = t_data["data"]["get"][i]["real_id"]
                --     self:MessageOnly(Itemid,Itemnum,Type,real_id)
                -- end


                self:refrshCoin()
       
                self:DeleOnlyItem(self.cur_sele_index)
                return
            end
            if t_data["data"]["eq_bag_full"] then
                if t_data["data"]["eq_bag_full"] == 1 then
                    local eq_max = 0
                    if t_data["data"]["eq_max"] then
                        eq_max = t_data["data"]["eq_max"]
                    end
                    local callFuncBagAdd = function()
                        local addSucessFunc = function()
                            self:addLabel(UITool.ToLocalization("灵装背包扩容成功"))
                        end
                        self.bagAddView = BagAddView.new():init(eq_max,addSucessFunc,self)
                        self.uiLayer:addChild(self.bagAddView:getRootNode(),0,3)
                    end
                    local strDec = UITool.ToLocalization("灵装背包已满，无法领取灵装。是否进行扩充？")
                    MsgManager:showSimpMsgCanOver(strDec,nil,function()
                        if GameManagerInst.gameType == 2 then
                            callFuncBagAdd()
                        end
                    end)

                elseif t_data["data"]["eq_bag_full"] == 2 then
                    GameManagerInst:alert(UITool.ToLocalization("您的灵装数量已到达上限，请清理后领取。"))
                else--背包无异常
                end
            end

            local TableLen = #t_data["data"]["get"]

            if TableLen > 0 then
                local Type   = nil
                local Itemid = nil
                local Itemnum = nil
                local real_id = nil
                local len = #t_data["data"]["get"]
                if len <= 1 then
                    Type = t_data["data"]["get"][1]["item_type"]
                    Itemid   = t_data["data"]["get"][1]["id"]
                    Itemnum  = t_data["data"]["get"][1]["num"]
                    real_id  = t_data["data"]["get"][1]["real_id"]
                    self:MessageOnly(Itemid,Itemnum,Type,real_id)
                else
                    local sData = {}
                    sData["AllData"] = t_data["data"]["get"]
                    -- print("gggggggggg == "..#t_data["data"]["get"])
                    if self.sManager ~= nil then
                        self.sManager:toMailGetAllLayer(sData)
                    end      
                end
                -- for i = 1, #t_data["data"]["get"] do 
                --     Type = t_data["data"]["get"][i]["item_type"]
                --     Itemid   = t_data["data"]["get"][i]["id"]
                --     Itemnum  = t_data["data"]["get"][i]["num"]
                --     real_id  = t_data["data"]["get"][i]["real_id"]
                --     self:MessageOnly(Itemid,Itemnum,Type,real_id)
                -- end


                self:refrshCoin()
       
                self:DeleOnlyItem(self.cur_sele_index)
            end

        else
            --ShowMessage(t_data["data"]["warning"],nil,"null")
            local popData = {}
            popData["oneself"]       = self
            popData["showButType"]   = 1
            popData["showModelType"] = 1
            popData["texDec"]        = UITool.getUserLanguage(t_data["data"]["warning"])
            --popData["baseType"]    = 2
            --popData["callFunc"]    = self.ToGuild
            if self.sManager ~= nil then
                self.sManager.msgMgr:showMsgMode(popData)
            end
        end

    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local MialId = self.cur_select_mailD["mail_id"]

    local tempTable = {
        ["rpc"]       = "mail_get",
        ["mail_id"]   = MialId,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 邮件 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 删除单个邮件
function NewMailLayer:DeleOnlyItem( index )
    -- body 
    print("是否执行了这")
            print("inde index == "..index)
            local tempList    = {}
            table.remove(self.mail_list["Mail"], index)
            local  index = 1
            for k,v in pairs(self.mail_list["Mail"]) do 
                if v then
                    tempList[index] = v
                    index = index + 1
                end
            end
            self.mail_list["Mail"] = table.deepcopy(tempList)

            tempList = {}

            self.mail_list["mail_now"] = self.mail_list["mail_now"] - 1
            self.tempNode:setSelectIndex()
            self:ShowMailMember()
            --self:ShowMailNum(self.Mail_YList["mail_now"],self.Mail_YList["mail_max"])
            if self.mail_list["mail_now"] == 0 then
                self:NotMail();
            end

end
-- 获取单个邮件的弹窗
function NewMailLayer:MessageOnly( id ,num , ItemType,real_id)
    if ItemType == 3 and real_id ~= nil then 
        GameManagerInst:rpc( 
            {
                rpc = "eq_info",
                eq_id = real_id
            },
            3,
            function(data)
                --success
                local equipInfos = {}
                equipInfos.rsk = data["eq"][real_id].rsk
                MsgManager:showSimpItemInfo(ItemType,id,num,UITool.ToLocalization("收取成功"),equipInfos)
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText)
            end,
        true)
    else 
        MsgManager:showSimpItemInfo(ItemType,id,num,UITool.ToLocalization("收取成功"))
    end 

end-- 刷新货币
function NewMailLayer:refrshCoin( ... )
    -- body
    local function reiceSthCallBack(data)
        print("获取登陆奖励数量")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.CallClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
             
            return
        end
        user_info["gold"]  = t_data["data"].gold
        user_info["gem"]   = t_data["data"].gem
        user_info["gem_r"]   = t_data["data"].gem_r
        user_info["beryl"] = t_data["data"].beryl
        user_info["faith"] = t_data["data"].faith
        if  t_data["data"].ap then 
            user_info["ap"] =  t_data["data"].ap
        end
        if self.sManager ~= nil and self.sManager.menuLayer ~= nil then
            self.sManager.menuLayer:RefshTopBar()
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "refresh_user_coin",
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 1获取全部邮件 2星之乱除外的所有邮件
function NewMailLayer:AllCalllBack( type )            
    -- body   临时注释 服务器接口改好 解开调用
    local function reiceSthCallBack(data)
        print("获取全部邮件")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.CallClose)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
           
            return
        end

        if t_data["data"]["state_code"]  == 1 then

            if g_channel_control.b_newEqBag then
                if t_data["data"]["eq_bag_full"] then
                    if t_data["data"]["eq_bag_full"] == 1 then
                        local eq_max = 0
                        if t_data["data"]["eq_max"] then
                            eq_max = t_data["data"]["eq_max"]
                        end
                        local callFuncBagAdd = function()
                            local addSucessFunc = function()
                                self:addLabel(UITool.ToLocalization("灵装背包扩容成功"))
                            end
                            self.bagAddView = BagAddView.new():init(eq_max,addSucessFunc,self)
                            self.uiLayer:addChild(self.bagAddView:getRootNode(),0,3)
                        end
                        local strDec = UITool.ToLocalization("灵装背包已满，无法领取灵装。是否进行扩充？")
                        MsgManager:showSimpMsgCanOver(strDec,nil,function()
                            if GameManagerInst.gameType == 2 then
                                callFuncBagAdd()
                            end
                        end)

                    elseif t_data["data"]["eq_bag_full"] == 2 then
                        GameManagerInst:alert(UITool.ToLocalization("您的灵装数量已到达上限，请清理后领取。"))
                    else--背包无异常
                    end
                end
                local nGetNum = #t_data["data"]["get"]
                if nGetNum > 0 then
                    self:refrshCoin()
                    local tes = t_data["data"]["delete_mail_id_list"]
                    self:DeleAllItem(tes)
            
                    print("测试 邮件 gold   = "..t_data["data"]["gold"])
                    print("测试 邮件 gem    = "..t_data["data"]["gem"])
                    print("测试 邮件 eq     = "..t_data["data"]["eq"])
                    print("测试 邮件 others = "..t_data["data"]["others"])
                    local sData = {}
                    sData["AllData"] = t_data["data"]["get"]
                    -- print("gggggggggg == "..#t_data["data"]["get"])
                    if self.sManager ~= nil then
                        self.sManager:toMailGetAllLayer(sData)
                    end
                end
            else
                self:refrshCoin()
                local tes = t_data["data"]["delete_mail_id_list"]
                self:DeleAllItem(tes)
        
                print("测试 邮件 gold   = "..t_data["data"]["gold"])
                print("测试 邮件 gem    = "..t_data["data"]["gem"])
                print("测试 邮件 eq     = "..t_data["data"]["eq"])
                print("测试 邮件 others = "..t_data["data"]["others"])
                local sData = {}
                sData["AllData"] = t_data["data"]["get"]
               -- print("gggggggggg == "..#t_data["data"]["get"])
               if self.sManager ~= nil then
                    self.sManager:toMailGetAllLayer(sData)
               end
            end

        else
      
            local popData = {}
            popData["oneself"]     = self
            popData["showButType"] = 1
            popData["showModelType"] = 1
            popData["texDec"]      = UITool.getUserLanguage(t_data["data"]["warning"])
            if self.sManager ~= nil then
                self.sManager.msgMgr:showMsgMode(popData)
            end
        end
    
    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "mail_get_all",
        ["get_type"]   = type,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试 邮件 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 删除多个邮件
--获取邮件从列表中删除
function NewMailLayer:DeleAllItem( id_list )
    -- body
    if self.mail_list == nil then
        return
    end
    local tempList    = {}

    for i = 1,#id_list do
        local  id = id_list[i]
        table.removeif(self.mail_list["Mail"],function(mail)
            return mail["mail_id"] == id
        end)
    end

    local  index = 1
    for k,v in pairs(self.mail_list["Mail"]) do 
        if v then
            tempList[index] = v
            index = index + 1
        end
    end
    self.mail_list["Mail"] = table.deepcopy(tempList)
    tempList = {}
    self.mail_list["mail_now"] = #self.mail_list["Mail"]
    self:ShowMailMember() 
    if self.mail_list["mail_now"] == 0 then
        self:NotMail();
    end
    
end
function NewMailLayer:reNum(cur,max )
    -- body
    local node = self.uiLayer:getChildByTag(2);
    local num  = node:getChildByName("Text_num")
    num:setString(cur.."/"..max)

end
function NewMailLayer:CallClose(  )
    -- body
    self.exist = false
    self.sData = {}
    self.rData = {}
    if self.tempNode then
        self.tempNode:Close()
        self.tempNode = nil;
    end

    self:clearEx()
    SceneManager.isAct = true
    SceneManager.isTabBar = true
    SceneManager:toStartLayer()

    -- self.sManager:removeFromNavNodes(self)
    -- self.sData = {}
    -- self.backFunc(self.sManager,self.sData)
    -- self.exist = false
    -- self.sData = {}
    -- self.rData = {}
    -- self.tag = nil 

    -- self:clear()
end
-- /*提示信息*/
function NewMailLayer:addLabel(str)
  
    local label = cc.Label:createWithTTF(str, TEXT_FONT_NAME, 40)
    label:setPosition(cc.p(640,360))
    self.uiLayer:addChild(label)
    local function removeThis()
       label:removeFromParent()
    end
    --After 1.5 second, self will be removed.
    local moveBy  = cc.MoveBy:create(1.5,cc.p(0,150))
    local fadeOut = cc.FadeOut:create(1.5)
    local spawn = cc.Spawn:create(moveBy,fadeOut)
    label:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(removeThis)))

end

function NewMailLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function NewMailLayer:create(rData)

     local login = NewMailLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login
     
end
