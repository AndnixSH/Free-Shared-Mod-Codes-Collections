-- 不同渠道 如果有需要区别开通的代码，放到这里
-- 命名：文件名+关键字 
--transform 坐标转换 锚点修改，对齐方式修改，
--order 语序修改   
-- 默认false

g_channel_control = {}


--**************************************************************************************
--****************************     功   能   开   关      ********************************
--**************************************************************************************


g_channel_control.channelName = "us"
g_channel_control.mulPassLayer_boss_guang = true 	-- 大型战斗 光Boss 控制开启   true 开启
g_channel_control.chatLayer = true 					-- 世界聊天   true 开启
g_channel_control.openKeyBack = true 					-- 开启返回键 true 开启
g_channel_control.noticeUrl = "http://clcdn.playtai.com/cl/notice/cn/home.html"						--公告地址
g_channel_control.battleEnd_hidePsBg = false 			-- 战斗结束，隐藏神格背景（韩国）
g_channel_control.battleEnd_hideRoleName = false 		-- 战斗结束，隐藏角色名（韩国）
g_channel_control.roleInfoView_hideEquipSoulView = false    -- 角色详情，是否隐藏灵魂装 
g_channel_control.roleInfoView_hideExclusiveStory = false --角色详情，是否隐藏专属剧情
g_channel_control.ecastLayer_hideReforge = false 		--铸造界面，隐藏轮回重铸
g_channel_control.ecastLayer_hideExchange = false       --铸造界面，隐藏兑换
g_channel_control.bagLayer_hideReforge  = false 			--背包界面，隐藏轮回重铸
g_channel_control.bagLayer_hideExchange  = false 		--背包界面，隐藏兑换
g_channel_control.reforgeView_hideExchange  = false 		--轮回重铸界面，隐藏兑换
g_channel_control.openPVPPage  = false 					--是否开启pvp页面
g_channel_control.openQueryItem  = false 				--是否在进入游戏startLayer的时候检测是否购买了商品
g_channel_control.openUpdateRoleInfo  = true 			--战斗结束更新玩家信息
g_channel_control.gachaview_dailyDealBtn = false 		--抽卡界面，调整每日优惠文字
-- g_channel_control.serverName = "Tales of Erin"				--服务器名称
g_channel_control.checkWarnWord = true 				    --是否检查敏感词
g_channel_control.defend_pm = 4000                      --防御减少伤害
g_channel_control.chatTeamUsed = true                   --聊天公会使用群组
g_channel_control.chatShowReport = true                 --聊天显示举报按钮
g_channel_control.chatVoiceOpen = false                  --聊天开启语音功能
g_channel_control.chatRecentEabled   = true             --聊天最近回话
g_channel_control.chatHistoryEabled = true              --聊天开启历史记录
g_channel_control.gachaView_hideShopHero = false         --抽卡界面隐藏英雄圆桌
g_channel_control.gachaView_hideDragonCoin = false       --抽卡界面隐藏王召之徽功能 					--是否检查敏感词
g_channel_control.serverID = "1"						--服务器名称
g_channel_control.openStoreView = false					--是否开启评分功能（default false）
g_channel_control.serviceCenterName = "客服中心"          --用户中心或客服中心名称定义default 客服中心）
g_channel_control.b_drop_cangyu = true                 --是否掉落苍玉  目前国服不掉 台服要掉 日服要掉
g_channel_control.b_random_name = true                 --是否开启随机名字系统  日服关闭 (default true)
g_channel_control.b_show_cdkey_btn = true              --是否开启兑换码   (default true) --审核期关闭
g_channel_control.use_NewMulPassLayer = true 		 -- 是否使用新版多人站（求援加入分签、快速加入功能）
g_channel_control.useRankConfig = true             -- 排行榜页签是否使用配置  false 使用之前的写死  true  使用配置
g_channel_control.use_Act_2_NewVersion = true 		-- 是否使用外传活动1，新加boss点
g_channel_control.closeGameWithNetError = false 			-- 网络出错一段时间之后关闭游戏（默认true）

g_channel_control.ultimateCha_adjustUI = false           --极限挑战UI调整（韩服语序导致调整UI 默认 false）
g_channel_control.loginLayer_showNewBtn = true          --欧美服新增两个按钮(需要更新touch_login.csb)
g_channel_control.shopLayer_monthCardTime = 3*24*60*60   --商店月卡倒计时3天内允许续费(季卡，终身卡) 默认nil
g_channel_control.b_facebook = true 					-- 是否开启 facebook 点赞和评分功能
g_channel_control.b_newEqBag = true                     -- 灵装背包扩容分签功能 控制开启(开启需要服务器端配合开启：主要API结构变化 equip_list)

g_channel_control.b_actAcheMultiTab = true          --活动成就是否使用分签（默认false）
g_channel_control.b_refreshBattlePass = false          --废神活动关卡是否不切换界面刷新（默认false）
g_channel_control.b_allianceBattleMainView = true                     --使用新版公会战，新增 剩余充能次数3次
g_channel_control.useBgMusicOnIAByLogin = false          --登陆界面是否使用IA主题曲（默认false）
g_channel_control.b_voice_download = false 					-- 是否隐藏语音下载按钮（默认false不隐藏）

g_channel_control.battleLua = true
g_channel_control.b_newRole = true                     -- 是否开启新的角色界面功能（default false）
g_channel_control.b_Astrolabe = true                       --星盘开关
g_channel_control.quickMacroabled = false                    --开启按键精灵检测
g_channel_control.b_LikeState = true                     -- 是否开启好感度功能（default false）
g_channel_control.bDropBoxNew = true                    --是否开启新版掉落宝箱（默认false）
g_channel_control.smapAstrolabeLevel = true                    --区域地图 星盘关卡是否开启

g_channel_control.showGameNoticeLayer = false                --是否显示公告
g_channel_control.b_CangYi = false  					-------苍翼联动开关（默认false）
g_channel_control.b_CangYi_Act3 = false 				--废神使用苍翼资源
g_channel_control.b_SuQing = false 					-------苏晴开关（默认false）与 苍翼联动不能同时为true
g_channel_control.b_ZhouNianHD = false              -------周年活动开关 苏晴开关（默认false）与 苍翼联动不能同时为true
g_channel_control.b_XNYZ = false  					------新年外传开关（默认false）
g_channel_control.Act3BossType = 3                  --开放废神BossIndex
g_channel_control.b_allianceBattle_version2 = true                     --使用新版公会战，新增 剩余充能次数3次
g_channel_control.b_allianceBattle_version3 = true                    --是否是新版包含事件点的公会战，2018年10月版本。
g_channel_control.startLayer_hideEvent = false              --主界面隐藏活动
g_channel_control.eventGachaTrack = true                    --efun新打点，十连抽
g_channel_control.eventChapterNew = true                     --efun新增关卡打点，3-4-3
g_channel_control.UIVersion = 2                    --UI version （1，为第一次开发，2，为第二次开发
g_channel_control.mailVersion = 2                    --mail version （1，为第一次开发，2，为第二次开发）(默认第一次开发)



g_channel_control.b_XbPlayerInfoView = true                  --是否开启新版玩家个人界面

g_channel_control.open_NewHeroBookLayer = true               --开启新 角色图鉴（此功能关闭了所有的角色自选功能）

g_channel_control.b_XbWorkShopView = true                    --是否开启新版工坊界面(默认false)

g_channel_control.open_StoryAct    = true                    --是否开启剧情活动

g_channel_control.chatVersion = 2                    --chat version （1，为第一次开发，2，为第二次开发）(默认第一次开发)
g_channel_control.obtainItemsVersion = 2                    --obtainItems version （1，为第一次开发，2，为第二次开发）(默认第一次开发)
                   
g_channel_control.openUnlock = true                    --是否开启解锁系统（默认关闭， 需要是否UIVersion >= 2）

g_channel_control.chatUseTranslate = true  				--是否开启翻译功能
g_channel_control.bFeiShenRank = true               --是否开启废神排行榜（默认false）
g_channel_control.sysObtainItemShowStyle = true   --聊天系统获得物品文本描述样式
g_channel_control.bNewShop = true   --新版商店
g_channel_control.bNewGiftInfo = true   --新版礼包信息

g_channel_control.loginShop = true --付费登陆开关,2018.12.21.

g_channel_control.show_new_guild_main = false --公会新加功能

g_channel_control.unShow_gachaView_probability = true --是否不显示抽卡概率

g_channel_control.unShowUnlockTipIndex58 = false --剧情活动不开启，同时不弹出提示

g_channel_control.playerInfo_customName = "礼品码兑换"          --客服中心 改名  （欧美服 礼品码兑换）

g_channel_control.currency_type = "美元" --货币类型   默认日元

g_channel_control.transform_language = true --是否使用新的多语言转换表

g_channel_control.b_XbAct2SpecList = false --是否使用新版外传线路特殊关卡多人战结构修改

g_channel_control.b_NewGuildGift = true --是否开启新手礼包功能

--**************************************************************************************
--****************************     ui   调   整   开    关      **************************
--**************************************************************************************



g_channel_control.newMailTimeNameAnchorPoint=true       --是否修改邮件 限时/永久 锚点  transform
g_channel_control.newMailTimeFormat=true                --是否修改邮件时间显示方式     order
g_channel_control.dialogLayerNameAnchor = true         --DialogLayer修改名字锚点      transform
g_channel_control.GuildBaseInfoLayerChairmen = true    --GuildBaseInfoLayer调整公会会长名字  transform
g_channel_control.inputMaxLength = false                --输入框重置输入上限, （true 不确定中文是否作为两个字节处理）
g_channel_control.newNameRandom = true                 --随机名使用nameA+随机数
g_channel_control.PlayerCardLayerUseName = true        --玩家详情是否调整玩家名字位置（右移） transform
g_channel_control.RecommendGuildLayer_chairman = true --公会会长名字右移 transform
g_channel_control.RoleInfoPropView_txtLockAnchor =true --RoleInfoPropView 能力解锁文字右移 transform

g_channel_control.transform_RanklistLayer_Text_rankName_title_anchor = false --RanklistLayer 排名位置 右移动（默认 false）
g_channel_control.transform_RanklistLayer_Text_rank_pos = false --RanklistLayer 排名位置 右移动（默认 false）
g_channel_control.transform_RanklistNode_Text_rank_pos = false --RanklistNode 排名位置 右移动（默认 false）
g_channel_control.transform_SignInLayer_Text_day_pos = false --SignInLayer 已签到 天数 右移动（默认 false）
g_channel_control.transform_NewGuildMainLayer_Text_banniang_tip_contentSize = false --NewGuildMainLayer 右板娘提示文本大小（默认 false）
g_channel_control.transform_GiftShowListLayer_Text_dec_fontSize = false --GiftShowListLayer 礼包描述大小（默认 false）
g_channel_control.transform_ShopLayer_Text_dec_fontSize = false --ShopLayer 商品描述大小（默认 false）
g_channel_control.transform_RecommendGuildLayer_GuildRank_pos = false --RecommendGuildLayer 工会排行 位置（默认 false）
g_channel_control.transform_RoleInfoView_skillDesc_contentSize = false --RoleInfoView 角色技能描述content size 位置（默认 false）
g_channel_control.transform_RoleInfoView_roleName_fontSize = false --RoleInfoView 角色名字字号大小（默认 false）
g_channel_control.transform_AllianceBattle_RankPublicLayer_Text_rank_pos = false --AllianceBattle_RankPublicLayer 角色排行榜文本位置右移（默认 false）

g_channel_control.transform_AchievementNode_text_bonus_pos = false --AchievementNode 奖励文本位置左移（默认 false）
g_channel_control.transform_RoleInfoView_racename_align = false --RoleInfoView 种族文本居中对齐（默认 false）
g_channel_control.order_RoleInfoAddSPView_enhangce_skill_msg = false --RoleInfoAddSPView 消耗物品语序（默认 false）
g_channel_control.order_RoleInfoAddSPView_msg = false --RoleInfoAddSPView 消耗物品语序（默认 false）
g_channel_control.order_RoleInfoPropView_enhangce_prop_msg = true  --RoleInfoPropView 提升角色属性（默认 false）
g_channel_control.transform_RoleAwakenView_lbTitle_fontSize = false --RoleAwakenView 能力解放标题字体变小（默认 false）
g_channel_control.transform_RoleSthView_lbTitle_fontSize = false --RoleSthView 英雄强化标题字体变小（默认 false）
g_channel_control.transform_ShopLayer_zhekText_fontSize = false --ShopLayer 折扣字体变小（默认 false）
g_channel_control.order_RoleInfoView_summon_msg = false  --RoleInfoView 消耗物品召唤语序（默认 false）


g_channel_control.transform_StartLayer_Text_1_0_1_pos = false  --主界面玩家等级文本位置移动开关(默认false)
g_channel_control.transform_EquipListItemView_Text_3_pos = false  --灵装等级文本居中显示开关(默认false)
g_channel_control.transform_PlayerCardLayer_lab_lv_pos = false  --玩家信息冒险等级(默认false)
g_channel_control.transform_PlayerCardLayer_lab_lv_1_pos = false  --玩家信息探索等级(默认false)
g_channel_control.transform_GalleryView_nameColor_fontSize = false  --灵装名字文本字号(默认false)
g_channel_control.transform_GalleryView_nameGray_fontSize = false  --灵装名字文本字号(默认false)
g_channel_control.transform_EquipInfoView_lbCurMaxLv_pos = false  --装备等级文本位置(默认false)
g_channel_control.transform_NewGuildMainLayer_Text_3_pos = false  --公会成员数量文本左移(默认false)
g_channel_control.transform_GuildPavilionLayer_title_0_0_0_fontSize = false  --排名奖励字号(默认false)
g_channel_control.transform_GuildPavilionLayer_title_0_0_fontSize = false  --层数奖励字号(默认false)
g_channel_control.transform_MsgManager_lab1_fontSize = false  --本次战斗获得文本字号(默认false)
--g_channel_control.transform_Text_bulletin_0_fontSizeAndPos = false  --公会排行榜成员列表按钮文本位置和字号(默认false)
g_channel_control.transform_GuildContributionView_lbLevel_pos = false  --公会捐献界面玩家等级文本位置(默认false)
g_channel_control.transform_MsgManager_char_x = false  --物品数量x10(默认false)
g_channel_control.transform_DialogLayer_nameStr_fontSize = false  --剧情旁白角色名称
g_channel_control.transform_DialogLayer_nameStr_fontSize = false  --剧情旁白角色名称
g_channel_control.transform_RoleInfoView_powername_align = false --RoleInfoView 势力文本居中对齐（默认 false）
g_channel_control.order_GachaConfirmView_tip_msg = false --GachaConfirmView 抽卡确认提示文本语序（默认 false）
g_channel_control.transform_ExploreResultLayer_raceType = false --ExploreResultLayer 种族名字切换为图标（默认 false）
g_channel_control.transform_ShopLayer_Text_number_fontSize = false --ShopLayer 商品 名字赠送 字体缩小（默认 false）
g_channel_control.transform_GachaConfirmView_Text_color = false --GachaConfirmView 文本颜色（默认 false）
g_channel_control.transform_CreateGuildLayer_Text_order = false --CreateGuildLayer 文本顺序（默认 false）
g_channel_control.transform_UITool_Text_order = false --UITool 文本顺序（默认 false）
g_channel_control.transform_NewMailLayer_String_Del_Trim = false --NewMailLayer 邮件内容去掉空格（默认 false）
g_channel_control.transform_GachaView_btnB2Num2_align = false --GachaView   btnB2Num2 对齐方式（默认 false）
g_channel_control.transform_GachaView_btnB3Num2_align = false --GachaView   btnB3Num2 对齐方式（默认 false）
g_channel_control.transform_GuildBaseInfoLayer_Text_cur_pos_align = false --GuildBaseInfoLayer   Text_cur 锚点 位置 对齐方式（默认 false）
g_channel_control.transform_GuildBaseInfoLayer_Text_Max_pos = false --GuildBaseInfoLayer   Text_Max 位置（默认 false）
g_channel_control.transform_AllianceBattle_RankListNode_Text_Max_0_pos = false --AllianceBattle_RankListNode   Text_mem_num 位置（默认 false）
g_channel_control.transform_AllianceBattleGachaView_lbTitle_Text_fontSize = false --AllianceBattleGachaView_lbTitle  字号大小修改(默认false)
g_channel_control.transform_Act_3_MainLayer_reward_times_Text_pos = false --Act_3_MainLayer  reward_times  文本位置修改(默认false)
g_channel_control.transform_AllianceBattleMainView_activateTimes_Text_fontSize = false--公会战剩余充能激活次数字号修改  默认false



g_channel_control.LoadApTiliAnchorPoint=true           --LoadAp 修改体力文字锚点 transform
g_channel_control.GachaConfirmViewAnchorPoint=true     -- 抽卡提示语，“您拥有”修改锚点
g_channel_control.order_PrincessInfoView_unlockStr = true --神格解锁，修改翻译语序
g_channel_control.transform_ExploreResultLayer_raceType = true --星界探索显示种族图标代替名字
g_channel_control.transform_GalleryItemView_name = true --角色/灵装图鉴，修改名字显示方式
g_channel_control.transform_REIconView_font =true       --设置装备名字font=18
g_channel_control.transform_PSkillLayer_font =true       --设置神格短描述 font=18
g_channel_control.transform_gachaView_position=true      -- 抽卡页面，按钮金币价钱位置调整
g_channel_control.transform_SignInLayer_dayPosition=true --是否修签到日期锚点
g_channel_control.RoleInfoView_stateAwkNumPos = true     --角色-状态，觉醒阶段坐标右移
g_channel_control.updateManager_loadText = true          --loading改为加载本地资源中，不消耗流量
g_channel_control.transform_PrincessInfoView_UnlockFont=true --神格未解锁缩小font=22
g_channel_control.transform_MsgBoxNode_SS_font = true    --公会设施升级描述缩小字号20
g_channel_control.transform_ActManageItemNode_Alignment = true --活动右侧标题换行
g_channel_control.transform_BattleEndPs_font=true     -- 战斗结束，解锁加护，锚点左移
g_channel_control.transform_NewGuildMainLayer_font=true --公会设施伴娘提示语字体缩小16
g_channel_control.InputModelLayer_MaxX2 = true          --输入框提示上限X2（英文模式）
g_channel_control.MsgBoxNode_11_anchor = true           --灵装锻造提示框锚点修改
g_channel_control.transform_SoulEquipSkillItemView_skillName = true -- 魂灵装技能 升华1次后解锁 翻译
g_channel_control.transform_PrincessInfoView_skillNameFont = true -- 神格技能缩小字号
g_channel_control.transform_PublicHelpText_fontRate = 1.5  --公会塔帮助，字体大小比例（默认1.0）
g_channel_control.BattleEndLayer_MulRankIcon_pos = true    --多人战结束贡献排行神格头像左移

g_channel_control.NewAtkBarMax = false    --新角色atkbar计算算法开关,主要为峰值变更（默认为false,日服为true）
g_channel_control.transform_NewRoleDataItemView_PropTitle_posAndfontSize = false    --新角色界面属性名位置,字号调整
g_channel_control.transform_NewRoleDataItemView_numProp_fontSize = false    --新角色界面属性值位置调整
g_channel_control.transform_NewRoleDataItemView_numPropAdd_fontSize = false    --新角色界面增加属性值位置调整
g_channel_control.transform_NewRoleSoulView_lbRoleName_pos = true    --新魂灵装界面角色名字位置调整
g_channel_control.transform_NewRoleStateView_spBtnRoleSublText_fontSize = false    --新角色状态界面潜能解放字体大小修改
g_channel_control.transform_NewRoleSkillView_btnSkillResetText_fontSize = false    --新角色技能界面重置字体大小修改
g_channel_control.transform_NewRoleStoryView_storyDetail_autoChangeLine = true    --角色故事背景自动换行
g_channel_control.transform_NewRoleStoryView_storyRaceIcon_hide = false    --角色故事背景 隐藏种族icon
g_channel_control.transform_NewRoleStoryView_storySexIcon_hide = false    --角色故事背景 隐藏性别icon
g_channel_control.transform_NewRoleStoryView_storyArt_pos = false 			--角色故事背景 画师名字位置右移
g_channel_control.transform_SoulEquipSkillItemView_lockedText_pos = false 			--文本位置左移
g_channel_control.transform_SthMatNumView_matName_pos = false 			--文本位置左移
 
g_channel_control.transform_AstrolabeAddSPView_msg_tip_order = false 			--星盘扩张点提示
g_channel_control.transform_lvEx_pos = false                              --星盘强化额外增加属性文本位置修改（默认false）
g_channel_control.transform_BNListItem_bnName_fontSize = true          --文本字号调整
g_channel_control.transform_SysCfgView_lbBanniang_fontSize = true          --看板娘文本字号调整

g_channel_control.transform_AllianceBattle_ShopLayer_ItemTitleFont = true          --公会战商店物品名 font缩小
g_channel_control.transform_AllianceBattle_ShopLayer_awakenAlign = true            --公会商店已觉醒字右对齐
g_channel_control.transform_AllianceBattleGachaView_ItemTitleFont = true           --公会战卡池字号缩小


g_channel_control.transform_Act_3_MainLayer_needBreath_pos = true --Act_3_MainLayer  大型战斗消耗神之气息数字右移50  (默认false)


g_channel_control.transform_NewRoleStateView_spBtnRoleSublText_Alignment = true  --潜能解放 按钮 文字换行居中
g_channel_control.transform_NewRoleStateView_spBtnRoleSthText_Alignment = true  --角色强化 按钮 文字换行居中
g_channel_control.transform_NewRoleStateView_spBtnRoleStoryText_Alignment = true  --背景故事 按钮 文字换行居中
g_channel_control.transform_NewRoleSoulView_lbSoulEquipName_Alignment = true    --角色->魂灵装，魂灵装名字 文字居中换行
g_channel_control.transform_NewRoleAwakenView_lbAwake_Alignment = true          --角色->状态->潜能解放，潜能解放阶段文字居中换行
g_channel_control.transform_NewRoleSkillView_skillName_Alignment = true          --角色技能，技能名字换行居左
g_channel_control.transform_Card_ShopLayer_awakenAlign = true                    --英雄圆桌已觉醒右对齐

g_channel_control.transform_NewRoleStoryView_storyDetail_autoChangeLine = true      
g_channel_control.transform_NewRoleSkillView_skillDes_Alignment = true            --角色技能，技能描述扩容

g_channel_control.transform_AstrolabeMainLayer_textAwake_fontSize = true           --星盘解锁，右移
g_channel_control.transform_AstrolabeMainLayer_pointText_fontSize = true           --星盘 可分配星点，缩小字号
g_channel_control.transform_AstrolabeLockBoxLayer_textPoint_pos = true           --星盘 解锁点右移
g_channel_control.transform_Astrolabe_sth_matNum_pos   = true                   --星盘素材强化，当前数量右移
g_channel_control.transform_AstrolabeInfoBoxLayer_textPoint_pos   = true         --星盘特效 开启所需点数右移
g_channel_control.transform_AstrolabeClimaxBoxLayer_textPoint_pos = true


g_channel_control.transform_GiftShowListLayer_Text_buy_cishu_Alignment = true    --商店礼包描述居中
g_channel_control.transform_CommonSortBoxLayer_soutItem_Text_fontSize = true    --称号排序属性文本字号(默认false)
g_channel_control.transform_XbMailNormalControlLayer_Text_auto_delete_desc_pos = true    --自动删除邮件文本位置(默认false)
g_channel_control.transform_XbFriendsAddFriendConfirmLayer_Text_dec_pos = true   --添加好友文本描述位置
g_channel_control.transform_AllianceBattleMainView_V3_GuildName1_notSign_Text_pos = false   --本方公会名称文本描述位置
g_channel_control.transform_XbGiftInfoLayer_Text_dec_Alignment_FontSize = true   --礼包物品描述文本对齐  位置开关
g_channel_control.transform_XbGiftInfoLayer_Text_validity_Pos = false   --礼包有效期文本位置开关
g_channel_control.transform_XbItemInfoNode_Text_dec_Alignment_FontSize = false   --礼包物品描述文本对齐  位置开关

g_channel_control.transform_Act_2_MapLayer_Btn_left_btn_2_Pos = false   --新春外传按钮位置修正(默认false)

g_channel_control.transform_XbStartLayer_Panel_Server_Time_Show_Pos = true   --主界面显示服务器时间(默认false，欧美服特有需求)
g_channel_control.bind_copyToClipboard = true  --客户端是否已经绑定复制参战码功能
g_channel_control.UI_SettingLayer_Show_Down_JapanLuage = false --默认不现实
g_channel_control.UI_SettingLayer_Show_change_Luage = true --默认不现实


g_channel_control.transform_PrincessController_DialogWidthNum = 38 		--版娘弹出提示语单行字符数
g_channel_control.transform_showGMInfo_Title_Alignment = true 					--共鸣界面，提示换行


--**************************************************************************************
--****************************        函    数   调   用      ****************************
--**************************************************************************************


--获取公告地址
function g_channel_control:getNoticeUrl()
    local random = math.random()
    print("notice random "..tostring(random))
    if tonumber(XBConfigManager:getInstance():getUseIPType()) == 1 then
        return "https://cljjen-download.vsplay.com/cljjen/notice/efun/home.html"--"http://218.32.1.25/static/notice/efun/home.html"
    else
    	return "http://218.32.1.25/static/notice/efun/home.html"--.."?v="..tostring(random)
    end
    return ""
    
end



--是否开启跳转到热更页面的按钮
function g_channel_control:isOpenJumpToUpdate()
    if tonumber(XBConfigManager:getInstance():getUseIPType()) ~= 1 then
    	local gameUrl = cc.MyHttpHelper:shareMyHttpHelper():getGameURL() or "";
    	local simpleUrl  = string.match(gameUrl, "%d+%.%d+%.%d+%.%d+:%d+")
    	local confUrl = "119.28.161.158:27000"
    	if simpleUrl == confUrl then
    		return true
    	end
    end
    return false
    
end	



