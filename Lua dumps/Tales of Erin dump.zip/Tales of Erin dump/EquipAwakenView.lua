--require "XUIView"

EquipAwakenView = class("EquipAwakenView",XUIView)
EquipAwakenView.CS_FILE_NAME = "EquipAwakenView.csb"
EquipAwakenView.CS_BIND_TABLE = 
{
    panelEffect = "/i:426",
    effMagic = "/i:426/s:effMagic",
    effIcon = "/i:426/s:effIcon",
    effIcon2 = "/i:426/s:effIcon2",
    effNum = "/i:426/s:effNum",

    panelSort = "/i:160/s:panelSort",
    panelList = "/i:160/i:80",
    panelIcon1 = "/i:160/i:145",
    panelIcon2 = "/i:160/i:339",
    
    sortTitle = "/i:160/i:266",

    btnTarget1 = "/i:160/i:161",
    btnTarget2 = "/i:160/i:163",
    ImgBtnEq = "/i:160/i:184",
    ImgBtnNoEq = "/i:160/i:182",
    btnStartAwaken = "/i:160/i:477",
    btnHelp = "/i:160/s:btnHelp",

    lbLvNow = "/i:160/i:397/i:401",
    lbLvNew = "/i:160/i:397/i:402",

    lbGoldCost = "/i:160/i:1641",
    lbGoldMax = "/i:160/i:1631",

    lbSkillTwoName = "/i:160/i:256/i:259",
    lbSkillTwoLvNow = "/i:160/i:256/i:262",
    lbSkillTwoLvNew = "/i:160/i:256/i:263",
    lbSkillTwo = "/i:160/i:256",
    lbState1 = "/i:160/i:272",
}

function EquipAwakenView.createWithBackBtn(nSelectTitleNum)
    EquipListView.nDefaultSelect = nSelectTitleNum or 0
    local v = EquipAwakenView.new():init()
    --local b = BackgroundView.new():initWithBackBtn(v,"n_UIShare/Global_UI/bg/bg_003_1.png")
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function EquipAwakenView:init()
    EquipAwakenView.super.init(self)

    self.exist = true

    self.panelEffect:setVisible(false)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = EquipListItemView.new():init()

        temp.ClickEvent = function(item)            
            self:equipClicked(item)
        end
        
        temp.resetDataEvent = function(item)
            --设置展示模式
            local smode = 0
            if g_channel_control.b_newEqBag then
                smode = math.floor(self.sortBtnView:getSortMode() / 10)
            else
                smode = self.sortBtnView:getSortMode() % 10
            end
            item:setTitleMode(smode)

            local data = item:getData()
            if self.currentState == 1 then
                item:setSelected(item:getData().id == self.currentFirstEquipID)
            else
                if data.id == self.currentFirstEquipID then
                    item:setShadow(true)
                else
                    item:setSelected(item:getData()._isselected)
                end
            end
        end
        return temp
    end
    
    --排序
    if g_channel_control.b_newEqBag then
        self.sortBtnView = EqSortButtonView.new():init(self.panelSort,"EqP_t",51,"EqS_Rank_t",0,"EqS_Ele_t",0,"EqS_Brk_t",0)
        self.sortBtnView.sortModeChangedEvent = function()
            self:ReLoadData()
        end
    else
        self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_t",814,1)
        self.sortBtnView.sortModeChangedEvent = function()
            self:refresh()
        end
    end
    --

    self.btnStartAwaken:addClickEventListener(function()
        self:onEquipAwaken()
    end)

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)
    --
    self.iconView2 = REIconView.new():init(self.panelIcon2)
    --
    if g_channel_control.b_newEqBag then
        self.curTargetData = nil
        self.iconView1 = EQSelectIconView.new():init(self.panelIcon1)
        self.iconView1.BtnSelectClick = function(index)
            if self.currentState ~= 3 then
                self:showEquipList()
                self:refresh()
            end
        end
        --
        self.nSelectTitleNum = self.nDefaultSelect or 0 --1:已装。0:未装

        self.bEnableEqTitle = false   --已装灵装按钮是否有效
        self.bEnableNoEqTitle = true --未装灵装按钮是否有效

        self.ImgBtnEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableEqTitle then
                    self:onSelectTitle(1)
                end
            end
        end)
        self.ImgBtnEq:setSwallowTouches(true)

        self.ImgBtnNoEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableNoEqTitle then
                    self:onSelectTitle(0)
                end
            end
        end)
        self.ImgBtnNoEq:setSwallowTouches(true)
        
        --self:onCallEqListByTitle(self.nSelectTitleNum)
        --
        if g_channel_control.b_XbWorkShopView then
            self.ImgBtnEq:setVisible(false)
            self.ImgBtnNoEq:setVisible(false)
        else
            self.ImgBtnEq:setVisible(true)
            self.ImgBtnNoEq:setVisible(true)
        end
        --
    else
        self.iconView1 = REIconView.new():init(self.panelIcon1)

        self.btnTarget1:setPressedActionEnabled(false)
        self.btnTarget1:addClickEventListener(function()
            self:switchState(1)
            self:refresh()
        end)

        self.btnTarget2:setPressedActionEnabled(false)
        self.btnTarget2:addClickEventListener(function()
            self:switchState(2)
            self:refresh()
        end)
    end

    self:switchState(1)

    self:showAwakenInfo()
    self.lbGoldMax:setString(""..user_info["gold"])
    
    return self
end
--灵装突破
function EquipAwakenView:showGuidePicLayer( ... )
    if self.exist ==  false then 
        return
    end
    local data = {}
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_lztp_001.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function EquipAwakenView:onSelectTitle(nSelectNum)
    if self.exist ==  false then 
        return
    end
    if self.nSelectTitleNum ~= nSelectNum then
        self.nSelectTitleNum = nSelectNum
        self:onCallEqListByTitle(self.nSelectTitleNum)
    end
end

function EquipAwakenView:onCallEqListByTitle(nSelectNum)
    if self.exist ==  false then 
        return
    end
    --与后端交互获取新的装备列表
    self:ReLoadData()
    --
    --self:refreshTitleBtnState()
end

function EquipAwakenView:refreshTitleBtnState()
    if self.exist ==  false then 
        return
    end
    if self.nSelectTitleNum == 1 then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[2])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[1])
    else
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[1])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[2])
    end

    if not self.bEnableEqTitle then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
    if not self.bEnableNoEqTitle then
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
end

function EquipAwakenView:showEquipList()
    if self.exist ==  false then 
        return
    end
    
    local b,v = EquipListView.createWithBackBtn(1)
    self.changeCompareView = nil

    v.ItemResetEvent = function(item)
        local d = item:getData()
        if d.id == self.currentFirstEquipID then
            item:showUnequip()
        end
    end

    v.ItemClickedEvent = function(item)
        local eqdata = item:getData()

        if eqdata.id == self.currentFirstEquipID then
            self:setAwakenTarget()
            self.currentSecoundEquipID = nil
            self:switchState(1)
            self:ReLoadData()
        else
            self:setAwakenTarget(eqdata.id)
            self.currentSecoundEquipID = nil
            self:switchState(2)
            self:ReLoadData()
        end
        b:returnBack()
    end
    
    v.dataSourceEvent = function(sender,sortmode)
        local dataset = {}
        dataset = self:getTargetDataSource()
        return dataset
    end
    
    b.beforeCloseEvent = function()
        self:ReLoadData()
    end

    v:refresh()
    SceneManager.rootLayer:addChild(b:getRootNode())
    --self:addSubView(b)
end

function EquipAwakenView:switchState(state)
    if self.exist ==  false then 
        return
    end
    self.currentState = state

    if state == 1 then
        if g_channel_control.b_newEqBag then
            self.sortTitle:setString(UITool.ToLocalization("选择要消耗的灵装"))
        else
            self.sortTitle:setString(UITool.ToLocalization("选择要突破的灵装"))
        end
        if not g_channel_control.b_newEqBag then
            self.sortBtnView:setSortKey("eq_t",814)
        end
    else
        self.sortTitle:setString(UITool.ToLocalization("选择要消耗的灵装"))
        if not g_channel_control.b_newEqBag then
        self.sortBtnView:setSortKey("eq_s",421)
        end
    end

    if g_channel_control.b_newEqBag then
        if g_channel_control.b_XbWorkShopView then
            self.ImgBtnEq:setVisible(false)
            self.ImgBtnNoEq:setVisible(false)
        else
            self.ImgBtnEq:setVisible(true)
            self.ImgBtnNoEq:setVisible(true)
        end

        self.btnTarget1:setTouchEnabled(false)
        self.btnTarget2:setTouchEnabled(false)
        self.btnTarget1:setVisible(false)
        self.btnTarget2:setVisible(false)
    else
        self.ImgBtnEq:setVisible(false)
        self.ImgBtnNoEq:setVisible(false)
        self.btnTarget1:setTouchEnabled(state == 2)
        self.btnTarget1:setBright(state == 2)   
        self.btnTarget2:setTouchEnabled(state == 1)
        self.btnTarget2:setBright(state == 1)   

        self.btnTarget1:setVisible(state ~= 3)
        self.btnTarget2:setVisible(state ~= 3)
    end
end

function EquipAwakenView:lockAwakenTarget(target_id,nEquiped)
    if self.exist ==  false then 
        return
    end  
    self:switchState(3)
    if g_channel_control.b_newEqBag then
        self.lockedEid = target_id
        self.nCurLockTargetEquiped = nEquiped
        --self:setAwakenTarget(target_id)
        self.currentSecoundEquipID = nil
        --self:ReLoadDataInLocked(target_id,nEquiped)
    else
        self.currentFirstEquipID =  target_id
    end
end

function EquipAwakenView:equipClicked(item)
    if self.exist ==  false then 
        return
    end
    local data = item:getData()
    local e_id_num = getNumID( data["id"] )
    if self.currentState == 1 then
        if g_channel_control.b_newEqBag then
            GameManagerInst:alert(UITool.ToLocalization("请先点击左侧添加需要突破的灵装"))
        else
            self.currentFirstEquipID = data.id
            self.gridview:refresh()
            
            self.iconView1:showEquip(e_id_num)

            self:showAwakenInfo()

            self.currentSecoundEquipID = nil
            self.iconView2:showNoIcon()
        end
    else
        if self.currentFirstEquipID ~= data["id"] then
            if self.currentSecoundEquipID == data["id"] then
                self.currentSecoundEquipID = nil
                self.iconView2:showNoIcon()
                data._isselected = false
            else
                self.currentSecoundEquipID = data["id"]
                self.iconView2:showEquip(e_id_num)
                for i = 1,#self.currentDataSource do
                    self.currentDataSource[i]._isselected = false
                end
                data._isselected = true
            end
        end
        self.gridview:refresh()
    end
end

function EquipAwakenView:showAwakenInfo()
    if self.exist ==  false then 
        return
    end
    if self.currentFirstEquipID then
        local d = nil
        if g_channel_control.b_newEqBag then
            d = self.curTargetData
        else
            d = user_info["eq"][self.currentFirstEquipID]
        end
        if d == nil then
            return
        end
        local  breakCount  = d["brk_num"] -- 突破次数
        local  breakLimit  = d["rarity"]  -- 最大突破次数
        local num = breakCount+1
        if(num > #AwakenNum[breakLimit])then
            self.bCanAwaken = false
            --不可
            self.lbLvNew:setString("")
            self.lbLvNow:setString("")
            self.lbSkillTwoName:setString("")
            self.lbSkillTwoLvNow:setString("")
            self.lbSkillTwoLvNew:setString("")
            self.lbGoldCost:setString("0")

            self.lbSkillTwo:setVisible(false)
            
            self.btnStartAwaken:setTouchEnabled(false)
            self.btnStartAwaken:setBright(false)
        else
            self.bCanAwaken = true
            --可突破
            self.lbLvNow:setString(d["Lv_max"])
            self.lbLvNew:setString(AwakenNum[breakLimit][num]["lvmax"])

            --二技能
            local e_id_num = getNumID(self.currentFirstEquipID)
            if equip[e_id_num]["is_there_sk_two"] == 0 then
                self.lbSkillTwo:setVisible(false)
            else
                self.lbSkillTwo:setVisible(true)
                local skill_two_name = UITool.getUserLanguage(passive_sk[d["sk_two"]["provide_sk_id"]]["sk_name"])
                self.lbSkillTwoName:setString(skill_two_name)
                self.lbSkillTwoLvNow:setString(UITool.ToLocalization("等级 ")..d["sk_two"]["Lv"])
                self.lbSkillTwoLvNew:setString(UITool.ToLocalization("等级 ")..d["sk_two"]["Lv"] + 1)
            end

            self.lbGoldCost:setString(""..AwakenNum[breakLimit][num]["gold"])
            
            self.btnStartAwaken:setTouchEnabled(true)
            self.btnStartAwaken:setBright(true)
        end

    else
        self.bCanAwaken = nil
        self.lbLvNew:setString("")
        self.lbLvNow:setString("")
        self.lbSkillTwoName:setString("")
        self.lbSkillTwoLvNow:setString("")
        self.lbSkillTwoLvNew:setString("")
        self.lbGoldCost:setString("0")

        self.lbSkillTwo:setVisible(false)
        
        self.btnStartAwaken:setTouchEnabled(false)
        self.btnStartAwaken:setBright(false)
    end
end

function EquipAwakenView:playEffect()
    if self.exist ==  false then 
        return
    end
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
    
    local effs = {
        {self.effIcon,"EffAwkFrame.csb"},
        {self.effIcon2,"EffAwkFade.csb"},
        {self.effMagic,"EffAwkMagic.csb"},
        {self.effNum,"EffAwkNum.csb"}
    }

    for i = 1,#effs do
        local node_1 = cc.CSLoader:createNode(effs[i][2])
        local timeline_1 =cc.CSLoader:createTimeline(effs[i][2])
        node_1:setTag(123)
        local psize = effs[i][1]:getSize()
        node_1:setPosition(cc.p(psize.width/2,0))
        effs[i][1]:addChild(node_1)

        node_1:runAction(timeline_1)
        timeline_1:play("animation0",false) 
        timeline_1:setLastFrameCallFunc(function ()
            node_1:stopAllActions()
            node_1:removeFromParent()
        end)
    end
        
--    cc.SimpleAudioEngine:getInstance():playEffect("music/ui/tupo.mp3", false)          
     AudioManager:shareDataManager():playMusic("music/ui/tupo.mp3",0, false)
    local delay = cc.DelayTime:create(1.3)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:stopEffect()
    end))
    self.panelEffect:runAction(sequence)              
end

function EquipAwakenView:stopEffect()
    if self.exist ==  false then 
        return
    end
    KeyboardManager._isShowEffect = false
    self.panelEffect:stopAllActions()

    local effs = {
        self.effIcon,
        self.effIcon2,
        self.effMagic,
        self.effNum
    }

    for i = 1,#effs do
        local e = effs[i]:getChildByTag(123)
        if e then e:stopAllActions() end
        effs[i]:removeAllChildren()
    end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    self:refresh()
end

function EquipAwakenView:setAwakenTarget(target_id)
    if self.exist ==  false then 
        return
    end
    if target_id then
        self.currentFirstEquipID = target_id
        if user_info["eq"][target_id] then
            self.curTargetData = table.deepcopy(user_info["eq"][target_id])
        end
        if self.curTargetData then
            if self.curTargetData["owner"] == "0" then
                self.nCurTargetEquiped = 0
            else
                self.nCurTargetEquiped = 1
            end
        end
    else
        self.currentFirstEquipID = nil
        self.curTargetData = nil
        self.nCurTargetEquiped = nil
    end

end

function EquipAwakenView:onEquipAwaken()
    if self.exist ==  false then 
        return
    end

    if not self.bCanAwaken then return end
    if not self.currentFirstEquipID then return end
    if not self.currentSecoundEquipID then 
        GameManagerInst:alert(UITool.ToLocalization("请选择突破素材"))
        return 
    end

    local tempTable = {
        ["rpc"] = "eq_brk",
        ["target_eq_id"] = self.currentFirstEquipID ,
        ["eat_eq_id"] = self.currentSecoundEquipID
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        if g_channel_control.b_newEqBag then
            if self.lockedEid and self.nCurLockTargetEquiped and (self.currentState == 3) then
                self:ReLoadDataInLocked(self.lockedEid,self.nCurLockTargetEquiped)
            else
                self:ReLoadDataInSwitch()
            end
        else
            DataManager:euipBthEnd(self.currentFirstEquipID,data["upgrade"])
            DataManager:dTEquipData(self.currentSecoundEquipID)
        end

        user_info["gold"] = data["gold"]
        self.currentSecoundEquipID = nil
        self:playEffect()

        if self.infoChangedEvent then
            self.infoChangedEvent(self)
        end
    end,
    function(state_code,msgText)
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipAwakenView:ReLoadDataInSwitch()
    if self.exist ==  false then 
        return
    end
    self.currentSecoundEquipID = nil
    if self.currentState ~= 1 and self.currentFirstEquipID and self.nCurTargetEquiped then
        self:ReLoadDataInLocked(self.currentFirstEquipID,self.nCurTargetEquiped)
    else
        self:ReLoadData()
    end
end

function EquipAwakenView:ReLoadDataInLocked(target_id,nInEquiped)
    if self.exist ==  false then 
        return
    end
    local rankVaules = {3,4,5}--table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = {1,2,3,4,5,0}--table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = {1,2,3,4,0}--table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local nEquiped = nInEquiped
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = nEquiped,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()

        self:setAwakenTarget(target_id)
        self.currentSecoundEquipID = nil
        self:ReLoadData()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
            --self:returnBack()
        end)
    end,
    true)
end

function EquipAwakenView:ReLoadData()
    if self.exist ==  false then 
        return
    end
    local rankVaules = table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = self.nSelectTitleNum,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()       
        --DataManager:wAllBagData({mat = data["mat"]})
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end

        --self.equipListView:setDataSource(equip_list)
        self.dataLoaded = true
        self:refresh()
        self:refreshTitleBtnState()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
            --self:returnBack()
        end)
    end,
    true)
end

function EquipAwakenView:getDataSource()
    if self.exist ==  false then 
        return
    end
    local ds = {}
    --先排序，后刷列表  
    if self.currentState == 1 then
        --完整列表  满破不显示
        for i = 1,#equip_list do
            local d = equip_list[i]
                
            local  breakCount  = d["brk_num"] -- 突破次数
            local  breakLimit  = d["rarity"]  -- 最大突破次数  (equip_list[i]["owner"] == "0") and
            if (breakCount < #AwakenNum[breakLimit]) then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end
    else 
        --已选择的列表
        if self.currentFirstEquipID then
            local e_id_cur = getNumID(self.currentFirstEquipID)
            for i = 1,#equip_list do
                local e_id_num = getNumID( equip_list[i]["id"] )
                if ((e_id_num == e_id_cur) 
                    and (equip_list[i]["owner"] == "0") 
                    and (not equip_list[i]["is_lock"])) 
                    and (equip_list[i]["id"] ~= self.currentFirstEquipID ) then
                    table.insert(ds,table.deepcopy(equip_list[i]))
                end
            end
        end
    end
    
    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end
    return ds
end

function EquipAwakenView:getTargetDataSource()
    if self.exist ==  false then 
        return
    end
    local ds = {} 
    --完整列表  满破不显示
    for i = 1,#equip_list do
        local d = equip_list[i]
            
        local  breakCount  = d["brk_num"] -- 突破次数
        local  breakLimit  = d["rarity"]  -- 最大突破次数  (equip_list[i]["owner"] == "0") and
        if (breakCount < #AwakenNum[breakLimit]) then
            table.insert(ds,table.deepcopy(equip_list[i]))
        end
    end
    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end
    return ds
end

function EquipAwakenView:getUseDataSource()
    if self.exist ==  false then 
        return
    end
    local ds = {} 
    --已选择的列表
    if self.currentFirstEquipID then
        local e_id_cur = getNumID(self.currentFirstEquipID)
        for i = 1,#equip_list do
            local e_id_num = getNumID( equip_list[i]["id"] )
            if ((e_id_num == e_id_cur) 
                and (not equip_list[i]["is_lock"])) 
                and (equip_list[i]["id"] ~= self.currentFirstEquipID ) then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end
    else
        --默认显示全部未装灵装
        for i = 1,#equip_list do
            if (not equip_list[i]["is_lock"]) then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end
    end
    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end
    return ds
end

function EquipAwakenView:onSaleEquip(eid)
    if self.exist ==  false then 
        return
    end
    if self.currentFirstEquipID == eid then
        self.currentFirstEquipID = nil
        self.currentSecoundEquipID = nil
    elseif self.currentSecoundEquipID == eid then
        self.currentSecoundEquipID = nil
    end
end

function EquipAwakenView:refresh()
    if self.exist ==  false then 
        return
    end
    if g_channel_control.b_newEqBag then
        self.currentDataSource = self:getUseDataSource()
        if self.currentState == 1 then
            if self.panelList then
                self.panelList:setVisible(false)
            end
            if self.lbState1 then
                self.lbState1:setVisible(true)
            end
        else
            if self.panelList then
                self.panelList:setVisible(true)
            end
            if self.lbState1 then
                self.lbState1:setVisible(false)
            end
        end
    else
        self.currentDataSource = self:getDataSource()
    end
    if self.currentDataSource == nil then
        return
    end
    self.gridview:setDataSource(self.currentDataSource)

    if self.currentFirstEquipID then
        local eid = getNumID(self.currentFirstEquipID)
        self.iconView1:showEquip(eid)
        self:showAwakenInfo()
    else
        self.iconView1:showNoIcon()
        self.currentSecoundEquipID = nil
    end

    if self.currentSecoundEquipID then
        local eid = getNumID(self.currentSecoundEquipID)
        self.iconView2:showEquip(eid)
    else
        self.iconView2:showNoIcon()
    end
    
    self.lbGoldMax:setString(""..user_info["gold"])
end

function EquipAwakenView:DestroyHandle()
    self.exist = false
end
