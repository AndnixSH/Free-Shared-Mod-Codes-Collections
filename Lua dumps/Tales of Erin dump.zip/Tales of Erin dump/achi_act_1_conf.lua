achi_act_1_conf={} 
achi_act_1_conf[1] = {
        id= 1,
        achi_name= "Clear!",
        achi_desc= "Complete all stages of the event",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[2] = {
        id= 2,
        achi_name= "Demon Hunter (Easy)",
        achi_desc= "Complete multiplayer dungeon (Easy) 5 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[3] = {
        id= 3,
        achi_name= "Demon Hunter (Hard)",
        achi_desc= "Complete multiplayer dungeon (Hard) 10 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[4] = {
        id= 4,
        achi_name= "Demon Hunter (Hell)",
        achi_desc= "Complete multiplayer dungeon (Hell) 20 times",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[5] = {
        id= 5,
        achi_name= "One Man Army (Easy)",
        achi_desc= "Complete multiplayer dungeon (Easy) 1 time solo",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[6] = {
        id= 6,
        achi_name= "One Man Army (Hard)",
        achi_desc= "Complete multiplayer dungeon (Hard) 1 time solo",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[7] = {
        id= 7,
        achi_name= "One Man Army (Hell)",
        achi_desc= "Complete multiplayer dungeon (Hell) 1 time solo",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[8] = {
        id= 8,
        achi_name= "30 Kills",
        achi_desc= "Kill 30 demons",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[9] = {
        id= 9,
        achi_name= "50 Kills",
        achi_desc= "Kill 50 demons",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[10] = {
        id= 10,
        achi_name= "100 Kills",
        achi_desc= "Kill 100 demons",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_1_conf[11] = {
        id= 11,
        achi_name= "Ruler of eternal night",
        achi_desc= "Pass alone: Demon·Erosion of Blood (Challenge)",
        achi_icon= "icons/achiv/cjxt_001.png",

} 