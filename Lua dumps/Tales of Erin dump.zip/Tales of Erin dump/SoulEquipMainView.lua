--require "XUIView"

SoulEquipMainView = class("SoulEquipMainView",XUIView)
SoulEquipMainView.CS_FILE_NAME = "SoulEquipMainView.csb"
SoulEquipMainView.CS_BIND_TABLE = 
{
    vpanel="/i:58",
    btnTab1="/i:42/i:55",
    btnTab2="/i:42/i:56",
    btnTab3="/i:42/i:57",
    btnClose="/i:59/i:61",

    panelRight = "/i:42"
}

SoulEquipMainView.bReturnShouldRefresh = false

function SoulEquipMainView:init(rcvData)
    SoulEquipMainView.super.init(self)
    
    self.views = XUIView.new():init(self.vpanel)

    self.hero_id = rcvData.nHero_id
    self.backFunc = rcvData["sFunc"]
    self.sManager = rcvData["sManager"]
    self.sDelegate = rcvData["sDelegate"]

    self:InitSoulEquipInfoView()
    self:InitSoulEquipSthView()
    self:InitSoulEquipSublView()

    

    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:setBrightStyle(ccui.BrightStyle.normal)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)

    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:setBrightStyle(ccui.BrightStyle.normal)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:setBrightStyle(ccui.BrightStyle.normal)
    self.btnTab3:setTouchEnabled(true)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.curTab = 0
    self:switchView(rcvData.tab)


    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)

    self.soulEquipInfoLoaded = false
    --self:loadSoulEquipInfo()

    

    self:setNodeLockState()

    return self
end

function SoulEquipMainView:setShow( )
  -- body
    self.sManager.menuLayer:hiddenUserInfo(false)
    self.sManager.menuLayer:RefshTopBar()
end

function SoulEquipMainView:InitSoulEquipInfoView()
    if not self.hero_id then
        return
    end

    self.equipInfoView = SoulEquipInfoView.new():init(self.hero_id)
    self.views:addSubView(self.equipInfoView)
end

function SoulEquipMainView:InitSoulEquipSthView()
    if not self.hero_id then
        return
    end

    self.equipSthView = SoulEquipSthView.new():init(self.hero_id)
    
    self.equipSthView.infoChangedEvent = function(sender)
        -- 更新魂灵装静态信息
        self:loadSoulEquipInfo(false)
        sender:refresh()
        self.bReturnShouldRefresh = true
    end

    self.views:addSubView(self.equipSthView)
end

function SoulEquipMainView:InitSoulEquipSublView()
    if not self.hero_id then
        return
    end

    self.equipSublView = SoulEquipSublView.new():init(self.hero_id)
    
    
    self.equipSublView.infoChangedEvent = function(sender)
        -- 更新魂灵装静态信息
        self:loadSoulEquipInfo(false)
        sender:refresh()
        self.bReturnShouldRefresh = true
    end

    self.views:addSubView(self.equipSublView)
end

function SoulEquipMainView:refresh()
    if g_channel_control.b_newEqBag then
        if self.curTab == 1 then
            if self.soulEquipInfoLoaded then
                self.equipInfoView:refresh()
            end
        elseif self.curTab == 2 then
            self.equipSthView:ReLoadData()
        elseif self.curTab == 3 then
            --self.equipSublView:refresh()
        end
    else
        if self.soulEquipInfoLoaded then
            if self.curTab == 1 then
                self.equipInfoView:refresh()
            elseif self.curTab == 2 then
                self.equipSthView:refresh()
            elseif self.curTab == 3 then
                --self.equipSublView:refresh()
            end
        end
    end
    -- --设置小红点状态  灵装强化
    -- UITool.setCommmonBtnRedDop(self.btnTab2,false)
    -- if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.StEquip) == 0 then 
    --     UITool.setCommmonBtnRedDop(self.btnTab2,true,cc.p(150,70))
    -- end 
end

function SoulEquipMainView:switchView(tab)
    local num = tab or 1
    if self.curTab ~= num then
    
        local ctls = {
            {btn = self.btnTab1, view= self.equipInfoView},
            {btn = self.btnTab2, view= self.equipSthView},
            {btn = self.btnTab3, view= self.equipSublView}
        }

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            if i == num then
                ctls[i].btn:setBrightStyle(ccui.BrightStyle.highlight)
            else
                ctls[i].btn:setBrightStyle(ccui.BrightStyle.normal)
            end
            
            ctls[i].view:getRootNode():setVisible(i == num)
        end

        if self.Se_info and self.hero_id then
            local curSoulEquipId = tonumber(getNumID(self.hero_id))
            if self.Se_info["break_count"] >= hero_soul[curSoulEquipId]["soul_break"]["total_break"] then
                --已满升华
                self.btnTab3:setTouchEnabled(false)
                self.btnTab3:setBright(false)
            end
        end

        
        self.curTab = num
        self:refresh()
    end
end

function SoulEquipMainView:loadBagList()
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
		DataManager:wAllBagData(data["bag"])       
        --self:refresh()
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    true)
end

function SoulEquipMainView:beginLoadData()
    local tempData = {}
    if g_channel_control.b_newEqBag then
        tempData = { 
            rpc = "eq_list",
            rarity = {3,4,5},
            element = {1,2,3,4,5,0},
            brk_num = {1,2,3,4,0},
            key = "element",
            reverse = 0,
            equipped = nCurEquiped,
        }
    else
        tempData = { 
            rpc = "eq_list"
        }
    end
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        DataManager:rfsElist()

        self.soulEquipInfoLoaded = true
        self:FillSoulEquipInfoToChildren()
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function SoulEquipMainView:returnBack()
    if self.backFunc then
        if self.bReturnShouldRefresh then
            self.backFunc(self.sDelegate)
        end
    end
    self:clear()
    self.sManager:removeFromNavNodes(self)
    --self:removeFromNavNodes()
end


function SoulEquipMainView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        self:loadSoulEquipInfo(false)
        self:refresh()
    else
        self:loadSoulEquipInfo(true)
    end

end

--设置按钮等级解锁状态
function SoulEquipMainView:setNodeLockState()
    local curNodes = {self.btnTab1, self.btnTab2, self.btnTab3}
    for i=1,#curNodes do
        local config = guide_rank_config["EquipMainView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        end 
    end   
end

function SoulEquipMainView:getSoulEquipInfo()

end

function SoulEquipMainView:FillSoulEquipInfoToChildren()
    if self.soulEquipInfoLoaded then
        if self.equipInfoView then
            --self.equipInfoView:refresh()
            self.equipInfoView:FillSoulEquipData(self.Se_info)
        end
        if self.equipSthView then
            --self.equipSthView:refresh()
            self.equipSthView:FillSoulEquipData(self.Se_info)
        end
        if self.equipSublView then
            --self.equipSublView:refresh()
            self.equipSublView:FillSoulEquipData(self.Se_info)
            self.equipSublView:FillMatData(self.Mat_info)
            if self.Se_info and self.hero_id then
                local curSoulEquipId = tonumber(getNumID(self.hero_id))
                if self.Se_info["break_count"] >= hero_soul[curSoulEquipId]["soul_break"]["total_break"] then
                    --已满升华
                    self.btnTab3:setTouchEnabled(false)
                    self.btnTab3:setBright(false)
                end
            end
        end
    end
end

function SoulEquipMainView:loadSoulEquipInfo(bLoadEq)
    if not self.hero_id then return end

    print("==SoulEquipMainView==loadSoulEquipInfo: self.hero_id = "..self.hero_id)
    local h_id_num = getNumID( self.hero_id )
    local tempTable = {
                rpc = "hero_soul_info",
                hero_id = self.hero_id
    }

    --已获得角色，读取数据
    GameManagerInst:rpc( 
        tempTable,
        3,
        function(data)
            --success
            self.Se_info = table.deepcopy(data["hero_soul"][self.hero_id])
            self.Mat_info = table.deepcopy(data["soul_brk_mat"]["5"])
            --GameManagerInst:saveToFile("hero_soul_info.json",data)

            if bLoadEq then
                self:beginLoadData()
            else
                self.soulEquipInfoLoaded = true
                self:FillSoulEquipInfoToChildren()
                self:refresh()
            end
        end,
        function(state_code,msgText)
            --failed
            -- --TODO: 假数据（调试期间用 发布需更改）
            -- self:FillSoulEquipFakeInfo()
            -- self.soulEquipInfoLoaded = true
            -- self:FillSoulEquipInfoToChildren()
            GameManagerInst:alert(msgText)
        end,
        true)
end

-- # ■ [装备详情]* hero_soul_info
-- #  "hero_id": "1*1299656990",  #对应的角色ID
-- #返回:
-- data = {
--  "state_code": 1,
--  "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":1,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
-- }
--- 填充魂灵装假数据
function SoulEquipMainView:FillSoulEquipFakeInfo()
    -- local tdata = {}
    
    -- tdata.id = self.hero_id
    -- tdata.Lv = 2
    -- tdata.Lv_max = 40
    -- tdata.exp = 100
    -- tdata.exp_max = 200
    -- tdata.owner = 0
    -- tdata.Se_OpenStory = 1
    -- tdata.Se_StoryStage = 0
    -- tdata.Se_hp = 115
    -- tdata.Se_atk = 70
    -- tdata.Se_sub_Lv = 1
    -- tdata.Se_sth_Lv = 35
    -- tdata.sk = {
    --             {
    --                 sk_id = 4013101 ,
    --                 is_Open = 1,
    --             },
    --             {
    --                 sk_id = 4013101 ,
    --                 is_Open = 1,
    --             },
    --             {
    --                 sk_id = 4013101 ,
    --                 is_Open = 1,
    --             },
    --             {
    --                 sk_id = 4013101 ,
    --                 is_Open = 1,
    --             },
    --             {
    --                 sk_id = 4013101 ,
    --                 is_Open = 1,
    --             },
    --         }

    -- self.skList = table.deepcopy(tdata["sk"])

    -- self.Se_info = tdata
end