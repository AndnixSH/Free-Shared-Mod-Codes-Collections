
--聊天室 输入框控件


ChatInputNode = class("ChatInputNode",XUIView)
ChatInputNode.CS_FILE_NAME = "ChatPannelnput.csb"
ChatInputNode.CS_BIND_TABLE = 
{
    btn_voice          = "/i:1",
    btn_face           = "/i:2",
    btn_send           = "/i:3",
    btn_voice_img      = "/i:4",
    input_pannel       = "/i:5",
    input_textField    = "/i:5/i:1",
    voice_pannel       = "/i:6",
    voice_progress_bg  = "/i:6/i:2",
    Panel_emot         = "/i:61",
    Panel_touch        = "/i:241",
    BG                 = "/i:692",
}
ChatInputNode.LogTag = "ChatNewMainLayer"

function ChatInputNode:create(rData)
    local inputNode = ChatInputNode.new( )
    inputNode:initUI()
    return inputNode
end

function ChatInputNode:initData( ... )
    -- body
    self.bEmoticon = false
end

function ChatInputNode:initUI( ... )
    -- body
    self:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)

    self.emotLayer = XbChatEmoticonLayer:create({})
    self.Panel_emot:addChild(self.emotLayer.uiLayer)
    self:bindAllBtn()
    self:registerCustomEventListener()
    self:hideChatEmotiUI()
    -- self.input_textField:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_RIGHT)
    self.input_textField:ignoreContentAdaptWithSize(false);
    self.input_textField:setTextAreaSize(cc.size(380,0))

    self.btn_voice_img:setVisible(false)

    local inputPlaceHolderStr = Lang:toLocalization(1031018)
    self.input_textField:setPlaceHolder(inputPlaceHolderStr)

    self.BG:setVisible(false)

end


function ChatInputNode:registerCustomEventListener()
   self.chatEmtioEventListener = lemon.EventManager:addCustomEventListener(EEventType.CHAT_EXPRESSION_SEND, function(data)
        self:hideChatEmotiUI()
    end)
end

function ChatInputNode:hideChatEmotiUI( ... )
    -- body
    if tolua.isnull(self.Panel_emot) == false then
        self.Panel_emot:setVisible(false)
    end

    if tolua.isnull(self.Panel_touch) == false then
        self.Panel_touch:setVisible(false)
    end
end


function ChatInputNode:unRegisterCustomEventListener()
   
    
    if self.chatEmtioEventListener ~= nil then
        lemon.EventManager:removeEventListener(self.chatEmtioEventListener)
        self.chatEmtioEventListener = nil 
    end
end

function ChatInputNode:bindAllBtn( ... )
    
    self.btn_voice:addTouchEventListener(handler(self,self.voiceBtnCallback))
    self.btn_face:addTouchEventListener(handler(self,self.faceBtnCallback))
    self.btn_send:addTouchEventListener(handler(self,self.sendBtnCallback))

    self.input_pannel:addTouchEventListener(handler(self,self.touchInputCallback))
    self.btn_voice_img:addTouchEventListener(handler(self,self.touchVoiceCallBack))

    self.Panel_touch:addTouchEventListener(handler(self,self.touchShieldCallBack))

end

function ChatInputNode:setDelegate(delegate)
    print("setDelegate...delegate:"..tostring(delegate))
    self.delegate = delegate

end
function ChatInputNode:setSendCallback( sendCallback )
    print("setSendCallback...delegate:"..tostring(sendCallback))

    self.sendCallback = sendCallback
end

function ChatInputNode:setEmoticonCallback( emotionCallback )
    self.emotionCallback = emotionCallback
end

function ChatInputNode:setInputString( str )
    self.input_textField:setString(str)
end

function ChatInputNode:popInputView(sDelegate, confirmFunc,defaultStr)           --弹出输入框
    -- if GameManagerInst.gameType == 2 then
        local rcvData = {}
        rcvData["sDelegate"] = sDelegate
        rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
        rcvData["confirmFunc"] = confirmFunc
        rcvData["defalutStr"] = defaultStr
        rcvData["maxLength"] = 40
        rcvData["autoCloseByMaxLength"] = true
        SceneManager:toInputModelLayer(rcvData)
    -- end
end

function ChatInputNode:touchShieldCallBack( sender,eventType )
    -- body
    if eventType == ccui.TouchEventType.ended then
        self:hideChatEmotiUI()
    end
end

function ChatInputNode:touchInputCallback( sender,eventType )
    -- body
    if eventType == ccui.TouchEventType.ended then
        if self:checkChatUnlock() == false then
            return
        end



        print("touchInputCallback:"..sender:getTag())
        local confirmFunc = function(self,text)
                self.input_textField:setString(text)
            end
        local defaultStr = self.input_textField:getString()
        self:popInputView(self,confirmFunc,defaultStr)

    end

end

function ChatInputNode:touchVoiceCallBack(sender,eventType) --语音触摸
    if eventType ==ccui.TouchEventType.began then
        print("touchVoice----Began------")
        if XBChatData:getInstance():canSpeakEabled() == true then
            self.bTouchVoice = true 
            self:createVoiceProgressTimer()
            self:pauseOrResumeBGMusic(false)
            XBChatPlatform:getInstance():voiceRecord(1)
        else
            self.bTouchVoice = false 
        end


    elseif eventType == ccui.TouchEventType.ended then
        print("touchVoice-----end")
        if self.bTouchVoice == true  then
            self.bTouchVoice = false 
            local onfile = "n_UIShare/chatNew/lt_b_009a.png" 
            sender:loadTexture(onfile)
            self:removeVoiceProgressTimer()
            -- --跨平台回调录音完成 ，执行发送音频文件操作
            XBChatPlatform:getInstance():voiceRecord(2)
            self:pauseOrResumeBGMusic(true)
        end


    elseif eventType == ccui.TouchEventType.canceled then
        print("touchVoice -----cancel")
        if self.bTouchVoice == true then
            self:pauseOrResumeBGMusic(true)
            self.bTouchVoice = false 
        end
    elseif eventType == ccui.TouchEventType.moved then
        if self.bTouchVoice == true then
            local p2_world = sender:getTouchMovePosition()
            local p2 = sender:convertToNodeSpace(p2_world)
            local t = cc.rectContainsPoint(sender:getBoundingBox(),p2)
            if t == false and self.sendAudio ==true then --离开按钮
                 print("手指上滑，取消发送:"..tostring(t).."...p2："..p2.x..".."..p2.y)
                 self.sendAudio = false
                 self:removeVoiceProgressTimer()
                XBChatPlatform:getInstance():voiceRecord(3)
                self:pauseOrResumeBGMusic(true)
            end
        end



    end
end

function ChatInputNode:voiceBtnCallback( sender,eventType )

    

    -- body
    print("voiceBtnCallback:"..sender:getTag())
    local platform = cc.Application:getInstance():getTargetPlatform()


    if eventType == ccui.TouchEventType.ended then

        if self:checkChatUnlock() == false then
            return
        end
    
        if g_channel_control.chatVoiceOpen ~= true then
            return
        end
        if platform == cc.PLATFORM_OS_ANDROID then
            XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1031003))
            return 
        end
        local file = "n_UIShare/chatNew/lt_b_007a.png"
        if self.isOpenVoice == true then
            self.isOpenVoice = false
            self.btn_voice_img:setVisible(false)
            self.input_pannel:setVisible(true)
        else
            self.isOpenVoice = true
            file = "n_UIShare/chatNew/lt_b_006a.png"
            self.btn_voice_img:setVisible(true)
            self.input_pannel:setVisible(false)
        end
        local filePath = cc.FileUtils:getInstance():fullPathForFilename(file)
        if filePath ~= nil then
            self.btn_voice:loadTexture(filePath)
        end 

    end

end

function ChatInputNode:faceBtnCallback( sender,eventType )
   
    -- body
    if eventType == ccui.TouchEventType.ended then
        if self:checkChatUnlock() == false then
            return
        end

        local bEmoticon = self.Panel_emot:isVisible()
        self.bEmoticon = not bEmoticon
        print("faceBtnCallback:",bEmoticon)
        self.Panel_emot:setVisible(self.bEmoticon)
        self.Panel_touch:setVisible(self.bEmoticon)

    end
end

function ChatInputNode:sendBtnCallback( sender,eventType )
    -- body
    if eventType == ccui.TouchEventType.ended then
        print("sendBtnCallback:"..sender:getTag().."...delegate:"..tostring(self.delegate))
        if XBChatData:getInstance():canSpeakEabled() == true  then
            if self.sendCallback and self.delegate then
                self.sendCallback(self.delegate,self.input_textField:getString())
            end
        end


    end

end


function ChatInputNode:pauseOrResumeBGMusic( bResume ) --恢复/暂停背景音乐
    if bResume == true then
        AudioManager:shareDataManager():resumeBGMusic()
        if AudioManager:shareDataManager():getBGId() ~= -1 then 
    
        else 
            local fullpath = lua_musci["zhuyeBGM"]
           AudioManager:shareDataManager():preloadM(fullpath)
           AudioManager:shareDataManager():playBGMusic(fullpath, true)
        end
    else
        AudioManager:shareDataManager():pauseBGMusic()
    end
end

function ChatInputNode:removeVoiceProgressTimer( )

    self.voice_pannel:setVisible(false)

    local onfile = "n_UIShare/chatNew/lt_b_009a.png" 
    self.btn_voice_img:loadTexture(onfile)
end

function ChatInputNode:createVoiceProgressTimer(  )
    self.sendAudio = true  

    local onfile = "n_UIShare/chatNew/lt_b_009b.png" 
    self.btn_voice_img:loadTexture(onfile)

    self.voice_pannel:setVisible(true)

    self.voice_progress_bg:setVisible(false)


    local voiceProgress = self.voice_pannel:getChildByTag(1001)
    if voiceProgress == nil then
        voiceProgress = cc.ProgressTimer:create(cc.Sprite:create("n_UIShare/chatNew/lt_ui_012.png"))
        voiceProgress:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
        voiceProgress:setReverseDirection(false)
        voiceProgress:setPosition(cc.p(self.voice_progress_bg:getPosition()))
        self.voice_pannel:addChild(voiceProgress, 10, 1001)
    else
        voiceProgress:setPercentage(0)
    end
    local act1 = cc.ProgressTo:create(10,100) --10s转弯
    voiceProgress:runAction(act1)   
end

function ChatInputNode:clear( ... )
    -- body
    -- if self.emotLayer.uiLayer and self.emotLayer.uiLayer:getParent() then
    --     self.emotLayer.uiLayer:removeFromParent()
    --     self.emotLayer.uiLayer = nil
    --     self.emotLayer = nil
    -- end

    self:unRegisterCustomEventListener()
end

function ChatInputNode:checkChatUnlock( ... )
   local chatUnlockLevel = 11
    if user_info["rank"] < chatUnlockLevel then
        
        
        local msg = string.format(Lang:toLocalization(1031013), chatUnlockLevel)
        
        MsgManager:showSimpMsg(msg)
        return false
    end
    return true
end

 