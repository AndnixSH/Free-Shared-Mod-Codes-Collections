--------------------------------
-- @module cc

--------------------------------------------------------
-- the cc MyHttpRequest
-- @field [parent=#cc] MyHttpRequest#MyHttpRequest MyHttpRequest preloaded module


--------------------------------------------------------
-- the cc PassData
-- @field [parent=#cc] PassData#PassData PassData preloaded module


--------------------------------------------------------
-- the cc MyHttpHelper
-- @field [parent=#cc] MyHttpHelper#MyHttpHelper MyHttpHelper preloaded module


return nil
