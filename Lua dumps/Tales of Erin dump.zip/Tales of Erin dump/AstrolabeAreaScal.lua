--/*说明
	--星盘缩略图
--*/
AstrolabeAreaScal = {}

function AstrolabeAreaScal:init(_self)
	self.baseSelf = _self
	self.m_AudoId = nil
	self.skeletonNode = nil
	self:setClimax()
	self:scalShowScalEx()
	self:setEnableFales()
end
--每个区域标示图片左下角的
function AstrolabeAreaScal:setMarkImage( ... )
	local  areaImage = self.baseSelf.rootNode:getChildByName("Image_area")
	areaImage:loadTexture(self.baseSelf.areaTable["icon_small"])
end
--设置顶级技能
function AstrolabeAreaScal:setClimax( ... )
	--从本地或取需要的数据
	local  cmType    = self.baseSelf.areaTable["climax_type"]
	local  cmId      = self.baseSelf.areaTable["climax_id"] 
	local  cmNum     = self.baseSelf.areaTable["climax_num"]
	print(" cmType cmType == "..cmType)
	print(" cmId cmId  == "..cmId )
	--取出图片
	local  cmBtn     = self.baseSelf.rootNode:getChildByName("Image_climax")
	if cmType == 0 and cmId == 0 then
		cmBtn:setVisible(false)
		return
	end
	local  cmTable   = astrolabe_climax[cmType][cmId]

	
	--或取服务器的状态
	local  climax  =  self.baseSelf.serverData["climax"]
	-- 与的判断
	-- 与的条件达成 在根据服务器状态显示图片
	local climaxB  = self.baseSelf:andTrue(self.baseSelf.areaTable["climax_unlock"])
	if climaxB then
		if climax == 1 then
			cmBtn:loadTexture(cmTable["icon_checked"])
		else
			cmBtn:loadTexture(cmTable["icon_unlock"])
		end
	else
		cmBtn:loadTexture(cmTable["icon_locked"])
	end
	
	self:setMarkImage()
end
--在缩略图中 ID是不需要点击事件的
function AstrolabeAreaScal:setEnableFales( ... )
	-- body
	for i = 1,self.baseSelf.len do
		local imageChild = self.baseSelf.rootNode:getChildByName("Image_"..i)
		imageChild:setTouchEnabled(false)
    end

end
--显示缩略图 和主星盘不同的地方
function AstrolabeAreaScal:scalShowScalEx( ... )
	--等于true是达到解锁条件。
	local climaxB  = self.baseSelf:andTrue(self.baseSelf.areaTable["astro_unlock"])
	local state  =  self.baseSelf.serverData["state"]
	print("statestatestatestatestate == "..state)
	-- 如果达到解锁条件
	if climaxB then
		-- state 0没有解锁  1 解锁
		if state == 0 then
			self.baseSelf.panelLock:setVisible(true)
		elseif state == 1 then
			self.baseSelf.panelLock:setVisible(false)
		end
	else -- 没有达到条件
		self.baseSelf.panelLock:setVisible(true)
	end
	-- 如果没未解锁点击的是 未解锁的panel
	-- 解锁就是点击自己  此处判断就是按钮的一个转换
	local panelBtn = self.baseSelf.rootNode:getChildByName("Panel_lock")
	--panelBtn:setTouchEnabled(true)
	local rtNd     = self.baseSelf.rootNode
	local changeBtn = nil
	if state == 0 then
		changeBtn = panelBtn
	elseif state == 1 then
		changeBtn = rtNd
	end
	changeBtn:addClickEventListener(function()
		--添加点击的音效
		--self:playSpin()
		self:playMusicBtn()
        self:scalToucClick(climaxB,state)
    end)
	
end
function AstrolabeAreaScal:playMusicBtn( ... )
	
    self.m_AudoId =  AudioManager:shareDataManager():playMusic("music/ui/touchlong.mp3", 2,false)
      

end
--提示弹窗最多显示3个
function AstrolabeAreaScal:scalToucClick( climaxB,state )
	local isfull = self.baseSelf.serverData["star_up_enabled"]
	--其他属性
	local strTable  = self:scalAsbLockStr(self.baseSelf.areaTable["astro_unlock"])
	--等级
	local strTable1 = self:scalAsbLockStrLv(self.baseSelf.areaTable["astro_unlock"])
	--是加满
	local strTable2 = self:scalAsbLockStrSkill(self.baseSelf.curAreaIndex,isfull)
	--icon
	local icon      = self.baseSelf.areaTable["icon_small"]
	--bg
	local imBg      = self.baseSelf.areaTable["ui_msg_bg"]
	if climaxB then
		--isfull 0技能点没有全部加满
		if isfull == 1 then 
			-- state 0没有解锁  1 解锁
			if state == 0 then
				MsgManager:shwoAstrolabeBox( self,1,self.saclLockCall,strTable,strTable1,strTable2,imBg,icon)
			elseif state == 1 then
				--print("已经解锁 todo 主星盘")
				local sData = {}
				sData["curAreaIndex"]       = self.baseSelf.curAreaIndex
				sData["refreshCallFunc"]    = self.baseSelf.refreshCallFunc 
				sData["roleData"]           = self.baseSelf.roleData
				sData["hero_id"]            = self.baseSelf.hero_id
				sData["severData"]          = self.baseSelf.rcvData
				sData["newRoleStarSelf"]    = self.baseSelf.newRoleStarSelf
				SceneManager:toAstrolabeMainLayer(sData)
			end
		else
			MsgManager:shwoAstrolabeBox( self,0,nil,strTable,strTable1,strTable2,imBg,icon)
		end
	else -- 没有达到条件
			MsgManager:shwoAstrolabeBox( self,0,nil,strTable,strTable1,strTable2,imBg,icon)--str1,color1,str2,color2,str3,color3
	end
end
--[[
	缩略图解锁
	缩略图解锁和服务器同步 （但不需要使用服务器返回的数据）
	成功会对详情界面刷新，详情里边也有星盘数据
]]
function AstrolabeAreaScal:saclLockCall( ... )
	-- --[[]]
	local tempData = { 
        rpc = "hero_astrolabe_area_unlock",
        hero_id = self.baseSelf.hero_id,
        area_id = self.baseSelf.areaTable["astro_id"],
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        self.baseSelf.panelLock:setVisible(false)
        self:playSpin()
        
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
           
        end)
    end,
    true)
	
	--self.baseSelf.refreshData(self.baseSelf.newRoleStarSelf)
end
function AstrolabeAreaScal:playSpin( ... )
	local spineRoot = self.baseSelf.newRoleStarSelf.panel_spin
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
        self.skeletonNode = nil
    end 
	local id_str = "res/uifile/n_UIShare/astrolabe/xing_pan_jie_suo/xing_pan_jie_suo.atlas"--title_conf[tonumber(item_id)].res_spine
	if cc.FileUtils:getInstance():isFileExist(id_str) then 
	   	self.skeletonNode = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(id_str))
	   	local size = spineRoot:getSize()
		self.skeletonNode:setPosition(size.width/2+2,size.height/2)
		self.skeletonNode:registerSpineEventHandler(
		    function (event) 
		        self.baseSelf.refreshCallFunc(self.baseSelf.newRoleStarSelf)
		end, sp.EventType.ANIMATION_END)
		
	  	spineRoot:addChild(self.skeletonNode,123)
		self.skeletonNode:addAnimation(1,"effect",false)
		
	else 
	      print("文件不存在 error file not exist:"..id_str)
	end
	
end
--多属性的判断 注视调预留 以防后期改回来
-- function AstrolabeAreaScal:scalAsbLockStr( _tabel )
-- 	-- body
-- 	local andTable = _tabel
-- 	local index = 0
-- 	local strTable = {}
-- 	if  andTable.hero_lv  > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_lv,andTable.hero_lv)
-- 		strTable[index]["str"] = desc_info[2000]..andTable.hero_lv
-- 	end
-- 	if andTable.hero_add > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_add,andTable.hero_add)
-- 		strTable[index]["str"] = desc_info[2001]..andTable.hero_add
-- 	end
-- 	if andTable.feeling_lv > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.feeling_lv,andTable.feeling_lv)
-- 		strTable[index]["str"] = desc_info[2002]..andTable.feeling_lv
-- 	end
-- 	if andTable.soul_lv > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.soul_lv,andTable.soul_lv)
-- 		strTable[index]["str"] = desc_info[2003]..andTable.soul_lv
-- 	end
-- 	if andTable.astro_lv > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.rcvData["astrolabe"]["lv"],andTable.astro_lv)
-- 		strTable[index]["str"] = desc_info[2004]..andTable.astro_lv
-- 	end
-- 	if andTable.hero_sk_add > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_sk_add,andTable.hero_sk_add)
-- 		strTable[index]["str"] = desc_info[2005]..andTable.hero_sk_add
-- 	end
-- 	if andTable.astro_sk_add > 0 then
-- 		index = index+1
-- 		strTable[index] = {}
-- 		strTable[index]["color"] = self:scalGetTextColor( self.baseSelf.rcvData["astrolabe"]["used_items"],andTable.astro_sk_add)
-- 		strTable[index]["str"] = desc_info[2006]..andTable.astro_sk_add
-- 	end
-- 	return strTable
 
-- end
--等级是否达成
function AstrolabeAreaScal:scalAsbLockStrLv( _tabel )
	local andTable = _tabel
	local strTable = {}
	if  andTable.astro_lv  > 0 then

		strTable["color"] = self:scalGetTextColor(self.baseSelf.rcvData["astrolabe"]["lv"],andTable.astro_lv)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2004]),andTable.astro_lv)
		return strTable
	end
	return nil
end
--每区的技能点是否加满
function AstrolabeAreaScal:scalAsbLockStrSkill(areaIndex,isfull)
	local  isfull = isfull
	local hero_sub_id = getNumID(self.baseSelf.hero_id)--self.baseSelf.areaTable["name"]
	if self.baseSelf.curAreaIndex == 1 then --等于1 一区不需要此条件
		return nil
	else
	
		local str     = hero_astrolabe[hero_sub_id]["areas"][self.baseSelf.curAreaIndex-1]["name"]

		--local catstr = UITool.ToLocalization("解锁%s所有属性")..UITool.getUserLanguage(str)..UITool.ToLocalization("所有属性")
		local catstr = string.format(UITool.ToLocalization("解锁%s所有属性"),UITool.getUserLanguage(str))
		local strTable = {}
		if isfull == 0 then
			strTable["color"] = cc.c3b(197, 37, 37)
		else
			strTable["color"] = cc.c3b(255, 231, 145)
		end
		strTable["str"] = catstr
		return strTable
	end
end
--其他属性
function AstrolabeAreaScal:scalAsbLockStr( _tabel )
	-- body
	local andTable = _tabel

	local strTable = {}
	if andTable.hero_lv > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_lv,andTable.hero_lv)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2000]),andTable.hero_lv)
		return strTable
	end

	if andTable.hero_add > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_add,andTable.hero_add)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2001]),andTable.hero_add)
		return strTable
	end
	if andTable.feeling_lv > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.roleData.feeling_lv,andTable.feeling_lv)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2002]),andTable.feeling_lv)
		return strTable
	end
	if andTable.soul_lv > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.roleData.soul_lv,andTable.soul_lv)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2003]),andTable.soul_lv)
		return strTable
	end
	if andTable.astro_lv > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.rcvData["astrolabe"]["lv"],andTable.astro_lv)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2004]),andTable.astro_lv) 
		return strTable
	end
	if andTable.hero_sk_add > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.roleData.hero_sk_add,andTable.hero_sk_add)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2005]),andTable.hero_sk_add)
		return strTable
	end
	if andTable.astro_sk_add > 0 then
		strTable["color"] = self:scalGetTextColor( self.baseSelf.rcvData["astrolabe"]["used_items"],andTable.astro_sk_add)
		strTable["str"] = string.format(UITool.getUserLanguage(desc_info[2006]),andTable.astro_sk_add)
		return strTable
	end
	return nil
 
end
function AstrolabeAreaScal:scalGetTextColor( a,b )
	-- body
	if a < b then
		return cc.c3b(197, 37, 37)
	else
		return cc.c3b(255, 231, 145)
	end
end







