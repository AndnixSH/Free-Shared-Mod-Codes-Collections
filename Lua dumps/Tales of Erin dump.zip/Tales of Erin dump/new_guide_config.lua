
----触发引导类型
unlock_type_01 = 1    --触发 玩家技能   	rank等级 2
unlock_type_02 = 2    --触发 装备 		rank等级 3
unlock_type_03 = 3    --触发 神格 		rank等级 4
unlock_type_04 = 4    --触发 起名字 		rank等级 5
unlock_type_05 = 5    --灵装强化			rank等级 6
unlock_type_06 = 6    --商店：道具屋，神秘商店，商店：苍玉兑换 rank等级 8
unlock_type_07 = 7    --角色强化
unlock_type_08 = 8    --公会基础功能，公会BUFF
unlock_type_09 = 9    --灵装融合
unlock_type_10 = 10   --星界探索
unlock_type_11 = 11   --公会塔
unlock_type_12 = 12   --铸造功能
unlock_type_13 = 13   --多人战斗
unlock_type_14 = 14   --角色突破         rank等级 16
unlock_type_15 = 15   --灵装突破 			rank等级 17
unlock_type_16 = 16   --大型活动标签按钮  	rank等级 18
unlock_type_17 = 17   --试炼按钮   		rank等级 19
unlock_type_18 = 18   --试炼按钮   		rank等级 19

---强制引导ID 3、4 ---触发引导ID 5-21
guide_id_config = {}
guide_id_config.ThatCard = 3 --抽卡
guide_id_config.Team = 4 --编队
guide_id_config.FB = 5 --第一场战斗
guide_id_config.SB = 6 --第二场战斗

guide_id_config.StHero = 7   --角色强化
guide_id_config.RoleSkill = 8 --角色技能提升
guide_id_config.Equipment = 9 --装备引导ID
guide_id_config.Godhead = 10  --女主神格
guide_id_config.NewName = 11--起名字引导
guide_id_config.StEquip = 12    --灵装强化
guide_id_config.Shop = 13    --商店：道具屋，神秘商店

guide_id_config.Guild = 14   --公会基础功能
guide_id_config.Equip2 = 15   --灵装融合
guide_id_config.Explore = 16   --星界探索
guide_id_config.GuildTower = 17   --公会塔
guide_id_config.Casting = 18   --铸造功能
guide_id_config.MoreBattle = 19    --多人战斗
guide_id_config.HeroBT = 20    --角色突破   
guide_id_config.EquipBT = 21   --灵装突破 
guide_id_config.Act = 22    --大型活动
guide_id_config.Trial = 23   --试炼按钮  
guide_id_config.HeiCao = 24  --黑潮遗迹

----用于小红点的key
RedDotPromptKey = {}
RedDotPromptKey = {
	FristBattle = "CCUD_FristBattle",--第一次战斗胜利
	FristTeam = "CCUD_FristTeam",--第一次编队
	RoleSkill = "CCUD_RoleSkill",  	--队伍按钮，角色一览按钮，角色列表的角色图标，角色详情技能标签。
	Godhead = "CCUD_Godhead",      	--队伍按钮，神格按钮
	KRelics = "CCUD_KRelics",       --黑潮遗迹按钮。
	StEquip = "CCUD_StEquip",       --灵装按钮，灵装强化标签

	StHero = "CCUD_StHero",			--队伍按钮，角色强化标签
	Guild = "CCUD_Guild",       	--公会按钮
	Equip2 = "CCUD_Equip2", 		--灵装融合
	Explore = "CCUD_Explore",    	--星界探索
	GuildTower = "CCUD_GuildTower",	--公会按钮，公会塔按钮
	Casting = "CCUD_Casting",		--工坊按钮
	MoreBattle = "CCUD_MoreBattle", --多人战斗
	HeroBT = "CCUD_HeroBT",   		--队伍按钮，角色潜能解放标签
	EquipBT = "CCUD_EquipBT",		--灵装按钮。灵装突破标签
	Act = "CCUD_Act",				--大型活动		
	Trial = "CCUD_Trial",			--试炼按钮。

	Shop_1  = "CCUD_Shop_1",		--商店按钮，道具屋标签，神秘商店标签，苍玉兑换标签。
	Shop_2  = "CCUD_Shop_2",		--商店按钮，道具屋标签，神秘商店标签，苍玉兑换标签。
	Shop_3  = "CCUD_Shop_3",		--商店按钮，道具屋标签，神秘商店标签，苍玉兑换标签。
	Shop_4  = "CCUD_Shop_4",		--商店按钮，道具屋标签，神秘商店标签，苍玉兑换标签。
}

--这个用于解锁类型 获取所需要的引导ID
guide_ids = { 
    guide_id_config.RoleSkill, 	--1  玩家技能 
    guide_id_config.Equipment, 	--2  装备  9级
    guide_id_config.Godhead,   	--3  神格   5级
    guide_id_config.NewName,   	--4  起名字 7级
    guide_id_config.StEquip,  	--5  灵装强化
	guide_id_config.SMSHOP,  	--6  改成角色突破和试炼之地 13级 神秘商店
	guide_id_config.StHero,  	--7  角色强化  9级解锁
	guide_id_config.Guild, 		--8  公会基础功能 10级解锁
	guide_id_config.Equip2, 	--9  灵装融合
	guide_id_config.Explore,  	--10 星界探索  17级解锁
	guide_id_config.GuildTower, --11 公会塔
	guide_id_config.Casting,  	--12 铸造功能
	guide_id_config.MoreBattle, --13 多人战斗  12级
	guide_id_config.HeroBT, 	--14 角色突破   
	guide_id_config.EquipBT,  	--15 灵装突破 
	guide_id_config.Act,  		--16 大型活动
	guide_id_config.Trial, 		--17 试炼按钮  
	guide_id_config.HeiCao 		--18 黑潮遗迹  18级解锁 
 }
---等级开启表
--这里按照 类名处理吧，按钮的隐藏实在不好整 
--目前是 一级二级页面 用 表判断 ，三级、弹窗 跳转判断用 常量判断
--大的模块定义个字段吧 涉及到界面跳转时候的判断

UnlockMaxRank = 19  ---20级之后就不锁按钮了

UnlockExploreRank = 17   	--解锁星界大模块的等级
UnlockCastingRank = 16   	--解锁铸造大模块的等级
UnlockMoreBattleRank = 12   --解锁多人战斗的等级
UnlockGuildTowerRank = 10   --解锁公会塔的等级
UnlockEquipSKill = 9  --灵装融合
UnlockEquipSth = 9		--灵装强化
UnlockEquipAwaken = 9	--灵装突破
UnlockShopCangyuRank = 1  	--苍玉兑换
UnlockRoleSthRank = 3  		--角色强化
UnlockRoleAwakenRank = 14  	--角色突破（潜能解放）
UnlockGodheadRank = 5    	--女主神格
UnlockKRelicsRank = 18   	--黑潮遗迹
UnlockGuildRank = 10  		--公会按钮介绍
UnlockGongFangRank = 14  	--工坊按钮
UnlockTrialRank = 13  --试炼之地 解锁等级
UnlockMysteryShopRank = 13 --商店里面的神秘商店
UnlockItemShopRank = 1 --道具屋
UnlockGongGaoRank = 7  -- 这个是 公告按钮，邮箱按钮，累计登陆奖励按钮，任务按钮，信息按钮。
UnlockMainEquipmentRank  =  9 --主页灵装开启按钮
--
UnlockRoleInfoSoulRank  =  15 --角色详情魂灵装开启按钮
UnlockRoleInfoStarRank  =  35 --角色详情星盘开启按钮

UnlockMainActRank = 12  --大型活动开启等级

UnlockAstrolabeLevelRank = 35  --区域地图，星盘关卡开启等级

guide_rank_config = {}
----说明 下面这种方式很依赖 节点数组顺序。方便处理 连续tag值 ，如果是不连续的建议 自己写个数组，吧tag按照顺序塞进去
guide_rank_config["StartLayer"] = {
	{   --这个是 公告按钮，邮箱按钮，累计登陆奖励按钮，任务按钮，信息按钮。
		unlock_level = UnlockGongGaoRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
		effect = 0,  --解锁特效
	},
	----下方按钮群
	{   --队伍
		unlock_level = 1,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）101
		effect = 0,  --解锁特效
	},
	{   --灵装
		unlock_level = UnlockMainEquipmentRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）102
		effect = 0,  --解锁特效
		btn_name = "btn_lz",
	},
	{   --工坊
		unlock_level = UnlockGongFangRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）103
		effect = 1,  --解锁特效
		btn_name = "btn_gf"
	},
	{   --召唤
		unlock_level = 1,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）104
		effect = 0,  --解锁特效
	},
	{	--商店
		unlock_level = 8,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）105、
		effect = 0,  --解锁特效
	},
	{	--公会
		unlock_level = UnlockGuildRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）106
		effect = 1,  --解锁特效
		btn_name = "btn_gh"
	},
	{	--大型战斗
		unlock_level = UnlockMoreBattleRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）107
		effect = 0,  --解锁特效
	},
	---左侧按钮
	{	--出征    401
		unlock_level = 1,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--试炼之地  402 (素材本)
		unlock_level = UnlockTrialRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
		effect = 0,  --解锁特效
		btn_name = "btn_sl"
	},

	{	--星界探索 403 
		unlock_level = UnlockExploreRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
		effect = 1,  --解锁特效
		btn_name = "btn_xj"
	},

	-- {	--大型活动  404
	-- 	unlock_level = 1,
	-- 	state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	-- },
	{	--黑潮遗迹按钮 点点合战 405
		unlock_level = UnlockKRelicsRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
		effect = 1,  --解锁特效
		btn_name = "btn_hc"
	},
	{	--排行榜改成成就，成就改成7即解锁
		unlock_level = 7,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
		effect = 1,  --解锁特效
		btn_name = "btn_ph"
	},
}
----队伍主页面 的按钮隐藏情况
guide_rank_config["RoleMainView"] = {
	{	-- btnTab2  角色强化
		unlock_level = UnlockRoleSthRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--btnTab3  潜能解放按钮
		unlock_level = UnlockRoleAwakenRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--编队界面
guide_rank_config["RoleTeamView"] = {
	{	--  self.btnPSKill 神格按钮
		unlock_level = UnlockGodheadRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--角色详情页面
guide_rank_config["RoleInfoView"] = {
	{	-- btnTab2技能按钮
		unlock_level = 1,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--  btnTab3装备按钮
		unlock_level = UnlockMainEquipmentRank,  --九级可以穿装备
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--  btnTab4星盘按钮
		unlock_level = UnlockRoleInfoStarRank,  --15级可以开启星盘
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--  btnTab5魂灵装按钮
		unlock_level = UnlockRoleInfoSoulRank,  --15级可以开启魂灵装
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--角色详情页面的装备子页面
guide_rank_config["RoleInfoView_Equip"] = {
	{	-- eqBtnSkill
		unlock_level = UnlockEquipSKill,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--  eqBtnSth
		unlock_level = UnlockEquipSth,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--  eqBtnAwaken
		unlock_level = UnlockEquipAwaken,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--灵装主页
guide_rank_config["EquipMainView"] = {
	{	--btnTab1  --融合
		unlock_level = UnlockEquipSKill,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--btnTab2 --强化 
		unlock_level = UnlockEquipSth,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--btnTab3  --突破
		unlock_level = UnlockEquipAwaken,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--商店主页面
guide_rank_config["ShopLayer"] = {
	{	--道具屋
		unlock_level = UnlockItemShopRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--秘密商店 
		unlock_level = UnlockMysteryShopRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--苍郁兑换
		unlock_level = UnlockShopCangyuRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--抽卡界面
guide_rank_config["GachaView"] = {
	{	--苍玉兑换
		unlock_level = UnlockShopCangyuRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}
--战后结算
guide_rank_config["BattleFailedLayer"] = {
	{	--前往角色
		unlock_level = UnlockRoleSthRank,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
	{	--前往灵装
		unlock_level = UnlockEquipSth,
		state = 0,    --0 隐藏  1 解锁状态（禁用状态）
	},
}