require "BasicLayer"

ReadyLayer = class("ReadyLayer",BasicLayer)
ReadyLayer.__index = ReadyLayer
ReadyLayer.lClass = 1

ReadyLayer.teamIdx = nil 
ReadyLayer.ReadImage = nil
ReadyLayer.isOk      = false

function ReadyLayer:init()
    self.teamNodes = {} --存储队伍的父节点
    self.teamIdx  = nil  --当前选中的第几个队伍
    self.isFirstGetHeroList = true --第一次获取hero_list
    local node =cc.CSLoader:createNode("ReadyLayer.csb")
    self.uiLayer:addChild(node,0,1)

    local touchEventTable = {
     [121] = self.beginCallBack,
     [122] = self.returnBack,
     [123] = self.formationCallBack,
     [124] = self.rightCallBack,
     [125] = self.leftCallBack,
    }

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            touchEventTable[sender:getTag()](self)
        end
    end 

    local panel_1 = node:getChildByTag(1)
    self.buffNode = ccui.Helper:seekWidgetByName(panel_1,"buff_node")
    self.panelLabels = ccui.Helper:seekWidgetByName(panel_1,"panelLabels")

    self.dropLabels = nil
    local strs = nil
    self.dropLabels = XUILabelView:init(self.panelLabels,strs)

    for i=1,5 do 
       local button = ccui.Helper:seekWidgetByTag(panel_1,120+i)
       button:addTouchEventListener(touchCallBack)
        if i==2 then 
            button:setEffectType(3)
        end  
    end 
    self.ReadImage = panel_1
    self:initTeam()
    --------------------------新手引导----------------------------
    local newGuide = user_info["guide_id"]
    if newGuide == guide_id_config.FB  then
        NewGuideManager:startSubGuide(self, 4)
    end
    ----------------------------------------------------------
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
        self:returnBack()
    end)

    self:refreshRightAndLeftState()

    self:loadDropAddInfo()
  
end 

function ReadyLayer:initTeam()
   self.teamIdx = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
   if self.teamIdx==nil or self.teamIdx<1 then  --判断是否是第一次
         self.teamIdx = 1 
   end

   local node = self.uiLayer:getChildByTag(1)
   local panel_1 = node:getChildByTag(1)
   local root_panel = panel_1
   local dataTable = {}
   if g_channel_control.b_newRole then
        dataTable = {
            [141] = team_list[""..self.teamIdx]["team_name"],
            [142] = self.rData["rcvData"]["name"], --名字
            [143] = "Lv."..self.rData["rcvData"]["lv"], --Lv
            [144] = self.rData["rcvData"]["ap"] --user_info["ap"], --ap
            --[145] = " ", --色子
            --[146] = " ", --战斗力
        }
   else
        dataTable = {
            [141] = UITool.ToLocalization("第")..self.teamIdx..UITool.ToLocalization("编队"), --第一编队
            [142] = self.rData["rcvData"]["name"], --名字
            [143] = "Lv."..self.rData["rcvData"]["lv"], --Lv
            [144] = self.rData["rcvData"]["ap"] --user_info["ap"], --ap
            --[145] = " ", --色子
            --[146] = " ", --战斗力
        }
   end
    --- 队伍的战斗力 和消耗的ap
    local bgAp  = ccui.Helper:seekWidgetByTag(root_panel,300)
    local needApBg = ccui.Helper:seekWidgetByName(root_panel,"need_ap_bg")
    local needApLab = ccui.Helper:seekWidgetByName(root_panel,"need_ap")
    needApBg:setVisible(false)
     --需要ap
    if self.rData["rcvData"]["ap"] ~= nil then 
        local needApValue = tonumber(self.rData["rcvData"]["ap"])
        if  needApValue > 0 then 
            needApLab:setString(self.rData["rcvData"]["ap"])
            needApBg:setVisible(true)
            needApBg:loadTexture("n_UIShare/Nready/zqzb_ui_099.png")

            --因为没有星光之尘的图片资源   星盘关卡暂时隐藏needApBg minyou
            if self.rData["rcvData"] and self.rData["rcvData"]["b_id"] then
                local battle_id = self.rData["rcvData"]["b_id"]
                local flag = string.sub(battle_id,1,1)
                --flag 为k表示星盘关卡
                if flag == "k" then
                    needApBg:setVisible(false)
                else
                    needApBg:setVisible(true)
                end
            end
        end 
    end 
    --需要金币
    if self.rData["rcvData"]["gold"] ~= nil then 
        local needApValue = tonumber(self.rData["rcvData"]["gold"])
        if  needApValue > 0 then 
            needApLab:setString(self.rData["rcvData"]["gold"])
            needApBg:setVisible(true)
            needApBg:loadTexture("n_UIShare/Nready/zqzb_ui_098.png")
        end 
    end 
   
    self._fp = bgAp:getChildByTag(303)-- 战斗力

    for i =1,3 do 
         local text = ccui.Helper:seekWidgetByTag(panel_1,140+i)
         text:setString(dataTable[140+i])
    end 

    local function pageViewEvent(sender, eventType)
        if eventType == ccui.PageViewEventType.turning then
            local pageView = sender
            self.teamIdx =  pageView:getCurrentPageIndex() + 1
            local text = ccui.Helper:seekWidgetByTag(panel_1,141)
            if g_channel_control.b_newRole then
                text:setString(UITool.ToLocalization(team_list[""..self.teamIdx]["team_name"]))
            else
                text:setString(UITool.ToLocalization("第")..self.teamIdx..UITool.ToLocalization("编队"))
            end
            local bgAp  = ccui.Helper:seekWidgetByTag(root_panel,300)
            local fp = bgAp:getChildByTag(303)
            fp:setString(""..team_list[tostring(self.teamIdx)]["team_fp"])
            self:refreshRightAndLeftState()
            cc.UserDefault:getInstance():setIntegerForKey("teamIdx", self.teamIdx)
        end
    end 

    local pageView = ccui.Helper:seekWidgetByTag(panel_1,171)
    pageView:addEventListener(pageViewEvent)
    self.teamNodes = {}
    for i = 1,5 do  
        local layout = ccui.Layout:create()
        local node =cc.CSLoader:createNode("TeamPage_2.csb")
        local panel_1_2 = node:getChildByTag(1)
        panel_1_2:setSwallowTouches(false)
        self.teamNodes[i] = panel_1_2
        --左侧公主信息
        local oid =  team_list[tostring(i)]["ps"]  --公主职业id
        if oid ~= nil then 
            local end_pos = string.find(oid,'_') - 1
            local id = string.sub(oid,0,end_pos)

            local gid = id  --流派id

            print("流派Id == "..gid)
            print("公主的职业ID == "..oid)
            local imageView = ccui.Helper:seekWidgetByTag(panel_1_2,105)  --职业立绘
            imageView:setUnifySizeEnabled(true)
            imageView:loadTexture(princess_ocp[gid][oid]["ps_vdraw"])

            local texName   = ccui.Helper:seekWidgetByTag(self.ReadImage,200)  -- 女主名字
            texName:setString(UITool.getUserLanguage(princess_ocp[gid]["p_name"]))

            local Lv = ccui.Helper:seekWidgetByTag(self.ReadImage,87)   -- 公主的等级
            -- Lv:setString("LV."..user_info["princess"][oid]["Lv"])
         end 

        self:updateTeamHero(panel_1_2,i)

        node:setPosition(cc.p(panel_1_2:getContentSize().width/2 ,panel_1_2:getContentSize().height/2 ))
        layout:addChild(node,0,1)
        pageView:addPage(layout)
    end 

    pageView:setCurrentPageIndex(self.teamIdx-1)
    local text = ccui.Helper:seekWidgetByTag(panel_1,141)
    if g_channel_control.b_newRole then
        text:setString(UITool.ToLocalization(team_list[""..self.teamIdx]["team_name"]))
    else
        text:setString(UITool.ToLocalization("第")..self.teamIdx..UITool.ToLocalization("编队"))
    end
    local bgAp  = ccui.Helper:seekWidgetByTag(root_panel,300)
    local fp = bgAp:getChildByTag(303)
    fp:setString(""..team_list[tostring(self.teamIdx)]["team_fp"])
end 

--刷新队伍的信息（除女主外）
function ReadyLayer:updateTeamHero(root,teamIndex)
    self._fp:setString(""..team_list[tostring(self.teamIdx)]["team_fp"])
    local dropAddNum = 0
    for j=1,4 do 
        local addImg = ccui.Helper:seekWidgetByName(root,"img_add_"..j) --加号按钮
        local teamBgImg = ccui.Helper:seekWidgetByTag(root,100+j)       --hero csb 背景节点
        local oldChild = teamBgImg:getChildByTag(1) --
        if oldChild then 
            oldChild:removeFromParent()
        end 
        addImg:setVisible(true)
        --将界面设置为没有的状态
        local imageProBg = ccui.Helper:seekWidgetByTag(root,300+j)   --获取TeamPage_2 里面控件 Image
        local lv  = imageProBg:getChildByName("Text_1")
        lv:setString("0")
        local Atk = imageProBg:getChildByName("Text_2")
        Atk:setString("0")
        local HP = imageProBg:getChildByName("Text_3")
        HP:setString("0")
        local teamData = team_list[tostring(teamIndex)]["team"]
        local heroData = teamData[j]
        if teamData~=nil then
            if heroData~=nil and heroData["id"]~= "0" then
                local node = cc.CSLoader:createNode("RoleCard_3.csb")
                if node == nil then
                    return
                end
                local panel_1 = node:getChildByTag(1)
                panel_1:setSwallowTouches(false)

                local h_id_num = getNumID( heroData["id"] )
                local heroId = heroData["id"]
                print("现在队伍的角色Id =="..heroData["id"])

                local imageProBg = ccui.Helper:seekWidgetByTag(root,300+j)   --获取TeamPage_2 里面控件 Image
                local lv = imageProBg:getChildByName("Text_1")
                lv:setString(heroData["Lv"])
                local Atk = imageProBg:getChildByName("Text_2")
                Atk:setString(heroData["atk"])

                local HP = imageProBg:getChildByName("Text_3")
                HP:setString(heroData["hp"])

                local dataTable = {
                  [101] = hero[h_id_num].hero_team_icon, --图片
                  [102] = getEquipAtb(hero[h_id_num].hero_atb) ,--getRoleAtb(hero[h_id_num].hero_atb), --属性
                  [103] = Rarity_Hero_Frame[hero[h_id_num].hero_rank],--外框
                  [104] = Rarity_Team_BG[hero[h_id_num].hero_rank],--背景
                }

                for i=1,4 do
                     local imageView = ccui.Helper:seekWidgetByTag(panel_1,100+i)
                     imageView:setUnifySizeEnabled(true)
                     imageView:loadTexture(dataTable[100+i])
                end

                if g_channel_control.b_LikeState then
                    local imgIntimacy = panel_1:getChildByTag(249)
                    imgIntimacy:setVisible(true)
                    local intimacyState = heroData["like_feel_state"]["icon_state"]
                    local intimacy = like_state[intimacyState].icon_min --亲密度
                    if intimacy then
                        imgIntimacy:setTexture(intimacy)
                    end
                end

                local imgHasAddDrop = panel_1:getChildByTag(111)
                local bHasAddDrop = self:HasAddDrop(h_id_num)
                if bHasAddDrop then
                    imgHasAddDrop:setVisible(true)
                else
                    imgHasAddDrop:setVisible(false)
                end

                addImg:setVisible(false)
                teamBgImg:addChild(node,0,1)
                --
                if self:HasAddDrop(h_id_num) then
                    dropAddNum = dropAddNum + 1
                end
            end
        end
        --队伍编辑按钮
        local function touchCallBack(sender,eventType)
            if eventType == ccui.TouchEventType.ended then

                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()
                local l = cc.pGetDistance(p1,p2)
                if l < 30 then
                    self:dealTeamHerdTouch(j)
                end

            end
        end
        teamBgImg:addTouchEventListener(touchCallBack)
        teamBgImg:setSwallowTouches(false)
    end
    --
    if self.teamIdx == teamIndex then
        if dropAddNum > 0 then
            local strs = {}
            strs[1] = string.format(UITool.ToLocalization("额外宝箱掉落：%d"),dropAddNum)
            if self.dropLabels then
                self.dropLabels:resetStrInfo(strs)
            end
        else
            local strs = {}
            strs[1] = ""
            if self.dropLabels then
                self.dropLabels:resetStrInfo(strs)
            end
        end
    end
end

--角色是否有加成掉落
function ReadyLayer:HasAddDrop(nHeroId)
    if self.drop_info_list == nil then
        return false
    else
        local dropData = table.deepcopy(self.drop_info_list)
        for k,v in pairs(dropData) do
            print(k,v)
            local tempHeroList = v.hero_list
            for j=1,#tempHeroList do
                if tempHeroList[j] == nHeroId then
                    return true
                end
            end
        end
        -- for i=1,#dropData do
        --     local tempHeroList = dropData[i].hero_list
        --     for j=1,#tempHeroList do
        --         if tempHeroList[j] == nHeroId then
        --             return true
        --         end
        --     end
        -- end
        return false
    end
end

--掉落加成信息获取
function ReadyLayer:loadDropAddInfo()
    -- local data = {}
    -- local testlist = {}
    -- testlist = {13,37}
    -- data.info = {}
    -- data.info[1] = testlist
    -- self.drop_info_list = nil
    -- self.drop_info_list = table.deepcopy(data.info)
    -- self:refreshNowTeam()
    if self.rData["rcvData"] and self.rData["rcvData"]["b_id"] == nil then
        return
    end
    local temp_data = {}
    temp_data["rpc"] = "point_ex_drop_heroes"
    temp_data["point_id"] = self.rData["rcvData"]["b_id"]

    GameManagerInst:rpc(temp_data,3,
    function(data)
        --success
        --
        if self.exist == false then
            return
        end
        self.drop_info_list = nil
        self.drop_info_list = table.deepcopy(data.info)
        self:refreshNowTeam()
    end,
    function(state_code,msgText)
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

--刷新当前队伍
function ReadyLayer:refreshNowTeam()
    local idx = self.teamIdx
    self:updateTeamHero(self.teamNodes[tonumber(idx)], self.teamIdx)
end
---subIndex 点的第几个
--user_info["hero"] --datamanager保存的hero数据
function ReadyLayer:dealTeamHerdTouch(subIndex)
    if self.isFirstGetHeroList then 
        GameManagerInst:rpc("{\"rpc\":\"hero_list\"}",3,
        function(data)
            --success
            if self.exist == false then
              return
            end
            self.isFirstGetHeroList = false
            DataManager:wAllHeroData(data["hero_list"])
            DataManager:wAllBagData({mat = data["mat"]})
            self:ItemAdd(subIndex)
        end,
        function(state_code,msgText)
            if self.exist == false then
              return
            end
            GameManagerInst:alert(msgText)
        end,
        true)
    else 
        self:ItemAdd(subIndex)
    end 
end

function ReadyLayer:ItemAdd(index)  

    local b,v = RoleListView.createWithBackBtn()
    v.ItemClickedEvent = function(item)
        self:onEditTeam(index,item:getData().id)
        b:returnBack()
    end

    v.ItemResetEvent = function(item)
        local rdata = item:getData()
        if rdata.isCurrentRole then
            --当前点中的人
            item:showOutTeam()
        end
    end
    v.dataSourceEvent = function(sender,sort_mode)
        local ds = {}
        local outteam = {}       
            
        local temp_data = team_list[""..self.teamIdx]["team"]

        for i = 1,#hero_list do
            local rdata = table.deepcopy(hero_list[i])
            local notInTeam = true

            for j = 1,4 do
                if temp_data[j].id == rdata.id then
                    --在队伍中
                    table.insert(ds,rdata)
                    --当前点中的人
                    rdata.isCurrentRole = (j == index)

                    notInTeam = false
                    break
                end
            end

            if notInTeam then
                rdata.team_list = {}
                table.insert(outteam,rdata)
            end
        end

        SortBoxView.SortRole (ds, sort_mode ,false)
        SortBoxView.SortRole (outteam, sort_mode ,false)

        for i = 1,#outteam do
            table.insert(ds,outteam[i])
        end
        return ds
    end

    if self.drop_info_list ~= nil then
        v:setDropList(self.drop_info_list)
    end

    v:refresh()

    GameManagerInst:showModalView(b)
end

function ReadyLayer:onEditTeam(index,hid)
    local temp_data = team_list[""..self.teamIdx]

    --原始队伍信息
    local teamData = {}
    for i=1,4 do
        teamData[i] = temp_data["team"][i].id
    end    

    local nosame = true

    for i = 1,4 do
        if teamData[i] == hid then
            if i ~= index then
            --点了其他人
                teamData[i] = teamData[index]
                teamData[index] = hid
            else
                --点了自己
                teamData[index] = "0"
            end

            nosame = false
            break
        end
    end

    if nosame then
        teamData[index] = hid
    end

    local temp_team = {}
    temp_team["rpc"] = "team_edit"
    temp_team["team_id"] = self.teamIdx
    temp_team["ps_id"] = temp_data["ps"]
    temp_team["team_info"] = teamData        

    GameManagerInst:rpc(temp_team,3,
    function(data)
        --success
        --第一次编队之后，更改下本地的配置
        if self.exist == false then
              return
            end
        if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam)~=1 then 
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam,1)
        end
        DataManager:wTeamData(data["team"])
        for k,v in pairs(data["change_hero_list"]) do
            user_info["hero"][k] = table.deepcopy(v)
        end   
        DataManager:rfsHlist()
        self:refreshNowTeam()
    end,
    function(state_code,msgText)
        if self.exist == false then
              return
            end
        GameManagerInst:alert(msgText)
    end,
    true)
end
--返回
function ReadyLayer:returnBack()
    self.exist = false
    self:clear()
end

function ReadyLayer:returnBack1( ... )
  -- body
    self.exist = false
    self:clear()
end

--开始战斗
function ReadyLayer:beginCallBack()
    --cc.SimpleAudioEngine:getInstance():playEffect(lua_musci["zdks"], false)
    AudioManager:shareDataManager():playMusic(lua_musci["zdks"],1, false)
    self:reqBattle()
end 

function ReadyLayer:reqBattle()
    local function reicePointCallBack(data)
        print("收到进入战斗结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end

        XbTriggerGuideManager:clearUserUnlockID() ---弱引导清除 解锁状态

        local boss_state = t_data["data"]["boss_state"] or 0
        boss_state = tonumber(boss_state)
        if boss_state == 1 then 
            dump(boss_state)
            KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
            self:returnBack1()
            local sData = {}
            sData["mode"] = 2
            SceneManager:toBattleEndLayer(sData)
            return
        end 
        if boss_state == 2 then 
            dump(boss_state)
            KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
            self:returnBack1()
            local sData = {}
            sData["type"] = 2 -- 1、单人 2、BOSS
            sData["mode"] = 2 -- 1、单人战斗  2、多人战斗
            SceneManager:toBattleFailedLayer(sData)
            return
        end 

             
        if t_data["data"]["warning"]~=nil then
           
           print("warning is="..t_data["data"]["warning"])
        else
          if t_data["data"]["ap"]~=nil then
           user_info["ap"] = t_data["data"]["ap"]
          end
          if t_data["data"]["gold"]~=nil then
           user_info["gold"] = t_data["data"]["gold"]
          end
          self.sManager.menuLayer:RefshTopBar()

           if t_data["data"]["story_before"] ~= "" and t_data["data"]["story_before"] ~=nil then
                KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
               local filename = "story/"..t_data["data"]["story_before"]..".json"
               print("剧情文件名字="..filename)
               self.sData = {}
               self.sData["filename"] = filename 
                if g_channel_control.battleLua then
                    self.sData["battleData"] = t_data["data"]
                end
               self.sManager:toDialogLayer(self.sData)
               self.isOk = true
            else
                self.isOk = true
                GameManagerInst:blackScreenOn()
                 if g_channel_control.battleLua and G_STAGE_TYPE ~= 0 then
                    PushBattleScene(t_data["data"])
                else
                    cc.MyHttpHelper:shareMyHttpHelper():startGame() 
                end
                KeyboardManager:setbattleState(true)

                UITool.delayTask(0.1,function ( ... )
                local scene = cc.Director:getInstance():getRunningScene()
                dump(scene, "ReadyLayer:runningScene    22222")
                    if scene then
                        KeyboardManager:bindingAndroidKeyboard(scene,3)
                    end
                end)


            end
            self:returnBack1()
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
   

    if self.rData["rcvData"]["mode"] == "mutable" then
           local tempTable = {
            ["rpc"] = "multi_create",
            ["multi_sid"] = self.rData["rcvData"]["b_id"],
            ["team_id"] = tostring(self.teamIdx),
        }

         local str = self:checkSk()
         tempTable["check_sk"] = str
         
        local mydata =  cjson.encode(tempTable)
        print("测试 mydata = "..mydata)

        G_STAGE_TYPE = 2

        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
        ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
        if g_channel_control.battleLua then
            dbhttp:creatHttpRequestWithURL(mydata,3)
        else
            dbhttp:creatHttpRequestWithURL(mydata,105)
        end
   elseif self.rData["rcvData"]["mode"] == "mutable1" then
        local tempTable = {
            ["rpc"] = "multi_join",
            ["id"] = self.rData["rcvData"]["b_id"],
            ["team_id"] = tostring(self.teamIdx),
        }
         local str = self:checkSk()
         tempTable["check_sk"] = str
        local mydata =  cjson.encode(tempTable)
        print("测试 mydata = "..mydata)

        G_STAGE_TYPE = 2

        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
        ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
        if g_channel_control.battleLua then
            dbhttp:creatHttpRequestWithURL(mydata,3)
        else
            dbhttp:creatHttpRequestWithURL(mydata,105)
        end

    elseif self.rData["rcvData"]["mode"] == "Battle_Tower" then --道馆战斗（也叫爬塔）
        local tempTable = {
            ["rpc"] = "guild_tower_battle_start",
            ["tower_now"] = self.rData["rcvData"]["tower_now"],
            ["team_id"] = tostring(self.teamIdx),
        }
         local str = self:checkSk()
          tempTable["check_sk"] = str
        local mydata =  cjson.encode(tempTable)
        print("测试 mydata = "..mydata)

        G_STAGE_TYPE = 3

        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
        ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
        if g_channel_control.battleLua then
            dbhttp:creatHttpRequestWithURL(mydata,3)
        else
            dbhttp:creatHttpRequestWithURL(mydata,106)
        end
    else
        local tempTable = {
        ["rpc"] = "battle_start",
        ["battle_id"] = self.rData["rcvData"]["b_id"],
        ["team_id"] = tostring(self.teamIdx),
        }

        local str = self:checkSk()
        tempTable["check_sk"] = str

        local mydata =  cjson.encode(tempTable)
        print("测试 mydata = "..mydata)

        G_STAGE_TYPE = 1

        local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
        ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
        
        if g_channel_control.battleLua then
            dbhttp:creatHttpRequestWithURL(mydata,3)
        else
            dbhttp:creatHttpRequestWithURL(mydata,104)
        end
    end
end 

--
function ReadyLayer:checkSk()
     local teamData = team_list[tostring(self.teamIdx)]["team"]
     local tablesk = {}
     dump(team_list, "team_list")
     for i = 1,#teamData  do
        if teamData[i]~=nil and teamData[i]["id"]~= "0" then
            local sk1  = teamData[i]["active_sk"][1]
            local sk2 =  teamData[i]["active_sk"][2]
            
            local nowD1 = 0;
            local nowD2 = 0;
            for m = 1,  #skill[tonumber(sk1)]["skill_attack_hit"]do
                  nowD1 =nowD1+ skill[tonumber(sk1)]["skill_attack_hit"][m]["hit_dmg"]
            end
            tablesk[tostring(sk1)] = {skill[tonumber(sk1)]["skill_dmg"],skill[tonumber(sk1)]["skill_cd"],nowD1}
           
            for m = 1,  #skill[tonumber(sk2)]["skill_attack_hit"]do
                  nowD2 =nowD2+ skill[tonumber(sk2)]["skill_attack_hit"][m]["hit_dmg"]
            end
             tablesk[tostring(sk2)] = {skill[tonumber(sk2)]["skill_dmg"],skill[tonumber(sk2)]["skill_cd"],nowD2}
       end
    end
    local skID =  math.random(20024,20095)
    local nowD = 0;
    for m = 1,  #skill[tonumber(skID)]["skill_attack_hit"]do
              nowD =nowD+ skill[tonumber(skID)]["skill_attack_hit"][m]["hit_dmg"]
        end
    tablesk[tostring(skID)] = {skill[tonumber(skID)]["skill_dmg"],skill[tonumber(skID)]["skill_cd"],nowD}

    return tablesk
        
end 


--左翻页
function ReadyLayer:leftCallBack()
    print("测试="..self.teamIdx)
    local node      = self.uiLayer:getChildByTag(1)
    local panel_1   = node:getChildByTag(1)

    local pageView  = ccui.Helper:seekWidgetByTag(panel_1,171)
    if self.teamIdx > 1 then 
        pageView:scrollToPage(self.teamIdx-2)
        self.teamIdx = self.teamIdx - 1 

        cc.UserDefault:getInstance():setIntegerForKey("teamIdx", self.teamIdx)
        
    end 
    self:refreshRightAndLeftState()
    self:refreshNowTeam()
end 

--右翻页
function ReadyLayer:rightCallBack()
    print("测试="..self.teamIdx)
    local node      = self.uiLayer:getChildByTag(1)
    local panel_1   = node:getChildByTag(1)

    local pageView  = ccui.Helper:seekWidgetByTag(panel_1,171)
    if self.teamIdx < 5 then 

        pageView:scrollToPage(self.teamIdx)
        self.teamIdx = self.teamIdx + 1 
        cc.UserDefault:getInstance():setIntegerForKey("teamIdx", self.teamIdx)  
    end 
    self:refreshRightAndLeftState()
    self:refreshNowTeam()
end 

function ReadyLayer:refreshRightAndLeftState()
    local node      = self.uiLayer:getChildByTag(1)
    local panel_1   = node:getChildByTag(1)

    local leftBtn = ccui.Helper:seekWidgetByName(panel_1,"Button_12")
    local rightBtn = ccui.Helper:seekWidgetByName(panel_1,"Button_11")

    local function setBtnState(btn,isT)
      -- body
        btn:setTouchEnabled(isT)
        btn:setBright(isT)
    end
    if tonumber(self.teamIdx) == 1 then 
        setBtnState(leftBtn,false)
        setBtnState(rightBtn,true)
    elseif tonumber(self.teamIdx) == 5 then 
        setBtnState(leftBtn,true)
        setBtnState(rightBtn,false)
    else 
        setBtnState(leftBtn,true)
        setBtnState(rightBtn,true)
    end 
end 

--队伍编程
function ReadyLayer:formationCallBack()

end 
--发送拉取星之卵列表请求
function ReadyLayer:reqTeamList()
    local function reiceResultCallBack(data)
        print("收到星之卵列表信息")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
         if self.exist == false then
          return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
       user_info["team"] =  t_data["data"]["team"]
       self._buffs = t_data["data"]["buffs"] or {}
       DataManager:rfsTlist()
       self:init()
       self:addBuffIcons()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"] = "team_list"
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function ReadyLayer:create(rData)
    local layer = ReadyLayer.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer.exist = true
     layer:reqTeamList()
     return layer
end

--添加加成buff图标
function  ReadyLayer:addBuffIcons()
    local function addTips(partnerNode,strInfo)
        local spTip = self.buffNode:getChildByTag(10010)
        if  spTip == nil then 
            spTip = cc.CSLoader:createNode("BuffShowTip.csb")
            spTip:setTag(10010)
            self.buffNode:addChild(spTip)
        end 
        spTip:setPosition(partnerNode:getPositionX()+partnerNode:getContentSize().width/2,partnerNode:getContentSize().height/2+40)  
        local label = spTip:getChildByTag(34)
        if label~= nil then 
            label:setString(strInfo)
        end
    end

    local function removeTips()
        local spTip = self.buffNode:getChildByTag(10010)
        if  spTip ~= nil  then 
            spTip:removeFromParent()
            spTip = nil
        end 
    end

    local function touchEvent(sender,eventType) 
        if eventType == ccui.TouchEventType.began then
            local s_id = self._buffs[sender.myTag]
            local strInfo = UITool.getUserLanguage(passive_sk[s_id].sk_det_des)
            addTips(sender,strInfo)
        elseif eventType == ccui.TouchEventType.ended then
            removeTips()
        end
    end

    local p = cc.p(0,0)

    for i=1,#self._buffs do 
        local s_id = self._buffs[i]
        local iconStr = passive_sk[s_id].sk_icon
        local imgIcon = ccui.ImageView:create()
        imgIcon:loadTexture(iconStr)
        imgIcon:setAnchorPoint(cc.p(0,0.5))
        imgIcon:setPosition(p.x, p.y)
        imgIcon:setTouchEnabled(true)
        self.buffNode:addChild(imgIcon)
        p = cc.pAdd(p,cc.p(imgIcon:getContentSize().width+20,0))
        imgIcon.myTag = i
        imgIcon:addTouchEventListener(touchEvent)  
        --外框
        local img = ccui.ImageView:create()
        img:loadTexture("uifile/n_UIShare/Global_UI/other/zqzb_ui_096.png")
        img:setAnchorPoint(cc.p(0.5,0.5))
        img:setPosition(imgIcon:getContentSize().width/2, imgIcon:getContentSize().height/2)
        imgIcon:addChild(img)
    end 
end