--[[
首页baner
]]
ActBanerNode = class("ActBanerNode",function()
    return cc.Node:create()
end)
function ActBanerNode:ctor(data)
    -- body
    self:init(data)
end

function ActBanerNode:create(manager)
    local node = ActBanerNode.new(manager)
    return node
end

function ActBanerNode:init(manager)
    self.manager = manager
    local node = nil
    if g_channel_control.UIVersion >= 2 then
        node = cc.CSLoader:createNode("XbAtivityMainNode.csb")
    else
        node = cc.CSLoader:createNode("AtivityMainNode.csb")
    end


    
    node:setPosition(0,0)
    self:addChild(node,10)
    self._indicatorImgs = {} --指示器数组
    --self._pageView = node:getChildByTag(101)
    self._scrollNode = node:getChildByTag(101)---测试，UI直接删除就行了
    self._indicatorBG = node:getChildByTag(102)

    self:initScroillView()

    self._indicatorBG:setVisible(false)
end

function ActBanerNode:initScroillView()
    local size = self._scrollNode:getContentSize()
    self._cyclePageView = CyclePageView.new(size)
    self._scrollNode:addChild(self._cyclePageView)
    self._cyclePageView.onClickEvent = function(i)
        print("点击    "..i)
        self.manager:dealBanerTouchEvent(i)
    end
    self._cyclePageView.onturnEvent = function(i)
        self:updateIndicator(i)
    end
end

function ActBanerNode:updatePageView(data)
    self._data = data
    self._indicatorImgStr = {
        "n_UIShare/actBase/ldhd_ui_003.png",
        "n_UIShare/actBase/ldhd_ui_004.png",
    }
    self._totalNum = #self._data
    self._curIndex = 1 --从1开始 ，对应getCurrentPageIndex +1

    self._indicatorImgs = {} 
    local banerNum = #self._data
    if  banerNum >1 then 
        self._indicatorBG:setVisible(true)
        self:addIndicator(banerNum)
    else 
        self._indicatorBG:setVisible(false)
    end

    self._cyclePageView:updatePageView(self._data)
end 

--添加指示器
function ActBanerNode:addIndicator(num)
    self._indicatorBG:removeAllChildren()
    self._indicatorImgs = {}
    local rigntPos = cc.p(self._indicatorBG:getContentSize().width-50, self._indicatorBG:getContentSize().height/2)
    local interval = 3
    for i=1,num do
        local img = ccui.ImageView:create(self._indicatorImgStr[1])
        local imgW = 18
        img:setPosition(rigntPos.x-(interval+imgW)*(i-1), rigntPos.y)
        self._indicatorBG:addChild(img)
        self._indicatorImgs[num-i+1] = img --这种数组用法有风险，但是方便 ，推荐用字典，因为指示器是从左向右
    end
end
--更新指示器
function ActBanerNode:updateIndicator(curIndx)
  -- body
    --dump(curIndx)
    for i=1,#self._indicatorImgs do
        local imgStr = self._indicatorImgStr[1]
        if i == curIndx then 
            imgStr = self._indicatorImgStr[2]
        end 
        local img = self._indicatorImgs[i]
        if img then 
            img:loadTexture(imgStr)
        end 
    end
end
