

AchiEfecLayer = class("AchiEfecLayer")
AchiEfecLayer.__index = AchiEfecLayer
AchiEfecLayer.lClass  = 2
AchiEfecLayer.tdata   = nil
AchiEfecLayer.nLen    = 0
AchiEfecLayer.tLen    = 0

function AchiEfecLayer:init()
    local node =cc.CSLoader:createNode("AchiEfecLayer.csb")
    self.uiLayer:addChild(node,0,2)
    
    local panel = node:getChildByName("Panel_1")
    local bg_f  = panel:getChildByName("Image_d_f")
    local name  = bg_f:getChildByName("Text_name")
    local dec   = bg_f:getChildByName("Text_dec")
    
    local icon_Achiv   = bg_f:getChildByName("Image_1")     -- 任务图标


    G_Efc_num   = G_Efc_num + 1
    local id    = self.tdata[G_Efc_num][1]

    if G_Efc_num <= #self.tdata then
        name:setString(UITool.getUserLanguage(table.getValue("achi_everyday_conf",achi_everyday_conf,id,"achi_name")))--achi_everyday_conf[id]["achi_name"]
        dec:setString(UITool.getUserLanguage(achi_everyday_conf[id]["achi_desc"]))
        local icon_a = achi_everyday_conf[id]["achi_icon"] -- 任务图标
        icon_Achiv:setUnifySizeEnabled(true)
        icon_Achiv:loadTexture(icon_a)
    end
    local function caiSeCallBack( ... )
    	-- body 
    	if G_Efc_num >= #self.tdata then
    		HideAchiEfc()
    	else
    		ShowAchiEfc(self.tdata)
    	end
    end 
    local Anim  = cc.CSLoader:createTimeline("AchiEfecLayer.csb")
    Anim:setLastFrameCallFunc(caiSeCallBack)
 	node:runAction(Anim)
 	Anim:play("animation0", false);
	
--    cc.SimpleAudioEngine:getInstance():playEffect("music/ui/tiaochengjiu.mp3", false)  
    AudioManager:shareDataManager():playMusic("music/ui/tiaochengjiu.mp3", 0,false)
end

function AchiEfecLayer:create(tdata)
	 self.tdata = tdata
	 self.tLen  = #tdata
     self.uiLayer = cc.Layer:create()
     self:init()
     return self.uiLayer
end