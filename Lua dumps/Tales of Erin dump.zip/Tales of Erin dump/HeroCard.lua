HeroCard = class("HeroCard",BasicLayer)
HeroCard.__index   = HeroCard
HeroCard.Sp = nil  --spine动画
HeroCard.ATK = 1  --攻击力
HeroCard.celerity = 1  --速度
HeroCard.critRate = 1  --暴击率
HeroCard.critAdd = 1.5  --暴击加成
HeroCard.start_celerity = 0.1  --初始速度
HeroCard.sound = nil
HeroCard.effect = nil
HeroCard.file = 0
HeroCard.animationSate = 2
HeroCard.manager = nil
HeroCard.state = 0
HeroCard.callBackFuc = nil

function HeroCard:create(rData)
    local heroCrad = HeroCard.new()
    heroCrad:init(rData)
    return heroCrad
end

function HeroCard:init(rData)
	self.celerity = rData["celerity"]/1000
    self.critRate = rData["critRate"]
    self.start_celerity = rData["start_celerity"]
    self.manager = rData["manager"]
    self.callBackFuc = rData["callBackFuc"]
    self.ATK = rData["atk"]
	self.sound = rData["sound"]
	self.effect = rData["effect"]
    self.file = rData["file"]
	self.Sp = sp.SkeletonAnimation:createWithSkeletonAnimation(SPCacheManager:getSPFromCache(rData["file"]))
	self.Sp:registerSpineEventHandler(
            function (event) 
            print(string.format("[spine] %d end:", event.trackIndex))
            if self.state == 0 then
            	return
            end
            self.animationSate = 1
            local function playNext()
            	self:playAnimation("singleattack")
            end
            local  delay = cc.DelayTime:create(self.celerity)
            local sequence = cc.Sequence:create(delay, cc.CallFunc:create(playNext))
            sequence:setTag(1010)
            self.Sp:runAction(sequence)
            end, sp.EventType.ANIMATION_END)
	self.Sp:setAnimation(1, "loading", true)
end

function HeroCard:start()	
	self.state = 1
	self.animationSate =1 
	local function resetTime()
	      self:playAnimation("singleattack")
	end
	local  delay = cc.DelayTime:create(self.start_celerity)
	local sequence = cc.Sequence:create(delay, cc.CallFunc:create(resetTime))
	if self.Sp == nil then
		return
	end
	self.Sp:runAction(sequence)

end

function HeroCard:playAnimation(name)
	if self.Sp ==nil then
		return
	end
	if name~="loading" and name ~= "run" then
		if  self.animationSate ==1  then
			self.Sp:addAnimation(1, name, false)
			self.Sp:addAnimation(1, "loading", true)
			self.animationSate = 2
		    --cc.SimpleAudioEngine:getInstance():playEffect(self.sound, false)
			if self.callBackFuc ~=nil then
				local rNum = math.random(100)
				local mode = 0
				local dmg = self.ATK
				if rNum < self.critRate then
				   mode = 1
                   dmg = math.ceil(self.ATK*self.critAdd)
				end 
				
				local data = {}
				data["dmg"] = dmg
				data["mode"] = mode 
				data["effect"] = self.effect  
				self.callBackFuc(self.manager,data)
			end
		end
	else
		   self.Sp:addAnimation(1, name, true)		
	end
end


function HeroCard:paseAttack()
	 self.Sp:stopAllActions()
     self.animationSate = 2
     self.Sp:setToSetupPose()
     self.Sp:clearTracks()
     self.Sp:addAnimation(1, "loading", true)
     self.state = 0
end

function HeroCard:pruge()
         self.Sp:stopAllActions()
         self.animationSate = 2
         self.Sp:removeFromParent()
         self.Sp = nil
         self.manager = nil
         self.callBackFuc = nil
end

