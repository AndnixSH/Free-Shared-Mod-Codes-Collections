
GachaConfirmView = class("GachaConfirmView" , XUIView)
GachaConfirmView.CS_FILE_NAME = "GachaDailyView.csb"
GachaConfirmView.CS_BIND_TABLE = 
{
    txt1 = "/i:38/i:40/i:242",
    txt2 = "/i:38/i:40/i:243",
    txt3 = "/i:38/i:40/i:244",
    title_have = "/i:38/i:40/i:245",  --您拥有
    num1 = "/i:38/i:40/i:248",  --绑定
    num2 = "/i:38/i:40/i:249",  --非绑定
    btnClose = "/i:38/i:40/i:200",
    btnOk = "/i:38/i:40/i:201",
}


function GachaConfirmView:init()
    GachaConfirmView.super.init(self)
    self.num1:setString("")
    self.num2:setString("")

    self.txt1:setString("")
    self.txt2:setString("")
    self.txt3:setString("")

    if g_channel_control.GachaConfirmViewAnchorPoint == true then
        self.title_have:setAnchorPoint(cc.p(1,0.5))
        self.title_have:setPosition(cc.p(314,221))

    end

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:clearEx()
    end)

    self.btnOk:addClickEventListener(function()
        if self.callback then
            self.callback()
        end
    end)

    -- if ginfo.cheap_draw_cost > gem_r then
    --     dialog.num1:setTextColor(cc.c3b(255,46,46))                
    --     dialog.btnOk:addClickEventListener(function()
    --         dialog:removeFromParentView()
    --         --钻不够
    --         GameManagerInst:alert("您的 绑定星石 不足，无法进行召唤。")
    --     end)
    -- else
                
    --     dialog.btnOk:addClickEventListener(function()
    --         dialog:removeFromParentView()
    --         self:btnGacha(4)
    --     end)
    -- end
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:clearEx()
    end)
    
    return self
end
--
function GachaConfirmView:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function GachaConfirmView:setInfo(gem_f,gem_r,gacha_type,gem_cost,callback)
    self.num1:setString(""..gem_r)
    self.num2:setString(""..gem_f)

    --更改 
    if g_channel_control.order_GachaConfirmView_tip_msg == false then
        --gacha_type  1 赠券 2 单抽 3 十连 4 每日优惠
        if gacha_type == 2 then
            self.txt1:setString(UITool.ToLocalization("您是否要消耗"))
            self.txt2:setString(UITool.ToLocalization("星石")..gem_cost)
            self.txt3:setString(UITool.ToLocalization("，进行1次召唤?"))
        elseif gacha_type == 3 then
            self.txt1:setString(UITool.ToLocalization("您是否要消耗"))
            self.txt2:setString(UITool.ToLocalization("星石")..gem_cost)
            self.txt3:setString(UITool.ToLocalization("，进行10次召唤?"))
        elseif gacha_type == 4 then
            self.txt1:setString(UITool.ToLocalization("您是否要消耗"))
            self.txt2:setString(UITool.ToLocalization("有偿星石")..gem_cost)
            self.txt3:setString(UITool.ToLocalization("，进行1次召唤?"))
        end
    else
        if g_channel_control.transform_GachaConfirmView_Text_color == true then
            self.txt1:setTextColor(cc.c3b(255,243,165))
            self.txt2:setTextColor(cc.c3b(255,255,255))
            self.txt3:setTextColor(cc.c3b(255,255,255))
        end
        if gacha_type == 2 then
            self.txt1:setString(UITool.ToLocalization("星石")..gem_cost)
            self.txt2:setString(UITool.ToLocalization("您是否要消耗"))
            self.txt3:setString(UITool.ToLocalization("，进行1次召唤?"))
        elseif gacha_type == 3 then
            self.txt1:setString(UITool.ToLocalization("星石")..gem_cost)
            self.txt2:setString(UITool.ToLocalization("您是否要消耗"))
            self.txt3:setString(UITool.ToLocalization("，进行10次召唤?"))
        elseif gacha_type == 4 then
            self.txt1:setString(UITool.ToLocalization("有偿星石")..gem_cost)
            self.txt2:setString(UITool.ToLocalization("您是否要消耗"))
            self.txt3:setString(UITool.ToLocalization("，进行1次召唤?"))
        end

    end

    local width1 = self.txt1:getContentSize().width
    local width2 = self.txt2:getContentSize().width
    local width3 = self.txt3:getContentSize().width
    local pos_x = (self.txt1:getParent():getContentSize().width - width1 - width2 - width3) / 2
    local pos_y = self.txt1:getPositionY()

    self.txt1:setPosition(pos_x,pos_y)
    self.txt2:setPosition(pos_x + width1,pos_y)
    --韩国版本更换文字位置
    -- self.txt2:setPosition(pos_x,pos_y)
    -- self.txt1:setPosition(pos_x + width2,pos_y)

    self.txt3:setPosition(pos_x + width1 + width2,pos_y)

    self.callback = callback
end
