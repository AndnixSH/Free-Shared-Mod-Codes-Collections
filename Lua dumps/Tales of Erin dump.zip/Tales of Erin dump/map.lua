map = {} 
map[1] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[2] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[3] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[4] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_cunzhuang_q.png",--场景
    map_3 = "scene/sc_pt_cunzhuang_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[5] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[6] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[7] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[8] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[9] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[13] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_cunzhuang_q.png",--场景
    map_3 = "scene/sc_pt_cunzhuang_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[14] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_cunzhuang_q.png",--场景
    map_3 = "scene/sc_pt_cunzhuang_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[15] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[16] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[17] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b10.mp3",
 } 
map[18] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b10.mp3",
 } 
map[19] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_q.png",--场景
    map_3 = "scene/sc_pt_pingyuan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[20] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_ye_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[21] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_ye_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[22] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_ranshao_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_ranshao_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[23] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[24] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[25] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[26] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[27] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[28] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[29] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[30] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[34] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuzuo.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[35] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_q.png",--场景
    map_3 = "scene/sc_pt_pingyuan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[38] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xlc_q.png",--场景
    map_3 = "scene/sc_pt_xlc_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[41] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_zhou_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[42] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[43] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[46] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[47] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[48] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[49] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[50] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b14.mp3",
 } 
map[51] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b5.mp3",
 } 
map[53] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[54] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[55] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[56] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[57] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[58] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[59] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[60] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[61] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[62] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_wu_q.png",--场景
    map_3 = "scene/sc_pt_chuan_wu_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[63] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_wu_q.png",--场景
    map_3 = "scene/sc_pt_chuan_wu_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[64] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_wu_q.png",--场景
    map_3 = "scene/sc_pt_chuan_wu_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b10.mp3",
 } 
map[65] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_baoku.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[66] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_baoku.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[67] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[68] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[69] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b7.mp3",
 } 
map[70] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[71] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_baoku.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[72] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[73] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[74] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_baoku.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[75] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[76] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b5.mp3",
 } 
map[77] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[78] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_cjl.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b14.mp3",
 } 
map[100] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_zhou_q.png",--场景
    map_3 = "scene/sc_pt_chuan_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[251] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_ske.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[252] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_chen_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_chen_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[253] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[701] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_ske.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b11.mp3",
 } 
map[702] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_bl.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b12.mp3",
 } 
map[703] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_bdg.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b13.mp3",
 } 
map[704] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_kxl.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[705] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_guang_No5.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b20.mp3",
 } 
map[751] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xuzhang_q.png",--场景
    map_3 = "scene/sc_pt_xuzhang_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[752] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xuzhang_q.png",--场景
    map_3 = "scene/sc_pt_xuzhang_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[753] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dixiacheng.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[754] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_tingyuan.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[755] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_hd_jiedao.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[756] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_hd_jq_shinei.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[757] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_hd_senlin.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[758] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_hd_zoulang.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[759] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/TV_beijing/TV_beijing.atlas",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[801] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_diguojian_q.png",--场景
    map_3 = "scene/sc_pt_diguojian_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[802] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[803] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[804] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[805] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b17.mp3",
 } 
map[806] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b19.mp3",
 } 
map[807] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[808] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[809] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b10.mp3",
 } 
map[810] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b19.mp3",
 } 
map[811] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[812] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[813] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b17.mp3",
 } 
map[814] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_NO_5.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b17.mp3",
 } 
map[815] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_ranshao_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_ranshao_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[816] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[817] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_bl.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b14.mp3",
 } 
map[818] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_chuan_wu_q.png",--场景
    map_3 = "scene/sc_pt_chuan_wu_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[819] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_d_senlin_xue.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[820] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_fire.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[821] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_chen_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_chen_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[822] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xlc_q.png",--场景
    map_3 = "scene/sc_pt_xlc_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[823] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_huilang_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[824] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_zhou_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[825] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[826] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xlc_q.png",--场景
    map_3 = "scene/sc_pt_xlc_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[827] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_d_zoulang.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[828] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_zhou_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[829] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[830] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[831] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[832] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_q.png",--场景
    map_3 = "scene/sc_pt_pingyuan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[833] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_tz_q.png",--场景
    map_3 = "scene/sc_tz_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b11.mp3",
 } 
map[834] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_tzBOSS.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b11.mp3",
 } 
map[835] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_q.png",--场景
    map_3 = "scene/sc_pt_pingyuan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b20.mp3",
 } 
map[836] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_hd_jiedao.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[837] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_hd_jiedao.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[838] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[839] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[840] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[10102] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[10103] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10104] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[10115] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[10202] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_huilang_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[10204] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_huilang_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[10303] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10304] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[10315] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_ye_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[10403] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yidian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10404] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yidian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[10415] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yidian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[10503] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yanhui.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10603] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10615] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_ye.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[10703] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_laofang.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10802] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shatan_q.png",--场景
    map_3 = "scene/sc_pt_shatan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b2.mp3",
 } 
map[10903] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[10904] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[10915] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_senlin_q.png",--场景
    map_3 = "scene/sc_pt_senlin_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[11003] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_ranshao_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_ranshao_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11004] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yaosai_ranshao_q.png",--场景
    map_3 = "scene/sc_pt_yaosai_ranshao_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11104] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_ye_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11120] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_ye_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_ye_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b20.mp3",
 } 
map[11203] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_kxl.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11204] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_kxl.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11303] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_02.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11304] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_02.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11404] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_04.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11503] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_01.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11504] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_01.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11603] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_03.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11604] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_ld_cangyi_03.png",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11703] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11704] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xiagu_zhou_q.png",--场景
    map_3 = "scene/sc_pt_xiagu_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11803] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11804] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yiji.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[11903] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_zhou_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[11904] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_jiedao_zhou_q.png",--场景
    map_3 = "scene/sc_pt_jiedao_zhou_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12004] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_dongxue_q.png",--场景
    map_3 = "scene/sc_pt_dongxue_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12104] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12115] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuanshendian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b15.mp3",
 } 
map[12204] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_pingyuan_q.png",--场景
    map_3 = "scene/sc_pt_pingyuan_h.jpg",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12404] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_xueyuan_q.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12405] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_xueyuan.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12501] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_xinshoucun.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[12601] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_shamo_q.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[12701] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_wenquan.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[12801] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_gongzuoshi_q.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[12901] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_zhanjian.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[12902] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_zhanjian_q.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[13001] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_yuzuo1.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[13002] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_yuzuo1_q.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[13101] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_huilang.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[13201] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_linghunzhongya.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b4.mp3",
 } 
map[13202] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_pt_linghunzhongya_q.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 
map[13301] = { --地图的静态ID
    map_1 = "",--前景
    map_2 = "scene/sc_boss_shenshe.jpg",--场景
    map_3 = "",--中景
    map_4 = "", --远景
    voice_1 = "",
    voice_2 = "music/battle/b3.mp3",
 } 