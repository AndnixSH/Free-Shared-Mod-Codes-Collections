---非策划表，程序用

SortStateEnum = {
	UP = 0,
	DOWN = 1
}
-------------------
--排序优先级的key
SortFunDataKey = {
	ID = "excelID",
	ELEMENT = "element",
	RARITY = "rarity",
}
--排序的通用key
ComSortValue = {
	EXCELID = 1, --id
	ELEMENT = 2, --属性
	RARITY  = 3, --稀有度
}

--排序的通用key
TITLE_NAME = {
	SORT 		  = UITool.ToLocalization("排序"), 
	RARITY 		  = UITool.ToLocalization("稀有度"), 
	ELEMENT 	  = UITool.ToLocalization("属性"),
	HERO_RACE 	  = UITool.ToLocalization("种族"),
	HERO_POWER 	  = UITool.ToLocalization("势力"),
	IS_HAVE 	  = UITool.ToLocalization("收集"),
	ACT_TYPE 	  = UITool.ToLocalization("类型"),
	TARGET_TYPE   = UITool.ToLocalization("作用类型"),
	TARGET_RARITY = UITool.ToLocalization("作用属性"),
	SKILL_        = UITool.ToLocalization("技能"),
}
-------------------

--筛选的通用key
SiftSortMainType = {
	SORT = "sort",
	RARITY = "rarity",
	ELEMENT = "element",
	HERO_RACE = "hero_race",
	HERO_POWER = "hero_power",
	IS_HAVE = "is_have",
	ACT_TYPE = "act_type",
	TARGET_TYPE   = "target_type",
	TARGET_RARITY = "target_rarity",
	SKILL_ = "skill_",
}

sort_items_1 = {
	{
		value = ComSortValue.EXCELID,
		state =1, --1选中 0是未选中
		name  = UITool.ToLocalization("序号")
	},
	{
		value= ComSortValue.ELEMENT,
		state=0, --1选中 0是未选中
		name= UITool.ToLocalization("属性")
	},
	{
		value= ComSortValue.RARITY,
		state=0, --1选中 0是未选中
		name = UITool.ToLocalization("稀有度")
	}
}

herobook_sort_data = {}
herobook_sort_data = {
	{
		s_type = SiftSortMainType.SORT,
		name=TITLE_NAME.SORT,
		sortState = SortStateEnum.DOWN,
		items= sort_items_1, --单选
	},
	{
		s_type = SiftSortMainType.RARITY,  -- 稀有度
		name=TITLE_NAME.RARITY, 
		items = rarity_types,
	},
	{    
		s_type = SiftSortMainType.ELEMENT,  -- 属性
		name=TITLE_NAME.ELEMENT, 
		items= element_types,
	},
	{    
		s_type = SiftSortMainType.HERO_RACE,
		name=TITLE_NAME.HERO_RACE, 
		items= hero_race_types,
	},
	{    
		s_type = SiftSortMainType.HERO_POWER,
		name=TITLE_NAME.HERO_POWER, 
		items= hero_power_types,
	},
}

equipbook_sort_data = {}
equipbook_sort_data = {
	{
		s_type = SiftSortMainType.SORT,
		name=TITLE_NAME.SORT,
		sortState = SortStateEnum.DOWN,
		items= sort_items_1, --单选
	},
	{
		s_type = SiftSortMainType.RARITY,       --稀有度
		name=TITLE_NAME.RARITY, 
		items = rarity_types,
	},
	{    
		s_type = SiftSortMainType.ELEMENT,      --属性
		name=TITLE_NAME.ELEMENT, 
		items= element_types,
	},
	{    
		s_type = SiftSortMainType.TARGET_TYPE,   --作用类型
		name=TITLE_NAME.TARGET_TYPE, 
		items= eq_effect_types,
	},
	{    
		s_type = SiftSortMainType.TARGET_RARITY, --作用属性
		name=TITLE_NAME.TARGET_RARITY, 
		items= eq_effects,
	},
	{    
		s_type = SiftSortMainType.SKILL_,        --技能
		name=TITLE_NAME.SKILL_, 
		items= eq_sk2,
	},
}

titlebook_sort_data = {}
titlebook_sort_data = {
	{
		s_type = SiftSortMainType.SORT,
		name=TITLE_NAME.SORT,
		sortState = SortStateEnum.DOWN,
		items= sort_items_1, --单选
	},
	{
		s_type = SiftSortMainType.IS_HAVE, --收集度
		name=TITLE_NAME.IS_HAVE,
		items = collect_types,
	},
	{
		s_type = SiftSortMainType.RARITY,
		name=TITLE_NAME.RARITY, 
		items = rarity_types,
	},
	{    
		s_type = SiftSortMainType.ELEMENT,
		name=TITLE_NAME.ELEMENT, 
		items= element_types,
	},
	{    
		s_type = SiftSortMainType.ACT_TYPE,
		name=TITLE_NAME.ACT_TYPE, 
		items= title_types,
	},
}

titlebrowser_sort_data = {}
titlebrowser_sort_data = {
	{
		s_type = SiftSortMainType.SORT,
		name=TITLE_NAME.SORT,
		sortState = SortStateEnum.DOWN,
		items= sort_items_1,
	},
	{
		s_type = SiftSortMainType.RARITY,
		name=TITLE_NAME.RARITY,
		items = rarity_types,
	},
	{    
		s_type = SiftSortMainType.ELEMENT,
		name=TITLE_NAME.ELEMENT,
		items= element_types,
	},
	{    
		s_type = SiftSortMainType.ACT_TYPE,
		name=TITLE_NAME.ACT_TYPE,
		items= title_types,
	},
}