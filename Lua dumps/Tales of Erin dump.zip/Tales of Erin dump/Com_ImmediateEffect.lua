--立即生效的组件。如果是effect_type 为 3的情况。需要添加到com管理器。
--created by kobejaw. 2018.6.8.
Com_ImmediateEffect = class("Com_ImmediateEffect",ComponentBase)

function Com_ImmediateEffect:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 3
end

--开始生效。
--@isAdd 是否是正向生效。用于随触发器失效的情况。
function Com_ImmediateEffect:takeEffect(isAdd)
	local attrId = GetAttrIdByComId(self.comId,self.level)
	local comId = self.comId

	--修改属性值
	if attrId then
		local attrValue = self.level  --属性变化的百分比
		if not isAdd then
			attrValue = -attrValue
		end
		self.target.attributeManager:changeAttr(attrId,attrValue)
	--技能cd	
	elseif comId == 83010 then
		if self.target.entityType ~= 1 then
			return
		end
		ActiveSkillManager:changeSkillCD(self.target,self.comData.effect1,-self.comData.effect2)
	--改变生命值
	elseif comId == 83013 then
		local effect1 = self.comData.effect1
		local effect2 = self.comData.effect2
		local effect3 = self.comData.effect3

		local addedHp
		if effect1 ~= 0 then --改变固定生命值
			addedHp = effect1
		elseif effect2 ~= 0 then --改变生命值上限千分比的生命值
			addedHp = math.floor(effect2/1000 * self.target.attr[AE.hp_max])
		elseif effect3 ~= 0 then --按伤害回血
			if self.option and self.option.dmg and self.option.dmg ~= 0 then
				addedHp = math.floor(effect3/1000 * self.option.dmg)
			end
		end

		if addedHp then
			if addedHp >=0 then
				--考虑恢复力
				addedHp = math.floor(addedHp * self.target.attributeManager:getRecover()/100)
				--飘绿色字
				BattleDamageDisplay:create(self.target:getDamageShowingPos(false),addedHp,DamageFontType.AddHP)
			else
				--飘红色字
				BattleDamageDisplay:create(self.target:getDamageShowingPos(false),addedHp,DamageFontType.SelfHPLoss)					
			end
			self.target.attributeManager:changeAttr(AE.hp,addedHp)
		end

	--神格技能值
	elseif comId == 83014 then
		BattleUIManager:setSP(self.level,true)
	--削减boss的od槽
	elseif comId == 83026 then
		if G_Monsters[1].isBoss and not G_Monsters[1].isDead and G_Monsters[1].attr[AE.state] == 0 then
			G_Monsters[1]:onAttacked(self.level)
		end
	--固定伤害。都是独立造成伤害，无视“附加”这个叫法
	--注：83027目前包含两种情况。既可能是对攻击者进行反弹伤害，也可能是对防御者造成固定伤害
	--affectedEntity有可能是攻击者，也有可能是防御者。真几把乱。反弹的情况改为使用option.defender和option.attacker
	--effect1:固定值。effect2:攻击力千分比。effect3:目标最大生命值千分比
	elseif comId == 83027 then
		local option = self.option
		if not option then
			return
		end

		local effect1 = self.comData.effect1
		local effect2 = self.comData.effect2
		local effect3 = self.comData.effect3		

		local atkEntity,defEntity
		--反弹的情况
		if option.trig_time == 4 then
			atkEntity = option.defender
			defEntity = option.attacker
		--常规造成固定伤害
		else
			--这里有点乱，需要重新整理
			if option.trig_time == 3 then
				atkEntity = option.skillOwner
			else
				atkEntity = option.affectedEntity
			end
			defEntity = self.target
		end

		local dmg = 0
		if atkEntity and defEntity then
			if effect1 ~= 0 then
				dmg = effect1
			elseif effect2 ~= 0 then
				dmg = math.floor(effect2/1000 *  BattleDamageCompute:getSoloATK(atkEntity.attributeManager:getAttack()))		
			elseif effect3 ~= 0 then
				dmg = math.floor(effect3/1000 * defEntity.attr[AE.hp_max])
			else
				print("配表错误 .. comId:83027")
				return
			end

			if dmg > 0 then
				BattleDamageCompute:computeDamage_FixedDmg(dmg,defEntity,0)
			end
		end
	--驱散某类或者指定id的debuff 或 buff
	elseif comId == 83029 or comId == 83030 then
		local effect3 = self.comData.effect3
		local effect4 = self.comData.effect4

		if effect3 ~= 0 or effect4 ~= 0 then
			if effect3 ~= 0 then
				local com = self.target.componentManager:getComById(effect3)
				if com and com:checkCanBeDispelled() then
					self.target.componentManager:removeCom(com)
				end
			end
			if effect4 ~= 0 then
				local com = self.target.componentManager:getComById(effect4)
				if com and com:checkCanBeDispelled() then
					self.target.componentManager:removeCom(com)
				end
			end
		else
			local comType
			if comId == 83029 then
				comType = 2
			else
				comType = 1
			end
			self.target.componentManager:removeComByTypeAndNum(comType,self.comData.effect1,self.comData.effect2)
		end
		--83开头的只有驱散类有特效
		self:playEffectAni()
		
	--改变boss行动点上限
	elseif comId == 83031 then
		if self.target.isBoss then
			if isAdd then
				self.target.attributeManager:changeAttr(AE.energy_max,self.level)
			else
				self.target.attributeManager:changeAttr(AE.energy_max,-self.level)
			end

			if self.target.attr[AE.energy_max] < 1 then
				self.target.attr[AE.energy_max] = 1
			end

			if self.target.attr[AE.energy] > self.target.attr[AE.energy_max] then
				self.target.attr[AE.energy] = self.target.attr[AE.energy_max]
			end

			BattleUIManager:setMcountForBoss(self.target.attr[AE.energy],self.target.attr[AE.energy_max])
		end
	--减boss行动点
	elseif comId == 83032 then
		if self.target.isBoss then
			self.target.attributeManager:changeAttr(AE.energy,-self.level)
			BattleUIManager:setMcountForBoss(self.target.attr[AE.energy],self.target.attr[AE.energy_max])
		end
	--使用小技能
	elseif comId == 83035 then
		--注：能执行到这里说明角色一定满足使用小技能的条件（非异常，眩晕等）
		self.target.fsm:changeState(self.target.skill[1].skillInfo.skillStateEnum,self.target.skill[1].skillInfo)
	--重置技能cd(对应自己)
	elseif comId == 83036 then
		ActiveSkillManager:resetSkillCD(self.target,self.comData.effect1)
	--引爆特定效果debuff类 。引爆毒的效果。目前只用到了引爆火毒。使毒的剩余伤害一次性结算成固定伤害。
	--引爆82021
	elseif comId == 83039 then
		local com = self.target.componentManager:getComById(82021)
		if com then
			local dmg = com.damage
			local remainTime = math.ceil(com.comData.t - com.remainTime)
			local num = math.floor(remainTime/com.seconds_poison)
			BattleDamageCompute:computeDamage_FixedDmg(num * dmg,self.target,1)
			self.target.componentManager:removeCom(com)
		end
	--引爆特定效果，黑绞类。引爆黑绞。引爆造成固定伤害，伤害取决于黑绞debuff的等级和层数。
	elseif comId == 83041 then
		local com = self.target.componentManager:getComById(82033)
		if com then
			local dmg = math.floor(com.comData.effect2 * com.overlayNum)
			print("引爆黑绞  层数："..com.overlayNum.."   附加固定伤害："..dmg)
			BattleDamageCompute:computeDamage_FixedDmg(dmg,self.target,0)
			self.target.componentManager:removeCom(com)
		end
	--改变技能
	elseif comId == 83042 then
		local value1 = self.comData.effect1
		local value2 = self.comData.effect2		

		if isAdd then
			if value1 ~= 0 then
				self.target.skill[1]:changeSkill(value1)
			elseif value2 ~= 0 then
				self.target.skill[2]:changeSkill(value2)
			end
		else
			if value1 ~= 0 then
				self.target.skill[1]:changeBackSkill()
			elseif value2 ~= 0 then
				self.target.skill[2]:changeBackSkill()
			end
		end
	--使用某个技能，或者摆个pose
	elseif comId == 83043 then
		if G_GameState ~= 1 or (self.target.fsm.currentState.isSkill and self.target.fsm.currentState.skillInfo.isBigSkill)
			or self.target.fsm.currentState.stateEnum == StateEnum.UnusualCondition then
			return
		end

		local skillInfo
		if self.option.passiveId then
			skillInfo = self.target.extraSkillInfo[self.option.passiveId]
		end
		
		if skillInfo then
			--摆pose,尤娜生气的一个pose。
			if self.comData.state_lv == 1 then
				BattlePlaySound(skillInfo.skill_voice,false,1)
				self.target.fsm:changeState(StateEnum.Posing,"bigskill2")
			--使用某个技能。注：不是小技能，是指定等级的某个技能。需要在解析被动技能时事先缓存这个技能的信息。
			else
				self.target.fsm:changeState(skillInfo.skillStateEnum,skillInfo)
			end
		end		

	--减少boss狂暴槽（百分比）
	elseif comId == 83067 then
		if self.target.isBoss and self.target.attr[AE.state] == 0 then
			local percent = self.level/100
			local odValue = math.floor(percent * self.target.attr[AE.od_hp])
			self.target:onAttacked(odValue)
		end
	--移除指定ID的debuff的指定层数.没有用到，先不管了。
	--lv大于2的时候是移除指定debuff，不用管层数。只用到了这种情况。目前83069就是移除某个buff或debuff，跟83029和83030没有任何区别。
	elseif comId == 83069 then
		local id = self.comData.effect1
		if id ~= 0 then
			local com = self.target.componentManager:getComById(id)
			if com then
				self.target.componentManager:removeCom(com)
			end
		end
	end
end

--83开头的只有驱散类有特效
function Com_ImmediateEffect:playEffectAni()
	local path = self.comData.state_spine
	if path == "" then
		return
	end

	local spineData = BattleCacheManager:getData(path)
	local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
    if self.target:getMonsterEnum() == 5 then
       spineNode:setScale(1.2)
    end
    self.target.effectNode:addChild(spineNode);
	spineNode:setAnimation(0, "effect", false)

    local function completeCallback(event)
    	local function removeSelf() 
	    	if G_IsInBattle then
	        	spineNode:removeFromParent();
	    	end
    	end
    	PerformWithDelayTime(removeSelf,0.01)
    end
    spineNode:registerSpineEventHandler(completeCallback,sp.EventType.ANIMATION_COMPLETE)
end