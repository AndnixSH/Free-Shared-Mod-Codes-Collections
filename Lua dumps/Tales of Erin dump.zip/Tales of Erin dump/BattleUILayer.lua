BattleUILayer = class("BattleUILayer", function()
    return cc.Layer:create();
end);
BattleUILayer.BATTLE_UI_PATH = "uifile/zhandou.csb"
BattleUILayer.rootNode = nil
BattleUILayer.FHbtn = nil--复活按钮
BattleUILayer.autobtn = nil--自动战斗按钮
BattleUILayer.autoBattle = false--是否为自动战斗状态
BattleUILayer.bqbtn = nil
BattleUILayer.touchLayer = nil
function BattleUILayer:ctor()
    self.rootNode = cc.CSLoader:createNode(self.BATTLE_UI_PATH)
    self:addChild(self.rootNode)
    self:initBtns()
    self.touchLayer = ccui.Layout:create()
    self.touchLayer:setContentSize(cc.size(1280,720))
    self.touchLayer:setAnchorPoint(cc.p(0,0))
    self.touchLayer:setTouchEnabled(false)
    self:addChild(self.touchLayer,10001)
    self.touchLayer:setVisible(false)
end

function BattleUILayer:PauseUI(state)
    self.touchLayer:setTouchEnabled(state)
    self.touchLayer:setVisible(state)
end

function BattleUILayer:showFHbtn(state)
    self.FHbtn:setVisible(state)  
end

function BattleUILayer:initBtns()
  	local panel_sk =  self.rootNode:getChildByTag(4)
      
  	for i = 1, 4 do
        local roleImg = panel_sk:getChildByTag(i+403)
  	    roleImg:setVisible(false);
  	end
    -- 以上为设置角色技能区域隐藏
    local function touchCallBack( sender,eventType )
        self:touchEvent(sender,eventType)
    end
    for i = 10, 11 do
      	local btn = self.rootNode:getChildByTag(i)
      	btn:addTouchEventListener(touchCallBack)
        if i==10 and G_STAGE_TYPE ~= 2 then 
           btn:setVisible(false) --不是多人战则设置求援按钮为不可见
        end
    end
    
    self.FHbtn = self.rootNode:getChildByTag(943)
    self.FHbtn:addTouchEventListener(touchCallBack)
    self.FHbtn:setVisible(false) --设置复活按钮默认状态为隐藏

    self.autobtn = self.rootNode:getChildByTag(944)
    self.autobtn:addTouchEventListener(touchCallBack)
    self.autoBattle = cc.UserDefault:getInstance():getBoolForKey("AUTOBATTLE")
    if self.autoBattle == true then
       self.autobtn:loadTextureNormal("n_UIShare/Global_UI/btn/zd_b_003_2.png")
    else
       self.autobtn:loadTextureNormal("n_UIShare/Global_UI/btn/zd_b_003_1.png")     
    end --初始化自动战斗按钮相关    


    self.bqbtn = self.rootNode:getChildByTag(945)
    self.bqbtn:addTouchEventListener(touchCallBack)

    if G_STAGE_TYPE == 2 then
       self.bqbtn:setVisible(true)
    else
       self.bqbtn:setVisible(false)     
    end --初始化表情按钮相关   
end	


function BattleUILayer:touchEvent(sender,eventType)
    local tag = sender:getTag()
    if eventType == ccui.TouchEventType.ended then
        if tag ==10 then --多人战求援
            if G_GameState == 1 or G_GameState == 5 then
                BattleUIManager:showBattleHelpLayer()
            end
        elseif tag ==11  then -- 暂停界面
            if G_GameState == 1 or G_GameState == 5 then
                if G_GameState == 1 then
                    G_GameState = 4
                end              
                G_BattleScene:pauseGame()
                BattleUIManager:showPauseLayer(true)
            end
        elseif tag ==943  then --复活按钮事件
            self.FHbtn:setVisible(false)
            BattleUIManager:showPanelFH(G_BattleScene.onRevive) --展示复活界面
        --elseif tag ==944  then --自动战斗按钮事件在技能管理类里
        elseif tag ==945  then -- 多人战表情按钮事件
            if G_GameState == 1 then  
                self.bqbtn:loadTextureNormal("n_UIShare/zhandou/biaoqing/zdlt_b_001a.png")
            end
            BattleUIManager:showBQList()
        end
    end
end

function BattleUILayer:showXSYDMode(mode) -- 0、移除引导层 1、释放技能 2、增豆教学 3、满豆教学 4、女主技能教学
     if mode == 0 then 
        self:removeChildByTag(987987)
        --游戏继续
        G_BattleScene:resumeGame()
        return
     end
     G_BattleScene:pauseGame()  
     local imgFile = ""
     local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(BattleCacheManager:getData("effects/jiantou/jiantou.atlas"))
     local postion
     local ram = 0

     if mode == 2 then  --增豆教学
        imgFile = "n_UIShare/ZYTP/xsjx_ui_jnc1.png"
        postion = cc.p(750,655)
     elseif mode == 3 then -- 满豆教学
        imgFile = "n_UIShare/ZYTP/xsjx_ui_jnc2.png"--//满豆教学
        postion = cc.p(750,655)
     elseif mode == 4 then -- 女主技能教学  
        imgFile = "n_UIShare/ZYTP/xsjx_ui_sg1.png"--公主技能教学
        postion = cc.p(1020,100);
     end 
     
    local img = ccui.ImageView:create(imgFile)
    img:addChild(spineNode)
    if mode >= 2 then 
      function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
           self:showXSYDMode(0)
        end 
      end
      img:setTouchEnabled(true)
      img:addTouchEventListener(touchCallBack)
    end   
    spineNode:setAnimation(1, "effect", true)
    spineNode:setRotation(ram)
    self:addChild(img,10000);
    spineNode:setPosition(postion)
    img:setTag(987987)
    img:setPosition(640,360)
end
