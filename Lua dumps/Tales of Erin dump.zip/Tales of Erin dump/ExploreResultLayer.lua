--[[
	ExploreResultLayer.lua
	探索结果页面
    关卡解锁在这个页面进行处理
]]
require "BasicLayer"

ExploreResultLayer = class("ExploreResultLayer",BasicLayer)
ExploreResultLayer.__index = ExploreResultLayer
ExploreResultLayer.lClass = 3
local LIST_ITEM_H = 110 --item高度
local LIST_COLUMN = 3   --一行显示几个
function ExploreResultLayer:init()
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.resultData = self.rData["rcvData"]["data"]
    local exploreId = self.resultData.explore_id --探索Id
    self.unlock_area = self.resultData.unlock_area
    local node = cc.CSLoader:createNode("ExploreResult.csb")
    self.uiLayer:addChild(node,0,1)
    self._rootCSbNode = node:getChildByTag(102) 

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            -- 如果是有解锁。显示解锁页面
            if #self.unlock_area >0 then 
                self:toShowLockLayer()
            else 
        	   self:returnBack()
            end 
        end
    end
    local title = ccui.Helper:seekWidgetByName(self._rootCSbNode,"main_title")
    title:setString(UITool.getUserLanguage(exploerPass[exploreId].level_name))
    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_confrim")
    backBtn:addTouchEventListener(touchCallBack)

    self:initLeftUI()
    self:initRightUI()
    self:initListView()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
--探索队伍
function ExploreResultLayer:initLeftUI()
	--队伍列表
	local teamList = self.resultData.explore_result.team_list
    for i=1,#teamList do
        local keyStr = "team_"..i
        local panel = ccui.Helper:seekWidgetByName(self._rootCSbNode,keyStr)
        local node = cc.CSLoader:createNode("ExploreTeamItem.csb")
        node:setScale(0.85)
        panel:addChild(node,0,1)
        self:refreshTeamUI(node,teamList[i]) 
    end
end
--赶时间，凌乱版本。todo需要整理
function ExploreResultLayer:initRightUI()
    local explore_result = self.resultData.explore_result
    local exploreRank = explore_result.explore_rank

    local labeTabKey = {
        [1] = "race_cor", --种族修正
        [2] = "fa_cor", -- 战力修正
        [3] = "Explore_level_2", -- --旧的等级
        [4] = "Explore_level_3", -- +多少等级
        [5] = "exp_1",  -- 旧的经验
        [6] = "exp_2",  --加多少经验
    }

    local oldData = DataManager:getExploreData()
    local oldExp = oldData.explore_exp  or 0 
    local oldMaxExp = oldData.explore_max_exp or 0
    local oldLevel = oldData.explore_lv or 0
    -- --testCode 
    -- exploreRank["rank_new"] = 6
    local nowRank = exploreRank["rank_new"]
    local addLevel = nowRank - oldLevel --增加的等级
    local addLevelStr = nil 
    local addExp = exploreRank["rank_add_exp"]  --本次探索共获得多少经验
    local nowExp = exploreRank["rank_new_exp"]  --当前等级对应的经验 
    local maxExp = exploreRank["rank_max_exp"]  --当前探索等级对应的最大经验

    if addLevel>0 then 
        addLevelStr = "+"..addLevel
    else 
        addLevelStr = ""
    end

    local labeTabValue = {
        [1] = "+"..explore_result["race_cor"].."%", --种族修正
        [2] = "+"..explore_result["fa_cor"].."%", -- 战力修正
        [3] = oldLevel,
        [4] = addLevel,
        [5] = "", --没有旧的Exp了。只显示本次共获得多少经验
        [6] = "+"..addExp,
    }
    --种族修正
    local lab1 = ccui.Helper:seekWidgetByName(self._rootCSbNode,labeTabKey[1]) 
    lab1:setString(labeTabValue[1])
    --战力修正
    local lab2 = ccui.Helper:seekWidgetByName(self._rootCSbNode,labeTabKey[2]) 
    lab2:setString(labeTabValue[2])

    --当前经验（不要了）
    local lab5 = ccui.Helper:seekWidgetByName(self._rootCSbNode,labeTabKey[5]) 
    lab5:setVisible(false)
    ---加多少等级（隐藏掉不用了）
    local lab_addLevel = ccui.Helper:seekWidgetByName(self._rootCSbNode,labeTabKey[4]) 
    lab_addLevel:setVisible(false)

    ---等级显示
    self.lab_expLevel = ccui.Helper:seekWidgetByName(self._rootCSbNode,labeTabKey[3]) 
    self.labe_addExp = ccui.Helper:seekWidgetByName(self._rootCSbNode,labeTabKey[6]) 
    self.labe_addExp:setString(labeTabValue[6])
    --没有等级提升
    --进度
    local bar_bg = ccui.Helper:seekWidgetByName(self._rootCSbNode,"bar_bg") 
    --这个不用了改为Pro
    local loadingBar = ccui.Helper:seekWidgetByName(self._rootCSbNode,"LoadingBar") 
    loadingBar:setVisible(false)

    self.loadingBar = self:getBar()
    self.loadingBar:setPosition(bar_bg:getContentSize().width/2,bar_bg:getContentSize().height/2)
    bar_bg:addChild(self.loadingBar,10)
    self.loadingBar:setVisible(true)

    if addLevel < 1 then 
        self.lab_expLevel:setString(nowRank)
        self.labe_addExp:setVisible(true)
        self.loadingBar:setPercentage(math.floor(100*nowExp/maxExp))
    else
        self.oldLevel = oldLevel
        self.newLevel = nowRank
        self.showLevel = oldLevel
        self.oldPercent = math.floor(100*oldExp/oldMaxExp)
        self.endPercent = math.floor(100*nowExp/maxExp)
        self.labe_addExp:setVisible(false)
        self.lab_expLevel:setString(oldLevel)
        self.loadingBar:setPercentage(self.oldPercent)
        self:runExpUpAni()
    end 
end

function ExploreResultLayer:getBar()
    local bar = cc.ProgressTimer:create(cc.Sprite:create("n_UIShare/explore/ts_ui_017.png"))
    bar:setType(cc.PROGRESS_TIMER_TYPE_BAR)
    bar:setMidpoint(cc.p(0,0))
    bar:setBarChangeRate(cc.p(1, 0))
    return bar 
end 

function ExploreResultLayer:runExpUpAni()
    local endPrecent = 100
    local isEnd = false 
    if self.showLevel > self.oldLevel and self.showLevel < self.newLevel then 
        self.loadingBar:setPercentage(0)
        endPrecent = 100
        isEnd = false
    end
    if self.showLevel == self.newLevel then 
        self.loadingBar:setPercentage(0)
        endPrecent = self.endPercent
        isEnd = true
    end 
    local function stopAction()
        if isEnd then 
            self.labe_addExp:setVisible(true)
        else 
            self.showLevel = self.showLevel + 1 
            self:runExpUpAni()
        end 
        self.lab_expLevel:setString(self.showLevel )
    end  
    --todo优化 时间应该计算。0.6*剩余进度
    local to1 = cc.ProgressTo:create(0.6, endPrecent)
    local callfunc = cc.CallFunc:create(stopAction)
    local sequence = cc.Sequence:create(to1,callfunc)
    self.loadingBar:runAction(sequence)

end

function ExploreResultLayer:refreshTeamUI(_node,data)
	local _type = 3
	
    local function setUI(root,iconImg,frameImg,elementImg)
        local h_id_num = getNumID(data.hero_id)
        --icon
        local iconStr = hero[h_id_num].hero_team_icon
        iconImg:loadTexture(iconStr)
        --frame
        local frameStr = Rarity_Hero_Frame[hero[h_id_num].hero_rank]
        frameImg:loadTexture(frameStr)
        --element
        local elementStr =  ATB_Icon[hero[tonumber(tonumber(h_id_num))]["hero_atb"]]   
        elementImg:loadTexture(elementStr)
        --种族
        -- local hero_race = hero[h_id_num].hero_race
        -- local raceLab = ccui.Helper:seekWidgetByName(root,"raceType")  
        -- raceLab:setString(UITool.ToLocalization(HERO_RACE_NAME[hero_race]))

          --种族 显示种族名字 或者 图标
        if g_channel_control.transform_ExploreResultLayer_raceType == false then
            print("g_channel_control.transform_ExploreResultLayer_raceType == false")
            local hero_race = hero[h_id_num].hero_race
            local raceLab = ccui.Helper:seekWidgetByName(root,"raceType")  
            raceLab:setString(UITool.ToLocalization(HERO_RACE_NAME[hero_race]))

        else
             print("g_channel_control.transform_ExploreResultLayer_raceType == true")
            local hero_race = hero[h_id_num].hero_race
            local raceLab = ccui.Helper:seekWidgetByName(root,"raceType")  
            raceLab:setVisible(false)


            local raceIcon = ccui.Helper:seekWidgetByName(root,"raceIcon")
            if raceIcon == nil then
                raceIcon = ccui.ImageView:create()
                raceIcon:setPosition(117,50)
                raceIcon:setName("raceIcon")
                root:addChild(raceIcon);
            end

            raceIcon:loadTexture(HERO_RACE_ICON[hero_race])
            
           

        end

        --战力
        local powerLab = ccui.Helper:seekWidgetByName(root,"power")   
        powerLab:setString(data.fp_all)
        --已派遣
        local dispatchImg = ccui.Helper:seekWidgetByName(root,"isDis")
        dispatchImg:setVisible(false)       
    end
    local bgs = {
        "n_UIShare/explore/ts_ui_024.png",
        "n_UIShare/explore/ts_ui_014.png",
        "n_UIShare/explore/ts_ui_014.png"
    }

    local panel_1 = _node:getChildByTag(101) 
    local bgImg = ccui.Helper:seekWidgetByName(panel_1,"bg")
    bgImg:loadTexture(bgs[_type])

    local iconImg = ccui.Helper:seekWidgetByName(panel_1,"icon")
    local frameImg = ccui.Helper:seekWidgetByName(panel_1,"frame")
    local elementImg = ccui.Helper:seekWidgetByName(panel_1,"element")

    local panel_2 = _node:getChildByTag(102)

    panel_2:setVisible(true) 
    iconImg:setVisible(true)
    frameImg:setVisible(true)
    setUI(panel_2,iconImg,frameImg,elementImg)
end
---todo 去优化，现在和 MapItemDrops类似
--返回
function ExploreResultLayer:initListView()
    -- body
    self.listView = ccui.Helper:seekWidgetByName(self._rootCSbNode,"drop_list")
    --set bar
    self.listView:setScrollBarEnabled(false)
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end
    local  item = cc.CSLoader:createNode("MapDropsItem.csb")
    local  item_1 = item:getChildByTag(102)
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    for i=1,3 do
        local item = item_1:clone()
        item:setPosition((i-1)*(154*0.8+15),0) --152为框的大小。缩放80%
        --local touchItem = ccui.Helper:seekWidgetByName(item_c,"Image_e_bg")
        item:setName("item"..i)
        layout_list:addChild(item)
    end
    layout_list:setContentSize(400,110)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.listView:setItemModel(layout_list)
    self.listView:removeAllItems()
    self.listView:addEventListener(listViewEvent)
    self:refreshListView()
end
function ExploreResultLayer:refreshListView()
	self.rewards  = self.resultData.explore_result.explore_drop
    self.listView:removeAllItems()
    local totalNum = #self.rewards --总数
    local row = math.ceil(totalNum /3)  -- 行数
    self.listView:setInnerContainerSize(cc.size(self.listView:getContentSize().width,LIST_ITEM_H*row))
    for i = 1,row do 
        self.listView:pushBackDefaultItem()
        local item = self.listView:getItem(i - 1)
        for m = 1, 3 do          
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)*3 + m

            if num > totalNum then
                itme_info:setVisible(false)
            else
                local reward = self.rewards[num]
                local tabs = UITool.getItemInfos(reward.type,reward.id)

                local bg = itme_info:getChildByTag(1)
                local icon = itme_info:getChildByTag(2)
                local kuang = itme_info:getChildByTag(3)
                local element = itme_info:getChildByTag(4)
                local numLabe = itme_info:getChildByTag(5)
                numLabe:setVisible(true)
                numLabe:setString("x"..reward.num)
                kuang:loadTexture(tabs[1])
                icon:setUnifySizeEnabled(true)
                icon:loadTexture(tabs[2])
                if tabs[3] == "" then 
                    element:setVisible(false)
                else
                    element:loadTexture(tabs[3])
                end
                if tabs[4]~= "" then 
                    bg:loadTexture(tabs[4])
                else

                end 
                --显示道具详情
                local function CallBackEvent( sender,eventType )
                    if eventType == ccui.TouchEventType.ended then
                       MsgManager:showSimpItemInfo(reward.type,reward.id) 
                    end
                end 
                icon:addTouchEventListener(CallBackEvent)
            end
        end
    end
    self.listView:jumpToTop()
end
---解锁关卡 lock
function ExploreResultLayer:toShowLockLayer()
    local node = self.uiLayer:getChildByTag(1)
    if node then 
        node:removeFromParent()
    end 
    node = cc.CSLoader:createNode("ExploreUnlockLayer.csb")
    self.uiLayer:addChild(node,0,1)
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:returnBack()
        end
    end
    local rootCSbNode = node:getChildByTag(102) 
    local backBtn = ccui.Helper:seekWidgetByName(rootCSbNode,"btn_confrim")
    backBtn:addTouchEventListener(touchCallBack)
    for i=1,#self.unlock_area do 
        local exploreId = self.unlock_area[i]
        local keyStr = "title_"..i
        local lab = ccui.Helper:seekWidgetByName(rootCSbNode,keyStr) 
        if lab then
            local valueStr = "["..UITool.getUserLanguage(exploerPass[exploreId].level_name).."]"
            lab:setString(valueStr)
            lab:setVisible(true) 
        end 
    end 
end
--返回
function ExploreResultLayer:returnBack()
    self.backFunc(self.sDelegate)
    self.exist = false
    self:clearEx()

    -- if user_info["guide_id"] == GuideID.Explore then
    --     NewGuideManager:startSubGuide(nil, 7)
    -- end 
end

function ExploreResultLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ExploreResultLayer:create(rData)
     local layer = ExploreResultLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
