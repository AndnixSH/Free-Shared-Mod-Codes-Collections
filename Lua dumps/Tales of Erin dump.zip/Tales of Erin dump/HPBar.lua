--我方角色和小怪的血条
--created by kobejaw 2018.6.3.

HPBar = class("HPBar", function()
    return cc.Node:create();
end);

function HPBar:ctor(entity)
	self.entity = entity --添加HPBar的对象
    self.entityType = entity.entityType

	self.rootNode = cc.CSLoader:createNode(BattleGlobals.HPBAR)
	self:addChild(self.rootNode)

    self.visibleTime = 1;
    self.state = 0; --0为隐藏，1为显示。只对小怪有效。
    if self.entityType == 2 then
        self.visibleTime = 5;
        self.state = 0; --0为隐藏，1为显示。只对小怪有效。        
        self:setVisible(false)
    end

	self.bar = self.rootNode:getChildByTag(2)
	self.elementIcon = self.rootNode:getChildByTag(1)

	self.rootNode:setAnchorPoint(cc.p(0,0.5));
    self.rootNode:setPosition(-80, -15);
    self.bar:setPercent(math.ceil(100 * self.entity.attr[AE.hp]/self.entity.attr[AE.hp_max]))

    if self.entity.entityType == 1 then
    	self.bar:loadTexture(BattleGlobals.HP_Res_role)
    else
    	self.bar:loadTexture(BattleGlobals.HP_Res_monster)
    	self:setRotationSkewY(180)
    end

    local icon
    if self.entity.attr[AE.element] == 1 then
    	icon = "n_UIShare/Global_UI/element/ggsc_ui_126.png"
    elseif self.entity.attr[AE.element] == 2 then
    	icon = "n_UIShare/Global_UI/element/ggsc_ui_125.png"
    elseif self.entity.attr[AE.element] == 3 then
    	icon = "n_UIShare/Global_UI/element/ggsc_ui_127.png"
    elseif self.entity.attr[AE.element] == 4 then
    	icon = "n_UIShare/Global_UI/element/ggsc_ui_128.png"
    else
    	icon = "n_UIShare/Global_UI/element/ggsc_ui_129.png"
    end

    self.elementIcon:loadTexture(icon)

    --如果是爬塔的非boss关卡。先显示一下小怪的血量。
    if G_STAGE_TYPE == 3 and not self.entity.isBoss then
        self.visibleTime = 5;
        self.state = 1       
        self:setVisible(true)
        self.bar:setPercent(100 * self.entity.attr[AE.hp]/self.entity.attr[AE.hp_max])
    end
end

--只对小怪有效。
function HPBar:update(dt)
    if self.state == 1 then
        self.visibleTime = self.visibleTime - dt
        if self.visibleTime <= 0 then
            self.visibleTime = 5
            self.state = 0
            self:setVisible(false)
        end
    end
end

function HPBar:onHPChanged()
    if self.entityType == 2 and self.state == 0 then
        self.visibleTime = 5
        self.state = 1
        self:setVisible(true)
    end
	self.bar:setPercent(100 * self.entity.attr[AE.hp]/self.entity.attr[AE.hp_max])
end

--复活时调用
function HPBar:onRevive()
    self.bar:setPercent(100)
end