
--[[
    屏幕适配层 主场景
]]

ScreenFitMainLayer = class("ScreenFitMainLayer", function()  
                return cc.Layer:create()  
                end)



function ScreenFitMainLayer:initialize(infoStr)

    local node =cc.CSLoader:createNode("ScreenFitMainLayer.csb")
    if node then
    	self:addChild(node,100,2)
    end
    

end

function ScreenFitMainLayer:create(infoStr)
     local layer = ScreenFitMainLayer.new()
     layer:initialize(infoStr)
     return layer
end
