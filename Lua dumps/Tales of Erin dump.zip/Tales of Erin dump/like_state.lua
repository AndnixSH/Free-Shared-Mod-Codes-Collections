-- 好感度的8种状态
-- 7, 8 均为特效

like_state = {}
like_state[1] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_310.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_304.png",
     special_effect = "",
     detail_special_effect = "",
     resonance_special_effect = "",
} 
like_state[2] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_309.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_303.png",
     special_effect = "",
     detail_special_effect = "",
     resonance_special_effect = "",
} 
like_state[3] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_308.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_302.png",
     special_effect = "",
     detail_special_effect = "",
     resonance_special_effect = "",
} 
like_state[4] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_307.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_301.png",
     special_effect = "",
     detail_special_effect = "",
     resonance_special_effect = "",
} 
like_state[5] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_306.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_300.png",
     special_effect = "",
     detail_special_effect = "",
     resonance_special_effect = "",
} 
like_state[6] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_311.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_312.png",
     special_effect = "",
     detail_special_effect = "",
     resonance_special_effect = "",
} 
like_state[7] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_306.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_300.png",
     special_effect = "Resources/armatures/intimacy/gong_ming_man/gong_ming_man.atlas",
     detail_special_effect = "Resources/armatures/intimacy/gong_ming_fen_2/gong_ming_fen_2.atlas",
     resonance_special_effect = "Resources/armatures/intimacy/gong_ming_fen_1/gong_ming_fen_1.atlas",
} 
like_state[8] = {
     icon_max = "uifile/n_UIShare/Intimacy/ggsc_ui_311.png",
     icon_min = "uifile/n_UIShare/Intimacy/ggsc_ui_312.png",
     special_effect = "Resources/armatures/intimacy/gong_ming_man/gong_ming_man.atlas",
     detail_special_effect = "Resources/armatures/intimacy/gong_ming_hong_2/gong_ming_hong_2.atlas",
     resonance_special_effect = "Resources/armatures/intimacy/gong_ming_hong_1/gong_ming_hong_1.atlas",
} 