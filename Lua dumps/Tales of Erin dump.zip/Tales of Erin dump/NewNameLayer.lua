--NewNameLayer.lua
--[[
NewNameLayer.lua
--起名字
]]
NewNameLayer = class("NewNameLayer",BasicLayer)

function NewNameLayer:ctor(data)
    -- body
    self.data = data 
    self.sManager = data.sManager
    self:init()
end

function NewNameLayer:init()
	self.uiLayer = cc.Layer:create()
	local size = cc.Director:getInstance():getWinSize()
    self.size = size
    self.maxLength = 6
    self:showNameUI()
    self.exist = true
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        
    end)
end
--起名字UI
function NewNameLayer:showNameUI()
    local node = cc.CSLoader:createNode("NewNameLayer.csb")
    self.uiLayer:addChild(node,0, 2)
    
    self._rootCSbNode = node:getChildByTag(101) 
    self.uiNode = node

    local function onCickBtn(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:toReqUserCreate()
        end
    end 

    local btn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_confirm")
    btn:addTouchEventListener(onCickBtn)
    --随机名字
    local function onCickRandomBtn(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:randomName()
        end
    end 
    local randomBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_2")
    randomBtn:addTouchEventListener(onCickRandomBtn)
    local bOpenRandomName = g_channel_control.b_random_name
    randomBtn:setVisible(bOpenRandomName)
    randomBtn:setEnabled(bOpenRandomName)

    local Text_1 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Text_1")
    Text_1:setString(UITool.ToLocalization("   请输入您的名字:"))

    self.inputText =  ccui.Helper:seekWidgetByName(self._rootCSbNode,"input")
    --self.inputText:setPlaceHolder("请输入名字")
    self.inputText:setMaxLength(42)
    self.inputText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.inputText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    self.inputText:setTouchEnabled(false)

    self.inputPanel =  ccui.Helper:seekWidgetByName(self._rootCSbNode,"input_top")

    self.inputPanel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:popInputView()
        end
    end)
    --先随机一次名字
    if g_channel_control.b_random_name == true then
        self:randomName()
    else
        self.inputText:setText("")
    end
end

function NewNameLayer:popInputView()
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  function(self,text)
        self.inputText:setString(text)
    end
    rcvData["defalutStr"] = self.inputText:getString()
    rcvData["maxLength"] = self.maxLength
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    SceneManager:toInputModelLayer(rcvData)
end

--随机名字
function NewNameLayer:randomName()
    -- body
    --测试随机名字
    --随机个姓和名 。现在只随机名字
    math.randomseed(os.time())
    local keyIdxA = math.random(1, #name_a)
    local keyIdxB = math.random(1, #name_b)
    local keyIdxC = math.random(1, #name_c)


    if g_channel_control.newNameRandom == true then 
            --欧美服只取name_a,后缀使用1-99 随机
        local nameA = UITool.getUserLanguage(name_a[keyIdxA]) or UITool.getUserLanguage(name_a[1])
        local nameB = tostring(math.random(1,99))--name_b[keyIdxB] or name_a[2]

        self.inputText:setText(nameA..nameB)     
    else 
        local nameA = UITool.getUserLanguage(name_a[keyIdxA]) or UITool.getUserLanguage(name_a[1])
        local nameB = UITool.getUserLanguage(name_b[keyIdxB]) or UITool.getUserLanguage(name_a[2])
        local nameC = UITool.getUserLanguage(name_c[keyIdxC]) or UITool.getUserLanguage(name_a[3])

        self.inputText:setText(nameA..nameB..nameC)
    end

end

--起名字UI
function NewNameLayer:toReqUserCreate()
    --验证名字
    local newNameStr =  self.inputText:getString()
    local isOK = self:checkStr(newNameStr) 
    if isOK then 
        self:reqUserCreate()
    end 
end

function NewNameLayer:reqUserCreate()
    -- body
    --获取数据成功
    self.nowName = self.inputText:getString()
    local function ReqSuccess(data)
        --todo刷新数据
        user_info["name"] = self.nowName
        self.sManager.menuLayer:RefshTopBar()
        self:endName()

        --聊天室同步数据
        XBChatSys:getInstance():updateMyUserNameForChat()
       
    end
    local tempTable = {
        ["rpc"] = "change_pl_name",
        ["name"] = self.nowName,
    }
    self:doReq(tempTable, ReqSuccess)
end

function  NewNameLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            --failesFunc()
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

---说明这个只会调用一次
---所以不做判断了
function NewNameLayer:endName()
    --结束加点新手引导
    XbTriggerGuideManager:finishGuide(TriggerGuideConfig.NewName, self)
    self:clear()
end

function NewNameLayer:clear()
    self.uiLayer:removeFromParent()
    self.exist = false
    -- body
end

function NewNameLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function NewNameLayer:create(data)
	local layer = NewNameLayer.new(data)
    return layer
end

--检测输入 内容
function NewNameLayer:checkStr(text)
    local isOK = false
    if text~="" then 
        ---处理屏蔽词
        local isNoWarn = self:isNoWarningStr(text)
        if isNoWarn then 
            ---字符串长度
            local isLengthOK = self:checkMaxLengthStr(text)
            if isLengthOK then
                isOK = true
            end 
        end 
    else 
        local str = UITool.ToLocalization("不能为空")
        SceneManager:showPromptLabel(str)
    end 
    return isOK
end

---检测敏感词,有敏感词 返回false 没有敏感词返回OK
function NewNameLayer:isNoWarningStr(text)
    local isOK = true
    return isOK
end

---检测 字符串长度
--特殊说明 两个英文算一个。11.23修改
function NewNameLayer:checkMaxLengthStr(text)
    --获取长度 如果别的地方也用 放到公共里面吧
    local function getCharLength(str)
        str = str or ""
        local strLength = 0
        local len = string.len(str)
        while str do
            local fontUTF = string.byte(str,1)

            if fontUTF == nil then
                break
            end
            --lua中字符占1byte,中文占3byte
            if fontUTF > 127 then 
                local tmp = string.sub(str,1,3)
                strLength = strLength+1
                str = string.sub(str,4,len)
            else
                local tmp = string.sub(str,1,1)
                strLength = strLength+0.5
                str = string.sub(str,2,len)
            end
        end
        return strLength
    end
    local isOK = true

    local nowLength = getCharLength(text)
    print("当前字符串长度  "..nowLength)
    if nowLength > self.maxLength then 
        local str =string.format(UITool.ToLocalization("你输入的内容长度已超出%d个字的限制，请重新输入"), self.maxLength)
        SceneManager:showPromptLabel(str)
        isOK = false 
    end
    return isOK
end
