--require "XUIView"
--require "RoleAwakenView"
--require "RoleSthView"
--require "RoleTeamView"
--require "RoleListView"
--require "SortBoxView"

RoleMainView = class("RoleMainView",XUIView)
RoleMainView.CS_FILE_NAME = "RoleMainView.csb"
RoleMainView.CS_BIND_TABLE = 
{
    vpanel="/i:16",
    btnTab1="/i:3/i:4",
    btnTab2="/i:3/i:5",
    btnTab3="/i:3/i:6",
    btnTab4="/i:3/i:7",
    btnTab4Tip="/i:3/i:7/i:266",
    btnClose="/i:15/i:9"
}

function RoleMainView:init(tab)
    RoleMainView.super.init(self)
    self.exist = true
    self.views = XUIView.new():init(self.vpanel)

    self.roleSthView = RoleSthView.new():init()
    self.roleSthView.effectStopedEvent = function()
        self:refreshSkillPointTip()
    end
    self.roleSthView.matChangedEvent = function()
        self:loadBagList()
    end
    self.views:addSubView(self.roleSthView)

    self.roleAwakenView = RoleAwakenView.new():init()
    self.roleAwakenView.effectStopedEvent = function()
        self:refreshSkillPointTip()
    end
    self.roleAwakenView.matChangedEvent = function()
        self:loadBagList()
    end
    self.views:addSubView(self.roleAwakenView)

    if g_channel_control.b_newRole then
        self.roleTeamView = NewRoleTeamView.new():init()
    else
        self.roleTeamView = RoleTeamView.new():init()
    end
    self.views:addSubView(self.roleTeamView)

    self.roleListView = RoleListView.new():init()
    self.roleListView.ItemClickedEvent = function(item)
        local hlist = {}
        local tempds = self.roleListView.currentDataSource
        for i = 1,#tempds do
            table.insert(hlist,tempds[i].id)
        end
        if GameManagerInst.gameType == 1 then
            if g_channel_control.b_newRole then
                GameManagerInst.view:pushView(NewRoleMainView.new():init(item:getData().id,hlist))
            else
                GameManagerInst.view:pushView(RoleInfoView.new():init(item:getData().id,hlist))
            end
        elseif GameManagerInst.gameType == 2 then
            SceneManager:toRoleInfo({ hid = item:getData().id,
            hlist = hlist
            })
        end
    end
    self.roleListView:setShowSkillPoint(true)

    self.views:addSubView(self.roleListView)

    self:switchView(tab)

    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
        --self:addSubView(SortBoxView.new():init())
    end)

    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
        --角色强化
        if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.StHero) == 0 then
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.StHero, 1)
        end
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
        ---角色潜能解放
        if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.HeroBT) == 0 then
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.HeroBT, 1)
        end

    end)

    self.btnTab4:setPressedActionEnabled(false)
    self.btnTab4:addClickEventListener(function()
        self:switchView(4)
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self.roleTeamView:saveTeamIndex(function()
            self:returnBack()
        end)
    end)
    
    self.btnTab4Tip:setVisible(false)

    self.dataLoaded = false

    self:setNodeLockState()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

function RoleMainView:MainViewSaveTeamIndex( ... )
     self.roleTeamView:saveTeamIndex()
end

function RoleMainView:beginLoadData()
    GameManagerInst:rpc("{\"rpc\":\"hero_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        DataManager:wAllHeroData(data["hero_list"])
		DataManager:wAllBagData({mat = data["mat"]})

        self:beginLoadData2()
    end,
    function(state_code,msgText)
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function RoleMainView:beginLoadData2()
    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        DataManager:wTeamData(data["team"])

        -- self:beginLoadData3()
        
        self.dataLoaded = true
        self:refresh()
    end,
    function(state_code,msgText)
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end


-- function RoleMainView:beginLoadData3()
--     GameManagerInst:rpc("{\"rpc\":\"eq_list\"}",3,
--     function(data)
--         --success
--         user_info["eq"] =  data["eq"]
--         DataManager:rfsElist()   
--         for k,v in pairs(data["mat"]) do
--             user_info["bag"]["mat"][k] = v
--         end

--         self.dataLoaded = true
--         self:refresh()
--     end,
--     function(state_code,msgText)
--         --failed
--         GameManagerInst:alert(msgText)
--     end,
--     true)
-- end

function RoleMainView:loadBagList()
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
		DataManager:wAllBagData(data["bag"])
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function RoleMainView:refresh()
    if self.dataLoaded then
        if self.curTab == 1 then
            self.roleTeamView:refresh()
        elseif self.curTab == 2 then
            self.roleSthView:refresh()
        elseif self.curTab == 3 then
            self.roleAwakenView:refresh()
        elseif self.curTab == 4 then
            self.roleListView:refresh()
        end

        self:refreshSkillPointTip()
    end
    self:updateRedDotPrompt()
end

function RoleMainView:refreshSkillPointTip()
    self.btnTab4Tip:setVisible(false)
    
    for i = 1,#hero_list do
        if hero_list[i]["tp"]["num"] > 0 then
            self.btnTab4Tip:setVisible(true)
            break
        end
    end
end

function RoleMainView:switchView(tab)
    local num = tab or 1

    if self.curTab ~= num then
        local ctls = {
            {btn = self.btnTab1, view= self.roleTeamView},
            {btn = self.btnTab2, view= self.roleSthView},
            {btn = self.btnTab3, view= self.roleAwakenView},
            {btn = self.btnTab4, view= self.roleListView}
        }

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            ctls[i].btn:setBright(i ~= num)
            ctls[i].view:getRootNode():setVisible(i == num)
        end

        self.curTab = num

        self:refresh()
    end
    --新手引导 编队
    if NewGuideManager._nowGuideID == guide_id_config.Team then
        NewGuideManager:startSubGuide(self,2)
    end

    self:dealTriggerGuide(tab)
end
 ----------------todo优化：以下新手引导，有重复代码，可以重构 ，不做完之前建议不处理，防止策划调整步骤
function RoleMainView:dealTriggerGuide(tab)
    --触发引导-角色强化
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.StHero) then 
        if tab == 2 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.StHero)--选择角色
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.StHero)--角色强化
        end
    end 

    --触发引导-角色技能+点
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.RoleSkill) then 
        if tab == 4 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.RoleSkill)--选择角色
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.RoleSkill)--角色一览
        end
    end 

    --触发引导-女主神格
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Godhead) then 
        if tab == 1 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.Godhead)--切换女主按钮
        end 
    end

    --触发引导-装备
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Equip) then 
        if tab == 4 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.Equip)--选择角色
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.Equip)--角色一览
        end
    end

    --触发引导-潜能解放
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.RoleTP) then 
        if tab == 3 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.RoleTP)--选择角色
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.RoleTP)--潜能解放
        end
    end 

    --触发引导-魂装
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.HunEquip) then 
        if tab == 4 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.HunEquip)--选择角色
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.HunEquip)--角色一览
        end
    end

    --触发引导-星盘
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Star) then 
        if tab == 4 then 
            XbTriggerGuideManager:showTriggerGuide(nil, 4, TriggerGuideConfig.Star)--选择角色
        else 
            XbTriggerGuideManager:showTriggerGuide(nil, 3, TriggerGuideConfig.Star)--角色一览
        end
    end
    
end

function RoleMainView:returnBack()
    self.exist = false
    if self._navigationView then
        self._navigationView:popView()
    end
end

function RoleMainView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        self:refresh()
    else
        self:beginLoadData()
    end
end
--设置按钮等级解锁状态
function RoleMainView:setNodeLockState()

    if g_channel_control.UIVersion < 2 then
        local curNodes = {self.btnTab2, self.btnTab3}
        for i=1,#curNodes do
            local config = guide_rank_config["RoleMainView"][i]
            local btn = curNodes[i]
            if config.unlock_level > tonumber(user_info["rank"]) then 
                if config.state == 0 then 
                    btn:setVisible(false)
                end 
            end 
        end
    else
        UnlockSys:getInstance():bindLock(4, self.btnTab2, true)
        UnlockSys:getInstance():bindLock(5, self.btnTab3, true)

    end
  

   
end
--设置小红点提醒
function RoleMainView:updateRedDotPrompt()
    local btns = {self.btnTab2,self.btnTab3}  --强化，突破
    local keys = {RedDotPromptKey.StHero, RedDotPromptKey.HeroBT}
    for i=1,#btns do 
        local btn = btns[i]
        UITool.setCommmonBtnRedDop(btn,false)
        if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..keys[i]) == 0 then 
            UITool.setCommmonBtnRedDop(btn,true,cc.p(145,81))
        end  
    end 
end