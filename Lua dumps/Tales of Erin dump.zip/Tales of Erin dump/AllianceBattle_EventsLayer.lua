--新版公会战的事件点层。2018.10.23
--注：新添加了用钥匙创建单人或者多人战。但是加入公会战暂不支持钥匙，只能用金币加入。
AllianceBattle_EventsLayer = class("AllianceBattle_EventsLayer", function()
    return cc.Layer:create();
end);

function AllianceBattle_EventsLayer:ctor(mapPointData,fatherLayer,guild_battle_event)
    self.guild_battle_event = guild_battle_event
    self.mapPointData = mapPointData
    self.fatherLayer = fatherLayer
    local root = cc.CSLoader:createNode("AllianceBattle_EventsLayer.csb")
    self:addChild(root)
    self.rootPanel = root:getChildByTag(263)
    self:init()
end

function AllianceBattle_EventsLayer:init()
    self.listView = self.rootPanel:getChildByTag(294);
    
    --bg图片
    if self.mapPointData.bg_pic_path and self.mapPointData.bg_pic_path ~= "" then
        self.rootPanel:setBackGroundImage(self.mapPointData.bg_pic_path) 
    end

    --返回按钮
    local closeBtn = self.rootPanel:getChildByTag(385);
    closeBtn:addClickEventListener(function()
        self.fatherLayer.mapDataIdx = nil;
        self:removeFromParent()
    end)

    --挑战之钥按钮和面板
    self.challengeKeyBtn = self.rootPanel:getChildByTag(99)
    self.challengeKeyPanel = self.rootPanel:getChildByTag(100)
    local totalKeysNum,totalKeys_player = self:initChallengeKeyPanel() --需要的钥匙总数
    if totalKeysNum > 0 then
        local text = self.challengeKeyBtn:getChildByTag(387)
        text:setString(totalKeys_player)
        self.challengeKeyBtn:setVisible(true)
        self.isKeyPanelShowing = false

        self.challengeKeyBtn:addClickEventListener(function()
            if self.isKeyPanelShowing then
                self.isKeyPanelShowing = false
                self.challengeKeyPanel:setVisible(false)
            else
                self.isKeyPanelShowing = true
                self.challengeKeyPanel:setVisible(true)
            end
        end)
    else
        self.challengeKeyBtn:setVisible(false)
        self.challengeKeyPanel:setVisible(false)
    end
    --关卡
    if #self.mapPointData.events > 1 then
        self:initEventBtns()
        self:refreshKeyBubble()
    end
    self:createLevelsOfEvent(self.mapPointData.events[1])
end

--初始化事件按钮
function AllianceBattle_EventsLayer:initEventBtns()
    self.currChannel = 1;
    self.switchBtns = {};
    self.switchImageTable_1 = {};
    self.switchImageTable_2 = {};
    self.bubbleNodeTable = {}

    local eventNum = #self.mapPointData.events    

    for i = 1,eventNum do

        local eventId = tonumber(self.mapPointData.events[i].event_id)

        self.switchBtns[i] = self.rootPanel:getChildByName("Button_"..i)
        self.switchImageTable_1[i] = self.rootPanel:getChildByName("SwichImage"..i)
        self.switchImageTable_2[i] = self.rootPanel:getChildByName("SwichImage"..i+5)

        -- local no_select_pic = guild_battle["event"][eventId]["no_select"]
        -- local select_pic = guild_battle["event"][eventId]["selected"]
        local no_select_pic = self.guild_battle_event[eventId]["no_select"]
        local select_pic = self.guild_battle_event[eventId]["selected"]

        if no_select_pic ~= "" then
            self.switchImageTable_1[i]:setTexture(no_select_pic)
        end

        if select_pic ~= "" then
            self.switchImageTable_2[i]:setTexture(select_pic)
        end
        
        self.bubbleNodeTable[i] = self.rootPanel:getChildByName("NodeForBubble_"..i)

        self.switchBtns[i]:setVisible(true)
        self.switchImageTable_1[i]:setVisible(true)

        self.switchBtns[i]:addClickEventListener(function()
            if i == self.currChannel then
                return
            else
                self.switchImageTable_1[self.currChannel]:setVisible(true)
                self.switchImageTable_2[self.currChannel]:setVisible(false)
                self.switchImageTable_1[i]:setVisible(false)
                self.switchImageTable_2[i]:setVisible(true)
                self.currChannel = i;
                self:createLevelsOfEvent(self.mapPointData.events[i])
            end
        end)
    end

    self.switchImageTable_1[1]:setVisible(false);
    self.switchImageTable_2[1]:setVisible(true);        
end

--初始化挑战之钥对应的面板,返回需要钥匙的总数，如果为0则不显示挑战之钥的按钮和面板
function AllianceBattle_EventsLayer:initChallengeKeyPanel()
    local totalEventNum = #self.mapPointData.events
    local totalKeys = 0 --所需的钥匙总数
    local totalKeys_player = 0

    local rowsList = {} --钥匙列表，元素是行table

    for i = 1,totalEventNum do    
        local dataList = {}  --每行的数据,最多3个数据。
        local idx = 0
        for k,v in ipairs(self.mapPointData.events[i].level_list) do
            if v.need_type == 3 and v.key_num and v.key_num>0 then
                totalKeys = totalKeys + v.key_num
                totalKeys_player = totalKeys_player + v.key_num_player
                idx = idx + 1
                if (idx-1)%3 == 0 then  --换行
                    dataList = {}
                    table.insert(dataList,v)
                    table.insert(rowsList,dataList)
                else
                    table.insert(dataList,v)
                end
            end
        end
    end

    local rowNum = #rowsList
    if rowNum > 0 then
        for k,v in ipairs(rowsList) do
            local rowIdx = (rowNum + 1 - k )             --行
            for columnIdx,data in ipairs(v) do           --列
                local node = cc.CSLoader:createNode("AllianceBattle_Node_KeyOfChallenge.csb")
                self.challengeKeyPanel:addChild(node)

                local image = node:getChildByName("Image_1")
                local num = node:getChildByName("Text_1")

                if mat[data.key_id] and mat[data.key_id].icon then
                    local picPath = "res/hd/Resources/icons/mat/"..tostring(mat[data.key_id].icon)
                    image:loadTexture(picPath)
                end
                --num:setString(data.key_num)
                num:setString(data.key_num_player)
                node:setPosition(16 + (columnIdx-1) * 89,13 + (rowIdx-1) * 50)
            end
        end
        self.challengeKeyPanel:setContentSize(cc.size(262,26+50*rowNum))
        self.challengeKeyPanel:setVisible(false)
    end

    return totalKeys,totalKeys_player
end

--显示钥匙气泡
function AllianceBattle_EventsLayer:refreshKeyBubble()
    local eventNum = #self.mapPointData.events    
    if eventNum <= 1 then
        return
    end

    local flag = {}

    for i = 1,eventNum do    
        for k,v in ipairs(self.mapPointData.events[i].level_list) do
            if v.need_type == 3 and v.key_num_player >= v.key_num then
                if not flag[i] then
                    flag[i] = true
                    local skeletonNode = sp.SkeletonAnimation:create("n_UIShare/AllianceBattle/tuan_zhan_qi_pao.json", "n_UIShare/AllianceBattle/tuan_zhan_qi_pao.atlas",1)
                    skeletonNode:setAnimation(1, "effect", true)
                    self.bubbleNodeTable[i]:setVisible(true)
                    self.bubbleNodeTable[i]:addChild(skeletonNode)
                end
            end
        end
    end
end

--创建某个事件点对应的所有关卡
function AllianceBattle_EventsLayer:createLevelsOfEvent(eventData)
    self.listView:removeAllItems()

    local levelList = eventData.level_list
    local levelNum = #levelList
    if levelNum == 0 then
        print("关卡数量为0")
        return
    end

    local levelType = eventData.level_type
    local levelId = eventData.event_id

    --显示关卡列表层
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
            if self.isTouchRewerd then --如果是点击奖励查看，直接返回
                do return end 
            end 
            local pointIdx = sender:getCurSelectedIndex() + 1
            local levelData = levelList[pointIdx]

            --钥匙数量不足
            if levelData.need_type == 3 then
                if levelData.key_num_player < levelData.key_num then
                    MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("所需道具不足"),nil);
                    return
                end
            end

            --点击关卡进入战斗准备界面
            if levelType == 1 then
                self:onClickSinglePass(levelData)
            else
                self:onClickMullPass(levelData)
            end
        end
    end
    
    self.listView:addEventListener(listViewEvent)
    self.listView:setScrollBarEnabled(true)              
    self.listView:setScrollBarWidth(20)
    self.listView:setScrollBarColor(cc.c3b(255, 255, 255))
    self.listView:setScrollBarOpacity(225*0.5)
    self.listView:setScrollBarPositionFromCorner(cc.p(2,2))
    self.listView:setTouchTotalTimeThreshold(0.1)
    self.listView:setInnerContainerSize(cc.size(self.listView:getContentSize().width,200*levelNum))

    if #levelList > 1 then
        self.rootPanel:addTouchEventListener(function()
            if self.isKeyPanelShowing then
                self.isKeyPanelShowing = false
                self.challengeKeyPanel:setVisible(false)
            end            
        end)
    end

    for k,v in ipairs(levelList) do
        self:addOneLevelItem(v)
    end
end

--创建一个listview的item
function AllianceBattle_EventsLayer:addOneLevelItem(levelData)
    local level_id = levelData.level_id
    local levelData_local = battlePass[level_id] or actPass[level_id]
    if levelData_local == nil then
        print("本地无法读取到关卡数据")
       return
    end

    local layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0,1))
    local item_1 = cc.CSLoader:createNode("AlliacneBattle_LevelItem.csb"):getChildByTag(174)
    local item_c = item_1:clone()
    item_c:setPosition(cc.p(0,0))
    layout:addChild(item_c)
    layout:setContentSize(610,160)
    layout:setTouchEnabled(true)
    self.listView:pushBackCustomItem(layout)

    --BG。消耗体力或者钥匙。
    local bgImage = item_c:getChildByTag(20)
    local image_key = item_c:getChildByTag(54)
    local costNum = ccui.Helper:seekWidgetByTag(item_c,101)
    costNum:enableOutline(cc.c4b(81,23,0,255),3)
    costNum:setFontSize(30)
    if levelData.need_type == 1 then  --消耗体力
        costNum:setString(levelData["need_ap"])
    elseif levelData.need_type == 2 then --消耗金币
        print("配表错误，公会战战斗不支持金币创建")
        return
    else --消耗钥匙
        bgImage:loadTexture("n_UIShare/AllianceBattle/ghz_ui_033.png")
        costNum:setString(levelData["key_num"])
        image_key:setVisible(true)
        if mat[levelData.key_id] and mat[levelData.key_id].icon then
            local key_icon = "res/hd/Resources/icons/mat/"..tostring(mat[levelData.key_id].icon)
            image_key:loadTexture(key_icon)
        end

        --钥匙数量不足，置灰
        if levelData.key_num_player < levelData.key_num then
            local mask = item_c:getChildByTag(119)
            mask:setVisible(true)
        end
    end

    --通关奖励
    --道具类型 1金币 2星石 3装备 4英雄 5 素材 6 可使用道具 7礼包 8 碎片
    local rewards = levelData_local["finish_reward"][1]
    local reward_icon
    if rewards~=nil then 
        local IconType = rewards["type"]
        local item_id = rewards["id"]
        reward_icon = UITool.getItemIcon(IconType,item_id)
    else
        reward_icon = Coin_Icon[1] --如果没有图，返回默认的
    end
    local passRewardImg = ccui.Helper:seekWidgetByTag(item_c,170)
    passRewardImg:setUnifySizeEnabled(true)
    passRewardImg:loadTexture(reward_icon)
    passRewardImg:setScale(0.7)

    --名称
    local title = ccui.Helper:seekWidgetByTag(item_c,102)
    title:setString(UITool.getUserLanguage(levelData_local["level_name"]))--(levelData_local["level_name"])

    --icon
    local iconImageView = ccui.Helper:seekWidgetByTag(item_c,30)
    if iconImageView ~= nil then
       iconImageView:loadTexture(levelData_local["level_icon"])
    end

    --关卡属性
    local elementView = ccui.Helper:seekWidgetByTag(item_c,235)
    if elementView ~= nil then
        elementView:loadTexture(ATB_Icon[levelData_local["level_atb"]])
    end

    --限制时间
    local text_1 = ccui.Helper:seekWidgetByTag(item_c,104)
    text_1:setString(UITool.getFormatTime(levelData_local["level_limit"]))

    --推荐等级
    local Lvtitle = ccui.Helper:seekWidgetByTag(item_c,103)
    Lvtitle:setString(levelData_local["commend_lv"])

    --第几章第几话
    local title2 = ccui.Helper:seekWidgetByTag(item_c,1022)
    title2:setString(UITool.getUserLanguage(levelData_local["level_num"]))--(levelData_local["level_num"])

    --关卡奖励 
    local function rewardTouchCallBack(sender,eventType)
        if eventType == TOUCH_EVENT_BEGAN then
            self.isTouchRewerd = true
        end
        if eventType == TOUCH_EVENT_ENDED then
            self.isTouchRewerd = false 
            local data = {}
            data.title = UITool.getUserLanguage(levelData_local["level_name"])--levelData_local["level_name"]
            data.rewards = levelData_local["drop_reward"]
            data.level_is_boss = levelData_local["level_is_boss"]
            data.level_id = level_id
            self:toMapItemDropsLayer(data)
        end
    end 
    local rewardBtnImg = ccui.Helper:seekWidgetByTag(item_c,50)
    rewardBtnImg:setTouchEnabled(true)
    rewardBtnImg:setSwallowTouches(true)
    rewardBtnImg:addTouchEventListener(rewardTouchCallBack)
    if levelData_local["level_is_boss"] == 1 then 
        rewardBtnImg:loadTexture("n_UIShare/bossAtbSort/cxbh_ui_003.png")
        rewardBtnImg:setUnifySizeEnabled(true)
    end
end


function AllianceBattle_EventsLayer:onClickSinglePass(data)
    local requestData = {} 
    requestData["name"] =  UITool.getUserLanguage(actPass[data["level_id"]]["level_name"])--actPass[data["level_id"]]["level_name"]
    requestData["lv"] = actPass[data["level_id"]]["level_lv"]
    requestData["ap"] = data["need_ap"]
    requestData["b_id"] = data["battle_id"]

    SceneManager:toReadyLayer(requestData)
end

function AllianceBattle_EventsLayer:onClickMullPass(data)
    local requestData = {} 

    requestData["name"] =  UITool.getUserLanguage(battlePass[data["level_id"]]["level_name"])--battlePass[data["level_id"]]["level_name"]
    requestData["lv"] = battlePass[data["level_id"]]["level_lv"]
    requestData["ap"] = data["need_ap"]
    requestData["b_id"] = data["battle_id"]
    requestData["mode"] = "mutable"
    
    local state = data["level_state"]
    if state == 2 then --加入多人战
        print("服务器数据错了，这里的state应该为1")
    end

    SceneManager:toReadyLayer(requestData)
end

--查看掉落
function AllianceBattle_EventsLayer:toMapItemDropsLayer(data)
    local rcvData = {}
    rcvData["data"] =  data
    if data.level_is_boss == 1 then 
        SceneManager:toBossInformationLayer(rcvData)
    else 
        SceneManager:toMapItemDropsLayer(rcvData)
    end 
end
