require "BasicLayer"
-- 登陆奖励
AllianceBattle_ShopLayer = class("AllianceBattle_ShopLayer",BasicLayer)
AllianceBattle_ShopLayer.__index   = AllianceBattle_ShopLayer
AllianceBattle_ShopLayer.lClass    = 2 
AllianceBattle_ShopLayer.medal     = 0 -- 消耗道具奖章


function AllianceBattle_ShopLayer:init()
    print("进入商店初始化函数")
    local node = nil
    if g_channel_control.show_new_guild_main == true and self.rData["_type"] == 3 then
        node = cc.CSLoader:createNode("GuildShopLayer_new.csb")
    else
        node = cc.CSLoader:createNode("AllianceBattle_ShopLayer.csb")
    end
    self.uiLayer:addChild(node,0,2)
    self.panel = node:getChildByName("Panel_5")
    self.ListView = self.panel:getChildByName("ListView_1")
    if self.rData["_type"] == 1 then -- 团战
        self.sendShopName = "guildbattle_shop"
        self.sendBuyName  = "guildbattle_buy"
    elseif self.rData["_type"] == 2 then -- 极限挑战
        self.sendShopName = "ultimete_cha_shop"
        self.sendBuyName  = "ultimete_cha_buy"
    elseif self.rData["_type"] == 3 then -- 公会商店
        self.sendShopName = "guild_shop"
        self.sendBuyName  = "guild_buy"
    end
    self.isDownTiem = false

    self:initMode()
    self:initBtn()
    self:Send()
    self:setCostNum()

end

function AllianceBattle_ShopLayer:initBtn( ... )
    -- body

    print("到了这里面了")
    local node      = self.uiLayer:getChildByTag(2)
    local  btnClose   = node:getChildByName("Button_close")
    local curCostIcon =  self.panel:getChildByName("Image_medal")
    local HelpBtn     = self.panel:getChildByName("btnHelp")
    HelpBtn:setVisible(false)
    if self.rData["_type"] == 1 then -- 标签形式 团战
        btnClose:setVisible(false)
    elseif self.rData["_type"] == 2 then -- 跳界面形式 极限
        btnClose:setVisible(true)
        curCostIcon:setUnifySizeEnabled(true)
        curCostIcon:loadTexture("n_UIShare/UltimateChallenge/jxtz_ui_015.png")
    elseif self.rData["_type"] == 3 then -- 跳界面形式 公会
        btnClose:setVisible(false)
        curCostIcon:setUnifySizeEnabled(true)
        curCostIcon:loadTexture("n_UIShare/guild/newGuild/gh_ui_011.png")
        HelpBtn:setVisible(true)
    end

    
    local function btnCallBack( sender,eventType)
        -- body
        if eventType == ccui.TouchEventType.ended  then
           if sender:getName() == "Button_close" then
               -- AudioManager:shareDataManager():playMusic("music/ui/likaishop.mp3", 1,false)
                self:returnBack()
            end
        end
    end
    btnClose:addTouchEventListener(btnCallBack)
    if g_channel_control.show_new_guild_main == true then
        HelpBtn:setVisible(false)
    else
        HelpBtn:addClickEventListener(function()
            local data = {}
            data.pictures = { --一张或者多张
                "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
                "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
                "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
            }
            local sData = {}
            sData["prefix"] = "gh"
            sData["fontSize"] = 20
            sData["Iamgdata"] = data
            SceneManager:toPublicHelpText(sData)
        end)
    end
    -- HelpBtn:addClickEventListener(function()
    --     --self:showGuidePicLayer()
    --     local data = {}
    --     data.pictures = { --一张或者多张
    --         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
    --         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
    --         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
    --     }
    --     local sData = {}
    --     sData["prefix"] = "gh"
    --     sData["fontSize"] = 20
    --     sData["Iamgdata"] = data
    --     SceneManager:toPublicHelpText(sData)
    -- end)
    -- local function function_name( ... )
    --     -- body
    --      AudioManager:shareDataManager():playMusic("music/ui/inshop.mp3", 1,false)
    -- end 
    -- local delay = cc.DelayTime:create(0.5)
    -- local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function_name))
   
    -- node:runAction(sequence)
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
--  设置奖章
function AllianceBattle_ShopLayer:setCostNum( num )
    -- body
    local curCostIcon =  self.panel:getChildByName("Image_medal")
    self.curCostNum   = curCostIcon:getChildByName("Text_medal")
    self.curCostNum:setString(UITool.ToLocalization(self.medal))

end
---/*物品列表*/
function AllianceBattle_ShopLayer:RefishList( ... )
    -- body
    if self.ShopTabe == nil then
        return
    end
    local iTable   = self.ShopTabe["sells"]
    local len      = #iTable
    local laoutLen = math.ceil(len / 2 )
    self.ListView:removeAllChildren()
    for i = 1,laoutLen do
        self.ListView:pushBackDefaultItem()
    end

    for i = 1 , laoutLen do
        for m = 1,2 do
            local item = self.ListView:getItem(i - 1)
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)*2 +m
            --numIndex = num
            if num > len then
                itme_info:setVisible(false)
            else 

                local dtable = {
                    ["type"]           = iTable[num]["type"], 
                    ["id"]             = iTable[num]["id"],
                    -- cost_type  这个是素材的类型了  现在是5 素材的类型
                    --["costType"]       = iTable[num]["cost_id"], --以前消耗类型固定是19  现在因为消耗的是素材 所以将ID当做类型
                    ["item_num"]       = iTable[num]["item_num"],
                    ["cost_num"]       = iTable[num]["cost_num"],
                    ["item_id"]        = iTable[num]["item_id"],
                    ["stock_num"]      = iTable[num]["stock_num"],
                    ["title"]          = iTable[num]["title"],
                    ["content"]        = iTable[num]["content"],
                    ["is_buy"]         = iTable[num]["is_buy"],
                    --["medal_num"]      = iTable[num]["content"]
                    ["table_index"]    = num,
                    ["item_info"]      = itme_info,
                }
                -- [[如果是5 商店用的货币就是素材  根据第二个参数 cost_id 来显示 其他就是正式货币根据 cost_type 来显示]]
                if iTable[num]["cost_type"] == 5 then
                    dtable["costType"]   = iTable[num]["cost_id"]
                else
                     dtable["costType"]  = iTable[num]["cost_type"]
                end

                -- 背景
                local ImageBg        = itme_info:getChildByName("Image_bg")
                -- 获取item上的属性
                self:setItemPorper(itme_info,dtable)
                -- 点击背景调用
                local function callBack( sender,eventType )
                    -- body

                    if eventType == ccui.TouchEventType.ended then
                        self:ItemEvent(dtable)
                    end
                end
                ImageBg:addTouchEventListener(callBack)


            end
        end
    end
end
--/*点击商品控件  事件   */
--判断当前消耗道具，能够买的数量，和根据不同道具显示的弹窗
-- 弹窗单机购买调用BuyDaojuTow 判断消耗道具是否足够 足够调用购买接口连接服务器
-- 这个参数就是当前点击的数据
function AllianceBattle_ShopLayer:ItemEvent( dtable )
    -- body
   -- self.TestTable = nil
    self.TestTable = dtable;
    local Maxnum = 0; -- 这是当前的金币能够买的数量
    if self.TestTable["costType"] == 1 then
       Maxnum = math.floor(user_info["gold"] / self.TestTable["cost_num"])
       if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
            Maxnum = self.TestTable["stock_num"]
       end
    elseif self.TestTable["costType"] == 2 then
        Maxnum = math.floor(user_info["gem"] / self.TestTable["cost_num"])
        if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
            Maxnum = self.TestTable["stock_num"]
       end
    elseif self.TestTable["costType"] ==  10 then
    elseif self.TestTable["costType"] == 13  then
         Maxnum = math.floor(user_info["beryl"] / self.TestTable["cost_num"])
        if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
            Maxnum = self.TestTable["stock_num"]
        end
    elseif self.TestTable["costType"] == 14 then
    elseif self.TestTable["costType"] == 901 then -- 奖章
        Maxnum = math.floor(self.medal/ self.TestTable["cost_num"])
        if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
            Maxnum = self.TestTable["stock_num"]
        end
    elseif self.TestTable["costType"] == 413 then -- 奖章
        Maxnum = math.floor(self.medal/ self.TestTable["cost_num"])
        if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
            Maxnum = self.TestTable["stock_num"]
        end
    elseif self.TestTable["costType"] == 1500 then -- 公会币
        Maxnum = math.floor(self.medal/ self.TestTable["cost_num"])
        if Maxnum >= self.TestTable["stock_num"] and self.TestTable["stock_num"] ~= -1 then
            Maxnum = self.TestTable["stock_num"]
        end
    end
    if self.TestTable["type"] == 7 then
        local stada = {}
        stada["gift_tyep"]      = self.TestTable["type"]
        stada["costType"]       = self.TestTable["costType"]
        stada["gift_id"]        = self.TestTable["item_id"]
        stada["oneSelf"]        = self
        stada["cost_num"]       = self.TestTable["cost_num"]
        stada["num"]            = self.TestTable["item_num"]
        stada["stock_num"]      = self.TestTable["stock_num"]
        stada["content"]        = self.TestTable["content"]
        self.sManager:toGiftShowListlayer(stada)
        return
    elseif self.TestTable["type"] == 11 then
        local stada = {}
        stada["gift_tyep"] = self.TestTable["type"]
        stada["costType"]  = self.TestTable["costType"]
        stada["gift_id"]   = self.TestTable["item_id"]
        stada["oneSelf"]   = self
        stada["cost_num"]  = self.TestTable["cost_num"]
        stada["num"]       = self.TestTable["item_num"]
        stada["stock_num"] = self.TestTable["stock_num"]
        stada["content"]   = self.TestTable["content"]
        self.sManager:toGiftShowListlayer(stada)
        return
    end
    local function test( n_num )
        -- body
        self:BuyDaojuTow(n_num)
    end 
    if self.TestTable["type"] == 3 then
        MsgManager:ShopEquipInfo(self.TestTable["type"],self.TestTable["item_id"],self.TestTable["item_num"],self.TestTable["costType"],self.TestTable["cost_num"],Maxnum,self,test)
    else
        MsgManager:shopBuyItemsInfo(self.TestTable["type"],self.TestTable["item_id"],self.TestTable["item_num"],self.TestTable["costType"],self.TestTable["cost_num"],Maxnum,self,test)
    end
end
function AllianceBattle_ShopLayer:BuyDaojuTow( n_num )
    -- body
        print("AllianceBattle_ShopLayer BuyDaojuTow == "..n_num)
        local cost = 0
        if self.TestTable["costType"] == 1 then
            cost = user_info["gold"]
        elseif self.TestTable["costType"] == 2 then
            cost = user_info["gem"] + user_info["gem_r"]
        elseif self.TestTable["costType"] == 17 then
            cost = user_info["gem_r"] 
        elseif self.TestTable["costType"] == 13 then
            cost = user_info["beryl"]
        elseif self.TestTable["costType"] == 901 then
            cost = self.medal 
        elseif self.TestTable["costType"] == 413 then
            cost = self.medal 
        elseif self.TestTable["costType"] == 1500 then
            cost = self.medal 
        end
        
        print("AllianceBattle_ShopLayer cost == "..cost)
        print("AllianceBattle_ShopLayer costType == "..self.TestTable["costType"])
        print("AllianceBattle_ShopLayer cost_num == "..self.TestTable["cost_num"])
        if cost - (self.TestTable["cost_num"]*n_num) >=0 then  -- 购买道具的货币 满足
            self:ItemBuy(n_num)
        else
            local strDec = ""
            local function callBuyGold( ... )
                -- body
            end
            if self.TestTable["costType"] == 1 then
                if self.m_AudoIdJB == nil then
                     self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/huobibuzu.mp3", 1,false)
                end
                if self.m_AudoIdJB then
                    local id  = AudioManager:shareDataManager():MusicState(self.m_AudoIdJB )
                    if id == -1 then
                        self.m_AudoIdJB = nil;
                        self.m_AudoIdJB =  AudioManager:shareDataManager():playMusic("music/ui/huobibuzu.mp3", 1,false)
                    end
                end
                strDec = "金币不足"
                --MsgManager:showSimpMsg("金币不足")
            elseif self.TestTable["costType"] == 2 then
                --MsgManager:showSimpMsg("星石不足是否购买")
                strDec = "星石不足是否购买"
            elseif self.TestTable["costType"] == 17 then
                --MsgManager:showSimpMsg("有偿星石不足是否购买")
                strDec = "有偿星石不足是否购买"
            elseif self.TestTable["costType"] == 13 then
                --MsgManager:showSimpMsg("苍玉不足")
                strDec = "苍玉不足"
            elseif self.TestTable["costType"] == 901 then
                --MsgManager:showSimpMsg("奖章不足")
                strDec = "奖章不足"
            elseif self.TestTable["costType"] == 413 then
                --MsgManager:showSimpMsg("古代回路不足")
                strDec = "古代回路不足"
            elseif self.TestTable["costType"] == 1500 then
                --MsgManager:showSimpMsg("公会币不足")
                strDec = "公会币不足"
            end
             MsgManager:showSimpMsg(UITool.ToLocalization(strDec))
        end
end
-- 向服务器发送购买信息
function AllianceBattle_ShopLayer:ItemBuy( num )
    -- body
    local function reiceSthCallBack(data)
        print("团战商店购买")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        self.medal = self.medal - (self.ShopTabe["sells"][self.TestTable["table_index"]].cost_num * num)

        user_info["medal_num"] = self.medal
        if self.rData["buyCallback"] then
            self.rData["buyCallback"]()
        end

        self:setCostNum()
        if t_data["data"]["new_heroes"] then
            local heroData = t_data["data"]["new_heroes"]
            if #heroData > 0 then
                self.getdata = {}
                for i,v in ipairs(heroData) do
                    local test = {}
                    local id = v["id"]
                    print("id ==== ",id)
                    test["id"] = tonumber(id)
                    test["story"] = v["story"]
                    test["rarity"] = hero[tonumber(id)].hero_rank
                    table.insert(self.getdata,test)
                end
                self:showNewHeroEffet()
            end
        end

        self.ShopTabe["sells"][self.TestTable["table_index"]] = t_data["data"]["goods"]
        self:refrshShopItem(self.TestTable["item_info"],self.ShopTabe["sells"][self.TestTable["table_index"]])
        self:RefishList()

        --self:Send()
        --self.ShopTabe = t_data["data"]["good"]
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = self.sendBuyName,
        ["sell_id"]   = self.ShopTabe["sells"][self.TestTable["table_index"]]["id"],
        ["buy_num"]   = num
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
    

end

function AllianceBattle_ShopLayer:showNewHeroEffet()
    print("展示新任人物特效动画")
    if self.getdata == nil then
        return
    end
    -- local getdata = {} 
    -- for i,v in ipairs(data) do
    --     local test = {}
    --     local id = v["id"]
    --     print("id ==== ",id)
    --     test["id"] = tonumber(id)
    --     test["story"] = v["story"]
    --     test["rarity"] = hero[tonumber(id)].hero_rank
    --     table.insert(getdata,test)
    -- end
    dump(self.getdata,"getdata:")
    if GameManagerInst.gameType == 2 then

        local function resumeBGMusic(  )
            print("resumeBGMusic-----")
            AudioManager:shareDataManager():resumeAll()
            --AudioManager:shareDataManager():stopAll()--抽卡音效超过上限，导致无法播放新音效
            local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
            --todo 停止或者恢复当前音乐
            if musicState == 0 then --开启音乐
                
                if AudioManager:shareDataManager():getBGId() ~= -1 then 
                    AudioManager:shareDataManager():resumeBGMusic()
                else 
                    local fullpath = lua_musci["zhuyeBGM"]
                    AudioManager:shareDataManager():preloadM(fullpath)
                    AudioManager:shareDataManager():playBGMusic(fullpath, true)
                end
            end 

        end
        SceneManager.menuLayer:RefshTopBar()
        SceneManager:toGetNewHeroView({   itemList = self.getdata,
                                            finalFunc = function()
                                                resumeBGMusic()
                                                NoticeManager:startNotice()
                                                cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                                                --self:loadData()
                                            end
                                            })
    end
end
--刷新商店的Item
function AllianceBattle_ShopLayer:refrshShopItem(itme_info, dtable)
    -- body
    self:setItemPorper(itme_info,dtable)
end
-- 获取Item上的属性
function AllianceBattle_ShopLayer:setItemPorper( itme_info,dtable )
    -- 背景
    local ImageBg       = itme_info:getChildByName("Image_bg")
    -- body
    -- 售馨显示的蒙版
    self.imaga          = ImageBg:getChildByName("Image_a")
    --  显示的消耗道具的类型
    self.itemCostIcon   = ImageBg:getChildByName("Image_5")
    -- 商品的背景
    self.e_bg           = ImageBg:getChildByName("Image_iconbg")
    -- 商品的框 
    self.e_fr           = ImageBg:getChildByName("Image_form")
    -- 商品的图标
    self.e_icon         = ImageBg:getChildByName("Image_icon")
    -- 商品的名字
    self.Name           = ImageBg:getChildByName("Text_Name")
    -- 商品的描述
    self.dec            = ImageBg:getChildByName("Text_dec")
    --商品数量
    self.number         = ImageBg:getChildByName("Text_number")
    --库存数量
    self.number1        = ImageBg:getChildByName("Text_number_1")
    --显示消耗道具的数量
    self.costTypeNum    = ImageBg:getChildByName("Text_gold")
    --设置item头属性
    self:setItemPer(tonumber(dtable.type),tonumber(dtable.item_id))
    --设置item板子属性
    self:setItemEnd(dtable)
end
--设置item板子属性
function AllianceBattle_ShopLayer:setItemEnd( dtable )
    -- body
    --设置名字描述 
    self.Name:setString(UITool.getUserLanguage(dtable["title"]))
    self.dec:setString(UITool.getUserLanguage(dtable["content"]))
    -- 商品数量
    self.number:setFontSize(24);
    self.number:enableOutline(cc.c4b(0,0,0,255),2)
    self.number:setString("x"..dtable["item_num"])
    -- 库存数量
    --修复bug 多语言无法翻译 需要同步到中心服
    self.number1:setString(UITool.ToLocalization("库存:")..dtable["stock_num"])
    --self.number1:setString(UITool.ToLocalization("库存:"..dtable["stock_num"]))

    -- 根据类型获取显示消耗道具图标 
   -- self.itemCostIcon:setUnifySizeEnabled(true)
    self.itemCostIcon:loadTexture(UITool:Coin_type(dtable["costType"])) 
    -- 如果库存为 -1 表示只要货币够。就可以无限购买
    if dtable["stock_num"] == -1 then
         self.number1:setVisible(false)
    end
    -- 根据库存  是否显示蒙版 和 消耗道具
    if dtable["is_buy"] == 2 then--已觉醒(角色+10才会为2)
        self.costTypeNum:setString(UITool.ToLocalization("已觉醒"))
        self.costTypeNum:setColor(cc.c3b(255,0,0))
        self.imaga:setVisible(true) 
        self.itemCostIcon:setVisible(false)

        if g_channel_control.transform_AllianceBattle_ShopLayer_awakenAlign == true then 
            self.costTypeNum:setPosition(cc.p(395,11.5))
            self.costTypeNum:setAnchorPoint(cc.p(1,0))
        end

    else
        if dtable["stock_num"] == 0 then  
            self.costTypeNum:setString(UITool.ToLocalization("已购买"))
            self.costTypeNum:setColor(cc.c3b(255,0,0))
            self.imaga:setVisible(true) 
            self.itemCostIcon:setVisible(false)
        else
            -- 消耗金币的数量
            self.costTypeNum:setString(UITool.ToLocalization(dtable["cost_num"]))
            self.imaga:setVisible(false)
            self.itemCostIcon:setVisible(true)
        end
    end
end
--设置item头属性
function AllianceBattle_ShopLayer:setItemPer( _type,_itemId )
    -- body
    -- 传入类型和Id获取到这个商品的属性
    local prop = {}
    prop = UITool.getItemInfos(_type,_itemId)

    self.e_bg:loadTexture(prop[4])
    self.e_fr:loadTexture(prop[1])
    self.e_icon:loadTexture(prop[2])

    if g_channel_control.transform_AllianceBattle_ShopLayer_ItemTitleFont == true then 
        self.Name:setFontSize(22)
    end  

    --属性球
    if prop[3] ~= "" then 
      local elementImg = cc.Sprite:create(prop[3])
      elementImg:setAnchorPoint(cc.p(1,1))
      elementImg:setPosition(self.e_fr:getContentSize().width,self.e_fr:getContentSize().height)
      elementImg:setScale(0.8)
      self.e_fr:addChild(elementImg)
    end
end

--/*初始化List模板*/
function AllianceBattle_ShopLayer:initMode( ... )
    -- body
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("ShopItemNode.csb")
    local  item_1 = list_item:getChildByName("Panel_1")

    for i=1,2 do
        local item_c = item_1:clone()
        item_c:setPosition((i-1)*(412+7),0)
        local touchItem = ccui.Helper:seekWidgetByName(item_c,"Image_1")
        item_c:setName("item"..i)
        layout_list:addChild(item_c)
    end
    layout_list:setContentSize(858,164)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.ListView:setItemModel(layout_list)
end
--链接服务器 获取服务器数据
function AllianceBattle_ShopLayer:Send( ... )
    -- body

    local function reiceSthCallBack(data)
        print("团长获取商店列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        self.sManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            --MsgManager:showSimpMsg("获取数据异常，请联系客服")
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            
            return
        end
        self.medal = t_data["data"]["medal_num"]
        print("self.medal self.medal self.medal == "..self.medal)
        self:setCostNum()
        self.ShopTabe = {}
        self.ShopTabe["sells"] = t_data["data"]["goods"]
        self:RefishList()
        if self.rData["_type"] == 3 then
            self.resetTime = t_data["data"]["guild_r_time"]
            self:initAddUI()
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = self.sendShopName,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
    
end
function AllianceBattle_ShopLayer:returnBack( ... )
    -- body
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)

    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    if self.backFunc then
        self.backFunc(self.sDelegate,self.sData)
    end
    self.exist = false
    self.sData = {}
    self.rData = {}
    self:clear()

end

function AllianceBattle_ShopLayer:create(rData)

     local login     = AllianceBattle_ShopLayer.new()
     login.rData     = rData
     login.sManager  = login.rData["sManager"]
     if rData["_type"] == 2 then -- 极限挑战
         login.backFunc  = login.rData["rcvData"]["sFunc"]
         login.sDelegate = login.rData["rcvData"]["sDelegate"]
     end
     login.uiLayer   = cc.Layer:create()
     login:init()

     return login

end

function AllianceBattle_ShopLayer:initAddUI()
     if g_channel_control.show_new_guild_main == true then
        local Image_time = self.panel:getChildByName("Image_time_bg")
        local Text_time = Image_time:getChildByName("Text_time")
        local Image_bg = self.panel:getChildByName("Image_bg")
        local herobg = Image_bg:getChildByName("Image_11")
        local curCostIcon =  self.panel:getChildByName("Image_medal")
        curCostIcon:setVisible(false)
        --herobg:setVisible(false)
        --Image_bg:loadTexture("uifile/n_UIShare/shop/sc_ui_006.png")
        if self.resetTime then
            if self.resetTime ~= 0 then
                local function fCall( ... )
                    -- body
                end
                Image_time:setVisible(true)
                if self.isDownTiem == false then
                    local curTime = UserDataMgr:getInstance().timeData:getCurrentTime()
                    local delTime = self.resetTime - curTime
                    UITool:schedule(Image_time,1,delTime,Text_time,fCall)
                    self.isDownTiem = true
                end
            end
        end
        
    end
end
