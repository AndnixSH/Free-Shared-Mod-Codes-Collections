--属性管理器
--created by kobejaw.2018.5.18.
AttributeManager = class("AttributeManager")

function AttributeManager:ctor(entity)
	self.entity = entity --绑定到entity上

	self.attr = {}
	entity.attr = self.attr--快捷访问

	self:init(entity.data)
end

function AttributeManager:init(initialData)
	--从initialData里直接读取的属性

	--基础属性
	self:initHP(initialData)                                                                        --hp
	self.attr[AE.atk_interval] = ThreeMeshTwoParam(initialData.celerity,2)               --攻击间隔（秒）
	self.attr[AE.reduce_interval] = 0                                                    --降低的攻击间隔百分比加成。
	self.attr[AE.level] = ThreeMeshTwoParam(initialData.Lv,1)                            --等级
	self.attr[AE.recover] = ThreeMeshTwoParam(initialData.recover,100)                   --恢复力
	self.attr[AE.add_recover] = 0                                                        --恢复力加成
	self.attr[AE.hit_rate] = 100                                                         --命中率。默认是100。黑暗debuff修改这个值。
	self.attr[AE.dodge] = 0                                                              --闪避率。默认是0。
	self.attr[AE.element] = ThreeMeshTwoParam(initialData.atb,1)                         --元素值。1水2火3风4光5暗
	self.attr[AE.add_debuff_rate] = ThreeMeshTwoParam(initialData.debuff_rate,0)         --释放debuff的命中率加成
	self.attr[AE.add_debuff_dodge_rate] = ThreeMeshTwoParam(initialData.resistance,0)    --闪避debuff的加成
	self.attr[AE.block_rate] = ThreeMeshTwoParam(initialData.block_rate,0)               --格挡率
	self.attr[AE.reduce_block_rate] = ThreeMeshTwoParam(initialData.block_break_rate,0)  --破格率 
	self.attr[AE.block_value] = ThreeMeshTwoParam(initialData.block_effect,0)            --格挡值
	self.attr[AE.reduce_block_value]= ThreeMeshTwoParam(initialData.block_break_effect,0)--破格值 
	--注：命中率和闪避相关的计算只有加法没有乘法。

	--攻击力相关
	self.attr[AE.attack] = ThreeMeshTwoParam(initialData.attack,1)                       --攻击力
	self.attr[AE.add_atk] = 0                                                            --攻击力加成
	self.attr[AE.add_atk_winordie] = ThreeMeshTwoParam(initialData.emi_atk,0)            --背水攻击力加成。库拉夏的被动技能。
	self.attr[AE.add_atk_normal] = ThreeMeshTwoParam(initialData.pattack_rate,0)          --普通攻击攻击力加成。对应api中的pattack_rate

	--伤害加成相关
	self.attr[AE.add_dmg] = ThreeMeshTwoParam(initialData.add_dmg,0)                      --伤害加成
	self.attr[AE.add_dmg_skill] = ThreeMeshTwoParam(initialData.skill_dmg,0)              --技能伤害加成。注：是增伤，不是增加倍率
	self.attr[AE.add_dmg_chimera] = ThreeMeshTwoParam(initialData.addweakDamage,0)        --奇美拉诅咒伤害加成。黑鸦的被动技能。
	self.attr[AE.add_dmg_od] = ThreeMeshTwoParam(initialData.add_od_dmg,0)                --对狂暴状态的敌人伤害加成
	self.attr[AE.add_dmg_bk] = ThreeMeshTwoParam(initialData.add_bk_dmg,0)                --对虚弱状态的敌人伤害加成
	self.attr[AE.add_dmg_normal] = 0                                                      --普通伤害加成（灵剑乱舞这个buff）
	self.attr[AE.add_dmg_skill_1] = ThreeMeshTwoParam(initialData.add_dmg_skill_1,0)      --小技能伤害加成
	self.attr[AE.add_dmg_skill_2] = ThreeMeshTwoParam(initialData.add_dmg_skill_2,0)      --大技能伤害加成

	--暴击相关
	self.attr[AE.crit_multiplying] = ThreeMeshTwoParam(initialData.crit_dmg,100)           --暴击倍率（初始值为面板暴击倍率）
	self.attr[AE.crit_rate] = ThreeMeshTwoParam(initialData.crit,0)                        --暴击率
	self.attr[AE.add_crit_rate] = 0                                                        --暴击率的加成
	self.attr[AE.add_crit_rate_skill] = ThreeMeshTwoParam(initialData.skill_crite,0)       --技能暴击率的加成
	self.attr[AE.add_dmg_crit] = 0                                                         --暴击倍率加成(与AE.crit_multiplying相加，不算增伤)
	self.attr[AE.crit_resistance] = ThreeMeshTwoParam(initialData.crit_resist,0)           --暴抗率
	self.attr[AE.add_dmg_skill_crit] = ThreeMeshTwoParam(initialData.skill_criteDmg,0)     --技能暴击倍率的加成(与AE.crit_multiplying相加，不算增伤)

	--防御力相关
	self.attr[AE.defence] = ThreeMeshTwoParam(initialData.defence,0)                       --防御力
	self.attr[AE.add_defence] = 0                                                          --防御力加成
	self.attr[AE.reduce_dmg] = ThreeMeshTwoParam(initialData.re_dmg,0)                     --减伤
	self.attr[AE.add_def_water] = ThreeMeshTwoParam(initialData.water_res,0)               --水属性防御力加成
	self.attr[AE.add_def_fire]  = ThreeMeshTwoParam(initialData.fire_res,0)                --火属性防御力加成
	self.attr[AE.add_def_wind]  = ThreeMeshTwoParam(initialData.wind_res,0)                --风属性防御力加成
	self.attr[AE.add_def_light] = ThreeMeshTwoParam(initialData.light_res,0)               --光属性防御力加成
	self.attr[AE.add_def_dark]  = ThreeMeshTwoParam(initialData.dark_res,0)                --暗属性防御力加成

	--其他属性
	if self.entity.isBoss then
		self.attr[AE.state] = 0                                                              --od和bk状态。OD为0，BK为1.
		if G_STAGE_TYPE == 2 then
			self.attr[AE.state] = BattleDataManager.multiData.bossState
		end

		self.attr[AE.energy_max] =  ThreeMeshTwoParam(initialData.mCount,1)                     --能量豆上限
		self.attr[AE.energy] =  0                           	  								--能量豆
		self.attr[AE.od_hp] = initialData.od_hp         --od值
		self.attr[AE.bk_hp] = initialData.bk_hp         --bk值
		self.attr[AE.bk_t] = initialData.bk_t           --bk时间
	end
	self.attr[AE.total_dmg] = 0                     --累计受到伤害。用于受到xx总伤害的判定。会引发触发器
	self.attr[AE.total_dmg_2] = 0                   --累计受到的伤害。用于每受到xx伤害的判定
	self.attr[AE.totalnum_atked] = 0                --累计受攻击次数。会引发触发器
	self.attr[AE.totalnum_atk] = 0                  --累计攻击次数。会引发触发器


	--对某些debuff免疫。
	self.retce_state = {}
	self.retce_state.state = 0 --0,对所有都不免疫。1.对list中的免疫。-1，对所有debuff免疫。
	self.retce_state.list = {}

	--对所有debuff免疫
	if initialData.retce_state == "-1" then
		self.retce_state.state = -1;
	--对指定debuff免疫
	elseif initialData.retce_state ~= "0_0" then
		local tempArray = UITool.stringSplit(initialData.retce_state,"_");
		self.retce_state.state = 1
		for i = 1,#tempArray do
			table.insert(self.retce_state.list,tonumber(tempArray[i]))
		end
	end
end

function AttributeManager:initHP(initialData)
	--爬塔的小怪或者boss
	if G_STAGE_TYPE == 3 and self.entity.entityType == 2 then
		self.attr[AE.hp] = BattleDataManager.towerData[self.entity.data.puid]                --当前hp                            
		self.attr[AE.hp_max] = ThreeMeshTwoParam(initialData.HP,1)                           --hp上限
	else
		self.attr[AE.hp] = ThreeMeshTwoParam(initialData.HP,1)                               --当前hp
		self.attr[AE.hp_max] = ThreeMeshTwoParam(initialData.HP,1)                           --hp上限
	end
end

function AttributeManager:changeAttr(attrId,num)
	--最大生命值变化
	if attrId == AE.hp_max then
		self.attr[AE.hp_max] = math.floor(self.attr[AE.hp_max] * (100 + num)/100)
		return
	end

	self.attr[attrId] = self.attr[attrId] + num
	if self.attr[attrId] < 0 and AE_GreaterThan0[attrId] then
		self.attr[attrId] = 0
	end

	--生命值变化
	if attrId == AE.hp then
		if self.entity.isDead then
			return
		end

		if self.attr[attrId] > self.attr[AE.hp_max] then
			self.attr[attrId] = self.attr[AE.hp_max]
		end

		--触发时机7 生命值变化时,包括致死时。生效的结果有可能是hp从0变成1
		local option = {}
		self.entity.triggerManager:check(7,option)

		--81043生效
		if self.entity.attr[AE.hp] <= 1 and self.entity.componentManager:getComById(81043) then
			self.entity.attributeManager:changeAttr(AE.hp,1)
		end

		if self.entity.isBoss then
			local isIncrease
			if num >=0 then
				isIncrease = true
			else
				isIncrease = false
			end
			BattleUIManager:setHP(math.abs(num),isIncrease)
		else
			self.entity.hpBar:onHPChanged()
		end

		--触发时机10 死亡时
		if self.attr[attrId] == 0 then
			local option = {}
			self.entity.triggerManager:check(10,option)
			self.entity:onDead()
		end
	end
end

--设置多人战boss的hp
function AttributeManager:setHPForMultiBoss(hp)
	local isIncrease

	if hp < 0 then
		hp = 0
	elseif hp > self.attr[AE.hp_max] then
		hp = self.attr[AE.hp_max]
	end

	local num = hp - self.attr[AE.hp]
	if num >= 0 then
		isIncrease = true
	else
		isIncrease = false
	end 

	self.attr[AE.hp] = hp
	local option = {}
	self.entity.triggerManager:check(7,option)
	
	BattleUIManager:setHP(math.abs(num),isIncrease)
end

--检测是否对某个debuff免疫
function AttributeManager:checkIsImmuneToDebuff(comId)
	if self.retce_state.state == -1 then
		return true
	elseif self.retce_state.state == 1 then
		for k,v in pairs(self.retce_state.list) do
			if v == comId then
				return true
			end
		end
		return false
	else
		return false
	end
end

--获取攻击力
function AttributeManager:getAttack()
	if self.attr[AE.add_atk_winordie] ~= 0 then --背水的情况
		local hpPercent = self.attr[AE.hp]/self.attr[AE.hp_max] * 100
		local addAttackMulti = BattleDamageCompute:getEMIATK(hpPercent)            --背水攻击力的倍率
		local add_atk_beishui = addAttackMulti * self.attr[AE.add_atk_winordie]    --背水增加的攻击力百分比
		return self.attr[AE.attack] * (1 +  self.attr[AE.add_atk]/100 + add_atk_beishui/100)
	else
		return self.attr[AE.attack] * (1 +  self.attr[AE.add_atk]/100)
	end
end

--获取防御力
function AttributeManager:getDefence()
	return self.attr[AE.defence] * (1 + self.attr[AE.add_defence]/100)
end

--获取攻击间隔
function AttributeManager:getAtkInterval()
	--boss做一下四舍五入
	if self.entity.isBoss then
		local result = GetRoundNum(self.attr[AE.atk_interval] * (1 - self.attr[AE.reduce_interval]/100))
		if result <= 0 then
			result = 1
		end
		return result
	else
		return self.attr[AE.atk_interval] * (1 - self.attr[AE.reduce_interval]/100)
	end
end

--获取恢复力
function AttributeManager:getRecover()
	return self.attr[AE.recover] * (1 + self.attr[AE.add_recover]/100)
end