--Boss的攻击状态。（实际上是boss的普通状态，攻击时切换到PlayingSkill状态，攻击完毕切换回来）
--created by kobejaw.2018.5.21.
State_Attacking_Boss = class("State_Attacking_Boss",StateBase)

function State_Attacking_Boss:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.Attacking_Boss
	self.isWaiting = false
end

function State_Attacking_Boss:Enter()
	if self.entity.isDead then
		return
	end

	self.entity:playIdleAnimation();
	self.isWaiting = false
	--如果此时正处在cutin阶段或者等待玩家复活的状态，等待cutin结束后再释放技能
	if G_GameState == 3 then
		self.isWaiting = true
	elseif G_GameState == 5 then
		self.entity.fsm:changeState(StateEnum.Idling);
	else
		self:playSkill()
	end
end

function State_Attacking_Boss:Exit()
	self.super.Exit(self)
end

function State_Attacking_Boss:playSkill()
	local this = self
	local function onTimeUp()		
		this.entity:playSkill()
	end
	--通知UI开始下一个技能的倒计时
	BattleUIManager:startBOSSActInCD(onTimeUp)
end