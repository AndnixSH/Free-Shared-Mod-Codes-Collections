--无法释放技能的异常状态。
--created by kobejaw.2018.4.28.
State_UnusualCondition = class("State_UnusualCondition",StateBase)

function State_UnusualCondition:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.UnusualCondition
end

--data.stateType:  1:击飞。2.浮空。3.击倒.4.击退。5.硬直中（pvp没有硬直,pve只有小怪有硬直）
--data.arg:   可能用到的参数，例如用来区分float1,float2等不同的float表现
function State_UnusualCondition:Enter(data)
	self.data = data;
	self.stateType = data.stateType
	self.isStandingUp = false --是否正在起身

	self.entity:setOrientation()

	if self.stateType ~= 5 then
		--如果此时正处在跑动状态，先把角色的位置设置为当前所处的格子中心，然后计算角色所属的格子。
		if self.entity.fsm.previousState.stateEnum == StateEnum.RunningToEnemy or self.entity.fsm.previousState.stateEnum == StateEnum.RunningToPosition then
			local idx = self.entity:getBoxIdx()
			self.entity:setPosition(GetPointByBoxIdx(idx))
		end
	end

	if self.entity.fsm.previousState.stateEnum ~= StateEnum.UnusualCondition then
		self.initial_y = self.entity:getPositionY();
		self.initial_w,self.initial_h = self.entity:getBoxWH();
	end

	--播放动画,计算落地位置，刷新entity的w,h值为落地位置，刷新落地位置对应的BoxData
	self:doAction()
end 

function State_UnusualCondition:Exit()
	self.super.Exit(self)
	--if not self.entity.isDead then
		--self.entity.effectNode:setPosition(cc.p(self.entity.centerPoint.x,self.entity.centerPoint.y))
	--end
end

function State_UnusualCondition:doAction()
	if self.stateType == 1 then
		self:doAction_Fly()--被击飞
	elseif self.stateType == 2 then
		self:doAction_Float()--被浮空
	elseif self.stateType == 3 then
		self:doAction_Down()--被击倒
	elseif self.stateType == 4 then
		self:doAction_Back()--被击退
	elseif self.stateType == 5 then
		if not self.entity.isDead then
			self:doAction_BeHit() --后仰
		end
	end
end

--被击飞
function State_UnusualCondition:doAction_Fly()
	self.entity:playFloatAnimation()

	local currPosY = self.entity:getPositionY()
	local time_back
	local speed_up = 500
	local speed_down = 400
	local offset_y
	local offset_x

	local time_up
	if self.data.arg == 1 then
		if currPosY<300 then
			offset_y = 50
		elseif currPosY < 450 then
			offset_y = 28
		else
			offset_y = 10
		end
		offset_x = 200;
		time_back = 0.3
	else
		if currPosY < 300 then
			offset_y = 90
			if offset_y + currPosY > 350 then
				offset_y = 350 - currPosY
			end
			time_up = 90/speed_up
		elseif currPosY < 400 then
			offset_y = 50
			if offset_y + currPosY > 400 then
				offset_y = 400 - currPosY
			end
			time_up = 50/speed_up
		else
			offset_y = 10
		end
        offset_x = 340;
        time_back = 0.4;
	end

	if time_up == nil then
		time_up = offset_y/speed_up;
	end
    local time_down = (currPosY+offset_y-self.initial_y)/speed_down   

    --self.entity:setOrientation(self.data.attacker)

	if self.entity.faceTo == BattleGlobals.FaceRight then
		offset_x = -offset_x
	end

	local this = self
	local function callback()
		if self.entity.attr[AE.hp] == 0 then
			this.entity.fsm:changeState(StateEnum.Dead)
			return
		end
		self.isStandingUp = true
		if this.data.arg == 1 then
			this.entity:playStandUp1Animation()
		else
			this.entity:playStandUp2Animation()
		end
	end

    local move1 = cc.MoveBy:create(time_up,cc.p(0,offset_y))
    local move2 = cc.MoveBy:create(time_down,cc.p(0,self.initial_y - currPosY - offset_y))
    local ease_out = cc.EaseSineOut:create(move1)
    local ease_in = cc.EaseSineIn:create(move2)
    
    local seq1 = cc.Sequence:create(ease_out,ease_in)
    self.entity:runAction(seq1)

    local move3 = cc.MoveBy:create(time_back,cc.p(offset_x,0))
    local seq2 = cc.Sequence:create(move3,cc.CallFunc:create(callback))
    self.entity:runAction(seq2)

    self:refreshBoxData(offset_x)
end

--被浮空
function State_UnusualCondition:doAction_Float()
	self.entity:playFloatAnimation()
	local speed_up = 500
	local speed_down = 600
	local currPosY = self.entity:getPositionY()
	
	local time_delay = 0.05
	local offset_y = 100
	if self.data.arg == 1 then
		if currPosY>=430 then
			offset_y = 5;
		elseif currPosY>=290 then
			offset_y = 450-currPosY
		else
			offset_y = 300-currPosY
		end
	else
		if currPosY>=430 then
			offset_y = 5;
		else
			offset_y = 450-currPosY
		end		
	end

	local time_up = offset_y/speed_up
	local time_down = (currPosY + offset_y - self.initial_y)/speed_down

	local this = self
	local function callback()
		if self.entity.attr[AE.hp] == 0 then
			this.entity.fsm:changeState(StateEnum.Dead)
			return
		end
		self.isStandingUp = true
		if this.data.arg == 1 then
			this.entity:playStandUp1Animation()
		else
			this.entity:playStandUp2Animation()
		end
	end

    local move1 = cc.MoveBy:create(time_up,cc.p(0,offset_y))
    local move2 = cc.MoveBy:create(time_down,cc.p(0,self.initial_y - currPosY - offset_y))
    local ease_out = cc.EaseSineOut:create(move1)
    local ease_in = cc.EaseSineIn:create(move2)

    local seq = cc.Sequence:create(ease_out,cc.DelayTime:create(time_delay),ease_in,cc.CallFunc:create(callback))
    self.entity:runAction(seq)

    self:refreshBoxData(0)
end

--被击倒（前一种状态一定是击退中或者击倒中，或者非异常状态）
function State_UnusualCondition:doAction_Down()
	self.entity:playFloatAnimation()
	local offset_x,time
	if self.data.arg == 1 then --TODO，如果是pvp，击倒不后退。
		offset_x = 50
		time = 0.1
	elseif self.data.arg == 2 then
		offset_x = 150
		time = 0.17
	else
		offset_x = 200
		time = 0.2
	end

	--self.entity:setOrientation(self.data.attacker)

	if self.entity.faceTo == BattleGlobals.FaceRight then
		offset_x = -offset_x
	end

	local this = self
	local function callback()
		if self.entity.attr[AE.hp] == 0 then
			this.entity.fsm:changeState(StateEnum.Dead)
			return
		end
		self.isStandingUp = true		
		this.entity:playStandUp2Animation()
	end

	local move = cc.MoveBy:create(time,cc.p(offset_x,0))
	local seq = cc.Sequence:create(move,cc.CallFunc:create(callback))
	self.entity:runAction(seq)

	self:refreshBoxData(offset_x)
end

--被击退（前一种状态一定是击退中或者非异常状态）
function State_UnusualCondition:doAction_Back()
	self.entity:playFloatAnimation()
	local offset_x,time
	if self.data.arg == 1 then
		offset_x = 150
		time = 0.17
	elseif self.data.arg == 2 then
		offset_x = 250
		time = 0.2	
	else
		offset_x = 300
		time = 0.23
	end

	--self.entity:setOrientation(self.data.attacker)

	if self.entity.faceTo == BattleGlobals.FaceRight then
		offset_x = -offset_x
	end

	local this = self
	local function callback()
		if self.entity.attr[AE.hp] == 0 then
			this.entity.fsm:changeState(StateEnum.Dead,2)
			return
		end
		self.isStandingUp = true
		this.entity:playStandUp2Animation()
	end

	local move = cc.MoveBy:create(time,cc.p(offset_x,0))
	local seq = cc.Sequence:create(move,cc.CallFunc:create(callback))

	self.entity:runAction(seq)

	self:refreshBoxData(offset_x)
end

function State_UnusualCondition:doAction_BeHit()
	self.entity:playBeHitAnimation()
end

function State_UnusualCondition:refreshBoxData(offsetx)
	local x = self.entity:getPositionX()
	local destX = x + offsetx
	self.entity.box_w,self.entity.box_h = GetBoxWHByPoint(destX,self.initial_y)
end

function State_UnusualCondition:onSpineCompleteCallback(event)
	if event.animation == SpineAnimationName.StandUp1 or event.animation == SpineAnimationName.StandUp2 
		or event.animation == "up12" or event.animation == "up22"  then
		--self:correctPosWithRunning(),2018.11.26.
	    local data = {}
	    data.type = 1;
	    self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)
	elseif event.animation == SpineAnimationName.BeHit or event.animation == "behit2" then
		if self.isDead then
			return
		end

		self.entity.spineNode:setAnimation(0,"loading",true)
		self.entity.spineNode:setToSetupPose()

		local this = self
		local function changeState()
			if this.isDead then
				return
			end

			if this.entity.fsm.currentState == this and this.stateType == 5 then
				--延时一小下，然后切换到寻敌状态
		        local data = {}
		        data.type = 1;
		        this.entity.fsm:changeState(StateEnum.RunningToEnemy,data)					
			end
		end

		PerformWithDelayTime(changeState,0.2)
	end
end