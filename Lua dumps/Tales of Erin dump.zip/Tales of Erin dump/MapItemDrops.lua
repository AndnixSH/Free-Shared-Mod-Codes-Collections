--物品掉落查看，区域地图
--MapItemDrops.lua
require "BasicLayer"
--require "ConsoleLayer"

MapItemDrops = class("MapItemDrops",BasicLayer)
MapItemDrops.__index = MapItemDrops
MapItemDrops.lClass = 3
local LIST_ITEM_H = 110 --item高度
local LIST_COLUMN = 3   --一行显示几个

function MapItemDrops:init()
    local data = self.rData.rcvData.data
    self.rewards = data.rewards or {}--奖励列表
    self:sortRewards()--奖励排序
    local node = cc.CSLoader:createNode("MapItemDrops.csb")
    self.uiLayer:addChild(node,0,1)
    local panel = node:getChildByTag(102) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end

    local backBtn  =  ccui.Helper:seekWidgetByName(panel,"back_btn")
    backBtn:addTouchEventListener(touchCallBack)

    local title  =  ccui.Helper:seekWidgetByTag(panel,108)
    title:setString(data.title)
    local  pos = self.rData.rcvData.pos or cc.p(0,0)
    panel:setPosition(pos.x,pos.y)

    self:initListView()
    self:refreshListView()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
end
--排序奖励
function MapItemDrops:sortRewards()
    --info 由于 不同类型之间的 品质取不同字段，所以要提前将品质取出来
     for i=1,#self.rewards do
        local reward = self.rewards[i]
        local quality = UITool.getItemQuality(reward.type,reward.id)
        local type_Q =  UITool.getItemTypeQuality(reward.type)
        self.rewards[i].com_quality = quality
        self.rewards[i].type_Q = type_Q
        self.rewards[i].sort_id = reward.id
     end
     local function qualitySort(a,b)
        if a.type_Q == b.type_Q then
            if a.com_quality == b.com_quality then
                return a.sort_id > b.sort_id
            else
                return a.com_quality > b.com_quality
            end
        else
            return a.type_Q > b.type_Q
        end
     end
     table.sort(self.rewards, qualitySort)
end

function MapItemDrops:initListView()
    -- body
    local node = self.uiLayer:getChildByTag(1)
    local panel = node:getChildByTag(102) 
    self.listView = ccui.Helper:seekWidgetByTag(panel,"105")
    --set bar
    self.listView:setScrollBarEnabled(true)
    self.listView:setScrollBarWidth(20)
    self.listView:setScrollBarColor(cc.c3b(0, 0, 0))
    self.listView:setScrollBarOpacity(225*0.5)
    self.listView:setScrollBarPositionFromCorner(cc.p(2,2))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end
    local  item = cc.CSLoader:createNode("MapDropsItem.csb")
    local  item_1 = item:getChildByTag(102)
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    for i=1,LIST_COLUMN do
        local item = item_1:clone()
        item:setPosition((i-1)*(154*0.8+15),0) --152为框的大小。缩放80%
        --local touchItem = ccui.Helper:seekWidgetByName(item_c,"Image_e_bg")
        item:setName("item"..i)
        layout_list:addChild(item)
    end
    layout_list:setContentSize(400,110)
    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.listView:setItemModel(layout_list)
    self.listView:removeAllItems()
    self.listView:addEventListener(listViewEvent)

end
--返回
function MapItemDrops:returnBack()
   self.exist = false
   self:clearEx()
end

function MapItemDrops:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function MapItemDrops:refreshListView()
    self.listView:removeAllItems()
    local totalNum = #self.rewards --总数
    local row = math.ceil(totalNum /LIST_COLUMN)  -- 行数
    self.listView:setInnerContainerSize(cc.size(self.listView:getContentSize().width,LIST_ITEM_H*row))
    for i = 1,row do 
        self.listView:pushBackDefaultItem()
        local item = self.listView:getItem(i - 1)
        for m = 1 , LIST_COLUMN do          
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)*LIST_COLUMN + m

            if num > totalNum then
                itme_info:setVisible(false)
            else
                local reward = self.rewards[num]
                local tabs = UITool.getItemInfos(reward.type,reward.id)

                local bg = itme_info:getChildByTag(1)
                local icon = itme_info:getChildByTag(2)
                local kuang = itme_info:getChildByTag(3)
                local element = itme_info:getChildByTag(4)
                local drop_res = itme_info:getChildByTag(6)
                if reward.tag then
                    if reward.tag == 0 then
                        drop_res:setVisible(false)
                    else
                        local path = table.getValue("drop_tag",drop_tag,reward.tag,"path_res")
                        if path == "" then
                            drop_res:setVisible(false)
                        else
                            drop_res:setVisible(true)
                            drop_res:loadTexture(path)
                            icon:setUnifySizeEnabled(true)
                        end
                    end
                end
                    
                kuang:loadTexture(tabs[1])
                icon:setUnifySizeEnabled(true)
                icon:loadTexture(tabs[2])
                if tabs[3] == "" then 
                    element:setVisible(false)
                else
                    element:loadTexture(tabs[3])
                end
                if tabs[4]~= "" then 
                    bg:loadTexture(tabs[4])
                else

                end 
                --显示道具详情
                local function CallBackEvent( sender,eventType )
                    if eventType == ccui.TouchEventType.ended then
                       --此处为正确调用
                      MsgManager:showSimpItemInfo(reward.type,reward.id)
                      --下面为测试使用
                        function buyItemCallBack(num) 
                                 --print("点击购买按钮回调")
                                 print("点击购买按钮回调"..num)
                        end
                     -- MsgManager:showSimpItemInfoAndDropInfo(reward.type,reward.id) 
                      -- MsgManager:shopBuyItemsInfo(reward.type,reward.id,100,2,self,buyItemCallBack)--购买无可选次数回调
                       --MsgManager:shopBuyItemsInfo(reward.type,reward.id,100,2,300,30,self,buyItemCallBack)--购买可选次数回调
                      --MsgManager:sellItemsInfo(reward.type,reward.id,1,300,30,self,buyItemCallBack)--贩卖
                    end
                end 
                icon:addTouchEventListener(CallBackEvent)
            end
        end
    end
    self.listView:jumpToTop()
end

function MapItemDrops:create(rData)
     local layer = MapItemDrops.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end