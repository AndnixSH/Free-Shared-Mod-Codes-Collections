--ExploreLayer.lua
--ExploreLayer.lua
--[[
探索主页面
]]
require "BasicLayer"
local scheduler = cc.Director:getInstance():getScheduler()
ExploreLayer = class("ExploreLayer",BasicLayer)
ExploreLayer.__index = ExploreLayer
ExploreLayer.lClass = 2

function ExploreLayer:init()
	--data
	self._currentAreaIdx = 1 --当前所在区域
	self._exploreListData = {}  --探索关卡的数据容器
    self._selectExploreItem = nil --存储 选中的探索关卡    目前的队伍派遣 返回需要单刷，所有标记
    self._selectExploreIdx = nil  --存储 选中的探索关卡Idx 目前的队伍派遣 返回需要单刷，所有标记
    self._time_diamond_rate = nil
    self._time_diamond_need = nil 
    self.isTouchBtnUpdate = false --点击按钮导致的界面刷新
    self.isGetItem = false --是否获得道具，用于返回的时候刷新界面
    self.area_state = {}
    self.schedulerEntry = nil 
    -- --新手引导临时存储数据
    -- if user_info["guide_id"] == GuideID.Explore then
    --     self.guideItem = nil
    -- end 

    local node = cc.CSLoader:createNode("ExploreLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    local panel = node:getChildByTag(101)
    self._rootCSbNode = panel
    local backBtn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(function(sender,eventType)
    	if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    
    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")

 	self:initListView()
    self:initMainBtn()
    self:RefshTopBar()

    ---第一次进入星界，更改配置文件
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Explore) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Explore, 1)
    end
    self:updateLastTime()
    


end
 --绑定四个按钮
function ExploreLayer:initMainBtn()
 	--self._rootCSbNode 
 	local function dealBtnEvent()
 		for i=1,4 do
    		local tag = 200+i
    		local button = ccui.Helper:seekWidgetByTag(self._rootCSbNode,tag)
		    if i==self._currentAreaIdx then
		      	button:setTouchEnabled(false)
		      	button:setBright(false)
		    else 
		      	button:setTouchEnabled(true) 
		      	button:setBright(true)
		    end
  		end
        self.isTouchBtnUpdate = true
  		self:requireExploreListInfo()--刷新当前数据
 	end

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            self._currentAreaIdx = sender:getTag()-200
            dealBtnEvent()
        end
    end 
    for i=1,4 do 
    	local tag = 200+i
    	local button = ccui.Helper:seekWidgetByTag(self._rootCSbNode,tag)
    	button:addTouchEventListener(touchCallBack)
    end 

    --点击说明按钮
    local function touchGuideBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:showGuidePicLayer()
        end
    end 
    local guideButton = ccui.Helper:seekWidgetByName(self._rootCSbNode,"Button_guide")
    guideButton:addTouchEventListener(touchGuideBtnEvent)

    --添加钻石、金币按钮
    local btnAddD = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_addD")
    btnAddD:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local index = 1
            local bOver = XbShopData:getInstance():checkActTimeOver()
            if bOver == true then
                index = 1
            else
                index = 2
            end

            local sData = {}
            sData["shopTypeIndex"] = index
            SceneManager:toShopLayer(sData)

            -- local sData = {}
            -- sData["sDelegate"] = self
            -- sData["sFunc"] = self.buyCallBack
            -- sData["shopTypeIndex"] = 1
            -- SceneManager:toShopLayer(sData) 
        end
    end)
    ---金币
    local btnAddG = ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn_addG")
    btnAddG:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local index = 3
            local bOver = XbShopData:getInstance():checkActTimeOver()
            if bOver == true then
                index = 3
            else
                index = 4
            end

            local sData = {}
            sData["shopTypeIndex"] = index
            SceneManager:toShopLayer(sData)

            -- local sData = {}
            -- sData["sDelegate"] = self
            -- sData["sFunc"] = self.buyCallBack
            -- sData["shopTypeIndex"] = 2
            -- SceneManager:toShopLayer(sData) 
        end
    end)

    self.sManager.menuLayer:hiddenUserInfo(true)

    --新手
    if XbTriggerGuideManager:isEndGuide(TriggerGuideConfig.Explore) then 
    else 
        self:showGuidePicLayer(true)
    end 

    local function deimeFunc()
        dealBtnEvent()
    end

    local delay    = CCDelayTime:create(0.1)
    local callfunc = CCCallFunc:create(deimeFunc)
    local sequence = cc.Sequence:create(delay, callfunc)
    self.uiLayer:runAction(sequence)
end
--购买钻石成功
function ExploreLayer:buyCallBack()
    self:RefshTopBar()
end
function ExploreLayer:showGuidePicLayer(isShowGuide)
    local data = {}
    data.pictures = {
          "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_010.png",
    }
    local function backFunc()
        XbTriggerGuideManager:finishGuide(TriggerGuideConfig.Explore)
    end
    data.sFunc = backFunc 
    data.sDelegate = nil   
    data.isShowGuide = isShowGuide or false
    self.sManager:toGuidePictureLayer(data)
end

function ExploreLayer:initListView()
   	local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 242,570)
    self.gridview:setDirection(SCROLLVIEW_DIR_HORIZONTAL)
    self.gridview.itemCreateEvent = function()
        local temp = ExploreIteamView.new():init()
        temp.ClickEvent = function(item)
            --点击
        end
        --开始按钮
        temp.onCickStartBtn = function(item)
           	self:toExploreTeamLayer(item._data)
        end
        --快速完成
        temp.onCickQucikDoBtn = function(item)
 		    print("立即完成")
            self:toExploreQuickEnd(item._data)
        end
        --获取奖励
        temp.onGetRewardBtn = function(item)
     		print("获取奖励")
            self:toGetReward(item._data)
        end
        -- --倒计时结束 回到方法
        -- temp.countDownTimeRefsh= function(item)
        -- 	self:requireExploreListInfo()
        -- end
        return temp
    end
end

--刷新英雄列表
function ExploreLayer:refreshListUI()
	--前面是保存一下当前的位置，跳转到固定位置
	local innerCSize = self.gridview._scrollView:getInnerContainerSize()
    local contSize =  self.gridview._scrollView:getContentSize()
    local w = innerCSize.width - contSize.width;
    local pos = self.gridview._scrollView:getInnerContainerPosition()
    local percent = 0
    if w ~= 0 then 
        percent = -(pos.x *100/w)
    end 
    if percent <0 then 
        percent = 0
    end 
    if percent >100 then 
        percent = 100
    end 

    self.gridview:setDataSource(self._exploreListData)
    if self.isTouchBtnUpdate then
        --按钮的相关操作
        self.gridview._scrollView:jumpToPercentHorizontal(0)
        self.isTouchBtnUpdate = false
    else 
        self.gridview._scrollView:jumpToPercentHorizontal(percent)
    end 
end

--重新请求数据
function ExploreLayer:refresh()
    self:RefshTopBar()
    self:requireExploreListInfo()
end

--探索队伍页面
function ExploreLayer:toExploreTeamLayer(data)
    --判断剩余次数
    local exploreData = DataManager:getExploreData()
    if exploreData.explore_num <= 0 then 
        MsgManager:showSimpMsg(UITool.ToLocalization("今日探索次数已用尽，请明日再来"))
    else 
        local rcvData = {}
        rcvData["sDelegate"] =  self
        rcvData["sFunc"] =  self.refresh
        rcvData["data"] =  data
        self.sManager:toExploreTeamLayer(rcvData)     
    end 
end

--立即完成按钮
function ExploreLayer:toExploreQuickEnd(_data)
    --判断消耗钻石
    local lastTime = _data.explore_time or 0
    self.selectExploreID = _data.explore_id
    local needDiamond = (1 + math.floor(lastTime/self._time_diamond_rate))*self._time_diamond_need 
    if needDiamond > (DataManager:getDiamond()) then 
        local strMsg = string.format(UITool.ToLocalization("星石不足%s"),needDiamond)
        MsgManager:showSimpMsg(strMsg)
    else 
        self._needDiamond = needDiamond
        local strMsg = string.format(UITool.ToLocalization("立即完成需要花费星石%s,是否立即完成"),needDiamond)
        MsgManager:showSimpMsgWithCallFunc(strMsg,self,self.requireExploreQc)
    end 
end

--获取奖励
function ExploreLayer:toGetReward(_data)
    self.selectExploreID = _data.explore_id
    self:requireExploreResult()
end

--探索结果页面
function ExploreLayer:toExploreResultLayer(data)
   self:refresh()
   local rcvData = {}
   rcvData["sDelegate"] =  self
   rcvData["sFunc"] =  self.refresh
   rcvData["data"] =  data
   self.sManager:toExploreResultLayer(rcvData)
   self.isGetItem = true
end

function ExploreLayer:requireExploreListInfo()
    --获取数据成功
    local function ReqSuccess(data)
        user_info["explore_num"] = data.explore_num        -- #当前剩余的探索次数
        user_info["explore_max"] = data.explore_max        --  #最大探索次数
        user_info["explore_lv"] = data.explore_lv          --#当前的探索等级
        user_info["explore_exp"] = data.explore_exp        --#当前的探索经验
        user_info["explore_max_exp"] = data.explore_max_exp--#等前升级所需的探索经验

        self.area_state = data.area_state --# 各区域的完成状态 1代表有完成的,0代表没有已完成的
        self._exploreListData = {}
        self._exploreListData = data["explore_list"]
        self._time_diamond_rate =  data["time_diamond_rate"]
        self._time_diamond_need =  data["time_diamond_need"]
        self:refreshListUI()
        self:updateBtnAreaStatue()
        self:RefshTopBar()
    end
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end

        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "explore_list",
        ["area_id"] = self._currentAreaIdx,
    }
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--立即完成
function ExploreLayer:requireExploreQc()
    --获取数据成功
    local function ReqSuccess(data)
        print("立即完成成功返回")
        local c_data = data
        c_data.explore_id = self.selectExploreID
        --更新userdata
        self:toExploreResultLayer(c_data)
        self:updateUserExploreInfo(c_data)
        self._needDiamond = 0
    end
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "explore_qc",
        ["explore_id"] = self.selectExploreID,
    }
    --dump(tempTable)
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--探索结果页面
function ExploreLayer:requireExploreResult()
    --获取数据成功
    local function ReqSuccess(data)
        print("点击完成弹出结果页面")
        --dump(data)
        local c_data = data
        c_data.explore_id = self.selectExploreID
        self:toExploreResultLayer(c_data)
        self:updateUserExploreInfo(c_data)
    end
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        ReqSuccess(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "explore_result",
        ["explore_id"] = self.selectExploreID,
    }
    --dump(tempTable)
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
---更新倒计时
function ExploreLayer:updateLastTime()
   local function unpause(time)
   		for i=1,#self._exploreListData do 
   			if self._exploreListData[i].explore_time ~= nil then 
   				if self._exploreListData[i].explore_time > 0 then 
   					self._exploreListData[i].explore_time = self._exploreListData[i].explore_time - 1
   				else 
   					self._exploreListData[i].explore_time = nil 
   					self:requireExploreListInfo()
   				end 
   			end 
   		end 
   end
   local scheduler = cc.Director:getInstance():getScheduler()
   self.schedulerEntry = scheduler:scheduleScriptFunc(unpause,1, false)
end
--停止添加的计时器
function ExploreLayer:stopUpdate()
    if self.schedulerEntry == nil then return end
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.schedulerEntry)
    self.schedulerEntry = nil
end
--topbar todo可以写到startLayer
function ExploreLayer:RefshTopBar()
    local panel_3 = ccui.Helper:seekWidgetByName(self._rootCSbNode,"topBar")
    local data = DataManager:getExploreData()
    local numPercentValue = math.floor(data.explore_num/data.explore_max*100)
    local expPrecentValue = math.floor(data.explore_exp/data.explore_max_exp*100)
    local keyStr = {
        [1] = "explore_num", --探索次数 1/5
        [2] = "explore_level",--当前探索等级
        [3] = "info_lab_2", -- 钻石
        [4] = "info_lab_3", -- 金币
    }
    local dataTable = {
          [1] = data.explore_num.."/"..data.explore_max,
          [2] = data.explore_lv,
          [3] = user_info["gem"],
          [4] = user_info["gold"],
    }
    for i=1,#keyStr do
        local lab = ccui.Helper:seekWidgetByName(panel_3,keyStr[i])
        lab:setString(dataTable[i]) 
    end
    local expBar = ccui.Helper:seekWidgetByName(panel_3,"exp_bar")
    expBar:setPercent(expPrecentValue)
end
--更新user_info
function ExploreLayer:updateUserExploreInfo(data)
    --更新use数据
    user_info["beryl"] = data.beryl
    user_info["gold"] = data.gold
    user_info["gem"] = data.gem
    user_info["gem_r"] = data.gem_r
    local exploreRank = data.explore_result.explore_rank
    local exploreData = {}
    exploreData.explore_lv = exploreRank["rank_new"]          --#当前的探索等级
    exploreData.explore_exp = exploreRank["rank_new_exp"]     --#当前的探索经验
    exploreData.explore_max_exp = exploreRank["rank_max_exp"] --#等前升级所需的探索经验
    DataManager:refreshExploreData(exploreData)
    self:RefshTopBar()
end

--更新按钮的小红点提示状态
function ExploreLayer:updateBtnAreaStatue( )
    -- body
    for i=1,4 do 
        local img = ccui.Helper:seekWidgetByName(self._rootCSbNode,"sWar_"..i)
        if img then 
            self.area_state[i] = self.area_state[i] or 0
            if self.area_state[i] == 1 then 
                img:setVisible(true)
            else 
                img:setVisible(false)
            end 
        end 
    end 
end

function ExploreLayer:returnBack()

   self.sManager:removeFromNavNodes(self)
   --self.sManager.menuLayer:RefshTopBar()
    if self.backFunc then
      self.backFunc(self.sManager)
   end
    if self.rData["rcvData"]["isCallFunc"] then
        if self.isGetItem then  --如果获得了素材，就刷新回调
            self.rData["rcvData"]["callFunc"](self.rData["rcvData"]["self"])
        end 
    end
   self.exist = false
   self:clearEx()
end

function ExploreLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function ExploreLayer:clear()
	self:stopUpdate()
    self.sData = nil
    self.rData = nil
    self.sManager = nil
    self.sDelegate  = nil
    if self.uiLayer~=nil then
        self.uiLayer:removeFromParent()
        self.uiLayer = nil
    end
    self._exploreListData = nil  --探索关卡的数据容器
    self._selectExploreItem = nil --存储 选中的探索关卡    目前的队伍派遣 返回需要单刷，所有标记
    self._selectExploreIdx = nil  --存储 选中的探索关卡Idx 目前的队伍派遣 返回需要单刷，所有标记
    self._time_diamond_rate = nil
    self._time_diamond_need = nil 
    self.isTouchBtnUpdate = false --点击按钮导致的界面刷新
    self.area_state = nil
    self.schedulerEntry = nil 
    self = nil
end

--todo
function ExploreLayer:setShow( )
	-- body
    self.sManager.menuLayer:hiddenUserInfo(true)
    self.sManager.menuLayer:showTopBarBG(false)
end
function ExploreLayer:create(rData)
     local layer = ExploreLayer.new()
     layer.rData = rData
     layer.titleNum = 13
     layer.sManager = layer.rData["sManager"]
     layer.backFunc = layer.rData["rcvData"]["sFunc"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
