
--好友系统




FriendsSys = class("FriendsSys")


function FriendsSys:getInstance()
   if self.s_instance == nil then

        self.s_instance = FriendsSys.new()
        self:initialize()

   end
   return self.s_instance;
end


function FriendsSys:initialize()

    self:reset()

end

function FriendsSys:reset()
    self.lastChanglistTime = 0
    self.maxChangeTime = 10
    self.findFriendList = {}
end

function FriendsSys:getLastChanglistTime()
    return self.lastChanglistTime
end

function FriendsSys:setLastChanglistTime(time)
    self.lastChanglistTime = time
end

function FriendsSys:getMaxChanglistTime()
    return self.maxChangeTime
end

--获得查询好友列表
function FriendsSys:getFindFriendList()
    return self.findFriendList
end

--设置查询好友列表
function FriendsSys:setFindFriendList(findList)
    self.findFriendList = findList or {}
end

--检测红点
function FriendsSys:checkRedDot()
    
    -- if XBChatSys:getInstance():getInitSdkResult() == false then
    --     return false

    -- end
     
    local friendApplyList = XBChatSys:getInstance():getFriendApplyList()
    if type(friendApplyList) == "table" and #friendApplyList > 0 then
        return true
    end

    return false
end


-- --删除好友
-- function FriendsSys:deleteFriend(friendArr)


--      --发送消息好友信息改变
--     lemon.EventManager:getInstance():dispatchCustomEvent(EEventType.FRIEND_DELETE, friendArr)
   
-- end

-- --删除好友
-- function FriendsSys:addFriend(friendArr)


--      --发送消息好友信息改变
--     lemon.EventManager:getInstance():dispatchCustomEvent(EEventType.FRIEND_ADD, friendArr)
   
-- end



--好友赠送体力
-- friend_id 用户id
-- type 1 公会， type 2，好友
function FriendsSys:reqGiveFriendAp(reqData, successCallback, failCallback)

   
    local uid = table.getValue("FriendsSys:reqGiveFriendAp reqData", reqData, "uid")
    print("uid", uid)

    -- 体力赠送最大值
    local maxGiveCount = XBChatSys:getInstance():getMaxGiveNum( )
    -- 体力赠送最大值
    local curGiveCount = XBChatSys:getInstance():getCurGiveNum( )

    print("maxGiveCount", maxGiveCount)
    print("curGiveCount", curGiveCount)

    if curGiveCount >= maxGiveCount then
        local msg = string.format(Lang:toLocalization(1040137), maxGiveCount, maxGiveCount)
        MsgTipSys:getInstance():addData(msg)

        if failCallback then
            failCallback()
        end
        return 
   
    end

    local tempData = {
        ["rpc"]       = "give_ap",
        ["friend_id"] = uid,
        ["type"] = 2
    }
   

    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --success

            
            local friendArr = {}
            table.insert(friendArr, uid)
            XBChatSys:getInstance():giveFriendAp(uid)
            local nextGiveNum = curGiveCount + 1
            XBChatSys:getInstance():setCurGiveNum(nextGiveNum)

              --发送消息好友信息改变
            lemon.EventManager:getInstance():dispatchCustomEvent(EEventType.FRIEND_FRESH, friendArr)


            local msg = string.format(Lang:toLocalization(1040136), nextGiveNum, maxGiveCount)
            MsgTipSys:getInstance():addData(msg)

           


            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end


function FriendsSys:reqGiveGuildAp(reqData, successCallback, failCallback)

   
    local uid = table.getValue("FriendsSys:reqGiveGuildAp data", reqData, "uid")
    print("uid", uid)

    -- 体力赠送最大值
    local maxGiveCount = GuildSys:getInstance():getMaxGiveCount( )
    -- 体力赠送最大值
    local curGiveCount = GuildSys:getInstance():getCurGiveCount( )

    print("maxGiveCount", maxGiveCount)
    print("curGiveCount", curGiveCount)

    if curGiveCount >= maxGiveCount then
        local msg = string.format(Lang:toLocalization(1040142), maxGiveCount, maxGiveCount)
        MsgTipSys:getInstance():addData(msg)

        if failCallback then
            failCallback()
        end
        return 
   
    end

    local tempData = {
        ["rpc"]       = "give_ap",
        ["friend_id"] = uid,
        ["type"] = 1
    }
   

    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --success

            local friendArr = {}
            table.insert(friendArr, uid)
            lemon.EventManager:getInstance():dispatchCustomEvent(EEventType.GUILD_GIVE_AP, friendArr)
            XBChatSys:getInstance():giveGuildAp(uid)

            curGiveCount = curGiveCount + 1
            GuildSys:getInstance():setCurGiveCount(curGiveCount)
            local msg = string.format(Lang:toLocalization(1040141),  curGiveCount, maxGiveCount)
            MsgTipSys:getInstance():addData(msg)
           


            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end


--推荐好友
function FriendsSys:recommendUser(reqData, successCallback, failCallback)

    local tempData = {
        ["rpc"]       = "recommend_user",
       
    }
   

    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --successs

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end

--根据id查询用户
function FriendsSys:searchUser(reqData, successCallback, failCallback)
    local userId = table.getValue("FriendsSys:searchUser data", reqData, "userId")
    local tempData = {
        ["rpc"]       = "search_user",
        ["uid"]       = userId
    }
   

    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --successs

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end

-- # ■ [更新玩家的聊天配置]
-- # 接口名: sync_chat_conf
-- # 参数: "uid": "WIUE9232I9",  # 要查找的玩家ID
-- # 参数: accept: 1,    1-接受其他玩家加好友请求 0-不接收

function FriendsSys:synChatConf(reqData, successCallback, failCallback)
    dump(reqData, "FriendsSys:synChatConf")

    local userId = table.getValue("FriendsSys:searchUser data", reqData, "userId")
    local accept = table.getValue("FriendsSys:searchUser data", reqData, "accept")

    local tempData = {
        ["rpc"]       = "sync_chat_conf",
        ["uid"]       = userId,
        ["accept"]       = accept
    }

    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --successs
            print("FriendsSys:synChatConf successs")
            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end


-- # ■ [更新玩家的聊天配置]
-- # 接口名: user_chat_conf
-- # 参数: "uid": "WIUE9232I9",  # 要查找的玩家ID

function FriendsSys:userChatConf(reqData, successCallback, failCallback)
    local uids = table.getValue("FriendsSys:searchUser data", reqData, "uids")

    local tempData = {
        ["rpc"]       = "user_chat_conf",
        ["uids"]       = uids,
    }
   
    GameManagerInst:rpc(tempData,
        10,
        function(data)
            --successs

            if successCallback then
                successCallback(data)
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
            if failCallback then
                failCallback()
            end
        end,
        true)
    
end




function FriendsSys:handleFriendServerData(srcData)
    local uid = table.getValue("", srcData, "uid")
    local isFriend = XBChatSys:getInstance():isMyFriendById( uid ) 
    local isFriendValue = 0
    if isFriend then
        isFriendValue = 1
    end

    local friend_can_give = XBChatSys:getInstance():getGiveFriendApValue(uid)
    

     local data = { 
            ["rank"]            = table.getValue("", srcData, "rank") or 1,              -- 等级
            ["name"]            = table.getValue("", srcData, "name") or "name",          -- 玩家名称
            ["uid"]             = table.getValue("", srcData, "uid") or "0",            -- 玩家ID
            ["head"]            = table.getValue("", srcData, "head")or 13,            -- 头像id
            ["team_score"]      = table.getValue("", srcData, "team_score") or 0,      -- 战斗力
            ["title_id"]        = table.getValue("", srcData, "title_id"),               --称号                                      --称号
            ["position"]        = table.getValue("", srcData, "position") or 1,            --公会工作
            ["score"]           = table.getValue("", srcData, "score")or 0,              --公会积分
            ["login_tm"]        = table.getValue("", srcData, "login_tm") or -1,                                                     --在线时间
            ["can_give"]        = table.getValue("", srcData, "can_give") or 0,            --是否给过体力 
            ["is_friend"]       = isFriendValue or 0,                                           --是否是好友
            ["user_nim_id"]     = table.getValue("", srcData, "user_nim_id") or 0,          --  云信id
            ["friend_can_give"] = friend_can_give or 0,                                 -- 好友是否可以赠送体力
            ["online"]          = table.getValue("", srcData, "online") or 0,          --  云信id
            ["lastAddTime"]     = table.getValue("", srcData, "lastAddTime") or 0,          -- 上次添加好友的时间

        }

    -- dump(data, "FriendsSys:handleFriendServerData")
    return data
end 

function FriendsSys:handleFriendApplyServerData(srcData)
     local data = { 
            ["rank"]            = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "rank") or 1,             -- 等级
            ["name"]            = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "name") or "",              -- 玩家名称
            ["uid"]             = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "uid") or 0,                -- 玩家ID
            ["head"]            = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "head") or 0,            -- 头像id
            ["team_score"]      = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "team_score") or 0,   -- 战斗力
            ["title_id"]        = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "title_id") or "",              --称号
            ["login_tm"]          = table.getValue(" XbFriendsGuildApplyItem self._data", applicants[i], "login_tm") or -1,            --在线时间
            ["user_nim_id"]     = table.getValue(" XbGameFriendsItem self._data", applicants[i], "user_nim_id") or 0,
            ["requestFriendMessage"]     = table.getValue(" XbGameFriendsItem self._data", applicants[i], "requestFriendMessage") or "mess",
        }


    return data
end 


--排序好友公会
function FriendsSys:sortFriendGuildData(guildList)
 
    dump(guildList, "sortFriendGuildData guildList")
    table.sort(guildList,function(a, b)
          
            if (a.position or 0) > (b.position or 0) then
                return true
            elseif (a.position or 0) == (b.position or 0) then
                if (a.score or 0) > (b.score or 0) then
                    return true
                end
            end
            return false

        end)
    print("sort after")
    dump(guildList, "sortFriendGuildData guildList")
    return guildList
end


--排序好友
function FriendsSys:sortFriendData(friendList)
 
    -- dump(friendList, "sortFriendGuildData friendList")
    table.sort(friendList,function(a, b)
            --登陆状态为2，表示在线
   
            if (a.online or 0) > (b.online or 0) then
                return true

            elseif (a.online or 0) == (b.online or 0) then
                if (a.login_tm or 0) < (b.login_tm or 0) then
                    return true
                elseif (a.login_tm or 0) == (b.login_tm or 0) then
                    if (a.team_score or 0) > (b.team_score or 0) then
                        return true
                    end
                end

            end
            
            return false

        end)
    print("sort after")
    -- dump(friendList, "sortFriendGuildData friendList")
    return friendList
end




-- 距返回时间24小时以内。  上次登录 *小时*分钟前
-- 距返回时间24小时以上。  上次登录 1天前
-- 距返回时间2天以上。  上次登录2天前

function FriendsSys:lastLoginTimetoVisibleStr(lastloginTime,isSelf, online)
    print("FriendsSys:lastLoginTimetoVisibleStr lastloginTime = ", lastloginTime)
    print("FriendsSys:lastLoginTimetoVisibleStr online = ", online)
    lastloginTime = lastloginTime or -1
    local timeStr = ""
    if lastloginTime < 0 or isSelf == true or online == 2 then
        timeStr = Lang:toLocalization(1040134)

    else
        local nowTime  =UserDataMgr:getInstance().timeData:getCurrentTime()
         -- print("FriendsSys:lastLoginTimetoVisibleStr nowTime = ", nowTime)
        local dist = nowTime - lastloginTime
        local tableTime = UITool.ShowTime(dist)
        -- dump(tableTime, "lastLoginTimetoVisibleStr tabletime")
        
        if tableTime["D"] < 1 then

            if tableTime["H"] < 1 then

                local minnute = math.max(1, tableTime["M"])
                timeStr = string.format(Lang:toLocalization(1040133), minnute)

            else

                timeStr = string.format(Lang:toLocalization(1040132), tableTime["H"], tableTime["M"])

            end
            
        else
            timeStr = string.format(Lang:toLocalization(1040131), tableTime["D"])

        end

    end
    
    return timeStr
   
end

--获得在线时间类型 
-- 1、在线，2、一天内，3、一周内，4、一个月内，5、一个月外
--lastloginTime 上次登陆时间， online 表示是否在线
function FriendsSys:getLoginTimeType(lastloginTime,online)
    print("FriendsSys:getLoginTimeType lastloginTime = ", lastloginTime)
    lastloginTime = lastloginTime or 0
    
    local nowTime  =UserDataMgr:getInstance().timeData:getCurrentTime()

    local dist = nowTime - lastloginTime
    local tableTime = UITool.ShowTime(dist)

    local loginTimeType = 1

    if online == true then
        loginTimeType = 1
    else

        if tableTime["D"] < 1 then

            loginTimeType = 2
        
        elseif tableTime["D"] < 7 then
            loginTimeType = 3
        elseif tableTime["D"] < 30 then
            loginTimeType = 4
        else
            loginTimeType = 5
        end

    end
    
    -- print("loginTimeType", loginTimeType)
    return loginTimeType
   
end




