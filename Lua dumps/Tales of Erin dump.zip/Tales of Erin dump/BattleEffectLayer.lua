--特效所在的Layer，比如技能特效
--create by kobejaw.2018.4.24.
BattleEffectLayer = class("BattleEffectLayer", function()
    return cc.Layer:create();
end);

function BattleEffectLayer:ctor()
	G_EffectLayer = self;
end