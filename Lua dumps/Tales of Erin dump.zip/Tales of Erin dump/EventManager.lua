
--事件派发管理器管理器
--单例类
--调用cocos 库总的派发事件，实现事件管理，有需要的时候，可自实现事件派发
--[[
    添加
    self.event_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.EVENT_TEST,callback)
    callback(event){  table_data = event.__usedata}
    移除
    lemon.EventManager:getInstance():removeEventListener(self.event_listener)
    派发
    lemon.EventManager:dispatchCustomEvent(EEventType.EVENT_TEST, table)
]]--

lemon = lemon or {}
lemon.EventManager = class("EventManager")

local EventManager = lemon.EventManager

function EventManager:ctor()
    self.eventArr= {}
end



function EventManager:getInstance()
    if self.s_Instance == nil then
        self.s_Instance = self:new()
    end
    return self.s_Instance

end

function EventManager:clearData(  )
    local eventDispatcher =  cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:removeAllEventListeners()
end

--添加自定义事件监听
-- EventListenerCustom* addCustomEventListener(const std::string &eventName, const std::function<void(EventCustom*)>& callback);
function EventManager:addCustomEventListener(eventName, callback)
    assert(type(eventName) == "string" , "type(eventName) == 'string'")

    local function bind(event)
        print("bind")
        return self.handlebind(self, callback, event)
    end
    local listener = cc.EventListenerCustom:create(eventName, bind)
    -- local listener = cc.EventListenerCustom:create(eventName, callback)
    local eventDispatcher =  cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:addEventListenerWithFixedPriority(listener, 1)


    return listener
end



-- 
function EventManager:handlebind(callback, event)
    print("EventManager:handler()")
    if type(callback) == "function"  then
       callback(event._usedata)
    end
end

--移除事件监听
--  void removeEventListener(EventListener* listener);
function EventManager:removeEventListener(listener)
    cc.Director:getInstance():getEventDispatcher():removeEventListener(listener)
end



--派发自定义事件
--  void dispatchCustomEvent(const std::string &eventName, void *optionalUserData = nullptr);
function EventManager:dispatchCustomEvent(eventName, data)
    
    assert(type(data) == "table" and type(eventName) == "string" , "type(data) == 'table' and type(eventName) == 'string'")

    local event = cc.EventCustom:new(eventName)
    event._usedata = data 
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
end