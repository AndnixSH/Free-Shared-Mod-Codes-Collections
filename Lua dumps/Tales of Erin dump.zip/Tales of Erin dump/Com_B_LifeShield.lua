--生命护盾组件
--created by kobejaw. 2018.6.8.
Com_B_LifeShield = class("Com_B_LifeShield",ComponentBase)

--81033
function Com_B_LifeShield:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 1
	self.buffType = Com_BuffEnum.LifeShield
	
	local value1 = self.comData.effect1
	local value2 = self.comData.effect2
	local value3 = self.comData.effect3

	--剩余的可以吸收的伤害值
	self.remainHP = 0;
	if value1 ~= 0 then
		self.remainHP = value1
	elseif value2 ~= 0 then
		self.remainHP = math.ceil( BattleDamageCompute:getSoloATK(target.attributeManager:getAttack()) * value2/1000)
	elseif value3 ~= 0 then
		self.remainHP = math.ceil(value3/1000 * target.attr[AE.hp_max])
	end
end

--返回吸收后的剩余的伤害值。
function Com_B_LifeShield:onAttacked(dmg)
	local remain = self.remainHP - dmg
	if remain > 0 then --完全吸收
		self.remainHP = remain
		return 0
	elseif remain == 0 then --完全吸收，生命护盾消失
		self.target.componentManager:removeCom(self)
		return 0
	else   --只吸收了一部分，生命护盾消失。
		local result = dmg - self.remainHP
		self.target.componentManager:removeCom(self)
		return result
	end
end