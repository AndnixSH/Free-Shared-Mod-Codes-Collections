double_drop_conf = {} 

double_drop_conf[1] = {
    remark = "单人副本",
    priority= 1,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[2] = {
    remark = "多人战",
    priority= 2,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[3] = {
    remark = "试炼之地",
    priority= 3,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[4] = {
    remark = "公会塔",
    priority= 4,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[5] = {
    remark = "星界探索",
    priority= 5,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[6] = {
    remark = "黑潮遗迹",
    priority= 6,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[7] = {
    remark = "英雄升级",
    priority= 7,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[8] = {
    remark = "主线副本",
    priority= 8,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}

double_drop_conf[9] = {
    remark = "星盘副本",
    priority= 9,
    icon_m= "zqxg_ui_014.png",
    icon_p= "zqxg_ui_013.png",
}