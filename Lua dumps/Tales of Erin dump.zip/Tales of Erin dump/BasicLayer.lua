BasicLayer = class("BasicLayer")
BasicLayer.__index   = BasicLayer
BasicLayer.uiLayer   = nil     --ui层
BasicLayer.exist     = false   --界面是否存在
BasicLayer.sData     = nil     --发送数据表 抱括 sDelegate 回调对象  sFunc 回调方法 注：此处存在2种回调机制，1为继承的refresh方法，2为回调
BasicLayer.rData     = nil    --接收数据表 抱括sManager全局管理者，上一层管理者发来的sData
BasicLayer.sManager  = nil     --所属管理者 
BasicLayer.sDelegate  = nil    --上级界面的代理 
BasicLayer.backFunc  = nil     --上级界面返回接口
BasicLayer.lClass    = nil     --界面等级
BasicLayer.lName     = nil     --界面名字
BasicLayer.ModelType = nil     --界面连续的切换
BasicLayer.titleNum  = -1      --界面的title编号 对应SceneManager的titleTable
BasicLayer.sec = nil
BasicLayer.baseScheduler = nil
function BasicLayer:clear()
  print("BasicLayer:clear")
    self.sData = nil
    self.rData = nil
    self.sManager = nil
    self.ModelType = nil
    self.sDelegate  = nil
    if self.uiLayer~=nil and tolua.isnull(self.uiLayer) == false then
      print("self.uiLayer:removeFromParent()")
      self.uiLayer:removeFromParent()
      self.uiLayer = nil
    end
   
   if self.sec~=nil then
   	
   end
   if self.baseScheduler ~= nil then
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.baseScheduler)
    self.baseScheduler = nil
  end
end
--界面切换刷新数据
--根据不同功能进行自定义数据结构
function BasicLayer:refresh(refData)

end
--界面切换显示隐藏动画
--["isShow"] = 0, -- 0隐藏, 1显示 ,2 特殊隐藏  3特殊显示
--["sDelegate"] = nil,--动画结束回调者
--["sFunc"] = nil,--动画结束回调方法 
function BasicLayer:setShow()
     
    if self.uiLayer ==nil then
      return
    end
end

