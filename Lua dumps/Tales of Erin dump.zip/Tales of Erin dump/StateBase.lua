--状态基类。
--created by kobejaw.2018.3.29.
StateBase = class("StateBase")

function StateBase:ctor(entity)
	self.entity = entity;
	self.needUpdate = false;
end

--must override
function StateBase:Enter()
	if self.isSkill then
		if self.entity.isDead then
			return
		end

		if G_GameState == 5 then
			if not self.skillInfo.isPrincess then
				self.entity.fsm:changeState(StateEnum.Idling)
			end
			return
		end

		if self.entity.entityType == 2 then
			self.entity.skillManager:onPlaySkill()

			--怪物技能语音
			BattlePlaySound(self.skillInfo.skill_voice,false,1)
		end

		if self.skillInfo.isBigSkill then
			G_BattleContainerLayer:zoomIn_BigSkill(self.entity)
		end

		if not self.skillInfo.isPrincess then
			self.entity:playSkillAnimation(self.skillInfo)
			print("释放技能，释放者类型："..self.entity.entityType.."   技能ID："..self.skillInfo.skillId)

			--触发器
			local option = {}
			option.dmg = 0  --纠错处理，正常情况下绝对不会用到dmg
			option.skillId = self.skillInfo.skillId
			option.trig_time = 3
			option.skillOwner = self.entity
			--触发时机3.使用技能时。
			self.entity.triggerManager:check(3,option)
			--触发时机103。队友使用技能时。
			option.trig_time = 103
			self.entity.teamManager:checkTeamTrigger(103,self.entity,option)
		else --神格技能,一定是场景类
			self:dealWithAutoplayEvent()
			print("释放技能，释放者类型：神格技能".."   技能ID："..self.skillInfo.skillId)	
		end
	end
end

--must override
function StateBase:Exit()
	self.entity:stopNodeActions();
	G_EntityLayer:resetZOrder()
	if self.entity.entityType == 2 and self.isSkill then
		self.entity.skillManager:onSkillFinished()
	end
end

--override if neccessary
function StateBase:onSpineEventCallback(event)
end
--override if neccessary
function StateBase:onSpineCompleteCallback(event)
end

--检测某个地块是否在自己的射程范围内
--引入enemy用于处理体积，用传进来的w,h，而不从enemy上取。这里逻辑有点乱，需求是格子和体积混用，暂时没找到好的处理方法。
function StateBase:checkIsInRange(w,h,enemy)
	local self_w,self_h = self.entity:getBoxWH()
	local shotRange = self.entity.shotRange
	if self.entity.entityType == 1 and enemy and not BattleDataManager.isBoss then
		shotRange = shotRange + enemy.cubageType
	end

	if math.abs(self_w - w) + math.abs(self_h - h) <= shotRange then
		return true
	else
		return false
	end
end

--检测某个敌人是否在自己射程范围内
function StateBase:checkIsEnemyInRange(enemyEntity)
	local w,h = enemyEntity:getBoxWH();
	return self:checkIsInRange(w,h,enemyEntity)
end 

--检测是否是autoplay类型的事件
function StateBase:checkIsAutoplayEvent(event)
	if string.find(event.eventData.name,"Autoplay") then
		return true
	else
		return false
	end
end

--检测是否是attack类型的事件
function StateBase:checkIsAttackEvent(event,skillInfo)
	--特殊情况处理：有些动作里是没有attack事件的，有可能要用autoplay事件代替attack事件，见过太多特殊情况了，现在心如止水了。
	--例如技能20041。
	if skillInfo and not skillInfo.haveAutoplayEffect and self:checkIsAutoplayEvent(event) then
		return true,1
	end

	--常规情况
	if string.find(event.eventData.name,"attack") then
		if string.len(event.eventData.name) >= 7 then
			return true,tonumber(string.sub(event.eventData.name,7,7))
		else
			return true,0
		end
	--奇葩历史遗留特殊情况处理
	elseif string.find(event.eventData.name,"nvzhu") then
		if string.len(event.eventData.name) >= 6 then
			return true,tonumber(string.sub(event.eventData.name,6,6))
		else
			return true,0
		end
	else
		return false
	end
end

--检测是否是cutin事件.
--return 0:非cutin事件。1.cutin事件 2.endcutin事件
function StateBase:checkIsCutInEvent(event)
	if string.find(event.eventData.name,"endcutin") then
		return 2
	elseif string.find(event.eventData.name,"cutin") then
		return 1
	else
		return 0
	end
end

--通用的几个spine事件
function StateBase:dealWithCommonEvents(event,skillInfo)
	--震屏
	if string.find(event.eventData.name,"shake") then
		local id = tonumber(string.sub(event.eventData.name,6,6))
		G_BattleContainerLayer:startShake(id)
	--"teshuji"
	elseif string.find(event.eventData.name,"teshuji") then
		local node = cc.CSLoader:createNode("uifile/Shan.csb")
		self.entity:addChild(node)
	    local action = cc.CSLoader:createTimeline("uifile/Shan.csb")
	    node:runAction(action)
	    action:play("shan",false);

	    local function removeShanNode()
	    	node:removeFromParent();
	    end

	    if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
	    	PerformWithDelayTime(removeShanNode,0.5)
	    else
	    	action:setLastFrameCallFunc(removeShanNode)
	    end
	--音效
	elseif string.find(event.eventData.name,"playmusic") then
		--技能音效
		if skillInfo then
			if string.find(event.eventData.name,"playmusic1") then
				if skillInfo.skill_sound ~= "" then
					local str = string.sub(skillInfo.skill_sound,1,13).."2"..string.sub(skillInfo.skill_sound,14)
					BattlePlaySound(str,false,0)
				end
			else
				BattlePlaySound(skillInfo.skill_sound,false,0)
			end
		--普通攻击出手音效
		else
			BattlePlaySound(self.attackSound,false,2)
		end
	end
end

--技能的击中特效（普通攻击的在自己的类里）
function StateBase:playHitEffect(defender,res_hit)
	if res_hit and res_hit ~= "" then
		local hitEffectSpineNode = CreateEffectSpineNode(res_hit)
		table.insert(G_NodesWithSpine,hitEffectSpineNode)
		defender.effectNode:addChild(hitEffectSpineNode)
		RemoveEffectOnComplete(hitEffectSpineNode)
	end
end

--检测是否能在两种异常状态中切换（有优先级）
function StateBase:checkCanChangeToUnusualState(type)
	--浮空和击飞优先级最高，击倒次之，击退最次。
	if self.entity.isDead or self.entity.isBoss or self.entity.componentManager.BaTi or self.entity.componentManager:checkIsWuDi() 
		or (self.entity.fsm.currentState.isSkill and self.entity.fsm.currentState.skillInfo.isBigSkill) then
		return false
	end

	--霸体次数护盾
	local batiNumShieldCom = self.entity.componentManager:getComById(81067)
	if batiNumShieldCom then
		batiNumShieldCom:onLoseOneOverlay()
		return false
	end

	--精英怪不会进入状态5
	if self.entity.entityType == 2 and self.entity.data.monsterEnum == 6 and type == 5 then
		return false
	end

	--从其他状态进入异常状态
	if self.entity.fsm.currentState.stateEnum ~= StateEnum.UnusualCondition then
		return true
	elseif self.entity.fsm.currentState.isStandingUp and type ~= 5 then
		return true
	end
	--当前正处在异常状态，优先级高的替换优先级低的。type值小的可以替换type值大的。浮空和击飞可以相互替换。
	if type == 5 then
		return false
	elseif type <=2 then
		return true
	elseif type <= self.stateType then
		return true
	end
	return false
end

--检测是否造成击飞浮空击退击倒
--return:  1:击飞。2.浮空。3.击倒.4.击退。
function StateBase:checkIsCauseUnsualCondition(event)
	local pos
	local len = string.len(event.eventData.name)

	pos = string.find(event.eventData.name,"befly")
	if pos then
		return 1,tonumber(string.sub(event.eventData.name,len,len))
	end

	pos = string.find(event.eventData.name,"befloat")
	if pos then
		return 2,tonumber(string.sub(event.eventData.name,len,len))
	end

	pos = string.find(event.eventData.name,"bedown")
	if pos then
		return 3,tonumber(string.sub(event.eventData.name,len,len))
	end

	pos = string.find(event.eventData.name,"beback")
	if pos then
		return 4,tonumber(string.sub(event.eventData.name,len,len))
	end

	return false;
end

--处理造成异常状态的情况。
function StateBase:dealWithUnsualCondition(type,attacker,defender,event)
	if defender.isBoss then
		return false
	end

	local result1,result2 = self:checkIsCauseUnsualCondition(event)
	if result1 then
		if defender.fsm.currentState:checkCanChangeToUnusualState(result1) then
			local data = {}
			data.stateType = result1;
			data.arg = result2;
			defender.fsm:changeState(StateEnum.UnusualCondition,data)
			return true
		end
	end	
end

--处理autoplay事件，场景类和自身类通用
function StateBase:dealWithAutoplayEvent()
	local pos
	--自身类
	if self.skillInfo.skillType == 1 then
		pos = cc.p(self.entity:getPositionX(),self.entity:getPositionY())
	--场景类
	else
		pos = G_BattleLayer:convertToNodeSpace(cc.p(640,360))
	end

	local effectNum = 0
	local firstEffectRes
	if self.skillInfo.res_scene ~= "" then
		firstEffectRes = self.skillInfo.res_scene
		effectNum = effectNum + 1
	end
	if self.skillInfo.res_fly ~= "" then
		effectNum = effectNum + 1

		if self.skillInfo.res_scene == "" then
			firstEffectRes = self.skillInfo.res_fly
		end

	end 

	if effectNum == 0 then
		print("配表错误，没有特效资源")
		return
	end

	local effectSpineNode = CreateEffectSpineNode(firstEffectRes)
	table.insert(G_NodesWithSpine,effectSpineNode)
	G_EntityLayer:addChild(effectSpineNode)
	effectSpineNode:setLocalZOrder(-10000)
	effectSpineNode:setPosition(pos)

	local this = self;
	local function eventCallback(event)
		--震屏，闪烁等处理
		this:dealWithCommonEvents(event,this.skillInfo)

		--"attack"事件
		local result1,result2 = this:checkIsAttackEvent(event)
		if result1 then
			this:dealWithAttackEvent(event,result2)
		end

		--"autoplay"事件。如果effectNum为2，则由res_scene中的autoplay触发res_fly
		result1 = this:checkIsAutoplayEvent(event)
		if result1 and effectNum == 2 then
			local effectSpineNode2 = CreateEffectSpineNode(self.skillInfo.res_fly)
			table.insert(G_NodesWithSpine,effectSpineNode2)
			G_EffectLayer:addChild(effectSpineNode2)
			effectSpineNode2:setLocalZOrder(-10000)
			effectSpineNode2:setPosition(pos)			
			local function eventCallback2(event2)
				--震屏，闪烁等处理
				this:dealWithCommonEvents(event,this.skillInfo)

				local result3,result4 = this:checkIsAttackEvent(event2)
				if result3 then
					this:dealWithAttackEvent(event2,result4)
				end
			end
			effectSpineNode2:registerSpineEventHandler(eventCallback2,sp.EventType.ANIMATION_EVENT)
			RemoveEffectOnComplete(effectSpineNode2)
		end		
	end

	effectSpineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
	RemoveEffectOnComplete(effectSpineNode)
end

--生成受影响的entity列表。两种Target类型的技能会用到。

--判定：
--target_type 1.自己。2.按条件从我方选择。3.按条件从敌方选择
--target_num 作用数量。0，表示全体。
--target_property 0.距离 1.血量 2.防御 3.攻击 4.随机
--target_p_type 0和1一样都是指选取目标所在的位置（范围攻击，使用hit_rect）。 3.选取目标(注意：如果不是target_type为1或者target_num为0的情况，优先判定这个，这个牵扯到场景或者飞行特效是在固定位置还是目标身上播放)
--sort_type 排序方式。0升序 1降序
function StateBase:generateEffectedListForTargetSkill()
	local result = {}
	local tempResult = {}

	--先检测嘲讽。嘲讽只对目标类的单体技能有效
	if self.skillInfo.target_type == 3 and self.skillInfo.target_num == 1 then
		local entityWithTaunt = self.entity:checkTaunt()
		if entityWithTaunt then
			table.insert(result,entityWithTaunt)
			return result
		end
	end

	--选取目标
	if self.skillInfo.target_type == 1 then
		table.insert(result,self.entity)
		return result
	end	
	local potentialList
	if self.skillInfo.target_type == 2 then
		potentialList = self.entity.teammateList
	else
		potentialList = self.entity.enemyList
	end

	--我方或者敌方全体
	if self.skillInfo.target_num == 0 then
		for k,v in ipairs(potentialList) do
			if not v.isDead then
				table.insert(result,v)
			end
		end
		return result
	end

	--根据target_property和sort_type选择
	for k,v in pairs(potentialList) do
		if not v.isDead then
			local data = {}
			data.entity = v
			--通过距离排序，选target_num个
			if self.skillInfo.target_property == 0 then
				data.value = math.abs(v:getPositionX()-self.entity:getPositionX()) + math.abs(v:getPositionY() - self.entity:getPositionY())
			--通过血量排序，选target_num个
			elseif self.skillInfo.target_property == 1 then
				data.value = v.attr[AE.hp]/v.attr[AE.hp_max]
			--通过防御排序，选target_num个
			elseif self.skillInfo.target_property == 2 then
				data.value = v.attr[AE.defence]
			--通过攻击排序，选target_num个
			elseif self.skillInfo.target_property == 3 then
				data.value = v.attr[AE.attack]
			--随机取target_num个。			
			else
				data.value = GetRandomBetweenAB(1,100)
			end
			table.insert(tempResult,data)
		end
	end

	local this = self
	table.sort(tempResult,function (a,b)
		if this.skillInfo.sort_type == 0 then
			return a.value < b.value
		else
			return a.value > b.value
		end
	end)

	for i = 1,self.skillInfo.target_num do
		if tempResult[i] ~= nil then
			table.insert(result,tempResult[i].entity)
		end
	end

	return result
end

--根据skill_attack_hit信息生成受攻击的entity列表。所有技能状态都会用到。
--@rect_attacker :攻击者的rect,可能是基于特效的位置，可能是基于角色自身的位置。
function StateBase:generateAttackedList(rect_attacker,pos,skillInfo,hitData)
	local attackedList = {}
	local tempList = {}
	local targetList = {}

	local hit_num = hitData.hit_num

	if skillInfo.isPrincess then
		if hitData.hit_type == 1 then
			targetList = G_Roles
		else
			targetList = G_Monsters
		end
	else
		if hitData.hit_type == 1 then
			targetList = self.entity.teammateList
		else
			targetList = self.entity.enemyList
		end
	end

	--正常情况的处理
	local hit_rect_x,hit_rect_y,hit_rect_w,hit_rect_h
	local enemyX,enemyY,enemyLocalRect,enemyRect,disX,disY,dis

	for k,v in pairs(targetList) do
		if not v.isDead then
			enemyLocalRect = v:getTouchRect()
			enemyX,enemyY = v:getPosition()
			hit_rect_x = enemyLocalRect[1] + enemyX
			hit_rect_y = enemyLocalRect[2] + enemyY
			hit_rect_w = enemyLocalRect[3]
			hit_rect_h = enemyLocalRect[4]
			enemyRect = cc.rect(hit_rect_x, hit_rect_y, hit_rect_w, hit_rect_h)
			if cc.rectIntersectsRect(rect_attacker,enemyRect) then--检测两个矩形是否相交
				if hit_num == 100 then
					table.insert(attackedList,v)
				else
					local data = {}
					disX = enemyX - pos.x
					disY = enemyY - pos.y
					dis = disX*disX + disY*disY
					data.entity = v
					data.dis = dis
					table.insert(tempList,data) 
				end
			end
		end
	end

	if hit_num == 100 then
		return attackedList
	else
		table.sort(tempList,function(a,b)
			return a.dis<b.dis
		end)

		for i = 1,hit_num do
			if tempList[i] ~= nil then
				table.insert(attackedList,tempList[i].entity)
			end
		end
		return attackedList
	end
end

--修正一下位置，直接修正到当前格子中心点。
function StateBase:correctPosImmediately()
end

--修正一下位置，跑动到附近可用格子的中心点
function StateBase:correctPosWithRunning()
	--如果当前格子可用，修正到格子中心
	self.entity.box_w,self.entity.box_h = GetBoxWHByPoint(self.entity:getPositionX(),self.entity:getPositionY())

	if self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h) then
		--切换到RunningToPosition状态，移动到当前格子的中心
		local data = {}
		data.type = 2
		data.w = self.entity.box_w
		data.h = self.entity.box_h
		self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
	--当前格子如果被队友或者敌人占了，修正位置到附近的格子
	else
		--玩家角色优先向后走，然后向上向下走，怪物优先向上向下，然后向后走

		--玩家角色
		if self.entity.entityType == 1 then
			for i = 1,3 do
				if self.entity.box_w - i > 0 and self.entity:checkBoxAvailableByWH(self.entity.box_w - i,self.entity.box_h) then
					local data = {}
					data.type = 2
					data.w = self.entity.box_w-i
					data.h = self.entity.box_h
					self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
					return
				end
			end

			if self.entity.box_h + 1 <= 2 and self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h + 1) then
				local data = {}
				data.type = 2
				data.w = self.entity.box_w
				data.h = self.entity.box_h + 1
				self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
				return
			end

			if self.entity.box_h - 1 >= 0 and self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h - 1) then
				local data = {}
				data.type = 2
				data.w = self.entity.box_w
				data.h = self.entity.box_h - 1
				self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
				return
			end

			for i = 4,10 do
				if self.entity.box_w - i > 0 and self.entity:checkBoxAvailableByWH(self.entity.box_w - i,self.entity.box_h) then
					local data = {}
					data.type = 2
					data.w = self.entity.box_w-i
					data.h = self.entity.box_h
					self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
					return
				end
			end
		--怪物
		else
			if self.entity.box_h + 1 <= 2 and self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h + 1) then
				local data = {}
				data.w = self.entity.box_w
				data.h = self.entity.box_h + 1
				self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
				return
			end

			if self.entity.box_h - 1 >= 0 and self.entity:checkBoxAvailableByWH(self.entity.box_w,self.entity.box_h - 1) then
				local data = {}
				data.w = self.entity.box_w
				data.h = self.entity.box_h - 1
				self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
				return
			end

			for i = 1,10 do
				if self.entity:checkBoxAvailableByWH(self.entity.box_w + i,self.entity.box_h) then
					local data = {}
					data.w = self.entity.box_w + i
					data.h = self.entity.box_h
					self.entity.fsm:changeState(StateEnum.RunningToPosition,data)
					return
				end
			end
		end
		--如果哪都去不了则原地idle，这种情况发生概率为0
		self.entity.fsm:changeState(StateEnum.Idling)
	end	
end

--伤害计算相关

--造成伤害
--@type 1.技能。2.神格技能  3.普通攻击。 
--@skillData :如果是普通攻击，传attackData。
--@event :可能为空，例如普通远程攻击不需要event
function StateBase:onCauseDamage(type,attacker,defender,event,skillData,idx)
	if attacker.isDead or defender.FuHuoWuDi then
		return
	end

	--根据hit_type判断是治疗还是伤害还是加buffdebuff
	local hitData
	if type == 3 then
		hitData = skillData.skill_hit[idx]  --只是个百分比的数字
	else
		hitData = skillData.skill_attack_hit[idx]
	end

	--治疗。必定命中
	if type ~= 3 and hitData.hit_type == 1 then
		self:onCauseDamage_HitType1(type,attacker,defender,event,skillData,hitData)
		return
	--buff，debuff。
	elseif type ~= 3 and hitData.hit_type == 2 then
		self:onCauseDamage_HitType2(type,attacker,defender,event,skillData,hitData)
		return
	else
		--普通攻击或者造成伤害的技能攻击
		self:onCauseDamage_HitType0(type,attacker,defender,event,skillData,hitData)
	end
end

--造成伤害的情况
function StateBase:onCauseDamage_HitType0(type,attacker,defender,event,skillData,hitData)
	if attacker.isDead then
		return
	end

	--击中特效和神格数值累计
	if type == 3 then
		self:playHitEffect()
		--公主技能统计，我方普攻时
		if BattleDataManager.hasPrincess and attacker.entityType == 1 then
			BattleUIManager:setSP(10,true)
		end
		--累加普攻攻击次数.2019.1.28.
		self.entity.attr[AE.totalnum_atk] = self.entity.attr[AE.totalnum_atk] + 1
	else
		self:playHitEffect(defender,hitData.res_hit)
	end

	--伤害类型。这里的dmgType不可能是固定伤害。
	--0.普通伤害  1.治疗  4.真实伤害  5.贯穿伤害  6.真实贯穿。其中5和6无视次数护盾。
	local dmgType = BattleDamageCompute:getDmgType(type,skillData,hitData)	

	--是否免疫
	local isImmune = false
	if defender.componentManager:checkIsWuDi() and dmgType ~= 5 and dmgType ~= 6 then
		isImmune = true
	end
	--是否命中
	local isRoquet = BattleDamageCompute:isRoquet(attacker,defender)

	--检测次数护盾
	local numShieldCom = defender.componentManager:getComById(81032)
	local isNumShield
	if numShieldCom and not isImmune and isRoquet and dmgType ~= 5 and dmgType ~= 6 then
		isNumShield = true
	end

	--是否暴击
	local isCrit = BattleDamageCompute:isCrit(type,attacker,defender,skillData)

	--各种触发器
	local option = {}
	local dmg--填规则坑：虽然是伤害前，但是还是需要先计算伤害，例如根据伤害吸血等效果要用。
	if isImmune or not isRoquet or isNumShield then
		dmg = 0
		option.isCrit = false
	else
		dmg = BattleDamageCompute:computeDamage(type,attacker,defender,skillData,hitData,isCrit,dmgType)
		option.isCrit = isCrit
	end

	option.affectedEntity = defender
	option.dmg = dmg

	--技能相关触发器
	if type == 1 then
		--触发时机16.配在主动技能里的技能伤害前
		for k1,v1 in pairs(hitData.add_buff) do
			if TriggerChecker:check(16,v1,attacker,option) then
				for k2,v2 in pairs(v1.skill_trig_effect) do
					ComponentCreator:createComponent(v2,attacker,option)
				end
			end
		end

		--触发时机2.配在被动技能里的技能伤害后。用于检测是否有附加固定伤害或者是否暴击。
		attacker.triggerManager:check(2,option)
		--触发时机102.用于检测队友技能是否暴击
		attacker.teamManager:checkTeamTrigger(102,self.entity,option)
	--神格技能相关触发器。			
	elseif type == 2 then
		--触发时机9。
		for k1,v1 in pairs(hitData.add_buff) do
			if TriggerChecker:check(9,v1,nil,option) then
				for k2,v2 in pairs(v1.skill_trig_effect) do
					ComponentCreator:createComponent(v2,nil,option)
				end
			end
		end
	--普攻相关触发器
	elseif type == 3 then
		--触发时机1.普攻造成伤害后。注：因为普通一定是单体攻击，所以可以放在这里，否则要放在攻击状态类里。
		attacker.triggerManager:check(1,option)	
	else
		print("出错了...onCauseDamage_HitType0")
		return		
	end

	--是否免疫
	if isImmune then
		--飘字，"免疫"
		BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Immune)
		return
	end

	--连击数，被闪避后不统计连击数
	if type ~= 2 and attacker.entityType == 1 then
		BattleUIManager:addHit()
	end

	--是否命中。
	if not isRoquet then
		--未命中的飘字
		BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Miss)
		return
	end
	
	--次数护盾
	if isNumShield then
		numShieldCom:onLoseOneOverlay()
		--吸收的飘字
		BattleDamageDisplay:create(defender:getDamageShowingPos(true),-1,DamageFontType.Absorb)
	end 

	--累计受到伤害的次数
	defender.attr[AE.totalnum_atked] = defender.attr[AE.totalnum_atked] + 1

	--击飞，击倒等。
	if event ~= nil then
		if self:dealWithUnsualCondition(type,attacker,defender,event) then
			--do nothing
		else
			--如果是小怪，播放受攻动作。
			if defender.entityType == 2 and not defender.isBoss then
				if defender.isDead then
					return
				end
				if defender.fsm.currentState:checkCanChangeToUnusualState(5) then
					local data = {}
					data.stateType = 5;
					defender.fsm:changeState(StateEnum.UnusualCondition,data)		
				end
			end
		end
	end

	--触发时机104。全队受击时(伤害计算后)
	defender.teamManager:checkTeamTrigger(104,defender,option)

	--触发时机4。受击时(伤害计算后)
	option.trig_time = 4
	option.affectedEntity = attacker
	option.attacker = attacker --处理反弹的时候用
	option.defender = defender --处理反弹的时候用
	defender.triggerManager:check(4,option)	

	--公主技能统计，我方受击时
	if BattleDataManager.hasPrincess and defender.entityType == 1 then
		BattleUIManager:setSP(math.floor(dmg * 100/defender.attr[AE.hp_max]),true)
	end
end

--治疗的情况
--注：治疗类没有暴击
function StateBase:onCauseDamage_HitType1(type,attacker,defender,event,skillData,hitData)	
	--如果此时被治疗者身上有恶鬼缠刃的buff，最终加血值为0
	if defender.componentManager.EGuiChanRen then
		BattleDamageDisplay:create(defender:getDamageShowingPos(true), 0,DamageFontType.AddHP)
		return
	end

	--注：不存在多人战boss给自己加血的情况，所以不需要同步。
	local dmg = BattleDamageCompute:computeDamage(type,attacker,defender,skillData,hitData,false,1)
	defender.attributeManager:changeAttr(AE.hp,dmg)

	--加血特效。
	self:playHitEffect(defender,hitData.res_hit)

	--飘字
	BattleDamageDisplay:create(defender:getDamageShowingPos(true), dmg,DamageFontType.AddHP)

	local option = {}

	if attacker.isPrincess then
		--触发时机9。
		for k1,v1 in pairs(hitData.add_buff) do
			if TriggerChecker:check(9,v1,nil,option) then
				for k2,v2 in pairs(v1.skill_trig_effect) do
					ComponentCreator:createComponent(v2,nil,option)
				end
			end
		end
	else
		option.isCrit = false
		option.affectedEntity = defender
		option.attacker = attacker --TODO,修复中毒的bug临时添加，以后再整理
		--触发时机16.
		for k1,v1 in pairs(hitData.add_buff) do
			if TriggerChecker:check(16,v1,attacker,option) then
				for k2,v2 in pairs(v1.skill_trig_effect) do
					ComponentCreator:createComponent(v2,attacker,option)
				end
			end
		end
	end

	--触发时机5.受治疗时
	option = {}
	option.isCrit = false
	option.affectedEntity = attacker
	defender.triggerManager:check(5,option)
end

--加buff、debuff或者直接生效的情况
function StateBase:onCauseDamage_HitType2(type,attacker,defender,event,skillData,hitData)
	local option = {}
	option.affectedEntity = defender
	
	--触发时机16.
	for k1,v1 in pairs(hitData.add_buff) do
		if TriggerChecker:check(16,v1,attacker,option) then
			for k2,v2 in pairs(v1.skill_trig_effect) do
				ComponentCreator:createComponent(v2,attacker,option)
			end
		end
	end	
end
