
--------------------------------
-- @module PassData
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PassData] getCMD 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#PassData] getData 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#PassData] PassData 
-- @param self
-- @param #string data
-- @param #int cmd
        
return nil
