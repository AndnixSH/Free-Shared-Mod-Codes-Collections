princess_mainpage = {}
princess_mainpage[1] = {
    bn_name = "134111",
    bn_icon = "icons/role/list/lb_r_001.png",
    bn_des = "134201",
    spinepath = "effects/Nvzhu/NvZhu.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
        "action5",
        "action6",
        "action7",
    },
    login_voice={ "music/ui/banniang/1.mp3","music/ui/banniang/2.mp3","music/ui/banniang/3.mp3",
    },
    battle_voice = "music/ui/banniang/3.mp3",
    touch = {   
        {
            paneldesc = { x = 10,y = 340,width = 300,height = 400 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "action2",
                "action3",
                "action4",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action1",   --有新的多人战
        NewMail = "action13",  --新邮件
        SkillPoint = "action8",  --新技能点
        LoginGift = "action10",  --登录奖励
        AchiGift = "action11",  --成就奖励
        DDBattle = "action9",  --黑潮遗迹解锁
        GetAP = "action12",  --获取体力
        Forge = "action15",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = "music/ui/banniang/14.mp3",
        action2 = "music/ui/banniang/7.mp3",
        action3 = "music/ui/banniang/9.mp3",
        action4 = "music/ui/banniang/8.mp3",
        action5 = "music/ui/banniang/6.mp3",
        action6 = "music/ui/banniang/5.mp3",
        action7 = "music/ui/banniang/4.mp3",
        action8 = "music/ui/banniang/13.mp3",
        action9 = "music/ui/banniang/10.mp3",
        action10 = "music/ui/banniang/12.mp3",
        action13 = "music/ui/banniang/11.mp3",
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 1,  --板娘类型编码
    origin_x = 0,
    origin_y = 0,
    scaling = 1.0,  --缩放比例
    likefeeling_id =0,  --共鸣绑定ID,
    hero_id = 0,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/14.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/7.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/9.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/8.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/6.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/5.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/4.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/13.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/10.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/12.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/11.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="",
            dialog = {},
        },
    }
} 
princess_mainpage[2] = {
    bn_name = "134112",
    bn_icon = "icons/role/list/lb_r_451.png",
    bn_des = "134199",
    spinepath = "effects/AiJiang/AiJiang.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
        "loading2",
        "action5",
        "action6",
    },
    login_voice={ "music/ui/signboradgirl2/login2.mp3","music/ui/signboradgirl2/g2ready.mp3",
    },
    battle_voice = "music/ui/signboradgirl2/g2ready.mp3",
    touch = {   
        {
            paneldesc = { x = 11,y = 440,width = 160,height = 160 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "action2",
            }
        },
        {
            paneldesc = { x = 11,y = 275,width = 155,height = 95 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "action3",
                "action7",
            }
        },
        {
            paneldesc = { x = 11,y = 140,width = 200,height = 140 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "action4",
                "action16",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action1",   --有新的多人战
        NewMail = "action13",  --新邮件
        SkillPoint = "action8",  --新技能点
        LoginGift = "action10",  --登录奖励
        AchiGift = "action11",  --成就奖励
        DDBattle = "action9",  --黑潮遗迹解锁
        GetAP = "action12",  --获取体力
        Forge = "action15",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = "music/ui/signboradgirl2/g2action1.mp3",
        action2 = "music/ui/signboradgirl2/g2action2.mp3",
        action3 = "music/ui/signboradgirl2/g2action3.mp3",
        action4 = "music/ui/signboradgirl2/g2action4.mp3",
        action5 = "music/ui/signboradgirl2/g2action5.mp3",
        action6 = "music/ui/signboradgirl2/g2action6.mp3",
        action7 = "music/ui/signboradgirl2/g2action7.mp3",
        action8 = "music/ui/signboradgirl2/g2action8.mp3",
        action10 = "music/ui/signboradgirl2/gift2.mp3",
        action11 = "music/ui/signboradgirl2/gift2.mp3",
        action12 = "music/ui/signboradgirl2/gift2.mp3",
        action13 = "music/ui/signboradgirl2/message2.mp3",
        action16 = "music/ui/signboradgirl2/g2action16.mp3",
        action17 = "music/ui/signboradgirl2/g2action17.mp3",
        action18 = "music/ui/signboradgirl2/g2action18.mp3",
        action19 = "music/ui/signboradgirl2/g2action19.mp3",
        action20 = "music/ui/signboradgirl2/g2action20.mp3",
        action21 = "music/ui/signboradgirl2/g2action21.mp3",
        action22 = "music/ui/signboradgirl2/g2action22.mp3",
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 1,  --板娘类型编码
    origin_x = 0,
    origin_y = 0,
    scaling = 1.0,  --缩放比例
    likefeeling_id =451,  --共鸣绑定ID,
    hero_id = 451,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action1.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action2.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action3.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action4.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action5.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action6.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action7.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action8.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/gift2.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/gift2.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/gift2.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/message2.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action16.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action17.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action18.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action19.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action20.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action21.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl2/g2action22.mp3",
            dialog = "135282",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="",
            dialog = {},
        },
    }
} 
princess_mainpage[3] = {
    bn_name = "134113",
    bn_icon = "icons/role/list/bn_r_001.png",
    bn_des = "134200",
    spinepath = "effects/Aixia_Shengdan/AiXia_ShengDan.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
        "loading2",
        "action5",
        "action6",
        "action7",
    },
    login_voice={ "music/ui/banniang/1.mp3","music/ui/banniang/2.mp3","music/ui/banniang/3.mp3",
    },
    battle_voice = "music/ui/banniang/3.mp3",
    touch = {   
        {
            paneldesc = { x = 10,y = 340,width = 300,height = 400 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "action2",
                "action3",
                "action4",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action1",   --有新的多人战
        NewMail = "action13",  --新邮件
        SkillPoint = "action8",  --新技能点
        LoginGift = "action10",  --登录奖励
        AchiGift = "action11",  --成就奖励
        DDBattle = "action9",  --黑潮遗迹解锁
        GetAP = "action12",  --获取体力
        Forge = "action15",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = "music/ui/banniang/14.mp3",
        action2 = "music/ui/banniang/7.mp3",
        action3 = "music/ui/banniang/9.mp3",
        action4 = "music/ui/banniang/8.mp3",
        action5 = "music/ui/banniang/6.mp3",
        action6 = "music/ui/banniang/5.mp3",
        action7 = "music/ui/banniang/4.mp3",
        action8 = "music/ui/banniang/13.mp3",
        action9 = "music/ui/banniang/10.mp3",
        action10 = "music/ui/banniang/12.mp3",
        action13 = "music/ui/banniang/11.mp3",
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 1,  --板娘类型编码
    origin_x = 0,
    origin_y = 90,
    scaling = 0.868,  --缩放比例
    likefeeling_id =0,  --共鸣绑定ID,
    hero_id = 0,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/14.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/7.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/9.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/8.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/6.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/5.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/4.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/13.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/10.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/12.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/banniang/11.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="",
            dialog = {},
        },
    }
} 
princess_mainpage[4] = {
    bn_name = "134114",
    bn_icon = "icons/role/list/bn_r_412.png",
    bn_des = "134201",
    spinepath = "effects/Youna/YouNa.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
        "loading2",
        "action5",
        "action6",
        "action7",
    },
    login_voice={ "music/ui/banniang4/g4action4","music/ui/signboradgirl4/g4action10.mp3",
    },
    battle_voice = "music/ui/signboradgirl4/g4action10.mp3",
    touch = {   
        {
            paneldesc = { x = 1,y = 240,width = 250,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "action2",
                "action3",
                "action4",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action1",   --有新的多人战
        NewMail = "action13",  --新邮件
        SkillPoint = "action8",  --新技能点
        LoginGift = "action10",  --登录奖励
        AchiGift = "action11",  --成就奖励
        DDBattle = "action9",  --黑潮遗迹解锁
        GetAP = "action12",  --获取体力
        Forge = "action15",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = "music/ui/signboradgirl4/g4action1.mp3",
        action2 = "music/ui/signboradgirl4/g4action2.mp3",
        action3 = "music/ui/signboradgirl4/g4action3.mp3",
        action4 = "music/ui/signboradgirl4/g4action4.mp3",
        action5 = "music/ui/signboradgirl4/g4action5.mp3",
        action6 = "music/ui/signboradgirl4/g4action6.mp3",
        action7 = "music/ui/signboradgirl4/g4action7.mp3",
        action8 = "music/ui/signboradgirl4/g4action8.mp3",
        action13 = "music/ui/signboradgirl4/g4action13.mp3",
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 1,  --板娘类型编码
    origin_x = 0,
    origin_y = 0,
    scaling = 1.0,  --缩放比例
    likefeeling_id =412,  --共鸣绑定ID,
    hero_id = 412,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
        "135282",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action1.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action2.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action3.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action4.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action5.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action6.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action7.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action8.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl4/g4action13.mp3",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="",
            dialog = {},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="",
            dialog = {},
        },
    }
} 
princess_mainpage[1011] = {
    bn_name = "134115",
    bn_icon = "icons/role/list/lb_r_011.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_011.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =11,  --共鸣绑定ID,
    hero_id = 11,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134203",
        "134204",
        "134205",
        "134206",
        "134207",
        "134208",
        "134209",
        "134210",
        "134211",
        "134212",
        "134213",
        "134214",
        "134215",
        "134216",
        "134217",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134203",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134204",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134205",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134206",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134207",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134208",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134209",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134210",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134211",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134212",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134213",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134214",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134215",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134216",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134217",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1011",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1011",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1011",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1011",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1013] = {
    bn_name = "134116",
    bn_icon = "icons/role/list/lb_r_013.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_013.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =13,  --共鸣绑定ID,
    hero_id = 13,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134218",
        "134219",
        "134220",
        "134221",
        "134222",
        "134223",
        "134224",
        "134225",
        "134226",
        "134227",
        "134228",
        "134229",
        "134230",
        "134231",
        "134232",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134218",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134219",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134220",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134221",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134222",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134223",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134224",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134225",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134226",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134227",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134228",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134229",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134230",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134231",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134232",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1013",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1013",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1013",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1013",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1023] = {
    bn_name = "134117",
    bn_icon = "icons/role/list/lb_r_023.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_023.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =23,  --共鸣绑定ID,
    hero_id = 23,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134233",
        "134234",
        "134235",
        "134236",
        "134237",
        "134238",
        "134239",
        "134240",
        "134241",
        "134242",
        "134243",
        "134244",
        "134245",
        "134246",
        "134247",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134233",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134234",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134235",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134236",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134237",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134238",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134239",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134240",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134241",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134242",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134243",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134244",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134245",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134246",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134247",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1023",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1023",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1023",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1023",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1024] = {
    bn_name = "134118",
    bn_icon = "icons/role/list/lb_r_024.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_024.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =24,  --共鸣绑定ID,
    hero_id = 24,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134248",
        "134249",
        "134250",
        "134251",
        "134252",
        "134253",
        "134254",
        "134255",
        "134256",
        "134257",
        "134258",
        "134259",
        "134260",
        "134261",
        "134262",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134248",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134249",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134250",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134251",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134252",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134253",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134254",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134255",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134256",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134257",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134258",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134259",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134260",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134261",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134262",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1024",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1024",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1024",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1024",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1036] = {
    bn_name = "134119",
    bn_icon = "icons/role/list/lb_r_036.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_036.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =36,  --共鸣绑定ID,
    hero_id = 36,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134263",
        "134264",
        "134265",
        "134266",
        "134267",
        "134268",
        "134269",
        "134270",
        "134271",
        "134272",
        "134273",
        "134274",
        "134275",
        "134276",
        "134277",
        "134278",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134263",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134264",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134265",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134266",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134267",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134268",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134269",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134270",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134271",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134272",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134273",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134274",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134275",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134276",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134277",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134278",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1036",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1036",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1036",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1036",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1037] = {
    bn_name = "134120",
    bn_icon = "icons/role/list/lb_r_037.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_037.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =37,  --共鸣绑定ID,
    hero_id = 37,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134279",
        "134280",
        "134281",
        "134282",
        "134283",
        "134284",
        "134285",
        "134286",
        "134287",
        "134288",
        "134289",
        "134290",
        "134291",
        "134292",
        "134293",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134279",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134280",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134281",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134283",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134284",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134285",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134286",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134287",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134288",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134289",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134290",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134291",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134292",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134293",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1037",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1037",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1037",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1037",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1051] = {
    bn_name = "134121",
    bn_icon = "icons/role/list/lb_r_051.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_051.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =51,  --共鸣绑定ID,
    hero_id = 51,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134294",
        "134295",
        "134296",
        "134297",
        "134298",
        "134299",
        "134300",
        "134301",
        "134302",
        "134303",
        "134304",
        "134305",
        "134306",
        "134307",
        "134308",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134294",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134295",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134296",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134297",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134298",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134299",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134300",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134301",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134302",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134303",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134304",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134305",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134306",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134307",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134308",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1051",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1051",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1051",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1051",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1061] = {
    bn_name = "134122",
    bn_icon = "icons/role/list/lb_r_061.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_061.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =61,  --共鸣绑定ID,
    hero_id = 61,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134309",
        "134310",
        "134311",
        "134312",
        "134313",
        "134314",
        "134315",
        "134316",
        "134317",
        "134318",
        "134319",
        "134320",
        "134321",
        "134322",
        "134323",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134309",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134310",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134311",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134312",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134313",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134314",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134315",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134316",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134317",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134318",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134319",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134320",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134321",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134322",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134323",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1061",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1061",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1061",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1061",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1062] = {
    bn_name = "134123",
    bn_icon = "icons/role/list/lb_r_062.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_062.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =62,  --共鸣绑定ID,
    hero_id = 62,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134324",
        "134325",
        "134326",
        "134327",
        "134328",
        "134329",
        "134330",
        "134331",
        "134332",
        "134333",
        "134334",
        "134335",
        "134336",
        "134337",
        "134338",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134324",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134325",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134326",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134327",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134328",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134329",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134330",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134331",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134332",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134333",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134334",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134335",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134336",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134337",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134338",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1062",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1062",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1062",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1062",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1076] = {
    bn_name = "134124",
    bn_icon = "icons/role/list/lb_r_076.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_076.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =76,  --共鸣绑定ID,
    hero_id = 76,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134339",
        "134340",
        "134341",
        "134342",
        "134343",
        "134344",
        "134345",
        "134346",
        "134347",
        "134348",
        "134349",
        "134350",
        "134351",
        "134352",
        "134353",
        "134354",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134339",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134340",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134341",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134342",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134343",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134344",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134345",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134346",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134347",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134348",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134349",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134350",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134351",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134352",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134353",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134354",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1076",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1076",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1076",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1076",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1101] = {
    bn_name = "134125",
    bn_icon = "icons/role/list/lb_r_101.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_101.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =101,  --共鸣绑定ID,
    hero_id = 101,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134355",
        "134356",
        "134357",
        "134358",
        "134359",
        "134360",
        "134361",
        "134362",
        "134363",
        "134364",
        "134365",
        "134366",
        "134367",
        "134368",
        "134369",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134355",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134356",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134357",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134358",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134359",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134360",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134361",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134362",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134363",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134364",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134365",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134366",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134367",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134368",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134369",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1101",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1101",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1101",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1101",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1103] = {
    bn_name = "134126",
    bn_icon = "icons/role/list/lb_r_103.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_103.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =103,  --共鸣绑定ID,
    hero_id = 103,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134370",
        "134371",
        "134372",
        "134373",
        "134374",
        "134375",
        "134376",
        "134377",
        "134378",
        "134379",
        "134380",
        "134381",
        "134382",
        "134383",
        "134384",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134370",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134371",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134372",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134373",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134374",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134375",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134376",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134377",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134378",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134379",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134380",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134381",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134382",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134383",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134384",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1103",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1103",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1103",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1103",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1116] = {
    bn_name = "134127",
    bn_icon = "icons/role/list/lb_r_116.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_116.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =116,  --共鸣绑定ID,
    hero_id = 116,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134385",
        "134386",
        "134387",
        "134388",
        "134389",
        "134390",
        "134391",
        "134392",
        "134393",
        "134394",
        "134395",
        "134396",
        "134397",
        "134398",
        "134399",
        "134400",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134385",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134386",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134387",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134388",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134389",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134390",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134391",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134392",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134393",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134394",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134395",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134396",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134397",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134398",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134399",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134400",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1116",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1116",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1116",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1116",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1117] = {
    bn_name = "134128",
    bn_icon = "icons/role/list/lb_r_117.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_117.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =117,  --共鸣绑定ID,
    hero_id = 117,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134401",
        "134402",
        "134403",
        "134404",
        "134405",
        "134406",
        "134407",
        "134408",
        "134409",
        "134410",
        "134411",
        "134412",
        "134413",
        "134414",
        "134415",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134401",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134402",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134403",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134404",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134405",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134406",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134407",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134408",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134409",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134410",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134411",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134412",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134413",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134414",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134415",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1117",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1117",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1117",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1117",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1142] = {
    bn_name = "134129",
    bn_icon = "icons/role/list/lb_r_142.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_142.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =142,  --共鸣绑定ID,
    hero_id = 142,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134416",
        "134417",
        "134418",
        "134419",
        "134420",
        "134421",
        "134422",
        "134423",
        "134424",
        "134425",
        "134426",
        "134427",
        "134428",
        "134429",
        "134430",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134416",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134417",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134418",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134419",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134420",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134421",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134422",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134423",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134424",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134425",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134426",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134427",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134428",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134429",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134430",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1142",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1142",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1142",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1142",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1156] = {
    bn_name = "134130",
    bn_icon = "icons/role/list/lb_r_156.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_156.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =156,  --共鸣绑定ID,
    hero_id = 156,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134431",
        "134432",
        "134433",
        "134434",
        "134435",
        "134436",
        "134437",
        "134438",
        "134439",
        "134440",
        "134441",
        "134442",
        "134443",
        "134444",
        "134445",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134431",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134432",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134433",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134434",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134435",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134436",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134437",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134438",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134439",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134440",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134441",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134442",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134443",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134444",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134445",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1156",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1156",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1156",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1156",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1157] = {
    bn_name = "134131",
    bn_icon = "icons/role/list/lb_r_157.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_157.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =157,  --共鸣绑定ID,
    hero_id = 157,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134446",
        "134447",
        "134448",
        "134449",
        "134450",
        "134451",
        "134452",
        "134453",
        "134454",
        "134455",
        "134456",
        "134457",
        "134458",
        "134459",
        "134460",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134446",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134447",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134448",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134449",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134450",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134451",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134452",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134453",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134454",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134455",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134456",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134457",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134458",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134459",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134460",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1157",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1157",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1157",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1157",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1181] = {
    bn_name = "134132",
    bn_icon = "icons/role/list/lb_r_181.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_181.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =181,  --共鸣绑定ID,
    hero_id = 181,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134461",
        "134462",
        "134463",
        "134464",
        "134465",
        "134466",
        "134467",
        "134468",
        "134469",
        "134470",
        "134471",
        "134472",
        "134473",
        "134474",
        "134475",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134461",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134462",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134463",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134464",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134465",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134466",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134467",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134468",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134469",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134470",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134471",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134472",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134473",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134474",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134475",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1181",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1181",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1181",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1181",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1182] = {
    bn_name = "134133",
    bn_icon = "icons/role/list/lb_r_182.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_182.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 383,
    scaling = 0.8,  --缩放比例
    likefeeling_id =182,  --共鸣绑定ID,
    hero_id = 182,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134476",
        "134477",
        "134478",
        "134479",
        "134480",
        "134481",
        "134482",
        "134483",
        "134484",
        "134485",
        "134486",
        "134487",
        "134488",
        "134489",
        "134490",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134476",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134477",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134478",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134479",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134480",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134481",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134482",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134483",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134484",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134485",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134486",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134487",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134488",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134489",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134490",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1182",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1182",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1182",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1182",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1183] = {
    bn_name = "134134",
    bn_icon = "icons/role/list/lb_r_183.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_183.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =183,  --共鸣绑定ID,
    hero_id = 183,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134491",
        "134492",
        "134493",
        "134494",
        "134495",
        "134496",
        "134497",
        "134498",
        "134499",
        "134500",
        "134501",
        "134502",
        "134503",
        "134504",
        "134505",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134491",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134492",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134493",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134494",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134495",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134496",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134497",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134498",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134499",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134500",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134501",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134502",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134503",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134504",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134505",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1183",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1183",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1183",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1183",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1184] = {
    bn_name = "134135",
    bn_icon = "icons/role/list/lb_r_184.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_184.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =184,  --共鸣绑定ID,
    hero_id = 184,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134506",
        "134507",
        "134508",
        "134509",
        "134510",
        "134511",
        "134512",
        "134513",
        "134514",
        "134515",
        "134516",
        "134517",
        "134518",
        "134519",
        "134520",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134506",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134507",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134508",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134509",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134510",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134511",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134512",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134513",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134514",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134515",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134516",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134517",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134518",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134519",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134520",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1184",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1184",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1184",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1184",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1196] = {
    bn_name = "134136",
    bn_icon = "icons/role/list/lb_r_196.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_196.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action14",  --铸造完成
        Explore = "action15",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =196,  --共鸣绑定ID,
    hero_id = 196,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134521",
        "134522",
        "134523",
        "134524",
        "134525",
        "134526",
        "134527",
        "134528",
        "134529",
        "134530",
        "134531",
        "134532",
        "134533",
        "134534",
        "134535",
        "134536",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134521",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134522",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134523",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134524",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134525",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134526",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134527",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134528",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134529",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134530",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134531",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134532",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134533",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134534",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134535",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134536",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1196",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1196",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1196",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1196",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1305] = {
    bn_name = "134137",
    bn_icon = "icons/role/list/lb_r_305.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_305.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action15",  --铸造完成
        Explore = "action1",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =305,  --共鸣绑定ID,
    hero_id = 305,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134537",
        "134538",
        "134539",
        "134540",
        "134541",
        "134542",
        "134543",
        "134544",
        "134545",
        "134546",
        "134547",
        "134548",
        "134549",
        "134550",
        "134551",
        "134552",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134537",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134538",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134539",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134540",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134541",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134542",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134543",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134544",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134545",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134546",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134547",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134548",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134549",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134550",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134551",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134552",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1305",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1305",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1305",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1305",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1354] = {
    bn_name = "134138",
    bn_icon = "icons/role/list/lb_r_354.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_354.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =354,  --共鸣绑定ID,
    hero_id = 354,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134568",
        "134569",
        "134570",
        "134571",
        "134572",
        "134573",
        "134574",
        "134575",
        "134576",
        "134577",
        "134578",
        "134579",
        "134580",
        "134581",
        "134582",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134568",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134569",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134570",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134571",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134572",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134573",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134574",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134575",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134576",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134577",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134578",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134579",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134580",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134581",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134582",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1354",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1354",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1354",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1354",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1356] = {
    bn_name = "134139",
    bn_icon = "icons/role/list/lb_r_356.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_356.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =356,  --共鸣绑定ID,
    hero_id = 356,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134583",
        "134584",
        "134585",
        "134586",
        "134587",
        "134588",
        "134589",
        "134590",
        "134591",
        "134592",
        "134593",
        "134594",
        "134595",
        "134596",
        "134597",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134583",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134584",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134585",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134586",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134587",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134588",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134589",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134590",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134591",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134592",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134593",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134594",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134595",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134596",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134597",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1356",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1356",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1356",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1356",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1357] = {
    bn_name = "134140",
    bn_icon = "icons/role/list/lb_r_357.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_357.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =357,  --共鸣绑定ID,
    hero_id = 357,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134598",
        "134599",
        "134600",
        "134601",
        "134602",
        "134603",
        "134604",
        "134605",
        "134606",
        "134607",
        "134608",
        "134609",
        "134610",
        "134611",
        "134612",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134598",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134599",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134600",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134601",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134602",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134603",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134604",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134605",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134606",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134607",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134608",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134609",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134610",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134611",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134612",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1357",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1357",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1357",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1357",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1359] = {
    bn_name = "134141",
    bn_icon = "icons/role/list/lb_r_359.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_359.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 1.0,  --缩放比例
    likefeeling_id =359,  --共鸣绑定ID,
    hero_id = 359,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134613",
        "134614",
        "134615",
        "134616",
        "134617",
        "134618",
        "134619",
        "134620",
        "134621",
        "134622",
        "134623",
        "134624",
        "134625",
        "134626",
        "134627",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134613",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134614",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134615",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134616",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134617",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134618",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134619",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134620",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134621",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134622",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134623",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134624",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134625",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134626",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134627",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1359",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1359",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1359",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1359",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1360] = {
    bn_name = "134142",
    bn_icon = "icons/role/list/lb_r_360.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_360.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =360,  --共鸣绑定ID,
    hero_id = 360,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134628",
        "134629",
        "134630",
        "134631",
        "134632",
        "134633",
        "134634",
        "134635",
        "134636",
        "134637",
        "134638",
        "134639",
        "134640",
        "134641",
        "134642",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134628",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134629",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134630",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134631",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134632",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134633",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134634",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134635",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134636",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134637",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134638",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134639",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134640",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134641",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134642",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1360",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1360",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1360",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1360",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1361] = {
    bn_name = "134143",
    bn_icon = "icons/role/list/lb_r_361.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_361.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =361,  --共鸣绑定ID,
    hero_id = 361,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134643",
        "134644",
        "134645",
        "134646",
        "134647",
        "134648",
        "134649",
        "134650",
        "134651",
        "134652",
        "134653",
        "134654",
        "134655",
        "134656",
        "134657",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134643",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134644",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134645",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134646",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134647",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134648",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134649",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134650",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134651",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134652",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134653",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134654",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134655",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134656",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134657",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1361",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1361",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1361",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1361",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1362] = {
    bn_name = "134144",
    bn_icon = "icons/role/list/lb_r_362.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_362.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =362,  --共鸣绑定ID,
    hero_id = 362,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134658",
        "134659",
        "134660",
        "134661",
        "134662",
        "134663",
        "134664",
        "134665",
        "134666",
        "134667",
        "134668",
        "134669",
        "134670",
        "134671",
        "134672",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134658",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134659",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134660",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134661",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134662",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134663",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134664",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134665",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134666",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134667",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134668",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134669",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134670",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134671",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134672",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1362",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1362",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1362",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1362",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1363] = {
    bn_name = "134145",
    bn_icon = "icons/role/list/lb_r_363.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_363.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =363,  --共鸣绑定ID,
    hero_id = 363,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134673",
        "134674",
        "134675",
        "134676",
        "134677",
        "134678",
        "134679",
        "134680",
        "134681",
        "134682",
        "134683",
        "134684",
        "134685",
        "134686",
        "134687",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134673",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134674",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134675",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134676",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134677",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134678",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134679",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134680",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134681",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134682",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134683",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134684",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134685",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134686",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134687",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1363",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1363",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1363",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1363",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1364] = {
    bn_name = "134146",
    bn_icon = "icons/role/list/lb_r_364.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_364.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =364,  --共鸣绑定ID,
    hero_id = 364,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134688",
        "134689",
        "134690",
        "134691",
        "134692",
        "134693",
        "134694",
        "134695",
        "134696",
        "134697",
        "134698",
        "134699",
        "134700",
        "134701",
        "134702",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134688",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134689",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134690",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134691",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134692",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134693",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134694",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134695",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134696",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134697",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134698",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134699",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134700",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134701",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134702",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1364",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1364",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1364",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1364",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1367] = {
    bn_name = "134147",
    bn_icon = "icons/role/list/lb_r_367.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_367.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =367,  --共鸣绑定ID,
    hero_id = 367,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134718",
        "134719",
        "134720",
        "134721",
        "134722",
        "134723",
        "134724",
        "134725",
        "134726",
        "134727",
        "134728",
        "134729",
        "134730",
        "134731",
        "134732",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134718",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134719",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134720",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134721",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134722",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134723",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134724",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134725",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134726",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134727",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134728",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134729",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134730",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134731",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134732",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1367",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1367",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1367",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1367",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1369] = {
    bn_name = "134148",
    bn_icon = "icons/role/list/lb_r_369.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_369.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =369,  --共鸣绑定ID,
    hero_id = 369,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134733",
        "134734",
        "134735",
        "134736",
        "134737",
        "134738",
        "134739",
        "134740",
        "134741",
        "134742",
        "134743",
        "134744",
        "134745",
        "134746",
        "134747",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134733",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134734",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134735",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134736",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134737",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134738",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134739",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134740",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134741",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134742",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134743",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134744",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134745",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134746",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134747",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1369",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1369",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1369",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1369",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1370] = {
    bn_name = "134149",
    bn_icon = "icons/role/list/lb_r_370.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_370.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =370,  --共鸣绑定ID,
    hero_id = 370,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134748",
        "134749",
        "134750",
        "134751",
        "134752",
        "134753",
        "134754",
        "134755",
        "134756",
        "134757",
        "134758",
        "134759",
        "134760",
        "134761",
        "134762",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134748",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134749",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134750",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134751",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134752",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134753",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134754",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134755",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134756",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134757",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134758",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134759",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134760",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134761",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134762",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1370",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1370",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1370",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1370",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1373] = {
    bn_name = "134150",
    bn_icon = "icons/role/list/lb_r_373.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_373.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =373,  --共鸣绑定ID,
    hero_id = 373,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134763",
        "134764",
        "134765",
        "134766",
        "134767",
        "134768",
        "134769",
        "134770",
        "134771",
        "134772",
        "134773",
        "134774",
        "134775",
        "134776",
        "134777",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134763",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134764",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134765",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134766",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134767",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134768",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134769",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134770",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134771",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134772",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134773",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134774",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134775",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134776",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134777",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1373",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1373",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1373",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1373",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1374] = {
    bn_name = "134151",
    bn_icon = "icons/role/list/lb_r_374.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_374.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =374,  --共鸣绑定ID,
    hero_id = 374,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134778",
        "134779",
        "134780",
        "134781",
        "134782",
        "134783",
        "134784",
        "134785",
        "134786",
        "134787",
        "134788",
        "134789",
        "134790",
        "134791",
        "134792",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134778",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134779",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134780",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134781",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134782",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134783",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134784",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134785",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134786",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134787",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134788",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134789",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134790",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134791",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134792",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1374",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1374",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1374",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1374",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1375] = {
    bn_name = "134152",
    bn_icon = "icons/role/list/lb_r_375.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_375.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =375,  --共鸣绑定ID,
    hero_id = 375,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134793",
        "134794",
        "134795",
        "134796",
        "134797",
        "134798",
        "134799",
        "134800",
        "134801",
        "134802",
        "134803",
        "134804",
        "134805",
        "134806",
        "134807",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134793",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134794",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134795",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134796",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134797",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134798",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134799",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134800",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134801",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134802",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134803",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134804",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134805",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134806",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134807",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1375",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1375",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1375",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1375",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1376] = {
    bn_name = "134153",
    bn_icon = "icons/role/list/lb_r_376.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_376.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =376,  --共鸣绑定ID,
    hero_id = 376,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134808",
        "134809",
        "134810",
        "134811",
        "134812",
        "134813",
        "134814",
        "134815",
        "134816",
        "134817",
        "134818",
        "134819",
        "134820",
        "134821",
        "134822",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134808",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134809",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134810",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134811",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134812",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134813",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134814",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134815",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134816",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134817",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134818",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134819",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134820",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134821",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134822",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1376",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1376",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1376",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1376",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1379] = {
    bn_name = "134154",
    bn_icon = "icons/role/list/lb_r_379.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_379.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =379,  --共鸣绑定ID,
    hero_id = 379,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134853",
        "134854",
        "134855",
        "134856",
        "134857",
        "134858",
        "134859",
        "134860",
        "134861",
        "134862",
        "134863",
        "134864",
        "134865",
        "134866",
        "134867",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134853",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134854",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134855",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134856",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134857",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134858",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134859",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134860",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134861",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134862",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134863",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134864",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134865",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134866",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134867",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1379",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1379",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1379",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1379",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1380] = {
    bn_name = "134155",
    bn_icon = "icons/role/list/lb_r_380.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_380.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =380,  --共鸣绑定ID,
    hero_id = 380,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134868",
        "134869",
        "134870",
        "134871",
        "134872",
        "134873",
        "134874",
        "134875",
        "134876",
        "134877",
        "134878",
        "134879",
        "134880",
        "134881",
        "134882",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134868",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134869",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134870",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134871",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134872",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134873",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134874",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134875",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134876",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134877",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134878",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134879",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134880",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134881",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134882",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1380",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1380",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1380",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1380",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1381] = {
    bn_name = "134156",
    bn_icon = "icons/role/list/lb_r_381.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_381.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =381,  --共鸣绑定ID,
    hero_id = 381,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134883",
        "134884",
        "134885",
        "134886",
        "134887",
        "134888",
        "134889",
        "134890",
        "134891",
        "134892",
        "134893",
        "134894",
        "134895",
        "134896",
        "134897",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134883",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134884",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134885",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134886",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134887",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134888",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134889",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134890",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134891",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134892",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134893",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134894",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134895",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134896",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134897",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1381",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1381",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1381",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1381",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1384] = {
    bn_name = "134157",
    bn_icon = "icons/role/list/lb_r_384.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_384.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =384,  --共鸣绑定ID,
    hero_id = 384,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134928",
        "134929",
        "134930",
        "134931",
        "134932",
        "134933",
        "134934",
        "134935",
        "134936",
        "134937",
        "134938",
        "134939",
        "134940",
        "134941",
        "134942",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134928",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134929",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134930",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134931",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134932",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134933",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134934",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134935",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134936",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134937",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134938",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134939",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134940",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134941",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134942",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1384",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1384",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1384",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1384",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1390] = {
    bn_name = "134158",
    bn_icon = "icons/role/list/lb_r_390.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_390.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =390,  --共鸣绑定ID,
    hero_id = 390,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135018",
        "135019",
        "135020",
        "135021",
        "135022",
        "135023",
        "135024",
        "135025",
        "135026",
        "135027",
        "135028",
        "135029",
        "135030",
        "135031",
        "135032",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135018",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135019",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135020",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135021",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135022",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135023",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135024",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135025",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135026",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135027",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135028",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135029",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135030",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135031",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135032",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1390",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1390",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1390",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1390",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1387] = {
    bn_name = "134159",
    bn_icon = "icons/role/list/lb_r_387.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_387.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =387,  --共鸣绑定ID,
    hero_id = 387,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134973",
        "134974",
        "134975",
        "134976",
        "134977",
        "134978",
        "134979",
        "134980",
        "134981",
        "134982",
        "134983",
        "134984",
        "134985",
        "134986",
        "134987",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134973",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134974",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134975",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134976",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134977",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134978",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134979",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134980",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134981",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134982",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134983",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134984",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134985",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134986",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134987",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1387",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1387",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1387",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1387",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1378] = {
    bn_name = "134160",
    bn_icon = "icons/role/list/lb_r_378.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_378.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =378,  --共鸣绑定ID,
    hero_id = 378,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134838",
        "134839",
        "134840",
        "134841",
        "134842",
        "134843",
        "134844",
        "134845",
        "134846",
        "134847",
        "134848",
        "134849",
        "134850",
        "134851",
        "134852",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134838",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134839",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134840",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134841",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134842",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134843",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134844",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134845",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134846",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134847",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134848",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134849",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134850",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134851",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134852",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1378",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1378",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1378",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1378",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1394] = {
    bn_name = "134161",
    bn_icon = "icons/role/list/lb_r_394.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_394.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =394,  --共鸣绑定ID,
    hero_id = 394,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135048",
        "135049",
        "135050",
        "135051",
        "135052",
        "135053",
        "135054",
        "135055",
        "135056",
        "135057",
        "135058",
        "135059",
        "135060",
        "135061",
        "135062",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135048",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135049",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135050",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135051",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135052",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135053",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135054",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135055",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135056",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135057",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135058",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135059",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135060",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135061",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135062",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1394",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1394",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1394",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1394",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1386] = {
    bn_name = "134162",
    bn_icon = "icons/role/list/lb_r_386.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_386.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =386,  --共鸣绑定ID,
    hero_id = 386,
    level = 3,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134958",
        "134959",
        "134960",
        "134961",
        "134962",
        "134963",
        "134964",
        "134965",
        "134966",
        "134967",
        "134968",
        "134969",
        "134970",
        "134971",
        "134972",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134958",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134959",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134960",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134961",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134962",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134963",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134964",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134965",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134966",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134967",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134968",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134969",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134970",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134971",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134972",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1386",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1386",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1386",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1386",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1385] = {
    bn_name = "134163",
    bn_icon = "icons/role/list/lb_r_385.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_385.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =385,  --共鸣绑定ID,
    hero_id = 385,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134943",
        "134944",
        "134945",
        "134946",
        "134947",
        "134948",
        "134949",
        "134950",
        "134951",
        "134952",
        "134953",
        "134954",
        "134955",
        "134956",
        "134957",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134943",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134944",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134945",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134946",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134947",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134948",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134949",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134950",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134951",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134952",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134953",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134954",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134955",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134956",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134957",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1385",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1385",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1385",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1385",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1389] = {
    bn_name = "134164",
    bn_icon = "icons/role/list/lb_r_389.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_389.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =389,  --共鸣绑定ID,
    hero_id = 389,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135003",
        "135004",
        "135005",
        "135006",
        "135007",
        "135008",
        "135009",
        "135010",
        "135011",
        "135012",
        "135013",
        "135014",
        "135015",
        "135016",
        "135017",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135003",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135004",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135005",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135006",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135007",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135008",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135009",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135010",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135011",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135012",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135013",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135014",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135015",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135016",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135017",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1389",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1389",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1389",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1389",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1383] = {
    bn_name = "134165",
    bn_icon = "icons/role/list/lb_r_383.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_383.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =383,  --共鸣绑定ID,
    hero_id = 383,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134913",
        "134914",
        "134915",
        "134916",
        "134917",
        "134918",
        "134919",
        "134920",
        "134921",
        "134922",
        "134923",
        "134924",
        "134925",
        "134926",
        "134927",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134913",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134914",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134915",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134916",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134917",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134918",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134919",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134920",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134921",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134922",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134923",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134924",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134925",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134926",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134927",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1383",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1383",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1383",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1383",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1382] = {
    bn_name = "134166",
    bn_icon = "icons/role/list/lb_r_382.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_382.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =382,  --共鸣绑定ID,
    hero_id = 382,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134898",
        "134899",
        "134900",
        "134901",
        "134902",
        "134903",
        "134904",
        "134905",
        "134906",
        "134907",
        "134908",
        "134909",
        "134910",
        "134911",
        "134912",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134898",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134899",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134900",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134901",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134902",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134903",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134904",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134905",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134906",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134907",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134908",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134909",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134910",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134911",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134912",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1382",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1382",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1382",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1382",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1391] = {
    bn_name = "134167",
    bn_icon = "icons/role/list/lb_r_391.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_391.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =391,  --共鸣绑定ID,
    hero_id = 391,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135033",
        "135034",
        "135035",
        "135036",
        "135037",
        "135038",
        "135039",
        "135040",
        "135041",
        "135042",
        "135043",
        "135044",
        "135045",
        "135046",
        "135047",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135033",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135034",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135035",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135036",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135037",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135038",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135039",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135040",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135041",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135042",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135043",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135044",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135045",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135046",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135047",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1391",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1391",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1391",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1391",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1388] = {
    bn_name = "134169",
    bn_icon = "icons/role/list/lb_r_388.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_388.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =388,  --共鸣绑定ID,
    hero_id = 388,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134988",
        "134989",
        "134990",
        "134991",
        "134992",
        "134993",
        "134994",
        "134995",
        "134996",
        "134997",
        "134998",
        "134999",
        "135000",
        "135001",
        "135002",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134988",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134989",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134990",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134991",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134992",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134993",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134994",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134995",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134996",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134997",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134998",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134999",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135000",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135001",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135002",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1388",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1388",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1388",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1388",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1451] = {
    bn_name = "134170",
    bn_icon = "icons/role/list/lb_r_451.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_451.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =451,  --共鸣绑定ID,
    hero_id = 451,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135228",
        "135229",
        "135230",
        "135231",
        "135232",
        "135233",
        "135234",
        "135235",
        "135236",
        "135237",
        "135238",
        "135239",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135228",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135229",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135230",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135231",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135232",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135233",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135234",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135235",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135236",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135237",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135238",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135239",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1451",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1451",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1451",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1451",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1404] = {
    bn_name = "134171",
    bn_icon = "icons/role/list/lb_r_404.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_404.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =404,  --共鸣绑定ID,
    hero_id = 404,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135093",
        "135094",
        "135095",
        "135096",
        "135097",
        "135098",
        "135099",
        "135100",
        "135101",
        "135102",
        "135103",
        "135104",
        "135105",
        "135106",
        "135107",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135093",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135094",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135095",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135096",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135097",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135098",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135099",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135100",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135101",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135102",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135103",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135104",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135105",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135106",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135107",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1404",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1404",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1404",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1404",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1405] = {
    bn_name = "134172",
    bn_icon = "icons/role/list/lb_r_405.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_405.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =405,  --共鸣绑定ID,
    hero_id = 405,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135108",
        "135109",
        "135110",
        "135111",
        "135112",
        "135113",
        "135114",
        "135115",
        "135116",
        "135117",
        "135118",
        "135119",
        "135120",
        "135121",
        "135122",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135108",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135109",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135110",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135111",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135112",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135113",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135114",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135115",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135116",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135117",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135118",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135119",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135120",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135121",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135122",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1405",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1405",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1405",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1405",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1397] = {
    bn_name = "134173",
    bn_icon = "icons/role/list/lb_r_397.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_397.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =397,  --共鸣绑定ID,
    hero_id = 397,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135063",
        "135064",
        "135065",
        "135066",
        "135067",
        "135068",
        "135069",
        "135070",
        "135071",
        "135072",
        "135073",
        "135074",
        "135075",
        "135076",
        "135077",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135063",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135064",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135065",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135066",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135067",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135068",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135069",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135070",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135071",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135072",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135073",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135074",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135075",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135076",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135077",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1397",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1397",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1397",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1397",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1408] = {
    bn_name = "134174",
    bn_icon = "icons/role/list/lb_r_408.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_408.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =408,  --共鸣绑定ID,
    hero_id = 408,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135153",
        "135154",
        "135155",
        "135156",
        "135157",
        "135158",
        "135159",
        "135160",
        "135161",
        "135162",
        "135163",
        "135164",
        "135165",
        "135166",
        "135167",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135153",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135154",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135155",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135156",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135157",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135158",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135159",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135160",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135161",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135162",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135163",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135164",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135165",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135166",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135167",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1408",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1408",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1408",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1408",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1407] = {
    bn_name = "134175",
    bn_icon = "icons/role/list/lb_r_407.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_407.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =407,  --共鸣绑定ID,
    hero_id = 407,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135138",
        "135139",
        "135140",
        "135141",
        "135142",
        "135143",
        "135144",
        "135145",
        "135146",
        "135147",
        "135148",
        "135149",
        "135150",
        "135151",
        "135152",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135138",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135139",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135140",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135141",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135142",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135143",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135144",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135145",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135146",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135147",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135148",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135149",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135150",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135151",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135152",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1407",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1407",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1407",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1407",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1409] = {
    bn_name = "134176",
    bn_icon = "icons/role/list/lb_r_409.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_409.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =409,  --共鸣绑定ID,
    hero_id = 409,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135168",
        "135169",
        "135170",
        "135171",
        "135172",
        "135173",
        "135174",
        "135175",
        "135176",
        "135177",
        "135178",
        "135179",
        "135180",
        "135181",
        "135182",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135168",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135169",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135170",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135171",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135172",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135173",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135174",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135175",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135176",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135177",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135178",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135179",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135180",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135181",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135182",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1409",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1409",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1409",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1409",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1412] = {
    bn_name = "134177",
    bn_icon = "icons/role/list/lb_r_412.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_412.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =412,  --共鸣绑定ID,
    hero_id = 412,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135198",
        "135199",
        "135200",
        "135201",
        "135202",
        "135203",
        "135204",
        "135205",
        "135206",
        "135207",
        "135208",
        "135209",
        "135210",
        "135211",
        "135212",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135198",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135199",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135200",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135201",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135202",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135203",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135204",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135205",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135206",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135207",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135208",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135209",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135210",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135211",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135212",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1412",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1412",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1412",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1412",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1403] = {
    bn_name = "134178",
    bn_icon = "icons/role/list/lb_r_403.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_403.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =403,  --共鸣绑定ID,
    hero_id = 403,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135078",
        "135079",
        "135080",
        "135081",
        "135082",
        "135083",
        "135084",
        "135085",
        "135086",
        "135087",
        "135088",
        "135089",
        "135090",
        "135091",
        "135092",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135078",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135079",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135080",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135081",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135082",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135083",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135084",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135085",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135086",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135087",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135088",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135089",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135090",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135091",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135092",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1403",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1403",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1403",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1403",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1413] = {
    bn_name = "134179",
    bn_icon = "icons/role/list/lb_r_413.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_413.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =413,  --共鸣绑定ID,
    hero_id = 413,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135213",
        "135214",
        "135215",
        "135216",
        "135217",
        "135218",
        "135219",
        "135220",
        "135221",
        "135222",
        "135223",
        "135224",
        "135225",
        "135226",
        "135227",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135213",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135214",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135215",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135216",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135217",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135218",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135219",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135220",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135221",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135222",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135223",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135224",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135225",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135226",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135227",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1413",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1413",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1413",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1413",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1353] = {
    bn_name = "134180",
    bn_icon = "icons/role/list/lb_r_353.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_353.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =353,  --共鸣绑定ID,
    hero_id = 353,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134553",
        "134554",
        "134555",
        "134556",
        "134557",
        "134558",
        "134559",
        "134560",
        "134561",
        "134562",
        "134563",
        "134564",
        "134565",
        "134566",
        "134567",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134553",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134554",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134555",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134556",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134557",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134558",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134559",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134560",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134561",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134562",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134563",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134564",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134565",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134566",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134567",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1353",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1353",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1353",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1353",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1377] = {
    bn_name = "134181",
    bn_icon = "icons/role/list/lb_r_377.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_377.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =377,  --共鸣绑定ID,
    hero_id = 377,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "134823",
        "134824",
        "134825",
        "134826",
        "134827",
        "134828",
        "134829",
        "134830",
        "134831",
        "134832",
        "134833",
        "134834",
        "134835",
        "134836",
        "134837",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "134823",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134824",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134825",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134826",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134827",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134828",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134829",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134830",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134831",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134832",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134833",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134834",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134835",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134836",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "134837",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1377",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1377",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1377",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1377",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1402] = {
    bn_name = "134182",
    bn_icon = "icons/role/list/lb_r_402.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_402.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =402,  --共鸣绑定ID,
    hero_id = 402,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135240",
        "135241",
        "135242",
        "135243",
        "135244",
        "135245",
        "135246",
        "135247",
        "135248",
        "135249",
        "135250",
        "135251",
        "135252",
        "135253",
        "135254",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135240",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135241",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135242",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135243",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135244",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135245",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135246",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135247",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135248",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135249",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135250",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135251",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135252",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135253",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135254",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1402",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1402",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1402",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1402",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1406] = {
    bn_name = "134183",
    bn_icon = "icons/role/list/lb_r_406.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_406.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =406,  --共鸣绑定ID,
    hero_id = 406,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135123",
        "135124",
        "135125",
        "135126",
        "135127",
        "135128",
        "135129",
        "135130",
        "135131",
        "135132",
        "135133",
        "135134",
        "135135",
        "135136",
        "135137",
        "135255",
        "135256",
        "135257",
        "135258",
        "135259",
        "135260",
        "135261",
        "135262",
        "135263",
        "135264",
        "135265",
        "135266",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135123",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135124",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135125",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135126",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135127",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135128",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135129",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135130",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135131",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135132",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135133",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135134",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135135",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135136",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135137",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135255",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135256",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135257",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135258",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135259",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135260",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135261",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135262",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135263",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135264",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135265",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135266",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1406",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1406",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1406",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1406",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1410] = {
    bn_name = "134184",
    bn_icon = "icons/role/list/lb_r_410.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_410.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action10",  --铸造完成
        Explore = "action11",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =410,  --共鸣绑定ID,
    hero_id = 410,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135267",
        "135268",
        "135269",
        "135270",
        "135271",
        "135272",
        "135273",
        "135274",
        "135275",
        "135276",
        "135277",
        "135278",
        "135279",
        "135280",
        "135281",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135267",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135268",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135269",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135270",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135271",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135272",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135273",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135274",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135275",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135276",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135277",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135278",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135279",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135280",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135281",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1410",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1410",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1410",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1410",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1414] = {
    bn_name = "134185",
    bn_icon = "icons/role/list/lb_r_414.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_414.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =414,  --共鸣绑定ID,
    hero_id = 414,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135282",
        "135283",
        "135284",
        "135285",
        "135286",
        "135287",
        "135288",
        "135289",
        "135290",
        "135291",
        "135292",
        "135293",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135282",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135283",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135284",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135285",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135286",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135287",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135288",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135289",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135290",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135291",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135292",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135293",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1414",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1414",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1414",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1414",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1500] = {
    bn_name = "134186",
    bn_icon = "icons/role/list/lb_r_500.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_500.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action7",  --铸造完成
        Explore = "action8",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =500,  --共鸣绑定ID,
    hero_id = 500,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135294",
        "135295",
        "135296",
        "135297",
        "135298",
        "135299",
        "135300",
        "135301",
        "135302",
        "135303",
        "135304",
        "135305",
        "135306",
        "135307",
        "135308",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135294",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135295",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135296",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135297",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135298",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135299",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135300",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135301",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135302",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135303",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135304",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135305",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135306",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135307",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135308",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1500",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1500",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1500",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1500",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1600] = {
    bn_name = "134187",
    bn_icon = "icons/role/list/lb_r_600.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_600.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =600,  --共鸣绑定ID,
    hero_id = 600,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135324",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135324",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1600",
            dialog = {1},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1600",
            dialog = {1},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1600",
            dialog = {1},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1600",
            dialog = {1},
        },
    }
} 
princess_mainpage[1601] = {
    bn_name = "134188",
    bn_icon = "icons/role/list/lb_r_601.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_601.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =601,  --共鸣绑定ID,
    hero_id = 601,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135325",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135325",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1601",
            dialog = {1},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1601",
            dialog = {1},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1601",
            dialog = {1},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1601",
            dialog = {1},
        },
    }
} 
princess_mainpage[1602] = {
    bn_name = "134189",
    bn_icon = "icons/role/list/lb_r_602.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_602.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =602,  --共鸣绑定ID,
    hero_id = 602,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135326",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135326",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1602",
            dialog = {1},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1602",
            dialog = {1},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1602",
            dialog = {1},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1602",
            dialog = {1},
        },
    }
} 
princess_mainpage[1603] = {
    bn_name = "134190",
    bn_icon = "icons/role/list/lb_r_603.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_603.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =603,  --共鸣绑定ID,
    hero_id = 603,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135327",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135327",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1603",
            dialog = {1},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1603",
            dialog = {1},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1603",
            dialog = {1},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1603",
            dialog = {1},
        },
    }
} 
princess_mainpage[1604] = {
    bn_name = "134191",
    bn_icon = "icons/role/list/lb_r_604.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_604.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =604,  --共鸣绑定ID,
    hero_id = 604,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135328",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135328",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1604",
            dialog = {1},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1604",
            dialog = {1},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1604",
            dialog = {1},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1604",
            dialog = {1},
        },
    }
} 
princess_mainpage[1605] = {
    bn_name = "134192",
    bn_icon = "icons/role/list/lb_r_605.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_605.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action",  --铸造完成
        Explore = "action",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =605,  --共鸣绑定ID,
    hero_id = 605,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135329",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135329",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1605",
            dialog = {1},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1605",
            dialog = {1},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1605",
            dialog = {1},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1605",
            dialog = {1},
        },
    }
} 
princess_mainpage[1411] = {
    bn_name = "134193",
    bn_icon = "icons/role/list/lb_r_411.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_411.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action1",  --铸造完成
        Explore = "action2",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =411,  --共鸣绑定ID,
    hero_id = 411,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135183",
        "135184",
        "135185",
        "135186",
        "135187",
        "135188",
        "135189",
        "135190",
        "135191",
        "135192",
        "135193",
        "135194",
        "135195",
        "135196",
        "135197",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135183",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135184",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135185",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135186",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135187",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135188",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135189",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135190",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135191",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135192",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135193",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135194",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135195",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135196",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135197",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1411",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1411",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1411",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1411",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1527] = {
    bn_name = "134194",
    bn_icon = "icons/role/list/lb_r_527.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_527.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =527,  --共鸣绑定ID,
    hero_id = 527,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135330",
        "135331",
        "135332",
        "135333",
        "135334",
        "135335",
        "135336",
        "135337",
        "135338",
        "135339",
        "135340",
        "135341",
        "135342",
        "135343",
        "135344",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135330",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135331",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135332",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135333",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135334",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135335",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135336",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135337",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135338",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135339",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135340",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135341",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135342",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135343",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135344",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1527",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1527",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1527",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1527",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1392] = {
    bn_name = "134195",
    bn_icon = "icons/role/list/lb_r_392.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_392.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =392,  --共鸣绑定ID,
    hero_id = 392,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135345",
        "135346",
        "135347",
        "135348",
        "135349",
        "135350",
        "135351",
        "135352",
        "135353",
        "135354",
        "135355",
        "135356",
        "135357",
        "135358",
        "135359",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135345",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135346",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135347",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135348",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135349",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135350",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135351",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135352",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135353",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135354",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135355",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135356",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135357",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135358",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135359",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1392",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1392",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1392",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1392",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1395] = {
    bn_name = "134196",
    bn_icon = "icons/role/list/lb_r_395.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_395.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 333,
    scaling = 0.9,  --缩放比例
    likefeeling_id =395,  --共鸣绑定ID,
    hero_id = 395,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135360",
        "135361",
        "135362",
        "135363",
        "135364",
        "135365",
        "135366",
        "135367",
        "135368",
        "135369",
        "135370",
        "135371",
        "135372",
        "135373",
        "135374",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135360",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135361",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135362",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135363",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135364",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135365",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135366",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135367",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135368",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135369",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135370",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135371",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135372",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135373",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135374",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1395",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1395",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1395",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1395",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1504] = {
    bn_name = "134197",
    bn_icon = "icons/role/list/lb_r_504.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_504.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action7",  --铸造完成
        Explore = "action8",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =504,  --共鸣绑定ID,
    hero_id = 504,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135309",
        "135310",
        "135311",
        "135312",
        "135313",
        "135314",
        "135315",
        "135316",
        "135317",
        "135318",
        "135319",
        "135320",
        "135321",
        "135322",
        "135323",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135309",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135310",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135311",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135312",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135313",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135314",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135315",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135316",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135317",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135318",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135319",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135320",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135321",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135322",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135323",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1504",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1504",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1504",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1504",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1506] = {
    bn_name = "134198",
    bn_icon = "icons/role/list/lb_r_506.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_506.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =506,  --共鸣绑定ID,
    hero_id = 506,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "135375",
        "135376",
        "135377",
        "135378",
        "135379",
        "135380",
        "135381",
        "135382",
        "135383",
        "135384",
        "135385",
        "135386",
        "135387",
        "135388",
        "135389",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "135375",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135376",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135377",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135378",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135379",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135380",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135381",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135382",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135383",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135384",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135385",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135386",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135387",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135388",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "135389",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1506",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1506",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1506",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1506",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1530] = {
    bn_name = "607201",
    bn_icon = "icons/role/list/lb_r_530.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_530.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1530/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1530/1.mp3",
            dialog = "607301",
            voiceTime = 8
        },
        action2 = {
            voice = "music/ui/signboradgirl_1530/2.mp3",
            dialog = "607302",
            voiceTime = 4
        },
        action3 = {
            voice = "music/ui/signboradgirl_1530/3.mp3",
            dialog = "607303",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1530/4.mp3",
            dialog = "607304",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1530/5.mp3",
            dialog = "607305",
            voiceTime = 9
        },
        action6 = {
            voice = "music/ui/signboradgirl_1530/6.mp3",
            dialog = "607306",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1530/7.mp3",
            dialog = "607307",
            voiceTime = 8
        },
        action8 = {
            voice = "music/ui/signboradgirl_1530/8.mp3",
            dialog = "607308",
            voiceTime = 9
        },
        action9 = {
            voice = "music/ui/signboradgirl_1530/9.mp3",
            dialog = "607309",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1530/10.mp3",
            dialog = "607310",
            voiceTime = 8
        },
        action11 = {
            voice = "music/ui/signboradgirl_1530/11.mp3",
            dialog = "607311",
            voiceTime = 12
        },
        action12 = {
            voice = "music/ui/signboradgirl_1530/12.mp3",
            dialog = "607312",
            voiceTime = 13
        },
        action13 = {
            voice = "music/ui/signboradgirl_1530/13.mp3",
            dialog = "607313",
            voiceTime = 6
        },
        action14 = {
            voice = "music/ui/signboradgirl_1530/14.mp3",
            dialog = "607314",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1530/15.mp3",
            dialog = "607315",
            voiceTime = 5
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =530,  --共鸣绑定ID,
    hero_id = 530,
    level = 4,  --板娘品质
    dialogs = {     --好感度对话文字 
        "607301",
        "607302",
        "607303",
        "607304",
        "607305",
        "607306",
        "607307",
        "607308",
        "607309",
        "607310",
        "607311",
        "607312",
        "607313",
        "607314",
        "607315",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1530/1.mp3",
            dialog = "607301",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1530/2.mp3",
            dialog = "607302",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1530/3.mp3",
            dialog = "607303",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1530/4.mp3",
            dialog = "607304",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1530/5.mp3",
            dialog = "607305",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1530/6.mp3",
            dialog = "607306",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1530/7.mp3",
            dialog = "607307",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1530/8.mp3",
            dialog = "607308",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1530/9.mp3",
            dialog = "607309",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1530/10.mp3",
            dialog = "607310",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1530/11.mp3",
            dialog = "607311",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1530/12.mp3",
            dialog = "607312",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1530/13.mp3",
            dialog = "607313",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1530/14.mp3",
            dialog = "607314",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1530/15.mp3",
            dialog = "607315",
            voiceTime = 5
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1530",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1530",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1530",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1530",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1531] = {
    bn_name = "607202",
    bn_icon = "icons/role/list/lb_r_531.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_531.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1531/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1531/1.mp3",
            dialog = "607401",
            voiceTime = 6
        },
        action2 = {
            voice = "music/ui/signboradgirl_1531/2.mp3",
            dialog = "607402",
            voiceTime = 8
        },
        action3 = {
            voice = "music/ui/signboradgirl_1531/3.mp3",
            dialog = "607403",
            voiceTime = 7
        },
        action4 = {
            voice = "music/ui/signboradgirl_1531/4.mp3",
            dialog = "607404",
            voiceTime = 10
        },
        action5 = {
            voice = "music/ui/signboradgirl_1531/5.mp3",
            dialog = "607405",
            voiceTime = 7
        },
        action6 = {
            voice = "music/ui/signboradgirl_1531/6.mp3",
            dialog = "607406",
            voiceTime = 10
        },
        action7 = {
            voice = "music/ui/signboradgirl_1531/7.mp3",
            dialog = "607407",
            voiceTime = 8
        },
        action8 = {
            voice = "music/ui/signboradgirl_1531/8.mp3",
            dialog = "607408",
            voiceTime = 9
        },
        action9 = {
            voice = "music/ui/signboradgirl_1531/9.mp3",
            dialog = "607409",
            voiceTime = 11
        },
        action10 = {
            voice = "music/ui/signboradgirl_1531/10.mp3",
            dialog = "607410",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1531/11.mp3",
            dialog = "607411",
            voiceTime = 16
        },
        action12 = {
            voice = "music/ui/signboradgirl_1531/12.mp3",
            dialog = "607412",
            voiceTime = 13
        },
        action13 = {
            voice = "music/ui/signboradgirl_1531/13.mp3",
            dialog = "607413",
            voiceTime = 8
        },
        action14 = {
            voice = "music/ui/signboradgirl_1531/14.mp3",
            dialog = "607414",
            voiceTime = 6
        },
        action15 = {
            voice = "music/ui/signboradgirl_1531/15.mp3",
            dialog = "607415",
            voiceTime = 10
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =531,  --共鸣绑定ID,
    hero_id = 531,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "607401",
        "607402",
        "607403",
        "607404",
        "607405",
        "607406",
        "607407",
        "607408",
        "607409",
        "607410",
        "607411",
        "607412",
        "607413",
        "607414",
        "607415",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1531/1.mp3",
            dialog = "607401",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1531/2.mp3",
            dialog = "607402",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1531/3.mp3",
            dialog = "607403",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1531/4.mp3",
            dialog = "607404",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1531/5.mp3",
            dialog = "607405",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1531/6.mp3",
            dialog = "607406",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1531/7.mp3",
            dialog = "607407",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1531/8.mp3",
            dialog = "607408",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1531/9.mp3",
            dialog = "607409",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1531/10.mp3",
            dialog = "607410",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1531/11.mp3",
            dialog = "607411",
            voiceTime = 16
        },
        {
            voice = "music/ui/signboradgirl_1531/12.mp3",
            dialog = "607412",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1531/13.mp3",
            dialog = "607413",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1531/14.mp3",
            dialog = "607414",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1531/15.mp3",
            dialog = "607415",
            voiceTime = 10
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1531",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1531",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1531",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1531",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1532] = {
    bn_name = "607203",
    bn_icon = "icons/role/list/lb_r_532.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_532.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1532/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1532/1.mp3",
            dialog = "607501",
            voiceTime = 4
        },
        action2 = {
            voice = "music/ui/signboradgirl_1532/2.mp3",
            dialog = "607502",
            voiceTime = 9
        },
        action3 = {
            voice = "music/ui/signboradgirl_1532/3.mp3",
            dialog = "607503",
            voiceTime = 8
        },
        action4 = {
            voice = "music/ui/signboradgirl_1532/4.mp3",
            dialog = "607504",
            voiceTime = 10
        },
        action5 = {
            voice = "music/ui/signboradgirl_1532/5.mp3",
            dialog = "607505",
            voiceTime = 10
        },
        action6 = {
            voice = "music/ui/signboradgirl_1532/6.mp3",
            dialog = "607506",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1532/7.mp3",
            dialog = "607507",
            voiceTime = 10
        },
        action8 = {
            voice = "music/ui/signboradgirl_1532/8.mp3",
            dialog = "607508",
            voiceTime = 7
        },
        action9 = {
            voice = "music/ui/signboradgirl_1532/9.mp3",
            dialog = "607509",
            voiceTime = 11
        },
        action10 = {
            voice = "music/ui/signboradgirl_1532/10.mp3",
            dialog = "607510",
            voiceTime = 8
        },
        action11 = {
            voice = "music/ui/signboradgirl_1532/11.mp3",
            dialog = "607511",
            voiceTime = 6
        },
        action12 = {
            voice = "music/ui/signboradgirl_1532/12.mp3",
            dialog = "607512",
            voiceTime = 8
        },
        action13 = {
            voice = "music/ui/signboradgirl_1532/13.mp3",
            dialog = "607513",
            voiceTime = 6
        },
        action14 = {
            voice = "music/ui/signboradgirl_1532/14.mp3",
            dialog = "607514",
            voiceTime = 6
        },
        action15 = {
            voice = "music/ui/signboradgirl_1532/15.mp3",
            dialog = "607515",
            voiceTime = 5
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 333,
    scaling = 0.9,  --缩放比例
    likefeeling_id =532,  --共鸣绑定ID,
    hero_id = 532,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "607501",
        "607502",
        "607503",
        "607504",
        "607505",
        "607506",
        "607507",
        "607508",
        "607509",
        "607510",
        "607511",
        "607512",
        "607513",
        "607514",
        "607515",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1532/1.mp3",
            dialog = "607501",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1532/2.mp3",
            dialog = "607502",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1532/3.mp3",
            dialog = "607503",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1532/4.mp3",
            dialog = "607504",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1532/5.mp3",
            dialog = "607505",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1532/6.mp3",
            dialog = "607506",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1532/7.mp3",
            dialog = "607507",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1532/8.mp3",
            dialog = "607508",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1532/9.mp3",
            dialog = "607509",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1532/10.mp3",
            dialog = "607510",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1532/11.mp3",
            dialog = "607511",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1532/12.mp3",
            dialog = "607512",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1532/13.mp3",
            dialog = "607513",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1532/14.mp3",
            dialog = "607514",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1532/15.mp3",
            dialog = "607515",
            voiceTime = 5
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1532",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1532",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1532",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1532",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1529] = {
    bn_name = "607204",
    bn_icon = "icons/role/list/lb_r_529.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_529.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1529/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1529/1.mp3",
            dialog = "607601",
            voiceTime = 7
        },
        action2 = {
            voice = "music/ui/signboradgirl_1529/2.mp3",
            dialog = "607602",
            voiceTime = 9
        },
        action3 = {
            voice = "music/ui/signboradgirl_1529/3.mp3",
            dialog = "607603",
            voiceTime = 4
        },
        action4 = {
            voice = "music/ui/signboradgirl_1529/4.mp3",
            dialog = "607604",
            voiceTime = 9
        },
        action5 = {
            voice = "music/ui/signboradgirl_1529/5.mp3",
            dialog = "607605",
            voiceTime = 8
        },
        action6 = {
            voice = "music/ui/signboradgirl_1529/6.mp3",
            dialog = "607606",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1529/7.mp3",
            dialog = "607607",
            voiceTime = 4
        },
        action8 = {
            voice = "music/ui/signboradgirl_1529/8.mp3",
            dialog = "607608",
            voiceTime = 9
        },
        action9 = {
            voice = "music/ui/signboradgirl_1529/9.mp3",
            dialog = "607609",
            voiceTime = 16
        },
        action10 = {
            voice = "music/ui/signboradgirl_1529/10.mp3",
            dialog = "607610",
            voiceTime = 14
        },
        action11 = {
            voice = "music/ui/signboradgirl_1529/11.mp3",
            dialog = "607611",
            voiceTime = 13
        },
        action12 = {
            voice = "music/ui/signboradgirl_1529/12.mp3",
            dialog = "607612",
            voiceTime = 7
        },
        action13 = {
            voice = "music/ui/signboradgirl_1529/13.mp3",
            dialog = "607613",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1529/14.mp3",
            dialog = "607614",
            voiceTime = 2
        },
        action15 = {
            voice = "music/ui/signboradgirl_1529/15.mp3",
            dialog = "607615",
            voiceTime = 6
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =529,  --共鸣绑定ID,
    hero_id = 529,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "607601",
        "607602",
        "607603",
        "607604",
        "607605",
        "607606",
        "607607",
        "607608",
        "607609",
        "607610",
        "607611",
        "607612",
        "607613",
        "607614",
        "607615",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1529/1.mp3",
            dialog = "607601",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1529/2.mp3",
            dialog = "607602",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1529/3.mp3",
            dialog = "607603",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1529/4.mp3",
            dialog = "607604",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1529/5.mp3",
            dialog = "607605",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1529/6.mp3",
            dialog = "607606",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1529/7.mp3",
            dialog = "607607",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1529/8.mp3",
            dialog = "607608",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1529/9.mp3",
            dialog = "607609",
            voiceTime = 16
        },
        {
            voice = "music/ui/signboradgirl_1529/10.mp3",
            dialog = "607610",
            voiceTime = 14
        },
        {
            voice = "music/ui/signboradgirl_1529/11.mp3",
            dialog = "607611",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1529/12.mp3",
            dialog = "607612",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1529/13.mp3",
            dialog = "607613",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1529/14.mp3",
            dialog = "607614",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1529/15.mp3",
            dialog = "607615",
            voiceTime = 6
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1529",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1529",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1529",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1529",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1528] = {
    bn_name = "607205",
    bn_icon = "icons/role/list/lb_r_528.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_528.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1528/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1528/1.mp3",
            dialog = "607701",
            voiceTime = 5
        },
        action2 = {
            voice = "music/ui/signboradgirl_1528/2.mp3",
            dialog = "607702",
            voiceTime = 11
        },
        action3 = {
            voice = "music/ui/signboradgirl_1528/3.mp3",
            dialog = "607703",
            voiceTime = 9
        },
        action4 = {
            voice = "music/ui/signboradgirl_1528/4.mp3",
            dialog = "607704",
            voiceTime = 6
        },
        action5 = {
            voice = "music/ui/signboradgirl_1528/5.mp3",
            dialog = "607705",
            voiceTime = 11
        },
        action6 = {
            voice = "music/ui/signboradgirl_1528/6.mp3",
            dialog = "607706",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1528/7.mp3",
            dialog = "607707",
            voiceTime = 6
        },
        action8 = {
            voice = "music/ui/signboradgirl_1528/8.mp3",
            dialog = "607708",
            voiceTime = 13
        },
        action9 = {
            voice = "music/ui/signboradgirl_1528/9.mp3",
            dialog = "607709",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1528/10.mp3",
            dialog = "607710",
            voiceTime = 9
        },
        action11 = {
            voice = "music/ui/signboradgirl_1528/11.mp3",
            dialog = "607711",
            voiceTime = 14
        },
        action12 = {
            voice = "music/ui/signboradgirl_1528/12.mp3",
            dialog = "607712",
            voiceTime = 14
        },
        action13 = {
            voice = "music/ui/signboradgirl_1528/13.mp3",
            dialog = "607713",
            voiceTime = 5
        },
        action14 = {
            voice = "music/ui/signboradgirl_1528/14.mp3",
            dialog = "607714",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1528/15.mp3",
            dialog = "607715",
            voiceTime = 7
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =528,  --共鸣绑定ID,
    hero_id = 528,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "607701",
        "607702",
        "607703",
        "607704",
        "607705",
        "607706",
        "607707",
        "607708",
        "607709",
        "607710",
        "607711",
        "607712",
        "607713",
        "607714",
        "607715",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1528/1.mp3",
            dialog = "607701",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1528/2.mp3",
            dialog = "607702",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1528/3.mp3",
            dialog = "607703",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1528/4.mp3",
            dialog = "607704",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1528/5.mp3",
            dialog = "607705",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1528/6.mp3",
            dialog = "607706",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1528/7.mp3",
            dialog = "607707",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1528/8.mp3",
            dialog = "607708",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1528/9.mp3",
            dialog = "607709",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1528/10.mp3",
            dialog = "607710",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1528/11.mp3",
            dialog = "607711",
            voiceTime = 14
        },
        {
            voice = "music/ui/signboradgirl_1528/12.mp3",
            dialog = "607712",
            voiceTime = 14
        },
        {
            voice = "music/ui/signboradgirl_1528/13.mp3",
            dialog = "607713",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1528/14.mp3",
            dialog = "607714",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1528/15.mp3",
            dialog = "607715",
            voiceTime = 7
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1528",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1528",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1528",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1528",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1501] = {
    bn_name = "612314",
    bn_icon = "icons/role/list/lb_r_501.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_501.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =501,  --共鸣绑定ID,
    hero_id = 501,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "612315",
        "612316",
        "612317",
        "612318",
        "612319",
        "612320",
        "612321",
        "612322",
        "612323",
        "612324",
        "612325",
        "612326",
        "612327",
        "612328",
        "612329",
    },
    actionTouch = { 
        {
            voice = "",
            dialog = "612315",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612316",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612317",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612318",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612319",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612320",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612321",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612322",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612323",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612324",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612325",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612326",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612327",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612328",
            voiceTime = 3
        },
        {
            voice = "",
            dialog = "612329",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1501",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1501",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1501",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1501",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1606] = {
    bn_name = "300005",
    bn_icon = "icons/role/list/lb_r_606.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_606.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1606/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1606/1.mp3",
            dialog = "613207",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1606/2.mp3",
            dialog = "613208",
            voiceTime = 5
        },
        action3 = {
            voice = "music/ui/signboradgirl_1606/3.mp3",
            dialog = "613209",
            voiceTime = 4
        },
        action4 = {
            voice = "music/ui/signboradgirl_1606/4.mp3",
            dialog = "613210",
            voiceTime = 2
        },
        action5 = {
            voice = "music/ui/signboradgirl_1606/5.mp3",
            dialog = "613211",
            voiceTime = 4
        },
        action6 = {
            voice = "music/ui/signboradgirl_1606/6.mp3",
            dialog = "613212",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1606/7.mp3",
            dialog = "613213",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1606/8.mp3",
            dialog = "613214",
            voiceTime = 6
        },
        action9 = {
            voice = "music/ui/signboradgirl_1606/9.mp3",
            dialog = "613215",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1606/10.mp3",
            dialog = "613216",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1606/11.mp3",
            dialog = "613217",
            voiceTime = 6
        },
        action12 = {
            voice = "music/ui/signboradgirl_1606/12.mp3",
            dialog = "613218",
            voiceTime = 7
        },
        action13 = {
            voice = "music/ui/signboradgirl_1606/13.mp3",
            dialog = "613219",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1606/14.mp3",
            dialog = "613220",
            voiceTime = 2
        },
        action15 = {
            voice = "music/ui/signboradgirl_1606/15.mp3",
            dialog = "613221",
            voiceTime = 2
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =606,  --共鸣绑定ID,
    hero_id = 606,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "613207",
        "613208",
        "613209",
        "613210",
        "613211",
        "613212",
        "613213",
        "613214",
        "613215",
        "613216",
        "613217",
        "613218",
        "613219",
        "613220",
        "613221",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1606/1.mp3",
            dialog = "613207",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1606/2.mp3",
            dialog = "613208",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1606/3.mp3",
            dialog = "613209",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1606/4.mp3",
            dialog = "613210",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1606/5.mp3",
            dialog = "613211",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1606/6.mp3",
            dialog = "613212",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1606/7.mp3",
            dialog = "613213",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1606/8.mp3",
            dialog = "613214",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1606/9.mp3",
            dialog = "613215",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1606/10.mp3",
            dialog = "613216",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1606/11.mp3",
            dialog = "613217",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1606/12.mp3",
            dialog = "613218",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1606/13.mp3",
            dialog = "613219",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1606/14.mp3",
            dialog = "613220",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1606/15.mp3",
            dialog = "613221",
            voiceTime = 2
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1606",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1606",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1606",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1606",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1607] = {
    bn_name = "300006",
    bn_icon = "icons/role/list/lb_r_607.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_607.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1607/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1607/1.mp3",
            dialog = "613222",
            voiceTime = 5
        },
        action2 = {
            voice = "music/ui/signboradgirl_1607/2.mp3",
            dialog = "613223",
            voiceTime = 4
        },
        action3 = {
            voice = "music/ui/signboradgirl_1607/3.mp3",
            dialog = "613224",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1607/4.mp3",
            dialog = "613225",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1607/5.mp3",
            dialog = "613226",
            voiceTime = 5
        },
        action6 = {
            voice = "music/ui/signboradgirl_1607/6.mp3",
            dialog = "613227",
            voiceTime = 9
        },
        action7 = {
            voice = "music/ui/signboradgirl_1607/7.mp3",
            dialog = "613228",
            voiceTime = 4
        },
        action8 = {
            voice = "music/ui/signboradgirl_1607/8.mp3",
            dialog = "613229",
            voiceTime = 5
        },
        action9 = {
            voice = "music/ui/signboradgirl_1607/9.mp3",
            dialog = "613230",
            voiceTime = 10
        },
        action10 = {
            voice = "music/ui/signboradgirl_1607/10.mp3",
            dialog = "613231",
            voiceTime = 4
        },
        action11 = {
            voice = "music/ui/signboradgirl_1607/11.mp3",
            dialog = "613232",
            voiceTime = 5
        },
        action12 = {
            voice = "music/ui/signboradgirl_1607/12.mp3",
            dialog = "613233",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1607/13.mp3",
            dialog = "613234",
            voiceTime = 6
        },
        action14 = {
            voice = "music/ui/signboradgirl_1607/14.mp3",
            dialog = "613235",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1607/15.mp3",
            dialog = "613236",
            voiceTime = 6
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =607,  --共鸣绑定ID,
    hero_id = 607,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "613222",
        "613223",
        "613224",
        "613225",
        "613226",
        "613227",
        "613228",
        "613229",
        "613230",
        "613231",
        "613232",
        "613233",
        "613234",
        "613235",
        "613236",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1607/1.mp3",
            dialog = "613222",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1607/2.mp3",
            dialog = "613223",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1607/3.mp3",
            dialog = "613224",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1607/4.mp3",
            dialog = "613225",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1607/5.mp3",
            dialog = "613226",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1607/6.mp3",
            dialog = "613227",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1607/7.mp3",
            dialog = "613228",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1607/8.mp3",
            dialog = "613229",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1607/9.mp3",
            dialog = "613230",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1607/10.mp3",
            dialog = "613231",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1607/11.mp3",
            dialog = "613232",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1607/12.mp3",
            dialog = "613233",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1607/13.mp3",
            dialog = "613234",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1607/14.mp3",
            dialog = "613235",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1607/15.mp3",
            dialog = "613236",
            voiceTime = 6
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1607",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1607",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1607",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1607",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1608] = {
    bn_name = "300007",
    bn_icon = "icons/role/list/lb_r_608.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_608.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1608/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1608/1.mp3",
            dialog = "613237",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1608/2.mp3",
            dialog = "613238",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1608/3.mp3",
            dialog = "613239",
            voiceTime = 8
        },
        action4 = {
            voice = "music/ui/signboradgirl_1608/4.mp3",
            dialog = "613240",
            voiceTime = 5
        },
        action5 = {
            voice = "music/ui/signboradgirl_1608/5.mp3",
            dialog = "613241",
            voiceTime = 4
        },
        action6 = {
            voice = "music/ui/signboradgirl_1608/6.mp3",
            dialog = "613242",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1608/7.mp3",
            dialog = "613243",
            voiceTime = 8
        },
        action8 = {
            voice = "music/ui/signboradgirl_1608/8.mp3",
            dialog = "613244",
            voiceTime = 2
        },
        action9 = {
            voice = "music/ui/signboradgirl_1608/9.mp3",
            dialog = "613245",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1608/10.mp3",
            dialog = "613246",
            voiceTime = 7
        },
        action11 = {
            voice = "music/ui/signboradgirl_1608/11.mp3",
            dialog = "613247",
            voiceTime = 5
        },
        action12 = {
            voice = "music/ui/signboradgirl_1608/12.mp3",
            dialog = "613248",
            voiceTime = 5
        },
        action13 = {
            voice = "music/ui/signboradgirl_1608/13.mp3",
            dialog = "613249",
            voiceTime = 2
        },
        action14 = {
            voice = "music/ui/signboradgirl_1608/14.mp3",
            dialog = "613250",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1608/15.mp3",
            dialog = "613251",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =608,  --共鸣绑定ID,
    hero_id = 608,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "613237",
        "613238",
        "613239",
        "613240",
        "613241",
        "613242",
        "613243",
        "613244",
        "613245",
        "613246",
        "613247",
        "613248",
        "613249",
        "613250",
        "613251",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1608/1.mp3",
            dialog = "613237",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1608/2.mp3",
            dialog = "613238",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1608/3.mp3",
            dialog = "613239",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1608/4.mp3",
            dialog = "613240",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1608/5.mp3",
            dialog = "613241",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1608/6.mp3",
            dialog = "613242",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1608/7.mp3",
            dialog = "613243",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1608/8.mp3",
            dialog = "613244",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1608/9.mp3",
            dialog = "613245",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1608/10.mp3",
            dialog = "613246",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1608/11.mp3",
            dialog = "613247",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1608/12.mp3",
            dialog = "613248",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1608/13.mp3",
            dialog = "613249",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1608/14.mp3",
            dialog = "613250",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1608/15.mp3",
            dialog = "613251",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1608",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1608",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1608",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1608",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1609] = {
    bn_name = "300008",
    bn_icon = "icons/role/list/lb_r_609.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_609.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1609/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1609/1.mp3",
            dialog = "613252",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1609/2.mp3",
            dialog = "613253",
            voiceTime = 4
        },
        action3 = {
            voice = "music/ui/signboradgirl_1609/3.mp3",
            dialog = "613254",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1609/4.mp3",
            dialog = "613255",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1609/5.mp3",
            dialog = "613256",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1609/6.mp3",
            dialog = "613257",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1609/7.mp3",
            dialog = "613258",
            voiceTime = 2
        },
        action8 = {
            voice = "music/ui/signboradgirl_1609/8.mp3",
            dialog = "613259",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1609/9.mp3",
            dialog = "613260",
            voiceTime = 4
        },
        action10 = {
            voice = "music/ui/signboradgirl_1609/10.mp3",
            dialog = "613261",
            voiceTime = 6
        },
        action11 = {
            voice = "music/ui/signboradgirl_1609/11.mp3",
            dialog = "613262",
            voiceTime = 5
        },
        action12 = {
            voice = "music/ui/signboradgirl_1609/12.mp3",
            dialog = "613263",
            voiceTime = 1
        },
        action13 = {
            voice = "music/ui/signboradgirl_1609/13.mp3",
            dialog = "613264",
            voiceTime = 5
        },
        action14 = {
            voice = "music/ui/signboradgirl_1609/14.mp3",
            dialog = "613265",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1609/15.mp3",
            dialog = "613266",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =609,  --共鸣绑定ID,
    hero_id = 609,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "613252",
        "613253",
        "613254",
        "613255",
        "613256",
        "613257",
        "613258",
        "613259",
        "613260",
        "613261",
        "613262",
        "613263",
        "613264",
        "613265",
        "613266",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1609/1.mp3",
            dialog = "613252",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1609/2.mp3",
            dialog = "613253",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1609/3.mp3",
            dialog = "613254",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1609/4.mp3",
            dialog = "613255",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1609/5.mp3",
            dialog = "613256",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1609/6.mp3",
            dialog = "613257",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1609/7.mp3",
            dialog = "613258",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1609/8.mp3",
            dialog = "613259",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1609/9.mp3",
            dialog = "613260",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1609/10.mp3",
            dialog = "613261",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1609/11.mp3",
            dialog = "613262",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1609/12.mp3",
            dialog = "613263",
            voiceTime = 1
        },
        {
            voice = "music/ui/signboradgirl_1609/13.mp3",
            dialog = "613264",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1609/14.mp3",
            dialog = "613265",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1609/15.mp3",
            dialog = "613266",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1609",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1609",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1609",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1609",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1610] = {
    bn_name = "300009",
    bn_icon = "icons/role/list/lb_r_610.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_610.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1610/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1610/1.mp3",
            dialog = "613267",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1610/2.mp3",
            dialog = "613268",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1610/3.mp3",
            dialog = "613269",
            voiceTime = 5
        },
        action4 = {
            voice = "music/ui/signboradgirl_1610/4.mp3",
            dialog = "613270",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1610/5.mp3",
            dialog = "613271",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1610/6.mp3",
            dialog = "613272",
            voiceTime = 2
        },
        action7 = {
            voice = "music/ui/signboradgirl_1610/7.mp3",
            dialog = "613273",
            voiceTime = 6
        },
        action8 = {
            voice = "music/ui/signboradgirl_1610/8.mp3",
            dialog = "613274",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1610/9.mp3",
            dialog = "613275",
            voiceTime = 8
        },
        action10 = {
            voice = "music/ui/signboradgirl_1610/10.mp3",
            dialog = "613276",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1610/11.mp3",
            dialog = "613277",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1610/12.mp3",
            dialog = "613278",
            voiceTime = 10
        },
        action13 = {
            voice = "music/ui/signboradgirl_1610/13.mp3",
            dialog = "613279",
            voiceTime = 4
        },
        action14 = {
            voice = "music/ui/signboradgirl_1610/14.mp3",
            dialog = "613280",
            voiceTime = 1
        },
        action15 = {
            voice = "music/ui/signboradgirl_1610/15.mp3",
            dialog = "613281",
            voiceTime = 5
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =610,  --共鸣绑定ID,
    hero_id = 610,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "613267",
        "613268",
        "613269",
        "613270",
        "613271",
        "613272",
        "613273",
        "613274",
        "613275",
        "613276",
        "613277",
        "613278",
        "613279",
        "613280",
        "613281",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1610/1.mp3",
            dialog = "613267",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1610/2.mp3",
            dialog = "613268",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1610/3.mp3",
            dialog = "613269",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1610/4.mp3",
            dialog = "613270",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1610/5.mp3",
            dialog = "613271",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1610/6.mp3",
            dialog = "613272",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1610/7.mp3",
            dialog = "613273",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1610/8.mp3",
            dialog = "613274",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1610/9.mp3",
            dialog = "613275",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1610/10.mp3",
            dialog = "613276",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1610/11.mp3",
            dialog = "613277",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1610/12.mp3",
            dialog = "613278",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1610/13.mp3",
            dialog = "613279",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1610/14.mp3",
            dialog = "613280",
            voiceTime = 1
        },
        {
            voice = "music/ui/signboradgirl_1610/15.mp3",
            dialog = "613281",
            voiceTime = 5
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1610",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1610",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1610",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1610",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1611] = {
    bn_name = "300010",
    bn_icon = "icons/role/list/lb_r_611.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_611.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1611/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1611/1.mp3",
            dialog = "613282",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1611/2.mp3",
            dialog = "613283",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1611/3.mp3",
            dialog = "613284",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1611/4.mp3",
            dialog = "613285",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1611/5.mp3",
            dialog = "613286",
            voiceTime = 2
        },
        action6 = {
            voice = "music/ui/signboradgirl_1611/6.mp3",
            dialog = "613287",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1611/7.mp3",
            dialog = "613288",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1611/8.mp3",
            dialog = "613289",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1611/9.mp3",
            dialog = "613290",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1611/10.mp3",
            dialog = "613291",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1611/11.mp3",
            dialog = "613292",
            voiceTime = 4
        },
        action12 = {
            voice = "music/ui/signboradgirl_1611/12.mp3",
            dialog = "613293",
            voiceTime = 4
        },
        action13 = {
            voice = "music/ui/signboradgirl_1611/13.mp3",
            dialog = "613294",
            voiceTime = 2
        },
        action14 = {
            voice = "music/ui/signboradgirl_1611/14.mp3",
            dialog = "613295",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1611/15.mp3",
            dialog = "613296",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =611,  --共鸣绑定ID,
    hero_id = 611,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "613282",
        "613283",
        "613284",
        "613285",
        "613286",
        "613287",
        "613288",
        "613289",
        "613290",
        "613291",
        "613292",
        "613293",
        "613294",
        "613295",
        "613296",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1611/1.mp3",
            dialog = "613282",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1611/2.mp3",
            dialog = "613283",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1611/3.mp3",
            dialog = "613284",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1611/4.mp3",
            dialog = "613285",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1611/5.mp3",
            dialog = "613286",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1611/6.mp3",
            dialog = "613287",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1611/7.mp3",
            dialog = "613288",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1611/8.mp3",
            dialog = "613289",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1611/9.mp3",
            dialog = "613290",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1611/10.mp3",
            dialog = "613291",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1611/11.mp3",
            dialog = "613292",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1611/12.mp3",
            dialog = "613293",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1611/13.mp3",
            dialog = "613294",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1611/14.mp3",
            dialog = "613295",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1611/15.mp3",
            dialog = "613296",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1611",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1611",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1611",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1611",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1525] = {
    bn_name = "300011",
    bn_icon = "icons/role/list/lb_r_525.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_525.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1525/1.mp3",
            dialog = "601241",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1525/2.mp3",
            dialog = "601242",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1525/3.mp3",
            dialog = "601243",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1525/4.mp3",
            dialog = "601244",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1525/5.mp3",
            dialog = "601245",
            voiceTime = 2
        },
        action6 = {
            voice = "music/ui/signboradgirl_1525/6.mp3",
            dialog = "601246",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1525/7.mp3",
            dialog = "601247",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1525/8.mp3",
            dialog = "601248",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1525/9.mp3",
            dialog = "601249",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1525/10.mp3",
            dialog = "601250",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1525/11.mp3",
            dialog = "601251",
            voiceTime = 4
        },
        action12 = {
            voice = "music/ui/signboradgirl_1525/12.mp3",
            dialog = "601252",
            voiceTime = 4
        },
        action13 = {
            voice = "music/ui/signboradgirl_1525/13.mp3",
            dialog = "601253",
            voiceTime = 2
        },
        action14 = {
            voice = "music/ui/signboradgirl_1525/14.mp3",
            dialog = "601254",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1525/15.mp3",
            dialog = "601255",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =525,  --共鸣绑定ID,
    hero_id = 525,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "601241",
        "601242",
        "601243",
        "601244",
        "601245",
        "601246",
        "601247",
        "601248",
        "601249",
        "601250",
        "601251",
        "601252",
        "601253",
        "601254",
        "601255",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1525/1.mp3",
            dialog = "601241",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1525/2.mp3",
            dialog = "601242",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1525/3.mp3",
            dialog = "601243",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1525/4.mp3",
            dialog = "601244",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1525/5.mp3",
            dialog = "601245",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1525/6.mp3",
            dialog = "601246",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1525/7.mp3",
            dialog = "601247",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1525/8.mp3",
            dialog = "601248",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1525/9.mp3",
            dialog = "601249",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1525/10.mp3",
            dialog = "601250",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1525/11.mp3",
            dialog = "601251",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1525/12.mp3",
            dialog = "601252",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1525/13.mp3",
            dialog = "601253",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1525/14.mp3",
            dialog = "601254",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1525/15.mp3",
            dialog = "601255",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1525",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1525",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1525",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1525",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1524] = {
    bn_name = "300012",
    bn_icon = "icons/role/list/lb_r_524.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_524.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1524/1.mp3",
            dialog = "601256",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1524/2.mp3",
            dialog = "601257",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1524/3.mp3",
            dialog = "601258",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1524/4.mp3",
            dialog = "601259",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1524/5.mp3",
            dialog = "601260",
            voiceTime = 2
        },
        action6 = {
            voice = "music/ui/signboradgirl_1524/6.mp3",
            dialog = "601261",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1524/7.mp3",
            dialog = "601262",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1524/8.mp3",
            dialog = "601263",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1524/9.mp3",
            dialog = "601264",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1524/10.mp3",
            dialog = "601265",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1524/11.mp3",
            dialog = "601266",
            voiceTime = 4
        },
        action12 = {
            voice = "music/ui/signboradgirl_1524/12.mp3",
            dialog = "601267",
            voiceTime = 4
        },
        action13 = {
            voice = "music/ui/signboradgirl_1524/13.mp3",
            dialog = "601268",
            voiceTime = 2
        },
        action14 = {
            voice = "music/ui/signboradgirl_1524/14.mp3",
            dialog = "601269",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1524/15.mp3",
            dialog = "601270",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =524,  --共鸣绑定ID,
    hero_id = 524,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "601256",
        "601257",
        "601258",
        "601259",
        "601260",
        "601261",
        "601262",
        "601263",
        "601264",
        "601265",
        "601266",
        "601267",
        "601268",
        "601269",
        "601270",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1524/1.mp3",
            dialog = "601256",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1524/2.mp3",
            dialog = "601257",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1524/3.mp3",
            dialog = "601258",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1524/4.mp3",
            dialog = "601259",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1524/5.mp3",
            dialog = "601260",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1524/6.mp3",
            dialog = "601261",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1524/7.mp3",
            dialog = "601262",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1524/8.mp3",
            dialog = "601263",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1524/9.mp3",
            dialog = "601264",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1524/10.mp3",
            dialog = "601265",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1524/11.mp3",
            dialog = "601266",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1524/12.mp3",
            dialog = "601267",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1524/13.mp3",
            dialog = "601268",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1524/14.mp3",
            dialog = "601269",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1524/15.mp3",
            dialog = "601270",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1524",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1524",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1524",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1524",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1355] = {
    bn_name = "300014",
    bn_icon = "icons/role/list/lb_r_355.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_355.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ 
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1355/1.mp3",
            dialog = "614544",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1355/2.mp3",
            dialog = "614545",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1355/3.mp3",
            dialog = "614546",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1355/4.mp3",
            dialog = "614547",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1355/5.mp3",
            dialog = "614548",
            voiceTime = 2
        },
        action6 = {
            voice = "music/ui/signboradgirl_1355/6.mp3",
            dialog = "614549",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1355/7.mp3",
            dialog = "614550",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1355/8.mp3",
            dialog = "614551",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1355/9.mp3",
            dialog = "614552",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1355/10.mp3",
            dialog = "614553",
            voiceTime = 5
        },
        action11 = {
            voice = "music/ui/signboradgirl_1355/11.mp3",
            dialog = "614554",
            voiceTime = 4
        },
        action12 = {
            voice = "music/ui/signboradgirl_1355/12.mp3",
            dialog = "614555",
            voiceTime = 4
        },
        action13 = {
            voice = "music/ui/signboradgirl_1355/13.mp3",
            dialog = "614556",
            voiceTime = 2
        },
        action14 = {
            voice = "music/ui/signboradgirl_1355/14.mp3",
            dialog = "614557",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1355/15.mp3",
            dialog = "614558",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =355,  --共鸣绑定ID,
    hero_id = 355,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "614544",
        "614545",
        "614546",
        "614547",
        "614548",
        "614549",
        "614550",
        "614551",
        "614552",
        "614553",
        "614554",
        "614555",
        "614556",
        "614557",
        "614558",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1355/1.mp3",
            dialog = "614544",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1355/2.mp3",
            dialog = "614545",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1355/3.mp3",
            dialog = "614546",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1355/4.mp3",
            dialog = "614547",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1355/5.mp3",
            dialog = "614548",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1355/6.mp3",
            dialog = "614549",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1355/7.mp3",
            dialog = "614550",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1355/8.mp3",
            dialog = "614551",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1355/9.mp3",
            dialog = "614552",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1355/10.mp3",
            dialog = "614553",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1355/11.mp3",
            dialog = "614554",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1355/12.mp3",
            dialog = "614555",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1355/13.mp3",
            dialog = "614556",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1355/14.mp3",
            dialog = "614557",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1355/15.mp3",
            dialog = "614558",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1355",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1355",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1355",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1355",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1700] = {
    bn_name = "300015",
    bn_icon = "icons/role/list/lb_r_700.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_700.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1700/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1700/1.mp3",
            dialog = "614651",
            voiceTime = 10
        },
        action2 = {
            voice = "music/ui/signboradgirl_1700/2.mp3",
            dialog = "614652",
            voiceTime = 7
        },
        action3 = {
            voice = "music/ui/signboradgirl_1700/3.mp3",
            dialog = "614653",
            voiceTime = 4
        },
        action4 = {
            voice = "music/ui/signboradgirl_1700/4.mp3",
            dialog = "614654",
            voiceTime = 10
        },
        action5 = {
            voice = "music/ui/signboradgirl_1700/5.mp3",
            dialog = "614655",
            voiceTime = 11
        },
        action6 = {
            voice = "music/ui/signboradgirl_1700/6.mp3",
            dialog = "614656",
            voiceTime = 8
        },
        action7 = {
            voice = "music/ui/signboradgirl_1700/7.mp3",
            dialog = "614657",
            voiceTime = 6
        },
        action8 = {
            voice = "music/ui/signboradgirl_1700/8.mp3",
            dialog = "614658",
            voiceTime = 5
        },
        action9 = {
            voice = "music/ui/signboradgirl_1700/9.mp3",
            dialog = "614659",
            voiceTime = 8
        },
        action10 = {
            voice = "music/ui/signboradgirl_1700/10.mp3",
            dialog = "614660",
            voiceTime = 8
        },
        action11 = {
            voice = "music/ui/signboradgirl_1700/11.mp3",
            dialog = "614661",
            voiceTime = 8
        },
        action12 = {
            voice = "music/ui/signboradgirl_1700/12.mp3",
            dialog = "614662",
            voiceTime = 13
        },
        action13 = {
            voice = "music/ui/signboradgirl_1700/13.mp3",
            dialog = "614663",
            voiceTime = 6
        },
        action14 = {
            voice = "music/ui/signboradgirl_1700/14.mp3",
            dialog = "614664",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1700/15.mp3",
            dialog = "614665",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =700,  --共鸣绑定ID,
    hero_id = 700,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "614651",
        "614652",
        "614653",
        "614654",
        "614655",
        "614656",
        "614657",
        "614658",
        "614659",
        "614660",
        "614661",
        "614662",
        "614663",
        "614664",
        "614665",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1700/1.mp3",
            dialog = "614651",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1700/2.mp3",
            dialog = "614652",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1700/3.mp3",
            dialog = "614653",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1700/4.mp3",
            dialog = "614654",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1700/5.mp3",
            dialog = "614655",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1700/6.mp3",
            dialog = "614656",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1700/7.mp3",
            dialog = "614657",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1700/8.mp3",
            dialog = "614658",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1700/9.mp3",
            dialog = "614659",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1700/10.mp3",
            dialog = "614660",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1700/11.mp3",
            dialog = "614661",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1700/12.mp3",
            dialog = "614662",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1700/13.mp3",
            dialog = "614663",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1700/14.mp3",
            dialog = "614664",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1700/15.mp3",
            dialog = "614665",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1700",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1700",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1700",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1700",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1702] = {
    bn_name = "300016",
    bn_icon = "icons/role/list/lb_r_702.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_702.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1702/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1702/1.mp3",
            dialog = "614666",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1702/2.mp3",
            dialog = "614667",
            voiceTime = 5
        },
        action3 = {
            voice = "music/ui/signboradgirl_1702/3.mp3",
            dialog = "614668",
            voiceTime = 8
        },
        action4 = {
            voice = "music/ui/signboradgirl_1702/4.mp3",
            dialog = "614669",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1702/5.mp3",
            dialog = "614670",
            voiceTime = 6
        },
        action6 = {
            voice = "music/ui/signboradgirl_1702/6.mp3",
            dialog = "614671",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1702/7.mp3",
            dialog = "614672",
            voiceTime = 8
        },
        action8 = {
            voice = "music/ui/signboradgirl_1702/8.mp3",
            dialog = "614673",
            voiceTime = 5
        },
        action9 = {
            voice = "music/ui/signboradgirl_1702/9.mp3",
            dialog = "614674",
            voiceTime = 12
        },
        action10 = {
            voice = "music/ui/signboradgirl_1702/10.mp3",
            dialog = "614675",
            voiceTime = 9
        },
        action11 = {
            voice = "music/ui/signboradgirl_1702/11.mp3",
            dialog = "614676",
            voiceTime = 16
        },
        action12 = {
            voice = "music/ui/signboradgirl_1702/12.mp3",
            dialog = "614677",
            voiceTime = 8
        },
        action13 = {
            voice = "music/ui/signboradgirl_1702/13.mp3",
            dialog = "614678",
            voiceTime = 6
        },
        action14 = {
            voice = "music/ui/signboradgirl_1702/14.mp3",
            dialog = "614679",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1702/15.mp3",
            dialog = "614680",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =702,  --共鸣绑定ID,
    hero_id = 702,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "614666",
        "614667",
        "614668",
        "614669",
        "614670",
        "614671",
        "614672",
        "614673",
        "614674",
        "614675",
        "614676",
        "614677",
        "614678",
        "614679",
        "614680",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1702/1.mp3",
            dialog = "614666",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1702/2.mp3",
            dialog = "614667",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1702/3.mp3",
            dialog = "614668",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1702/4.mp3",
            dialog = "614669",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1702/5.mp3",
            dialog = "614670",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1702/6.mp3",
            dialog = "614671",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1702/7.mp3",
            dialog = "614672",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1702/8.mp3",
            dialog = "614673",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1702/9.mp3",
            dialog = "614674",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1702/10.mp3",
            dialog = "614675",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1702/11.mp3",
            dialog = "614676",
            voiceTime = 16
        },
        {
            voice = "music/ui/signboradgirl_1702/12.mp3",
            dialog = "614677",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1702/13.mp3",
            dialog = "614678",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1702/14.mp3",
            dialog = "614679",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1702/15.mp3",
            dialog = "614680",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1702",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1702",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1702",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1702",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1703] = {
    bn_name = "300017",
    bn_icon = "icons/role/list/lb_r_703.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_703.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1703/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1703/1.mp3",
            dialog = "614681",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1703/2.mp3",
            dialog = "614682",
            voiceTime = 1
        },
        action3 = {
            voice = "music/ui/signboradgirl_1703/3.mp3",
            dialog = "614683",
            voiceTime = 2
        },
        action4 = {
            voice = "music/ui/signboradgirl_1703/4.mp3",
            dialog = "614684",
            voiceTime = 7
        },
        action5 = {
            voice = "music/ui/signboradgirl_1703/5.mp3",
            dialog = "614685",
            voiceTime = 6
        },
        action6 = {
            voice = "music/ui/signboradgirl_1703/6.mp3",
            dialog = "614686",
            voiceTime = 5
        },
        action7 = {
            voice = "music/ui/signboradgirl_1703/7.mp3",
            dialog = "614687",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1703/8.mp3",
            dialog = "614688",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1703/9.mp3",
            dialog = "614689",
            voiceTime = 4
        },
        action10 = {
            voice = "music/ui/signboradgirl_1703/10.mp3",
            dialog = "614690",
            voiceTime = 18
        },
        action11 = {
            voice = "music/ui/signboradgirl_1703/11.mp3",
            dialog = "614691",
            voiceTime = 9
        },
        action12 = {
            voice = "music/ui/signboradgirl_1703/12.mp3",
            dialog = "614692",
            voiceTime = 6
        },
        action13 = {
            voice = "music/ui/signboradgirl_1703/13.mp3",
            dialog = "614693",
            voiceTime = 8
        },
        action14 = {
            voice = "music/ui/signboradgirl_1703/14.mp3",
            dialog = "614694",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1703/15.mp3",
            dialog = "614695",
            voiceTime = 5
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =703,  --共鸣绑定ID,
    hero_id = 703,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "614681",
        "614682",
        "614683",
        "614684",
        "614685",
        "614686",
        "614687",
        "614688",
        "614689",
        "614690",
        "614691",
        "614692",
        "614693",
        "614694",
        "614695",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1703/1.mp3",
            dialog = "614681",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1703/2.mp3",
            dialog = "614682",
            voiceTime = 1
        },
        {
            voice = "music/ui/signboradgirl_1703/3.mp3",
            dialog = "614683",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1703/4.mp3",
            dialog = "614684",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1703/5.mp3",
            dialog = "614685",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1703/6.mp3",
            dialog = "614686",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1703/7.mp3",
            dialog = "614687",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1703/8.mp3",
            dialog = "614688",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1703/9.mp3",
            dialog = "614689",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1703/10.mp3",
            dialog = "614690",
            voiceTime = 18
        },
        {
            voice = "music/ui/signboradgirl_1703/11.mp3",
            dialog = "614691",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1703/12.mp3",
            dialog = "614692",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1703/13.mp3",
            dialog = "614693",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1703/14.mp3",
            dialog = "614694",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1703/15.mp3",
            dialog = "614695",
            voiceTime = 5
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1703",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1703",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1703",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1703",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1705] = {
    bn_name = "300019",
    bn_icon = "icons/role/list/lb_r_705.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_705.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1705/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1705/1.mp3",
            dialog = "614711",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1705/2.mp3",
            dialog = "614712",
            voiceTime = 2
        },
        action3 = {
            voice = "music/ui/signboradgirl_1705/3.mp3",
            dialog = "614713",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1705/4.mp3",
            dialog = "614714",
            voiceTime = 2
        },
        action5 = {
            voice = "music/ui/signboradgirl_1705/5.mp3",
            dialog = "614715",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1705/6.mp3",
            dialog = "614716",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1705/7.mp3",
            dialog = "614717",
            voiceTime = 5
        },
        action8 = {
            voice = "music/ui/signboradgirl_1705/8.mp3",
            dialog = "614718",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1705/9.mp3",
            dialog = "614719",
            voiceTime = 7
        },
        action10 = {
            voice = "music/ui/signboradgirl_1705/10.mp3",
            dialog = "614720",
            voiceTime = 9
        },
        action11 = {
            voice = "music/ui/signboradgirl_1705/11.mp3",
            dialog = "614721",
            voiceTime = 9
        },
        action12 = {
            voice = "music/ui/signboradgirl_1705/12.mp3",
            dialog = "614722",
            voiceTime = 14
        },
        action13 = {
            voice = "music/ui/signboradgirl_1705/13.mp3",
            dialog = "614723",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1705/14.mp3",
            dialog = "614724",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1705/15.mp3",
            dialog = "614725",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =705,  --共鸣绑定ID,
    hero_id = 705,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "614711",
        "614712",
        "614713",
        "614714",
        "614715",
        "614716",
        "614717",
        "614718",
        "614719",
        "614720",
        "614721",
        "614722",
        "614723",
        "614724",
        "614725",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1705/1.mp3",
            dialog = "614711",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1705/2.mp3",
            dialog = "614712",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1705/3.mp3",
            dialog = "614713",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1705/4.mp3",
            dialog = "614714",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1705/5.mp3",
            dialog = "614715",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1705/6.mp3",
            dialog = "614716",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1705/7.mp3",
            dialog = "614717",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1705/8.mp3",
            dialog = "614718",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1705/9.mp3",
            dialog = "614719",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1705/10.mp3",
            dialog = "614720",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1705/11.mp3",
            dialog = "614721",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1705/12.mp3",
            dialog = "614722",
            voiceTime = 14
        },
        {
            voice = "music/ui/signboradgirl_1705/13.mp3",
            dialog = "614723",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1705/14.mp3",
            dialog = "614724",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1705/15.mp3",
            dialog = "614725",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1705",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1705",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1705",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1705",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1393] = {
    bn_name = "300020",
    bn_icon = "icons/role/list/lb_r_393.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_393.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1393/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1393/1.mp3",
            dialog = "614726",
            voiceTime = 1
        },
        action2 = {
            voice = "music/ui/signboradgirl_1393/2.mp3",
            dialog = "614727",
            voiceTime = 1
        },
        action3 = {
            voice = "music/ui/signboradgirl_1393/3.mp3",
            dialog = "614728",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1393/4.mp3",
            dialog = "614729",
            voiceTime = 5
        },
        action5 = {
            voice = "music/ui/signboradgirl_1393/5.mp3",
            dialog = "614730",
            voiceTime = 6
        },
        action6 = {
            voice = "music/ui/signboradgirl_1393/6.mp3",
            dialog = "614731",
            voiceTime = 5
        },
        action7 = {
            voice = "music/ui/signboradgirl_1393/7.mp3",
            dialog = "614732",
            voiceTime = 12
        },
        action8 = {
            voice = "music/ui/signboradgirl_1393/8.mp3",
            dialog = "614733",
            voiceTime = 7
        },
        action9 = {
            voice = "music/ui/signboradgirl_1393/9.mp3",
            dialog = "614734",
            voiceTime = 6
        },
        action10 = {
            voice = "music/ui/signboradgirl_1393/10.mp3",
            dialog = "614735",
            voiceTime = 11
        },
        action11 = {
            voice = "music/ui/signboradgirl_1393/11.mp3",
            dialog = "614736",
            voiceTime = 9
        },
        action12 = {
            voice = "music/ui/signboradgirl_1393/12.mp3",
            dialog = "614737",
            voiceTime = 7
        },
        action13 = {
            voice = "music/ui/signboradgirl_1393/13.mp3",
            dialog = "614738",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1393/14.mp3",
            dialog = "614739",
            voiceTime = 2
        },
        action15 = {
            voice = "music/ui/signboradgirl_1393/15.mp3",
            dialog = "614740",
            voiceTime = 5
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =393,  --共鸣绑定ID,
    hero_id = 393,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "614726",
        "614727",
        "614728",
        "614729",
        "614730",
        "614731",
        "614732",
        "614733",
        "614734",
        "614735",
        "614736",
        "614737",
        "614738",
        "614739",
        "614740",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1393/1.mp3",
            dialog = "614726",
            voiceTime = 1
        },
        {
            voice = "music/ui/signboradgirl_1393/2.mp3",
            dialog = "614727",
            voiceTime = 1
        },
        {
            voice = "music/ui/signboradgirl_1393/3.mp3",
            dialog = "614728",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1393/4.mp3",
            dialog = "614729",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1393/5.mp3",
            dialog = "614730",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1393/6.mp3",
            dialog = "614731",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1393/7.mp3",
            dialog = "614732",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1393/8.mp3",
            dialog = "614733",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1393/9.mp3",
            dialog = "614734",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1393/10.mp3",
            dialog = "614735",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1393/11.mp3",
            dialog = "614736",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1393/12.mp3",
            dialog = "614737",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1393/13.mp3",
            dialog = "614738",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1393/14.mp3",
            dialog = "614739",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1393/15.mp3",
            dialog = "614740",
            voiceTime = 5
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1393",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1393",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1393",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1393",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1511] = {
    bn_name = "300021",
    bn_icon = "icons/role/list/lb_r_511.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_511.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1511/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1511/1.mp3",
            dialog = "615649",
            voiceTime = 4
        },
        action2 = {
            voice = "music/ui/signboradgirl_1511/2.mp3",
            dialog = "615650",
            voiceTime = 11
        },
        action3 = {
            voice = "music/ui/signboradgirl_1511/3.mp3",
            dialog = "615651",
            voiceTime = 11
        },
        action4 = {
            voice = "music/ui/signboradgirl_1511/4.mp3",
            dialog = "615652",
            voiceTime = 6
        },
        action5 = {
            voice = "music/ui/signboradgirl_1511/5.mp3",
            dialog = "615653",
            voiceTime = 7
        },
        action6 = {
            voice = "music/ui/signboradgirl_1511/6.mp3",
            dialog = "615654",
            voiceTime = 13
        },
        action7 = {
            voice = "music/ui/signboradgirl_1511/7.mp3",
            dialog = "615655",
            voiceTime = 9
        },
        action8 = {
            voice = "music/ui/signboradgirl_1511/8.mp3",
            dialog = "615656",
            voiceTime = 8
        },
        action9 = {
            voice = "music/ui/signboradgirl_1511/9.mp3",
            dialog = "615657",
            voiceTime = 8
        },
        action10 = {
            voice = "music/ui/signboradgirl_1511/10.mp3",
            dialog = "615658",
            voiceTime = 12
        },
        action11 = {
            voice = "music/ui/signboradgirl_1511/11.mp3",
            dialog = "615659",
            voiceTime = 9
        },
        action12 = {
            voice = "music/ui/signboradgirl_1511/12.mp3",
            dialog = "615660",
            voiceTime = 8
        },
        action13 = {
            voice = "music/ui/signboradgirl_1511/13.mp3",
            dialog = "615661",
            voiceTime = 4
        },
        action14 = {
            voice = "music/ui/signboradgirl_1511/14.mp3",
            dialog = "615662",
            voiceTime = 5
        },
        action15 = {
            voice = "music/ui/signboradgirl_1511/15.mp3",
            dialog = "615663",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =511,  --共鸣绑定ID,
    hero_id = 511,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "615649",
        "615650",
        "615651",
        "615652",
        "615653",
        "615654",
        "615655",
        "615656",
        "615657",
        "615658",
        "615659",
        "615660",
        "615661",
        "615662",
        "615663",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1511/1.mp3",
            dialog = "615649",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1511/2.mp3",
            dialog = "615650",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1511/3.mp3",
            dialog = "615651",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1511/4.mp3",
            dialog = "615652",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1511/5.mp3",
            dialog = "615653",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1511/6.mp3",
            dialog = "615654",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1511/7.mp3",
            dialog = "615655",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1511/8.mp3",
            dialog = "615656",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1511/9.mp3",
            dialog = "615657",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1511/10.mp3",
            dialog = "615658",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1511/11.mp3",
            dialog = "615659",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1511/12.mp3",
            dialog = "615660",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1511/13.mp3",
            dialog = "615661",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1511/14.mp3",
            dialog = "615662",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1511/15.mp3",
            dialog = "615663",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1511",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1511",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1511",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1511",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1503] = {
    bn_name = "300022",
    bn_icon = "icons/role/list/lb_r_503.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_503.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1503/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1503/1.mp3",
            dialog = "615671",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1503/2.mp3",
            dialog = "615672",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1503/3.mp3",
            dialog = "615673",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1503/4.mp3",
            dialog = "615674",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1503/5.mp3",
            dialog = "615675",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1503/6.mp3",
            dialog = "615676",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1503/7.mp3",
            dialog = "615677",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1503/8.mp3",
            dialog = "615678",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1503/9.mp3",
            dialog = "615679",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1503/10.mp3",
            dialog = "615680",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1503/11.mp3",
            dialog = "615681",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1503/12.mp3",
            dialog = "615682",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1503/13.mp3",
            dialog = "615683",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1503/14.mp3",
            dialog = "615684",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1503/15.mp3",
            dialog = "615685",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =503,  --共鸣绑定ID,
    hero_id = 503,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "615671",
        "615672",
        "615673",
        "615674",
        "615675",
        "615676",
        "615677",
        "615678",
        "615679",
        "615680",
        "615681",
        "615682",
        "615683",
        "615684",
        "615685",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1503/1.mp3",
            dialog = "615671",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/2.mp3",
            dialog = "615672",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/3.mp3",
            dialog = "615673",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/4.mp3",
            dialog = "615674",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/5.mp3",
            dialog = "615675",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/6.mp3",
            dialog = "615676",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/7.mp3",
            dialog = "615677",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/8.mp3",
            dialog = "615678",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/9.mp3",
            dialog = "615679",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/10.mp3",
            dialog = "615680",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/11.mp3",
            dialog = "615681",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/12.mp3",
            dialog = "615682",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/13.mp3",
            dialog = "615683",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/14.mp3",
            dialog = "615684",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1503/15.mp3",
            dialog = "615685",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1503",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1503",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1503",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1503",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1534] = {
    bn_name = "300023",
    bn_icon = "icons/role/list/lb_r_534.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_534.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1534/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1534/1.mp3",
            dialog = "615693",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1534/2.mp3",
            dialog = "615694",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1534/3.mp3",
            dialog = "615695",
            voiceTime = 4
        },
        action4 = {
            voice = "music/ui/signboradgirl_1534/4.mp3",
            dialog = "615696",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1534/5.mp3",
            dialog = "615697",
            voiceTime = 9
        },
        action6 = {
            voice = "music/ui/signboradgirl_1534/6.mp3",
            dialog = "615698",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1534/7.mp3",
            dialog = "615699",
            voiceTime = 5
        },
        action8 = {
            voice = "music/ui/signboradgirl_1534/8.mp3",
            dialog = "615700",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1534/9.mp3",
            dialog = "615701",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1534/10.mp3",
            dialog = "615702",
            voiceTime = 7
        },
        action11 = {
            voice = "music/ui/signboradgirl_1534/11.mp3",
            dialog = "615703",
            voiceTime = 10
        },
        action12 = {
            voice = "music/ui/signboradgirl_1534/12.mp3",
            dialog = "615704",
            voiceTime = 7
        },
        action13 = {
            voice = "music/ui/signboradgirl_1534/13.mp3",
            dialog = "615705",
            voiceTime = 4
        },
        action14 = {
            voice = "music/ui/signboradgirl_1534/14.mp3",
            dialog = "615706",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1534/15.mp3",
            dialog = "615707",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =534,  --共鸣绑定ID,
    hero_id = 534,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "615693",
        "615694",
        "615695",
        "615696",
        "615697",
        "615698",
        "615699",
        "615700",
        "615701",
        "615702",
        "615703",
        "615704",
        "615705",
        "615706",
        "615707",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1534/1.mp3",
            dialog = "615693",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1534/2.mp3",
            dialog = "615694",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1534/3.mp3",
            dialog = "615695",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1534/4.mp3",
            dialog = "615696",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1534/5.mp3",
            dialog = "615697",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1534/6.mp3",
            dialog = "615698",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1534/7.mp3",
            dialog = "615699",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1534/8.mp3",
            dialog = "615700",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1534/9.mp3",
            dialog = "615701",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1534/10.mp3",
            dialog = "615702",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1534/11.mp3",
            dialog = "615703",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1534/12.mp3",
            dialog = "615704",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1534/13.mp3",
            dialog = "615705",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1534/14.mp3",
            dialog = "615706",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1534/15.mp3",
            dialog = "615707",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1534",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1534",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1534",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1534",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1514] = {
    bn_name = "300024",
    bn_icon = "icons/role/list/lb_r_514.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_514.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1514/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1514/1.mp3",
            dialog = "616182",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1514/2.mp3",
            dialog = "616183",
            voiceTime = 5
        },
        action3 = {
            voice = "music/ui/signboradgirl_1514/3.mp3",
            dialog = "616184",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1514/4.mp3",
            dialog = "616185",
            voiceTime = 5
        },
        action5 = {
            voice = "music/ui/signboradgirl_1514/5.mp3",
            dialog = "616186",
            voiceTime = 6
        },
        action6 = {
            voice = "music/ui/signboradgirl_1514/6.mp3",
            dialog = "616187",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1514/7.mp3",
            dialog = "616188",
            voiceTime = 7
        },
        action8 = {
            voice = "music/ui/signboradgirl_1514/8.mp3",
            dialog = "616189",
            voiceTime = 8
        },
        action9 = {
            voice = "music/ui/signboradgirl_1514/9.mp3",
            dialog = "616190",
            voiceTime = 4
        },
        action10 = {
            voice = "music/ui/signboradgirl_1514/10.mp3",
            dialog = "616191",
            voiceTime = 8
        },
        action11 = {
            voice = "music/ui/signboradgirl_1514/11.mp3",
            dialog = "616192",
            voiceTime = 11
        },
        action12 = {
            voice = "music/ui/signboradgirl_1514/12.mp3",
            dialog = "616193",
            voiceTime = 8
        },
        action13 = {
            voice = "music/ui/signboradgirl_1514/13.mp3",
            dialog = "616194",
            voiceTime = 5
        },
        action14 = {
            voice = "music/ui/signboradgirl_1514/14.mp3",
            dialog = "616195",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1514/15.mp3",
            dialog = "616196",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =514,  --共鸣绑定ID,
    hero_id = 514,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616182",
        "616183",
        "616184",
        "616185",
        "616186",
        "616187",
        "616188",
        "616189",
        "616190",
        "616191",
        "616192",
        "616193",
        "616194",
        "616195",
        "616196",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1514/1.mp3",
            dialog = "616182",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1514/2.mp3",
            dialog = "616183",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1514/3.mp3",
            dialog = "616184",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1514/4.mp3",
            dialog = "616185",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1514/5.mp3",
            dialog = "616186",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1514/6.mp3",
            dialog = "616187",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1514/7.mp3",
            dialog = "616188",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1514/8.mp3",
            dialog = "616189",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1514/9.mp3",
            dialog = "616190",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1514/10.mp3",
            dialog = "616191",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1514/11.mp3",
            dialog = "616192",
            voiceTime = 11
        },
        {
            voice = "music/ui/signboradgirl_1514/12.mp3",
            dialog = "616193",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1514/13.mp3",
            dialog = "616194",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1514/14.mp3",
            dialog = "616195",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1514/15.mp3",
            dialog = "616196",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1514",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1514",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1514",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1514",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1513] = {
    bn_name = "300025",
    bn_icon = "icons/role/list/lb_r_513.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_513.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1513/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1513/1.mp3",
            dialog = "616156",
            voiceTime = 5
        },
        action2 = {
            voice = "music/ui/signboradgirl_1513/2.mp3",
            dialog = "616157",
            voiceTime = 2
        },
        action3 = {
            voice = "music/ui/signboradgirl_1513/3.mp3",
            dialog = "616158",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1513/4.mp3",
            dialog = "616159",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1513/5.mp3",
            dialog = "616160",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1513/6.mp3",
            dialog = "616161",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1513/7.mp3",
            dialog = "616162",
            voiceTime = 9
        },
        action8 = {
            voice = "music/ui/signboradgirl_1513/8.mp3",
            dialog = "616163",
            voiceTime = 8
        },
        action9 = {
            voice = "music/ui/signboradgirl_1513/9.mp3",
            dialog = "616164",
            voiceTime = 5
        },
        action10 = {
            voice = "music/ui/signboradgirl_1513/10.mp3",
            dialog = "616165",
            voiceTime = 9
        },
        action11 = {
            voice = "music/ui/signboradgirl_1513/11.mp3",
            dialog = "616166",
            voiceTime = 12
        },
        action12 = {
            voice = "music/ui/signboradgirl_1513/12.mp3",
            dialog = "616167",
            voiceTime = 8
        },
        action13 = {
            voice = "music/ui/signboradgirl_1513/13.mp3",
            dialog = "616168",
            voiceTime = 4
        },
        action14 = {
            voice = "music/ui/signboradgirl_1513/14.mp3",
            dialog = "616169",
            voiceTime = 4
        },
        action15 = {
            voice = "music/ui/signboradgirl_1513/15.mp3",
            dialog = "616170",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =513,  --共鸣绑定ID,
    hero_id = 513,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616156",
        "616157",
        "616158",
        "616159",
        "616160",
        "616161",
        "616162",
        "616163",
        "616164",
        "616165",
        "616166",
        "616167",
        "616168",
        "616169",
        "616170",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1513/1.mp3",
            dialog = "616156",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1513/2.mp3",
            dialog = "616157",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1513/3.mp3",
            dialog = "616158",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1513/4.mp3",
            dialog = "616159",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1513/5.mp3",
            dialog = "616160",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1513/6.mp3",
            dialog = "616161",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1513/7.mp3",
            dialog = "616162",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1513/8.mp3",
            dialog = "616163",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1513/9.mp3",
            dialog = "616164",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1513/10.mp3",
            dialog = "616165",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1513/11.mp3",
            dialog = "616166",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1513/12.mp3",
            dialog = "616167",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1513/13.mp3",
            dialog = "616168",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1513/14.mp3",
            dialog = "616169",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1513/15.mp3",
            dialog = "616170",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1513",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1513",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1513",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1513",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1366] = {
    bn_name = "300026",
    bn_icon = "icons/role/list/lb_r_366.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_366.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1366/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1366/1.mp3",
            dialog = "616208",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1366/2.mp3",
            dialog = "616209",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1366/3.mp3",
            dialog = "616210",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1366/4.mp3",
            dialog = "616211",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1366/5.mp3",
            dialog = "616212",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1366/6.mp3",
            dialog = "616213",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1366/7.mp3",
            dialog = "616214",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1366/8.mp3",
            dialog = "616215",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1366/9.mp3",
            dialog = "616216",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1366/10.mp3",
            dialog = "616217",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1366/11.mp3",
            dialog = "616218",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1366/12.mp3",
            dialog = "616219",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1366/13.mp3",
            dialog = "616220",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1366/14.mp3",
            dialog = "616221",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1366/15.mp3",
            dialog = "616222",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =366,  --共鸣绑定ID,
    hero_id = 366,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616208",
        "616209",
        "616210",
        "616211",
        "616212",
        "616213",
        "616214",
        "616215",
        "616216",
        "616217",
        "616218",
        "616219",
        "616220",
        "616221",
        "616222",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1366/1.mp3",
            dialog = "616208",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/2.mp3",
            dialog = "616209",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/3.mp3",
            dialog = "616210",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/4.mp3",
            dialog = "616211",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/5.mp3",
            dialog = "616212",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/6.mp3",
            dialog = "616213",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/7.mp3",
            dialog = "616214",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/8.mp3",
            dialog = "616215",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/9.mp3",
            dialog = "616216",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/10.mp3",
            dialog = "616217",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/11.mp3",
            dialog = "616218",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/12.mp3",
            dialog = "616219",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/13.mp3",
            dialog = "616220",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/14.mp3",
            dialog = "616221",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1366/15.mp3",
            dialog = "616222",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1366",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1366",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1366",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1366",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1519] = {
    bn_name = "300027",
    bn_icon = "icons/role/list/lb_r_519.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_519.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1519/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1519/1.mp3",
            dialog = "616634",
            voiceTime = 4
        },
        action2 = {
            voice = "music/ui/signboradgirl_1519/2.mp3",
            dialog = "616635",
            voiceTime = 5
        },
        action3 = {
            voice = "music/ui/signboradgirl_1519/3.mp3",
            dialog = "616636",
            voiceTime = 4
        },
        action4 = {
            voice = "music/ui/signboradgirl_1519/4.mp3",
            dialog = "616637",
            voiceTime = 5
        },
        action5 = {
            voice = "music/ui/signboradgirl_1519/5.mp3",
            dialog = "616638",
            voiceTime = 6
        },
        action6 = {
            voice = "music/ui/signboradgirl_1519/6.mp3",
            dialog = "616639",
            voiceTime = 5
        },
        action7 = {
            voice = "music/ui/signboradgirl_1519/7.mp3",
            dialog = "616640",
            voiceTime = 4
        },
        action8 = {
            voice = "music/ui/signboradgirl_1519/8.mp3",
            dialog = "616641",
            voiceTime = 4
        },
        action9 = {
            voice = "music/ui/signboradgirl_1519/9.mp3",
            dialog = "616642",
            voiceTime = 10
        },
        action10 = {
            voice = "music/ui/signboradgirl_1519/10.mp3",
            dialog = "616643",
            voiceTime = 8
        },
        action11 = {
            voice = "music/ui/signboradgirl_1519/11.mp3",
            dialog = "616644",
            voiceTime = 10
        },
        action12 = {
            voice = "music/ui/signboradgirl_1519/12.mp3",
            dialog = "616645",
            voiceTime = 13
        },
        action13 = {
            voice = "music/ui/signboradgirl_1519/13.mp3",
            dialog = "616646",
            voiceTime = 5
        },
        action14 = {
            voice = "music/ui/signboradgirl_1519/14.mp3",
            dialog = "616647",
            voiceTime = 7
        },
        action15 = {
            voice = "music/ui/signboradgirl_1519/15.mp3",
            dialog = "616648",
            voiceTime = 5
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =519,  --共鸣绑定ID,
    hero_id = 519,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616634",
        "616635",
        "616636",
        "616637",
        "616638",
        "616639",
        "616640",
        "616641",
        "616642",
        "616643",
        "616644",
        "616645",
        "616646",
        "616647",
        "616648",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1519/1.mp3",
            dialog = "616634",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1519/2.mp3",
            dialog = "616635",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1519/3.mp3",
            dialog = "616636",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1519/4.mp3",
            dialog = "616637",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1519/5.mp3",
            dialog = "616638",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1519/6.mp3",
            dialog = "616639",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1519/7.mp3",
            dialog = "616640",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1519/8.mp3",
            dialog = "616641",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1519/9.mp3",
            dialog = "616642",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1519/10.mp3",
            dialog = "616643",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1519/11.mp3",
            dialog = "616644",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1519/12.mp3",
            dialog = "616645",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1519/13.mp3",
            dialog = "616646",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1519/14.mp3",
            dialog = "616647",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1519/15.mp3",
            dialog = "616648",
            voiceTime = 5
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1519",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1519",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1519",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1519",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1520] = {
    bn_name = "300028",
    bn_icon = "icons/role/list/lb_r_520.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_520.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1520/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1520/1.mp3",
            dialog = "616649",
            voiceTime = 4
        },
        action2 = {
            voice = "music/ui/signboradgirl_1520/2.mp3",
            dialog = "616650",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1520/3.mp3",
            dialog = "616651",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1520/4.mp3",
            dialog = "616652",
            voiceTime = 6
        },
        action5 = {
            voice = "music/ui/signboradgirl_1520/5.mp3",
            dialog = "616653",
            voiceTime = 6
        },
        action6 = {
            voice = "music/ui/signboradgirl_1520/6.mp3",
            dialog = "616654",
            voiceTime = 9
        },
        action7 = {
            voice = "music/ui/signboradgirl_1520/7.mp3",
            dialog = "616655",
            voiceTime = 12
        },
        action8 = {
            voice = "music/ui/signboradgirl_1520/8.mp3",
            dialog = "616656",
            voiceTime = 6
        },
        action9 = {
            voice = "music/ui/signboradgirl_1520/9.mp3",
            dialog = "616657",
            voiceTime = 5
        },
        action10 = {
            voice = "music/ui/signboradgirl_1520/10.mp3",
            dialog = "616658",
            voiceTime = 15
        },
        action11 = {
            voice = "music/ui/signboradgirl_1520/11.mp3",
            dialog = "616659",
            voiceTime = 8
        },
        action12 = {
            voice = "music/ui/signboradgirl_1520/12.mp3",
            dialog = "616660",
            voiceTime = 7
        },
        action13 = {
            voice = "music/ui/signboradgirl_1520/13.mp3",
            dialog = "616661",
            voiceTime = 4
        },
        action14 = {
            voice = "music/ui/signboradgirl_1520/14.mp3",
            dialog = "616662",
            voiceTime = 5
        },
        action15 = {
            voice = "music/ui/signboradgirl_1520/15.mp3",
            dialog = "616663",
            voiceTime = 6
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =520,  --共鸣绑定ID,
    hero_id = 520,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616649",
        "616650",
        "616651",
        "616652",
        "616653",
        "616654",
        "616655",
        "616656",
        "616657",
        "616658",
        "616659",
        "616660",
        "616661",
        "616662",
        "616663",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1520/1.mp3",
            dialog = "616649",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1520/2.mp3",
            dialog = "616650",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1520/3.mp3",
            dialog = "616651",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1520/4.mp3",
            dialog = "616652",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1520/5.mp3",
            dialog = "616653",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1520/6.mp3",
            dialog = "616654",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1520/7.mp3",
            dialog = "616655",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1520/8.mp3",
            dialog = "616656",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1520/9.mp3",
            dialog = "616657",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1520/10.mp3",
            dialog = "616658",
            voiceTime = 15
        },
        {
            voice = "music/ui/signboradgirl_1520/11.mp3",
            dialog = "616659",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1520/12.mp3",
            dialog = "616660",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1520/13.mp3",
            dialog = "616661",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1520/14.mp3",
            dialog = "616662",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1520/15.mp3",
            dialog = "616663",
            voiceTime = 6
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1520",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1520",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1520",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1520",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1502] = {
    bn_name = "300029",
    bn_icon = "icons/role/list/lb_r_502.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_502.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1502/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1502/1.mp3",
            dialog = "616898",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1502/2.mp3",
            dialog = "616899",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1502/3.mp3",
            dialog = "616900",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1502/4.mp3",
            dialog = "616901",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1502/5.mp3",
            dialog = "616902",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1502/6.mp3",
            dialog = "616903",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1502/7.mp3",
            dialog = "616904",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1502/8.mp3",
            dialog = "616905",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1502/9.mp3",
            dialog = "616906",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1502/10.mp3",
            dialog = "616907",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1502/11.mp3",
            dialog = "616908",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1502/12.mp3",
            dialog = "616909",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1502/13.mp3",
            dialog = "616910",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1502/14.mp3",
            dialog = "616911",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1502/15.mp3",
            dialog = "616912",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =502,  --共鸣绑定ID,
    hero_id = 502,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616898",
        "616899",
        "616900",
        "616901",
        "616902",
        "616903",
        "616904",
        "616905",
        "616906",
        "616907",
        "616908",
        "616909",
        "616910",
        "616911",
        "616912",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1502/1.mp3",
            dialog = "616898",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/2.mp3",
            dialog = "616899",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/3.mp3",
            dialog = "616900",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/4.mp3",
            dialog = "616901",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/5.mp3",
            dialog = "616902",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/6.mp3",
            dialog = "616903",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/7.mp3",
            dialog = "616904",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/8.mp3",
            dialog = "616905",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/9.mp3",
            dialog = "616906",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/10.mp3",
            dialog = "616907",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/11.mp3",
            dialog = "616908",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/12.mp3",
            dialog = "616909",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/13.mp3",
            dialog = "616910",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/14.mp3",
            dialog = "616911",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1502/15.mp3",
            dialog = "616912",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1502",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1502",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1502",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1502",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1535] = {
    bn_name = "300030",
    bn_icon = "icons/role/list/lb_r_535.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_535.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1535/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1535/1.mp3",
            dialog = "616913",
            voiceTime = 5
        },
        action2 = {
            voice = "music/ui/signboradgirl_1535/2.mp3",
            dialog = "616914",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1535/3.mp3",
            dialog = "616915",
            voiceTime = 7
        },
        action4 = {
            voice = "music/ui/signboradgirl_1535/4.mp3",
            dialog = "616916",
            voiceTime = 5
        },
        action5 = {
            voice = "music/ui/signboradgirl_1535/5.mp3",
            dialog = "616917",
            voiceTime = 5
        },
        action6 = {
            voice = "music/ui/signboradgirl_1535/6.mp3",
            dialog = "616918",
            voiceTime = 4
        },
        action7 = {
            voice = "music/ui/signboradgirl_1535/7.mp3",
            dialog = "616919",
            voiceTime = 7
        },
        action8 = {
            voice = "music/ui/signboradgirl_1535/8.mp3",
            dialog = "616920",
            voiceTime = 2
        },
        action9 = {
            voice = "music/ui/signboradgirl_1535/9.mp3",
            dialog = "616921",
            voiceTime = 8
        },
        action10 = {
            voice = "music/ui/signboradgirl_1535/10.mp3",
            dialog = "616922",
            voiceTime = 10
        },
        action11 = {
            voice = "music/ui/signboradgirl_1535/11.mp3",
            dialog = "616923",
            voiceTime = 6
        },
        action12 = {
            voice = "music/ui/signboradgirl_1535/12.mp3",
            dialog = "616924",
            voiceTime = 9
        },
        action13 = {
            voice = "music/ui/signboradgirl_1535/13.mp3",
            dialog = "616925",
            voiceTime = 5
        },
        action14 = {
            voice = "music/ui/signboradgirl_1535/14.mp3",
            dialog = "616926",
            voiceTime = 7
        },
        action15 = {
            voice = "music/ui/signboradgirl_1535/15.mp3",
            dialog = "616927",
            voiceTime = 6
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =535,  --共鸣绑定ID,
    hero_id = 535,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "616913",
        "616914",
        "616915",
        "616916",
        "616917",
        "616918",
        "616919",
        "616920",
        "616921",
        "616922",
        "616923",
        "616924",
        "616925",
        "616926",
        "616927",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1535/1.mp3",
            dialog = "616913",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1535/2.mp3",
            dialog = "616914",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1535/3.mp3",
            dialog = "616915",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1535/4.mp3",
            dialog = "616916",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1535/5.mp3",
            dialog = "616917",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1535/6.mp3",
            dialog = "616918",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1535/7.mp3",
            dialog = "616919",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1535/8.mp3",
            dialog = "616920",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1535/9.mp3",
            dialog = "616921",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1535/10.mp3",
            dialog = "616922",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1535/11.mp3",
            dialog = "616923",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1535/12.mp3",
            dialog = "616924",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1535/13.mp3",
            dialog = "616925",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1535/14.mp3",
            dialog = "616926",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1535/15.mp3",
            dialog = "616927",
            voiceTime = 6
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1535",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1535",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1535",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1535",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1538] = {
    bn_name = "300031",
    bn_icon = "icons/role/list/lb_r_538.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_538.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1538/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1538/1.mp3",
            dialog = "617146",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1538/2.mp3",
            dialog = "617147",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1538/3.mp3",
            dialog = "617148",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1538/4.mp3",
            dialog = "617149",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1538/5.mp3",
            dialog = "617150",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1538/6.mp3",
            dialog = "617151",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1538/7.mp3",
            dialog = "617152",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1538/8.mp3",
            dialog = "617153",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1538/9.mp3",
            dialog = "617154",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1538/10.mp3",
            dialog = "617155",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1538/11.mp3",
            dialog = "617156",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1538/12.mp3",
            dialog = "617157",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1538/13.mp3",
            dialog = "617158",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1538/14.mp3",
            dialog = "617159",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1538/15.mp3",
            dialog = "617160",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =538,  --共鸣绑定ID,
    hero_id = 538,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "617146",
        "617147",
        "617148",
        "617149",
        "617150",
        "617151",
        "617152",
        "617153",
        "617154",
        "617155",
        "617156",
        "617157",
        "617158",
        "617159",
        "617160",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1538/1.mp3",
            dialog = "617146",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/2.mp3",
            dialog = "617147",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/3.mp3",
            dialog = "617148",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/4.mp3",
            dialog = "617149",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/5.mp3",
            dialog = "617150",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/6.mp3",
            dialog = "617151",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/7.mp3",
            dialog = "617152",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/8.mp3",
            dialog = "617153",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/9.mp3",
            dialog = "617154",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/10.mp3",
            dialog = "617155",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/11.mp3",
            dialog = "617156",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/12.mp3",
            dialog = "617157",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/13.mp3",
            dialog = "617158",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/14.mp3",
            dialog = "617159",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1538/15.mp3",
            dialog = "617160",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1538",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1538",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1538",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1538",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1540] = {
    bn_name = "300032",
    bn_icon = "icons/role/list/lb_r_540.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_540.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1540/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1540/1.mp3",
            dialog = "617161",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1540/2.mp3",
            dialog = "617162",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1540/3.mp3",
            dialog = "617163",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1540/4.mp3",
            dialog = "617164",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1540/5.mp3",
            dialog = "617165",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1540/6.mp3",
            dialog = "617166",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1540/7.mp3",
            dialog = "617167",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1540/8.mp3",
            dialog = "617168",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1540/9.mp3",
            dialog = "617169",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1540/10.mp3",
            dialog = "617170",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1540/11.mp3",
            dialog = "617171",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1540/12.mp3",
            dialog = "617172",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1540/13.mp3",
            dialog = "617173",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1540/14.mp3",
            dialog = "617174",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1540/15.mp3",
            dialog = "617175",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =540,  --共鸣绑定ID,
    hero_id = 540,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "617161",
        "617162",
        "617163",
        "617164",
        "617165",
        "617166",
        "617167",
        "617168",
        "617169",
        "617170",
        "617171",
        "617172",
        "617173",
        "617174",
        "617175",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1540/1.mp3",
            dialog = "617161",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/2.mp3",
            dialog = "617162",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/3.mp3",
            dialog = "617163",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/4.mp3",
            dialog = "617164",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/5.mp3",
            dialog = "617165",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/6.mp3",
            dialog = "617166",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/7.mp3",
            dialog = "617167",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/8.mp3",
            dialog = "617168",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/9.mp3",
            dialog = "617169",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/10.mp3",
            dialog = "617170",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/11.mp3",
            dialog = "617171",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/12.mp3",
            dialog = "617172",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/13.mp3",
            dialog = "617173",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/14.mp3",
            dialog = "617174",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1540/15.mp3",
            dialog = "617175",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1540",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1540",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1540",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1540",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1539] = {
    bn_name = "300033",
    bn_icon = "icons/role/list/lb_r_539.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_539.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1539/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1539/1.mp3",
            dialog = "617442",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1539/2.mp3",
            dialog = "617443",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1539/3.mp3",
            dialog = "617444",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1539/4.mp3",
            dialog = "617445",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1539/5.mp3",
            dialog = "617446",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1539/6.mp3",
            dialog = "617447",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1539/7.mp3",
            dialog = "617448",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1539/8.mp3",
            dialog = "617449",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1539/9.mp3",
            dialog = "617450",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1539/10.mp3",
            dialog = "617451",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1539/11.mp3",
            dialog = "617452",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1539/12.mp3",
            dialog = "617453",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1539/13.mp3",
            dialog = "617454",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1539/14.mp3",
            dialog = "617455",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1539/15.mp3",
            dialog = "617456",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =539,  --共鸣绑定ID,
    hero_id = 539,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "617442",
        "617443",
        "617444",
        "617445",
        "617446",
        "617447",
        "617448",
        "617449",
        "617450",
        "617451",
        "617452",
        "617453",
        "617454",
        "617455",
        "617456",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1539/1.mp3",
            dialog = "617442",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/2.mp3",
            dialog = "617443",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/3.mp3",
            dialog = "617444",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/4.mp3",
            dialog = "617445",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/5.mp3",
            dialog = "617446",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/6.mp3",
            dialog = "617447",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/7.mp3",
            dialog = "617448",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/8.mp3",
            dialog = "617449",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/9.mp3",
            dialog = "617450",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/10.mp3",
            dialog = "617451",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/11.mp3",
            dialog = "617452",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/12.mp3",
            dialog = "617453",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/13.mp3",
            dialog = "617454",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/14.mp3",
            dialog = "617455",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1539/15.mp3",
            dialog = "617456",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1539",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1539",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1539",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1539",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1541] = {
    bn_name = "300034",
    bn_icon = "icons/role/list/lb_r_541.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_541.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1541/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1541/1.mp3",
            dialog = "617457",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1541/2.mp3",
            dialog = "617458",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1541/3.mp3",
            dialog = "617459",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1541/4.mp3",
            dialog = "617460",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1541/5.mp3",
            dialog = "617461",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1541/6.mp3",
            dialog = "617462",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1541/7.mp3",
            dialog = "617463",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1541/8.mp3",
            dialog = "617464",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1541/9.mp3",
            dialog = "617465",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1541/10.mp3",
            dialog = "617466",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1541/11.mp3",
            dialog = "617467",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1541/12.mp3",
            dialog = "617468",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1541/13.mp3",
            dialog = "617469",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1541/14.mp3",
            dialog = "617470",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1541/15.mp3",
            dialog = "617471",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =541,  --共鸣绑定ID,
    hero_id = 541,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "617457",
        "617458",
        "617459",
        "617460",
        "617461",
        "617462",
        "617463",
        "617464",
        "617465",
        "617466",
        "617467",
        "617468",
        "617469",
        "617470",
        "617471",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1541/1.mp3",
            dialog = "617457",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/2.mp3",
            dialog = "617458",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/3.mp3",
            dialog = "617459",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/4.mp3",
            dialog = "617460",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/5.mp3",
            dialog = "617461",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/6.mp3",
            dialog = "617462",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/7.mp3",
            dialog = "617463",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/8.mp3",
            dialog = "617464",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/9.mp3",
            dialog = "617465",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/10.mp3",
            dialog = "617466",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/11.mp3",
            dialog = "617467",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/12.mp3",
            dialog = "617468",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/13.mp3",
            dialog = "617469",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/14.mp3",
            dialog = "617470",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1541/15.mp3",
            dialog = "617471",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1541",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1541",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1541",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1541",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1537] = {
    bn_name = "300035",
    bn_icon = "icons/role/list/lb_r_537.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_537.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1537/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1537/1.mp3",
            dialog = "617774",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1537/2.mp3",
            dialog = "617775",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1537/3.mp3",
            dialog = "617776",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1537/4.mp3",
            dialog = "617777",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1537/5.mp3",
            dialog = "617778",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1537/6.mp3",
            dialog = "617779",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1537/7.mp3",
            dialog = "617780",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1537/8.mp3",
            dialog = "617781",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1537/9.mp3",
            dialog = "617782",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1537/10.mp3",
            dialog = "617783",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1537/11.mp3",
            dialog = "617784",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1537/12.mp3",
            dialog = "617785",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1537/13.mp3",
            dialog = "617786",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1537/14.mp3",
            dialog = "617787",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1537/15.mp3",
            dialog = "617788",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =537,  --共鸣绑定ID,
    hero_id = 537,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "617774",
        "617775",
        "617776",
        "617777",
        "617778",
        "617779",
        "617780",
        "617781",
        "617782",
        "617783",
        "617784",
        "617785",
        "617786",
        "617787",
        "617788",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1537/1.mp3",
            dialog = "617774",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/2.mp3",
            dialog = "617775",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/3.mp3",
            dialog = "617776",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/4.mp3",
            dialog = "617777",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/5.mp3",
            dialog = "617778",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/6.mp3",
            dialog = "617779",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/7.mp3",
            dialog = "617780",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/8.mp3",
            dialog = "617781",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/9.mp3",
            dialog = "617782",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/10.mp3",
            dialog = "617783",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/11.mp3",
            dialog = "617784",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/12.mp3",
            dialog = "617785",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/13.mp3",
            dialog = "617786",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/14.mp3",
            dialog = "617787",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1537/15.mp3",
            dialog = "617788",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1537",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1537",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1537",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1537",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1516] = {
    bn_name = "300036",
    bn_icon = "icons/role/list/lb_r_516.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_516.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1516/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1516/1.mp3",
            dialog = "618005",
            voiceTime = 2
        },
        action2 = {
            voice = "music/ui/signboradgirl_1516/2.mp3",
            dialog = "618006",
            voiceTime = 4
        },
        action3 = {
            voice = "music/ui/signboradgirl_1516/3.mp3",
            dialog = "618007",
            voiceTime = 6
        },
        action4 = {
            voice = "music/ui/signboradgirl_1516/4.mp3",
            dialog = "618008",
            voiceTime = 4
        },
        action5 = {
            voice = "music/ui/signboradgirl_1516/5.mp3",
            dialog = "618009",
            voiceTime = 4
        },
        action6 = {
            voice = "music/ui/signboradgirl_1516/6.mp3",
            dialog = "618010",
            voiceTime = 5
        },
        action7 = {
            voice = "music/ui/signboradgirl_1516/7.mp3",
            dialog = "618011",
            voiceTime = 7
        },
        action8 = {
            voice = "music/ui/signboradgirl_1516/8.mp3",
            dialog = "618012",
            voiceTime = 9
        },
        action9 = {
            voice = "music/ui/signboradgirl_1516/9.mp3",
            dialog = "618013",
            voiceTime = 8
        },
        action10 = {
            voice = "music/ui/signboradgirl_1516/10.mp3",
            dialog = "618014",
            voiceTime = 7
        },
        action11 = {
            voice = "music/ui/signboradgirl_1516/11.mp3",
            dialog = "618015",
            voiceTime = 12
        },
        action12 = {
            voice = "music/ui/signboradgirl_1516/12.mp3",
            dialog = "618016",
            voiceTime = 7
        },
        action13 = {
            voice = "music/ui/signboradgirl_1516/13.mp3",
            dialog = "618017",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1516/14.mp3",
            dialog = "618018",
            voiceTime = 6
        },
        action15 = {
            voice = "music/ui/signboradgirl_1516/15.mp3",
            dialog = "618019",
            voiceTime = 4
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =516,  --共鸣绑定ID,
    hero_id = 516,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "618005",
        "618006",
        "618007",
        "618008",
        "618009",
        "618010",
        "618011",
        "618012",
        "618013",
        "618014",
        "618015",
        "618016",
        "618017",
        "618018",
        "618019",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1516/1.mp3",
            dialog = "618005",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1516/2.mp3",
            dialog = "618006",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1516/3.mp3",
            dialog = "618007",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1516/4.mp3",
            dialog = "618008",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1516/5.mp3",
            dialog = "618009",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1516/6.mp3",
            dialog = "618010",
            voiceTime = 5
        },
        {
            voice = "music/ui/signboradgirl_1516/7.mp3",
            dialog = "618011",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1516/8.mp3",
            dialog = "618012",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1516/9.mp3",
            dialog = "618013",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1516/10.mp3",
            dialog = "618014",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1516/11.mp3",
            dialog = "618015",
            voiceTime = 12
        },
        {
            voice = "music/ui/signboradgirl_1516/12.mp3",
            dialog = "618016",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1516/13.mp3",
            dialog = "618017",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1516/14.mp3",
            dialog = "618018",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1516/15.mp3",
            dialog = "618019",
            voiceTime = 4
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1516",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1516",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1516",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1516",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1542] = {
    bn_name = "300037",
    bn_icon = "icons/role/list/lb_r_542.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_542.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1542/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1542/1.mp3",
            dialog = "618020",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1542/2.mp3",
            dialog = "618021",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1542/3.mp3",
            dialog = "618022",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1542/4.mp3",
            dialog = "618023",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1542/5.mp3",
            dialog = "618024",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1542/6.mp3",
            dialog = "618025",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1542/7.mp3",
            dialog = "618026",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1542/8.mp3",
            dialog = "618027",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1542/9.mp3",
            dialog = "618028",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1542/10.mp3",
            dialog = "618029",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1542/11.mp3",
            dialog = "618030",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1542/12.mp3",
            dialog = "618031",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1542/13.mp3",
            dialog = "618032",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1542/14.mp3",
            dialog = "618033",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1542/15.mp3",
            dialog = "618034",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =542,  --共鸣绑定ID,
    hero_id = 542,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "618020",
        "618021",
        "618022",
        "618023",
        "618024",
        "618025",
        "618026",
        "618027",
        "618028",
        "618029",
        "618030",
        "618031",
        "618032",
        "618033",
        "618034",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1542/1.mp3",
            dialog = "618020",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/2.mp3",
            dialog = "618021",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/3.mp3",
            dialog = "618022",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/4.mp3",
            dialog = "618023",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/5.mp3",
            dialog = "618024",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/6.mp3",
            dialog = "618025",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/7.mp3",
            dialog = "618026",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/8.mp3",
            dialog = "618027",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/9.mp3",
            dialog = "618028",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/10.mp3",
            dialog = "618029",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/11.mp3",
            dialog = "618030",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/12.mp3",
            dialog = "618031",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/13.mp3",
            dialog = "618032",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/14.mp3",
            dialog = "618033",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1542/15.mp3",
            dialog = "618034",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1542",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1542",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1542",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1542",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1543] = {
    bn_name = "300038",
    bn_icon = "icons/role/list/lb_r_543.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_543.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1543/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1543/1.mp3",
            dialog = "618152",
            voiceTime = 7
        },
        action2 = {
            voice = "music/ui/signboradgirl_1543/2.mp3",
            dialog = "618153",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1543/3.mp3",
            dialog = "618154",
            voiceTime = 4
        },
        action4 = {
            voice = "music/ui/signboradgirl_1543/4.mp3",
            dialog = "618155",
            voiceTime = 10
        },
        action5 = {
            voice = "music/ui/signboradgirl_1543/5.mp3",
            dialog = "618156",
            voiceTime = 9
        },
        action6 = {
            voice = "music/ui/signboradgirl_1543/6.mp3",
            dialog = "618157",
            voiceTime = 6
        },
        action7 = {
            voice = "music/ui/signboradgirl_1543/7.mp3",
            dialog = "618158",
            voiceTime = 6
        },
        action8 = {
            voice = "music/ui/signboradgirl_1543/8.mp3",
            dialog = "618159",
            voiceTime = 6
        },
        action9 = {
            voice = "music/ui/signboradgirl_1543/9.mp3",
            dialog = "618160",
            voiceTime = 4
        },
        action10 = {
            voice = "music/ui/signboradgirl_1543/10.mp3",
            dialog = "618161",
            voiceTime = 8
        },
        action11 = {
            voice = "music/ui/signboradgirl_1543/11.mp3",
            dialog = "618162",
            voiceTime = 7
        },
        action12 = {
            voice = "music/ui/signboradgirl_1543/12.mp3",
            dialog = "618163",
            voiceTime = 13
        },
        action13 = {
            voice = "music/ui/signboradgirl_1543/13.mp3",
            dialog = "618164",
            voiceTime = 6
        },
        action14 = {
            voice = "music/ui/signboradgirl_1543/14.mp3",
            dialog = "618165",
            voiceTime = 2
        },
        action15 = {
            voice = "music/ui/signboradgirl_1543/15.mp3",
            dialog = "618166",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =543,  --共鸣绑定ID,
    hero_id = 543,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "618152",
        "618153",
        "618154",
        "618155",
        "618156",
        "618157",
        "618158",
        "618159",
        "618160",
        "618161",
        "618162",
        "618163",
        "618164",
        "618165",
        "618166",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1543/1.mp3",
            dialog = "618152",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1543/2.mp3",
            dialog = "618153",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1543/3.mp3",
            dialog = "618154",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1543/4.mp3",
            dialog = "618155",
            voiceTime = 10
        },
        {
            voice = "music/ui/signboradgirl_1543/5.mp3",
            dialog = "618156",
            voiceTime = 9
        },
        {
            voice = "music/ui/signboradgirl_1543/6.mp3",
            dialog = "618157",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1543/7.mp3",
            dialog = "618158",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1543/8.mp3",
            dialog = "618159",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1543/9.mp3",
            dialog = "618160",
            voiceTime = 4
        },
        {
            voice = "music/ui/signboradgirl_1543/10.mp3",
            dialog = "618161",
            voiceTime = 8
        },
        {
            voice = "music/ui/signboradgirl_1543/11.mp3",
            dialog = "618162",
            voiceTime = 7
        },
        {
            voice = "music/ui/signboradgirl_1543/12.mp3",
            dialog = "618163",
            voiceTime = 13
        },
        {
            voice = "music/ui/signboradgirl_1543/13.mp3",
            dialog = "618164",
            voiceTime = 6
        },
        {
            voice = "music/ui/signboradgirl_1543/14.mp3",
            dialog = "618165",
            voiceTime = 2
        },
        {
            voice = "music/ui/signboradgirl_1543/15.mp3",
            dialog = "618166",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1543",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1543",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1543",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1543",
            dialog = {10,11,12},
        },
    }
} 
princess_mainpage[1544] = {
    bn_name = "300039",
    bn_icon = "icons/role/list/lb_r_544.png",
    bn_des = "134202",
    spinepath = "Resources/armatures/lihuispine/Lihui_544.atlas",  --spine地址
    loadingcount = 3,  --呼吸次数
    loadingchance = 0.5, --到达呼吸次数后播放动画的概率
    loading = "loading", --呼吸事件名
    waiting = {   --呼吸事件,播放时随机一个  
    },
    login_voice={ "music/ui/signboradgirl_1544/15.mp3",
    },
    battle_voice = "",
    touch = {   
        {
            paneldesc = { x = 12,y = 450,width = 300,height = 550 },   --触摸区域(相对于spine锚点的坐标)
            actions = {  --触摸事件，触摸时随机播一个
                "",
            }
        },
    },
    namedevent ={   --固定事件（如新邮件，多人战等)
        MultiBattle = "action",   --有新的多人战
        NewMail = "action",  --新邮件
        SkillPoint = "action",  --新技能点
        LoginGift = "action",  --登录奖励
        AchiGift = "action",  --成就奖励
        DDBattle = "action",  --黑潮遗迹解锁
        GetAP = "action",  --获取体力
        Forge = "action13",  --铸造完成
        Explore = "action14",  --探索完成
    },
    voicemap ={  -- 老的板娘，每个spine动画对应的语音，没有语音就不填 
    },
    voicemap_v2 ={  -- 新的板娘，每个spine动画对应的语音，没有语音就不填 
        action1 = {
            voice = "music/ui/signboradgirl_1544/1.mp3",
            dialog = "618195",
            voiceTime = 3
        },
        action2 = {
            voice = "music/ui/signboradgirl_1544/2.mp3",
            dialog = "618196",
            voiceTime = 3
        },
        action3 = {
            voice = "music/ui/signboradgirl_1544/3.mp3",
            dialog = "618197",
            voiceTime = 3
        },
        action4 = {
            voice = "music/ui/signboradgirl_1544/4.mp3",
            dialog = "618198",
            voiceTime = 3
        },
        action5 = {
            voice = "music/ui/signboradgirl_1544/5.mp3",
            dialog = "618199",
            voiceTime = 3
        },
        action6 = {
            voice = "music/ui/signboradgirl_1544/6.mp3",
            dialog = "618200",
            voiceTime = 3
        },
        action7 = {
            voice = "music/ui/signboradgirl_1544/7.mp3",
            dialog = "618201",
            voiceTime = 3
        },
        action8 = {
            voice = "music/ui/signboradgirl_1544/8.mp3",
            dialog = "618202",
            voiceTime = 3
        },
        action9 = {
            voice = "music/ui/signboradgirl_1544/9.mp3",
            dialog = "618203",
            voiceTime = 3
        },
        action10 = {
            voice = "music/ui/signboradgirl_1544/10.mp3",
            dialog = "618204",
            voiceTime = 3
        },
        action11 = {
            voice = "music/ui/signboradgirl_1544/11.mp3",
            dialog = "618205",
            voiceTime = 3
        },
        action12 = {
            voice = "music/ui/signboradgirl_1544/12.mp3",
            dialog = "618206",
            voiceTime = 3
        },
        action13 = {
            voice = "music/ui/signboradgirl_1544/13.mp3",
            dialog = "618207",
            voiceTime = 3
        },
        action14 = {
            voice = "music/ui/signboradgirl_1544/14.mp3",
            dialog = "618208",
            voiceTime = 3
        },
        action15 = {
            voice = "music/ui/signboradgirl_1544/15.mp3",
            dialog = "618209",
            voiceTime = 3
        },
    },
    type = 2,  --板娘类型编码
    origin_x = 0,
    origin_y = 353,
    scaling = 0.8,  --缩放比例
    likefeeling_id =544,  --共鸣绑定ID,
    hero_id = 544,
    level = 5,  --板娘品质
    dialogs = {     --好感度对话文字 
        "618195",
        "618196",
        "618197",
        "618198",
        "618199",
        "618200",
        "618201",
        "618202",
        "618203",
        "618204",
        "618205",
        "618206",
        "618207",
        "618208",
        "618209",
    },
    actionTouch = { 
        {
            voice = "music/ui/signboradgirl_1544/1.mp3",
            dialog = "618195",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/2.mp3",
            dialog = "618196",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/3.mp3",
            dialog = "618197",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/4.mp3",
            dialog = "618198",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/5.mp3",
            dialog = "618199",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/6.mp3",
            dialog = "618200",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/7.mp3",
            dialog = "618201",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/8.mp3",
            dialog = "618202",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/9.mp3",
            dialog = "618203",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/10.mp3",
            dialog = "618204",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/11.mp3",
            dialog = "618205",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/12.mp3",
            dialog = "618206",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/13.mp3",
            dialog = "618207",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/14.mp3",
            dialog = "618208",
            voiceTime = 3
        },
        {
            voice = "music/ui/signboradgirl_1544/15.mp3",
            dialog = "618209",
            voiceTime = 3
        },
    },
    like_action = {  --好感度对应动作,对话
        {
            range = { 0, 49 },  --好感度区间
            action ="action1544",
            dialog = {1,2,3},
        },
        {
            range = { 50, 79 },  --好感度区间
            action ="action1544",
            dialog = {4,5,6},
        },
        {
            range = { 80, 99 },  --好感度区间
            action ="action1544",
            dialog = {7,8,9},
        },
        {
            range = { 100, 999 },  --好感度区间
            action ="action1544",
            dialog = {10,11,12},
        },
    }
} 