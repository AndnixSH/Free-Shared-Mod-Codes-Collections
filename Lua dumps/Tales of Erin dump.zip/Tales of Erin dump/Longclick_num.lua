--require "XUIView"
Longclick_num = class("Longclick_num")
Longclick_num.__index      = Longclick_num 

-- dataTable = {
	--["btnLeft"]   	左边的按钮
	--["btnRight"]  	右面的按钮  左减右加的操作
	--["maxMatNum"] 	最大的数量
	--["lbCurNum"]		需要显示当前数量的文本
	--["cost_text"] 	显示贩卖收益  贩卖界面可用 可选参数
	--["cost_num"]  	显示价格     贩卖界面可用 可选参数
	--["curMatNum"] 	显示初始数量  默认是1  	  可选参数
	--["longclickT"]    长点击加数量的类型  默认是1 根据速度加每次加 1
--}
--btnLeft,btnRight,maxMatNum,lbCurNum,cost_text,cost_num
function Longclick_num:init(dataTable)
  
    self.btnLeft    = dataTable.btnLeft
    self.btnRight   = dataTable.btnRight
    self.maxMatNum  = dataTable.maxMatNum
    self.lbCurNum   = dataTable.lbCurNum
    -- 显示初始化的占位文本数量
    if dataTable.curMatNum then
    	self.curMatNum  = dataTable.curMatNum 
    else
    	self.curMatNum  = 0
    end
    -- 常量定义  初始的占位文本数量
    self.INIT_NUM 	= self.curMatNum
    if dataTable.longclickT then
    	self.CLICK_TYPE = dataTable.longclickT
    else
    	self.CLICK_TYPE = 1
    end 
   	-- 根据参数 是否显示贩卖收益
    if dataTable.cost_text  then
    	self.lbCostText = dataTable.cost_text
    	self.cost_num   = dataTable.cost_num
    end


    self.btnLeft:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.began then
		--先要减一次
		--开始减小狗粮
		if self.CLICK_TYPE == 1 then
			self:startIncreaseFood(-1)
		elseif self.CLICK_TYPE == 2 then
			self:startIncreaseFood2(-1)
		end
		elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
		--停止减小狗粮
		self:stopFoodNum()
		end
    end)

    self.btnRight:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.began then
		--开始加小狗粮
			if self.CLICK_TYPE == 1 then
				self:startIncreaseFood(1)
			elseif self.CLICK_TYPE == 2 then
				self:startIncreaseFood2(1)
			end
		elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
		--停止加小狗粮
		self:stopFoodNum()
		end
    end)

    self:refresh()

    return self
end



function Longclick_num:setCurMatNum(n)
    self.curMatNum = n
    self:refresh()
end
-- 获取当前的数量
function Longclick_num:getCurMatNum()
    return self.curMatNum
end
-- 刷新
function Longclick_num:refresh()

    if self.curMatNum > self.INIT_NUM then
        --可以减数
        if self.btnLeft then
        	self.btnLeft:setTouchEnabled(true)
        	self.btnLeft:setBright(true)
        end
    else
    	if self.btnLeft then
        	self.btnLeft:setTouchEnabled(false)
        	self.btnLeft:setBright(false)
        end
    end

    if  self.curMatNum < self.maxMatNum  then
        --可以加数
        if self.btnRight then
        	self.btnRight:setTouchEnabled(true)
        	self.btnRight:setBright(true)
        end
    else
    	if self.btnRight then
        	self.btnRight:setTouchEnabled(false)
        	self.btnRight:setBright(false)
        end
    end

    self.lbCurNum:setString(""..self.curMatNum)
    if self.lbCostText then
    	self.lbCostText:setString(""..(self.cost_num*self.curMatNum))
    end



end
-- CLICK_TYPE  == 1  游戏统一的处理  装备强化 人物强化 和次函数的执行的效果一样
function Longclick_num:startIncreaseFood(opt)
	self:stopFoodNum()
	
	--闭包变量
	local c_opt = opt
	local c_total_time = 10
  	local c_cnt = 0
	
	local function addfoodfunc(time)
		-- local food_H_M_num = user_info["bag"]["mat"][ID_H_M]
		c_total_time = c_total_time + time
		c_cnt = c_cnt + 1
		
		local n = 1

		if c_total_time < 0.3 then
      		return
		elseif c_total_time < 2 then 
			if c_cnt > 3.5 then
				c_cnt = 0
			else
				return
			end
		elseif c_total_time < 3 then
			if c_cnt > 2.5 then
				c_cnt = 0
			else
				return
			end
		elseif c_total_time < 4 then
			if c_cnt > 1.5 then
				c_cnt = 0
			else
				return
			end
		else
			c_cnt = 0
		end
			
        self.curMatNum = self.curMatNum + n * c_opt
        
        if self.curMatNum <= self.INIT_NUM then 
            self.curMatNum = self.INIT_NUM
            self:stopFoodNum()
        end

        if self.curMatNum >=  self.maxMatNum then
            self.curMatNum =  self.maxMatNum
            self:stopFoodNum()
        end   
        self:refresh()
	end
	
	local scheduler = cc.Director:getInstance():getScheduler()
	self.schedulerEntry = scheduler:scheduleScriptFunc(addfoodfunc, 1/60 , false)
	
	addfoodfunc(0) ---点击同时先加一次
	c_total_time = 0
end
-- CLICK_TYPE  == 2 -- 特殊的处理  此函数可扩展根据策划需求修改
function Longclick_num:startIncreaseFood2(opt)
	self:stopFoodNum()
	
	--闭包变量
	local c_opt = opt
	local c_total_time = -10
  	local c_cnt = 0
	
	local function addfoodfunc(time)
		-- local food_H_M_num = user_info["bag"]["mat"][ID_H_M]
		c_total_time = c_total_time + time
		c_cnt = c_cnt + 1
		local n = 1
		if c_total_time == -10 then

		elseif c_total_time < 0.2 then
      		return
		elseif c_total_time < 2 then 
			if c_cnt > 3.5 then
				c_cnt = 0
			else
				return
			end
		elseif c_total_time < 3 then
			if c_cnt > 2.5 then
				c_cnt = 0
				--n = 4
			else
				return
			end
		elseif c_total_time < 4 then
			if c_cnt > 1.5 then
				c_cnt = 0
				--n = 6
			else
				return
			end
		elseif c_total_time < 5 then
				n = 10
		elseif c_total_time < 6 then
				n = 100
		elseif c_total_time > 6 then
				n = 1000
		end
			
        self.curMatNum = self.curMatNum + n * c_opt
        
        if self.curMatNum <= self.INIT_NUM then 
            self.curMatNum = self.INIT_NUM
            self:stopFoodNum()
        end

        if self.curMatNum >=  self.maxMatNum then
            self.curMatNum =  self.maxMatNum
            self:stopFoodNum()
        end   
        self:refresh()
	end
	
	local scheduler = cc.Director:getInstance():getScheduler()
	self.schedulerEntry = scheduler:scheduleScriptFunc(addfoodfunc, 1/60 , false)
	
	addfoodfunc(0) ---点击同时先加一次
	c_total_time = 0
end

function Longclick_num:stopFoodNum()
	if self.schedulerEntry == nil then return end
	
	local scheduler = cc.Director:getInstance():getScheduler()
	scheduler:unscheduleScriptEntry(self.schedulerEntry)
	self.schedulerEntry = nil
end