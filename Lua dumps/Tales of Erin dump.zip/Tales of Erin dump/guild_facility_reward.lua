guild_facility_reward = {}

    guild_facility_reward[2] = { 
     {
        item_type= 2,  -- 物品类型
        item_id= 0,  -- 物品ID
        item_num=100,  -- 物品数量
        item_name="无偿钻石",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 1500,  -- 物品ID
        item_num=500,  -- 物品数量
        item_name="公会币",  -- 物品名称
     }, 
     {
        item_type= 6,  -- 物品类型
        item_id= 3,  -- 物品ID
        item_num=1,  -- 物品数量
        item_name="契约书",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 703,  -- 物品ID
        item_num=1,  -- 物品数量
        item_name="黄金之锤",  -- 物品名称
     },  }

    guild_facility_reward[3] = { 
     {
        item_type= 2,  -- 物品类型
        item_id= 0,  -- 物品ID
        item_num=200,  -- 物品数量
        item_name="无偿钻石",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 1500,  -- 物品ID
        item_num=1000,  -- 物品数量
        item_name="公会币",  -- 物品名称
     }, 
     {
        item_type= 6,  -- 物品类型
        item_id= 3,  -- 物品ID
        item_num=2,  -- 物品数量
        item_name="契约书",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 703,  -- 物品ID
        item_num=2,  -- 物品数量
        item_name="黄金之锤",  -- 物品名称
     },  }

    guild_facility_reward[4] = { 
     {
        item_type= 2,  -- 物品类型
        item_id= 0,  -- 物品ID
        item_num=300,  -- 物品数量
        item_name="无偿钻石",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 1500,  -- 物品ID
        item_num=1500,  -- 物品数量
        item_name="公会币",  -- 物品名称
     }, 
     {
        item_type= 6,  -- 物品类型
        item_id= 3,  -- 物品ID
        item_num=3,  -- 物品数量
        item_name="契约书",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 703,  -- 物品ID
        item_num=3,  -- 物品数量
        item_name="黄金之锤",  -- 物品名称
     },  }

    guild_facility_reward[5] = { 
     {
        item_type= 2,  -- 物品类型
        item_id= 0,  -- 物品ID
        item_num=400,  -- 物品数量
        item_name="无偿钻石",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 1500,  -- 物品ID
        item_num=2000,  -- 物品数量
        item_name="公会币",  -- 物品名称
     }, 
     {
        item_type= 6,  -- 物品类型
        item_id= 3,  -- 物品ID
        item_num=4,  -- 物品数量
        item_name="契约书",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 703,  -- 物品ID
        item_num=4,  -- 物品数量
        item_name="黄金之锤",  -- 物品名称
     },  }

    guild_facility_reward[6] = { 
     {
        item_type= 2,  -- 物品类型
        item_id= 0,  -- 物品ID
        item_num=500,  -- 物品数量
        item_name="无偿钻石",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 1500,  -- 物品ID
        item_num=3000,  -- 物品数量
        item_name="公会币",  -- 物品名称
     }, 
     {
        item_type= 6,  -- 物品类型
        item_id= 3,  -- 物品ID
        item_num=5,  -- 物品数量
        item_name="契约书",  -- 物品名称
     }, 
     {
        item_type= 5,  -- 物品类型
        item_id= 703,  -- 物品ID
        item_num=5,  -- 物品数量
        item_name="黄金之锤",  -- 物品名称
     },  }
