MsgManager = class("MsgManager")
MsgManager.__index      = MsgManager 

----------------定义表参数-----------
--oneself       传入的self
--callFunc      需要回调的函数
--basicDec      描述
--titleName     标题的名字
--buttonType    显示but类型  1 一个确定按钮   2 确定和取消
--formType      1 小  2 中  3 大 4 大
--nodeCsb       csb文件    直接传入一个node文件 
--basicType     -- 基础描述 类型  1 是一 纯文本格式的 纯文本类型参数可选可默认 为nil  2 金币  3 钻石

--只有简单的信息展示，并没有回调处理
function MsgManager:showSimpMsg(msg,LTop)
	local pop = {}
	pop["buttonType"] = 1
	pop["formType"]   = 1
	pop["titleName"]  = UITool.ToLocalization("提示")
	pop["basicDec"]   = msg
  	pop["TextType"]   = LTop
	SceneManager:showMsgMode(pop)
end
--只有简单的信息展示， 带一个按钮 回调
function MsgManager:showSimpMsgWithCallFunc1(msg,oneSelf,callfunc)
  local pop = {}
  pop["buttonType"] = 1
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["basicDec"]   = msg
  pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
  SceneManager:showMsgMode(pop)
end

--只有简单的信息展示， 两个按钮 回调
function MsgManager:showSimpMsgWithCallFunc2(msg,oneSelf,callfunc)
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["basicDec"]   = msg
  pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
  SceneManager:showMsgMode(pop)
end

--只有简单的信息展示， 两个按钮 回调  倒计时  LTop 字体对其方式现在就支持两种 居中 左上 默认是中  LTop == "LTOP"  左上
function MsgManager:showSimpMsgTime(msg,oneSelf,callfunc,sTime,LTop)
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["basicDec"]   = msg
  pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
  pop["sTime"]      = sTime
  pop["TextType"]   = LTop
  pop["OKBtnName"]  = UITool.ToLocalization("确认报名")
  SceneManager:showMsgMode(pop)
end
function MsgManager:setBuyNum( num )
  -- body
    self.curBuyNum = num
end
function MsgManager:getBuyNum( ... )
  -- body
  return self.curBuyNum
end
-- 简单的显示金币星石的消耗
-- dec1,dec2 dec3
function MsgManager:shwoAstrolabeBox( oneSelf,sellType,callFunc,strTable,strTable1,strTable2,bgImg,icon)--str1,color1,str2,color2,str3,color3
  -- body
  local node    = cc.CSLoader:createNode("MsgBoxNode_astro_2.csb")
  local imageBg = node:getChildByName("Image_bg")
  --背景
  if imageBg then
    imageBg:loadTexture(bgImg)
  end
  --图标
  local imgIcon    = node:getChildByName("Image_icon")
  if icon then
    imgIcon:loadTexture(icon)
  end
  --额外
  local text1   = node:getChildByName("Text_1")
  if strTable == nil then
    text1:setVisible(false)
  else
    text1:setString(strTable["str"])
    text1:setColor(strTable["color"])
  end
  --等级
  local text2   = node:getChildByName("Text_2")
  if strTable1 == nil then
    text2:setVisible(false)
  else
    text2:setString(strTable1["str"])
    text2:setColor(strTable1["color"])
  end
  --解锁所有技能
  local text3   = node:getChildByName("Text_3")
  if strTable2 == nil then
    text3:setVisible(false)
  else
    text3:setString(strTable2["str"])
    text3:setColor(strTable2["color"])
  end

  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 2
  pop["titleName"]  = UITool.ToLocalization("小提示")
  pop["OKBtnName"]  = UITool.ToLocalization("解锁")
  pop["nodeCsb"]    = node
  pop["order"]      = true
  pop["oneself"]    = oneSelf

  if sellType ~= nil and sellType == 0 then
    print("进入了贩卖灰色的函数")
    pop["Brish_en"]  = sellType
  end
  pop["callFunc"]   = callFunc
  SceneManager:showMsgMode(pop)
end
-- 简单的显示金币星石的消耗
-- dec1,dec2 dec3
function MsgManager:shwoColorText( oneSelf,sellType,callFunc,_table)--str1,color1,str2,color2,str3,color3
  -- body
  local node = cc.CSLoader:createNode("MsgBoxNode_astrolabe.csb")
  local dec1 = node:getChildByTag(535)
  local dec2 = node:getChildByTag(539)
  local dec3 = node:getChildByTag(541)
  if _table[1] then
    dec1:setString(_table[1]["str"])
    dec1:setColor(_table[1]["color"])
  end
  if _table[2] then
    dec2:setString(_table[2]["str"])
    dec2:setColor(_table[2]["color"])
  end
  if _table[3] then
    dec3:setString(_table[3]["str"])
    dec3:setColor(_table[3]["color"])
  end
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["OKBtnName"]  = UITool.ToLocalization("解锁")
  pop["nodeCsb"]    = node
  pop["oneself"]    = oneSelf

  if sellType ~= nil and sellType == 0 then
    print("进入了贩卖灰色的函数")
    pop["Brish_en"]  = sellType
  end
  pop["callFunc"]   = callFunc
  SceneManager:showMsgMode(pop)
end
--显示称号的弹窗
function MsgManager:showBaseSpine( id )
  -- body
  local skeletonNode = nil
  local node  = cc.CSLoader:createNode("MsgBoxNode_chenghao.csb")
  local spineRoot = node:getChildByName("Node_spine")
  local des   = node:getChildByName("Text_dec")
  local base_desc = UITool.getUserLanguage(title_conf[tonumber(id)].des) or ""
  local extra_desc = UITool.getUserLanguage(title_conf[tonumber(id)].sk_des) or ""
  local desc = base_desc..extra_desc
  des:setString(desc)
  local id_str = title_conf[tonumber(id)].res_spine
  if cc.FileUtils:getInstance():isFileExist(id_str) then 
      local dt = cc.DelayTime:create(0.01)
      local cf = cc.CallFunc:create(function()
           ---添加spine
          local end_pos = string.find(id_str,'atlas') - 1
          local spName = string.sub(id_str,0,end_pos)

          skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
          skeletonNode:setAnchorPoint(0,0)
          skeletonNode:setPosition(0,0)
          spineRoot:addChild(skeletonNode,1000)
          skeletonNode:setAnimation(1, "effect", true)

      end)
      local seq = cc.Sequence:create(dt,cf)
      spineRoot:runAction(seq)
  else 
      print("文件不存在 error file not exist:"..id_str)
  end
  local pop = {}
  pop["buttonType"] = 1
  pop["formType"]   = 3
  pop["titleName"]  = UITool.ToLocalization("物品信息")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
 -- pop["callFunc"]   = buyItemCallBack
  SceneManager:showMsgMode(pop)
end

--简单的信息展示，带回调的
function MsgManager:showSimpMsgWithCallFunc(msg,oneSelf,callfunc,cancelFunc,bBtnCanTouch,btnSureName)
	local pop = {}
	pop["buttonType"] = 2
	pop["formType"]   = 1
	pop["titleName"]  = UITool.ToLocalization("提示")
	pop["basicDec"]   = msg
	pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
  pop["cancelFunc"]   = cancelFunc
  if bBtnCanTouch ~= nil then
    pop["bBtnCanTouch"]   = bBtnCanTouch
  end
  if btnSureName ~= nil then
    pop["OKBtnName"]  = btnSureName
  end
	SceneManager:showMsgMode(pop)
end

--简单的信息展示，带回调的(用于可被二级界面遮挡的弹窗)
function MsgManager:showSimpMsgCanOver(msg,oneSelf,callfunc,cancelFunc,bBtnCanTouch)
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["basicDec"]   = msg
  pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
  pop["cancelFunc"]   = cancelFunc
  if bBtnCanTouch ~= nil then
    pop["bBtnCanTouch"]   = bBtnCanTouch
  end
  SceneManager:showMsgModeCanOver(pop)
end

function MsgManager:showBagAddView(equipMax,fcall,oneSelf)
  local pop = {}
  pop["oneself"] = oneSelf
  pop["callFunc"] = fcall
  pop["equipMax"] = equipMax
  SceneManager:showBagAddView(pop)
end

-- 简单的显示金币星石的消耗
-- dec1,dec2  是否花费 + 图标 + 立刻完场
function MsgManager:shwoCostType( ntype ,num,oneSelf,callFunc,dec1,dec2)
  -- body
  local node = cc.CSLoader:createNode("MsgBoxNode_10.csb")
  local cost_icon = node:getChildByTag(115)--消耗类型icon
  cost_icon:setUnifySizeEnabled(true)
  cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

  local cost_num = node:getChildByTag(116)
  cost_num:setString(num)

  if dec1 then -- 
      local sdec1 = node:getChildByTag(94)
      sdec1:setString(dec1)
  end
  if dec2  then
      local sdec2 = node:getChildByTag(95)
      sdec2:setString(dec2)
  end
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 2
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = oneSelf
  pop["callFunc"]   = callFunc
  SceneManager:showMsgMode(pop)
end
-- 显示捐献
-- table
function MsgManager:showGuildInfo( nLv )
  local node = cc.CSLoader:createNode("MsgBoxNode_SS.csb")
  node:getChildByName("lbLevelNum"):setString(""..nLv)
  if g_channel_control.transform_MsgBoxNode_SS_font == true then
    local reward1 = node:getChildByName("lbReward_1")
    local reward2 = node:getChildByName("lbReward_2")
    local reward3 = node:getChildByName("lbReward_3")
    reward1:setFontSize(20)
    reward2:setFontSize(20)
    reward3:setFontSize(20)
  end
  node:getChildByName("lbReward_2"):setTextColor(cc.c3b(127,127,127))
  node:getChildByName("lbReward_3"):setTextColor(cc.c3b(127,127,127))
  for i=1,nLv do
    local skillIndex = guild_facility[i].buff_type
    local lbReward = node:getChildByName("lbReward_"..skillIndex)
    if lbReward then
      local skillDes = UITool.getUserLanguage(guild_facility[i].des)--guild_facility[i].des
      if skillDes then
        lbReward:setString(skillDes)
        lbReward:setTextColor(cc.c3b(255,231,145))
      end
    end
  end
  local pop = {}
  pop["buttonType"] = 1
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("设施详情")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  SceneManager:showMsgMode(pop)
end
-- 显示捐献
-- table
function MsgManager:showGuildAdd( table,callFunc)
  -- body
  -- 
  -- table["nType"] = 13
  -- table["cost_num"] = 300
  -- 确定消耗的货币类型
  local cost_n  = 0
  local addCount = 1
  local GetCoinNumOnce = 1
  if table["nType"] == 13 then -- 苍玉
      cost_n =  user_info["beryl"]
      GetCoinNumOnce = guild_basic_conf.cb_beryl_coin
  elseif table["nType"] == 2 then -- 宝石
      cost_n = user_info["gem"]
      GetCoinNumOnce = guild_basic_conf.cb_gem_coin
  end

  local node = cc.CSLoader:createNode("MsgBoxJXNode.csb")
  local btn_bg = node:getChildByName("Image_numBg")
  -- 显示捐献金币
  local buy_num_text = btn_bg:getChildByName("Text_tex_0")
 -- if cost_n > table["cost_num"] then
    buy_num_text:setString(table["cost_num"])
 -- else
  --  buy_num_text:setString(cost_n)
 -- end

  --显示消耗类型
  local cost_icon = node:getChildByName("Image_gem")--消耗类型icon
  cost_icon:setUnifySizeEnabled(true)
  cost_icon:loadTexture(SHOP_BUY_TYPE[table["nType"]])

  local lbGetNum = node:getChildByName("lbGetNum")--获取公会币数量
  lbGetNum:setString(addCount*GetCoinNumOnce)

  local nAddCoinNum = 0
  local facility_lv = table["facility_lv"]
  local coinAddVaule = 0
  local coinDoubleVaule = 0
  for i=1,facility_lv do
    local buff_type = guild_facility[i].buff_type
    if buff_type == 2 then--公会币加成
      coinAddVaule = guild_facility[i].buff_value
    elseif buff_type == 1 then--公会币翻倍
      coinDoubleVaule = guild_facility[i].buff_value
    end
  end
  nAddCoinNum = (addCount*GetCoinNumOnce)*coinAddVaule

  --是否显示每日双倍
  local Image_double = node:getChildByName("Image_double")--每日双倍icon
  local lbAddNum = node:getChildByName("Text_beryl_add")--每日双倍加成数量
  if table["bIsFirst"] then
    if table["bIsFirst"] > 0 then
      Image_double:setVisible(true)
      if table["buff_value"] == 1 then
        Image_double:loadTexture("uifile/n_UIShare/guild/newGuild/gh_ui_009.png")
      elseif table["buff_value"] == 2 then
        Image_double:loadTexture("uifile/n_UIShare/guild/newGuild/gh_ui_012.png")
      else
        Image_double:setVisible(false)
      end
      nAddCoinNum = nAddCoinNum + GetCoinNumOnce*coinDoubleVaule
    else
      Image_double:setVisible(false)
    end
  else
    Image_double:setVisible(false)
  end
  if nAddCoinNum > 0 then
    lbAddNum:setString("+"..nAddCoinNum)
  else
    lbAddNum:setString("")
  end
  
  local addBtn = btn_bg:getChildByName("Button_add")--加号
  local delBtn = btn_bg:getChildByName("Button_Subtract")--减号
  local nCanMaxAdd = math.floor(cost_n/table["cost_num"])

  -- 等于零无法购买
  if cost_n < table["cost_num"] then
      local addBtn = btn_bg:getChildByName("Button_add")--加号
      local delBtn = btn_bg:getChildByName("Button_Subtract")--减号
      addBtn:setTouchEnabled(false)
      addBtn:setBright(false)
      delBtn:setTouchEnabled(false)
      delBtn:setBright(false)
  end
  -- 持有货币数量Text_gem
  local cost_text = node:getChildByName("Text_gem")
  cost_text:setString(tostring(cost_n))

  function refreshNum()
    --
    self:setBuyNum(tonumber(buy_num_text:getString()))
    local lbGetNum = node:getChildByName("lbGetNum")--获取公会币数量
    --捐献次数
    local nContributeCount = buy_num_text:getString()/table["cost_num"]
    lbGetNum:setString(nContributeCount*GetCoinNumOnce)

    nAddCoinNum = (nContributeCount*GetCoinNumOnce)*coinAddVaule
    if table["bIsFirst"] then
      if table["bIsFirst"] > 0 then
        nAddCoinNum = nAddCoinNum + GetCoinNumOnce*coinDoubleVaule
      end
    end
    if nAddCoinNum > 0 then
      lbAddNum:setString("+"..nAddCoinNum)
    else
      lbAddNum:setString("")
    end
    if nContributeCount <= 1 then
      addBtn:setTouchEnabled(true)
      addBtn:setBright(true)
      delBtn:setTouchEnabled(false)
      delBtn:setBright(false)
    elseif nContributeCount >= nCanMaxAdd then
      addBtn:setTouchEnabled(false)
      addBtn:setBright(false)
      delBtn:setTouchEnabled(true)
      delBtn:setBright(true)
    else
      addBtn:setTouchEnabled(true)
      addBtn:setBright(true)
      delBtn:setTouchEnabled(true)
      delBtn:setBright(true)
    end
  end

  function stopChangeNum()
    if self.schedulerEntry == nil then return end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    scheduler:unscheduleScriptEntry(self.schedulerEntry)
    self.schedulerEntry = nil
  end

  function startIncreaseNum(opt)
    stopChangeNum()
    
    --闭包变量
    local c_opt = opt
    local c_total_time = 10
      local c_cnt = 0
    
    local function addNumfunc(time)
      c_total_time = c_total_time + time
      c_cnt = c_cnt + 1
      
      local n = 1

      if c_total_time < 0.3 then
            return
      elseif c_total_time < 2 then 
        if c_cnt > 3.5 then
          c_cnt = 0
        else
          return
        end
      elseif c_total_time < 3 then
        if c_cnt > 2.5 then
          c_cnt = 0
        else
          return
        end
      elseif c_total_time < 4 then
        if c_cnt > 1.5 then
          c_cnt = 0
        else
          return
        end
      else
        c_cnt = 0
      end
      
      local c_n = tonumber(buy_num_text:getString())
      c_n = c_n + table["cost_num"] * c_opt
      if c_n <= 0 then
        stopChangeNum()
        c_n = table["cost_num"]
      end
      if cost_n - c_n >= 0 then
          buy_num_text:setString(tostring(c_n))
      else
        stopChangeNum()
      end
      --
      refreshNum()

    end
    
    local scheduler = cc.Director:getInstance():getScheduler()
    self.schedulerEntry = scheduler:scheduleScriptFunc(addNumfunc, 1/60 , false)
    
    addNumfunc(0) ---点击同时先加一次
    c_total_time = 0
  end

  function touchAddCallBack(sender,eventType)
    if eventType == ccui.TouchEventType.began then
      startIncreaseNum(1)
    elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
      stopChangeNum()
    end
  end
  function touchSubCallBack(sender,eventType)
    if eventType == ccui.TouchEventType.began then
      startIncreaseNum(-1)
    elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
      stopChangeNum()
    end
  end
  self:setBuyNum(tonumber(buy_num_text:getString())) 
  local addBtn = btn_bg:getChildByName("Button_add")--加号
  addBtn:addTouchEventListener(touchAddCallBack)
  local delBtn = btn_bg:getChildByName("Button_Subtract")--减号
  delBtn:addTouchEventListener(touchSubCallBack)
  addBtn:setTouchEnabled(true)
  addBtn:setBright(true)
  delBtn:setTouchEnabled(false)
  delBtn:setBright(false)
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 2
  pop["titleName"]  = UITool.ToLocalization("捐献提示")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = callFunc
  SceneManager:showMsgMode(pop)
end
-- 获取所有的邮件
-- print("测试 邮件 gold   = "..t_data["data"]["gold"])
-- print("测试 邮件 gem    = "..t_data["data"]["gem"])
-- print("测试 邮件 eq     = "..t_data["data"]["eq"])
-- print("测试 邮件 others = "..t_data["data"]["others"])
function MsgManager:getAllMail(gold,gem,eq,others)
  -- body
   local node  = cc.CSLoader:createNode("MsgBoxNode_12.csb")

   local sGold = node:getChildByName("Text_GoldNum")
   local sEp   = node:getChildByName("Text_Enum")
   local sGem  = node:getChildByName("Text_GemNum")
   local other = node:getChildByName("Text_OtherNum")
   sGold:setString(gold)
   sGem:setString(gem)
   sEp:setString(eq)
   other:setString(others)
  local pop = {}
  pop["buttonType"] = 1
  pop["formType"]   = 2
  pop["titleName"]  = UITool.ToLocalization("收取成功")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  --pop["oneself"]    = oneSelf
 -- pop["callFunc"]   = callFunc
  SceneManager:showMsgMode(pop)
end
--商店点击装备需要显示的详细   
--  现在因为商店的道具屋是阶梯价格  所以隐藏左右的加减按钮所以加一个参数进行控制 isButton  修改日期是9.12  和策划确定在十一月之前的版本不会修改 
--  根据 有偿 免费的钻石的类型 来显示  但是只是道具屋有这样的显示  所以把商店的id传进来 
-- 因为  isButton 这个是和道具屋并存的  所以用它判断也是一样的 就不用传商店的id
function MsgManager:ShopEquipInfo( item_type,item_id,item_num,cost_type,cost_num,max_buy_num,oneSelf,callfunc,isButton )
  -- body
    local item_data = UITool.getItemInfos(item_type,item_id)
  local node = nil
    node = cc.CSLoader:createNode("MsgBoxNode_13.csb")
    local item_rarity_bg = node:getChildByName("Image_icon_bg")--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByName("Image_icon_form")--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
    local item_img = node:getChildByName("Image_icon")--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])

    local skillName = node:getChildByName("Text_skill_name_1")
    skillName:setString(item_data[9])
    local skillDec  = node:getChildByName("Text_dec_1")
    local des = string.gsub(item_data[10],"*","")
    skillDec:setString(des)

    local skillName_2 = node:getChildByName("Text_skill_name_2")
    local skillDec_2 = node:getChildByName("Text_dec_2")
    if item_data[11] == 0 then
      skillName:setAnchorPoint(0.5,0.5)
      skillName:setPosition(0,30)
      skillDec:setAnchorPoint(0.5,0.5)
      skillDec:setPosition(0,-30)
      skillName_2:setVisible(false)
      skillDec_2:setVisible(false)
    else
      skillName:setAnchorPoint(0,0.5)
      skillName:setPosition(-250,30)
      skillDec:setAnchorPoint(0,0.5)
      skillDec:setPosition(-80,30)
      skillName_2:setVisible(true)
      skillDec_2:setVisible(true)
      skillName_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_name"]))--(passive_sk[item_data[12]]["sk_name"])
      skillDec_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_des"]))--(passive_sk[item_data[12]]["sk_des"])
    end

    local name_text = node:getChildByName("Text_name")--名称
    name_text:setString(item_data[5].."X"..item_num)
    if g_channel_control.transform_MsgManager_char_x == true then
      name_text:setString(item_data[5].."x"..item_num)
    end
    -- local des_text = node:getChildByName("Text_dec")--描述
    --  local des = string.gsub(item_data[6],"*","")
    -- des_text:setString(des)

    local property_node = node:getChildByName("Image_property")

    local hp_text = property_node:getChildByName("Text_hp")--最大hp
    hp_text:setString(item_data[8])
    local atk_text = property_node:getChildByName("Text_attck")--最大atk
    atk_text:setString(item_data[7])

    local cost_icon = node:getChildByName("Image_gem")--消耗类型icon
    cost_icon:setUnifySizeEnabled(true)
    cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

  local cost_text = node:getChildByName("Text_number")--消耗的数量
  cost_text:setString(cost_num)
    
    local buy_num_text = property_node:getChildByName("Text_tex_0")--购买的数量
    buy_num_text:setString(1)

    function touchCallBack(sender,eventType)
       if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Button_add" then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum +1
               buy_num_text:setString(nowNum)
               cost_text:setString(nowNum*cost_num)
               if nowNum >= max_buy_num then
                  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end   
               if nowNum > 1 then
                  local btn_bg = node:getChildByName("Image_numBg")
                  local delBtn = btn_bg:getChildByName("Button_Subtract")   
                  delBtn:setTouchEnabled(true)
                  delBtn:setBright(true)
               end
            elseif sender:getName() == "Button_Subtract" then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum - 1
               buy_num_text:setString(nowNum)
               cost_text:setString(nowNum*cost_num)
               if nowNum < 2 then
                  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end  
               print("now"..nowNum.."---max"..max_buy_num) 
               if  max_buy_num > nowNum  then
                  local btn_bg = node:getChildByName("Image_numBg")
                  local addBtn = btn_bg:getChildByName("Button_add")   
                  addBtn:setTouchEnabled(true)
                  addBtn:setBright(true)
               end

         end
       end
    end

    local btn_bg = node:getChildByName("Image_numBg")
    local addBtn = btn_bg:getChildByName("Button_add")--加号
    addBtn:addTouchEventListener(touchCallBack)
    local delBtn = btn_bg:getChildByName("Button_Subtract")--减号
    delBtn:addTouchEventListener(touchCallBack)
  


    --因为是阶梯价格  所以隐藏左右的加减按钮
    if isButton then
      local Test_text = node:getChildByName("Text_tex")

      if cost_type == 17 then
        Test_text:setString(UITool.ToLocalization("消费   有偿星石"))
      else
        Test_text:setString(UITool.ToLocalization("消费   免费星石"))
      end
      addBtn:setVisible(false)
      delBtn:setVisible(false)
    end
    delBtn:setTouchEnabled(false)
    delBtn:setBright(false)
    if max_buy_num < 2 then
       addBtn:setTouchEnabled(false)
       addBtn:setBright(false)
    end

    function buyItemCallBack()
        print("点击购买按钮回调")
        callfunc(tonumber(buy_num_text:getString()),oneSelf)

    end

  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 3
  pop["titleName"]  = UITool.ToLocalization("物品信息")
  pop["OKBtnName"]  = UITool.ToLocalization("购买")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = buyItemCallBack
  SceneManager:showMsgMode(pop)
end
-- 开始铸造 imag 物品图标  name  物品名字   不是消耗的 item是消耗物品的
function MsgManager:forgeStartModel( imag,name,item_name,item_num,item_name1,item_num_1,cost_type,cost_num,oneSelf,callfunc)
  -- body

  local node = cc.CSLoader:createNode("MsgBoxNode_11.csb")
  local img = node:getChildByTag(91)--装备图标
  img:setUnifySizeEnabled(true)
  img:loadTexture(imag)

  local name1 = node:getChildByTag(93)
  name1:setString(name)


  local dec = node:getChildByTag(94)
  local str = UITool.ToLocalization("是否消耗: %s %d, %s %d")
  local desStr =string.format(str, item_name,item_num,item_name1,item_num_1)
  if g_channel_control.MsgBoxNode_11_anchor == true then 
    dec:setPosition(cc.p(0,-9.5))
    dec:setAnchorPoint(cc.p(0.5,0.5))

    local title551 = node:getChildByTag(551)
    title551:setPosition(cc.p(0,-57))
    title551:setAnchorPoint(cc.p(0.5,0.5))

  end
  -- UITool.ToLocalization("是否消耗: ")..item_name.." "..item_num..", "..item_name1.." "..item_num_1
  dec:setString(desStr)

  local cost_icon = node:getChildByTag(115)--消耗类型icon
  cost_icon:setUnifySizeEnabled(true)
  cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])


  local cost_n = node:getChildByTag(116)
  cost_n:setString(cost_num)
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 3
  pop["titleName"]  = UITool.ToLocalization("物品信息")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
  SceneManager:showMsgMode(pop)
end
-- 背包道具使用的类型
function MsgManager:showBagModelItem( item_type,item_id,item_num,oneSelf,callfunc,img,dec,name)
  -- body
  local item_data = UITool.getItemInfos(item_type,item_id)
  node = cc.CSLoader:createNode("MsgBoxNode_1.csb")
  if img then
      local item_img = node:getChildByTag(91)--装备图标
      item_img:setUnifySizeEnabled(true)
      item_img:loadTexture(img)

      local des_text = node:getChildByTag(94)--描述
      des_text:setString(dec) 

      local name_text = node:getChildByTag(93)--名称
      name_text:setString(name)
      local pop = {}
      pop["buttonType"] = 1
      pop["formType"]   = 2
      pop["titleName"]  = UITool.ToLocalization("物品信息")
      pop["OKBtnName"]  = UITool.ToLocalization("确定")
      pop["nodeCsb"]    = node
      pop["oneself"]    = oneSelf
      pop["callFunc"]   = callfunc
      SceneManager:showMsgMode(pop)
  else
  -- 待定的实现   根据需求暂时留着
    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])

    local item_img = node:getChildByTag(92)--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])
    
    local name_text = node:getChildByTag(93)--名称
    name_text:setString(item_data[5])

    local des_text = node:getChildByTag(94)--描述
    local des = string.gsub(item_data[6],"*","")
    des_text:setString(des)    

    -- local itemNum = node:getChildByTag(116)
    -- itemNum:setString(item_num)
    local pop = {}
    pop["buttonType"] = 1
    pop["formType"]   = 2
    pop["titleName"]  = UITool.ToLocalization("物品信息")
    pop["OKBtnName"]  = UITool.ToLocalization("确定")
    pop["nodeCsb"]    = node
    pop["oneself"]    = oneSelf
    pop["callFunc"]   = callfunc
    SceneManager:showMsgMode(pop)
  end
end

--道具详情，多用于活动兑换 huobi 3.png lingzhuang2.png 
--参数 item_type 道具类型  
--item_id 道具ID
--equipInfos  装备额外信息（如 随机技能等等）
function MsgManager:showSimpItemInfo(item_type,item_id,n_num,titleName, equipInfos,callfunc)

  if item_type ==16 then
      MsgManager:showBaseSpine(item_id)
      return
  end  

	local item_data = UITool.getItemInfos(item_type,item_id)
  if item_data == nil then
      return
  end
	local node = nil
	if  item_type ==3 then
	    node = cc.CSLoader:createNode("MsgBoxNode_4.csb")
	    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
	    item_rarity_bg:setUnifySizeEnabled(true)
	    item_rarity_bg:loadTexture(item_data[4]) 

	    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
	    item_rarity_icon:setUnifySizeEnabled(true)
	    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          if elementImg then
            elementImg:setAnchorPoint(cc.p(0.5,0.5))
            --  elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
            elementImg:setPosition(134.5,113)
            elementImg:setScale(0.6)
            item_rarity_icon:addChild(elementImg)
          end

      end  

	    local item_img = node:getChildByTag(92)--装备图标
	    item_img:setUnifySizeEnabled(true)
	    item_img:loadTexture(item_data[2])
	    
      local name_text = node:getChildByTag(93)--名称
      if n_num then
        name_text:setString(item_data[5].." x"..n_num)
      else
         name_text:setString(item_data[5])
      end

      local property_node = node:getChildByTag(119)

      local hp_text = property_node:getChildByTag(120)--最大hp
      hp_text:setString(item_data[8])

      if isTrue then
          local hp_text = property_node:getChildByTag(649)--最大hp
          hp_text:setVisible(true)
      end

      local atk_text = property_node:getChildByTag(121)--最大atk
      atk_text:setString(item_data[7])

      local skillName = node:getChildByName("Text_skill_name_1")
      skillName:setString(item_data[9])
      local skillDec  = node:getChildByName("Text_dec_1")
      local des = string.gsub(item_data[10],"*","")
      skillDec:setString(des)


      --技能描述
      local skillName_2 = node:getChildByName("Text_skill_name_2")
      local skillDec_2 = node:getChildByName("Text_dec_2")
      if item_data[11] == 0 then
        skillName:setAnchorPoint(0.5,0.5)
        skillName:setPosition(0,-43)
        skillDec:setAnchorPoint(0.5,0.5)
        skillDec:setPosition(0,-103)
        skillName_2:setVisible(false)
        skillDec_2:setVisible(false)
      else
        skillName:setAnchorPoint(1,0.5)
        skillName:setPosition(-114,-43)
        skillDec:setAnchorPoint(0,0.5)
        skillDec:setPosition(-80,-43)
        skillName_2:setVisible(true)
        skillDec_2:setVisible(true)
        skillName_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_name"]))--(passive_sk[item_data[12]]["sk_name"])
        skillDec_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_des"]))--(passive_sk[item_data[12]]["sk_des"])
        skillName_2:setPosition(cc.p(-114,-103))
        skillName_2:setAnchorPoint(cc.p(1,0.5))

      end

      --随机技能新加的(有没有)
      --装备随机技能
      if equipInfos then 
            for i = 1,2 do
              local prsk = node:getChildByName("pRsk"..i)
              if equipInfos["rsk"] ~= nil and equipInfos["rsk"][i] ~= nil then
                  prsk:setVisible(true)
                  local strsrc = UITool.getUserLanguage(eq_random_sk[equipInfos["rsk"][i][1]])--eq_random_sk[equipInfos["rsk"][i][1]]
                  strsrc = string.gsub(strsrc,"%*",""..(equipInfos["rsk"][i][2]))
                  prsk:getChildByName("rskDesc"):setString(strsrc)
              else
                  prsk:setVisible(false)
              end
          end
      end 
	else
      node = cc.CSLoader:createNode("MsgBoxNode_1.csb")
      local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
      item_rarity_bg:setUnifySizeEnabled(true)
	    item_rarity_bg:loadTexture(item_data[4]) 

	    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
	    item_rarity_icon:setUnifySizeEnabled(true)
	    item_rarity_icon:loadTexture(item_data[1])
      --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          if elementImg ~= nil then
            elementImg:setAnchorPoint(cc.p(0.5,0.5))
            --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
            elementImg:setPosition(134.5,113)
            elementImg:setScale(0.6)
            item_rarity_icon:addChild(elementImg)
          end
      end  
	    local item_img = node:getChildByTag(92)--装备图标
	    item_img:setUnifySizeEnabled(true)
	    item_img:loadTexture(item_data[2])
	    
      local name_text = node:getChildByTag(93)--名称
      if n_num then
        name_text:setString(item_data[5].." x"..n_num)
      else
         name_text:setString(item_data[5])
      end

      local des_text = node:getChildByTag(94)--描述
      local des = "";
      if item_data and item_data[6] then
        des = string.gsub(item_data[6],"*","")
      end
      des_text:setString(des)      
	end
  print("showSimpItemInfo  == 进入了函数体")
	local pop = {}
	pop["buttonType"] = 1
	pop["formType"]   = 2
  if  item_type ==3 then 
      pop["formType"]   = 3
  end  
  if titleName then
    pop["titleName"] = titleName
  else
	   pop["titleName"]  = UITool.ToLocalization("物品详细")
  end
	pop["nodeCsb"]    = node
  pop["callFunc"]   = callfunc
	SceneManager:showMsgMode(pop)
end
---铸造专用，装备equipInfos 装备额外信息（如 随机技能等等）
function MsgManager:showSimpItemInfo1( item_type,item_id,isTrue,oneself,callfunc, equipInfos)
  -- body
    local item_data = UITool.getItemInfos(item_type,item_id)
  local node = nil
      node = cc.CSLoader:createNode("MsgBoxNode_4.csb")
      local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
      item_rarity_bg:setUnifySizeEnabled(true)
      item_rarity_bg:loadTexture(item_data[4]) 

      local item_rarity_icon = node:getChildByTag(91)--稀有度边框
      item_rarity_icon:setUnifySizeEnabled(true)
      item_rarity_icon:loadTexture(item_data[1])
      --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          if elementImg ~= nil then
            elementImg:setAnchorPoint(cc.p(0.5,0.5))
            --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
            elementImg:setPosition(134.5,113)
            elementImg:setScale(0.6)
            item_rarity_icon:addChild(elementImg)
          end
      end  

      local item_img = node:getChildByTag(92)--装备图标
      item_img:setUnifySizeEnabled(true)
      item_img:loadTexture(item_data[2])
      
      local name_text = node:getChildByTag(93)--名称
      name_text:setString(item_data[5])

      local property_node = node:getChildByTag(119)

      local hp_text = property_node:getChildByTag(120)--最大hp
      hp_text:setString(item_data[8])

      if isTrue then
          local hp_text = property_node:getChildByTag(649)--最大hp
          hp_text:setVisible(true)
      end
      --随机技能新加的(有没有)
      --装备随机技能
      if equipInfos then 
            for i = 1,2 do
              local prsk = node:getChildByName("pRsk"..i)
              if equipInfos["rsk"] ~= nil and equipInfos["rsk"][i] ~= nil then
                  prsk:setVisible(true)
                  local strsrc = UITool.getUserLanguage(eq_random_sk[equipInfos["rsk"][i][1]])--eq_random_sk[equipInfos["rsk"][i][1]]
                  strsrc = string.gsub(strsrc,"%*",""..(equipInfos["rsk"][i][2]))
                  prsk:getChildByName("rskDesc"):setString(strsrc)
              else
                  prsk:setVisible(false)
              end
          end
      end 

      local atk_text = property_node:getChildByTag(121)--最大atk
      atk_text:setString(item_data[7])

      local skillName = node:getChildByName("Text_skill_name_1")
      skillName:setString(item_data[9])
      local skillDec  = node:getChildByName("Text_dec_1")
      local des = string.gsub(item_data[10],"*","")
      skillDec:setString(des)

      --技能描述
      local skillName_2 = node:getChildByName("Text_skill_name_2")
      local skillDec_2 = node:getChildByName("Text_dec_2")
      if item_data[11] == 0 then
        skillName:setAnchorPoint(0.5,0.5)
        skillName:setPosition(0,-43)
        skillDec:setAnchorPoint(0.5,0.5)
        skillDec:setPosition(0,-103)
        skillName_2:setVisible(false)
        skillDec_2:setVisible(false)
      else
        skillName:setAnchorPoint(1,0.5)
        skillName:setPosition(-104,-43)
        skillDec:setAnchorPoint(0,0.5)
        skillDec:setPosition(-80,-43)
        skillName_2:setVisible(true)
        skillDec_2:setVisible(true)
        skillName_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_name"]))--(passive_sk[item_data[12]]["sk_name"])
        skillDec_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_des"]))--(passive_sk[item_data[12]]["sk_des"])

        skillName_2:setPosition(cc.p(-114,-103))
        skillName_2:setAnchorPoint(cc.p(1,0.5))
      end

      local pop = {}
      pop["buttonType"] = 1
      pop["formType"]   = 3
      pop["titleName"]  = UITool.ToLocalization("物品信息")
      pop["OKBtnName"]  = UITool.ToLocalization("购买")
      pop["nodeCsb"]    = node
      pop["oneself"]    = oneSelf
      pop["callFunc"]   = callfunc
      SceneManager:showMsgMode(pop)
end


--道具购买，多用于商店购买只有1库存的道具 lingzhuang-1.png huobi-2.png
--参数 item_type 道具类型
--item_id 道具ID 
--item_num 道具数量
--cost_type 消耗道具类型 1 金币  2 星石 13 苍玉
--cost_num  消耗的数量
--oneSelf   代理者
--callfunc  回调方法
function MsgManager:shopBuyItemInfo(item_type,item_id,item_num,cost_type,cost_num,oneSelf,callfunc)
	local item_data = UITool.getItemInfos(item_type,item_id)
  if item_data == nil then
     return
  end
	local node = nil
	if  item_type ==3 then --星之卵
	    node = cc.CSLoader:createNode("MsgBoxNode_5.csb")
	    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
	    item_rarity_bg:setUnifySizeEnabled(true)
	    item_rarity_bg:loadTexture(item_data[4]) 

	    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
	    item_rarity_icon:setUnifySizeEnabled(true)
	    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
	    local item_img = node:getChildByTag(92)--装备图标
	    item_img:setUnifySizeEnabled(true)
	    item_img:loadTexture(item_data[2])
	    
      local name_text = node:getChildByTag(93)--名称
      name_text:setString(item_data[5].."X"..item_num)


      local property_node = node:getChildByTag(119)

      local hp_text = property_node:getChildByTag(120)--最大hp
      hp_text:setString(item_data[8])

      local atk_text = property_node:getChildByTag(121)--最大atk
      atk_text:setString(item_data[7])

      local skill_node = node:getChildByTag(104)

  		local sk_name_text = skill_node:getChildByTag(122)--技能名称
  		sk_name_text:setString(item_data[9])

  		local sk_des_text = skill_node:getChildByTag(124)--技能描述
      local des = string.gsub(item_data[10],"*","")
  		sk_des_text:setString(des)

  		local cost_icon = node:getChildByTag(115)--消耗类型icon
  		cost_icon:setUnifySizeEnabled(true)
      cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

  		local cost_text = cost_icon:getChildByTag(116)--消耗的数量
  		cost_text:setString(cost_num)


	else --其他
      node = cc.CSLoader:createNode("MsgBoxNode_2.csb")
      local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
      item_rarity_bg:setUnifySizeEnabled(true)
	    item_rarity_bg:loadTexture(item_data[4]) 

	    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
	    item_rarity_icon:setUnifySizeEnabled(true)
	    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
         -- elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
         elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
	    local item_img = node:getChildByTag(92)--装备图标
	    item_img:setUnifySizeEnabled(true)
	    item_img:loadTexture(item_data[2])
	    
      local name_text = node:getChildByTag(93)--名称
      print("item_num item_num == "..item_num)
      name_text:setString(item_data[5].."X"..item_num)

      local des_text = node:getChildByTag(94)--描述
      local des = string.gsub(item_data[6],"*","")
      des_text:setString(des)

      local cost_icon = node:getChildByTag(115)--消耗类型icon
      cost_icon:setUnifySizeEnabled(true)
      cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

  		local cost_text = node:getChildByTag(116)--消耗的数量
  		cost_text:setString(cost_num)      
	end
	local pop = {}
	pop["buttonType"] = 2
	pop["formType"]   = 3
	pop["titleName"]  = UITool.ToLocalization("物品信息")
	pop["OKBtnName"]  = UITool.ToLocalization("购买")
	pop["nodeCsb"]    = node
	pop["oneself"]    = oneSelf
  pop["callFunc"]   = callfunc
	SceneManager:showMsgMode(pop)
end


--道具购买，多用于商店购买可选次数的道具 sucai2-1.png
--参数 item_type 道具类型
--item_id 道具ID 
--item_num 道具数量
--cost_type 消耗道具类型 1 金币  2 星石 13 苍玉
--cost_num  消耗的数量
--max_buy_num  最大购买次数
--oneSelf   代理者
--callfunc  回调方法
--  现在因为商店的道具屋是阶梯价格  所以隐藏左右的加减按钮所以加一个参数进行控制 isButton  修改日期是9.12  和策划确定在十一月之前的版本不会修改 
function MsgManager:shopBuyItemsInfo(item_type,item_id,item_num,cost_type,cost_num,max_buy_num,oneSelf,callfunc,isButton)
	local item_data = UITool.getItemInfos(item_type,item_id)
	local node = nil
    node = cc.CSLoader:createNode("MsgBoxNode_7.csb")
    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
    local item_img = node:getChildByTag(92)--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])
    
    local name_text = node:getChildByTag(93)--名称
    name_text:setString(item_data[5].."X"..item_num)

    local des_text = node:getChildByTag(94)--描述
     local des = string.gsub(item_data[6],"*","")
    des_text:setString(des)

    local cost_icon = node:getChildByTag(274)--消耗类型icon
    cost_icon:setUnifySizeEnabled(true)
    cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

	local cost_text = cost_icon:getChildByTag(238)--消耗的数量
	cost_text:setString(cost_num)
    
    local buy_num_text = node:getChildByTag(243)--购买的数量
    buy_num_text:setString(1)

    function touchCallBack(sender,eventType)
    	 if eventType == ccui.TouchEventType.ended then
            if sender:getTag() == 242 then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum +1
               buy_num_text:setString(nowNum)
               cost_text:setString(nowNum*cost_num)
               if nowNum >= max_buy_num then
               	  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end   
               if nowNum > 1 then
               	  local btn_bg = node:getChildByTag(239)
                  local delBtn = btn_bg:getChildByTag(241)   
        				  delBtn:setTouchEnabled(true)
        				  delBtn:setBright(true)
               end
            elseif sender:getTag() == 241 then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum - 1
               buy_num_text:setString(nowNum)
               cost_text:setString(nowNum*cost_num)
               if nowNum < 2 then
               	  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end  
               print("now"..nowNum.."---max"..max_buy_num) 
               if  max_buy_num > nowNum  then
               	  local btn_bg = node:getChildByTag(239)
                  local addBtn = btn_bg:getChildByTag(242)   
        				  addBtn:setTouchEnabled(true)
        				  addBtn:setBright(true)
               end

			   end
	     end
    end
    
    local btn_bg = node:getChildByTag(239)
    local addBtn = btn_bg:getChildByTag(242)--加号
    addBtn:addTouchEventListener(touchCallBack)
    local delBtn = btn_bg:getChildByTag(241)--减号
    delBtn:addTouchEventListener(touchCallBack)
    if isButton then
      local Test_text = node:getChildByName("Text_tex")
      Test_text:setAnchorPoint(cc.p(1,0.5))

      if cost_type == 17 then
        Test_text:setString(UITool.ToLocalization("消费   有偿星石"))
      else
        Test_text:setString(UITool.ToLocalization("消费   免费星石"))
      end
      addBtn:setVisible(false)
      delBtn:setVisible(false)
    end
    delBtn:setTouchEnabled(false)
    delBtn:setBright(false)
    if max_buy_num < 2 then
       addBtn:setTouchEnabled(false)
       addBtn:setBright(false)
    end

    function buyItemCallBack()
   	    print("点击购买按钮回调")
   	    callfunc(tonumber(buy_num_text:getString()),oneSelf)

    end

	local pop = {}
	pop["buttonType"] = 2
	pop["formType"]   = 3
	pop["titleName"]  = UITool.ToLocalization("物品信息")
	pop["OKBtnName"]  = UITool.ToLocalization("购买")
	pop["nodeCsb"]    = node
	pop["oneself"]    = self
  pop["callFunc"]   = buyItemCallBack
	SceneManager:showMsgMode(pop)
end


--道具贩卖，多用于背包进行出售素材等 fanmai.png
--参数 item_type 道具类型
--item_id 道具ID 
--cost_type 贩卖获得货币的类型 1 金币  2 星石 13 苍玉
--cost_num  单个贩卖所得的货币数
--max_buy_num  最大贩卖的次数
--oneSelf   代理者
--callfunc  回调方法
--costOnly  单价
--itemNum   道具数量
-- sellType 贩卖类型  0 是不能贩卖
function MsgManager:sellItemsInfo(item_type,item_id,cost_type,cost_num,max_buy_num,oneSelf,callfunc,costOnly,itemNum,sellType)
	print("sellType == "..sellType)
  local item_data = UITool.getItemInfos(item_type,item_id)
	local node = nil
    node = cc.CSLoader:createNode("MsgBoxNode_8.csb")
    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
         -- elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
         elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
    local item_img = node:getChildByTag(92)--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])
    
    local name_text = node:getChildByTag(93)--名称
    name_text:setString(item_data[5])

    -- local des_text = node:getChildByTag(94)--描述
    -- des_text:setString(item_data[6])

    local cost_icon = node:getChildByTag(274)--消耗类型icon
    cost_icon:setUnifySizeEnabled(true)
    cost_icon:loadTexture(SHOP_BUY_TYPE[cost_type])

	 local cost_text = cost_icon:getChildByTag(238)--消耗的数量
	 cost_text:setString(cost_num)
    
    local buy_num_text = node:getChildByTag(243)--购买的数量
    buy_num_text:setString(1)

    local title_text = node:getChildByTag(114)--购买的数量
    title_text:setString(UITool.ToLocalization("获得"))

    local onlyCost_i   = node:getChildByTag(407)     -- 单价消费类型
    onlyCost_i:setUnifySizeEnabled(true)
    onlyCost_i:loadTexture(SHOP_BUY_TYPE[cost_type])

    local onlyCost     = onlyCost_i:getChildByTag(408) -- 单价
    onlyCost:setString(costOnly)

    local iNum       = node:getChildByTag(409)   -- item 数量
    iNum:setString(itemNum)

    local btn_bg    = node:getChildByTag(239)
    local addBtn    = btn_bg:getChildByTag(242)--加号
    local delBtn    = btn_bg:getChildByTag(241)--减号
    local dataTable = {
      ["btnLeft"]    = delBtn,
      ["btnRight"]   = addBtn,
      ["maxMatNum"]  = max_buy_num,
      ["lbCurNum"]   = buy_num_text,
      ["cost_text"]  = cost_text,
      ["cost_num"]   = cost_num,
      ["curMatNum"]  = 1,
      ["longclickT"] = 1
  }
    local LongClick = Longclick_num.new():init(dataTable)--delBtn,addBtn,max_buy_num,buy_num_text,cost_text,cost_num
    -- -- 长点击自增自减
    -- local curaddNum = 1  -- 保存自增自减的数量
    -- local addSu = 1  -- 1 加 2 减
    -- local function tsteNum( ... )
    --   -- body
    --   node:stopAllActions()
    --   local function function_name( ... )
    --     -- body
    --     if addSu == 1 then
    --         curaddNum = curaddNum + 1
    --         if curaddNum >= max_buy_num then
    --             addBtn:setTouchEnabled(false)
    --             addBtn:setBright(false)
    --             curaddNum = max_buy_num
    --             node:stopAllActions()
    --         elseif curaddNum > 1 then
    --             delBtn:setTouchEnabled(true)
    --             delBtn:setBright(true)
                  
    --         end 
    --     elseif addSu == 2 then
    --         curaddNum = curaddNum - 1
    --         if curaddNum < 2 then
    --             delBtn:setTouchEnabled(false)
    --             delBtn:setBright(false)
    --             curaddNum = 1
    --             node:stopAllActions()
    --         elseif curaddNum < max_buy_num then
    --             addBtn:setTouchEnabled(true)
    --             addBtn:setBright(true)

                  
    --         end 
    --     end
    --     buy_num_text:setString(curaddNum)
    --     cost_text:setString(curaddNum*cost_num)
    --     print("curaddNum curaddNum == "..curaddNum)
    --   end 
    --     local delay = cc.DelayTime:create(0.1)
    --     local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function_name))
    --     local action = cc.RepeatForever:create(sequence)
    --     node:runAction(action)

    -- end 
    -- function touchCallBack(sender,eventType)
    --     if eventType == ccui.TouchEventType.began then
    --         if sender:getTag() == 242 then
    --           addSu = 1
    --         else
    --           addSu = 2
    --         end
    --         local delay = cc.DelayTime:create(2)
    --         local rep1 = cc.Repeat:create(cc.Sequence:create(delay, cc.CallFunc:create(tsteNum)),1)
    --         node:runAction(rep1)
    --     elseif eventType == ccui.TouchEventType.canceled then
    --         node:stopAllActions()
    --     elseif eventType == ccui.TouchEventType.ended then
    --          node:stopAllActions()
    --         -- curaddNum = 1
    --         if sender:getTag() == 242 then
    --            local nowNum = tonumber(buy_num_text:getString())
    --            nowNum = nowNum +1
    --            buy_num_text:setString(nowNum)
    --            cost_text:setString(nowNum*cost_num)
    --            if nowNum >= max_buy_num then
    --               sender:setTouchEnabled(false)
    --               sender:setBright(false)
    --            end   
    --            if nowNum > 1 then
    --               -- local btn_bg = node:getChildByTag(239)
    --               -- local delBtn = btn_bg:getChildByTag(241)   
    --               delBtn:setTouchEnabled(true)
    --               delBtn:setBright(true)
    --            end
    --         elseif sender:getTag() == 241 then
    --            local nowNum = tonumber(buy_num_text:getString())
    --            nowNum = nowNum - 1
    --            buy_num_text:setString(nowNum)
    --            cost_text:setString(nowNum*cost_num)
    --            if nowNum < 2 then
    --               sender:setTouchEnabled(false)
    --               sender:setBright(false)
    --            end  
    --            print("now"..nowNum.."---max"..max_buy_num) 
    --            if  max_buy_num > nowNum  then
    --               -- local btn_bg = node:getChildByTag(239)
    --               -- local addBtn = btn_bg:getChildByTag(242)   
    --               addBtn:setTouchEnabled(true)
    --               addBtn:setBright(true)
    --            end

    --      end
    --    end
    -- end
    

    -- addBtn:addTouchEventListener(touchCallBack)

    -- delBtn:addTouchEventListener(touchCallBack)
    -- delBtn:setTouchEnabled(false)
    -- delBtn:setBright(false)
    -- if max_buy_num < 2 then
    --    addBtn:setTouchEnabled(false)
    --    addBtn:setBright(false)
    -- end

    function buyItemCallBack()
   	    print("点击购买按钮回调")
   	    callfunc(tonumber(LongClick:getCurMatNum()),oneSelf)

    end

	local pop = {}
	pop["buttonType"] = 2
	pop["formType"]   = 3
	pop["titleName"]  = UITool.ToLocalization("物品贩卖")
	pop["OKBtnName"]  = UITool.ToLocalization("贩卖")
	pop["nodeCsb"]    = node
	pop["oneself"]    = self
  if sellType ~= nil and sellType == 0 then
    print("进入了贩卖灰色的函数")
    pop["Brish_en"]  = sellType
  end
  pop["callFunc"]   = buyItemCallBack
	SceneManager:showMsgMode(pop)
end


--道具对话，多用于大型活动兑换
--参数 item_type 道具类型
--item_id 道具ID 
--max_buy_num  最大兑换的次数
--oneSelf   代理者
--callfunc  回调方法
function MsgManager:exchangeItemsInfo(item_type,item_id,max_buy_num,oneSelf,callfunc)
  local item_data = UITool.getItemInfos(item_type,item_id)
  local node = nil
    node = cc.CSLoader:createNode("MsgBoxNode_7.csb")
    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
    local item_img = node:getChildByTag(92)--装备图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])
    
    local name_text = node:getChildByTag(93)--名称
    name_text:setString(item_data[5])

    local des_text = node:getChildByTag(94)--描述
     local des = string.gsub(item_data[6],"*","")
    des_text:setString(des)

    local cost_icon = node:getChildByTag(274)--消耗类型icon
    
    cost_icon:setVisible(false)
    
    local buy_num_text = node:getChildByTag(243)--购买的数量
    buy_num_text:setString(1)

    local title_text = node:getChildByTag(114)--购买的数量
    title_text:setString(UITool.ToLocalization("获得"))
    title_text:setVisible(false)

    function touchCallBack(sender,eventType)
       if eventType == ccui.TouchEventType.ended then
            if sender:getTag() == 242 then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum +1
               buy_num_text:setString(nowNum)
               if nowNum >= max_buy_num then
                  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end   
               if nowNum > 1 then
                  local btn_bg = node:getChildByTag(239)
                  local delBtn = btn_bg:getChildByTag(241)   
                  delBtn:setTouchEnabled(true)
                  delBtn:setBright(true)
               end
            elseif sender:getTag() == 241 then
               local nowNum = tonumber(buy_num_text:getString())
               nowNum = nowNum - 1
               buy_num_text:setString(nowNum)
               if nowNum < 2 then
                  sender:setTouchEnabled(false)
                  sender:setBright(false)
               end  
               print("now"..nowNum.."---max"..max_buy_num) 
               if  max_buy_num > nowNum  then
                  local btn_bg = node:getChildByTag(239)
                  local addBtn = btn_bg:getChildByTag(242)   
                  addBtn:setTouchEnabled(true)
                  addBtn:setBright(true)
               end

         end
       end
    end
    
    local btn_bg = node:getChildByTag(239)
    local addBtn = btn_bg:getChildByTag(242)--加号
    addBtn:addTouchEventListener(touchCallBack)
    local delBtn = btn_bg:getChildByTag(241)--减号
    delBtn:addTouchEventListener(touchCallBack)
    delBtn:setTouchEnabled(false)
    delBtn:setBright(false)
    if max_buy_num < 2 then
       addBtn:setTouchEnabled(false)
       addBtn:setBright(false)
    end

    function buyItemCallBack()
        print("点击购买按钮回调")
        callfunc(tonumber(buy_num_text:getString()), oneSelf)

    end

  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 3
  pop["titleName"]  = UITool.ToLocalization("物品兑换")
  pop["OKBtnName"]  = UITool.ToLocalization("兑换")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = buyItemCallBack
  SceneManager:showMsgMode(pop)
end




--道具详情，多用于强化，突破等，能跳转到道具掉落位置 sucai1.png
--参数 item_type 道具类型 目前只有素材
--item_id 道具ID
-- 是否需要回调 没有可以为nil  或是不用理会不填
-- 回调的函数   没有可以为nil  或是不用理会不填
function MsgManager:showSimpItemInfoAndDropInfo(item_type,item_id,isCallFunc,callFunc,onself,hideCallFunc)
	local item_data = UITool.getItemInfos(item_type,item_id)
    local node = cc.CSLoader:createNode("MsgBoxNode_3.csb")

    local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
    item_rarity_bg:setUnifySizeEnabled(true)
    item_rarity_bg:loadTexture(item_data[4]) 

    local item_rarity_icon = node:getChildByTag(91)--稀有度边框
    item_rarity_icon:setUnifySizeEnabled(true)
    item_rarity_icon:loadTexture(item_data[1])
    --属性球
    if item_data[3] ~= "" then 
        local elementImg = cc.Sprite:create(item_data[3])
        elementImg:setAnchorPoint(cc.p(0.5,0.5))
       -- elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
        elementImg:setPosition(134.5,113)
        elementImg:setScale(0.6)
        item_rarity_icon:addChild(elementImg)
    end 

    local item_img = node:getChildByTag(92)--图标
    item_img:setUnifySizeEnabled(true)
    item_img:loadTexture(item_data[2])
    
    local name_text = node:getChildByTag(93)--名称
    name_text:setString(item_data[5])

    local des_text = node:getChildByTag(94)--描述
     local des = string.gsub(item_data[6],"*","")
    des_text:setString(des)

    local pass_drop_state = mat[item_id]["mat_pass"]
    local exploer_drop_state = mat[item_id]["mat_explore"]

    function touchCallBack(sender,eventType)
    	 if eventType == ccui.TouchEventType.ended then
          if sender:getTag() == 101 then
            print("去关卡")
            SceneManager:hideMsgMode()
            if hideCallFunc then
              hideCallFunc(onself)
            end
            local rcvData = {}
            rcvData["item_type"] = item_type
            rcvData["item_id"] = item_id
            rcvData["isCallFunc"] = isCallFunc
            rcvData["callFunc"]   = callFunc
            rcvData["self"]       = onself
            SceneManager:toBattlePassListLayer(rcvData)
          elseif sender:getTag() == 102 then
              if tonumber(user_info["rank"]) >= UnlockExploreRank then
                  if hideCallFunc then
                    hideCallFunc(onself)
                  end 
                  SceneManager:hideMsgMode()
                  local rcvData = {}
                  rcvData.isBackStartLayer = 0
                  rcvData["isCallFunc"] = isCallFunc
                  rcvData["callFunc"]   = callFunc
                  rcvData["self"]       = onself
                  SceneManager:toExploreLayer(rcvData)
                  print("去探索")
              else 
              ---todo锁住 星界
                   local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),UnlockExploreRank)
                  SceneManager:showPromptLabel(str)
              end 
          end
       end
	end
    
    local pass_drop_btn = node:getChildByTag(101)--关卡掉落
    pass_drop_btn:addTouchEventListener(touchCallBack)
    if  pass_drop_state == 0 then
    	pass_drop_btn:setTouchEnabled(false)
    	local drop_img = pass_drop_btn:getChildByTag(108)
    	drop_img:loadTexture("n_UIShare/AllMessgae/tc_ui_011_2.png")
    	local drop_text = pass_drop_btn:getChildByTag(107)
    	drop_text:setTextColor(cc.c4b(200,200,200,255))
    end

    local exploer_drop_btn = node:getChildByTag(102)--探索掉落
    exploer_drop_btn:addTouchEventListener(touchCallBack)
    if  exploer_drop_state == 0 then
    	exploer_drop_btn:setTouchEnabled(false)
    	local drop_img = exploer_drop_btn:getChildByTag(111)
    	drop_img:loadTexture("n_UIShare/AllMessgae/tc_ui_011_2.png")
    	local drop_text = exploer_drop_btn:getChildByTag(110)
    	drop_text:setTextColor(cc.c4b(200,200,200,255))
    end
	local pop = {}
	pop["buttonType"] = 1
	pop["formType"]   = 3
	pop["titleName"]  = UITool.ToLocalization("物品详细")
	pop["nodeCsb"]    = node
	SceneManager:showMsgMode(pop)
end
--通关奖励 equipInfos 装备额外信息（如 随机技能等等）
function MsgManager:showRewardItem(item_type,item_id,num,equipInfos)
  local item_data = UITool.getItemInfos(item_type,item_id)
  if item_data == nil then
     return
  end
  num = num or 0
  local numStr = ""
  if num >0 then 
      numStr = "(x"..num..")"
  end 
  local node = nil
  if  item_type ==3 then
      node = cc.CSLoader:createNode("MsgBoxNode_4.csb")
      local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
      item_rarity_bg:setUnifySizeEnabled(true)
      item_rarity_bg:loadTexture(item_data[4]) 

      local item_rarity_icon = node:getChildByTag(91)--稀有度边框
      item_rarity_icon:setUnifySizeEnabled(true)
      item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
      local item_img = node:getChildByTag(92)--装备图标
      item_img:setUnifySizeEnabled(true)
      item_img:loadTexture(item_data[2])
      
      local name_text = node:getChildByTag(93)--名称

      name_text:setString(item_data[5]..numStr)

      local property_node = node:getChildByTag(119)

      local hp_text = property_node:getChildByTag(120)--最大hp
      hp_text:setString(item_data[8])

      if isTrue then
          local hp_text = property_node:getChildByTag(649)--最大hp
          hp_text:setVisible(true)
      end

      local atk_text = property_node:getChildByTag(121)--最大atk
      atk_text:setString(item_data[7])

      local skillName = node:getChildByName("Text_skill_name_1")
      skillName:setString(item_data[9])
      local skillDec  = node:getChildByName("Text_dec_1")
      local des = string.gsub(item_data[10],"*","")
      skillDec:setString(des)

      --技能描述
      local skillName_2 = node:getChildByName("Text_skill_name_2")
      local skillDec_2 = node:getChildByName("Text_dec_2")
      if item_data[11] == 0 then
        skillName:setAnchorPoint(0.5,0.5)
        skillName:setPosition(0,-43)
        skillDec:setAnchorPoint(0.5,0.5)
        skillDec:setPosition(0,-103)
        skillName_2:setVisible(false)
        skillDec_2:setVisible(false)
      else
        skillName:setAnchorPoint(1,0.5)
        skillName:setPosition(-114,-43)
        skillDec:setAnchorPoint(0,0.5)
        skillDec:setPosition(-80,-43)
        skillName_2:setVisible(true)
        skillDec_2:setVisible(true)
        skillName_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_name"]))--(passive_sk[item_data[12]]["sk_name"])
        skillDec_2:setString(UITool.getUserLanguage(passive_sk[item_data[12]]["sk_des"]))--(passive_sk[item_data[12]]["sk_des"])

        skillName_2:setPosition(cc.p(-114,-103))
        skillName_2:setAnchorPoint(cc.p(1,0.5))
      end

      --装备随机技能
      if equipInfos then 
            for i = 1,2 do
              local prsk = node:getChildByName("pRsk"..i)
              if equipInfos["rsk"] ~= nil and equipInfos["rsk"][i] ~= nil then
                  prsk:setVisible(true)
                  local strsrc = UITool.getUserLanguage(eq_random_sk[equipInfos["rsk"][i][1]])--eq_random_sk[equipInfos["rsk"][i][1]]
                  strsrc = string.gsub(strsrc,"%*",""..(equipInfos["rsk"][i][2]))
                  prsk:getChildByName("rskDesc"):setString(strsrc)
              else
                  prsk:setVisible(false)
              end
          end
      end 

  else
      node = cc.CSLoader:createNode("MsgBoxNode_1.csb")
      local item_rarity_bg = node:getChildByTag(90)--技能稀有度背景
      item_rarity_bg:setUnifySizeEnabled(true)
      item_rarity_bg:loadTexture(item_data[4]) 

      local item_rarity_icon = node:getChildByTag(91)--稀有度边框
      item_rarity_icon:setUnifySizeEnabled(true)
      item_rarity_icon:loadTexture(item_data[1])
            --属性球
      if item_data[3] ~= "" then 
          local elementImg = cc.Sprite:create(item_data[3])
          elementImg:setAnchorPoint(cc.p(0.5,0.5))
          --elementImg:setPosition(item_rarity_icon:getContentSize().width,item_rarity_icon:getContentSize().height)
          elementImg:setPosition(134.5,113)
          elementImg:setScale(0.6)
          item_rarity_icon:addChild(elementImg)
      end  
      local item_img = node:getChildByTag(92)--装备图标
      item_img:setUnifySizeEnabled(true)
      item_img:loadTexture(item_data[2])
      
      local name_text = node:getChildByTag(93)--名称
      name_text:setString(item_data[5]..numStr)

      local des_text = node:getChildByTag(94)--描述
      local des = string.gsub(item_data[6],"*","")
      des_text:setString(des)      
  end
  print("showSimpItemInfo  == 进入了函数体")
  local pop = {}
  pop["buttonType"] = 1
  pop["formType"]   = 2
  if  item_type ==3 then 
      pop["formType"]   = 3
  end  
  pop["titleName"]  = UITool.ToLocalization("通关奖励")
  pop["nodeCsb"]    = node
  SceneManager:showMsgMode(pop)
end

--修改名字
function MsgManager:showChangeNameInfo(oneSelf,callFunc,showStr)
  -- body
  local node = cc.CSLoader:createNode("MsgBoxNode_name.csb")
  local textfield = node:getChildByTag(101)

  -- textfield:setText("") --暂时不用
  -- textfield:setPlaceHolder("点击输入新昵称")
  -- textfield:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
  -- textfield:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
  local bgImg = node:getChildByTag(100)
  textfield:setVisible(false)
  bgImg:setVisible(false)
  --testEditbox
  local img = "n_UIShare/playerCard/wjmp_ui_004.png"
  local pos = cc.p(0,0)
  local _editBoxDes = UITool.getEditBox(img, bgImg:getContentSize(), pos, 8, UITool.ToLocalization("点击输入新昵称"))
  node:addChild(_editBoxDes,1)

  function changeCallBack()
      callFunc(_editBoxDes:getText(),oneSelf)
  end

  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("修改昵称")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = changeCallBack
  SceneManager:showMsgMode(pop)
end

--两个lab的提示窗
function MsgManager:showTwoLabInfo(oneSelf,callFunc,str1,str2)
  -- body
  local node = cc.CSLoader:createNode("MsgBoxNodeTBattleEnd.csb")
  local lab1 = node:getChildByTag(101)
  local lab2 = node:getChildByTag(102)
  lab1:setString(str1)
  if g_channel_control.transform_MsgManager_lab1_fontSize == true then
    local oldFontSize = lab2:getFontSize()
    lab1:setFontSize(oldFontSize)
  end
  lab2:setTextColor(cc.c3b(255,255,255))
  lab2:setString(str2)
  local function changeCallBack()
      callFunc(oneSelf)
  end
  local pop = {}
  pop["buttonType"] = 1
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = changeCallBack
  SceneManager:showMsgMode(pop)
end

-- 共鸣道具
function MsgManager:showGMInfo(oneSelf,callFunc,intimacyNum,resonance_prop_num,bBtnCanTouch)
  local node = cc.CSLoader:createNode("MsgBoxNode_GM.csb")

  local titleInfo = node:getChildByTag(234);
  if titleInfo and g_channel_control.transform_showGMInfo_Title_Alignment == true then 
        titleInfo:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        titleInfo:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        titleInfo:ignoreContentAdaptWithSize(false);
        titleInfo:setTextAreaSize(cc.size(500,64))
        titleInfo:setPosition(cc.p(0,30))
  end 

  local lbGMInfo = node:getChildByTag(236)
  local strGmInfo = string.format(UITool.ToLocalization("当前共鸣值%d，当前共鸣契约%d"),intimacyNum,resonance_prop_num)
  if strGmInfo then
    lbGMInfo:setString(strGmInfo)
  end

  local function changeCallBack()
      callFunc(oneSelf)
  end
  local pop = {}
  pop["buttonType"] = 2
  pop["formType"]   = 1
  pop["titleName"]  = UITool.ToLocalization("提示")
  pop["OKBtnName"]  = UITool.ToLocalization("确定")
  pop["nodeCsb"]    = node
  pop["oneself"]    = self
  pop["callFunc"]   = changeCallBack
  if bBtnCanTouch ~= nil then
    pop["bBtnCanTouch"]   = bBtnCanTouch
  end
  SceneManager:showMsgMode(pop)
end
