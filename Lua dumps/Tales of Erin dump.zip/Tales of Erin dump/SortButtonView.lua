
SortButtonView = class("SortButtonView", XUIView)
SortButtonView.CS_FILE_NAME = "SortButtonView.csb"
SortButtonView.CS_BIND_TABLE = 
{
    sortBtnSort = "/i:169/s:btnSort",
    sortBtnSortTitle = "/i:169/s:btnSort/s:btnSortTitle",
    sortBtnAsc = "/i:169/s:btnAsc",
    sortBtnDesc = "/i:169/s:btnDesc"
}

function SortButtonView:init(rootNode,strkey,defmode,reType)
    SortButtonView.super.init(self,rootNode)

    --升序按钮
    self.sortBtnAsc:setPressedActionEnabled(false)
    self.sortBtnAsc:addClickEventListener(function()
    
        local num = math.floor(self.sortMode/100)     
        local num1 = self.sortMode % 10
        self:setSortMode(num * 100 + num1 + 10 )
       
    end)
    --降序按钮
    self.sortBtnDesc:setPressedActionEnabled(false)
    self.sortBtnDesc:addClickEventListener(function()
    
        local num = math.floor(self.sortMode/100)     
        local num1 = self.sortMode % 10
        self:setSortMode(num * 100 + num1 + 20 )

    end)

    self.reType = reType

    self.sortBtnSort:setPressedActionEnabled(false)
    self.sortBtnSort:addClickEventListener(function()
        local sortview = SortBoxView.new():init(self.reType)
        sortview.beforeCloseEvent = function(sender,stype)
            if not stype then
                --没选择，不处理
                return
            end

            local num = math.floor(self.sortMode / 10)            
            local sort = num%10 --升降序            
            --local sort_type = math.floor(num/10) --属性类型

            self:setSortMode(stype + sort * 10)

        end
        sortview:setSortMode(self.sortMode)
        GameManagerInst:showModalView(sortview)
    end)

    self:setSortKey(strkey,defmode)
    
    return self
end

function SortButtonView:getSortMode()
    return self.sortMode
end

function SortButtonView:setSortKey(strkey,defmode)

    self.sortKey = strkey

    if not self.sortKey then return end

    self.sortMode = cc.UserDefault:getInstance():getIntegerForKey(self.sortKey)
    if self.sortMode == 0 then
        self.sortMode = defmode
    end
    
    --self:setSortMode(self.)
    
    local num = math.floor(self.sortMode/10)
    
    local sort = num%10 --升降序
    
    -- local sort_type = math.floor(num/10) --属性类型

    self.sortBtnAsc:setVisible(sort ~= 1)
    self.sortBtnDesc:setVisible(sort == 1)

    self.sortBtnSortTitle:setString(SortBoxView.GetSortName(self.sortMode,self.reType))
end


function SortButtonView:setSortMode(sort_mode)
    if self.sortMode ~= sort_mode then --  提升效率 排序模式非变化不走此刷新逻辑
        self.sortMode = sort_mode
        cc.UserDefault:getInstance():setIntegerForKey(self.sortKey,self.sortMode)
   
        local num = math.floor(sort_mode/10)
    
        local sort = num%10 --升降序
    
        -- local sort_type = math.floor(num/10) --属性类型

        self.sortBtnAsc:setVisible(sort ~= 1)
        self.sortBtnDesc:setVisible(sort == 1)

        self.sortBtnSortTitle:setString(SortBoxView.GetSortName(self.sortMode,self.reType))

        if self.sortModeChangedEvent then
            self.sortModeChangedEvent(self,self.sortMode)
        end
    end
    
end