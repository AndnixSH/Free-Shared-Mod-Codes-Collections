--require "XUIView"

GMEffectView = class("GMEffectView",XUIView)
GMEffectView.CS_FILE_NAME = "GMEffectView.csb"
GMEffectView.CS_BIND_TABLE = {
    panelLight = "/s:panelLight",
    panelDark = "/s:panelDark",

    panelDialog = "/s:panelDialog",
}

function GMEffectView:init(nHeroId,finalFunc)
    GMEffectView.super.init(self)

    self.hero_id = nHeroId

    self.videoPlayer = ccexp.VideoPlayer:create()
    self.videoPlayer:setAnchorPoint(cc.p(0.5, 0.5))
    self.videoPlayer:setPosition(640,360)
    self.videoPlayer:setContentSize(cc.size(1280, 720))
    local stoped = false
    self.videoPlayer:addEventListener(function(sender,eventType)
        local function stopfunc()
            if not stoped then
                stoped = true
                self.panelLight:setOpacity(255)
                self.panelLight:runAction(cc.FadeIn:create(0.0))
                UITool.delayTask(0,function()  
                    self:nextStep()
                end)
            end
        end

        if eventType == ccexp.VideoPlayerEvent.PLAYING then
        elseif eventType == ccexp.VideoPlayerEvent.PAUSED then
            stopfunc()
        elseif eventType == ccexp.VideoPlayerEvent.STOPPED then       
        elseif eventType == ccexp.VideoPlayerEvent.COMPLETED  then 
            local targetPlatform = cc.Application:getInstance():getTargetPlatform()
            if cc.PLATFORM_OS_ANDROID == targetPlatform then
                stopfunc()
            else 
                if self.videoPlayer.isPlaying then 
                else 
                    stopfunc()
                end 
            end
        end
    end)
    self:getRootNode():addChild(self.videoPlayer)

    self.finalFunc = finalFunc
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        ---
        print("KeyboardManager GMEffectView not registeredKeyBoardEvent")
    end)

    self:startPlay()

    return self
end
  
function GMEffectView:startPlay()
    self.currentStep = 0
    self.videoPlayer:setFileName(GM_MP4[1])
    self.videoPlayer:play()
end

function GMEffectView:nextStep()
    --currentStep 
    -- 0  播放视频
    -- 1  角色对话

    if not self.currentStep or self.currentStep < 0 then
        self:startPlay()
    elseif self.currentStep == 0 then
        --播放特效
        self.videoPlayer:addEventListener(function()end)
        self.videoPlayer:stop()
        if not tolua.isnull(self.videoPlayer) then
            self.videoPlayer:removeFromParent()
        end
        self.videoPlayer = nil

        local function whiteCallBack()
            self.currentStep = 1
            self:playDialog()


        end
        local fadeOut = cc.FadeOut:create(0.5)
        local sequence = cc.Sequence:create(fadeOut, cc.CallFunc:create(whiteCallBack))
        self.panelLight:runAction(sequence)
    else
        if self.finalFunc then
            self.finalFunc()
        end
        
        self:returnBack()
    end
end

function GMEffectView:playDialog()
    if not self.hero_id then return end
    local h_id_num = getNumID( self.hero_id )
    --hero_h412.json
    if GameManagerInst.gameType == 2 then
        local storyName = girlback[h_id_num][2]
        if not storyName or storyName == "" then
            self._rootNode:removeChildByTag(999)
            self:nextStep()
        else
            local dialogfile = "story/"..storyName..".json"
            --local dialogfile = "story/c1s2e3l0.json"
            local param = {}
            param["rcvData"] = {}
            param["rcvData"]["filename"] = dialogfile--filename
            param["rcvData"]["hiddenSkipBtn"] = 1--hiddenSkipBtn 
            --param["rcvData"]["autoPlay"] = 0
            param["rcvData"]["callFunc"] = function ( obj )
                self._rootNode:removeChildByTag(999)
                self:nextStep()
            end 
            param["rcvData"]["obj"] = self 
            self._rootNode:addChild(DialogLayer:create(param).uiLayer,10,999)
        end
    end
end

function GMEffectView:returnBack()
    if self._navigationView then
        self._navigationView:popView()
    end
end

function GMEffectView:onNavigateTo(isback)
    if not isback then
        --self:startPlay()
    end
end