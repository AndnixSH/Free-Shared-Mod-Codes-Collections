--BattleLayer的父layer。
--created by kobejaw.2018.5.15.
BattleContainerLayer = class("BattleContainerLayer", function()
    return cc.Layer:create();
end);

local idx = 0

function BattleContainerLayer:ctor()
    G_BattleContainerLayer = self

    self:setContentSize(cc.p(1280,720))
    self:setAnchorPoint(cc.p(0.5,0.5))

    if BattleDataManager.isBoss then
        self:setPosition3D(cc.vec3(0,0,0))
        self.zoomState = 2;  --1.远镜头。 2.近镜头。
    else
        self:setPosition3D(cc.vec3(0,0,-100))
        self.zoomState = 1;  --1.远镜头。 2.近镜头。
    end

    local bgLayer = BattleBGLayer:create()
    self:addChild(bgLayer)
    bgLayer:setPositionY(-80)

    local battleLayer = BattleLayer:create()
    self:addChild(battleLayer)

    self.isZooming = false
    self.isShaking = false
    self.isZooming_BigSkill = false
    self.initialPosZ = -100

    self.zoomState = 1;  --1.远镜头。 2.近镜头。 
    idx = 3
end

--检测镜头拉近拉远
function BattleContainerLayer:checkZoom()    
    idx = idx + 1
    if idx >= 3 then
        idx = 0
        if G_GameState == 2 or G_GameState == 3 then
            return
        end

        local role =  BattleCameraManager:getRightestRole()
        local monster = BattleCameraManager:getLeftestMonster()

        if role and monster and monster:getPositionX()-role:getPositionX() > 500 then
            self:zoomOut()
        else
            self:zoomIn()
        end
    end
end

--镜头拉远
function BattleContainerLayer:zoomOut()
    if self.isZooming or self.isZooming_BigSkill or self.isShaking or self.zoomState == 1 then
        return
    end

    local function func1()
        self.isZooming = true
    end

    local function func2()
        self.isZooming = false
        self.zoomState = 1
    end

    local move = cc.MoveTo:create(0.3,cc.vec3(0,0,-100))

    local seq = cc.Sequence:create(cc.CallFunc:create(func1),move,cc.DelayTime:create(1),cc.CallFunc:create(func2))
    self:stopAllActions()
    self:runAction(seq)    
end

--镜头拉近
function BattleContainerLayer:zoomIn()
    if self.isZooming or self.isZooming_BigSkill or self.isShaking or self.zoomState == 2 then
        return
    end

    local function func1()
        self.isZooming = true
    end

    local function func2()
        self.isZooming = false
        self.zoomState = 2
    end

    local move = cc.MoveTo:create(0.3,cc.vec3(0,0,0))

    local seq = cc.Sequence:create(cc.CallFunc:create(func1),move,cc.DelayTime:create(1),cc.CallFunc:create(func2))
    self:stopAllActions()
    self:runAction(seq)
end

function BattleContainerLayer:startShake(shakeId)
    if self.isZooming or self.isShaking or self.isZooming_BigSkill or not shakeSkill[shakeId] then
        return
    end

    local actions = {}
    local initialPosX = G_BattleContainerLayer:getPositionX()
    local initialPosY = G_BattleContainerLayer:getPositionY()
    for i = 1, #shakeSkill[shakeId] do
        local data =shakeSkill[shakeId][i] 
        local action = cc.MoveTo:create(data.shake_t/1000,cc.p((initialPosX+data["shake_x"]),(initialPosY+data["shake_y"])))
        table.insert(actions, action)
    end

    function actionCallBack(  )
        self.isShaking = false
    end

    local callBack =  cc.CallFunc:create(actionCallBack)
    table.insert(actions, callBack)
    local shakeSeq = cc.Sequence:create(actions)

    self:stopAllActions()
    self:runAction(shakeSeq)
    self.isShaking = true
end

--大招时的镜头拉近并左移,施放技能时调用
function BattleContainerLayer:zoomIn_BigSkill(role)
    if self.isZooming_BigSkill then
        return
    end

    self:stopAllActions()
    self.isZooming_BigSkill = true
    self.isShaking = false
    self.isZooming = false

    self.initialPosZ = self:getPositionZ()

    local posInScreen = role:convertToWorldSpace(cc.p(0,0))
    local offsetX
    if posInScreen.x < 450 then
        offsetX = 60
    else
        offsetX = 0
    end

    local move2 = cc.MoveTo:create(0.2,cc.vec3(offsetX,0,self.initialPosZ + 20))
    self:runAction(move2)
end

--大招时的恢复,cunEnd时调用
function BattleContainerLayer:zoomOut_BigSkill()
    self:stopAllActions()

    local move2 = cc.MoveTo:create(0.2,cc.vec3(0,0,self.initialPosZ))

    local this = self
    local function onMoveFinish()
        this.isZooming_BigSkill = false
    end

    self:runAction(cc.Sequence:create(move2,cc.CallFunc:create(onMoveFinish)))
end

function BattleContainerLayer:onChangeWave()
    self:setPosition3D(cc.vec3(0,0,-100))
    self.initialPosZ = -100
    self:stopAllActions()
    self.isZooming = false
    self.isShaking = false
    self.isZooming_BigSkill = false
    self.zoomState = 1
end