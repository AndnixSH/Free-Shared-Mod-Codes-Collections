
BattleUIInfo = class("BattleUIInfo") 
BattleUIInfo.__index = BattleUIInfo
BattleUIInfo.rootNode = nil
BattleUIInfo.timeText = nil --显示时间
BattleUIInfo.panelWave = nil --wave波数的panel对象
BattleUIInfo.bxText = nil --宝箱数量展示
BattleUIInfo.boxCount = 0 --宝箱数量
BattleUIInfo.nowHit = 0
BattleUIInfo.BATTLE_UI_HIT  = "uifile/coBom.csb"
BattleUIInfo.BaoXiang_PATH = "uifile/BaoXiang.csb"
BattleUIInfo.pointTable = {1,2,3,4,5,6,7}
function BattleUIInfo:createWithMainUINode(node)
    local battleInfo = BattleUIInfo.new()
    battleInfo:init(node)
    return battleInfo
end

function BattleUIInfo:init(node)
	self.rootNode = node 
	local imgNode = self.rootNode:getChildByTag(30)
    self.timeText = imgNode:getChildByTag(3001)

    self.panelWave = self.rootNode:getChildByTag(4000)
    local panel_2 = self.rootNode:getChildByTag(2) 
    self.bxText = ccui.Helper:seekWidgetByTag(panel_2,203)
    self.boxCount = 0
    if G_STAGE_TYPE == 2 then
       self.panelWave:setVisible(false)
       panel_2:setVisible(false)
    else
       local panel_ranker = self.rootNode:getChildByTag(61)
       panel_ranker:setVisible(false)     
    end	

    --游戏时间
    self.gameTime = 0
    self.tempTime = 0
    self.isTimeUp = false
    self:setCountDownTime()

    --连击相关
    --当前连击的次数
    self.nowHit = 0 
    self.istimeEnd = false
    self.timeEnd = 0
    -- 显示攻击的node 
    self.hitNode   = self.rootNode:getChildByTag(358);
    self.panel_hit = self.hitNode:getChildByTag(1);
    -- 显示当前连击
    self.addNum    = self.panel_hit:getChildByTag(101)
    -- 显示当前伤害加成
    self.hitUp     = self.panel_hit:getChildByTag(102):getChildByTag(103)
    self.addHitCsb = "uifile/coBom.csb"
    self.boxCount = 0

    self.boxList = {}
end

function BattleUIInfo:setWave(now,max) -- 设置波数
	local  nowWave = ccui.Helper:seekWidgetByTag(self.panelWave,4003)
	nowWave:setUnifySizeEnabled(true)
	nowWave:loadTexture(self:getWaveImg(now))
	local  maxWave = ccui.Helper:seekWidgetByTag(self.panelWave,4004)
	maxWave:setUnifySizeEnabled(true)
	maxWave:loadTexture(self:getWaveImg(max))
end

function BattleUIInfo:getWaveImg(num) --获取波数图片
	local imgFile = "n_UIShare/zhandou/zdzx_ui_018.png"
	if num == 2 then 
	   imgFile = "n_UIShare/zhandou/zdzx_ui_019.png"
    elseif num == 3 then
        imgFile = "n_UIShare/zhandou/zdzx_ui_020.png"
    end
    return imgFile
end

function BattleUIInfo:dropBox(count,beginPos,battleLayer)
    self.pointTable = {1,2,3,4,5,6,7}

    self.boxCount = self.boxCount + count
    self.bxText:setString(self.boxCount)

    for i = 1,  count do
        self:playBoxAni(beginPos,battleLayer)
    end
end

function BattleUIInfo:playBoxAni(beginPos,battleLayer)
    local actionNode = cc.CSLoader:createNode(self.BaoXiang_PATH);
    table.insert(self.boxList,actionNode)
    battleLayer:addChild(actionNode)
    local random = math.random(7)
    local posIndex = self.pointTable[random] or 0
    table.remove( self.pointTable, random )
    local endPoint = cc.p(0,0);
    if posIndex == 1 then
        endPoint = beginPos;
    elseif posIndex == 2 then
        endPoint.x = beginPos.x-54;
        endPoint.y = beginPos.y-6;
    elseif posIndex == 3 then
        endPoint.x = beginPos.x+56;
        endPoint.y = beginPos.y-12;
    elseif posIndex == 4 then
        endPoint.x = beginPos.x-26;
        endPoint.y = beginPos.y+38;
    elseif posIndex == 5 then
        endPoint.x = beginPos.x+36;
        endPoint.y = beginPos.y+30;
    elseif posIndex == 6 then
        endPoint.x = beginPos.x-22;
        endPoint.y = beginPos.y-42;
    elseif posIndex == 7 then
        endPoint.x = beginPos.x+35;
        endPoint.y = beginPos.y-55;
    end
    local this = self
    local function BaoXiangEnd()
        actionNode:setVisible(false)
    end
    actionNode:setPosition(endPoint);
    local action = cc.CSLoader:createTimeline(self.BaoXiang_PATH);
    actionNode:runAction(action);
    action:play("BaoXiang", false);
    SetLastFrameCallFunc_AllPlatform(action,BaoXiangEnd,1)
end

--切换场景的时候调用一下
function BattleUIInfo:removeBox()
    if #self.boxList > 0 then
        for k,v in pairs(self.boxList) do
            v:removeFromParent()
        end
    end

    self.boxList = {}
end

-- 设置当前倒计时剩余时间
function BattleUIInfo:setCountDownTime( )
    local time    = (BattleDataManager.timeLimit - self.gameTime);
    local m       = (time/60);
    local s       = (time%60);
    local m_1     = (m/10);
    local m_2     = (m%10);
    local s_1     = (s/10);
    local s_2     = (s%10);
    if self.gameTime > BattleDataManager.timeLimit then
        self.isTimeUp = true
        --战斗时间到，战斗失败
        G_BattleScene:onTimeUp()        
    else
        self.remainTime = string.format("%d%d:%d%d",m_1,m_2,s_1,s_2)
        self.timeText:setFontName("uifile/font/Microsoft Yahei.ttf")
        self.timeText:setString(self.remainTime) 
    end    
end

-- 获取剩余时间
function BattleUIInfo:getRemainTime()
    return self.remainTime
end

function BattleUIInfo:update(dt)
    if self.isTimeUp then
        return
    end

    --倒计时更新
    self.tempTime = self.tempTime + dt
    if self.tempTime >= 1 then
        self.tempTime = 0
        self.gameTime = self.gameTime + 1
        self:setCountDownTime()
    end

    if G_GameState ~= 1 then
        return
    end

    --连击数更新
    if self.istimeEnd then
        self.timeEnd = self.timeEnd + dt
        if self.timeEnd >= 2 then
            self.timeEnd = 0
            self.istimeEnd = false
            self.nowHit = 0;
            self.hitNode:setVisible(false);   
            self.panel_hit:getChildByTag(102):setVisible(false);

            --触发时机15.
            self:checkTrigTime15()
        end
    end
end

function BattleUIInfo:addHit()
    --触发时机15.
    self:checkTrigTime15()

    self.nowHit = self.nowHit + 1;

    if (self.nowHit>1) then
        self.hitNode:setVisible(true);
 
        self.addNum:setString(tostring(self.nowHit))
        local num = BattleDamageCompute:getAddHitDmg(self.nowHit)
        if num then
            self.hitUp:setString(tostring(num).."%")
        else
            self.hitUp:setString("")
        end

        local action = nil;
        if (self.nowHit==2) then
            action = cc.CSLoader:createTimeline(self.addHitCsb);
            action:play("play1", false); 
        elseif (self.nowHit==HIT_NUM1) then
            self.panel_hit:getChildByTag(102):setVisible(true);
            action = cc.CSLoader:createTimeline(self.addHitCsb);
            action:play("play2", false);
        end
        if action then
            self.hitNode:runAction(action);
        end
    end
    self.istimeEnd = true
    self.timeEnd  = 0
end

--连击数发生变化时的触发时机检测
function BattleUIInfo:checkTrigTime15()
    if BattleRuntimeInfo.teams[1].isNeedCheckTrigTime15 then
        for k,v in pairs(BattleRuntimeInfo.teams[1].entities) do
            if not v.isDead then
                local option = {}
                v.triggerManager:check(15,option)
            end
        end
    end
end
