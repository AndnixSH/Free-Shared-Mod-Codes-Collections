--[[
	ActBanerManager.lua
	--#toType 跳转类型  0、默认无跳转 1、调用loadstring实现的 2、跳转到外部网页 3、打开appstore 去评价
	2、跳转到外部网页也可以用类型1实现
		cc.Application:getInstance():openURL(self._data[touchTag].url)
]]
ActBanerManager = class("ActBanerManager")

function ActBanerManager:ctor()
	self._actBanerNode = nil
  self._needLoadFile = nil
  self._selectActID = nil
	self._data = {}
end
function ActBanerManager:getActBanerNode()
	self._actBanerNode = ActBanerNode:create(self)
	return self._actBanerNode
end
---刷新baner
function ActBanerManager:updateBaner()

	 self:reqBanerList()
end
--处理点击活动
function ActBanerManager:dealBanerTouchEvent(touchTag)
	-- body
  	local banerTpye = tonumber(self._data[touchTag].toType)

  	if banerTpye == 0 then

  	elseif banerTpye == 1 then 
        --限制条件
        local unlock_lv = self._data[touchTag].unlock_lv or 1
        if  tonumber(user_info["rank"]) < unlock_lv  then
            local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"), unlock_lv)
            SceneManager:showPromptLabel(str)
        else 
            self._needLoadFile = self._data[touchTag].lua_file
            self._selectActID = self._data[touchTag].act_id
            loadstring(self._data[touchTag].parameter)()
        end 
  	elseif banerTpye == 2 then
  		--跳转到外部网页
  		cc.Application:getInstance():openURL(self._data[touchTag].parameter)
  	elseif banerTpye == 3 then 
  		  local  sData = { shopTypeIndex = 1}
        SceneManager:toShopLayer(sData) 
  	end 	
end

function ActBanerManager:requireFile()
    if self._needLoadFile~= nil then 
        require_ex(self._needLoadFile)
    end 
end

function ActBanerManager:getSelectActID()
  -- body
    return self._selectActID
end
function ActBanerManager:reqBanerList()
    -- body
    local function ReqSuccess(data)
      -- UITool.delayTask(0,function()  
      --       MsgManager:showSimpMsg("ActBanerManager:reqBanerList()")
      --   end)
    	self._data = data.banner_list
      if self._actBanerNode ~= nil and self._actBanerNode.updatePageView ~= nil then
         self._actBanerNode:updatePageView(self._data)
      end
    end
    local tempTable = {
        ["rpc"] = "banner_list",
    }
    self:doReq(tempTable, ReqSuccess)
end

function  ActBanerManager:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        --data不能为nil
        if not data then
          MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
        end
        data = tolua.cast(data, "PassData");
        --print("callBack-----"..data:getData())
        SceneManager:delWaitLayer()
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())

        -- UITool.delayTask(0,function()  
        --     MsgManager:showSimpMsg("ActBanerManager:reqBanerList()"..tostring(data:getData()))
        -- end)

        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            --failesFunc()
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    SceneManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
