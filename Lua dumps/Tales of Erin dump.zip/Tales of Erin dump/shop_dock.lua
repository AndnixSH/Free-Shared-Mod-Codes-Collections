-- 商店dock栏

shop_tab_config = {}

shop_tab_config[1] = {
    shop_name = "活动商店",
    shop_type = 6,
    nor_icon = "scjm_b_001_1.png",
    select_icon = "scjm_b_001_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {"615365",},
    tab_id = {1,},
    des = "",
}

shop_tab_config[2] = {
    shop_name = "充值商店",
    shop_type = 1,
    nor_icon = "sc_b_001_1.png",
    select_icon = "sc_b_001_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {"135959","135960",},
    tab_id = {1, 2},
    des = "",
}

shop_tab_config[3] = {
    shop_name = "礼包商店",
    shop_type = 7,
    nor_icon = "scjm_b_002_1.png",
    select_icon = "scjm_b_002_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {"135961","135962",},
    tab_id = {1, 2},
    des = "",
}

shop_tab_config[4] = {
    shop_name = "道具屋",
    shop_type = 2,
    nor_icon = "sc_b_002_1.png",
    select_icon = "sc_b_002_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {},
    tab_id = {},
    des = "",
}

shop_tab_config[5] = {
    shop_name = "神秘商店",
    shop_type = 3,
    nor_icon = "sc_b_003_1.png",
    select_icon = "sc_b_003_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {},
    tab_id = {},
    des = "",
}

shop_tab_config[6] = {
    shop_name = "苍玉商店",
    shop_type = 4,
    nor_icon = "sc_b_004_1.png",
    select_icon = "sc_b_004_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {},
    tab_id = {},
    des = "",
}

shop_tab_config[7] = {
    shop_name = "英雄圆桌",
    shop_type = 5,
    nor_icon = "sc_b_005_1.png",
    select_icon = "sc_b_005_2.png",
    help_pic = {"xsjx_sd_001.png", },
    tab_name = {},
    tab_id = {},
    des = "",
}
