--require "XUIView"
--require "RoleTeamItemView"

NewRoleTeamView = class("NewRoleTeamView",XUIView)
NewRoleTeamView.CS_FILE_NAME = "NewRoleTeamView.csb"
NewRoleTeamView.CS_BIND_TABLE = 
{
    psPanel = "/i:364/i:27",
    psShortImg = "/i:364/i:27/i:26",
    psVdrawImg = "/i:364/i:190",

    psTitleBG = "/i:364/i:53/i:54",
    titleSpine = "/i:364/i:53/i:63",
    btn_change_title = "/i:364/i:53/i:56",

    lbTitle = "/i:364/i:344",
    btnLeft = "/i:364/i:378",
    btnRight = "/i:364/i:379",
    btnPSKill = "/i:364/i:367",
    panel1 = "/i:364/i:204/i:205",
    panel2 = "/i:364/i:204/i:206",
    panel3 = "/i:364/i:204/i:207",
    panel4 = "/i:364/i:204/i:208",
    --
    --
    btnChangeName = "/i:364/i:142",
    btnTeamList = "/i:364/i:479",
    btnChangeTeam = "/i:364/i:145",
    lbTeamFp = "/i:364/i:508",
}
NewRoleTeamView.teamListNames = {"1","2","3","4","5",nil,nil,nil,nil,nil}

function NewRoleTeamView:init()
    NewRoleTeamView.super.init(self)
    self.items = {}
    
    self.currentTeamIndex = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
    if self.currentTeamIndex == 0 then
        self.currentTeamIndex = 1
    end    
    self.beginTeamIndex = self.currentTeamIndex

    for i = 1,4 do
        self.items[i] = NewRoleTeamItemView.new():init(self["panel"..i],i)
        self.items[i].BtnInfoClick = function(index)
            self:ItemInfo(index)            
        end
        self.items[i].BtnAddClick = function(index)
            self:ItemAdd(index)
        end
    end

    --self.psPanel:setVisible(false)
    self.psShortImg:setVisible(false)
    self.psVdrawImg:setVisible(false)

    local shortImgX = (self.psPanel:getContentSize().width - self.psShortImg:getContentSize().width)/2
    self.psShortImg:setPositionX(shortImgX)

    self.btnPSKill:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toPSkillLayer({resetcallback = function()  
                self:loadTeamList()
            end})
        end
    end)
 
    self.btnLeft:addClickEventListener(function()
        self:changeTeam(0)
    end)

    self.btnRight:addClickEventListener(function()
        self:changeTeam(6)
    end)

    self.btn_change_title:addClickEventListener(function ( ... )
        -- body
        self:toTitleLayer()
    end)

    self:setNodeLockState()

    --
    self.bOpenChangeTeam = false
    self.bOpenChangeName = false
    self.bOpenTeamList = false
    --
    self.btnChangeTeam:addClickEventListener(function()
        self:OnBtnChangeTeam()
    end)
    self.btnChangeName:addClickEventListener(function()
        self:ChangeNameInput()
    end)
    self.btnTeamList:addClickEventListener(function()
        self:OnBtnTeamList()
    end)
    --

    return self
end

function NewRoleTeamView:toTitleLayer( ... )
    -- body
    local rcvData = {}
    rcvData["from"] = "team"
    rcvData["team_id"] = self.currentTeamIndex
    rcvData["sFunc"] = function( )
        self:loadTeamList(handler(self,self.refresh))
    end
    SceneManager:toTitleBrowerLayer(rcvData)
end

function NewRoleTeamView:refreshTitle(  )
    -- body
    local teamInfo = team_list[""..self.currentTeamIndex]
    local titleId = teamInfo["title_id"]
    if self.m_titleID == nil or self.m_titleID ~= titleId then 
        self.m_titleID = titleId
        local spineNameStr = ""
        if title_conf[titleId] and title_conf[titleId].res_spine then
            spineNameStr = title_conf[titleId].res_spine
        end

        if self.m_titleSkeletonNode ~=nil then 
            self.m_titleSkeletonNode:stopAllActions()
            self.m_titleSkeletonNode:removeFromParent()
            self.m_titleSkeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            self.m_titleSkeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            local title_png = ccui.ImageView:create(spName.."png")
            local size = title_png:getContentSize()

            local titleSpineX = (self.titleSpine:getContentSize().width - size.width)/2 + size.width/2 - self.btn_change_title:getContentSize().width/2
            local titleSpineY = (self.titleSpine:getContentSize().height - size.height)/2 + size.height/2
            self.m_titleSkeletonNode:setPosition(cc.p(titleSpineX,titleSpineY))
            self.titleSpine:addChild(self.m_titleSkeletonNode)
            self.m_titleSkeletonNode:setAnimation(1, "effect", true)
            self.titleSpine:setVisible(false)
            local dt = cc.DelayTime:create(0.01)
            local cf = cc.CallFunc:create(function()
                self.titleSpine:setVisible(true)
            end)
            local seq = cc.Sequence:create(dt,cf)
            self.titleSpine:runAction(seq)
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 
end

function NewRoleTeamView:ChangeTeamCallBack(beginTeamIndex)
    self.beginTeamIndex = beginTeamIndex
    self:refresh()
end

function NewRoleTeamView:OnBtnChangeTeam()
    local changeTeamView = NewRoleTeamChangeView.new():init(self.ChangeTeamCallBack,self)
    SceneManager.rootLayer:addChild(changeTeamView:getRootNode())
end

function NewRoleTeamView:OnBtnTeamList()
    local teamListView = NewRoleTeamListView.new():init(self.changeTeam,self,self.currentTeamIndex,self.teamListNames)
    SceneManager.rootLayer:addChild(teamListView:getRootNode())
end

--弹出修改名字窗口
function NewRoleTeamView:ChangeNameInput()
    local rcvData = {}
    rcvData["sDelegate"] = self
    rcvData["confirmFunc"] =  self.ReqChangeName--self.ReqCheckNewName 
    rcvData["defalutStr"] = UITool.ToLocalization(self.teamListNames[self.currentTeamIndex])
    rcvData["maxLength"] = 6
    rcvData["isCheckWarnWord"] = g_channel_control.checkWarnWord
    self.inputLayer = SceneManager:toInputModelLayer(rcvData)
end

--检测新昵称敏感词
function NewRoleTeamView:ReqCheckNewName(newNameStr)

    local tempTable = {
        ["rpc"] = "user_name_check",
        ["name"] = newNameStr,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        self:ReqChangeName(newNameStr)
    end,
    function(state_code,msgText)
        --self:ChangeNameInput()
        GameManagerInst:alert(msgText)
    end,
    true)
end

--发送改名请求
function NewRoleTeamView:ReqChangeName(newNameStr)
    self.nowName = newNameStr
    --
    local tempTable = {
        ["rpc"] = "change_team_name",
        ["team_name"] = newNameStr,
        ["team_id"] = self.currentTeamIndex,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        self:loadTeamList()
        self.teamListNames[self.currentTeamIndex] = newNameStr
        self.lbTitle:setString(newNameStr)
        local str = UITool.ToLocalization("昵称修改成功")
        SceneManager:showPromptLabel(str)
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleTeamView:loadTeamList(callback)
    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success

        DataManager:wTeamData(data["team"])

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleTeamView:loadTeam()
    --["team_fp"]
    for i=1,10 do
        local teamList = team_list[""..i]
        if teamList and teamList["team_name"] then
            --
            self.teamListNames[i] = teamList["team_name"]
        else
            --TODO
        end
    end
    local teamInfo = team_list[""..self.currentTeamIndex]
    local teamInfoList = nil
    if teamInfo and teamInfo["team"] then
        teamInfoList = teamInfo["team"]
    end

    for i = 1,4 do
        local h = nil
        if teamInfoList and teamInfoList[i] then
            h = teamInfoList[i]
        end
        local roleInfo = h or {id="0"}
        self.items[i]:setRoleInfo(roleInfo)
        if roleInfo["id"] == "0" then
            self.items[i].BtnAddClick = function(index)
                --GameManagerInst:alert("self:ItemAdd   "..index)
                self:ItemAdd(index)
            end
        else
            self.items[i].BtnAddClick = function(index)
                --GameManagerInst:alert("self:ItemAdd   "..index)
                self:ItemInfo(index)
            end
        end
    end

    --左侧公主信息
    if teamInfo and teamInfo["ps"] then
        local oid =  teamInfo["ps"]  --公主职业id
        local end_pos = string.find(oid,'_') - 1
        local gid = string.sub(oid,0,end_pos)
        local psinfo = princess_ocp[gid][oid]

        if psinfo then
            local vdrawpath = psinfo.ps_vdraw
            if vdrawpath ~= nil and vdrawpath ~= "" then
                self.psVdrawImg:setVisible(true)
                self.psVdrawImg:setTexture(vdrawpath)
            else
                self.psVdrawImg:setVisible(false)
            end

            local namepath = psinfo.ps_name_short
            if namepath ~= nil and namepath ~= "" then
                --self.psPanel:setVisible(true)
                self.psShortImg:setVisible(true)
                self.psShortImg:setTexture(namepath)
            else
                self.psShortImg:setVisible(false)
                --self.psPanel:setVisible(false)
            end
        else
            --self.psPanel:setVisible(false)
            self.psShortImg:setVisible(false)
            self.psVdrawImg:setVisible(false)
        end
    end
    
    local teamName = self.teamListNames[self.currentTeamIndex]--  {UITool.ToLocalization("第一编队"),UITool.ToLocalization("第二编队"),UITool.ToLocalization("第三编队"),UITool.ToLocalization("第四编队"),UITool.ToLocalization("第五编队")}
    self.lbTitle:setString(UITool.ToLocalization(teamName))
    --
    if self.lbTeamFp then
        self.lbTeamFp:setString(""..team_list[tostring(self.currentTeamIndex)]["team_fp"])
    end

    local title_id = teamInfo["title_id"]
    self:refreshTitle(title_id)
    PlayerInfoSys:getInstance():setTeamTitleId(title_id)
end

function NewRoleTeamView:changeTeam(idx)
    if idx < 1 then
        self.currentTeamIndex = self.currentTeamIndex - 1
    elseif idx > 5 then
        self.currentTeamIndex = self.currentTeamIndex + 1
    else
        self.currentTeamIndex = idx
    end

    if self.currentTeamIndex < 1 then
        self.currentTeamIndex = 5
    end

    if self.currentTeamIndex > 5 then
        self.currentTeamIndex = 1 
    end

    cc.UserDefault:getInstance():setIntegerForKey("teamIdx",self.currentTeamIndex)
    self:loadTeam()
end

function NewRoleTeamView:ItemAdd(index)
    --GameManagerInst:alert("添加"..index)    
    local b,v = RoleListView.createWithBackBtn()

    v.ItemClickedEvent = function(item)
        --GameManagerInst:alert("self:onEditTeam("..index..","..item:getData().id)   
        self:onEditTeam(index,item:getData().id)
        b:returnBack()
    end

    v.ItemResetEvent = function(item)
        local rdata = item:getData()
        if rdata.isCurrentRole then
            --当前点中的人
            item:showOutTeam()
        end
    end

    v.dataSourceEvent = function(sender,sort_mode)
        local ds = {}
        local outteam = {}       
            
        local temp_data = nil
        if team_list[""..self.currentTeamIndex] ~= nil and team_list[""..self.currentTeamIndex]["team"] ~= nil then
            temp_data = team_list[""..self.currentTeamIndex]["team"]
        end

        for i = 1,#hero_list do
            local rdata = table.deepcopy(hero_list[i])
            local notInTeam = true

            for j = 1,4 do
                if temp_data ~= nil and temp_data[j] ~= nil and temp_data[j].id == rdata.id then
                    --在队伍中
                    table.insert(ds,rdata)
                    --当前点中的人
                    rdata.isCurrentRole = (j == index)

                    notInTeam = false
                    break
                end
            end

            if notInTeam then
                rdata.team_list = {}
                table.insert(outteam,rdata)
            end
        end

        SortBoxView.SortRole (ds, sort_mode ,false)
        SortBoxView.SortRole (outteam, sort_mode ,false)

        for i = 1,#outteam do
            table.insert(ds,outteam[i])
        end
        return ds
    end

    v:refresh()

    --新手引导 编队 保存数据
    if user_info["guide_id"] == guide_id_config.Team then
        self.ng_b = b
        self.ng_needId = v.currentDataSource[2].id
    end

    SceneManager.rootLayer:addChild(b:getRootNode())
end

function NewRoleTeamView:onEditTeam(index,hid)
    local temp_data = team_list[""..self.currentTeamIndex]

    --原始队伍信息
    local teamData = {}
    for i=1,4 do
        teamData[i] = temp_data["team"][i].id
    end    

    local nosame = true

    for i = 1,4 do
        if teamData[i] == hid then
            if i ~= index then
            --点了其他人
                teamData[i] = teamData[index]
                teamData[index] = hid
            else
                --点了自己
                teamData[index] = "0"
            end

            nosame = false
            break
        end
    end

    if nosame then
        teamData[index] = hid
    end

    local temp_team = {}
    temp_team["rpc"] = "team_edit"
    temp_team["team_id"] = self.currentTeamIndex
    temp_team["ps_id"] = temp_data["ps"]
    temp_team["team_info"] = teamData        

    GameManagerInst:rpc(temp_team,3,
    function(data)
        --success
        --第一次编队之后，更改下本地的配置
        if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam)~=1 then 
            cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam,1)
        end
        self.beginTeamIndex = self.currentTeamIndex
        DataManager:wTeamData(data["team"])

        for k,v in pairs(data["change_hero_list"]) do
            user_info["hero"][k] = table.deepcopy(v)
        end        
        DataManager:rfsHlist()

        self:refresh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleTeamView:saveTeamIndex(callback)
    if self.beginTeamIndex == self.currentTeamIndex then
        if callback then
            callback()
        end
        return
    end
    
    local temp_data = team_list[""..self.currentTeamIndex]
    local teamData = {}
    if temp_data then
        for i=1,4 do
            if temp_data["team"] and temp_data["team"][i] then
                teamData[i] = temp_data["team"][i].id
            end
        end 
    end
       
    local temp_team = {}
    temp_team["rpc"] = "team_edit"
    temp_team["team_id"] = self.currentTeamIndex
    if temp_data and temp_data["ps"] then
        temp_team["ps_id"] = temp_data["ps"]
    end
    temp_team["team_info"] = teamData       

    
    GameManagerInst:rpc(temp_team,3,
    function(data)
        --success
        self.beginTeamIndex = self.currentTeamIndex
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleTeamView:ItemInfo(index)
    --GameManagerInst:alert("详情"..index)
    local tempinfo = team_list[""..self.currentTeamIndex]["team"]
    local tempds = {}
    for i = 1,#tempinfo do
        if tempinfo[i].id ~= "0" then
            table.insert(tempds,tempinfo[i].id)
        end
    end

    local data = tempinfo[index]

    if GameManagerInst.gameType == 1 then
        if g_channel_control.b_newRole then
            GameManagerInst.view:pushView(NewRoleMainView.new():init(data.id,tempds,self.currentTeamIndex))
        else
            GameManagerInst.view:pushView(RoleInfoView.new():init(data.id,tempds,self.currentTeamIndex))
        end
    elseif GameManagerInst.gameType == 2 then
        SceneManager:toRoleInfo({ hid = data.id  , 
            hlist = tempds,
            teamidx = self.currentTeamIndex
            })
    end
end

function NewRoleTeamView:refresh()
    self:loadTeam()
    self:dealRedDotPrompt() 
end

--新手引导
function NewRoleTeamView:newGuideTeamFunc()
    --新手引导 编队
    self:onEditTeam(2,self.ng_needId)
    self.ng_b:returnBack()
end

--设置按钮等级解锁状态
function NewRoleTeamView:setNodeLockState()
    local curNodes = {self.btnPSKill}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleTeamView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        end 
    end  
    self:dealRedDotPrompt() 
end
---根据本地配置表处理按钮小红点的显示状态
function NewRoleTeamView:dealRedDotPrompt()
    local event_3 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Godhead)   --队伍按钮，神格按钮
     self:setbtnPSKillRedDop(false)
    if event_3 == 0 then --队伍按钮，神格按钮
        self:setbtnPSKillRedDop(true)
    end 
end
--神格小红点显示
function NewRoleTeamView:setbtnPSKillRedDop(_isShow)
    local oldTip = self.btnPSKill:getChildByTag(TIP_POINT_TAG)
    if _isShow then 
        if oldTip == nil then 
            local p = cc.p(self.btnPSKill:getContentSize().width,self.btnPSKill:getContentSize().height)
            UITool.addTipPoint(self.btnPSKill,p, TIP_POINT_TAG)
        end 
    else
        if oldTip ~= nil then 
            oldTip:removeFromParent(true)
            oldTip = nil 
        end 
    end  
end
--去 PSkillLayer
function NewRoleTeamView:toPSkillLayer()
    SceneManager:toPSkillLayer({resetcallback = function() 
        self:loadTeamList()
    end})
end
