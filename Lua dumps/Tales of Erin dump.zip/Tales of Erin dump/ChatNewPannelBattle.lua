
ChatNewPannelBattle = class("ChatNewPannelBattle",XUIView)
ChatNewPannelBattle.CS_FILE_NAME = "ChatPannelBattle.csb"
ChatNewPannelBattle.CS_BIND_TABLE = 
{

    battlePannel 				= "/i:1",
	battle_bg 					= "/i:1/i:1",
    battle_pannel_name 			= "/i:1/i:2/i:1",

    battle_chatList_pannel 		= "/i:1/i:4",

    battle_members_pannel 		= "/i:1/i:5",
    battle_members_num			= "/i:1/i:5/i:1/i:2",
    battle_members_list 		= "/i:1/i:5/i:2",
    
}

ChatNewPannelBattle.LogTag = "ChatNewPannelBattle"

function ChatNewPannelBattle:create(rData)
    local login = ChatNewPannelBattle.new()
    login.uiLayer   = cc.Layer:create()
    login:initUI()
    return login
end

function ChatNewPannelBattle:clear( )
	-- self:registEventDispatcher(false)
end

function ChatNewPannelBattle:returnBack(  )
	self:clear()
end

function ChatNewPannelBattle:initUI(  )
	self:init(self.uiLayer,self.CS_FILE_NAME,self.CS_BIND_TABLE)
	
	self:initData()


	self:bindAllBtn()

	-- self:registEventDispatcher(true) 	--启动通知事件
end

function ChatNewPannelBattle:initData(  )

	self._battle_id = nil 

	self.inputNode = nil 
	self._scrollView = nil 
	self.memberScrollView = nil 
end

function ChatNewPannelBattle:bindAllBtn(  )
	self.battle_bg:setVisible(false)

	self.inputNode = ChatInputNode:create()
	self.inputNode:setDelegate(self)
	self.inputNode:setSendCallback(function ( sender,message )
		self:sendMessage(message)
	end)
	self.battlePannel:addChild(self.inputNode:getRootNode())

	if self._scrollView == nil  then
		local psize = self.battle_chatList_pannel:getContentSize()
		self._scrollView = XBChatNewListView.new():initWithNodeAndSize(self.battle_chatList_pannel, psize.width, psize.height)
		self._scrollView:setItemCreateFunc(handler(self,self.createItem))
		self._scrollView:setItemRemoveFunc(handler(self,self.removeItem))
	end

	if self.memberScrollView == nil  then
		local psize = self.battle_members_pannel:getContentSize()
	    self.memberScrollView = XUIGridView.new():initWithNodeAndSize( self.battle_members_pannel , psize.width, psize.height,142,58)
	    self.memberScrollView.itemCreateEvent = function()
	        local temp = self:createMembersItem(data)
	        --战斗聊天室，点击名字不处理
	       	-- temp:setItemCallback(handler(self,self.itemSelectedCallback))
	        return temp
	    end

	end


end

function ChatNewPannelBattle:registEventDispatcher(bTrue)
	print("registEventDispatcher:::"..tostring(bTrue))
	if bTrue == false  then
		lemon.EventManager:getInstance():removeEventListener(self.get_battleId_listener)
		self.get_battleId_listener = nil 
		return 
	end
	--监听战斗聊天ID
	if self.get_battleId_listener == nil  then
		self.get_battleId_listener = lemon.EventManager:getInstance():addCustomEventListener(EEventType.CHAT_BATTLE_ID_CHANGE,handler(self,self.eventBattleChangeCb))
	end

end

function ChatNewMainLayer:eventBattleChangeCb( event_data )
	-- todo
	--战斗聊天室监听，如果有则判断是否登陆，如果没有，则登出之前的聊天室
	dump(event_data, "ChatNewMainLayer:eventBattleChangeCb")

	local event_data = event_data["event_data"]

	if event_data == nil then 
		return 
	end 

	local battleId = event_data["battle_id"]

	if battleId == nil then

		if self._battle_id ~= nil  then
			self:exitBattleRoom(self._battle_id)
		end

		return 

	else
		if tostring(battleId) == tostring(self._battle_id) then
			--不处理！
			return 
		else
			self:changeBattleRoom(battleId)
		end
	end


end

function ChatNewPannelBattle:eventEnterChatroom( session_type,session_id,code ) --登陆结果通知回调
	if session_type ~= 2  then
		print("拒绝处理：类型不匹配。。eventEnterChatroom type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._battle_id))
		return 
	end
	if code ~= 0 then
		-- print("聊天室登陆失败！！code:"..tostring(code)..",session_id:"..tostring(session_id)..",session_type:"..tostring(session_type))
		XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1031015))

		return
	end
	
	local battle_id = XBChatData:getInstance():getCurrentBattleID()

	-- print("ChatNewPannelBattle;;eventEnterChatroom====="..battle_id.."....:"..session_id)
	if tostring(session_id) == battle_id then
		self._battle_id = battle_id

		self:refreshChatListView()
	else
		--todo
	end 


end

function ChatNewPannelBattle:eventRefreshUI( session_type,session_id,scrollEnd )

	if session_type ~= 2 or session_id ~= self._battle_id  then
		print("拒绝处理：类型不匹配。。eventRefreshUI: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._battle_id))
		return 
	end
	
	self:refreshChatListView(scrollEnd)

end
--
function ChatNewPannelBattle:eventFecthSession( session_type,session_id )
	if session_type ~= 2 or session_id ~= self._battle_id  then
		print("拒绝处理：类型不匹配。。eventFecthSession: type："..tostring(session_type).."....id:"..tostring(session_id).."..myid:"..tostring(self._battle_id))
		return 
	end
	--战斗聊天室，需要在监听到聊天室之后
	print("ChatNewPannelBattle:eventFecthSession")
	self.fetchMessage = true 

	self:refreshChatListView(true)

end

function ChatNewPannelBattle:createMembersItem( data )
	-- body
	return ChatNewFriendItem:create(data)

end

function ChatNewPannelBattle:itemSelectedCallback( data )
	-- 战斗聊天室玩家不做点击事件
end 

function ChatNewPannelBattle:createItem( data )
	data["size_type_small"] = true -- 是否为小item
	return XBChatListViewItemPool:getInstance():createItemByData(data)
end

function ChatNewPannelBattle:removeItem( item )

	return XBChatListViewItemPool:getInstance():removeItemToPool(item)

end


function ChatNewPannelBattle:channelDataRefresh( ... )
	self:initConcationChatRoom()
end

function ChatNewPannelBattle:initConcationChatRoom(  )
	local roomid = XBChatData:getInstance():getCurrentBattleId()
	if roomid == nil  then
		return 
	end
	if  XBChatData:getInstance():getChatRoomEnterState(roomid) ~= true  then --世界
		print("initConcationChatRoom.....roomid:"..tostring(roomid))

		if roomid == "0"  then
			XBChatSys:getInstance():showChatSimpMsg(Lang:toLocalization(1010797))
			return
		end

		XBChatSys:getInstance():createChatWaitLayer();

		self._battle_id = roomid 

		local t_data = {
			session_id = roomid,
		}
		XBChatSys:getInstance():enterChatRoom(t_data)
	else

		self:refreshChatListView()

	end
end

function ChatNewPannelBattle:exitBattleRoom( roomid )
	-- body
	local function exitBattleCallback( t_data  )
		--只做退出操作
		if t_data == nil  then
			return 
		end

		local code = t_data["code"]
		local roomid = t_data["room_id"]

		if code == 0  then
			if tostring(roomid) == tostring(self._battle_id) then
				slef._battle_id = nil 
			end
		else
			-- self:exitBattleRoom(roomid)
			print("error==========退出聊天室失败！！！")
		end

	end
	local t_data = {
		session_id = roomid,
	}
	XBChatSys:getInstance():exitChatRoom(t_data, exitBattleCallback)

end

function ChatNewPannelBattle:changeBattleRoom( newBattleId )
	
	if tostring(self._battle_id) == tostring(newBattleId) then 
		return 
	end

	local function exitBattleCallback( t_data  )
		if t_data == nil  then
			return 
		end

		local code = t_data["code"]
		local roomid_exit = t_data["room_id"]


		if code == 0  then
			if tostring(roomid_exit) == tostring(self._battle_id) then
				self._battle_id = nil 
			end

		else
			print("error==========退出聊天室失败！！！")
		end
		
		self:initConcationChatRoom()


	end
	local t_data_exit = {
		session_id = self._battle_id,
	}
	XBChatSys:getInstance():exitChatRoom(t_data_exit, exitBattleCallback)


end

function ChatNewPannelBattle:removeScrollView( ... )
	if self._scrollView then
		self._scrollView:resetTempData()
	end
	self._battle_id 			= nil
	self.fetchMessage 			= false 

end

function ChatNewPannelBattle:refreshChatListView( scrollEnd )
	if self._battle_id == nil then
		return 
	end

	if self.fetchMessage == true or self._scrollView:getDataSource() == nil  then
		if self.fetchMessage == true  then
			self.fetchMessage = false 
		end
		local chatroom_datas = XBChatListViewDataMap:getInstance():getDatasByType(2, self._battle_id)
		self._scrollView:setDataSource(chatroom_datas)
	else
		self._scrollView:refreshDataSource(scrollEnd)
	end 


end





function ChatNewPannelBattle:sendMessage( message )
	-- body
	print("sendBtnCallback:"..tostring(message).."..._session_id:"..tostring(self._battle_id))
	if self._battle_id == nil  then
		
		return 
	end
	local channelIndex = 5
	XBChatPlatform:getInstance():sendmessage(channelIndex, self._battle_id,0,tostring(message),"ext" ,function (  )
		self.inputNode:setInputString("")
	end)
end

