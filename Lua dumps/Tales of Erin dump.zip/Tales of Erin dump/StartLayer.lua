require "BasicLayer"
-- panelnum 4战斗 5角色 6星之卵 7抽卡 8商店 9 公会
require "CountTime"

StartLayer = class("StartLayer",BasicLayer)
StartLayer.__index = StartLayer
StartLayer.lClass = 1
StartLayer.title = { "战斗","队伍","角色","装备","抽卡","商店","公会"}
StartLayer.panel_posx = 662
StartLayer.bPush      = true  --主界面是否弹出 
StartLayer.pNums      = 4  --主界面是否弹出 
StartLayer.IsNewGuide = false
StartLayer.GuildImage = nil
StartLayer.CurDLNum   = 0   --登陆的次数
StartLayer.BuyGoldNum = 0   --购买金币的次数
StartLayer.BuyApNUm   = 0   --购买体力的次数
StartLayer.titleLable = nil
StartLayer.IsAP       = false
StartLayer.IsGold     = false
StartLayer.curBZ      = 1
StartLayer.isSwitchBg = false
StartLayer.skAnimation = 1
StartLayer.IsTabbarActionDone = true
StartLayer.guildBattleState = 0--公会战状态。0未开启。1报名中 2.战斗中 3.休战中。4.已结束。注：3和4都显示为“休战中”。
StartLayer.hasJoinedGuild = 0 --是否已经加入公会
StartLayer.actInTimeData = nil

function StartLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, StartLayer)
    return target
end



function StartLayer:init()
    self.baseScheduler = nil 
    local node =cc.CSLoader:createNode("Menue.csb")
    if node == nil then
        return
    end
    self.uiLayer:addChild(node,0,1)
    node:setPositionX(640)
    --玩家名称位置右移
    if g_channel_control.transform_StartLayer_Text_1_0_1_pos == true then
        local panel =node:getChildByTag(1):getChildByTag(3)
        local playNameAndLvText = panel:getChildByTag(319)
        local playNameAndLvTextX = -297
        local newX = playNameAndLvTextX+20
        playNameAndLvText:setPositionX(newX)
    end
    self.sManager.rootNode = node:getChildByTag(11) 
    self.menuRootNode =  self.uiLayer:getChildByTag(1)

    local function changeCallBack(sender,eventType)
          print("点击按钮"..sender:getTag())
          if self.sManager.sceneNum ==1 then
             return
          end
         self.pNums = 4 
         self.sManager:toStartLayer()
    end
    local panel_1 =node:getChildByTag(1)
    local button = ccui.Helper:seekWidgetByTag(panel_1,121)
    button:addClickEventListener(changeCallBack)
    button:setEffectType(1)
    self.titleLable = ccui.Helper:seekWidgetByTag(panel_1,141)
    self.titleLable:setString("主页")
    
    -- ??? self.sManager:createWaitLayer()
    self:initPages() 
    self:initUserInfo()  
    self:initTopBtn()
    -- ??? self.sManager:delWaitLayer()
    self:showAll()   
    self:dealAp()
    --查询购买
    self:queryBuyItem()
end

function StartLayer:dealAp()
    local function reqSuccess(data)
        self:RefshTopBar()
        self:dealAp()
    end
    local function unpause(time)
        time = time or 0
         local ap_next = user_info["ap_next"] or 0
         local ap  = user_info["ap"] or 0
         local max_ap  = user_info["ap_max"] or 0
         if ap >= max_ap  then
            user_info["ap_next"] = 0
         else
            ap_next = ap_next-time
            if ap_next < 1  then
                if self.baseScheduler ~= nil then
                    local scheduler = cc.Director:getInstance():getScheduler()
                    scheduler:unscheduleScriptEntry(self.baseScheduler)
                    self.baseScheduler = nil
                end
                DataManager.reqUerCoin(reqSuccess)
            end
            user_info["ap_next"] = ap_next
         end
   end
    if self.baseScheduler ==nil then 
        local scheduler = cc.Director:getInstance():getScheduler()
        self.baseScheduler = scheduler:scheduleScriptFunc(unpause,1, false)
    end
end
--查询商店道具
function StartLayer:queryBuyItem()
    if g_channel_control.openQueryItem then
          SceneManager:createWaitLayer()
        local function serverCheckCallback(bRet)
             SceneManager:delWaitLayer();
            
        end 
        zc.queryItem(serverCheckCallback)
    end
    
  
    -- body
end
--初始化主页翻页功能
function StartLayer:initPages()
    self:initPagePvp()
    self:initPageMain()
    --self:initPage3()   --预留的活动页
    local pageView = self.uiLayer:getChildByTag(1):getChildByTag(9)
    local psize = pageView:getContentSize()
    local xuipw = XUIPageView.new():initWithNodeAndSize(pageView, psize.width, psize.height)
    self.xuiPageView = xuipw
    xuipw.pageChangingEvent = function(sender,newIndex,timemul)
        self:pageChanged(newIndex,timemul)
    end

    --开关控制是否开启PVP页面
    if g_channel_control.openPVPPage then
        xuipw:addPage(self.pagePvP)
    end
    
    xuipw:addPage(self.pageMain)    

    -- local page3 = ccui.Layout:create()
    -- page3:setBackGroundColor(cc.c3b(0,255,0))
    -- page3:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    -- page3:setContentSize(psize.width,psize.height)
    -- xuipw:addPage(page3)

    local tempgap = ccui.Layout:create()
    -- tempgap:setBackGroundColor(cc.c3b(255,0,0))
    -- tempgap:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    tempgap:setClippingEnabled(true)
    tempgap:setContentSize(80,psize.height)
    xuipw:setGapNode(tempgap)

    local gapimg = cc.Sprite:create()
    gapimg:setPosition(40,360)
    gapimg:setTexture("n_UIShare/newZhuye/ggsc_ui_101.png")
    tempgap:addChild(gapimg)

    xuipw:setCurPageIndex(2)
    xuipw:refresh()

    local tab = self.uiLayer:getChildByTag(1):getChildByTag(10)
    tab:addChild(self.tabbarPvP,1)
    tab:addChild(self.tabbarMain,1)

    local btnleft = self.uiLayer:getChildByTag(1):getChildByTag(164)
    btnleft:addClickEventListener(function(sender,eventType)
        local cur = xuipw:getCurPageIndex() - 1
        if cur >= 1 then
            xuipw:scrollToPage(cur)
        end
    end)
    local btnright = self.uiLayer:getChildByTag(1):getChildByTag(165)
    btnright:addClickEventListener(function(sender,eventType)
        local cur = xuipw:getCurPageIndex() + 1
        if cur < 3 then
            xuipw:scrollToPage(cur)
        end
    end)    
    
    self:pageChanged(2)

    --去掉PVP页面，屏蔽左右按钮
    local btnleft = self.uiLayer:getChildByTag(1):getChildByTag(164)
    local btnright = self.uiLayer:getChildByTag(1):getChildByTag(165)
    btnleft:setVisible(false)
    btnright:setVisible(false)
end

function StartLayer:pageChanged(newPage,animeTime)
    self.tabbarPvP:stopAllActions()
    self.tabbarMain:stopAllActions()

    local btnleft = self.uiLayer:getChildByTag(1):getChildByTag(164)
    local btnright = self.uiLayer:getChildByTag(1):getChildByTag(165)

    local function baranim(barout,barin)
        --self.sManager:addAniMask()

        barout:setPositionY(0)
        barin:setPositionY(-200)
        barout:setVisible(true)
        barin:setVisible(true)

        barout:runAction(cc.Sequence:create(cc.MoveBy:create(animeTime / 2, cc.p(0, -200)), cc.CallFunc:create(function()
            barout:setVisible(false)
            barin:runAction(cc.Sequence:create(cc.MoveBy:create(animeTime / 2, cc.p(0, 200)), cc.CallFunc:create(function()
                --self.sManager:removeAniMaskLayer()
            end))) 
        end)))
    end

    if newPage == 1 then

        btnleft:setVisible(false)
        btnright:setVisible(true)

        
        if animeTime then
            baranim(self.tabbarMain,self.tabbarPvP)
        else
            self.tabbarPvP:setVisible(true)
            self.tabbarPvP:setPositionY(0)

            self.tabbarMain:setVisible(false)
        end

    elseif newPage == 2 then

        btnleft:setVisible(true)
        btnright:setVisible(false)

        if animeTime then
            baranim(self.tabbarPvP,self.tabbarMain)
        else
            self.tabbarPvP:setVisible(false)
    
            self.tabbarMain:setVisible(true)
            self.tabbarMain:setPositionY(0)
        end
        
    else
        self.tabbarPvP:setVisible(false)
        self.tabbarMain:setVisible(false)
        return
    end

end 

--绑定下方动作条
function StartLayer:initPageMain() 

    -- self.pageMain
    -- self.tabbarMain
    local node = cc.CSLoader:createNode("Menue_main.csb")
    if node == nil then
        return
    end
    self.pageMain = node

    --背景动画
    local skeletonNode = sp.SkeletonAnimation:create("effects/zhu_jie_mian/zhujiemian.json", "effects/zhu_jie_mian/zhujiemian.atlas", 1.0)
    skeletonNode:setAnimation(1, "effect", true)
    skeletonNode:setPosition(640,360)
    skeletonNode:setTag(1020)   
    node:addChild(skeletonNode,-2)

    --主页左侧按钮开始
    local function CallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            self:toLayer1(sender:getTag())
         end
     end

    local panel_2 = node:getChildByTag(2)
    for i=1,5 do
        local button = ccui.Helper:seekWidgetByTag(panel_2,200+i)
        if (i == 3 and g_channel_control.chatLayer ~= true) or (i == 4 and g_channel_control.startLayer_hideEvent == true)  then
            --屏蔽聊天
            button:setVisible(false)
        end
        button:addTouchEventListener(CallBack)
    end

    --主页女主
    self.princessController = PrincessController.new():init()
    local psnode = self.princessController:getNode()
    psnode:setPosition(cc.p(360,0))
    node:addChild(psnode,-1,999)

    --主页右侧按钮
    local panel_4  = node:getChildByTag(4)
    local function changeCallBack(sender,eventType)
            print("点击按钮"..sender:getTag())
            local tag = sender:getTag()
            self:toLayer(tag)
    end
    --说明 404 大型活动删除
    for i=1,6 do
        local btn = ccui.Helper:seekWidgetByTag(panel_4,400+i)
        if btn then 
            btn:setTouchEnabled(true)
            btn:setEffectType(1)
            btn:addClickEventListener(changeCallBack)
            -- if i == 1 or i == 2 then
            --     btn:setEffectType(1)
            -- end
        end 
    end

    self.exploreBtn = ccui.Helper:seekWidgetByTag(panel_4,403)
    --
    --初始化活动UI
    local actRootNode = panel_4:getChildByTag(407)
    local actBanerNode = ActBanerManager:getActBanerNode()
    actRootNode:addChild(actBanerNode)

    ---tabbar
    local tab = cc.CSLoader:createNode("Mian_tabar.csb")
    self.tabbarMain = tab
    tab:setPosition(cc.p(-640,0))

  local function changeCallBack(sender,eventType)
        print("点击按钮"..sender:getTag())
        local tag = sender:getTag()
        if tag==101  then -- 队伍
            self.sManager:toRole({tab = 1})
        elseif tag==102 then
            --node:getChildByTag(6):setVisible(true)
            self.sManager:toEquip({tab = 4})
         elseif tag==103 then
            --node:getChildByTag(7):setVisible(true) 
            print("点击的 是工坊")  
            local  sData = {}
            self.sManager:toECastingLayer(sData)
            --self.sManager:toBagLayer(sData)
        else
          self:toLayer(tag)
        end
        
   end

  for i=101,107 do
    local  tabBTN = tab:getChildByTag(i)
    tabBTN:addClickEventListener(changeCallBack)
    tabBTN:setEffectType(1)
  end
  
  local mulBattleBtn =  tab:getChildByTag(107)
  mulBattleBtn:setPressedActionEnabled(false)
  mulBattleBtn:addTouchEventListener(function ( sender,eventType )
      if eventType == TOUCH_EVENT_BEGAN then
        sender:setScale(0.9)
      elseif (eventType == TOUCH_EVENT_ENDED) or (eventType == TOUCH_EVENT_CANCELED) then
        sender:setScale(1)
      end
  end)
  
  self:resetMulBattleBtnState(0)
  
    --公会战
    self.guildBattleBtn = panel_4:getChildByTag(101)
    self.guildBattleBtn:addClickEventListener(function ()
        if self.guildBattleState == 0 then
            print("未开启")
        elseif self.guildBattleState == 1 then
            --报名中
            print("报名中")
            local data = {};
            SceneManager:toAllianceApply(data);
        else
            if self.hasJoinedGuild == 0 then
                --提示未加入公会无法参战
                local function  doNothing()
                end
                MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("无法进入，请先加入公会。"),self,doNothing);
            else
                SceneManager:toAllienceBattleLayer();
            end
        end
    end)
end
--
function StartLayer:initPagePvp()
    -- self.pagePvP
    -- self.tabbarPvP
    local pvpview = XUIView.new():init(nil,"Menue_pvp.csb",{
        bgNode = "/i:66",
        panelFlag = "/i:60"
    })
    self.pagePvP = pvpview:getRootNode()
    local skeletonNode = sp.SkeletonAnimation:create("effects/zhu_jie_mian_pvp/shouye.json", "effects/zhu_jie_mian_pvp/shouye.atlas", 1.0)
    skeletonNode:setAnimation(1, "effect", true)
    skeletonNode:setPosition(640,360)
    pvpview.bgNode:addChild(skeletonNode, -2)

    local fangzi = sp.SkeletonAnimation:create("effects/zhu_jie_mian_pvp/fangzi.json", "effects/zhu_jie_mian_pvp/fangzi.atlas", 1.0)
    fangzi:setAnimation(1, "animation", true)
    fangzi:setPosition(640,360)
    pvpview.bgNode:addChild(fangzi, -1)


    local flagsize = pvpview.panelFlag:getContentSize()
    local flagspine = sp.SkeletonAnimation:create("effects/ZhanQi/ZhanQi.json", "effects/ZhanQi/ZhanQi.atlas", 1.0)
    flagspine:setAnimation(1, "effect", true)
    flagspine:setPosition(flagsize.width / 2 ,flagsize.height)
    pvpview.panelFlag:addChild(flagspine, -1)

    local tab = cc.CSLoader:createNode("Main_tabbar_pvp.csb")
    tab:setPosition(-640,0)
    self.tabbarPvP = tab

    local pvpbtns = {52,76,77,78}
    for _,v in ipairs(pvpbtns) do
        local btn = tab:getChildByTag(v)
        if btn then
            btn:setEffectType(1)
            btn:addClickEventListener(function()
                GameManagerInst:alert(UITool.ToLocalization("暂未开启，敬请期待。"))
            end)
        end
    end
end

--初始化上面几个按钮（增加 体力、钻石、金币）
function StartLayer:initTopBtn()
    local node = self.uiLayer:getChildByTag(1)
    local topRoot = node:getChildByTag(1):getChildByTag(3)
    --购买体力
    local btnAddT = ccui.Helper:seekWidgetByTag(topRoot,"308")
    btnAddT:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local popData = {}
            self.sManager:toLoadApLayer(popData)
        end
    end)
    --购买钻石
    local btnAddD = ccui.Helper:seekWidgetByTag(topRoot,"309")
    btnAddD:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            --如果当前在商店界面
            self:toShopLayerByIndex(1)
        end
    end)
    --购买金币
    local btnAddG = ccui.Helper:seekWidgetByTag(topRoot,"310")
    btnAddG:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:toShopLayerByIndex(2)
        end
    end)

    local ptip1 = topRoot:getChildByTag(78)
    ptip1:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:showTips(1)
        end
    end)

    local ptip2 = topRoot:getChildByTag(79)
    ptip2:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:showTips(2)
        end
    end)

    local userinfo_btn = topRoot:getChildByTag(161)  --顶部玩家信息按钮
    userinfo_btn:setPressedActionEnabled(false)
    userinfo_btn:addClickEventListener(function(sender,eventType)
        self:toLayer1(206)
    end)

    local userinfo_btn_anim = sp.SkeletonAnimation:create("effects/wanjiaxinxi/wanjiaxinxi.json", "effects/wanjiaxinxi/wanjiaxinxi.atlas", 1.0)
    userinfo_btn_anim:setPosition(47,42)
    userinfo_btn_anim:setAnimation(1, "animation", true)
    userinfo_btn:addChild(userinfo_btn_anim,99,206)

    local tip1 = topRoot:getChildByTag(73)
    tip1:setVisible(false)
    local tip2 = topRoot:getChildByTag(74)
    tip2:setVisible(false)

end
--1、钻石 2、金币
function StartLayer:toShopLayerByIndex(index)
    if self:getTitle() == SceneManager.titleTable[9] then 
        if self.sManager._shopLayer then 
            if self.sManager._shopLayer.Shopindex ~= index then 
                self.sManager._shopLayer:ShopTypeCall(index)
            end 
        end 
    else 
      --说明： 一级页面，回到1.二级界面回到当前界面
        local sData = {}
        if self.sManager.rootLocation == 1 then 
            sData["sDelegate"] = nil
            sData["sFunc"] = nil
        else 
            sData["sDelegate"] = self
            sData["sFunc"] = self.buyCallBack
        end 
        sData["shopTypeIndex"] = index
        SceneManager:toShopLayer(sData) 
    end 
end

function StartLayer:hideTips(tipType)
    local node = self.uiLayer:getChildByTag(1)
    local topRoot = node:getChildByTag(1):getChildByTag(3)
    local tippanel = nil

    if tipType == 1 then
        tippanel = topRoot:getChildByTag(73) 
    elseif tipType == 2 then
        tippanel = topRoot:getChildByTag(74)
    end

    if not tippanel:isVisible() then return end

    local sequence = cc.Sequence:create(cc.FadeOut:create(0.1), cc.CallFunc:create(function()
        tippanel:stopAllActions()
        tippanel:setVisible(false)  
    end))
    tippanel:runAction(sequence);
end

function StartLayer:showTips(tipType)
    local node = self.uiLayer:getChildByTag(1)
    local topRoot = node:getChildByTag(1):getChildByTag(3)
    
    if tipType == 1 then
        local tip1 = topRoot:getChildByTag(73)
        tip1:stopAllActions()
        tip1:setOpacity(255)
        tip1:setVisible(true)   
        local time1 = tip1:getChildByTag(187)   
        local time2 = tip1:getChildByTag(188)   
        local time3 = tip1:getChildByTag(189)  

        local function refreshTime()
            -- 刷新体力数字
            local ap_next = user_info["ap_next"] or 0   --x秒后加下一点
            local ap  = user_info["ap"] or 1
            local max_ap  = user_info["ap_max"] or 1

            local t = (max_ap - ap - 1) * AP_T + ap_next
            if t < 0 then t = 0 end
            
            local currentTime = UserDataMgr:getInstance().timeData:getCurrentTime()
            time1:setString(os.date("%H:%M:%S", currentTime))--os.time()
            time2:setString(UITool.getFormatTime(ap_next))
            time3:setString(UITool.getFormatTime(t))
        end

        refreshTime()
        local delay = cc.DelayTime:create(0.5)
        local sequence = cc.Sequence:create(delay, cc.CallFunc:create(refreshTime))
        local action = cc.RepeatForever:create(sequence)
        tip1:runAction(action)
        
    elseif tipType == 2 then
        local tip2 = topRoot:getChildByTag(74)
        
        tip2:stopAllActions()
        tip2:setOpacity(255)
        tip2:setVisible(true)
        local num1 = tip2:getChildByTag(80)
        local num2 = tip2:getChildByTag(81)
        if user_info["gem_r"] ~= nil and user_info["gem"] ~= nil then
            num1:setString(user_info["gem_r"])
            num2:setString(user_info["gem"] - user_info["gem_r"])
        else
            num1:setString("")
            num2:setString("")
        end
    end

    GameManagerInst:showModalView(XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            sender:removeFromParentView()
            self:hideTips(tipType)
        end
    end))
end

--购买钻石成功
function StartLayer:buyCallBack()
  --监听商店回调，目前什么刷新都不需要
end

function StartLayer:HideTitle( ... )
  -- ????
end
function StartLayer:ShowTitle( ... )
  -- ????
end

function StartLayer:setTitle(titleStr)
 self.titleLable:setString(titleStr)
end  
function StartLayer:getTitle()
    local str = ""
    if self.titleLable then 
      str = self.titleLable:getString()
    end 
    return str
end  

function StartLayer:resetMulBattleBtnState( num )
  
  local mulBattleBtn =  self.tabbarMain:getChildByTag(107)
  
  --80 32    77 26
  local btnBlue = mulBattleBtn:getChildByName("btnBlue")
  local btnRed = mulBattleBtn:getChildByName("btnRed")
  
  btnBlue:stopAllActions()
  btnRed:stopAllActions()
  
  if num >  0 then
    -- red
    local actred =cc.CSLoader:createTimeline("mulBattleBtnRed.csb") 
    btnBlue:setVisible(false)
    btnRed:setVisible(true)
      
    btnRed:runAction(actred)
    actred:play("animation0", true)

    mulBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_ui_083.png",
                                "n_UIShare/newZhuye/ggsc_ui_083.png",
                                "n_UIShare/newZhuye/ggsc_ui_083.png")
  else
    -- blue
    local actblue =cc.CSLoader:createTimeline("mulBattleBtnBlue.csb") 
    btnBlue:setVisible(true)
    btnRed:setVisible(false)
       
    btnBlue:runAction(actblue)
    actblue:play("animation0", true)

    mulBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_ui_082.png",
                                "n_UIShare/newZhuye/ggsc_ui_082.png",
                                "n_UIShare/newZhuye/ggsc_ui_082.png")
  end
  
end

--显示or隐藏tabbar
function StartLayer:showTabBar(state)
   if SceneManager.isTabBar  then 
    SceneManager.isTabBar = false 
    return
  end
  local node = self.uiLayer:getChildByTag(1)
  local panel_10 = node:getChildByTag(10)
  local function hideT( ... )
    -- body
    self.IsTabbarActionDone = true
  end 
  
    if state then
        if panel_10:getActionByTag(100) and panel_10:getActionByTag(100):isDone()==false then
           return;
        end
        local function removeAniMask()
            self.sManager:removeAniMaskLayer()
        end
        panel_10:setPositionY(-200)

        local actionBy = cc.MoveTo:create(0.3, cc.p(0, 0))
        local sequence = cc.Sequence:create(actionBy, cc.CallFunc:create(removeAniMask))
        sequence:setTag(100);
        self.sManager:addAniMask()
        panel_10:runAction(sequence)  
    else
        local function removeAniMask2()
            self.sManager:removeAniMaskLayer()
            --停掉所有其他页面的音效
--AudioManager:shareDataManager():stopAll()
        end
        if panel_10:getActionByTag(200) and panel_10:getActionByTag(200):isDone()==false then
           return;
        end
        local actionBy = cc.MoveTo:create(0.3, cc.p(0, -200))
        local sequence = cc.Sequence:create(actionBy, cc.CallFunc:create(removeAniMask2))
        self.sManager:addAniMask()
        sequence:setTag(200);
        panel_10:runAction(sequence)
    end
end

--隐藏listpanel
function StartLayer:hiddenListPanel()
          local panel_list = self.pageMain:getChildByTag(4)
          panel_list:setVisible(false)
end
--隐藏邮件
--左边众多按钮
function StartLayer:hiddenLWPanel(state)
  if SceneManager.isAct then
    SceneManager.isAct = false
    return
  end
     local panel_list = self.pageMain:getChildByTag(2)
     --测试版隐藏按钮
     if panel_list.isLock == false then 
          return 
     end 

     local actionBy = cc.MoveTo:create(0.3, cc.p(0, 0))
     actionBy:setTag(100)
       if state then
         actionBy = cc.FadeOut:create(0.3)
         actionBy:setTag(200)
         panel_list:setVisible(false)
         return
         else

        if panel_list:getActionByTag(100) and panel_list:getActionByTag(100):isDone()==false then
         return;
        end

         panel_list:setOpacity(255)
         panel_list:setVisible(true)
         panel_list:setPositionX(-400) 
       end
     panel_list:runAction(actionBy)
end

--隐藏用户信息
function StartLayer:hiddenUserInfo(state)
    self:showTopBar(true)
    
     local node = self.uiLayer:getChildByTag(1)
     node:getChildByTag(1):getChildByTag(1):setVisible(state)
     node:getChildByTag(1):getChildByTag(3):setVisible(not state)
    --  local panel_list = node:getChildByTag(3)
    --  local fadeOut  = cc.FadeOut:create(0.1)
    --  if not state then
    --       panel_list:setVisible(true)
    --       fadeOut = cc.FadeIn:create(0.1)
    --    else
    --       panel_list:setVisible(false)
    --       return
    --  end
    --  panel_list:runAction(fadeOut)

end

function StartLayer:initUserInfo()
    self:RefshTopBar()
end


function StartLayer:RefshTopBar()
  if self.uiLayer == nil then
      do return end  
  end 
 local node = self.uiLayer:getChildByTag(1)
    local panel_3 =node:getChildByTag(1):getChildByTag(3)
      local dataTable = {
          [303] = user_info["name"],
          [304] = ""..user_info["rank"],
          [305] = user_info["ap"].."/"..user_info["ap_max"],
          [306] = user_info["gem"],
          [307] = user_info["gold"],
          [308] = user_info["beryl"],
          [301] = user_info["exp"]/user_info["exp_max"]*100,--距离下级所需经验
          [302] = 100 * user_info["ap"]/user_info["ap_max"]
         }

        for i=3,7 do
          local text = ccui.Helper:seekWidgetByTag(panel_3,300+i)
          text:setString(dataTable[300+i])
        end
        -- for i=1,2 do
        --   local loadBar = panel_3:getChildByTag(300+i)
        --   loadBar:setPercent(dataTable[300+i])
        -- end

        --等级条
        local loadBar = panel_3:getChildByTag(301)
        loadBar:setPercent(dataTable[301])
end

--初始化活动列表
function StartLayer:initActive(panel)
    local pageView = ccui.Helper:seekWidgetByTag(panel,471)
    for i=1,3 do
      local layout =ccui.Layout:create() 
      local img = ccui.ImageView:create()
      img:loadTexture("yxzy019.png")
      img:setPosition(cc.p(pageView:getContentSize().width/2,pageView:getContentSize().height/2))
      layout:addChild(img)
      pageView:insertPage(layout,i)
    end
end
--跳转二级界面
function StartLayer:toLayer(tag)
    local node = self.uiLayer:getChildByTag(1)
    print("将要去"..tag)
    local sData = {}
      if tag == 103 then  -- 制作
      
      elseif tag == 104 then  -- 抽卡 
        self.sManager:toDrawCardLayer(sData)
      
      elseif tag == 105 then  -- 商店
        sData["shopTypeIndex"] = 1
        self.sManager:toShopLayer(sData)
        
      elseif tag == 106 then  --公会
        --  local popData = {}
        --   popData["oneself"]     = self
        --   popData["showButType"] = 1
        --   popData["showDecType"] = 1
        --   popData["texDec"]      = MessageInfo["gongneng"][1]
        --   popData["MsgType"]     = 5 
        --   self.sManager.msgMgr:showECastingMsg(popData)

        --self.sManager:toGuildMain() 
        GameManagerInst:rpc("{\"rpc\":\"guild_mine\"}",3,
        function(data)
            --success
            --GameManagerInst:saveToFile("guild_mine.json",data)
            if data.have_guild == 1 then
                local sData = {}
                sData["guild_data"] = table.deepcopy(data)   
                GuildSingleton:getInstance():setMedal_num(data.medal_num or 0)           
                self.sManager:toGuildMain(sData) 
            elseif data.have_guild == 0 then
                --无公会
                local sData = {}
                sData["sDelegate"] = self.sManager
                sData["sFunc"] = self.sManager.toStartLayer
                GuildSingleton:getInstance():setMedal_num(data.medal_num or 0)
                GuildInterface:GuildRecommend(sData)
            else
                GameManagerInst:alert(UITool.ToLocalization("冒险等级不足，公会暂未开启"))
            end
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true) 
      elseif tag == 107 then  --多人出战
         self.sManager:toMulBattleLayer(sData)
      elseif tag == 401 then  --出征
         self.sManager:toSMapLayer(sData)
      elseif tag == 402 then  --试炼之地
          local sData = {}
          self.sManager:toTrialLandLayer(sData)

    do return end 
      elseif tag == 404 then  --活动
          self.sManager:toActLayer(sData)
      elseif tag == 501 then  --队伍编成
          self.sManager:toRole({tab = 1})

      elseif tag == 502 then  --角色强化
          self.sManager:toRole({tab = 2})
                 
      elseif tag == 503 then  --潜能解放
          self.sManager:toRole({tab = 3})
       
      elseif tag == 504 then  --角色一览
          self.sManager:toRole({tab = 4})
       
      elseif tag == 601 then  --灵装融合
          self.sManager:toEquip({tab = 1})
       
      elseif tag == 602 then  --灵装强化
          self.sManager:toEquip({tab = 2})
       
      elseif tag == 603 then  --灵装突破
          self.sManager:toEquip({tab = 3})
       
      elseif tag == 604 then  --灵装一览
          self.sManager:toEquip({tab = 4})
      elseif tag == 701 then  --背包
          self.sManager:toBagLayer(sData)
      elseif tag == 702 then  --铸造
          self.sManager:toECastingLayer(sData)
      elseif tag == 403 then --星界
          self.sManager:toExploreLayer(sData)--去探索
      elseif tag ==405 then  --合战（黑潮遗迹）
        --  local sData = {}
        --   self.sManager:toTestGuildMainLayer(sData)
        self.sManager:toDDBattleMainLayer(sData)
      elseif tag ==406 then  --改成任务成就
        sData["func"] = self.refshBtnsState
        sData["self"] = self
        self.sManager:toAchievement(sData)
      end
end
function StartLayer:toLayer1( tag )
  local sData = {}
  if tag == 202 then -- 邮件
    self.sManager:toMailLayer(sData)

  elseif tag == 203 then -- 登陆奖励改到活动页，这个变成聊天   

    self.sManager:toChatLayer(sData)--toChatLayer(sData)
	-- GameManagerInst:alert("弹出聊天")
    --SceneManager:toConsole()
  elseif tag == 201 then -- 排行榜
        sData["from"] = RankSys.ERankType.resident
        self.sManager:toRanklistLayer(sData)
   elseif tag == 204 then -- 公告
      local sData = {}
    --  self.sManager:toGameNoticeLayer(sData)
      self.sManager:toActManageLayer(sData)
    elseif tag == 205 then --签到
    self.sManager:toLandingAward(sData)
  elseif tag == 206 then --图鉴
      self.sManager:toGallery()
  end
end

--隐藏上方topBar true 是显示  false 是隐藏
function StartLayer:showTopBar(state)

  if self.uiLayer:getChildByTag(1)~=nil  then
     local node = self.uiLayer:getChildByTag(1):getChildByTag(1)
     node:setVisible(state)
     node:getChildByTag(3):setVisible(true)
     node:getChildByTag(1):setVisible(false)
     node:getChildByTag(1):getChildByTag(13):setVisible(true)
  end

end

--隐藏上方topBar 窄条
function StartLayer:showTopBarBG(state)

  if self.uiLayer:getChildByTag(1)~=nil  then
     local node = self.uiLayer:getChildByTag(1):getChildByTag(1)
     node:getChildByTag(1):getChildByTag(13):setVisible(state)
  end
end

--隐藏一级界面 位于二级界面弹出一级界面时 点击一级空白区域 隐藏所有
function StartLayer:hiddenAll()
    if self.uiLayer:getChildByTag(1)~=nil  then
    --    self:hiddenListPanel()
    --    self:hiddenLWPanel(true)
       self:showTabBar(false)
       self.bPush = false
       --local node = self.uiLayer:getChildByTag(1)
       --self.princessController:releaseAnime()
    end
end

function StartLayer:showAll()
    if self.uiLayer:getChildByTag(1)~=nil  then
        self.bPush = true
        print("当前的编号"..self.pNums)
        self:initUserInfo()
        self:hiddenUserInfo(false)
        self:showTabBar(true)
        self:changePanel(self.pNums)
    end
end

--这个方法没有人调用
function StartLayer:display()
   local node = self.uiLayer:getChildByTag(1)
   local panel_list = node:getChildByTag(12)
   self.bPush = true
   local function hiddenlist(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self.bPush = false
            self.sManager:popStartLayer()
        end
    end
    panel_list:addTouchEventListener(hiddenlist)
    panel_list:setVisible(true)
    self:initUserInfo()
    self:hiddenUserInfo(false)
    self:showTabBar(true)
    self:changePanel(self.pNums)
end

--Release 女主动画
function StartLayer:ReleaseHeroineAnime()
    if self.princessController ~= nil  then
       self.princessController:releaseAnime()
    end
end

function StartLayer:changeBGScene(num)
  print("开始切换背景----"..num)
    local node = self.uiLayer:getChildByTag(1) 
    local bgImg = ccui.Helper:seekWidgetByTag(panel_9,901)
    --self.princessController:releaseAnime()

    local function changeBG()
          --[[local node = self.uiLayer:getChildByTag(1) 
          local panel_9 = node:getChildByTag(9)
          local bgImg = ccui.Helper:seekWidgetByTag(panel_9,901)
         if num==1 then
            bgImg:removeChildByTag(1020)
            local id_str = "res/hd/Resources/effects/zhu_jie_mian/zhujiemian.atlas"
            local end_pos = string.find(id_str,'atlas') - 1
            local spName = string.sub(id_str,0,end_pos)
            local skeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            skeletonNode:setAnimation(1, "effect", true)
            bgImg:addChild(skeletonNode)
            skeletonNode:setPosition(640,360)
            skeletonNode:setTag(1020)   
         elseif num<100 then
            --切换背景  这个已经不用了，注意12.30号
           -- bgImg:removeChildByTag(1020)
           -- bgImg:loadTexture(UI_BG[num])
           -- print("loadImg---"..UI_BG[num])
         else
             bgImg:removeChildByTag(1020)
             local bgCsd = cc.CSLoader:createNode(UI_BG[num])
             bgImg:addChild(bgCsd)
             bgCsd:setTag(1020)
         end]]
         if num==1  then
           --bgImg:removeChildByTag(100)
            ---强制引导之前 和触发 引导 不显示女主
            if  NewGuideManager.isStart  == false then 
                if  NewGuideManager.isStartWeakGuide == false and self.princessController ~= nil then 
                   self.princessController:createAnime()
                end 
            end 
        end

        --  local fadeIn =cc.FadeIn:create(0.3)
        --  panel_9:runAction(fadeIn)

   end 
  changeBG()
end



function StartLayer:fadeOutBGScene()
--   local node = self.uiLayer:getChildByTag(1) 
--   local panel_9 = node:getChildByTag(9)
--   local bgImg = ccui.Helper:seekWidgetByTag(panel_9,901)
--   local fadeout =cc.FadeOut:create(0.3)
--   panel_9:runAction(fadeout)
end

--切换
function StartLayer:changePanel(num)

    -- print("panel编号"..num)
    -- local node = self.uiLayer:getChildByTag(1)
    -- self:hiddenLWPanel(false)
    -- local panel = node:getChildByTag(num)
    -- panel:stopAllActions()
    -- panel:setVisible(true) --当前的显示
    -- panel:setOpacity(255)

end

---------------------------主界面需要获得的消息 ---------------------
function StartLayer:AllRefreshSend( ... )    -- landing_state  接口  
  --   "landed_state": 0,  # 0为未登陆、1为真标识已经登陆 
  --    "mail_state": 0,# 0为无邮件、1为有邮件未领取
  --   "multi_state":0,#0为无多人站邀请、1为有多人站邀请
  -- "achi_state":0,#0为无完成成就、1为有成就完成
  -- body
    local function reiceSthCallBack(data)
        print("获取登陆状态")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end

        
        if t_data["data"]["state_code"]  == 1 then
         
           -----开始女主提示
            if user_info["rank"] >= UnlockGongGaoRank then
                -- "get_ap_state":0,#是否获得整点体力的提示
                if t_data["data"]["get_ap_state"] == 1 then  
                    self.princessController:addNamedEvent("GetAP")
                end             
                if t_data["data"]["achi_state"] == 1 then  
                -- "achi_state":0,#0为无完成成就、1为有成就完成
                    self.princessController:addNamedEvent("AchiGift")      
                end
                if t_data["data"]["mail_state"] == 1 then 
                -- "mail_state": 0,# 0为无邮件、1为有邮件未领取
                    self.princessController:addNamedEvent("NewMail")
                end
                if t_data["data"]["landed_state"] == 1 then 
                -- "landed_state": 0,  # 0为未登陆、1为真标识已经登陆 
                    self.princessController:addNamedEvent("LoginGift")    
                end
            end

            if user_info["rank"] >= UnlockMoreBattleRank and t_data["data"]["multi_state"] == 1 then
            -- "multi_state":0,#0为无多人站邀请、1为有多人站邀请
                self.princessController:addNamedEvent("MultiBattle")
            end

            if t_data["data"]["skill_state"] == 1 then
                -- "skill_state":0,#0为无技能引导、1为有技能点引导
                self.princessController:addNamedEvent("SkillPoint")
            end

            if user_info["rank"] >= UnlockGongFangRank and t_data["data"]["forge_state"] == 1 then
            -- "forge_state":0,#铸造红点显示  
                self.princessController:addNamedEvent("Forge")
            end

            if user_info["rank"] >= UnlockExploreRank and t_data["data"]["explore_state"] == 1 then                
            -- "explore_state":0,#0为无探索任务、1为有探索任务完成  
                self.princessController:addNamedEvent("Explore")
            end
            -----结束女主提示

           local panel_2 = self.pageMain:getChildByTag(2)

          --# 登陆奖励   主页没这个按钮了
           if t_data["data"]["landed_state"] == 0 then  
                ccui.Helper:seekWidgetByTag(panel_2,2051):setVisible(false)
           elseif t_data["data"]["landed_state"] == 1 then
                ccui.Helper:seekWidgetByTag(panel_2,2051):setVisible(true)
           end
          -- #邮件
           if t_data["data"]["mail_state"] == 0 then
                ccui.Helper:seekWidgetByTag(panel_2,2021):setVisible(false)
           elseif t_data["data"]["mail_state"] == 1 then
                ccui.Helper:seekWidgetByTag(panel_2,2021):setVisible(true)
           end
          -- #多人战
           if t_data["data"]["multi_state"] == 0 then
                self:resetMulBattleBtnState(0)
           elseif t_data["data"]["multi_state"] == 1 then
                self:resetMulBattleBtnState(1)
           end
           -----------获取工坊的按钮
          local  tabBTN_1 = self.tabbarMain:getChildByTag(103)
           --探索有完成的任务
        local panel_4 = self.pageMain:getChildByTag(4)
        local panel_2 = self.pageMain:getChildByTag(2)

          self._exploreBtn =ccui.Helper:seekWidgetByTag(panel_4,403) 
          self._teamBtn = self.tabbarMain:getChildByTag(101) --主页队伍按钮
          local achiveBtn = ccui.Helper:seekWidgetByTag(panel_4,406) 
          local actBtn = ccui.Helper:seekWidgetByTag(panel_2,204) 

          if user_info["rank"] >=UnlockMaxRank then 
              UITool.setCommmonBtnRedDop(tabBTN_1,false)
              UITool.setCommmonBtnRedDop(self._exploreBtn,false)
              UITool.setCommmonBtnRedDop(self._teamBtn,false)
          end 
        
          -- #任务
          if t_data["data"]["achi_state"] == 0 then
              UITool.setCommmonBtnRedDop(achiveBtn,false)
           elseif t_data["data"]["achi_state"] == 1 then
              UITool.setCommmonBtnRedDop(achiveBtn,true,cc.p(95,86))
           end
            if t_data["data"]["explore_state"] == 1 then
                UITool.setCommmonBtnRedDop(self._exploreBtn,true,cc.p(95,86))
            end
            ---新技能按钮提示
            if t_data["data"]["skill_state"] == 1 then
                UITool.setCommmonBtnRedDop(self._teamBtn,true,cc.p(135,130))
            end

            -- 工坊
            if t_data["data"]["forge_state"] == 1 then
               UITool.setCommmonBtnRedDop(tabBTN_1,true,cc.p(120,120))

            end
            --活动中心
            local actRed = actBtn:getChildByTag(2041)
            if t_data["data"]["act_state"] == 0 then
                if actRed then 
                    actRed:setVisible(false)
                end 
            elseif t_data["data"]["act_state"] == 1 then
                if actRed then 
                    actRed:setVisible(true)
                end 
            end

            self:hideAllActMarkIcon()
            local act_in_time_arr = t_data["data"]["double_drop"]
            self:refreshEntranceMarkInActivity(act_in_time_arr)

            --公会战
            self.guildBattleState = t_data["data"]["guildbattle_state"]
            self.hasJoinedGuild = t_data["data"]["guild_state"]--是否已经加入公会

            if tonumber(user_info["rank"]) < 12 then
                self.guildBattleState = 0;
            end
            --v1，v2版
            if not g_channel_control.b_allianceBattle_version3 then
                if self.guildBattleState == 0 then
                    self.guildBattleBtn:setVisible(false)
                    self.guildBattleBtn:setTouchEnabled(false)
                elseif self.guildBattleState == 1 then
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)   
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_1.png","n_UIShare/newZhuye/ggsc_b_054_1.png") 
                elseif self.guildBattleState == 2 then
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)                   
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_2.png","n_UIShare/newZhuye/ggsc_b_054_2.png") 
                elseif self.guildBattleState >= 3 then
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)                  
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_3.png","n_UIShare/newZhuye/ggsc_b_054_3.png") 
                end
            --v3版
            else
                if self.guildBattleState == 0 then
                    self.guildBattleBtn:setVisible(false)
                    self.guildBattleBtn:setTouchEnabled(false)
                elseif self.guildBattleState == 1 then
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)   
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_1.png","n_UIShare/newZhuye/ggsc_b_054_1.png") 
                elseif self.guildBattleState == 2 then
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)                   
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_4.png","n_UIShare/newZhuye/ggsc_b_054_4.png") 
                elseif self.guildBattleState == 3 then
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)                  
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_5.png","n_UIShare/newZhuye/ggsc_b_054_5.png") 
                else
                    self.guildBattleBtn:setVisible(true)
                    self.guildBattleBtn:setTouchEnabled(true)                  
                    self.guildBattleBtn:loadTextures("n_UIShare/newZhuye/ggsc_b_054_3.png","n_UIShare/newZhuye/ggsc_b_054_3.png")                     
                end
            end
        end
  end
    self.sManager:createWaitLayer()
    local cjson = require "cjson"

    local version =  UpdateManager:getVersion() or ""
    local tempTable = {
        ["rpc"]       = "landing_state",
        ["version"]   = version
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励列表 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--隐藏所有活动标签
function StartLayer:hideAllActMarkIcon( ... )
    -- body
    local panel_4 = self.pageMain:getChildByTag(4)
    local mulBatttleBtn = self.tabbarMain:getChildByTag(107)
    local multiBattleImage = mulBatttleBtn:getChildByName("Image_mark")
    if multiBattleImage then
        multiBattleImage:setVisible(false)
    end

    local trialBtn =ccui.Helper:seekWidgetByTag(panel_4,402) 
    local trialImage = trialBtn:getChildByName("Image_mark")
    if trialImage then
        trialImage:setVisible(false)
    end
    
    local guildBtn = self.tabbarMain:getChildByTag(106)
    local guildImage = guildBtn:getChildByName("Image_mark")
    if guildImage then
        guildImage:setVisible(false)
    end

    local exploreBtn =ccui.Helper:seekWidgetByTag(panel_4,403)
    local exploreImage = exploreBtn:getChildByName("Image_mark")
    if exploreImage then
        exploreImage:setVisible(false)
    end

    local heiChaoBtn = ccui.Helper:seekWidgetByTag(panel_4,405)
    local heiChaoImage = heiChaoBtn:getChildByName("Image_mark")
    if heiChaoImage then
        heiChaoImage:setVisible(false)
    end
    
    local mainCopyBtn = ccui.Helper:seekWidgetByTag(panel_4,401)
    local mainCopyImage = mainCopyBtn:getChildByName("Image_mark")
    if mainCopyImage then
        mainCopyImage:setVisible(false)
    end
end

--刷新所有按钮的状态
function StartLayer:refshBtnsState()
  -- body
  print("刷新所有按钮的状态")
  self:setNodeLockState()
  self:AllRefreshSend()

end

--刷新在活动期间的标识
function StartLayer:refreshEntranceMarkInActivity( actInTimeArr )
    -- body
    local actMarkKey = nil
    local actKeys = table.keys(act_in_time_conf)
    table.sort(actKeys, function(a, b)
              return a < b
          end)
    local act_num = #actKeys
    local function getActMarkIcon( idx )
        -- body
        local icon = double_drop_conf[idx]["icon_m"]
        return icon
    end

    local function getActMarkKey( idx )
        -- body
        local actKeys = table.keys(act_in_time_conf)
        table.sort(actKeys, function(a, b)
              return a < b
          end)
        local act_num = #actKeys
        local act_key = nil
        for i=1,act_num do
            local actKey = tonumber(actKeys[i])
            local actItemData = act_in_time_conf[actKey]
            local type_str = actItemData["act_type"]
            local typeArr = string.split(type_str,",")
            local typeLen = #typeArr
            for j=1,typeLen do
                local actType = tonumber(typeArr[j])
                if idx == actType then
                    act_key = actKey
                    break
                end
            end
        end
        return act_key
    end

    local function getActMarkType( act_key )
        -- body
        local actKeyArr = {}
        if act_in_time_conf[act_key] and act_in_time_conf[act_key]["act_type"] then
            local act_type = act_in_time_conf[act_key]["act_type"]
            actKeyArr = string.split(act_type,",")
            table.sort(actKeyArr, function(a, b)
                  return a < b
            end)
        end
        return actKeyArr
    end

    local function refreshSingleMarkIcon( imageView,actType )
        -- body
        imageView:setVisible(false)
        local actTypeArr = actType or {}
        table.sort(actTypeArr, function(a, b)
            local compA = tonumber(a)
            local compB = tonumber(b)
            if compA and compB then
                return compA < compB
            end
        end)

        local actNum = #actTypeArr
        for i=1,actNum do
            local act_type = tonumber(actTypeArr[i])
            if act_type then
                local icon = getActMarkIcon(act_type)
                if imageView and icon then
                    imageView:setVisible(true)
                    imageView:loadTexture("n_UIShare/ditu/CombatList/"..icon..".png")
                end
            end
        end
    end

    local function refreshActMarkIcon(actKey,actTypeArr )
        -- body
        local panel_4 = self.pageMain:getChildByTag(4)
        if actKey == ACTIVITY_MARK_MAP["MULTI_BUTTLE"] then
            local mulBatttleBtn = self.tabbarMain:getChildByTag(107)
            local multiBattleImage = mulBatttleBtn:getChildByName("Image_mark")
            refreshSingleMarkIcon(multiBattleImage,actTypeArr)
        elseif actKey == ACTIVITY_MARK_MAP["TRIAL"] then
            local trialBtn =ccui.Helper:seekWidgetByTag(panel_4,402) 
            local trialImage = trialBtn:getChildByName("Image_mark")
            refreshSingleMarkIcon(trialImage,actTypeArr)
        elseif actKey == ACTIVITY_MARK_MAP["GUILD_TOWER"] then
            local guildBtn = self.tabbarMain:getChildByTag(106)
            local guildImage = guildBtn:getChildByName("Image_mark")
            refreshSingleMarkIcon(guildImage,actTypeArr)
        elseif actKey == ACTIVITY_MARK_MAP["EXPLORE"] then
            local exploreBtn =ccui.Helper:seekWidgetByTag(panel_4,403)
            local exploreImage = exploreBtn:getChildByName("Image_mark")
            refreshSingleMarkIcon(exploreImage,actTypeArr)
        elseif actKey == ACTIVITY_MARK_MAP["HEI_CHAO"] then
            local heiChaoBtn = ccui.Helper:seekWidgetByTag(panel_4,405)
            local heiChaoImage = heiChaoBtn:getChildByName("Image_mark")
            refreshSingleMarkIcon(heiChaoImage,actTypeArr)
        elseif actKey == ACTIVITY_MARK_MAP["MAIN_COPY"] then
            local mainCopyBtn = ccui.Helper:seekWidgetByTag(panel_4,401)
            local mainCopyImage = mainCopyBtn:getChildByName("Image_mark")
            refreshSingleMarkIcon(mainCopyImage,actTypeArr)     
        end
    end

    local act_in_time_arr = actInTimeArr or {}
    local act_num = #act_in_time_arr
    for num = 1,act_num do
        local actIndex = act_in_time_arr[num]
        local actKey = getActMarkKey(actIndex)
        if actKey then
            local actTypeArr = getActMarkType(actKey)
            refreshActMarkIcon(actKey,actTypeArr)
        end
    end 
end
function StartLayer:create(rData)


  local startLayer = StartLayer.new()
     startLayer.rData = rData 
     startLayer.sManager = rData["sManager"]
     startLayer.uiLayer = cc.Layer:create()
     startLayer:init()
     startLayer.sManager.menuLayer =startLayer
     return startLayer
end
--
--根据等级或者引导判断 按钮或者节点的显示状态
---刷新当前页面的显示状态
----todo 全部解锁等级之后。就不走这些了
function StartLayer:setNodeLockState()
    --user_info["rank"] = 14 ---testCode 
    --------------------------------
    if user_info["rank"] >=UnlockMaxRank then 
        return 
    end 
 
    local node = self.uiLayer:getChildByTag(1)
    local leftNode = self.pageMain:getChildByTag(2)
    ----下方按钮条
    --local panel_10 = node:getChildByTag(10) --下方按钮群的父节点
    local panel_4 = self.pageMain:getChildByTag(4)   --右侧按钮的父节点
    local tab = self.tabbarMain
    local curNodes = {} --当前页面需要处理的node
     --添加 公告等的父节点
    curNodes[1] = leftNode
    --添加下方的全部按钮
    for i=1,7 do
        local btn =  tab:getChildByTag(100+i)
        curNodes[#curNodes+1] = btn
    end
    --添加右侧按钮
    for i=1,6 do
        local btn = ccui.Helper:seekWidgetByTag(panel_4,400+i)
        if i~= 4 then 
            curNodes[#curNodes+1] = btn
        end 
    end

    local userinfo_btn = node:getChildByTag(1):getChildByTag(3):getChildByTag(161)  --顶部玩家信息按钮
    ---大型活动之前的tag 404 ，现在已经删除了
    for i=1,#curNodes do
        local config = guide_rank_config["StartLayer"][i]
        local btn = curNodes[i]
        if btn then 
            if config.unlock_level > tonumber(user_info["rank"]) then 
                if config.state == 0 then 
                    btn:setVisible(false)
                end 
                if i == 1 then
                    userinfo_btn:setTouchEnabled(false)
                    userinfo_btn:setBright(false)
                    userinfo_btn:getChildByTag(206):setVisible(false)
                    self.xuiPageView:setScrollTouchEnabled(false)

                    local btnleft = self.uiLayer:getChildByTag(1):getChildByTag(164)
                    local btnright = self.uiLayer:getChildByTag(1):getChildByTag(165)
                    
                    btnleft:setVisible(false)
                    btnright:setVisible(false)
                end
            else 
              --todo第一次出现特效
                config.effect =  config.effect or 0
                if config.effect > 0 then 
                    --第一次解锁功能特效
                    self:showFirghtOpenEffect(btn, config.btn_name)
                else 
                    btn:setVisible(true)
                end   
                if i == 1 then
                    userinfo_btn:setTouchEnabled(true)
                    userinfo_btn:setBright(true)
                    userinfo_btn:getChildByTag(206):setVisible(true)
                    self.xuiPageView:setScrollTouchEnabled(true)
                end 
            end 
        end 
    end
    -----处理引导相关按钮的提前隐藏或者显示
    local frightBtn = ccui.Helper:seekWidgetByTag(panel_4,401)   --出征按钮
    if user_info["guide_id"] > guide_id_config.ThatCard then 
        tab:getChildByTag(104):setVisible(true)   --召唤
    else  
        tab:getChildByTag(104):setVisible(false) --召唤
    end 

    local isShow = false
    if user_info["guide_id"] > guide_id_config.Team then 
        isShow = true
    else
        isShow = false
    end 
    tab:getChildByTag(101):setVisible(isShow) --队伍
    tab:getChildByTag(105):setVisible(isShow) --商店
    frightBtn:setVisible(isShow)              --出征按钮

    local _moreBatttleImgLock = self.tabbarMain:getChildByTag(108) --大型活动锁住状态
    if UnlockMoreBattleRank > tonumber(user_info["rank"]) then 
        _moreBatttleImgLock:setVisible(true)
        _moreBatttleImgLock:addClickEventListener(function()
              local str = string.format(UITool.ToLocalization("冒险等级达到%d级时解锁"),UnlockMoreBattleRank)
              SceneManager:showPromptLabel(str)
        end)   
    else 
        _moreBatttleImgLock:setVisible(false)
    end 
    self:updateRedDotPrompt()

end
----处理按钮是否红点引导
function  StartLayer:updateRedDotPrompt()
    --local node = self.uiLayer:getChildByTag(1)
    --local panel_10 = node:getChildByTag(10)
    local panel_4 = self.pageMain:getChildByTag(4)
    --恢复默认状态
    self._teamBtn = self.tabbarMain:getChildByTag(101) --主页队伍按钮
    UITool.setCommmonBtnRedDop(self._teamBtn,false)
    -- --出征按钮
    self._smapBattleBtn = ccui.Helper:seekWidgetByTag(panel_4,401)
    self:showSmapRedDop(false)
    --试炼之地
    self._TrialBtn =ccui.Helper:seekWidgetByTag(panel_4,402) 
    UITool.setCommmonBtnRedDop(self._TrialBtn,false)
    --探索按钮
    self._exploreBtn =ccui.Helper:seekWidgetByTag(panel_4,403) 
    UITool.setCommmonBtnRedDop(self._exploreBtn,false)
    ---黑潮遗迹
    self._DDBattleBtn = ccui.Helper:seekWidgetByTag(panel_4,405)
    UITool.setCommmonBtnRedDop(self._DDBattleBtn,false)
    --灵装按钮
    self._equipSthBtn = self.tabbarMain:getChildByTag(102) --灵装按钮
    UITool.setCommmonBtnRedDop(self._equipSthBtn,false)

    self._gongFangBtn = self.tabbarMain:getChildByTag(103) --工坊按钮
    UITool.setCommmonBtnRedDop(self._gongFangBtn,false)
    --商店
    self._shopBtn = self.tabbarMain:getChildByTag(105) --商店按钮
    UITool.setCommmonBtnRedDop(self._shopBtn,false)
    --公会按钮
    self._guildBtn = self.tabbarMain:getChildByTag(106) --公会按钮
    UITool.setCommmonBtnRedDop(self._guildBtn,false)
    --大型战斗
    self._moreBatttleBtn = self.tabbarMain:getChildByTag(107) --大型战斗
    UITool.setCommmonBtnRedDop(self._moreBatttleBtn,false)
    --去设置新的状态
    self:dealRedDotPrompt()
    
end

---根据本地配置表处理按钮小红点的显示状态
function StartLayer:dealRedDotPrompt( ... )
  -- body
    local nowRank = tonumber(user_info["rank"])  --当前等级
    --local event_1 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.RoleSkill) --技能加点有自己的一套红点，所以不用处理
    local event_1 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristTeam)   --没有遍过队伍
    --local event_2 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristBattle) --出征按钮的箭头指示
    local event_3 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Godhead)     --队伍按钮，神格按钮
    local event_4 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.KRelics)     --黑潮遗迹
    local event_5 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.StEquip)     --灵装按钮，灵装强化标签 cc.p(120,120)
    local event_6_1 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Shop_1)    --星石商店
    local event_6_2 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Shop_2)    --道具商店
    local event_6_3 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Shop_3)    --神秘商店
    local event_6_4 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Shop_4)    --苍玉商店
    local event_7 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.StHero)      --角色强化
    local event_8 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.HeroBT)      --角色突破（就是潜能解放）
    local event_9 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Guild)       --公会按钮
    local event_10 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Explore)    --星界
    local event_11 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.GuildTower) --公会按钮 公会塔
    local event_12 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Casting)    --工坊按钮  
    local event_13 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.MoreBattle) --大型战斗
    local event_14 = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Trial) --试炼之地

    ---默认是隐藏 的，下面函数只负责显示，有这个事件就去显示，隐藏不用管
    if event_1 == 0 then --没有编队之前
        UITool.setCommmonBtnRedDop(self._teamBtn,true,cc.p(135,130))
    end 

    if event_3 == 0 and nowRank >= UnlockGodheadRank  then --队伍按钮，神格按钮
        UITool.setCommmonBtnRedDop(self._teamBtn,true,cc.p(135,130))
    end 
    if event_4 == 0 and nowRank >= UnlockKRelicsRank  then --黑潮遗迹
        UITool.setCommmonBtnRedDop(self._DDBattleBtn,true, cc.p(95,86))
    end 
    if event_5 == 0 and nowRank >= UnlockEquipSth  then --灵装按钮，灵装强化标签
        UITool.setCommmonBtnRedDop(self._equipSthBtn,true,cc.p(120,120))
    end 
    --商店
    if event_6_1 == 0 then --商店按钮
        UITool.setCommmonBtnRedDop(self._shopBtn,true,cc.p(120,120))
    end 
    if event_6_2 == 0 and nowRank >= UnlockShopCangyuRank then --商店按钮
        UITool.setCommmonBtnRedDop(self._shopBtn,true,cc.p(120,120))
    end 
    if event_6_3 == 0 and nowRank >= UnlockMysteryShopRank then --神秘商店
        UITool.setCommmonBtnRedDop(self._shopBtn,true,cc.p(120,120))
    end 
    if event_6_4 == 0 and nowRank >= UnlockShopCangyuRank then --商店按钮
        UITool.setCommmonBtnRedDop(self._shopBtn,true,cc.p(120,120))
    end 
    if event_7 == 0 and nowRank >= UnlockRoleSthRank  then --角色强化,队伍按钮亮起来
        UITool.setCommmonBtnRedDop(self._teamBtn,true,cc.p(135,130))
    end 
    if event_8 == 0 and nowRank >= UnlockRoleAwakenRank  then --角色突破（就是潜能解放）
        UITool.setCommmonBtnRedDop(self._teamBtn,true,cc.p(135,130))
    end 
    if event_9 == 0 and nowRank >= UnlockGuildRank then  --公会按钮
        UITool.setCommmonBtnRedDop(self._guildBtn,true,cc.p(120,120))
    end 
    if event_10 == 0 and nowRank >= UnlockExploreRank then  --星界按钮
        UITool.setCommmonBtnRedDop(self._exploreBtn,true,cc.p(95,86))
    end 
    if event_11 == 0 and nowRank >= UnlockGuildTowerRank then  --公会塔 13
        UITool.setCommmonBtnRedDop(self._guildBtn,true,cc.p(120,120))
    end 
    if event_12 == 0 and nowRank >= UnlockGongFangRank then  --工坊按钮
        UITool.setCommmonBtnRedDop(self._gongFangBtn,true,cc.p(120,120))
    end 
    if event_13 == 0 and nowRank >= UnlockMoreBattleRank then  --大型战斗
        UITool.setCommmonBtnRedDop(self._moreBatttleBtn,true,cc.p(140,140))
    end 
    if event_14 == 0 and nowRank >= UnlockTrialRank  then --试炼之地
        UITool.setCommmonBtnRedDop(self._TrialBtn,true, cc.p(145,125))
    end 
    ---出征按钮箭头
    local u_rank = tonumber(user_info["rank"])
    if  tonumber(user_info["guide_id"]) > guide_id_config.SB then
        if u_rank == 4 or u_rank == 5 then 
            if  NewGuideManager.isStartWeakGuide then 
                self:showSmapRedDop(false)
            else  
                self:showSmapRedDop(true)
            end 
           
        end    
    end
end
-- -----出征按钮箭头显示状态
function StartLayer:showSmapRedDop(_isShow)
    --出征
    local btn = self._smapBattleBtn
    local oldEffect = btn:getChildByTag(TIP_POINT_TAG)
    if _isShow then 
          if oldEffect == nil then 
              local guide = sp.SkeletonAnimation:create("effects/jiantou/jiantou.json", "effects/jiantou/jiantou.atlas", 1.0)
              -- guide:setPosition(btn:getContentSize().width/2,btn:getContentSize().height+20)
              -- guide:setRotation(90)
              guide:setPosition(-30,btn:getContentSize().height/2)

              guide:setTag(TIP_POINT_TAG)
              guide:setAnimation(1, "effect", true)
              btn:addChild(guide)
          else 
              guide:setAnimation(1, "effect", true)
          end 
    else 
        if oldEffect ~= nil then
            oldEffect:stopAllActions() 
            oldEffect:removeFromParent()
            oldEffect  = nil             
        end 
    end 
end
---按钮出现特效
function StartLayer:btnShowEffect(btns)
  -- body
    for i=1,#btns do
        local btn = btns[i]
        btn:setVisible(true)
        btn:setOpacity(0)
        local fadeIn = cc.FadeIn:create(0.3)
        btn:runAction(fadeIn)
    end
end
--显示出抽卡按钮
function  StartLayer:showCardBtn()
    -- body
    -- local node = self.uiLayer:getChildByTag(1)
    -- local panel_10 = node:getChildByTag(10)
    -- local tab = panel_10:getChildByTag(1000)
    local btn = self.tabbarMain:getChildByTag(104) --召唤

    local btns = {btn}
    self:btnShowEffect(btns)
end
--显示出队伍按钮
--selectState 选中引导的状态 1是选继续，2是选中拒绝
function  StartLayer:showTeamBtn(selectState)
    -- body
    selectState = selectState or 0
    --local node = self.uiLayer:getChildByTag(1)
    --local panel_10 = node:getChildByTag(10)  --下面按钮的父节点
    local panel_4 = self.pageMain:getChildByTag(4)   --右侧按钮的父节点
    local tab = self.tabbarMain

    local btn = tab:getChildByTag(101)  --召唤
    local btn2 = tab:getChildByTag(105) --商店
    local btns 
    if selectState == 0 then 
        local btn3 = ccui.Helper:seekWidgetByTag(panel_4,401)-- 出征按钮
        btns = {btn, btn2, btn3}
    else 
        btns = {btn, btn2}
    end 
    self:btnShowEffect(btns)
end
--显示出征按钮
function  StartLayer:showFirghtBtn()
    -- body
    --出征
    local panel_4 = self.pageMain:getChildByTag(4)
    local btn = ccui.Helper:seekWidgetByTag(panel_4,401)
    if btn:isVisible() then
    else 
        local btns = {btn}
        self:btnShowEffect(btns)
    end 
end

--显示功能第一次解锁特效
function  StartLayer:showFirghtOpenEffect(btn,uKey)
    -- body
    --cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."btnEffect"..uKey, 0) --testCode
    local isShow = cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."btnEffect"..uKey)
    if isShow == 1 then  --已经显示过按钮特效了
        btn:setVisible(true)
    else 
        btn:setVisible(false)
        local partnerNode = btn:getParent()
        local guide = sp.SkeletonAnimation:create("effects/gongnengjiesuo/gongnengjiesuo.json", "effects/gongnengjiesuo/gongnengjiesuo.atlas", 1.0)
        partnerNode:addChild(guide)
        local anchor = btn:getAnchorPoint()
        if  anchor.x == 0 then 
            guide:setPosition(btn:getPositionX()+btn:getContentSize().width/2,btn:getPositionY()+btn:getContentSize().height/2)
        else 
            guide:setPosition(btn:getPositionX(),btn:getPositionY())
        end 
        --关键帧appear
        guide:registerSpineEventHandler(
            function (event) 
              if event.eventData.name == "appear" then 
                -- dump("appear")
                  cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."btnEffect"..uKey, 1)
                  btn:setVisible(true)
              end 
        end, sp.EventType.ANIMATION_EVENT)
        --延迟一秒移除
        guide:registerSpineEventHandler(
            function (event) 
              local  delay = cc.DelayTime:create(0.1)
              local sequence = cc.Sequence:create(delay, cc.RemoveSelf:create())
              guide:runAction(sequence)
        end, sp.EventType.ANIMATION_END)
       
        local dt = cc.DelayTime:create(0.2)
        local cf = cc.CallFunc:create(function()
            guide:stopAllActions()
            guide:setVisible(true)
            guide:setAnimation(1, "effect", false)

            --显示女主特效 黑潮遗迹
            if uKey == "btn_hc" then 
                self.princessController:addNamedEvent("DDBattle")
            end
        end)
        guide:setVisible(false)
        local seq = cc.Sequence:create(dt,cf)
        guide:runAction(seq)

    end 
end
