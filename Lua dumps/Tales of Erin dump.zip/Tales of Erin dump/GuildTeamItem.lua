--[[
	GuildTeamItem.lua
]]
--require "XUIView"
GuildTeamItem = class("GuildTeamItem", XUIView)
GuildTeamItem.CS_FILE_NAME = "RoleTeamItemView.csb"
GuildTeamItem.CS_BIND_TABLE = 
{
    panNoRole = "/i:180/i:183",
    imgAdd1 = "/i:180/i:183/i:220",
    imgAdd2 = "/i:180/i:183/i:221",
    panHasRole = "/i:180/i:186",
    imgBG = "/i:180/i:186/i:49",
    imgRole = "/i:180/i:186/i:192",
    imgFrame = "/i:180/i:186/i:188",
    imgFrameSub = "/i:180/i:186/i:190",
    imgElement = "/i:180/i:186/i:191",
    btnInfo = "/i:180/i:186/i:189",
    lbLv = "/i:180/i:186/i:194",
    lbATK = "/i:180/i:186/i:195",
    lbHP = "/i:180/i:186/i:196",
    nameLab = "/i:180/i:186/i:189/i:110",
    imgIntimacy = "/i:180/i:186/i:440",
    intimacyIconPos = "/i:180/i:186/i:110",
}

function GuildTeamItem:init(rootNode,index)
    GuildTeamItem.super.init(self,rootNode)
    self.BtnInfoClick = nil
    self.BtnAddClick = nil
    
    self.index = index

    self.panNoRole:setVisible(true)
    self.panHasRole:setVisible(false)

    self.btnInfo:setTouchEnabled(false)
  
    -- self.panNoRole:addTouchEventListener(function (sender, eventType)
    --     if eventType == ccui.TouchEventType.began then
    --         self.imgAdd1:setVisible(false)
    --         self.imgAdd2:setVisible(true)
    --     elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.began then
    --         self.imgAdd1:setVisible(true)
    --         self.imgAdd2:setVisible(false)
    --     end

    --     if eventType == ccui.TouchEventType.ended then
    --         if self.BtnAddClick then
    --             self.BtnAddClick(self.index)
    --         end
    --     end
    -- end)

    -- self.panHasRole:addTouchEventListener(function (sender, eventType)
    --     if eventType == ccui.TouchEventType.ended then
    --         if self.BtnAddClick then
    --             self.BtnAddClick(self.index)
    --         end
    --     end
    -- end)

    return self
end
--[[
    "team" : {
         "2":{
           "ps": "warrior_1",              # 公主
           "team_fp":1234, #队伍战力
           "team": [
           { 
            "id":"1*1299656990",#角色ID
            "Lv": 1,            # 等级 
            "hp": 735,          # 生命力
            "atk": 1400,        # 攻击力
            "def": 12,          # 防御
            "rarity": 5,       # 角色稀有度
            "element": 5,       # 角色元素类型: 1水 2火 3风 4光 5暗
            }, {"id":"0"}, {"id":"0"}, {"id":"0"}]}  # 队形
    },   
]]
function GuildTeamItem:setRoleInfo(rInfo)
    if rInfo["id"] ~= "0" then
        self.panNoRole:setVisible(false)
        self.panHasRole:setVisible(true)

        local h_id_num = getNumID( rInfo["id"] )
        
                    -- [103] = hero[h_id_num].hero_team_icon,
                    -- [141] = hero[h_id_num].hero_name,
                    -- [142] = team_list[tostring(self.teamIdx)]["team"][j]["Lv"],
                    -- [143] = team_list[tostring(self.teamIdx)]["team"][j]["atk"],
                    -- [144] = team_list[tostring(self.teamIdx)]["team"][j]["hp"],
        
        local framebg = Rarity_Team_BG[rInfo["rarity"]]
        if framebg then
            self.imgBG:setTexture(framebg)
        end

        local frame = Rarity_Hero_Frame[rInfo["rarity"]]
        if frame then
            self.imgFrame:setTexture(frame)
        end
        
        local framesub = Rarity_Hero_Frame_Sub[rInfo["rarity"]]
        if framesub then
            self.imgFrameSub:setTexture(framesub)
        end

        local roleface = hero[h_id_num].hero_team_icon
        if roleface then
            self.imgRole:setTexture(roleface)
        end

        local element = ATB_Icon[rInfo["element"]] --属性球
        if element then
            self.imgElement:setTexture(element)
        end

        if g_channel_control.b_LikeState then
            self.imgIntimacy:setVisible(true)
            -- local intimacy = like_state[1].icon_min --亲密度TODO：根据不同亲密度显示不同
            -- if intimacy then
            --     self.imgIntimacy:setTexture(intimacy)
            -- end

            local intimacyState = rInfo["like_feel_state"]["icon_state"]

            local intimacy = like_state[intimacyState].icon_min --亲密度
            if intimacy then
                self.imgIntimacy:setTexture(intimacy)
            end
            local effectFile = like_state[intimacyState].special_effect --特效资源路径
            if effectFile ~= "" then
                self:startGMeffect(intimacyState)
            else
                self:stopGMeffect()
            end
        else
            self.imgIntimacy:setVisible(false)
        end


        self.lbATK:setString(rInfo["atk"])
        self.lbHP:setString(rInfo["hp"])
        self.lbLv:setString(rInfo["Lv"])
        self.nameLab:setString(UITool.getUserLanguage(hero[h_id_num].hero_name))--(hero[h_id_num].hero_name)
        self.nameLab:setTextColor(cc.c4b(255,255,255,255))
    else
        self.panNoRole:setVisible(true)
        self.panHasRole:setVisible(false)
        self.imgAdd2:setVisible(false)
        self.imgAdd1:setVisible(false)
        
    end
    --todo角色名字
    
end

function GuildTeamItem:startGMeffect(intimacyState)
    local effectFile = like_state[intimacyState].special_effect --特效资源路径

    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(effectFile) then
        local end_pos = string.find(effectFile,'atlas') - 1
        local spName = string.sub(effectFile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil

            local rps = self.intimacyIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2, rps.height / 2))
            roleIcon:setScale(1)
            self.intimacyIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect", true)
        end)
    end
end

function GuildTeamItem:stopGMeffect()
    self.intimacyIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end
end