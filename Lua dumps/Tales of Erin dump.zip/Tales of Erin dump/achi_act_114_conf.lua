achi_act_114_conf={} 
achi_act_114_conf[1] = {
        id= 1,
        achi_name= "通关！",
        achi_desc= "完成活动所有关卡",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[2] = {
        id= 2,
        achi_name= "初次登台",
        achi_desc= "通关简单难度活动多人副本5次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[3] = {
        id= 3,
        achi_name= "步伐熟练",
        achi_desc= "通关困难难度活动多人副本10次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[4] = {
        id= 4,
        achi_name= "全场瞩目",
        achi_desc= "通关超难难度活动多人副本30次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[5] = {
        id= 5,
        achi_name= "纵情狂欢",
        achi_desc= "通关超难难度活动多人副本100次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[6] = {
        id= 6,
        achi_name= "血腥轮舞",
        achi_desc= "通关超难难度活动多人副本200次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[7] = {
        id= 7,
        achi_name= "相杀谢幕",
        achi_desc= "通关超难难度活动多人副本400次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[8] = {
        id= 8,
        achi_name= "厄夜明星",
        achi_desc= "通关超难难度活动多人副本600次",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[10] = {
        id= 10,
        achi_name= "单枪匹马（简单）",
        achi_desc= "单独通关简单难度活动多人副本",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[11] = {
        id= 11,
        achi_name= "单枪匹马（困难）",
        achi_desc= "单独通关困难难度活动多人副本",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[12] = {
        id= 12,
        achi_name= "单枪匹马（超难）",
        achi_desc= "单独通关超难难度活动多人副本",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[13] = {
        id= 13,
        achi_name= "追寻真相",
        achi_desc= "击杀恶魔100只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[14] = {
        id= 14,
        achi_name= "揭穿谎言",
        achi_desc= "击杀恶魔250只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[15] = {
        id= 15,
        achi_name= "撕裂假面",
        achi_desc= "击杀恶魔500只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[16] = {
        id= 16,
        achi_name= "曲终魔灭",
        achi_desc= "击杀恶魔1000只!",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_114_conf[17] = {
        id= 17,
        achi_name= "封印命运",
        achi_desc= "通关单人关卡-月下罪罚",
        achi_icon= "icons/achiv/cjxt_001.png",

} 