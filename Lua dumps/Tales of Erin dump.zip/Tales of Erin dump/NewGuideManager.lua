--[[
初级测试版本  
说明：
从 1 开始
1、2 新手引导战斗阶段
id可参照配置文件 new_guide.lua

2016.12.21
---到编队都为强制引导。后面为rank解锁
guide_id_config.Team
最新版新手引导

---需要删除该文件 2018.12.27

]]

local MaxGuide = 20
local MaxMandatoryGuide = guide_id_config.SB --强制引导最大ID 
local isFineshFirst = false
NewGuideManager = class("NewGuideManager")
NewGuideManager.__index = NewGuideManager

function NewGuideManager:ctor()
    self:resetState()
end
function NewGuideManager:resetState()
    self.isStart = false 
    self.guideLayer = nil 
    self.sManager = nil 
    self._nowGuideID = 0
    self._curIndex = 1
    self.guideEffect_1 = nil 
    self.guideEffect_2 = nil 
    self.isStartWeakGuide = false
    self.curUnlockType = nil  --
    self.backDeleagte = nil  --用于弱引导的返回回调
    self.backFun = nil      --用于弱引导的返回回调
end

--todo  manager 改为 sManager后期改一下
function NewGuideManager:setManager(manager)
	self.manager = manager
    self.sManager = manager
    self._nowGuideID = user_info["guide_id"]
end
--每次登陆之后调用新手引导
function NewGuideManager:startGuide()
    self._nowGuideID = user_info["guide_id"]
    local isStart = true 
    local guide_id = user_info["guide_id"] or 1
-------------testCode 跳过战斗新手引导   记得上传的时候备注上
    -- if guide_id < 30 then 
    --     NewGuideManager:reqSendGuide(guide_id_config.FB)
    --     return 
    -- end
-- -----------------------------------        
    if guide_id == 0 then 
        print("请服务器默认初始新手引导为1")
    elseif guide_id <= 2 then 
        self:startBattleGuide()
    elseif guide_id <= MaxMandatoryGuide then 
        self.manager:addTouchMask() --屏蔽触摸
        if self.manager.isStartLayerInit then 
            self.manager:toStartLayer()
        end 
        self:startMenuGuide()
    else
        isStart = false
    end

    local user_soft_guide = user_info["user_soft_guide"] or 0

    --user_soft_guide = unlock_type_17 --testCode 

    if tonumber(user_soft_guide) ~= 0 then 
        print("触发引导 ID:"..user_soft_guide)
        if self.manager.isStartLayerInit then 
            self.manager:toStartLayer()
        end 
        self:startWeakGuide(tonumber(user_soft_guide))
        isStart = true
    end 

    self.isStart = isStart
    return isStart
end
--------新手战斗引导
function NewGuideManager:startBattleGuide()
    local guide_id = user_info["guide_id"] or 0
    	if user_info["guide_id"] == 1 then
        cc.MyHttpHelper:shareMyHttpHelper():startGame()
        KeyboardManager:setbattleState(true)

        UITool.delayTask(0.1,function ( ... )
            local scene = cc.Director:getInstance():getRunningScene()
                dump(scene, "NewGuideManager:startBattleGuide    22222")
                if scene then
                    KeyboardManager:bindingAndroidKeyboard(scene,3)
                end
            end)

    elseif user_info["guide_id"] ==2 then
        if isFineshFirst == false then
        local sData = {}
        sData["filename"] = "story/c0s0e0l2.json"
        sData["callBack"] = 5
        SceneManager:toDialogLayer(sData)
        end
    end
end 
----todo重新处理！！！！
--处理第一阶段和c++层交互引导Id 业务逻辑拿到这边处理
function NewGuideManager:dealFirstGuide(id)
    print("Guide id == "..id)
    if id == 1 then
        self.manager:addTouchMask() --屏蔽触摸
        NewGuideManager:reqSendGuide(3)
    end
    -- if id == 1 then
    --     isFineshFirst = true
    --     NewGuideManager:reqSendGuide(3)
    --     -- local sData = {}
    --     -- sData["filename"] = "story/c0s0e0l2.json"
    --     -- sData["callBack"] = 5
    --     -- SceneManager:toDialogLayer(sData)
    --     -- self:finshNowGuide()   -- SceneManager:toDialogLayer(sData)  
    -- elseif id == 2 then
    --     --self:finshNowGuide()
    -- elseif id == 3 then
    --     G_toStart = true
    --     self.manager:toStartLayer()
    -- end 
end 
----新手引导界面阶段
function NewGuideManager:startMenuGuide()
    ---新手引导
    if user_info["guide_id"] > MaxMandatoryGuide then 
        do return end 
    end 
    self._curIndex = 1
    --第二场战斗
    if self._nowGuideID == guide_id_config.SB then 
        if self.sManager.sceneNum == 1 then
            self._curIndex = 1
        else 
            self._curIndex = 3
        end  
    end
    dump(self._nowGuideID.." #####  "..self._curIndex)
    local tab = {}
    tab.guide_id = self._nowGuideID
    tab.manager = self
    tab.curIndex = self._curIndex
    if self.guideLayer ~= nil then 
        self:nilGuideLayer()
    end 
    self.guideLayer = NewGuideLayer:create(tab)
    self.manager:addGuideLayer(self.guideLayer)
 	self.guideLayer:startPlay()
    self.sManager:removeTouchMaskLayer()
end

--弱引导。剧情触发引导
function NewGuideManager:startWeakGuide(_type)
    self._curIndex = 1
    if _type >= unlock_type_01 and _type <= unlock_type_18 then 
        self._nowGuideID = guide_ids[_type]
    else 
        do return end 
    end 
    self.curUnlockType = _type  --用于给服务器发消息
    local tab = {}
    tab.guide_id = self._nowGuideID
    tab.manager = self
    tab.curIndex = self._curIndex
    if self.guideLayer ~= nil then 
        self:nilGuideLayer()
    end 
    self.guideLayer = NewGuideLayer:create(tab)
    self.manager:addGuideLayer(self.guideLayer) 
    self.guideLayer:startPlay()
    self.isStartWeakGuide = true
end

function NewGuideManager:startSubGuide(delegate, curIndex,guide_id)
    if user_info["guide_id"] > MaxGuide  then 
        return false
    end
    self._nowGuideID = guide_id or self._nowGuideID
    self._curIndex = curIndex
    --dump(self._nowGuideID.."   "..self._curIndex)
    if delegate ~= nil then 
        self.curLayer = delegate --代理页面
    end 
    local tab = {}
    tab.guide_id = self._nowGuideID
    tab.manager = self
    tab.curIndex = self._curIndex
    if self.guideLayer ~= nil then 
        self:nilGuideLayer()
    end 
    self.guideLayer = NewGuideLayer:create(tab)
    self.manager:addGuideLayer(self.guideLayer)
    self.guideLayer:startPlay()
    return true
end

function NewGuideManager:nilGuideLayer()
    self.guideLayer = nil 
end

--处理按钮点击事件
function NewGuideManager:dealMenuGuide(guide_id,curIndex)
    local sData = {}
    if guide_id  == guide_id_config.ThatCard then       --抽卡
        self:dealGuideThatCard(guide_id,curIndex)
    elseif guide_id  == guide_id_config.Team then       --编队
        self:dealGuideTeam(guide_id,curIndex)
    elseif guide_id  == guide_id_config.FB then --第一场战斗
         self:dealGuideFB(guide_id,curIndex)
    elseif guide_id  == guide_id_config.SB then --第二场战斗
         self:dealGuideSB(guide_id,curIndex)
    elseif guide_id  == guide_id_config.StHero then     --角色强化
        self:dealGuideStHero(guide_id,curIndex)
    elseif guide_id  == guide_id_config.RoleSkill then  --角色技能升级
        self:dealGuideRoleSkill(guide_id,curIndex)  
    elseif guide_id  == guide_id_config.Equipment then  --灵装
        self:dealGuideEquipment(guide_id,curIndex)  
    elseif guide_id  == guide_id_config.Godhead then    --女主
        self:dealGuideGodhead(guide_id,curIndex)  
    elseif guide_id  == guide_id_config.NewName then    --起名字引导
        self:dealGuideNewName(guide_id,curIndex)  
    elseif guide_id  == guide_id_config.MoreBattle then    --多人战引导
        self:dealGuideMoreBattle(guide_id,curIndex) 
    elseif guide_id  == guide_id_config.HeroBT then     --角色突破，潜能解放
        self:dealGuideHeroBT(guide_id,curIndex) 
    elseif guide_id  == guide_id_config.Trial then     --试练之地
        self:dealGuideTrial(guide_id,curIndex) 
    else 
        --特殊处理一句话的引导 
        if guide_id >= guide_id_config.StEquip and guide_id <=guide_id_config.HeiCao then 
            self:dealOtherGuide(guide_id,curIndex)  
        end 
    end 
end
--3抽卡 
function NewGuideManager:dealGuideThatCard(guide_id,curIndex)
    if guide_id ~= guide_id_config.ThatCard then 
        return 
    end 
    local sData = {}
    if curIndex == 1 then      --去抽卡页面
        self.sManager:toDrawCardLayer(sData)
    elseif curIndex == 2 then  --开始抽卡
        self.curLayer:btnGacha(2)
    elseif curIndex == 3 then  --结束当前抽卡引导，开启新引导
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        user_info["guide_id"] = self.nextGuide
        self._nowGuideID = user_info["guide_id"]
        self.sManager:toStartLayer()
        self:startGuide()
    end 
end
--4、编队
function NewGuideManager:dealGuideTeam(guide_id,curIndex)
    if guide_id ~= guide_id_config.Team then 
        return 
    end 
    self._nowGuideID = guide_id
    local sData = {}
    if curIndex == 1 then  --点击编队，进入队伍页面  
        self.sManager:toRole({tab = 1})
    elseif curIndex == 2 then  --点击加人
        self.curLayer.roleTeamView:ItemAdd(2)
        NewGuideManager:startSubGuide(self.curLayer, 3)
    elseif curIndex == 3 then
        self.curLayer.roleTeamView:newGuideTeamFunc()
        self:finshNowGuide()
        self:startSubGuide(self.curLayer,4)
    elseif curIndex == 4 then
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(self.curLayer, 5, guide_id_config.Team)
    elseif curIndex == 5 then 
        self.sManager.menuLayer:showTeamBtn(0)
        self.sManager.menuLayer:showFirghtBtn()
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        user_info["guide_id"] = self.nextGuide
        self._nowGuideID = user_info["guide_id"]
        self:startGuide()
        ---这个拿到结束强制新手引导吧
        -- if self.sManager.sceneNum == 1 then
        --     self.sManager.menuLayer.princessController:createAnime()
        -- end 
    end 
end

--5、第一次出征
function NewGuideManager:dealGuideFB(guide_id,curIndex)
    if guide_id ~= guide_id_config.FB then 
        return 
    end 
    local sData = {}
    if curIndex == 1 then      --出征
        self.manager:toSMapLayer(sData)
    elseif curIndex == 2 then   --点击区域地图
        self.curLayer.event_idx =  1
        self.curLayer.touch_point = self.curLayer.now_area.."_"..1
        self.curLayer:addTollgate()
        self.curLayer:reqPointInfo(self.curLayer.now_area.."_"..1)
    elseif curIndex == 3 then  --选中区域地图关卡
        self.curLayer.click_point = 1
        if self.curLayer.tollgate[self.curLayer.click_point]["type"] ~= 3 then --type 0-主线, 1-角色, 2-自由任务, 3-多人BOSS
            self.curLayer:onClickOtherPass()   
        else
            self.curLayer:onClickMullPass()
        end
    elseif curIndex == 4 then  --开始战斗
        self.curLayer:beginCallBack()
    elseif curIndex == 5 then
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        user_info["guide_id"] = self.nextGuide
        self._nowGuideID = user_info["guide_id"]
    end
end

--6 第二次战斗
function NewGuideManager:dealGuideSB(guide_id,curIndex)
    if guide_id ~= guide_id_config.SB then 
        return 
    end 
    local sData = {}
    if curIndex == 1 then
        self.manager:toSMapLayer(sData)
    elseif curIndex == 2 then   --点击区域地图
        self.curLayer.event_idx =  1
        self.curLayer.touch_point = self.curLayer.now_area.."_"..1
        self.curLayer:addTollgate()
        self.curLayer:reqPointInfo(self.curLayer.now_area.."_"..1)    
    elseif curIndex == 3 then  --选中区域地图关卡
        self.curLayer.click_point = 1
        if self.curLayer.tollgate[self.curLayer.click_point]["type"] ~= 3 then --type 0-主线, 1-角色, 2-自由任务, 3-多人BOSS
            self.curLayer:onClickOtherPass()   
        else
            self.curLayer:onClickMullPass()
        end
    elseif curIndex == 4 then  --开始战斗
        self.curLayer:beginCallBack()
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
    end 
end

--7、强化角色
function NewGuideManager:dealGuideStHero(guide_id,curIndex)
    if guide_id ~= guide_id_config.StHero  then 
        return 
    end 
    local sData = {}
    if curIndex == 1 then  --主页 队伍按钮亮起来
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then  --点击队伍按钮
        self.sManager:toRole({tab = 1})
    elseif curIndex == 3 then  --角色强化
        self.curLayer:switchView(2)
        NewGuideManager:startSubGuide(self.curLayer, 4)
    elseif curIndex == 4 then  --角色强化 选中第一个角色
        self.curLayer.roleSthView:setSelectedHero(1)
        NewGuideManager:startSubGuide(self.curLayer, 5)
    elseif curIndex == 5 then
        self.curLayer.roleSthView.matViewL:startIncreaseFood(1)
        self.curLayer.roleSthView.matViewL:stopFoodNum()
        NewGuideManager:startSubGuide(self.curLayer, 6)
    elseif curIndex == 6 then
        self.curLayer.roleSthView:onRoleSth()
    elseif curIndex == 7 then 
        NewGuideManager:startSubGuide(self.curLayer, 8)
    elseif curIndex == 8 then ---返回首页
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(self.curLayer, 9)
    elseif curIndex == 9 then
        self.manager:toSMapLayer(sData)
    elseif curIndex == 10 then   --点击区域地图
        self.curLayer.event_idx =  1
        self.curLayer.touch_point = self.curLayer.now_area.."_"..1
        self.curLayer:addTollgate()
        self.curLayer:reqPointInfo(self.curLayer.now_area.."_"..1)    
    elseif curIndex == 11 then  --选中区域地图关卡
        self.curLayer.click_point = 1
        if self.curLayer.tollgate[self.curLayer.click_point]["type"] ~= 3 then --type 0-主线, 1-角色, 2-自由任务, 3-多人BOSS
            self.curLayer:onClickOtherPass()   
        else
            self.curLayer:onClickMullPass()
        end
    elseif curIndex == 12 then  --开始战斗
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id) 
        self.curLayer:beginCallBack()
        self:weakGuideCallBack()
    end 
end

--5、角色技能升级
function NewGuideManager:dealGuideRoleSkill(guide_id,curIndex)
    local sData = {}
    if curIndex == 1 then  --主页 队伍按钮亮起来
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then  --点击队伍按钮
        self.sManager:toRole({tab = 1})
    elseif curIndex == 3 then  --角色预览按钮亮起
        self.curLayer:switchView(4)
        NewGuideManager:startSubGuide(nil, 4)
    elseif curIndex == 4 then  --
        local selectId = self.curLayer.roleListView.currentDataSource[1].id
        SceneManager:toRoleInfo({ 
            hid = selectId })
        NewGuideManager:startSubGuide(self.curLayer,5)
    elseif curIndex == 5 then
        self.sManager.RoleInfoView:switchView(2)
        NewGuideManager:startSubGuide(self.curLayer,6)
    elseif curIndex == 6 then-- 技能升级按钮
        self.sManager.RoleInfoView:onSkillStartAdd()
        NewGuideManager:startSubGuide(self.curLayer,7)
    elseif curIndex == 7 then-- + 处理+事件
        self.sManager.RoleInfoView:onSkillAdd(2)
        NewGuideManager:startSubGuide(self.curLayer,8)
    elseif curIndex == 8 then-- + 确定加点
        self.sManager.RoleInfoView:onSkillCommit()
    elseif curIndex == 9 then-- + 确定加点成功
        --处理加点成功 。告诉服务器加点成功
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        print("加点引导结束。回调去处理页面吧")
        self:weakGuideCallBack()
    end 
end
--灵装使用
function NewGuideManager:dealGuideEquipment(guide_id,curIndex)
    local sData = {}
    if curIndex == 1 then  
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then  --主页 队伍按钮
        self.sManager:toRole({tab = 1})
    elseif curIndex == 3 then  --角色预览按钮
        self.curLayer:switchView(4)
        NewGuideManager:startSubGuide(nil, 4)
    elseif curIndex == 4 then  --
        local hlist = {}
        local tempds = self.curLayer.roleListView.currentDataSource
        local len = #tempds or 0
        for i = 1,len do
            table.insert(hlist,tempds[i].id)
        end
        local selectId = self.curLayer.roleListView.currentDataSource[1].id
        SceneManager:toRoleInfo({ hid = selectId,  hlist = hlist })
        NewGuideManager:startSubGuide(self.curLayer,5)
    elseif curIndex == 5 then
        self.sManager.RoleInfoView:switchView(3)
        NewGuideManager:startSubGuide(self.curLayer,6)
    elseif curIndex == 6 then --武器列表
        if g_channel_control.b_newRole then
            self.sManager.RoleInfoView.roleEquipView:onClickEquip(1)
            NewGuideManager:startSubGuide(self.curLayer,7)
        else
            self.sManager.RoleInfoView:onClickEquip(1)
            NewGuideManager:startSubGuide(self.curLayer,7)
        end
    elseif curIndex == 7 then--穿装备
        if g_channel_control.b_newRole then
            self.sManager.RoleInfoView.roleEquipView:newGuideRoleInfoFunc()
        else
            self.sManager.RoleInfoView:newGuideRoleInfoFunc()
        end
    elseif curIndex == 8 then --发送结果返回处理的
        print("灵装使用。回调去处理页面吧")
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        self:weakGuideCallBack()
    end 
end
--女主神格
function NewGuideManager:dealGuideGodhead(guide_id,curIndex)
    local sData = {}
    if curIndex == 1 then
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then --显示主页面队伍页面
        self.sManager:toRole({tab = 1})
    elseif curIndex == 3 then
         self.curLayer.roleTeamView:toPSkillLayer() --神格变更
    elseif curIndex == 4 then
        self.sManager.PSkillLayer:newGuideTouchFirst()
        NewGuideManager:startSubGuide(self.curLayer, 5)
    elseif curIndex == 5 then --获得
        self.sManager.PrincessInfoView:dealGuide()
    elseif curIndex == 6 then --使用
        self.sManager.PrincessInfoView:dealGuide()
    elseif curIndex == 7 then --关闭神格对话
        print("--todo神格成功 通知服务器神格成功 ")
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        self:weakGuideCallBack()
    end 
end
--起名字引导
function NewGuideManager:dealGuideNewName(guide_id,curIndex)
    local sData = {}
    if curIndex == 1 then   --弹出起名字
        print("--弹出起名字页面")
        SceneManager:toNewNameLayer()
    elseif curIndex == 2 then  --开始抽卡
        print("--起名字结束")
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        self:weakGuideCallBack()
    end 
end
----多人战引导
function NewGuideManager:dealGuideMoreBattle(guide_id,curIndex)
    local sData = {}
    if curIndex == 1 then
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then --多人战按钮
        self.sManager:toMulBattleLayer(sData)
    elseif curIndex == 3 then 
        NewGuideManager:startSubGuide(nil, 4)
    elseif curIndex == 4 then --创建战斗按钮
        self.curLayer:refreshList(2)
    elseif curIndex == 5 then --多人战按钮
       -- NewGuideManager:startSubGuide(nil, 6)
        local function dealEndReq()
            --AppsFlyer打点
            SysDot:eventTutorialComplete(guide_id)
            self:weakGuideCallBack()
        end
        NewGuideManager:reqSoftGuidePass(dealEndReq)
    -- elseif curIndex == 6 then --列表
    --     self.curLayer.click_point = 1
    --     self.curLayer:createToReadyLayer()
    -- elseif curIndex == 7 then  --开始战斗
    --     self.curLayer:beginCallBack()  
    --     local function dealEndReq()
    --         self:weakGuideCallBack()
    --     end
    --     NewGuideManager:reqSoftGuidePass(dealEndReq)
    end 
end
--、角色突破（潜能解放）
function NewGuideManager:dealGuideHeroBT(guide_id,curIndex)
    if guide_id ~= guide_id_config.HeroBT  then 
        return 
    end 
    local sData = {}
    if curIndex == 1 then  --主页 队伍按钮亮起来
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then  --点击队伍按钮
        self.sManager:toRole({tab = 1})
    elseif curIndex == 3 then  --角色突破
        self.curLayer:switchView(3)
        NewGuideManager:startSubGuide(self.curLayer, 4)
    elseif curIndex == 4 then  --角色突破 选中第一个角色
        self.curLayer.roleAwakenView:setSelectedHero(1)
        NewGuideManager:startSubGuide(self.curLayer, 5)
    elseif curIndex == 5 then
        self.curLayer.roleAwakenView:onRoleAwaken()
    elseif curIndex == 6 then
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        self:weakGuideCallBack()
    end 
end
----试炼之地引导
function NewGuideManager:dealGuideTrial(guide_id,curIndex)
    local sData = {}
    if curIndex == 1 then
        if  self.backDeleagte~= nil then 
             self.backDeleagte:myClear()
        end 
        self.backDeleagte = nil
        self.backFun = nil
        self.sManager:toStartLayer()
        NewGuideManager:startSubGuide(nil, 2)
    elseif curIndex == 2 then --多人战按钮
        self.sManager:toTrialLandLayer(sData)
    elseif curIndex == 3 then --列表
        self.curLayer.click_point = 1
        self.curLayer:toReadyLayer()
    elseif curIndex == 4 then  --开始战斗
        self.curLayer:beginCallBack()  
        local function dealEndReq()
        end
        NewGuideManager:reqSoftGuidePass(dealEndReq)
    elseif curIndex == 5 then  --结束
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        self:weakGuideCallBack()
    end 
end
--后面的对话引导
function NewGuideManager:dealOtherGuide(guide_id,curIndex)
    local function dealEndReq()
        self:dealReyunGuideOtherEvent(guide_id) --热云统计
        self:weakGuideCallBack()
    end
    local sData = {}
    if curIndex == 1 then
        if new_guide[guide_id][2] ~= nil then 
            NewGuideManager:startSubGuide(nil, 2)
        else   
            NewGuideManager:reqSoftGuidePass(dealEndReq)
        end
    elseif curIndex == 2 then
        --AppsFlyer打点
        SysDot:eventTutorialComplete(guide_id)
        NewGuideManager:reqSoftGuidePass(dealEndReq)
    end 
end
---BattleEndLayer:showPlayerUp
function NewGuideManager:weakGuideCallBack()
    self.isStartWeakGuide = false
    self.isStart = false
    if self.backFun~=nil then 
        self.backFun(self.backDeleagte)
    end 
    self.backDeleagte = nil
    self.backFun = nil

    ---如果在主界面 显示女主2
    if SceneManager.sceneNum == 1 then
        SceneManager.menuLayer.princessController:createAnime()
    end 
end
--对话最后一步显示
--暂时不用了
function NewGuideManager:playGuideEffect(dialogLayer,num)
    print("NewGuideManager:playGuideEffect"..num)
end
--去显示选择引导UI
function NewGuideManager:showTeamSelectUI(dialogLayer)
	-- body
	self.guideLayer:showTeamSelectUI(dialogLayer)
end
--通知服务器完成当前引导
function NewGuideManager:finshNowGuide()
    local nowGuideId = user_info["guide_id"]
    local nextGuideId = nowGuideId + 1
    self:reqSendGuide(nextGuideId)   
end
--启动网络的时候新手引导隐藏掉
function NewGuideManager:setGuideLayerVisibele(isVisible)
    if self.isStart and self.guideLayer ~= nil and self.guideLayer.uiLayer ~=nil then 
        self.guideLayer.uiLayer:setVisible(isVisible)   
    end 
end
--向服务器发送新手引导进度
function NewGuideManager:reqSendGuide(id)
  -- body
    local function reiceSthCallBack(data)
        print("收到新手引导结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if user_info["guide_id"] < guide_id_config.ThatCard then 
        	user_info["guide_id"] = t_data["data"]["guide_id"]
            self._nowGuideID = user_info["guide_id"]
        	self:startGuide()
        else 
        	self.nextGuide = t_data["data"]["guide_id"]
            if user_info["guide_id"] == guide_id_config.FB  then 
                self:dealGuideFB(guide_id_config.FB, 5)
            end 
            if user_info["guide_id"] == guide_id_config.SB then 
                user_info["guide_id"] = t_data["data"]["guide_id"]
                self:endGuideFunc() --结束强制引导
            end 
        end 
        --保存ID
        cc.UserDefault:getInstance():setIntegerForKey("GuideId", tonumber(t_data["data"]["guide_id"]))
    end

    local cjson = require "cjson"
    self.manager:createWaitLayer()
    local tempTable = {
        ["rpc"]      = "guide",
        ["guide_id"] = id
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--向服务器发送新手引导进度
function NewGuideManager:reqSendGuideWithCallBack(delegate,callback)
    local nowGuideId = user_info["guide_id"]
    id = nowGuideId + 1
  -- body
    local function reiceSthCallBack(data)
        print("收到新手引导结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        user_info["guide_id"] = t_data["data"]["guide_id"]
        --保存ID
        cc.UserDefault:getInstance():setIntegerForKey("GuideId", tonumber(t_data["data"]["guide_id"]))

        if callback ~=nil then 
        	callback(delegate)
        end 
    end

    local cjson = require "cjson"
    self.manager:createWaitLayer()
    local tempTable = {
        ["rpc"]      = "guide",
        ["guide_id"] = id
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
------------下面是处理按钮显示特效 的相关方法
--去显示选择引导UI
function NewGuideManager:showBtn()
    -- body
    --抽卡出现特效
    if self._nowGuideID == guide_id_config.ThatCard and self._curIndex == 1 then 
        self.sManager.menuLayer:showCardBtn()
    end 
    --编队出现特效
    if self._nowGuideID == guide_id_config.Team then 
        self.sManager.menuLayer:showTeamBtn(1)
    end   
end
--处理拒绝引导之后的刷新
function NewGuideManager:dealRefused()
    -- body
   -- dump("NewGuideManager:dealRefused111")
    --新加 热云统计
    self:dealReyunEventRefuse()

    if self._nowGuideID == guide_id_config.Team then 
        self.sManager.menuLayer:showTeamBtn(0)
    end  
    self._nowGuideID=user_info["guide_id"] 
    self.isStartWeakGuide = false 
    self.isStart = false
    if self.backFun~=nil then 
        self.backFun(self.backDeleagte)
    end 
    self.backDeleagte = nil
    self.backFun = nil
    ---如果在主界面 显示女主
    if SceneManager.sceneNum == 1 then
        SceneManager.menuLayer.princessController:createAnime()
    end 
end
---强制引导结束函数
function NewGuideManager:endGuideFunc()
    -- body
    if self._nowGuideID == guide_id_config.Team then 
        self.sManager.menuLayer:showFirghtBtn()
        self.isStart = false
        if self.sManager.sceneNum == 1 then
            self.sManager.menuLayer.princessController:createAnime()
        end 
    end   
    self._nowGuideID = user_info["guide_id"] 
    self.isStartWeakGuide = false
    self.isStart = false
end

----告诉服务器完成 弱引导
function NewGuideManager:reqSoftGuidePass(callBack)
  -- body
    local function reiceSthCallBack(data)
        print("收到新手引导结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        user_info["user_soft_guide"] = 0
        if callBack then 
            callBack()
        end 
    end

    local cjson = require "cjson"
    self.manager:createWaitLayer()
    local tempTable = {
        ["rpc"]      = "user_soft_guide_pass",
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

---热云选择拒绝引导
function  NewGuideManager:dealReyunEventRefuse()
    -- body
    if self._nowGuideID == guide_id_config.Team then 
    elseif self._nowGuideID == guide_id_config.RoleSkill then 
    elseif self._nowGuideID == guide_id_config.Equipment then 
    elseif self._nowGuideID == guide_id_config.Godhead then 
    end
end

---热云 一句话引导 新手引导9 灵装强化教学-- 新手引导22 黑潮遗迹
--说明：目前eventId 是 event00 +当前引导ID，所以代码拼接，如果有变化，直接整表吧
function  NewGuideManager:dealReyunGuideOtherEvent(guide_id)
end