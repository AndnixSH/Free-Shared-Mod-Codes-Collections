
--mini聊天系统
MiniChatSys = class("MiniChatSys")
MiniChatSys.EType = {
    --系统公告
    notice = 1,
    --世界
    world = 2,
    --公会
    guild = 3,
    --私聊
    friend = 4,
    --战斗
    fight = 5,
    --玩家获得物品
    obtain = 6,
}

function MiniChatSys:getInstance()
   if self.s_instance == nil then
        self.s_instance = MiniChatSys.new()
        self.s_instance:initialize()
   end
   return self.s_instance;
end

function MiniChatSys:initialize( ... )
    -- body
    self.talkDataMap = {}
    --listview里最多显示4条
    self.CountOfDisplay = 4

end

function MiniChatSys:getMsgMaxCount( ... )
    -- body
    return self.CountOfDisplay
end

function MiniChatSys:getLastFourData()
    -- body
    local temp_data = {}
    local list_data = XBChatSys:getInstance():getChatDisplayData()
    local min_idx = list_data:getMinIndex()
    local max_idx = list_data:getMaxIndex()

    local src_list_data = list_data:getList()
    -- dump(src_list_data,"src_list_data")
    -- local count = max_idx - min_idx
    -- print("MiniChatSys:getLastFourData  ==> min_idx  , max_idx  count  ",min_idx,max_idx,count)

     -- dump(temp_data,"MiniChatSys:getLastFourData  temp_data")
    local dest_data = self:filterData(src_list_data,min_idx,max_idx)
    -- dump(dest_data,"MiniChatSys:getLastFourData  dest_data")
 

    local count = #dest_data
    if count <= self.CountOfDisplay then
        temp_data = dest_data
    else
        temp_data = self:getLastFourMsg(dest_data)
    end
   
    return temp_data
end

function MiniChatSys:getLastFourMsg( dest_data )
    -- body
    local chat_data = {}
    -- dump(dest_data,"MiniChatSys:getLastFourMsg(  dest_data")
    local dataCount = #dest_data
    print("MiniChatSys:getLastFourMsg dataCount ", dataCount)

    local resultCount = math.min(4, dataCount)

    print("MiniChatSys:getLastFourMsg resultCount ", resultCount)
    for i = dataCount - resultCount + 1, dataCount do

        table.insert(chat_data, dest_data[i])
        
    end

    -- dump(chat_data,"MiniChatSys:getLastFourMsg(  chat_data")
    return chat_data


    -- local chat_data = {}
    -- local list_data = XBChatSys:getInstance():getChatDisplayData()
    -- local src_list_data = list_data:getList()
    -- local max_idx = list_data:getMaxIndex()
    -- if max_idx > self.CountOfDisplay then
    --     local _min = max_idx - self.CountOfDisplay + 1
    --     for i = _min,max_idx do
    --         local item_data = src_list_data[i]
    --         table.insert(chat_data,item_data)
    --     end
    -- end
    -- return chat_data
end

function MiniChatSys:getLastMsg( ... )
    -- body
    local msgData = self:getLastFourData()
    local lastMsgData = nil
    local count = #msgData
    for i=1,count do
        lastMsgData = msgData[i]
    end
    return lastMsgData
end

function MiniChatSys:filterData( list,minIndex,maxIndex )
    local dest_data = {}
    local src_data = list or {}
    --系统是否勾选
    local bSettingSys = XBChatSys:getInstance():getChatSetting(EChatSetting.MAIN_SHOW_SYS)
    --世界是否勾选
    local bSettingWorld = XBChatSys:getInstance():getChatSetting(EChatSetting.MAIN_SHOW_WORLD)
    --公会是否勾选
    local bSettingGuild = XBChatSys:getInstance():getChatSetting(EChatSetting.MAIN_SHOW_GUILD)      
    --私聊是否勾选
    local bSettingShiliao = XBChatSys:getInstance():getChatSetting(EChatSetting.MAIN_SHOW_PRIVATE_CHAT)
    print("MiniChatSys:filterData  bShiliao",bSettingShiliao)

    -- local count = #src_data or 0
    -- print("MiniChatSys:filterData  count",count)
    print("MiniChatSys:filterData ...minIndex:"..tostring(minIndex)..",maxIndex:"..tostring(maxIndex))

    minIndex = minIndex or 1
    maxIndex = maxIndex or 1


    for i=minIndex,maxIndex do
        local talkData = src_data[i]

        if talkData then
            local messageType = talkData["messageType"]
            local session_id = talkData["session"]["session_id"]
            local session_type = talkData["session"]["session_type"]
            
            talkData["miniChatIndex"] = i
            --系统
            if (messageType == 1005 or messageType == 1006) and bSettingSys == true then
                table.insert(dest_data,talkData)
            end

            --世界
            local bWorld = XBChatSys:getInstance():isWorldRoom(session_id,session_type)
            if messageType == 0 and bWorld == true and bSettingWorld == true then
                table.insert(dest_data,talkData)
            end

            --公会
            local bGuild = XBChatSys:getInstance():isGuideID(session_id,session_type)
            if messageType == 0 and bGuild == true and bSettingGuild == true then
                table.insert(dest_data,talkData)
            end
            print("MiniChatSys:filterData  bWorld  bGuild",bWorld,bGuild)
            print("MiniChatSys:filterData  messageType333333  messageType session_id  bSettingShiliao",messageType,session_id,bSettingShiliao)
            --私聊
            if messageType == 0 and session_type == 0 and bSettingShiliao == true then
                print("MiniChatSys:filterData  messageType   session_id   bShiliao444444",messageType,session_id,bSettingShiliao)
                table.insert(dest_data,talkData)
            end
        end
    end
    -- dump(dest_data,"MiniChatSys:filterData  messageType   session_id   dest_data")
    return dest_data
end

-- messageType —区分文字、语音，公告，物品获得，时间戳，多人战邀请
-- session = {  —频道类型：（id，type）       —区分频道: 私聊.世界,公会，系统，战斗
--         session_id
--         session_type
--     }

-- uid
-- name
-- text
-- itemObject = { id,type}
function MiniChatSys:deConver( data )
    -- body
    if data == nil then
        return
    end

    -- {
    --  "messageType" = 0
    --  "session" = {
    --      "session_id"   = "21707543"
    --      "session_type" = 2
    --  }
    --  "text"        = "过哈哈哈哈哈"
    --  "timestamp"   = 1542958622.8491
    --  "user_nim_id" = "379uqu8jd_gf0"
    -- }

    -- dump(data,"MiniChatSys:deConver  data")

    local user_nim_id = data["user_nim_id"]
    local player_info = XBChatSys:getInstance():getUserInfoByNimId(user_nim_id)
    -- dump(player_info,"MiniChatSys:deConver  player_info")
    local user_uid = 0
    if player_info and player_info["uid"] then
        user_uid = player_info["uid"]
    end
    local user_name = Lang:toLocalization(1031031) --"无名"
    if player_info and player_info["name"] then
        user_name = player_info["name"]
    end
    local fillSpace = self:fillSpace()
    local chat_type = data["chat_type"]
    local messageType = data["messageType"]
    local session_id = data["session"]["session_id"]
    local session_type = data["session"]["session_type"]
    
    local user_talk = fillSpace..tostring(data["text"])
    local item_id = 0
    local item_type = 0
    local message = ""

    if data["messageObject"] and data["messageObject"]["id"] then
        item_id = data["messageObject"]["id"]
    end

    if data["messageObject"] and data["messageObject"]["type"] then
        item_type = data["messageObject"]["type"]
    end

    if data["messageObject"] and data["messageObject"]["message"] then
        message = data["messageObject"]["message"]
    end

    local bGuild = XBChatSys:getInstance():isGuideID(session_id,session_type)
    local bWorld = XBChatSys:getInstance():isWorldRoom(session_id,session_type)

    local devTalk = user_talk or ""

    print("MiniChatSys:after deConver  bGuild  bWorld  messageType session_id session_type  ",bGuild,bWorld,messageType,session_id,session_type)
    --公会 文本信息
    if bGuild == true and messageType == 0 then
        chat_type = MiniChatSys.EType.guild
    end

    --世界
    if bWorld == true and messageType == 0 then
        chat_type = MiniChatSys.EType.world
    end

    --私聊
    if messageType == 0 and session_type == 0 then
        chat_type = MiniChatSys.EType.friend
    end

    --系统公告
    if messageType == 1005 then
        chat_type = MiniChatSys.EType.notice
        devTalk = "            "..tostring(message)
    end

    --物品获得
    if messageType == 1006 then
        chat_type = MiniChatSys.EType.obtain
        devTalk = message
    end

    local item_name = ""
    local item_rarity_str = ""
    local item_des = ""
    local rarity = 0
    if messageType == 1006 then
        if item_type == 3 then
            local equip_data = table.getValue("deConver item_id == >,",equip,item_id)
            rarity = table.getValue("deConver rarity == >",equip_data,"equip_rank")
            item_rarity_str = string.format(UITool.ToLocalization("经过不懈努力,终于抽到了  %d星 "),rarity)
            item_des = UITool.ToLocalization(" 稀有装备  ")
            item_name = UITool.getUserLanguage(table.getValue("deConver item_name == >",equip_data,"equip_name"))
        elseif item_type == 4 then
            local hero_data = table.getValue("deConver hero_id == >,",hero,item_id)
            rarity = table.getValue("deConver rarity == >",hero_data,"hero_rank")
            item_rarity_str = string.format(UITool.ToLocalization("经过不懈努力,终于抽到了  %d星 "),rarity)
            item_des = UITool.ToLocalization(" 稀有英雄  ")
            item_name = UITool.getUserLanguage(table.getValue("deConver item_name == >",hero_data,"hero_name"))
        end
    end


    local chat_data = {}
    chat_data.chat_type = chat_type
    chat_data.uid = user_uid
    chat_data.speaker = user_name
    if chat_type == MiniChatSys.EType.notice then 
        chat_data.talk = tostring(devTalk)
    else
        chat_data.talk = self:fillSpace(chat_data.speaker)..tostring(devTalk)
    end
    chat_data.item_type = item_type
    chat_data.item_id = item_id
    chat_data.rarity_des = item_rarity_str
    chat_data.item_des = item_des
    chat_data.item_name = item_name
    -- dump(chat_data,"MiniChatSys:deConver  chat_data")
    print("MiniChatSys:deConver  fillSpace count  user_uid:",self:fillSpace(chat_data.speaker),user_uid)
    return chat_data
end

function MiniChatSys:fillSpace(str )
    -- body
    local space = ""
    local spaceCount = self:getSpaceCount(str)
    for i=1,spaceCount do
        space = space.." "
    end

    return space
end

function MiniChatSys:fillLittleSpace( str )
    -- body
    local space = ""
    local spaceCount = self:getSpaceCount(str)
    spaceCount = spaceCount - 26
    for i=1,spaceCount do
        space = space.." "
    end

    return space
end

function MiniChatSys:fillSysSpace()
    return self:getSpaceCount("        ")
end

function MiniChatSys:getSpaceCount( str )
    -- body
    local baseSpaceCount = 6
    local fontSize = 22
    local fixCount = 8
    local fixW = fontSize * 8
    local label = ccui.Text:create(str,TEXT_FONT_NAME,fontSize)
    local strW = label:getContentSize().width

    local space = ccui.Text:create(" ",TEXT_FONT_NAME,fontSize)
    local oneSpaceW = space:getContentSize().width

    local spaceCount = math.ceil(strW/oneSpaceW) + 2

    local destSpaceCount = baseSpaceCount + spaceCount

    -- local strSpace = math.ceil()
    -- print("MiniChatSys:fillSpace  str",str)
    -- print("MiniChatSys:fillSpace  strW",strW)
    -- local delW = fixW - strW

    
    --  print("MiniChatSys:fillSpace   delW   fixW   strW",delW,fixW,strW)
    -- local spaceCount = math.floor(delW/oneSpaceW)
    -- print("MiniChatSys:fillSpace   spaceCount",spaceCount)
    -- spaceCount = baseSpaceCount + spaceCount
    return destSpaceCount
end


