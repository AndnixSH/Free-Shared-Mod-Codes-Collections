--战斗数据
--created by kobejaw.2018.3.13.
BattleDataManager = {}

local melleePosArray = {16,14,12,10}
local remotePosArray = {8,6,10,4}
local melleePosIdx
local remotePosIdx

function BattleDataManager:init(data)
	self.data = data;

	melleePosIdx = 1;
	remotePosIdx = 1;

	self.bgm1 = nil;
	self.bgm2 = nil;

	self.isBoss = false
	self.isReJoin = false --是否是第二次加入
end

function BattleDataManager:getData()
	return self.data;
end

function BattleDataManager:parseJsonData()
	self:createBattleData()
	self:createDropData()
	self:createRoleData()
	self:createMonsterData()
	self:createWavesData()

	if G_STAGE_TYPE == 2 then
		self:createMultiData()
	end

	if G_STAGE_TYPE == 3 then
		self:createTowerData()
	end
end

--战场数据
function BattleDataManager:createBattleData()
	if G_STAGE_TYPE == 2 then
		self.battleId = tostring(self.data.id)
		self.timeLimit = tonumber(self.data.ret_time)--剩余时间（秒）
	else
		self.battleId = tostring(self.data.level_id)
		self.timeLimit = tonumber(self.data.time_limit)
	end

	if not self.timeLimit then
		self.timeLimit = 240
	end

	if self.data.re_join and self.data.re_join == 1 then
		self.isReJoin = true
	else
		self.isReJoin = false
	end
end

--掉落宝箱
function BattleDataManager:createDropData()
	--掉落宝箱列表
    self.dropList = {}
    if not self.data.drop then --多人战没有这个字段
    	return
    end
    for k,v in pairs(self.data.drop) do
    	local puid = tonumber(v.m_id)
		if G_STAGE_TYPE == 3 then
			puid = puid + 1
		end
    	self.dropList[puid] = tonumber(v.drop_num)
    end
end

function BattleDataManager:createRoleData()
	--公主技能信息
	local ps_skillID = self.data.ps.a_skill
	if ps_skillID ~= nil and tonumber(ps_skillID) ~= 0 then
        self.hasPrincess = true
        self.ps_skillID = tonumber(ps_skillID)
    else
    	self.hasPrincess = false
    end

    self.heroIdList = {}

	--角色信息
	self.roleDataArray = {}
    local heroInfoArray = self.data.team
    for i = 1,#heroInfoArray do

    	if IsTestMode and i > TotalTestRoleNum then
    		return
    	end

        self.roleDataArray[i] = self:createOneRoleData(heroInfoArray[i],i)
    end	
end

function BattleDataManager:createOneRoleData(jsonData,idx)
    local str = jsonData.id
    local array = UITool.stringSplit(str, "*")
    local heroId

    if IsTestMode then
    	heroId = RolesTest[idx].heroId
    else
    	heroId = tonumber(array[1])
    end
    
    table.insert(self.heroIdList,heroId)

	local data = {}
	--自定义
	data.entityType = BattleGlobals.EntityType.Role

	--常量组1。服务器传过来的值
	data.heroId = heroId
	data.gid = tostring(heroId)
	data.HP = tonumber(jsonData.hp)
	data.shotRange = tonumber(jsonData.shot) --射程
	data.retce_state = tostring(jsonData.retce_state) --免疫的debuff列表
	data.recover = tonumber(jsonData.hel) --恢复力
	data.crit = tonumber(jsonData.crit) --暴击率
	data.speed = tonumber(jsonData.mvs)   --移动速度
	data.attack = tonumber(jsonData.atk)   --攻击力
	data.defence = tonumber(jsonData.def)  --防御力
	data.celerity = tonumber(jsonData.asp)/1000  --攻速。攻击完后停顿的时间。
	data.add_bk_dmg = tonumber(jsonData.add_bk_dmg)  --对手是狂暴状态增加的攻击力
	data.add_od_dmg = tonumber(jsonData.add_od_dmg)  --对手是虚弱状态增加的攻击力
	data.entityType = BattleGlobals.EntityType.Role
	data.Lv = tonumber(jsonData.Lv)
	data.crit_dmg = tonumber(jsonData.crit_dmg)   --暴击伤害加成
	data.pattack_rate = tonumber(jsonData.pattack_rate)       --普攻倍率加成
	data.resistance = tonumber(jsonData.resistance)  --异常抗性
	data.debuff_rate = tonumber(jsonData.debuff_rate) --释放debuff的命中率加成
	data.re_dmg = tonumber(jsonData.re_dmg)  --减伤  角色被动技能+星之卵被动 +公会buff + 公主被动 + master
	data.add_dmg = tonumber(jsonData.add_dmg) --增加的伤害  角色被动技能+星之卵被动 +公会buff + 公主被动 + master
	data.emi_atk = tonumber(jsonData.e_atk)    --背水攻击力。
	data.addweakDamage = tonumber(jsonData.add_weak_dmg) --弱点攻击力.每多一个debuff增加的攻击力
	data.skill_dmg = tonumber(jsonData.add_sk_dmg)   --（被动）技能（提供的）倍率加成
	data.skill_crite = tonumber(jsonData.skill_crite)--（被动）技能（提供的）暴击率加成
	data.skill_criteDmg = tonumber(jsonData.skill_criteDmg)  --技能暴击伤害加成。
	data.water_res = tonumber(jsonData.water_res) --水抗性
	data.wind_res = tonumber(jsonData.wind_res)   --风抗性
	data.fire_res = tonumber(jsonData.fire_res)   --火抗性
	data.light_res = tonumber(jsonData.light_res) --光抗性
	data.dark_res = tonumber(jsonData.dark_res) --暗抗性
	data.skill_cd_1 = tonumber(jsonData.skill_cd_1)--小技能减少的CD
	data.skill_cd_2 = tonumber(jsonData.skill_cd_2)--大技能减少的CD
	data.crit_resist = tonumber(jsonData.crit_resist) --抗暴率
	data.block_rate = tonumber(jsonData.block_rate)   --格挡率
	data.block_effect = tonumber(jsonData.block_effect) --格挡值
	data.block_break_rate = tonumber(jsonData.block_break_rate)  --破格率
	data.block_break_effect = tonumber(jsonData.block_break_effect)  --破格值
	data.add_dmg_skill_1 = tonumber(jsonData.add_dmg_skill_1)  --小技能伤害加成
	data.add_dmg_skill_2 = tonumber(jsonData.add_dmg_skill_2)  --大技能伤害加成

	data.activeSkillArray = {} --主动技能

	if IsTestMode then
		data.activeSkillArray = RolesTest[idx].skill
	else
		for i = 1,#jsonData.active_sk do
			data.activeSkillArray[i] = tonumber(jsonData.active_sk[i])
		end
	end

	data.skill_cd_1 = skill[data.activeSkillArray[1]].skill_cd - data.skill_cd_1  --小技能CD
	data.skill_cd_2 = skill[data.activeSkillArray[2]].skill_cd - data.skill_cd_2  --大技能CD

	data.passiveSkillArray = {}--被动技能
	if IsTestMode then
		data.passiveSkillArray = RolesTest[idx].passiveSkill
	else
		for i = 1,#jsonData.passive_sk do--角色自带的被动技能
			data.passiveSkillArray[i] = tonumber(jsonData.passive_sk[i])
		end
	end

	--常量组2.本地表里的值
	data.atb = hero[heroId].hero_atb   --元素
	data.sex = hero[heroId].sex_name   --性别。男1女2
	data.power_name = hero[heroId].power_name --势力
	data.job = hero[heroId].hero_job --职业
	data.race = hero[heroId].hero_race --种族

	if IsTestMode then--射程
		if data.job == 1 then
			data.shotRange = 3
		else
			data.shotRange = 10
		end
	end

	data.spineFullPath = tostring(hero[heroId].hero_bat)
	data.heroName = GetStringAllPlatform(tostring(hero[heroId].hero_name))
	if data.job == 1 then --近战
		data.mellee = true
		data.fight_pos = melleePosArray[melleePosIdx]
		melleePosIdx = melleePosIdx + 1
	else                                --远程
		data.fight_pos = remotePosArray[remotePosIdx]
		remotePosIdx = remotePosIdx + 1;
	end
	data.initialPos = GetPointByBoxIdx(data.fight_pos)--初始位置。
	--普通攻击类型
	local atkId = hero[heroId].hero_atk1

	data.attackData = Attack[atkId]
	if atkId == 0 then
		data.attackType = 0
	else
		data.attackType = Attack[atkId].attack_type
		--远程普通攻击子弹资源路径
		data.bulletRes = Attack[atkId].res_fly
		--普通攻击击中效果资源路径
		data.hitRes = Attack[atkId].res_hit	
		--飞弹类普通攻击的速度
		data.bulletSpeed = Attack[atkId].skill_speed
		--远程或爆炸类的击中音效
		data.hitSound = Attack[atkId].skill_sound
	end

	--播放受击特效的位置
	data.hitPosX = hero[heroId].hero_bd[1] 
	data.hitPosY = hero[heroId].hero_bd[2]
	--出手点（对于远程有效）
	data.bulletPos = {}
	data.bulletPos.x = hero[heroId].hero_shoot[1]
	data.bulletPos.y = hero[heroId].hero_shoot[2]
	--受击框左侧x值
	data.hitLeftX = hero[heroId].hero_hit[1]
	--受击框右侧x值
	data.hitRightX = hero[heroId].hero_hit[1] + hero[heroId].hero_hit[3]

	--其他信息用到的时候去查hero表

	return data;
end

function BattleDataManager:createMonsterData()
    self.monsterDataArray = {}
    local monsterInfoArray = self.data.monster
    for i = 1,#monsterInfoArray do
        self.monsterDataArray[i] = self:createOneMonsterData(monsterInfoArray[i])
    end
end

function BattleDataManager:createOneMonsterData(jsonData)

	local monsterId
	if IsTestMode and IsBossTest then
		monsterId = BossTest.heroId
	else
		monsterId = tonumber(jsonData.static_id)
	end

	local data = {}
	--自定义
	data.entityType = BattleGlobals.EntityType.Monster

	--常量组1。服务器传过来的值
	data.puid = tonumber(jsonData.m_id)--唯一标识

	--爬塔的m_id是从0开始的，其他战斗是从1开始的。
	if G_STAGE_TYPE == 3 then
		data.puid = data.puid + 1
	end

	--掉落
	if self.dropList[data.puid] ~= nil then
		data.dropNum = self.dropList[data.puid]
	end

	data.monsterId = monsterId;
	data.HP = tonumber(jsonData.hp)
	data.shotRange = tonumber(jsonData.shot) --射程
	data.retce_state = tostring(jsonData.retce_state) --免疫的debuff列表
	data.recover = tonumber(jsonData.hel) --恢复力
	data.crit = tonumber(jsonData.crit) --暴击率
	data.speed = tonumber(jsonData.mvs)   --移动速度
	data.attack = tonumber(jsonData.atk)   --攻击力
	data.defence = tonumber(jsonData.def)  --防御力
	data.celerity = tonumber(jsonData.asp)/1000  --攻速
	data.add_bk_dmg = tonumber(jsonData.add_bk_dmg)  --对手是狂暴状态增加的攻击力
	data.add_od_dmg = tonumber(jsonData.add_od_dmg)  --对手是虚弱状态增加的攻击力
	data.Lv = tonumber(jsonData.Lv)
	data.resistance = tonumber(jsonData.resistance)  --异常抗性
	data.debuff_rate = tonumber(jsonData.debuff_rate) --释放debuff的命中率加成
	data.mCount = tonumber(jsonData.mCount_max)       --能量都上限
	data.re_dmg = tonumber(jsonData.re_dmg)  --减伤  角色被动技能+星之卵被动 +公会buff + 公主被动 + master
	data.add_dmg = tonumber(jsonData.add_dmg) --增加的伤害  角色被动技能+星之卵被动 +公会buff + 公主被动 + master
	data.emi_atk = tonumber(jsonData.e_atk)    --背水攻击力。
	data.addweakDamage = tonumber(jsonData.add_weak_dmg) --弱点攻击力。每多一个debuff增加的攻击力
	data.skill_dmg = tonumber(jsonData.add_sk_dmg)   --技能倍率加成
	data.skill_crite = tonumber(jsonData.skill_crite)--技能暴击加成
	data.skill_criteDmg = tonumber(jsonData.skill_criteDmg)  --技能暴击伤害加成。
	data.water_res = tonumber(jsonData.water_res) --水抗性
	data.wind_res = tonumber(jsonData.wind_res)   --风抗性
	data.fire_res = tonumber(jsonData.fire_res)   --火抗性
	data.light_res = tonumber(jsonData.light_res) --光抗性
	data.dark_res = tonumber(jsonData.dark_res) --暗抗性
	data.atb = tonumber(jsonData.element)
	data.crit_resist = tonumber(jsonData.crit_resist) --抗暴率
	data.block_rate = tonumber(jsonData.block_rate)   --格挡率
	data.block_effect = tonumber(jsonData.block_effect) --格挡值
	data.block_break_rate = tonumber(jsonData.block_break_rate)  --破格率
	data.block_break_effect = tonumber(jsonData.block_break_effect)  --破格值

	--5为boss，6为精英怪。
	data.monsterEnum = tonumber(jsonData.m_type) --2019.1.3新增。monsterEnum为6代表是精英怪。精英怪不会后仰硬直。
	if data.monsterEnum == 5 then
		self.isBoss = true;  --注：C++是在MonsterController里的，lua放这里。
	end

	data.od_hp = tonumber(jsonData.od_hp)
	data.bk_hp = tonumber(jsonData.bk_hp)
	if G_STAGE_TYPE == 2 then
		data.bk_t = tonumber(jsonData.bk_t)       --虚弱时间
	else
		data.bk_t = tonumber(jsonData.bk_t)/1000  --虚弱时间
	end

	data.activeSkillArray = {} --主动技能
	if IsTestMode then
		for i = 1,#BossTest.skill do
			data.activeSkillArray[i] = BossTest.skill[i]
		end
	else
		for i = 1,#jsonData.active_sk do
			data.activeSkillArray[i] = tonumber(jsonData.active_sk[i])	
		end	
	end

	data.passiveSkillArray = {}--被动技能
	if IsTestMode then
		for i = 1,#BossTest.passiveSkill do
			data.passiveSkillArray[i] = BossTest.passiveSkill[i]
		end	
	else
		for i = 1,#jsonData.passive_sk do
			data.passiveSkillArray[i] = tonumber(jsonData.passive_sk[i])
		end
	end

	--如果是爬塔
	if G_STAGE_TYPE == 3 then
		local count_tow = #self.data.monster_state
		for i = 1,count_tow do
			local m_id_tower = tostring(self.data.monster_state[i].m_id)
			if data.puid - 1 == m_id_tower then
				data.HP = self.data.monster_state[i].hp
			end
		end
	end
	
	--常量组2.本地表里的值
	--体积类型
	data.cubageType = monster[monsterId].monster_cubageType

	data.job = monster[monsterId].monster_job --职业
	data.race = monster[monsterId].monster_race --种族

	data.spineFullPath = tostring(monster[monsterId].monster_bat)
	data.heroName = tostring(monster[monsterId].monster_name)

	--攻击类型
	local atkId = monster[monsterId].monster_atk1
	data.attackData = Attack[atkId]
	if atkId == 0 then
		data.attackType = 0
	else
		data.attackType = Attack[atkId].attack_type
		--远程普通攻击子弹资源路径
		data.bulletRes = Attack[atkId].res_fly
		--普通攻击击中效果资源路径
		data.hitRes = Attack[atkId].res_hit
		--飞弹类普通攻击的速度
		data.bulletSpeed = Attack[atkId].skill_speed
		--远程或爆炸类的击中音效，近战的攻击音效
		data.hitSound = Attack[atkId].skill_sound					
	end

	--出手点（对于远程有效）
	data.bulletPos = {}
	data.bulletPos.x = monster[monsterId].monster_shoot[1]
	data.bulletPos.y = monster[monsterId].monster_shoot[2]
	--播放受击特效的位置
	data.hitPosX = monster[monsterId].monster_bd[1] 
	data.hitPosY = monster[monsterId].monster_bd[2]
	--受击框左侧x值
	data.hitLeftX = monster[monsterId].monster_hit[1]
	--受击框右侧x值
	data.hitRightX = monster[monsterId].monster_hit[1] + monster[monsterId].monster_hit[3]

	--其他信息用到的时候去查monster表

	return data;
end

--多人战相关数据
function BattleDataManager:createMultiData()
	self.multiData = {}

	self.multiData.bossState = tonumber(self.data.monster_mul[1].mode)
	self.multiData.od_n_hp = tonumber(self.data.monster_mul[1].od.od_n_hp)
	self.multiData.bk_n_hp = tonumber(self.data.monster_mul[1].bk.bk_n_hp)
end

--爬塔相关数据
function BattleDataManager:createTowerData()
	self.towerData = {}
	for k,v in pairs(self.data.monster_state) do
		self.towerData[v.m_id+1] = v.hp
	end
end

function BattleDataManager:getRoleDataById(roleId)
	for i = 1,#self.roleDataArray do
		if self.roleDataArray[i].heroId == roleId then
			return self.roleDataArray[i]
		end
	end
	return nil;
end

function BattleDataManager:getMonsterDataById(puid)
	for i = 1,#self.monsterDataArray do
		if self.monsterDataArray[i].puid == puid then
			return self.monsterDataArray[i]
		end
	end
	return nil;
end

--创建刷怪
function BattleDataManager:createWavesData()
	self.wavesArray = {}

	if self.data.screens ~= nil and type(self.data.screens) == "table" then
		for i = 1,#self.data.screens do
			self.wavesArray[i] = self:createOneWaveData(self.data.screens[i])
		end
	end
end

--创建一波怪
function BattleDataManager:createOneWaveData(jsonData)
	local data = {}
	data.wave = jsonData.wav;
	return data;
end

function BattleDataManager:clear()
	self.multiData = {}
	self.wavesArray = {}
	self.monsterDataArray = {}
	self.roleDataArray = {}
	self.dropList = {}
	self.heroIdList = {}
	self.towerData = {}
	self.sharedbuff = {}
	self.bgm1 = nil
	self.bgm2 = nil
	self.isReJoin = false
end