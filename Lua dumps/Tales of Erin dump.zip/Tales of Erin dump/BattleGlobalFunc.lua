--战斗相关全局函数
--created by kobejaw.2018.3.16.

local audio --windows版会用到

function PushBattleScene(data)
    if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
        audio = require("cocos/framework/audio")
    end
    BattleDataManager:init(data); 
    local battlescene = BattleScene:create();
    cc.Director:getInstance():pushScene(battlescene)	
end

--延时执行
function PerformWithDelayTime(listener, seconds)
    if not G_IsInBattle then
        return
    end

    local scheduler = cc.Director:getInstance():getScheduler()
    local handle
    handle = scheduler:scheduleScriptFunc(function()
        scheduler:unscheduleScriptEntry(handle)
        if G_IsInBattle then
            listener()
        end
    end, seconds, false)
    return handle
 end

--三目运算
function ThreeMeshOperation(conditon,result1,result2)
    if conditon then
        return result1
    else
        return result2
    end
end
--简易版三目运算
function ThreeMeshTwoParam(result1,result2)
    if result1 then
        return result1
    else
        return result2
    end
end

--数组去重函数
function RemoveRepeatedNum(a)
    local b = {}
    for k,v in ipairs(a) do
        if(#b == 0) then
            b[1]=v;
        else
            local index = 0
            for i=1,#b do
                if(v == b[i]) then
                    break
                end
                index = index + 1
            end
            if(index == #b) then
                b[#b + 1] = v;
            end
        end
    end
    return b
end

--获取A到B之间的随机数
--全局：G_Seed 上一次的随机数种子
G_Seed = 0
G_SeedIdx = 11111
function GetRandomBetweenAB(A,B)
    local seed = tonumber(tostring(os.time()):reverse():sub(1, 6))
    if seed == G_Seed then
        G_SeedIdx = G_SeedIdx + 11111
        if G_SeedIdx >= 10000000 then
            G_SeedIdx = 11111
        end 
        math.randomseed(G_Seed + G_SeedIdx)
    else
        math.randomseed(seed)
    end
    G_Seed = seed
    return math.random(A,B)
end

--检测概率事件是否发生。例如命中，暴击等。
function CheckProbabilityEvent(probability)
    local v = GetRandomBetweenAB(1,100)
    if v <= probability then
        return true
    else
        return false
    end
end

--四舍五入
function GetRoundNum(num)
    return math.floor(num + 0.5)
end

--根据格子序号计算坐标
function GetPointByBoxIdx(boxNum)
    local boxWN = math.floor(boxNum/BattleGlobals.BOX_N);
    local boxNN = boxNum%BattleGlobals.BOX_N;
   
    local addx = BattleGlobals.BOX_W/2;
    local addy = BattleGlobals.BOX_H/2;

    local x = boxWN*BattleGlobals.BOX_W + addx;
    local y = boxNN*BattleGlobals.BOX_H + BattleGlobals.localMinY + addy;
    
    return cc.p(x,y)
end

--根据wh计算xy
function GetPointByBoxWH(w,h)
    local x = w*BattleGlobals.BOX_W + 25;
    local y = h*BattleGlobals.BOX_H + BattleGlobals.localMinY + 25;
    return cc.p(x,y)
end

--根据坐标计算格子序号
function GetBoxIdxByPoint(x,y)
    if y > BattleGlobals.localMaxY then
        y = BattleGlobals.localMaxY
    end
    if y < BattleGlobals.localMinY then
        y = BattleGlobals.localMinY
    end

    local boxNum_w = math.floor(x/BattleGlobals.BOX_W)
    local boxNum_h = math.floor((y-BattleGlobals.localMinY)/BattleGlobals.BOX_H)
    return boxNum_w * BattleGlobals.BOX_N + boxNum_h
end

--根据坐标计算格子的w和h值
function GetBoxWHByPoint(x,y)
    if y > BattleGlobals.localMaxY then
        y = BattleGlobals.localMaxY
    end
    if y < BattleGlobals.localMinY then
        y = BattleGlobals.localMinY
    end

    local boxNum_w = math.floor(x/BattleGlobals.BOX_W)
    local boxNum_h = math.floor((y-BattleGlobals.localMinY)/BattleGlobals.BOX_H)

    return boxNum_w,boxNum_h
end

--获得修正后的坐标，新坐标对应某个格子的中心点
function GetCorrectedPoint(x,y)
    if y > BattleGlobals.localMaxY then
        y = BattleGlobals.localMaxY
    end
    if y < BattleGlobals.localMinY then
        y = BattleGlobals.localMinY
    end
    local boxNum_w = math.floor(x/BattleGlobals.BOX_W)
    local boxNum_h = math.floor((y-BattleGlobals.localMinY)/BattleGlobals.BOX_H)   

    local ret_x = boxNum_w * BattleGlobals.BOX_W + BattleGlobals.BOX_W/2
    local ret_y = boxNum_h * BattleGlobals.BOX_H + BattleGlobals.localMinY + BattleGlobals.BOX_H/2;

    return cc.p(ret_x,ret_y)
end

function GetWHByIdx(idx)
    return math.floor(idx/3),idx%3
end

--创建特效spine
function CreateEffectSpineNode(path,isRepeat,animationName)
    local spineData = BattleCacheManager:getData(path)
    if not spineData then
        return nil
    end

    local aniName;
    if animationName then
        aniName = animationName
    else
        aniName = "effect"
    end

    local effectSpineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
    if isRepeat then
        effectSpineNode:setAnimation(0,aniName,true)
    else
        effectSpineNode:setAnimation(0,aniName,false)
    end

    return effectSpineNode
end

--当特效播放完成后移除自己
function RemoveEffectOnComplete(effectNode)
    local function completeCallback(event)
        --删除自己，如果在事件里删除自己，必须下一帧执行。
        local function removeSelf()
            if G_IsInBattle then
                RemoveFromNodesWithSpine(effectNode)
                effectNode:removeFromParent();
            end
        end
        PerformWithDelayTime(removeSelf,0.01)
    end

    effectNode:registerSpineEventHandler(completeCallback,sp.EventType.ANIMATION_COMPLETE)
end

function PauseNodesWithAction()
    for k,v in pairs(G_NodesWithAction) do
        v:pause()
        v:setColor(cc.c3b(80,80,80))
    end
end

function ResumeNodesWithAction()
    for k,v in pairs(G_NodesWithAction) do
        v:resume()
        v:setColor(cc.c3b(255,255,255))
    end    
end

function RemoveFromNodesWithAction(node)
    for k,v in pairs(G_NodesWithAction) do
        if v == node then
            table.remove(G_NodesWithAction,k)
        end
    end
end

function PauseNodesWithSpine()
    for k,v in pairs(G_NodesWithSpine) do
        v:setTimeScale(0.00000001)
        v:setColor(cc.c3b(80,80,80))
    end
end

function ResumeNodesWithSpine()
    for k,v in pairs(G_NodesWithSpine) do
        v:setTimeScale(1)
        v:setColor(cc.c3b(255,255,255))
    end    
end

function RemoveFromNodesWithSpine(node)
    for k,v in pairs(G_NodesWithSpine) do
        if v == node then
            table.remove(G_NodesWithSpine,k)
        end
    end
end

--@delayTime:只有windows平台用到
function SetLastFrameCallFunc_AllPlatform(action,callback,delayTime)
    if not G_IsInBattle then
        return
    end
    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        action:setLastFrameCallFunc(callback)
    else
        PerformWithDelayTime(callback,delayTime)
    end
end

--音乐音效相关
--预加载音乐
function BattlePreloadMusic(file)
    if file == nil or file == "" then
        return
    end

    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        AudioManager:shareDataManager():preloadM(file)
    else
        audio.preloadMusic(file)
    end
end

--播放音乐
function BattlePlayBGM(file,loop)
    if not BattleRuntimeInfo.isMusicOn or file == nil or file == "" then
        return
    end

    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        AudioManager:shareDataManager():playBGMusic(file,loop)
    else
        audio.playMusic(file,loop)
    end
end

--播放音效
--type: 0.音效。1.语音。2.攻击音效。
function BattlePlaySound(file,loop,type)
    if not BattleRuntimeInfo.isSoundOn or file == nil or file == "" then
        return
    end

    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        AudioManager:shareDataManager():playMusic(file,type,loop)
    else
        audio.playSound(file,loop)
    end
end

--背景音乐是否在播放
function BattleIsBGMPlaying()
    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        if AudioManager:shareDataManager():getBGId() == -1 then
            return false
        else
            return true
        end
    else
        return audio.isMusicPlaying()
    end
end

function BattleStopBGM()
    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        AudioManager:shareDataManager():stopBGMusic()
    else
        audio.stopMusic(true)
    end
end

function GetStringAllPlatform(str)
    if cc.Application:getInstance():getTargetPlatform() ~= cc.PLATFORM_OS_WINDOWS then
        return UITool.getUserLanguage(str)
    else
        return str
    end 
end

--将文本拷贝至系统剪切板
function copyToClipBoard(str)
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()

    local function luaCallback(param)
        --java的lua回调。Do Nothing
    end
    
    if cc.PLATFORM_OS_ANDROID == targetPlatform then -- android 平台复制粘贴相关功能
        --[[
        local className = "org/cocos2dx/lib/Cocos2dxHelper"
        local luaj = require "cocos.cocos2d.luaj"
        local args = {str,luaCallback}
        local sigs = "(Ljava/lang/String;I)V"
        
        local ok,ret = luaj.callStaticMethod(className, "copyToClipboard",args,sigs)
        ]]
    elseif (targetPlatform == cc.PLATFORM_OS_MAC or targetPlatform == cc.PLATFORM_OS_IPHONE or targetPlatform == cc.PLATFORM_OS_IPAD) then  -- ios 平台复制粘贴相关功能
        --[[
        local className = "LuaObjectCBridge";
        local luaoc = require "cocos.cocos2d.luaoc";
        local args = {
            text = str
        }
        local ok, ret = luaoc.callStaticMethod(className, "copyToClipboard", args)
        if not ok then
            print(string.format("DeviceInfo.payForCoins() - call API failure, error code: %s", tostring(ret)))
        end
        ]]  
    end
end
