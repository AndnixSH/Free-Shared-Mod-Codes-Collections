require "BasicLayer"

ActAchievementLayer= class("ActAchievementLayer",BasicLayer)
ActAchievementLayer.__index        = ActAchievementLayer
ActAchievementLayer.lClass         = 2


ActAchievementLayer.changeTable    = nil

ActAchievementLayer.panelList      = nil
ActAchievementLayer.act_id      = nil --活动ID

--以下是分签新增
ActAchievementLayer.tab_btn_data      = nil --页签数据
ActAchievementLayer.actAchiData = {}
ActAchievementLayer.tab_btn_listview      = nil
ActAchievementLayer.defaultIndex    =     1 --默认选择页签索引
ActAchievementLayer.lastSelectIndex    =     0 --上次选择页签索引
ActAchievementLayer.bSendGet = false

function ActAchievementLayer:init()
	local node  = cc.CSLoader:createNode("ActAchievementLayer.csb")
    self.uiLayer:addChild(node,0,2)
    
    self.bIsCYStory =  self.rData["rcvData"]["bIsCYStory"] or false
    self.cyConfig =  self.rData["rcvData"]["cyConfig"] or nil
    
    self.act_id  = self.rData["rcvData"]["act_id"]

    self:initStaticData()
    self:initView()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        self:returnBack()
    end)

    self.exist = true
end

function ActAchievementLayer:initStaticData( ... )
    -- body
    print("团长的成就是 self.act_id == "..self.act_id)
    if self.rData["rcvData"]["_type"] then
        --这是从团战成就过来的，不需要require_ex  固定的ID 也可以不用取
        --判断不是空的话  证明不需要require_ex 
        -- 1 是团战   2 是极限挑战界面
        if self.rData["rcvData"]["_type"] == 1 then
            self.sendGuildName = "guildbattle_act_achi_list"
            self.getGuildName  = "guildbattle_act_achi_get"
        elseif self.rData["rcvData"]["_type"] == 2 then
            self.sendGuildName = "ultimetecha_act_achi_list"
            self.getGuildName  = "ultimetecha_act_achi_get"
        end
    else 
        
        ---添加当前活动数据表
        local achiTable = string.format("achi_act_%d_conf",tonumber(self.act_id))
        require_ex(achiTable)
    end
end

function ActAchievementLayer:initView( ... )
    -- body
    local node      = self.uiLayer:getChildByTag(2)

    if g_channel_control.b_actAcheMultiTab == true then
        self.tab_btn_listview = node:getChildByTag(127)
        local model = self:initItemModel()
        self.tab_btn_listview:setItemModel(model)
        self.tab_btn_listview:setItemsMargin(15)
        self.tab_btn_listview:setScrollBarEnabled(false)
    end

    local but_Close = node:getChildByName("Button_close") 

    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then

            if name == "Button_close" then
                self:returnBack()

            end
       end
    end

    -- 这是从团战排行过来的
    if self.rData["rcvData"]["_type"] == 1  then
        but_Close:setVisible(false)
        node:getChildByName("Image_closeBg"):setVisible(false)
        node:getChildByName("Image_bg"):setVisible(false)
        --node:getChildByName("Panel_2"):setSwallowTouches(false)
    end
    but_Close:addTouchEventListener(touchCallBack)
    but_Close:setEffectType(3)

    self:initListView()
end

function ActAchievementLayer:initListView( ... )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    local panel = node:getChildByName("Panel_5")
    -- 这是团站界面需要显示的
    local bg  = node:getChildByName("Image_bg")
    local bg_0  = node:getChildByName("Image_bg_0")

    if self.bIsCYStory and g_channel_control.b_CangYi then
        local spBgPath = self.cyConfig.gachaViewBg
        if spBgPath ~= nil then
            bg:loadTexture(spBgPath)
            bg_0:loadTexture(spBgPath)
        end
        local spLihui  = node:getChildByName("Image_bg_0"):getChildByName("spLihui")
        local sLihuiPath = self.cyConfig.gachaViewLihui
        if sLihuiPath ~= nil then
            spLihui:setTexture(sLihuiPath)
        end
        panel:setPosition(425,71)
        bg:setVisible(false)
        bg_0:setVisible(true)
    else
        if self.rData["rcvData"]["_type"] == 1  then
            panel:setPosition(345,71)
            bg:setVisible(false)
            bg_0:setVisible(true)
        else
            bg:setVisible(true)
            bg_0:setVisible(false)
            panel:setPosition(425,71)
        end
    end

    if g_channel_control.b_actAcheMultiTab == true then
        local oldX = panel:getPositionX()
        local newX = oldX - 24
        panel:setPositionX(newX)
    end

    self.panelList = panel
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,830,145)
    self.gridview.itemCreateEvent = function()
        local temp = ActAchievementNode.new():init()
        temp:setActID(self.act_id)
         if self.rData["rcvData"]["_type"] == 1  then
            temp:setBattle("alliance")
         elseif  self.rData["rcvData"]["_type"] == 2 then

            temp:setBattle("ultimate")
        end
        temp:setIsCYStory(self.bIsCYStory,self.cyConfig)
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    if self.rData["rcvData"]["_type"] == 1 or self.rData["rcvData"]["_type"] == 2 then
                        self:sendBatlleGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                    else
                        print("curId == "..temp.curId)
                        self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                    end

                end
            end
        end 
        temp.PanelList:getChildByName("Button_get"):setSwallowTouches(false)
        -- temp.PanelList:getChildByName("Image_panel")setSwallowTouches(false)
        temp.PanelList:getChildByName("Button_get"):addTouchEventListener(touchCallBack)

        return temp
    end

    self:reqActAchiData()
end

function ActAchievementLayer:reqActAchiData( ... )
    -- body
    if self.rData["rcvData"]["_type"] == 1 or self.rData["rcvData"]["_type"] == 2 then
         self:sendBattleTable()
    else
         self:sendTable()
    end
end

--刷新Tble  每次点击不一样的 table 都会更改
function ActAchievementLayer:refreshTale()
    print("self.changeTable self.changeTable == "..#self.changeTable)
    if self.changeTable == nil then
        return
    end
    self.gridview:setDataSource(self.changeTable)
end

function ActAchievementLayer:returnBack( ... )
    -- body
    self.sManager:removeFromNavNodes(self)
    self.sData = {}
    if self.backFunc then
        self.backFunc(self.sDelegate,self.sData)
    end
    self.exist = false
    self.sData = {}
    self.rData = {}
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()

end
-- 团战的成就获取
function ActAchievementLayer:sendBatlleGet( id,ItemId,ItemType,ItemNum )
    -- body
    local function reiceSthCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        if t_data["data"]["guildbattle_achi_red_point"] then
            SceneManager.guildbattle_achi_red_point = t_data["data"]["guildbattle_achi_red_point"]
        end
        if self.refreshSFunc then
            self.refreshSFunc()
        end
        -------------根据类型刷新及时跟新数据-------------
        if ItemType ~= 16 then
            MsgManager:showSimpItemInfo(ItemType,ItemId,ItemNum,UITool.ToLocalization("获取成功"))
        else
            MsgManager:showBaseSpine(ItemId)
        end
       -- MsgManager:showSimpItemInfo(ItemType,ItemId,ItemNum,"获取成功")
        self:refreshUserAsset(t_data)
        -- 根据新街口的需求 需要从新来下服务器列表
        self.everydayTable = nil;
        self:sendBattleTable()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]         = self.getGuildName,
        ["gb_id"]       = self.act_id,
        ["act_achi_id"] = id
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

-- 工会战成就列表
function ActAchievementLayer:sendBattleTable( ... )
    -- body
    local function reiceSthCallBack(data)
        print("获取任务奖励")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.everydayTable = t_data["data"]["list"]--t_data["data"]["everyday_list"]
        self.changeTable = self.everydayTable
        self:SortItem()
        
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = self.sendGuildName,
        ["gb_id"] =    self.act_id,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
-- 活动的成就获取
function ActAchievementLayer:sendGet( id,ItemId,ItemType,ItemNum )
    -- body
    local function reiceSthCallBack(data)
        print("获取登人物奖励 ActAchievementLayer  sendGet")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        -------------根据类型刷新及时跟新数据-------------
        if ItemType ~= 16 then
            MsgManager:showSimpItemInfo(ItemType,ItemId,ItemNum,UITool.ToLocalization("获取成功"))
        else
            MsgManager:showBaseSpine(ItemId)
        end
       -- MsgManager:showSimpItemInfo(ItemType,ItemId,ItemNum,UITool.ToLocalization("获取成功"))
        self:refreshUserAsset(t_data)
        -- 根据新街口的需求 需要从新来下服务器列表
        self.everydayTable = nil
        self.bSendGet = true
        self:sendTable()



    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_achi_get",
       -- ["achi_type"] = self.TypeIndex,
        ["act_achi_id"]   = id,
        ["act_id"] =    self.act_id,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function ActAchievementLayer:sendTable( ... )
	-- body
	local function reiceSthCallBack(data)
        print("获取任务奖励")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end

        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())

        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then

             MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
	        return
        end
        local bMultiable = self:checkData(t_data["data"]["list"])
        if g_channel_control.b_actAcheMultiTab == false then
            if bMultiable == false then
                self.everydayTable = t_data["data"]["list"]--t_data["data"]["everyday_list"]
                self.changeTable = self.everydayTable
                self:SortItem()
            else
                self.actAchiData = t_data["data"]["list"]
                self:refreshActAchiTabView(t_data["data"]["list"])
            end
        elseif g_channel_control.b_actAcheMultiTab == true then
            if bMultiable == false then
                self.everydayTable = t_data["data"]["list"]--t_data["data"]["everyday_list"]
                self.changeTable = self.everydayTable
                self:SortItem()
            else
                self.actAchiData = t_data["data"]["list"]
                self:refreshActAchiTabView(t_data["data"]["list"])
            end
        end
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"]       = "act_achi_list",
        ["act_id"] =    self.act_id,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function ActAchievementLayer:SortItem( tab )
    -- body
------------------怎样的排序----------------------
    local function getStatePriority(_state)
        local priority = 1
        if _state == 1 then 
            priority = 3
        elseif _state == 0 then 
            priority = 2
        end 
        return priority
    end
    local function SortFunc(a,b)
        a.state_priority = getStatePriority(a.state) 
        b.state_priority = getStatePriority(b.state) 
        if a.state_priority == b.state_priority then
            if a.state_priority == 3 then 
                return tonumber(a.id) > tonumber(b.id)
            else 
                return tonumber(a.id) < tonumber(b.id)
            end   
        else
            return a.state_priority > b.state_priority
        end
    end

    table.sort(self.changeTable ,SortFunc)
    -- 需要刷新新的列表
    --self:addItem(self.changeTable,1,4)
    self:refreshTale()
    
end

--刷新用户资产
function ActAchievementLayer:refreshUserAsset( t_data )
    -- body
    user_info["gold"] = t_data["data"]["resource"]["gold"]
    user_info["gem"]  = t_data["data"]["resource"]["gem"]
    user_info["gem_r"]  = t_data["data"]["resource"]["gem_r"]
    if self.sManager ~= nil and self.sManager.menuLayer ~= nil then
        self.sManager.menuLayer:RefshTopBar()
    end
end

--初始化页签模型
function ActAchievementLayer:initItemModel( ... )
    local  layout_model = ccui.Layout:create()
    layout_model:setContentSize(164,100)
    layout_model:setTouchEnabled(true)

    local model = ccui.ImageView:create("n_UIShare/shop/sc_b_001_1.png")
    model:setName("model_img")
    model:setContentSize(164,100) 
    model:setHighlighted(false)
    model:setPosition(cc.p(82,50))

    layout_model:addChild(model)

    local redImg = ccui.ImageView:create("n_UIShare/Global_UI/other/ggsc_b_031_3.png")
    redImg:setTag(TIP_POINT_TAG)
    redImg:setPosition(cc.p(145,76))
    redImg:setScale(0.7)
    layout_model:addChild(redImg)
    
    return layout_model
end

--刷新页签视图
function ActAchievementLayer:refreshActAchiTabView( data )
    -- body
    self.tab_btn_listview:removeAllChildren()

    local tabKeys = self:sortActAchiTabKey(data)
    local btn_num = #tabKeys
    for i = 1,btn_num do
        self.tab_btn_listview:pushBackDefaultItem()
    end

    local function touchCallBack( sender,eventType)
        if eventType == ccui.TouchEventType.ended then
             local tabItemIndex = sender:getTag()
             self:selectButtonByIndex(tabItemIndex)
        end
    end

    for m = 1,btn_num do
        local key = tabKeys[m]
        local t_data = self:getDataByIndex(key)
        local list_data = t_data["list"]
        local bRed = self:checkRedDot(list_data)

        local tab_item = self.tab_btn_listview:getItem(m - 1)
        
        local redImg = tab_item:getChildByTag(TIP_POINT_TAG)
        redImg:setVisible(bRed)

        tab_item:setTag(m)
        tab_item:addTouchEventListener(touchCallBack)
    end
    --默认选中第一个
    self.defaultIndex = self.lastSelectIndex == 0 and 1 or self.lastSelectIndex
    self:selectButtonByIndex(self.defaultIndex)
end

--检测红点
function ActAchievementLayer:checkRedDot( data )
    -- body
    local t_data = data or nil
    local len = #t_data or 0
    local bRed = false
    if len then
        for i=1,len do
            local item_data = t_data[i]
            local state = item_data["state"]
            if state == 1 then
                bRed = true
                break
            end
        end
    end
    return bRed
end

--页签排序
function ActAchievementLayer:sortActAchiTabKey( data )
    -- body
    local t_data = data
    local keys = table.keys(t_data)
    table.sort(keys, function(a, b)
            if type(a) == "number" and type(b) == "number" then
                return a < b
            else
                return tostring(a) < tostring(b)
            end
    end)    
    self.tab_btn_data = keys

    return keys
end

--选中某页签
function ActAchievementLayer:selectButtonByIndex( btn_index )
    local btn_num = #self.tab_btn_data
    local selectIndex = btn_index or 1

    if self.bSendGet == true then
        self.bSendGet = false
    else
        if self.lastSelectIndex == selectIndex then
            return
        end
    end

    self.lastSelectIndex = selectIndex
    for i = 1,btn_num do
        local dataIndex = self.tab_btn_data[i]
        local itemData = self:getDataByIndex(dataIndex)
        local selectIcon = itemData["icon_select"] or nil
        local unSelectIcon = itemData["icon_normal"] or nil
        local item = self.tab_btn_listview:getItem(i - 1)
        if i == selectIndex then
            self.changeTable = itemData["list"]
            self:SortItem()
            if selectIcon ~= nil then
                item:getChildByName("model_img"):loadTexture("uifile/n_UIShare/Act_feishen/"..selectIcon..".png")
                --item:loadTexture("uifile/n_UIShare/Ranklist/"..selectIcon..".png")
            end
        else
            if unSelectIcon ~= nil then
                --item:loadTexture("uifile/n_UIShare/Ranklist/"..unSelectIcon..".png")
                item:getChildByName("model_img"):loadTexture("uifile/n_UIShare/Act_feishen/"..unSelectIcon..".png")
            end
        end
    end
end

function ActAchievementLayer:getDataByIndex( index )
    local idx = index..""
    local itemData = self.actAchiData[idx]
    return itemData
end

--检测数据是否是某种格式的
function ActAchievementLayer:checkData( data )
    local tdata = data
    local bMultiable = false
    if tdata and tdata["1"] and tdata["1"]["list"] then
        bMultiable = true
    end
    return bMultiable
end

function ActAchievementLayer:create(rData)
    local login = ActAchievementLayer.new()
    login.rData = rData
    login.sManager  = login.rData["sManager"]
    if rData["rcvData"]["_type"] == 1  then
        login.refreshSFunc  = login.rData["rcvData"]["refreshSFunc"]
    else
        
        login.backFunc  = login.rData["rcvData"]["sFunc"]
        login.sDelegate = login.rData["rcvData"]["sDelegate"]
    end

    login.uiLayer   = cc.Layer:create()
    login:init()
    return login
end