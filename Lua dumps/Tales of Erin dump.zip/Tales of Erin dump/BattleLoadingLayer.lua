--战斗资源加载界面
--created by kobejaw.2018.3.12.
BattleLoadingLayer = class("BattleLoadingLayer", function()
    return cc.Layer:create();
end);

local loadedNum;
local totalLoadNum;
local loadingBar;
local loadArray;
local atlasArray;
local idxForAtlas

function BattleLoadingLayer:ctor()
    loadedNum = 0;
    totalLoadNum = 0;
    idxForAtlas = 0
    loadArray = {}
    atlasArray = {}
	self.battleData = BattleDataManager:getData();

    local rootNode = cc.CSLoader:createNode("uifile/Loading.csb");
    self:addChild(rootNode);
    self.imgView = rootNode:getChildByTag(2)
    local action = cc.CSLoader:createTimeline("uifile/Loading.csb")
    rootNode:runAction(action)
    action:play("play",true);
    loadingBar = rootNode:getChildByTag(1)
    loadingBar:setPercent(0)
    --解析玩家和怪物数据
    BattleDataManager:parseJsonData()
    self:showTips();
    self:showAnimation();
    self:setLoadArray();
    self:loadRes()--如果有卡顿，则改成下一帧加载。
end

function BattleLoadingLayer:showAnimation()
    local skeletonNode = sp.SkeletonAnimation:create("ui/loading/ky.json", "ui/loading/ky.atlas", 0.5)
    skeletonNode:setMix("loading", "rengshitou", 0.2);
    skeletonNode:setMix("rengshitou", "loading", 0.2);
    skeletonNode:setAnimation(0, "loading", true);
    skeletonNode:setPosition(cc.p(1150,30));
    self:addChild(skeletonNode); 
end

function BattleLoadingLayer:showTips()
	local tipId = tonumber(self.battleData.tips_id)
	
	local tipsArray = tips[tipId];
	local id = math.random(1, #tipsArray);
    if id == 2 then
        id = 27
    end
	local picFullPath = string.format("n_UIShare/newGuide/picture_guide/xsjx_ui_%03d.png",id)

    self.imgView:loadTexture(picFullPath);

    if id == 0 then
        self.imgView:setPosition(cc.p(640,360));
        self.imgView:setUnifySizeEnabled(true); 
        self.skeletonNode:setScale(0.6);
    end
end

--资源加载回调
function BattleLoadingLayer:loadCallback()
    loadedNum = loadedNum + 1;
    loadingBar:setPercent( (loadedNum+1) * 100 / totalLoadNum);

    if loadedNum == #loadArray then
        --创建spine缓存，完毕后进入战斗
        self:createSpineData()
    end
end

--创建spine缓存数据
function BattleLoadingLayer:createSpineData()
    --异步加载完spine的png资源后，每帧创建一个spine缓存，纯粹为了视觉效果保证loading圆滑。
    local scheduler = cc.Director:getInstance():getScheduler();
    local currentScheduler = nil;
    
    local function loadingCallback()
        idxForAtlas = idxForAtlas + 1
        loadedNum = loadedNum + 1
        loadingBar:setPercent( (loadedNum+1) * 100 / totalLoadNum);

        local jsonFilePath = string.gsub(atlasArray[idxForAtlas], ".atlas", ".json")
        cc.Texture2D:setDefaultAlphaPixelFormat(_G.kCCTexture2DPixelFormat_RGBA4444)
        local spine = sp.SkeletonAnimation:create(jsonFilePath, atlasArray[idxForAtlas], 1.0)
        cc.Texture2D:setDefaultAlphaPixelFormat(_G.kCCTexture2DPixelFormat_RGBA8888)
        BattleCacheManager:addToCache(atlasArray[idxForAtlas],spine,2)

        if idxForAtlas == #atlasArray then
            scheduler:unscheduleScriptEntry(currentScheduler)
            --进入战斗场景
            print("资源加载完成，进入战斗场景")
            G_BattleScene:onLoadFinished()
        end
    end
    currentScheduler = scheduler:scheduleScriptFunc(loadingCallback, 0, false)
end

--同步加载ExportJson资源，异步加载图片资源和spine资源
function BattleLoadingLayer:loadRes()
    local asyncLoadSpineCallback = {}

    for i = 1, #loadArray do
        if string.find(loadArray[i], ".ExportJson") then
            BattleCacheManager:addToCache(loadArray[i],"",3)
            ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(loadArray[i])
            BattleLoadingLayer:loadCallback();
        elseif string.find(loadArray[i], ".PNG") or string.find(loadArray[i], ".png") or string.find(loadArray[i], ".jpg") then
            BattleCacheManager:addToCache(loadArray[i],"",1)
            cc.Director:getInstance():getTextureCache():addImageAsync(loadArray[i], BattleLoadingLayer.loadCallback)
        elseif string.find(loadArray[i], ".atlas") then
            local name = loadArray[i];
            asyncLoadSpineCallback[i] = function()
                BattleLoadingLayer:loadCallback()
            end
            local pngPath = string.gsub(name, ".atlas", ".png")
            cc.Director:getInstance():getTextureCache():addImageAsync(pngPath, asyncLoadSpineCallback[i])
        elseif string.find(loadArray[i], ".mp3") then
            BattlePreloadMusic(loadArray[i])
            BattleLoadingLayer:loadCallback();
        end
    end
end

function BattleLoadingLayer:addToLoadArray(path)
    if path ~= nil and path ~= "" then
        table.insert(loadArray,path)
        if string.find(path, ".atlas") then
            table.insert(atlasArray,path)
        end
    end
end

--注：每个.atlas文件对应2个num。加载图片一次，创建spinedata一次。
function BattleLoadingLayer:getTotalLoadNum()
    local total = 0

    for k,v in pairs(loadArray) do
        if string.find(v, ".atlas") then
            total = total + 2
        else
            total = total + 1
        end
    end
    return total
end

--战斗需要预加载的资源列表
function BattleLoadingLayer:setLoadArray()
    --注：尽量把png和jpg资源放最前面，atlas放中间，ExportJson资源放最后面。

    --背景资源
    local sceneid = tonumber(self.battleData.scene_id)
    self:addToLoadArray(map[sceneid].map_1)
    self:addToLoadArray(map[sceneid].map_2)
    self:addToLoadArray(map[sceneid].map_3)
    self:addToLoadArray(map[sceneid].map_4)

    local effectArray = {}--用于防止重复加载

    --神格技能Icon和特效资源
    if BattleDataManager.hasPrincess then
        --icon
        self:addToLoadArray(skill[BattleDataManager.ps_skillID].skill_icon)
        
        --特效
        local res_fly = skill[BattleDataManager.ps_skillID].skill_play_hit[1].res_fly
        local res_scene = skill[BattleDataManager.ps_skillID].skill_play_hit[1].res_scene

        if res_fly ~= "" and effectArray[res_fly] == nil then
            effectArray[res_fly] = 1
            self:addToLoadArray(res_fly)
        end

        if res_scene ~= "" and effectArray[res_scene] == nil then
            effectArray[res_scene] = 1
            self:addToLoadArray(res_scene)
        end

        --击中特效
        local hitData = skill[BattleDataManager.ps_skillID].skill_attack_hit
        if hitData then
            for k,v in pairs(hitData) do
                local res_hit = v.res_hit
                if res_hit ~= "" and effectArray[res_hit] == nil then
                    effectArray[res_hit] = 1
                    self:addToLoadArray(res_hit)
                end
            end
        end
    end

    --角色资源
    --注：服务器传过来的id是11111*NNN的形式，要先把1111取出来。
    local heroIdArray = BattleDataManager.heroIdList
    for i = 1,#heroIdArray do
        local heroId = heroIdArray[i]
        
        if heroId ~=nil and heroId ~= "" then
            --角色spine资源
            self:addToLoadArray(hero[heroId].hero_bat)
            --角色cutin资源
            local cutin = hero[heroId].hero_cutin
            if cutin ~= "" and effectArray[cutin] == nil then
                effectArray[cutin] = 1
                self:addToLoadArray(cutin)                
            end
        end

        --普通攻击远程子弹资源
        local atkId = hero[heroId].hero_atk1
        if atkId ~= 0 then
            local bulletResPath = Attack[atkId].res_fly--普通攻击远程子弹特效
            local hitEffectPath = Attack[atkId].res_hit--普通攻击击中特效
            if bulletResPath ~= "" and effectArray[bulletResPath] == nil then
                effectArray[bulletResPath] = 1
                self:addToLoadArray(bulletResPath)
            end
            if hitEffectPath ~= "" and effectArray[hitEffectPath] == nil then
                effectArray[hitEffectPath] = 1
                self:addToLoadArray(hitEffectPath)
            end
        end

        --主动技能资源
        local heroData = BattleDataManager:getRoleDataById(heroId)
        for k,v in pairs(heroData.activeSkillArray) do
            local res_fly = skill[v].skill_play_hit[1].res_fly
            local res_scene = skill[v].skill_play_hit[1].res_scene
            local res_cut = skill[v].res_cut

            if res_fly ~= "" and effectArray[res_fly] == nil then
                effectArray[res_fly] = 1
                self:addToLoadArray(res_fly)
            end

            if res_scene ~= "" and effectArray[res_scene] == nil then
                effectArray[res_scene] = 1
                self:addToLoadArray(res_scene)
            end

            if res_cut ~= "" and effectArray[res_cut] == nil then
                effectArray[res_cut] = 1
                self:addToLoadArray(res_cut)               
            end

            --击中特效
            local hitData = skill[v].skill_attack_hit
            if hitData then
                for k1,v1 in pairs(hitData) do
                    local res_hit = v1.res_hit
                    if res_hit ~= "" and effectArray[res_hit] == nil then
                        effectArray[res_hit] = 1
                        self:addToLoadArray(res_hit)
                    end
                end
            end

            --主动技能中buff和debuff的spine特效
            local comSpineList = SkillUtil:getComSpinePathList_activeSkill(v)
            for k1,v1 in pairs(comSpineList) do
                if effectArray[v1] == nil then
                    effectArray[v1] = 1
                    self:addToLoadArray(v1) 
                end
            end
        end

        --被动技能中buff和debuff的spine特效
        for k,v in pairs(heroData.passiveSkillArray) do
            local comSpineList = SkillUtil:getComSpinePathList_passiveSkill(v)
            for k1,v1 in pairs(comSpineList) do
                if effectArray[v1] == nil then
                    effectArray[v1] = 1
                    self:addToLoadArray(v1) 
                end
            end            
        end
    end

    --怪物资源
    local monsterDataArray = BattleDataManager.monsterDataArray
    for i = 1,#monsterDataArray do
        local monsterData = monsterDataArray[i]
        --怪物spine资源
        local monsterId = tonumber(monsterData.monsterId)

        local monster_bat = monster[monsterId].monster_bat
        if monster_bat ~= "" and effectArray[monster_bat] == nil then
            self:addToLoadArray(monster_bat)
        end

        --普通攻击远程子弹资源
        local atkId = monster[monsterId].monster_atk1
        if atkId ~= 0 then
            local bulletResPath = Attack[atkId].res_fly--普通攻击远程子弹特效
            local hitEffectPath = Attack[atkId].res_hit--普通攻击击中特效
            if bulletResPath ~= "" and effectArray[bulletResPath] == nil then
                effectArray[bulletResPath] = 1
                self:addToLoadArray(bulletResPath)
            end
            if hitEffectPath ~= "" and effectArray[hitEffectPath] == nil then
                effectArray[hitEffectPath] = 1
                self:addToLoadArray(hitEffectPath)
            end
        end

        --主动技能资源
        
        local isNeedLoadCutInResByGID = true
        for k,monsterSkillId in pairs(monsterData.activeSkillArray) do
            for k1,v in pairs(monster_sk[monsterSkillId].sk_skill_id) do --boss的一般是个技能序列，包含多个技能
                local res_fly = skill[v].skill_play_hit[1].res_fly
                local res_scene = skill[v].skill_play_hit[1].res_scene
                local res_cut = skill[v].res_cut

                if res_fly ~= "" and effectArray[res_fly] == nil then
                    effectArray[res_fly] = 1
                    self:addToLoadArray(res_fly)
                end

                if res_scene ~= "" and effectArray[res_scene] == nil then
                    effectArray[res_scene] = 1
                    self:addToLoadArray(res_scene)
                end

                if res_cut ~= "" and effectArray[res_cut] == nil then
                    effectArray[res_cut] = 1
                    self:addToLoadArray(res_cut)
                end

                --击中特效
                local hitData = skill[v].skill_attack_hit
                if hitData then
                    for k2,v2 in pairs(hitData) do
                        local res_hit = v2.res_hit
                        if res_hit ~= "" and effectArray[res_hit] == nil then
                            effectArray[res_hit] = 1
                            self:addToLoadArray(res_hit)
                        end
                    end
                end

                --主动技能中buff和debuff的spine特效
                local comSpineList = SkillUtil:getComSpinePathList_activeSkill(v)
                for k2,v2 in pairs(comSpineList) do
                    if effectArray[v2] == nil then
                        effectArray[v2] = 1
                        self:addToLoadArray(v2) 
                    end
                end                
            end
        end

        --被动技能中buff和debuff的spine特效
        for k,v in pairs(monsterData.passiveSkillArray) do
            local comSpineList = SkillUtil:getComSpinePathList_passiveSkill(v)
            for k1,v1 in pairs(comSpineList) do
                if effectArray[v1] == nil then
                    effectArray[v1] = 1
                    self:addToLoadArray(v1) 
                end
            end            
        end        
    end

    --boss特效
    if BattleDataManager.isBoss then
        self:addToLoadArray(BattleGlobals.BOSS_MODE_OD_SPINE)
        self:addToLoadArray(BattleGlobals.DeadEffect)
        --self:addToLoadArray(BattleGlobals.BOSS_MODE_BK1_SPINE)
        --self:addToLoadArray(BattleGlobals.BOSS_MODE_BK2_SPINE)    
        self:addToLoadArray(BattleGlobals.BOSS_SHOW)
    end

    --通用
    --self:addToLoadArray(BattleGlobals.EnemyDyingEffects)
    self:addToLoadArray(BattleGlobals.DEFEATE_EFFECT)
    self:addToLoadArray(BattleGlobals.VICTORY_EFFECT)

    --cutin特效
    self:addToLoadArray(BattleGlobals.CutInEffect_water)
    self:addToLoadArray(BattleGlobals.CutInEffect_fire)
    self:addToLoadArray(BattleGlobals.CutInEffect_wind)
    self:addToLoadArray(BattleGlobals.CutInEffect_light)
    self:addToLoadArray(BattleGlobals.CutInEffect_dard)

    --背景音乐
    local bgm1 = map[sceneid].voice_1
    local bgm2 = map[sceneid].voice_2
    
    if bgm1 ~= "" and effectArray[bgm1] == nil then
        BattleDataManager.bgm1 = bgm1
        effectArray[bgm1] = 1
        self:addToLoadArray(bgm1)
    end
    if bgm2 ~= "" and effectArray[bgm2] == nil then
        BattleDataManager.bgm2 = bgm2
        effectArray[bgm2] = 1
        self:addToLoadArray(bgm2)
    end

    --[[音效暂时不做预加载
    --cutin音效
    if effectArray[BattleGlobals.Sound_CutIn] == nil then
        effectArray[BattleGlobals.Sound_CutIn] = 1
        self:addToLoadArray(BattleGlobals.Sound_CutIn)
    end
    ]]

    totalLoadNum = self:getTotalLoadNum()
end

