--require "XUIView"

SoulEquipSublView = class("SoulEquipSublView",XUIView)
SoulEquipSublView.CS_FILE_NAME = "SoulEquipSublView.csb"
SoulEquipSublView.CS_BIND_TABLE = 
{
    panelEffect = "/i:426",
    effMagic = "/i:426/s:effMagic",
    effIcon = "/i:426/s:effIcon",
    effIcon2 = "/i:426/s:effIcon2",
    effNum = "/i:426/s:effNum",

    panelList = "/i:160/i:80",
    panelIcon = "/i:160/i:145",
    
    sortTitle = "/i:160/i:266",

    btnStartAwaken = "/i:160/i:477",

    panelSkill = "/i:160/i:397",

    lbLvNow = "/i:160/i:397/i:401",
    lbLvNew = "/i:160/i:397/i:402",

    SkillDescribeNode = "/i:160/i:397/i:777",

    --
    panelProp = "/i:160/i:640",
    lbCurAtk = "/i:160/i:640/i:642",
    lbAddAtk = "/i:160/i:640/i:643",
    lbCurHP = "/i:160/i:640/i:644",
    lbAddHP = "/i:160/i:640/i:645",

    spSubMax = "/i:160/i:175",
}

-- hero_soul[13] = {
--     name = "阿尔芬魂灵装",
--     desc = "阿尔芬魂灵装",
--     unlock_type = 2,
--     unlock_msg = "通过第五章关卡【妈妈3（普通）】解锁",
--     soul_break = {
--         total_break = 5, 
--         break_0 = {
--             icon_small = "hs_13.png",
--             icon_big = "hss_13.png",
--             Lv_max = 40,
--             add_hp = 72,
--             add_atk = 87,
--             skill_unlock = 0,
--             break_mat = { 
--                 -- ID 数量 类型                                                                                                                                            
--             },
--         }, 
--         break_1 = {
--             icon_small = "hs_13.png",
--             icon_big = "hss_13.png",
--             Lv_max = 60,
--             add_hp = 432,
--             add_atk = 522,
--             skill_unlock = 6013001,
--             break_mat = { 
--                 -- ID 数量 类型   
--                 { 1005,20,5 },   
--                 { 1021,10,5 },   
--                 { 1082,10,5 },   
--                 { 1122,10,5 },   
--                 { 1081,30,5 },   
--                 { 1105,20,5 },   
--                 { 1109,10,5 },   
--                 { 1121,10,5 },                                                                                                                            
--             },
--         }, 
--         break_2 = {
--             icon_small = "hs_13.png",
--             icon_big = "hss_13.png",
--             Lv_max = 80,
--             add_hp = 1008,
--             add_atk = 1218,
--             skill_unlock = 6013002,
--             break_mat = { 
--                 -- ID 数量 类型                   
--                 { 1006,10,5 },   
--                 { 1005,20,5 },   
--                 { 1022,7,5 },   
--                 { 1021,15,5 },   
--                 { 1114,30,5 },   
--                 { 1106,20,5 },   
--                 { 1110,20,5 },   
--                 { 1081,20,5 },   
--                 { 1121,15,5 },   
--                 { 1085,10,5 },   
--                 { 1089,10,5 },                                                                                                      
--             },
--         }, 
--         break_3 = {
--             icon_small = "hs_13.png",
--             icon_big = "hss_13.png",
--             Lv_max = 120,
--             add_hp = 1584,
--             add_atk = 1914,
--             skill_unlock = 6013003,
--             break_mat = { 
--                 -- ID 数量 类型                                         
--                 { 1006,20,5 },   
--                 { 1005,40,5 },   
--                 { 1022,10,5 },   
--                 { 1021,20,5 },   
--                 { 1123,1,5 },   
--                 { 1082,20,5 },   
--                 { 1122,20,5 },   
--                 { 1110,10,5 },   
--                 { 1090,10,5 },   
--                 { 1121,30,5 },   
--                 { 1113,30,5 },   
--                 { 1117,20,5 },   
--                 { 1201,1,5 },                                                                            
--             },
--         }, 
--         break_4 = {
--             icon_small = "hs_13.png",
--             icon_big = "hss_13.png",
--             Lv_max = 160,
--             add_hp = 2160,
--             add_atk = 2610,
--             skill_unlock = 6013004,
--             break_mat = { 
--                 -- ID 数量 类型                                                                   
--                 { 1144,30,5 },   
--                 { 1007,15,5 },   
--                 { 1006,30,5 },   
--                 { 1023,15,5 },   
--                 { 1022,30,5 },   
--                 { 1041,20,5 },   
--                 { 1042,10,5 },   
--                 { 1142,4,5 },   
--                 { 1141,10,5 },   
--                 { 1083,20,5 },   
--                 { 1103,15,5 },   
--                 { 1123,10,5 },   
--                 { 1082,20,5 },   
--                 { 1110,20,5 },   
--                 { 1114,20,5 },   
--                 { 1105,30,5 },   
--                 { 1097,30,5 },   
--                 { 1201,1,5 },                                        
--             },
--         }, 
--         break_5 = {
--             icon_small = "hs_13.png",
--             icon_big = "hss_13.png",
--             Lv_max = 200,
--             add_hp = 2880,
--             add_atk = 3480,
--             skill_unlock = 6013005,
--             break_mat = { 
--                 -- ID 数量 类型                                                                                                       
--                 { 1144,50,5 },   
--                 { 1007,20,5 },   
--                 { 1006,40,5 },   
--                 { 1023,20,5 },   
--                 { 1022,40,5 },   
--                 { 1043,10,5 },   
--                 { 1042,20,5 },   
--                 { 1128,1,5 },   
--                 { 1124,1,5 },   
--                 { 1141,10,5 },   
--                 { 1123,20,5 },   
--                 { 1087,20,5 },   
--                 { 1111,30,5 },   
--                 { 1106,30,5 },   
--                 { 1114,20,5 },   
--                 { 1122,20,5 },   
--                 { 1117,40,5 },   
--                 { 1082,40,5 },   
--                 { 1201,1,5 },  
--             },
--         }, 
--     }
-- }

SoulEquipSublView.hero_soul_info = {}
SoulEquipSublView.soul_brk_mat = {}

function SoulEquipSublView.createWithBackBtn()
    local v = SoulEquipSublView.new():init()
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function SoulEquipSublView:init(nHeroId)
    SoulEquipSublView.super.init(self)

    self.nHeroId = nHeroId
    self.curSoulEquipId = nHeroId --暂定魂灵装与角色ID一致（修改需要增加从角色ID转换为专属灵装ID的方法转换）
    if nHeroId then
        self.curSoulEquipId = tonumber(getNumID(nHeroId))
    end
    if hero_soul[self.curSoulEquipId] then
        self.hero_soul_info = hero_soul[self.curSoulEquipId]
    end

    self.panelEffect:setVisible(false)
    self.spSubMax:setVisible(false)
    self.panelProp:setVisible(true)
    self.panelSkill:setVisible(true)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,205)
    self.gridview.itemCreateEvent = function()
        local temp = MatItemNode.new():init()
        temp.ClickEvent = function(item)            
            self:matClicked(item)
        end

        temp.onResetData = function(item)
            local data = item:getData()
            if data then
                item:SetMatId(data[1])
                item:SetMatNumNeed(tonumber(data[2]))
                local nMatBagNum = 0
                if self.Mat_info then
                    if self.Mat_info["mat_"..data[1]] then
                        nMatBagNum = self.Mat_info["mat_"..data[1]]
                    end
                end
                item:SetMatNumCur(nMatBagNum)
            end
        end

        return temp
    end

    self.btnStartAwaken:addClickEventListener(function()
        self:onSoulEquipSubl()
    end)

    self.iconView = SEIconView.new():init(self.panelIcon,self.curSoulEquipId,0)

    self.skillDescNode = SoulEquipSkillItemView.new():init(self.SkillDescribeNode)


    self.bHasFinishInit = 1


    --self:refresh()

    return self
end

function SoulEquipSublView:FillSoulEquipData(rcvData)
    if rcvData then
        self.Se_info = table.deepcopy(rcvData)
        if self.Se_info ~= nil then
            if self.Se_info["break_count"] >= hero_soul[self.curSoulEquipId]["soul_break"]["total_break"] then
                --满升华
                self:refreshMax()
            end
        end

    end
end

function SoulEquipSublView:FillMatData(rcvData)
    if rcvData then
        self.Mat_info = table.deepcopy(rcvData)
        self:refresh()
    end
end

-- # ■ [装备详情]* hero_soul_info
-- #  "hero_id": "1*1299656990",  #对应的角色ID
-- #返回:
-- data = {
--  "state_code": 1,
--  "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":1,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
-- }

function SoulEquipSublView:refreshMax()
    if not self.Se_info then
        print("SoulEquipSthView:refreshPropNum not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("无开放魂灵装解锁表数据")
        return
    end

    self.lbAddAtk:setString("")
    self.lbAddHP:setString("")

    local data = self.Se_info

    local nAtk = data["atk"] + data["add_atk"]
    local nHp = data["hp"] + data["add_hp"]
    self.lbCurAtk:setString(nAtk)
    self.lbCurHP:setString(nHp)

    self.btnStartAwaken:setTouchEnabled(false)
    self.btnStartAwaken:setBright(false)

    if self.SkillDescribeNode then
        self.SkillDescribeNode:setVisible(false)
    end

    --升华阶段
    local nCurSublStageCount = tonumber(data["break_count"])

    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    if self.iconView then
        self.iconView:RefreshSeIcon(self.curSoulEquipId,nCurSublStageCount)
    end

    self.lbLvNow:setString("")
    self.lbLvNew:setString("")
    --GameManagerInst:alert("已满升华")

    self.spSubMax:setVisible(true)
    self.panelProp:setVisible(false)
    self.panelSkill:setVisible(false)

    self.currentDataSource = {}
    self.gridview:setDataSource(self.currentDataSource)
    self.gridview:refresh()
end

function SoulEquipSublView:refreshStates()
    if not self.Se_info then
        return
    end
    if not self.hero_soul_info then
        return
    end
    -- --基本数据属性

    --升华阶段
    local nCurSublStageCount = tonumber(self.Se_info["break_count"])

    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    if self.iconView then
        self.iconView:RefreshSeIcon(self.curSoulEquipId,nCurSublStageCount)
    end

    local nNextSublStageCount = nCurSublStageCount + 1
    local nTotalSublStageCount = self.hero_soul_info["soul_break"]["total_break"]
    --
    local nCurLvMax = self.hero_soul_info["soul_break"]["break_"..nCurSublStageCount]["Lv_max"]
    local nNextLvMax = 0
    if nNextSublStageCount > nTotalSublStageCount then
        --已满升华
        --TODO:满升华 UI展示需添加（未设计）
    else
        --未满升华
        nNextLvMax = self.hero_soul_info["soul_break"]["break_"..nNextSublStageCount]["Lv_max"]
        --魂灵装等级上限
        self.lbLvNow:setString(nCurLvMax)
        self.lbLvNew:setString(nNextLvMax)

        --下一级升华带来技能描述
        if self.SkillDescribeNode then
            if self.bHasFinishInit == 1 then
                local nNextBreakSkillId = self.hero_soul_info["soul_break"]["break_"..nNextSublStageCount]["skill_unlock"]
                self.skillDescNode:SetSkillId(nNextBreakSkillId)
                self.skillDescNode:SetIsHavedSkill(true)
                self.skillDescNode:SetSkillIndex(nNextSublStageCount)
            end
            
        end
        

        local curAtk = self.Se_info["atk"]
        local curHP = self.Se_info["hp"]

        local curLv = self.Se_info["Lv"]

        local addAtk = self.hero_soul_info["soul_break"]["break_"..nNextSublStageCount]["add_atk"] - self.hero_soul_info["soul_break"]["break_"..nCurSublStageCount]["add_atk"]
        local addHP = self.hero_soul_info["soul_break"]["break_"..nNextSublStageCount]["add_hp"] - self.hero_soul_info["soul_break"]["break_"..nCurSublStageCount]["add_hp"]

        local nAtk = self.Se_info["atk"] + self.Se_info["add_atk"]
        local nHp = self.Se_info["hp"] + self.Se_info["add_hp"]
        self.lbCurAtk:setString(nAtk)
        self.lbCurHP:setString(nHp)

        --self.lbCurAtk:setString(curAtk)
        if addAtk > 0 then
            self.lbAddAtk:setString("+"..addAtk)
        else
            self.lbAddAtk:setString("")
        end

        --self.lbCurHP:setString(curHP)
        if addHP > 0 then
            self.lbAddHP:setString("+"..addHP)
        else
            self.lbAddHP:setString("")
        end
    end
    
end

function SoulEquipSublView:matClicked(item)
    local data = item:getData()
    MsgManager:showSimpItemInfoAndDropInfo(data[3],data[1],true,self.onMatChanged,self)
end

function SoulEquipSublView:onMatChanged()
    if self.matChangedEvent then
        self.matChangedEvent(self)
    end
end

function SoulEquipSublView:playEffect()
    self.panelEffect:stopAllActions()
    self.panelEffect:setVisible(true)

    local skeletonNode = sp.SkeletonAnimation:create("effects/hun_ling_zhuang/hun_ling_zhuang.json", "effects/hun_ling_zhuang/hun_ling_zhuang.atlas", 1.0)
    skeletonNode:setAnimation(1, "effect", false)
    local psize = self.effIcon:getSize()
    skeletonNode:setPosition(cc.p(psize.width/2,psize.height/2))
    skeletonNode:setTag(123)   
    self.effIcon:addChild(skeletonNode,0,123)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
    
    -- local effs = {
    --     {self.effIcon,"EffAwkFrame.csb"},
    --     {self.effIcon2,"EffAwkFade.csb"},
    --     {self.effMagic,"EffAwkMagic.csb"},
    --     {self.effNum,"EffAwkNum.csb"}
    -- }

    -- for i = 1,#effs do
    --     local node_1 = cc.CSLoader:createNode(effs[i][2])
    --     local timeline_1 =cc.CSLoader:createTimeline(effs[i][2])
    --     node_1:setTag(123)
    --     local psize = effs[i][1]:getSize()
    --     node_1:setPosition(cc.p(psize.width/2,0))
    --     effs[i][1]:addChild(node_1)

    --     node_1:runAction(timeline_1)
    --     timeline_1:play("animation0",false) 
    --     timeline_1:setLastFrameCallFunc(function ()
    --         node_1:stopAllActions()
    --         node_1:removeFromParent()
    --     end)
    -- end
        
--    cc.SimpleAudioEngine:getInstance():playEffect("music/ui/tupo.mp3", false)          
     AudioManager:shareDataManager():playMusic("music/ui/tupo.mp3",0, false)
    local delay = cc.DelayTime:create(1.3)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:stopEffect()
    end))
    self.panelEffect:runAction(sequence)              
end

function SoulEquipSublView:stopEffect()
    self.panelEffect:stopAllActions()

    -- local effs = {
    --     self.effIcon,
    --     self.effIcon2,
    --     self.effMagic,
    --     self.effNum
    -- }

    -- for i = 1,#effs do
    --     local e = effs[i]:getChildByTag(123)
    --     if e then e:stopAllActions() end
    --     effs[i]:removeAllChildren()
    -- end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)
    self:refresh()
end

-- # -----------------------------------------------------
-- # ■ [魂灵装升华] 
-- # 接口名: hero_soul_brk
-- # 参数1 : target_id: "1*1299656994",  # 要升华的魂灵装ID

-- #返回:
-- data = {
--     "state_code":  1,       #反馈结果 1-成功,
--     "message":["第一条信息","第二条信息"], # 数组形式的信息,用于前端弹出消息提示框
--     "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":3,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
--     # "mat": {"mat_1": 66, },# 只返回变化的素材 当前的个数  ----存疑
    
-- }
--------------

-- {
--     "hero_soul":{
--         "375*1512720307":{
--             "Lv":28,
--             "atk":664,
--             "hp":530,
--             "exp":980,
--             "exp_max":1120,
--             "add_atk":474,
--             "break_count":1,
--             "state":3,
--             "skills":[
--                 6375001
--             ],
--             "Lv_max":60,
--             "add_hp":379
--         }
--     },
--     "soul_brk_mat":{
--         "5":{
--             "mat_1113":6970,
--             "mat_1125":6960,
--             "mat_1126":6980,
--             "mat_1102":6990,
--             "mat_1093":6980,
--             "mat_1029":6990,
--             "mat_1001":6970,
--             "mat_1085":13980,
--             "mat_1144":6990
--         }
--     },
--     "achi":{

--     },
--     "message":{

--     },
--     "state_code":1
-- }
function SoulEquipSublView:onSoulEquipSubl()
    if self.curSoulEquipId == nil then
        return
    end

    local tempTable = {
        ["rpc"] = "hero_soul_brk",
        ["target_id"] = self.nHeroId,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        --:更新突破成功带来的素材数据变化
        -- if data["soul_brk_mat"] ~= nil then
        --     self.Mat_info = {}
        --     self.Mat_info = table.deepcopy(data["soul_brk_mat"])
        -- end

        --GameManagerInst:saveToFile("hero_soul_brk.json",data)

        self:playEffect()

        if self.infoChangedEvent then
            self.infoChangedEvent(self)
        end
        
    end,
    function(state_code,msgText,hehe)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function SoulEquipSublView:getDataSource()
    local ds = {}
    if self.hero_soul_info and self.Se_info then
        --升华阶段
        local nCurSublStageCount = tonumber(self.Se_info["break_count"])
        local nNextSublStageCount = nCurSublStageCount + 1
        local nTotalSublStageCount = self.hero_soul_info["soul_break"]["total_break"]
        --
        if nNextSublStageCount <= nTotalSublStageCount then
            --未满升华
            ds = table.deepcopy(self.hero_soul_info["soul_break"]["break_"..nNextSublStageCount]["break_mat"])
        end
    end
    return ds
end

function SoulEquipSublView:refresh()
    self.currentDataSource = self:getDataSource()
    self.gridview:setDataSource(self.currentDataSource)
    self:refreshStates()
end