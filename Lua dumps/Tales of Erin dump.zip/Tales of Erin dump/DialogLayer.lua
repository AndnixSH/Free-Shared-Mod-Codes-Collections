require "BasicLayer"

require "story/bgm.lua"

DialogLayer = class("DialogLayer",BasicLayer)
DialogLayer.__index = DialogLayer
DialogLayer.lClass = 3

DialogLayer.Item = nil 
DialogLayer.Conversation = nil 


DialogLayer.nowDiaId = nil 
DialogLayer.lastDiaId = nil 

DialogLayer.nameText = nil   --名字
DialogLayer.richText = nil   --富文本

DialogLayer.pos_left     = cc.p(320,360)
DialogLayer.pos_right    = cc.p(960,360)
DialogLayer.pos_center   = cc.p(640,360)
DialogLayer.pos_LeftSide = cc.p(0,360)
DialogLayer.pos_rightSide= cc.p(1280,360)
DialogLayer.pos_bgE= cc.p(0,0)


DialogLayer.img_a = nil    -- 左
DialogLayer.img_b = nil    -- 右
DialogLayer.img_c = nil    -- 中
DialogLayer.img_aSide  = nil   -- 左中
DialogLayer.img_bSide  = nil   -- 右中
DialogLayer.isPlayNext = true -- 是否应该播放下一段对话 
DialogLayer.img_old_bg = nil

DialogLayer.readyShadowIn = 0
 
DialogLayer.img_bg    = nil 

DialogLayer.IsIBright = false

DialogLayer.CurSelectId = 0

DialogLayer.CurBrightIm = nil
DialogLayer.IsTouchSe   = false

DialogLayer.low_speed    = 0.3
DialogLayer.fast_speed   = 0.13
DialogLayer.fast_speed_1 = 0.07


------------人物上的五个位置---------------
DialogLayer.p_UL  = nil  --左上
DialogLayer.p_ULS = nil  -- 左半边上
DialogLayer.p_UC  = nil  -- 上中
DialogLayer.p_UR  = nil  -- 上右
DialogLayer.p_URS = nil  -- 上右半边


-----------人物下的五个位置------------------
DialogLayer.p_DL  = nil  
DialogLayer.p_DLS = nil  
DialogLayer.p_DC  = nil  
DialogLayer.p_DR  = nil  
DialogLayer.p_DRS = nil  

-----------三个遮罩层-------------
DialogLayer.cover_BG = nil
DialogLayer.cover_Actor = nil
DialogLayer.cover_All = nil
DialogLayer.cover_BG_finalOpacity = 0
DialogLayer.cover_Actor_finalOpacity = 0
DialogLayer.cover_All_finalOpacity = 0

DialogLayer.effect_handle = nil
DialogLayer.voice_handle = nil

local scheduler = cc.Director:getInstance():getScheduler()
local schedulerEntry = nil 


local isUsingScript =  false  -- 是否正在执行脚本文件中的方法


function DialogLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, DialogLayer)
    return target
end



function DialogLayer:init()

    local node =cc.CSLoader:createNode("DialogLayer.csb")
    self.uiLayer:addChild(node,0,1) 
    KeyboardManager._isShowStory = true   
    local layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0,0))
    layout:setPosition(0,0)
    layout:setContentSize(1280,720)
    layout:setBackGroundColor(cc.c3b(0,0,0))
    layout:setBackGroundColorType(LAYOUT_COLOR_SOLID)

    node:addChild(layout,-100,100)
    self.blackBackground = layout

    local touchEventTable = {
     [221] = self.returnBack,
     --[122] = ,
    }

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            touchEventTable[sender:getTag()](self)
        end
    end 

    
    local function panelCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then 
           self:skiptDialog(self.nowDiaId)
       end 
    end    

    local panel = node:getChildByTag(2)
    panel:addTouchEventListener(panelCallBack)
    self.dialogPanel = panel
  
    local panel_8 = node:getChildByTag(8)
   
    local button = ccui.Helper:seekWidgetByTag(panel_8,221)
    button:addTouchEventListener(touchCallBack)
    --跳过按钮 skip隐藏 1为隐藏，0为显示。默认为 0
    self.rData["rcvData"]["hiddenSkipBtn"]  = self.rData["rcvData"]["hiddenSkipBtn"]  or 0
    if self.rData["rcvData"]["hiddenSkipBtn"] == 1 then 
        button:setVisible(false)
        button:setTouchEnabled(false)
    end   


    self.cover_BG = node:getChildByTag(163)
    self.cover_Actor = node:getChildByTag(164)
    self.cover_All = node:getChildByTag(165)

    local function CallBackDHXZ( sender,eventType )
      -- body
      print("进入 选择对话界面回调函数")
        if eventType == ccui.TouchEventType.ended then 
            print("对话选择按钮")
            self:DialogSelect(sender)
           --self:skiptDialog(self.nowDiaId)
       end 
    end 
    local panel_1 = node:getChildByTag(3)
    local BtnDialog1 = ccui.Helper:seekWidgetByTag(panel_1,222)
    local BtnDialog2 = ccui.Helper:seekWidgetByTag(panel_1,223)

    BtnDialog1:addTouchEventListener(CallBackDHXZ)
    BtnDialog2:addTouchEventListener(CallBackDHXZ)

    self.readyShadowIn = 0
    self.effect_handle = nil

    --if self.rData["rcvData"]~=nil then 
      
        --对话需要三部分信息  角色actor 道具item 位置location  
    --    self:deConv(self.rData["rcvData"]["Conversations"])
    --    self.deItem(self.rData["rcvData"]["Item"])
    --    self.deLoc(self.rData["rcvData"]["Locations"])
            
    --end 
    
    if self.rData["rcvData"]~=nil then 
       if self.rData["rcvData"]["filename"]~= nil then 
          --  print("现在读取剧情的名字是 == "..self.rData["rcvData"]["filename"])
          local jsonData = cc.FileUtils:getInstance():getStringFromFile(self.rData["rcvData"]["filename"])

          --  print("jsonData == "..jsonData)
          self:deConv(jsonData)
          --自动播放剧情对话，默认为是 。1为是，0 为不自动
          self.rData["rcvData"]["autoPlay"] = self.rData["rcvData"]["autoPlay"] or 1
          if  self.rData["rcvData"]["autoPlay"] == 1 then 
              self:begDialog()
          else 
          end 
          
          local tempfilename = self.rData["rcvData"]["filename"]
          if not (string.find(tempfilename,"story/cjs0") == 1 or
             string.find(tempfilename,"story/hero") == 1 ) then
           -- cc.SimpleAudioEngine:getInstance():stopMusic()
           AudioManager:shareDataManager():stopBGMusic()
          end

         
        end 
    else 

    end 


   
    

end 
-- 对话选择

function DialogLayer:RemoveBlackBackground()
  if self.blackBackground then
    self.blackBackground:removeFromParent()
    self.blackBackground = nil
  end
end

function DialogLayer:DialogSelect( sender )
  -- body
  local node = self.uiLayer:getChildByTag(1)
  local panel = node:getChildByTag(3)
  local BtnDialog1 = ccui.Helper:seekWidgetByTag(panel,222)
  local BtnDialog2 = ccui.Helper:seekWidgetByTag(panel,223)
  BtnDialog1:setVisible(false)
  BtnDialog2:setVisible(false)
  local panel_2 = node:getChildByTag(2)
  panel_2:setEnabled(true)

  if sender:getName() == "Button_Dialog_1" then

        self.CurSelectId = 1
        self.isPlayNext = true
        self:FaceReset()
        self:AllActorReset()
        self:deleteAllActor()
        self.nowDiaId = self.Conversation[self.nowDiaId]["OutgoingLinks"][1]
        self:playDialog(self.nowDiaId)

  elseif sender:getName() == "Button_Dialog_2" then
        -- print("是否点击了第二个选择")
        -- print("没选择之前的Id == "..self.nowDiaId)
        -- print("选择的Id == "..self.Conversation[self.nowDiaId]["OutgoingLinks"][2])
        
        self.CurSelectId = 2
        self.isPlayNext = true
        self:FaceReset()
        self:AllActorReset()
        self:deleteAllActor()
        self.nowDiaId = self.Conversation[self.nowDiaId]["OutgoingLinks"][2]
        self:playDialog(self.nowDiaId)
  end
end


--返回
function DialogLayer:returnBack()
   AudioManager:shareDataManager():resumeAll()

    if self.rData["rcvData"]~=nil then 
       if self.rData["rcvData"]["filename"]~= nil then           
          local tempfilename = self.rData["rcvData"]["filename"]
          if not (string.find(tempfilename,"story/cjs0") == 1 or
             string.find(tempfilename,"story/hero") == 1 ) then
            --cc.SimpleAudioEngine:getInstance():stopMusic()
            AudioManager:shareDataManager():stopBGMusic()
          end
        end 
    end 

    self.uiLayer:removeFromParent()
    KeyboardManager._isShowStory = false 
    self.uiLayer = nil 
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()

   print("点击返回")

    if self.effect_handle ~= nil then
        --cc.SimpleAudioEngine:getInstance():stopEffect(self.effect_handle)
        AudioManager:shareDataManager():stop(self.effect_handle)
        self.effect_handle = nil
    end

    if self.voice_handle then
        AudioManager:shareDataManager():stop(self.voice_handle)
        self.voice_handle = nil
    end
 
   if schedulerEntry~= nil then 
     scheduler:unscheduleScriptEntry(schedulerEntry)
     schedulerEntry = nil
   end 

   self.Item = nil 
   self.Conversation = nil 
   self.Location = nil 
   self.nowDiaId = nil 
   self.lastDiaId = nil   
   local rrData = self.rData --table.deepcopy(self.rData) ----deepcopy会导致实例对象变更
  
   if rrData["rcvData"] ~= nil and rrData["rcvData"]["callFunc"]~= nil then 
        rrData["rcvData"]["callFunc"](rrData["rcvData"]["obj"])
         self.rData = {}
         self.sData = {}
   else 
      self.rData = {}
      self.sData = {}
      GameManagerInst:blackScreenOn()
      if g_channel_control.battleLua and G_STAGE_TYPE ~= 0 then
        if rrData["rcvData"] ~= nil and rrData["rcvData"]["battleData"] ~= nil then 
          local battleData = rrData["rcvData"]["battleData"]
          PushBattleScene(battleData)
        else
          print("DialogLayer rcvData->battleData is nil")
        end
      else
          cc.MyHttpHelper:shareMyHttpHelper():startGame() 
      end
      KeyboardManager:setbattleState(true)

      UITool.delayTask(0.1,function ( ... )
        dump(scene, "DialogLayer:returnBack    22222")
        local scene = cc.Director:getInstance():getRunningScene()
            if scene then
                KeyboardManager:bindingAndroidKeyboard(scene,3)
            end
        end)

   end 


end

 

--解析对话数据
function DialogLayer:deConv(data)
    
   local cjson = require "cjson"
   local t_data = cjson.decode(data)
   DataManager:rfsStory(t_data["Assets"]["Locations"],t_data["Assets"]["Actors"])
   local dialogNodes = t_data["Assets"]["Conversations"][1]["DialogNodes"]
  
   if self.Conversation== nil then 
      self.Conversation = {}
   end

   for i=1,#dialogNodes do 
       
       self.Conversation[dialogNodes[i]["ID"]] = dialogNodes[i]

       if dialogNodes[i].IsRoot == true then 
          self.nowDiaId = dialogNodes[i]["OutgoingLinks"][1]  --记录根节点
          print("记录根节点 self.nowDiaId =="..self.nowDiaId)
       end 
      
   end 

   self.Conversation["Fields"] = t_data["Assets"]["Conversations"][1]["Fields"]


end 



--解析道具数据
function DialogLayer:deItem(data)



end 

--执行脚本
function DialogLayer:playScript(method)
 


end 



--开始对话 
function DialogLayer:begDialog()

    print("进入开始对话")
    local node = self.uiLayer:getChildByTag(1)
    local panel_1 = node:getChildByTag(1)
    local panel_2 = node:getChildByTag(2) 
    local imageView_1 = ccui.Helper:seekWidgetByTag(panel_2,201)
    local imageView_2 = ccui.Helper:seekWidgetByTag(panel_2,202)

    self.img_bg = cc.Sprite:create()
    self.img_bg:setAnchorPoint(cc.p(0,0))
    self.img_bg:setPosition(cc.p(0,0))

    self.img_old_bg = cc.Sprite:create()
    self.img_old_bg:setAnchorPoint(cc.p(0,0))
    self.img_old_bg:setPosition(cc.p(0,0))

    local num = self.Conversation["Fields"]["Primary_Location"]

    if num > 0 then
    print(num.."数量"..#Location.."名称"..Location[ num ]["Name"])
    if Location[ num ]["Pictures"][1] then
      self.img_bg:setTexture("scene/"..Location[ num ]["Pictures"][1] )
      self.img_old_bg:setTexture("scene/"..Location[ num ]["Pictures"][1] )
    end
    end

    node:addChild(self.img_bg,-1)
    node:addChild(self.img_old_bg,-2)
    
    self.img_a = ccui.ImageView:create()
    self.img_a:setCascadeOpacityEnabled(true)
    self.img_a:setCascadeColorEnabled(true)
    self.img_a:setAnchorPoint(cc.p(0.5,0.5))
    self.img_a:loadTexture("ui/share/gzzy_image_0.png")
    self.img_a:setVisible(false)
    self.img_a:setPosition(cc.p(self.pos_left))
    panel_1:addChild(self.img_a,4)

    self.img_b = ccui.ImageView:create()
    self.img_b:setCascadeOpacityEnabled(true)
    self.img_b:setCascadeColorEnabled(true)
    --self.img_b:setScale(1.5)
    self.img_b:setAnchorPoint(cc.p(0.5,0.5))
    self.img_b:loadTexture("ui/share/gzzy_image_0.png")
    self.img_b:setVisible(false)
    self.img_b:setPosition(self.pos_right)
    panel_1:addChild(self.img_b,4)

    self.img_c = ccui.ImageView:create()
    self.img_c:setCascadeOpacityEnabled(true)
    self.img_c:setCascadeColorEnabled(true)
    --self.img_c:setScale(1.5)
    self.img_c:setAnchorPoint(cc.p(0.5,0.5))
    self.img_c:loadTexture("ui/share/gzzy_image_0.png")
    self.img_c:setVisible(false)
    self.img_c:setPosition(self.pos_center)
    panel_1:addChild(self.img_c,4)


    self.img_aSide = ccui.ImageView:create()
    self.img_aSide:setCascadeOpacityEnabled(true)
    self.img_aSide:setCascadeColorEnabled(true)
    --self.img_aSide:setScale(1.5)
    self.img_aSide:setAnchorPoint(cc.p(0.5,0.5))
    self.img_aSide:loadTexture("ui/share/gzzy_image_0.png")
    self.img_aSide:setVisible(false)
    self.img_aSide:setPosition(self.pos_LeftSide)
    panel_1:addChild(self.img_aSide,4)


    self.img_bSide = ccui.ImageView:create()
    self.img_bSide:setCascadeOpacityEnabled(true)
    self.img_bSide:setCascadeColorEnabled(true)
    --self.img_bSide:setScale(1.5)
    self.img_bSide:setAnchorPoint(cc.p(0.5,0.5))
    self.img_bSide:loadTexture("ui/share/gzzy_image_0.png")
    self.img_bSide:setVisible(false)
    self.img_bSide:setPosition(self.pos_rightSide)
    panel_1:addChild(self.img_bSide,4)


   ------------------创建五个上的位置--------------------
    self.p_UL = ccui.Layout:create()
    self.p_UL:setVisible(false)
    self.p_UL:setContentSize(0,0)
    self.p_UL:setAnchorPoint(cc.p(0.5,0.5))
    self.p_UL:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_UL,5,106)

    self.p_ULS = ccui.Layout:create()
    self.p_ULS:setVisible(false)
    self.p_ULS:setContentSize(0,0)
    self.p_ULS:setAnchorPoint(cc.p(0.5,0.5))
    self.p_ULS:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_ULS,5,107)

    self.p_UC = ccui.Layout:create()
    self.p_UC:setVisible(false)
    self.p_UC:setContentSize(0,0)
    self.p_UC:setAnchorPoint(cc.p(0.5,0.5))
    self.p_UC:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_UC,5,108)


    self.p_UR = ccui.Layout:create()
    self.p_UR:setVisible(false)
    self.p_UR:setContentSize(0,0)
    self.p_UR:setAnchorPoint(cc.p(0.5,0.5))
    self.p_UR:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_UR,5,109)

    self.p_URS = ccui.Layout:create()
    self.p_URS:setVisible(false)
    self.p_URS:setContentSize(0,0)
    self.p_URS:setAnchorPoint(cc.p(0.5,0.5))
    self.p_URS:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_URS,5,110)

----------------创建五个下的位置---------------------

    self.p_DL = ccui.Layout:create()
    self.p_DL:setVisible(false)
    self.p_DL:setContentSize(0,0)
    self.p_DL:setAnchorPoint(cc.p(0.5,0.5))
    self.p_DL:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_DL,2,111)

    self.p_DLS = ccui.Layout:create()
    self.p_DLS:setVisible(false)
    self.p_DLS:setContentSize(0,0)
    self.p_DLS:setAnchorPoint(cc.p(0.5,0.5))
    self.p_DLS:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_DLS,2,112)

    self.p_DC = ccui.Layout:create()
    self.p_DC:setVisible(false)
    self.p_DC:setContentSize(0,0)
    self.p_DC:setAnchorPoint(cc.p(0.5,0.5))
    self.p_DC:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_DC,2,113)


    self.p_DR = ccui.Layout:create()
    self.p_DR:setVisible(false)
    self.p_DR:setContentSize(0,0)
    self.p_DR:setAnchorPoint(cc.p(0.5,0.5))
    self.p_DR:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_DR,2,114)

    self.p_DRS = ccui.Layout:create()
    self.p_DRS:setVisible(false)
    self.p_DRS:setContentSize(0,0)
    self.p_DRS:setAnchorPoint(cc.p(0.5,0.5))
    self.p_DRS:setPosition(cc.p(0,0))
    panel_1:addChild(self.p_DRS,2,115)
   

    self:isShowEffects(false)

    self.nameText = ccui.Text:create()
    self.nameText:setFontSize(35)
    self.nameText:setString(UITool.ToLocalization("名字"))
    self.nameText:setColor(cc.c3b(251,238,197))
    self.nameText:setPosition(cc.p(150,160))
    self.nameText:setFontName(TEXT_FONT_NAME)
    if g_channel_control.dialogLayerNameAnchor == true then
        self.nameText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
      self.nameText:setPosition(cc.p(50,160))
      self.nameText:setAnchorPoint(cc.p(0,0.5)) --修改名字锚点
    end


    if g_channel_control.transform_DialogLayer_nameStr_fontSize == true then
        self.nameText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        self.nameText:setAnchorPoint(cc.p(0,0.5))
        self.nameText:setPosition(cc.p(58,160))
    end
    imageView_1:addChild(self.nameText)

    self.cover_BG:setOpacity(0)
    self.cover_Actor:setOpacity(0)
    self.cover_All:setOpacity(0)
    self.cover_BG_finalOpacity = 0
    self.cover_Actor_finalOpacity = 0
    self.cover_All_finalOpacity = 0
    

    print("进入开始对话 结束")
    print("self.nowDiaId"..self.nowDiaId)

    self:playDialog(self.nowDiaId)

end 

--剧情语音
function DialogLayer:getVoicePath(item)

   local langType = AudioManager:shareDataManager():getLangAudioType();
  local vpath = item["Fields"]["Audio_Files"]
    if vpath == nil or string.len(vpath) == 0 then
        --从文件名自动生成
        local tempfilename = self.rData["rcvData"]["filename"]
        local poss = string.find(tempfilename,"/")
        local pose = string.find(tempfilename,"%.")
        local shortFileName = string.sub(tempfilename,poss + 1,pose - 1)

        if string.find(shortFileName,"hero") == 1 then
           vpath = string.format("music/herogot/"..langType.."/%sc%03d.mp3",shortFileName,item["ID"])
        else
            local posn = string.find(shortFileName,"e")
            local subpath = string.sub(shortFileName,1,posn - 1).."/"

            vpath = string.format("voice/"..langType .."/%s%sj%03d.mp3",subpath,shortFileName,item["ID"])
              
            
        end
    end
 
    return vpath

    --切换语言
    -- local languageType = 2  -- 1 中文  2 日文 "voice/cn/"
 


    -- local vpath = item["Fields"]["Audio_Files"]
    -- if vpath == nil or string.len(vpath) == 0 then
    --     --从文件名自动生成
    --     local tempfilename = self.rData["rcvData"]["filename"]
    --     local poss = string.find(tempfilename,"/")
    --     local pose = string.find(tempfilename,"%.")
    --     local shortFileName = string.sub(tempfilename,poss + 1,pose - 1)

    --     if string.find(shortFileName,"hero") == 1 then
    --        --角色登场
    --         if languageType == 1 then
    --           vpath = string.format("music/herogot/cn/%sc%03d.mp3",shortFileName,item["ID"])
    --         elseif languageType == 2 then
    --           vpath = string.format("music/herogot/jp/%sc%03d.mp3",shortFileName,item["ID"])
    --         end
    --     else
    --         local posn = string.find(shortFileName,"e")
    --         local subpath = string.sub(shortFileName,1,posn - 1).."/"

    --         if languageType == 1 then
    --           vpath = string.format("voice/cn/%s%sc%03d.mp3",subpath,shortFileName,item["ID"])
    --         elseif languageType == 2 then
    --           vpath = string.format("voice/jp/%s%sj%03d.mp3",subpath,shortFileName,item["ID"])
    --         end
    --     end
    -- end
 
    -- return vpath
end

--播放一段对话
function DialogLayer:playDialog(id)

    self.fixedActorBright = false
    self:showDialogPanel()
    
    --这个地方回调。起名字。现在只有一个地方用，需要扩展的话再做
    if self.nowDiaId == 2 and self.rData["rcvData"]["playDialogCallFunc"] ~= nil then 
        self.rData["rcvData"]["playDialogCallFunc"](self.rData["rcvData"]["obj"])
    end 
    
     --判断是否有脚本
     --self:ResetPosition()
     --print("play nowDiaId == "..self.nowDiaId)
     if self.Conversation[id]["UserScript"]~="" then 
         --print("当前 是什么动作 == "..self.Conversation[id]["UserScript"])
         loadstring(self.Conversation[id]["UserScript"])()
     end 
    --  print("当前 是什么动作 == "..self.Conversation[id]["UserScript"])
    
    if Actor[self.Conversation[id]["Fields"]["Actor"]].Name ~= "旁白" then --名字
        local nameStr = Actor[self.Conversation[id]["Fields"]["Actor"]].Name
        --user_info.name =  user_info.name or  ""
        --nameStr = string.gsub(nameStr,"阿尔芬",user_info["name"])
        self.nameText:setString(nameStr)
    else 
        self.nameText:setString("")
    end 

    local vpath = self:getVoicePath(self.Conversation[id])
    if vpath then
      if self.voice_handle == nil then
        -- AudioManager:shareDataManager():stopAllEffects()
        AudioManager:shareDataManager():resumeAll()
      end
      self.voice_handle =  AudioManager:shareDataManager():playMusic(vpath,1,false);
    end

    -- if self.Conversation[id]["OutgoingLinks"][1] == nil then 
    --    -- print("进入这里面了")
    --    self:returnBack()
    --    --cc.MyHttpHelper:shareMyHttpHelper():startGame()
    --    return 
    -- end 

    print("临时打印长度 =="..#self.Conversation[id]["OutgoingLinks"])
    if #self.Conversation[id]["OutgoingLinks"] > 1 then
      -- self.IsTouchSe = true
      -- local node = self.uiLayer:getChildByTag(1)
      -- local panel = node:getChildByTag(3)
      -- local BtnDialog1 = ccui.Helper:seekWidgetByTag(panel,222)
      -- local BtnDialog2 = ccui.Helper:seekWidgetByTag(panel,223)
      -- BtnDialog1:setEnabled(false)
      -- BtnDialog2:setEnabled(false)

      self:TowSelect(self.Conversation[id]["OutgoingLinks"])
    end
    

      -------------------------------根据新需求 改动逻辑-------------------------------------
     -- local function TestFunc( ... ) 
        -- body

        local CurSpeakerId  = self.Conversation[id]["Fields"]["Actor"]
        --print("CurSpeakerId == "..CurSpeakerId)

        local LeftSideId  = self.Conversation[id]["Fields"]["LeftSide"]
       -- print("LeftSideId  == "..LeftSideId)

        local LeftId      = self.Conversation[id]["Fields"]["Left"]
       --print("LeftId  == "..LeftId)

        local MidId       = self.Conversation[id]["Fields"]["Mid"]
       -- print("MidId  == "..MidId)

        local RightId     = self.Conversation[id]["Fields"]["Right"]
       -- print("RightId  == "..RightId)

        local RightSideId = self.Conversation[id]["Fields"]["RightSide"]
       -- print("RightSideId  == "..RightSideId)

        self:AoutVisible(LeftSideId,self.img_aSide)
        self:AoutVisible(LeftId,self.img_a)
        self:AoutVisible(MidId,self.img_c)
        self:AoutVisible(RightId,self.img_b)
        self:AoutVisible(RightSideId,self.img_bSide)

        if not self.fixedActorBright then

          self.IsIBright = false
          -----------判断 那个高亮 
          self:AoutBright(CurSpeakerId,LeftSideId,self.img_aSide)

          self:AoutBright(CurSpeakerId,LeftId,self.img_a)

          self:AoutBright(CurSpeakerId,MidId,self.img_c)

          self:AoutBright(CurSpeakerId,RightId,self.img_b)

          self:AoutBright(CurSpeakerId,RightSideId,self.img_bSide)

          if self.IsIBright == false then
            self:AllBright()
          end
        end
        
    -- local dialogVoice = self.Conversation[id]["Fields"]["Audio_Files"]
    -- if dialogVoice ~= nil and string.len(dialogVoice) > 0 then
    --     self.effect_handle = cc.SimpleAudioEngine:getInstance():playEffect("music/jqyy/"..dialogVoice, false)
    -- end



    local talkString = self.Conversation[id]["Fields"]["Dialogue_Text"] --谈话内容
    user_info.name =  user_info.name or  ""
    --talkString = string.gsub(talkString,"阿尔芬",user_info["name"])

    if schedulerEntry ~= nil then
        scheduler:unscheduleScriptEntry(schedulerEntry)
        schedulerEntry = nil
    end

    local textArea = nil
    local tpanel_2 = self.uiLayer:getChildByTag(1):getChildByTag(2)
    if tpanel_2:getChildByTag(10)~= nil then 
        --self.uiLayer:getChildByTag(10):removeAllChildren()
        textArea = tpanel_2:getChildByTag(10)
        textArea:setString("")
    else
        textArea = ccui.Text:create("",TEXT_FONT_NAME,28)
        --textArea:setTextAreaSize(cc.size(800,0))
        textArea:ignoreContentAdaptWithSize(false)
        textArea:setContentSize(1100,155)
        --textArea:setAnchorPoint(cc.p(0.5,0.5))
        textArea:setPosition(640,40)
        textArea:setString("")
        tpanel_2:addChild(textArea,10,10)
    end 

    if talkString == nil or talkString == "" then 
        
        -- if self.Conversation[id]["OutgoingLinks"][1] == nil then 
        --     return 
        -- else 
        --     self:playDialog(self.Conversation[id]["OutgoingLinks"][1]) --当前为空直接跳到下一个
        -- end 
    else 
        local len = string.len(talkString)   --对话字符串的长度
        local begin = 1  --起始字符位置
        --local beginStr = ""  --起始字符为空     

        --富文本 
        -- local richText = ccui.RichText:create()
        -- richText:ignoreContentAdaptWithSize(false)
        -- richText:setContentSize(cc.size(1100, 155))
        -- richText:setPosition(cc.p(640,40))
        -- self.uiLayer:addChild(richText,10,10)

        local textAreaText = ""
        
        local function update(time)
     
          --如果字符没了停止
          if begin > len then 
             scheduler:unscheduleScriptEntry(schedulerEntry)
             schedulerEntry = nil
             
             --对话跳转  播放下一段对话
              -- if self.isPlayNext then
              --   if self.CurSelectId == 1 then
              --     self.lastDiaId = self.nowDiaId 
              --     self.nowDiaId = self.Conversation[id]["OutgoingLinks"][1]
              --     self.CurSelectId = 0 
              --   elseif self.CurSelectId == 2 then
              --     self.lastDiaId = self.nowDiaId 
              --     self.nowDiaId = self.Conversation[id]["OutgoingLinks"][1]
              --     self.CurSelectId = 0 
              --   else
              --     self.lastDiaId = self.nowDiaId 
              --     self.nowDiaId = self.Conversation[id]["OutgoingLinks"][1]
              --   end
              --   print("播放下一段对话")
              --   print("self.lastDiaId =="..self.lastDiaId)
              --   print("self.nowDiaId =="..self.nowDiaId)
              --   print("播放下一段对话完成")
              -- end
              -- if self.IsTouchSe == true then
              --     self.IsTouchSe = false
              --     local node = self.uiLayer:getChildByTag(1)
              --     local panel = node:getChildByTag(3)
              --     local BtnDialog1 = ccui.Helper:seekWidgetByTag(panel,222)
              --     local BtnDialog2 = ccui.Helper:seekWidgetByTag(panel,223)
              --     BtnDialog1:setEnabled(true)
              --     BtnDialog2:setEnabled(true)
              -- end
             --self:playDialog(self.nowDiaId)

           else 
         
             local curByte = string.byte(talkString,begin) 
            
             local byteCount = 1;

              if curByte >= 252  then
                  byteCount = 6
              elseif curByte >= 248 then
                  byteCount = 5
              elseif curByte >= 240 then
                  byteCount = 4
              elseif curByte >= 224 then
                  byteCount = 3
              elseif curByte >= 192 then
                  byteCount = 2
              else
                  byteCount = 1
              end


               local char = string.sub(talkString, begin, begin+byteCount -1)  --当前需要显示字符
                
               begin = begin + byteCount  --起始位置
               --beginStr = beginStr..char 
               --添加到富文本
               textAreaText = textAreaText..char

              --  local r_text =  ccui.RichElementText:create(1, cc.c3b(255, 255, 255), 255, char, TEXT_FONT_NAME, 32) 
              --  richText:pushBackElement(r_text)
              textArea:setString(textAreaText)
            end 
      end
      schedulerEntry= scheduler:scheduleScriptFunc(update, 0.02, false)
      --textArea:setString(talkString)

    end  
     print("结束 play nowDiaId == "..self.nowDiaId)
end 

--显示 当前需要显示或隐藏的人
function DialogLayer:AoutVisible(id,img)
    if id ~= -1 then
      --  print("id id id id =="..id)
        -- if id == 13 then
        --   img:setVisible(false)  
        --   return
        -- end
        img:setVisible(true)  
       -- local imagePath = cc.FileUtils:getInstance():isAbsolutePath("icons/role/vdrawing/"..Actor[id]["Pictures"][1])
        --if imagePath then    
        --  print("是否进入这里")
        print("Actor[id] id == "..id)
        --print("Actor[id] == "..Actor[id])
        --print("nil nil =="..Actor[id]["Pictures"][1])
        if #Actor[id]["Pictures"] >0 then
           print("现在table 的长度是  =="..#Actor[id]["Pictures"])
        end

        if #Actor[id]["Pictures"] > 0 then
          img:loadTexture("icons/role/vdrawing/"..Actor[id]["Pictures"][1])
        else
          img:setVisible(false) 
         -- print(""..Actor[id]["Pictures"][1])
        end
       -- end
    else
        img:setVisible(false) 
    end
end
--  当前演讲的高亮 聆听的灰
function DialogLayer:AoutBright(id,id1,img)  -- 进入半透的时候 id1 可能是nin 在资源不全的 
  --print("演讲人Id == "..id)
  --print("聆听人 Id == "..id1)
  --local img_sub = img:getChildByTag(9999)
  if id ~= id1 then 
      img:setLocalZOrder(3)
      img:setColor(cc.c3b(150,150,150))
      --if img_sub then img_sub:setColor(cc.c3b(150,150,150)) end
     -- print("没有执行")
  else
      self.CurBrightIm = img 
      img:setLocalZOrder(4)
      img:setColor(cc.c3b(255,255,255))      
      --if img_sub then img_sub:setColor(cc.c3b(255,255,255)) end
      self.IsIBright = true
  end
end

--- 全部高亮
function DialogLayer:AllBright( ... )
  -- body
  -- self.img_c:setColor(cc.c3b(255,255,255))
  -- self.img_bSide:setColor(cc.c3b(255,255,255))
  -- self.img_aSide:setColor(cc.c3b(255,255,255))
  -- self.img_b:setColor(cc.c3b(255,255,255))
  -- self.img_a:setColor(cc.c3b(255,255,255))
  local imgs = {self.img_c,self.img_bSide,self.img_aSide,self.img_b,self.img_a}
  for i = 1,#imgs do
    imgs[i]:setLocalZOrder(4)
    imgs[i]:setColor(cc.c3b(255,255,255))
    -- local img_sub = imgs[i]:getChildByTag(9999)
    -- if img_sub then img_sub:setColor(cc.c3b(255,255,255)) end
  end
end

function DialogLayer:ReadyShadowIn(type)
  if type >0 and type <= 3 then
    self.readyShadowIn = type
  end
end
--跳过一段对话 显示全部信息
function DialogLayer:skiptDialog(id)

     if id ==nil then
        self:returnBack()
        return
     end

      -- if self.CurSelectId == 1 then
      --   self.lastDiaId = self.nowDiaId 
      --   self.nowDiaId = self.Conversation[id]["OutgoingLinks"][1]
      --   self.CurSelectId = 0 
      --   id = self.nowDiaId
      -- elseif self.CurSelectId == 2 then
      --   self.lastDiaId = self.nowDiaId 
      --   self.nowDiaId = self.Conversation[id]["OutgoingLinks"][2]
      --   self.CurSelectId = 0 
      --   id = self.nowDiaId
      -- end
     if schedulerEntry~= nil then 
        
        scheduler:unscheduleScriptEntry(schedulerEntry)
        schedulerEntry = nil

        --暂停后显示当前dialog全部文字信息
        local talkString = self.Conversation[id]["Fields"]["Dialogue_Text"]
        user_info.name =  user_info.name or  ""
        --talkString = string.gsub(talkString,"阿尔芬",user_info["name"])
        local len = string.len(talkString)   --对话字符串的长度
        local begin = 1  --起始字符位置

        local tpanel_2 = self.uiLayer:getChildByTag(1):getChildByTag(2)
         if tpanel_2:getChildByTag(10) ~= nil then 
            --self.uiLayer:removeChildByTag(10)
            local textArea = tpanel_2:getChildByTag(10) 
            textArea:setString(talkString)
         else           
            local textArea = ccui.Text:create("",TEXT_FONT_NAME,32)
            --textArea:setTextAreaSize(cc.size(800,0))
            textArea:ignoreContentAdaptWithSize(false)
            textArea:setContentSize(1100,155)
            --textArea:setAnchorPoint(cc.p(0.5,0.5))
            textArea:setPosition(640,40)
            tpanel_2:addChild(textArea,10,10)
            textArea:setString(talkString)
          end

        --  local richText = ccui.RichText:create()
        --  richText:ignoreContentAdaptWithSize(false)
        --  richText:setContentSize(cc.size(1100, 155))
        --  richText:setPosition(cc.p(640,40))
        --  self.uiLayer:addChild(richText,10,10)

        --  while(begin <= len)
        --  do
        --     local curByte = string.byte(talkString,begin) 
          
        --     local byteCount = 1;

              -- if curByte >= 252  then
              --     byteCount = 6
              -- elseif curByte >= 248 then
              --     byteCount = 5
              -- elseif curByte >= 240 then
              --     byteCount = 4
              -- elseif curByte >= 224 then
              --     byteCount = 3
              -- elseif curByte >= 192 then
              --     byteCount = 2
              -- else
              --     byteCount = 1
              -- end
        --     local char = string.sub(talkString, begin, begin + byteCount - 1)  --当前需要显示字符

        --     local r_text =  ccui.RichElementText:create(1, cc.c3b(255, 255, 255), 255, char, TEXT_FONT_NAME, 32) 
        --     richText:pushBackElement(r_text)

        --     begin = begin + byteCount  --起始位置
        --  end
        
         
     else 
        local shadownode = nil
        local shadowtimeline = nil

        local function aftershadowout()
          self.readyShadowIn = 0
          --移除特效
          --恢复点击层
          if shadownode ~= nil then
              shadownode:stopAllActions()
              shadownode:removeFromParent()
          end          
          local node = self.uiLayer:getChildByTag(1)
          local panel_2 = node:getChildByTag(2)
          panel_2:setEnabled(true)
        end
        local function aftershadowin()
          if self.Conversation[id]["OutgoingLinks"][1] ~= nil then  
              print("跳过一段对话 self.nowDiaId =="..self.nowDiaId)
            -- print()
              print("fuzhi 跳过一段对话 self.nowDiaId =="..self.nowDiaId)
              self:FaceReset()
              self:AllActorReset()
              self:deleteAllActor()
              self.nowDiaId = self.Conversation[id]["OutgoingLinks"][1]
              self:playDialog(self.nowDiaId)
          
              if shadowtimeline ~= nil then
                --播放特效2
                shadowtimeline:setLastFrameCallFunc(aftershadowout)
                shadowtimeline:play("animation1",false)
              else
                local node = self.uiLayer:getChildByTag(1)
                local panel_2 = node:getChildByTag(2)
                panel_2:setEnabled(true)
              end
          else
              aftershadowout()
              self:returnBack()
          end 
        end

        if self.effect_handle ~= nil then
		        --cc.SimpleAudioEngine:getInstance():stopEffect(self.effect_handle)
            AudioManager:shareDataManager():stop(self.effect_handle)
            self.effect_handle = nil
        end

        if self.voice_handle then
            AudioManager:shareDataManager():stop(self.voice_handle)
            self.voice_handle = nil
        end

        local node = self.uiLayer:getChildByTag(1)
        local panel_2 = node:getChildByTag(2)
        panel_2:setEnabled(false)
        
        if self.readyShadowIn > 0 then
          --禁用点击层
          --播放特效

          --shadownode = cc.CSLoader
          shadownode = cc.CSLoader:createNode("DialogEffectShadow.csb")          

          if self.readyShadowIn == 1 then
              local p = node:getChildByName("shadow_1")
              p:addChild(shadownode)
          elseif self.readyShadowIn ==2 then
              local p = node:getChildByName("shadow_2")
              p:addChild(shadownode)
          else
              local p = node:getChildByName("shadow_3")
              p:addChild(shadownode)
          end

          shadowtimeline  = cc.CSLoader:createTimeline("DialogEffectShadow.csb")
          shadownode:runAction(shadowtimeline)

          shadowtimeline:setLastFrameCallFunc(aftershadowin)          
          shadowtimeline:play("animation0",false)
        else
        
          local dt = cc.DelayTime:create(0.05)
          local cf = cc.CallFunc:create(aftershadowin)
          local seq = cc.Sequence:create(dt,cf)
          self.uiLayer:runAction(seq) 
        end
        
     end 

end 

--结束对话
function DialogLayer:endDialog()
   
     if schedulerEntry~= nil then 
        
        scheduler:unscheduleScriptEntry(schedulerEntry)
        schedulerEntry = nil
     end 
 
end
-------根据Id返回当前应该执行动作的位置图片
function DialogLayer:getCurAcIm( id )
  -- body
  local img = nil
  local pos = cc.p(0,0)
  if id == 0 then
    img = self.img_aSide
    pos = self.pos_LeftSide
  elseif id == 1 then
    img = self.img_a
    pos = self.pos_left
  elseif id == 2 then
    img = self.img_c
    pos = self.pos_center
  elseif id == 3 then
    img = self.img_b
    pos = self.pos_right

  elseif id == 4 then
    img = self.img_bSide
    pos = self.pos_rightSide
  end
  return img , pos
end



--临时 播放动作提示
function DialogLayer:addTips() 


end 

function DialogLayer:ActorFlipMode(actor_position,flipmode)
  local img = self:getCurAcIm(actor_position)
  if img then
    img:setFlippedX(flipmode == 1)
  end
end

function DialogLayer:ActorBright(b1,b2,b3,b4,b5)

  self.fixedActorBright = true

  local bn = {b1,b2,b3,b4,b5}

  for i = 0,4 do

    local img = self:getCurAcIm(i)
    --local img_sub = img:getChildByTag(9999)

    if bn[i+1] == 0 then 
        img:setLocalZOrder(3)
        img:setColor(cc.c3b(150,150,150))
        --if img_sub then img_sub:setColor(cc.c3b(150,150,150)) end
    else
        img:setLocalZOrder(4)
        img:setColor(cc.c3b(255,255,255))      
        --if img_sub then img_sub:setColor(cc.c3b(255,255,255)) end
    end

  end

end

function DialogLayer:UseFace(actor_position,actorid,faceIndex,delaySecond)  -- 面部表情
  faceIndex = faceIndex + 1
  local img   = self:getCurAcIm(actor_position)
  if img:getChildByTag(9999) then
    print("是相同的对象")
     img:removeChildByTag(9999)
  else
    print("不是同一个对象了")
  end
  local function Execution( ... )
    -- body
      local Iname = "icons/role/face/"
      local img_face = ccui.ImageView:create()
      img_face:setAnchorPoint(cc.p(0,1))
      local ChangeY = 720 - Actor[actorid]["FacePosY"] 
      print("face pos x == "..Actor[actorid]["FacePosX"])
      print("ChangeY == "..ChangeY)
      
      img_face:setPosition(cc.p(Actor[actorid]["FacePosX"],ChangeY))
      if Actor[actorid]["FaceFiles"][faceIndex] then
        img_face:loadTexture(Iname..Actor[actorid]["FaceFiles"][faceIndex])
      else
        return
      end
      
      img:addChild(img_face,0,9999)
      -- if self.CurBrightIm ~= img then
      --   print("执行了相等的图片半透")
      --   img:getChildByTag(9999):setColor(cc.c3b(150,150,150))
      -- else
      --   print("执行了相等的图片半透 oooooooo")
      -- end

  end
  if delaySecond > 0 then
      local delay = cc.DelayTime:create(delaySecond)
      local callfunc = cc.CallFunc:create(Execution)
      local sequence = cc.Sequence:create(delay,callfunc)
      img:runAction(sequence)
  else
      Execution()
  end
end 
function DialogLayer:deleteAllActor( ... )
  -- body
      self.img_bg:stopAllActions()
      self.img_bg:setOpacity(255)

      self.img_old_bg:stopAllActions()
      self.img_old_bg:setOpacity(0)

      self.img_a:stopAllActions()
      self.img_a:setOpacity(255)

      self.img_b:stopAllActions()
      self.img_b:setOpacity(255)

      self.img_c:stopAllActions()
      self.img_c:setOpacity(255)

      self.img_aSide:stopAllActions()
      self.img_aSide:setOpacity(255)

      self.img_bSide:stopAllActions()
      self.img_bSide:setOpacity(255)
      
      self:deleteAllEffects()
     -- self:StopEffectsMuisc()

end

function DialogLayer:ActorFadeTo(actor_position,opacity,playSecond,delaySecond)
  local img  = self:getCurAcIm(actor_position)

  if playSecond == 0 and delaySecond == 0 then
    img:setOpacity(opacity)
  else

    local delay = cc.DelayTime:create(delaySecond)
    local fade = cc.FadeTo:create(playSecond,opacity)
    local sequence = cc.Sequence:create(delay,fade)

    img:runAction(sequence)
  end
end

function DialogLayer:ActorBeaten(actor_position, direction, speed1, distance, stay,speed2, delaySecond) 
end

function DialogLayer:ActorShake(actor_position, speed, direction,actorNum, delaySecond) --晃动    修改

  local img = self:getCurAcIm(actor_position)
  local function Execution( ... )
    -- body
     print("执行了人物晃动")
      
      local CurSeep = 0.1
      if speed == 0 then
        CurSeep = self.low_speed
      elseif speed == 1 then
        CurSeep = self.fast_speed
      elseif speed == 2 then
        CurSeep = self.fast_speed_1
      end
      if direction == 0 then -- 左右
          local seq  = cc.Sequence:create(
            cc.MoveBy:create(CurSeep,cc.p(15,0)),
            cc.MoveBy:create(CurSeep,cc.p(-15,0)))
          local rep1 = cc.Repeat:create(seq,actorNum)
          img:runAction(rep1)

      elseif direction == 1 then -- 上下
          local seq  = cc.Sequence:create(
            cc.MoveBy:create(CurSeep,cc.p(0,15)),
            cc.MoveBy:create(CurSeep,cc.p(0,-15)))
          local rep1 = cc.Repeat:create(seq,actorNum)
          img:runAction(rep1)

      end
  end
  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  img:runAction(sequence)

end 

function DialogLayer:ActorMoveEx(actor_position, moveDirection, speed,move_distance,  delaySecond) -- 人物移动 修改
  local img = self:getCurAcIm(actor_position)
  local function Execution( ... )
      print("执行了人物移动")
      local CurSeep = speed

      if moveDirection == 0 then   -- 上
        local Move = cc.MoveTo:create(CurSeep,cc.p(img:getPositionX(),move_distance))
        img:runAction(Move)
      elseif moveDirection == 1 then -- 下
        local Move = cc.MoveTo:create(CurSeep,cc.p(img:getPositionX(),move_distance))
        img:runAction(Move)
      elseif moveDirection == 2 then -- 左
        local Move = cc.MoveTo:create(CurSeep,cc.p(move_distance,img:getPositionY()))
        img:runAction(Move)
      elseif moveDirection == 3 then -- 右
        local Move = cc.MoveTo:create(CurSeep,cc.p(move_distance,img:getPositionY()))
        img:runAction(Move)
      end
  end

  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  img:runAction(sequence)
end

function DialogLayer:ActorMove(actor_position, moveDirection, speed,move_distance,  delaySecond) -- 人物移动 修改

 --[[   print("进入移动的函数")
    if moveType == 0 then -- 左或右露出 半个立绘

        self.img_c:setPositionX(0)

    

    elseif moveType == 1 then -- 退场方式
        local Move = cc.MoveBy:create(delaySecond,cc.p(0,-1000))
        self.img_c:runAction(Move)
    elseif moveType == 2 then -- 进场方式
        self.img_c:setPositionX(-500)
        local Move = cc.MoveTo:create(delaySecond,cc.p(0,self.img_c:getPositionY()))
        self.img_c:runAction(Move)
    end]]--
  local img = self:getCurAcIm(actor_position)
  local function Execution( ... )
      print("执行了人物移动")
      local CurSeep = 0.3
      if speed == 0 then
        CurSeep = self.low_speed
      elseif speed == 1 then
        CurSeep = self.fast_speed
      elseif speed == 2 then
        CurSeep = self.fast_speed_1
      end

      

      if moveDirection == 0 then   -- 上
        local Move = cc.MoveTo:create(CurSeep,cc.p(img:getPositionX(),move_distance))
        img:runAction(Move)
      elseif moveDirection == 1 then -- 下
        local Move = cc.MoveTo:create(CurSeep,cc.p(img:getPositionX(),move_distance))
        img:runAction(Move)
      elseif moveDirection == 2 then -- 左
        local Move = cc.MoveTo:create(CurSeep,cc.p(move_distance,img:getPositionY()))
        img:runAction(Move)
      elseif moveDirection == 3 then -- 右
        local Move = cc.MoveTo:create(CurSeep,cc.p(move_distance,img:getPositionY()))
        img:runAction(Move)
      end
  end

  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  img:runAction(sequence)
end 

function DialogLayer:ResetActorPos(actor_position,speed,delaySecond) --人物复位 修改
     --[[ self.img_bg:setPosition(cc.p(0,0))
      self.img_a:setPosition(cc.p(self.pos_left))
      self.img_a:setRotation(0)
      self.img_b:setPosition(self.pos_right)
      self.img_b:setRotation(0)
      self.img_c:setPosition(self.pos_center)
      self.img_c:setRotation(0)

      self.img_aSide:setPosition(self.pos_LeftSide)
      self.img_aSide:setRotation(0)

      self.img_bSide:setPosition(self.pos_rightSide)
      self.img_bSide:setRotation(0)]]--
  local img ,pos = self:getCurAcIm(actor_position)
 -- if img:getChildByTag(1) then
--    print("看看是怎么回事")
--    img:removeChildByTag(1)
--  end
  local function Execution( ... )
       print("执行了人物复位")
        local CurSeep = 0.1
        if speed == 0 then
          CurSeep = self.low_speed
        elseif speed == 1 then
          CurSeep = self.fast_speed
        elseif speed == 2 then
          CurSeep = self.fast_speed_1
        end

     
      --local Move     = cc.MoveBy:create(CurSeep,pos)
      --img:runAction(Move)
      img:setPosition(pos)

  end

  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  img:runAction(sequence)
end 

function DialogLayer:ActorDown(actor_position,delaySecond)  -- 倒下 震动 向下移出屏幕
   
      --[[  local seq  = cc.Sequence:create( 
          cc.MoveBy:create(0.1,cc.p(0,-10)),
          cc.MoveBy:create(0.1,cc.p(0,10))
        )
        local down = cc.RotateTo:create(0.1,-90)
       -- self.img_c:runAction(down)
        local rep1 = cc.Repeat:create(seq,delaySecond)
       -- self.img_c:runAction(rep1)
        local Move = cc.MoveBy:create(delaySecond,cc.p(0.1,-600))

        self.img_c:runAction(cc.Sequence:create(seq,down,rep1,Move))]]--
  local img  = self:getCurAcIm(actor_position)
  local function Execution( ... )
      print("执行了人物左右震动")
      local CurSeep = 0.3
      if speed == 0 then
        CurSeep = self.low_speed
      elseif speed == 1 then
        CurSeep = self.fast_speed
      elseif speed == 2 then
        CurSeep = self.fast_speed_1
      end
     
      local seq  = cc.Sequence:create( 
          cc.MoveBy:create(0.1,cc.p(0,-10)),
          cc.MoveBy:create(0.1,cc.p(0,10))
         
        )
      local rep1 = cc.Repeat:create(seq,2)
      img:runAction(rep1)
      local Move = cc.MoveBy:create(CurSeep,cc.p(0,-1000))
      img:runAction(Move)
  end
  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  img:runAction(sequence)
end 
function DialogLayer:ActorDownAfterShake( actor_id,delaySecond )  -- 震动倒下 向下移出屏幕
  -- body
  local img  = self:getCurAcIm(actor_position)
  local function Execution( ... )
       print("执行了人物上下震动")
      local CurSeep = 0.1
      if speed == 0 then
        CurSeep = self.low_speed
      elseif speed == 1 then
        CurSeep = self.fast_speed
      elseif speed == 2 then
        CurSeep = self.fast_speed_1
      end
      
      local seq  = cc.Sequence:create( 
          cc.MoveBy:create(0.1,cc.p(10,0)),
          cc.MoveBy:create(0.1,cc.p(-10,0))
         
        )
      local rep1 = cc.Repeat:create(seq,2)
      img:runAction(rep1)
      local Move = cc.MoveBy:create(delaySecond,cc.p(0,-1000))
      img:runAction(Move)
  end
  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  img:runAction(sequence)

end

function DialogLayer:PlayCover(colorR, colorG , colorB, cover_type, opacity, playSecond, delaySecond ,playSecond2)
  -- 1,2,3 渐变到指定透明度
  -- 4，5，6 简便到指定透明度后变回原样

  if playSecond2 == nil then playSecond2 = 0 end

  local tempcover = nil
  local delay2 = nil
  local fade2 = nil

  if cover_type == 1 then
    tempcover = self.cover_BG
    self.cover_BG_finalOpacity = opacity
  elseif cover_type == 2 then
    tempcover = self.cover_Actor
    self.cover_Actor_finalOpacity = opacity
  elseif cover_type == 3 then
    tempcover = self.cover_All
    self.cover_All_finalOpacity = opacity
  elseif cover_type == 4 then
    tempcover = self.cover_BG
    delay2 = cc.DelayTime:create(playSecond2)
    fade2 = cc.FadeTo:create(playSecond,self.cover_BG_finalOpacity)
  elseif cover_type == 5 then
    tempcover = self.cover_Actor
    delay2 = cc.DelayTime:create(playSecond2)
    fade2 = cc.FadeTo:create(playSecond,self.cover_Actor_finalOpacity )
  elseif cover_type == 6 then
    tempcover = self.cover_All
    delay2 = cc.DelayTime:create(playSecond2)
    fade2 = cc.FadeTo:create(playSecond,self.cover_All_finalOpacity)
  end
  
  tempcover:setBackGroundColor(cc.c3b(colorR, colorG, colorB))
  
  if playSecond == 0 and delaySecond == 0 and delay2 == nil then
    tempcover:setOpacity(opacity)
  else
    local delay = cc.DelayTime:create(delaySecond)
    local fade = cc.FadeTo:create(playSecond,opacity)
    local sequence = nil
    if delay2 ~= nil then
       sequence = cc.Sequence:create(delay,fade,delay2,fade2)
    else
       sequence = cc.Sequence:create(delay,fade)
    end
    tempcover:runAction(sequence)
  end
  
end
 --
function DialogLayer:PlayAnim(actor_position, effectType, effect_order,isType, delaySecond)  -- 位置 , --id ,--层级 0 下 1 上 , --延时

   local isLoop = false
   local isOnly = 0
   if isType == 0 then
    isLoop = false
   elseif isType == 1 then
    isLoop = true
   elseif isType == 2 then
    isOnly = 2
   end
     local node = cc.CSLoader:createNode("DialogEffects_"..effectType..".csb")

     ------------------回调函数------------------
     local function caiSeCallBack( ... )
      -- body
      if isOnly == 0 then
        if isLoop == false then
          node:stopAllActions()
          node:removeFromParent()
        end
      end
     end
    
     -----------------设置位置--------------------


      local p_panel = nil
      local pos = cc.p(0,0)

     if effect_order == 0 then
       if actor_position == 0 then
          pos     = self.pos_LeftSide
          p_panel = self.p_ULS
       elseif actor_position == 1 then
          pos     = self.pos_left
          p_panel = self.p_UL
       elseif actor_position == 2 then
          pos     = self.pos_center
          p_panel = self.p_UC
       elseif actor_position == 3 then
          pos     = self.pos_right
          p_panel = self.p_UR
       elseif actor_position == 4 then
          pos     = self.pos_rightSide
          p_panel = self.p_URS
       elseif actor_position == 5 then -- 场景特效
          pos = self.pos_bgE
          p_panel = self.p_UC
       end
        
     elseif effect_order == 1 then
        if actor_position == 0 then
          pos     = self.pos_LeftSide
          p_panel = self.p_DLS
       elseif actor_position == 1 then
          pos     = self.pos_left
          p_panel = self.p_DL
       elseif actor_position == 2 then
          pos     = self.pos_center
          p_panel = self.p_DC
       elseif actor_position == 3 then
          pos     = self.pos_right
          p_panel = self.p_DR
       elseif actor_position == 4 then
          pos     = self.pos_rightSide
          
          p_panel = self.p_DRS
       elseif actor_position == 5 then -- 场景特效
          pos = self.pos_bgE
          p_panel = self.p_DC
       end
     end 
     


    ----------------设置层级--------------------- 
    node:setVisible(false)
    p_panel:addChild(node,0,321)
    p_panel:setPosition(pos)  
    local function Execution( ... )
       self:isShowEffects(true)
       local Aninode = cc.CSLoader:createTimeline("DialogEffects_"..effectType..".csb")
       node:stopAllActions() 
       node:setVisible(true)
       node:runAction(Aninode);
       Aninode:setLastFrameCallFunc(caiSeCallBack)
        if isOnly == 2 then
          Aninode:play("animation0", false);
        else       
            Aninode:play("animation0", isLoop);
        end
    end

    local delay = cc.DelayTime:create(delaySecond)
    local callfunc = cc.CallFunc:create(Execution)
    local sequence = cc.Sequence:create(delay,callfunc)
    p_panel:runAction(sequence)

end 
function DialogLayer:deleteAllEffects( ... )
  -- body
  self:isShowEffects(false)
  local panels = {
  self.p_ULS,
  self.p_UC,
  self.p_UL,
  self.p_UR,
  self.p_URS,
  self.p_DC,
  self.p_DRS,
  self.p_DR,
  self.p_DL,
  self.p_DLS,
  }

  for i = 1,#panels do
    local panel = panels[i]
    panel:stopAllActions()
    local node = panel:getChildByTag(321)
    if node then
      node:stopAllActions()
    end
    panel:removeAllChildren()
  end

  self.cover_BG:stopAllActions()
  self.cover_BG:setOpacity(self.cover_BG_finalOpacity)
  
  self.cover_Actor:stopAllActions()
  self.cover_Actor:setOpacity(self.cover_Actor_finalOpacity)
  
  self.cover_All:stopAllActions()
  self.cover_All:setOpacity(self.cover_All_finalOpacity)
  
end
function DialogLayer:isShowEffects( bol )
  -- body
  self.p_UL:setVisible(bol)
  self.p_ULS:setVisible(bol)
  self.p_UC:setVisible(bol)
  self.p_UR:setVisible(bol)
  self.p_URS:setVisible(bol)
  self.p_DC:setVisible(bol)
  self.p_DRS:setVisible(bol)
  self.p_DR:setVisible(bol)
  self.p_DL:setVisible(bol)
  self.p_DLS:setVisible(bol)
end
function DialogLayer:PlayAnimOnActor(actor_id,effectType,delaySecond)


end 
function DialogLayer:BgShake(speed,direction, actorNum,delaySecond)

   --[[ if direction == 0 then -- 左右

     --[[ self.img_bg:runAction(
        cc.Repeat:create(
          cc.Sequence:create(
            cc.MoveBy:create(0.1,cc.p(self.img_bg:getPositionX(),20)),
            cc.MoveBy:create(0.1, cc.p(self.img_bg:getPositionX(),-20))),100))]]
    --[[  local seq  = cc.Sequence:create(
        cc.MoveBy:create(0.1,cc.p(15,0)),
        cc.MoveBy:create(0.1,cc.p(-15,0)))
      local rep1 = cc.Repeat:create(seq,delaySecond)
      self.img_bg:runAction(rep1)



    elseif direction == 1 then -- 上下
      local seq  = cc.Sequence:create(
        cc.MoveBy:create(0.1,cc.p(0,15)),
        cc.MoveBy:create(0.1,cc.p(0,-15)))
      local rep1 = cc.Repeat:create(seq,delaySecond)
      self.img_bg:runAction(rep1)

    end]]--


    local function Execution( ... )
        print("执行了背景震动")
        local CurSeep = 0.1
        if speed == 0 then
          CurSeep = self.low_speed
        elseif speed == 1 then
          CurSeep = self.fast_speed
        elseif speed == 2 then
          CurSeep = self.fast_speed_1
        end
      if direction == 0 then -- 左右
          local seq  = cc.Sequence:create(
            cc.MoveBy:create(CurSeep,cc.p(15,0)),
            cc.MoveBy:create(CurSeep,cc.p(-15,0)))
          local rep1 = cc.Repeat:create(seq,actorNum)
          self.img_bg:runAction(rep1)
      elseif direction == 1 then -- 上下
          local seq  = cc.Sequence:create(
            cc.MoveBy:create(CurSeep,cc.p(0,15)),
            cc.MoveBy:create(CurSeep,cc.p(0,-15)))
          local rep1 = cc.Repeat:create(seq,actorNum)
          self.img_bg:runAction(rep1)
      end

    end
    local function restPos( ... )
      -- body
       self.img_bg:setPosition(cc.p(0,0))
    end 
    local delay = cc.DelayTime:create(delaySecond)
    local callfunc  = cc.CallFunc:create(Execution)
    local callfunc1 = cc.CallFunc:create(restPos)
    local sequence  = cc.Sequence:create(delay,callfunc,callfunc1)
    self.img_bg:runAction(sequence)
end 

function DialogLayer:ChangeBg(location_id,speed,changetype)    -- 更换背景  0 渐入 1 渐出

  
   local CurSeep = 0.1 
   if speed == 0 then
     CurSeep = self.low_speed
   elseif speed == 1 then
     CurSeep = self.fast_speed
   elseif speed == 2 then
    CurSeep = self.fast_speed_1
   end
  
   if self.img_bg:isVisible() then
      print("显示了 正确")
   else
      print("显示了  失败")
   end
   if changetype == 0 then
      self.img_bg:setTexture("scene/"..Location[ location_id ]["Pictures"][1] )
      print("进入fadein")
      local function Execution( ... )
        -- body
        self.img_old_bg:setTexture("scene/"..Location[ location_id ]["Pictures"][1] )
        --self.img_bg:setOpacity(100)
      end 
      self.img_bg:setOpacity(0)
     -- self.img_old_bg:setOpacity(0)
      local fadeIn = cc.FadeIn:create(CurSeep)
      local callfunc  = cc.CallFunc:create(Execution)
      local sequence = cc.Sequence:create(fadeIn,callfunc)
      self.img_bg:runAction(sequence)
   elseif changetype == 1 then  -- FadeOut
      print("开始fedeout")
      self.img_bg:setTexture("scene/"..Location[ location_id ]["Pictures"][1] )

      self.img_old_bg:setLocalZOrder(-1)
      self.img_bg:setLocalZOrder(-2)
      local function Execution( ... )
        -- body
        self.img_old_bg:setTexture("scene/"..Location[ location_id ]["Pictures"][1] )
        self.img_old_bg:setLocalZOrder(-2)
        self.img_bg:setLocalZOrder(-1)
        self.img_old_bg:setOpacity(255)
        --self.img_bg:setOpacity(100)
      end 
      local fadeOut = cc.FadeOut:create(CurSeep)

      local callfunc  = cc.CallFunc:create(Execution)
      local sequence = cc.Sequence:create(fadeOut,callfunc)
      self.img_old_bg:runAction(sequence)
   elseif changetype == 2 then
      self.img_bg:setTexture("scene/"..Location[ location_id ]["Pictures"][1] )
      self.img_old_bg:setTexture("scene/"..Location[ location_id ]["Pictures"][1] )
   end
end 
function DialogLayer:TowSelect( DiaList )
  -- body
    self.isPlayNext = false
    local node = self.uiLayer:getChildByTag(1)
    local panel = node:getChildByTag(3)

    local panel_2 = node:getChildByTag(2)
    panel_2:setEnabled(false)

    local BtnDialog1 = ccui.Helper:seekWidgetByTag(panel,222)
    local BtnDialog2 = ccui.Helper:seekWidgetByTag(panel,223)
    BtnDialog1:setVisible(true)
    BtnDialog2:setVisible(true)
  --   BtnDialog1:setEnabled(false)
  --   BtnDialog2:setEnabled(false)
  -- local function Execution( ... )
  --   -- body
  --   BtnDialog1:setEnabled(true)
  --   BtnDialog2:setEnabled(true)
  -- end 
  -- local delay = cc.DelayTime:create(1.5)
  -- local callfunc = cc.CallFunc:create(Execution)
  -- local sequence = cc.Sequence:create(delay,callfunc)
  -- self.img_bg:runAction(sequence)

    ---------根据配置表 来确定按钮的显示文字
    local tex1 = BtnDialog1:getChildByName("Text_1")
    tex1:setString(self.Conversation[DiaList[1]]["Fields"]["Menu_Text"])
    local tex2 = BtnDialog2:getChildByName("Text_1")
    tex2:setString(self.Conversation[DiaList[2]]["Fields"]["Menu_Text"])
end
function DialogLayer:FaceReset( ... )
  -- body
    if self.img_a:getChildByTag(9999) then
      print("看看是怎么回事")
      self.img_a:removeChildByTag(9999)
    end
  
    if self.img_aSide:getChildByTag(9999) then
      print("看看是怎么回事")
      self.img_aSide:removeChildByTag(9999)
    end
    if self.img_c:getChildByTag(9999) then
      print("看看是怎么回事")
      self.img_c:removeChildByTag(9999)
    end
    if self.img_bSide:getChildByTag(9999) then
      print("看看是怎么回事")
      self.img_bSide:removeChildByTag(9999)
    end
    if self.img_b:getChildByTag(9999) then
      print("看看是怎么回事")
      self.img_b:removeChildByTag(9999)
    end
end
function DialogLayer:AllActorReset( ... )
  -- body
  self.img_a:setPosition(cc.p(self.pos_left))
  self.img_b:setPosition(self.pos_right)
  self.img_c:setPosition(self.pos_center)
  self.img_aSide:setPosition(self.pos_LeftSide)
  self.img_bSide:setPosition(self.pos_rightSide)

  self.img_a:setFlippedX(false)
  self.img_b:setFlippedX(false)
  self.img_c:setFlippedX(false)
  self.img_aSide:setFlippedX(false)
  self.img_bSide:setFlippedX(false)

end
--[[function DialogLayer:startMusic( ... )     --  开始
  -- body
  cc.SimpleAudioEngine:getInstance():preloadEffect("music/xxxx.mp3");
  cc.SimpleAudioEngine:getInstance():playEffect("music/xxxx.mp3",false)
end
function DialogLayer:pauseMusic( ... )     --  暂停
  -- body
  cc.SimpleAudioEngine:getInstance():stopAllEffects()
end
function DialogLayer:swischingMusic( ... ) -- 转换
  -- body
  cc.SimpleAudioEngine:getInstance():stopAllEffects("music/xxxx.mp3")
  cc.SimpleAudioEngine:getInstance():preloadEffect("music/xxxx.mp3");
  cc.SimpleAudioEngine:getInstance():playEffect("music/xxxx.mp3",false)
end]]--
function DialogLayer:ChangeBgMusic( music_id, delaySecond)
  -- body
  local name = BGM[music_id]["File"]
  local path = "music/battle/"
  local function Execution( ... )
    -- body
   -- cc.SimpleAudioEngine:getInstance():playMusic(path..name,true);
   AudioManager:shareDataManager():playBGMusic(path..name,true)
  end 
  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  self.img_bg:runAction(sequence)

end
function DialogLayer:StopBgMusic( delaySecond )
  -- body
  local function Execution( ... )
    -- body
   -- cc.SimpleAudioEngine:getInstance():pauseMusic()
   AudioManager:shareDataManager():stopBGMusic()

  end 
  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  self.img_bg:runAction(sequence)
end
function DialogLayer:ChangeEffectsMuisc( music_id,delaySecond )
  -- body
  local path = "music/herobs/"..sound_conf[music_id]["file_name"]
  local function Execution( ... )
    -- body
    --cc.SimpleAudioEngine:getInstance():playEffect(path,false);
   self.effect_handle =  AudioManager:shareDataManager():playMusic(path,0,false);
  end 
  local delay = cc.DelayTime:create(delaySecond)
  local callfunc = cc.CallFunc:create(Execution)
  local sequence = cc.Sequence:create(delay,callfunc)
  self.img_bg:runAction(sequence)
end
function DialogLayer:StopEffectsMuisc( ... )
  -- body
  --cc.SimpleAudioEngine:getInstance():stopAllEffects()
  AudioManager:shareDataManager():stopAll()
end

function DialogLayer:playGuideEffect(num)
    NewGuideManager:playGuideEffect(self,num)
end

---隐藏当前对话框
function DialogLayer:hiddenDialogPanel()
  if self.dialogPanel then
      self.dialogPanel:setOpacity(0)
  end
end
---显示当前对话框
function DialogLayer:showDialogPanel()
  if  self.dialogPanel then
    self.dialogPanel:setOpacity(255)
  end
end

function DialogLayer:create(rData)
     self.rData = rData
     self.sManager = self.rData["sManager"]
     self.uiLayer = cc.Layer:create()
     self:init()
     return self

end

--手动删除函数 ，不需要回调等等
function DialogLayer:handDelete()
    if self.rData["rcvData"]~=nil then 
       if self.rData["rcvData"]["filename"]~= nil then           
          local tempfilename = self.rData["rcvData"]["filename"]
          if not (string.find(tempfilename,"story/cjs0") == 1 or
             string.find(tempfilename,"story/hero") == 1 ) then
            --cc.SimpleAudioEngine:getInstance():stopMusic()
            AudioManager:shareDataManager():stopBGMusic();
          end
        end 
    end 

    self.uiLayer:removeFromParent()
    self.uiLayer = nil 

    if self.effect_handle ~= nil then
        --cc.SimpleAudioEngine:getInstance():stopEffect(self.effect_handle)
        AudioManager:shareDataManager():stop(self.effect_handle);
        self.effect_handle = nil
    end
 
   if schedulerEntry~= nil then 
     scheduler:unscheduleScriptEntry(schedulerEntry)
     schedulerEntry = nil
   end 
   self.Item = nil 
   self.Conversation = nil 
   self.Location = nil 
   self.nowDiaId = nil 
   self.lastDiaId = nil  
end

--DialogLayer:ChangeBg(3,1) DialogLayer:ActorShake(4,0,1,1) DialogLayer:UseFace(4,1,1) DialogLayer:ActorMove(4,1,1,200,1)
