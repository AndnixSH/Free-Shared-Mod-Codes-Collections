--require "XUIView"

NewGuildMainLayer = class("NewGuildMainLayer",XUIView)
NewGuildMainLayer.CS_FILE_NAME = "NewGuildMainLayer.csb"
NewGuildMainLayer.CS_BIND_TABLE = {
    -- pan 背景
    panebg  = "/s:panelBG", 
    -- 背景图片
    imagebg = "/s:panelBG/s:Sprite_1",
    -- [[主界面显示的父节点]]
    panelMain = "/s:Panel_mian",
    panel_3   = "/s:Panel_mian/s:Panel_3",
    --公会头像
    gFace     = "/s:Panel_mian/s:Panel_3/s:gFace",
    -- 会长名字
    gBoss     =  "/s:Panel_mian/s:Panel_3/s:gBoss",
    --成员数量标签
    gCountT     =  "/s:Panel_mian/s:Panel_3/s:Text_3",
    -- 公会名字
    gName     =  "/s:Panel_mian/s:Panel_3/s:gName",
    -- 公会排名
    gTop      =  "/s:Panel_mian/s:Panel_3/s:gTop",
    -- 公会当前数 最大数
    gMan      =  "/s:Panel_mian/s:Panel_3/s:gMan",
    gManMax   =  "/s:Panel_mian/s:Panel_3/s:Text_4",
    -- 公会积分
    gPoint    = "/s:Panel_mian/s:Panel_3/s:gPoint",
    -- 公会公告
    gDesc     = "/s:Panel_mian/s:Panel_3/s:gDesc",
    --公会设定
    btnSetup  = "/s:Panel_mian/s:Panel_3/s:Button_3",
    -- 成员    
    btnMember = "/s:Panel_mian/s:Panel_3/s:Button_4",
    -- 留言板 
    btnBBS    = "/s:Panel_mian/s:Panel_3/s:Button_4_0",

    btnHelp   = "/s:btnHelp",
    --塔
    btnTower  = "/s:Panel_mian/s:Button_1",

    -- 左边版娘
    bnL_btn = "/s:Panel_mian/s:Button_bn_l",
    -- 左版娘提示文本bg
    image_L =  "/s:Panel_mian/s:Image_bn_l",
    -- 左版娘提示文本
    image_tex_L = "/s:Panel_mian/s:Image_bn_l/s:Text_25",
    -- 右边版娘
    bnR_btn = "/s:Panel_mian/s:Button_bn_r",
    -- 右版娘提示文本bg
    image_R =  "/s:Panel_mian/s:Image_bn_r",
    -- 右版娘提示文本
    image_tex_R = "/s:Panel_mian/s:Image_bn_r/s:Text_25",

    skills    = "/s:Panel_4",-- skicon  lvtext
    -- 右标签页btn
    panel_r_btn    = "/s:Panel_r_btn",
    -- 返回
    btnClose       = "/s:Panel_r_btn/s:Button_close",
    --[[为加入公会活未开启状态]]
    panelNoGuild   = "/s:Panel_7_0",

    panelNotActive = "/s:Panel_7",

    -- 标签的父节点
    otherNode      = "/s:Node_5",

    --topbar节点 
    topBarViewPanel = "/s:TopBarPanel",
    btnList = "/s:btnList",
}

-- 初始化函数
function NewGuildMainLayer:init(guild_data)
    if g_channel_control.show_new_guild_main == true then
        NewGuildMainLayer.CS_FILE_NAME = "GuildMainLayer_new.csb"
    end
    NewGuildMainLayer.super.init(self)

    self.guild_data = guild_data

    self.cur_rBtnIndex = 1
    self.old_rBtnIndex = 0
    self.isShowLable   = false
    self.n_tiem        = 10
    self.n_tiem_2      = 5
    self:initRbtn()
    self:switchView(self.cur_rBtnIndex,self.old_rBtnIndex)
    self:setUIData()
    self:initUIBtn()
    self:initBnLable()
    self:changeRightBanNiangTextTip()
    if g_channel_control.show_new_guild_main == true then
        self:InitTopBarView()
        self:initFacilityBtnList()
    end

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end
function NewGuildMainLayer:refrsh( ... )
    -- body
    self:setUIData()
end

-- [[获取标签按钮 用table保存每种状态的图片]]
function NewGuildMainLayer:initRbtn( ... )
    -- body
    self.rbtnTable = {}
    self.swichTable1 = {}
    self.swichTable2 = {}
    for i = 1,4 do
        self.rbtnTable[i]   = self.panel_r_btn:getChildByName("Panel_btn_"..i)
        self.swichTable1[i] = self.panel_r_btn:getChildByName("Image_g_"..i)
      
        self.swichTable2[i] = self.panel_r_btn:getChildByName("Image_g_"..i.."_"..i)
  
        --print(self.swichTable2[i]:getName())
        self.rbtnTable[i]:addClickEventListener(function()
            if i == self.cur_rBtnIndex then
                return
            else
                self.old_rBtnIndex = self.cur_rBtnIndex;
                self.cur_rBtnIndex = i;
                self:switchView(i,self.old_rBtnIndex)
            end
        end)

        local configId = i + 22
        print("**************")
        UnlockSys:getInstance():bindLock(configId, self.rbtnTable[i], true)
    end

    UnlockSys:getInstance():bindLock(55, self.btnMember, true)
end
-- [[cur_rBtnIndex == 1 , lastChannel == 0 初始化显示
--    否则根据规则显示]]
function NewGuildMainLayer:switchView( cur_rBtnIndex,lastChannel )
    
    if cur_rBtnIndex == 1 and lastChannel == 0 then
        print("cur_rBtnIndex == "..cur_rBtnIndex)
        self.swichTable1[cur_rBtnIndex]:setVisible(false)
        self.swichTable2[cur_rBtnIndex]:setVisible(true)
    else

        self.swichTable1[lastChannel]:setVisible(true)
        self.swichTable2[lastChannel]:setVisible(false)
        self.swichTable1[cur_rBtnIndex]:setVisible(false)
        self.swichTable2[cur_rBtnIndex]:setVisible(true)
    end
    
    -- 删除旧的
    if lastChannel == 1 then
    elseif lastChannel == 2 then  -- 公会设施
        SceneManager:hideGuildFacility()
        if g_channel_control.show_new_guild_main == true then
            self.btnList:setVisible(false)
        end
    elseif lastChannel == 3 then  -- 商店
        SceneManager:hideAllianceShop()
    elseif lastChannel == 4 then  -- 公会排行
        SceneManager:hideGuildRank()
    end
    local function fCall(index)
        if g_channel_control.show_new_guild_main == true then
            self:refreshTopBar(index)
        end
    end
    -- 添加新的
    if cur_rBtnIndex == 1 then      -- 新的
        self.skills:setVisible(true)
        fCall(1)
    elseif cur_rBtnIndex == 2 then      -- 公会设施
        local function sFunc( ... )
            -- body
        end 
        local function call_refreshTopBar()
            fCall(2)
        end
        local rcvData = {}
        rcvData["curNode"] = self.otherNode
        rcvData["sDelegate"] = self
        rcvData["sFunc"] = nil
        rcvData["refreshTopBar"] = call_refreshTopBar
        SceneManager:showGuildFacility(rcvData)--curNode ,sDelegate ,sFunc 
        self.skills:setVisible(false)
        if g_channel_control.show_new_guild_main == true then
            self.btnList:setVisible(true)
        end
        fCall(2)
    elseif cur_rBtnIndex == 3 then  -- 商店
        local function buyCallback()
            -- body
            print("buyCallback=="..user_info["medal_num"])
            self:refreshByUserInfoChange()
        end
        SceneManager:showAllianceShop(self.otherNode ,3,buyCallback)
        self.skills:setVisible(false)
        fCall(3)
    elseif cur_rBtnIndex == 4 then  -- 公会排行
        --GuildInterface:GuildRanking()
        SceneManager:showGuildRank(self.otherNode)
        self.skills:setVisible(false)
        fCall(4)
    end

end

-- [[除了标签页的按钮调用]]
function NewGuildMainLayer:initUIBtn( ... )
    -- body
    if g_channel_control.transform_NewGuildMainLayer_Text_3_pos == true then
        local oldX = 190
        local newX = oldX - 66
        self.gCountT:setPositionX(newX)
    end
    --返回
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)
    -- 公会设定
    self.btnSetup:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toGuildSetup({
                guild_data = table.deepcopy(self.guild_data),
                exitGuildFunc = function()
                    self.needReturnBack = true
                end})
        end
    end)
    -- 留言板
    self.btnBBS:setPressedActionEnabled(false)
    self.btnBBS:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            SceneManager:toGuildBBS()
        end
    end)
    -- 帮助
    self.btnHelp:addClickEventListener(function()
        --self:showGuidePicLayer()
        local data = {}
        data.pictures = { --一张或者多张
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
            "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
        }
        local sData = {}
        sData["prefix"] = "gh"
        sData["fontSize"] = 20
        sData["Iamgdata"] = data
        SceneManager:toPublicHelpText(sData)
    end)
    -- 成员列表
    self.btnMember:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            local rData = {}
            rData["nType"]       = 2
            rData["guild_id"]    = self.guild_data.guild_id
            rData["GuildType"]   = nil
            rData["selectIndex"] = 1
            rData["pos"]         = self.guild_data.position
            SceneManager:toGuildMemberLayer(rData)
        end
    end)
    -- 公会塔
    self.btnTower:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then

            if tonumber(user_info["rank"]) >= UnlockGuildTowerRank then 
                SceneManager:toGuildPavilionLayer({})
            else 
              ---todo锁住 星界
                local str = string.format("公会塔将在冒险等级到达%d级时开放。",UnlockGuildTowerRank)
                SceneManager:showPromptLabel(UITool.ToLocalization(str))
            end 
        end
    end)
    -- 左版娘
    self.bnL_btn:setPressedActionEnabled(false)
    self.bnL_btn:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            self:showBnLable("L")   
        end
    end)
    -- 右版娘
    self.bnR_btn:setPressedActionEnabled(false)
    self.bnR_btn:addClickEventListener(function()
        if GameManagerInst.gameType == 2 then
            self:showBnLable("R")  
        end
    end)


end
-- 初始化版娘
-- [[在界面没有操作十几秒后 自动显示文本]]
function NewGuildMainLayer:initBnLable( ... )
    -- body
    if self.isShowLable == false then

        local function callback( ... )
            -- body
           
            self.image_L:setVisible(true)
            local index = math.random(1, 2)
            local str = UITool.getUserLanguage(guild_girl[index])
            --设置文本
            self.image_tex_L:setString(UITool.ToLocalization(str))
        end
        local function callback1( ... )
            -- body
            self.image_L:stopAllActions()
            self.image_L:setVisible(false)
            self:initBnLable()

        end
        local delay = cc.DelayTime:create(self.n_tiem)
        local delay1 = cc.DelayTime:create(self.n_tiem_2)
        local sequence = cc.Sequence:create(delay, cc.CallFunc:create(callback),delay1,cc.CallFunc:create(callback1))
        self.image_L:runAction(sequence)
    end
end

function NewGuildMainLayer:changeRightBanNiangTextTip( ... )
    -- body
    if g_channel_control.transform_NewGuildMainLayer_Text_banniang_tip_contentSize == true then
        print("changeRightBanNiangTextTip")
        self.image_R:setContentSize(230, 110)
        self.image_tex_R:setFontSize(16)
        self.image_tex_R:setContentSize(190,100)
        
        self.image_L:setContentSize(230, 110)
        self.image_tex_L:setFontSize(16)
        local imageTextLPosX, imageTextLPosY = self.image_tex_L:getPosition();
        self.image_tex_L:setPosition(imageTextLPosX + 10, imageTextLPosY);
        self.image_tex_L:setContentSize(190,100)
        
    end
end

-- 控制版娘显示的文本
function NewGuildMainLayer:showBnLable( strN )
    -- body
    self.isShowLable = true 
    local index = math.random(1, 2)
    local str = UITool.getUserLanguage(guild_girl[index])
    -- 条件一 隐藏上一个 显示当前的
    if strN == "L" then
        -- 暂停动作
        self.image_R:stopAllActions()
        self.image_L:stopAllActions()
        -- 显示当前的文本
        self.image_R:setVisible(false)
        self.image_L:setVisible(true)
        --设置文本
        if g_channel_control.transform_NewGuildMainLayer_font == true then 
            self.image_tex_L:setFontSize(16)
        end
        self.image_tex_L:setString(UITool.ToLocalization(str))
        local function callback( ... )
            -- body
            self.image_L:stopAllActions()
            self.image_L:setVisible(false)
            self.isShowLable = false
            self:initBnLable() 
        end
        local delay = cc.DelayTime:create(self.n_tiem)
        local sequence = cc.Sequence:create(delay, cc.CallFunc:create(callback))
        self.image_L:runAction(sequence)

    elseif strN == "R" then
        -- 暂停动作
        self.image_R:stopAllActions()
        self.image_L:stopAllActions()
        -- 显示当前的文本
        self.image_R:setVisible(true)
        self.image_L:setVisible(false)
        --设置文本
        self.image_tex_R:setString(UITool.ToLocalization(str))
        if g_channel_control.transform_NewGuildMainLayer_font == true then 
            self.image_tex_R:setFontSize(16)
        end
        local function callback( ... )
            -- body
            self.image_R:stopAllActions()
            self.image_R:setVisible(false)
            self.isShowLable = false 
            self:initBnLable() 
        end
        local delay = cc.DelayTime:create(self.n_tiem)
        local sequence = cc.Sequence:create(delay, cc.CallFunc:create(callback))
        self.image_R:runAction(sequence)
    end

end
-- [[设置UI上的数据
--    # 如果有公会, 会出现下面属性 <--可能出现的属性-->  
--     "guild_id": "1437719007",     # 公会ID
--     "name": u"蜀山",        # 公会名
--   #  "Lv": 1,                # 公会等级 1-M(从低到高)
--     "ranking":"100",#公会排行,注：字符串，以防后续出现文本描述
--     "score": 0,             # 公会积分
--     "notice": u"这是公会的公告文本",
--     "mem_num": "18/20",     # 公会成员数量
--     "chairman": u"清虚",    # 会长名字
--     "image": "xxxxxx.jpg",  # 公会形象-----暂为公会会长头像
--     "join_condition": 1,    # 加入条件: 0-需要审批, 1-自动通过
--     "position": 6,          # 自己处职位,1-6(6最高,会长) 
--     # 公会buff
--     "buff": {
--          {
--             "skill_id":1,#生效的buffID
--             "need_gold": 500,
--             "end_time": 1437384422,  
--]]
function NewGuildMainLayer:setUIData( ... )
    -- body
        --have_guild   是否有公会       # 1-有公会, 0-已开启公会功能但未加入，-1，未达到开启公会的条件 
    if self.guild_data then
        if self.guild_data.have_guild == 1 then
            self.panelMain:setVisible(true)
            self.panel_r_btn:setVisible(true)
            self.panelNoGuild:setVisible(false)
            self.panelNotActive:setVisible(false)
            local npos = string.find(self.guild_data.mem_num,'/')
            local nlen = string.len(self.guild_data.mem_num)
            local nman = string.sub(self.guild_data.mem_num,0,npos - 1)
            local nmanmax = string.sub(self.guild_data.mem_num,npos + 1,nlen)
            -- 公会名字
            self.gName:setString(self.guild_data.name)
            -- 公会排行
            self.gTop:setString(self.guild_data.ranking)
            -- 会长名字
            self.gBoss:setString(self.guild_data.chairman)
            -- 公告
            print("gDesc  = ",self.guild_data.notice)
            self.gDesc:setString(self.guild_data.notice)
            -- 公会积分
            self.gPoint:setString(""..self.guild_data.score)
            -- 公会当前数 最大数
            self.gMan:setString(nman)    
            self.gManMax:setString(nmanmax)

            -- 公会形象 如果是nil就隐藏掉
            local hinfo = hero[self.guild_data["image"]]
            if hinfo then
                self.gFace:setVisible(true)
                self.gFace:setTexture(hinfo.hero_bat_icon)

            else
                self.gFace:setVisible(false)
            end
            -- 公会buff
            --[[如果不等nil 显示否则隐藏 根据等级设置颜色]]
            for i = 1,3 do  
                local skdata = self.guild_data.buff[""..i]

                local panel = self.skills:getChildByName("sk"..i)
                local icon = panel:getChildByName("skicon")
                local lv = panel:getChildByName("lvtext")

                if passive_sk[skdata.skill_id] then
                    print("passive_sk icon == "..passive_sk[skdata.skill_id].sk_icon)
                    icon:setVisible(true)
                    icon:setTexture(passive_sk[skdata.skill_id].sk_icon)
                else
                    icon:setVisible(false)
                end

                lv:setString(skdata.lv)
                if skdata.lv > 0 then
                    panel:setColor(cc.c3b(255,255,255))
                else
                    panel:setColor(cc.c3b(127,127,127))
                end

            end

            --self.btnSetup:setVisible(self.guild_data.position > 1)
            --设置小红点状态  塔的小红点
            UITool.setCommmonBtnRedDop(self.btnTower,false)
            UITool.setCommmonBtnRedDop(self.btnBBS,false)
            UITool.setCommmonBtnRedDop(self.btnMember,false)
            if self.guild_data["red_message"] == 1 then
                UITool.setCommmonBtnRedDop(self.btnBBS,true,cc.p(132,54))
            end
            if self.guild_data["red_member"] == 1 then
                UITool.setCommmonBtnRedDop(self.btnMember,true,cc.p(132,54))
            end
            if tonumber(user_info["rank"]) >= UnlockGuildTowerRank then 
                self.btnTower:setTouchEnabled(true)
                self.btnTower:setBright(true)

                if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.GuildTower) == 0 then 
                    UITool.setCommmonBtnRedDop(self.btnTower, true, cc.p(508,125))
                end 
            else
                self.btnTower:setTouchEnabled(false)
                self.btnTower:setBright(false)
            end

            ---第一次进入公会，更改配置文件
            if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Guild) == 0 then
                cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Guild, 1)
            end

        elseif   self.guild_data.have_guild == 0 then
            self.panelMain:setVisible(false)
            self.panel_r_btn:setVisible(false)
            self.panelNoGuild:setVisible(true)
            self.panelNotActive:setVisible(false)
        else
            self.panelMain:setVisible(false)
            self.panel_r_btn:setVisible(false)
            self.panelNoGuild:setVisible(false)
            self.panelNotActive:setVisible(true)
        end 
    else
        self.panelMain:setVisible(false)
        self.panel_r_btn:setVisible(false)
        self.panelNoGuild:setVisible(false)
        self.panelNotActive:setVisible(false)
        -- self.gFace:setVisible(false)
        -- self.gBoss:setString("")
        -- self.gName:setString("")
        -- self.gTop:setString("")
        -- self.gMan:setString("")
        -- self.gPoint:setString("")
        -- self.gDesc:setString("")
    end
end

function NewGuildMainLayer:showGuidePicLayer( ... )
    local data = {}
    data.pictures = { --一张或者多张
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function NewGuildMainLayer:loadData()
    GameManagerInst:rpc("{\"rpc\":\"guild_mine\"}",3,
    function(data)
        --success
        --GameManagerInst:saveToFile("guild_mine.json",data)
        self.guild_data = table.deepcopy(data)
        self:refrsh()
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function NewGuildMainLayer:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    if isback then
        --[[公会设定是否退出公会  退出if  修改else]]
        if self.needReturnBack then 
            self:returnBack()
        else
            cc.Director:getInstance():getTextureCache():removeUnusedTextures()
            self:loadData()
        end
    else
        if not self.guild_data then
            self:loadData()
        end
    end
  
end

function NewGuildMainLayer:returnBack()
    if self._navigationView then
        self._navigationView:popView()
    else
        self:removeFromParentView()
    end
end


function NewGuildMainLayer:InitTopBarView()
    if self.topBarViewPanel then
        self.topBarViews = XUIView.new():init(self.topBarViewPanel)
        local iteamDatas = {}
        local rcvData = {}
        rcvData["sIteamDatas"] = iteamDatas
        rcvData["bIsStartLayer"] = false
        rcvData["nInfoState"] = table.getValue("coinbar",coinbar,20,"coinbar_type")
        rcvData["nTitleNum"] = 7
        self.topBarView = TopBarView.new():init(rcvData)
        self.topBarViews:addSubView(self.topBarView)
        self:InitSociatyInfoTopBarView()
    end
end

function NewGuildMainLayer:InitSociatyInfoTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,20,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

function NewGuildMainLayer:InitSociatyFacilityTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,21,"coin_list")
        dump(iteamDatas,"iteamDatas:")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end
function NewGuildMainLayer:InitSociatyShopTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,22,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end
function NewGuildMainLayer:InitSociatyRankTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,23,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

-- 当货币栏中有不是金币，体力和星石时，需要单独刷洗数据 (根据不同的类型数据存入array_cointype中),具体类型参考cointype表 
function NewGuildMainLayer:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
            if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end

function NewGuildMainLayer:refreshTopBar(_type)
    local switch = 
    {
        [1] = function()
            self:InitSociatyInfoTopBarView()
        end,
        [2] = function()
            self:InitSociatyFacilityTopBarView()
        end,
        [3] = function()
            self:InitSociatyShopTopBarView()
        end,
        [4] = function()
            self:InitSociatyRankTopBarView()
        end
    }
    local f = switch[_type]
    if f then
        f()
    else
        print("调用TopBar错误")
    end
end

function NewGuildMainLayer:initFacilityBtnList()
    self.btnList:setVisible(false)
    self.btnList:addClickEventListener(function()
        GameManagerInst:rpc("{\"rpc\":\"guild_contr_ranking\"}",3,
        function(data)
            GameManagerInst:showModalView(GuildContributionView.new():initWithData(data.members))
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true)
    end)
end

function NewGuildMainLayer:refreshByUserInfoChange()
    if self.topBarView then
        self.topBarView:refreshByUserInfoChange()
    end
end



