
 
 CountTime =  {}
--CountTime = class("CountTime")
--CountTime.__index = CountTime

--Lua 实现倒计时功能  
 
CountTime.scheduler = nil--cc.Director:getInstance():getScheduler()  
CountTime.run_logic = nil  
CountTime.hour = 1  
CountTime.minute = 0  
CountTime.second = 0  
CountTime.CallFunc = nil
CountTime.Myself   = nil
--时 分 秒 数值  
function CountTime:init( hour,minute, second)
		-- body
		--将int类型转换为string类型  
	self.hour = hour..""  
	self.minute = minute..""  
	self.second = second..""  
	self.scheduler= cc.Director:getInstance():getScheduler() 
	--当显示数字为个位数时，前位用0补上  
	if string.len(self.hour) == 1 then  
	    self.hour = "0"..self.hour  
	end  
	  
	if string.len(self.minute) == 1 then  
	    self.minute = "0"..self.minute  
	end  
	  
	if string.len(self.second) == 1 then  
	    self.second = "0"..self.second  
	end 
	 
end
function CountTime:CallFunc( fuc )
	-- body
	self.CallFunc = fuc
end
function CountTime:setMySelf( s )
	-- body
	self.Myself = s
end
  
--倒计时更新函数  
function CountTime:Begin()  

	local function updata( ... )
		-- body
			self.second = self.second-1  
		    if self.second == -1 then  
		        if self.minute ~= -1 or self.hour ~= -1 then  
		            self.minute = self.minute-1  
		            self.second = 59  
		            if self.minute == -1 then  
		                if self.hour ~= -1 then  
		                    self.hour = self.hour-1  
		                   self.minute = 59  
		                    if self.hour == -1 then  
		                        --倒计时结束停止更新  
		                        if self.run_logic ~= nil then  
		                            self.scheduler:unscheduleScriptEntry(self.run_logic)  
		                            self.run_logic = nil  
		                        end  
		                        self.second = 0  
		                        self.minute = 0  
		                        self.hour = 0   
		                    end  
		                end  
		            end  
		        end  
		    end  
		      
		    self.second = self.second..""  
		    self.minute = self.minute..""  
		    self.hour = self.hour..""  
		      
		    if string.len(self.second) == 1 then  
		        self.second = "0"..self.second  
		    end  
		      
		    if string.len(self.minute) == 1 then  
		        self.minute = "0"..self.minute  
		    end  
		      
		    if string.len(self.hour) == 1 then  
		        self.hour = "0"..self.hour  
		    end 
		   -- if self.CallFunc then
		    self:CallFunc(self.hour,self.minute,self.second,self.Myself)
		    --else
		    	--self:Stop()
		    --end
		    print("self.second == "..self.second)
		    print("self.minute == "..self.minute)
		    print("self.hour == "..self.hour)
	end
 
	self.run_logic = self.scheduler:scheduleScriptFunc(updata,1,false) 
end  
  
--开始倒计时 每1秒调用一次anticlockwiseUpdate方法  
function CountTime:Stop( ... )
	-- body
	print("暂停")
	if self.scheduler ~= nil then
		self.scheduler:unscheduleScriptEntry(self.run_logic) 
	end 
	self.run_logic = nil
	self.CallFunc       = nil
end
  
function CountTime:create()
  	-- body

    local t = t or {}
    self.__index = self
    setmetatable( t, self )
    return t
end  
 

