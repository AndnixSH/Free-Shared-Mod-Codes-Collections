--require "XUIView"

SthMatNumView = class("SthMatNumView",XUIView)
SthMatNumView.CS_FILE_NAME = "SthMatNumView.csb"
SthMatNumView.CS_BIND_TABLE = 
{
    panelicon = "/i:143/i:146",
    matFace = "/i:143/i:146/i:148",
    matName = "/i:143/i:149",
    btnLeft = "/i:143/i:150",
    btnRight = "/i:143/i:151",
    lbCurNum = "/i:143/i:152",
    lbMaxNum =  "/i:143/i:154"
}

function SthMatNumView:init(rootNode)
    SthMatNumView.super.init(self,rootNode)
    self.CurNumChangedEvent = nil
    self.maxMatNum = 0
    self.curMatNum = 0
    self.isMaxLevel = false

    self.btnLeft:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.began then
		--先要减一次
		--开始减小狗粮
		self:startIncreaseFood(-1)
		elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
		--停止减小狗粮
		self:stopFoodNum()
		end
    end)

    self.btnRight:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.began then
		--开始加小狗粮
		self:startIncreaseFood(1)
		elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
		     --停止加小狗粮
		    self:stopFoodNum()
            if XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.StHero) then 
                if XbTriggerGuideManager._isSth then 
                    XbTriggerGuideManager:showTriggerGuide(nil, 6, TriggerGuideConfig.StHero)
                end  
            end
		end
    end)

    self.panelicon:setTouchEnabled(true)
    self.panelicon:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            if self.iconClickEvent then
                self.iconClickEvent(self)
            end
        end
    end)

    self:refresh()

    return self
end

function SthMatNumView:setMatInfo(matid,num)
    self.curMatNum = 0
    self.maxMatNum = num

    local mid = getMatID(matid)
    local matobj = mat[mid]

    self.matFace:setTexture("icons/mat/"..matobj["icon"])
    self.matName:setString(UITool.getUserLanguage(matobj["name"]))--(matobj["name"])
    
    self:refresh()
end

function SthMatNumView:setCurMatNum(n)
    self.curMatNum = n
    self:refresh()
end

function SthMatNumView:getCurMatNum()
    return self.curMatNum
end

function SthMatNumView:setIsMaxLevel(isMaxLevel)
    self.isMaxLevel = isMaxLevel
    if self.isMaxLevel then
        self:stopFoodNum()
    end
end

function SthMatNumView:refresh()

    if self.curMatNum > 0 then
        --可以减数
        self.btnLeft:setTouchEnabled(true)
        self.btnLeft:setBright(true)
    else
        self.btnLeft:setTouchEnabled(false)
        self.btnLeft:setBright(false)
    end

    if (not self.isMaxLevel) and (self.curMatNum < self.maxMatNum ) then
        --可以加数
        self.btnRight:setTouchEnabled(true)
        self.btnRight:setBright(true)
    else
        self.btnRight:setTouchEnabled(false)
        self.btnRight:setBright(false)
    end

    self.lbCurNum:setString(""..self.curMatNum)
    self.lbMaxNum:setString(""..(self.maxMatNum - self.curMatNum))
end

function SthMatNumView:startIncreaseFood(opt)
	self:stopFoodNum()
	
	--闭包变量
	local c_opt = opt
	local c_total_time = 10
  	local c_cnt = 0
	
	local function addfoodfunc(time)
		-- local food_H_M_num = user_info["bag"]["mat"][ID_H_M]
		c_total_time = c_total_time + time
		c_cnt = c_cnt + 1
		
		local n = 1

		if c_total_time < 0.3 then
      		return
		elseif c_total_time < 2 then 
			if c_cnt > 3.5 then
				c_cnt = 0
			else
				return
			end
		elseif c_total_time < 3 then
			if c_cnt > 2.5 then
				c_cnt = 0
			else
				return
			end
		elseif c_total_time < 4 then
			if c_cnt > 1.5 then
				c_cnt = 0
			else
				return
			end
		else
			c_cnt = 0
		end
		
        self.curMatNum = self.curMatNum or 0
        self.curMatNum = self.curMatNum + n * c_opt
        
        if self.curMatNum < 0 then 
            self.curMatNum = 0
            self:stopFoodNum()
        end

        if self.curMatNum >  self.maxMatNum then
            self.curMatNum =  self.maxMatNum
            self:stopFoodNum()
        end

        if self.CurNumChangedEvent then
            self.CurNumChangedEvent()
        end
        
        self:refresh()
	end
	
	local scheduler = cc.Director:getInstance():getScheduler()
	self.schedulerEntry = scheduler:scheduleScriptFunc(addfoodfunc, 1/60 , false)
	
	addfoodfunc(0) ---点击同时先加一次
	c_total_time = 0
end

function SthMatNumView:stopFoodNum()
	if self.schedulerEntry == nil then return end
	
	local scheduler = cc.Director:getInstance():getScheduler()
	scheduler:unscheduleScriptEntry(self.schedulerEntry)
	self.schedulerEntry = nil
end