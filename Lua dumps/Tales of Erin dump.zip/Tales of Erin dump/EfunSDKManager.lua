
EfunSDKManager = {}
EfunSDKManager.roleLogin = false --efun ios其他接口需要在efunRoleLogin 调用之后
EfunSDKManager.EFUNSDK_ANDROID_CLASS = LUA_BRIDGE_CLASS
EfunSDKManager.EFUNSDK_IOS_CLASS = "EfunSDKManager"

EfunSDKManager.debug = false --开启调试，C++/Android 增加弹出提示

-- require "EfunTrackEvent"

function EfunSDKManager:efunLogin( ... )--SDK登陆 --已集成到SDKManage
end

function EfunSDKManager:efunRoleLogin() --角色登陆
    --角色登陆只做一次
    if EfunSDKManager.roleLogin == true  then
        return
    end
    if user_info["id"] ~= nil then 
        EfunSDKManager.roleLogin = true
    end 
    --玩家id
    -- local uid               = SDKManagerLua:getSdkUserId() or "1"
    --玩家名字
    -- local userName          = user_info["name"] or "username"
    --余额
    -- local balance           = user_info["gem"] or "0"
    --角色id
    local roleId            = tostring(user_info["id"]) or "392DJ4C8E"
    --角色名字
    local roleName          = tostring(user_info["name"]) or "username"
    --角色等级
    local roleLevel 		= tostring(user_info["rank"]) or "1"
    --帮派
    -- local roleParty         = user_info["guild_name"] or ""
    --服务器名字
    local serverName        = g_channel_control.serverName or "Tales of Erin"
    --服务器ID
    local serverCode 		= tostring(user_info["server_id"]) or "0"
    --vip等级
    local vip               = tostring(user_info["vip"]) or "0"
    -- local title             = "客服"
    -- 是否弹出c++/Android 弹出框
    local showLog           = tostring(EfunSDKManager.debug)

    local platform = cc.Application:getInstance():getTargetPlatform()
    local args = {
            -- 角色id
            roleId        	= tostring(roleId),
            -- 玩家角色名称
            roleName        = tostring(roleName),
            -- 玩家角色等级
            roleLevel 		= tostring(roleLevel),
            -- 服务器名字
            serverName    	= tostring(serverName), 
            -- 服务器ID
            serverCode 		= tostring(serverCode),        
            --vip
            vip             = tostring(vip),

            showLog         = tostring(showLog) 
        }
    print("EfunSDKManager:efunRoleLogin")
    if platform == cc.PLATFORM_OS_ANDROID then
    	local args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(EfunSDKManager.EFUNSDK_ANDROID_CLASS,"efunRoleLogin",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        zc.luaBridgeCall(EfunSDKManager.EFUNSDK_IOS_CLASS,"efunRoleLogin",args,"")
    end	
end

function EfunSDKManager:loginOut( ... )--SDK登陆 --已集成到SDKManage
	-- body
end

function EfunSDKManager:efunSEAPay( t_data )
    -- body
end

function EfunSDKManager:checkPromotedIAP( t_data )
    -- body
end

function EfunSDKManager:efunShare( data ) --分享
    if data == nil then
        print("error-------EfunSDKManager:efunShare")
        data = {}
    end
	-- body
    local sharePlatformType = data["sharePlatformType"] or 7 -- 0 facebook,1 twitter分享,2 kakao分享,3 vk分享,4 line分享,5 naver的cafe分享
                            -- 6 whatsApp分享,7 wechat分享,8 wechat朋友圈分享,9 messenger分享,10 instagram分享
     local shareType            = data["shareType"] or 1    --0 图片，1文本、2、图片 3、在线链接分享  (andorid有3)               
     local shareUrl             = data["shareUrl"] or "https://www.efun.com"     --链接
     local shareName            = g_channel_control.serverName or "Tales of Erin"    --名字，默认游戏名
     local sharePicture         = "" --图片url
     local shareDescription     = "this is a message share" --文字内容
     local shareTarget          = data["shareTarget"] or 1 --1 ：WxFriend 2: WxFriendCircle 3:WxFavorite （android Wx分享需要）
    local args = {
        sharePlatformType   = sharePlatformType,
        shareType           = shareType,
        shareUrl            = shareUrl,
        shareName           = shareName,
        sharePicture        = sharePicture,
        shareDescription    = shareDescription,
        shareTarget         = shareTarget
    }
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        local args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        -- zc.luaBridgeCall(EfunSDKManager.EFUNSDK_ANDROID_CLASS,"efunShare",args,sigs)
        zc.share(args)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        zc.luaBridgeCall(EfunSDKManager.EFUNSDK_IOS_CLASS,"efunShare",args,"")
    end 

end

function EfunSDKManager:efunInvitation( ... ) --邀请
    -- local invitationType = 0 -- 0 facebook,1 vk,2 kakao
    -- local args = {
    --     invitationType = invitationType
    -- }
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     local args = {json.encode(args)};
    --     local sigs = "(Ljava/lang/String;)V"
    --     zc.luaBridgeCall(EfunSDKManager.EFUNSDK_ANDROID_CLASS,"efunInvitation",args,sigs)
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     zc.luaBridgeCall(EfunSDKManager.EFUNSDK_IOS_CLASS,"efunInvitation",args,"")
    -- end 
end

function EfunSDKManager:efunShowPlatform( ... ) -- Efun游戏平台
    -- local remark = "扩展参数,选填" 
    -- local args = {
    --     remark = remark
    -- }
    -- local platform = cc.Application:getInstance():getTargetPlatform()
    -- if platform == cc.PLATFORM_OS_ANDROID then
    --     local args = {json.encode(args)};
    --     local sigs = "(Ljava/lang/String;)V"
    --     zc.luaBridgeCall(EfunSDKManager.EFUNSDK_ANDROID_CLASS,"efunShowPlatform",args,sigs)
    -- elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
    --     zc.luaBridgeCall(EfunSDKManager.EFUNSDK_IOS_CLASS,"efunShowPlatform",args,"")
    -- end 
end

function EfunSDKManager:efunTrackEventNameAndType( eventID )

    if eventID == nil or EfunTrackEvent[eventID] == nil then
        LogManager.showSimpMsgDebug("error-------efunTrackEventNameAndType:ID:"..tostring(eventID))
        return nil,nil
    end

    local eventName_key = "eventName_ios"
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        eventName_key = "eventName_android"
    end

    local name = EfunTrackEvent[eventID][eventName_key]
    local eType = EfunTrackEvent[eventID]["eventType"]
    print("eventID:"..tostring(eventID).."....eventName:"..tostring(name).."......eType:"..tostring(eType))
    return name,eType 
end

    -- local event = {
    --     eventID            = "purchaseBegin", --除了purchaseBegin和purchaseEnd，其他类型不需要价格和pid
    --     eventPurchasePrice = "99.99",
    --     eventPurchasePid   = "smshd.sm.1usd"
    -- }   
function EfunSDKManager:efunTrackEvent( data ) --SDK数据追踪
    print("EfunSDKManager:efunTrackEvent")
    dump(data,"efunTrackEvent.data")
    LogManager.showSimpMsgDebug("efunTrackEvent:"..tostring(data.eventID))

    if data == nil then
        data = {}
        print("error-------EfunSDKManager:efunTrackEvent")
        return
    end
    if EfunSDKManager.roleLogin ~= true then
        EfunSDKManager:efunRoleLogin()
    end
    local eventID = data.eventID 
    local eventName,eventType = EfunSDKManager:efunTrackEventNameAndType(eventID)
    if eventName == nil then
        print("error-------EfunSDKManager:efunTrackEvent...eventID:"..tostring(eventID))
        return
    end
    local level = data.level or user_info["rank"]

    local roleId                = tostring(user_info["id"]) or "392DJ4C8E"
    local roleLevel             = tostring(level)
    local eventPurchasePrice    = tostring(data.eventPurchasePrice)
    local eventPurchasePid      = tostring(data.eventPurchasePid)
    local args = {
         eventType          = eventType,
         eventName          = eventName,
         roleId             = roleId,
         roleLevel          = roleLevel,
         eventPurchasePrice = eventPurchasePrice,
         eventPurchasePid   = eventPurchasePid
    }
    local platform = cc.Application:getInstance():getTargetPlatform()
    if platform == cc.PLATFORM_OS_ANDROID then
        if eventType == 3 or eventType == 4 then
            --支付打点android不需要
            return
        end
        local args = {json.encode(args)};
        local sigs = "(Ljava/lang/String;)V"
        zc.luaBridgeCall(EfunSDKManager.EFUNSDK_ANDROID_CLASS,"efunTrackEvent",args,sigs)
    elseif (platform == cc.PLATFORM_OS_IPHONE or platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_MAC) then
        zc.luaBridgeCall(EfunSDKManager.EFUNSDK_IOS_CLASS,"efunTrackEvent",args,"")
    end 

end