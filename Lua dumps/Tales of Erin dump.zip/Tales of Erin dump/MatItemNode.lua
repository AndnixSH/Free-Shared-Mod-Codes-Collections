--require "XUICellView"

MatItemNode = class("MatItemNode", XUICellView)
MatItemNode.CS_FILE_NAME = "MatItemNode.csb"
MatItemNode.CS_BIND_TABLE = 
{
    Image_icon = "/i:111/i:114",
    Image_icon_Rarity = "/i:111/i:115",
    lbName = "/i:111/i:118",
    lbNumNeed = "/i:111/i:119",
    lbNumCur = "/i:111/i:175",
    touchPanel = "/i:338",
}
MatItemNode.IconPath = "icons/mat/"

function MatItemNode:init(...)
    MatItemNode.super.init(self,...)

    self.touchPanel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)

    return self
end

-- function MatItemNode:onResetData()
--     if not self._data then return end
--     self:SetMatId(self._data[1])
--     self:SetMatNumNeed(tonumber(self._data[2]))
--     local nMatBagNum = 0
--     if user_info["bag"]["mat"]["mat_"..self._data[1]] then
--         nMatBagNum = user_info["bag"]["mat"]["mat_"..self._data[1]]
--     end
--     if nMatBagNum then
--         self:SetMatNumCur(nMatBagNum)
--     end
-- end
function MatItemNode:refresh()
    if not self.nMatId then
        return
    end
    if mat[self.nMatId] then
        self.matData = mat[self.nMatId]
    end
    
    self:RefreshIcon()
    self:RefreshName()
end

function MatItemNode:RefreshIcon()
    if not self.nMatId then
        return
    end
    if not self.matData then
        return
    end
    local iconImagePath = self.matData.icon
    if iconImagePath then
        local path = self.IconPath..iconImagePath
        if self.Image_icon then
            self.Image_icon:setUnifySizeEnabled(true)
            self.Image_icon:loadTexture(path)
        end
        
    end

    local rform = Rarity_mat[self.matData["rarity"]]   --外框
    if rform then
        self.Image_icon_Rarity:loadTexture(rform)
    end
end

function MatItemNode:RefreshName()
    if not self.nMatId then
        return
    end
    if not self.matData then
        return
    end
    local sName = UITool.getUserLanguage(self.matData.name)  --self.matData.name
    if sName then
        self.lbName:setString(sName)
    end
end

function MatItemNode:RefreshNumNeed()
    if not self.nMatNumNeed then
        return
    end
    self.lbNumNeed:setString("/"..self.nMatNumNeed)
end

function MatItemNode:RefreshNumCur()
    if not self.nMatNumCur then
        return
    end
    self.lbNumCur:setString(self.nMatNumCur)

    if self.nMatNumNeed then
        if self.nMatNumCur < self.nMatNumNeed then
            --红色
            self.lbNumCur:setColor(cc.c3b(255, 0, 0))
        else
            --普通色
            self.lbNumCur:setColor(cc.c3b(255, 255, 255))
        end
    end

end

function MatItemNode:SetMatId(nMatId)
    self.nMatId = nMatId
    self:refresh()
end

function MatItemNode:SetMatNumNeed(nMatNumNeed)
    self.nMatNumNeed = nMatNumNeed
    self:RefreshNumNeed()
end

function MatItemNode:SetMatNumCur(nMatNumCur)
    self.nMatNumCur = nMatNumCur
    self:RefreshNumCur()
end






