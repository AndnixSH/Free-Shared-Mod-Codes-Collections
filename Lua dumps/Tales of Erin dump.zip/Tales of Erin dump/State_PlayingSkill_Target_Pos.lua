--释放State_PlayingSkill_Target_Pos技能中。(打某个或全体的初始位置及周围，目前只支持选中一个)
--注：State_PlayingSkill_Scene和State_PlayingSkill_Target中打全体的区别，前者在场景播放特效，后者在目标身上或初始位置播放特效
--created by kobejaw.2018.4.27.

--判定：
--target_type 1.自己。2.按条件从我方选择。3.按条件从敌方选择
--target_num 作用数量。0，表示全体。
--target_property 0.距离 1.血量 2.防御 3.攻击 4.随机
--target_p_type 0和1.选取目标所在的位置（范围攻击，使用hit_rect）。 3.选取目标(注意：如果不是target_type为1或者target_num为0的情况，优先判定这个，这个牵扯到场景或者飞行特效是在固定位置还是目标身上播放)
--sort_type 排序方式。0升序 1降序

--注意：不要滥用target_p_type。大部分时候你需要配成3而不是0。典型的配成0的情况是：对随机一个单位及其周围造成伤害。
--注意：target_p_type为0或者1的时候，目前只支持选择一个单位，不支持多个。
--target_p_type为3的时候，受影响对象在放技能之前就知道了。target_p_type为0的时候，受影响的对象需要依靠fly特效做碰撞检测。

State_PlayingSkill_Target_Pos = class("State_PlayingSkill_Target_Pos",StateBase)

function State_PlayingSkill_Target_Pos:ctor(entity) --处理方式类似于Attacking状态中的爆炸类型的普通攻击
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.PlayingSkill_Target
	self.entitiesEffected = {}       --受影响的entity列表
	self.isSkill = true
end

function State_PlayingSkill_Target_Pos:Enter(skillInfo)
	self.skillInfo = skillInfo;
	self.skillInfo.target_num = 1--对某单位及其周围造成伤害的情况，目前只支持1个。
	self.entitiesEffected = {}       --受影响的entity列表
	self.super.Enter(self)	
end

function State_PlayingSkill_Target_Pos:Exit()
	self.super.Exit(self)
end

function State_PlayingSkill_Target_Pos:onSpineEventCallback(event)

	--震屏，闪烁等处理
	self:dealWithCommonEvents(event,self.skillInfo)

	--"autoplay"事件
	result1 = self:checkIsAutoplayEvent(event)
	if result1 then
		if self.skillInfo.res_scene ~= "" then
			self:playSceneEffect()
		elseif self.skillInfo.res_fly ~= "" then	
			self:playFlyEffect()
		end
	end

	--注："attack"和击飞等事件一定只出现在autoplay里。
	--也可能出现在 attack里，这一类应该是State_PlayingSkill_Target_Entity。配错情况的太多了，暂时只能程序做兼容了。
	local result1,result2 = self:checkIsAttackEvent(event,self.skillInfo)
	if result1 then
		--兼容性处理，理论上角色身上不会有attack事件。
		self:compatibilityProcessing(result2,event)
	end

	--"cutin"事件
	local result_cutin = self:checkIsCutInEvent(event)
	if result_cutin == 1 then
		G_GameState = 3
		SkillUtil:playCutIn(self.entity)
		if not self.entity.isBoss then
			ActiveSkillManager:refreshSkillWhenCutIn(self.entity.skill[2])
		end
	elseif result_cutin == 2 then
		SkillUtil:playEndCutIn(self.entity)
	end
end

function State_PlayingSkill_Target_Pos:dealWithAttackEvent(event,idx,pos)
	if self.entity.isDead then
		return
	end

	local hitData = self.skillInfo.skillData.skill_attack_hit[idx]
	if not hitData then
		print("配错表了，State_PlayingSkill_Target_Pos:dealWithAttackEvent")
		return
	end

	if hitData.hit_type >= 1 then
		print("target_p_type配错了，应该改成3。技能ID:  "..self.skillInfo.skillId)
		return
	end

	local hit_rect = hitData.hit_rec

	local x = ThreeMeshOperation(pos.x,pos.x,0)
	local y = ThreeMeshOperation(pos.y,pos.y,0)

	local hit_rect_x = x + hit_rect[1]
	local hit_rect_y = y + hit_rect[2]
	local hit_rect_w = hit_rect[3]
	local hit_rect_h = hit_rect[4]
	local damageRange = cc.rect(hit_rect_x, hit_rect_y, hit_rect_w, hit_rect_h)

	local attackedList = self:generateAttackedList(damageRange,cc.p(x,y),self.skillInfo,hitData)

	for k,v in pairs(attackedList) do
		self:onCauseDamage(1,self.entity,v,event,self.skillInfo.skillData,idx)
	end
end

--在目标所在位置播放，不随目标的移动而变化
function State_PlayingSkill_Target_Pos:playSceneEffect()
	if self.skillInfo.res_scene == "" or self.entity.isDead then
		return
	end

	local temp = self:generateEffectedListForTargetSkill()
	local target = temp[1]
	if target == nil then
		return
	end

	local targetPos
	if target.fsm.currentState.stateEnum == StateEnum.UnusualCondition then
		targetPos = cc.p(target:getPositionX(),target.fsm.currentState.initial_y)
	else
		targetPos = cc.p(target:getPosition())
	end

	local effectSpineNode = CreateEffectSpineNode(self.skillInfo.res_scene)
	table.insert(G_NodesWithSpine,effectSpineNode)
	G_EffectLayer:addChild(effectSpineNode)  --锁定目标的初始位置
	effectSpineNode:setPosition(targetPos)

	local this = self;
	local function eventCallback(event)
		--震屏，闪烁等处理
		this:dealWithCommonEvents(event,this.skillInfo)

		local result1,result2
		--"autoplay"事件，目标类技能的场景特效里只可能出现autoplay事件,不可能出现attack事件
		result1 = this:checkIsAutoplayEvent(event)
		if result1 then
			this:playFlyEffect(targetPos)
		end

		--attack事件。策划配错表的容错处理，例如IA的1技能。这里本来不该有attack事件的。
		result1,result2 = this:checkIsAttackEvent(event)
		if result1 then
			this:dealWithAttackEvent(event,result2,targetPos)
		end
	end

	effectSpineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
	RemoveEffectOnComplete(effectSpineNode)	
end

--@type  1:由角色身上触发。2.由场景特效触发。
function State_PlayingSkill_Target_Pos:playFlyEffect(pos)
	if self.skillInfo.res_fly == "" or self.entity.isDead then
		return
	end

	local targetPos
	if pos == nil then
		local temp = self:generateEffectedListForTargetSkill()

		local target = temp[1]
		if target == nil then
			return
		end
		if target.fsm.currentState.stateEnum == StateEnum.UnusualCondition then
			targetPos = cc.p(target:getPositionX(),target.fsm.currentState.initial_y)
		else
			targetPos = cc.p(target:getPosition())
		end
	else
		targetPos = pos
	end

	local effectSpineNode = CreateEffectSpineNode(self.skillInfo.res_fly)
	table.insert(G_NodesWithSpine,effectSpineNode)
	G_EffectLayer:addChild(effectSpineNode)  --锁定目标的初始位置
	effectSpineNode:setPosition(targetPos)

	local this = self;
	local function eventCallback(event)
		--震屏，闪烁等处理
		this:dealWithCommonEvents(event,this.skillInfo)

		--attack事件
		local result1,result2 = this:checkIsAttackEvent(event)
		if result1 then
			this:dealWithAttackEvent(event,result2,targetPos)
		end
	end

	effectSpineNode:registerSpineEventHandler(eventCallback,sp.EventType.ANIMATION_EVENT)
	RemoveEffectOnComplete(effectSpineNode)
end

function State_PlayingSkill_Target_Pos:onSpineCompleteCallback(event)
	if self.entity.isBoss then
		self.entity.fsm:changeState(StateEnum.Attacking_Boss)
	else
		--技能释放完毕。切换到RunningToEnemy状态
		local data = {}
		data.type = 1;
		self.entity.fsm:changeState(StateEnum.RunningToEnemy,data)		
	end
end

------------------------------策划配错表的兼容性处理------------------------------

--针对target_p_type本应该配成3却配成了0或者1的情况，这类错误的数量太大了只能做兼容性处理。处理成target_p_type为3的情况。
function State_PlayingSkill_Target_Pos:compatibilityProcessing(idx,event)
	if self.entity.isDead then
		return
	end

	print("target_p_type配错了，应该改成3。技能ID:  "..self.skillInfo.skillId)

	self.entitiesEffected = self:generateEffectedListForTargetSkill()

	for k,v in ipairs(self.entitiesEffected) do
		self:dealWithAttackEvent_OneTarget(idx,v,event)
	end
end

--兼容性处理，粘贴过来的State_PlayingSkill_Target_Entity类的同名函数
function State_PlayingSkill_Target_Pos:dealWithAttackEvent_OneTarget(idx,target,event)
	--注：如果hit_num>1,则在目标身上爆炸，而且是范围攻击。治疗和buff类的一定是1.但是很多都配成了100.强制纠正成1.

	local hitData = self.skillInfo.skillData.skill_attack_hit[idx]
	if not hitData then
		print("配错表了，State_PlayingSkill_Target_Pos:dealWithAttackEvent_OneTarget")
		return
	end

	--治疗音效
	if hitData.hit_type == 1 and not self.isHealSoundPlayed then
		self.isHealSoundPlayed = true
		BattlePlaySound(BattleGlobals.Sound_Heal,false,0)
	end

	--治疗类或buffdebuff类
	if hitData.hit_type >= 1 then
		self:onCauseDamage(1,self.entity,target,event,self.skillInfo.skillData,idx)
		return
	end

	--伤害类
	local hit_num = hitData.hit_num
	if hit_num == 1 then
		self:onCauseDamage(1,self.entity,target,event,self.skillInfo.skillData,idx)
	else
		--在目标身上爆炸，范围攻击
		local attackedList = {}

		local posx,posy = target:getPosition()

		local hit_rect = hitData.hit_rec
		local hit_rect_x = posx-hit_rect[3]/2
		local hit_rect_y = posy-hit_rect[4]/2
		local hit_rect_w = hit_rect[3]
		local hit_rect_h = hit_rect[4]
		local damageRange = cc.rect(hit_rect_x, hit_rect_y, hit_rect_w, hit_rect_h)

		local attackedList = self:generateAttackedList(damageRange,cc.p(posx,posy),self.skillInfo,hitData)

		for k,v in pairs(attackedList) do
			self:onCauseDamage(1,self.entity,v,event,self.skillInfo.skillData,idx)
		end
	end
end
