--require "XUIView"

SoulEquipInfoView = class("SoulEquipInfoView",XUIView)
SoulEquipInfoView.CS_FILE_NAME = "SoulEquipInfoView.csb"
SoulEquipInfoView.CS_BIND_TABLE = 
{
    panelList = "/i:87/i:868",
    spSoulEquipIconImage = "/i:87/i:848/i:11",
    lbSoulEquipName = "/i:87/i:848/i:14",
    --
    lbSubStageNum = "/i:87/i:808/i:108",
    barAtk = "/i:87/i:808/i:109",
    barHP = "/i:87/i:808/i:110",
    barAtkAdd = "/i:87/i:808/i:1069",
    barHPAdd = "/i:87/i:808/i:1070",

    lbNumAtk = "/i:87/i:808/i:111",
    lbNumHP = "/i:87/i:808/i:112",
    lbNumAtkAdd = "/i:87/i:808/i:1071",
    lbNumHPAdd = "/i:87/i:808/i:1072",

    lbCurLv = "/i:87/i:808/i:113",
    lbMaxLv = "/i:87/i:808/i:114",
    lbExpNext = "/i:87/i:808/i:115",
    barExp = "/i:87/i:808/i:116",
    --
    spSublStage1 = "/i:87/i:808/i:102/i:202",
    spSublStage2 = "/i:87/i:808/i:103/i:204",
    spSublStage3 = "/i:87/i:808/i:104/i:206",
    spSublStage4 = "/i:87/i:808/i:105/i:208",
    spSublStage5 = "/i:87/i:808/i:106/i:210",
    --
    skDescPanel = "/i:87/i:1755",
    lbSkillDesc = "/i:87/i:1755/i:1758",
}

SoulEquipInfoView.curClickedSkillId = 0
SoulEquipInfoView.curSkillDescState = false

function SoulEquipInfoView.createWithBackBtn()
    local v = SoulEquipInfoView.new():init()
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function SoulEquipInfoView:init(nHeroId)
    SoulEquipInfoView.super.init(self)
    
    self.hero_id = nHeroId

    self.spSoulEquipIconImage:setVisible(false)
    self.lbSoulEquipName:setString("")
    self.lbSubStageNum:setString("")
    if g_channel_control.RoleInfoView_stateAwkNumPos == true then
        self.lbSubStageNum:setPosition(cc.p(189,609))
    end
    self.barAtk:setPercent(0)
    self.barHP:setPercent(0)
    self.barAtkAdd:setPercent(0)
    self.barHPAdd:setPercent(0)

    self.lbNumAtk:setString("")
    self.lbNumHP:setString("")
    self.lbNumAtkAdd:setString("")
    self.lbNumHPAdd:setString("")

    self.lbCurLv:setString("")
    self.lbMaxLv:setString("")
    self.lbExpNext:setString("")
    self.barExp:setPercent(0)
    
    for i = 1,5 do
        self["spSublStage"..i]:setVisible(false)
    end

    self.skDescPanel:setVisible(false)
    



    

    --魂灵装ID
    self.curSoulEquipId = tonumber(getNumID(self.hero_id))
    print("SoulEquipInfoView:init== curSoulEquipId:"..self.curSoulEquipId)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,560,100)
    self.gridview.itemCreateEvent = function()
        local temp = SoulEquipSkillItemView.new():init()

        -- temp.ClickEvent = function(item)            
        --     local skillid = self._data
        --     self:SkillClicked(skillid)
        -- end
        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end
        temp.onResetData = function(self)
            local skilldata = _data
            local IsHave = self._data["isHaved"]
            local skillid = self._data["skillId"]
            local index = self._data["index"]
            temp:SetSkillId(skillid)
            temp:SetIsHavedSkill(IsHave)
            temp:SetSkillIndex(index)
        end
        return temp
    end

    return self
end

function SoulEquipInfoView:FillSoulEquipData(rcvData)
    if rcvData then
        self.Se_info = table.deepcopy(rcvData)
        self.skList = table.deepcopy(rcvData["skills"])
    end
end

--获取已有技能数据
function SoulEquipInfoView:getDataSrouce()
    local ds = {}
    if self.skList then
        ds = self.skList
    end
    return ds
end

--获取全部技能数据
function SoulEquipInfoView:getAllDataSrouce()
    local ds = {}
    local soul_break = table.deepcopy(self.hero_soul_info["soul_break"])
    if soul_break then
        local nTotalBreak = soul_break.total_break
        local nSkillId = 0
        for i=0,nTotalBreak do
            if soul_break["break_"..i] then
                nSkillId = soul_break["break_"..i].skill_unlock
                if nSkillId ~= 0 then
                    local data = {}
                    data["skillId"] = nSkillId
                    data["isHaved"] = self:IsHavedSkill(nSkillId)
                    data["index"] = i
                    table.insert(ds,data)
                end
            end
        end
    end
    return ds
end

--
function SoulEquipInfoView:IsHavedSkill(nSkillId)
    if not self.skList then
        return false
    end
    local IsHave = false
    local SkillsHaved = self.skList
    for i=1,#SkillsHaved do
        if SkillsHaved[i] == nSkillId then
            IsHave = true
        end
    end
    return IsHave
end

function SoulEquipInfoView:SkillClicked(nSkillId)
    local id = item:getData().id
    if nSkillId ~= self.curClickedSkillId then
        self:refreshSkDescPanel(nSkillId,true)
    else
        if self.curSkillDescState then
            self:refreshSkDescPanel(nSkillId,false)
        end
    end
end

function SoulEquipInfoView:onItemClicked(item)
    local nSkillId = item:getData()["skillId"]
    if nSkillId ~= self.curClickedSkillId then
        self:refreshSkDescPanel(nSkillId,true)
        self.curClickedSkillId = nSkillId
    else
        self:refreshSkDescPanel(nSkillId,false)
        -- if self.curSkillDescState then
        --     self:refreshSkDescPanel(nSkillId,false)
        -- end
    end
end

function SoulEquipInfoView:ShowSkDescPanel(bShow)
    if not self.skDescPanel then
        return 
    end
    self.skDescPanel:setVisible(bShow)
    self.curSkillDescState = bShow
    if bShow == false then
        self.curClickedSkillId = 0
    end
end

function SoulEquipInfoView:refreshSkDescPanel(nSkillId,bShow)
    if not self.skDescPanel then
        return 
    end
    print("SoulEquipInfoView:refreshSkDescPanel==nSkillId"..nSkillId)
    print("SoulEquipInfoView:refreshSkDescPanel==nSkillId"..passive_sk[nSkillId].sk_det_des)
    self.lbSkillDesc:setString(""..UITool.getUserLanguage(passive_sk[nSkillId].sk_det_des))

    self:ShowSkDescPanel(bShow)
end

function SoulEquipInfoView:refresh()
    self:refreshStates()
end

-- # ■ [装备详情]* hero_soul_info
-- #  "hero_id": "1*1299656990",  #对应的角色ID
-- #返回:
-- data = {
--  "state_code": 1,
--  "hero_soul": {
--         # 装备唯一id
--         "2*1299656992": {
--             "state":1,
--             "hp":108,
--             "atk":50,
--             "Lv": 1,
--             "Lv_max":50,
--             "exp": 0,
--             "exp_max": 100,
--             "break_count": 0,
--             "add_hp":0,
--             "add_atk":0,
--             "skills": [ ],
--         },
--     }, 
-- }

function SoulEquipInfoView:refreshStates()
    if not self.Se_info then
        print("SoulEquipInfoView:refreshStates not self.Se_info")
        return
    end

    if not hero_soul[self.curSoulEquipId] then
        print("SoulEquipInfoView:refreshStates not hero_soul[self.curSoulEquipId]")
        return
    end

    --升华阶段
    local nSublStageCount = tonumber(self.Se_info["break_count"])
    for i = 1,5 do
        self["spSublStage"..i]:setVisible(nSublStageCount >=i)
    end
    
    --根据魂灵装ID取本地数据
    self.hero_soul_info = hero_soul[self.curSoulEquipId]
    --魂灵装名称
    self.lbSoulEquipName:setString(self.hero_soul_info.name)
    --魂灵装Icon(需根据不同升华阶段取不同Icon--目前为唯一Icon 为后续需求变更做准备)
    local face = self.hero_soul_info["soul_break"]["break_"..nSublStageCount].icon_big
    if face then
        print("Icon_Info===SoulEquipInfoView:refreshStates===face:"..face)
        self.spSoulEquipIconImage:setTexture("icons/soulequip/vdrawing/"..face)
        self.spSoulEquipIconImage:setVisible(true)
    end

    --基本数据属性
    local nAtk = self.Se_info["atk"] + self.Se_info["add_atk"]
    local nHp = self.Se_info["hp"] + self.Se_info["add_hp"]
    local nHpMax = self.hero_soul_info["soul_break"]["break_"..nSublStageCount]["hp_max"]
    local nAtkMax = self.hero_soul_info["soul_break"]["break_"..nSublStageCount]["atk_max"]

    self.lbNumAtk:setString(nAtk)
    self.lbNumHP:setString(nHp)
    --
    -----======技能加成======-----
    if self.Se_info["ex_hp"] ~= nil then
        --服务器下发数据
        if self.Se_info["ex_hp"] > 0 then
            self.lbNumHPAdd:setString("+"..self.Se_info["ex_hp"])
            self.barHPAdd:setPercent((nHp + self.Se_info["ex_hp"])/ nHpMax * 100)
        else
            self.lbNumHPAdd:setString("")
            self.barHPAdd:setPercent(0)
        end
    else
        --服务器未下发数据
        self.lbNumHPAdd:setString("")
        self.barHPAdd:setPercent(0)
    end

    if self.Se_info["ex_atk"] ~= nil then
        --服务器下发数据
        if self.Se_info["ex_atk"] > 0 then
            self.lbNumAtkAdd:setString("+"..self.Se_info["ex_atk"])
            self.barAtkAdd:setPercent((nAtk + self.Se_info["ex_atk"])/ nAtkMax * 100)
        else
            self.lbNumAtkAdd:setString("")
            self.barAtkAdd:setPercent(0)
        end
    else
        --服务器未下发数据
        self.lbNumAtkAdd:setString("")
        self.barAtkAdd:setPercent(0)
    end
    -----======技能加成======-----

    self.lbCurLv:setString(string.format(UITool.ToLocalization("等级:%d"),self.Se_info["Lv"]))
    self.lbMaxLv:setString(UITool.ToLocalization("最大等级:")..self.Se_info["Lv_max"])
    local nExpNeed = self.Se_info["exp_max"] - self.Se_info["exp"]
    self.lbExpNext:setString(UITool.ToLocalization("离下一级：")..nExpNeed)
    self.lbSubStageNum:setString(self.Se_info["break_count"].."/5") --目前满升阶段固定 TODO：需要做成数据可变
    self.barExp:setPercent(self.Se_info["exp"] / self.Se_info["exp_max"] * 100)


    self.barAtk:setPercent((self.Se_info["atk"] + self.Se_info["add_atk"]) / nAtkMax * 100) --
    self.barHP:setPercent((self.Se_info["hp"] + self.Se_info["add_hp"]) / nHpMax * 100) --
    

    
    --技能信息列表
    self.currentDataSource = nil
    self.currentDataSource = self:getAllDataSrouce()
    self.gridview:setDataSource(self.currentDataSource)
end