--[[
KeyboardManager.lua
--【【
说明：
    1、所有界面必须 创建界面的时候注册返回键
    KeyboardManager:registeredKeyBoardEvent(self,function ()
        —body—这里不做处理的话，就只监听不处理，按返回键没有反应
        —-self:returnBack()
    end)
    2、clear：
    移除界面的时候，需要删除监听
    KeyboardManager:removeKeyBoardEvent()

--战斗开始的时候设置_isStartBattle true ，回来的时候设置为false
--新手引导阶段不处理返回键
    
    

]]

KeyboardManager = {}

--用于初始化，恢复初始化
function KeyboardManager:init()
	self._keyBoardListener = nil
	self._isDeal = true --是否处理返回键特殊情况下需要关闭
    self._isStartBattle = false --如果开始战斗。需要屏蔽返回键
    self._isShowStory = false --剧情
    self._isShowNotice = false --公告
    self._isShowGuidePic = false --图片引导
    self._isShowEffect = false --特效屏蔽
    self._isShowWaitLayer = false --请求等待蒙版
	self._users = {}
end
---绑定按钮home back 键
-- 绑定到scene上面，需要多次绑定，更换scene的时候
-- fromID 1 为登陆界面，，2 为mainScene
function KeyboardManager:bindingAndroidKeyboard(scene,fromID)
    --绑定返回键
    if self._keyBoardListener then 
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self._keyBoardListener)
        self._keyBoardListener = nil 
    end 
    local function exitGame()
        if fromID == 2 then 
            GameManagerInst:rpc( 
                {
                    rpc = "game_quit",
                },
                3,
                function(data)
                    print("game_quit success");
                    --success

                end,
                function(state_code,msgText)
                    print("game_quit fail msg: "..msgText);
                    --failed
                end,
            true)
        end 
        cc.Director:getInstance():endToLua()
        --os.exit()
    end 

    local function cancelFunc()
        self.showExit = false
    end

    local function dealExitGamme()
          MsgManager:showSimpMsgWithCallFunc(UITool.ToLocalization("是否退出游戏"),self,exitGame,cancelFunc)
    end

    local function dealBackFuc()
        if g_channel_control.openKeyBack == false then
            return
        end
        if self._isShowWaitLayer then
            return
        end
        --新手引导阶段不处理
        if NewGuideManager.isStart and self.showExit ~= true then 
            --韩服新手引导点击返回键，弹出退出游戏提示框
            self.showExit = true
            dealExitGamme()
            return
        end  
        if NewGuideManager.isStartWeakGuide and self.showExit ~= true then 
             --韩服新手引导点击返回键，弹出退出游戏提示框
            self.showExit = true
            dealExitGamme()
            return
        end 
       
        if self._isShowStory then 
            return 
        end 
        --韩服取消 公告的屏蔽返回键
        -- if self._isShowNotice then 
        --     return
        -- end 
        -- if self._isShowGuidePic then 
        --     return 
        -- end 
        if self._isShowEffect  then 
            return
        end 
             --开始战斗就要返回
        if self._isStartBattle then 
            cc.MyHttpHelper:shareMyHttpHelper():exchangePauseLayer() --自动切换暂停/恢复
            return
        end 

        if fromID == 2 then
            if not self._isDeal then 
                return 
            end 
        	--只有在主场景的时候需要处理后退键盘
        	local topIndex = #self._users
        	if topIndex>0 then 
                --MsgManager:showSimpMsg("KeyboardManager:"..topIndex)
	        	local node = self._users[topIndex]._node
				local func = self._users[topIndex]._func
				if func then 
					func()
				end 
            else 
                dealExitGamme()
        	end 
        else 
            local topIndex = #self._users
            if topIndex>0 then 
                --MsgManager:showSimpMsg("KeyboardManager:"..topIndex)
                local node = self._users[topIndex]._node
                local func = self._users[topIndex]._func
                if func then 
                    func()
                end 
            else 
                dealExitGamme()
            end 
            
            -- dealExitGamme()
        end 
    end 

    local function onKeyReleased(keyCode, event)
        --local label = event:getCurrentTarget()
        if keyCode == cc.KeyCode.KEY_BACK then
            dealBackFuc()
        elseif keyCode == cc.KeyCode.KEY_MENU  then
        end
    end

    self._keyBoardListener = cc.EventListenerKeyboard:create()
    self._keyBoardListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    if scene then 
        local eventDispatcher =  cc.Director:getInstance():getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(self._keyBoardListener, scene)
    end 
end
---设置返回键开启是否失效
function KeyboardManager:setIsDealReturnBack(isDeal)
	self._isDeal = isDeal
end 

function KeyboardManager:setbattleState(isStart)
    self._isStartBattle = isStart
end 

function KeyboardManager:setWaitState(bRet)
    self._isShowWaitLayer = bRet
end 

--清空容器。到首页的时候 todo 回到首页
function KeyboardManager:clearAndReset()
	self._isDeal = true --是否处理返回键特殊情况下需要关闭
    self._isStartBattle = false --如果开始战斗。需要屏蔽返回键
    self._isShowStory = false
    self._isShowNotice = false --公告
    self._isShowGuidePic = false --图片引导
    self._isShowEffect = false
    self._isShowWaitLayer = false
	self._users = {}
end 

function KeyboardManager:getStaticValue(  )
    self.staticValue = self.staticValue or 1
    return self.staticValue
end

--注意添加的话，退出的时候需要移除
function KeyboardManager:registeredKeyBoardEvent(node,func)
    dump("----111111111111111111111111111@@KeyboardManager:registeredKeyBoardEvent:"..node.class.__cname)
    -- self.staticValue = self.staticValue + 1
    local staticVaue = self:getStaticValue()
    self.staticValue = self.staticValue + 1
	local user = {
		_node = node,
        _func = func,
        _staticValue = staticVaue
	}
	self._users[#self._users+1] = user
    return user
end

function KeyboardManager:removeKeyBoardEvent(user)
    -- dump(user, "removeKeyBoardEvent:user")
    -- dump("----@@KeyboardManager:removeKeyBoardEvent:"..#self._users.."   user= "..tostring(user._staticValue))
    for i=1,#self._users do
        print("@@KeyboardManager:  user["..i.."] = "..tostring(self._users[i]).."   name:"..tostring(self._users[i]._node.class.__cname))
        if user and user._staticValue and user._staticValue == self._users[i]._staticValue then
            local testNode = self._users[i]._node 
            dump("----@@KeyboardManager:removeKeyBoardEvent:"..testNode.class.__cname)

            table.remove(self._users,i)
            return
        end
    end
	-- local topIndex = #self._users
 --    if topIndex>0 then 
 --        --testCode
 --        local testNode = self._users[topIndex]._node 
 --        dump("----@@KeyboardManager:removeKeyBoardEvent:"..testNode.class.__cname)

        
 --        table.remove(self._users,topIndex)
 --    end 

    -- local 
end 
