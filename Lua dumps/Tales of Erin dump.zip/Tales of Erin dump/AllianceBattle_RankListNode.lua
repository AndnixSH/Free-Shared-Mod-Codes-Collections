

AllianceBattle_RankListNode = class("AllianceBattle_RankListNode", XUICellView)
AllianceBattle_RankListNode.CS_FILE_NAME = "AllianceBattle_RankListNode.csb"
-- self.curType  1 是玩家排行  2 公会排行
-- 玩家排行和公会排行共用的
AllianceBattle_RankListNode.CS_BIND_TABLE = 
{
    PanelList  = "/s:Panel_1",
    Image_bg   = "/i:306/i:193",
    -- 头像
    headImage  = "/i:306/i:193/s:Image_icon",
    -- 玩家账号
    userId     = "/i:306/i:193/s:Panel_user/s:Text_ID",
    -- 排名
    ranking       = "/i:306/i:193/s:Text_rank",
    -- 玩家名字活公会的名字
    name       = "/i:306/i:193/s:Text_name",
    -- 玩家排行特有的属性 称号panel
    panelUser  = "/i:306/i:193/s:Panel_user",
        -- 玩家称号
    sp           = "/i:306/i:193/s:Panel_user/s:Node_spine",
    -- 公会排行特有的属性会长的名字,
    panelGuild   = "/i:306/i:193/s:Panel_guild",
    -- 会长名字
    PosName    = "/i:306/i:193/s:Panel_guild/s:Text_gName",
    -- 贡献度
    contribution = "/i:306/i:193/s:Text_gxd",
    -- 当前成员
    Text_Max_0 = "/i:306/i:193/s:Panel_guild/s:Image_1/s:Text_Max_0",
    curConut     = "/i:306/i:193/s:Panel_guild/s:Image_1/s:Text_cur",
    MaxConut     = "/i:306/i:193/s:Panel_guild/s:Image_1/s:Text_Max",

    showImageT   = "/i:306/i:193/s:Image_gd",

    
}
-- 设置当前的类型
function AllianceBattle_RankListNode:setType( type )
    -- body
    self.curType = type
end

function AllianceBattle_RankListNode:showImageType( type )
    -- body
    self._showImageType = type
end
function AllianceBattle_RankListNode:init(...)
    AllianceBattle_RankListNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    return self
end
-- 显示称号  玩家排行会显示
function AllianceBattle_RankListNode:showCH( _spineRoot ,chID)
    -- body
                    --称号
    local spineRoot = _spineRoot
    if self.skeletonNode then 
        self.skeletonNode:stopAllActions()
        self.skeletonNode:removeFromParent()
    end 

    local id_str = title_conf[tonumber(chID)].res_spine
    if cc.FileUtils:getInstance():isFileExist(id_str) then 
        local end_pos = string.find(id_str,'atlas') - 1
        local spName = string.sub(id_str,0,end_pos)

        self.skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
        self.skeletonNode:setAnchorPoint(0,0.5)
        self.skeletonNode:setPosition(0,0)
        spineRoot:setAnchorPoint(0,0.5)
        spineRoot:addChild(self.skeletonNode,1000)

        self.skeletonNode:setAnimation(1, "effect", true)
        local dt = cc.DelayTime:create(0.01)
        local cf = cc.CallFunc:create(function()
             ---添加spine
                local size=self.skeletonNode:getBoundingBox()
                print("getBoundingBox width == "..size.width)
                self.skeletonNode:setPosition(size.width/2,0)
        end)
        local seq = cc.Sequence:create(dt,cf)
        spineRoot:runAction(seq)
    else 
        print("文件不存在 error file not exist:"..id_str)
    end
end
-- 显示自己独有属性
function AllianceBattle_RankListNode:showOnlyPer( ... )
    -- body
      if self.curType == 1 then
            self.panelGuild:setVisible(false)
            self.panelUser:setVisible(true)    
      else
            self.panelUser:setVisible(false)
            self.panelGuild:setVisible(true)      
      end
end
-- 设置玩家的数据
function AllianceBattle_RankListNode:userTable(_udata )
    -- body
    if _udata.attack_value  then -- 不等nil的 时候 证明这个是从极限挑战排行进来的
        _udata.contribution = _udata.attack_value
    end 
    local dtable = {
        ["uid"]           = _udata.uid,           -- 玩家ID
        ["name"]          = _udata.name,          -- 玩家名称
        ["position"]      = _udata.position,      -- 公会的位置      
        ["rank"]          = _udata.rank,          -- 玩家等级
        ["head"]          = _udata.head,          -- 玩家头像
        ["ranking"]       = _udata.ranking,       -- 玩家排行
        ["contribution"]  = _udata.contribution,   -- 贡献度
        ["title_id"]      = _udata.title_id ,      -- 称号
    }
    if user_info["id"] == dtable["uid"] then
        self.Image_bg:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_002.png")
    else
        self.Image_bg:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_001.png")
    end
    -- 设置显示自己独有的属性
    self:showOnlyPer()
    -- 玩家Id
    self.userId:setString(dtable.uid)
    -- 
    -- 玩家排行
    self.ranking:setString(tostring(dtable.ranking))
    self.ranking:setVisible(true)
    -- 设置玩家头像
    local heroid  = tonumber(dtable["head"])
    self.headImage:setUnifySizeEnabled(true)
    self.headImage:loadTexture(hero[heroid].hero_bat_icon)
    -- 设置称号
    self:showCH(self.sp,dtable.title_id)
    -- 玩家的名字
    self.name:setString(dtable.name)
    -- 贡献度
    self.contribution:setString(tostring(dtable.contribution))
    --print("self.ImageType  self.ImageType =="..self.ImageType)
    if self._showImageType  then
        if self._showImageType  == 1 then -- 个人积分
            self.showImageT:loadTexture("n_UIShare/UltimateChallenge/jxtz_ui_002.png") 
        elseif self._showImageType  == 2 then -- 最高伤害
            self.showImageT:loadTexture("n_UIShare/UltimateChallenge/jxtz_ui_001.png")
        end
        
    else
       print("nil nil ni l") 
    end

    local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    self:switchPlayerInfoLayer(dtable.uid,dtable.head)
                end
            end
    end 
    self.PanelList:addTouchEventListener(touchCallBack)
end

function AllianceBattle_RankListNode:switchPlayerInfoLayer( id,head )
    -- body
    local rcvData = {}
    local info = {}
    if g_channel_control.b_XbPlayerInfoView == true then
        info["ui_from"] = PlayerInfoSys.EUiType.guild
        info["uid"] = id
        rcvData["info"] =  info
    else
        info["fromType"] = 4   -- 1、查看会内成员 2、申请列表查看信息  3、查看其它公会的成员信息
        info["m_position"] = nil   --self.GuildMemberTable["tab"][index]["position"], --自己的公会职位
        info["other_infos"] = {}    --要查看对象的信息
        info["other_infos"]["uid"] = id
        info[other_infos]["head"] = head
        rcvData["info"] =  info
    end
    SceneManager:toPlayerInfoLayer(rcvData)
end

--设置公会数据
function AllianceBattle_RankListNode:guildTable( _udata )
    -- body
    print("self.curType == "..self.curType)
    local dtable = {
        ["id"]            = _udata.id,              -- 公会ID
        ["name"]          = _udata.name,            -- 公会名称
        ["image"]         = _udata.image,           -- 公会头像     
        ["ranking"]       = _udata.ranking,        -- 公会排行
        ["contribution"]  = _udata.contribution,   -- 贡献度
        ["chairman"]      = _udata.chairman ,      -- 会长的名字
        ["mem_num"]       = _udata.mem_num ,       -- 成员数量
     }
    if user_info["id"] == dtable["id"] then
        self.Image_bg:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_002.png")
    else
        self.Image_bg:loadTexture("uifile/n_UIShare/Ranklist/phb_ui_001.png")
    end
    -- 设置显示自己独有的属性
    self:showOnlyPer()
    -- 公会排行
    self.ranking:setString(tostring(dtable.ranking))
    self.ranking:setVisible(true)
    -- 公会的名字
    self.name:setString(dtable.name)
    -- 贡献度
    self.contribution:setString(tostring(dtable.contribution))
    -- 会长的名字
    self.PosName:setString(dtable.chairman)

    if g_channel_control.transform_AllianceBattle_RankListNode_Text_Max_0_pos == true then
        local oldX = 76--self.Text_Max_0:getPositionX()
        local newX = oldX - 30
        self.Text_Max_0:setPositionX(newX)
    end

    local curNum  = UITool.SubStringToInt( dtable["mem_num"],"/",1)
    local MaxNum  = UITool.SubStringToInt( dtable["mem_num"],"/",2)
    self.curConut:setString(tostring(curNum))
    self.MaxConut:setString("/"..MaxNum)

    local heroid  = tonumber(dtable["image"])
    self.headImage:setUnifySizeEnabled(true)
    self.headImage:loadTexture(hero[heroid].hero_bat_icon)
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    local rData = {}
                    rData["guildData"] = dtable  
                    rData["guild_id"]  = dtable.id
                    rData["GuildType"] = 2-- 1 推荐公会  2 公会排行
                    -- self.rData["callFunc"]  = self.refreshUI
                    -- self.rData["self"]      = self
                    rData["isGuild"]  = true
                    SceneManager:toGuildBaseInfoLayer(rData)
                end
            end
    end 
    self.PanelList:addTouchEventListener(touchCallBack)

    print("curNum  curNum curNum == "..curNum)
    print("MaxNum  MaxNum MaxNum == "..MaxNum)
end
function AllianceBattle_RankListNode:onResetData()
     print("第一步  执行 GuildMemberItemNode onResetData")
     if not self._data then return end
      local  panelP    = self.PanelList
      if self.curType == 1 then
        self:userTable(self._data)
      elseif self.curType == 2 then
        self:guildTable(self._data)
      end
     if self.resetDataEvent then
        self.resetDataEvent(self)
     end

end




