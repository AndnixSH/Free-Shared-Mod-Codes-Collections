princess_ocp = {} 
princess_ocp["warrior"] = {
   p_icon = "ui/princess/gzzy_lp_wa_1.png",
   p_icon_h = "ui/princess/gzzy_lp_wa_1_1.png",
   p_bg = "ui/princess/gzzy_ui_015.png",
   p_jl = "icons/role/prin_vdraw/sg_jl_ui_wa.png",--解锁，经验数值
   p_sh = "icons/role/prin_vdraw/sg_sh_ui_wa.png",--详细介绍
   p_name = "56327", 
   warrior_1 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_wa_1c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_wa_1.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_wa_1.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_wa_1.png",--短名称图片
       ps_des  = "56307",--描述
       ps_short_des  = "56315",--短描述
       ps_desName  = "56291",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_wa_1xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56299",
       ps_vedio = "music/vedio/nvzhu2.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu2.jpg",--短视频
       ps_pre = "",--前置职业头像
       ps_buy = 50, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_wa_1.png", --城技能图标
                       sk_des  = "114939", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_wa1_1.png", --被动技能图标
                               sk_name = "121265",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124239", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_wa1_2.png", --被动技能图标
                               sk_name = "121266",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124240", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
   warrior_2 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_wa_2c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_wa_2.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_wa_2.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_wa_2.png",--短名称图片
       ps_des  = "56308",--描述
       ps_short_des  = "56316",--短描述
       ps_desName  = "56292",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_wa_2xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56300",
       ps_vedio = "music/vedio/nvzhu2.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu2.jpg",--短视频
       ps_pre = "icons/role/prin_vdraw/nzxx_ui_011.png",--前置职业头像
       ps_buy = 150, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_wa_2.png", --城技能图标
                       sk_des  = "114940", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_wa2_1.png", --被动技能图标
                               sk_name = "121267",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124241", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_wa2_2.png", --被动技能图标
                               sk_name = "121268",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124242", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                       [3] = { sk_icon = "icons/skill/gzzy_sk_wa2_3.png", --被动技能图标
                               sk_name = "121269",
                               sk_unlock_lv = 15, -- 解锁等级
                               sk_des = "124243", --描述
                               sk_lock = "需要15级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
} 
princess_ocp["lancer"] = {
   p_icon = "ui/princess/gzzy_lp_la_1.png",
   p_icon_h = "ui/princess/gzzy_lp_la_1_1.png",
   p_bg = "ui/princess/gzzy_ui_015.png",
   p_jl = "icons/role/prin_vdraw/sg_jl_ui_la.png",--解锁，经验数值
   p_sh = "icons/role/prin_vdraw/sg_sh_ui_la.png",--详细介绍
   p_name = "56328", 
   lancer_1 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_la_1c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_la_1.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_la_1.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_la_1.png",--短名称图片
       ps_des  = "56309",--描述
       ps_short_des  = "56317",--短描述
       ps_desName  = "56293",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_la_1xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56301",
       ps_vedio = "music/vedio/nvzhu3.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu3.jpg",--短视频
       ps_pre = "",--前置职业头像
       ps_buy = 50, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_la_1.png", --城技能图标
                       sk_des  = "114942", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_la1_1.png", --被动技能图标
                               sk_name = "121270",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124244", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_la1_2.png", --被动技能图标
                               sk_name = "121271",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124245", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
   lancer_2 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_la_2c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_la_2.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_la_2.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_la_2.png",--短名称图片
       ps_des  = "56310",--描述
       ps_short_des  = "56318",--短描述
       ps_desName  = "56294",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_la_2xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56302",
       ps_vedio = "music/vedio/nvzhu3.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu3.jpg",--短视频
       ps_pre = "icons/role/prin_vdraw/nzxx_ui_013.png",--前置职业头像
       ps_buy = 150, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_la_2.png", --城技能图标
                       sk_des  = "114943", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_la2_1.png", --被动技能图标
                               sk_name = "121272",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124246", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_la2_2.png", --被动技能图标
                               sk_name = "121273",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124247", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                       [3] = { sk_icon = "icons/skill/gzzy_sk_la2_3.png", --被动技能图标
                               sk_name = "121274",
                               sk_unlock_lv = 15, -- 解锁等级
                               sk_des = "124248", --描述
                               sk_lock = "需要15级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
} 
princess_ocp["sheshou"] = {
   p_icon = "ui/princess/gzzy_lp_st_1.png",
   p_icon_h = "ui/princess/gzzy_lp_st_1_1.png",
   p_bg = "ui/princess/gzzy_ui_015.png",
   p_jl = "icons/role/prin_vdraw/sg_jl_ui_st.png",--解锁，经验数值
   p_sh = "icons/role/prin_vdraw/sg_sh_ui_st.png",--详细介绍
   p_name = "56329", 
   sheshou_1 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_ar_1c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_ar_1.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_ar_1.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_ar_1.png",--短名称图片
       ps_des  = "56311",--描述
       ps_short_des  = "56319",--短描述
       ps_desName  = "56295",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_ar_1xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56303",
       ps_vedio = "music/vedio/nvzhu4.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu4.jpg",--短视频
       ps_pre = "",--前置职业头像
       ps_buy = 50, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_ar_1.png", --城技能图标
                       sk_des  = "114945", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_ar1_1.png", --被动技能图标
                               sk_name = "121275",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124249", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_la1_2.png", --被动技能图标
                               sk_name = "121276",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124250", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
   sheshou_2 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_ar_2c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_ar_2.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_ar_2.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_ar_2.png",--短名称图片
       ps_des  = "56312",--描述
       ps_short_des  = "56320",--短描述
       ps_desName  = "56296",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_ar_2xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56304",
       ps_vedio = "music/vedio/nvzhu4.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu4.jpg",--短视频
       ps_pre = "icons/role/prin_vdraw/nzxx_ui_021.png",--前置职业头像
       ps_buy = 150, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_ar_2.png", --城技能图标
                       sk_des  = "114946", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_ar2_1.png", --被动技能图标
                               sk_name = "121277",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124251", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_la2_2.png", --被动技能图标
                               sk_name = "121278",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124252", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                       [3] = { sk_icon = "icons/skill/gzzy_sk_la2_3.png", --被动技能图标
                               sk_name = "121279",
                               sk_unlock_lv = 15, -- 解锁等级
                               sk_des = "124253", --描述
                               sk_lock = "需要15级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
} 
princess_ocp["huifu"] = {
   p_icon = "ui/princess/gzzy_lp_hl_1.png",
   p_icon_h = "ui/princess/gzzy_lp_hl_1_1.png",
   p_bg = "ui/princess/gzzy_ui_015.png",
   p_jl = "icons/role/prin_vdraw/sg_jl_ui_hl.png",--解锁，经验数值
   p_sh = "icons/role/prin_vdraw/sg_sh_ui_hl.png",--详细介绍
   p_name = "56330", 
   huifu_1 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_hl_1c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_hl_1.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_hl_1.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_hl_1.png",--短名称图片
       ps_des  = "56313",--描述
       ps_short_des  = "56321",--短描述
       ps_desName  = "56297",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_hl_1xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56305",
       ps_vedio = "music/vedio/nvzhu1.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu1.jpg",--短视频
       ps_pre = "",--前置职业头像
       ps_buy = 50, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_hl_1.png", --城技能图标
                       sk_des  = "114948", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_hl1_1.png", --被动技能图标
                               sk_name = "121280",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124254", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_la1_2.png", --被动技能图标
                               sk_name = "121281",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124255", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
   huifu_2 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_hl_2c.png",
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_hl_2.png",
       ps_rec  = {0,0,400,120},--icon的裁剪坐标
       ps_name = "ui/princess/gzzy_f_hl_2.png",--名称
       ps_name_short = "ui/princess/gzzy_zf_hl_2.png",--短名称图片
       ps_des  = "56314",--描述
       ps_short_des  = "56322",--短描述
       ps_desName  = "56298",--女主名称
       ps_icon  = "icons/role/prin_vdraw/gzzy_vdraw_hl_2xq.png",--女主对应小头像
       ps_sort = "ui/princess/gzxq_ui_028.png",---职业类别
       ps_info = "56306",
       ps_vedio = "music/vedio/nvzhu1.mp4",--视频
       ps_short_vedio = "music/vedio/nvzhu1.jpg",--短视频
       ps_pre = "icons/role/prin_vdraw/nzxx_ui_009.png",--前置职业头像
       ps_buy = 150, --学习所需要的宝石
       ps_buy_gold = 0, --学习所需要的金币
       master = { 
                [1] = {
                       m_icon = "icons/skill/zdjm_nz_001.png",--master1的奖励图标
                       m_icon_none_active = "icons/skill/zdjm_nz_001.png",--master1的未激活奖励图标
                       m_des  = "",--奖励描述
                       },
                   },
          ini_skill = {  --城技能
                       sk_icon = "icons/skill/gzzy_skp_hl_2.png", --城技能图标
                       sk_des  = "114949", --描述
                      },
          pas_skill = { --被动加护 
                       [1] = { sk_icon = "icons/skill/gzzy_sk_hl2_1.png", --被动技能图标
                               sk_name = "121282",
                               sk_unlock_lv = 5, -- 解锁等级
                               sk_des = "124256", --描述
                               sk_lock = "需要5级解锁", -- 解锁条件 
                       },
                       [2] = { sk_icon = "icons/skill/gzzy_sk_la2_2.png", --被动技能图标
                               sk_name = "121283",
                               sk_unlock_lv = 10, -- 解锁等级
                               sk_des = "124257", --描述
                               sk_lock = "需要10级解锁", -- 解锁条件 
                       },
                       [3] = { sk_icon = "icons/skill/gzzy_sk_la2_3.png", --被动技能图标
                               sk_name = "121284",
                               sk_unlock_lv = 15, -- 解锁等级
                               sk_des = "124258", --描述
                               sk_lock = "需要15级解锁", -- 解锁条件 
                       },
                      },
          master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
         }, 
} 

princess_ocp["no"] = {
   p_icon = "",
   p_icon_h = "",
   p_bg = "",
   p_name = "战士",
   no_princess_1 = { --第个职业详细信息
       ps_vdraw = "icons/role/prin_vdraw/gzzy_vdraw_hl_1xq_0.png",
       ps_rec  = {0,0,0,0},--icon的裁剪坐标
       ps_name = "",--名称
       ps_des  = "",--描述
       ps_desName  = "",--女主名称
       ps_icon  = "icons/role/prin_ocp/gzzy_image_0.png",--女主对应小头像
       ps_ocp  = "icons/role/prin_ocp/gzzy_image_0.png",
       ps_sort = "",---职业类别
       ps_info = "",
       ps_vedio = "",--视频
       ps_pre = "",--前置职业头像
       ps_buy = 0, --学习所需要的宝石
       ps_buy_gold = 250, --学习所需要的金币
       master = {},
       ini_skill = {},
       pas_skill = {},
       master_buy = 0,  --由被动技能升级需要星ti改为master开启需要
   },
}