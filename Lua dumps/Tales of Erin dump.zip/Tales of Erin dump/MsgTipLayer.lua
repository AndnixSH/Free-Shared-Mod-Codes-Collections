
MsgTipLayer = class("MsgTipLayer", function()  
                return cc.Node:create()  
                end)



function MsgTipLayer:initialize(infoStr)
    print("进入了msgModel 界面")

    local tipStr = ""
    local rate = 1
    if type(infoStr) == "string" then
        tipStr = infoStr
    elseif type(infoStr) == "table" then
        tipStr = table.getValue("MsgTipLayer", infoStr, "tipStr")
        rate = table.getValue("MsgTipLayer", infoStr, "rate")

    end
    
    self:initMs(infoStr, rate)
end
--/*初始化显示文本框的属性*/
function MsgTipLayer:initMs(infoStr, rate)

    local offset = 25;
    local winSize = cc.Director:getInstance():getWinSize();
    local desText = self:getText(infoStr);
    local contentSize = desText:getContentSize();
    desText:setPosition(offset,6)

    local panel = ccui.Layout:create();
    --panel:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    --panel:setBackGroundColor(cc.c3b(150, 200, 255))
    --panel:setOpacity(255)
    panel:setContentSize(contentSize.width + 100,38)
    panel:setCascadeOpacityEnabled(true)

    local tipBg = ccui.ImageView:create("n_UIShare/Global_UI/other/xzy_ui_016.png")
    tipBg:setScale9Enabled(true)
    tipBg:ignoreContentAdaptWithSize(false)
    tipBg:setCapInsets(cc.rect(100,2,50,34))
    tipBg:setContentSize(cc.size(panel:getContentSize().width,panel:getContentSize().height))
    tipBg:setPosition(cc.p(panel:getContentSize().width/2,panel:getContentSize().height/2))
    
    local desTextX = (panel:getContentSize().width - contentSize.width)/2
    local desTextY = (panel:getContentSize().height - contentSize.height)/2
    desText:setPosition(cc.p(desTextX,desTextY))

    panel:addChild(tipBg)
    panel:addChild(desText)

    self:addChild(panel)
    self:setPosition(winSize.width/2 - panel:getContentSize().width/2, winSize.height/2)

    local delay    = cc.DelayTime:create(1*rate)
    local moveBy   = cc.MoveBy:create(0.5*rate, cc.p(0,60))
    local fadeOut   = cc.FadeOut:create(0.5*rate)
    local spawn = cc.Spawn:create(moveBy,fadeOut) 
    local removeSelf = cc.RemoveSelf:create(true)
    local sequence = cc.Sequence:create(delay,spawn,removeSelf)
    panel:runAction(sequence)
end

function MsgTipLayer:getText( infoStr )
    -- body
    infoStr = infoStr or "";
    local outLineColor = cc.c4b(0, 0, 0, 255);
    local color = cc.c3b(255, 255, 255)
    local desText = ccui.Text:create()
    desText:setFontSize(22)
    desText:enableOutline(outLineColor,2)
    --desText:ignoreContentAdaptWithSize(true)
    desText:setString(infoStr)
    desText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    desText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    desText:setColor(color)
    --desText:setPosition(0,0)
    desText:setAnchorPoint(cc.p(0, 0))
    -- local textWidth = 440;
    -- local size = cc.size(textWidth, 0);
    -- desText:setTextAreaSize(size);
    -- local virtualSize = desText:getVirtualRendererSize();
    -- desText:setContentSize(virtualSize)

    return desText;
end

function MsgTipLayer:create(infoStr)

     local msgTip = MsgTipLayer.new()
     msgTip:initialize(infoStr)
     return msgTip
end
