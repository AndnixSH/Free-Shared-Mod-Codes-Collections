

GuildMemberNode = class("GuildMemberNode", XUICellView)
GuildMemberNode.CS_FILE_NAME = "GuildMemberItemNode.csb"
-- GuildMemberNode.curId    = nil -- 成就Id
-- GuildMemberNode.ItemType = nil -- 获得物品类型
-- GuildMemberNode.ItemId   = nil -- 获得物品Id
-- GuildMemberNode.ItemNum  = nil -- 获得物品数量
GuildMemberNode.skeletonNode = nil
GuildMemberNode.GuildMemberIndex = 1;
GuildMemberNode.OnSelf = nil;
GuildMemberNode.DataTest = nil;
GuildMemberNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
    btn_shotoff = "/s:Panel_1/s:Image_bg/s:Button_shotoff",
    btn_commission = "/s:Panel_1/s:Image_bg/s:Button_commission",
    btn_addFriend = "/s:Panel_1/s:Image_bg/s:Button_addFriend",
    btn_chat = "/s:Panel_1/s:Image_bg/s:Button_chat",
    text_allFighting = "/s:Panel_1/s:Image_bg/s:Text_allFighting",
    text_score = "/s:Panel_1/s:Image_bg/s:Text_score",
    text_title = "/s:Panel_1/s:Image_bg/s:Text_title",
    text_state = "/s:Panel_1/s:Image_bg/s:Text_state",
}

function GuildMemberNode:init(...)
    self.skeletonNode = nil
    if g_channel_control.show_new_guild_main == true then
        GuildMemberNode.CS_FILE_NAME = "GuildMemberItemNode_new.csb"
    end
    GuildMemberNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    if g_channel_control.show_new_guild_main == true then
        self:initHideOrShowThing()
    end
    return self
end
function GuildMemberNode:setData( tdad )
    -- body
    self.DataTest = tdad;
    self.GuildMemberIndex = tdad["GuildMemberIndex"];
    self.GuildType = tdad["GuildType"]
    self.OnSelf  = tdad["OnSelf"];
    print("self.GuildMemberIndex self.GuildMemberIndex == "..self.GuildMemberIndex);
end
function GuildMemberNode:onResetData()
    if g_channel_control.show_new_guild_main == true then
        self:initHideOrShowThing()
    end
    print("第一步  执行 GuildMemberItemNode onResetData")
    if not self._data then return end
    --local iTable   = self.GuildMemberTable["tab"]
        local dtable = {
            ["id"]           = self._data["uid"],               -- ID
            ["Name"]         = self._data["name"],              -- 名字
            ["position"]     = self._data["position"],          -- 公会位置
            ["rank"]         = self._data["rank"],              -- 等级
            ["head"]         = self._data["head"],              -- 头像
            ["login_tm"]     = self._data["login_tm"],          -- 上次登录时间

        }
        print()
        if self.GuildMemberIndex == 1 then
            dtable["can_give"]      = self._data["can_give"]           --是否赠送体力
            dtable["can_get"]       = self._data["can_get"]            --#是否收到赠送的体力
        end
        ----------------------------------------------------------------------------

        local  panelP        = self.PanelList
        print("panelP == "..panelP:getName());

        local  ItemBg        = panelP:getChildByName("Image_bg")

      
        -- /*自己的图标*/
        local  memberIcon    = ItemBg:getChildByName("Image_iconHead")
        --memberIcon:setVisible(false)
     
        local heroid  = tonumber(dtable["head"])

        memberIcon:setUnifySizeEnabled(true)
        memberIcon:loadTexture(hero[heroid].hero_bat_icon)
        -- /*自己的名字*/
        local  memberName    = ItemBg:getChildByName("Text_Name")

        if g_channel_control.show_new_guild_main == true then
            memberName:setString(dtable["Name"])
        else
            memberName:setString(dtable["Name"])
            memberName:enableOutline(cc.c4b(0,0,0,255),1)
            memberName:setFontSize(22)
            memberName:setAnchorPoint(cc.p(0,0.5))
            memberName:setPosition(cc.p(135,82))
            memberName:setTextColor(cc.c4b(255,255,255,255))
        end
        --称号
        local spineRoot = ItemBg:getChildByName("Node_spine")
        if self.skeletonNode then 
            self.skeletonNode:stopAllActions()
            self.skeletonNode:removeFromParent()
            self.skeletonNode = nil --todo
        end 
        if (self._data["title_id"]) then
            local id_str = title_conf[tonumber(self._data["title_id"])].res_spine
            if cc.FileUtils:getInstance():isFileExist(id_str) then 
                local end_pos = string.find(id_str,'atlas') - 1
                local spName = string.sub(id_str,0,end_pos)

                self.skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
                --local size=self.skeletonNode:getBoundingBox()
                --print("getBoundingBox width == "..size.width)
               -- self.skeletonNode:setAnchorPoint(0.5,0.5)
                --self.skeletonNode:setPosition(0,0)
                spineRoot:addChild(self.skeletonNode,1000)
                self.skeletonNode:setAnimation(1, "effect", true)
                local dt = cc.DelayTime:create(0.01)
                local cf = cc.CallFunc:create(function()
                     ---添加spine

                    local size=self.skeletonNode:getBoundingBox()
                    print("getBoundingBox width == "..size.width)
                    self.skeletonNode:setPosition(size.width/2,0)

                end)
                local seq = cc.Sequence:create(dt,cf)
                spineRoot:runAction(seq)
            else 
                print("文件不存在 error file not exist:"..id_str)
            end
        end

        -- /*公会 成员阶位 图标*/
        local  textureIcon   = ItemBg:getChildByName("Image_icon")
        textureIcon:setPosition(cc.p(313.50,textureIcon:getPositionY()))
        --textureIcon:setAnchorPoint(cc.p(0,0.5))
        textureIcon:setUnifySizeEnabled(true)

        if dtable["position"] == 1 then
            textureIcon:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_003.png")
        elseif dtable["position"] == 2 then
            textureIcon:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_002.png")
        elseif dtable["position"] == 3 then
            textureIcon:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_001.png") -- 会长n_UIShare/xbmain/xbfriend//hyjm_ui_005.png
        end

        -- /*等级*/
        local  rank          = ItemBg:getChildByName("Text_rank")
        rank:setString(dtable["rank"])
        -- /*最后登录时间*/
        local  time          = ItemBg:getChildByName("Text_time")
      --  print("到底有没有 == "..dtable["login_tm"])
        local  strTime       = self.OnSelf:timeSwitch(tonumber(dtable["login_tm"]))
        time:setString(strTime)
        local function touchCallBack(sender,eventType)
            local name = sender:getName()
            if eventType == ccui.TouchEventType.ended then
                if name == "Button_1" then
                   self.OnSelf:getApSend(dtable["id"],sender)
                elseif name == "Button_1_0" then
                    if user_info["id"] == dtable["id"] then
                    else
                        self.OnSelf:giveApSend(dtable["id"],sender)
                    end
                    
                elseif name == "Panel_1" then
                    AudioManager:shareDataManager():TestPrint();
                    local p1 = sender:getTouchBeganPosition()
                    local p2 = sender:getTouchEndPosition()

                    local l = cc.pGetDistance(p1,p2)
                    
                    if l < 30 then
                        --self.OnSelf:toPalyinfo(self._data)
                        self.OnSelf:switchPlayerInfoLayer(self._data["uid"],self._data["head"])
                    end
                   
                elseif name == "Button_cancle" then
                    self.OnSelf:confrimToCancleSend(dtable["id"],0)
                elseif name == "Button_confrim" then
                    self.OnSelf:confrimToCancleSend(dtable["id"],1) 
                elseif name == "Button_shotoff" then
                    self:removePartner()
                elseif name == "Button_commission" then    
                    self:changePositionView()    
                elseif name == "Button_addFriend" then 
                    self.OnSelf:addFriend(self._data["user_nim_id"],sender)
                elseif name == "Button_chat" then 
                    self.OnSelf:friendChat(sender)
                end
            end
        end
        -- /*申请列表是显示*/
        -- /*取消*/
        local sCancleBtn      = ItemBg:getChildByName("Button_cancle")
        -- /*确定*/
        local sConfirmBtn     = ItemBg:getChildByName("Button_confrim")


        --/*获取Ap*/
        local  apGet         = ItemBg:getChildByName("Button_1")
        -- /*赠送Ap*/
        local  apSet         = ItemBg:getChildByName("Button_1_0")
        self.apGet = apGet
        self.apSet = apSet

        -- /*不是申请列表隐藏*/
        if self.GuildMemberIndex == 1 then -- 成员
            sCancleBtn:setVisible(false)
            sConfirmBtn:setVisible(false)
            apGet:setVisible(true)
            apSet:setVisible(true)
            textureIcon:setVisible(true)
            -- /*点击获取玩家名片夹*/
            panelP:addTouchEventListener(touchCallBack)
        elseif self.GuildMemberIndex == 2 then -- 申请
            sCancleBtn:setVisible(true)
            sConfirmBtn:setVisible(true)
            apGet:setVisible(false)
            apSet:setVisible(false)
            textureIcon:setVisible(false)
        end
     --/*成员列表中的自己*/ 
        if user_info["id"] == dtable["id"] then
            ItemBg:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_009.png")
            memberName:setTextColor(cc.c4b(255,253,102,255))
            apGet:setVisible(false)
            apSet:setVisible(false)
            if g_channel_control.show_new_guild_main == true then
                ItemBg:loadTexture("uifile/n_UIShare/xbmain/xbfriend/hyjm_ui_012.png")
            end
        elseif user_info["id"] ~= dtable["id"] then
            ItemBg:loadTexture("uifile/n_UIShare/guild/guild_members/ghcy_ui_006.png")
            if g_channel_control.show_new_guild_main == true then
                ItemBg:loadTexture("uifile/n_UIShare/xbmain/xbfriend/hyjm_ui_002.png")
            end
        end
     -- 根据 成员的职位来判断是否显示 通过取消按钮
        if self.OnSelf.pos then
            if self.OnSelf.pos <= 1 then
                sCancleBtn:setVisible(false)
                sConfirmBtn:setVisible(false)
            end
        end
        --/*根据服务器状态判断 赠送 领取是否是禁用状态*/
        if dtable["can_give"] == 0  and dtable["can_give"] then
            apSet:setBright(false)
            --apSet:setEnabled(false)
        -- else
        --     apSet:setBright(true)
        else
            --/赠送Ap*/
            if self.DataTest["cur_give_num"] and self.DataTest["max_give_num"] then
                print("can_give ==  1")
                if self.DataTest["cur_give_num"] >= self.DataTest["max_give_num"] then
                    apSet:setBright(false)
                    print("can_give ==  false")
                else
                    print("can_give ==  true")
                    apSet:setBright(true)
                    apSet:addTouchEventListener(touchCallBack)    
                end
            end
        end

        if dtable["can_get"] == 0 and dtable["can_get"] then
            apGet:setBright(false)
           -- apGet:setEnabled(false)
           
        else
            apGet:setBright(true)
            --/获取Ap*/
            apGet:addTouchEventListener(touchCallBack)
        end
        --/*是否通过申请*/
        sCancleBtn:addTouchEventListener(touchCallBack)
        sConfirmBtn:addTouchEventListener(touchCallBack)
        if self.GuildMemberIndex == 1 then
            if self.nType == 1 then
                apGet:setVisible(false)
                apSet:setVisible(false)
            else
                apGet:setVisible(true)
                apSet:setVisible(true)
            end
            if self.GuildType then
                apGet:setVisible(false)
                apSet:setVisible(false)
            else
                apGet:setVisible(true)
                apSet:setVisible(true)
            end
        end
        if user_info["id"] == dtable["id"] then
            apSet:setBright(false)
            --apSet:setTouchEnabled(false)
        end
        if self.resetDataEvent then
            self.resetDataEvent(self)
        end


        if g_channel_control.UIVersion > 1 then
            apGet:setVisible(false)
        end
        if g_channel_control.show_new_guild_main == true then
            if GuildSingleton:getInstance():GetMemberState() == GuildSingleton.pType.manage then
                self:refreshBtnState(dtable)
                self.btn_shotoff:addTouchEventListener(touchCallBack)
                self.btn_commission:addTouchEventListener(touchCallBack)
            else
                if self.GuildMemberIndex == 1 then
                    if user_info["id"] == dtable["id"] then
                        self.btn_addFriend:setVisible(false)
                        self.btn_chat:setVisible(false)
                    else
                        local b_friend = XBChatSys:getInstance():isMyFriendById(self._data["uid"]) or false
                        if b_friend == false then
                            self.btn_addFriend:setVisible(true)
                            self.btn_addFriend:addTouchEventListener(touchCallBack)
                            self.btn_chat:setVisible(false)
                        else
                            self.btn_chat:setVisible(true)
                            self.btn_addFriend:setVisible(false)
                            self.btn_chat:addTouchEventListener(touchCallBack)
                        end
                        
                    end
                    
                end
            end
            local totalFightString = Lang:toLocalization(1040109)..tostring(self._data["team_score"])
            self.text_allFighting:setString(totalFightString)
            local guildStoreString = Lang:toLocalization(1040110)..tostring(self._data["score"])
            self.text_score:setString(guildStoreString)
            local onLineStr = self.OnSelf:lastLoginTimetoVisibleStr(self._data["login_tm"] ,self._data["uid"] == user_info["id"], self._data["online"])
            self.text_state:setString(onLineStr)
            rank:setString("LV"..tostring(self._data["rank"]))

            if dtable["position"] == 1 then
                textureIcon:setVisible(false)
                local jobStr = "("..Lang:toLocalization(1010106)..")"
                self.text_title:setString(jobStr)
            elseif dtable["position"] == 2 then
                local jobStr = "("..Lang:toLocalization(1010279)..")"
                self.text_title:setString(jobStr)
                textureIcon:loadTexture("uifile/n_UIShare/xbmain/xbfriend//hyjm_ui_006.png")
            elseif dtable["position"] == 3 then
                local jobStr = "("..Lang:toLocalization(1010107)..")"
                self.text_title:setString(jobStr)
                textureIcon:loadTexture("uifile/n_UIShare/xbmain/xbfriend//hyjm_ui_005.png") -- 会长
            end

            --重新设置text_title的位置
            local iconPosX = memberName:getPosition()
            local iconContent = memberName:getContentSize()
            local textJobPosX = iconPosX + iconContent.width + 10
            self.text_title:setPositionX(textJobPosX)

            local iconJobContent = self.text_title:getContentSize()
            local imageJobPosX = textJobPosX + iconJobContent.width + 10
            textureIcon:setPositionX(imageJobPosX)
        end
end
function GuildMemberNode:refreshBtnState(dtable)
    if self.GuildMemberIndex == 1 then
        if (dtable["position"] == 1 or dtable["position"] == 2) and user_info["id"] ~= dtable["id"] then
            self.btn_commission:setVisible(true)
            self.btn_shotoff:setVisible(true)
        end
        self.apSet:setVisible(false)
    else
        self.btn_commission:setVisible(false)
        self.btn_shotoff:setVisible(false)
    end
end

--修改成员公会级别
function GuildMemberNode:changePositionView()
    -- body
    local guild_info = {}
    guild_info["name"] = self._data["name"]
    guild_info["position"] = self._data["position"]
    
    local data = {
        info = guild_info,
        sDelegate = self,
        callFunc = self.doAppoint
    }
    
    local layer = GuildAppointPopView:create(data) 
    SceneManager.rootLayer:addChild(layer.uiLayer,9991)
end

--任命
function GuildMemberNode:doAppoint(selectPos)
    --todo 掉任命借口呀
    local selectPos = tonumber(selectPos)
    print("XbPersonalInfoLayer:doAppoint selectPos",selectPos)
    self:reqAppoint(self._data["uid"], selectPos)
end

function GuildMemberNode:reqAppoint(the_uid,_position)
    local function ReqSuccess(data)
        MsgTipSys:getInstance():addData(UITool.ToLocalization("任命成功，刷新"))
        --SceneManager:showPromptLabel(UITool.ToLocalization("任命成功，刷新"))
        self:reqPlayerInfo(self._data["uid"])
    end
    local tempTable = {
        ["rpc"] = "guild_appointment", 
        ["uid"] = self._data["uid"],
        ["position"] = _position,
    }
    
    PlayerInfoSys:getInstance():requestUpdateData(tempTable,ReqSuccess)  
end

function GuildMemberNode:removePartner()
    local str = string.format(UITool.ToLocalization("是否开除 %s"), self._data["name"])
    MsgManager:showSimpMsgWithCallFunc(str,self,self.reqFriedInfo)
end
--开除
function GuildMemberNode:reqFriedInfo()
    local function ReqSuccess(data)
        self:reqPlayerInfo(self._data["uid"])
        MsgTipSys:getInstance():addData(UITool.ToLocalization("删除成功"))
        --SceneManager:showPromptLabel(UITool.ToLocalization("删除成功"))
    end
    local tempTable = {
        ["rpc"] = "guild_kick",
        ["uid"] = self._data["uid"],
    }
    
    PlayerInfoSys:getInstance():requestUpdateData(tempTable,ReqSuccess)
end

function GuildMemberNode:reqPlayerInfo( uid )
    -- body
    local the_uid = uid
    local function Success(data)
        if self.exist == false then
            return
        end

        local temp_data = data
        temp_data.uid = uid

        PlayerInfoSys:getInstance():updatePersonalInfo(temp_data)
        self.OnSelf:refreshMember()
    end
    local msg_data = {
        ["rpc"] = "someone_info",
        ["the_uid"] = the_uid,
    }
    PlayerInfoSys:getInstance():requestUpdateData(msg_data,Success)
end

function GuildMemberNode:initHideOrShowThing()
    self.btn_shotoff:setVisible(false)
    self.btn_commission:setVisible(false)
    self.btn_addFriend:setVisible(false)
    self.btn_chat:setVisible(false)
end