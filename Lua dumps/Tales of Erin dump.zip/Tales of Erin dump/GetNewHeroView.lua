--require "XUIView"

GetNewHeroView = class("GetNewHeroView",XUIView)
GetNewHeroView.CS_FILE_NAME = "GetNewHeroView.csb"
GetNewHeroView.CS_BIND_TABLE = {
    panelLight = "/s:panelLight",
    panelDark = "/s:panelDark",

    panelMain = "/s:panelMain",
    pHalo = "/s:panelMain/s:pHalo",
    nodeMain = "/s:panelMain/s:nodeMain",
    pShow = "/s:panelMain/s:pShow",
    pStar = "/s:panelMain/s:pStar",
    nodeLabel = "/s:panelMain/s:nodeLabel",

    nodeMain_Face = "/s:panelMain/s:nodeMain/i:173/i:174",
    nodeMain_New = "/s:panelMain/s:nodeMain/i:173/i:175",

    --nodeLabel_Icon = "/s:panelMain/s:nodeLabel/i:83/i:85"
    nodeLabel_numStone = "/s:panelMain/s:nodeLabel/i:66/i:14",
    nodeLabel_iconStone = "/s:panelMain/s:nodeLabel/i:66/i:15",

    nodeLabel_lbName = "/s:panelMain/s:nodeLabel/i:65/i:15",
    nodeLabel_numAddAtk = "/s:panelMain/s:nodeLabel/i:65/i:7",
    nodeLabel_numAddHP = "/s:panelMain/s:nodeLabel/i:65/i:8",
    nodeLabel_numAddDef = "/s:panelMain/s:nodeLabel/i:65/i:9",
    nodeLabel_numAddCri = "/s:panelMain/s:nodeLabel/i:65/i:10",
    nodeLabel_numAddCriDmg = "/s:panelMain/s:nodeLabel/i:65/i:11",
    nodeLabel_numAddHel = "/s:panelMain/s:nodeLabel/i:65/i:12",
    nodeLabel_panelArrow = "/s:panelMain/s:nodeLabel/i:65/i:13",

    panelDialog = "/s:panelDialog",

    btnSkipAll = "/i:52"
}

function GetNewHeroView:init(itemList,finalFunc)
    GetNewHeroView.super.init(self)

    self.panelLight:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:nextStep()
        end
    end)

    self.btnSkipAll:addClickEventListener(function()
        self:skipToResult()
    end)
    self.btnSkipAll:setVisible(false)

    local psize = nil

    psize = self.pHalo:getSize()
    self.actHalo = sp.SkeletonAnimation:create("effects/gacha/bo_wen/effect.json", "effects/gacha/bo_wen/effect.atlas", 1.0)
    self.pHalo:addChild(self.actHalo)
    self.actHalo:setPosition(cc.p(psize.width/2,psize.height/2))

    self.actMain = cc.CSLoader:createTimeline("EffGaMain.csb")
    self.nodeMain:runAction(self.actMain)

    psize = self.pShow:getSize()
    self.actShow = sp.SkeletonAnimation:create("effects/gacha/zhong_yang/effect.json", "effects/gacha/zhong_yang/effect.atlas", 1.0)
    self.pShow:addChild(self.actShow)
    self.actShow:setPosition(cc.p(psize.width/2,psize.height/2))

    psize = self.pStar:getSize()
    self.actStar = sp.SkeletonAnimation:create("effects/gacha/xing_xing/effect.json", "effects/gacha/xing_xing/effect.atlas", 1.0)
    self.pStar:addChild(self.actStar)
    self.actStar:setPosition(cc.p(psize.width/2,70))

    self.actLabel = cc.CSLoader:createTimeline("EffGaLabel.csb")
    self.nodeLabel:runAction(self.actLabel)

    self.actLabel:play("reset",false)
    self.actMain:play("reset",false)

    self.actHalo:setAnimation(1, "reset", false) 
    self.actStar:setAnimation(1, "reset", false) 
    self.actShow:setAnimation(1, "reset", false) 

    self.dataSet = itemList

    self.finalFunc = finalFunc
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        ---
        print("KeyboardManager GetNewHeroView not registeredKeyBoardEvent")
    end)

    self.curHeroIndex = 1

    self:startPlay()

    return self
end
  
function GetNewHeroView:startPlay()
    if not self.dataSet then return end
    if #self.dataSet == 0 then return end

    local rarity = 1 

    for i = 1,#self.dataSet do  
        if self.dataSet[i].rarity > rarity then
            rarity = self.dataSet[i].rarity
        end
    end    

    self.currentStep = 0
    self:nextStep()
end

function GetNewHeroView:skipToResult()
    local nextHeroIndex = self.curHeroIndex + 1

    if nextHeroIndex > #self.dataSet then
        self.currentStep = 999
        self.curHeroIndex = 1
        if self.finalFunc then
            self.finalFunc()
        end
        
        self:returnBack()
    else
        self.curHeroIndex = nextHeroIndex
        self.currentStep = 0
        self:nextStep()
    end
end

function GetNewHeroView:fillContent(idx)
    local dat = self.dataSet[idx]
    local ischange = nil
    local isshowstart = false

    self.dialogFileName = nil

    local facepath = nil
    facepath = hero[dat.id].hero_vcw_icon
    if dat.story ~= nil then
        local dialogfile = "story/"..dat.story..".json"
        self.dialogFileName = dialogfile
    end
    isshowstart = true

    if facepath and self.nodeMain_Face then
        self.nodeMain_Face:setTexture(facepath)
    end

    self.nodeMain_New:setVisible(true)

    return ischange,isshowstart
end

function GetNewHeroView:play1x(idx)
    local dat = self.dataSet[idx]
    local rarity = dat.rarity

    local ischange = nil
    local isshowstart = nil
    local strshow = nil
    local strhalo = nil
    local strstar = nil
    local strstarfadeout = nil
    local strstarend = nil
    local effpath = nil
    --隐藏是否为新
    
    if rarity == 5 then
        strshow = "PtShow"
        strhalo = "PtHalo"
        strstar = "PtStar"
        strstarend = "PtEnd"
        strstarfadeout = "PtFadeOut"
        effpath = "music/ui/gacha_r5.mp3"
    elseif rarity == 4 then
        strshow = "AuShow"
        strhalo = "AuHalo"
        strstar = "AuStar"
        strstarend = "AuEnd"
        strstarfadeout = "AuFadeOut"
        effpath = "music/ui/gacha_r4.mp3"
    else
        strshow = "AgShow"
        strhalo = "AgHalo"
        strstar = "AgStar"
        strstarend = "AgEnd"
        strstarfadeout = "AgFadeOut"
        effpath = "music/ui/gacha_r3.mp3"
    end

    ischange,isshowstart = self:fillContent(idx)

    self.actMain:setFrameEventCallFunc(function(frame)
        local fn = frame:getEvent()
        if fn == "watingend" then
            self.actShow:clearTracks()
            self.actShow:setToSetupPose()
            self.actShow:setAnimation(2,strshow,false)  --
            self.actMain:play("show",false)
            AudioManager:shareDataManager():playMusic(effpath,0, false)
        elseif fn == "f14" then
            self.actHalo:clearTracks()
            self.actHalo:setToSetupPose()
            self.actHalo:setAnimation(3,strhalo,false)
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()
                self.actStar:setAnimation(3,strstar,false)
            end
        elseif fn == "f30" then
            self:nextStep()
        elseif fn == "lastframe" then
            --动画结束，进入下一阶段
            self:nextStep()
        elseif fn == "startfadeout" then
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()        
                self.actStar:setAnimation(4,strstarfadeout,false)
            end
        elseif fn == "forceshow" then
            if isshowstart then
                self.actStar:clearTracks()
                self.actStar:setToSetupPose()   
                self.actStar:setAnimation(5,strstarend,false)
            end       
        end
    end)

    self.actMain:play("waiting3",false)

    self.actHalo:clearTracks()
    self.actHalo:setToSetupPose()
    self.actHalo:setAnimation(1,"reset",false)
    self.actStar:clearTracks()
    self.actStar:setToSetupPose()
    self.actStar:setAnimation(1,"reset",false)
    self.actLabel:play("reset",false)
end

function GetNewHeroView:nextStep()
    --currentStep 
    -- 0  单抽第一阶段
    -- 1  单抽角色对话
    -- 2  角色淡出
    -- 3  nextHeroIndex + 1 播放下一个英雄

    self.actMain:stop()
    if not self.currentStep or self.currentStep < 0 then
        self:startPlay()
    elseif self.currentStep == 0 then
        self.panelLight:setOpacity(255)
        self.panelLight:setTouchEnabled(true)
        self.btnSkipAll:setVisible(true)
        
        --此处开始播特效
        self.currentStep = 1
        self.panelDark:setOpacity(255)
        self.panelLight:runAction(cc.FadeOut:create(0.5))
        self:play1x(self.curHeroIndex)
    elseif self.currentStep == 1 then
        self.actHalo:clearTracks()            
        self.actHalo:setToSetupPose()
        self.actHalo:setAnimation(1, "reset", false) 
        self.actShow:clearTracks()
        self.actShow:setToSetupPose()
        self.actShow:setAnimation(1, "reset", false) 
        --有剧情则 放剧情 没剧情则放淡出
        if self.dialogFileName ~= nil then
            self.currentStep = 2
            self.actMain:play("forceshow",false)
            self:playDialog(self.dialogFileName)
        else
            self.currentStep = 3
            self.actMain:play("fadeout",false)
        end
    elseif self.currentStep == 2 then
        --播放一句剧情，播放完则淡出
        self.currentStep = 3
        self.actMain:play("fadeout",false)
    elseif self.currentStep == 3 then
        local nextHeroIndex = self.curHeroIndex + 1

        if nextHeroIndex > #self.dataSet then
            self.currentStep = 999
            self.curHeroIndex = 1
            if self.finalFunc then
                self.finalFunc()
            end
            
            self:returnBack()
        else
            self.curHeroIndex = nextHeroIndex
            self.currentStep = 0
            self:nextStep()
        end
    else
        if self.finalFunc then
            self.finalFunc()
        end
        
        self:returnBack()
    end
end

function GetNewHeroView:playDialog(filename)
    --
    if GameManagerInst.gameType == 2 then
        local param = {}
        param["rcvData"] = {}
        param["rcvData"]["filename"] = filename
        param["rcvData"]["callFunc"] = function ( obj )
            self._rootNode:removeChildByTag(999)
            self:nextStep()
        end 
        param["rcvData"]["obj"] = self 
        self._rootNode:addChild(DialogLayer:create(param).uiLayer,10,999)
    end
end

function GetNewHeroView:returnBack()
    if self._navigationView then
        self._navigationView:popView()
    end
end

function GetNewHeroView:onNavigateTo(isback)
    if not isback then
        self:startPlay()
    end
end