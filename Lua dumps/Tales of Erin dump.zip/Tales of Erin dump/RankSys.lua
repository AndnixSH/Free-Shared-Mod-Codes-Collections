RankSys = {}
RankSys.ERankType = {
    --常驻排行榜(主界面)
    resident = 1,
    --废神活动排行榜
    feiShen = 2
}

function RankSys:getInstance( ... )
     -- body
     if self.instance == nil then
        self.instance = self:new()
     end
     return self.instance
end

function RankSys:new( o )
    -- body
    o = o or {}
    setmetatable(o,self)
    self.__index = self
    return o
end

--通过类型获得配置的排行榜页签
function RankSys:getRankTabByType( rank_type )
    -- body
    local rankType = rank_type or RankSys.ERankType.resident
    local rankData = rank_tab_config[rankType]
    return rankData
end
--通过类型获得配置的排行榜data
function RankSys:getRankDataByType( rankType )
    -- body
    local rankData = {}
    local rankTabData = self:getRankTabByType(rankType)
    local rankTabCount = #rankTabData
    for i=1,rankTabCount do
        local rankTabItemKey = rankTabData[i]
        local rankTabItemData = rank_reward_list[rankTabItemKey]
        if rankTabItemData then
            table.insert(rankData,rankTabItemData)
        end
    end
    return rankData
end