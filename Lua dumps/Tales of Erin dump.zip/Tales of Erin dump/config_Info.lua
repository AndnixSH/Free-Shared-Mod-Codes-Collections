--此表为静态表，用于配置本地静态数值数据，如ap药的效果，购买一次ap所消耗的宝石，进入素材本所消耗的钥匙个数，购买钥匙所需宝石数量等

AP_M  = 100  --大体力药消耗
AP_L = 50   -- 小体力药消耗
AP_GEM = 25 -- 购买体力所需宝石个数
KEY_GEM = 100 --购买钥匙所需宝石个数
AP_T = 300

-- 新的新手引导  控制是否点击弱引导进入战斗
G_newGuidSmp        = false   -- 弱引导  控制界面直接的跳转 
G_toStart           = false   -- 是否调用 StartLayer init()


------------公会自己所处在的职位
G_GuildPos         = 0  ----- 6 会长 5 副队长


G_Jion             = 0  ------- 申请机制的条件 0 审批 1 自动

G_SkillResetCost   = 20000


------------执行几次成就特效--------------
G_Efc_num   = 0


--临时 是否允许发送抽卡请求
allow_draw_card  = true
-- 记录数据用的   排序
G_EquipSortTable = nil    -- 排序完成的表
-- 排序中 各种设置和控制  需要的表参数
G_IsRfsHList     = false  
G_IsEfsHList     = false
G_RListTag       = nil
G_ListMode       = nil
G_EListMode      = nil
G_SortMode       = nil
AP_T = 300    -- AP的自动恢复时间

-- 狗粮经验改为从mat表里面读取
-- EXP_H_M = 80000 --大的角色狗粮提供的经验值     
-- EXP_H_L = 4000  --小的角色狗粮所提供的经验值
-- EXP_E_M = 25000  --大的灵装狗粮所提供的经验值
-- EXP_E_L = 1000   --小的灵装狗粮所提供的经验值

ID_H_M  = "mat_602"  --大角色狗粮ID
ID_H_L  = "mat_601"  --小角色狗粮ID
ID_E_M  = "mat_612"  --大灵装狗粮ID
ID_E_L  = "mat_611"  --小灵装狗粮ID

ID_ROLE_ADDSK   = "mat_701"     --角色额外技能点
ID_ROLE_ADDPROP = "mat_702"     --角色额外提升
ID_EQUIP_RSK    = "mat_703"     --装备洗炼

ID_ACT_2_KEYITEM = "mat_704"    --ACT 2 活动道具

ID_HERO_OPT  = "mat_705"   --角色兑换
