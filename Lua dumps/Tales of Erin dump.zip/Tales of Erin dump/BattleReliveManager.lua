--[[
     说明 复活弹窗的管理
     复活弹窗是通用的弹窗，这里边是封装了，获取服务器数据，对复活弹窗的调用

]]
BattleReliveManager = class("BattleRankerUIManager") 
BattleReliveManager.__index = BattleReliveManager

--[[    显示复活弹窗之前 先获取数据
        1 有两种情况是不需显示弹窗的  道具不够，达到复活次数最大
        2 根据获取的服务器数据来显示弹窗的内容
]] 
BattleReliveManager.rootNode = nil 
BattleReliveManager.panel_fh = nil
BattleReliveManager.reliveCallBackFuc = nil
function BattleReliveManager:createWithMainUINode(node,reliveCallBackFuc)
    local battle = BattleReliveManager.new()
    battle:init(node,reliveCallBackFuc)
    return battle
end

function BattleReliveManager:init(node,reliveCallBackFuc)
    self.rootNode = node 
    self.panel_fh = self.rootNode:getChildByTag(50)
    self.panel_fh:setVisible(false)
    self.reliveCallBackFuc =  reliveCallBackFuc
    local this = self
    function touchCallBack( sender,eventType  )
        if eventType == ccui.TouchEventType.ended then
            local tag = sender:getTag()
            if tag == 5002 then
                for i = 2, 3 do
                    local btn = ccui.Helper:seekWidgetByTag(this.panel_fh,5000+i)
                    btn:setTouchEnabled(false)
                end
                this.panel_fh:setVisible(false)
                this:confirmReliveData()
            elseif tag == 5003 then
                --多人战点取消后停留在战斗界面
                if G_STAGE_TYPE == 2 then 
                    this.panel_fh:setVisible(false)
                    BattleUIManager:showFHbtn(true)
                --单人战点取消后退出战斗，显示战斗失败
                else
                    if G_BattleScene.battleResult ~= 3 then--防止可以无限点击
                        G_BattleScene.battleResult = 3
                        BattleUIManager:showLose(G_BattleScene.quitBattleScene)
                    end
                end 
            end
        end
    end

    for i = 2, 3 do
        local btn = ccui.Helper:seekWidgetByTag(self.panel_fh,5000+i)
        btn:addTouchEventListener(touchCallBack)
    end
end

function BattleReliveManager:sendShowReliveBoxData()
    local this = self
    local function reiceSthCallBack(data)
        print("获取复活弹窗 数据")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if SceneManager ~= nil then
            SceneManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil or t_data["data"]["state_code"] ~=1 then           
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常,请点击确认尝试重新连接!"), self, self.confirmReliveData)
            --todo 处理错误数据页面跳转逻辑
            return
        else
            this:setReliveDate(t_data)
        end 
    end
    local cjson = require "cjson"
    SceneManager:createWaitLayer()
    local tempTable = {
        ["rpc"]          = "relive_get",
        ["battle_type"]  =  G_STAGE_TYPE,
        ["battle_id"]    = BattleDataManager.battleId,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
--[[
    设置复活弹窗的数据 
    点击复活都是调用此函数
    1 用服务器返回的 cost_gem 来判断 如果小于或等于零 证明是点击的复活
]]
function BattleReliveManager:setReliveDate( t_data )
    -- body
    local cost_num = tonumber(t_data["data"]["cost_gem"]) 
    if  cost_num > 0 then
        local now_gem    = tonumber(t_data["data"]["gem"])
        local relive_num = tonumber(t_data["data"]["relive"])
        local text_num = ccui.Helper:seekWidgetByTag(self.panel_fh,5101)
        text_num:setString(cost_num)
        local text_reLive_num  =  ccui.Helper:seekWidgetByTag(self.panel_fh,5102)
        text_reLive_num:setString(relive_num)
        ccui.Helper:seekWidgetByTag(self.panel_fh,5002):setTouchEnabled(true)
        ccui.Helper:seekWidgetByTag(self.panel_fh,5003):setTouchEnabled(true)   
        ccui.Helper:seekWidgetByTag(self.panel_fh,5002):setBright(true)
        if cost_num > now_gem or relive_num < 1 then 
           ccui.Helper:seekWidgetByTag(self.panel_fh,5002):setTouchEnabled(false)
           ccui.Helper:seekWidgetByTag(self.panel_fh,5002):setBright(false) 
        end  
        self.panel_fh:setVisible(true)
    end
end


function BattleReliveManager:confirmReliveData( )

    local function reiceSthCallBack(data)
        print("复活")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if SceneManager ~= nil then
            SceneManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil or t_data["data"]["state_code"] ~=1 then           
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常,请点击确认尝试重新连接!"), self, self.confirmReliveData)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        local is_live = tonumber(t_data["data"]["is_live"])
        if (is_live  == 1) then
            -- 刷新当前的钻石数量
            user_info["gem"] = t_data["data"]["gem"]
            user_info["gem_r"] = t_data["data"]["gem_r"]
            self.reliveCallBackFuc()
        end       
    end
    local cjson = require "cjson"
    SceneManager:createWaitLayer()
    local tempTable = {
        ["rpc"]          = "relive",
        ["battle_type"]  =  G_STAGE_TYPE,
        ["battle_id"]    = BattleDataManager.battleId,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end
