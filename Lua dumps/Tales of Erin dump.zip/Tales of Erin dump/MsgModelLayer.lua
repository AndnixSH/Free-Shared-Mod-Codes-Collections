
require "BasicLayer"
---------大型活素材详细
MsgModelLayer = class("MsgModelLayer",BasicLayer)
MsgModelLayer.__index = MsgModelLayer
MsgModelLayer.lClass  = 3                     ------  锻造弹窗tag 555
MsgModelLayer.rData = nil
----------------定义表参数-----------
--oneself       传入的self
--callFunc      需要回调的函数
--basicDec      描述
--titleName     标题的名字
--buttonType    显示but类型  1 一个确定按钮   2 确定和取消
--OKBtnName     确定按钮的文本
--formType      1 小  2 中  3 大 4 大
--nodeCsb       csb文件    直接传入一个node文件 
--basicType     -- 基础描述 类型  1 是一 纯文本格式的 纯文本类型参数可选可默认 为nil  2 金币  3 钻石
-- Brish_en     -- 是否贩卖  灰色不可点击
-- sTime        -- 按钮上的倒计时
--order         -- 处理node盖住按钮的问题
---------------调用弹窗格式------------
    -- local pop = {}
    -- pop["oneself"]    = self
    -- pop["buttonType"] = 2
    -- pop["formType"]   = 2
    -- pop["callFunc"]   = self:callFuc  默认点击界面消失
    -- pop["titleName"]  = "小弹窗"
    -- pop["basicDec"]   = "我是送快递的"
    -- self.sManager:showMsgMode(pop)
--------------node的格式------------------
   --  local node =cc.CSLoader:createNode("MsgBoxNode_2.csb")
   --  local pop = {}
   --  pop["oneself"]    = self
   --  pop["buttonType"] = 1
   --  pop["formType"]   = 2
   --  pop["nodeCsb"]    = node
   --  pop["titleName"]  = "小弹窗"
   --  self.sManager:showMsgMode(pop)
--------- MsgBoxNode_1 2    MsgBoxNode_2,MsgBoxNode_3，MsgBoxNode_4,MsgBoxNode_5,MsgBoxNode_6 的底框类型 3
--/*效果图*/
-- MsgBoxNode_1  huobi3.png 
-- MsgBoxNode_2  huobi_2.png 
-- MsgBoxNode_3  huobi_1.png 
-- MsgBoxNode_4  lingzhuang2.png 
-- MsgBoxNode_5  lingzhuang_1.png
-- MsgBoxNode_6  sucai2.png
-- MsgBoxNode_7  sucai2_1.png
-- MsgBoxNode_8  背包贩卖
-- MsgBoxNode_9  背包使用
-- MsgBoxNode_10 消耗的类型 和描述
-- MsgBoxNode_11 铸造开始
function MsgModelLayer:init()
    print("进入了msgModel 界面")
    local node =cc.CSLoader:createNode("MsgModelLayer.csb")
    self.uiLayer:addChild(node,0,2)
    self:initMs()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)   

end
function MsgModelLayer:setAllz(panel)
    local titleName = panel:getChildByName("Text_title")
    local basicDec  = panel:getChildByName("Text_dec")
    local butConfirm = panel:getChildByName("Button_confirm")
    local butCancle  = panel:getChildByName("Button_cancle")
    local butSingle  = panel:getChildByName("Button_single")
    titleName:setZOrder(1)
    basicDec:setZOrder(1)
    butConfirm:setZOrder(1)
    butCancle:setZOrder(1)
    butSingle:setZOrder(1)
end
--/*初始化显示文本框的属性*/
function MsgModelLayer:initMs( ... )
    local node  = self.uiLayer:getChildByTag(2)
    local panel = nil
    print("进入了msgModel 界面 == "..self.rData["formType"])
    if self.rData["formType"] == 1 then
       panel = node:getChildByName("Panel_xiao")

    elseif self.rData["formType"] == 2 then
       panel = node:getChildByName("Panel_zhong")
    elseif self.rData["formType"] == 3 then
       panel = node:getChildByName("Panel_da")
    elseif self.rData["formType"] == 4 then
       panel = node:getChildByName("Panel_da_da")
    end
    panel:setVisible(true)
    -- 获取基础框上的空间  最基础的显示
    local titleName = panel:getChildByName("Text_title")
    local basicDec  = panel:getChildByName("Text_dec")
    --/*弹框的标题*/
    if self.rData["titleName"] then
        titleName:setString(self.rData["titleName"] )
    else
        titleName:setString(UITool.ToLocalization("提示"))
    end
    --/*弹框的基础描述*/
    if self.rData["basicDec"] then
        if self.rData["TextType"] == "LTOP" then
            basicDec:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
            basicDec:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
        end
        basicDec:setString(self.rData["basicDec"] )
    else
        basicDec:setString("")
    end
   
    --/*弹框的金币*/
    if self.rData["basicType"] == 2 then
         basicDec:setString("")
    end
    --/*弹框的星石*/
    if self.rData["basicType"] == 3 then
        basicDec:setString("")
    end
    --/*直接传入node文件*/
    --/*参数看需要填写*/
    if self.rData["nodeCsb"] then
        if self.rData["order"] then
            self:setAllz(panel)
        end
        self.rData["nodeCsb"]:setPosition(640,360);
        panel:addChild(self.rData["nodeCsb"]);
    end

    if self.rData["OKBtnName"] then
       local btnConfirm = panel:getChildByName("Button_confirm")
       local ord = btnConfirm:getZOrder()
       print("ord ord ord ord ord == "..ord)
       local btnText = btnConfirm:getChildByName("Text_2")
       
        if self.rData["sTime"] then
            local function function_name( ... )
                -- body
                btnConfirm:setTouchEnabled(true)
                btnConfirm:setBright(true)
                btnText:setString(self.rData["OKBtnName"])

            end 
            btnText:setString(self.rData["OKBtnName"].."("..self.rData["sTime"].."s)")
            btnConfirm:setTouchEnabled(false)
            btnConfirm:setBright(false)
            self:schedule(btnConfirm,1,self.rData["sTime"],btnText,function_name)
        else
            btnText:setString(self.rData["OKBtnName"])
        end
    end
    if self.rData["Brish_en"]then
        local btnConfirm = panel:getChildByName("Button_confirm")
        btnConfirm:setTouchEnabled(false)
        btnConfirm:setBright(false)
    end

    if self.rData["bBtnCanTouch"] ~= nil then
        local btnConfirm = panel:getChildByName("Button_confirm")
        btnConfirm:setTouchEnabled(self.rData["bBtnCanTouch"])
        btnConfirm:setBright(self.rData["bBtnCanTouch"])
    end
    self:initBut(panel)
    self.rootPanel = panel
end
-- 倒计时
--/*倒计时   1执行动作的node 2 间隔时间   3 倒计时总时间   4 时间需设置Text文本*/  5 callf 回调函数
function MsgModelLayer:schedule(node, delay,Countdown ,str,callf)
    local  funcCountdown = Countdown
   local function TimeFunc( )

    -- body
    --local function updata( ... )
        funcCountdown = funcCountdown - 1

        --local s = math.floor((funcCountdown%3600)%60)--() 
        if funcCountdown < 0 then
            funcCountdown = 0
        end
        if  funcCountdown == 0 then
          if callf then
            callf()
            return
          end
        end

        print("sssss === "..funcCountdown)
        local time = string.format("%d",funcCountdown)
        print("现在的时间"..time)
        str:setString(self.rData["OKBtnName"].."("..time.."s)")
    end
    --print()
    local delay    = CCDelayTime:create(delay)

    local callfunc = CCCallFunc:create(TimeFunc)

    local sequence = cc.Sequence:create(delay, callfunc)

    local action   = CCRepeatForever:create(sequence)

    node:runAction(action)

    return action
end
--/*文本框的点击事件  single 是单一的确定按钮*/
function MsgModelLayer:initBut( panel )
    local butConfirm = panel:getChildByName("Button_confirm")
    local butCancle  = panel:getChildByName("Button_cancle")
    local butSingle  = panel:getChildByName("Button_single")
    if self.rData["buttonType"] == 1 then
        butConfirm:setVisible(false)
        butCancle:setVisible(false)
    elseif self.rData["buttonType"] == 2 then
        butSingle:setVisible(false)
    end
    butCancle:setEffectType(3)
    local function CallBak( sender,eventType )
        -- body
       if eventType == ccui.TouchEventType.ended then
            if sender:getName() == "Button_confirm" then
                self:callCanfirm()
            elseif sender:getName() == "Button_cancle" then
                self:returnBack();
            elseif sender:getName() == "Button_single" then
                self:callCanfirm()
            end
       end
    end 
    butConfirm:addTouchEventListener(CallBak)
    butCancle:addTouchEventListener(CallBak)
    butSingle:addTouchEventListener(CallBak)
end
function MsgModelLayer:returnBack( ... )
	-- body
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    if self.rData and self.rData["cancelFunc"] then
        self.rData["cancelFunc"](self.rData["oneself"])
    end
    --清楚smanager中的引用
    if self.sManager and self.sManager.MsgModelLayer then
        self.sManager.MsgModelLayer = nil
    end
    if self.uiLayer~=nil then
      self.uiLayer:removeFromParent()
      self.uiLayer = nil
    end
    self:clear()
    --self.sManager:hideMsgMode()
end

function MsgModelLayer:callCanfirm( ... )
    if self.rData["callFunc"] then
        print("进入回调")
        self.rData["callFunc"](self.rData["oneself"])
    end
    self:returnBack()
end

--用于新手引导。设置取消按钮失灵
function MsgModelLayer:setCancleButtonVisible(isTouch)
    local butCancle  = self.rootPanel:getChildByName("Button_cancle")
    butCancle:setTouchEnabled(isTouch)
end

function MsgModelLayer:create(tdata,sManager)

     local msgModel = MsgModelLayer.new()
	 msgModel.rData = tdata 
	 msgModel.sManager  = sManager
     msgModel.uiLayer = cc.Layer:create()
     msgModel:init()
     return msgModel
end