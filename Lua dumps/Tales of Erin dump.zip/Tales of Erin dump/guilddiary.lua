-- 公会日志

guild_diary = {}

guild_diary[1] = "60882" -- 公会创建

guild_diary[2] = "60883" -- 公会成员加入

guild_diary[3] = "60884" -- 公会成员被踢

guild_diary[4] = "60885" -- 公会成员被踢

guild_diary[5] = "60886" -- 公会成员离开

guild_diary[6] = "60887" -- 公会成员任命

guild_diary[7] = "60888" -- 公会成员任命

guild_diary[8] = "60889" -- 公会成员任命

guild_diary[9] = "60890" -- 公会战报名情况

guild_diary[10] = "60891" -- 公会战每次匹配情况

guild_diary[11] = "60892" -- 公会战每次匹配胜负

guild_diary[12] = "60893" -- 公会战每次匹配胜负

guild_diary[13] = "60894" -- 公会获得公会战先关成就

guild_diary[14] = "60895" -- 会长被公投

guild_diary[15] = "60896" -- 会长竞选

guild_diary[16] = "60897" -- 会长当选
