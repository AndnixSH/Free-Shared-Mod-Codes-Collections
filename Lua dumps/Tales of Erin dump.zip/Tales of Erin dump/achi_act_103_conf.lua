achi_act_103_conf={} 
achi_act_103_conf[1] = {
        id= 1,
        achi_name= "스토리 클리어",
        achi_desc= "모든 이벤트 스테이지 완료",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[2] = {
        id= 2,
        achi_name= "사계의 탑 협력자",
        achi_desc= "사계의 탑 외전 개인 스테이지 50회 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[3] = {
        id= 3,
        achi_name= "진실 추적(쉬움)",
        achi_desc= "이벤트 스테이지(쉬움) 단체전 10번 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[4] = {
        id= 4,
        achi_name= "진실 추적(어려움)",
        achi_desc= "이벤트 스테이지(어려움) 단체전 30번 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[5] = {
        id= 5,
        achi_name= "진실 추적(매우 어려움)",
        achi_desc= "이벤트 스테이지(매우 어려움) 단체전 50번 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[6] = {
        id= 6,
        achi_name= "단기필마(쉬움)",
        achi_desc= "이벤트 스테이지(쉬움) 단체전 개인 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[7] = {
        id= 7,
        achi_name= "단기필마(어려움)",
        achi_desc= "이벤트 스테이지(어려움) 단체전 개인 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 
achi_act_103_conf[8] = {
        id= 8,
        achi_name= "단기필마(매우 어려움)",
        achi_desc= "이벤트 스테이지(매우 어려움) 단체전 개인 클리어",
        achi_icon= "icons/achiv/cjxt_001.png",

} 