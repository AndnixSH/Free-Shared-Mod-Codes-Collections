--[[
	GuildTeamView.lua
]]
GuildTeamView = class("GuildTeamView")
GuildTeamView.__index = GuildTeamView

function GuildTeamView:create(data)
     local layer = GuildTeamView.new()
     layer.data = data
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end

function GuildTeamView:init()
	self.items = {}
	local node = cc.CSLoader:createNode("GuildTeamLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self._rootCSbNode = node:getChildByTag(102) 
    for i = 1,4 do
    	local panel = ccui.Helper:seekWidgetByTag(self._rootCSbNode,340+i-1)
        self.items[i] = GuildTeamItem.new():init(panel,i)
    end
    self.panelTitle = ccui.Helper:seekWidgetByTag(self._rootCSbNode,43)
    self:loadTeam()
end

function GuildTeamView:loadTeam()
    for i = 1,4 do
        local h = self.data.team[i]
        self.items[i]:setRoleInfo(h or {id="0"})
    end
    self.psVdrawImg = self._rootCSbNode:getChildByTag(329)
    --左侧公主信息
    local oid =  self.data["ps"]  --公主职业id
    local end_pos = string.find(oid,'_') - 1
    local gid = string.sub(oid,0,end_pos)
    local psinfo = princess_ocp[gid][oid]

    if psinfo then
        local vdrawpath = psinfo.ps_vdraw
        if vdrawpath ~= nil and vdrawpath ~= "" then
            self.psVdrawImg:setVisible(true)
            self.psVdrawImg:setTexture(vdrawpath)
        else
            self.psVdrawImg:setVisible(false)
        end
    else
        self.psVdrawImg:setVisible(false)
    end  
    --总战力
    local labfp = ccui.Helper:seekWidgetByName(self._rootCSbNode,"fpValue")
    labfp:setString(self.data.team_fp)

    self:refreshTitle()
end

function GuildTeamView:refreshTitle(  )
    -- body
    local titleId = self.data["title_id"]
    print("GuildTeamView:refreshTitle   titleId",titleId)
    if self.m_titleID == nil or self.m_titleID ~= titleId then 
        self.m_titleID = titleId
        local spineNameStr = ""
        if title_conf[titleId] and title_conf[titleId].res_spine then
            spineNameStr = title_conf[titleId].res_spine
        end

        if self.m_titleSkeletonNode ~=nil then 
            self.m_titleSkeletonNode:stopAllActions()
            self.m_titleSkeletonNode:removeFromParent()
            self.m_titleSkeletonNode = nil
        end

        if cc.FileUtils:getInstance():isFileExist(spineNameStr) then    
            local end_pos = string.find(spineNameStr,'atlas') - 1
            local spName = string.sub(spineNameStr,0,end_pos)
            self.m_titleSkeletonNode = sp.SkeletonAnimation:create(spName.."json", spName.."atlas", 1.0)
            local title_png = ccui.ImageView:create(spName.."png")
            local size = title_png:getContentSize()

            local titleSpineX = (self.panelTitle:getContentSize().width - size.width)/2 + size.width/2
            local titleSpineY = (self.panelTitle:getContentSize().height - size.height)/2 + size.height/2
            self.m_titleSkeletonNode:setPosition(cc.p(titleSpineX,titleSpineY))
            self.panelTitle:addChild(self.m_titleSkeletonNode)
            self.m_titleSkeletonNode:setAnimation(1, "effect", true)
            self.panelTitle:setVisible(false)
            local dt = cc.DelayTime:create(0.01)
            local cf = cc.CallFunc:create(function()
                self.panelTitle:setVisible(true)
            end)
            local seq = cc.Sequence:create(dt,cf)
            self.panelTitle:runAction(seq)
        else 
            print("文件不存在 error file not exist:"..spineNameStr)
        end 
    else 
        print("避免重复加载")
    end 
end
