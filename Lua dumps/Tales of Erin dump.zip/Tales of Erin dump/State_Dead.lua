--死亡状态
--created by kobejaw.2018.7.14.
State_Dead = class("State_Dead",StateBase)

function State_Dead:ctor(entity)
	self.super.ctor(self,entity);
	self.stateEnum = StateEnum.Dead
end

function State_Dead:Enter()
	self.entity.isDead = true;

	self.entity.componentManager:onDead()

	self.entity.box_w = -1000
	self.entity.box_h = -1000

	if self.entity.entityType == 1 then
		BattleRuntimeInfo.team1EntityNum = BattleRuntimeInfo.team1EntityNum - 1
	else
		BattleRuntimeInfo.team2EntityNum = BattleRuntimeInfo.team2EntityNum - 1
	end

	if BattleRuntimeInfo.team1EntityNum == 0 then
		self:enterIdleState(2)
	elseif BattleRuntimeInfo.team2EntityNum == 0 then
		self:enterIdleState(1)
	end

	self.entity:playDeadAnimation();
	self:dropBox()

	if self.entity.isBoss then
		BattlePlaySound(BattleGlobals.Sound_BossDead,false,1) 
	end
end

--角色播完死亡动画后的回调
function State_Dead:onSpineCompleteCallback(event)
	--检测是否我方队伍团灭
	if self.entity.entityType == 1 then
		self.entity:setVisible(false)
		self.entity.isTruelyDead = true
		local num = 0
		for k,v in pairs(G_Roles) do
			if v.isTruelyDead then
				num = num + 1
			end
		end
		if num == #G_Roles then
	        if G_STAGE_TYPE == 1 then
	            G_BattleScene:onBattleOver(2)
	        elseif G_STAGE_TYPE == 2 then
	        	G_BattleScene:onBattleOver(5)
	        elseif G_STAGE_TYPE == 3 then
	            G_BattleScene:onBattleOver(9)
	        end
		end
	--检测是否小怪团灭
	elseif self.entity.entityType == 2 and not self.entity.isBoss then
		self.entity:setVisible(false)
		self.entity.isTruelyDead = true

		local num = 0
		for k,v in pairs(G_Monsters) do
			if v.isTruelyDead then
				num = num + 1
			end
		end
		if num == #G_Monsters then
	        if G_STAGE_TYPE == 1 then
	            G_BattleScene:onBattleOver(1)
	        elseif G_STAGE_TYPE == 3 then
	            G_BattleScene:onBattleOver(8)
	        end
		end
	--boss死亡	
	else
		--boss的死亡特效
		local spineData = BattleCacheManager:getData(BattleGlobals.DeadEffect)
	    local effectSpineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(spineData)
	    effectSpineNode:setAnimation(0,"effect",false)
	    table.insert(G_NodesWithSpine,effectSpineNode)    

	    G_BattleLayer:addChild(effectSpineNode)

	    effectSpineNode:setPosition(cc.p(self.entity:getPositionX(),360))

	    local this = self
	    local function completeCallback(event2)
	        --删除自己，如果在事件里删除自己，必须下一帧执行。
	        local function removeSelf()
	            RemoveFromNodesWithSpine(effectSpineNode)
	            effectSpineNode:removeFromParent();
	            this.entity:setVisible(false)

		        if G_STAGE_TYPE == 1 then
		            G_BattleScene:onBattleOver(1)
		        elseif G_STAGE_TYPE == 2 then
		        	G_BattleScene:onBattleOver(4)
		        elseif G_STAGE_TYPE == 3 then
		            G_BattleScene:onBattleOver(8)
		        end
	        end
	        PerformWithDelayTime(removeSelf,0.01)
	    end

	    effectSpineNode:registerSpineEventHandler(completeCallback,sp.EventType.ANIMATION_COMPLETE)	
	end
end

--如果所有敌人都死了，全体进入idle状态
--@type 1.我方全体。2.怪物全体
function State_Dead:enterIdleState(type)
	if type == 1 then
		for k,v in pairs(G_Roles) do
			if not v.isDead and v ~= G_EntityPlayingCutin then
				v.fsm:changeState(StateEnum.Idling)
			end
		end
	else
		for k,v in pairs(G_Monsters) do
			if not v.isDead and v ~= G_EntityPlayingCutin then
				v.fsm:changeState(StateEnum.Idling)
			end
		end
	end
end

function State_Dead:Exit()
	self.super.Exit(self)
end

--掉落宝箱
function State_Dead:dropBox()
	if self.entity.data.dropNum then
		BattleUIManager:dropBox(self.entity.data.dropNum,cc.p(self.entity:getPosition()),G_BattleLayer)
	end
end