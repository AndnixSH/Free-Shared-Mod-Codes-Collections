--require "XUIView"

EqSortBoxView = class("EqSortBoxView",XUIView)
EqSortBoxView.CS_FILE_NAME = "EqSortBoxView.csb"
EqSortBoxView.CS_BIND_TABLE = 
{
    --排序 单选
    ImgbtnElement = "/i:119/i:32/s:ImgbtnElement",
    ImgbtnRank = "/i:119/i:32/s:ImgbtnRank",
    ImgbtnFP = "/i:119/i:32/s:ImgbtnFP",
    ImgbtnLevel = "/i:119/i:32/s:ImgbtnLevel",
    ImgbtnBrk = "/i:119/i:32/s:ImgbtnBrk",
    ImgbtnSk = "/i:119/i:32/s:ImgbtnSk",
    ImgbtnTime = "/i:119/i:32/s:ImgbtnTime",
    --筛选条件3项分别单独存储，通过位运算思想解析
    --稀有度 多选 --0:全部，单选
    ImgbtnRank_0 = "/i:119/i:32/s:ImgbtnRank_0",--000
    ImgbtnRank_1 = "/i:119/i:32/s:ImgbtnRank_1",--001
    ImgbtnRank_2 = "/i:119/i:32/s:ImgbtnRank_2",--010
    ImgbtnRank_3 = "/i:119/i:32/s:ImgbtnRank_3",--100
    --属性 多选 --0:全部，单选
    ImgbtnElement_0 = "/i:119/i:32/s:ImgbtnElement_0",--00000
    ImgbtnElement_1 = "/i:119/i:32/s:ImgbtnElement_1",--00001
    ImgbtnElement_2 = "/i:119/i:32/s:ImgbtnElement_2",--00010
    ImgbtnElement_3 = "/i:119/i:32/s:ImgbtnElement_3",--00100
    ImgbtnElement_4 = "/i:119/i:32/s:ImgbtnElement_4",--01000
    ImgbtnElement_5 = "/i:119/i:32/s:ImgbtnElement_5",--10000
    --突破次数 多选 --0:全部，单选
    ImgbtnBrk_0 = "/i:119/i:32/s:ImgbtnBrk_0",--00000
    ImgbtnBrk_1 = "/i:119/i:32/s:ImgbtnBrk_1",--00001
    ImgbtnBrk_2 = "/i:119/i:32/s:ImgbtnBrk_2",--00010
    ImgbtnBrk_3 = "/i:119/i:32/s:ImgbtnBrk_3",--00100
    ImgbtnBrk_4 = "/i:119/i:32/s:ImgbtnBrk_4",--01000
    ImgbtnBrk_5 = "/i:119/i:32/s:ImgbtnBrk_5",--10000
    --
    btnReset = "/i:119/i:32/s:btnReset",
    --
    btnCancel = "/i:119/i:32/i:514",
    btnOK = "/i:119/i:32/i:121",
}

--排序条件与升降序组成两位数单独存储，个位代表升降序 0：升序-1:降序;  十位代表排序条件：1-7（与sortButtons下标对应)
EqSortBoxView.stypes = 
{
    { 10,UITool.ToLocalization("属性"),"element"},
    { 20,UITool.ToLocalization("稀有度"),"rarity"},
    { 30,UITool.ToLocalization("战斗力"),"fp"},
    { 40,UITool.ToLocalization("等级"),"Lv"},
    { 50,UITool.ToLocalization("突破次数"),"brk_num"},
    { 60,UITool.ToLocalization("灵装技能"),"sk_Lv"},
    { 70,UITool.ToLocalization("入手时间"),"get_time"}
}

EqSortBoxView.rankStates = {1,0,0,0,}
EqSortBoxView.eleStates = {1,0,0,0,0,0,}
EqSortBoxView.brkStates = {1,0,0,0,0,0,}

EqSortBoxView.titleSelected = cc.c3b(255, 239, 167)
EqSortBoxView.titleNor = cc.c3b(255, 255, 255)

function EqSortBoxView:init(defmode)
    EqSortBoxView.super.init(self)

    self.defmode = defmode

    self._CurSortMode = 10 --TODO:此处需要从缓存中读取排序条件

    self.sortButtons = {
        self.ImgbtnElement,
        self.ImgbtnRank,
        self.ImgbtnFP,
        self.ImgbtnLevel,
        self.ImgbtnBrk,
        self.ImgbtnSk,
        self.ImgbtnTime,
    }

    self.rankButtons = {
        self.ImgbtnRank_0,
        self.ImgbtnRank_1,
        self.ImgbtnRank_2,
        self.ImgbtnRank_3,
    }

    self.eleButtons = {
        self.ImgbtnElement_0,
        self.ImgbtnElement_1,
        self.ImgbtnElement_2,
        self.ImgbtnElement_3,
        self.ImgbtnElement_4,
        self.ImgbtnElement_5,
    }

    self.brkButtons = {
        self.ImgbtnBrk_0,
        self.ImgbtnBrk_1,
        self.ImgbtnBrk_2,
        self.ImgbtnBrk_3,
        self.ImgbtnBrk_4,
        self.ImgbtnBrk_5,
    }

    local function btnFunc(sender)
        self:onBtnClick(sender:getTag())
    end

    local function rankBtnFunc(sender)
        self:onRankBtnClick(sender:getTag())
    end

    local function eleBtnFunc(sender)
        self:onEleBtnClick(sender:getTag())
    end

    local function brkBtnFunc(sender)
        self:onBrkBtnClick(sender:getTag())
    end

    for i = 1,#self.sortButtons do
        self.sortButtons[i]:setTag(i)
        self.sortButtons[i]:addClickEventListener(btnFunc)
    end

    for i = 1,#self.rankButtons do
        self.rankButtons[i]:setTag(i)
        self.rankButtons[i]:addClickEventListener(rankBtnFunc)
    end

    for i = 1,#self.eleButtons do
        self.eleButtons[i]:setTag(i)
        self.eleButtons[i]:addClickEventListener(eleBtnFunc)
    end

    for i = 1,#self.brkButtons do
        self.brkButtons[i]:setTag(i)
        self.brkButtons[i]:addClickEventListener(brkBtnFunc)
    end

    self.btnReset:addClickEventListener(function ()
        self:onBtnReset()
    end)

    local function returnBack()
        KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
        self:removeFromParentView()
    end

    self.btnCancel:addClickEventListener(function ()
        returnBack()
    end)

    self.btnOK:addClickEventListener(function ()
       if self._CurSortMode ~= self.selectedSortMode or
       self._selectRankVaule ~= self._nRankVaule or
       self._selectEleVaule ~= self._nEleVaule or
       self._selectBrkVaule ~= self._nBrkVaule then
            if self.beforeCloseEvent then
                self.beforeCloseEvent(self, self.selectedSortMode,self._selectRankVaule,self._selectEleVaule,self._selectBrkVaule)
            end
        end
        returnBack()
    end)

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        returnBack()
    end)

    self:setFilterMode(0,0,0)

    return self
end

function EqSortBoxView:onBtnClick(index)
    --排序选择界面只负责十位，EqSortButtonView负责各位
    local st = EqSortBoxView.stypes
    self.selectedSortMode = st[index][1]

    for i = 1,#self.sortButtons do
        if i == index then
            self.sortButtons[i]:loadTexture(EQ_SORT_BTN_IMG[2])
            self.sortButtons[i]:getChildByName("btntitle"):setColor(self.titleSelected)
        else
            self.sortButtons[i]:loadTexture(EQ_SORT_BTN_IMG[1])
            self.sortButtons[i]:getChildByName("btntitle"):setColor(self.titleNor)
        end
    end
end

function EqSortBoxView:onRankBtnClick(index)
    if index > 1 then --所点非全部
        if self.rankStates[index] > 0 then
            self.rankStates[index] = 0
        else
            self.rankStates[index] = 1
            self.rankStates[1] = 0
        end
        if self.rankStates[2] == self.rankStates[3] and self.rankStates[2] == self.rankStates[4] then --其他几个多选子选项状态统一 则全部为是 其他为非
            self.rankStates[1] = 1
            for i=2,#self.rankStates do--全部是状态其他选项为非状态
                self.rankStates[i] = 0
            end
        else--其他状态不一致则全部非状态
            self.rankStates[1] = 0
        end
    else --点击全部（非状态可改变为是状态，不可逆向）
        if self.rankStates[index] == 0 then
            self.rankStates[1] = 1
            for i=2,#self.rankStates do--全部是状态其他选项为非状态
                self.rankStates[i] = 0
            end
        end
    end
    self._selectRankVaule = self:GetRankVaule()
    self:RefreshFilterBtns()
end

function EqSortBoxView:onEleBtnClick(index)
    if index > 1 then --所点非全部
        if self.eleStates[index] > 0 then
            self.eleStates[index] = 0
        else
            self.eleStates[index] = 1
            self.eleStates[1] = 0
        end
        if self.eleStates[2] == self.eleStates[3] and 
            self.eleStates[2] == self.eleStates[4] and 
            self.eleStates[2] == self.eleStates[5] and 
            self.eleStates[2] == self.eleStates[6] then --其他几个多选子选项状态统一 则全部为是 其他为非
            self.eleStates[1] = 1
            for i=2,#self.eleStates do--全部是状态其他选项为非状态
                self.eleStates[i] = 0
            end
        else--其他状态不一致则全部非状态
            self.eleStates[1] = 0
        end
    else --点击全部（非状态可改变为是状态，不可逆向）
        if self.eleStates[index] == 0 then
            self.eleStates[1] = 1
            for i=2,#self.eleStates do--全部是状态其他选项为非状态
                self.eleStates[i] = 0
            end
        end
    end
    self._selectEleVaule = self:GetEleVaule()
    self:RefreshFilterBtns()
end

function EqSortBoxView:onBrkBtnClick(index)
    if index > 1 then --所点非全部
        if self.brkStates[index] > 0 then
            self.brkStates[index] = 0
        else
            self.brkStates[index] = 1
            self.brkStates[1] = 0
        end
        if self.brkStates[2] == self.brkStates[3] and 
            self.brkStates[2] == self.brkStates[4] and 
            self.brkStates[2] == self.brkStates[5] and 
            self.brkStates[2] == self.brkStates[6] then --其他几个多选子选项状态统一 则全部为是 其他为非
            self.brkStates[1] = 1
            for i=2,#self.brkStates do--全部是状态其他选项为非状态
                self.brkStates[i] = 0
            end
        else--其他状态不一致则全部非状态
            self.brkStates[1] = 0
        end
    else --点击全部（非状态可改变为是状态，不可逆向）
        if self.brkStates[index] == 0 then
            self.brkStates[1] = 1
            for i=2,#self.brkStates do--全部是状态其他选项为非状态
                self.brkStates[i] = 0
            end
        end
    end
    self._selectBrkVaule = self:GetBrkVaule()
    self:RefreshFilterBtns()
end

function EqSortBoxView:onBtnReset()
    --初始化按钮：全部初始化为最初默认状态
    if self.rankStates then
        for i=1,#self.rankStates do
            self.rankStates[i] = 0
        end
        self.rankStates[1] = 1
    end
    if self.eleStates then
        for i=1,#self.eleStates do
            self.eleStates[i] = 0
        end
        self.eleStates[1] = 1
    end
    if self.brkStates then
        for i=1,#self.brkStates do
            self.brkStates[i] = 0
        end
        self.brkStates[1] = 1
    end
    if self._selectRankVaule then
        self._selectRankVaule = 0
    end
    if self._selectEleVaule then
        self._selectEleVaule = 0
    end
    if self._selectBrkVaule then
        self._selectBrkVaule = 0
    end
    --排序规则重置为最初默认状态
    if self.defmode then
        self:setSortMode(self.defmode)
    end
    
    self:RefreshFilterBtns()
end

function EqSortBoxView:GetRankVaule()
    local nRankVaule = 0
    for i=2,#self.rankStates do
        nRankVaule = nRankVaule + self.rankStates[i]*(math.pow(10,i-2))
    end
    return nRankVaule
end

function EqSortBoxView:SetRankVaule(nRankVaule)
    self._nRankVaule = nRankVaule
    self._selectRankVaule = nRankVaule
    local n_RankVaule = nRankVaule
    for i=#self.rankStates,2,-1 do
        self.rankStates[i] = math.floor(n_RankVaule/(math.pow(10,i-2)))
        if self.rankStates[i] > 0 then
            n_RankVaule = n_RankVaule - math.pow(10,i-2)
        end
    end
    if self.rankStates[2] == self.rankStates[3] and self.rankStates[2] == self.rankStates[4] then --其他几个多选子选项状态统一 则全部为是 其他为非
        self.rankStates[1] = 1
        for i=2,#self.rankStates do--全部是状态其他选项为非状态
            self.rankStates[i] = 0
        end
    else--其他状态不一致则全部非状态
        self.rankStates[1] = 0
    end
end

function EqSortBoxView:GetEleVaule()
    local nEleVaule = 0
    for i=2,#self.eleStates do
        nEleVaule = nEleVaule + self.eleStates[i]*(math.pow(10,i-2))
    end
    return nEleVaule
end

function EqSortBoxView:SetEleVaule(nEleVaule)
    self._nEleVaule = nEleVaule
    self._selectEleVaule = nEleVaule
    local n_EleVaule = nEleVaule
    for i=#self.eleStates,2,-1 do
        self.eleStates[i] = math.floor(n_EleVaule/(math.pow(10,i-2)))
        if self.eleStates[i] > 0 then
            n_EleVaule = n_EleVaule - math.pow(10,i-2)
        end
    end
    if self.eleStates[2] == self.eleStates[3] and 
    self.eleStates[2] == self.eleStates[4] and 
    self.eleStates[2] == self.eleStates[5] and 
    self.eleStates[2] == self.eleStates[6] then --其他几个多选子选项状态统一 则全部为是 其他为非
        self.eleStates[1] = 1
        for i=2,#self.eleStates do--全部是状态其他选项为非状态
            self.eleStates[i] = 0
        end
    else--其他状态不一致则全部是状态
        self.eleStates[1] = 0
    end
end

function EqSortBoxView:GetBrkVaule()
    local nBrkVaule = 0
    for i=2,#self.brkStates do
        nBrkVaule = nBrkVaule + self.brkStates[i]*(math.pow(10,i-2))
    end
    return nBrkVaule
end

function EqSortBoxView:SetBrkVaule(nBrkVaule)
    self._nBrkVaule = nBrkVaule
    self._selectBrkVaule = nBrkVaule
    local n_BrkVaule = nBrkVaule
    for i=#self.brkStates,2,-1 do
        self.brkStates[i] = math.floor(n_BrkVaule/(math.pow(10,i-2)))
        if self.brkStates[i] > 0 then
            n_BrkVaule = n_BrkVaule - math.pow(10,i-2)
        end
    end
    if self.brkStates[2] == self.brkStates[3] and 
    self.brkStates[2] == self.brkStates[4] and 
    self.brkStates[2] == self.brkStates[5] and 
    self.brkStates[2] == self.brkStates[6] then --其他几个多选子选项状态统一 则全部为是 其他为非
        self.brkStates[1] = 1
        for i=2,#self.brkStates do--全部是状态其他选项为非状态
            self.brkStates[i] = 0
        end
    else--其他状态不一致则全部是状态
        self.brkStates[1] = 0
    end
end

function EqSortBoxView:RefreshFilterBtns()
    for i = 1,#self.rankButtons do
        if self.rankStates[i] > 0 then
            self.rankButtons[i]:loadTexture(EQ_SORT_BTN_IMG[2])
            self.rankButtons[i]:getChildByName("btntitle"):setColor(self.titleSelected)
        else
            self.rankButtons[i]:loadTexture(EQ_SORT_BTN_IMG[1])
            self.rankButtons[i]:getChildByName("btntitle"):setColor(self.titleNor)
        end
    end
    for i = 1,#self.eleButtons do
        if self.eleStates[i] > 0 then
            self.eleButtons[i]:loadTexture(EQ_SORT_BTN_IMG[2])
            self.eleButtons[i]:getChildByName("btntitle"):setColor(self.titleSelected)
        else
            self.eleButtons[i]:loadTexture(EQ_SORT_BTN_IMG[1])
            self.eleButtons[i]:getChildByName("btntitle"):setColor(self.titleNor)
        end
    end
    for i = 1,#self.brkButtons do
        if self.brkStates[i] > 0 then
            self.brkButtons[i]:loadTexture(EQ_SORT_BTN_IMG[2])
            self.brkButtons[i]:getChildByName("btntitle"):setColor(self.titleSelected)
        else
            self.brkButtons[i]:loadTexture(EQ_SORT_BTN_IMG[1])
            self.brkButtons[i]:getChildByName("btntitle"):setColor(self.titleNor)
        end
    end
end

function EqSortBoxView:setFilterMode(nRankVaule,nEleVaule,nBrkVaule)
    self:SetRankVaule(nRankVaule)
    self:SetEleVaule(nEleVaule)
    self:SetBrkVaule(nBrkVaule)
    self:RefreshFilterBtns()
end

function EqSortBoxView:setSortMode(sortMode)
    self._CurSortMode = sortMode
    local st = EqSortBoxView.stypes

    local num = math.floor(sortMode / 10)
    for i = 1,#st do
        local num1 = math.floor(st[i][1]/10)
        if num == num1 then
            self:onBtnClick(i)
            break
        end
    end
end

function EqSortBoxView.GetSortName(sortMode)
    local names = EqSortBoxView.stypes
    local num = math.floor(sortMode / 10)

    for i = 1,#names do
        local num1 = math.floor(names[i][1]/10)
        if num == num1 then
            return UITool.ToLocalization(names[i][2])
        end
    end
    return nil
end

function EqSortBoxView.GetSortVaule(sortMode)
    local names = EqSortBoxView.stypes
    local num = math.floor(sortMode / 10)

    for i = 1,#names do
        local num1 = math.floor(names[i][1]/10)
        if num == num1 then
            return names[i][3]
        end
    end
    return nil
end

function EqSortBoxView.SortEquip(dataSet,str)
    --新的排序机制放于后端实现，保留新手引导等特殊需求
    --GameManagerInst:alert("EqSortBoxView.SortEquip")
    local sor_s = nil
    
    local compFunc = nil
    compFunc = function(a,b) return a < b end
    sor_s = function (item) return item["index"] end
    if sor_s == nil then
      return
    end
    
    table.sort(dataSet,function(x,y)
        return compFunc(sor_s(x),sor_s(y))
    end)
    -----------------------新手引导特殊排序
   
    ---现在改成 固定ID 的装备
    local function guideSortFunc(s_e_iD)
        local function isSelect(c_e_iD)
            local isIn = 0
            if c_e_iD == s_e_iD then 
                isIn = 1
            end 
            return isIn
        end
        local function newGuideSort(a,b)

            local _a = isSelect(getNumID(a.id))
            local _b = isSelect(getNumID(b.id))
            return _a > _b
        end
        table.sort(dataSet, newGuideSort)
    end 

    -- --穿装备 火属性在前
    -- if  NewGuideManager.isStartWeakGuide and  NewGuideManager._nowGuideID == guide_id_config.Equipment then
    --     local e_iD = 132300  -- 固定ID
    --     guideSortFunc(e_iD)
    -- end
end