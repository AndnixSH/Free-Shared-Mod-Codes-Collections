--伤害展示
BattleDamageDisplay = {}

function BattleDamageDisplay:create(pos, str_,flyType )
    self:playFontAnimation(str_,flyType,pos)
end

function BattleDamageDisplay:init()
	self.font_num_crit     = "font/hit_bj.fnt"       --暴击数字
    self.font_char_crit    = "font/text_bj.fnt"      --暴击文字

	self.font_num_addHp    = "font/hit_jx.fnt"       --加血数字
	self.font_num_normal   = "font/hit_pt.fnt"       --普通伤害数字
	self.font_char_normal  = "font/text_miss.fnt"    --闪避、未命中、免疫、吸收等文字

    self.font_num_block = "font/hit_gdpt.fnt"         --格挡的数字
    self.font_char_block = "font/text_gd_0.fnt"       --格挡的文字

    self.font_num_crit_block = "font/hit_gdbj.fnt"       --暴击被格挡的数字
    self.font_char_crit_block = "font/text_gd.fnt"       --暴击被格挡的文字
end
--随机位置显示
function BattleDamageDisplay:setRandomPosition( pos,rootNode)
    local m  = GetRandomBetweenAB(1, 40) - 20
    rootNode:setPosition(pos.x+m,pos.y+m)
end

--@str_:伤害值。传入-1表示不显示伤害值。
--@flyType:类型    
function BattleDamageDisplay:playFontAnimation(str_,flyType,pos)
    local rootNode = self:createNodePanel()
    local panel_1  = rootNode:getChildByTag(1)
    G_EffectLayer:addChild(rootNode)

    local aniType = 0--aniType:1.暴击。2.格挡。3.暴击被格挡。0.其他通用
    
    --常规lalel。可能是攻击数值，也可能是“闪避”等文字
    local normalLabel = ccui.TextBMFont:create()
    normalLabel:setAnchorPoint(1,1)
    normalLabel:setPosition(66,15)
    panel_1:addChild(normalLabel)

    if str_ ~= -1 then
        normalLabel:setString(str_);
    end

    if flyType == DamageFontType.Normal then             --普通伤害
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_normal);
    elseif flyType == DamageFontType.Normal_Crit then    --暴击
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_crit);
        aniType = 1
    elseif flyType == DamageFontType.Poison then         -- 中毒
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_normal);
    elseif flyType == DamageFontType.Block then          -- 格挡
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_block);
        aniType = 2
    elseif flyType == DamageFontType.AddHP then          -- 加血
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_addHp);
    elseif flyType == DamageFontType.Miss then           -- 未命中
        rootNode:setPosition(pos)
        normalLabel:setString(UITool.ToLocalization("未命中"));
        normalLabel:setFntFile(self.font_char_normal);
    elseif flyType == DamageFontType.Dodge then          -- 闪避
        rootNode:setPosition(pos)
        normalLabel:setString(UITool.ToLocalization("闪避"));
        normalLabel:setFntFile(self.font_char_normal);
    elseif flyType == DamageFontType.Crit_Block then     --暴击被格挡
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_normal);
        aniType = 3        
    elseif flyType == DamageFontType.Immune then         -- 免疫
        rootNode:setPosition(pos)
        normalLabel:setString(UITool.ToLocalization("免疫"));
        normalLabel:setFntFile(self.font_char_normal);
    elseif flyType == DamageFontType.Absorb then         -- 吸收
        rootNode:setPosition(pos)
        normalLabel:setString(UITool.ToLocalization("吸收"));
        normalLabel:setFntFile(self.font_char_normal);
    elseif flyType == DamageFontType.SelfHPLoss then     -- 自身掉血（有些技能减自己的血）
        self:setRandomPosition(pos,rootNode)
        normalLabel:setFntFile(self.font_num_normal);
    else                                                 
        print("没设置字体")
    end

    --暴击、格挡的特殊动画
    if aniType ~= 0 then
        self:createSpecialChar(panel_1,aniType)
        self:playSpecialAction(panel_1,rootNode)    
    --常规动画
    else
        self:playNormalAction(panel_1,rootNode)
    end
end

-- 创建显示飘字的node
function BattleDamageDisplay:createNodePanel()
    local Node=cc.Node:create()
    local Panel_1 = ccui.Layout:create()
    Panel_1:ignoreContentAdaptWithSize(false)
    Panel_1:setClippingEnabled(false)
    Panel_1:setBackGroundColorType(1)
    Panel_1:setTag(1)
    Panel_1:setBackGroundColor({r = 150, g = 200, b = 255})
    Panel_1:setBackGroundColorOpacity(102)
    Panel_1:setLayoutComponentEnabled(true)
    Panel_1:setCascadeColorEnabled(true)
    Panel_1:setCascadeOpacityEnabled(true)
    Panel_1:setAnchorPoint(0.5, 0.5)
    Panel_1:setScaleX(0.5)
    Panel_1:setScaleY(0.5)
    Node:addChild(Panel_1)
    return Node
end

--创建特殊文字。例如，暴击，格挡。
--@type:1.暴击。2.格挡。3.暴击被格挡
-- 显示“暴击”文字的label
function BattleDamageDisplay:createSpecialChar(panel,type)
    local label = ccui.TextBMFont:create()
    label:setPosition(122, 15)
    panel:addChild(label)
    --暴击    
    if type == 1 then
        label:setFntFile(self.font_char_crit)
        label:setString(UITool.ToLocalization("暴击"))
    --格挡
    elseif type == 2 then
        label:setFntFile(self.font_char_block)
        label:setString(UITool.ToLocalization("格挡"))
    --暴击被格挡
    else
        label:setFntFile(self.font_char_crit_block)
        label:setString(UITool.ToLocalization("暴击"))
    end

end

-- 播放暴击、格挡、暴击被格挡的动画
function BattleDamageDisplay:playSpecialAction( panel,rootNode )
    local scale1   = cc.ScaleTo:create(0.066,1.2)--0.17
    local scale2   = cc.ScaleTo:create(0.033,1)
    local scale3   = cc.ScaleTo:create(0.033,1.2)
    local scale4   = cc.ScaleTo:create(0.033,1)
    local delay   = cc.DelayTime:create(0.25)--0.25
    local fadeout = cc.FadeOut:create(0.17) --0.17
    local function callBack()
        rootNode:removeFromParent()
    end 
    local sq = cc.Sequence:create(scale1,scale2,scale3,scale4,delay,fadeout,cc.CallFunc:create(callBack))
    panel:runAction(sq)
end

-- 播放常规动画
function BattleDamageDisplay:playNormalAction( panel,rootNode )
    local move     = cc.MoveTo:create(0,cc.p(0,0))
    local scale    = cc.ScaleTo:create(0,0.01)
    local scale1   = cc.ScaleTo:create(0.06,1,1)
    local move1    = cc.MoveTo:create(0.283,cc.p(0,90))
    local move2    = cc.MoveTo:create(0.21,cc.p(0,140))
    local fadeout  = cc.FadeOut:create(0.21)
    local spawn  = cc.Spawn:create(move,scale)
    local spawn1 = cc.Spawn:create(move2,fadeout)
    local function callBack()
        rootNode:removeFromParent()
    end 
    local sq = cc.Sequence:create(spawn,scale1,move1,spawn1,cc.CallFunc:create(callBack))
    panel:runAction(sq)
end