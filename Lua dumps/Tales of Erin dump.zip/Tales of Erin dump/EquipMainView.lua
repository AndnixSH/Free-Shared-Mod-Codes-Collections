--require "XUIView"

EquipMainView = class("EquipMainView",XUIView)
EquipMainView.CS_FILE_NAME = "EquipMainView.csb"
EquipMainView.CS_BIND_TABLE = 
{
    vpanel="/i:58",
    btnTab1="/i:42/i:43",
    btnTab2="/i:42/i:55",
    btnTab3="/i:42/i:56",
    btnTab4="/i:42/i:57",
    btnClose="/i:59/i:61",

    panelRight = "/i:42",

    panelSale = "/i:634",
    btnSaleCancel = "/i:634/i:778",
    btnSaleOK = "/i:634/i:776",
    lbSaleCur = "/i:634/i:810/i:813",
    lbSaleSel = "/i:634/i:814/i:817"
}

function EquipMainView:init(tab)
    EquipMainView.super.init(self)
    
    self.views = XUIView.new():init(self.vpanel)

    self.equipSkillView = EquipSkillView.new():init()
    self.views:addSubView(self.equipSkillView)

    self.equipSthView = EquipSthView.new():init()
    self.equipSthView.matChangedEvent = function()
        self:loadBagList()
    end
    self.views:addSubView(self.equipSthView)

    self.equipAwakenView = EquipAwakenView.new():init()
    self.views:addSubView(self.equipAwakenView)
    self.exist = true;
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    print("@@KeyboardManager:registeredKeyBoardEvent..."..tostring(self.keyboardValue))
    self.equipListView = EquipListView.new():init()
    self.equipListView.ItemClickedEvent = function(item)
        if self.isSaleMode then
            local dat = item:getData()
            if dat._isselected then
                dat._isselected = false
                item:setSelected(false)
            else
                dat._isselected = true
                item:setSelected(true)
            end
            self:computeMoney()
        else

            local elist = {}
            local tempds = self.equipListView.currentDataSource
            for i = 1,#tempds do
                table.insert(elist,tempds[i].id)
            end
            if GameManagerInst.gameType == 1 then
                GameManagerInst.view:pushView(EquipInfoView.new():init(item:getData().id))
            elseif GameManagerInst.gameType == 2 then
                SceneManager:toEquipInfo({ eid = item:getData().id,
                elist = elist})
            end
        end
    end
    self.equipListView.dataSourceEvent = function(sender,sortmode)
        local dataset = {}
        if self.isSaleMode then
            for i = 1,#equip_list do
                if equip_list[i]["owner"] == "0" and (not equip_list[i]["is_lock"]) then
                    table.insert(dataset,table.deepcopy(equip_list[i]))
                end
            end
            self.datasetForSale = dataset
        else
            dataset =  table.deepcopy(equip_list)
            -- for i = 1,#equip_list do
            --     if equip_list[i]["owner"] == "0" then
            --         table.insert(dataset,table.deepcopy(equip_list[i]))
            --     end
            -- end
        end
        if g_channel_control.b_newEqBag then
            EqSortBoxView.SortEquip (dataset, sortmode)
        else
            SortBoxView.SortEquip (dataset, sortmode)
        end
        return dataset
    end
    self.equipListView.ItemResetEvent = function(item)
        if self.isSaleMode then
            item:setSelected(item:getData()._isselected)
        end
    end
    self.views:addSubView(self.equipListView)

    self:switchView(tab)

    self.btnTab1:setPressedActionEnabled(false)
    self.btnTab1:addClickEventListener(function()
        self:switchView(1)
    end)

    self.btnTab2:setPressedActionEnabled(false)
    self.btnTab2:addClickEventListener(function()
        self:switchView(2)
    end)

    self.btnTab3:setPressedActionEnabled(false)
    self.btnTab3:addClickEventListener(function()
        self:switchView(3)
    end)

    self.btnTab4:setPressedActionEnabled(false)
    self.btnTab4:addClickEventListener(function()
        self:switchView(4)
    end)

    --贩卖相关
    
    self.equipListView:setTopBtn("贩卖",function()
        self:startSaleMode()
        self.equipListView:refresh()
    end,self.endSaleMode,self)

    self.btnSaleOK:addClickEventListener(function()
        self:confirmSaleEquip()
    end)

    self.btnSaleCancel:addClickEventListener(function()
        self:endSaleMode()
        self.equipListView:refresh()
    end)

    self:endSaleMode()
    --

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:returnBack()
    end)
    
    self.dataLoaded = false

    self.bHideAllEquip = false

    self:setNodeLockState()


    return self
end

function EquipMainView:startSaleMode()
    self.isSaleMode = true
    self.panelSale:setVisible(true)
    self.panelRight:setVisible(false)
    self.equipListView:setTopBtnVisible(false)
    --self.equipListView:refresh()
    self:computeMoney()
end

function EquipMainView:endSaleMode()
    self.isSaleMode = false
    self.datasetForSale = nil   
    self.panelSale:setVisible(false)
    self.panelRight:setVisible(true)
    self.equipListView:setTopBtnVisible(true)
    --self.equipListView:refresh()
end

function EquipMainView:computeMoney()
    if self.isSaleMode then
        self.lbSaleCur:setString(""..user_info["gold"])
        local money = 0
        if self.datasetForSale then
            for i = 1,#self.datasetForSale do
                if self.datasetForSale[i]._isselected then
                    money = money + self.datasetForSale[i].sell
                end
            end
        end
        self.lbSaleSel:setString(""..money)
    end
end

function EquipMainView:confirmSaleEquip()
    if not self.isSaleMode then return end
    if not self.datasetForSale then return end

    local ds = {}
    local hasR5 = false

    for i = 1,#self.datasetForSale do
        local obj = self.datasetForSale[i]
        if obj._isselected then
            table.insert(ds,obj)
            if obj["rarity"] == 5 then
                hasR5 = true
            end
        end
    end

    if #ds == 0 then
        --没选装备
        GameManagerInst:alert(UITool.ToLocalization("没有选择灵装"))
        return
    end

    if hasR5 then
        GameManagerInst:confirm(UITool.ToLocalization("您选中将要出售的道具中有高星级稀有度道具，\n是否继续出售？"),function()
            self:commitSaleEquip(ds)
        end)
    else
        self:commitSaleEquip(ds)
    end
end

function EquipMainView:commitSaleEquip(ds)

    local tempTable = {
        ["rpc"] = "eq_sell",
        ["eq_list"] = {},

    }

    for i = 1,#ds do
        table.insert(tempTable["eq_list"],ds[i].id)
    end


    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        DataManager:dEquipData(ds)
        DataManager:wGold(data["gold"])

        if g_channel_control.b_newEqBag then
            self:refresh()
        else
            self.equipListView:refresh()
        end

        for i=1,#ds do
            if self.datasetForSale then
                for j = 1,#self.datasetForSale do
                    if self.datasetForSale[j].id == ds[i].id then
                        self.datasetForSale[j]._isselected = false
                    end
                end
            end
            self.equipAwakenView:onSaleEquip(ds[i].id)
            self.equipSkillView:onSaleEquip(ds[i].id)
        end
        
        self:computeMoney()

        if GameManagerInst.gameType == 2 then
            SceneManager.menuLayer:RefshTopBar()
        end
        
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipMainView:refresh()
    if self.exist ==  false then 
        return
    end
    if g_channel_control.b_newEqBag then
        if self.curTab == 1 then
            if self.nCurSkLockedEid and self.nCurSkLockTargetEquiped then
                self.equipSkillView:ReLoadDataInLocked(self.nCurSkLockedEid,self.nCurSkLockTargetEquiped)
            else
                self.equipSkillView:ReLoadDataInSwitch()                
            end
        elseif self.curTab == 2 then
            self.equipSthView:ReLoadData()
        elseif self.curTab == 3 then
            if self.nCurAwLockedEid and self.nCurAwLockTargetEquiped then
                self.equipAwakenView:ReLoadDataInLocked(self.nCurAwLockedEid,self.nCurAwLockTargetEquiped)
            else
                self.equipAwakenView:ReLoadDataInSwitch()                
            end
        elseif self.curTab == 4 then
            self.equipListView:ReLoadData()
        end
    else
        if self.dataLoaded then
            if self.curTab == 1 then
                self.equipSkillView:refresh()
            elseif self.curTab == 2 then
                self.equipSthView:refresh()
            elseif self.curTab == 3 then
                self.equipAwakenView:refresh()
            elseif self.curTab == 4 then
                self.equipListView:refresh()
            end
        end
    end

    --设置小红点状态  灵装强化
    UITool.setCommmonBtnRedDop(self.btnTab2,false)
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.StEquip) == 0 then 
        UITool.setCommmonBtnRedDop(self.btnTab2,true,cc.p(150,70))
    end 
end

function EquipMainView:switchView(tab)
    local num = tab or 1
    if self.curTab ~= num then
    
        local ctls = {
            {btn = self.btnTab1, view= self.equipSkillView},
            {btn = self.btnTab2, view= self.equipSthView},
            {btn = self.btnTab3, view= self.equipAwakenView},
            {btn = self.btnTab4, view= self.equipListView}
        }

        for i = 1,#ctls do  
            ctls[i].btn:setTouchEnabled(i ~= num)
            ctls[i].btn:setBright(i ~= num)
            ctls[i].view:getRootNode():setVisible(i == num)
        end
        self.curTab = num
        self:refresh()
    end
    --首次进入 显示说明 key 统一用类名吧
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."EquipMainView_"..num) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."EquipMainView_"..num, 1)
        self:showGuidePicLayer(num)
    end
end

function EquipMainView:showGuidePicLayer(tag)
    local pics = {
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_lzrh_001.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_lzqh_001.png",
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_lztp_001.png",
    }
    if tag ~= 4 then 
        local data = {}
        data.pictures = { --一张或者多张
            pics[tag]
        }
        SceneManager:toGuidePictureLayer(data)       
    end 
end

function EquipMainView:loadBagList()
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
		DataManager:wAllBagData(data["bag"])        
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipMainView:beginLoadData()
    local tempData = {}
    if g_channel_control.b_newEqBag then
        tempData = { 
            rpc = "eq_list",
            rarity = {3,4,5},
            element = {1,2,3,4,5,0},
            brk_num = {1,2,3,4,0},
            key = "element",
            reverse = 0,
            equipped = 0,
        }
    else
        tempData = { 
            rpc = "eq_list"
        }
    end

    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        if g_channel_control.b_newEqBag then
            user_info["eq_num"] =  data["eq_num"]
        end
        DataManager:rfsElist()       
        --DataManager:wAllBagData({mat = data["mat"]})
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end


        --self.equipListView:setDataSource(equip_list)
        self.dataLoaded = true
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function EquipMainView:returnBack()
    if self.equipAwakenView then
        self.equipAwakenView:DestroyHandle()
    end
    if self.equipSkillView then
        self.equipSkillView:DestroyHandle()
    end
    if self.equipSthView then
        self.equipSthView:DestroyHandle()
    end
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self.exist = false;
    if self._navigationView then
        self._navigationView:popView()
    end
end


function EquipMainView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        self:refresh()
    else
        if g_channel_control.b_newEqBag then
            --self:beginLoadData()
        else
            self:beginLoadData()
        end
    end

end

--设置按钮等级解锁状态
function EquipMainView:setNodeLockState()
    local curNodes = {self.btnTab1, self.btnTab2, self.btnTab3}
    for i=1,#curNodes do
        local config = guide_rank_config["EquipMainView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        end 
    end   
end

--设置强化锁定选择ID
function EquipMainView:lockSthTargetID(id,nEquiped)
    self.equipSthView:lockSthTargetID(id,nEquiped)
end

--设置突破锁定选择ID
function EquipMainView:lockAwakenTarget(id,nEquiped)
    self.nCurAwLockedEid = id
    self.nCurAwLockTargetEquiped = nEquiped
    self.equipAwakenView:lockAwakenTarget(id,nEquiped)
end

--设置融合锁定选择ID
function EquipMainView:lockSkillTarget(id,nEquiped)
    self.nCurSkLockedEid = id
    self.nCurSkLockTargetEquiped = nEquiped
    self.equipSkillView:lockSkillTarget(id,nEquiped)
end

--设置灵装一览按钮显示
function EquipMainView:setHideAllEquip(bHide)
    self.bHideAllEquip = bHide
    if self.bHideAllEquip then
        self.btnTab4:setVisible(false)
        self.btnTab4:setTouchEnabled(false)

        local ctls = {
            {btn = self.btnTab1, view= self.equipSkillView},
            {btn = self.btnTab2, view= self.equipSthView},
            {btn = self.btnTab3, view= self.equipAwakenView},
        }

        for i = 1,#ctls do  
            ctls[i].btn:setPosition(cc.p(ctls[i].btn:getPositionX(),ctls[i].btn:getPositionY() + 120))
        end
    else
        self.btnTab4:setVisible(true)
        self.btnTab4:setTouchEnabled(true)
    end
end


