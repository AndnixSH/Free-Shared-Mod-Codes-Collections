--require "XUICellView"

EquipListItemView = class("EquipListItemView", XUICellView)
EquipListItemView.CS_FILE_NAME = "EquipListItemView.csb"
EquipListItemView.CS_BIND_TABLE = 
{
    touchPanel = "/i:221",
    imgBG = "/i:29/i:30/i:39",
    imgFace = "/i:29/i:30/i:40",
    imgRarity = "/i:29/i:30/i:38",
    imgElement = "/i:29/i:30/i:41",
    inTeamFlag = "/i:29/i:36",
    inTeamText = "/i:29/i:36/i:45",
    atkdefPanel = "/i:29/i:44",
    rankPanel = "/i:29/i:41",
    zhanliPanel = "/i:29/i:42",
    rankImg1 = "/i:29/i:41/i:44",
    rankImg2 = "/i:29/i:41/i:45",
    rankImg3 = "/i:29/i:41/i:46",
    rankImg4 = "/i:29/i:41/i:47",
    lbATK = "/i:29/i:44/i:42",
    lbHP = "/i:29/i:44/i:43",
    lbZhanli = "/i:29/i:42/i:50",
    lbZhanliName ="/i:29/i:42/i:49",
    imgUnequip = "/i:29/i:295",
    panSelArrow = "/i:29/i:298",
    redPoint = "/i:29/i:103",
    newTwoPanel = "/i:29/i:157",
    lbTwoATK = "/i:29/i:157/i:164",
    lbTwoHP = "/i:29/i:157/i:165",
    lbTwoBrkCount = "/i:29/i:157/i:161",
    lbTwoBrkBar = "/i:29/i:157/i:160",
    --
    newOnePanel = "/i:29/i:150",
    lbOneTitle = "/i:29/i:150/i:155",
    lbOneNum = "/i:29/i:150/i:156",
    lbOneBrkCount = "/i:29/i:150/i:154",
    lbOneBrkBar = "/i:29/i:150/i:153",
}

function EquipListItemView:init(...)
    EquipListItemView.super.init(self,...)
    self.imgUnequip:setVisible(false)  --n_UIShare\equip\list\ggsc_ui_221.png   --锁 n_UIShare/equip/list/lzsd_ui_001.png
    self.panSelArrow:setVisible(false) 
    self.redPoint:setVisible(false)
    self.inTeamFlag:setAnchorPoint(cc.p(1,0))
    self.inTeamFlag:setPosition(cc.p(162,70))
    --self.inTeamFlag:setScale(0.8)
    self.inTeamText:removeFromParent()   --"队伍中"
    self.inTeamText = nil
        
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)

    return self
end

function EquipListItemView:setSelected(sel)
    self.panSelArrow:setVisible(sel)
end

function EquipListItemView:setShadow(b)
    if b then
        self.touchPanel:setBackGroundColorType(LAYOUT_COLOR_SOLID)
        self.touchPanel:setBackGroundColor(cc.c3b(0,0,0))
        self.touchPanel:setOpacity(153)
    else
        self.touchPanel:setBackGroundColorType(LAYOUT_COLOR_NONE)
    end
end

--[[
            # 装备唯一id
        "2*1299656992": {
            "element": 4,       # 元素类型: 1水 2火 3风 4光 5暗
            "rarity": 5,       # 角色稀有度
            "Lv": 1,            # 当前等级(1-N)
            "Lv_max": 40,       # 等级上限
            "exp": 0,           # 当前经验
            "exp_max": 130,     # 升级需要的经验
            "sell": 5000,       # 贩卖价格(金币) 
            "owner": "0",       # 所有者(对应角色ID), 未被装备,则为0. 这个ID存在于hero的eq属性里
            "is_lock": False,   # 是否锁定 
            # 增加的固有属性: (程序里做检测, 有哪个加哪个)
            "hp": 48,          # 加的血量
            "atk": 295,        # 加的攻击力
            "brk_num":10,
            "fp":100,   #战斗力
            # 装备附属的技能(如果没有技能, 为{})
            "sk": {
                "Lv": 1,       # 技能等级
                "provide_sk_exp": 500,    # 提供技能经验
                "up_need_exp": 100,       # 技能升级所需经验
                "add_atk_rate": 0.06,     # 光属性角色攻击力上升6%
                "next_add_atk":0.01,      # 升级所带来的技能提升
            },  
        },
    },
    "mat": {"mat_1": 66, },# 只返回强化素材 
]]
function EquipListItemView:setTitleMode(mode)
    self.atkdefPanel:setVisible(false)
    self.zhanliPanel:setVisible(false)
    self.rankPanel:setVisible(false)
    self.newTwoPanel:setVisible(false)
    self.newOnePanel:setVisible(false)
    
    if g_channel_control.transform_EquipListItemView_Text_3_pos == true then
    	self.lbZhanli:setAnchorPoint(cc.p(0.5,0.5))
        local x = 155 - 32
    	self.lbZhanli:setPositionX(x)
    end
    
    if g_channel_control.b_newEqBag then
        if mode == 6 then
            --技能等级
            self.newOnePanel:setVisible(true)
            self.lbOneTitle:setString(UITool.ToLocalization("技能等级"))
            self.lbOneNum:setString(self._data["sk"]["Lv"])
            self.lbOneBrkCount:setString(""..self._data["brk_num"])
            local  breakCount  = self._data["brk_num"] -- 突破次数
            local  breakRarity  = self._data["rarity"]  -- 品质
            local  breakLimit  = #AwakenNum[breakRarity]  -- 最大突破次数
            self.lbOneBrkBar:setPercent(100*breakCount/breakLimit)
        elseif mode == 5 then
            --突破次数
            self.rankPanel:setVisible(true)
            for i=1,4 do    
                if i <= self._data.brk_num then
                    self["rankImg"..i]:setVisible(true)
                    self["rankImg"..i]:setTexture("n_UIShare/equip/info/xqzx_ui_004.png")
                else
                    self["rankImg"..i]:setVisible(false)
                end
            end
        elseif mode == 3 then
            --战斗力
            self.newOnePanel:setVisible(true)
            self.lbOneTitle:setString(UITool.ToLocalization("战斗力"))
            self.lbOneNum:setString(self._data.fp)
            self.lbOneBrkCount:setString(""..self._data["brk_num"])
            local  breakCount  = self._data["brk_num"] -- 突破次数
            local  breakRarity  = self._data["rarity"]  -- 品质
            local  breakLimit  = #AwakenNum[breakRarity]  -- 最大突破次数
            self.lbOneBrkBar:setPercent(100*breakCount/breakLimit)
        elseif mode == 4 then
            --等级
            self.newOnePanel:setVisible(true)
            self.lbOneTitle:setString(UITool.ToLocalization("等级"))
            self.lbOneNum:setString(self._data.Lv)
            self.lbOneBrkCount:setString(""..self._data["brk_num"])
            local  breakCount  = self._data["brk_num"] -- 突破次数
            local  breakRarity  = self._data["rarity"]  -- 品质
            local  breakLimit  = #AwakenNum[breakRarity]  -- 最大突破次数
            self.lbOneBrkBar:setPercent(100*breakCount/breakLimit)
        else
            --攻击力，血量
            self.newTwoPanel:setVisible(true)
            self.lbTwoATK:setString(""..self._data["atk"])
            self.lbTwoHP:setString(""..self._data["hp"])
            self.lbTwoBrkCount:setString(""..self._data["brk_num"])
            local  breakCount  = self._data["brk_num"] -- 突破次数
            local  breakRarity  = self._data["rarity"]  -- 品质
            local  breakLimit  = #AwakenNum[breakRarity]  -- 最大突破次数
            self.lbTwoBrkBar:setPercent(100*breakCount/breakLimit)
        end
    else
        if mode == 5 then
            --技能等级
            self.zhanliPanel:setVisible(true)
            self.lbZhanliName:setString(UITool.ToLocalization("技能等级"))
            self.lbZhanli:setString(self._data["sk"]["Lv"])
        elseif mode == 4 then
            --突破次数
            self.rankPanel:setVisible(true)
            for i=1,4 do    
                if i <= self._data.brk_num then
                    self["rankImg"..i]:setVisible(true)
                    self["rankImg"..i]:setTexture("n_UIShare/equip/info/xqzx_ui_004.png")
                else
                    self["rankImg"..i]:setVisible(false)
                end
            end
        elseif mode == 3 then
            --战斗力
            self.zhanliPanel:setVisible(true)
            self.lbZhanliName:setString(UITool.ToLocalization("战斗力"))
            self.lbZhanli:setString(self._data.fp)
        elseif mode == 2 then
            --等级
            self.zhanliPanel:setVisible(true)
            self.lbZhanliName:setString(UITool.ToLocalization("等级"))
            self.lbZhanli:setString(self._data.Lv)
        else
            --攻击力，血量            
            self.atkdefPanel:setVisible(true)
            self.lbATK:setString(""..self._data["atk"])
            self.lbHP:setString(""..self._data["hp"])
        end
    end
end

function EquipListItemView:showUnequip()
    self.imgUnequip:setVisible(true)  
    self.imgUnequip:setTexture("n_UIShare/equip/list/ggsc_ui_221.png")
end

function EquipListItemView:onResetData()
    self:setShadow(false)
    self.panSelArrow:setVisible(false)

    if not self._data then return end

    local e_id_num = getNumID( self._data["id"] )
    local e_id_str = getStrID( self._data["id"] )
    
    local frame = Rarity_Icon[self._data["rarity"]]  --外框
    if frame then
        self.imgRarity:setTexture(frame)
    end

    local rbg = Rarity_E_BG[self._data["rarity"]]   --背景
    if rbg then
        self.imgBG:setTexture(rbg)
    end

    local element = ATB_Icon[self._data["element"]] --属性球
    if element then
        self.imgElement:setTexture(element)
    end

    local face = equip[e_id_num].equip_list_icon    
    if face then
        self.imgFace:setTexture(face)
    end

    if self._data["owner"] ~= "0" then
        local h_id_num = getNumID(self._data["owner"])
        self.inTeamFlag:setVisible(true)
        self.inTeamFlag:setTexture(hero[h_id_num].hero_eqface_icon)
    else
        self.inTeamFlag:setVisible(false)
    end

    if self._data["is_lock"] then
        self.imgUnequip:setVisible(true)
        self.imgUnequip:setTexture("n_UIShare/equip/list/lzsd_ui_001.png")
    else
        self.imgUnequip:setVisible(false)
    end

    self:setTitleMode(1)
    
    if self.resetDataEvent then
        self.resetDataEvent(self)
    end
end
