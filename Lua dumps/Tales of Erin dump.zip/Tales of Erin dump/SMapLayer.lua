
--[[ 
区域地图
    --info 
    ui 工程中所有map 的根node tag 设置为67 
    btn_  为点击区域
    icon_ 为显示icon
    road_ 为路线
]]
require "BasicLayer"

SMapLayer = class("SMapLayer",BasicLayer)
SMapLayer.__index = SMapLayer
SMapLayer.lClass = 2
--锁住状态
local lockBtns = {
    "n_UIShare/ditu/dt_b_jd_a.png",
    "n_UIShare/ditu/dt_b_kn_c.png",
    "n_UIShare/ditu/dt_b_tz_c.png",
}
---解锁状态
local unlockBtns = {
    "n_UIShare/ditu/dt_b_jd_a.png",
    "n_UIShare/ditu/dt_b_kn_a.png",
    "n_UIShare/ditu/dt_b_tz_a.png",
}
local dLevels ={"a","b","c"}

local bossIconPos = {
    ["1"] = {1,1,1,2,2},
    ["2"] = {1,1,1,2,2},
    ["3"] = {1,1,2,1,1},
    ["4"] = {2,2,1,1,1,2,2},
    ["5"] = {1,1,2,1,1},
    ["6"] = {1,1,1,2,2},
}

function SMapLayer:create(rData)
    local smapLayer = SMapLayer.new()
    smapLayer.rData = rData
    smapLayer.titleNum = 8
    smapLayer.sManager = smapLayer.rData["sManager"]
    smapLayer.backFunc = smapLayer.rData["rcvData"]["sFunc"]
    smapLayer.sDelegate = smapLayer.rData["rcvData"]["sDelegate"]
    smapLayer.uiLayer = cc.Layer:create()
    smapLayer:init()
    return smapLayer
end

--初始化地图数据
function SMapLayer:init()
    -- 0 正常  1 列表  2.素材和狗粮  --todo重新定义，。做 素材本的时候，重新处理一下 self.state
    --这个好像是用这个 状态来处理返回按钮的 ，0 的时候直接返回主页
    self.tollgate = nil 
    self.area = nil  --保存服务器返回来的地图数据
    self.now_area = nil  --当前所在区域
    self.touch_point = nil  --点击的事件点
    self.click_point = 0  --点击的关卡序号
    self.open_count = 0  
    self.myTableView = nil
    self.scrollView = nil
    self.passImgView = nil
    self.kyImgView = nil --飞动的精灵
    self.NXImgView = nil --下一个事件的指示的精灵
    self.isTouchRewerd = false
    self._nowSelectDiffLevel = 1  --难易等级  1、简单  2、困难 3、极限挑战
    self._maxDiffLevel = 1  --当前解锁的难度
    self._rootBtnNode = nil 
    self._starRootNode = nil --星星和boss头像的父节点

    self._isAstrolabeList = false  --显示的是星盘列表

    self.exist = true
    self.now_area = self.rData.rcvData.target_area or  user_info["now_area"]
    user_info["now_area"] = self.now_area
    self.areaSecondStr = tostring(string.sub(self.now_area,2,2)) ---在第几章（目前只有 四章）

    local node = cc.CSLoader:createNode("SMapLayer.csb")
    self.uiLayer:addChild(node,0,1)
   
    local panel = node:getChildByTag(1)
    self._starRootNode = ccui.Helper:seekWidgetByName(panel,"star_root")

    local imageView = ccui.Helper:seekWidgetByTag(panel,101)

    local bgName = UITool.getNumFromatStr("uifile/n_UIShare/ditu/zqxg_bg_",self.areaSecondStr)
    imageView:loadTexture(bgName)

    self.kyImgView = panel:getChildByTag(112)
    self.NXImgView = panel:getChildByTag(111)

    local touchEventTable = {
     [323] = self.menuCallBack,
     [322] = self.returnBack,
    }

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            touchEventTable[sender:getTag()](self) 
        end
    end 

    self._rootBtnNode = node:getChildByTag(3)
    local panel_4 = node:getChildByTag(4)
    self._rootBtnNode:setSwallowTouches(false)
    local button = ccui.Helper:seekWidgetByTag(panel_4,322)
    button:setEffectType(3)
    button:addTouchEventListener(touchCallBack)
    local button_1 = ccui.Helper:seekWidgetByTag(self._rootBtnNode,323)
    button_1:addTouchEventListener(touchCallBack)

    self:initDifficultyBtn()
    self:initAstrolabeBtn()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self:reqAreaInfo()
end

--群星试炼按钮
function SMapLayer:initAstrolabeBtn()
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            --群星试炼 展示界面
            local sData = {}
            sData["sDelegate"] =  self
            sData["sFunc"] =  self.refresh
            local layer = AstrolabeDropsNode:create(sData)
            self.astrolabeNode:addChild(layer.uiLayer)
        end
    end 
    self.astrolabeBtn = self._rootBtnNode:getChildByName("btn_astrolabe")
    self.astrolabeNode = self._rootBtnNode:getChildByName("node_astrolabe")
    self.astrolabeBtn:addTouchEventListener(touchCallBack)
    self.astrolabeBtn:setVisible(false)
    self.astrolabeNode:setVisible(false)
end

function SMapLayer:refreshAstrolabe()
    if  tonumber(user_info["rank"]) >= UnlockAstrolabeLevelRank and g_channel_control.smapAstrolabeLevel then 
        local drops = table.keys(self.area["ex_drop_info"])
        if #drops > 0 then
            self.astrolabeBtn:setVisible(true)
            self.astrolabeNode:setVisible(true)
        else
            self.astrolabeBtn:setVisible(false)
            self.astrolabeNode:setVisible(false)
        end
    else 
        self.astrolabeBtn:setVisible(false)
        self.astrolabeNode:setVisible(false)
    end 
end

---初始化难易按钮
function SMapLayer:initDifficultyBtn()
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local areaFirstStr = dLevels[sender.diffLevel]
            local area_id = areaFirstStr..self.areaSecondStr
            self:reqAreaInfo(area_id)
        end
    end 
    local function touchImgCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            sender:setTouchEnabled(false)
            local function deFunc()
                sender:setTouchEnabled(true)
            end
            local delay = cc.DelayTime:create(2.0)
            sender:runAction(cc.Sequence:create(delay,cc.CallFunc:create(deFunc)))
            SceneManager:showPromptLabel(UITool.ToLocalization("通关上一难度的所有本章关卡后解锁"))
        end
    end 
    for i=1,3 do 
        local btn = ccui.Helper:seekWidgetByName(self._rootBtnNode,"diff_btn_"..i)
        btn:addTouchEventListener(touchCallBack)
        btn.diffLevel = i
        local diffImg = ccui.Helper:seekWidgetByName(self._rootBtnNode,"diff_img_"..i) --只有2 和3 有
        if  diffImg then 
            diffImg:addTouchEventListener(touchImgCallBack)
        end 
    end 
end

function SMapLayer:updateDifficultyBtn()
    if self._rootBtnNode ~= nil then
        for i=1,3 do 
            local btn = ccui.Helper:seekWidgetByName(self._rootBtnNode,"diff_btn_"..i)
            local diffImg = ccui.Helper:seekWidgetByName(self._rootBtnNode,"diff_img_"..i) --只有2 和3 有
            if btn and diffImg then
            
                if i == self._nowSelectDiffLevel then
                    btn:setTouchEnabled(false)
                    btn:setBright(false)
                    btn:loadTextureDisabled(unlockBtns[i])
                else 
                    btn:setTouchEnabled(true) 
                    btn:setBright(true)
                end
                if diffImg then 
                    diffImg:setVisible(false)
                end 
                if i > self._maxDiffLevel then 
                    if btn:isTouchEnabled() then 
                        btn:setTouchEnabled(false)
                        btn:setBright(false)
                    end 
                    btn:loadTextureDisabled(lockBtns[i])
                    if diffImg then 
                        diffImg:setVisible(true)
                    end 
                end
            end
        end 
    end
end
---更新章节
function SMapLayer:updateChapter()
    local bgImg = ccui.Helper:seekWidgetByName(self._rootBtnNode,"percent_bg")
    local bgName = UITool.getNumFromatStr("uifile/n_UIShare/ditu/dtxz_ui_",self.areaSecondStr)
    local precentLab = ccui.Helper:seekWidgetByName(self._rootBtnNode,"lab_precent")
    precentLab:setString(self.area["now_level_num"].."/"..self.area["max_level_num"] )
    bgImg:loadTexture(bgName)
    bgImg:setVisible(true)
    bgImg:loadTexture(bgName)
    self._precentLabBgImg = bgImg
end
--初始化地图数据
function SMapLayer:initMap()
    --map node 
    self:updateDifficultyBtn()
    self:updateChapter()
    local node = self.uiLayer:getChildByTag(1)

    local panel = node:getChildByTag(1)
    local imageView = ccui.Helper:seekWidgetByTag(panel,101)

    imageView:setVisible(true)
    local map = imageView:getChildByTag(1)
    if map ~= nil then 
        imageView:removeChildByTag(1, true)
        map = nil 
    end 
    local csbName = "SMap_Node"..self.areaSecondStr..".csb"
    local mapNode = cc.CSLoader:createNode(csbName)
    if mapNode == nil then
        return
    end
    mapNode:setPosition(cc.p(0,0))
    imageView:addChild(mapNode,0,1) 

    self._mapCsbNode = mapNode:getChildByTag(67)
    -- 初始化地图
    local function touchIconBtnEvent(sender,eventType)
       if eventType == ccui.TouchEventType.ended then
           local selectPoint = sender:getTag() - 100
           self.touch_point = self.now_area.."_"..selectPoint
           self:reqPointInfo(self.touch_point,false)
       end
    end 

    local totalNum = tonumber(self.area["total_points"])

    for i=1,totalNum do
          local icon = ccui.Helper:seekWidgetByName(self._mapCsbNode,"icon_"..i)
          if icon~=nil then
              local button  = ccui.Helper:seekWidgetByName(self._mapCsbNode,"btn_"..i)
              button:setTag(100+i)
              button:addTouchEventListener(touchIconBtnEvent)
              icon:setVisible(false)

              local roadBar = ccui.Helper:seekWidgetByName(self._mapCsbNode,"road_"..i)
              if roadBar then
                   roadBar:setVisible(false)
              end
              --当前开始的
              if i < self.open_count+1 then
                  button:setVisible(true)
                  icon:setVisible(true) 
              else
                  button:setVisible(false)
              end
          end   
    end 
    --nextPoint #此区域的下一个区域是否解锁，如：第一个区域打完之后第二个区域开启则此处为1，若没有开启则为0
    local nowPoint  = self.area["now_point"]   -- 目前所在的事件点
    local newPoint =  self.area["newPoint"]    -- #新的事件点开启，如果无新的事件点为""
    local nextPoint = self.area["target_point"]-- #此区域的下一个区域是否解锁
    local nextArea = getPSID(nextPoint)

    local nowArea = getPSID(nowPoint)--目前所在的事件点 区域
    local nowNum = getMatID(nowPoint)--目前所在的事件点 --小点
    if self.now_area == nowArea then --在当前区域
        if nowNum > 0 then --事件点
            local icon = ccui.Helper:seekWidgetByName(self._mapCsbNode,"icon_"..nowNum)
            icon:setVisible(true)
            local pointx = icon:getPositionX()
            local pointy = icon:getPositionY()
            local size_w  =  icon:getContentSize().width
            local size_h  =  icon:getContentSize().height
            local action = cc.CSLoader:createTimeline("SMap_ky.csb")
            self.kyImgView:stopAllActions()
            self.kyImgView:runAction(action)
            action:play("fly", true)
            self.kyImgView:setVisible(true)
            self.kyImgView:setPosition(pointx, pointy)
        else
            self.kyImgView:setVisible(false)
        end
    else
        self.kyImgView:setVisible(false)    
    end
    if nextArea == self.now_area then
        --有新开启点
        if newPoint == nextPoint then 
            local newIdx = getMatID(newPoint)--新到达的事件点
            self:showluxian(true,newIdx)
            return
        end
        self:showluxian(false,nil)
    else
        self:showluxian(false,nil)
    end

    -- if self.areaSecondStr ~= nil and tonumber(self.areaSecondStr) > 1 then
    --     if not XBConfigManager:getInstance():getGlobalBooleanByKey(GAME_PROFILE_KEY_LANGCHECKED) and
    --         VoiceDownloader.checkManifest("jp") then

    --         GameManagerInst:confirm("是否下载全剧情语音包（100MB)？\n(建议WIFI条件下下载)",function()

    --             local  network = SDKManager:getInstance():getNetworkType()
    --             if network == "wifi" then 
    --                 self:downloadVoice("jp")
    --             else 
    --                 GameManagerInst:confirm("您当前处于非wifi网络环境下，继续使用可能产生流量费用，是否继续下载？",function()
    --                     self:downloadVoice("jp")
    --                 end)
    --             end 
    --         end,
    --         function()
    --             XBConfigManager:getInstance():setGlobalBooleanByKey(GAME_PROFILE_KEY_LANGCHECKED,true) 
    --         end
    --         )
    --     end
    -- end
end 

function SMapLayer:downloadVoice(lang)
    self:releaseVcdlmgr()

    self.voiceMgr = VoiceDownloader.new():init(lang)

    local view = ProcessBarView.new():init()

    view:setTitle(UITool.ToLocalization("提示"))
    view:setMessage(UITool.ToLocalization("正在下载语音包..."))

    self.voiceMgr.processionEvent = function(sender,percent)
        view:setPercent(percent)
        view:setProcessMsg(string.format("已完成 %d%%",percent))
    end
    
    self.voiceMgr.downloaderEvent = function(sender,eventType)
        if eventType == VOICEDL_EVENT_MANIFEST_ERROR then
            print("没有新版本或索引错误")
            KeyboardManager._isShowEffect = false
            view:removeFromParentView()
            self:releaseVcdlmgr()
            GameManagerInst:alert(UITool.ToLocalization("网络出现问题，下载失败，请稍后再试。\n(下载为断点续传)"))
        elseif eventType == VOICEDL_EVENT_NEW_VERSION then
            view:setProcessMsg(string.format("已完成 %d%%",0))
        elseif eventType == VOICEDL_EVENT_NO_NEW_VERSION  or eventType == VOICEDL_EVENT_UPDATE_FINISHED then
            KeyboardManager._isShowEffect = false
            view:removeFromParentView()
            self:releaseVcdlmgr()
            XBConfigManager:getInstance():setGlobalBooleanByKey(GAME_PROFILE_KEY_LANGCHECKED,true) 
            GameManagerInst:alert(UITool.ToLocalization("下载完成"))
        elseif eventType == VOICEDL_EVENT_UPDATE_FAILED == 5 then
            KeyboardManager._isShowEffect = false
            view:removeFromParentView()
            self:releaseVcdlmgr()
            GameManagerInst:alert(UITool.ToLocalization("网络出现问题，下载失败，请稍后再试。\n(下载为断点续传)"))
        end
    end
    self.voiceMgr:startDownload()

    GameManagerInst:showModalView(view)
end

function SMapLayer:releaseVcdlmgr()
    if self.voiceMgr then
        self.voiceMgr:dispose()
        self.voiceMgr = nil
    end
end

--显示路线
function SMapLayer:showluxian(isShowAct,newPointIdx)
    --显示 路线
    local num  = self.open_count-1
    for i=1,num do
        local roadBar = ccui.Helper:seekWidgetByName(self._mapCsbNode,"road_"..i)
        if roadBar then 
            roadBar:setVisible(true)
        end  
        --self:testRun(roadBar) ---testCode
    end
    local function showNext()
        if user_info["guide_id"] == guide_id_config.FB then     --新手引导第一次出征               
            NewGuideManager:startSubGuide(self, 2)
            self.kyImgView:setVisible(false) 
        else  
            self:addNextFlyIcon() 
        end
    end
    -----本地图的第一个点，不用显示路
    if num < 0 then
        local icon = ccui.Helper:seekWidgetByName(self._mapCsbNode,"icon_1")
        icon:setScale(1.3)
        icon:setVisible(true)
        local scale =cc.ScaleTo:create(0.15,1)
        local sq = cc.Sequence:create(scale,cc.CallFunc:create(showNext))
        icon:runAction(sq)
        return
    end
    ----有新路线动画,而且动画前面有路线
    if isShowAct then 
        local roadBarKey = newPointIdx -1 --新事件 目标点-1
        local roadBar = ccui.Helper:seekWidgetByName(self._mapCsbNode,"road_"..roadBarKey)
        if roadBar ~= nil then
            self.schedulerEntry = nil
            local scheduler = cc.Director:getInstance():getScheduler()

            local width =  roadBar:getContentSize().width
            local height = roadBar:getContentSize().height
            --指向的point
            local toImgIdx = newPointIdx
            local targetIcon = ccui.Helper:seekWidgetByName(self._mapCsbNode,"icon_"..toImgIdx)
            targetIcon:setVisible(false)
            local targetBtn= ccui.Helper:seekWidgetByName(self._mapCsbNode,"btn_"..toImgIdx)
            targetBtn:setTouchEnabled(false)
            local nowT = 0
            local function unpause(time)
                nowT = nowT + time*30
                if nowT > 1 then
                    nowT = 1
                    if self.schedulerEntry ~= nil then
                        scheduler:unscheduleScriptEntry(self.schedulerEntry)
                        self.schedulerEntry = nil
                    end
                    targetIcon:setScale(1.3)
                    targetIcon:setVisible(true)
                    targetBtn:setTouchEnabled(true)
                    local scale =cc.ScaleTo:create(0.15,1)
                    local sq = cc.Sequence:create(scale,cc.CallFunc:create(showNext))
                    targetIcon:runAction(sq)
                    self.sManager:removeTouchMaskLayer()
                end
                if roadBar ~= nil then
                    roadBar:setContentSize(cc.size(width*nowT,height)) 
                end
            end
            roadBar:setContentSize(cc.size(width*0,height)) 
            roadBar:setVisible(true)
            self.sManager:addTouchMask()
            local time_ = 0.01
            self.schedulerEntry = scheduler:scheduleScriptFunc(unpause,time_, false)
        else 
            showNext()   
        end 
    else 
        showNext()
    end 
end

--测试函数，需要删除
--用于所有路线动画测试
function SMapLayer:testRun(roadBar)
   ----有新路线动画,而且动画前面有路线
    if roadBar then 
        local schedulerEntry = nil
        local scheduler = cc.Director:getInstance():getScheduler()
        local width =  roadBar:getContentSize().width
        local height = roadBar:getContentSize().height
        local nowT = 0
        local function unpause(time)
            nowT = nowT + time*30
            if nowT > 1 then
                nowT = 1
                if schedulerEntry ~= nil then
                    scheduler:unscheduleScriptEntry(schedulerEntry)
                    schedulerEntry = nil
                end
            end
            if roadBar ~= nil then
                roadBar:setContentSize(cc.size(width*nowT,height)) 
            end
        end
        roadBar:setContentSize(cc.size(width*0,height)) 
        roadBar:setVisible(true)
        schedulerEntry = scheduler:scheduleScriptFunc(unpause,0.01, false) 
    end
end

function SMapLayer:deallistViewChick()
    -- body
    if self.tollgate[self.click_point]["type"] ~= 3 then --type 0-主线, 1-角色, 2-自由任务, 3-多人BOSS
        self:onClickOtherPass()   
    else
        self:onClickMullPass()
    end
end

--显示关卡列表层
function SMapLayer:addTollgate()
    if self.uiLayer == nil then
        return
    end
    local node = self.uiLayer:getChildByTag(1)
    local panel_2 = node:getChildByTag(2) 
    panel_2:setVisible(true)
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
                if  self.isTouchRewerd then --如果是点击奖励查看，直接返回
                    do return end 
                end 
                self.click_point = sender:getCurSelectedIndex() + 1
                self:deallistViewChick()
          end
    end
    self.scrollView = ccui.Helper:seekWidgetByTag(panel_2,202)
    self.passImgView = ccui.Helper:seekWidgetByTag(panel_2,201)
    self.scrollView:removeAllItems()
    self.scrollView :addEventListener(listViewEvent)
    self.scrollView:setScrollBarEnabled(true)
    self.scrollView:setScrollBarWidth(20)
    self.scrollView:setScrollBarColor(cc.c3b(255, 255, 255))
    self.scrollView:setScrollBarOpacity(225*0.5)
    self.scrollView:setScrollBarPositionFromCorner(cc.p(2,2))
    self.scrollView:setTouchTotalTimeThreshold(0.1)
   -- self.state = 1 
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("pass_item.csb")
    local  item_1 = list_item:getChildByTag(174)
    local item_c = item_1:clone()
    item_c:setPosition(cc.p(0,0))
    item_c:setName("item")
    layout_list:addChild(item_c)
    layout_list:setContentSize(610,160)
    layout_list:setTouchEnabled(true)
    self.scrollView:setItemModel(layout_list)

    self:updateListViewUIShow()
end

function SMapLayer:updateListViewUIShow()
    local node = self.uiLayer:getChildByTag(1)
    local panel_2 = node:getChildByTag(2) 
    local imgs = {"dt_ui_lbnd_jd.png","dt_ui_lbnd_kn.png","dt_ui_lbnd_tz.png"}
    local diff_img = ccui.Helper:seekWidgetByName(panel_2,"diff_img")
    local boss_img = ccui.Helper:seekWidgetByName(panel_2,"boss_icon")
    local mat_root = ccui.Helper:seekWidgetByName(panel_2,"mat_root")
    if self._isAstrolabeList then 
        boss_img:setUnifySizeEnabled(true)
        boss_img:loadTexture(self.point_img)
        local btn_add_mat = ccui.Helper:seekWidgetByName(mat_root,"btn_add_mat")
        local lab_mat_num = ccui.Helper:seekWidgetByName(mat_root,"lab_mat_num")
        lab_mat_num:setString(self.ex_ap_info.ex_ap.."/"..self.ex_ap_info.ex_ap_max)
        btn_add_mat:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local function purchaseBack( data )
                    dump(data, "data")
                    lab_mat_num:setString(data.fast_trade_info.goods_have.."/"..self.ex_ap_info.ex_ap_max)
                end
                local purchase_data = {
                    callFunc = purchaseBack,              --购买返回
                    fast_trade_id = 1                     --交易id 1
                }
                SceneManager:showPurchase( purchase_data )
            end
        end)
        boss_img:setVisible(true) 
        mat_root:setVisible(true)
        diff_img:setVisible(false)
    else 
        diff_img:setVisible(true)
        diff_img:loadTexture("n_UIShare/ditu/"..imgs[self._nowSelectDiffLevel])
        boss_img:setVisible(false) 
        mat_root:setVisible(false)
    end 
end
function SMapLayer:reqAstrolabeList()
    self:reqPointInfo(self.touch_point, true)
end
--更新关卡默认状态
function SMapLayer:updateMapDefaultStatus( ... )
    -- body
    --"ex_point_1"   csd 文件里只有一个ex_point节点
    local exPointNum = 1
    for i=1,exPointNum do
        local btn = ccui.Helper:seekWidgetByName(self._mapCsbNode ,"ex_point_"..i)
        if btn ~= nil then 
            btn:setTouchEnabled(false)
            btn:setBright(false)
        end 
    end
end
function SMapLayer:setAstrolabeBtn(exPointNum,ex_area_info)
    self.ex_area = {}
    ex_area_info = ex_area_info or {}
    if g_channel_control.smapAstrolabeLevel then
        if exPointNum == nil then 
            GameManagerInst:alert("检查服务器，星盘关卡接口是否合并，如果不需要，前端需关闭星盘关卡")
        end 
    else 
        exPointNum = 1
    end

    for k,v in pairs(ex_area_info) do 
        self.ex_area[k] = v 
    end 
    local areaSec = string.sub(self.now_area,2,2)
    --如果星盘未开启 exPointNum值为0，不会进入下面的for循环  关卡的初始状态无法更新 因此加入以下方法更新关卡状态
    --begin
    self:updateMapDefaultStatus()
    --over
    for i=1,exPointNum do
        local btn = ccui.Helper:seekWidgetByName(self._mapCsbNode ,"ex_point_"..i)
        if btn ~= nil then 
            local k = "k"..areaSec.."_"..i
            if self.ex_area[k] and g_channel_control.smapAstrolabeLevel and tonumber(user_info["rank"]) >= UnlockAstrolabeLevelRank then 
                btn:setTouchEnabled(true)
                btn:setBright(true)
                btn:addTouchEventListener(function(sender,eventType)
                    if eventType == ccui.TouchEventType.ended then
                        self.touch_point = k
                        self:reqAstrolabeList()
                    end
                end)
            else 
                btn:setTouchEnabled(false)
                btn:setBright(false)
            end
        end 
    end
end
--点击非多人战类型的关卡
--需要消耗AP
function SMapLayer:onClickOtherPass()
    self:toReadyLayer()
end

--点击多人战类型的关卡
function SMapLayer:onClickMullPass()
    --多人战创建
    local state = self.tollgate[(self.click_point)]["level_state"]
    if state == 2 then --加入 不消耗次数
        self:toReadyLayer()
    else               --新建 消耗次数
        local totalValue = self.tollgate[self.click_point]["multi"]["total"]
        local nowValue = self.tollgate[self.click_point]["multi"]["now"]
        local nums = totalValue - nowValue
        if nums >0 then
            local msg = string.format(UITool.ToLocalization("今日还剩余挑战次数:%d"),nums)
            MsgManager:showSimpMsgWithCallFunc(msg,self,self.toReadyLayer)
        else
            local msg = UITool.ToLocalization("你的挑战次数已用完")
           MsgManager:showSimpMsg(msg)
        end
    end 
end

function  SMapLayer:toReadyLayer()
    --battle_id   多人战斗 的话 battle_idself.tollgate[(self.click_point)]["battle_id"]
    self.sData = {} 
    self.sData["name"] =  UITool.getUserLanguage(battlePass[self.tollgate[(self.click_point)]["level_id"]]["level_name"])
    self.sData["lv"] = battlePass[self.tollgate[(self.click_point)]["level_id"]]["level_lv"]
    self.sData["ap"] = self.tollgate[self.click_point]["need_ap"]
    local type_ = self.tollgate[(self.click_point)]["type"]
    --创建多人战表里面的  和 参加多人战的区别（返回的Id）
    local state = self.tollgate[(self.click_point)]["level_state"]
    if type_ == 3 then
        if state == 2 then --加入多人战
            self.sData["b_id"] = self.tollgate[(self.click_point)]["id"]
            self.sData["mode"] = "mutable1" --join
            self.sData["ap"]  = 0
        else
            self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
            self.sData["mode"] = "mutable" --create
        end
    else
        self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
    end
    if self.sManager then
        self.sManager:toReadyLayer(self.sData)
    end   
end

function SMapLayer:removeTollgate()
    local node = self.uiLayer:getChildByTag(1)
    local panel_2 = node:getChildByTag(2)
    panel_2:setVisible(false)
    self:reqAreaInfo()
end 

-- Next标记，在事件点上添加next标记
function SMapLayer:addNextFlyIcon()
    local nextPoint = self.area["target_point"]
    local nextArea = getPSID(nextPoint)
    if nextArea ~= self.now_area then
        return
    end
    local now_event = getMatID(self.area["target_point"])
    --now_event = 2 --testCode
    local icon = ccui.Helper:seekWidgetByName(self._mapCsbNode,"icon_"..now_event)
    local title = ccui.Helper:seekWidgetByName(self._mapCsbNode,"title_"..now_event)
    local pointx = title:getPositionX()
    local pointy = icon:getPositionY()
    --local size_w  =  icon:getContentSize().width
    local size_h  =  icon:getContentSize().height
    local action = cc.CSLoader:createTimeline("SMap_Next.csb")
    self.NXImgView:stopAllActions()
    self.NXImgView:runAction(action)
    action:play("zhuan", true)
    self.NXImgView:setPosition(pointx,pointy+size_h/2-10)
end 
--添加新关卡提示
--[[]
    添加boss头像
]] 
function SMapLayer:addBossAndStar() 
    local totalNum = tonumber(self.area["total_points"])
    local function deimeFunc()   
        for i=1,totalNum do
            local iArea = self.now_area.."_"..i
            ---未开启的事件点 或 已开启但是没有获取奖励的事件点
            if self.area["area_info"][iArea] == nil or self.area["area_info"][iArea].get_reward == 0 then 
                if area_boss_info[iArea] ~= nil then
                    local iconStr  = area_boss_info[iArea].icon 
                    if self.area["area_info"][iArea] then 
                        if self.area["area_info"][iArea].act_img then 
                            iconStr = self.area["area_info"][iArea].act_img
                        end 
                    end          
                    if iconStr ~= nil and iconStr ~=""then 
                        local iconNode = ccui.Helper:seekWidgetByName(self._mapCsbNode,"icon_"..i)
                        local titleNode = ccui.Helper:seekWidgetByName(self._mapCsbNode,"title_"..i)
                        if iconNode == nil then
                            break
                        end
                        local titleX = titleNode:getPositionX()
                        local titleY= titleNode:getPositionY()
                        local iconW = iconNode:getContentSize().width
                        local posIdx = bossIconPos[tostring(self.areaSecondStr)][i]
                        local bgImgStr
                        local iconPos 
                        local bgPos
                        if posIdx == 1 then 
                            bgImgStr = "n_UIShare/ditu/dt_ui_002.png"
                            iconPos = cc.p(42,45)
                            bgPos = cc.p(titleX-iconW/2+10, titleY+70)
                        else 
                            bgImgStr = "n_UIShare/ditu/dt_ui_002_1.png"
                            iconPos = cc.p(56,45)   
                            bgPos = cc.p(titleX+iconW/2-10, titleY+70)                        
                        end 
                        local bg_img = ccui.ImageView:create(bgImgStr)
                        bg_img:setAnchorPoint(0.5,0)
                        bg_img:setPosition(bgPos.x, bgPos.y)
                        --icon
                        local bossIcon = ccui.ImageView:create(iconStr)
                        bossIcon:setPosition(iconPos.x,iconPos.y)
                        bg_img:addChild(bossIcon) 
                        self._starRootNode:addChild(bg_img)
                    end 
                end 
            end  
        end 
    end
    self._starRootNode:removeAllChildren()
    deimeFunc()
end

---添加星星
---笨方法吧。。。。
function SMapLayer:addStar(root, pos, num)
    local xs 
    if num  == 1 then 
        xs = {pos.x}
    elseif num == 2 then 
        xs = {pos.x -18.5, pos.x +18.5}
    else 
        xs = {pos.x -37, pos.x, pos.x + 37}
    end 
    for i=1,num do
        local img = ccui.ImageView:create("n_UIShare/ditu/dt_ui_001.png")
        img:setPosition(xs[i], pos.y)
        root:addChild(img)
    end
end
--获取区域信息 
function SMapLayer:reqAreaInfo(_area_id)
    _area_id = _area_id or self.now_area
    local function reiceAreaCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            self.sManager:delWaitLayer()
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            self.sManager:delWaitLayer()
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end

        self._isAstrolabeList = false

        self.now_area = _area_id ---设置为新的区域
        self.areaSecondStr = tostring(string.sub(self.now_area,2,2)) ---在第几章（目前只有 四章）
        local dStr = tostring(string.sub(self.now_area,1,1))
        if dStr == "a" then 
            self._nowSelectDiffLevel = 1
        elseif dStr =="b" then 
            self._nowSelectDiffLevel = 2
        else 
            self._nowSelectDiffLevel = 3
        end 
        self.area = {}
        self.area["area_info"] = {}
        self.area["target_point"] = t_data["data"]["target_point"]
        self.area["now_point"] = t_data["data"]["now_point"]
        self.area["newPoint"] = t_data["data"]["new_point"]--#新的事件点开启，如果无新的事件点为"",另新点只追踪主线,支线和boss关卡不管
        self.area["max_level_num"] = t_data["data"]["max_level_num"] --当前区域一共多少关卡
        self.area["now_level_num"] = t_data["data"]["now_level_num"]
        self.area["ex_drop_info"] = t_data["data"]["ex_drop_info"] -- 掉落英雄信息
        
        self._maxDiffLevel = t_data["data"]["difficulty_level"] --解锁的难度
        self.area["total_points"] = t_data["data"]["total_points"]
        for k,v in pairs(t_data["data"]["area_info"]) do 
            self.area["area_info"][k] = v 
            self.open_count = self.open_count + 1 
        end 
        self:initMap()
        self:addBossAndStar()

        self:refreshAstrolabe()
        self:setAstrolabeBtn(t_data["data"]["total_ex_points"], t_data["data"]["ex_area_info"])
    
        --新区域解锁的话 next标记到世界地图的位置
        if t_data["data"]["next_area_open"] == 1 then
            self.NXImgView:setPosition(107,174)
            self.NXImgView:setVisible(true)
            local action = cc.CSLoader:createTimeline("SMap_Next.csb")
            self.NXImgView:stopAllActions()
            self.NXImgView:runAction(action)
            action:play("zhuan", true)
        end
        self.sManager:delWaitLayer()
    end

    local cjson = require "cjson"
    if self.sManager ~= nil then
        self.sManager:createWaitLayer()
    end
    self.open_count = 0

    local tempTable = {
        ["rpc"] = "area_info",
        ["area_id"] = _area_id,
    }

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceAreaCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end 

--战斗结束刷新数据
function SMapLayer:SMapRefresh(_state,isVictory,now_event_point)
    if  self._isAstrolabeList then 
       self:reqAstrolabeList()
    else 
        if _state == 2 then	
            self.touch_point = now_event_point or self.touch_point
        	self:reqPointInfo(self.touch_point,false)
        else
        	self:removeTollgate()
        end
    end
end

--获取某一事件点详细信息  关卡列表
function SMapLayer:reqPointInfo(event_idx,isAstrolabeList)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end

        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self._isAstrolabeList = isAstrolabeList
        self.tollgate = nil 
        self.tollgate = {} 
        self.tollgate = t_data["data"]["level_list"]
        self.point_img= t_data["data"]["point_image"]
        self.ex_ap_info = table.getValue("back_data",t_data["data"],"ex_ap_info") 

        if self._precentLabBgImg then 
             self._precentLabBgImg:setVisible(false)
        end 
        self:refreshPassList()
    end
    local cjson = require "cjson"
    if self.sManager ~= nil then
        self.sManager:createWaitLayer()
    end
    local tempTable = {}
    tempTable["rpc"] = "point_info"
    local areaNum = string.sub(self.now_area,2,2)
    if isAstrolabeList then --星盘关卡
        tempTable["area_id"]  = "k"..areaNum
        tempTable["point_id"] = event_idx
    else 
        tempTable["area_id"]  = self.now_area
        tempTable["point_id"] = event_idx
    end 
    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function SMapLayer:refreshPassList()
    self:addTollgate()
    local node = self.uiLayer:getChildByTag(1)
    local panel = node:getChildByTag(2)
    local node = self.uiLayer:getChildByTag(1)
    UITool.refreshPassList(self,"level_id")
    self.scrollView:jumpToTop()
    -----新手引导相关
    if user_info["guide_id"] == guide_id_config.FB then     --新手引导第一次出征               
        NewGuideManager:dealGuideFBForSmap(self)
    end

end
--打开世界地图
function SMapLayer:menuCallBack()
  local rcvData = {}
  rcvData["sDelegate"] =  self
  rcvData["sFunc"] =  self.refresh
  self.sManager:toWMapLayer(rcvData)
end

--查看掉落
function SMapLayer:toMapItemDropsLayer(data)
    local rcvData = {}
    rcvData["data"] =  data
    if data.level_is_boss == 1 then 
         self.sManager:toBossInformationLayer(rcvData)
    else 
        self.sManager:toMapItemDropsLayer(rcvData)
    end 
end
--返回
function SMapLayer:returnBack()
    local node = self.uiLayer:getChildByTag(1)
    local panel_2 = node:getChildByTag(2)
    if panel_2:isVisible() then 
        self:removeTollgate()
    else 
        self.sManager:removeFromNavNodes(self)
        self.backFunc(self.sDelegate)
        self.exist = false
        self:clearEx()
    end 

    if self.voiceMgr then
        self.voiceMgr:dispose()
    end
end

function SMapLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--界面切换刷新数据
function SMapLayer:refresh(refData)
    self.open_count = 0 
    self.now_area =  user_info["now_area"] 
    self:reqAreaInfo()
end
