
CoverView = class("CoverView")
CoverView.__index = CoverView
CoverView.layer = nil 
CoverView.swPosition = nil 
CoverView.swSize = nil 
CoverView.slSize = nil 
CoverView.disDistance = nil 
CoverView.disScale = nil 
CoverView.swBox = nil 
CoverView.scrollLayer = nil 
CoverView.cardNum = nil 
CoverView.offsetPosition = nil 
CoverView.slayerPosition = nil 
CoverView.isMove = nil  
CoverView.wSize = nil 
CoverView.cardTable = nil 
CoverView.scrollView = nil 
CoverView.resTable = nil 
CoverView.lastIndex = nil 

function CoverView.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, CoverView)
    return target
end



function CoverView:circulate()
   
        
    local idx = self:getCurCardIndex()

    if idx<=8 or idx>=2 then
     --  self.cardTable[idx+2]:setPosition(self.cardTable[idx-2]:getPosition())
    end
end 


function CoverView:refreshMsg()
  


end
function CoverView:getOffsetPosition()
     return self.offsetPosition 
end


function CoverView:setOffsetPosition(var) 

     self.scrollView:setContentOffset(var)
     self:adjustCardScale(cc.p(0,0))
end

function CoverView:addCard(card,nIndex)
   
    local zOrder = 1000 - self.cardNum 
    local positionY = self.offsetPosition.y - self.disDistance * self.cardNum
    local scale = 1 - self.disScale * self.cardNum 
    card:setPosition(cc.p(self.offsetPosition.x,positionY))
    card:setScale(scale)
    card:setTouchEnabled(true)
    table.insert(self.cardTable,card)
    local function backEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 15 then
                self:CardCallBack(nIndex)
            end
        end
    end
    card:addTouchEventListener(backEvent)
    card:setSwallowTouches(false)
    self.scrollLayer:addChild(card,zOrder,self.cardNum)
    self.cardNum = self.cardNum + 1 
end

function CoverView:CardCallBack(nIndex)
    self:JumpScrollView(nIndex,self.lastIndex)
end

function CoverView:JumpScrollView(nIndex,fromIndex)
    self.nCurIndex = nIndex
    local itemLast = self.cardTable[fromIndex]
    local itemCur = self.cardTable[nIndex]
    local disY = itemLast:getPositionY() - itemCur:getPositionY()

    local adjustPoint = cc.p(0,disY)
    self:adjustScrollView(adjustPoint)
    self:adjustCardScale(adjustPoint)
    
end

function CoverView:getCurCardIndex()
    if self.nCurIndex then
        return self.nCurIndex
    else
        local distance1 =  self.scrollLayer:getPositionY()

        local index = ((distance1 + 5)/ self.disDistance) + 1
        if index < 0 then

          index = 0

        end

        index = math.floor(index)
        
        return index 
    end
end




function CoverView:adjustEndScrollView()
     
    local minY = self.wSize.height 
    local midY = self.swSize.height/2 

    for i=1,#self.cardTable do 
        
        local card =self.cardTable[i]
        local offset = self.scrollView:getContentOffset().y 
        local posY = card:getPositionY() + offset 
        local disMid = midY -posY 
        if math.abs(disMid) < math.abs(minY) then
            minY = disMid 
        end

    end

    for i=1,#self.cardTable do
    	
    	local item = self.cardTable[i]
    	local offset = self.scrollView:getContentOffset().y 
    	local posY = item:getPositionY() + offset 
    	local disMid = math.abs(midY - posY - minY)
    	local scale = 1 - disMid/self.disDistance* self.disScale 
    	local scaleTo = cc.ScaleTo:create(0.2,scale)
    	item:runAction(scaleTo)
    	local zOr = math.floor(1000 - disMid * 0.1)
    	--item:setZOrder(zOr)
    end


    local function cardViewEnd_callBack()
         print("index = "..self:getCurCardIndex())
         --self.slayerPosition = self.scrollLayer:getPosition()
         self.isMove = true
         local index = self:getCurCardIndex()
         local curCardIndex = index
         local curCard = self.cardTable[curCardIndex]
         local curCardTexture = self.resTable[2][curCardIndex]
         if curCard ~= nil and curCardTexture ~= nil then
            curCard:loadTexture(curCardTexture)
         end

         if self.lastIndex ~= nil then
            if self.lastIndex ~= curCardIndex then
                local lastCard = self.cardTable[self.lastIndex]
                local lastCardTexture = self.resTable[1][self.lastIndex]
                if lastCard ~= nil and lastCardTexture ~= nil then
                    lastCard:loadTexture(lastCardTexture)
                end
            end
         end

         self.lastIndex = curCardIndex 
         self.pslayer:refreshOccu(curCardIndex)
         self.nCurIndex = nil

         --切换纹理
         -- self.cardTable[self:getCurCardIndex()+1]:loadTexture(self.resTable[2][self:getCurCardIndex()+1])

         -- if self.lastIndex ~= nil then
         --    if self.lastIndex ~= self:getCurCardIndex() + 1 then 
         --       self.cardTable[self.lastIndex]:loadTexture(self.resTable[1][self.lastIndex])
         --    end
         -- end

         -- self.lastIndex = self:getCurCardIndex() + 1 
         -- self.pslayer:refreshOccu(self:getCurCardIndex()+1)

    end

    local scrollLayer = self.scrollView:getContainer() 
    local moveBy = cc.MoveBy:create(0.2,cc.p(0,minY))
    local callfunc = cc.CallFunc:create(cardViewEnd_callBack)
    local seq = cc.Sequence:create(moveBy,callfunc)
    scrollLayer:runAction(seq)
    
end


function CoverView:adjustScrollView(adjustPoint)
     
    
     local endPoint = cc.p(self.scrollView:getContentOffset().x,self.scrollView:getContentOffset().y + adjustPoint.y)

     --self.scrollView:unscheduleAllCallbacks()
     self.scrollView:setContentOffset(endPoint,false)
end


function CoverView:adjustCardScale(adjustPoint)
     for i=1,#self.cardTable do
     	 
     	 local card = self.cardTable[i]
     	 local offset = self.scrollView:getContentOffset().y 
     	 local posY = card:getPositionY() + offset 
     	 local disMid = math.abs(self.swSize.height/2 - posY)
     	 local scale = 1 - disMid/self.disDistance * self.disScale 
         local opacity = scale * 255
     	 card:setScale(scale)
         card:setOpacity(opacity)
     	 local zOr = math.floor(1000 - disMid * 0.1)
         --card:setZOrder(zOr)`
     end
end



function CoverView:scrollViewDidZoom(view)


end



function CoverView:scrollViewDidScroll(view)


end


function CoverView:initData()
    
     self.wSize = cc.Director:getInstance():getWinSize()
     self.cardTable = {}
     self.cardNum = 0 

     self.offsetPosition = cc.p(self.swSize.width/2,self.swSize.height/2)

     self.scrollLayer = cc.Layer:create()
     self.scrollLayer:setAnchorPoint(cc.p(0,0))
     self.scrollLayer:setPosition(cc.p(0,0))
     self.scrollLayer:setContentSize(self.slSize)
     
     self.slayerPosition = cc.p(0,0)
     self.isMove = true 
     self.scrollView = cc.ScrollView:create(self.swSize,self.scrollLayer)
     self.scrollView:setAnchorPoint(cc.p(0,0))
     self.scrollView:setContentOffset(cc.p(0,0))
     self.scrollView:setTouchEnabled(false)
     self.scrollView:setDelegate()
     self.scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
     self.layer:addChild(self.scrollView,1)

     --scrollView:registerScriptHandler(scrollView1DidScroll,cc.SCROLLVIEW_SCRIPT_SCROLL)
     --scrollView:registerScriptHandler(scrollView1DidZoom,cc.SCROLLVIEW_SCRIPT_ZOOM)


     
    self.resTable = {}
    self.resTable[1] = {}
    self.resTable[2] = {}
    for i = 1,#princess_list do 
       self.resTable[1][i]= princess_ocp[princess_list[i]["career"]]["p_icon_h"]
       self.resTable[2][i]= princess_ocp[princess_list[i]["career"]]["p_icon"]
    end

end


function CoverView:init(swBox,slSize,disDistance,disScale)

    self.swBox = swBox 
    self.swPosition = swBox.origin
    self.swSize = cc.size(swBox.width,swBox.height)
    self.slSize = slSize 
    self.disDistance = disDistance 
    self.disScale = disScale 


    local function onTouchBegan(touch, event)
        return true
    end

    local function onTouchMoved(touch,event)
       
       local scroll_prepoint = touch:getPreviousLocation()
       local scroll_movepoint = touch:getLocation()
        if cc.rectContainsPoint(self.swBox,scroll_movepoint) then
           local adjustPoint = cc.p(scroll_movepoint.x - scroll_prepoint.x,scroll_movepoint.y- scroll_prepoint.y)
           self:adjustScrollView(adjustPoint)
           self:adjustCardScale(adjustPoint)
       end
    end

    local function onTouchEnded(touch, event)
        local scroll_prepoint = touch:getPreviousLocation()
        local scroll_endpoint = touch:getLocation()
        self:adjustEndScrollView()
        local curPosition = cc.p(self.scrollLayer:getPositionX(),self.scrollLayer:getPositionY())
        local distance = cc.pGetDistance(self.slayerPosition,curPosition)
        if distance < 5 then
           isMove = false
        end
    end



    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.layer:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.layer)
    
    self:initData()
end


function CoverView:create(swBox,slSize,disDistance,disScale)
    self.layer = cc.Layer:create()
    self:init(swBox,slSize,disDistance,disScale)
    return self.layer
end


