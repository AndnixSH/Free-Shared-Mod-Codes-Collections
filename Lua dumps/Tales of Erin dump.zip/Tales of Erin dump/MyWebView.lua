
--------------------------------
-- @module MyWebView
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#MyWebView] loadUrl 
-- @param self
-- @param #char url
        
--------------------------------
-- 
-- @function [parent=#MyWebView] onWebViewDidFailLoading 
-- @param self
-- @param #cc.experimental::ui::WebView sender
-- @param #string url
        
--------------------------------
-- 
-- @function [parent=#MyWebView] reLoad 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#MyWebView] onWebViewShouldStartLoading 
-- @param self
-- @param #cc.experimental::ui::WebView sender
-- @param #string url
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#MyWebView] purg 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#MyWebView] initWithRectAndPartentNode 
-- @param self
-- @param #rect_table myRect
-- @param #cc.Node partentNode
-- @param #char luaFileName
-- @param #char functionName
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#MyWebView] setVisible 
-- @param self
-- @param #bool state
        
--------------------------------
-- 
-- @function [parent=#MyWebView] onWebViewDidFinishLoading 
-- @param self
-- @param #cc.experimental::ui::WebView sender
-- @param #string url
        
--------------------------------
-- 
-- @function [parent=#MyWebView] creatWithRectAndPartentNode 
-- @param self
-- @param #rect_table myRect
-- @param #cc.Node partentNode
-- @param #char luaFileName
-- @param #char functionName
-- @return MyWebView#MyWebView ret (return value: MyWebView)
        
return nil
