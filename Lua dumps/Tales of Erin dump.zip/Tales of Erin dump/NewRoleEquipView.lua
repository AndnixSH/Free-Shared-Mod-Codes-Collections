--require "XUIView"

NewRoleEquipView = class("NewRoleEquipView",XUIView)
NewRoleEquipView.CS_FILE_NAME = "NewRoleEquipView.csb"
NewRoleEquipView.CS_BIND_TABLE = 
{
    --equip
    equip1 = "/i:726",
    equip2 = "/i:743",
    equip3 = "/i:744",
    eqDetailPanel ="/i:747",
    eqName ="/i:747/i:772",
    eqBG ="/i:747/i:767/i:771",
    eqIcon ="/i:747/i:767/i:770",
    eqFrame ="/i:747/i:767/i:769",
    eqElement ="/i:747/i:767/i:768",
    eqAtk ="/i:747/i:25",
    eqHP ="/i:747/i:24",
    eqLv ="/i:747/i:26",
    eqMaxLv ="/i:747/i:27",
    -- eqExpNext ="/i:747/i:28",
    eqExpBar ="/i:747/i:57",

    --技能1
    eqSkName1 ="/i:747/i:59",
    eqSkLv1 ="/i:747/i:60",
    eqSkDesc1 ="/i:747/i:213/i:61",
    eqSkIcon1 = "/i:747/i:213/i:219",

    --技能2
    eqSkName2 ="/i:747/i:214",
    eqSkLv2 ="/i:747/i:215",
    eqSkDesc2 ="/i:747/i:216/i:217",
    eqSkIcon2 = "/i:747/i:216/i:218",
    eqSkNo2 = "/i:747/i:216/i:220",

    eqBtnSkRnd ="/i:747/i:39",
    eqSkPrsk1 ="/i:747/i:33",
    eqSkPrsk2 ="/i:747/i:36",

    eqBtnChange ="/i:747/i:784",
    eqBtnSth ="/i:747/i:788",
    eqAwk1 = "/i:747/i:304",
    eqAwk2 = "/i:747/i:305",
    eqAwk3 = "/i:747/i:306",
    eqAwk4 = "/i:747/i:307",
    --
    spSelected1 = "/i:1471",
    spSelected2 = "/i:1472",
    spSelected3 = "/i:1473",
}

NewRoleEquipView.SKILL_COLOR = cc.c4b(255,192,0,255)
NewRoleEquipView.PSKILL_COLOR = cc.c4b(0,232,255,255)
NewRoleEquipView.LastTab = 1
NewRoleEquipView.VoiceMap = {2,5,7,8,9}

function NewRoleEquipView:init(hero_id,ReLoadCallFunc,sDelegate)
    NewRoleEquipView.super.init(self)
    self.exist = true;
    self.galleryMode = 0
    self.hero_id = hero_id
    --
    self.ReLoadCallFunc = ReLoadCallFunc
    self.sDelegate = sDelegate

    --加载装备
    self.eqBtnChange:addClickEventListener(function()
        self:showEquipList()
    end)
    self.eqBtnSth:addClickEventListener(function()
        self:showEquipSth()
    end)

    self.eqBtnSkRnd:addClickEventListener(function()
        self:onEqSkRnd()
    end)
    --

    local bindTable =
    {
        panelNoOpen = "/i:709",
        panelNoOpen_img3 = "/i:709/i:710",
        panelNoOpen_img1 = "/i:709/i:18",
        panelInfo = "/i:657",
        panelTouch = "/i:598",

        lbName = "/i:657/i:665",
        lbLevel = "/i:657/i:706",
        lbHP = "/i:657/i:707",
        lbAtk = "/i:657/i:708",

        eskIcon1 = "/i:657/i:216/s:eskIcon",
        eskIcon2 = "/i:657/i:219/s:eskIcon",
        lbSkillLv1 = "/i:657/i:216/s:skillLv",
        lbSkillLv2 = "/i:657/i:219/s:skillLv",
        skillPanel1 = "/i:657/i:216",
        skillPanel2 = "/i:657/i:219",
        
        imgBG = "/i:657/i:661/i:662",
        imgElement = "/i:657/i:661/i:664",
        imgFace = "/i:657/i:661/i:659",
        imgRarity = "/i:657/i:661/i:663",
    }

    self.equipView1 = XUIView.new():init(self.equip1,"RoleInfoEquipItemView.csb",bindTable)
    self.equipView2 = XUIView.new():init(self.equip2,"RoleInfoEquipItemView.csb",bindTable)
    self.equipView3 = XUIView.new():init(self.equip3,"RoleInfoEquipItemView.csb",bindTable)

    local SEbindTable =
    {
        panelNoOpen = "/i:709",
        panelNoOpen_img3 = "/i:709/i:710",
        panelInfo = "/i:657",
        panelTouch = "/i:598",

        lbName = "/i:657/i:665",
        lbLevel = "/i:657/i:706",
        lbHP = "/i:657/i:707",
        lbAtk = "/i:657/i:708",
        eskIcon = "/i:657/s:eskIcon",
        
        imgBG = "/i:657/i:661/i:662",
        imgFace = "/i:657/i:661/i:659",
        imgRarity = "/i:657/i:661/i:663",
    }


    self.equipView1.panelNoOpen_img3:removeFromParent()
    self.equipView2.panelNoOpen_img3:removeFromParent()
    self.equipView3.panelNoOpen_img1:removeFromParent()


    self.equip1:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickEquip(1)
        end
    end)
    self.equip2:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickEquip(2)
        end
    end)
    self.equip3:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:onClickEquip(3)
        end
    end)
    ---equip end
    for i = 1,3 do  
        local spSelected = self["spSelected"..i]
        spSelected:setVisible(false)
    end

    return self
end

function NewRoleEquipView:resetViewsState()
    if self.exist == false then
        return
    end
    self.curEquipIndex = nil
    self:refreshEquipDetail()
end

--- 以下为装备相关
function NewRoleEquipView:refreshEquip()
    if self.exist == false then
        return
    end
    -- self.curEquipIndex = nil
    -- self.eqDetailPanel:setVisible(false)
    if self.hero_data then 
        for i = 1,3 do  
            local eqdata = self.hero_data.eq[""..i]
            local eqview = self["equipView"..i]
            if eqdata["eq_id"] == "lock" then
                --锁定
                eqview.panelInfo:setVisible(false)
                eqview.panelNoOpen:setVisible(true)
            elseif eqdata["eq_id"] == "" then
                --未装备
                eqview.panelNoOpen:setVisible(false)
                eqview.panelInfo:setVisible(false)
            else
                eqview.panelNoOpen:setVisible(false)
                eqview.panelInfo:setVisible(true)

                local eqinfo = eqdata["eq_info"]

                eqview.lbAtk:setString(eqinfo["atk"])
                eqview.lbHP:setString(eqinfo["hp"])
                eqview.lbLevel:setString(string.format(UITool.ToLocalization("等级 %d"),eqinfo["Lv"]))

                local enumid = getNumID(eqdata["eq_id"])
                -- eqview.lbDesc:setString(equip[enumid]["equip_skill"]["skill_name"])
                -- eqview.eskIcon:setTexture(equip[enumid]["equip_skill"]["skill_img"])
                eqview.lbSkillLv1:setString("LV "..eqinfo["skOne_Lv"])
                eqview.eskIcon1:setTexture(equip[enumid]["equip_skill"]["skill_img"])

                if equip[enumid]["is_there_sk_two"] == 0 then
                    if eqview.skillPanel2 then
                        eqview.skillPanel2:setVisible(false)
                    end
                else
                    eqview.lbSkillLv2:setString("LV "..eqinfo["skTwo_Lv"])
                    local skill_two_icon = passive_sk[eqinfo["provide_sk_id"]]["sk_icon"]
                    eqview.eskIcon2:setTexture(skill_two_icon)

                    if eqview.skillPanel2 then
                        eqview.skillPanel2:setVisible(true)
                    end
                end

                eqview.lbName:setString(UITool.getUserLanguage(equip[enumid].equip_name))--(equip[enumid].equip_name)

                
                eqview.imgRarity:setTexture( Rarity_Icon[equip[enumid].equip_rank] ) --外框

                eqview.imgBG:setTexture( Rarity_E_BG[equip[enumid].equip_rank])   --背景
                eqview.imgElement:setTexture( ATB_Icon[equip[enumid].equip_atb]) --属性球

                eqview.imgFace:setTexture(equip[enumid].equip_list_icon)
            end
        end
    else
        for i = 1,3 do  
            local eqview = self["equipView"..i]

            eqview.panelNoOpen:setVisible(false)
            eqview.panelInfo:setVisible(false)
        end


    end
    self:refreshEquipDetail()
end

--刷新装备详情
function NewRoleEquipView:refreshEquipDetail()
    if self.exist == false then
        return
    end
    if not self.curEquipIndex then
        self.eqDetailPanel:setVisible(false)
        for i = 1,3 do  
            local spSelected = self["spSelected"..i]
            spSelected:setVisible(false)
        end
        return
    end
    for i = 1,3 do
        local spSelected = self["spSelected"..i]
        if i == self.curEquipIndex then
            spSelected:setVisible(true)
        else
            spSelected:setVisible(false)
        end
    end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]



    -- for i = 1,4 do
    --     self["eqAwk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
    -- end

    if eqdata["eq_id"] == "lock" 
        or eqdata["eq_id"] == "" 
        or user_info["eq"] == nil 
        or user_info["eq"][eqdata.eq_id] == nil then

        self.curEquipIndex = nil
        self.eqDetailPanel:setVisible(false)
    else

        local equip_data = user_info["eq"][eqdata.eq_id]
        self.vCurShowDetailEqData = user_info["eq"][eqdata.eq_id]

        local e_id_num = getNumID( eqdata.eq_id )

        self.eqBG:setTexture(Rarity_E_BG[equip_data["rarity"]])
        self.eqIcon:setTexture(equip[e_id_num].equip_list_icon)
        self.eqFrame:setTexture(Rarity_Icon[equip_data["rarity"]])
        self.eqElement:setTexture(ATB_Icon[equip_data["element"]])

        self.eqName:setString(UITool.getUserLanguage(equip[e_id_num].equip_name))--(equip[e_id_num].equip_name)


        self.eqAtk:setString(equip_data["atk"])
        self.eqHP:setString(equip_data["hp"])

        local eqlv = equip_data["Lv"]
        local eqlvmax = equip_data["Lv_max"]

        -- self.eqLv:setString("等级 "..eqlv)
        -- self.eqMaxLv:setString("等级上限 "..eqlvmax)
        self.eqMaxLv:setString(eqlv.."/"..eqlvmax)

        if eqlv >= eqlvmax then
            --满级
            -- self.eqExpNext:setString("")
            self.eqExpBar:setPercent(100)
        else
            -- self.eqExpNext:setString("离下一级："..(equip_data.exp_max - equip_data.exp))
            self.eqExpBar:setPercent(100 * equip_data.exp / equip_data.exp_max)
        end

        -- 一技能
        self.eqSkName1:setString(UITool.getUserLanguage(equip[e_id_num]["equip_skill"]["skill_name"]))--(equip[e_id_num]["equip_skill"]["skill_name"])
        self.eqSkLv1:setString(UITool.ToLocalization("等级: ")..equip_data["sk"]["Lv"])
        self.eqSkIcon1:setTexture(equip[e_id_num]["equip_skill"]["skill_img"])

        --技能描述-当前等级
        local str_des = UITool.getUserLanguage(equip[e_id_num]["equip_skill"]["skill_des"])--equip[e_id_num]["equip_skill"]["skill_des"]
        str_des = UITool.stringForEqSK(str_des,equip_data["sk"]["add_atk_rate"])
        self.eqSkDesc1:setString(str_des)

        -- 二技能
        if equip[e_id_num]["is_there_sk_two"] == 0 then
            self.eqSkNo2:setVisible(true)
            self.eqSkName2:setVisible(false)
            self.eqSkLv2:setVisible(false)
        else
            self.eqSkNo2:setVisible(false)
            self.eqSkName2:setVisible(true)
            self.eqSkLv2:setVisible(true)

            local skill_two_name = UITool.getUserLanguage(passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_name"])--passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_name"]
            local skill_two_icon = passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_icon"]
            self.eqSkName2:setString(skill_two_name)
            self.eqSkLv2:setString(UITool.ToLocalization("等级: ")..equip_data["sk_two"]["Lv"])
            self.eqSkIcon2:setTexture(skill_two_icon)

            --技能描述-当前等级
            local str_des = UITool.getUserLanguage(passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_det_des"])--passive_sk[equip_data["sk_two"]["provide_sk_id"]]["sk_det_des"]
            self.eqSkDesc2:setString(str_des)
            --
        end


        self.eqDetailPanel:setVisible(true)

        for i = 1,2 do
            local prsk = self["eqSkPrsk"..i]
            if equip_data["rsk"] ~= nil and equip_data["rsk"][i] ~= nil then
                prsk:setVisible(true)
                local strsrc = UITool.getUserLanguage(eq_random_sk[equip_data["rsk"][i][1]])--eq_random_sk[equip_data["rsk"][i][1]]
                strsrc = string.gsub(strsrc,"%*",""..(equip_data["rsk"][i][2]))
                prsk:getChildByName("rskDesc"):setString(strsrc)
            else
                prsk:setVisible(false)
            end
        end

        local break_count = equip_data["brk_num"]
        for i = 1,4 do
            if break_count>= i then
                --self["eqAwk"..i]:setTexture("n_UIShare/equip/info/ggsc_ui_145.png")
                self["eqAwk"..i]:setVisible(true)
            else
                --self["eqAwk"..i]:setTexture("n_UIShare/equip/info/ggsc_ui_146.png")
                self["eqAwk"..i]:setVisible(false)
            end
        end

        self:setEquipNodeLockState()
    end
end

function NewRoleEquipView:onClickEquip(index)
    if self.exist == false then
        return
    end
    if  self.hero_data == nil
        or index > 3 
        or index < 0 
        or index == nil then

        self.curEquipIndex = nil
        self:refreshEquipDetail()
    else

        local eqdata = self.hero_data.eq[""..index]

        if eqdata["eq_id"] == "lock" then
            self.curEquipIndex = nil
            self:refreshEquipDetail()
        elseif eqdata["eq_id"] == "" then
            self.curEquipIndex = nil
            if g_channel_control.b_newEqBag then
                self:loadEquipList(function()
                    self:showEquipList(index)
                end,0)
            else
                if self.eqlistLoaded then
                    self:showEquipList(index)
                else
                    self:loadEquipList(function()
                        self:showEquipList(index)
                    end)
                end
            end

        elseif self.curEquipIndex == index then
                --点的同一个
            self.curEquipIndex = nil 
            self:refreshEquipDetail()
        else
            self.curEquipIndex = index
            if g_channel_control.b_newEqBag then
                self:loadEquipList(function()
                    self:refreshEquipDetail()
                end,1)
            else
                if self.eqlistLoaded then
                    self:refreshEquipDetail()
                else
                    self:loadEquipList(function()
                        self:refreshEquipDetail()
                    end)
                end
            end
        end
    end

end

function NewRoleEquipView:loadEquipList(callback,nEquiped)
    if self.exist == false then
        return
    end
    local nCurEquiped = nEquiped or 0
    local tempData = {}
    if g_channel_control.b_newEqBag then
        tempData = { 
            rpc = "eq_list",
            rarity = {3,4,5},
            element = {1,2,3,4,5,0},
            brk_num = {1,2,3,4,0},
            key = "element",
            reverse = 0,
            equipped = nCurEquiped,
        }
    else
        tempData = { 
            rpc = "eq_list"
        }
    end
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        DataManager:rfsElist()   
        for k,v in pairs(data["mat"]) do
            user_info["bag"]["mat"][k] = v
        end

        self.eqlistLoaded = true

        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleEquipView:showEquipSth()
    if self.exist == false then
        return
    end
    if not self.curEquipIndex then return end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]

    SceneManager:toEquipFromRole({rootNode = self.sDelegate:getRootNode(), tab = 2, eq_id = eqdata.eq_id , hideAllEquipBtn = true, nEquiped = 1})
   
end

function NewRoleEquipView:loadBagList(callback)
    if self.exist == false then
        return
    end
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
		DataManager:wAllBagData(data["bag"])
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleEquipView:ReLoadHeroInfo()
    if self.exist == false then
        return
    end
    if self.ReLoadCallFunc then
        self.ReLoadCallFunc(self.sDelegate)
    end
end

function NewRoleEquipView:onEqSkRnd()
    if self.exist == false then
        return
    end
    if not self.curEquipIndex then return end

    -- local mid = getMatID(ID_EQUIP_RSK)
    -- local cnt = user_info["bag"]["mat"][ID_EQUIP_RSK]
    -- if not cnt or cnt <= 0 then 
    --     GameManagerInst:alert(""..mat[mid].name.."不足")
    --     return
    -- end

    local eqdata = self.hero_data.eq[""..self.curEquipIndex]
    local equip_id = eqdata.eq_id    
    local equip_data = user_info["eq"][eqdata.eq_id]

    local needrefresh = false

    local view = EquipRskView.new():initWithData(equip_id,equip_data)
    view.updateInfoEvent = function(sender,data)
        self:refreshEquipDetail()
        needrefresh = true
    end

    view.beforeCloseEvent = function(sender)
        if needrefresh then
            self:ReLoadHeroInfo()
        end
    end
    GameManagerInst:showModalView(view)
end

function NewRoleEquipView:showEquipList(i)
    if self.exist == false then
        return
    end
    
    --触发引导-装备
    if  XbTriggerGuideManager:checkIsSelectGuide(TriggerGuideConfig.Equip) then 
        XbTriggerGuideManager:showTriggerGuide(nil, 7, TriggerGuideConfig.Equip)--选择装备
    end 

    local index = i or self.curEquipIndex
    if not index then return end

    local eq_id = self.hero_data.eq[""..index].eq_id
    
    local b,v
    if g_channel_control.b_newEqBag then
        b,v = EquipListView.createWithBackBtn(0)
        v:ReLoadData()
    else
        b,v = EquipListView.createWithBackBtn()
    end
    self.changeCompareView = nil

    v.ItemResetEvent = function(item)
        local d = item:getData()
        if d.id == eq_id then
            item:showUnequip()
        end
    end

    v.ItemClickedEvent = function(item)
        local eqdata = item:getData()



        local function callback ()
            if b then
                b:returnBack()
            end
            self:sendChangeEquip(index,eqdata.id)
        end

        local function callbackCompare ()
            if eqdata.owner ~= "0" and eqdata.owner ~= self.hero_id then--选中装备已装备于别的角色
                local hid_cur = getNumID( self.hero_id )
                local hid_other = getNumID( eqdata.owner )
                local eid = getNumID( eqdata.id )

                local name_cur = UITool.getUserLanguage(hero[hid_cur].hero_name)--hero[hid_cur].hero_name
                local name_other = UITool.getUserLanguage(hero[hid_other].hero_name)--hero[hid_other].hero_name
            local name_eq = UITool.getUserLanguage(equip[eid].equip_name)..UITool.ToLocalization("(等级")..eqdata["Lv"]..")"--equip[eid].equip_name..UITool.ToLocalization("(等级")..eqdata["Lv"]..")"
                --GameManagerInst:confirm("是否从 "..name_other.." 身上卸下 "..name_eq.." ，为 "..name_cur.." 装上此灵装？",callback)
	 	local str = UITool.ToLocalization("是否从 %s 身上卸下 %s , 为 %s 装上此灵装")
            	GameManagerInst:confirm(string.format(str, name_other,name_eq,name_cur),callback)
            else
                callback()
            end
        end

        if eq_id ~= "" and eq_id ~= eqdata.id then--原槽中有装备且不是卸下操作（替换）
            local function callbackCancel ()
                self.changeCompareView:removeFromParentView()
                self.changeCompareView = nil
            end

            local function callbackSure ()
                callbackCompare()
                self.changeCompareView:removeFromParentView()
                self.changeCompareView = nil
            end

            if g_channel_control.b_newEqBag then
                self.changeCompareView = EquipChangeCompareView:initEx(self.vCurShowDetailEqData,eqdata,callbackCancel,callbackSure)
            else
                self.changeCompareView = EquipChangeCompareView:init(eq_id,eqdata.id,callbackCancel,callbackSure)
            end
            self:getRootNode():addChild(self.changeCompareView:getRootNode())
        else--原槽无装备情况下装备操作或原槽有装备情况下装备卸下操作
            callbackCompare()
        end
        --b:returnBack()
    end
    
    v.dataSourceEvent = function(sender,sortmode)
        local dataset = {}
        -- for i = 1,#equip_list do
        --     if equip_list[i]["owner"] == "0" or equip_list[i].id == eq_id then
        --         table.insert(dataset,table.deepcopy(equip_list[i]))
        --     end
        -- end
        -- SortBoxView.SortEquip (dataset, sortmode)

        if g_channel_control.b_newEqBag then
            -- dataset =  table.deepcopy(equip_list)
            -- EqSortBoxView.SortEquip (dataset, sortmode)
            ------优化方案
            local ds2 = {}
            for i = 1,#equip_list do
                if equip_list[i]["owner"] == "0" or equip_list[i].id == eq_id then
                    table.insert(dataset,table.deepcopy(equip_list[i]))
                else
                    table.insert(ds2,table.deepcopy(equip_list[i]))
                end
            end
            EqSortBoxView.SortEquip (dataset, sortmode)
            EqSortBoxView.SortEquip (ds2, sortmode)
            for j = 1,#ds2 do
                table.insert(dataset,ds2[j])
            end
            ------
        else
            ------优化方案
            local ds2 = {}
            for i = 1,#equip_list do
                if equip_list[i]["owner"] == "0" or equip_list[i].id == eq_id then
                    table.insert(dataset,table.deepcopy(equip_list[i]))
                else
                    table.insert(ds2,table.deepcopy(equip_list[i]))
                end
            end
            SortBoxView.SortEquip (dataset, sortmode)
            SortBoxView.SortEquip (ds2, sortmode)
            for j = 1,#ds2 do
                table.insert(dataset,ds2[j])
            end
            ------
        end

        return dataset
    end

    v:refresh()
    self:getRootNode():addChild(b:getRootNode())
end

function NewRoleEquipView:sendChangeEquip(pos,eid)
    if self.exist == false then
        return
    end
    --一键卸装时pos为0，暂不处理
    local strpos = ""..pos
    local eqdata = self.hero_data.eq[strpos]

    local tempTable = nil
    local successFunc = nil

    if eqdata.eq_id == eid then
        --卸下
	    tempTable = {
            ["rpc"]     = "eq_unload",
            ["hero_id"] = self.hero_id,
            ["slot"]    = strpos,
	    }
        
        successFunc = function(data)
            --success
            DataManager:modEqiupUnload(self.hero_id,strpos,data)
            self.curEquipIndex = nil
            if self.ReLoadCallFunc then
                self.ReLoadCallFunc(self.sDelegate)
            end
        end
    else
        --装备
        tempTable = {
            ["rpc"] = "eq_use",
            ["eq_id"] = eid,
            ["hero_id"] = self.hero_id,
            ["slot"] = strpos
        }

        successFunc = function(data)
            --success
            --烫烫烫烫烫 发现接口BUG

             XbTriggerGuideManager:finishGuide(TriggerGuideConfig.Equip, self)

            if g_channel_control.b_newEqBag then
                for k,v in pairs(data["hero"]) do
                    print(k,v)
                    user_info["hero"][k] = v
                end
                DataManager:rfsHlist()
            else
                DataManager:modEqiupUse(self.hero_id,strpos,eid,data)
            end
            
            if self.ReLoadCallFunc then
                self.ReLoadCallFunc(self.sDelegate)
            end
            
            self.curEquipIndex = pos
        end
    end

    GameManagerInst:rpc(tempTable,3,
    successFunc
    ,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText)
    end,
    true)
end
---以上为装备相关

function NewRoleEquipView:refreshStaticState()
    if self.exist == false then
        return
    end

    local time_id = getTimeNumID( self.hero_id )
    local h_id_num = getNumID( self.hero_id )

    self.currentVoiceIndex = 1

    --装备
    self.curEquipIndex = nil
    self.eqDetailPanel:setVisible(false)
end

function NewRoleEquipView:refresh()
    if self.exist == false then
        return
    end
    self:refreshEquip()
end

function NewRoleEquipView:DestroyHandle()
    self.exist = false
end

function NewRoleEquipView:onNavigateTo(isback)
    -- --GameManagerInst:setTitleUIType(nil,3)
    -- if isback then
    --     cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    --     GameManagerInst:alert("1")
    --     if self.ReLoadCallFunc then
    --         self.ReLoadCallFunc(self.sDelegate)
    --     end
    -- else
    --     --self:loadInfo(false)
    -- end
end

function NewRoleEquipView:FillHeroData(rcvData)
    if self.exist == false then
        return
    end
    if rcvData then
        self.hero_data = nil
        self.hero_data = table.deepcopy(rcvData)
        self.hero_id = self.hero_data.id
        self:refresh()
        self:refreshStaticState()
    end
end

--设置按钮等级解锁状态
function NewRoleEquipView:setNodeLockState()
    if self.exist == false then
        return
    end
    local curNodes = {self.btnTab2, self.btnTab3}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleInfoView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end
        end 
    end   
end
--设置按钮等级解锁状态
function NewRoleEquipView:setEquipNodeLockState()
    if self.exist == false then
        return
    end
    --local curNodes = {self.eqBtnSkill, self.eqBtnSth, self.eqBtnAwaken}
    local curNodes = {self.eqBtnSth}
    for i=1,#curNodes do
        local config = guide_rank_config["RoleInfoView_Equip"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        else 
            btn:setVisible(true)
        end 
    end   
end
