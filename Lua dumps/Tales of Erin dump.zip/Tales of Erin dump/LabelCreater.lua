LabelCreater = {}
LabelCreater.LabelMap = {}
LabelCreater.BaseTag = 1000
LabelCreater.TeamTag = 2000
LabelCreater.SetTag = 3000

function LabelCreater:getLabelMap( ... )
    -- body
    return self.LabelMap
end

function LabelCreater:initPersonalInfoLabelView(data,parent )
    -- body
    if parent == nil then
        return
    end
    local list_data = data
    local container_h = parent:getContentSize().height
    local function initView( startTag,data,deltaH,parent )
        local list_data = data or {}
        local count = #list_data
        print("count",count)
        for i=1,count do
            local item_data = list_data[i]
            local text_layout = LabelCreater:createTextGroup(item_data,startTag,i)
            local layout_y = container_h - i * text_layout:getContentSize().height + deltaH
            text_layout:setPositionY(layout_y)
            if parent then
                parent:addChild(text_layout)
            end 
        end
    end
    initView(self.BaseTag,list_data["list_data1"],40,parent)
    initView(self.TeamTag,list_data["list_data2"],-120,parent)
end

function LabelCreater:initSysSettingLabelView( data,parent )
    -- body
    if parent == nil then
        return
    end
    local list_data = data
    local container_h = parent:getContentSize().height
    local function initView( startTag,data,deltaH,parent )
        local list_data = data or {}
        local count = #list_data
        for i=1,count do
            local item_data = list_data[i]
            local text_layout = LabelCreater:createTextAndButtonGroup(item_data,startTag,i)
            local layout_y = container_h - i * text_layout:getContentSize().height + deltaH
            text_layout:setPositionY(layout_y)
            if parent then
                parent:addChild(text_layout)
            end 
        end
    end
    initView(self.SetTag,list_data,40,parent)
    --initView(self.TeamTag,list_data["list_data2"],-150,parent)
end

-- {
--     {label = "展示称号"},
--     {label = "高大威猛"},
--     {label = "所属公会"},
--     {label = "公会排名"}
-- }
function LabelCreater:createTextGroup( data,startTag,tag )
    -- body
    local  layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0,1))
    layout:setContentSize(496,50)
    layout:setTouchEnabled(false)

    layout:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layout:setBackGroundColor(ccc3(0, 0, 255))
    layout:setOpacity(255)
    layout:setTag(tag)
    local layout_tag = tag

    local gap = 20
    local texts_data = data or {}
    local count = #texts_data
    for i=1,count do
        local text_data = texts_data[i]

        local cell_tag = (layout_tag - 1) * count + i
        local label_cell = self:createText(text_data,startTag,cell_tag)

        local label_w = label_cell:getVirtualRendererSize().width
        local label_h = label_cell:getVirtualRendererSize().height
        local layout_h = layout:getContentSize().height

        local idx = i - 1
        local label_x = idx * (label_w + gap) + label_w/2
        local label_y = (layout_h - label_h)/2 + label_h/2
        
        label_cell:setPosition(cc.p(label_x,label_y))
        
        layout:addChild(label_cell)
    end

    return layout
end

--{label = "昵称"},{label = "高大威猛"},{label = "btn_change"}
function LabelCreater:createTextAndButtonGroup( data,startTag,tag )
    -- body
    local  layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0,1))
    layout:setContentSize(480,50)
    layout:setTouchEnabled(false)

    layout:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layout:setBackGroundColor(ccc3(0, 0, 255))
    layout:setOpacity(255)
    layout:setTag(tag)
    local layout_tag = tag

    local gap = 20
    local texts_data = data or {}
    local count = #texts_data
    for i=1,count do
        local text_data = texts_data[i]
        local flag = text_data["label"]
        if flag == "btn_change" then
            gap = 50
        end

        local cell_tag = (layout_tag - 1) * count + i
        local label_cell = self:createTextAndButton(text_data,startTag,cell_tag,"变更")

        local label_w = label_cell:getVirtualRendererSize().width
        local label_h = label_cell:getVirtualRendererSize().height
        local layout_h = layout:getContentSize().height

        local idx = i - 1
        local label_x = idx * (label_w + gap) + label_w/2
        local label_y = (layout_h - label_h)/2 + label_h/2
        
        label_cell:setPosition(cc.p(label_x,label_y))
        
        layout:addChild(label_cell)
    end

    return layout
end

-- {label = "昵称",value = "null"},
-- {label = "UID",value = "null"}

function LabelCreater:createText( value,startTag,tag )
    -- body
    local  layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0.5,0.5))
    layout:setTouchEnabled(false)
    layout:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layout:setBackGroundColor(ccc3(255, 0, 255))
    layout:setOpacity(255)

    local valueStr = value["label"] or "none"
    local label = ccui.Text:create("",TEXT_FONT_NAME,22)
    label:ignoreContentAdaptWithSize(true)
    label:setAnchorPoint(cc.p(0.5,0.5))
    label:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    label:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    label:setColor(cc.c3b(255, 255, 255))
    label:setString(valueStr)

    local label_w = label:getVirtualRendererSize().width
    local label_h = label:getVirtualRendererSize().height
    local layout_w = 120
    local layout_h = 30
    local layout_x = (layout_w - label_w)/2 + label_w/2
    local layout_y = (layout_h - label_h)/2 + label_h/2
    label:setPosition(cc.p(layout_x,layout_y))
    layout:setContentSize(cc.size(layout_w,layout_h))
    
    local realTag = startTag + tag
    layout:setTag(realTag)
    layout:addChild(label)
    layout:setTouchEnabled(false)
    table.insert(self.LabelMap,realTag,label) 
    -- local function levelTouchCallBack(sender,eventType)
    --     if eventType == TOUCH_EVENT_ENDED then
    --         print("vvvvvvv")
    --     end
    -- end 
    -- layout:addTouchEventListener(levelTouchCallBack)
    return layout
end

function LabelCreater:createTextAndButton( value,startTag,tag,btnValue )
    -- body
    local  layout = ccui.Layout:create()
    layout:setAnchorPoint(cc.p(0.5,0.5))
    layout:setTouchEnabled(false)
    layout:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    layout:setBackGroundColor(ccc3(255, 0, 255))
    layout:setOpacity(255)

    local realTag = startTag + tag
    local valueStr = value["label"] or "none"
    local btnValueStr = btnValue or "变更"
    local layout_w = 120
    local layout_h = 30
    if valueStr ~= "btn_change" then
        local label = ccui.Text:create("",TEXT_FONT_NAME,22)
        label:ignoreContentAdaptWithSize(true)
        label:setAnchorPoint(cc.p(0.5,0.5))
        label:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        label:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        label:setColor(cc.c3b(255, 255, 255))
        label:setString(valueStr)

        local label_w = label:getVirtualRendererSize().width
        local label_h = label:getVirtualRendererSize().height

        local layout_x = (layout_w - label_w)/2 + label_w/2
        local layout_y = (layout_h - label_h)/2 + label_h/2
        label:setPosition(cc.p(layout_x,layout_y))
        layout:addChild(label)
        table.insert(self.LabelMap,realTag,label) 
    else
        local button = ccui.Button:create("res/uifile/n_UIShare/playerCard/wjmp_b_005_1.png", "res/uifile/n_UIShare/playerCard/wjmp_b_005_2.png")
        button:setTitleFontSize(26)
        button:setTitleText(btnValueStr)
        button:setContentSize(cc.size(layout_w,layout_h))
        button:setAnchorPoint(cc.p(0.5,0.5))
        local buttonX = layout_w/2
        local buttonY = layout_h/2
        button:setPosition(cc.p(buttonX,buttonY))
        layout:addChild(button)
        table.insert(self.LabelMap,realTag,button) 
    end
    
    layout:setContentSize(cc.size(layout_w,layout_h))
    layout:setTag(realTag)
    layout:setTouchEnabled(false)
    
    return layout
end

function LabelCreater:getLabelByTag( tag )
    -- body
    local label_tag = tag or 1
    local label = self.LabelMap[tag] or nil
    if label then
        return label
    end
end

function LabelCreater:createToggleButton( imgOn,imgOf,callBack )
    local imageOn = imgOn or "res/uifile/n_UIShare/playerCard/xxjm_b_004_1.png"
    local imageOff = imgOf or "res/uifile/n_UIShare/playerCard/xxjm_b_004_2.png"
    local function menuCallback(tag, sender)
        local index = sender:getSelectedIndex()
        if index == 0 then
            if callBack then
                callBack("On")
            end
        else
            if callBack then
                callBack("Off")
            end
        end
    end

    local menu_item = cc.MenuItemImage:create(imageOn,imageOn)
    local menu_sub_item = cc.MenuItemImage:create(imageOff,imageOff)
    local toggle_item = cc.MenuItemToggle:create(menu_item)
    toggle_item:registerScriptTapHandler(menuCallback)
    toggle_item:addSubItem(menu_sub_item)
    toggle_item:setName("toggle_item")
    
    local menu = cc.Menu:create()
    menu:setContentSize(menu_item:getContentSize())
    menu:addChild(toggle_item)
    return menu
end