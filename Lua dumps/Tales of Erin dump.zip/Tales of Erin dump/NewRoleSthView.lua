--require "XUIView"
--require "SthMatNumView"
--require "SthLevelUpView"
----角色详情进去  快捷 强化
NewRoleSthView = class("NewRoleSthView",XUIView)
NewRoleSthView.CS_FILE_NAME = "NewRoleSthView.csb"
NewRoleSthView.CS_BIND_TABLE = 
{
    panelEffect = "/i:412",
    -- effIcon = "/i:412/s:effIcon",

    panelMatL = "/i:352/i:90",
    panelMatM = "/i:352/i:76",
    panelLevel = "/i:352/i:130",

    panelIcon = "/i:352/i:53",

    lbCurAtk = "/i:352/i:141/i:144",
    lbAddAtk = "/i:352/i:141/i:148",
    lbCurHP = "/i:352/i:141/i:146",
    lbAddHP = "/i:352/i:141/i:149",
    lbCurDef = "/i:352/i:141/i:145",
    lbAddDef = "/i:352/i:141/i:150",
    lbCurSP = "/i:352/i:141/i:147",
    lbAddSP = "/i:352/i:141/i:151",

    btnStartSth = "/i:352/i:253",
}

-- ID_H_L  --狗粮ID
-- ID_H_M

function NewRoleSthView:init(hero_id,ReLoadCallFunc,sDelegate)
    NewRoleSthView.super.init(self)

    self.hero_id = hero_id

    self.ReLoadCallFunc = ReLoadCallFunc
    self.sDelegate = sDelegate

    self.panelEffect:setVisible(false)

    self.matViewL = SthMatNumView.new():init(self.panelMatL)
    if g_channel_control.transform_SthMatNumView_matName_pos == true then
        local oldLx = 74
        local newLx = oldLx+8
        self.matViewL.matName:setPositionX(newLx)
    end
    self.matViewL:setMatInfo(ID_H_L,0)
    self.matViewL.CurNumChangedEvent = function()
        self:computExp()
        self.matViewM:refresh()
    end
    self.matViewL.iconClickEvent = function()
        local nid = getMatID(ID_H_L)
        if GameManagerInst.gameType == 2 then
            MsgManager:showSimpItemInfoAndDropInfo(5,nid,true,self.onMatChanged,self)
        end
    end

    self.matViewM = SthMatNumView.new():init(self.panelMatM)
    if g_channel_control.transform_SthMatNumView_matName_pos == true then
        local oldMx = 74
        local newMx = oldMx+8
        self.matViewM.matName:setPositionX(newMx)
    end
    self.matViewM:setMatInfo(ID_H_M,0)
    self.matViewM.CurNumChangedEvent = function()
        self:computExp()
        self.matViewL:refresh()
    end
    self.matViewM.iconClickEvent = function()
        local nid = getMatID(ID_H_M)
        if GameManagerInst.gameType == 2 then
            MsgManager:showSimpItemInfoAndDropInfo(5,nid,true,self.onMatChanged,self)
        end
    end

    self.btnStartSth:addClickEventListener(function()
        self:onRoleSth()
    end)

    self.lvupView = SthLevelUpView.new():init(self.panelLevel)

    return self
end

function NewRoleSthView:onMatChanged()
    if self.matChangedEvent then
        self.matChangedEvent(self)
    end
    self:loadBagList()
end

function NewRoleSthView:loadBagList()
    GameManagerInst:rpc("{\"rpc\":\"bag_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        DataManager:wAllBagData(data["bag"])
        self:refresh()
    end,
    function(state_code,msgText)
        --failed
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleSthView:computExp()
    if self.hero_data then
        local midm = getMatID(ID_H_M)
        local midl = getMatID(ID_H_L)
        local expm = mat[midm].mat_data
        local expl = mat[midl].mat_data
        
        local n = self.matViewM:getCurMatNum()
        local n2 = self.matViewL:getCurMatNum()

        self.lvupView:setAddExp(n * expm + n2 * expl)
        local flv,ismax = self.lvupView:getFinalLevel()
        --刷新属性区域
        self:refreshPropNum(flv)

        self.matViewL:setIsMaxLevel(ismax)
        self.matViewM:setIsMaxLevel(ismax)

    end
end

function NewRoleSthView:playEffect()
    KeyboardManager._isShowEffect = true
    -- self.panelEffect:setVisible(true)

    -- local node_1 = cc.CSLoader:createNode("EffSthFrame.csb")
    -- local timeline_1 =cc.CSLoader:createTimeline("EffSthFrame.csb")

    -- self.lvupView.levelUpEffectEvent = function()
    --     timeline_1:play("animation0",false) 
    -- end
    self.lvupView.effectEndEvent = function()
        self:stopEffect()
    end
    self.lvupView:playEffect()    

    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    GameManagerInst:showModalView(self.maskView)
end

function NewRoleSthView:stopEffect()
    KeyboardManager._isShowEffect = false
    self.lvupView.levelUpEffectEvent = nil
    self.lvupView.effectEndEvent = nil
    self.lvupView:stopEffect()

    --self.effIcon:removeAllChildren()

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 

    self.panelEffect:setVisible(false)

    if self.effectStopedEvent then
        self.effectStopedEvent(self)
    end

    if self.ReLoadCallFunc then
        self.ReLoadCallFunc(self.sDelegate)
    end

    XbTriggerGuideManager:finishGuide(TriggerGuideConfig.StHero, self)
    
end

function NewRoleSthView:onRoleSth()

    if  not self.hero_data then return end

    local matnum1 = self.matViewL:getCurMatNum() or 0
    local matnum2 = self.matViewM:getCurMatNum() or 0

    if matnum1 + matnum2 == 0 then
        GameManagerInst:alert(UITool.ToLocalization("请选择强化素材"))
        return
    end

    local hid = self.hero_id

    local tempTable = {
        ["rpc"] = "hero_lv_up",
        ["target_id"] = hid,
        ["eat_mats"] ={},
    }
    
	if matnum1 > 0 then 
		table.insert(tempTable["eat_mats"],{mat_id = ID_H_L, mat_nums = matnum1})
	end
	
	if matnum2 > 0 then 
		table.insert(tempTable["eat_mats"],{mat_id = ID_H_M, mat_nums = matnum2})
	end

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        DataManager:wHeroData({data = data["data"][hid]},hid)
		for k,v in pairs(data["mat"]) do
			user_info["bag"]["mat"][k] = v
		end

        if  #data["data"][hid]["team_list"] > 0  then
            self:loadTeamList(function()
                self:playEffect()
            end)
        else
            self:playEffect()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end


function NewRoleSthView:loadTeamList(callback)

    GameManagerInst:rpc("{\"rpc\":\"team_list\"}",3,
    function(data)
        --success
        DataManager:wTeamData(data["team"])   
             
        if callback then
            callback()
        end
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function NewRoleSthView:FillHeroData(rcvData)
    if rcvData then
        self.hero_data = nil
        self.hero_data = table.deepcopy(rcvData)
        self.hero_id = self.hero_data.id
        self:refresh()
    end
end

function NewRoleSthView:refreshPropNum(flv)

    if self.hero_data then
        local h_id_num = getNumID( self.hero_id )
        local data = self.hero_data

        local h_id_str = getStrID( data["id"] )

        local curAtk = data["atk"]
        local curDef = data["def"]
        local curHP = data["hp"]
        local curSP = data["tp"]["max_num"]

        local curLv = data["Lv"]

        local addAtk = 0--hero_upgrade[h_id_num][flv][3] - curAtk
        local addDef = 0--hero_upgrade[h_id_num][flv][4] - curDef
        local addHP = 0--hero_upgrade[h_id_num][flv][2] - curHP
        if hero_upgrade[h_id_num] then
            if hero_upgrade[h_id_num][flv] then
                if hero_upgrade[h_id_num][flv][3] then
                    addAtk = hero_upgrade[h_id_num][flv][3] - curAtk
                end

                if hero_upgrade[h_id_num][flv][4] then
                    addDef = hero_upgrade[h_id_num][flv][4] - curDef
                end

                if hero_upgrade[h_id_num][flv][2] then
                    addHP = hero_upgrade[h_id_num][flv][2] - curHP
                end
            end
        end
        

        --计算技能点数
        local addSP = 0
        if flv > curLv then
            for i = curLv + 1,flv do
                addSP = addSP + hero_upgrade[h_id_num][i][8]
            end
        end

        self.lbCurAtk:setString(""..curAtk)
        if addAtk > 0 then
            self.lbCurAtk:setTextColor(cc.c3b(255,255,255))
            self.lbAddAtk:setString("+"..addAtk)
        else
            self.lbCurAtk:setTextColor(cc.c3b(171,171,171))
            self.lbAddAtk:setString("")
        end


        self.lbCurDef:setString(""..curDef)
        if addDef > 0 then
            self.lbCurDef:setTextColor(cc.c3b(255,255,255))
            self.lbAddDef:setString("+"..addDef)
        else
            self.lbCurDef:setTextColor(cc.c3b(171,171,171))
            self.lbAddDef:setString("")
        end

        
        self.lbCurHP:setString(""..curHP)
        if addHP > 0 then
            self.lbCurHP:setTextColor(cc.c3b(255,255,255))
            self.lbAddHP:setString("+"..addHP)
        else
            self.lbCurHP:setTextColor(cc.c3b(171,171,171))
            self.lbAddHP:setString("")
        end

        
        self.lbCurSP:setString(""..curSP)
        if addSP > 0 then
            self.lbCurSP:setTextColor(cc.c3b(255,255,255))
            self.lbAddSP:setString("+"..addSP)
        else
            self.lbCurSP:setTextColor(cc.c3b(171,171,171))
            self.lbAddSP:setString("")
        end

    else
        self.lbCurAtk:setString("")
        self.lbAddAtk:setString("")
        self.lbCurDef:setString("")
        self.lbAddDef:setString("")
        self.lbCurHP:setString("")
        self.lbAddHP:setString("")
        self.lbCurSP:setString("")
        self.lbAddSP:setString("")
    end
end

function NewRoleSthView:refresh()

    local nl = user_info["bag"]["mat"][ID_H_L]
    local nm = user_info["bag"]["mat"][ID_H_M]

    if nl == nil then nl = 0 end
    if nm == nil then nm = 0 end

    self.matViewL:setMatInfo(ID_H_L,nl)
    self.matViewM:setMatInfo(ID_H_M,nm)

    if self.hero_data then
        local data = self.hero_data
        local h_id_num = getNumID( data["id"] )

        --加载经验值
        local expTable = {}
        for i = 1,#hero_upgrade[h_id_num] do
            expTable[i] = hero_upgrade[h_id_num][i][1]
        end
        
        self.lvupView:setLevelInfo(expTable,data["Lv"],data["Lv_max"],data["exp"])

        local flv,ismax = self.lvupView:getFinalLevel()

        self.matViewL:setIsMaxLevel(ismax)
        self.matViewM:setIsMaxLevel(ismax)

        self.matViewL:setCurMatNum(0)
        self.matViewM:setCurMatNum(0)

        self.btnStartSth:setTouchEnabled(not ismax)
        self.btnStartSth:setBright(not ismax)

        self:refreshPropNum(flv)
    else
        self.matViewL:setIsMaxLevel(true)
        self.matViewM:setIsMaxLevel(true)

        self.matViewL:setCurMatNum(0)
        self.matViewM:setCurMatNum(0)

        self.lvupView:setLevelInfo(nil,0,0,0)
        
        self.btnStartSth:setTouchEnabled(false)
        self.btnStartSth:setBright(false)

        self:refreshPropNum()
    end
end
