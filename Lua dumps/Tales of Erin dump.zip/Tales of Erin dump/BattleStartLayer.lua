--开始战斗ui BattleStart.csb
BattleStartLayer = class("BattleStartLayer", function()
    return cc.Layer:create();
end);

function BattleStartLayer:ctor()
	self:initVariables()	

end
-- 初始化变量
function BattleStartLayer:initVariables( ... )
	self.battleStartPath = "uifile/BattleStart.csb"
	self.battleNewGuide  = "uifile/GuideiPictureView.csb"

	self.rootNode = cc.CSLoader:createNode(self.battleStartPath)
	self:addChild(self.rootNode)
	self.rootNode:setVisible(false)
end

--[[根据mode的值来调用指定的函数
    规则：
    mode =1:
        文字(准备，战斗开始，第n波） 动画(Start)        函数(playStart)   开始战斗调用
    mode =2: 
        文字(强敌出现）            动画(这是spine)     函数(playBoss)    路径 battleBossPath  boss战调用
    mode = 3:
        文字(遭遇战,第n波)         动画(scroll2)      函数(playScroll2) 在第二波或第三波调用。一般在mode = 4 之后调用
    mode = 4:
        场景过度动画 ，从右到左     动画(scroll1)      函数(playScroll1)  完成之后调用 mode = 3
    mode = 5:  --暂时不用
         场景过度动画 ，从右到左    动画(scroll1)      函数(playScroll15) 没有动作完成回调 和不需要处理的，只是简单的播放
]]
function BattleStartLayer:modeStateCall( mode ,callback )
    -- body
    if mode == 1 then
        self:playStart(callback)
    elseif mode == 2 then
        self:playBoss(callback)
    elseif mode == 3 then
        self:playScroll2(callback)
    elseif mode == 4 then
        self:playScroll1(callback)
    elseif mode == 5 then
        --self:playScroll15()
    end
end
-- 播放Start (mode==1)（准备战斗开始动画 显示第几波的文本）
function BattleStartLayer:playStart(callback) 
	-- body
    self.rootNode:stopAllActions()
    self.action = cc.CSLoader:createTimeline(self.battleStartPath)
    self.rootNode:runAction(self.action)
    self.rootNode:setVisible(true)
    --动作回调
    local this = self 
    local function localGame()
        this.rootNode:setVisible(false);
        this.rootNode:stopAllActions();
        callback()
    end

    SetLastFrameCallFunc_AllPlatform(self.action,localGame,2)

    local platform = cc.Application:getInstance():getTargetPlatform()
	if platform == cc.PLATFORM_OS_ANDROID then
		self.action:play("Start", true)
	else
		self.action:play("Start", false)
	end

    local waveNumText = self.rootNode:getChildByTag(3):getChildByTag(32)
    waveNumText:setString("1/"..BattleRuntimeInfo.totalWaveNum)

    self:resetGame()
end
-- boos关播放的。（强敌出现的spine） (mode == 2)
function BattleStartLayer:playBoss(callback)
	local spineNode = sp.SkeletonAnimation:createWithSkeletonAnimation(BattleCacheManager:getData(BattleGlobals.BOSS_SHOW))
    spineNode:setAnchorPoint(cc.p(0.5,0.5));
    spineNode:setPosition(cc.p(640,360));
    self:addChild(spineNode, 20);
    
    local layout = ccui.Layout:create();
    layout:setContentSize(cc.size(1280,720));
    layout:setAnchorPoint(cc.p(0.5,0.5));
    layout:setTouchEnabled(true);
    spineNode:addChild(layout);

    local this = self 
    local function func()
        this.rootNode:setVisible(false);
        this.rootNode:stopAllActions();
        callback()
    end

    spineNode:registerSpineEventHandler(
        function (event) 
            local  delay = cc.DelayTime:create(0.01)
            local sequence = cc.Sequence:create(delay, cc.RemoveSelf:create())
            spineNode:runAction(sequence)
            func()
        end, sp.EventType.ANIMATION_COMPLETE)

    spineNode:setAnimation(0, "effect", false);
    self:resetGame()
end
-- 开始播放scroll2 遭遇战 显示第几波怪物（mode == 3）
function BattleStartLayer:playScroll2( callback)
    self.rootNode:stopAllActions()
    self.action = cc.CSLoader:createTimeline(self.battleStartPath)
    self.rootNode:runAction(self.action)
    self.rootNode:setVisible(true);
    local this = self 
    local function localGame()
        this.rootNode:setVisible(false);
        this.rootNode:stopAllActions();
        callback()
    end

    SetLastFrameCallFunc_AllPlatform(self.action,localGame,2)

    self.action:play("scroll2", false);

    local waveNumText = self.rootNode:getChildByTag(7):getChildByTag(702)
    waveNumText:setString(BattleRuntimeInfo.currentWaveNum.."/"..BattleRuntimeInfo.totalWaveNum)

    self:resetGame()
end
-- 开始播放scroll 场景过度动画。从右到左  （mode == 4）一般情况是先播放完在播放 mode 3
function BattleStartLayer:playScroll1(callback)
    -- body
    self.rootNode:stopAllActions()
    self.action = cc.CSLoader:createTimeline(self.battleStartPath)
    self.rootNode:runAction(self.action)
    self.rootNode:setVisible(true);
    --待定调用
    local this = self 
    local function localGame()
        this.rootNode:setVisible(false);
        this.rootNode:stopAllActions();
        callback()
    end
    SetLastFrameCallFunc_AllPlatform(self.action,localGame,2) 
    self.action:play("scroll1", false);
end

-- 开始播放动作调用的函数  这根据后期如是暂停在改名字
function BattleStartLayer:resetGame( ... )
    -- body
end

--[[暂时用不到
-- 开始播放scroll 场景过度动画。从右到左 这个是无处理无回调的（mode == 5） 
function BattleStart:playScroll15( ... )
    -- body
        self.rootNode:stopAllActions()
        self.rootNode:runAction(self.action)
        self.rootNode:setVisible(true);
        self.action:play("scroll1", false);
end]]
