explain_help = {}
explain_help["gh"] = {}
explain_help["gh"]["max"] = 27
explain_help["gh"]["startNum"] = 1
explain_help["gh"]["endNum"] = 27

explain_help["gh"][1] ="56811"

explain_help["gh"][2] ="56812"

explain_help["gh"][3] ="56813"

explain_help["gh"][4] ="56814"

explain_help["gh"][5] ="56815"

explain_help["gh"][6] ="56816"

explain_help["gh"][7] ="56817"

explain_help["gh"][8] ="56818"

explain_help["gh"][9] ="56819"

explain_help["gh"][10] ="56820"

explain_help["gh"][11] ="56821"

explain_help["gh"][12] ="56822"

explain_help["gh"][13] ="56823"

explain_help["gh"][14] ="56824"

explain_help["gh"][15] ="56825"

explain_help["gh"][16] ="56826"

explain_help["gh"][17] ="56827"

explain_help["gh"][18] ="56828"

explain_help["gh"][19] ="56829"

explain_help["gh"][20] ="56830"

explain_help["gh"][21] ="56831"

explain_help["gh"][22] ="56832"

explain_help["gh"][23] ="56833"

explain_help["gh"][24] ="56834"

explain_help["gh"][25] ="56835"

explain_help["gh"][26] ="56836"

explain_help["gh"][27] ="56837"

explain_help["gh"][28] ="56838"

explain_help["gh"][29] ="56839"

explain_help["gh"][30] ="56840"

explain_help["gh"][31] ="56841"

explain_help["gh"][32] ="56842"

explain_help["gh"][33] ="56843"

explain_help["gh"][34] ="56844"

explain_help["gh"][35] ="56845"

explain_help["gh"][36] ="56846"

explain_help["xp"] = {}
explain_help["xp"]["max"] = 1
explain_help["xp"]["startNum"] = 1
explain_help["xp"]["endNum"] = 15

explain_help["xp"][1] ="50000"

explain_help["xp"][2] ="50001"

explain_help["xp"][3] ="50002"

explain_help["xp"][4] ="50003"

explain_help["xp"][5] ="50004"

explain_help["xp"][6] ="50005"

explain_help["xp"][7] ="50006"

explain_help["xp"][8] ="50007"

explain_help["xp"][9] ="50008"

explain_help["xp"][10] ="50009"

explain_help["xp"][11] ="50010"

explain_help["xp"][12] ="50011"

explain_help["xp"][13] ="50012"

explain_help["xp"][14] ="50013"

explain_help["xp"][15] ="50014"
