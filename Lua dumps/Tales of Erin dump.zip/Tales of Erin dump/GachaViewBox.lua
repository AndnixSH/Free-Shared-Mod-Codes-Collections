
require "BasicLayer"
---------大型活素材详细
GachaViewBox = class("GachaViewBox",BasicLayer)
GachaViewBox.__index = GachaViewBox
GachaViewBox.lClass  = 3                     ------  锻造弹窗tag 555
GachaViewBox.rData = nil

function GachaViewBox:init()
    print("进入了msgModel 界面")
    local node =cc.CSLoader:createNode("GachaViewBox.csb")
    self.uiLayer:addChild(node,0,2)
    self:initListView()
    self:sendData()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)   

end
function GachaViewBox:sendData( ... )
    local tempData = { 
        rpc = "lottery_detail",
        draw_id = self.rData["draw_id"],

    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        self:refrsh(data["item_detail"])
        self:setAll(data)
    end,
    function(state_code,msgText)
        --failed
        GameManagerInst:alert(msgText,function()
           
        end)
    end,
    true)
end
--显示总概率
function GachaViewBox:setAll( table )
    local  node   = self.uiLayer:getChildByTag(2)
    local  imagBg = node:getChildByName("Image_bg")
    local  title  = imagBg:getChildByName("Text_name")
    title:setString(UITool.getUserLanguage(table.title))
    local  imag   = imagBg:getChildByName("Image_2")
    local  text3  = imag:getChildByName("Text_1")
    text3:setString(table.pool_detail["3"])
    local  text4  = imag:getChildByName("Text_2")
    text4:setString(table.pool_detail["4"])
    local  text5  = imag:getChildByName("Text_3")
    text5:setString(table.pool_detail["5"])

    local btn = node:getChildByName("Button_close")
    local function touchCallBack(sender,eventType)
       local name = sender:getName()
       if eventType == ccui.TouchEventType.ended then
            self:returnBack()
       end
    end
    btn:addTouchEventListener(touchCallBack)
end
function GachaViewBox:returnBack( ... )
	-- body
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)


    if self.uiLayer~=nil then
      self.uiLayer:removeFromParent()
      self.uiLayer = nil
    end
    self:clear()
    --self.sManager:hideMsgMode()
end

function GachaViewBox:initListView()
    local  node   = self.uiLayer:getChildByTag(2)
    local  imagBg = node:getChildByName("Image_bg")
    local  _panelList = imagBg:getChildByName("Panel_5")

    local psize = _panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(_panelList, psize.width, psize.height,602,49)
    self.gridview.itemCreateEvent = function()
        local temp = XUICellView.new():init(nil,"GachaViweBoxNode.csb",{
            PanelList = "/s:Panel_1",
            name = "/i:33/i:29/s:Text_1",
            num  = "/i:33/i:29/s:Text_2",
            bl   = "/i:33/i:29/s:Text_3",
            

        })
        
        temp.onResetData = function(self)
            self.PanelList:setSwallowTouches(false)
            self.name:setString(UITool.getUserLanguage(self._data[1]))
            self.num:setString(self._data[2])
            self.bl:setString(self._data[3])
        end
        
        return temp
    end
    -- self.gridview.itemClickedEvent = function (sender,index)
    --     local data = sender:getDataSource()[index]
    --     self:showEquipGallery(index)
    -- end
end
function GachaViewBox:refrsh( table )
    -- body
    self.gridview:setDataSource(table)
end


function GachaViewBox:create(tdata,sManager)

     local msgModel = GachaViewBox.new()
	 msgModel.rData = tdata 
	 msgModel.sManager  = sManager
     msgModel.uiLayer = cc.Layer:create()
     msgModel:init()
     return msgModel
end