--require "XUIView"

EquipSkillView = class("EquipSkillView",XUIView)
EquipSkillView.CS_FILE_NAME = "EquipSkillView.csb"
EquipSkillView.CS_BIND_TABLE = 
{
    panelEffect = "/i:255",
    effCharge = "/i:255/s:effCharge",

    panelSort = "/i:81/s:panelSort",
    panelList = "/i:81/i:93",
    panelIcon = "/i:81/i:189",
    btnTarget1 = "/i:81/i:82",
    btnTarget2 = "/i:81/i:84",
    ImgBtnEq = "i:81/i:134",
    ImgBtnNoEq = "i:81/i:136",
    btnStartUP = "/i:81/i:1691",
    btnHelp = "/i:81/s:btnHelp",
    pBar = "/i:81/i:108",
    pArrow = "/i:81/i:109",
    pArrowText = "/i:81/i:109/i:111",
    lbMatNum = "/i:81/i:107",

    sortTitle = "/i:81/i:268",

    skillIcon = "/i:81/i:20/i:21",
    skillName = "/i:81/i:20/i:22",
    skillLv = "/i:81/i:20/i:23",
    skillLvNext = "/i:81/i:20/i:24",
    skillDescPanel = "/i:81/i:20/i:25",
    -- skillRskPanel1 = "/i:81/i:20/i:38",
    -- skillRskPanel2 = "/i:81/i:20/i:39",
    lbState1 = "/i:81/i:227",
}

function EquipSkillView.createWithBackBtn(nSelectTitleNum)
    EquipListView.nDefaultSelect = nSelectTitleNum or 0
    local v = EquipSkillView.new():init()
    --local b = BackgroundView.new():initWithBackBtn(v,"n_UIShare/Global_UI/bg/bg_003_1.png")
    local b = BackgroundView.new():initWithCloseBtn(v)
    return b,v
end

function EquipSkillView:init()
    EquipSkillView.super.init(self)

    self.exist = true
    
    self.panelEffect:setVisible(false)

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = EquipListItemView.new():init()

        temp.ClickEvent = function (item)
            self:equipClickEvent(item)
        end
                
        temp.resetDataEvent = function(item)
        --设置展示模式
            local smode = 0
            if g_channel_control.b_newEqBag then
                smode = math.floor(self.sortBtnView:getSortMode() / 10)
            else
                smode = self.sortBtnView:getSortMode() % 10
            end
            item:setTitleMode(smode)

            local data = item:getData()
            if self.currentState == 1 then
                item:setSelected(item:getData().id == self.currentTargetID)
            else
                if data.id == self.currentTargetID then
                    item:setShadow(true)
                else
                    item:setSelected(item:getData()._isselected)
                end
            end
        end
        return temp
    end

    --排序
    if g_channel_control.b_newEqBag then
        self.sortBtnView = EqSortButtonView.new():init(self.panelSort,"EqP_sk",61,"EqS_Rank_sk",0,"EqS_Ele_sk",0,"EqS_Brk_sk",0)
        self.sortBtnView.sortModeChangedEvent = function()
            self:ReLoadData()
        end
    else
        self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_qsk",915,1)
        self.sortBtnView.sortModeChangedEvent = function()
            self:refresh()
        end
    end
    --
    self.btnStartUP:addClickEventListener(function()
        self:onSkillUP()
    end)

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)
    --
    if g_channel_control.b_newEqBag then
        self.curTargetData = nil
        self.iconView = EQSelectIconView.new():init(self.panelIcon)
        self.iconView.BtnSelectClick = function(index)
            if self.currentState ~= 3 then
                self:showEquipList()
                self:refresh()
            end
        end
        --
        self.nSelectTitleNum = self.nDefaultSelect or 0 --1:已装。0:未装

        self.bEnableEqTitle = false   --已装灵装按钮是否有效
        self.bEnableNoEqTitle = true --未装灵装按钮是否有效

        self.ImgBtnEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableEqTitle then
                    self:onSelectTitle(1)
                end
            end
        end)
        self.ImgBtnEq:setSwallowTouches(true)

        self.ImgBtnNoEq:addTouchEventListener(function(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 and self.bEnableNoEqTitle then
                    self:onSelectTitle(0)
                end
            end
        end)
        self.ImgBtnNoEq:setSwallowTouches(true)
        
        --self:onCallEqListByTitle(self.nSelectTitleNum)
        --
        if g_channel_control.b_XbWorkShopView then
            self.ImgBtnEq:setVisible(false)
            self.ImgBtnNoEq:setVisible(false)
        else
            self.ImgBtnEq:setVisible(true)
            self.ImgBtnNoEq:setVisible(true)
        end
        --
    else
        self.iconView = REIconView.new():init(self.panelIcon)

        self.btnTarget1:setPressedActionEnabled(false)
        self.btnTarget1:addClickEventListener(function()
            self:switchState(1)
            self:refresh()
        end)

        self.btnTarget2:setPressedActionEnabled(false)
        self.btnTarget2:addClickEventListener(function()
            self:switchState(2)
            self:refresh()
        end)
    end

    self:switchState(1)

    self:showSkillInfo()
    self:setSkillTarget()
    
    return self
end

function EquipSkillView:showGuidePicLayer( ... )
    if self.exist ==  false then 
        return
    end
    local data = {}
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_lzrh_001.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function EquipSkillView:onSelectTitle(nSelectNum)
    if self.exist ==  false then 
        return
    end
    if self.nSelectTitleNum ~= nSelectNum then
        self.nSelectTitleNum = nSelectNum
        self:onCallEqListByTitle(self.nSelectTitleNum)
    end
end

function EquipSkillView:onCallEqListByTitle(nSelectNum)
    if self.exist ==  false then 
        return
    end
    --与后端交互获取新的装备列表
    self:ReLoadData()
    --
    --self:refreshTitleBtnState()
end

function EquipSkillView:refreshTitleBtnState()
    if self.exist ==  false then 
        return
    end
    if self.nSelectTitleNum == 1 then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[2])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[1])
    else
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[1])
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[2])
    end

    if not self.bEnableEqTitle then
        self.ImgBtnEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
    if not self.bEnableNoEqTitle then
        self.ImgBtnNoEq:loadTexture(EQ_TITLE_BTN_IMG[3])
    end
end

function EquipSkillView:showEquipList()
    if self.exist ==  false then 
        return
    end
    local b,v = EquipListView.createWithBackBtn(1)
    self.changeCompareView = nil

    v.ItemResetEvent = function(item)
        local d = item:getData()
        if d.id == self.currentTargetID then
            item:showUnequip()
        end
    end

    v.ItemClickedEvent = function(item)
        local eqdata = item:getData()

        if eqdata.id == self.currentTargetID then
            self:setSkillTarget()
            if g_channel_control.b_newEqBag then
                self:switchState(1)
                self:ReLoadData()
            end
        else
            self:setSkillTarget(eqdata.id)
            if g_channel_control.b_newEqBag then
                self:switchState(2)
                self:ReLoadData()
            end
        end
        b:returnBack()
    end
    
    v.dataSourceEvent = function(sender,sortmode)
        local dataset = {}
        dataset = self:getTargetDataSource()
        return dataset
    end

    b.beforeCloseEvent = function()
        self:ReLoadData()
    end

    v:refresh()
    SceneManager.rootLayer:addChild(b:getRootNode())
    --self:addSubView(b)
end


function EquipSkillView:switchState(state)
    if self.exist ==  false then 
        return
    end
    self.currentState = state

    if state == 1 then
        if g_channel_control.b_newEqBag then
            self.sortTitle:setString(UITool.ToLocalization("选择要消耗的灵装"))
        else
            self.sortTitle:setString(UITool.ToLocalization("选择要融合的灵装"))
        end
        if not g_channel_control.b_newEqBag then
            self.sortBtnView:setSortKey("eq_qsk",915)
        end
    else
        self.sortTitle:setString(UITool.ToLocalization("选择要消耗的灵装"))
        if not g_channel_control.b_newEqBag then
            self.sortBtnView:setSortKey("eq_qe",421)
        end
    end

    if g_channel_control.b_newEqBag then
        if g_channel_control.b_XbWorkShopView then
            self.ImgBtnEq:setVisible(false)
            self.ImgBtnNoEq:setVisible(false)
        else
            self.ImgBtnEq:setVisible(true)
            self.ImgBtnNoEq:setVisible(true)
        end

        self.btnTarget1:setTouchEnabled(false)
        self.btnTarget2:setTouchEnabled(false)
        self.btnTarget1:setVisible(false)
        self.btnTarget2:setVisible(false)
    else
        self.ImgBtnEq:setVisible(false)
        self.ImgBtnNoEq:setVisible(false)
        self.btnTarget1:setTouchEnabled(state == 2)
        self.btnTarget1:setBright(state == 2)   
        self.btnTarget2:setTouchEnabled(state == 1)
        self.btnTarget2:setBright(state == 1)   

        self.btnTarget1:setVisible(state ~= 3)
        self.btnTarget2:setVisible(state ~= 3)
    end
end

function EquipSkillView:lockSkillTarget(target_id,nEquiped)  
    if self.exist ==  false then 
        return
    end
    self:switchState(3)
    if g_channel_control.b_newEqBag then
        self.lockedEid = target_id
        self.nCurLockTargetEquiped = nEquiped
        --self:ReLoadDataInLocked(target_id,nEquiped)
    else
        self.currentTargetID =  target_id
    end
end

function EquipSkillView:setSkillTarget(target_id)
    if self.exist ==  false then 
        return
    end
    if tolua.isnull(self.skillDescPanel) == false then
        self.skillDescPanel:removeAllChildren()
    end
    self.currentTargetID = target_id

    local data = nil
    local sk_num_id = nil

    if target_id then
        sk_num_id = getNumID( target_id )
        self.iconView:showEquip(sk_num_id)

        data = user_info["eq"][target_id]
        if user_info["eq"][target_id] then
            self.curTargetData = table.deepcopy(user_info["eq"][target_id])
        end
        --self.curTargetData = table.deepcopy(user_info["eq"][target_id])
        if self.curTargetData then
            if self.curTargetData["owner"] == "0" then
                self.nCurTargetEquiped = 0
            else
                self.nCurTargetEquiped = 1
            end
        end
    else
        self.nCurTargetEquiped = nil
        self.iconView:showNoIcon()
    end    


    if not (data ~= nil and data.sk ~= nil) then
        --没选装备或装备无技能
        self.curSkillExp = 0
        self.skillIcon:setVisible(false)
        self.skillLv:setString("")
        self.skillLvNext:setString("")
        self.skillName:setString("")
        
        self.btnStartUP:setTouchEnabled(false)
        self.btnStartUP:setBright(false)

        -- self.skillRskPanel1:setVisible(false)
        -- self.skillRskPanel2:setVisible(false)
        
        return
    end

    -- for i = 1,2 do
    --     local prsk = self["skillRskPanel"..i]
    --     if data["rsk"] ~= nil and data["rsk"][i] ~= nil then
    --         prsk:setVisible(true)
    --         local strsrc = eq_random_sk[data["rsk"][i][1]]
    --         strsrc = string.gsub(strsrc,"%*",""..(data["rsk"][i][2]))
    --         prsk:getChildByName("rskDesc"):setString(strsrc)
    --     else
    --         prsk:setVisible(false)
    --     end
    -- end


    self.skillName:setString(UITool.getUserLanguage(equip[sk_num_id]["equip_skill"]["skill_name"]))--(equip[sk_num_id]["equip_skill"]["skill_name"])
    self.skillIcon:setTexture(equip[sk_num_id]["equip_skill"]["skill_img"])
    self.skillIcon:setVisible(true)
    self.skillLv:setString(string.format(UITool.ToLocalization("等级 %d"),data["sk"]["Lv"]))
    

    local detail_size = self.skillDescPanel:getSize()

    local richText = ccui.RichText:create()
    richText:ignoreContentAdaptWithSize(false)
    richText:setContentSize(detail_size.width-40,detail_size.height)
    richText:setPosition((detail_size.width-40) / 2,detail_size.height / 2)

    self.skillDescPanel:addChild(richText)

    --技能描述-当前等级
    local str_des = UITool.getUserLanguage(equip[sk_num_id]["equip_skill"]["skill_des"])--equip[sk_num_id]["equip_skill"]["skill_des"]
    str_des = UITool.stringForEqSK(str_des,data["sk"]["add_atk_rate"])
    -- -- str_des = string.gsub(str_des,"%*",""..(data["sk"]["add_atk_rate"]).."%%")
    -- richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 22) )

    self.curSkillExp = data["sk"]["up_need_exp"]   -------技能提升所需的经验

    if self.curSkillExp == 0 then --技能已经满级
        -- --panel_skillupdate:setVisible(false)
        -- SkLoadingBar_2:setVisible(false)
        -- panel_arrow:setVisible(false)
        -- text_slv_next:setVisible(false)
        richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(248,181,81), 255,str_des, TEXT_FONT_NAME, 22) )
        self.skillLvNext:setString("")        
        
        self.btnStartUP:setTouchEnabled(false)
        self.btnStartUP:setBright(false)
    else
        -- SkLoadingBar_2:setVisible(true)
        -- panel_arrow:setVisible(true)
        -- text_slv_next:setVisible(true)

        --技能描述-下个等级
        --local str_des_1 = " (+"..(data["sk"]["next_add_atk"]).."%)"
        --richText:pushBackElement(ccui.RichElementText:create(1, cc.c3b(95, 248, 2), 255, str_des_1, TEXT_FONT_NAME, 22) )
        for k, v in pairs( UITool.stringForEqSKUP(UITool.getUserLanguage(equip[sk_num_id]["equip_skill"]["skill_des"]),data["sk"]["add_atk_rate"],data["sk"]["next_add_atk"]) ) do
            if v ~= 0 then 
              richText:pushBackElement(v)  
            end     
        end
        self.skillLvNext:setString(string.format(UITool.ToLocalization("等级 %d"),(data["sk"]["Lv"]+1)))
        
        self.btnStartUP:setTouchEnabled(true)
        self.btnStartUP:setBright(true)
    end
end


--计算成功率
function EquipSkillView:showSkillInfo()
    if self.exist ==  false then 
        return
    end

    local pr = 0
    if self.currentState ~= 1 then
        local inum = 0
        local AllSkillExp = 0
        
        for i = 1,#self.currentDataSource do 
            local ld = self.currentDataSource[i]
            if ld._isselected then
                inum = inum + 1
                if ld.sk then
                    AllSkillExp = AllSkillExp + ld["sk"]["provide_sk_exp"]
                end
            end
        end

        self.lbMatNum:setString(inum)

        if self.curSkillExp == 0 then
            pr = 0
        else
            pr = math.min(AllSkillExp/self.curSkillExp,1)
        end
    else
        self.lbMatNum:setString("0")
    end

    local probabilistic = 0
    probabilistic = math.floor( pr * 100)
    
    self.pBar:setPercent(probabilistic)
    local posx = self.pBar:getPositionX()
    local psize = self.pBar:getSize()
    local posy = self.pArrow:getPositionY()
    posx = posx + psize.width * probabilistic / 100

    self.pArrow:setPosition(cc.p(posx,posy))
    self.pArrowText:setString(""..probabilistic.."%")
end

function EquipSkillView:equipClickEvent(item)
    if self.exist ==  false then 
        return
    end
    --local index = item:getIndex()
    local data = item:getData() --self.currentDataSource[index]

    if self.currentState == 1 then
        if g_channel_control.b_newEqBag then
            GameManagerInst:alert(UITool.ToLocalization("请先点击左侧添加需要融合的灵装"))
        else
            self:setSkillTarget(data.id)
            --self.num = 0
            self.gridview:refresh()
        end

    else
        --self.num = self.num + 1
        if data.id ~= self.currentTargetID then
            if data._isselected then
                data._isselected = false
            else
                local nselect = 0
                for i = 1,#self.currentDataSource do 
                    if self.currentDataSource[i]._isselected then
                        nselect = nselect + 1
                    end
                end
                if nselect < 20 then
                    data._isselected = true
                end
            end
            self.gridview:refresh()
        end
    end

    --计算升级
    self:showSkillInfo()
end

function EquipSkillView:playEffect(isSuccess)
    if self.exist ==  false then 
        return
    end
    KeyboardManager._isShowEffect = true
    self.panelEffect:setVisible(true)
    
    self.maskView = XUIFullScreenView.new():initMaskWithCallback(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)
    
    GameManagerInst:showModalView(self.maskView)
    
    local skeletonNode = sp.SkeletonAnimation:create("effects/eqskill/effect.json", "effects/eqskill/effect.atlas", 1.0)
    local psize = self.effCharge:getSize()
    skeletonNode:setPosition(cc.p(psize.width/2,0))
    skeletonNode:setTag(123)
    skeletonNode:setCompleteListener(function(trackIndex,loopCount)
        if trackIndex == 1 then
            skeletonNode:clearTracks()
            skeletonNode:setToSetupPose()
            if isSuccess then
                skeletonNode:setAnimation(2, "cheng_gong", false) 
            else
                skeletonNode:setAnimation(2, "shi_bai", false) 
            end  
        elseif trackIndex == 2 then
            UITool.delayTask(0.1,function()
                self:stopEffect()
            end)
        end
    end)
    self.effCharge:addChild(skeletonNode)

    skeletonNode:setAnimation(1, "xu_li", false)    
    
    if isSuccess then
        --self.lvping_handle = 
        AudioManager:shareDataManager():playMusic("music/ui/eqsklvupwin.mp3",0, false)
    else
        --self.lvping_handle = 
        AudioManager:shareDataManager():playMusic("music/ui/eqsklvupwin.mp3",0, false)
    end
end


function EquipSkillView:stopEffect()
    if self.exist ==  false then 
        return
    end
    KeyboardManager._isShowEffect = false
    local sk = self.effCharge:getChildByTag(123)
    if sk then
        sk:setToSetupPose()
        sk:clearTracks()
    end
    self.effCharge:removeAllChildren()

    -- if self.lvping_handle then
    --     AudioManager:shareDataManager():stop(self.lvping_handle)
    -- end

    if self.maskView then
        self.maskView:removeFromParentView()
        self.maskView = nil   
    end 
    
    self.panelEffect:setVisible(false)
    self:refresh()
end

-- -- 返回是否选择消耗的灵装中包含五星装备
function EquipSkillView:IsSelectedFive()
    if self.exist ==  false then 
        return
    end
    for i=1,#self.currentDataSource do
        local ld = self.currentDataSource[i]
        if ld then
            if ld._isselected then
                if ld["equip_rank"] > 4 then
                    return true
                end
            end
        end    
    end
    return false
end

function EquipSkillView:onSkillUP()
    if self.exist ==  false then 
        return
    end
    if self.currentTargetID == nil 
        or self.curSkillExp == 0 then
        return
    end

    if self.currentState == 1 then
        GameManagerInst:alert(UITool.ToLocalization("请选择融合素材"))
        return 
    end

    if self:IsSelectedFive() then
        MsgManager:showSimpMsgWithCallFunc2(UITool.ToLocalization("消耗灵装中包含五星灵装，是否继续"),self,self.SendSkillUPMsg)
    else
        self:SendSkillUPMsg()
    end
end

function EquipSkillView:SendSkillUPMsg( ... )
    if self.exist ==  false then 
        return
    end
    -- body
    local ids = {}
    local datas = {}
    local bIsSelectedFive = false
    for i = 1,#self.currentDataSource do 
        local ld = self.currentDataSource[i]
        if ld._isselected then
            bIsSelectedFive = true
            table.insert(ids,{
                ["fodder_type"] = 1,
                ["fodder_id"] = ld.id,
                ["fodder_nums"] = 1,
            })     --提交接口用
            table.insert(datas,ld)  --删除用
        end
    end

    if #ids == 0 then 
        GameManagerInst:alert(UITool.ToLocalization("请选择融合素材"))
        return 
    end

    local tempTable = {
        ["rpc"] = "eq_sk_up",
        ["target_id"] = self.currentTargetID,
        ["eat_fodders"] = ids,
    }

    GameManagerInst:rpc(tempTable,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        local isSkillUp
        if g_channel_control.b_newEqBag then
            isSkillUp = data["upgrade"][self.currentTargetID]["sk"]["Lv"] > self.curTargetData["sk"]["Lv"]
            local nEquiped = 0
            if self.curTargetData["owner"] == "0" then
                nEquiped = 0
            else
                nEquiped = 1
            end
            if self.lockedEid and self.nCurLockTargetEquiped and (self.currentState == 3) then
                self:ReLoadDataInLocked(self.lockedEid,self.nCurLockTargetEquiped)
            else
                self:ReLoadDataInSwitch()
            end
        else
            isSkillUp = data["upgrade"][self.currentTargetID]["sk"]["Lv"] > user_info["eq"][self.currentTargetID]["sk"]["Lv"]
            DataManager:dEquipData(datas)
            DataManager:wEquipData(data["upgrade"])
        end

        self:playEffect(isSkillUp)

        if self.infoChangedEvent then
            self.infoChangedEvent(self)
        end
    end,
    function(state_code,msgText,hehe)
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText)
    end,
    true)
end

function EquipSkillView:ReLoadDataInSwitch()
    if self.exist ==  false then 
        return
    end
    if self.currentState ~= 1 and self.currentTargetID and self.nCurTargetEquiped then
        self:ReLoadDataInLocked(self.currentTargetID,self.nCurTargetEquiped)
    else
        self:ReLoadData()
    end
end

function EquipSkillView:ReLoadDataInLocked(target_id,nInEquiped)
    if self.exist ==  false then 
        return
    end
    local rankVaules = {3,4,5}--table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = {1,2,3,4,5,0}--table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = {1,2,3,4,0}--table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local nEquiped = nInEquiped
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = nEquiped,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()

        self:setSkillTarget(target_id)
        --self:refresh()
        self:ReLoadData()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
            --self:returnBack()
        end)
    end,
    true)
end

function EquipSkillView:ReLoadData()
    if self.exist ==  false then 
        return
    end
    local rankVaules = table.deepcopy(self.sortBtnView:getRankMode())
    local eleVaules = table.deepcopy(self.sortBtnView:getEleMode())
    local brkVaules = table.deepcopy(self.sortBtnView:getBrkMode())
    local sortRev = table.deepcopy(self.sortBtnView:getSortRev())
    local sortKey = table.deepcopy(self.sortBtnView:getSortVaule())
    local tempData = { 
        rpc = "eq_list",
        rarity = rankVaules,
        element = eleVaules,
        brk_num = brkVaules,
        key = sortKey,
        reverse = sortRev,
        equipped = self.nSelectTitleNum,
    }
    GameManagerInst:rpc(tempData,3,
    function(data)
        --success
        if self.exist ==  false then 
            return
        end
        user_info["eq"] =  data["eq"]
        user_info["eq_max"] =  data["eq_max"]
        user_info["eq_num"] =  data["eq_num"]
        DataManager:rfsElist()       
        --DataManager:wAllBagData({mat = data["mat"]})
        if user_info["bag"]["mat"] == nil then
            user_info["bag"]["mat"] = {}
        end
        for k,v in pairs(data["mat"]) do
          user_info["bag"]["mat"][k] = v
        end

        --self.equipListView:setDataSource(equip_list)
        self.dataLoaded = true
        self:refresh()
        self:refreshTitleBtnState()
    end,
    function(state_code,msgText)
        --failed
        if self.exist ==  false then 
            return
        end
        GameManagerInst:alert(msgText,function()
           --self:returnBack()
        end)
    end,
    true)
end

function EquipSkillView:getDataSource()
    if self.exist ==  false then 
        return
    end
    local ds = {}
    --先排序，后刷列表  
    if self.currentState == 1 then
        --ds = table.deepcopy(equip_list)
        -- for i = 1,#equip_list do
        --     if equip_list[i]["owner"] == "0" then
        --         table.insert(ds,table.deepcopy(equip_list[i]))
        --     end
        -- end

        for i = 1,#equip_list do
            if equip_list[i]["sk"]["up_need_exp"] > 0 then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end
    elseif self.currentTargetID then       
    
        for i = 1,#equip_list do
            if (equip_list[i]["owner"] == "0") 
                and (not equip_list[i]["is_lock"])
                and (equip_list[i]["id"] ~= self.currentTargetID) then
                table.insert(ds,table.deepcopy(equip_list[i]))
            end
        end

    end

    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end

    return ds

end

function EquipSkillView:getTargetDataSource()
    if self.exist ==  false then 
        return
    end
    local ds = {} 
    for i = 1,#equip_list do
        if equip_list[i]["sk"]["up_need_exp"] > 0 then
            table.insert(ds,table.deepcopy(equip_list[i]))
        end
    end
    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end
    return ds
end

function EquipSkillView:getUseDataSource()
    if self.exist ==  false then 
        return
    end
    local ds = {} 
    for i = 1,#equip_list do
        if (not equip_list[i]["is_lock"])
            and (equip_list[i]["id"] ~= self.currentTargetID) then
            table.insert(ds,table.deepcopy(equip_list[i]))
        end
    end
    if g_channel_control.b_newEqBag then
        EqSortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    else
        SortBoxView.SortEquip (ds, self.sortBtnView:getSortMode())
    end
    return ds
end

function EquipSkillView:onSaleEquip(eid)
    if self.exist ==  false then 
        return
    end
    if self.currentTargetID == eid then
        self.currentTargetID = nil
    end
end

function EquipSkillView:refresh()
    if self.exist ==  false then 
        return
    end
    if g_channel_control.b_newEqBag then
        self.currentDataSource = self:getUseDataSource()
        if self.currentState == 1 then
            if self.panelList then
                self.panelList:setVisible(false)
            end
            if self.lbState1 then
                self.lbState1:setVisible(true)
            end
        else
            if self.panelList then
                self.panelList:setVisible(true)
            end
            if self.lbState1 then
                self.lbState1:setVisible(false)
            end
        end
    else
        self.currentDataSource = self:getDataSource()
    end
    if self.currentDataSource == nil then
        return
    end
    self.gridview:setDataSource(self.currentDataSource)

    if not g_channel_control.b_newEqBag then
        self:setSkillTarget(self.currentTargetID)
    end
    self:showSkillInfo()

end

function EquipSkillView:DestroyHandle()
    self.exist = false
end
