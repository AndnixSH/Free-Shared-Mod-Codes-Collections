--require "XUIView"
--require "XUIGridView"
--require "RoleListItemView"
--require "BackgroundView"

LabelListView = class("LabelListView",XUIView)
LabelListView.CS_FILE_NAME = "LabelListView.csb"
LabelListView.CS_BIND_TABLE = 
{
    panelList = "/i:332/i:334"
}

function LabelListView:init(str)
    LabelListView.super.init(self)

    self.dataStr = str

    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,600,30)
    self.gridview.itemCreateEvent = function()
        local temp = LabelListItem.new():init()

        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end

        temp.resetDataEvent = function(item)
            self:onItemReset(item)
        end

        return temp
    end

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

    self:refresh()

    return self
end

function LabelListView:closeBack()
    self:onBeforeClose()
    self:returnBack()
end

function LabelListView:onBeforeClose()
    if self.beforeCloseEvent then
        self.beforeCloseEvent(self)
    end
end


function LabelListView:returnBack()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:removeFromParentView()
end

function LabelListView:onItemClicked(item)    
    if self.ItemClickedEvent then
        self.ItemClickedEvent(item)
    end
end

function LabelListView:onItemReset(item)    
    if self.ItemResetEvent then
        self.ItemResetEvent(item)
    end
end

function LabelListView:refreshWithData(str)
    self.dataStr = str
    self:refresh()
end

function LabelListView:getDataSource()
    if self.dataStr then
        dataset = UITool.stringSplit(self.dataStr,"\n");
    else
        local str = "亲密度亲密度亲密度\n\t\t描述描述描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述\n  描述"
        dataset = UITool.stringSplit(str,"\n");
    end
    return dataset
end

function LabelListView:refresh()
    --先排序，后刷列表  equip_list
    local ds = self:getDataSource()

    self.currentDataSource = ds
    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(ds)
    self.gridview:jumpToPercent(percent)
end