--[[
	GuildPavilionLayer.lua
	公会道馆
]]
-- user_info["ap"]
-- user_info["ap_max"]
require "BasicLayer"
local scheduler = cc.Director:getInstance():getScheduler()
GuildPavilionLayer = class("GuildPavilionLayer",BasicLayer)
GuildPavilionLayer.__index = GuildPavilionLayer
GuildPavilionLayer.lClass = 2

function GuildPavilionLayer:create(rData)
     local layer = GuildPavilionLayer.new()
     layer.rData = rData
     layer.titleNum = 7
     layer:init()
     return layer
end

function GuildPavilionLayer:init()
    self.towerData = {} --存储塔的信息
	self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]

    self.uiLayer = cc.Layer:create()

    local node = cc.CSLoader:createNode("GuildPavilion.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    local panel = node:getChildByTag(102)
    self._rootCSbNode = panel
    self.topBarViewPanel = node:getChildByTag(553)

    --bg特效
    -- local bgRoot = ccui.Helper:seekWidgetByName(self._rootCSbNode,"bgRoot")
    -- local bganime = sp.SkeletonAnimation:create("effects/Diban/Diban.json", "effects/Diban/Diban.atlas", 1.0)
    -- local psize = bgRoot:getSize()
    -- bgRoot:addChild(bganime)
    -- bganime:setPosition(cc.p(psize.width / 2, psize.height / 2))
    -- bganime:setAnimation(1, "effect", true)

    self:initDefaultUI()
    self:showUIAp()

    local backBtn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(function(sender,eventType)
    	if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end)

    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")

    self:initListView()
    self:initBtnEvent()

    self:reqGuildTower()
    if g_channel_control.show_new_guild_main == true then
        self:InitTopBarView()
        local bg = self._rootCSbNode:getChildByName("Image_ap_bg")
        bg:setVisible(false)
    end
        --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    --首次进入 说明 key 统一用类名吧
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."GuildPavilionLayer_1") == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."GuildPavilionLayer_1", 1)
        self:showGuidePicLayer()
    end
    ---公会塔
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.GuildTower) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.GuildTower, 1)
    end

end
-- 显示UI AP
function GuildPavilionLayer:showUIAp( ... )
    -- body
    SceneManager.menuLayer:RefshTopBar()
    local bg        = self._rootCSbNode:getChildByName("Image_ap_bg")
    local lb_ap     = bg:getChildByName("lab_ap_cm")
    lb_ap:setString(user_info["ap"].."/"..user_info["ap_max"])
    local buyAp_btn = bg:getChildByName("Button_17")
    buyAp_btn:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local popData = {}
            popData["oneself"] = self
            popData["callFunc"] = self.buyAP
            popData["rcvData"] = nil
            self.sManager:toLoadApLayer(popData)


        end
    end)
end
-- 购买体力刷新体力
function GuildPavilionLayer:buyAP( ... )
    -- body
    -- 调用了这个
    SceneManager.menuLayer:RefshTopBar()
    local bg        = self._rootCSbNode:getChildByName("Image_ap_bg")
    local lb_ap     = bg:getChildByName("lab_ap_cm")
    lb_ap:setString(user_info["ap"].."/"..user_info["ap_max"])
end
function GuildPavilionLayer:initBtnEvent()
    --标签切换
    local function touchLabelBtnBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
           self:dealBtnEvent(sender.myTag)
        end
    end
    local btnkeys = {"Button_1","btn_start","btn_reward","btn_info"}
    for i=1,#btnkeys do
        local key = btnkeys[i]
        local btn = ccui.Helper:seekWidgetByName(self._rootCSbNode,key)
        btn.myTag = i --注：不用setTag 是为了防止tag值混乱
        btn:addTouchEventListener(touchLabelBtnBack)
    end
end
--1 排名奖励、2开始按钮、3层奖励、4说明
function GuildPavilionLayer:dealBtnEvent(selectTag)
    -- body
    local rData = {}
    if selectTag==1 then 
        rData.mType = 2
        self.sManager:toPavilionRewardLayer(rData)
    elseif selectTag==2 then 
        self:toReadyLayer()
    elseif selectTag==3 then 
        rData.mType = 1
        self.sManager:toPavilionRewardLayer(rData)
    elseif selectTag==4 then 
        self:showGuidePicLayer()
    end 
end

function GuildPavilionLayer:showGuidePicLayer()
    -- local data = {}
    --     data.pictures = { --一张或者多张
    --         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
    -- }
    -- self.sManager:toGuidePictureLayer(data)
    local data = {}
    data.pictures = { --一张或者多张
        "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
    }
    local sData = {}
    sData["prefix"] = "gh"
    sData["fontSize"] = 20
    sData["Iamgdata"] = data
    SceneManager:toPublicHelpText(sData)
end

function GuildPavilionLayer:toReadyLayer()
    local data = self.towerData.tower_info
    self.sData = {}
    if data and data.tower_now then
        local str = string.format(UITool.ToLocalization("苍蓝之塔第%d层"), tonumber(data.tower_now))
        self.sData["name"] = str
        self.sData["tower_now"] = data.tower_now
    end 
    if data and data.ap then
        self.sData["ap"] = data.ap
    end
    self.sData["mode"] = "Battle_Tower"
    self.sData["lv"] = 1 --隐藏的，不知道这个参数有什么用
    self.sManager:toReadyLayer(self.sData) 
end
--初始化列表
function GuildPavilionLayer:initListView()
    -- body
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 435.00,116)
    self.gridview.itemCreateEvent = function()
        require_ex("GuildPavilionItem")
        local temp = GuildPavilionItem.new():init()
        temp.ClickEvent = function(item)
        end
        temp.resetDataEvent = function(item)
        end
        return temp
    end
end

--刷新列表列表
function GuildPavilionLayer:refreshListUI()
    self.gridview:setDataSource(self.towerData.ranking)
end

--设置没有请求网络之前的界面状态
function GuildPavilionLayer:initDefaultUI( ... )
    local lab_floor = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_floor") --当前层数
    local lab_level = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_level") --推荐等级
    local lab_ap = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_ap")       --消耗ap
    local lab_hp = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_hp")       --hp
    local bar = ccui.Helper:seekWidgetByName(self._rootCSbNode,"bar1_1")       --hp
    local boss_icon = ccui.Helper:seekWidgetByName(self._rootCSbNode,"boss_icon")       --boss_icon
    local lab_time = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_time")       --boss_icon
    
    local bg_img        = self._rootCSbNode:getChildByName("bg_img")
    local Button_1 = bg_img:getChildByName("Button_1")
    local rankRwardText = Button_1:getChildByName("title_0_0_0")
    local floorRwardText = ccui.Helper:seekWidgetByName(self._rootCSbNode,"title_0_0")

    lab_time:setString("")
    lab_floor:setString("")
    lab_level:setString("")
    lab_ap:setString("")
    lab_hp:setString("")
    bar:setPercent(0)
    boss_icon:setVisible(false)

    if g_channel_control.transform_GuildPavilionLayer_title_0_0_0_fontSize == true then
        rankRwardText:setFontSize(22)
    end

    if g_channel_control.transform_GuildPavilionLayer_title_0_0_fontSize == true then
        floorRwardText:setFontSize(22)
    end

end

--其他UI，比如当前多少层、消耗的体力
function GuildPavilionLayer:refreshOtherUI()
    local data = self.towerData.tower_info
    local hpNow,hpMax
    hpNow= tonumber(data.boss_hp)
    hpMax= tonumber(data.boss_hp_max)

    --当前层次
    local lab_floor = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_floor") --当前层数
    local lab_level = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_level") --推荐等级
    local lab_ap = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_ap")       --消耗ap
    local lab_hp = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_hp")       --hp
    local bar = ccui.Helper:seekWidgetByName(self._rootCSbNode,"bar1_1")       --hp
    local boss_icon = ccui.Helper:seekWidgetByName(self._rootCSbNode,"boss_icon")       --boss_icon

    lab_floor:setString(data.tower_now)
    lab_level:setString(UITool.ToLocalization("推荐角色等级")..data.commend_lv)
    lab_ap:setString(data.ap)
    lab_hp:setString(hpNow.."/"..hpMax)
    bar:setPercent(hpNow/hpMax*100)
    boss_icon:loadTexture(data.boss_icon)
    boss_icon:setVisible(true)

    
    --元素
    for i=1,5 do 
        local emement = ccui.Helper:seekWidgetByName(self._rootCSbNode,"element_"..i) 
        if data.boss_atb[i]~=nil then 
            local e = tonumber(data.boss_atb[i])
            emement:loadTexture(ATB_Icon[e])
            emement:setVisible(true)
        else 
            emement:setVisible(false)
        end   
    end
    --end time end_time
    local lab_time = ccui.Helper:seekWidgetByName(self._rootCSbNode,"lab_time")       --boss_icon
    local timeStr = UITool.getFormat2Time(data.end_time)
    lab_time:setString(timeStr)
end

--item UI
function GuildPavilionLayer:updateItem(idx,root)
    -- body
    local data = self.towerData.ranking[idx]
    local rank = data.rank_num
    --name
    local title = ccui.Helper:seekWidgetByName(root,"title")
    title:setString(data.name)
    --icon head
    local icon = ccui.Helper:seekWidgetByName(root,"img_icon")
    --todo 说明:两种 一种是服务器返回的。png ，一种是id
    --icon:loadTexture(data.head)
    local iconId =tonumber(data.head)
    icon:loadTexture(hero[iconId].hero_bat_icon)

    --score
    local lab_score = ccui.Helper:seekWidgetByName(root,"lab_score")
    lab_score:setString(UITool.ToLocalization("积分 ")..data.score)
    --level
    local lab_level = ccui.Helper:seekWidgetByName(root,"lab_level")
    lab_level:setString(string.format(UITool.ToLocalization("等级 %d"),data.rank))

    --rank icon 
    local rankImgs = {"ghdg_ui_003.png","ghdg_ui_004.png","ghdg_ui_005.png"}
    local imgRank = ccui.Helper:seekWidgetByName(root,"rank_img")
    local labRank = ccui.Helper:seekWidgetByName(root,"rank_lab")
    if rank>0 and rank <4 then 
    	imgRank:loadTexture("n_UIShare/guild/guild_pavilion/"..rankImgs[rank])
		labRank:setVisible(false)
    else 
    	imgRank:setVisible(false)
    	labRank:setString(rank)
    end 

    --bg todo 
    if data.uid == user_info["id"] then 
        local item_bg = ccui.Helper:seekWidgetByName(root,"item_bg")
        item_bg:loadTexture("n_UIShare/guild/guild_pavilion/ghdg_ui_015.png")
        title:setColor(cc.c3b(255,237,120))
    end 
    
end
--刷新界面UI 包括列表和当前塔的信息
function  GuildPavilionLayer:refreshAllUI()
    -- body
    self:refreshListUI()
    self:refreshOtherUI()
    self:showUIAp()
end

--战斗结束
--todo data 
function GuildPavilionLayer:reqGuildTowerBattleEnd(jsonData)
    local function ReqSuccess(data)
        self:showBattleResult(data)
    end
    self:doJsonReq(jsonData, ReqSuccess)  
    self:refreshByUserInfoChange()
end

--显示战斗获得积分
function  GuildPavilionLayer:showBattleResult(data)
    -- body
    --弹窗 刷新
    local str1 = UITool.ToLocalization("本次战斗获得")
    --修改bug 之后需要上传到中心服
    local str2 = string.format(UITool.ToLocalization("%d积分、%d公会币。"),tonumber(data.get_score), tonumber(data.get_coin))
    --local str2 = UITool.ToLocalization(data.get_score.."积分、"..data.get_coin.."公会币。")
    MsgManager:showTwoLabInfo(self,self.reqGuildTower, str1,str2)
end

function GuildPavilionLayer:returnBack()
    self.sManager:removeFromNavNodes(self)
    if self.backFunc then
       self.backFunc(self.sDelegate)
    end
    self.exist = false
    self:clearEx()
end

function GuildPavilionLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function GuildPavilionLayer:setShow( )
	-- body
    self.sManager.menuLayer:hiddenUserInfo(true)
end

--获取道馆信息
function GuildPavilionLayer:reqGuildTower()
    local function ReqSuccess(data)
        self.towerData = data
        self:refreshAllUI()
    end
    local tempTable = {
        ["rpc"] = "guild_tower",
    }
    self:doReq(tempTable, ReqSuccess)  
end

-----todo 发送请求的放到公共里面，现在不知道放哪，暂时放着。
function GuildPavilionLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsgWithCallFunc1(UITool.getUserLanguage(t_data["data"]["warning"]),self,self.returnBack)
            return
        end
        
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    if self.sManager ~= nil then
        self.sManager:createWaitLayer()
    end

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

-----todo 发送请求的放到公共里面，现在不知道放哪，暂时放着。
function GuildPavilionLayer:doJsonReq(jsonData, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end
    
    self.sManager:createWaitLayer()

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(jsonData,3)
end


function GuildPavilionLayer:InitTopBarView()
    self.topBarViews = XUIView.new():init(self.topBarViewPanel)
    local iteamDatas = {}
    local rcvData = {}
    rcvData["sIteamDatas"] = iteamDatas
    rcvData["bIsStartLayer"] = false
    rcvData["nInfoState"] = table.getValue("coinbar",coinbar,24,"coinbar_type")
    rcvData["nTitleNum"] = 7

    self.topBarView = TopBarView.new():init(rcvData)
    self.topBarViews:addSubView(self.topBarView)
    self:InitSociatyTowerTopBarView()
end

function GuildPavilionLayer:InitSociatyTowerTopBarView()
    if self.topBarView then
        local iteamDatas = table.getValue("coinbar",coinbar,24,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end

-- 当货币栏中有不是金币，体力和星石时，需要单独刷洗数据 (根据不同的类型数据存入array_cointype中),具体类型参考cointype表 
function GuildPavilionLayer:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
           if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end

function GuildPavilionLayer:refreshByUserInfoChange()
    if self.topBarView then
        self.topBarView:refreshByUserInfoChange()
    end
end
