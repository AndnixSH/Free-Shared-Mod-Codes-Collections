--[[
     战斗求援按钮
     后期对接的时候需要修改两个地方 1 textCopyId =  战斗ID  2 发送服务器 id  = 战斗id
]]    

BattleHelperUILayer= class("BattleHelperUILayer", function()
    return cc.Layer:create();
end);

function BattleHelperUILayer:ctor()
    self:initVariables()
    self:initBtns()
end
-- 显示自己
function BattleHelperUILayer:showSelf()
    -- body
    self:setVisible(true)
end
-- 初始变量
function BattleHelperUILayer:initVariables( )
  	self.rootNode = cc.CSLoader:createNode("uifile/qiuyuanLayer.csb")
    self:addChild(self.rootNode);
    self:setVisible(false)
    -- panel 
    self.panel_AskHelp = self.rootNode:getChildByTag(1)
    -- 惨战代码文本
    self.textCopyId    = self.panel_AskHelp:getChildByTag(101):getChildByTag(102)

    self.textCopyId:setString(BattleDataManager.battleId);
    -- 求援按钮
    self.askHelpBtn = self.panel_AskHelp:getChildByTag(103)
    -- 取消按钮
    self.cancelBtn  = self.panel_AskHelp:getChildByTag(104)
    -- 拷贝按钮
    self.copyBtn    = self.panel_AskHelp:getChildByTag(107)
end
-- 初始化按钮
function BattleHelperUILayer:initBtns( ... )
	-- body
	local function touchCallBack( sender,eventType )
        -- body
        if eventType == ccui.TouchEventType.ended then
            self:touchClick(sender,eventType)
        end
    end
    self.askHelpBtn:addTouchEventListener(touchCallBack)
    self.cancelBtn:addTouchEventListener(touchCallBack)
    self.copyBtn:addTouchEventListener(touchCallBack)
end
-- 按钮点击事件
function BattleHelperUILayer:touchClick( sender,eventType )
	-- body
    if eventType == ccui.TouchEventType.ended then

    	local tag = sender:getTag()
        if tag == 103 then       -- 求援
           self:askHelpBtnCallBack()
        elseif tag == 104 then   -- 取消
           self:cancelBtnCallBack()
        elseif tag == 107 then   -- 复制惨战代码 按钮  
           self:copyBtnCallBack()
        end
        self:setVisible(false)
    end
end
-- 点击求援按钮回调
function  BattleHelperUILayer:askHelpBtnCallBack( ... )
	-- body
    self:sendAskHelp()
end
-- 点击取消按钮回调
function BattleHelperUILayer:cancelBtnCallBack( ... )
	-- body
    self:setVisible(false)
end
-- 点击拷贝按钮回调
function BattleHelperUILayer:copyBtnCallBack( ... )
    --拷贝，用到时打开注释
    if g_channel_control.bind_copyToClipboard then
        cc.Application:getInstance():copyToClipboard(BattleDataManager.battleId)
    end
end

--[[  获取求援数据
      mode == 0 发给所有玩家 活跃
      mode == 1 发给公会成员
      mode == 2 活跃 + 成员
]]

function BattleHelperUILayer:sendAskHelp( ... )
	-- body
    --所有玩家 活跃
    local check_1 = self.rootNode:getChildByTag(105);
    -- 公会成员
    local check_2 = self.rootNode:getChildByTag(106);
    local mode = 0;
    if check_1:isSelected() == false and check_2:isSelected() then
        mode = 1;
    elseif check_1:isSelected() and check_2:isSelected()then
        mode = 2; 
    end
	local function reiceSthCallBack(data)
        print("求援 数据")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if SceneManager ~= nil then
            SceneManager:delWaitLayer()
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then           
            --MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then 
            --MsgManager:showSimpMsgWithCallFunc1(UITool.ToLocalization("获取数据异常，请联系客服"), self, self.returnBack)
            return
        end
    end
    local cjson = require "cjson"
    SceneManager:createWaitLayer()
    local tempTable = {
        ["rpc"]       = "multi_invite",
        ["id"]        = BattleDataManager.battleId,
        ["scope"]     = mode,
    }

    local mydata =  cjson.encode(tempTable)
    print("测试  奖励数量 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

