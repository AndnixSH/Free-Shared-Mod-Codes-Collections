require "BasicLayer"

LoadAp = class("LoadAp",BasicLayer)
LoadAp.__index = LoadAp
LoadAp.lClass = 3
LoadAp.ApInfo = {}

 function LoadAp:init()
    local node =cc.CSLoader:createNode("LoadAP.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    local panel = node:getChildByTag(500)
    panel:setTouchEnabled(true)

    --修改锚点，
    if g_channel_control.LoadApTiliAnchorPoint == true then
        local tili1 = panel:getChildByTag(50)
        if tili1~= nil then
          tili1:setAnchorPoint(cc.p(1.0,0.5))
          tili1:setPosition(cc.p(496,342));
        end
        local tili2 = panel:getChildByTag(51)
        if tili2~= nil then
          tili2:setAnchorPoint(cc.p(1.0,0.5))
          tili2:setPosition(cc.p(728,342));
        end
    end
    local function touchCallBack(sender,eventType)
	  if eventType == ccui.TouchEventType.ended then
		
		if sender:getTag() ==101 then
		   local tempTable = {
             ["rpc"] = "eat_item",
             ["item_type"] = 1,
             ["item_num"] = 1
           }
           self:reqAP(tempTable)
		elseif sender:getTag() ==102 then
           local tempTable = {
             ["rpc"] = "eat_item",
             ["item_type"] = 2,
             ["item_num"] = 1
           }
           self:reqAP(tempTable)
		elseif sender:getTag() ==103 then
          local tempTable = {
             ["rpc"] = "eat_item",
             ["item_type"] = 3,
             ["item_num"] = AP_GEM
           }
           self:reqAP(tempTable)
        else
           self:returnBack()
        end

      end
   end 
    for i=1,4 do
    	   local button = ccui.Helper:seekWidgetByTag(panel,100+i)
    	   button:addTouchEventListener(touchCallBack)
    end
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
      -- body
      self:returnBack()
    end)
    self:reqAPInfo()
end


function LoadAp:updateAPInfo()
	local node =self.uiLayer:getChildByTag(1)
	local panel = node:getChildByTag(500)
    local dataTable = {
          [201] = self.ApInfo["ap"],
          [202] = self.ApInfo["ap"],
          [203] = self.ApInfo["ap"],
          [204] = self.ApInfo["ap"] + AP_M,
          [205] = self.ApInfo["ap"] + AP_L,
          [206] = self.ApInfo["ap"] + AP_M,
          [301] = self.ApInfo["m_ap"],
          [302] = self.ApInfo["l_ap"],
          [303] = self.ApInfo["gem"],
          [304] = (self.ApInfo["m_ap"]-1),
          [305] = (self.ApInfo["l_ap"]-1),
          [306] = (self.ApInfo["gem"]-AP_GEM)
       }

	for i=1,6 do
		local nowAp =  ccui.Helper:seekWidgetByTag(panel,200+i)
    local num = dataTable[200+i]
    if num < 0 then
       num = 0
    end
		nowAp:setString(num)
		local gem = ccui.Helper:seekWidgetByTag(panel,300+i)
    local num_1 = dataTable[300+i]
    if num_1 < 0 then
       num_1 = 0
    end
		gem:setString(num_1..UITool.ToLocalization("个"))
	end

   ccui.Helper:seekWidgetByTag(panel,11):loadTexture("icons/mat/"..useprop[1]["icon"])
   ccui.Helper:seekWidgetByTag(panel,21):loadTexture("icons/mat/"..useprop[2]["icon"])

end

function LoadAp:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function LoadAp:returnBack()
      self.exist = false
      self.uiLayer:removeFromParent()
      self.uiLayer = nil 
      self:clearEx()
end

--发送AP详情请求
function LoadAp:reqAP(itemTable)
    local function reiceResultCallBack(data)
        print("收到吃ap信息")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        DataManager:eatAP(t_data["data"])
        if self.sManager ~= nil then
           self.sManager.menuLayer:RefshTopBar()
        end
        
        if self.rData["rcvData"]["callFunc"] then
  		      self.rData["rcvData"]["callFunc"](self.rData["rcvData"]["oneself"],self.rData["rcvData"]["rcvData"])
            self.exist = false
            self.uiLayer:removeFromParent()
            self.uiLayer = nil 
            self:clearEx()
        else 
            self:reqAPInfo()
            MsgManager:showSimpMsg(UITool.ToLocalization("购买体力成功"))
	      end
    end
    local cjson = require "cjson"
    if self.sManager ~= nil then
       self.sManager:createWaitLayer()
    end
    
    local mydata =  cjson.encode(itemTable)
    print("测试 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--发送AP详情请求
function LoadAp:reqAPInfo()
 local function reiceResultCallBack(data)
        print("收到ap信息")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
           self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
       self.ApInfo = {}
       self.ApInfo =t_data["data"]
       self:updateAPInfo()
       end
    local cjson = require "cjson"
    if self.sManager ~= nil then
       self.sManager:createWaitLayer()
    end
    local tempTable = {
        ["rpc"] = "ap_info"
    }
    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)

end

function LoadAp:create(rData)
    local layer = LoadAp.new()
     layer.rData = rData 
     layer.exist = true
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
