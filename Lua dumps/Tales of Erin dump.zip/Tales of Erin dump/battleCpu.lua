
--属性克制计算伤害先关
RACE_RST = 1.25 --克制时伤害加成
NO_RACE_RST = 0.75 --非克制时伤害加成
DEBUFF_RST = 50 --克制异常命中加成
NO_DEBUFF_RST = -30 --非克制异常命中加成

--连击相关
HIT_NUM1 = 49    --连击1阶段需要连击数
HIT_NUM2 = 99   --连击2阶段需要连击数
HIT_NUM3 = 149   --连击3阶段需要连击数
HIT_NUM4 = 199   --连击4阶段需要连击数
HIT_NUM5 = 249  --连击5阶段需要连击数
HIT_NUM6 = 299  --连击5阶段需要连击数
HIT_NUM7 = 349  --连击5阶段需要连击数
HIT_NUM8 = 399  --连击5阶段需要连击数
HIT_NUM9 = 449  --连击5阶段需要连击数
HIT_NUM10 = 499  --连击5阶段需要连击数
HIT_NUM11 = 99999  --连击5阶段需要连击数

ADD_HIT1_DMG = 0 --连击1阶段伤害加成
ADD_HIT2_DMG = 5 --连击2阶段伤害加成
ADD_HIT3_DMG = 10 --连击3阶段伤害加成
ADD_HIT4_DMG = 15 --连击4阶段伤害加成
ADD_HIT5_DMG = 20 --连击5阶段伤害加成
ADD_HIT6_DMG = 25 --连击1阶段伤害加成
ADD_HIT7_DMG = 30 --连击2阶段伤害加成
ADD_HIT8_DMG = 35 --连击3阶段伤害加成
ADD_HIT9_DMG = 40 --连击4阶段伤害加成
ADD_HIT10_DMG = 45 --连击5阶段伤害加成
ADD_HIT11_DMG = 50 --连击5阶段伤害加成
--攻击力 防御力 计算相关
PA_ATK1 = 0.04 --治疗系数1
PA_ATK2 = 0.04 --治疗系数2
PA_PM = 10000 --阶段参数

SA_ATK1 = 0.1 --普通攻击 技能攻击系数1
SA_ATK2 = 0.1 --普通攻击 技能攻击系数2
SA_PM = 15000 --阶段参数

DEF_1 = 1 --防御系数1
DEF_2 = 1 --防御系数2
DEF_PM = g_channel_control.defend_pm or 2000 --防御阶段系数

---背水阶段计算
EM_NUM1 = 80 --第1阶段背水触发需要血线
EM_NUM2 = 50 --第2阶段背水触发需要血线
EM_NUM3 = 25 --第4阶段背水触发需要血线
EM_NUM4 = 10 --第4阶段背水触发需要血线
EM_ADD1 = 1  --第1阶段背水攻击力加成效果
EM_ADD2 = 2  --第2阶段背水攻击力加成效果
EM_ADD3 = 3  --第3阶段背水攻击力加成效果
EM_ADD4 = 4  --第4阶段背水攻击力加成效果

--获得属性克制加成
function getRaceRestraint(race1,race2,type)    
local race = 1.0;
    
    if ((race1==1 and race2==2) or (race1==2 and race2==3) or (race1==3 and race2==1)) then
        race = RACE_RST
   
    elseif ((race2==1 and race1==2) or (race2==2 and race1==3) or (race2==3 and race1==1)) then
        race = NO_RACE_RST
    end

    if (type==1) then
        if((race1==4 and race2==5) or (race1==5 and race2==4)) then
           race = RACE_RST
        end
        
   else 
        if((race2==4 and race1==5) or (race2==5 and race1==4)) then
            race = NO_RACE_RST
        end
   end
    
  return race;

end

--获得异常命中加成
function getDebuffRate(race1,race2,type)
      local race = getRaceRestraint(race1,race2,type) 
      local kz = 0
      if race>1 then
        kz = DeBUFF_RST;
    elseif race<1  then
        kz = NO_DEBUFF_RST
    else 
        kz = 0
    end
    return kz
end

--获得连击数加成
 function getAddHitDmg(hit)
 
    if hit > HIT_NUM11 then
      dmg = ADD_HIT11_DMG
    elseif hit > HIT_NUM10 then
      dmg = ADD_HIT11_DMG
    elseif hit > HIT_NUM9 then
      dmg = ADD_HIT10_DMG
    elseif hit > HIT_NUM8 then
      dmg = ADD_HIT9_DMG
    elseif hit > HIT_NUM7 then
      dmg = ADD_HIT8_DMG
    elseif hit > HIT_NUM6 then
      dmg = ADD_HIT7_DMG
   elseif hit > HIT_NUM5 then
      dmg = ADD_HIT6_DMG
   elseif hit > HIT_NUM4 then
      dmg = ADD_HIT5_DMG
   elseif hit > HIT_NUM3 then
      dmg = ADD_HIT4_DMG
   elseif hit > HIT_NUM2 then
      dmg = ADD_HIT3_DMG
   elseif hit > HIT_NUM1 then 
      dmg = ADD_HIT2_DMG
   else 
      dmg = ADD_HIT1_DMG
   end
   return dmg 
 end

-- 获取治疗攻击力
function getPastorATK(atk)
    local rATK = 0;
    
    local a = PA_ATK1
    local b = PA_ATK2
    local A = PA_PM
    if(atk-A<=0) then
       rATK = rATK + atk*a
    elseif (atk-A>0) then
        rATK = rATK + A*a;
        rATK =rATK +(atk-A)*b
    end
    return rATK;

end

--获取普攻攻击力
function getSoloATK(atk)
   local rATK = 0
    if atk<0 then
        atk = 0
    end

    local a = SA_ATK1
    local b = SA_ATK2
    
    local A = SA_PM
    
    if (atk-A<=0) then
        rATK =  rATK +atk*a;
    elseif (atk-A>0) then
        rATK = rATK +A *a; 
        rATK = rATK +(atk-A)*b;
    end
    return rATK;
end

--获取防御系数

function getDef(atk)
  local  rATK = 0;
    if atk<0 then
        atk = 0;
    end

    local a = DEF_1;
    local b = DEF_2;
    
    local A = DEF_PM;
    
    rATK =atk*a/(A+atk*b);
    
    return 1 - rATK;
end

--获取背水攻击力
function getEMIATK(pe)
    local rATK = 0
    if (pe<=EM_NUM4) then
        EM_ADD4 = 4
    elseif (pe<=EM_NUM3)then
        EM_ADD3 = 3
    elseif (pe<=EM_NUM2)then
        EM_ADD2 = 2
    elseif (pe<=EM_NUM1) then
        EM_ADD1 = 1;
    end
    return rATK
end
