EmoticonItem = class("EmoticonItem", function()
    return ccui.Layout:create()
end)

function EmoticonItem:ctor( data )
    
end
function EmoticonItem:initialize(data)
    if data == nil then
        return
    end
    self:initData(data)
    self:initUI()
end

function EmoticonItem:initUI( ... )
    local data = self._data
    self:setContentSize(cc.size(108,108))
    --self:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    --self:setBackGroundColor(cc.c3b(0, 255, 100))
    local emot_icon = data["expression_path"]
    local emot_icon_path = "res/hd/Resources/icons/expression/"..emot_icon

    local emot_img = ccui.ImageView:create(emot_icon_path)
    emot_img:setScale(0.8)
    self:addChild(emot_img)

    local emot_img_w = emot_img:getContentSize().width
    local emot_img_h = emot_img:getContentSize().height
    self:setContentSize(cc.size(emot_img_w,emot_img_h))
    emot_img:setPosition(cc.p(emot_img_w/2,emot_img_h/2 + 16))
    emot_img:setTouchEnabled(true)
    emot_img:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local t_data = {}
            t_data["id"] = data["index"]
            t_data["type"] = data["id"]
            lemon.EventManager:dispatchCustomEvent(EEventType.CHAT_EXPRESSION_SEND,t_data)
        end
    end)

    local emot_label = ccui.Text:create("",TEXT_FONT_NAME,18)
    emot_label:ignoreContentAdaptWithSize(true)
    --emot_label:setAnchorPoint(cc.p(0.5,0.5))
    emot_label:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    emot_label:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    emot_label:setColor(cc.c3b(228, 209, 166))

    local emot_name = UITool.getUserLanguage(data["expression_name"]) or ""
    emot_label:setString(emot_name)

    local emot_label_w = emot_label:getVirtualRendererSize().width
    local emot_label_h = emot_label:getVirtualRendererSize().height

    local emot_label_x = emot_img_w/2
    local emot_label_y = emot_label_h--54--(108 - emot_label_h)/2
    
    emot_label:setPosition(cc.p(emot_label_x,emot_label_y))

    self:addChild(emot_label)
end

function EmoticonItem:initData(data)
    -- body
    self._data = data
end

function EmoticonItem:create(data)
    local node = EmoticonItem.new()
    node:initialize(data)
    return node
end
