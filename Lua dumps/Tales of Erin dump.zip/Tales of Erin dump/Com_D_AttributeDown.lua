--属性下降类的组件
--created by kobejaw.2018.6.30.
Com_D_AttributeDown = class("Com_D_AttributeDown",ComponentBase)

function Com_D_AttributeDown:ctor(comId,level,target,option)
	self.super.ctor(self,comId,level,target,option)
	self.comType = 2
	self.buffType = Com_DebuffEnum.AttributeDown
end

--开始生效。
--@isAdd 是否正向生效
function Com_D_AttributeDown:takeEffect(isAdd)
	local attrId = GetAttrIdByComId(self.comId,self.level)
	--一个debuff对应单属性的情况
	if attrId then 
		local attrValue = self.comData.effect1 * self.overlayNum
		if isAdd then
			attrValue = -attrValue
		end
		self.target.attributeManager:changeAttr(attrId,attrValue)	
	--一个debuff对应多个属性的情况
	else
		--虚弱.降低攻击力，防御力
		if self.comId == 82026 then
			local attrId1 = AE.add_atk
			local attrId2 = AE.add_defence
			local value1 = self.comData.effect1 * self.overlayNum
			local value2 = self.comData.effect2	* self.overlayNum	
			if isAdd then
				value1 = -value1
				value2 = -value2	
			end
			self.target.attributeManager:changeAttr(attrId1,value1)	
			self.target.attributeManager:changeAttr(attrId2,value2)	
		else
			print("程序未实现这个组件.comID:  "..self.comId)
			return				
		end
	end	

	self.super.takeEffect(self,isAdd)
end
