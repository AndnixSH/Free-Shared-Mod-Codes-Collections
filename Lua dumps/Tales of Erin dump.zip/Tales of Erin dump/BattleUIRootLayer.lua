--所有UI的父layer
--create by kobejaw.2018.4.17.
BattleUIRootLayer = class("BattleUIRootLayer", function()
    return cc.Layer:create();
end);

function BattleUIRootLayer:ctor()
	--战斗信息层
	G_BattleUILayer = self

	--UI
	BattleUIManager:init()
	local uilayer = BattleUIManager:getUILayer()
	self:addChild(uilayer)

	--初始化技能管理器
	ActiveSkillManager:init(uilayer.rootNode)
end