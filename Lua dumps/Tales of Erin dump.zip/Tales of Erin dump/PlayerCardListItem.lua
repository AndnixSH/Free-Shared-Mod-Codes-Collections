
PlayerCardListItem = class("PlayerCardListItem", XUICellView)
PlayerCardListItem.CS_FILE_NAME = "PlayerCardListItem.csb"
PlayerCardListItem.CS_BIND_TABLE = 
{
    touchPanel = "/s:root",
    imgRarity = "/s:root/s:imgRarity",
    imgFace = "/s:root/s:imgFace",
    selectImg = "/s:root/s:selectImg",
    imgBG = "/s:root/s:imgBG",
}

function PlayerCardListItem:init(...)
    PlayerCardListItem.super.init(self,...)

    self.isSelect = false
    self.touchPanel:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                if self.ClickEvent then
                    self.ClickEvent(self)
                end
            end
        end
    end)
    self.touchPanel:setSwallowTouches(false)
    return self
end

function PlayerCardListItem:initFromType( fromType )
    -- body
    self.from = fromType or PlayerInfoSys.EChangeType.changeTJBanNiang
end

--重置UI
function PlayerCardListItem:onResetData()
    if not self._data then return end
    local heroID = nil
    local rbg = nil
    if g_channel_control.b_XbPlayerInfoView == true then
        heroID = getNumID(self._data["id"])
        rbg = Rarity_E_BG[self._data["hero_rank"]] --背景
    else
        heroID = self._data
        rbg = Rarity_E_BG[hero[heroID].hero_rank] --背景
    end
    
    if rbg then
        self.imgBG:setTexture(rbg)
    end

    --icon
    if heroID then
        local face = hero[heroID].hero_list_icon    
        if face then
            self.imgFace:setTexture(face)
        end
        --kuang
        local frame = Rarity_Icon[hero[heroID].hero_rank]  --外框
        if frame then
            self.imgRarity:setTexture(frame)
        end

        self:refreshSelected(heroID)

        local img = ATB_Icon[hero[heroID]["hero_atb"]]   
        local elementImg = cc.Sprite:create(img)
        if elementImg ~= nil then
            elementImg:setAnchorPoint(cc.p(0.5,0.5))
            elementImg:setPosition(134.5,113)
            elementImg:setScale(0.6)
            self.imgRarity:addChild(elementImg)
        end
    end
end

function PlayerCardListItem:refreshSelected( hero_id )
    -- body
    local heroID = hero_id
    if self.from == PlayerInfoSys.EChangeType.changeHead then
        local player_info = PlayerInfoSys:getInstance():getPersonalInfo()
        if player_info["head_icon_id"] == heroID then 
            self.selectImg:setVisible(true)
        else 
            self.selectImg:setVisible(false)
        end 
    elseif self.from == PlayerInfoSys.EChangeType.changeTJBanNiang then
        print("lllllll==>",user_info["gallery_icon_id"],heroID)
        if user_info["gallery_icon_id"] == heroID then
            self.selectImg:setVisible(true)
        else
            self.selectImg:setVisible(false)
        end
    end
end
