--require "XUIView"

GuildFacilityView = class("GuildFacilityView",XUIView)
GuildFacilityView.CS_FILE_NAME = "GuildFacilityView.csb"
GuildFacilityView.CS_BIND_TABLE = {
    panelBG = "/s:panelBG",
    panelTouch = "/s:panelTouch",
    -- Item1 = "/s:Panel_25/s:Item1",
    -- Item2 = "/s:Panel_25/s:Item2",
    -- Item3 = "/s:Panel_25/s:Item3",
    panelItems = "/s:Panel_25",
    btnList = "/s:Panel_25/s:btnList",
    cangyu_bg = "/s:Panel_25/i:512",
    lbCangyuNum = "/s:Panel_25/i:513",
    xingshi_bg = "/s:Panel_25/i:514",
    lbXingshiNum = "/s:Panel_25/i:515",
    btnAdd = "/s:Panel_25/i:516",

    panelLevelInfo = "/i:493",
    btnInfo = "/i:493/i:502",
    barLevel = "/i:493/i:509",
    lbExp = "/i:493/i:510",
    lbLevel = "/i:493/i:505",
    lbTips = "/i:493/i:511",

    btnClose = "/i:234/i:92",
    btnHelp = "/i:65",
}

GuildFacilityView.ITEM_FILE = "GuildFacilityItemView.csb"
GuildFacilityView.ITEM_TABLE = {
    panelLv0 = "/i:539",
    Lv0Num1 = "/i:539/i:40",
    Lv0Num2 = "/i:539/i:42",
    Lv0Num3 = "/i:539/i:41",
    Lv0Bar = "/i:539/i:38",

    panelLv1 = "/i:45",
    Lv1Num0 = "/i:45/i:48",
    Lv1Num1 = "/i:45/i:49",
    Lv1Num2 = "/i:45/i:50",
    Lv1Num3 = "/i:45/i:51",   
    Lv1Bar =  "/i:45/i:52",   
    Lv1MaxIcon = "/i:45/i:53",   

    lbSkillDesc = "/i:538/i:43",
    lbTimeCount = "/i:538/i:44",

    effPanel = "/s:effPanel",
    effPanelBall = "/s:effPanel/s:effPanelBall",

    btn5000 = "/s:Panel_21/s:Button_32",
    num5000 = "/s:Panel_21/s:Button_32/s:num1",
    btn20000 = "/s:Panel_21/s:Button_32_0",
    num20000 = "/s:Panel_21/s:Button_32_0/s:num2",
}

GuildFacilityView.ITEM_EFFECT = {
    {
        atlas = "effects/facility/ghjz_t_4/ghjz_t_4.atlas",
        json = "effects/facility/ghjz_t_4/ghjz_t_4.json",
        -- pos_x = 0,
        -- pos_y = 0
    },
    {
        atlas = "effects/facility/ghjz_t_6/ghjz_t_6.atlas",
        json = "effects/facility/ghjz_t_6/ghjz_t_6.json",
        -- pos_x = 50,
        -- pos_y = 100
    },
    {
        atlas = "effects/facility/ghjz_t_5/ghjz_t_5.atlas",
        json = "effects/facility/ghjz_t_5/ghjz_t_5.json",
        -- pos_x = -50,
        -- pos_y = 100
    }
}

function GuildFacilityView:create(rData)

    local login     = GuildFacilityView.new()
    login.rData     = rData
    login.sManager  = login.rData["sManager"]
    login.backFunc  = login.rData["sFunc"]
    login.sDelegate = login.rData["sDelegate"]
    login.refreshTopBar = login.rData["refreshTopBar"]
    --login.uiLayer   = cc.Layer:create()
    login:init()

    return login
end

function GuildFacilityView:init()
    GuildFacilityView.super.init(self)

    self.nExpNum = 0
    self.bIsFirst = 1

    self.conting = false
    local delay = cc.DelayTime:create(0.1)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function()
        self:resetTimeCount()
    end))
    local action = cc.RepeatForever:create(sequence) 
    self:getRootNode():runAction(action)

    self.panelTouch:setVisible(false)
    self.panelTouch:addTouchEventListener(function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
            self:stopEffect()
        end
    end)

    self.buildings = {}
    for i = 1,3 do
        local tempBuilding = XUIView.new():init(nil,GuildFacilityView.ITEM_FILE,GuildFacilityView.ITEM_TABLE)
        local tempTimeline = cc.CSLoader:createTimeline(GuildFacilityView.ITEM_FILE)

        local effinfo = GuildFacilityView.ITEM_EFFECT[i]
        local tempEffectNode = sp.SkeletonAnimation:create(effinfo.json, effinfo.atlas, 1.0)

        self:getRootNode():addChild(tempEffectNode)
        tempEffectNode:setPosition(640, 360)     

        self.buildings[i] = {
            building = tempBuilding,
            timeline = tempTimeline,
            effectNode = tempEffectNode,
        }
        tempBuilding._csNode:runAction(tempTimeline)
        tempTimeline:play("reset",false)

        local panel = self.panelItems:getChildByName("Item"..i)
        panel:addChild(tempBuilding:getRootNode(),0,111)

        --tempBuilding.imgBuildFace:setTexture()
        --tempBuilding.imgLevelUp:setOpacity(0)
        --剪裁  n_UIShare/guild/guild_build/ghjz_ui_004.png

        local clipNode = cc.ClippingNode:create()
        local clipSprite = cc.Sprite:create()
        local clipLayer = cc.Layer:create()
        clipSprite:setTexture("n_UIShare/guild/guild_build/ghjz_ui_004.png")
        clipSprite:setAnchorPoint(cc.p(0,0.5))
        clipSprite:setPosition(tempBuilding.Lv0Bar:getPosition())
        clipNode:setAlphaThreshold(0.5)
        clipNode:setStencil(clipSprite)
        clipNode:addChild(clipLayer)    

        tempBuilding.effPanel:addChild(clipNode)
        tempBuilding.effPanelBar = clipLayer
        clipNode:setLocalZOrder(-1)

        tempBuilding.num5000:setString("")
        tempBuilding.num20000:setString("")
        tempBuilding.btn5000:addClickEventListener(function() 
            self:payMoney(i,1)
        end)
        tempBuilding.btn20000:addClickEventListener(function()     
            self:payMoney(i,2)
        end)
   
    end

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self:getRootNode():stopAllActions()
        self:returnBack()
    end)

    self.btnList:addClickEventListener(function()
        self:loadContributionData()
    end)

    self.btnInfo:addClickEventListener(function()
        self:showLevelInfo()
    end)

    self.btnAdd:addClickEventListener(function()
        local sData = {}
        sData["sDelegate"] = self
        sData["sFunc"] = self.buyCallBack
        sData["shopTypeIndex"] = 1
        SceneManager:toShopLayer(sData)
    end)

    if g_channel_control.show_new_guild_main == true then
        self.btnHelp:setVisible(false)
        self:initChange()
    else
        self.btnHelp:addClickEventListener(function()
            local data = {}
            data.pictures = { --一张或者多张
                "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_019.png",
                "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_020.png",
                "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_021.png",
            }
            local sData = {}
            sData["prefix"] = "gh"
            sData["fontSize"] = 20
            sData["Iamgdata"] = data
            SceneManager:toPublicHelpText(sData)
        end)
    end
    self:refreshIconStates()
    self:refresh()
    
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    return self
end

    -- "buff": {
    --     1: {
    --         "end_time": 14373,   #当前buff剩余秒数,到时间等级减少1,为0表示未开启
    --         "lv":111,      # 当前等级
    --         "skill_id":208, #　技能id
    --         "gold":12312,   # 当前剩余金币数量
    --         "max_gold":80000,  # 升到下一级需要的金币数量,为-1表示无法升级(一般是到达满级)

function GuildFacilityView:refresh()
    if self.guild_buff then
        local times = 0
        for i = 1,3 do
            local data = self.guild_buff[""..i]
            local building = self.buildings[i].building

            local tnum1,tnum2,tnum3,tbar = nil,nil,nil,nil

            local skdesc = UITool.ToLocalization("效果不明")

            if passive_sk[data.skill_id] then
                skdesc = UITool.getUserLanguage(passive_sk[data.skill_id].sk_det_des)
            end

            building.lbSkillDesc:setString(skdesc)

            if data.lv == 0 then
                building.panelLv0:setVisible(true)
                building.panelLv1:setVisible(false)
                self:refreshItemStates(i,0)

                tnum1 = building.Lv0Num1
                tnum2 = building.Lv0Num2
                tnum3 = building.Lv0Num3
                tbar = building.Lv0Bar

            else
                building.panelLv0:setVisible(false)
                building.panelLv1:setVisible(true)
                self:refreshItemStates(i,1)

                building.Lv1Num0:setString(""..data.lv)
                building.Lv1MaxIcon:setVisible(data.max_gold < 0)
                
                tnum1 = building.Lv1Num1
                tnum2 = building.Lv1Num2
                tnum3 = building.Lv1Num3
                tbar = building.Lv1Bar

                times = times + data.end_time
            end

            if data.max_gold <= 0 then
                tnum1:setString("")
                tnum2:setString("")
                tnum3:setString("")
                tbar:setPercent(100)
            else
                tnum1:setString(""..data.max_gold)
                tnum2:setString("/")
                tnum3:setString(""..data.gold)
                local size1 = tnum1:getContentSize()
                local pos_x,pos_y = tnum1:getPositionX(),tnum1:getPositionY()
                local size2 = tnum2:getContentSize()

                pos_x = pos_x - size1.width
                tnum2:setPosition(pos_x,pos_y)
                pos_x = pos_x - size2.width
                tnum3:setPosition(pos_x,pos_y)

                tbar:setPercent(data.gold / data.max_gold * 100)
            end

            if self.contribute_info then
                building.num5000:setString(self.contribute_info[1].cost_num)
                building.num20000:setString(self.contribute_info[2].cost_num)
            end
        end
    else
        for i = 1,3 do
            local building = self.buildings[i].building
            building.panelLv0:setVisible(true)
            building.panelLv1:setVisible(false)
            self:refreshItemStates(i,0)
            
            building.Lv0Num1:setString("")
            building.Lv0Num2:setString("")
            building.Lv0Num3:setString("")

            building.Lv0Bar:setPercent(0)

            building.lbSkillDesc:setString("")
            building.lbTimeCount:setString("--:--:--")

            building.num5000:setString("")
            building.num20000:setString("")
        end
    end
end

function GuildFacilityView:showLevelInfo()
    MsgManager:showGuildInfo(user_info["facility_lv"])
end

-- /*购买星石回调*/
function GuildFacilityView:buyCallBack()
    self.sManager.menuLayer:hiddenUserInfo(true)
    self:refreshIconStates()
end

-- /*提示信息*/
function GuildFacilityView:addLabel(str)
  
    local label = cc.Label:createWithTTF(str, TEXT_FONT_NAME, 40)
    label:setPosition(cc.p(640,360))
    self:getRootNode():addChild(label, 1)
    local function removeThis()
       label:removeFromParent()
    end
    --After 1.5 second, self will be removed.
    local moveBy  = cc.MoveBy:create(1.5,cc.p(0,150))
    local fadeOut = cc.FadeOut:create(1.5)
    local spawn = cc.Spawn:create(moveBy,fadeOut)
    label:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(removeThis)))

end

function GuildFacilityView:payMoney(idx,type_idx)
    if not self.contribute_info then return end

    --"contribute_info":  [{"type":13,"cost_num":500,"give_exp":300},{"type":2,"cost_num":50,"give_exp":300},], # 捐献消耗以及给予信息
    
    local cost_info = self.contribute_info[type_idx]
    local unit_name = ""
    local table = {}
     -- 确定消耗的货币类型
    local cost_n  = 0
    if type_idx == 1 then
        unit_name = "苍玉"
        table["nType"] = 13
        cost_n =  user_info["beryl"]
    elseif type_idx == 2 then
        unit_name = "星石"
        table["nType"] = 2
        cost_n = user_info["gem"]
    end
    table["cost_num"] = cost_info.cost_num
    table["bIsFirst"] = self.bIsFirst
    table["facility_lv"] = user_info["facility_lv"]

    local skillOneVaule = 0
    for i=1,user_info["facility_lv"] do
        local skillIndex = guild_facility[i].buff_type
        if skillIndex == 1 then
            skillOneVaule = guild_facility[i].buff_value
        end
    end
    table["buff_value"] = skillOneVaule
    GameManagerInst:confirm1(table,function()
        -- if cost_info.cost_num > cost_n then
        --      MsgManager:showSimpMsg(unit_name.."不足")
        -- end
        -- 给服务器传一个购买数量，现在接口未完善后续修改
        local num = math.floor(tonumber(MsgManager:getBuyNum()) / tonumber(cost_info.cost_num))
        if num > 0 then
        else
            MsgManager:showSimpMsg(UITool.ToLocalization(unit_name)..UITool.ToLocalization("不足"))
            return
        end
        MsgManager:setBuyNum(0)
        print("num num num == "..num)
        local tempTable = {
            rpc = "guild_contribute",
            cost_type = cost_info["type"],
            buff_type = idx,
            add_num   = num
        }

        GameManagerInst:rpc(tempTable,3,
        function(data)
            --success
            --GameManagerInst:saveToFile("guild_contribute.json",data)

            if data["is_lv_up"] > 0 then
                self:addLabel(UITool.ToLocalization("设施升级，全体成员将收到升级奖励"))
            end

            self:loadData(idx)
        end,
        function(state_code,msgText)
            GameManagerInst:alert(msgText)
        end,
        true)
    end)
    -- -- if self.guild_buff and self.guild_buff[""..idx].lv >= 20 then
    -- --     GameManagerInst:alert("该设施已满级")
    -- -- else
    --     GameManagerInst:confirm("是否捐献"..(cost_info.cost_num)..unit_name.."，获取"..(cost_info.give_exp).."积分？",function()
    --         local tempTable = {
    --             rpc = "guild_contribute",
    --             cost_type = cost_info["type"],
    --             buff_type = idx
    --         }

    --         GameManagerInst:rpc(tempTable,3,
    --         function(data)
    --             --success
    --             --GameManagerInst:saveToFile("guild_contribute.json",data)

    --             self:loadData(idx)
    --         end,
    --         function(state_code,msgText)
    --             GameManagerInst:alert(msgText)
    --         end,
    --         true)
    --     end)
    -- -- end
end

function GuildFacilityView:stopEffect(idx)

    -- if idx then
    --     self.lvEffCount[idx] = 0 

    --     local sum = 0
    --     for i = 1,3 do
    --         sum = sum + self.lvEffCount[i]
    --     end

    --     if sum > 0 then
    --         return
    --     end
    -- end

    -- self.lvEffCount = nil

    for i = 1,3 do
        local b = self.buildings[i]
        b.building.effPanelBall:removeAllChildren()
        b.building.effPanelBar:removeAllChildren()

        b.effectNode:setToSetupPose()
        b.effectNode:clearTracks()
    end

    self.panelTouch:setVisible(false)
    self:refresh()
end

function GuildFacilityView:playEffect(old_data,idx)
    self.panelTouch:setVisible(true)
    --self.lvEffCount = {1,1,1}
    --for i = 1,3 do
        local odata = old_data[""..idx]
        local skid = odata.skill_id
        local gold = odata.gold
        local max_gold = odata.max_gold
        local lv = odata.lv

        local ndata = self.guild_buff[""..idx]
        local new_gold = ndata.gold
        local new_max_gold = ndata.max_gold
        local new_lv = ndata.lv

        self:playLvEff(
            idx,
            skid,
            gold,
            max_gold,
            lv,
            new_gold,
            new_max_gold,
            new_lv
        )
    --end
end

function GuildFacilityView:playLvEff(idx,skill_id, gold ,max_gold,lv,new_gold,new_max_gold,new_lv)

    local build = self.buildings[idx].building
    build.Lv0Bar:setPercent(0)
    build.Lv1Bar:setPercent(0)
    build.Lv0Num1:setString("")
    build.Lv0Num2:setString("")
    build.Lv0Num3:setString("")
    build.Lv1Num1:setString("")
    build.Lv1Num2:setString("")
    build.Lv1Num3:setString("")

    --经验条
    local pos_x,pos_y = build.Lv0Bar:getPosition()
    local psize = build.Lv0Bar:getSize()

    local nodeExpbar = cc.CSLoader:createNode("EffSthExpbar.csb")
    local timelineExpbar =cc.CSLoader:createTimeline("EffSthExpbar.csb")
    nodeExpbar:runAction(timelineExpbar)
    timelineExpbar:play("animation0",true)
    build.effPanelBar:addChild(nodeExpbar)

    --经验球
    local nodeBall = cc.CSLoader:createNode("EffSthBall.csb")
    local timelineBall = cc.CSLoader:createTimeline("EffSthBall.csb")   
    nodeBall:runAction(timelineBall)
    timelineBall:play("animation0",true)  
    build.effPanelBall:addChild(nodeBall)


    --球消失
    local nodeBallFade = cc.CSLoader:createNode("EffSthBallFade.csb")
    local timelineBallFade = cc.CSLoader:createTimeline("EffSthBallFade.csb")
    nodeBallFade:setPosition(cc.p(pos_x + psize.width,pos_y))
    nodeBallFade:runAction(timelineBallFade)
    build.effPanelBall:addChild(nodeBallFade)

    local once_time = 0.5

    local function playExpBarBall(ratio,ratio2,endFunc)
        --经验条
        nodeExpbar:setVisible(true)        
        nodeExpbar:setPosition(cc.p(pos_x + ratio * psize.width,pos_y))
        local moveby = cc.MoveBy:create(ratio2 * once_time,
                                        cc.p( ratio2 * psize.width ,  0)
                                        )
        local seq = cc.Sequence:create(moveby, cc.CallFunc:create(endFunc))
        nodeExpbar:runAction(seq)

        --球
        nodeBall:setVisible(true)
        nodeBall:setPosition(cc.p(pos_x + ratio * psize.width,pos_y))
        local moveby2 = cc.MoveBy:create(ratio2 * once_time,
                                        cc.p( ratio2 * psize.width ,  0)
                                        )
        nodeBall:runAction(moveby2)

    end

    local addlv = new_lv - lv
                             
    if addlv == 0 then
        --没升级，播一次涨条

        if lv >=20 then
            self:stopEffect(idx)
        else
            local tempNextExp = max_gold  --满级经验
            local ratio =  gold / max_gold   --开始百分比
            local ratio2 = (new_gold - gold) / max_gold   --涨多少

            --self:playLVEffect(1)
            playExpBarBall(ratio,ratio2,function()
                self:stopEffect(idx)
                --self:onEffectEnd()
            end)
        end
    else
        -- 1次当前经验到满条
        -- addlv - 1次满条 
        -- 1次最后部分
        local nowlv = lv

        local function runBarFull()
            --self:stopLVEffect()
            nodeBall:setVisible(false)
            nodeExpbar:setVisible(false)
            --满级三个闪光
            nowlv = nowlv + 1
            --build.lv

            build.panelLv0:setVisible(false)
            build.panelLv1:setVisible(true)
            self:refreshItemStates(idx,1)
            
            build.Lv1MaxIcon:setVisible(false)
            build.Lv1Num0:setString(""..nowlv)

            skill_id = skill_id + 1
            local skdesc = "效果不明"
            if passive_sk[skill_id] then
                skdesc = UITool.getUserLanguage(passive_sk[skill_id].sk_det_des)
            end
            build.lbSkillDesc:setString(skdesc)

            if nowlv == new_lv then
                --升级完毕，播最后                
                --timelineExpFull:clearLastFrameCallFunc()
                timelineBallFade:setLastFrameCallFunc(function()
                    --建筑物最高20级
                    if (new_lv >= 20) or (new_max_gold <= 0) then
                        --已满级，不播最后一条
                        self:stopEffect(idx)
                    else
                        --未满级，播最后一条
                        --self:playLVEffect(1)
                        playExpBarBall(0, new_gold / new_max_gold,function()
                            --self:stopLVEffect()
                            self:stopEffect(idx)
                        end)
                    end
                end)
            end
            
            timelineBallFade:play("animation0",false)
            self.buildings[idx].timeline:play("levelup",false)
            self.buildings[idx].effectNode:setToSetupPose()
            self.buildings[idx].effectNode:clearTracks()
            self.buildings[idx].effectNode:setAnimation(1, "effect", false)
            --timelineExpFull:play("animation0",false)
            --timelineLvnum:play("animation0",false)
            --self:playLVEffect(2)

            -- if self.levelUpEffectEvent then
            --     self.levelUpEffectEvent(self)
            -- end
        end

        local function runOnce()
            --走一条经验到满级
            --self:playLVEffect(1)
            playExpBarBall(0,1,function()
                runBarFull()
            end)
            --已满级则停止
            --未满级则继续下一级
        end
        
        timelineBallFade:setLastFrameCallFunc(runOnce)

        local tempNextExp = max_gold  --满级经验
        local ratio =  gold / max_gold   --开始百分比
        --self:playLVEffect(1)
        playExpBarBall(ratio,(1-ratio),runBarFull)
    end

end

function GuildFacilityView:resetTimeCount()
    -- if not self.conting then 
    --     for i = 1,3 do
    --         self.buildings[i].building.lbTimeCount:setString("--:--:--")
    --     end
    --     return 
    -- end

    if not self.guild_buff then return end

    for i = 1,3 do
        local data = self.guild_buff[""..i]
        local build = self.buildings[i].building
        local currentTime = UserDataMgr:getInstance().timeData:getCurrentTime()
        local ostime =currentTime - self.conting_time

        local temptime = data.end_time - ostime

        if data.lv > 0 then
            if temptime < 0 then
                if self.conting then
                    self:loadData()
                else
                    build.lbTimeCount:setString("--:--:--")
                end
            else
                local h = math.floor(temptime / 3600)
                if h < 0 then
                    h = 0
                end
                local m = math.floor((temptime%3600) / 60 )
                if m < 0 then
                    m = 0
                end
                local s = math.floor((temptime%3600)%60)--() 
                if s < 0 then
                    s = 0
                end
                build.lbTimeCount:setString(string.format("%02d:%02d:%02d",h,m,s))
            end            
        else
            build.lbTimeCount:setString("--:--:--")
        end
        
    end
end

function GuildFacilityView:refreshItemStates(nIndex,nLv)
    local panel = self.panelItems:getChildByName("Item"..nIndex)
    local spLvBg = panel:getChildByName("spLvBg")
    if nIndex == 1 then
        if nLv ~= 0 then
            spLvBg:setTexture("n_UIShare/guild/newGuild/ghjz_ui_001.png")
        else
            spLvBg:setTexture("n_UIShare/guild/newGuild/ghjz_ui_001b.png")
        end
    elseif nIndex == 2 then
        if nLv ~= 0 then
            spLvBg:setTexture("n_UIShare/guild/newGuild/ghjz_ui_002.png")
        else
            spLvBg:setTexture("n_UIShare/guild/newGuild/ghjz_ui_002b.png")
        end
    elseif nIndex == 3 then
        if nLv ~= 0 then
            spLvBg:setTexture("n_UIShare/guild/newGuild/ghjz_ui_003.png")
        else
            spLvBg:setTexture("n_UIShare/guild/newGuild/ghjz_ui_003b.png")
        end
    else
    end
end

function GuildFacilityView:refreshIconStates()
    local nXingshiNum = user_info["gem"]
    local nCangyuNum = user_info["beryl"]
    if self.lbXingshiNum then
        self.lbXingshiNum:setString(nXingshiNum)
    end
    if self.lbCangyuNum then
        self.lbCangyuNum:setString(nCangyuNum)
    end
end

function GuildFacilityView:refreshLevelInfo(nLv,nExp)
    if self.lbLevel then
        self.lbLevel:setString(nLv)
    end

    if self.lbTips then
        if guild_facility[nLv].des then
            self.lbTips:setString(UITool.getUserLanguage(guild_facility[nLv].des))
        end
    end

    if guild_facility[nLv].lv_up_exp then
        if self.lbExp then
            self.lbExp:setString(nExp.."/"..guild_facility[nLv].lv_up_exp)
        end
        local percent = math.ceil(nExp / guild_facility[nLv].lv_up_exp * 100)
        if self.barLevel then
            self.barLevel:setPercent(percent)
        end
    end
end

function GuildFacilityView:loadContributionData()

    GameManagerInst:rpc("{\"rpc\":\"guild_contr_ranking\"}",3,
    function(data)
        --success
        --GameManagerInst:saveToFile("guild_contr_ranking.json",data)
        
        GameManagerInst:showModalView(GuildContributionView.new():initWithData(data.members))
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText)
    end,
    true)
end

function GuildFacilityView:loadData(idx)
    self.conting = false

    GameManagerInst:rpc("{\"rpc\":\"guild_buff_show\"}",3,
    function(data)
        --success
        --GameManagerInst:saveToFile("guild_buff_show.json",data)

        local old_data = self.guild_buff

        self.contribute_info = table.deepcopy(data["contribute_info"])
        self.guild_buff = table.deepcopy(data["buff"])
        --self.guild_gold = data["gold"]
        user_info["gem"] = data["gem"]
        user_info["gem_r"] = data["gem_r"]
        user_info["beryl"] = data["beryl"]
        user_info["gold"] = data["gold"]
        GuildSingleton:getInstance():setMedal_num(data["medal_num"] or 0)

        -- if data["facility_lv"] and user_info["facility_lv"] then
        --     if data["facility_lv"] > user_info["facility_lv"] then
        --         self:addLabel(UITool.ToLocalization("设施升级，全体成员将收到升级奖励"))
        --     end
        -- end

        user_info["facility_lv"] = data["facility_lv"]
        self.nExpNum = data["facility_exp"]
        self.bIsFirst = data["is_first_cb"]


        if GameManagerInst.gameType == 2 then
            SceneManager.menuLayer:RefshTopBar()
        end
        if self.refreshTopBar then
            self.refreshTopBar()
        end

        self.conting_time = UserDataMgr:getInstance().timeData:getCurrentTime()--os.time()
        self.conting = true

        if old_data and idx then
            --判断是否升级，播放动画
            self:playEffect(old_data,idx)
        else
            self:refresh()
        end

        self:refreshIconStates()
        self:refreshLevelInfo(user_info["facility_lv"],self.nExpNum)
    end,
    function(state_code,msgText)
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function GuildFacilityView:onNavigateTo(isback)
    --GameManagerInst:setTitleUIType("角色",2)
    self:loadData()
end

function GuildFacilityView:returnBack()
    if self.backFunc then
        self.sData = {}
        self.backFunc(self.sDelegate,self.sData)
    end
    if self._navigationView then
        self._navigationView:popView()
    else
        self:removeFromParentView()
    end
end

function GuildFacilityView:initChange()
    self.cangyu_bg:setVisible(false)
    self.lbCangyuNum:setVisible(false)
    self.xingshi_bg:setVisible(false)
    self.lbXingshiNum:setVisible(false)
    self.btnAdd:setVisible(false)
    self.btnList:setVisible(false)
    local bg = self.panelBG:getChildByName("Sprite_10")
    bg:initWithFile("uifile/n_UIShare/guild/Guild_add/xgh_bg_001.png")
    bg:setAnchorPoint(cc.p(0,0))
end