
EmoticonLayoutLayer= class("EmoticonLayoutLayer",function ()
    return ccui.Layout:create()
end)

function EmoticonLayoutLayer:initialize(data)
    self:initData(data)
    self:initView()
end

function EmoticonLayoutLayer:initData( data )
    self.page = data
end

function EmoticonLayoutLayer:initView( ... )
    -- body
    self:setContentSize(cc.size(650,232))
    self:setAnchorPoint(cc.p(0,0))

    --self:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    --self:setBackGroundColor(cc.c3b(230, 255, 180))

    local data = self.page
    local count = #data or 0
    local rowOfcount = EmotSys.rowOfCount
    local row = math.ceil(count/rowOfcount)
    for i=1,row do
        for j=1,rowOfcount do
            local idx = (i - 1) * rowOfcount + j
            local item_data = data[idx]
            local emotItem = EmoticonItem:create(item_data)
            local itemX = j * emotItem:getContentSize().width * 3/2 - emotItem:getContentSize().width - 26
            local itemY = 232 - i * (emotItem:getContentSize().height + 12) + 10
            emotItem:setPosition(cc.p(itemX,itemY))
            self:addChild(emotItem)
        end
    end
end


function EmoticonLayoutLayer:clearEx()
    self:clear()
end

function EmoticonLayoutLayer:create(data)
    local emotPageLayer = EmoticonLayoutLayer.new()
     emotPageLayer:initialize(data)
    return emotPageLayer
end
