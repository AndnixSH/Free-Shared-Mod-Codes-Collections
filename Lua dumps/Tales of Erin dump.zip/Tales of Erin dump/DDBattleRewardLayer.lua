--[[
	DDBattleRewardLayer.lua
	公会道馆 层奖励 和积分排名奖励
	1、层奖励 2、积分奖励
]]
require "BasicLayer"

DDBattleRewardLayer = class("DDBattleRewardLayer",BasicLayer)
DDBattleRewardLayer.__index = DDBattleRewardLayer
DDBattleRewardLayer.lClass = 3

local LIST_ITEM_H = 110 --item高度

function DDBattleRewardLayer:init()
    local data = self.rData.rcvData.data
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]

    self.rewards = data.drop or {}--奖励列表

    self:sortRewards()--奖励排序
    local node = cc.CSLoader:createNode("DDBattleRewardLayer.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
	self._rootCSbNode = node:getChildByTag(101)

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end

    local backBtn  =  ccui.Helper:seekWidgetByName(self._rootCSbNode,"btn")
    backBtn:addTouchEventListener(touchCallBack)
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    
    self:initListView()


    self:refreshListView()
end

--排序奖励  todo 新的在前面等等
function DDBattleRewardLayer:sortRewards()
    --info 由于 不同类型之间的 品质取不同字段，所以要提前将品质取出来
     for i=1,#self.rewards do
        local reward = self.rewards[i]
        local quality = UITool.getItemQuality(reward.type,reward.id)
        local type_Q =  UITool.getItemTypeQuality(reward.type)
        self.rewards[i].com_quality = quality
        self.rewards[i].type_Q = type_Q
     end
     local function qualitySort(a,b)
        if a.type_Q == b.type_Q then 
            return a.com_quality > b.com_quality
        else
            return a.type_Q > b.type_Q
        end
     end
     table.sort(self.rewards, qualitySort)
end

function DDBattleRewardLayer:initListView()

    self.listView =  ccui.Helper:seekWidgetByName(self._rootCSbNode,"list_view")

    self.listView:removeAllItems()
    self.listView:setScrollBarEnabled(true)
    self.listView:setScrollBarWidth(20)
    self.listView:setScrollBarColor(cc.c3b(255, 255, 255))
    self.listView:setScrollBarOpacity(225*0.5)
    self.listView:setScrollBarPositionFromCorner(cc.p(0,0))
 
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
        end
    end

    local  item = cc.CSLoader:createNode("DDBattleRewardItem.csb")
    local  item_1 = item:getChildByTag(102)
    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    
    local itemScale = 0.8 --UI 工程的缩放大小

    self._itemWidth = item_1:getContentSize().width*itemScale
    self._itemHeight = item_1:getContentSize().height*itemScale

    if self._itemWidth > 0 then 
    	self._columns = tonumber(math.floor(self.listView:getContentSize().width/self._itemWidth))
    else 
    	self._columns = 1
    end 
    if self._columns < 1 then
        self._columns = 1
    end
    self._intervalW = 15

    dump(tonumber(self._columns))

    for i=1,tonumber(self._columns) do
        local item = item_1:clone()
        item:setPosition((i-1)*(self._itemWidth+self._intervalW),0) --152为框的大小。缩放80%
        item:setName("item"..i)
        layout_list:addChild(item)
    end

    layout_list:setContentSize(self.listView:getContentSize().width,self._itemHeight)

    layout_list:setHighlighted(false)
    layout_list:setTouchEnabled(true)
    self.listView:setItemModel(layout_list)
    self.listView:removeAllItems()
    self.listView:addEventListener(listViewEvent)
end
--返回
function DDBattleRewardLayer:returnBack()
	self.backFunc(self.sDelegate)
    self.exist = false
    self:clearEx()
end

function DDBattleRewardLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function DDBattleRewardLayer:refreshListView()
    self.listView:removeAllItems()
    local totalNum = #self.rewards --总数

    local row = math.ceil(totalNum / self._columns)  -- 行数

    self.listView:setInnerContainerSize(cc.size(self.listView:getContentSize().width,LIST_ITEM_H* self._itemHeight))

    for i = 1,row do 
        self.listView:pushBackDefaultItem()
        local item = self.listView:getItem(i - 1)
        for m = 1, self._columns do          
            local itme_info = item:getChildByName("item"..m)
            local num = (i-1)* self._columns + m

            if num > totalNum then
                itme_info:setVisible(false)
            else
                local reward = self.rewards[num]
                local tabs = UITool.getItemInfos(reward.type,reward.id)

                local bg = itme_info:getChildByTag(1)
                local icon = itme_info:getChildByTag(2)
                local kuang = itme_info:getChildByTag(3)
                local element = itme_info:getChildByTag(4)

                kuang:loadTexture(tabs[1])
                icon:setUnifySizeEnabled(true)
                icon:loadTexture(tabs[2])
                if tabs[3] == "" then 
                    element:setVisible(false)
                else
                    element:loadTexture(tabs[3])
                end
                if tabs[4]~= "" then 
                    bg:loadTexture(tabs[4])
                else

                end 
                --显示道具详情
                local function CallBackEvent( sender,eventType )
                    if eventType == ccui.TouchEventType.ended then
                       --此处为正确调用
                      MsgManager:showSimpItemInfo(reward.type,reward.id)
                    end
                end 
                icon:addTouchEventListener(CallBackEvent)
                local numLab = itme_info:getChildByTag(5)
                numLab:setString("x"..reward.num)
                numLab:setVisible(true)
                local newImg = itme_info:getChildByTag(6)
                if reward.new ~= nil then 
                	--newImg:loadTexture("uifile/n_UIShare/gacha/ck_ui_005.png")
                	--newImg:setUnifySizeEnabled(true)
                    newImg:setVisible(true)
                else
                    newImg:setVisible(false)
                end 
            end
        end
    end
    self.listView:jumpToTop()
end

function DDBattleRewardLayer:create(rData)
     local layer = DDBattleRewardLayer.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end