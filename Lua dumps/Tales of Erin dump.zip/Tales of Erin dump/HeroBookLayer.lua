--[[
	HeroBookLayer.lua
--]]

HeroBookLayer = class("HeroBookLayer",XUIView)
HeroBookLayer.CS_FILE_NAME = "HeroBookLayer.csb"
HeroBookLayer.CS_BIND_TABLE = 
{
    vpanel="/i:101/s:subView",
    panelSort = "/i:101/s:panelSort",
    _panelList = "/i:101/s:listPanel",
    cntGot = "/i:101/s:got_bg/s:cntGot",
}

function HeroBookLayer.createWithBackBtn(nSelectTitleNum)
    local v = HeroBookLayer.new():init()
    local b = BackgroundView.new():initWithBackBtn(v)
    return b,v
end

function HeroBookLayer:clear()
    self.views = nil
    self._cntGotNum = 0
    self._maxOpenNum = 0
    self._baseListData = nil 
    self._selectShowData = nil
end

function HeroBookLayer:init()
    HeroBookLayer.super.init(self)
    self._baseListData = nil 

    self.views = XUIView.new():init(self.vpanel)

    self:initListView()
    self:initSortUI()
    return self
end

function HeroBookLayer:initListView()
    local psize = self._panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self._panelList, psize.width, psize.height,172,210)
    self.gridview.itemCreateEvent = function()
        local temp = XUICellView.new():init(nil,"HeroBookItem.csb",{
            imgBG = "/i:29/i:30/s:imgBG",
            imgFace = "/i:29/i:30/s:imgFace",
            imgRarity = "/i:29/i:30/s:imgRarity",
            imgElement = "/i:29/i:30/s:imgElement",
            imgLikey = "/i:29/i:30/s:imgLikey",
            shadowCover = "/i:29/i:298",
            nameColor = "/i:29/i:42/i:50",
            nameGray = "/i:29/i:42/i:87",
            nameGrayBg = "/i:29/i:42/i:48",
        })

        temp.onResetData = function(self)
            local nname = nil
            local face = nil

            local h_id_num = self._data.h_num_id
            face = hero[h_id_num].hero_list_icon  
            nname = UITool.getUserLanguage(hero[h_id_num].hero_name)
            local natb = hero[h_id_num].hero_atb
            local nrank = hero[h_id_num].hero_rank
            
            local frame = Rarity_Icon[nrank]  --外框
            self.imgLikey:setVisible(false)

            if self._data.got then
                --好感度
                if g_channel_control.b_LikeState then
                    frame = Rarity_Icon_New[nrank]
                    local intimacyState = self._data["like_feel_state"]["icon_state"]
                    local intimacy = like_state[intimacyState].icon_min --亲密度
                    if intimacy then
                        self.imgLikey:setVisible(true)
                        self.imgLikey:setTexture(intimacy)
                    end
                end
            end 
           
            --Rarity_BG  --背景
            if frame then
                self.imgRarity:setTexture(frame)
            end

            local rbg = Rarity_E_BG[nrank]   --背景
            if rbg then
                self.imgBG:setTexture(rbg)
            end

            local element = ATB_Icon[natb] --属性球

            if element then
                self.imgElement:setTexture(element)
            end

            if face then
                self.imgFace:setTexture(face)
                if self._data.got then
                    self.imgFace:setColor(cc.c3b(255,255,255))
                else
                    self.imgFace:setColor(cc.c3b(0,0,0))
                end
            end

            if g_channel_control.transform_GalleryItemView_name == true then 
                self.nameColor:setPosition(cc.p(86,55))
                self.nameColor:setAnchorPoint(cc.p(0.5,1))
                self.nameColor:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                self.nameColor:ignoreContentAdaptWithSize(false);
                self.nameColor:setTextAreaSize(cc.size(130,50))

                self.nameGray:setPosition(cc.p(86,55))
                self.nameGray:setAnchorPoint(cc.p(0.5,1))
                self.nameGray:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
                self.nameGray:ignoreContentAdaptWithSize(false);
                self.nameGray:setTextAreaSize(cc.size(130,50))

                self.nameGrayBg:setVisible(false)
            end

            self.nameColor:setString(nname)
            self.nameGray:setString(nname)

            self.nameColor:setVisible(self._data.got)

            --self.shadowCover:setVisible( not self._data.got )           
            self.shadowCover:setVisible(false) 
            self.nameColor:setVisible(self._data.got) 
            self.nameGray:setVisible( not self._data.got )
        end

        return temp
    end
    self.gridview.itemClickedEvent = function (sender,index)
        local data = sender:getDataSource()[index]
        self:showRoleGallery(index)
    end
end

function HeroBookLayer:showRoleGallery(index)
    local tempds = {}
    local tab_pieceid = {}
    tab_pieceid["allPieceId"] = {}
    for i = 1,#self._selectShowData do
        local j = self._selectShowData[i]
        local _piece_id = j.need_piece_id or -1
        tab_pieceid["allPieceId"][i] = _piece_id
        if j.got then
            tempds[i] = ""..j.h_num_id.."*"..1 
        else
            tempds[i] = ""..j.h_num_id.."*"..0
        end
    end

    local roleinfo = self._selectShowData[index]
    tab_pieceid["piece_id"] = roleinfo.need_piece_id
    if GameManagerInst.gameType == 2 then
        if roleinfo.got then
            SceneManager:toRoleInfo({ hid = ""..roleinfo.h_num_id.."*"..1 ,hlist = tempds,teamidx = nil,tab_piece_id = tab_pieceid})
        else
            SceneManager:toRoleInfo({ hid = ""..roleinfo.h_num_id.."*"..0 ,hlist = tempds,teamidx = nil,tab_piece_id = tab_pieceid})
        end
    end
end

function HeroBookLayer:onItemClicked(item)    
    if self.ItemClickedEvent then
        self.ItemClickedEvent(item)
    end
end

function HeroBookLayer:onItemReset(item)    
    if self.ItemResetEvent then
        self.ItemResetEvent(item)
    end
end

function HeroBookLayer:refresh()
    if not self._baseListData then 
        self:reqBaseData()
    end 
end

function HeroBookLayer:refreshUI()
    self:refreshGotUI()
    self:refreshList()
end

--收集度
function HeroBookLayer:refreshGotUI()
    local value = self._cntGotNum.."/"..self._maxOpenNum
    local strFormat = UITool.ToLocalization("收集度: %s")
    local str = string.format(strFormat,value)
    self.cntGot:setString(str)
end

function HeroBookLayer:refreshList()
    if not self._selectShowData then
        self.gridview:setDataSource(nil)
    else
        self.gridview:setDataSource(self._selectShowData)
    end
end

function HeroBookLayer:initBaseData(hero_ids)
    self._cntGotNum = 0 -- 已拥有（收集）
    local temp = {} --字典
    for k,v in pairs(hero_open) do
        local hf = hero[k]
        if hf then
            temp[k] = {
                h_num_id = k,  
                hero_add = 0,
                got = false,
                need_piece_id = v.need_piece_id
            }
            --添加排序所需数据
            temp[k][SortFunDataKey.ID] = v[SortFunDataKey.ID]
            temp[k][SortFunDataKey.ELEMENT] = hf.hero_atb
            temp[k][SortFunDataKey.RARITY]  = hf.hero_rank
        end
    end

    for k,v in pairs(hero_ids) do
        local tempobj = temp[v.id]
        if tempobj then
            temp[v.id].got = true
            temp[v.id].hero_add = v.hero_add
            temp[v.id].like_feel_state = v.like_feel_state
            --temp[v.id].need_piece_id = v.need_piece_id
            self._cntGotNum = self._cntGotNum+1
        end
    end

    local ds = {}

    for k,v in pairs(temp) do
        table.insert(ds,v)
    end

    self._baseListData = table.deepcopy(ds)
    self._maxOpenNum = #self._baseListData
    self:siftAndSortData()
    self:refreshUI()
end

--请求数据
function HeroBookLayer:reqBaseData()
    GameManagerInst:rpc("{\"rpc\":\"gallery_hero_info\"}",3,
    function(data)
        --success
        local ho = data.hero_open
        hero_open = {}
        for i=1,#ho do
            local v = table.deepcopy(ho[i])
            v[SortFunDataKey.ID] = i --默认添加一个序号id
            hero_open[v.hero_id] = v
        end
        --说明：NewRoleSthView 的336行未 处理 mat表为nil逻辑，为不影响其他逻辑，此处默认处理一波
        local tempmat = {}
        DataManager:wAllBagData({mat = tempmat})

        self:initBaseData(data.hero)
    end,

    function(state_code,msgText)
        GameManagerInst:alert(msgText,function()
            SceneManager:toStartLayer()
        end)
    end,
    true)
end

-----------------------------------------排序相关 start----------------------------------
function HeroBookLayer:initSortUI()
    use_herobook_sort_data = use_herobook_sort_data or herobook_sort_data
    self._sortComponent = CommonSortComponent.new():init(self, use_herobook_sort_data) 
    self._sortComponent:addSortButtonUI(self.panelSort)
end
---登出游戏后重置筛选为默认排序
function HeroBookLayer:cachSortData()
    use_herobook_sort_data = table.deepcopy(self._sortComponent._data) ---一定不要提别人保存
end

--生降序   发生变化
function HeroBookLayer:sortStateChangeFunc()
    self:sortData()
    self:refreshList()
end

--筛选及排序 发生变化
function HeroBookLayer:sortTypeChangeFunc()
    self:siftAndSortData()
    self:refreshList()
end

----此处可以本地排序、也可以服务器排序
function HeroBookLayer:sortData()
    local data = self._selectShowData
    local sortState = self._sortComponent:getSortState()
    local sort_typeValue = self._sortComponent:getSortTypeValue()
    ComSortData(data, sortState,sort_typeValue)
    self:cachSortData()
end

--先筛选、然后排序
function HeroBookLayer:siftAndSortData() 
    local selects = self._sortComponent:getSelectData()
    local tempData = SiftHeroBook(self._baseListData, selects)
    self._selectShowData = table.deepcopy(tempData)
    self:sortData()
end

-----------------------------------------排序相关 end----------------------------------

