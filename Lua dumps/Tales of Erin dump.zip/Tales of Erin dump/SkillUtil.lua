--技能功能函数集合
--created by kobejaw.2018.4.23.
SkillUtil = {}

function SkillUtil:createSkillInfo(skillId,isBigSkill,isPrincess)
	local skillInfo = {}
	skillInfo.skillId = skillId      --skill表中的id
	skillInfo.skillData = skill[skillId] --skill表中的数据
    if skillInfo.skillData ~= nil then
        skillInfo.skillType = skillInfo.skillData.skill_type
	    skillInfo.skill_sound = skillInfo.skillData.skill_sound[1]
	    skillInfo.skill_voice = skillInfo.skillData.skill_voice

        skillInfo.target_type = skillInfo.skillData.skill_target.target_type
        skillInfo.target_num = skillInfo.skillData.skill_target.target_num
        skillInfo.target_property = skillInfo.skillData.skill_target.target_property
        skillInfo.sort_type = skillInfo.skillData.skill_target.sort_type
        skillInfo.target_p_type = skillInfo.skillData.skill_target.target_p_type
        skillInfo.res_fly = skillInfo.skillData.skill_play_hit[1].res_fly
        skillInfo.res_scene = skillInfo.skillData.skill_play_hit[1].res_scene
        skillInfo.res_hit = skillInfo.skillData.skill_attack_hit[1].res_hit
        skillInfo.skillActionName = skillInfo.skillData.skill_ac_name
	    skillInfo.skill_cd = skillInfo.skillData.skill_cd
	    skillInfo.start_cd = skillInfo.skillData.start_cd

	    skillInfo.isBigSkill = isBigSkill
        skillInfo.isPrincess = isPrincess

	  	if skillInfo.skillType == 1 then
			skillInfo.skillStateEnum = StateEnum.PlayingSkill_Self  --自身类
		elseif skillInfo.skillType == 2 then
			skillInfo.skillStateEnum = StateEnum.PlayingSkill_Scene --场景类		
		elseif skillInfo.skillType == 3 then
			skillInfo.skillStateEnum = StateEnum.PlayingSkill_StraightLine --贯穿类
		else
			if skillInfo.target_p_type == 3 then
				skillInfo.skillStateEnum = StateEnum.PlayingSkill_Target_Entity  --目标选择类，固定entity
			else 
				skillInfo.skillStateEnum = StateEnum.PlayingSkill_Target_Pos     --目标选择类，固定位置
			end
		end

		--对策划配表或者美术资源的纠错处理，如果有autoplay事件，而且skill_play_hit中没有配置场景和飞行特效，则把autoplay替换成attack1，哥不吐槽。
		--这里保存一下skill_play_hit里是否配了特效。
		if skillInfo.res_fly ~= "" or skillInfo.res_scene ~= "" then
			skillInfo.haveAutoplayEffect = true
		else
			skillInfo.haveAutoplayEffect = false
		end
    end
	return skillInfo
end

function SkillUtil:playCutIn(entity)
	entity:setLocalZOrder(10000)
	G_EntityPlayingCutin = entity

	PauseNodesWithAction()
	PauseNodesWithSpine()

	BattlePlaySound(BattleGlobals.Sound_CutIn,false,0) 

	local skillInfo = entity.fsm.currentState.skillInfo

	for k,v in pairs(G_Roles) do
		v:pause()
		v.spineNode:setTimeScale(0.00000001)

		if v ~= entity then
			v.spineNode:setColor(cc.c3b(80,80,80))
		end
	end

	for k,v in pairs(G_Monsters) do
		v:pause()
		v.spineNode:setTimeScale(0.00000001)
	end

	local res1
	if entity.entityType == 1 then
		if skillInfo.skillData.res_cut ~= "" then
			res1 = skillInfo.skillData.res_cut
		else
			res1 = hero[entity.data.heroId].hero_cutin
		end
	else --boss
		if skillInfo.skillData.res_cut ~= "" then
			res1 = skillInfo.skillData.res_cut
		else
			res1 = entity.cutinres
		end		
	end

	local spineNode1_aniName;
	if entity.entityType == 1 then
		spineNode1_aniName = "effect2"
	else
		spineNode1_aniName = "effect"
	end

	local spineNode1 = CreateEffectSpineNode(res1,false,spineNode1_aniName)
	if spineNode1 then
		if self:checkNeedAddToBattleUILayer(skillInfo.skillId) then
			G_BattleUILayer:addChild(spineNode1)
		else
			G_EntityLayer:addChild(spineNode1,-10000)
		end
		spineNode1:setPosition(cc.p(640,360))

	    local function spineNode1completeCallback(event)
	        --删除自己，如果在事件里删除自己，必须下一帧执行。
	        local function removeSelf()
	            spineNode1:removeFromParent();
	        end
	        PerformWithDelayTime(removeSelf,0.01)
	    end
	    spineNode1:registerSpineEventHandler(spineNode1completeCallback,sp.EventType.ANIMATION_COMPLETE)
	end


	local res2
	if entity.attr[AE.element] == 1 then
		res2 = BattleGlobals.CutInEffect_water
	elseif entity.attr[AE.element] == 2 then
		res2 = BattleGlobals.CutInEffect_fire
	elseif entity.attr[AE.element] == 3 then
		res2 = BattleGlobals.CutInEffect_wind
	elseif entity.attr[AE.element] == 4 then
		res2 = BattleGlobals.CutInEffect_light
	else
		res2 = BattleGlobals.CutInEffect_dard
	end
	local spineNode2 = CreateEffectSpineNode(res2)
	if spineNode2 ~= nil then
		G_BattleUILayer:addChild(spineNode2,-10000)
		spineNode2:setPosition(cc.p(640,360))
	    local function spineNode1completeCallback(event)
	        --删除自己，如果在事件里删除自己，必须下一帧执行。
	        local function removeSelf()
	            spineNode1:removeFromParent();
	            entity:resume()
	            entity.spineNode:setTimeScale(1)
	        end
	        PerformWithDelayTime(removeSelf,0.01)
	    end
	    spineNode1:registerSpineEventHandler(spineNode1completeCallback,sp.EventType.ANIMATION_COMPLETE)
	end


	--闪烁动画
	local shanNode = cc.CSLoader:createNode("uifile/Shan.csb")
	entity:addChild(shanNode)
    local action = cc.CSLoader:createTimeline("uifile/Shan.csb")
    shanNode:runAction(action)
    action:play("shan",false);
    local function removeShanNode()
    	shanNode:removeFromParent();
    end
    if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
    	PerformWithDelayTime(removeShanNode,0.5)
    else
    	action:setLastFrameCallFunc(removeShanNode)
    end	

    --背景
    for k,v in pairs(G_BattleBGLayer:getChildren()) do
    	v:setCascadeColorEnabled(true)
    	local tintTo = cc.TintTo:create(0.1,cc.c3b(80,80,80))
    	v:stopAllActions()
    	v:runAction(tintTo)
    end
end

function SkillUtil:playEndCutIn(entity)
	G_GameState = 1

	G_EntityLayer:resetZOrder()
	ResumeNodesWithAction()
	ResumeNodesWithSpine()

	G_BattleContainerLayer:zoomOut_BigSkill()

	--lua版新需求：角色在cutEnd时给自己加一个3秒内减伤80%的buff，取代原来的整个大招过程中无敌。
	--[[2019.1.4新需求。不添加这个buff了，在整个大招过程中，被攻击时减80%伤害。在BattleDamageCompute.lua里添加。
	if entity.entityType == 1 then
		local option = {}
		local reduceDamageBuff = {debuff_id =81100,debuff_hit = 100,lv = 1,target_type = 1,effect_type = 1}
		ComponentCreator:createComponent(reduceDamageBuff,G_EntityPlayingCutin,option)
	end]]

	--如果是boss战，且boss正处于等待释放技能的阶段
	if entity.entityType == 1 and BattleDataManager.isBoss then
		if G_Monsters[1].fsm.currentState.stateEnum == Attacking_Boss and G_Monsters[1].fsm.currentState.isWaiting then
			G_Monsters[1].fsm.currentState:playSkill()
		end
	end
    
	for k,v in pairs(G_Roles) do
		if v ~= entity then
			v:resume()
			v.spineNode:setTimeScale(1)
			v.spineNode:setColor(cc.c3b(255,255,255))	
		end	
	end

	for k,v in pairs(G_Monsters) do
		v:resume()
		v.spineNode:setTimeScale(1)
	end

    --背景
    for k,v in pairs(G_BattleBGLayer:getChildren()) do
    	v:setCascadeColorEnabled(true)
    	local tintTo = cc.TintTo:create(1,cc.c3b(255,255,255))
    	v:runAction(tintTo)
    end

    G_EntityPlayingCutin = nil

end

--获取某个主动技能对应的所有buff和debuff的spine特效列表
function SkillUtil:getComSpinePathList_activeSkill(skillId)
	local result = {}
	local temp = {}
	local skilldata = skill[skillId]
	for k,v in pairs(skilldata.skill_attack_hit) do
		for k1,v1 in pairs(v.add_buff) do
			for k2,v2 in pairs(v1.skill_trig_effect) do
				local id = v2.debuff_id
				if id < 83000 then
					local stateData = state[id][v2.lv]
					if stateData and stateData.state_spine ~= "" and temp[stateData.state_spine] == nil then
						temp[stateData.state_spine] = 1
						table.insert(result,stateData.state_spine)
					end
				end
			end
		end
	end
	return result
end

--获取某个被动技能对应的所有buff和debuff的spine特效列表
function SkillUtil:getComSpinePathList_passiveSkill(skillId)
	local result = {}
	local temp = {}
	local skillData = passive_sk[skillId]
	if skillData.trig_cdn.trig_time == 0 then
		return result
	end

	for k,v in pairs(skillData.trig_cdn) do
		for k1,v1 in pairs(v.skill_trig_effect) do
			local id = v1.debuff_id
			if id < 83000 then
				local stateData = state[id][v1.lv]
				if stateData and stateData.state_spine ~= "" and temp[stateData.state_spine] == nil then
					temp[stateData.state_spine] = 1
					table.insert(result,stateData.state_spine)
				end		
			end
		end
	end
	return result
end

-- 个别技能cutin资源添加到entityLayer而不是battleUILayer，表现会更好。添加这个检测是因为某些应该出现在autoplay的场景特效被美术配到了cutin资源里。
function SkillUtil:checkNeedAddToBattleUILayer(skillId)
	if skillId>=4402301 and skillId<=4402310 then
		return false
	end
	return true
end

