--require "XUIView"

GachaView = class("GachaView" , XUIView)
GachaView.CS_FILE_NAME = "GachaView.csb"
GachaView.CS_BIND_TABLE = 
{
    panelClose = "/i:21",
    btnClose = "/i:21/i:92",
    imgPrev = "/i:36/s:imgPrev",
    panelVideo = "/i:36/i:54",
    panelList = "/i:36/i:37",
    img_      = "/i:36/i:44",
    numExtra = "/i:8/i:65",
    imgCangyu = "/i:8/i:64",
    btnR1 = "/i:8/i:11",
    btnR2 = "/i:8/i:12",
    btnR3 = "/i:8/i:167",
    btnR4 = "/i:8/i:2731",
    btnB1 = "/i:68/i:7",
    btnB1Num1 = "/i:68/i:7/i:14",
    btnB2 = "/i:68/i:9",
    btnB2Text = "/i:68/i:9/i:15",
    btnB2Num1 = "/i:68/i:9/i:16",
    btnB2Num2 = "/i:68/i:9/i:17",
    btnB3 = "/i:68/i:10",
    btnB3Text = "/i:68/i:10/i:18",
    btnB3Num1 = "/i:68/i:10/i:19",
    btnB3Num2 = "/i:68/i:10/i:20",
    btnB4 = "/i:68/i:203",
    btnB4Text = "/i:68/i:203/i:204",
    btnHelp = "/s:btnHelp",
    lbLimit1 = "/i:68/s:limit1",
    lbLimit10 = "/i:68/s:limit10",
    topBarViewPanel = "/i:2665",
}
function GachaView:createButton( ... )
    self.btnTester = ccui.Button:create("n_UIShare/Global_UI/btn/nzxx_b_001_1.png", "n_UIShare/Global_UI/btn/nzxx_b_001_2.png")
    self.btnTester:setTitleText("")
    self.btnTester:setPosition(cc.p(996,56))
    local label = ccui.Text:create()
    label:setFontSize(22)
    label:setString(UITool.ToLocalization("详细概率"))
    label:setFontName(TEXT_FONT_NAME)
    label:enableOutline(cc.c4b(0,0,0,255),1)
    label:setPosition(cc.p(65,23))
    --label:setAnchorPoint(cc.p(0,0.5))
    self.btnTester:addClickEventListener(function (sender,eventType)
            
        print("点击抽卡详细按钮")
        local table = {}
        table["draw_id"] = self.currentGachaID
        SceneManager:showGachaBox(table)

     end)
    label:setTextColor(cc.c3b(255,255,255))
    self.btnTester:addChild(label)
    self.img_:addChild(self.btnTester)
    
    
    -- btnTester:setTitleFontSize(26)
    -- btnTester:setTitleFontName(TEXT_FONT_NAME)
    -- btnTester:setPosition(1190,35)
    -- btnTester:addClickEventListener(function (sender,eventType)
    --     self.uiLayer:addChild(ConsoleView.new():init():getRootNode(),99)
    -- end)
    -- self.uiLayer:addChild(btnTester)
end
function GachaView:init(defaultGachaID)
    GachaView.super.init(self)
    if g_channel_control.unShow_gachaView_probability ~= true then 
        self:createButton()
    end 
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,330,134)
    self.gridview:setScrollBarEnabled(false)
    self.gridview.itemCreateEvent = function()     ----创建Item
        local temp = XUICellView.new():init(nil,"GachaItemView.csb",{
            iconImage = "/i:32/i:28",
            frameNormal = "/i:32/i:26",
            frameSelected = "/i:32/i:27"
        })
        temp.onResetData = function(self)
            self.frameNormal:setVisible( not self._data._isselected )
            self.frameSelected:setVisible(self._data._isselected)

            self.iconImage:setTexture(self._data.draw_icon)
        end

        return temp
    end
    self.gridview.itemClickedEvent = function (sender,index)
        self:selectItem(index)
        self:refreshLimit()
    end

    self.btnR1:addClickEventListener(function()
        --购买星石
        if self.asyncHandler then
            self.asyncHandler:cancel(true)
            self.asyncHandler = nil
        end
        if GameManagerInst.gameType == 2 then
            local  sData = { shopTypeIndex = EShopTabType.charge}
            SceneManager:toShopLayer(sData) 
        end
    end)
    
    self.btnR2:addClickEventListener(function()
        --苍玉兑换
        if self.asyncHandler then
            self.asyncHandler:cancel(true)
            self.asyncHandler = nil
        end
        if GameManagerInst.gameType == 2 then
            local  sData = { shopTypeIndex = EShopTabType.cangyu}
            SceneManager:toShopLayer(sData) 
        end
    end)

    self.btnR3:addClickEventListener(function()
        --超限之证--TODO跳转超限商店
        if self.asyncHandler then
            self.asyncHandler:cancel(true)
            self.asyncHandler = nil
        end
        if GameManagerInst.gameType == 2 then
            -- local  sData = {}
            -- sData["_type"] = 4
            -- sData["sDelegate"] = self
            -- sData["sFunc"] = self.loadData
            -- SceneManager:toCardShop(sData)
            local  sData = { shopTypeIndex = EShopTabType.hero}
            SceneManager:toShopLayer(sData)
        end
    end)

    UnlockSys:getInstance():bindLock(34, self.btnR3, true)

    self.btnR4:addClickEventListener(function()
        if self.asyncHandler then
            self.asyncHandler:cancel(true)
            self.asyncHandler = nil
        end
        if GameManagerInst.gameType == 2 then
            local  sData = { shopTypeIndex = EShopTabType.act}
            SceneManager:toShopLayer(sData) 
        end
    end)

    self.btnClose:setEffectType(3)
    self.btnClose:addClickEventListener(function()
        self.currentSpineFile = nil

        if self.asyncHandler then
            self.asyncHandler:cancel(true)
            self.asyncHandler = nil
        end
        self:returnBack()
    end)

    --赠券
    self.btnB1:addClickEventListener(function()
        self:showConfirm(1)
    end)

    self.btnHelp:addClickEventListener(function()
        self:showGuidePicLayer()
    end)

    self.imgPrev:setVisible(false)

    self.numExtra:setString("")

    self.btnB1Num1:setString("")
    self.btnB2Num1:setString("")
    self.btnB2Num2:setString("")
    self.btnB3Num1:setString("")
    self.btnB3Num2:setString("")

    if g_channel_control.transform_gachaView_position == true then 
        self.btnB2Num1:setPosition(cc.p(54,65))
        self.btnB3Num1:setPosition(cc.p(54,65))
    end

    self.btnB2Text:setString("")
    self.btnB3Text:setString("")
    self.btnB4Text:setString("")
    self.btnB4:setVisible(false)

    if g_channel_control.gachaview_dailyDealBtn and self.btnB4Text then
        self.btnB4Text:setPosition(cc.p(85,65)) --每日优惠显示金额在上方，调整位置，size
        self.btnB4Text:setFontSize(24)
    end
    if g_channel_control.gachaView_hideDragonCoin == true then
        self.imgCangyu:setTexture("uifile/n_UIShare/shop/sc_ui_020.png")
    end
    if g_channel_control.gachaView_hideShopHero == true then
        self.btnR3:setVisible(false)
    end

    if g_channel_control.transform_GachaView_btnB2Num2_align == true then
        self.btnB2Num2:setAnchorPoint(cc.p(0,0.5))
        self.btnB2Num2:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.btnB2Num2:setPositionX(167.5)
    end

    if g_channel_control.transform_GachaView_btnB3Num2_align == true then
        self.btnB3Num2:setAnchorPoint(cc.p(0,0.5))
        self.btnB3Num2:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.btnB3Num2:setPositionX(160)
    end
    
    self.lbLimit1:setString("")
    self.lbLimit10:setString("")

    --单抽
    self.btnB2:addClickEventListener(function()
        self:showConfirm(2)
    end)

    --十连
    self.btnB3:addClickEventListener(function()
        self:showConfirm(3)
    end)
    
    --每日奖励
    self.btnB4:addClickEventListener(function()
        self:showConfirm(4)
    end)

    self.defaultGachaID = defaultGachaID

    --新手引导 抽卡 第三步
    local newGuide = user_info["guide_id"]
    if newGuide == guide_id_config.ThatCard then
        --NewGuideManager.curLayer = self
        self.defaultGachaID = 1
        NewGuideManager:startSubGuide(self, 2)

    end
    
    self:setNodeLockState()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    SceneManager.menuLayer:hiddenUserInfo(false)

    self.topBarViews = XUIView.new():init(self.topBarViewPanel)
    self:InitTopBarView()
    return  self
end

function GachaView:showConfirm(gacha_type)
    if self.currentGachaIndex ~= nil and self.lottery_cheap ~= nil then
        local ginfo = self.currentDataSource[self.currentGachaIndex]
        local cheap = self.lottery_cheap[self.currentGachaIndex]
        local gem_cost = 0
        local enoughstr = nil

        if gacha_type == 1 then
            local confStr = UITool.ToLocalization("您是否要消耗 %d 契约书，进行一次召唤")
            -- UITool.ToLocalization("您是否要消耗")..ginfo.d_num..UITool.ToLocalization("契约书，进行1次召唤？")
            GameManagerInst:confirm(string.format(confStr, ginfo.d_num),function()
                if ginfo.d_num > self.cntUseProp3 then
                    GameManagerInst:alert(UITool.ToLocalization("您的契约书不足，无法进行召唤。"))
                else
                    self:btnGacha(1)
                end
            end)
            return
        elseif gacha_type == 2 then
            gem_cost = ginfo.s_num
            if gem_cost > self.cntGem then
                enoughstr = UITool.ToLocalization("您的星石不足，无法进行召唤。\n是否前往商店购买？")
            end
        elseif gacha_type == 3 then
            gem_cost = ginfo.m_num
            if gem_cost > self.cntGem then
                enoughstr = UITool.ToLocalization("您的星石不足，无法进行召唤。\n是否前往商店购买？")
            end
        elseif gacha_type == 4 then
            if cheap ~= 0 then
                return
            end

            gem_cost = ginfo.cheap_draw_cost
            if gem_cost > self.cntGem_r then
                enoughstr = UITool.ToLocalization("您的有偿星石不足，无法进行召唤。\n是否前往商店购买？")
            end
        end

        local dialog = GachaConfirmView.new():init()
        --dialog:setInfo(gem_f,gem_r,gacha_type,gem_cost,callback)

        if enoughstr then
            dialog:setInfo(self.cntGem - self.cntGem_r,self.cntGem_r,gacha_type,gem_cost,function()
                dialog:clearEx()
                GameManagerInst:confirm(enoughstr,function()
                    if self.asyncHandler then
                        self.asyncHandler:cancel(true)
                        self.asyncHandler = nil
                    end
                    if GameManagerInst.gameType == 2 then
                        local  sData = { shopTypeIndex = 1}
                        SceneManager:toShopLayer(sData) 
                    end
                end)
            end)
        else
            dialog:setInfo(self.cntGem - self.cntGem_r,self.cntGem_r,gacha_type,gem_cost,function()
                dialog:clearEx()
                self:btnGacha(gacha_type)
            end)
        end

        GameManagerInst:showModalView(dialog)
    end

end

--抽卡说明
function GachaView:showGuidePicLayer( ... )
    local data = {}
    data.pictures = { --一张或者多张
         "uifile/n_UIShare/newGuide/picture_guide/xsjx_ck_001.png",
    }
    SceneManager:toGuidePictureLayer(data)
end

function GachaView:btnGacha(idx)
    if not self.currentGachaID then return end

    --GameManagerInst:alert("gid:"..self.currentGachaID.."  gtype:"..idx)

    
-- # 接口名:  
-- # 参数: "draw_id": 1,      # 卡池
-- # 参数: "use_d": 1,      # 0 不是用屌丝 1 使用屌丝单抽(用屌丝时,无视下面的lotto_num参数)
-- # 参数: "lotto_num": 1,      # 几抽,不用屌丝时,区分单抽还是十连: 1-单抽, 10-十连抽 

    local tempdata ={
        rpc = "lottery_draw",
        draw_id = self.currentGachaID
    }

    if idx == 1 then
        --赠券
        tempdata.use_d = 1
        tempdata.lotto_num = 1
    elseif idx == 2 then
        --单抽
        tempdata.use_d = 0
        tempdata.lotto_num = 1

        if self.lottery_limit ~= nil and self.currentGachaIndex ~= nil then
            local limit = self.lottery_limit[self.currentGachaIndex]

            if limit[2] > 0 and limit[1] >= limit[2] then
                GameManagerInst:alert(UITool.ToLocalization("购买次数已达每日上限"))
                return
            end
        end

    elseif idx == 3 then
        --十连
        tempdata.use_d = 0
        tempdata.lotto_num = 10
        
        if self.lottery_limit ~= nil and self.currentGachaIndex ~= nil then
            local limit = self.lottery_limit[self.currentGachaIndex]

            if limit[4] > 0 and limit[3] >= limit[4] then
                GameManagerInst:alert(UITool.ToLocalization("购买次数已达每日上限"))
                return
            end
        end
    elseif idx == 4 then
        tempdata.use_d = 2
        tempdata.lotto_num = 1
    end


    GameManagerInst:rpc(tempdata,
        3,
        function(data)
            --success            
            --GameManagerInst:saveToFile("lottery_list.json",data)
            --GameManagerInst:alert("已保存")
            data["resource"]["beryl"] = data["resource"]["beryl"] or 0
            local berylAdd = data["resource"]["beryl"] - self.cntBeryl
            local dragonAdd = data["resource"]["dragon_coin"] - self.cntDragon_coin
            local coinAdd = 0--berylAdd > dragonAdd and berylAdd or dragonAdd -- 两者中取较大值：龙币与苍玉不同服务器特殊需求选择不同，目前以此方案；拓展需更新TODO
            if self.nGive_type == 3 then--圣光之辉
                coinAdd = data["give_num"] or 0
            else
                coinAdd = berylAdd > dragonAdd and berylAdd or dragonAdd -- 两者中取较大值：龙币与苍玉不同服务器特殊需求选择不同，目前以此方案；拓展需更新TODO
            end

            self.cntGem = data["resource"]["gem"]
            self.cntGem_r = data["resource"]["gem_r"]
            self.cntBeryl = data["resource"]["beryl"]
            self.cntDragon_coin = data["resource"]["dragon_coin"]
            self.cntUseProp3 = data["resource"]["useprop_3"]
            self.badge = data["resource"]["badge"]
            if GameManagerInst.gameType == 2 then
                self:RefreshTopBarView()
            end
            
            local getdata = data["get"]
            
            -- GameManagerInst:saveToFile("lottery_draw_"..idx..".json",data)
            -- GameManagerInst:alert("已保存")

            if self.lottery_limit ~= nil and self.currentGachaIndex ~= nil then
                local limit = self.lottery_limit[self.currentGachaIndex]
                if idx == 2 then
                    limit[1] = limit[1] + 1
                elseif idx == 3 then
                    limit[3] = limit[3] + 1
                end
            end
                    
            if self.currentGachaIndex ~= nil and self.lottery_cheap ~= nil and idx == 4 then
                self.lottery_cheap[self.currentGachaIndex] = 1
            end

            self:checkTrackEvent(self.currentGachaID,idx) --根据卡池ID，以及当前抽卡类型判断打点

            self:refresh()
            
            user_info["gem"] = self.cntGem
            user_info["gem_r"] = self.cntGem_r
            user_info["beryl"] = self.cntBeryl
            user_info["dragon_coin"] = self.cntDragon_coin
            user_info["badge"] = self.badge

            --self:stopVideo()
            --新手引导抽卡完成
            if user_info["guide_id"] == guide_id_config.ThatCard then 
                NewGuideManager:finshNowGuide()
            end 
            if GameManagerInst.gameType == 2 then

                local function resumeBGMusic(  )
                    print("resumeBGMusic-----")
                    AudioManager:shareDataManager():resumeAll()
                    --AudioManager:shareDataManager():stopAll()--抽卡音效超过上限，导致无法播放新音效
                    local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
                    --todo 停止或者恢复当前音乐
                    if musicState == 0 then --开启音乐
                        
                        if AudioManager:shareDataManager():getBGId() ~= -1 then 
                            AudioManager:shareDataManager():resumeBGMusic()
                        else 
                            local fullpath = lua_musci["zhuyeBGM"]
                            AudioManager:shareDataManager():preloadM(fullpath)
                            AudioManager:shareDataManager():playBGMusic(fullpath, true)
                        end
                    end 

                end
                SceneManager.menuLayer:RefshTopBar()
                SceneManager:toDrawCardEndLayer({   itemList = getdata,
                                                    berylNum = coinAdd,
                                                    CoinType = self.nGive_type,
                                                    finalFunc = function()
                                                        resumeBGMusic()
                                                        NoticeManager:startNotice()
                                                        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                                                        self:loadData()
                                                    end
                                                    })
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText)
        end,
        true)
end

function GachaView:checkTrackEvent(currentGachaID,gacha_type) --卡池ID，抽卡方式
    -- body
    SysDot:eventGachaTrack( currentGachaID,gacha_type )
end
--[[
    data = {
    #         星石       苍玉         屌丝券
    resource:{"gem":221,"beryl":222,"useprop_3":11}
    # 根据抽奖类型, 扣除抽奖消耗后剩余的资源数量
    # 具体获得了什么东西
    "list": [
        {   
            "draw_icon":"123.png",  #卡池的icon
            "draw_vedio":"123.mp4", #视频地址
            "d_num":1,      # 单抽消耗屌丝个数
            "d_b_num":1,      # 单抽消耗屌丝送的苍玉个数
            "s_num": 15,      # 单抽花销
            "s_b_num":15,     # 单抽送的苍玉个数
            "m_num": 150,     # 十连抽花销
            "m_b_num": 150,     # 十连抽送的苍玉个数
            "draw_id": 1,     #卡池ID 
        },
    ], 
}
]]

function GachaView:selectItem(index)
    
    local ds = self.currentDataSource
    for i = 1,#ds do 
        ds[i]._isselected = false   
    end
    ds[index]._isselected = true

    self.currentGachaID = ds[index].draw_id
    self.currentGachaIndex = index

    local bIsDragon = false
    self.nGive_type = ds[index]["give_type"]
    
    if self.currentGachaID then
        if self.currentGachaID == 1 then
        --角色卡池
            -- self.btnB2Text:setString(UITool.ToLocalization("随机赠送1名角色"))
            -- self.btnB3Text:setString(UITool.ToLocalization("随机赠送10名角色"))
            -- if g_channel_control.gachaview_dailyDealBtn then
            --     self.btnB4Text:setString(UITool.ToLocalization("10"))
            -- else
            --     self.btnB4Text:setString(UITool.ToLocalization("随机赠送1名角色"))
            -- end
            bIsDragon = true
        elseif self.currentGachaID == 2 then
        --灵装卡池
            -- self.btnB2Text:setString(UITool.ToLocalization("随机赠送1件灵装"))
            -- self.btnB3Text:setString(UITool.ToLocalization("随机赠送10件灵装"))
            -- if g_channel_control.gachaview_dailyDealBtn then
            --     self.btnB4Text:setString(UITool.ToLocalization("10"))
            -- else
            --     self.btnB4Text:setString(UITool.ToLocalization("随机赠送1件灵装"))
            -- end
            bIsDragon = false
        else
        --活动卡池
        --经确认活动卡池为角色卡池的打折版本，所以与角色卡池抽卡显示同样信息
            -- self.btnB2Text:setString(UITool.ToLocalization("随机赠送1名角色"))
            -- self.btnB3Text:setString(UITool.ToLocalization("随机赠送10名角色"))
            -- if g_channel_control.gachaview_dailyDealBtn then
            --     self.btnB4Text:setString(UITool.ToLocalization("10"))
            -- else
            --     self.btnB4Text:setString(UITool.ToLocalization("随机赠送1名角色"))
            -- end
            bIsDragon = true
        end
    end
    self.btnB2Num1:setString(ds[index].s_num)
    self.btnB2Num2:setString(ds[index].s_d_num)
    self.btnB3Num1:setString(ds[index].m_num)
    self.btnB3Num2:setString(ds[index].m_d_num)
    if self.nGive_type == 2 or self.nGive_type == 3 then
        self.btnB2Text:setString(UITool.ToLocalization("随机赠送1名角色"))
        self.btnB3Text:setString(UITool.ToLocalization("随机赠送10名角色"))
        if g_channel_control.gachaview_dailyDealBtn then
            self.btnB4Text:setString(UITool.ToLocalization("10"))
        else
            self.btnB4Text:setString(UITool.ToLocalization("随机赠送1名角色"))
        end
    elseif self.nGive_type == 1 then
        self.btnB2Text:setString(UITool.ToLocalization("随机赠送1件灵装"))
        self.btnB3Text:setString(UITool.ToLocalization("随机赠送10件灵装"))
        if g_channel_control.gachaview_dailyDealBtn then
            self.btnB4Text:setString(UITool.ToLocalization("10"))
        else
            self.btnB4Text:setString(UITool.ToLocalization("随机赠送1件灵装"))
        end
    else
        
    end

    if self.nGive_type == 2 and bIsDragon then
        self.btnB2:loadTextures("uifile/n_UIShare/gacha/ck_b_002_11.png","uifile/n_UIShare/gacha/ck_b_002_21.png")
        self.btnB3:loadTextures("uifile/n_UIShare/gacha/ck_b_002_11.png","uifile/n_UIShare/gacha/ck_b_002_21.png")
        self.btnB4:loadTextures("uifile/n_UIShare/gacha/ck_b_003_11.png","uifile/n_UIShare/gacha/ck_b_003_12.png")
    elseif self.nGive_type == 3 and bIsDragon then
        self.btnB2:loadTextures("uifile/n_UIShare/gacha/ck_b_002_31.png","uifile/n_UIShare/gacha/ck_b_002_31.png")
        self.btnB3:loadTextures("uifile/n_UIShare/gacha/ck_b_002_31.png","uifile/n_UIShare/gacha/ck_b_002_31.png")
        self.btnB4:loadTextures("uifile/n_UIShare/gacha/ck_b_003_11.png","uifile/n_UIShare/gacha/ck_b_003_12.png")
    else
        self.btnB2:loadTextures("uifile/n_UIShare/gacha/ck_b_002_1.png","uifile/n_UIShare/gacha/ck_b_002_2.png")
        self.btnB3:loadTextures("uifile/n_UIShare/gacha/ck_b_002_1.png","uifile/n_UIShare/gacha/ck_b_002_2.png")
        self.btnB4:loadTextures("uifile/n_UIShare/gacha/ck_b_003_1.png","uifile/n_UIShare/gacha/ck_b_003_2.png")
    end


    self.btnB1:setVisible(ds[index].d_open == 1)
    self.btnB2:setVisible(ds[index].s_open == 1)
    self.btnB3:setVisible(ds[index].m_open == 1)


    --检查修改
    --self.btnB4Num1:setString(ds[index].cheap_draw_cost)

    self.gridview:refresh()

    self.imgPrev:setVisible(true)
    self.imgPrev:setTexture(ds[index].draw_vedio_static)

    --self.currentVideoFile = ds[index].draw_vedio
    --self:playVideo()
    local currentSpineFile = ds[index].draw_vedio
    self:playSpine(currentSpineFile)
end

function GachaView:refreshLimit()
    --每日抽卡次数限制
    if self.currentGachaIndex ~= nil and self.lottery_limit ~= nil then
        local limit = self.lottery_limit[self.currentGachaIndex]

        local now1 = limit[1]
        local limit1 = limit[2]
        local now10 = limit[3]
        local limit10 = limit[4]
        if limit1 ~= nil and limit1 > 0 then
            self.lbLimit1:setString(UITool.ToLocalization("今日已购买")..now1.."/"..limit1..UITool.ToLocalization("次"))
        else
            self.lbLimit1:setString("")
        end
        if limit10 ~= nil and limit10 > 0 then
            self.lbLimit10:setString(UITool.ToLocalization("今日已购买")..now10.."/"..limit10..UITool.ToLocalization("次"))
        else
            self.lbLimit10:setString("")
        end
    else
        self.lbLimit1:setString("")
        self.lbLimit10:setString("")
    end
    
    --每日奖励抽
    if self.currentGachaIndex ~= nil and self.lottery_cheap ~= nil then
        local ginfo = self.currentDataSource[self.currentGachaIndex]
        local cheap = self.lottery_cheap[self.currentGachaIndex]
        --local used = 
        if ginfo.cheap_draw == 1 and cheap == 0 then
            self.btnB4:setVisible(true)
        else
            self.btnB4:setVisible(false)
        end
    else
        self.btnB4:setVisible(false)
    end

end

function GachaView:refreshAll()
    if not self.currentDataSource then 
        --self:refresh()
        return
    end

    local len = #self.currentDataSource or 0
    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(self.currentDataSource)
    
    if not self.currentGachaIndex and len > 0 then
        local defidx = 1
        for i = 1,#self.currentDataSource do
            if self.defaultGachaID == self.currentDataSource[i].draw_id then
                defidx = i
                break
            end
        end
        self:selectItem(defidx)  
        self.gridview:jumpToIndex(defidx)      
    elseif self.currentGachaIndex > 0 and self.currentGachaIndex <= len then
        self:selectItem(self.currentGachaIndex)  
        self.gridview:jumpToPercent(percent)    
    end

    self:refresh()
end

function GachaView:refresh()

    self:refreshLimit()


    if g_channel_control.gachaView_hideDragonCoin == true then
        self.numExtra:setString(""..self.cntBeryl)
    else
        if self.cntDragon_coin then
            --self.numExtra:setString(""..self.cntBeryl)
            self.numExtra:setString(""..self.cntDragon_coin)
        else
            self.numExtra:setString("")
        end
    end

    --self.btnB1Num1:setString(UITool.ToLocalization("持有")..self.cntUseProp3..UITool.ToLocalization("个"))
    self.btnB1Num1:setString(string.format(UITool.ToLocalization("持有%d个"),self.cntUseProp3))
    UITool.setCommmonBtnRedDop(self.btnB1, self.cntUseProp3 > 0,nil)
end

function GachaView:playSpine(spine)

    if self.lastSpineFile == spine then return end
    self.lastSpineFile = nil

    self.panelVideo:removeAllChildren()
    if not spine or not cc.FileUtils:getInstance():isFileExist(spine) then return end
    self.lastSpineFile = spine

    local size = self.panelVideo:getSize()

    local id_str = spine
    local end_pos = string.find(id_str,'atlas') - 1
    local spName = string.sub(id_str,0,end_pos)

    --local skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
    if self.asyncHandler then
        self.asyncHandler:cancel()
        self.asyncHandler = nil
    end

    self.asyncHandler = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(skeletonNode)
        self.asyncHandler = nil
        dump(spName,"33333333333333")
        skeletonNode:setPosition(size.width / 2,size.height / 2)
        self.panelVideo:addChild(skeletonNode)
        skeletonNode:setAnimation(1, "effect", true)
    end)
end

function GachaView:playVideo()
    self:stopVideo()

    if not self.currentVideoFile then
        return
    end

    local size = self.panelVideo:getSize()

    self.videoPlayer = ccexp.VideoPlayer:create()
    self.videoPlayer:setContentSize(size)
    self.videoPlayer:setAnchorPoint(cc.p(0.5, 0.5))
    self.videoPlayer:setPosition(size.width / 2,size.height / 2)
    self.videoPlayer:addEventListener(function(sender,eventType)
        if eventType == ccexp.VideoPlayerEvent.PLAYING then
        elseif eventType == ccexp.VideoPlayerEvent.PAUSED then
        elseif eventType == ccexp.VideoPlayerEvent.STOPPED then  
        elseif eventType == ccexp.VideoPlayerEvent.COMPLETED then
            sender:play()
        end
    end)
    self.panelVideo:addChild(self.videoPlayer)
    
    self.videoPlayer:setFileName(self.currentVideoFile)
    self.videoPlayer:play()
end

function GachaView:stopVideo()
    if self.videoPlayer then
        self.videoPlayer:stop()
        self.videoPlayer:removeFromParent()
        self.videoPlayer = nil
    end
end

function GachaView:loadData()

    GameManagerInst:rpc("{\"rpc\":\"lottery_list\"}",
        3,
        function(data)
            --success
            --GameManagerInst:saveToFile("lottery_list.json",data)
            --GameManagerInst:alert("已保存")
            self.cntGem = data["resource"]["gem"]
            self.cntGem_r = data["resource"]["gem_r"]
            self.cntBeryl = data["resource"]["beryl"]
            self.cntDragon_coin = data["resource"]["dragon_coin"]
            self.cntUseProp3 = data["resource"]["useprop_3"]
            self.badge = data["resource"]["badge"]
            self.currentGachaID = nil
            self.currentDataSource = table.deepcopy(data["list"])

            self.lottery_limit = table.deepcopy(data["lottery_limit"])
            self.lottery_cheap = table.deepcopy(data["lottery_cheap"])

            self:refreshAll()
            
            user_info["gem"] = self.cntGem
            user_info["gem_r"] = self.cntGem_r
            user_info["beryl"] = self.cntBeryl
            user_info["dragon_coin"] = self.cntDragon_coin
            user_info["badge"] = self.badge
            if GameManagerInst.gameType == 2 then
                --SceneManager.menuLayer:RefshTopBar()
                self:RefreshTopBarView()
            end
            self.btnR4:setVisible(false)
            for i,v in ipairs(self.currentDataSource) do
                if v["give_type"] and v["give_type"] == 3 then
                    self.btnR4:setVisible(true)
                end
            end
        end,
        function(state_code,msgText)
            --failed
            GameManagerInst:alert(msgText,function()
                self:returnBack()
            end)
        end,
        true)
end

function GachaView:onNavigateTo(isback)
    if isback then
        cc.Director:getInstance():getTextureCache():removeUnusedTextures()
    else
        self:loadData()
    end
end

function GachaView:onNavigateFrom(isback)
    if isback then
        if self.asyncHandler then
            self.asyncHandler:cancel(true)
            self.asyncHandler = nil
        end
    end
end

function GachaView:returnBack()
    if self._navigationView then
        self._navigationView:popView()
    end
end

--设置按钮等级解锁状态
function GachaView:setNodeLockState()
    local curNodes = {self.btnR2}
    for i=1,#curNodes do
        local config = guide_rank_config["GachaView"][i]
        local btn = curNodes[i]
        if config.unlock_level > tonumber(user_info["rank"]) then 
            if config.state == 0 then 
                btn:setVisible(false)
            end 
        end 
    end   
end

function GachaView:InitTopBarView()
    local iteamDatas = {}
    local rcvData = {}
    rcvData["sIteamDatas"] = iteamDatas
    rcvData["bIsStartLayer"] = false -- 是否为主界面 右上角Home按钮区分处理作用
    rcvData["nInfoState"] = table.getValue("coinbar",coinbar,11,"coinbar_type")--2 -- 1、显示用户信息（一般为主页调用）2、隐藏用户信息显示货币栏（部分二级界面调用）3、隐藏用户信息隐藏货币栏（部分二级界面调用）
    rcvData["nTitleNum"] = 6 --显示界面title信息 从SceneManager的表中取字段（为了兼容性、统一维护一份title表，不在TopBarView中单独起title表，后续在确定全部采用新TopBarView后考虑换表）

    self.topBarView = TopBarView.new():init(rcvData)
    self.topBarViews:addSubView(self.topBarView)
    iteamDatas = table.getValue("coinbar",coinbar,29,"coin_list")
    self.topBarView:refreshByItemDataChange(iteamDatas)
    array_cointype[27] = user_info["badge"]
    self:refreshItemNumByIndex(iteamDatas)
end

function GachaView:refreshItemNumByIndex(_tab)
    for i,v in ipairs(_tab) do
        if v and v > 3 then
            if array_cointype[v] then
                self.topBarView:refreshItemNumByIndex(v,array_cointype[v])
            end
        end
    end
end
function GachaView:RefreshTopBarView()
    if self.topBarView then
        array_cointype[27] = user_info["badge"]
        local iteamDatas = table.getValue("coinbar",coinbar,29,"coin_list")
        self.topBarView:refreshByItemDataChange(iteamDatas)
        self:refreshItemNumByIndex(iteamDatas)
    end 
end
