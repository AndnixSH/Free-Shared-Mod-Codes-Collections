
--玩家信息 
user_info = {}

--角色列表
hero_list = {}


--队伍列表
team_list = {}

--角色详情
hero_info = {}

--角色自选
hero_open = {}

--装备详情
eq_info = {}

--剧情角色
Actor = {}

--背景
Location = {}

--装备列表
equip_list = {}

--公主职业列表
princess_list = {}


DataManager  = {} 
-- 邮件永久
Mail_YInfo   = {}
-- 邮件限时
Mail_XInfo   = {}
-- 邮件 永久的
Mail_YList  = {}
-- 邮件 限时的
Mail_XList  = {}

-- 背包 杂货 mat
bag_mat     = {}
-- 背包 礼包 gift 
bag_gift    = {}
-- 背包 可使用道具 useprop
bag_useprop = {}
--  背包 碎片
bag_piece   = {}

-- 聊天 数据 --本次游戏周期有效
chat_info = {}

check_sk_id = ""

check_sk_info = {}
check_sk_info["attack_info"] ={
 
}
check_sk_info["skill_info"] ={

}
check_sk_info["state_info"] ={

}

check_sk_info["passive_info"] ={

}

check_sk_info["monster_info"] ={

}
--战斗数据缓存
battle_data_cache = {}

--所有类型的货币数量
array_cointype = {}

--角色图鉴筛选条件 缓存
use_herobook_sort_data = nil
use_titlebook_sort_data = nil
use_titlebrowser_sort_data = nil
use_equipbook_sort_data = nil

function DataManager:getbeat_checksk()
  local  dataTable = {}
   if next(check_sk_info) ~=nil then 
      for k, v in pairs(check_sk_info) do
        if next(v) ~=nil then
          if k == "attack_info" then
                for i = 1, #v do
                    local  sk_id = tonumber(v[i])
                    print( "普攻技能ID".. sk_id)
                    dataTable[k] = {}
                    dataTable[k][tostring(sk_id)] = {}
                    dataTable[k][tostring(sk_id)] = Attack[sk_id]
                end
             end
          if k == "skill_info" then
                 for i = 1, #v do
                    local  sk_id = tonumber(v[i])
                    print( "技能ID".. sk_id)
                    dataTable[k] = {}
                    dataTable[k][tostring(sk_id)] = {}
                    dataTable[k][tostring(sk_id)] = skill[sk_id]
                 end
          end 
          if k == "state_info" then
                 for i = 1, #v do
                    local  sk_id = tonumber(v[i])
                    dataTable[k] = {}
                    dataTable[k][tostring(sk_id)] = {}
                    dataTable[k][tostring(sk_id)] = state[sk_id]
                 end
          end 
          if k == "passive_info" then
                 for i = 1, #v do
                    local  sk_id = tonumber(v[i])
                    dataTable[k] = {}
                    dataTable[k][tostring(sk_id)] = {}
                    dataTable[k][tostring(sk_id)] = passive_sk[sk_id]
                 end
          end 
          if k == "monster_info" then
                for i = 1, #v do
                    local  sk_id = tonumber(v[i])
                    dataTable[k] = {}
                    dataTable[k][tostring(sk_id)] = {}
                    dataTable[k][tostring(sk_id)] = monster_sk[sk_id]
                 end
          end 
       end  
      end
    end
    return dataTable
end

function DataManager:initDataManager()
         user_info["eq"] = {}
         user_info["bag"] = {}
         user_info["hero"] = {}
         user_info["team"] = {}
         cc.UserDefault:getInstance():setIntegerForKey("teamIdx", user_info["recent_team"])
         cc.UserDefault:getInstance():setStringForKey("userName", user_info["name"])
         local guideID = user_info["guide_id"] or 0
         cc.UserDefault:getInstance():setIntegerForKey("GuideId", guideID)
end
-- 刷新素材
function DataManager:rsfBagMat( ... )
  -- body
    local temp_list = {}
    local index = 1
    if user_info["bag"]["mat"] ~= nil then
      for k,v in pairs(user_info["bag"]["mat"]) do
        if v ~= 0 then
          temp_list[index] = {}
          temp_list[index]["num"] = v
          if temp_list[index]["num"]~= 0 then 
            temp_list[index]["id"] = tostring(k) 
            temp_list[index]["num"] = v
            index = index +1
          end
        end
      end
    end
   bag_mat = {}
   bag_mat = table.deepcopy(temp_list)
   print("bag_mat len == "..#bag_mat)
end
-- 刷新礼包
function DataManager:rsfBagGift( ... )
  -- body
   local temp_list = {}
   local index = 1
   if user_info["bag"]["gift"]~=nil then
      for k,v in pairs(user_info["bag"]["gift"]) do
    if v ~= 0 then
      temp_list[index] = {}
      temp_list[index]["num"] = v
      if temp_list[index]["num"]~=0 then 
        temp_list[index]["id"]  = tostring(k)  
        temp_list[index]["num"] = v
        index = index +1
      end
    end
   end
   end
  
   bag_gift = {}
   bag_gift = table.deepcopy(temp_list)
end
-- 刷新可以使用道具
function DataManager:rsfBagUseprop( ... )
  -- body
   local temp_list = {}
   local index = 1
   if user_info["bag"]["useprop"]~= nil then
   for k,v in pairs(user_info["bag"]["useprop"]) do
      if v and v["num"] ~= 0 then
        temp_list[index] = {}
        temp_list[index]["num"] = v["num"]
        if temp_list[index]["num"]~=0 then 
          --print("kkkkk == "..k)
          --print("vvvv == "..v["num"])
          temp_list[index]["id"] = tostring(k) 
          temp_list[index]["num"] = v["num"]
          index = index +1
        end
      end
   end
   end
   bag_useprop = {}
   bag_useprop = table.deepcopy(temp_list)
end
-- 刷新碎片
function DataManager:rsfBagPiece( ... )
  -- body
  local temp_list = {}
  local index = 1
  if user_info["bag"]["piece"]~=nil then
   for k,v in pairs(user_info["bag"]["piece"]) do
    if v ~= 0 then
      temp_list[index] = {}
      temp_list[index]["num"] = v
      if temp_list[index]["num"]~=0 then 
        temp_list[index]["id"] = tostring(k) 
        temp_list[index]["num"] = v
        index = index +1
      end
    end
   end
  end
   bag_piece = {}
   bag_piece = table.deepcopy(temp_list)
end

function DataManager:rfsStory(location,actor)
Actor = {}

Location = {}

for i=1,#location do
  Location[location[i]["ID"]] = location[i]["Fields"]
  print(location[i]["ID"].."名称"..location[i]["Fields"]["Name"])
end

for i=1,#actor do
  Actor[actor[i]["ID"]] = actor[i]["Fields"]
  print(actor[i]["ID"].."名称"..actor[i]["Fields"]["Name"])
end

end


--刷新英雄数据
function DataManager:rfsHlist()
  print("DataManager:rfsHlist()")
	local temp_list = {}
    local index = 1
    for k,v in pairs(user_info["hero"]) do
       
         temp_list[index] = v
         if temp_list[index]~=nil then 
           temp_list[index]["id"] = k 
           temp_list[index]["time_id"] = getTimeNumID(""..k)
           temp_list[index]["hero_rank"] = hero[getNumID(""..k)]["hero_rank"]
            temp_list[index]["hero_name"] = UITool.getUserLanguage(hero[getNumID(""..k)]["hero_name"])--hero[getNumID(""..k)]["hero_name"]
           index = index +1
         end 
    end
    hero_list = {}
    hero_list = table.deepcopy(temp_list)
end 

--刷新队伍列表
function DataManager:rfsTlist()
   team_list = {}
   team_list = table.deepcopy(user_info["team"])
   print("DataManager:rfsTlist()")
end

--刷新英雄数据
function DataManager:rfsHeroInfo()
  --  team_list = {}
  --  team_list = table.deepcopy(user_info["hero_info"])
end


--刷新装备数据 
function DataManager:rfsElist()
   
    local temp_list = {}
    local index = 1
    for k,v in pairs(user_info["eq"]) do
      temp_list[index] = v
      if temp_list[index]~=nil then
        temp_list[index]["id"] = k
        temp_list[index]["time_id"] = getTimeNumID(""..k)
        temp_list[index]["equip_rank"] = equip[getNumID(""..k)]["equip_rank"]
        temp_list[index]["equip_name"] = UITool.getUserLanguage(equip[getNumID(""..k)]["equip_name"])--equip[getNumID(""..k)]["equip_name"]
        index = index +1
      end
    end
    equip_list = {}
    equip_list = table.deepcopy(temp_list)
    temp_list = {}

       --------------------------升序还是降序 -----------------
end

--刷新公主职业信息
function DataManager:rfsPlist()
    local temp_list = {}
    for i,v in ipairs(user_info["princess_list"]) do
         temp_list[i] = v
    end
    princess_list = {}
    princess_list = table.deepcopy(temp_list)
    temp_list = {}
 
end 

--写入队伍数据
function DataManager:wTeamData(data)
    user_info["team"] =  table.deepcopy(data)
    self:rfsTlist()
end 

--写入星之卵数据
function DataManager:wAllEquipData( data )
  user_info["eq"] = data
  self:rfsElist()
end


--写入背包数据
function DataManager:wAllBagData( data )
  user_info["bag"] = table.deepcopy(data)
  self:rsfBagGift()
  self:rsfBagMat()
  self:rsfBagPiece()
  self:rsfBagUseprop()
end

--写入全部英雄数据
function DataManager:wAllHeroData(data)
  user_info["hero"] = table.deepcopy(data)
  self:rfsHlist()
end

--修改英雄数据
function DataManager:wHeroData(data,h_id)
   user_info["hero"][h_id] = data["data"]
  
    self:rfsHlist()
end 

--修改装备数据 星之卵强化成功调用
function DataManager:wEquipData(data)
  if(data == nil)then
  end
  for k,v in pairs(data) do
      user_info["eq"][k] = v
  end
    self:rfsElist()
end  


--修改英雄及 星之卵数据 卸下装备调用
function DataManager:modEqiupUnload(h_id,pos,data)
  for k,v in pairs(data["hero"]) do
     print(k,v)
     user_info["hero"][k] = v
   end 
  
   for i=1,#data["unload_eq"] do
      user_info["eq"][data["unload_eq"][i]]["owner"]= "0" 
   end
    self:rfsElist()
    self:rfsHlist()

end 

function DataManager:modEqiupUse(h_id,pos,e_id,data)

  for k,v in pairs(data["hero"]) do
     print(k,v)
     user_info["hero"][k] = v
   end 
   if  data["unload_eq"] ~= ""then
       user_info["eq"][data["unload_eq"]]["owner"]= "0"
   end 
   user_info["eq"][data["use_eq"]]["owner"]=  h_id
   self:rfsElist()
   self:rfsHlist()

end 

function DataManager:modQCEqiupUse(h_id,data)

  for k,v in pairs(data["hero"]) do
     print(k,v)
     user_info["hero"][k] = v
   end 
    for i=1,#data["unload_eq"] do
      user_info["eq"][data["unload_eq"][i]]["owner"]= "0" 
   end
       for i=1,#data["use_eq"] do
      user_info["eq"][data["use_eq"][i]]["owner"]= h_id 
   end
   self:rfsElist()
   self:rfsHlist()

end 


--修改公主技能
function DataManager:modPrincessLearn(index_1,index_2)
   user_info["princess_list"][index_1]["career"][index_2]["status"] = 2
   self:rfsPlist()
end 

--修改公主技能
function DataManager:changePrList(data)
user_info["princess_list"] = data
self:rfsPlist()
end

--删除装备数据
function DataManager:dEquipData(data)
       for i=1,#data do
            if user_info["eq"][data[i]["id"]] ~=nil then
                user_info["eq"][data[i]["id"]] = nil
           end
       end

   self:rfsElist()
end  
-------突破装备删除 
function DataManager:dTEquipData(id)
    
  if user_info["eq"][id] ~=nil then
  user_info["eq"][id] = nil
  end
  self:rfsElist()
end 

--修改玩家金币
function DataManager:wGold(count)
    user_info["gold"] = count  
end 

--角色突破 
function DataManager:roleBthEnd(id,data)
  print("突破成功 修改角色 "..id)
   user_info["hero"][id] = data["data"][id]
    self:rfsHlist()
    
    -- user_info["hero"][id]["hp"] =  data["upgrade"]["add_hp"]
    -- user_info["hero"][id]["atk"] =  data["upgrade"]["add_atk"]
    -- user_info["hero"][id]["Lv_max"] = data["upgrade"]["Lv_max"]
    -- user_info["hero"][id]["break_count"] = data["upgrade"]["break_count"]

    -- for i=1,#data["item_change"] do 
    --     if  data["item_change"][i]["id"]==nil then 
    --        user_info["gold"] = data["item_change"][i]["value"]
    --     else 
    --        user_info["bag"]["mat"][data["item_change"][i]["id"]] = data["item_change"][i]["value"]
    --     end 
    -- end 
    for k,v in pairs(data["use_mat"]) do
      user_info["bag"]["mat"][k] = v
    end
    self:rsfBagMat()
    
    user_info["gold"] = data["gold"]

  
end 
-- 装备突破
function DataManager:euipBthEnd(id,data)
    
    for k,v in pairs(data) do
      user_info["eq"][k] = v
    end

    self:rfsElist()
  
end 


--结算界面修改信息
function DataManager:battleEnd(data)
     
    print("结算修改结果")
    for k,v in pairs(data["drop"]) do 
        if v["type"] ==1 then
          user_info["gold"] = user_info["gold"] + v["num"]
        end
    end 
    
  if data["level_drop"]~=nil then  
    for k,v in pairs(data["level_drop"]) do 
        if v["type"] ==1 then
          user_info["gold"] = user_info["gold"] + v["num"]
        end
        if v["type"] ==2 then
          user_info["gem"] = user_info["gem"] + v["num"]
        end
         if v["type"] ==10 then
           user_info["faith"] = user_info["faith"]  + v["num"]
        end
        if v["type"] ==11 then
          user_info["beryl"] = user_info["beryl"] + v["num"]
        end
    end
  end

  if data["sp_drop"]~=nil then  
    for k,v in pairs(data["sp_drop"]) do 
        if v["type"] ==1 then
          user_info["gold"] = user_info["gold"] + v["num"]
        end
         if v["type"] ==2 then
          user_info["gem"] = user_info["gem"] + v["num"]
        end
        if v["type"] ==10 then
           user_info["faith"] = user_info["faith"]  + v["num"]
        end
        if v["type"] ==11 then
          user_info["beryl"] = user_info["beryl"] + v["num"]
        end
    end
  end

    if data["rank_up"]~=nil then 
       user_info["rank"] = data["rank_up"]["rank_new"]
       user_info["exp_max"] = data["rank_up"]["rank_max_exp"]
        user_info["exp"] = data["rank_up"]["rank_new_exp"]
       user_info["ap"] = data["rank_up"]["ap_new"]
       user_info["ap_max"] = data["rank_up"]["ap_max"]
       user_info["gem"] = data["rank_up"]["add_gem"] + user_info["gem"]
       user_info["gold"] = data["rank_up"]["add_gold"] + user_info["gold"]
       user_info["faith"] = user_info["faith"] + data["rank_up"]["add_faith"]  
    end 
    

end 
--刷新自选数据
function DataManager:roleZXEnd(data)
         for k,v in pairs(data) do
           user_info["hero"][k] = v
         end
end 

function DataManager:eatAP(data)
      user_info["ap"] = data["ap"]
      user_info["gem"] = data["gem"]
      user_info["gem_r"] = data["gem_r"]
end

function DataManager:getExploreData()
    --"explore_num":10,   #当前剩余的探索次数
    --"explore_max":10,   #最大探索次数
    --"explore_lv":19,#当前的探索等级
    --"explore_exp":1999,#当前的探索经验
    --"explore_max_exp":2999,#等前升级所需的探索经验
    local data = {}
    data.explore_num = user_info["explore_num"]         -- #当前剩余的探索次数
    data.explore_max = user_info["explore_max"]         --  #最大探索次数
    data.explore_lv = user_info["explore_lv"]           --#当前的探索等级
    data.explore_exp = user_info["explore_exp"]         --#当前的探索经验
    data.explore_max_exp = user_info["explore_max_exp"] --#等前升级所需的探索经验
    return data
end 

function DataManager:refreshExploreData(data)
    dump(data)
    user_info["explore_num"] = data.explore_num or user_info["explore_num"]      -- #当前剩余的探索次数
    user_info["explore_max"] = data.explore_max or user_info["explore_max"]      --  #最大探索次数
    user_info["explore_lv"] = data.explore_lv or user_info["explore_lv"]         --#当前的探索等级
    user_info["explore_exp"] = data.explore_exp or user_info["explore_exp"]      --#当前的探索经验
    user_info["explore_max_exp"] = data.explore_max_exp or user_info["explore_max_exp"]--#等前升级所需的探索经验
end 
function DataManager:getDiamond()
    return tonumber(user_info.gem) or 0
end 

function DataManager:clearAllData()
    --角色列表
    hero_list = {}
    --队伍列表
    team_list = {}
    --角色详情
    hero_info = {}
    --装备详情
    eq_info = {}
    --剧情角色
    Actor = {}
    --背景
    Location = {}
    --装备列表
    equip_list = {}
    --公主职业列表
    princess_list = {}
    -- 邮件永久
    Mail_YInfo   = {}
    -- 邮件限时
    Mail_XInfo   = {}
    -- 邮件 永久的
    Mail_YList  = {}
    -- 邮件 限时的
    Mail_XList  = {}
    -- 背包 杂货 mat
    bag_mat     = {}
    -- 背包 礼包 gift 
    bag_gift    = {}
    -- 背包 可使用道具 useprop
    bag_useprop = {}
    --  背包 碎片
    bag_piece   = {}
    --聊天数据
    chat_info = {}
    --战斗缓存数据
    battle_data_cache = {}

    DataManager:clearCachSort()

end 

function DataManager:clearCachSort()
    use_herobook_sort_data = nil
    use_titlebook_sort_data = nil
    use_titlebrowser_sort_data = nil
    use_equipbook_sort_data = nil
end

--从表中获取元素的值，可以是嵌套关系，依次从表中取值
-- @param table 一个表
-- @param tableName 表名
-- @param ... 可变参数 表示表中的key

-- deprecated Use table.getValue(tableName,table,...) instead 

-- function DataManager:getValue(tableName, table, ...)
--   local base = _G;
--   local vType = base.type(table)
--   tableName = tableName or "tableName"
--   local errorStr = "== Error ==: DataManager:getValue "
--   -- Handle strings
--   if vType ~='table' then
--     errorStr = errorStr.."tableName : "..tostring(tableName).." should be not nil or empty"
--     -- print(errorStr)
--     LogManager.showTableMsg(errorStr,tostring(tableName))

--     return nil
--   else
   

--   end
  
--   local function errorLog(...)
--     -- body
--     errorStr = errorStr.."table = "..tostring(tableName)
--     local paramCount = select('#', ...)
--     for i = 1, paramCount do
--         local v = select(i, ...)
--         errorStr = errorStr..", "..tostring(v);
--     end

--     --errorStr = errorStr.."error key is "..tostring(value)
--     -- print(errorStr)
--     LogManager.showTableMsg(errorStr,tostring(tableName))
--   end 

 
--   local value = table
--   local paramCount = select('#', ...)
--   for i = 1, paramCount do
--       local v = select(i, ...)
--       --print("k = "..tostring(v))
--       if value == nil then
--          errorLog(...)
--          break
--       end
--       value = value[v]
--   end


--   return value;
-- end





function DataManager.reqUerCoin(successFunc)
    urlType = urlType or 3
    local tempTable = {
        ["rpc"] = "refresh_user_coin",
    }
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            return
        end
        user_info["gold"]  = t_data["data"].gold
        user_info["gem"]   = t_data["data"].gem
        user_info["gem_r"]   = t_data["data"].gem_r
        user_info["beryl"] = t_data["data"].beryl
        user_info["faith"] = t_data["data"].faith
        user_info["ap"] =  t_data["data"].ap or user_info["ap"]
        user_info["ap_next"] =  t_data["data"].ap_next or user_info["ap_next"]
        successFunc(t_data["data"])

    end
    local cjson = require "cjson"
    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,urlType)
end



