--[[
	SelectPlayerTitleLayer.lua
	ui:SelectPlayerTitleUI.csb
	选择 玩家称号
]]

require "BasicLayer"

SelectPlayerTitleLayer = class("SelectPlayerTitleLayer",BasicLayer)
SelectPlayerTitleLayer.__index = SelectPlayerTitleLayer
SelectPlayerTitleLayer.lClass = 3

function SelectPlayerTitleLayer:create(rData)
     local layer = SelectPlayerTitleLayer.new()
     layer.rData = rData
     layer:init()
     return layer
end

function SelectPlayerTitleLayer:init()

	self.sManager = self.rData["sManager"]
    self.uiLayer = cc.Layer:create()

    local node = cc.CSLoader:createNode("SelectPlayerTitleUI.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
	self._rootCSbNode = node:getChildByTag(102) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack()
        end
    end
    local backBtn = ccui.Helper:seekWidgetByName(self._rootCSbNode ,"btn")
    backBtn:addTouchEventListener(touchCallBack)

    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")

	self:initListView()

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)
    self:reqTitles()	

end

function SelectPlayerTitleLayer:initListView()
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 764,121)

    self.gridview._scrollView:setScrollBarEnabled(true)
    self.gridview._scrollView:setScrollBarWidth(2)
    self.gridview._scrollView:setScrollBarColor(cc.c3b(255, 255, 255))
    self.gridview._scrollView:setScrollBarOpacity(225*0.5)
    self.gridview._scrollView:setScrollBarPositionFromCorner(cc.p(2,2))

    self.gridview.itemCreateEvent = function()
        local temp = SelectPlayerTitleItem.new():init()
        temp.ClickEvent = function(item)
        end
        temp.resetDataEvent = function(item)
        end
        temp.selectUserEvent = function(select_id)
        	self:selectUserEvent(select_id)
        end
        return temp
    end
end
---todo 发送请求 使用当前称号
function SelectPlayerTitleLayer:selectUserEvent(select_id)
    dump(select_id)
    self:reqTitleChange(select_id)
end
--刷新列表列表
function SelectPlayerTitleLayer:refreshListView()
    self.gridview:setDataSource(self.data)
end

--返回
function SelectPlayerTitleLayer:returnBack()
   self.exist = false
   self:clearEx()
end

function SelectPlayerTitleLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

--称号列表
function SelectPlayerTitleLayer:reqTitles()
    local function ReqSuccess(data)
        self.data = data.title_list
        --排序
        --装备的在前，然后根据id
        local function qualitySort(a,b)
            if a.state == b.state then 
                return tonumber(a.id) < tonumber(b.id)
            else
                return a.state > b.state
            end
        end
        table.sort(self.data, qualitySort)

        self:refreshListView()
    end
    local tempTable = {
        ["rpc"] = "title_list",
    }
    self:doReq(tempTable, ReqSuccess)  
end
--称号更改
function SelectPlayerTitleLayer:reqTitleChange(select_id)
    local function ReqSuccess(data)
        user_info["title_id"] = select_id
        local str = string.format(UITool.ToLocalization("称号已成功使用"))
        SceneManager:showPromptLabel(str)
        --todo  信息页面刷新称号
        if self.rData.rcvData.refreshFunc then 
            self.rData.rcvData.refreshFunc(self.rData.rcvData.sDelegate)
        end 
        self:returnBack()
    end
    local tempTable = {
        ["rpc"] = "title_change",
        ["title_id"] = select_id
    }
    self:doReq(tempTable, ReqSuccess)  
end
-----todo 发送请求的放到公共里面，现在不知道放哪，暂时放着。
function SelectPlayerTitleLayer:doReq(tempTable, successFunc,failesFunc)
    local function reicePointCallBack(data)
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            if failesFunc then 
                failesFunc(t_data["data"]["state_code"])
            end 
            return
        end
        successFunc(t_data["data"])
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

