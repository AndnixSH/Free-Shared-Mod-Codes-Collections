BattleExpressionManager = class("BattleExpressionManager") 
BattleExpressionManager.__index = BattleExpressionManager
BattleExpressionManager.rootNode = nil
BattleExpressionManager.bqNode = nil
BattleExpressionManager.touchPanel =nil
BattleExpressionManager.pageView = nil
BattleExpressionManager.BQ_NORMAL = "n_UIShare/zhandou/biaoqing/zdlt_b_001b.png"
BattleExpressionManager.BATTLE_UI_BQ = "uifile/BQAnimation.csb"
BattleExpressionManager.bqAniNum = 0
BattleExpressionManager.playBQ = false -- 记录当前是否为播放表情状态

function BattleExpressionManager:createWithMainUINode(node)
    local manager = BattleExpressionManager.new()
    manager:init(node)
    return manager
end

function BattleExpressionManager:init(node)
    self.rootNode = node 
    self.bqNode = self.rootNode:getChildByTag(855)
    self.touchPanel = self.bqNode:getChildByTag(4)
    self.pageView = self.bqNode:getChildByTag(2)
    self.bqNode:setVisible(false)
    self.pageView:setContentSize(cc.size(292, 320))
    self.pageView:setAnchorPoint(cc.p(0.5,0.5))

    function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self.bqNode:setVisible(false)
            self.rootNode:getChildByTag(945):loadTextureNormal(self.BQ_NORMAL) --设置bq按钮为未点击图标状态
        end
    end
    self.touchPanel:addTouchEventListener(touchCallBack)
    self.bqAniNum = 5    
end

function BattleExpressionManager:showBQList()
    self.bqNode:setVisible(true)
    self.pageView:removeAllPages()

    function onButtonClicked(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local tag = sender:getTag()
            self.bqNode:setVisible(false)
            self.rootNode:getChildByTag(945):loadTextureNormal(self.BQ_NORMAL)
            self:showBQAnimation(tag,UITool.ToLocalization("自己"))
            BattleUIManager:sendBQUpdate(tag)
        end
    end

	local count = #expression
	local pageCount = math.ceil(count/9.0)

    for i = 1, pageCount do
        local outerBox = ccui.HBox:create()
        outerBox:setContentSize(cc.size(292, 320))
        for k = 1, 3 do
            local innerBox = ccui.VBox:create()
            for j = 1, 3 do
                local index = (i-1)*9 + (k-1)*3 + j
                if index > count then 
                    break
                end 	
                local fileName = expression[index]["file"]
                local bqBtn = ccui.Button:create(fileName,fileName)
                bqBtn:setTag(index)
                bqBtn:setName("button"..index)
                bqBtn:setScale(0.85)
                innerBox:addChild(bqBtn)
                bqBtn:addTouchEventListener(onButtonClicked)
            end
            local parameter = ccui.LinearLayoutParameter:create()
            parameter:setMargin({left = 5, top = -10,right = 85, bottom = 0})
            innerBox:setLayoutParameter(parameter)
            outerBox:addChild(innerBox)
        end
        self.pageView:insertCustomItem(outerBox, i-1)
    end
end

function BattleExpressionManager:showBQAnimation(bqID,userName)
	local anNode = self.rootNode:getChildByTag(2746):getChildByTag(2558)
	anNode:setVisible(true)
	local panel = nil
    local fileName = expression[bqID]["file"]
    local name = "play"..(self.bqAniNum%3+1)
    if self.bqAniNum==5 then 
        panel = anNode:getChildByTag(1)
        panel:getChildByTag(1*100+1):setTexture(fileName)
        panel:getChildByTag(1*100+2):setString(userName)
        name = "play"
        self.bqAniNum = 4
    elseif self.bqAniNum==4 then
        panel = anNode:getChildByTag(2)
        panel:getChildByTag(2*100+1):setTexture(fileName)
        panel:getChildByTag(2*100+2):setString(userName)
        name = "play0"
        self.bqAniNum = 2
    else
        panel = anNode:getChildByTag(self.bqAniNum)
        panel:getChildByTag(self.bqAniNum*100+1):setTexture(fileName)
        panel:getChildByTag(self.bqAniNum*100+2):setString(userName)
    end

    panel:setVisible(true)
    local action = cc.CSLoader:createTimeline(self.BATTLE_UI_BQ)
    anNode:stopAllActions()
    anNode:runAction(action)
    self.playBQ = true
    
    local this = self
    function laseCallFuc()
        if this.bqAniNum==4 then 
        else
            this.bqAniNum = this.bqAniNum + 1
            if this.bqAniNum > 3 then 
            	 this.bqAniNum = 1
            end   
        end	
       this.playBQ = false
    end

    action:setLastFrameCallFunc(laseCallFuc)
    action:play(name, false)
end

function BattleExpressionManager:playNextBQ()
  	if self.playBQ == true then 
        return
  	end 
  	if #MutableBattleManager.bqList	 > 0 then
        local firstBQ = MutableBattleManager.bqList[1]
        self:showBQAnimation(firstBQ["id"],firstBQ["player_name"])
        table.remove( MutableBattleManager.bqList, 1)
  	end	
end
