
require "BasicLayer"

PlayerCardListLayer = class("PlayerCardListLayer",BasicLayer)
PlayerCardListLayer.__index = PlayerCardListLayer
PlayerCardListLayer.lClass = 3
PlayerCardListLayer.from = nil

function PlayerCardListLayer:init()
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.exploreData = self.rData["rcvData"]["data"]
    self.from = self.rData["rcvData"]["from"]

    local node = cc.CSLoader:createNode("PlayerCardList.csb")
    self.uiLayer:addChild(node,0,1)
    self.exist = true
    self._rootCSbNode = node:getChildByTag(101) 
    --关闭
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
        	self:returnBack(false)
        end
    end
    self._rootCSbNode:addTouchEventListener(touchCallBack)
    self.PanelBG = ccui.Helper:seekWidgetByName(self._rootCSbNode,"PanelBG")
    self.panelSort = ccui.Helper:seekWidgetByName(self.PanelBG,"panelSort")
    if self.from == PlayerInfoSys.EChangeType.changeHead then
        self.panelSort:setVisible(false)
    else
        self.panelSort:setVisible(true)
    end
    self.panelList = ccui.Helper:seekWidgetByName(self._rootCSbNode,"panelList")
    --排序
    self.sortBtnView = SortButtonView.new():init(self.panelSort,"eq_x",213,0)
    self.sortBtnView.sortModeChangedEvent = function()
        self:refresh()
    end
    
    self:initListView()
    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack(false)
    end)
    self:reqHeroList()
end

function PlayerCardListLayer:reqHeroList()
    GameManagerInst:rpc("{\"rpc\":\"hero_list\"}",3,
    function(data)
        --success
        if self.exist == false then
            return
        end
        DataManager:wAllHeroData(data["hero_list"])
        self:refreshListUI()
        --self.hero_list = data_list
    end,
    function(state_code,msgText)
        if self.exist == false then
            return
        end
        GameManagerInst:alert(msgText,function()
            self:returnBack()
        end)
    end,
    true)
end

function PlayerCardListLayer:getDataSource(sort_mode)
    if self.dataSourceEvent then
        return self.dataSourceEvent(self,sort_mode)
    else
        local dataset =  table.deepcopy(hero_list)
        SortBoxView.SortRole (dataset, sort_mode ,false)
        return dataset
    end
end

function PlayerCardListLayer:refresh()
    --先排序，后刷列表  equip_list
    local ds = self:getDataSource(self.sortBtnView:getSortMode())

    self.currentDataSource = ds
    local percent = self.gridview:getCurrentPercent()
    self.gridview:setDataSource(ds)
    self.gridview:jumpToPercent(percent)
end

function PlayerCardListLayer:initListView()
   	local from = self.from
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height, 173,145)
    self.gridview.itemCreateEvent = function()
        local temp = PlayerCardListItem.new():init()
        temp:initFromType(from)
        temp.ClickEvent = function(item)
            self:onItemClicked(item)
        end
        temp.resetDataEvent = function(item)
 			--self:onItemShow(temp)
        end
        return temp
    end
end

--刷新英雄列表
function PlayerCardListLayer:refreshListUI()
    local data = table.deepcopy(hero_list)
    self.gridview:setDataSource(data)
end

--点击列表中的英雄
function PlayerCardListLayer:onItemClicked(item)
    local id = item._data["id"]
    local heroId = getNumID(id)
    if self.from == PlayerInfoSys.EChangeType.changeTJBanNiang then

        if user_info["gallery_icon_id"] ~= heroId then
            self:reqUpdateTujianBanNiang(heroId)
        end
    elseif self.from == PlayerInfoSys.EChangeType.changeHead then
        local player_info = PlayerInfoSys:getInstance():getPersonalInfo()
        if player_info["head_icon_id"]~= heroId then 
            self:reqUpdateHeadImg(heroId)
        end 
    end
end

--更换头像接口
function PlayerCardListLayer:reqUpdateHeadImg(select_id)
    local function ReqSuccess(data)
		--返回 写入内存
        local player_info = PlayerInfoSys:getInstance():getPersonalInfo() 
		player_info["head_icon_id"] = select_id
        SceneManager:showPromptLabel(UITool.ToLocalization("更换头像成功"))

        --同步到user_info，以及聊天系统
        user_info["pl_icon_id"] = select_id
        XBChatSys:getInstance():updateMyUserNameForChat()

		self:returnBack(true)
    end
    
    local cjson = require "cjson"
    self.sManager:createWaitLayer()

    local tempTable = {
        ["rpc"] = "change_pl_icon",
        ["pl_icon_id"] = select_id
    }
    PlayerInfoSys:getInstance():requestUpdateData(tempTable,ReqSuccess)
end

--更换图鉴板娘
function PlayerCardListLayer:reqUpdateTujianBanNiang(select_id)
    local function ReqSuccess(data)
        --返回 写入内存
        user_info["gallery_icon_id"] = select_id
        SceneManager:showPromptLabel(UITool.ToLocalization("更换图鉴板娘成功"))
        self:returnBack(true)
    end
    local tempTable = {
        ["rpc"] = "change_gallery_icon",
        ["gallery_icon_id"] = select_id
    }
    PlayerInfoSys:getInstance():requestUpdateData(tempTable,ReqSuccess)
end

--返回
function PlayerCardListLayer:returnBack(isBackRefsh)
    --如果是派遣返回。舒刷新
    if isBackRefsh then 
        self.backFunc(self.sDelegate)
    end 
    self.exist = false
    self:clearEx()
end

function PlayerCardListLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end

function PlayerCardListLayer:create(rData)
     local layer = PlayerCardListLayer.new()
     layer.rData = rData
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end