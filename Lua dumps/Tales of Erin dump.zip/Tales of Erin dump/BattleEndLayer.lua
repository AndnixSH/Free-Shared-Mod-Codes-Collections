require "BasicLayer"

BattleEndLayer = class("BattleEndLayer",BasicLayer)
BattleEndLayer.__index = BattleEndLayer
BattleEndLayer.lClass = 1
BattleEndLayer.result_data = nil 
BattleEndLayer.oid = nil
BattleEndLayer.mode = 1 -- 1 单人战   2多人战
BattleEndLayer.boxContainer = nil
BattleEndLayer.dropBoxLayer = nil
BattleEndLayer.result = nil
BattleEndLayer.drop_items_list = nil
BattleEndLayer.action_count = 0
local scheduler = cc.Director:getInstance():getScheduler()
local schedulerEntry = nil 
local schedulerEntry_2 = nil 
local temp_tdata = nil 

function BattleEndLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, BattleEndLayer)
    return target
end

function BattleEndLayer:init()

    local node =cc.CSLoader:createNode("BattleEnd_main.csb")
    self.uiLayer:addChild(node,0,2)
    self.exist = true
    --node:setVisible(false)
    self:showDefaultUI(false)
    
    self.MaskPanel = node:getChildByName("Mask_Pop") --纯黑 的遮罩
    self.boxContainer = node:getChildByName("box_container")
    self.result = node:getChildByName("result")
    local bResult = (g_channel_control.bDropBoxNew == true and true) or false
    --self.result:setVisible(not bResult)
    self.boxContainer:setVisible(bResult)

    local boxItemPanel = self.result:getChildByName("ProjectNode_7")
    boxItemPanel:setVisible(not bResult)

    local topguang = node:getChildByName("Top_guang")
    local acAction = cc.CSLoader:createTimeline("Top_guang.csb")
    topguang:runAction(acAction)
    acAction:play("play",true)

    self.mode = self.rData["rcvData"]["mode"]

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
      -- body
        self:keyboardEvent()
    end)

    self:reqResult()

end 
-----------------------
function BattleEndLayer:keyboardEvent( )
  print("keyboardEvent-----------："..tostring(self.keyboardFunc))
  if self.keyboardFunc ~= nil then
    self.keyboardFunc(self)
  end

end
function BattleEndLayer:showDefaultUI(isShow)
    local node = self.uiLayer:getChildByTag(2)
    node:getChildByTag(1132):setVisible(isShow)
    node:getChildByTag(885):setVisible(isShow)
    node:getChildByTag(1):setVisible(isShow)
    node:getChildByTag(2129):setVisible(isShow)
end

-----------------------
--结算第一个页面 角色信息 panel_5
function BattleEndLayer:showRoleMsg()

    --打过一场战斗之后，更改下本地表
    if  cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.FristBattle)~=1 then 
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.FristBattle,1)
    end

    self:showDefaultUI(true)
    local node = self.uiLayer:getChildByTag(2)
    node:setVisible(true)
    --local ky_img = node:getChildByTag(342)  
    local ky_panle = node:getChildByTag(5) 
    ----填充结算人物
    if  self.mode==2 then
      local ky_node = ky_panle:getChildByTag(5005)
        
        for i=1,3 do
           local rankerImg = ky_node:getChildByTag(i)
           if i > #self.resultData["ranker"] then 
              rankerImg:setVisible(false);
           else 
              local  tempData = {
                [1] = self.resultData["ranker"][i]["ranker_name"],
                [2] = "",--hero[self.resultData["ranker"][i]["ranker_icon"]]["hero_nc_icon"],
                [3] = "icons/role/prin_ocp/gzzy_image_0(1).png", --princess_ocp[self.resultData["ranker"][i]["ranker_ps"]]["ps_ocp"],
                [4] = self.resultData["ranker"][i]["ranker_lv"],
                [5] = self.resultData["ranker"][i]["ranker_gx"],
                [6] = self.resultData["ranker"][i]["ranker_dmg"],
                [7] = self.resultData["ranker"][i]["ranker_creator"],
               }

           
                for k,v in pairs(princess_ocp) do 
                    local v1 = v[self.resultData["ranker"][i]["ranker_ps"]]
                    if v1 ~= nil then
                        local v2 = v1["ps_ocp"]
                        if v2 ~= nil and string.len(v2) > 0 then
                            tempData[3] = v2
                            break
                        end
                    end
                end

              local playIcon = rankerImg:getChildByTag(101)
              playIcon:setTexture(tempData[3])
              local rnum = rankerImg:getChildByTag(102)
              rnum:setString(i)

              local lvtext = rankerImg:getChildByTag(103)
              lvtext:setString(tempData[4])
              local gxtext = rankerImg:getChildByTag(104)
              gxtext:setString(tempData[6])
              local dmgtext = rankerImg:getChildByTag(105)
              dmgtext:setString(tempData[5])
              local nametext = rankerImg:getChildByTag(106)
              nametext:setString(tempData[1])

              local creator = rankerImg:getChildByTag(107)
              creator:setVisible(tempData[7])


              if self.resultData["ranker"][i]["ranker_self"] then
                  nametext:setTextColor(cc.c4b(209,205,63,255))
                  rnum:setTextColor(cc.c4b(209,205,63,255))
              end
            end
        end

      for i = 4,21 do
            local ranker = ky_node:getChildByTag(i)

            if i > #self.resultData["ranker"] then
                ranker:setVisible(false)
            else
                ranker:setVisible(true)

                local num = ranker:getChildByName("Num")
                num:setString(""..i)

                local name = ranker:getChildByName("Name")
                name:setString(self.resultData["ranker"][i]["ranker_name"])

                local creat = ranker:getChildByName("Creat")
                creat:setVisible(self.resultData["ranker"][i]["ranker_creator"])

                if self.resultData["ranker"][i]["ranker_self"] then
                    num:setTextColor(cc.c4b(209,205,63,255))
                    name:setTextColor(cc.c4b(209,205,63,255))
                end
            end
      end
    end


    --填充公主
    for k,v in pairs(self.resultData["ps"]) do
        local panel_2 = node:getChildByTag(3)
        local psNode = panel_2:getChildByTag(698)
        -- local imagePanel =  psNode:getChildByTag(1)
        -- local imageView = imagePanel:getChildByTag(101)
        self.oid = k
        --addExp = v["add_exp"]
        local end_pos = string.find(self.oid,'_') - 1
        local gid = string.sub(self.oid,0,end_pos) --流派id
        -- imageView:setUnifySizeEnabled(true)
        -- imageView:loadTexture(princess_ocp[gid][self.oid]["ps_vdraw"])

        local ps_msg = {}

        for k_1,v_1 in pairs(princess_ocp[gid][self.oid]["pas_skill"]) do
            if v_1["sk_unlock_lv"] == v["Lv"] then
                table.insert(ps_msg,{str1=UITool.ToLocalization("解锁了新的加护"),str2=UITool.getUserLanguage(v_1["sk_name"])})
            end
        end

        local psTable = {
              [120] = princess_ocp[gid][self.oid]["ps_name"],
            --   [111] = v["Lv"] - v["add_Lv"],
              [112] = v["Lv"]
        }
        

        local msgPanel = psNode:getChildByTag(1261)
        local nameImg = msgPanel:getChildByTag(110)
        nameImg:setTexture(psTable[120])
        -- local oldLv = msgPanel:getChildByTag(111)
        -- oldLv:setString(psTable[111])
        local newLv = msgPanel:getChildByTag(112)
        newLv:setString(psTable[112])

        local infoMsg = msgPanel:getChildByTag(104)
        for i=1,3 do
          local info_1 = infoMsg:getChildByTag(110+i)
          local info_2 = infoMsg:getChildByTag(120+i)
          if i > #ps_msg then
            info_1:setVisible(false)
            info_2:setVisible(false)
          else
            info_1:setVisible(true)
            info_2:setVisible(true)

            info_1:setString(ps_msg[i].str1)
            info_2:setString(ps_msg[i].str2)
          end
        end
    end

    -- 填充rank 
    if self.resultData["rank_up"]["and_rank"] >0 then
        local  rankTable =nil
        if self.rData["rcvData"]["test"] then
            rankTable = {
               [102] = "搅屎棍",
               [103] = ""..self.resultData["rank_up"]["ap_old"],
               [104] = ""..self.resultData["rank_up"]["ap_max"],
               [105] = ""..self.resultData["rank_up"]["add_gem"],
               [106] = ""..self.resultData["rank_up"]["add_faith"],
               [121] = self.resultData["rank_up"]["rank_new"] - self.resultData["rank_up"]["and_rank"],
               [122] = self.resultData["rank_up"]["rank_new"]
            }
        else
            rankTable = {
               [102] = user_info["name"],
               [103] = ""..self.resultData["rank_up"]["ap_old"],
               [104] = ""..self.resultData["rank_up"]["ap_max"],
               [105] = ""..self.resultData["rank_up"]["add_gem"],
               [106] = ""..self.resultData["rank_up"]["add_faith"],
               [121] = self.resultData["rank_up"]["rank_new"] - self.resultData["rank_up"]["and_rank"],
               [122] = self.resultData["rank_up"]["rank_new"]
            }
        end

        local panel_3 = node:getChildByTag(2)
        local rankNode = panel_3:getChildByTag(511)
        local msgPanel = rankNode:getChildByTag(1214)

        local roleName = msgPanel:getChildByTag(103) 
        if g_channel_control.battleEnd_hideRoleName == true then --韩服去掉角色名显示
            roleName:setVisible(false)
        else
            roleName:setString(rankTable[102])
        end
        local newLv = msgPanel:getChildByTag(122)
        newLv:setString(rankTable[122])
        local infoMsg = msgPanel:getChildByTag(108)
        for i=1,4 do
            local info_1 = infoMsg:getChildByTag(102+i)
            info_1:setString(rankTable[102+i])
        end

    end
    
    self.action_count = 0
    --填充掉落
    local panel_4 = node:getChildByTag(885)
    local rsNode = panel_4:getChildByTag(886)
   --local mulNode = panel_4:getChildByTag(2819)
    --if self.resultData["drop"] ~=nil and self.mode ==1 then
      --rsNode:setVisible(true)
      --mulNode:setVisible(false)
    self.drop_items_list = {}
    --星盘掉落宝箱
    if g_channel_control.bDropBoxNew == true then
       local sortBefore = self.resultData["drop"]
       local sortAfter = self:sortBoxItems(sortBefore)
       self.dropBoxLayer = DropBoxLayer:create(self.boxContainer,sortAfter,self.drop_items_list)
       self.dropBoxLayer:playBoxAnim()
    else
       self:showBoxItems(rsNode)
    end


    --填充升级经验
     local panel_1 = node:getChildByTag(1)
     local lvUpNode = panel_1:getChildByTag(478)
     local lvPanel = lvUpNode:getChildByTag(1)
      
      local function addBar(path)
          local left = cc.ProgressTimer:create(cc.Sprite:create(path))
          left:setType(cc.PROGRESS_TIMER_TYPE_BAR)
          left:setMidpoint(cc.p(0,0))
          left:setBarChangeRate(cc.p(1, 0))
          return left 
      end 
    

      --刷新玩家   
      local rankBar = addBar("n_UIShare/battleEnd/zdjs_ui_001.png")
      local imageView = lvPanel:getChildByTag(101)
      rankBar:setPosition(imageView:getPositionX(), imageView:getPositionY())
      imageView:setVisible(false)
      lvPanel:addChild(rankBar)

      local rank_handle = nil

      rankBar:setPercentage(100 * self.resultData["rank_up"]["rank_old_exp"]/self.resultData["rank_up"]["rank_old_max"])
      local psExp = lvPanel:getChildByTag(103)
      local psExp_str = string.format(UITool.ToLocalization("等级:%d"),self.resultData["rank_up"]["rank_new"])
      psExp:setString(string.format(UITool.ToLocalization("等级:%d"),(self.resultData["rank_up"]["rank_new"] - self.resultData["rank_up"]["and_rank"])))
      local rank_add_exp = self.resultData["rank_up"]["aad_rank_exp"] --增加经验
      local rank_now_exp = self.resultData["rank_up"]["rank_old_exp"]  --当前经验
      local rank_now_up_exp = self.resultData["rank_up"]["rank_old_max"] --当前的升级经验
      local rank_up_exp  = self.resultData["rank_up"]["rank_max_exp"]
      local rank_end_exp = self.resultData["rank_up"]["rank_new_exp"]
     
      local rand_add_lv = self.resultData["rank_up"]["and_rank"]

      self.action_count = self.action_count + 1
      rankBar:setTag(100*(rank_end_exp/rank_up_exp))

      if rand_add_lv ==0 then 
         local function stopAction()  
              self.action_count = self.action_count - 1
              -- cc.SimpleAudioEngine:getInstance():stopEffect(rank_handle)
              -- rank_handle = nil
         end  
         rankBar:setPercentage(100*(rank_now_exp/rank_now_up_exp))

         local to1 = cc.ProgressTo:create(2, 100*(rank_end_exp/rank_up_exp))
         local callfunc = cc.CallFunc:create(stopAction)
         local sequence = cc.Sequence:create(to1,callfunc)
         rankBar:runAction(sequence)
      -- rank_handle = cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvuping.mp3", true)

      elseif rand_add_lv == 1 then 
              
         local function stopAction()    
        -- cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false)  
        AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3", 0,false)   
              psExp:setString(string.format(UITool.ToLocalization("等级:%d"),self.resultData["rank_up"]["rank_new"]))
              rankBar:setPercentage(0)
              local to1 = cc.ProgressTo:create(1, 100*(rank_end_exp/rank_up_exp))
              local callfunc = cc.CallFunc:create(function()
                  self.action_count = self.action_count - 1
              -- cc.SimpleAudioEngine:getInstance():stopEffect(rank_handle)
              -- rank_handle = nil
              end)
              local sequence = cc.Sequence:create(to1,callfunc)
              rankBar:runAction(sequence)
         end
         rankBar:setPercentage(100*(rank_now_exp/rank_now_up_exp))
         local to1 = cc.ProgressTo:create(1, 100)
         local callfunc = cc.CallFunc:create(stopAction)
         local sequence = cc.Sequence:create(to1,callfunc)
         rankBar:runAction(sequence)

      -- rank_handle = cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvuping.mp3", true)
      elseif rand_add_lv >1 then 

         local time = 2/rand_add_lv --每次时间
         local fullTimes = rand_add_lv - 1 --0-100 次数
         local count = 0
         local function stopAction()      
        --cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false) 
        AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3", 0,false) 
             count = count + 1 
             if count <= fullTimes then 
                psExp:setString(string.format(UITool.ToLocalization("等级:%d"),(self.resultData["rank_up"]["rank_new"] - self.resultData["rank_up"]["and_rank"] + count)))
                rankBar:setPercentage(0)
                local to1 = cc.ProgressTo:create(time,100)
                local callfunc = cc.CallFunc:create(stopAction)
                local sequence = cc.Sequence:create(to1,callfunc)
                rankBar:runAction(sequence)
             else             
                  psExp:setString(string.format(UITool.ToLocalization("等级:%d"),self.resultData["rank_up"]["rank_new"]))
                  rankBar:setPercentage(0)
                  local to1 = cc.ProgressTo:create(time, 100*(rank_end_exp/rank_up_exp))
                  local callfunc = cc.CallFunc:create(function()
                      self.action_count = self.action_count - 1
              -- cc.SimpleAudioEngine:getInstance():stopEffect(rank_handle)
              -- rank_handle = nil
                  end)
                  local sequence = cc.Sequence:create(to1,callfunc)
                rankBar:runAction(sequence)
             end 
         end 
         local to1 = cc.ProgressTo:create(time, 100)
         local callfunc = cc.CallFunc:create(stopAction)
         local sequence = cc.Sequence:create(to1,callfunc)
         rankBar:runAction(sequence)
      --rank_handle = cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvuping.mp3", true)
        end 



        local psBar = addBar("n_UIShare/battleEnd/zdjs_ui_001.png")
        local imageView = lvPanel:getChildByTag(102)
        psBar:setPosition(imageView:getPositionX(), imageView:getPositionY())
        imageView:setVisible(false)
        lvPanel:addChild(psBar)
        psBar:setPercentage(0)

        local rankExp = lvPanel:getChildByTag(104)
        rankExp:setString("")
        local rankExp_str = "" 
        local ps_handle = nil

    --公主数据 
   if next(self.resultData["ps"]) ~=nil then

    psBar:setPercentage(100 *self.resultData["ps"][self.oid]["old_exp"] /self.resultData["ps"][self.oid]["old_max_exp"])
    
    local ps_add_exp = self.resultData["ps"][self.oid]["add_exp"] --增加经验
    local ps_now_exp = self.resultData["ps"][self.oid]["old_exp"]  --当前经验
    local ps_now_up_exp = self.resultData["ps"][self.oid]["old_max_exp"]   --当前的升级经验
    local ps_up_exp  = self.resultData["ps"][self.oid]["exp_max"]
    local ps_end_exp = self.resultData["ps"][self.oid]["exp"]
    local ps_add_lv = self.resultData["ps"][self.oid]["add_Lv"]
    local ps_lv = self.resultData["ps"][self.oid]["Lv"]
    
    rankExp_str = string.format(UITool.ToLocalization("等级:%d"),ps_lv)
    rankExp:setString(string.format(UITool.ToLocalization("等级:%d"),(ps_lv - ps_add_lv)))

    self.action_count = self.action_count + 1
    psBar:setTag(100*(ps_end_exp/ps_up_exp))

    if ps_add_lv ==0 then 
       local function stopAction()  
            self.action_count = self.action_count - 1
       end  
       psBar:setPercentage(100*(ps_now_exp/ps_now_up_exp))

       local to1 = cc.ProgressTo:create(2, 100*(ps_end_exp/ps_up_exp))
       local callfunc = cc.CallFunc:create(stopAction)
       local sequence = cc.Sequence:create(to1,callfunc)
       psBar:runAction(sequence)

    elseif ps_add_lv == 1 then 
            
       local function stopAction()      
    --cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false)
    AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3", 0,false) 
            rankExp:setString(string.format(UITool.ToLocalization("等级:%d"),ps_lv))
            psBar:setPercentage(0)
            local to1 = cc.ProgressTo:create(1, 100*(ps_end_exp/ps_up_exp))
            local callfunc = cc.CallFunc:create(function()
                self.action_count = self.action_count - 1
            end)
            local sequence = cc.Sequence:create(to1,callfunc)
            psBar:runAction(sequence)
       end
       psBar:setPercentage(100*(ps_now_exp/ps_now_up_exp))
       local to1 = cc.ProgressTo:create(1, 100)
       local callfunc = cc.CallFunc:create(stopAction)
       local sequence = cc.Sequence:create(to1,callfunc)
       psBar:runAction(sequence)

    elseif ps_add_lv >1 then 

       local time = 2/ps_add_lv --每次时间
       local fullTimes = ps_add_lv - 1 --0-100 次数
       local count = 0
       local function stopAction()  
       -- cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false)    
        AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3", 0,false) 
           count = count + 1 
           if count <= fullTimes then 
              rankExp:setString(string.format(UITool.ToLocalization("等级:%d"),(ps_lv - ps_add_lv + count)))
              psBar:setPercentage(0)
              local to1 = cc.ProgressTo:create(time,100)
              local callfunc = cc.CallFunc:create(stopAction)
              local sequence = cc.Sequence:create(to1,callfunc)
              psBar:runAction(sequence)
           else      
                rankExp:setString(string.format(UITool.ToLocalization("等级:%d"),ps_lv))
                psBar:setPercentage(0)
                local to1 = cc.ProgressTo:create(time, 100*(ps_end_exp/ps_up_exp))
                local callfunc = cc.CallFunc:create(function()
                    self.action_count = self.action_count - 1
                end)
                local sequence = cc.Sequence:create(to1,callfunc)
                psBar:runAction(sequence)
           end 
       end 
       local to1 = cc.ProgressTo:create(time, 100)
       local callfunc = cc.CallFunc:create(stopAction)
       local sequence = cc.Sequence:create(to1,callfunc)
       psBar:runAction(sequence)
      end 
  end
    
    --刷新四个角色信息 
  local role_bar_list = {}

  local temp_list = {}
  local index = 1
   for k,v in pairs(self.resultData["hero"]) do
     temp_list[index] = v
         if temp_list[index]~=nil then 
           temp_list[index]["id"] = k 
           temp_list[index]["hero_rank"] = hero[getNumID(""..k)]["hero_rank"]
           temp_list[index]["hero_atb"] = hero[getNumID(""..k)]["hero_atb"]
           temp_list[index]["hero_name"] = UITool.getUserLanguage(hero[getNumID(""..k)]["hero_name"])--hero[getNumID(""..k)]["hero_name"]
           temp_list[index]["hero_team_icon"] = hero[getNumID(""..k)]["hero_team_icon"]
           index = index +1
         end 
   end

    for i=1,4 do 
        --获取队伍列表中数据
       
          if next(temp_list) ~=nil then

           if temp_list[i]~=nil then

               local r_node = lvPanel:getChildByTag(110+i)            
               local panel_1 =r_node:getChildByTag(1)
               local h_id_str = getStrID( temp_list[i]["id"] )  
               local h_id_num = getNumID( temp_list[i]["id"] )


               local dataTable = {
                [101] = temp_list[i]["hero_team_icon"], --图片
                [103] = getEquipAtb(temp_list[i]["hero_atb"]), --属性
                [102] = Rarity_Hero_Frame[temp_list[i]["hero_rank"]],--外框
                --[104] = getRoleJob(hero[h_id_num]["hero_job"])
               }

              if g_channel_control.b_LikeState then
                local intimacyAddExp = tonumber(temp_list[i]["like_feeling"]["add_exp"])

                if intimacyAddExp > 0 then
                  local effectPos = panel_1:getChildByTag(2350)

                  local effectFile = "Resources/armatures/intimacy/gong_ming_jie_suan/gong_ming_jie_suan.atlas" --特效资源路径

                  effectPos:removeAllChildren()
                  if cc.FileUtils:getInstance():isFileExist(effectFile) then
                      local end_pos = string.find(effectFile,'atlas') - 1
                      local spName = string.sub(effectFile,0,end_pos)
                      local effectSp = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
                      local rps = effectPos:getSize()
                      effectSp:setPosition(cc.p(rps.width / 2, rps.height / 2))
                      effectSp:setScale(1)
                      effectPos:addChild(effectSp,0,123)
                      effectSp:setAnimation(1, "effect", false)
                  end
                end

                local intimacyState = temp_list[i]["like_feeling"]["icon_state"]

                local intimacy = like_state[intimacyState].icon_min --亲密度
                if intimacy then
                  local imgIntimacy = panel_1:getChildByTag(2305)
                  if imgIntimacy then
                    imgIntimacy:setTexture(intimacy)
                  end
                end

                local effectIconFile = like_state[intimacyState].special_effect --特效资源路径
                if effectIconFile ~= "" then
                  local effectIconPos = panel_1:getChildByTag(2304)
                  effectIconPos:removeAllChildren()
                  if cc.FileUtils:getInstance():isFileExist(effectIconFile) then
                      local end_pos = string.find(effectIconFile,'atlas') - 1
                      local spName = string.sub(effectIconFile,0,end_pos)
                      local effectIconSp = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
                      local rps = effectIconPos:getSize()
                      effectIconSp:setPosition(cc.p(rps.width / 2, rps.height / 2))
                      effectIconSp:setScale(1)
                      effectIconPos:addChild(effectIconSp,0,123)
                      effectIconSp:setAnimation(1, "effect", true)
                  end
                end
              end

               
               for i=1,3 do
                   local imageView = panel_1:getChildByTag(100+i)
                   --imageView:setAnchorPoint(cc.p(0,0))
                   imageView:setUnifySizeEnabled(true)
                   imageView:loadTexture(dataTable[100+i])
               end
               --panel_1:setScale(0.8)
                --经验条
                local rolebg = panel_1:getChildByTag(105)
                rolebg:setTexture(Rarity_Team_BG[temp_list[i]["hero_rank"]])

                local add_exp =  temp_list[i]["add_exp"] --增加经验
                local now_exp = temp_list[i]["old_exp"]  --当前经验
                local up_exp  = hero_upgrade[h_id_num][temp_list[i]["Lv"]-temp_list[i]["add_Lv"]][1]
                local end_exp = temp_list[i]["exp"]
                --print("增加经验:"..add_exp.."  当前经验:"..now_exp.." 升级经验:"..up_exp.."最终经验:"..end_exp)
                local textExp = r_node:getChildByTag(121) 
                textExp:setString(string.format(UITool.ToLocalization("等级:%d"),(temp_list[i]["Lv"]-temp_list[i]["add_Lv"])))
                local bar = addBar("n_UIShare/battleEnd/zdjs_ui_005.png")
                local imageView = r_node:getChildByTag(120)
                bar:setPosition(imageView:getPositionX(),imageView:getPositionY())
                r_node:addChild(bar)
        
                local roleobj = {}
                roleobj.bnode=bar
                roleobj.tnode=textExp
                roleobj.text=string.format(UITool.ToLocalization("等级:%d"),temp_list[i]["Lv"])
                roleobj.role_handle = nil

                table.insert(role_bar_list,roleobj)
                self.action_count = self.action_count + 1
                local nowmakexp = hero_upgrade[h_id_num][temp_list[i]["Lv"]][1]
                bar:setTag(100*(end_exp/nowmakexp))

                --判断是否升级  没升级  升一级 升多级 
                local add_lv = temp_list[i]["add_Lv"]
                if add_lv ==0 then 
                   
                   local function stopAction()  
                        self.action_count = self.action_count - 1
                   end  
                   bar:setPercentage(100*(now_exp/up_exp))

                   local to1 = cc.ProgressTo:create(2, 100*(end_exp/up_exp))
                   local callfunc = cc.CallFunc:create(stopAction)
                   local sequence = cc.Sequence:create(to1,callfunc)
                   bar:runAction(sequence)

                elseif add_lv == 1 then 
                        
                   local function stopAction()           
                       --add_exp = add_exp - (up_exp-now_exp)  --剩余经验
                       up_exp = hero_upgrade[h_id_num][temp_list[i]["Lv"]][1]  
                       textExp:setString(string.format(UITool.ToLocalization("等级:%d"),temp_list[i]["Lv"]))
                       bar:setPercentage(0)
                       local to1 = cc.ProgressTo:create(1, 100*(end_exp/up_exp))
                        local callfunc = cc.CallFunc:create(function()
                                self.action_count = self.action_count - 1
                        end)
                        local sequence = cc.Sequence:create(to1,callfunc)
                       bar:runAction(sequence)
 --    cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false)
 AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3",0, false)
                   end
                   bar:setPercentage(100*(now_exp/up_exp))
                   local to1 = cc.ProgressTo:create(1, 100)
                   local callfunc = cc.CallFunc:create(stopAction)
                   local sequence = cc.Sequence:create(to1,callfunc)
                   bar:runAction(sequence)

                elseif add_lv >1 then 

                   local time = 2/add_lv --每次时间
                   local fullTimes = add_lv - 1 --0-100 次数
                   local count = 0
                   local function stopAction()      
                       count = count + 1 
                    --    add_exp = add_exp - (up_exp-now_exp)
                    --    now_exp = 0
    --cc.SimpleAudioEngine:getInstance():playEffect("music/ui/lvupfull.mp3", false)
    AudioManager:shareDataManager():playMusic("music/ui/lvupfull.mp3",0, false)
                       if count <= fullTimes then 
                        --   up_exp = hero_upgrade[h_id_num][temp_list[i]["Lv"]-temp_list[i]["add_Lv"]+count][1]
                                textExp:setString(string.format(UITool.ToLocalization("等级:%d"),(temp_list[i]["Lv"]-temp_list[i]["add_Lv"]+count)))
                          bar:setPercentage(0)
                          local to1 = cc.ProgressTo:create(time,100)
                          local callfunc = cc.CallFunc:create(stopAction)
                          local sequence = cc.Sequence:create(to1,callfunc)
                          bar:runAction(sequence)
                       else 
                          --add_exp = add_exp - (up_exp-now_exp)  --剩余经验
                          up_exp = hero_upgrade[h_id_num][temp_list[i]["Lv"]][1]     
                                textExp:setString(string.format(UITool.ToLocalization("等级:%d"),temp_list[i]["Lv"]))
                          bar:setPercentage(0)
                          local to1 = cc.ProgressTo:create(time, 100*(end_exp/up_exp))
                        local callfunc = cc.CallFunc:create(function()
                                self.action_count = self.action_count - 1
                        end)
                        local sequence = cc.Sequence:create(to1,callfunc)
                          bar:runAction(sequence)
                       end 
                   end 
                   bar:setPercentage(100*(now_exp/up_exp))
                   local to1 = cc.ProgressTo:create(time, 100)
                   local callfunc = cc.CallFunc:create(stopAction)
                   local sequence = cc.Sequence:create(to1,callfunc)
                   bar:runAction(sequence)

                end 
             else 
              local r_node = lvPanel:getChildByTag(110+i) 
              r_node:setVisible(false)
             end 
          end
    end 

    local function changePanel()
        --停止所有特效，界面复位
        --rank经验
        --公主经验
        --4个角色经验
        --16个箱子

        psExp:setString(psExp_str)
        rankExp:setString(rankExp_str)

        -- if ps_handle ~= nil then
        --     cc.SimpleAudioEngine:getInstance():stopEffect(ps_handle)
        --     ps_handle = nil
        -- end

        -- if rank_handle ~= nil then
        --     cc.SimpleAudioEngine:getInstance():stopEffect(rank_handle)
        --     rank_handle = nil
        -- end


        if rankBar ~= nil then
            local p = rankBar:getTag()
            rankBar:stopAllActions()
            rankBar:setPercentage(p)
        end

        if psBar ~= nil then
            local p = psBar:getTag()
            psBar:stopAllActions()
            psBar:setPercentage(p)
        end

        for i = 1,#role_bar_list do
            local obj = role_bar_list[i]
            local bar = obj.bnode
            local p = bar:getTag()
            bar:stopAllActions()
            bar:setPercentage(p)
            
            local t = obj.tnode
            t:setString(obj.text)

            -- if obj.role_handle ~= nil then
            --     cc.SimpleAudioEngine:getInstance():stopEffect(obj.role_handle)
            --     obj.role_handle = nil
            -- end
        end
        -- if g_channel_control.bDropBoxNew == true then
        --     --self.dropBoxLayer:stopBoxAnim()
        --     -- if self.dropBoxLayer.stopBoxAnim then
        --     --    self.dropBoxLayer:stopBoxAnim()
        --     -- end
        -- else
        --    for i = 1,#self.drop_items_list do
        --       local item_Node = self.drop_items_list[i]
        --       item_Node:stopAllActions()
        --       item_Node:getChildByTag(2):setVisible(false)
        --       item_Node:getChildByTag(1):setOpacity(255) 
        --    end
        -- end
        for i = 1,#self.drop_items_list do
            local item_Node = self.drop_items_list[i]
            item_Node:stopAllActions()
            item_Node:getChildByTag(2):setVisible(false)
            item_Node:getChildByTag(1):setOpacity(255) 
        end
        self.action_count = 0
        BOX_EFF_COUNT = 0
    end 

    -- local total_time = 0 
    -- local function unpause(time)
          
    --       total_time = total_time + 0.2 
    --       if total_time > 4 then 
    --          total_time =0
    --          changePanel()
    --       end 
    -- end
    -- schedulerEntry= scheduler:scheduleScriptFunc(unpause,0.2, false)
    
    local panel_touch = node:getChildByName("Panel_touch")

    local function roleMsgCallfunc( )
        if g_channel_control.bDropBoxNew == true then
           self.action_count = BOX_EFF_COUNT
        end
        if self.action_count > 0 then            
            changePanel()
        elseif self.resultData["level_drop"] ~= nil and #self.resultData["level_drop"] > 0 and not self.showed_level_drop then
            self.showed_level_drop = true
            local sData = self.resultData["level_drop"]
            for i=1,#self.resultData["level_drop"] do
                self:showComInfo(
                    sData[i]["type"],
                    sData[i]["id"],
                    sData[i]["num"],
                    sData[i]["real_id"])
            end

        else  --进行下一阶段
            panel_touch:addTouchEventListener(function() end)

            for i = 1,#self.drop_items_list do
                local item_Node = self.drop_items_list[i]
                item_Node:getChildByName("panel_touch"):setTouchEnabled(false)
            end
            --if self.resultData["rank_up"]["and_rank"] > 0 then 
            self.keyboardFunc = nil

            self:showPlayerUp()
            --     print("人物rank升级")
            -- else  
            --     self:showRankers()
            --     print("显示多人战排名")
            -- end 
        end 
    end

    self.keyboardFunc = roleMsgCallfunc

    local function intoCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            roleMsgCallfunc()
        end
     end
    panel_touch:setTouchEnabled(false)
    panel_touch:addTouchEventListener(intoCallBack)

    local dt = cc.DelayTime:create(0.3)
    local cf = cc.CallFunc:create(function()
        panel_touch:setTouchEnabled(true)
    end)
    local seq = cc.Sequence:create(dt,cf)
    panel_touch:runAction(seq)


end 

function BattleEndLayer:sortBoxItems( data )
  -- body
    local sortData = data or {}
    table.sort(sortData, function(a, b)
        if type(a["sp_type"]) == "number" and type(b["sp_type"]) == "number" then
            return a["sp_type"] < b["sp_type"]
        else
            return tostring(a["sp_type"]) < tostring(b["sp_type"])
        end
    end)
    return sortData
end

function BattleEndLayer:showBoxItems( rsNode )
  -- body
  for i=1,16 do
      local reItem = rsNode:getChildByTag(i)

       if i > #self.resultData["drop"] then 
            reItem:setVisible(false)
       else

            local reTable = {
            [14] = "x"..self.resultData["drop"][i]["num"]
            }
            local aniTypeNum = 0
            local itemID = self.resultData["drop"][i]["id"] 
            if self.resultData["drop"][i]["type"] == 3 then  --装备
                aniTypeNum = equip[itemID]["equip_rank"]
                reTable[12] = equip[itemID]["equip_list_icon"]
                reTable[11] = Rarity_E_BG[aniTypeNum]
                reTable[14] = ""
                reTable[10] = ATB_Icon[equip[itemID].equip_atb]
                reTable[13] = Rarity_Icon[aniTypeNum]
            elseif self.resultData["drop"][i]["type"] == 4 then --英雄
                aniTypeNum = hero[itemID]["hero_rank"]
                reTable[13] = Rarity_Icon[hero[itemID]["hero_rank"]]
                reTable[12] = hero[itemID]["hero_list_icon"]
                reTable[10] = ATB_Icon[hero[itemID]["hero_atb"]]   --属性
                reTable[11] = Rarity_BG[aniTypeNum]
            elseif self.resultData["drop"][i]["type"] == 5 then
                aniTypeNum = mat[itemID]["rarity"]
                reTable[12] = "icons/mat/"..mat[itemID]["icon"]
                reTable[11] = Rarity_BG[aniTypeNum]          
                reTable[13] = Rarity_mat[aniTypeNum]
            elseif self.resultData["drop"][i]["type"] == 6 then--可使用道具
                aniTypeNum = useprop[itemID]["rarity"]  --品质
                reTable[13] = Rarity_mat[useprop[itemID]["rarity"]] --  --框  1
                reTable[12] = "icons/mat/"..useprop[itemID]["icon"]  --icon 2  
                reTable[11] = Rarity_BG[aniTypeNum]  --beijing  4
            elseif self.resultData["drop"][i]["type"] == 1 then --金币
                aniTypeNum = 3     
                reTable[12] = Coin_Icon[1]--"uifile/n_UIShare/mail/ggsc_ui_217.png"   
                reTable[11] = Rarity_BG[aniTypeNum]
                reTable[13] = Rarity_mat[aniTypeNum]  
            elseif self.resultData["drop"][i]["type"] == 2 then  --石头
                aniTypeNum = 5     
                reTable[12] = Coin_Icon[5]--"uifile/n_UIShare/mail/ggsc_ui_217.png"   
                reTable[11] = Rarity_BG[aniTypeNum]
                reTable[13] = Rarity_mat[aniTypeNum]  
            elseif g_channel_control.b_drop_cangyu == true and self.resultData["drop"][i]["type"] == 13 then
              aniTypeNum = 4    
              reTable[12] = Coin_Icon[8]--"uifile/n_UIShare/mail/ggsc_ui_217.png"   
              reTable[11] = Rarity_BG[aniTypeNum]
              reTable[13] = Rarity_mat[aniTypeNum]  
            end 

            if aniTypeNum == nil or aniTypeNum < 1 or aniTypeNum > 5 then
              aniTypeNum = 3
            end


            local rsPanel = reItem:getChildByTag(1)

            local imgNew = rsPanel:getChildByTag(407)

            self.resultData["drop"][i]["new"]  = self.resultData["drop"][i]["new"]  or 0
            
            if self.resultData["drop"][i]["new"] == 1 then
              imgNew:setVisible(true)
            else
              imgNew:setVisible(false)
            end

            local  num = rsPanel:getChildByTag(14)
            num:setString(reTable[14])

            local eleAtb = rsPanel:getChildByTag(1872)
            if reTable[10] ~= nil then
              eleAtb:setTexture(reTable[10])
            else
              eleAtb:setVisible(false)
            end

            if reTable[11] ~= nil then
              local bgImg = rsPanel:getChildByTag(11)
              bgImg:setUnifySizeEnabled(true)
              bgImg:loadTexture(reTable[11])
            end

            local  infoImg = rsPanel:getChildByTag(12)
            infoImg:setUnifySizeEnabled(true)
            infoImg:loadTexture(reTable[12])
            local  raImg = rsPanel:getChildByTag(13)
            raImg:setUnifySizeEnabled(true)
            raImg:loadTexture(reTable[13])

            local rsCreator = rsPanel:getChildByTag(15)
              
            local aniType = "hong"  --1 红 2 金 3 银 4 铜

            rsCreator:setString("")
      
            if self.resultData["drop"][i]["sp_type"] == 1 then  --创建者奖励
              --rsCreator:setString("创建者")
            elseif self.resultData["drop"][i]["sp_type"] == 2 then  --贡献奖励
              --rsCreator:setString("贡献")
            else --if self.resultData["drop"][i]["sp_type"] == 3 then --普通奖励
              --rsCreator:setString("")
              if aniTypeNum == 5 then
                  aniType = "jin"
              elseif aniTypeNum == 4 then
                  aniType = "yin"
              else
                  aniType = "tong"
              end
            end
    
            local show_type = self.resultData["drop"][i]["type"]
            local show_id = self.resultData["drop"][i]["id"]
            local show_num = self.resultData["drop"][i]["num"]
            local real_id = self.resultData["drop"][i]["real_id"]

            local item_panel_touch = reItem:getChildByName("panel_touch")
            item_panel_touch:addTouchEventListener(function(sender,eventType)
                  if eventType == ccui.TouchEventType.ended and self.action_count == 0 then
                      self:showComInfo(
                          show_type,
                          show_id,
                          show_num,
                          real_id)
                  end
            end)

          --播放动画
            local delay = cc.DelayTime:create(i*0.3)
            local action_2 = cc.CSLoader:createTimeline("BattleEnd_item.csb")
            action_2:setLastFrameCallFunc(function()
                self.action_count = self.action_count - 1
            end)
            reItem:runAction(action_2)
            action_2:play(aniType, false)
            action_2:pause()

            local playanime = cc.CallFunc:create(function ()
                action_2:resume()
            --cc.SimpleAudioEngine:getInstance():playEffect("music/ui/boxopeneff.mp3", false)  
            AudioManager:shareDataManager():playMusic("music/ui/boxopeneff.mp3", 0,false)
            end)

            local sequence = cc.Sequence:create(delay,playanime)
            table.insert(self.drop_items_list,reItem)
            self.action_count = self.action_count + 1
            reItem:setVisible(true)
            reItem:runAction(sequence)

        end
    end 
end

--结算第二个界面 某个角色升级 panel_3
function BattleEndLayer:showRoleUp()

    local node = self.uiLayer:getChildByTag(2)
    local panel_3 = node:getChildByTag(4)
    panel_3:setVisible(true) 
    panel_3:setTouchEnabled(false)

    local teamIdx = cc.UserDefault:getInstance():getIntegerForKey("teamIdx")
    if teamIdx ==nil or teamIdx <1 then 
        teamIdx =1 
    end 

    if self.rData["rcvData"]["test"] then
        team_list = {}
        temp_list[tostring(teamIdx)] = {}
        temp_list[tostring(teamIdx)]["team"] = {}
        local nnn = 1
        for k,v in pairs(self.resultData["hero"]) do 
            temp_list[tostring(teamIdx)]["team"][nnn] = k
            nnn = nnn + 1
        end

        for ii = nnn,4 do
            temp_list[tostring(teamIdx)]["team"][ii] = "0"
        end
    end

    local function rfsRoleUp(h_id,i,k)
        local roleNode = panel_3:getChildByTag(526)
        local dataTable = nil

    if self.rData["rcvData"]["test"] then
        dataTable = {
          [301] = hero[h_id].hero_vcw_icon, --角色立绘
          [111] = 1,  --等级
          [115] = 1, --攻击
          [113] = 1,  --生命
          [112] = 1 + self.resultData["hero"][k]["add_Lv"], --等级
          [116] = hero_upgrade[h_id][ 1 + self.resultData["hero"][k]["add_Lv"]][3], --攻击
          [114] = hero_upgrade[h_id][ 1 + self.resultData["hero"][k]["add_Lv"]][2], --生命
          [117] = 1,
          [118] = hero_upgrade[h_id][ 1 + self.resultData["hero"][k]["add_Lv"]][4],
        }
    else

        dataTable = {
          [301] = hero[h_id].hero_vcw_icon, --角色立绘
          [111] = user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].Lv,  --等级
          [115] = user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].atk, --攻击
          [113] = user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].hp,  --生命
          [112] = user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].Lv + self.resultData["hero"][k]["add_Lv"], --等级
          [116] = hero_upgrade[h_id][ user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].Lv + self.resultData["hero"][k]["add_Lv"]][3], --攻击
          [114] = hero_upgrade[h_id][ user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].Lv + self.resultData["hero"][k]["add_Lv"]][2], --生命
          [117] = user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].def,
          [118] = hero_upgrade[h_id][ user_info["hero"][team_list[tostring(teamIdx)]["team"][i]].Lv + self.resultData["hero"][k]["add_Lv"]][4],
        }
        end
        roleNode:stopAllActions()
        local imgPanle = roleNode:getChildByTag(1)
        local imageView = imgPanle:getChildByTag(102)
        imageView:setUnifySizeEnabled(true)
        imageView:loadTexture(dataTable[301])
  
        local infoPanle = roleNode:getChildByTag(1639)
        for i=1,8 do 
             local text = infoPanle:getChildByTag(110+i)
             text:setString(dataTable[110+i])
        end 

        
        local function showCallBack() 
              local action = cc.CSLoader:createTimeline("BattleEnd_RoleUp.csb")
              roleNode:runAction(action)
              action:play("play2", true)
        end
        local action = cc.CSLoader:createTimeline("BattleEnd_RoleUp.csb")
        action:setLastFrameCallFunc(showCallBack)
        roleNode:runAction(action)
        action:play("play", false)
        
        local action_2 = cc.CSLoader:createTimeline("jiantou.csb")
        local jiantou = infoPanle:getChildByTag(120)
        jiantou:runAction(action_2)
        action_2:play("play", true)

        local function changePanel()
            local function stopAction()
               judgeUp()
               local fadeIn = cc.FadeIn:create(0.25)
               panel_3:runAction(fadeIn)
            end 
             if schedulerEntry~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry)
              schedulerEntry = nil
            end
            if schedulerEntry_2~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry_2)
              schedulerEntry_2 = nil
            end
            panel_3:setTouchEnabled(false)
            total_time =0 
            local fadeOut  = cc.FadeOut:create(0.25)
            local callfunc = cc.CallFunc:create(stopAction)
            local sequence = cc.Sequence:create(fadeOut,callfunc)
            panel_3:runAction(sequence)

        end 

        local total_time = 0 
        local function unpause(time)

             total_time = total_time + 0.2 
             if total_time >2 then 
                panel_3:setTouchEnabled(true)
         
             end 
             if total_time > 5 then 
                total_time = 0 
                changePanel()
             end 
        end


            if schedulerEntry~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry)
              schedulerEntry = nil
            end

        schedulerEntry= scheduler:scheduleScriptFunc(unpause,0.2, false)

        local function intoCallBack(sender,eventType)
            if eventType == ccui.TouchEventType.ended then
               print("点击按钮"..sender:getTag())
               changePanel()
            end
        end
        panel_3:addTouchEventListener(intoCallBack)

    end 

  
    local i = 0
    function judgeUp() --判断队伍中的某一个人是否升级
         i=i+1
         print("i="..i)

         if i > 5  then
            return
         end

         if i==5 then 


             if schedulerEntry~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry)
              schedulerEntry = nil
            end
            if schedulerEntry_2~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry_2)
              schedulerEntry_2 = nil
            end
            if self.resultData["rank_up"]["and_rank"] > 0 then 
                self:showPlayerUp()
                print("人物rank升级")
            elseif self.resultData["ps"][self.oid]["add_Lv"] > 0 then 
                self:showPSUp()
            else  
                 self:showRankers()
                 print("显示多人战排名")
            end 
            return 
         end

         if team_list[tostring(teamIdx)]["team"][i]=="0" then 
             judgeUp()
              print("角色不存在跳过")
         else 

             --首先找到在结算里面那个人的id
            for k,v in pairs(self.resultData["hero"]) do 
                if team_list[tostring(teamIdx)]["team"][i] == k then 
                   if v["add_Lv"] >0 then
                    local h_id_num = getNumID(k)  
                    rfsRoleUp(h_id_num,i,k)
                    print("查找到有角色升级，显示角色升级信息")
                  else 
                    print("没有查找到有角色升级，继续向下进行判断")
                     judgeUp()
                end  
               end 
            end 
         end 
    end 

    judgeUp()
end 


function BattleEndLayer:showPSUp()
      if self.resultData["ps"]~=nil and 
      self.oid ~= nil and self.resultData["ps"][self.oid]~=nil and 
      self.resultData["ps"][self.oid]["add_Lv"] > 0 then 

    local node = self.uiLayer:getChildByTag(2)
    node:getChildByTag(4):setVisible(false)
    node:getChildByTag(2):setVisible(false)
    local panel_4 = node:getChildByTag(3)
    panel_4:setVisible(true) 
    local roleNode = panel_4:getChildByTag(698)
    -- local function showCallBack() 
    --       local action = cc.CSLoader:createTimeline("BattleEnd_ps.csb")
    --       roleNode:runAction(action)
    --       action:play("play2", true)
    -- end

    -- local action = cc.CSLoader:createTimeline("BattleEnd_ps.csb")
    -- action:setLastFrameCallFunc(showCallBack)
    -- roleNode:runAction(action)
    -- action:play("play", false)
    -- local infoPanle = roleNode:getChildByTag(1261)    
    -- local action_2 = cc.CSLoader:createTimeline("jiantou.csb")
    -- local jiantou = infoPanle:getChildByTag(105)
    -- jiantou:runAction(action_2)
    -- action_2:play("play", true)

    --根据渠道划分是否隐藏神格背景
    local panel_ps = roleNode:getChildByTag(1261)
    if panel_ps ~= nil and g_channel_control.battleEnd_hidePsBg == true then
      local panel_ps_bg = panel_ps:getChildByTag(104)
      if panel_ps_bg ~= nil then
        local bg = panel_ps_bg:getChildByTag(876)
        if bg then
          bg:setVisible(false)
        end
      end
    end
    local anime_play = true

    roleNode:setOpacity(0)
    local to1 = cc.FadeIn:create(1)
    local callfunc = cc.CallFunc:create(function()
        anime_play = false
    end)
    local sequence = cc.Sequence:create(to1,callfunc)
    roleNode:runAction(sequence)


    local panel_touch = node:getChildByName("Panel_touch")

    local function psdupCallfunc()
        if anime_play then
            roleNode:stopAllActions()
            roleNode:setOpacity(255)
            anime_play = false
            print("psdupCallfunc...keyboardFunc.."..tostring(self.keyboardFunc))
        else
          print("psdupCallfunc....keyboardFunc == nil....showRanders")
            self.keyboardFunc = nil
            panel_touch:addTouchEventListener(function() end)
            roleNode:stopAllActions()
            self:showRankers()
        end
    end
    self.keyboardFunc = psdupCallfunc
    print("keyboardFunc.."..tostring(self.keyboardFunc))

    local function intoCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
          psdupCallfunc()
        end
     end

    panel_touch:setTouchEnabled(false)
    panel_touch:addTouchEventListener(intoCallBack)

    local dt = cc.DelayTime:create(0.3)
    local cf = cc.CallFunc:create(function()
        panel_touch:setTouchEnabled(true)
    end)
    local seq = cc.Sequence:create(dt,cf)
    panel_touch:runAction(seq)
    
    else
      self.boxContainer:setVisible(false)
      self:showRankers()
    end
end

function BattleEndLayer:addChapterEvent() --关卡达成打点
  local battleID  = self.rData["rcvData"]["battle_id"]
  if  battleID == nil then
    return
  end
  SysDot:eventChapter(battleID)
end

--A
function BattleEndLayer:addAppsFlyerEvent()
  local current_lv = self.resultData["rank_up"]["rank_new"]
  if current_lv == nil  then
    return
  end
  SysDot:eventLevelAchieved(current_lv, 0)
end

--结算第三个界面 玩家升级 panel_4 
function BattleEndLayer:showPlayerUp()
   
    self:addChapterEvent()

    if self.resultData["rank_up"]["and_rank"] > 0 then 

      self:addAppsFlyerEvent()
      if g_channel_control.openUpdateRoleInfo and SDKManagerLua.updateRoleInfo then
        local current_lv = self.resultData["rank_up"]["rank_new"]
        local data ={
          roleLevel = current_lv
        }

        SDKManagerLua:updateRoleInfo(data)--玩家升级后更新角色信息
      end
      
      local anime_play = true

      local node = self.uiLayer:getChildByTag(2)
      node:getChildByTag(4):setVisible(false)
      local panel_4 = node:getChildByTag(2)
      panel_4:setVisible(true) 
      local roleNode = panel_4:getChildByTag(511)
      -- local function showCallBack() 
      --       local action = cc.CSLoader:createTimeline("BattleEnd_rankUp.csb")
      --       roleNode:runAction(action)
      --       action:play("play2", true)
      -- end

      -- local action = cc.CSLoader:createTimeline("BattleEnd_rankUp.csb")
      -- action:setLastFrameCallFunc(function()
      --     anime_play = false
      -- end)
      -- roleNode:runAction(action)
      -- action:play("play", false)
      -- local infoPanle = roleNode:getChildByTag(1214)    
      -- local action_2 = cc.CSLoader:createTimeline("jiantou.csb")
      -- local jiantou = infoPanle:getChildByTag(123)
      -- jiantou:runAction(action_2)
      -- action_2:play("play", true)

      roleNode:setOpacity(0)
      local to1 = cc.FadeIn:create(1)
      local callfunc = cc.CallFunc:create(function()
          anime_play = false
      end)
      local sequence = cc.Sequence:create(to1,callfunc)
      roleNode:runAction(sequence)

      local panel_touch = node:getChildByName("Panel_touch")
      
      local function playerUpCallfunc( )
          if anime_play then
              print("showPlayerUp......anime_play stop")
              roleNode:stopAllActions()
              roleNode:setOpacity(255)
              anime_play = false
          else
              print("showPlayerUp......showPSUp")
              self.keyboardFunc = nil
              panel_touch:addTouchEventListener(function() end)
              roleNode:stopAllActions()
              --jiantou:stopAllActions()
              self:showPSUp() 

          end
      end

      self.keyboardFunc = playerUpCallfunc
      print("showPlayerUp......"..tostring(self.keyboardFunc))
      local function intoCallBack(sender,eventType)
          if eventType == ccui.TouchEventType.ended then
              playerUpCallfunc()
          end
       end

      panel_touch:setTouchEnabled(false)
      panel_touch:addTouchEventListener(intoCallBack)

      local dt = cc.DelayTime:create(0.3)
      local cf = cc.CallFunc:create(function()
          panel_touch:setTouchEnabled(true)
      end)
      local seq = cc.Sequence:create(dt,cf)
      panel_touch:runAction(seq)
          if GAME_CHANNEL == CHANNEL.Android.CHANNEL_CODE_HW then
              local roleData = {}
              roleData.id = user_info["id"]
              roleData.name = user_info["name"]
              roleData.rank = self.resultData["rank_up"]["rank_new"]
              SDKManagerLua:setRoleData(roleData)
        --- 设置玩家等级提升
          elseif GAME_CHANNEL == CHANNEL.Android.CHANNEL_CODE_CN then
              local roleData = {}
              roleData.rank_new = tonumber(self.resultData["rank_up"]["rank_new"])
              SDKManagerLua:setRoleUpgrade(roleData)
          end
    else

        self:showPSUp()
    end
end 

--结算第四个界面 战利品 panel_6 
function BattleEndLayer:showGoods()

    local node = self.uiLayer:getChildByTag(2)
    node:getChildByTag(1):setVisible(false)
    node:getChildByTag(2):setVisible(false)
    node:getChildByTag(3):setVisible(false)
    node:getChildByTag(4):setVisible(false)

    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            print("点击按钮"..sender:getTag())
            if schedulerEntry~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry)
              schedulerEntry = nil
            end
            if schedulerEntry_2~=nil then
              scheduler:unscheduleScriptEntry(schedulerEntry_2)
              schedulerEntry_2 = nil
            end
            
             self:returnBack()
        end
     end
     

     
    local panel_6 = node:getChildByTag(885)
    local rsNode = panel_6:getChildByTag(886)
    local rsNode_1 = panel_6:getChildByTag(2819)
    panel_6:setVisible(true) 
   local times = 0 
   local times_1 = 0 
  
   local count = #self.resultData["drop"]
     local function touchCallBack_1(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
         if schedulerEntry~=nil then
             scheduler:unscheduleScriptEntry(schedulerEntry)
             schedulerEntry = nil
             end
           for i=1,count do
             local item_Node = rsNode:getChildByTag(i)
             item_Node:stopAllActions()
             item_Node:getChildByTag(2):setVisible(false)
             item_Node:getChildByTag(1):setOpacity(255)  
           end
           local imageView = rsNode:getChildByTag(756)
            imageView:setVisible(true)
            panel_6:addTouchEventListener(touchCallBack)
        end
    end

   if count < 1 then
            local imageView = rsNode:getChildByTag(756)
            imageView:setVisible(true)
            panel_6:addTouchEventListener(touchCallBack)
            return
   end

    panel_6:addTouchEventListener(touchCallBack_1)
   
    
   local function addGoods(num)
    local item_Node = rsNode:getChildByTag(num)
    item_Node:setVisible(true)
    local action_2 = cc.CSLoader:createTimeline("BattleEnd_item.csb")
     item_Node:runAction(action_2)
    action_2:play("play", false)
   end

    local function unpause(time)
  
        if count == 0 then 
            scheduler:unscheduleScriptEntry(schedulerEntry)
            local imageView = rsNode:getChildByTag(756)
            imageView:setVisible(true)
            panel_6:addTouchEventListener(touchCallBack)
            return
        end 
        count = count -1 
        times = times+1
        addGoods(times)
     end
     if schedulerEntry~=nil then
       scheduler:unscheduleScriptEntry(schedulerEntry)
       schedulerEntry = nil
     end
    schedulerEntry= scheduler:scheduleScriptFunc(unpause,0.3, false)

  --end
end 

--第X个界面，显示多人战斗排名
function BattleEndLayer:showRankers()
    if self.mode == 1 then
        self:returnBack()
        return
    end

    local node = self.uiLayer:getChildByTag(2)
    node:getChildByTag(1):setVisible(false)
    node:getChildByTag(2):setVisible(false)
    node:getChildByTag(3):setVisible(false)
    node:getChildByTag(4):setVisible(false)
    node:getChildByTag(885):setVisible(false)
    
    node:getChildByTag(5):setVisible(true)

    local panel_touch = node:getChildByName("Panel_touch")
    
    self.keyboardFunc = self.returnBack

    local function intoCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
                panel_touch:addTouchEventListener(function() end)
                self:returnBack()
        end
     end

    panel_touch:setTouchEnabled(false)
    panel_touch:addTouchEventListener(intoCallBack)

    local dt = cc.DelayTime:create(0.3)
    local cf = cc.CallFunc:create(function()
        panel_touch:setTouchEnabled(true)
    end)
    local seq = cc.Sequence:create(dt,cf)
    panel_touch:runAction(seq)
    
end

function BattleEndLayer:showStory()
    
    local node = self.uiLayer:getChildByTag(2)
    local panel_touch = node:getChildByName("Panel_touch")
    panel_touch:setTouchEnabled(false)
    self.MaskPanel:setVisible(false)
    self.MaskPanel:removeFromParent()
    self.MaskPanel=nil 
    self.resultData["story_after"] = self.resultData["story_after"] or ""
    if self.resultData["story_after"]~= "" then 
       self.sData = {}
       self.sData["filename"] = "story/"..self.resultData["story_after"]..".json"
       self.sData["callFunc"] = function(node)
            -- local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
            -- --todo 停止或者恢复当前音乐
            -- if musicState == 0 then --开启音乐
                
            --     if AudioManager:shareDataManager():getBGId() ~= -1 then 
            --         AudioManager:shareDataManager():resumeBGMusic()
            --     else 
            --         local fullpath = lua_musci["zhuyeBGM"]
            --         AudioManager:shareDataManager():preloadM(fullpath)
            --         AudioManager:shareDataManager():playBGMusic(fullpath, true)
            --     end
            -- end
            self:playEndResultBgMusic() 
            node:showRoleMsg()
       end
       self.sData["obj"] = self 
       self.sManager:toDialogLayer(self.sData)
    else
       self:playEndResultBgMusic() 
       self:showRoleMsg()
    end 
end
--播放结算界面背景音乐
function BattleEndLayer:playEndResultBgMusic()
   local musicState = tonumber(XBConfigManager:getInstance():getGlobalIntegerByKey("Z_MUSIC_STATUE"))
  --todo 停止或者恢复当前音乐
   if musicState == 0 then --开启音乐
      
       if AudioManager:shareDataManager():getBGId() ~= -1 then 
           AudioManager:shareDataManager():resumeBGMusic()
       else 
           local fullpath = lua_musci["zhuyeBGM"]
           AudioManager:shareDataManager():preloadM(fullpath)
           AudioManager:shareDataManager():playBGMusic(fullpath, true)
       end
   end 
end 
-- #back_type 1、多人战创建者、2、多人战参加者 3、活动战创建者、
-- # 4、普通关卡无事件点开启 5、普通关卡有新事件点开启 6、素材狗粮本活动关卡
--7 无新事件点（活动） 8有新事件点（）
--返回
function BattleEndLayer:returnBack()
    if self:triggerGuide() then 
        do return end 
    end 
    --判断是否弹出弹窗
    self.sData = {}
    self.exist = false
    -- local pop = 0
    -- local state = 2
    -- if self.resultData["level_drop"] ~= nil then 
    --    self.sData["complete_reward"] = self.resultData["level_drop"]
    --    pop = 1 
    -- end 
    
   
    -- if pop == 1 then   --临时
    --    print("执行跳转")
    --    self:showComInfo(self.sData["complete_reward"][1]["type"],self.sData["complete_reward"][1]["id"],self.sData["complete_reward"][1]["num"])
    -- end 
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)

    DataManager:battleEnd(self.resultData)
    self.sManager.menuLayer:RefshTopBar()
   

    if self.sManager:getRootNode() ==nil then
        SceneManager.BattleEndLayer  = nil  
        SceneManager:toStartLayer()
        return 
    end 
    --todo 不知道生效不生效，具体原因为找到
    if self.sManager:getRootNode().SMapRefresh == nil then
        SceneManager.BattleEndLayer  = nil  
        SceneManager:toStartLayer()
        return
    end 
    
    self.oid = nil    
     if self.resultData["back_type"]==4 then
       self.sManager:getRootNode():SMapRefresh(2,true, self.resultData["now_event_point"]) 
     elseif self.resultData["back_type"]==5 then
       self.sManager:getRootNode():SMapRefresh(1,true)
     elseif self.resultData["back_type"]==6 then
       self.sManager:getRootNode():SMapRefresh(3,true)   

      elseif self.resultData["back_type"]==1 then
          self.sManager:getRootNode():SMapRefresh()
      elseif self.resultData["back_type"]==2 then
          self.sManager:getRootNode():SMapRefresh()             
      elseif self.resultData["back_type"]==3 then
          self.sManager:getRootNode():SMapRefresh()  
      elseif self.resultData["back_type"]==7 then
          self.sManager:getRootNode():SMapRefresh(2,true, self.resultData["now_event_point"]) 
      elseif self.resultData["back_type"]==8 then
          self.sManager:getRootNode():SMapRefresh(1,true)
      elseif self.resultData["back_type"]==9 then
          self.sManager:getRootNode():SMapRefresh()
      else
          print("error back_type")
          SceneManager.BattleEndLayer  = nil  
          SceneManager:toStartLayer()
      end
     self.sManager.BattleEndLayer  = nil 
      self:clear()
   --end
end
---用于手动删除当前页面
function BattleEndLayer:myClear()
  print("BattleEndLayer:myClear")
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    DataManager:battleEnd(self.resultData)
    self.sManager.menuLayer:RefshTopBar()
    self.sManager.BattleEndLayer  = nil 

    self:clear()
end
--通关奖励窗口
function BattleEndLayer:showComInfo(item_type,item_id,num,real_id)
    if item_type == 3 and real_id ~= nil then 
        GameManagerInst:rpc( 
            {
                rpc = "eq_info",
                eq_id = real_id
            },
            3,
            function(data)
                --success
                local equipInfos = {}
                equipInfos.rsk = data["eq"][real_id].rsk
                MsgManager:showRewardItem(item_type,item_id,num, equipInfos) 
            end,
            function(state_code,msgText)
                --failed
                GameManagerInst:alert(msgText)
            end,
        true)
    else 
         MsgManager:showRewardItem(item_type,item_id,num) 
    end 

end


function BattleEndLayer:reqResult()

     local function reiceResultCallBack(data)
        
        print("收到结算结果")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
        if self.sManager ~= nil then
          self.sManager:delWaitLayer()
        end
        if self.exist == false then
            return
        end
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            self:clear()
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        ------完成当前新手引导 第一次出征结束
        if user_info["guide_id"] == guide_id_config.FB  then 
            NewGuideManager:finshNowGuide()
        end
    -- local path = cc.FileUtils:getInstance():getWritablePath()  
    -- local fname = "battle_single.json"
    -- if self.mode == 2 then
    --     fname = "battle_mul.json"
    -- end  
    -- local file = io.open(path..fname,"w+")
    -- file:write(data:getData())
    -- file:close()
        print("现在所需要的剧情 == "..t_data["data"]["story_after"])
        self.resultData = {}
        --GameManagerInst:saveToFile("battle_single.json",t_data["data"])

        --本地测试用
        --local m_data = self:getJsonData()
        --local t_data = cjsonSafe.decode(m_data)

        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        
        self.resultData = t_data["data"]

        -- --新手引导
        -- self.resultData["trigger_guide"] = {
        --     now_guide_id = TriggerGuideConfig.Star,
        --     unlock_id = TriggerGuideConfig.Star,
        --     guide_ids = {5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22}
        -- } --testCode

        self:showStory()
    end

    local cjson = require "cjson"
    self.sManager:createWaitLayer()


    local tempTable = {
        ["rpc"] = "battle_result",
        ["battle_id"] = self.rData["rcvData"]["battle_id"],
        ["battle_state"] = self.rData["rcvData"]["battle_state"],

    }

    if self.mode==2 then
        tempTable["rpc"] = "multi_result"
    end


    local mydata =  cjson.encode(tempTable)
    print("测试 mydata = "..mydata)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceResultCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

function BattleEndLayer:triggerGuide()
    local result = false
    local data = self.resultData["trigger_guide"]
    if data then 
        XbTriggerGuideManager:updateUserTriggerData(data)
        local unlockID = data.unlock_id 
        if unlockID and unlockID ~= -1 then
            result = XbTriggerGuideManager:startTriggerGuideFormBattle(self)        
        end 
    end
    return result 
end

function BattleEndLayer:triggerBack()
 --判断是否弹出弹窗
    self.sData = {}
    self.exist = false
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    DataManager:battleEnd(self.resultData)
    self.oid = nil    
    self.sManager.BattleEndLayer  = nil 
    self:clear()
end

function BattleEndLayer:getJsonData( ... )
    -- body
    local cjson = require "cjson"
    local filePath =  cc.FileUtils:getInstance():fullPathForFilename("test_conf.json")
    local file = io.open( filePath, "r" )
    local json_data = file:read( "*all" )
    file:close()
    return json_data
end

function BattleEndLayer:create(rData)
     local layer = BattleEndLayer.new()
     layer.rData = rData
     layer.sManager = layer.rData["sManager"]
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end
