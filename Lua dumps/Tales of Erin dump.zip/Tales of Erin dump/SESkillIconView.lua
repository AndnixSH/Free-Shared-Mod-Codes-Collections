--require "XUIView"

SESkillIconView = class("SESkillIconView", XUIView)

SESkillIconView.CS_FILE_NAME = "SESkillIconView.csb"
SESkillIconView.CS_BIND_TABLE = 
{
    panelIcon = "/i:100/i:101",
    iconImage = "/i:100/i:101/i:103"
}
function SESkillIconView:init(rootNode,nSkillId)
    SESkillIconView.super.init(self,rootNode)

    if nSkillId then
        self.curSkillId = nSkillId
    end
    --根据魂灵装技能ID取本地数据
    if passive_sk[self.curSkillId] then
        self.passive_sk_info = passive_sk[self.curSkillId]
        local spPath = passive_sk[self.curSkillId].sk_icon
        print("SoulRoleInfoEquipItemView:RefreshInfo===spPath:"..spPath)
        if spPath then
            self.iconImage:setTexture(spPath)
        end
    end

    return self
end

function SESkillIconView:RefreshIcon(nSkillId)
    if not nSkillId then
        return
    end
    if not self.passive_sk_info then
        return
    end
    
    --魂灵装技能Icon
    local face = self.passive_sk_info["sk_icon"]
    if face then
        self.iconImage:setTexture(face)
    end    
end