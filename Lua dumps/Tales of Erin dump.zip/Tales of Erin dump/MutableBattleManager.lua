MutableBattleManager = class("MutableBattleManager") --全局表 控制整个战斗的UI界面展示

MutableBattleManager.lastTime = 0  --服务器时间，防止http顺序错乱，只刷新比上次记录的服务器时间晚的消息。
MutableBattleManager.bqList = {}

function MutableBattleManager:init()
    self.lastTime = 0
    self.bqList = {}
end

function MutableBattleManager:refeshDate(dataTable)
    if self.lastTime < tonumber( dataTable["server_tm"]) then 
    	self.lastTime = tonumber( dataTable["server_tm"])
    	if tonumber(dataTable["data"]["timeout"]) == 1 then  --战斗超时 
    	   --战斗失败
           battleEndFuncFalse(2,2)
    	   return
    	end 
        if tonumber(dataTable["data"]["boss_state"]) == 1 then  --boss死亡
    	 	--boss死亡，boss血条变空，boss进入死亡
            G_IsMultiBattleWin = true
            G_Monsters[1].attributeManager:setHPForMultiBoss(0)
            G_Monsters[1].fsm:changeState(StateEnum.Dead)
    	 	return
    	end 

	    BattleUIManager:showRanking(dataTable["data"]["gx_rank"]) -- 刷新rank信息
	    BattleUIManager:showAddMembers(dataTable["data"]["add_members"]) --刷新有新角色入场等信息

	     -- 刷新表情
        if dataTable["data"]["expression"]~= nil and #dataTable["data"]["expression"] > 0 then
            for i = 1, #dataTable["data"]["expression"] do
                table.insert( self.bqList,dataTable["data"]["expression"][i])
            end
            BattleUIManager:playNextBQ()
        end
        
        -- 刷新角色数据和boss数据
        BattleRuntimeInfo:onReceiveMsg(dataTable["data"])
    end
end

--G_Test = 1
function MutableBattleManager:sendMultiData(data)
    local function reiceSthCallBack(data)
       
        data = tolua.cast(data, "PassData");
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil or t_data["data"]["state_code"] ~= 1 then
            print("多人战数据出错")
            return
        end 
        self:refeshDate(t_data)
    end

    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]          = "multi_update",
        ["hero_num"]  =  data.hero_num,--当前存活的人数，为了减少服务器的计算，第一次上传时传递队伍内的人数，第二次上传时若与上一次传递的人数没有发生变化则传递-1 若发生变化则传递实际存活玩角色数
        ["multi_id"]  =  data.multi_id,--本场多人战的ID 
        ["update_id"] = tostring(os.date("%Y%m%d%H%M%S", os.time())),
        ["dmg"] = data.dmgForMulti,-- 2秒内造成的总伤害
        ["od_dmg"] = data.odForMulti,-- 2秒内对bossod槽造成的总伤害
        ["bk_dmg"] = data.bkForMulti,-- 2秒内对bossbk槽造成的总伤害
        ["buff_list"] = data.buff_list,-- 2秒内释放的全团共享的buff以及debuff，注：我们角色释放的，从服务器下发过来的不计算入， 具体参考API
        ["dmg_list"] = {}-- 2秒内的伤害记录，具体参考api 
    }

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)


    --[[
    {"data": 
        {
            "boss_state": 0, 
            "gx_rank": [{"player_name": "u_420E6B49E", "rank": 1, "gx": 170470}], 
            "drop": [], 
            "monster_mul": [
                {
                    "m_id": "1", 
                    "hp_max": 694400, 
                    "hp": 525130, 
                    "od": {"od_hp": 90000, "od_n_hp": 33414}, 
                    "bk": {"end_time": -99, "is_add": 0, "interval": 25, "bk_n_hp": 80000, "bk_hp": 80000}, 
                    "debuff": [{"debuff_lv": 11, "id": 82021, "end_time": 71}], 
                    "mode": 0
                }
            ], 
            "timeout": 0, 
            "state_code": 1, 
            "expression": [], 
            "add_members": [], 
            "buff": []
        }, 
            "server_tm": 1535525130
    }
    ]]

    --[[
    --测试
    G_Test = G_Test + 1
    G_Test_MultiUpdate.boss_state = 0
    G_Test_MultiUpdate.gx_rank = {}
    G_Test_MultiUpdate.gx_rank[1] = {}
    G_Test_MultiUpdate.gx_rank[1].player_name = "kobejaw"
    G_Test_MultiUpdate.gx_rank[1].rank = 1
    G_Test_MultiUpdate.gx_rank[1].gx = 666
    G_Test_MultiUpdate.monster_mul = {}
    G_Test_MultiUpdate.monster_mul[1] = {}
    G_Test_MultiUpdate.monster_mul[1].m_id = 1
    G_Test_MultiUpdate.monster_mul[1].hp_max = 694400
    G_Test_MultiUpdate.monster_mul[1].hp = 694400 - G_Test * 1000
    G_Test_MultiUpdate.monster_mul[1].od = {}
    G_Test_MultiUpdate.monster_mul[1].od.od_hp = 90000
    G_Test_MultiUpdate.monster_mul[1].od.od_n_hp = 90000 - G_Test * 2000
    G_Test_MultiUpdate.monster_mul[1].bk = {}
    G_Test_MultiUpdate.monster_mul[1].bk.bk_n_hp = G_Test * 10000
    G_Test_MultiUpdate.monster_mul[1].bk.bk_hp = 80000
    G_Test_MultiUpdate.monster_mul[1].bk.interval = 25
    G_Test_MultiUpdate.monster_mul[1].debuff = {}
    G_Test_MultiUpdate.monster_mul[1].mode = 0

    if G_Test == 5 then
          G_Test_MultiUpdate.monster_mul[1].mode = 1
    else
        G_Test_MultiUpdate.monster_mul[1].mode = 0
    end

    G_Test_MultiUpdate.timeout = 0
    G_Test_MultiUpdate.state_code = 1
    G_Test_MultiUpdate.add_members = {}
    G_Test_MultiUpdate.buff = {}

    BattleRuntimeInfo:onReceiveMsg(G_Test_MultiUpdate)
    ]]
end


function MutableBattleManager:sendBQUpdate(bqID)

    local function reiceSthCallBack(data)
       
        data = tolua.cast(data, "PassData");
        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        if t_data == nil or t_data["data"]["state_code"] ~=1 then           
            --todo 多人战数据发送失败不进行处理
            return
        end 

    end
    local cjson = require "cjson"
    local tempTable = {
        ["rpc"]          = "multi_send_expression",
        ["expression_id"]  =  bqID
    }

    local mydata =  cjson.encode(tempTable)
    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reiceSthCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3) -- 发送表情失败不做处理
end

