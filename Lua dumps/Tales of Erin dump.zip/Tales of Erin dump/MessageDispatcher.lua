--各种消息转发
--created by kobejaw.2018.3.29.
MessageDispatcher = {}--战斗消息转发。（同步）msg是枚举类型就可以了。
TriggerMsgDispatcher = {}--触发器消息转发。（同步）

function MessageDispatcher:dispatchMessage(reciever,msg,sender,delay)
	reciever:onRecieveMessage(msg);
end

function TriggerMsgDispatcher:dispatchTriggerMsg()
	
end