guild_facility={}


guild_facility[1] = {
    des = "56803", -- 设施当前等级的buff描述
    buff_type = 1, -- 设施当前等级的buff类型
    buff_value = 1.0, -- 设施当前等级的buff的加成的值
    lv_up_exp = 120000, -- 设施升级所需经验值
    msg = 0, -- -- 设施等级对应信息
}

guild_facility[2] = {
    des = "56804", -- 设施当前等级的buff描述
    buff_type = 2, -- 设施当前等级的buff类型
    buff_value = 0.1, -- 设施当前等级的buff的加成的值
    lv_up_exp = 400000, -- 设施升级所需经验值
    msg = 0, -- -- 设施等级对应信息
}

guild_facility[3] = {
    des = "56805", -- 设施当前等级的buff描述
    buff_type = 1, -- 设施当前等级的buff类型
    buff_value = 2.0, -- 设施当前等级的buff的加成的值
    lv_up_exp = 960000, -- 设施升级所需经验值
    msg = 0, -- -- 设施等级对应信息
}

guild_facility[4] = {
    des = "56806", -- 设施当前等级的buff描述
    buff_type = 3, -- 设施当前等级的buff类型
    buff_value = 0.15, -- 设施当前等级的buff的加成的值
    lv_up_exp = 1680000, -- 设施升级所需经验值
    msg = 0, -- -- 设施等级对应信息
}

guild_facility[5] = {
    des = "56807", -- 设施当前等级的buff描述
    buff_type = 2, -- 设施当前等级的buff类型
    buff_value = 0.2, -- 设施当前等级的buff的加成的值
    lv_up_exp = 2500000, -- 设施升级所需经验值
    msg = 0, -- -- 设施等级对应信息
}

guild_facility[6] = {
    des = "56808", -- 设施当前等级的buff描述
    buff_type = 3, -- 设施当前等级的buff类型
    buff_value = 0.3, -- 设施当前等级的buff的加成的值
    lv_up_exp = 0, -- 设施升级所需经验值
    msg = 0, -- -- 设施等级对应信息
}
