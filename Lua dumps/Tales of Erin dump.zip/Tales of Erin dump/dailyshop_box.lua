--desc 描述
--desc_simple 引导描述
--sell_type 贩卖类型 0 金币 1 宝石
--sell_num 贩卖获得的道具数量
dailyshop_box = {}   
dailyshop_box[220190101] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "红莲之战鼓",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 10 days continuous purchases.",
    reward = {  
       {
           type=3,--奖励的类型
           id=182220,
           num=1,--奖励的数量
      },                                                          
    }
}    
dailyshop_box[220190102] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "红莲之战鼓",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 20 days continuous purchases.",
    reward = {   
       {
           type=3,--奖励的类型
           id=182220,
           num=1,--奖励的数量
      },                                                         
    }
}    
dailyshop_box[220190201] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "烈風之戰鼓",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 10 days continuous purchases.",
    reward = {    
       {
           type=3,--奖励的类型
           id=182120,
           num=1,--奖励的数量
      },                                                        
    }
}    
dailyshop_box[220190202] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "創世紀.賽特",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 20 days continuous purchases.",
    reward = {     
       {
           type=3,--奖励的类型
           id=181171,
           num=1,--奖励的数量
      },                                                       
    }
}    
dailyshop_box[220190301] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "骇浪之战鼓",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {      
       {
           type=3,--奖励的类型
           id=182320,
           num=1,--奖励的数量
      },                                                      
    }
}    
dailyshop_box[220190302] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "创世器·尤弥尔",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 29 days continuous purchases.",
    reward = {       
       {
           type=3,--奖励的类型
           id=181371,
           num=1,--奖励的数量
      },                                                     
    }
}    
dailyshop_box[220190401] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "好感度戒指*1，天慧果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {        
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },                                                    
    }
}    
dailyshop_box[220190402] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "全村最好的刀（火）*1，强化素材*120",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {         
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },
       {
           type=5,--奖励的类型
           id=612,
           num=120,--奖励的数量
      },                                                   
    }
}    
dailyshop_box[220190501] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "好感度戒指*1，天慧果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {          
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },                                                  
    }
}    
dailyshop_box[220190502] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "全村最好的刀（水）*1，强化素材*120",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {           
       {
           type=3,--奖励的类型
           id=181362,
           num=1,--奖励的数量
      },
       {
           type=5,--奖励的类型
           id=612,
           num=120,--奖励的数量
      },                                                 
    }
}    
dailyshop_box[220190601] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "好感度戒指*1，金暮之刃·格罗明",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {            
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181462,
           num=1,--奖励的数量
      },                                                
    }
}    
dailyshop_box[220190602] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "天慧果实*1，金暮之刃·格罗明",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {             
       {
           type=3,--奖励的类型
           id=181462,
           num=1,--奖励的数量
      },
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },                                               
    }
}    
dailyshop_box[220190701] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "好感度戒指*1，黯曦之刃·布莱兹",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {              
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181562,
           num=1,--奖励的数量
      },                                              
    }
}    
dailyshop_box[220190702] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {               
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },                                             
    }
}    
dailyshop_box[220190801] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "好感度戒指*1，风背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181162,
           num=1,--奖励的数量
      },                                            
    }
}    
dailyshop_box[220190802] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                 
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },                                           
    }
}    
dailyshop_box[220190901] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*2，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                  
       {
           type=5,--奖励的类型
           id=701,
           num=2,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                          
    }
}    
dailyshop_box[220190902] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                   
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                         
    }
}    
dailyshop_box[220191001] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 29 days continuous purchases.",
    reward = {                    
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                        
    }
}    
dailyshop_box[220191002] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 30 days continuous purchases.",
    reward = {                     
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },                                       
    }
}    
dailyshop_box[220191101] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*2，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                      
       {
           type=5,--奖励的类型
           id=701,
           num=2,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                      
    }
}    
dailyshop_box[220191102] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                       
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                     
    }
}    
dailyshop_box[220191201] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                        
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                    
    }
}    
dailyshop_box[220191202] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                         
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },                                   
    }
}    
dailyshop_box[220200101] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                          
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181262,
           num=1,--奖励的数量
      },                                  
    }
}    
dailyshop_box[220200102] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                           
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },                                 
    }
}    
dailyshop_box[220200301] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*3，水背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                            
       {
           type=5,--奖励的类型
           id=701,
           num=3,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181362,
           num=1,--奖励的数量
      },                                
    }
}    
dailyshop_box[220200302] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                             
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },                               
    }
}    
dailyshop_box[220200401] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                              
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181362,
           num=1,--奖励的数量
      },                              
    }
}    
dailyshop_box[220200402] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                               
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181362,
           num=1,--奖励的数量
      },                             
    }
}    
dailyshop_box[220200501] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=1,--奖励的数量
      },                            
    }
}    
dailyshop_box[220200502] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                 
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=1,--奖励的数量
      },                           
    }
}    
dailyshop_box[220200601] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                  
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=1,--奖励的数量
      },                          
    }
}    
dailyshop_box[220200602] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                   
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=1,--奖励的数量
      },                         
    }
}    
dailyshop_box[220200701] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                    
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                        
    }
}    
dailyshop_box[220200702] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                     
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                       
    }
}    
dailyshop_box[220200801] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                      
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                      
    }
}    
dailyshop_box[220200802] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                       
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                     
    }
}    
dailyshop_box[220200901] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                        
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                    
    }
}    
dailyshop_box[220200902] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                         
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                   
    }
}    
dailyshop_box[220201001] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                          
       {
           type=5,--奖励的类型
           id=701,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                  
    }
}    
dailyshop_box[220201002] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                           
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=1,--奖励的数量
      },                 
    }
}    
dailyshop_box[220201101] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                            
       {
           type=5,--奖励的类型
           id=1601,
           num=2,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=1,--奖励的数量
      },                
    }
}    
dailyshop_box[220201102] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                             
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=1,--奖励的数量
      },               
    }
}    
dailyshop_box[220201201] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                              
       {
           type=5,--奖励的类型
           id=1601,
           num=2,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=1,--奖励的数量
      },              
    }
}    
dailyshop_box[220201202] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                               
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=1,--奖励的数量
      },             
    }
}    
dailyshop_box[220210101] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                                
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      },            
    }
}    
dailyshop_box[220210102] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                                 
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181170,
           num=2,--奖励的数量
      },           
    }
}    
dailyshop_box[220210201] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                                  
       {
           type=5,--奖励的类型
           id=1601,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      },          
    }
}    
dailyshop_box[220210202] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                                   
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      },         
    }
}    
dailyshop_box[220210301] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                                    
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=2,--奖励的数量
      },        
    }
}    
dailyshop_box[220210302] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                                     
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=2,--奖励的数量
      },       
    }
}    
dailyshop_box[220210401] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                                      
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      },      
    }
}    
dailyshop_box[220210402] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                                       
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      },     
    }
}    
dailyshop_box[220210501] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                                        
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=2,--奖励的数量
      },    
    }
}    
dailyshop_box[220210502] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                                         
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181270,
           num=2,--奖励的数量
      },   
    }
}    
dailyshop_box[220210601] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_001a.png",
    desc = "天慧的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 15 days continuous purchases.",
    reward = {                                                          
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      },  
    }
}    
dailyshop_box[220210602] = {
    name = "Treasure",
    rarity = 5,
    icon = "ffqd_box_002a.png",
    desc = "觉醒的果实*1，火背水*1",
    desc_simple = "礼包",
    desc_2 = "Free Bonus for 28 days continuous purchases.",
    reward = {                                                           
       {
           type=5,--奖励的类型
           id=702,
           num=1,--奖励的数量
      },
       {
           type=3,--奖励的类型
           id=181470,
           num=2,--奖励的数量
      }, 
    }
}   