--require "XUIView"

NewRoleStateView = class("NewRoleStateView",XUIView)
NewRoleStateView.CS_FILE_NAME = "NewRoleStateView.csb"
NewRoleStateView.CS_BIND_TABLE = 
{
    --state
    stateBG2 = "/s:stateBG2",
    stateHead1 = "/s:stateHead1",
    awk1 = "/i:250/i:493",
    awk2 = "/i:250/i:496",
    awk3 = "/i:250/i:495",
    awk4 = "/i:250/i:494",
    awk5 = "/i:250/i:853",
    lbCurLv = "/i:250/i:492",
    lbExpNext = "/i:250/i:490",
    barExp = "/i:250/i:536",

    stateHead2 = "/s:stateHead2",
    stateGetMethod = "/s:stateHead2/i:253",
    --
    panel_info = "/i:3454",
    --
    barAtk = "/i:3454/i:629",
    barAtkAdd = "/i:3454/i:266",
    barAtkEquip = "/i:3454/i:178",
    barAtkOther = "/i:3454/i:227",
    barHP = "/i:3454/i:628",
    barHpAdd = "/i:3454/i:317",
    barHPEquip = "/i:3454/i:179",
    barHPOther = "/i:3454/i:228",
    barFY = "/i:3454/i:3345",
    barFYAdd = "/i:3454/i:318",
    barFYEquip = "/i:3454/i:3344",
    barFYOther = "/i:3454/i:229",
    --
    numAtk = "/i:3454/i:627",
    numHP = "/i:3454/i:626",
    numFY = "/i:3454/i:3346",
    --
    jobImg = "/i:3454/s:jobImg",  
    jobName = "/i:3454/s:jobName",
    --
    pRoleModel = "/i:3454/i:412",
    --
    spBtnRoleSth = "/s:spBtnRoleSth",
    spBtnRoleSubl = "/s:spBtnRoleSubl",
    spBtnRoleSublText = "/s:spBtnRoleSubl/i:124",
    spBtnRoleSthText = "/s:spBtnRoleSth/i:120",
    spBtnRoleStoryText = "/s:spBtnRoleStory/i:122",
    spBtnRoleStory = "/s:spBtnRoleStory",
    --
    viewsPanel = "/s:ViewsPanel",
    --
    effLevel = "/i:803/s:effLevel",
    --
    panelList = "/i:3454/i:409",
    Btn_com = "/s:Btn_com",
}

function NewRoleStateView:init(hero_id,ReLoadCallFunc,sDelegate)
    NewRoleStateView.super.init(self)
    self.exist = true;
    self.galleryMode = 0
    self.hero_id = hero_id
    ----------
    self.ReLoadCallFunc = ReLoadCallFunc
    self.sDelegate = sDelegate

    self.bHasLoadData = false

    self.views = XUIView.new():init(self.viewsPanel)

    if g_channel_control.transform_NewRoleStateView_spBtnRoleSublText_fontSize == true then
         self.spBtnRoleSublText:setFontSize(20)
    end
   
    if g_channel_control.transform_NewRoleStateView_spBtnRoleSublText_Alignment == true then 
        self.spBtnRoleSublText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.spBtnRoleSublText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.spBtnRoleSublText:ignoreContentAdaptWithSize(false);
        self.spBtnRoleSublText:setTextAreaSize(cc.size(150,64))
        self.spBtnRoleSublText:setPosition(cc.p(83,36))
    end 
    if g_channel_control.transform_NewRoleStateView_spBtnRoleSthText_Alignment == true then 
        self.spBtnRoleSthText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.spBtnRoleSthText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.spBtnRoleSthText:ignoreContentAdaptWithSize(false);
        self.spBtnRoleSthText:setTextAreaSize(cc.size(150,64))
        self.spBtnRoleSthText:setPosition(cc.p(83,36))
    end 
    if g_channel_control.transform_NewRoleStateView_spBtnRoleStoryText_Alignment == true then 
        self.spBtnRoleStoryText:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        self.spBtnRoleStoryText:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
        self.spBtnRoleStoryText:ignoreContentAdaptWithSize(false);
        self.spBtnRoleStoryText:setTextAreaSize(cc.size(160,60))
        self.spBtnRoleStoryText:setPosition(cc.p(83,36))
    end 

    ---
    self.jobImg:setVisible(false)
    self.jobName:setString("")
    --
    self.pRoleModel:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self:swithModelAction()
        end
    end)

    self:InitRoleSthView()
    self:InitRoleAwakenlView()
    self:InitRoleStoryView()
    self:initBtnCom()
    self.spBtnRoleSth:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                self:onClickSth()
            end
        end
    end)
    self.spBtnRoleSubl:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                self:onClickSubl()
            end
        end
    end)
    self.spBtnRoleStory:addTouchEventListener(function(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            local p1 = sender:getTouchBeganPosition()
            local p2 = sender:getTouchEndPosition()

            local l = cc.pGetDistance(p1,p2)
            
            if l < 30 then
                self:onClickStory()
            end
        end
    end)



    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize(self.panelList, psize.width, psize.height,280,40)
    self.gridview.itemCreateEvent = function()
        local temp = NewRoleDataItemView.new():init()
        temp.onResetData = function(self)
            local index = self._data["dataIndex"]
            temp:SetDataIndex(index)
        end
        return temp
    end

    self:refresh()

    self.curTab = 0

    self:setNodeLockState()

    return self
end

function NewRoleStateView:FillHeroData(rcvData,f_call)
    dump(rcvData,"rcvData:")
    self.f_call = f_call
    self.piece_id = rcvData["piece_id"] or -1
    if self.exist == false then
        return
    end
    if rcvData then
        if self.hero_data then--有数据，不是初始化后首次
            if self.hero_id == rcvData.id then--并非切换英雄重获数据
                local nLastLv = self.hero_data.Lv
                local nNewLv = rcvData.Lv
                if nNewLv > nLastLv then--新等级大于老等级：判定为升级(不管升几级，只播放一次升级特效)
                    self:PlayLvUpEffect()
                end
            end
        end
        self.hero_data = nil
        self.hero_data = table.deepcopy(rcvData)
        self.hero_id = self.hero_data.id
        if self.roleSthView then
            self.roleSthView:FillHeroData(rcvData)
        end
        if self.roleAwakenlView then
            self.roleAwakenlView:FillHeroData(rcvData)
        end
        if self.roleStoryView then
            self.roleStoryView:FillHeroData(rcvData)
        end
        self.bHasLoadData = true
        self:refresh()
        self:refreshStaticState()
    end
end

function NewRoleStateView:InitRoleSthView()
    if self.exist == false then
        return
    end
    if not self.hero_id then
        return
    end

    self.roleSthView = NewRoleSthView.new():init(self.hero_id,self.ReLoadCallFunc,self.sDelegate)
    self.views:addSubView(self.roleSthView)
    self.roleSthView:getRootNode():setVisible(false)
end

function NewRoleStateView:InitRoleAwakenlView()
    if self.exist == false then
        return
    end
    if not self.hero_id then
        return
    end

    self.roleAwakenlView = NewRoleAwakenView.new():init(self.hero_id,self.ReLoadCallFunc,self.sDelegate)
    self.views:addSubView(self.roleAwakenlView)
    self.roleAwakenlView:getRootNode():setVisible(false)
end

function NewRoleStateView:InitRoleStoryView()
    if self.exist == false then
        return
    end
    if not self.hero_id then
        return
    end

    self.roleStoryView = NewRoleStoryView.new():init(self.hero_id)
    self.views:addSubView(self.roleStoryView)
    self.roleStoryView:getRootNode():setVisible(false)
end

function NewRoleStateView:refreshBtnState()
end

function NewRoleStateView:onClickSth()
    if self.bHasLoadData then
        self:switchView(1)
    end
end

function NewRoleStateView:onClickSubl()
    if self.bHasLoadData then
        self:switchView(2)
    end
end

function NewRoleStateView:onClickStory()
    if self.bHasLoadData then
        self:switchView(3)
    end
end

function NewRoleStateView:switchView(tab)
    if self.exist == false then
        return
    end
    local num = tab or 0
    if self.curTab ~= num then
    
        local ctls = {
            {btn = self.spBtnRoleSth, view= self.roleSthView},
            {btn = self.spBtnRoleSubl, view= self.roleAwakenlView},
            {btn = self.spBtnRoleStory, view= self.roleStoryView}
        }

        for i = 1,#ctls do  
            ctls[i].btn:loadTexture(ROLE_INFO_BTN_IMG[1])
            ctls[i].btn:getChildByName("lbTitle"):setTextColor(cc.c3b(250, 236, 204))
            if i == num then
                ctls[i].btn:loadTexture(ROLE_INFO_BTN_IMG[2])
                ctls[i].btn:getChildByName("lbTitle"):setTextColor(cc.c3b(160, 210, 227))
            end
            
            ctls[i].view:getRootNode():setVisible(i == num)
        end
        
        self.curTab = num
        self:refresh()
    else
        self:switchView(0)
    end
end

function NewRoleStateView:resetViewsState()
    if self.exist == false then
        return
    end
    local ctls = {
        {btn = self.spBtnRoleSth, view= self.roleSthView},
        {btn = self.spBtnRoleSubl, view= self.roleAwakenlView},
        {btn = self.spBtnRoleStory, view= self.roleStoryView}
    }

    for i = 1,#ctls do  
        ctls[i].btn:loadTexture(ROLE_INFO_BTN_IMG[1])
        ctls[i].btn:getChildByName("lbTitle"):setTextColor(cc.c3b(250, 236, 204))
        ctls[i].view:getRootNode():setVisible(false)
    end
    self.curTab = 0
end

function NewRoleStateView:PlayLvUpEffect()
    if self.exist == false then
        return
    end
    local nodeLvnum = cc.CSLoader:createNode("EffSthLvnum.csb")
    local timelineLvnum = cc.CSLoader:createTimeline("EffSthLvnum.csb")
    local psize3 = self.effLevel:getSize()
    nodeLvnum:setPosition(cc.p(psize3.width / 2,0))
    nodeLvnum:runAction(timelineLvnum)
    self.effLevel:addChild(nodeLvnum,1,123)
    timelineLvnum:play("animation0",false)
end

function NewRoleStateView:swithModelAction()
    if self.exist == false then
        return
    end
    if not self.skeletonNode then return end

    local time_id = getTimeNumID( self.hero_id )
    if time_id == 0 then return end

    if self.modelActionIndex == 1 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "run", true)  
    elseif self.modelActionIndex == 2 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "attack", false)
        self.skeletonNode:addAnimation(1, "loading", true) 
    elseif self.modelActionIndex == 3 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "singleattack", false)
        self.skeletonNode:addAnimation(1, "loading", true)   
    elseif self.modelActionIndex == 4 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "bigskill", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 5 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "up1", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 6 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "up2", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 7 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "behit", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 8 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "float", false)
        self.skeletonNode:addAnimation(1, "loading", true)  
    
    elseif self.modelActionIndex == 9 then
        self.skeletonNode:setToSetupPose()
        self.skeletonNode:clearTracks()
        self.skeletonNode:addAnimation(1, "dead", false)
        self.skeletonNode:addAnimation(1, "loading", true) 
   end
    self.modelActionIndex = self.modelActionIndex + 1
    if self.modelActionIndex > 4 then
        self.modelActionIndex = 1
    end
end

function NewRoleStateView:refreshState()
    if self.exist == false then
        return
    end
    if self.hero_data then
        --有数据        
        local h_id_num = getNumID( self.hero_id )
        local time_id = getTimeNumID( self.hero_id )

        --突破次数
        local break_count = self.hero_data.break_count
        local break_limit = hero[h_id_num]["hero_break"].total_break
        for i = 1,5 do
            if break_count>= i then
                self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_145.png")
            else
                self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
            end
        end
        if g_channel_control.b_Astrolabe then
            if break_limit >= 5 then
                self["awk5"]:setVisible(true)
            else
                self["awk5"]:setVisible(false)
            end
        else
            self["awk5"]:setVisible(false)
        end

        --等级

        local lvcur = self.hero_data.Lv
        local lvmax = self.hero_data.Lv_max
        self.lbCurLv:setString(string.format(UITool.ToLocalization("等级 %d"),lvcur))

        if lvcur >= lvmax  then  --已经满级
            self.barExp:setPercent(100)
            self.lbExpNext:setString("")
        else
            self.barExp:setPercent(100 * self.hero_data.exp / self.hero_data.exp_max)
            self.lbExpNext:setString(string.format(UITool.ToLocalization("离下一级：%d"),(self.hero_data.exp_max - self.hero_data.exp)))
        end
        --属性
        if self.hero_data.base_data and self.hero_data.base_data.atk then
            if self.hero_data.base_data.atk > 0 then
                local patkadd = getRoleATKPrent(self.hero_data.base_data.atk)
                self.barAtk:setPercent(patkadd * 100)
            else
                self.barAtk:setPercent(0)
            end
            --
            if self.hero_data.base_data.hp > 0 then
                local phpadd = getRoleATKPrent(self.hero_data.base_data.hp)
                self.barHP:setPercent(phpadd * 100)
            else
                self.barHP:setPercent(0)
            end
            --
            if self.hero_data.base_data.def > 0 then
                local pdefadd = getRoleATKPrent(self.hero_data.base_data.def)
                self.barFY:setPercent(pdefadd * 100)
            else
                self.barFY:setPercent(0)
            end
        end
        --觉醒
        if self.hero_data.base_data and self.hero_data.hero_add_values then
            if self.hero_data.hero_add_values.atk > 0 then
                local patkadd = getRoleATKPrent(self.hero_data.base_data.atk + self.hero_data.hero_add_values.atk)
                self.barAtkAdd:setPercent(patkadd * 100)
            else
                self.barAtkAdd:setPercent(0)
            end
            --
            if self.hero_data.hero_add_values.hp > 0 then
                local phpadd = getRoleATKPrent(self.hero_data.base_data.hp + self.hero_data.hero_add_values.hp)
                self.barHpAdd:setPercent(phpadd * 100)
            else
                self.barHpAdd:setPercent(0)
            end
            --
            if self.hero_data.hero_add_values.def > 0 then
                local pdefadd = getRoleATKPrent(self.hero_data.base_data.def + self.hero_data.hero_add_values.def)
                self.barFYAdd:setPercent(pdefadd * 100)
            else
                self.barFYAdd:setPercent(0)
            end
        end
        --装备
        if self.hero_data.base_data and self.hero_data.hero_add_values and self.hero_data.eq_data then
            if self.hero_data.eq_data.atk > 0 then
                local patkadd = getRoleATKPrent(self.hero_data.base_data.atk + self.hero_data.hero_add_values.atk + self.hero_data.eq_data.atk)
                self.barAtkEquip:setPercent(patkadd * 100)
            else
                self.barAtkEquip:setPercent(0)
            end
            --
            if self.hero_data.eq_data.hp > 0 then
                local phpadd = getRoleATKPrent(self.hero_data.base_data.hp + self.hero_data.hero_add_values.hp + self.hero_data.eq_data.hp)
                self.barHPEquip:setPercent(phpadd * 100)
            else
                self.barHPEquip:setPercent(0)
            end
            --
            if self.hero_data.eq_data.def > 0 then
                local pdefadd = getRoleATKPrent(self.hero_data.base_data.def + self.hero_data.hero_add_values.def + self.hero_data.eq_data.def)
                self.barFYEquip:setPercent(pdefadd * 100)
            else
                self.barFYEquip:setPercent(0)
            end
        end
        --其他百分比
        if self.hero_data.base_data and self.hero_data.hero_add_values and self.hero_data.eq_data and self.hero_data.other_data then
            if self.hero_data.other_data.atk > 0 then
                local patkadd = getRoleATKPrent(self.hero_data.base_data.atk + self.hero_data.hero_add_values.atk + self.hero_data.eq_data.atk + self.hero_data.other_data.atk)
                self.barAtkOther:setPercent(patkadd * 100)
            else
                self.barAtkOther:setPercent(0)
            end
            --
            if self.hero_data.other_data.hp > 0 then
                local phpadd = getRoleATKPrent(self.hero_data.base_data.hp + self.hero_data.hero_add_values.hp + self.hero_data.eq_data.hp + self.hero_data.other_data.hp)
                self.barHPOther:setPercent(phpadd * 100)
            else
                self.barHPOther:setPercent(0)
            end
            --
            if self.hero_data.other_data.def > 0 then
                local pdefadd = getRoleATKPrent(self.hero_data.base_data.def + self.hero_data.hero_add_values.def + self.hero_data.eq_data.def + self.hero_data.other_data.def)
                self.barFYOther:setPercent(pdefadd * 100)
            else
                self.barFYOther:setPercent(0)
            end
        end

        --重复抽卡加成，变色
        local tempTextColor = cc.c3b(255,255,255)
        local titlename = ""
        if self.hero_data.hero_add > 0 then
            for i = 1,#color_hero_bouns do
                local coloritem = color_hero_bouns[i]
                if self.hero_data.hero_add >= coloritem[1] then
                    tempTextColor = cc.c3b(coloritem[2], coloritem[3], coloritem[4])            
                    if string.len(title_hero_conf[h_id_num]["title"][i]) > 0 then
                        titlename = title_hero_conf[h_id_num]["title"][i].." "
                    else
                        titlename = ""
                    end
                end
            end
        end

        self.numAtk:setTextColor(tempTextColor)
        self.numHP:setTextColor(tempTextColor)
        self.numFY:setTextColor(tempTextColor)
        --
        self.numAtk:setString(self.hero_data.fp_all.atk)
        self.numHP:setString(self.hero_data.fp_all.hp)
        self.numFY:setString(self.hero_data.fp_all.def)
        --
        local critAdd = self.hero_data.fp_all.crit - self.hero_data.crit
        local critAddStr = string.format("%+d%%",critAdd)
        if critAdd <= 0 then
            critAddStr = ""
        end
        local critDmgAdd = self.hero_data.fp_all.crit_dmg - self.hero_data.crit_dmg
        local critDmgAddStr = string.format("%+d%%",critDmgAdd)
        if critDmgAdd <= 0 then
            critDmgAddStr = ""
        end
        local aspAdd = self.hero_data.fp_all.asp - self.hero_data.asp
        local aspAddStr = string.format("%+.2f",(aspAdd/1000))
        if aspAdd == 0 then
            aspAddStr = ""
        end
        local helAdd = self.hero_data.fp_all.hel - self.hero_data.hel
        local helAddStr = string.format("%+d",helAdd)
        if helAdd <= 0 then
            helAddStr = ""
        end

        local pattackRateAdd = 0
        local pattackRateAddStr = string.format("%+d%%",pattackRateAdd)
        if pattackRateAdd <= 0 then
            pattackRateAddStr = ""
        end

        local skDmgAdd = 0
        local skDmgAddStr = string.format("%+d%%",skDmgAdd)
        if skDmgAdd <= 0 then
            skDmgAddStr = ""
        end
        local dmgAdd = 0
        local dmgAddStr = string.format("%+d%%",dmgAdd)
        if dmgAdd <= 0 then
            dmgAddStr = ""
        end
        local atkRateAdd = 0
        local atkRateAddStr = string.format("%+d%%",atkRateAdd)
        if atkRateAdd <= 0 then
            atkRateAddStr = ""
        end
        local hpRateAdd = 0
        local hpRateAddStr = string.format("%+d%%",hpRateAdd)
        if hpRateAdd <= 0 then
            hpRateAddStr = ""
        end
        --
        local addTextColor = cc.c3b(108,215,255)

        local cur_role_data = {
            {   
                dataIndex = 1, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_bj.png",
                dataName = UITool.ToLocalization("暴击"),
                dataNum = self.hero_data.crit.."%", 
                dataNumAdd = critAddStr, 
                dataTextColor = tempTextColor,
            },
            {   
                dataIndex = 2, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_bjsh.png",
                dataName = UITool.ToLocalization("暴击伤害"),
                dataNum = self.hero_data.crit_dmg.."%", 
                dataNumAdd = critDmgAddStr, 
                dataTextColor = tempTextColor,
            },
            {   
                dataIndex = 3, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_gjjg.png",
                dataName = UITool.ToLocalization("攻击间隔"),
                dataNum = self.hero_data.asp/1000, 
                dataNumAdd = aspAddStr, 
                dataTextColor = tempTextColor,
            },
            {   
                dataIndex = 4, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_hfl.png",
                dataName = UITool.ToLocalization("回复力"),
                dataNum = self.hero_data.hel, 
                dataNumAdd = helAddStr, 
                dataTextColor = tempTextColor,
            },
            {   
                dataIndex = 5, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_pgsh.png",
                dataName = UITool.ToLocalization("普攻伤害"),
                dataNum = (table.getValue("self.hero_data", self.hero_data, "fp_all", "pattack_rate") or "0").."%",
                dataNumAdd = nil, 
                dataTextColor = addTextColor,
            },
            {   
                dataIndex = 6, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_gjsh.png",
                dataName = UITool.ToLocalization("技能伤害"),
                dataNum = self.hero_data.fp_all.add_sk_dmg.."%", 
                dataNumAdd = nil, 
                dataTextColor = addTextColor,
            },
            {   
                dataIndex = 7, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_zzsh.png",
                dataName = UITool.ToLocalization("最终伤害"),
                dataNum = self.hero_data.fp_all.add_dmg.."%", 
                dataNumAdd = nil, 
                dataTextColor = addTextColor,
            },
            {   
                dataIndex = 8, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_gjbfb.png",
                dataName = UITool.ToLocalization("攻击百分比"),
                dataNum = self.hero_data.fp_all.atk_rate.."%", 
                dataNumAdd = nil, 
                dataTextColor = addTextColor,
            },
            {   
                dataIndex = 9, 
                dataSpPath = "n_UIShare/role/newrole/sxtb_smbfb.png",
                dataName = UITool.ToLocalization("生命百分比"),
                dataNum = self.hero_data.fp_all.hp_rate.."%", 
                dataNumAdd = nil, 
                dataTextColor = addTextColor,
            },
        }
        self.gridview:setDataSource(cur_role_data)

    else
        for i = 1,5 do
            self["awk"..i]:setTexture("n_UIShare/role/info/ggsc_ui_146.png")
        end

        self.lbCurLv:setString("")
        self.barExp:setPercent(0)
        self.lbExpNext:setString("")
        self.numAtk:setString("")
        self.numHP:setString("")
        self.numFY:setString("")
        self.barAtk:setPercent(0)
        self.barHP:setPercent(0)
        self.barFY:setPercent(0)
        self.barAtkAdd:setPercent(0)
        self.barHpAdd:setPercent(0)
        self.barFYAdd:setPercent(0)  
        self.barAtkEquip:setPercent(0)
        self.barHPEquip:setPercent(0)
        self.barFYEquip:setPercent(0)
        self.barAtkOther:setPercent(0)
        self.barHPOther:setPercent(0)
        self.barFYOther:setPercent(0)
    end
    
end

function NewRoleStateView:refreshStaticState()
    if self.exist == false then
        return
    end
    local time_id = getTimeNumID( self.hero_id )
    local h_id_num = getNumID( self.hero_id )

    if time_id > 10 then
        --已获取时界面状态
        if self.galleryMode ~= 2 then
            self.galleryMode = 2
           
            self.stateHead1:setVisible(true)
            self.stateHead2:setVisible(false)
            self.panel_info:setPosition(852,350)
            self.stateBG2:setTexture("n_UIShare/role/newrole/jsxqjm_ui_002.png")
            --
            self.spBtnRoleSth:setVisible(true)
            self.spBtnRoleSubl:setVisible(true)
            self.spBtnRoleStory:setVisible(true)
            self.Btn_com:setVisible(false)
        end   
    else
        --未获取时界面状态
        if self.galleryMode ~= 1 then
            self.galleryMode = 1
            self.stateHead1:setVisible(false)
            self.stateHead2:setVisible(true)
            self.panel_info:setPosition(852,276)
            self.stateBG2:setTexture("n_UIShare/role/newrole/jsxqjm_ui_007.png")    
            --
            self.spBtnRoleSth:setVisible(false)
            self.spBtnRoleSubl:setVisible(false)
            self.spBtnRoleStory:setVisible(false)
            self.Btn_com:setVisible(true)
        end  
        print("self.piece_id = ",self.piece_id)
        if self.piece_id == -1 then
            self.Btn_com:setTouchEnabled(false)
            self.Btn_com:setBright(false)
        else
            local tab_bag = user_info["bag"]["useprop"]
            if tab_bag and tab_bag[self.piece_id] then
                if tab_bag[self.piece_id]["can_make"] == 1 then
                    self.Btn_com:setTouchEnabled(true)
                    self.Btn_com:setBright(true)
                end
            end
        end     
    end
    self:setNodeLockState()
    ---
    
    local hero_job = hero[h_id_num].hero_job

    if hero_job == 1 then  -- 1  近战
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_098.png")
        self.jobImg:setVisible(true)
    elseif hero_job == 11 then   -- 11 远程 
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_095.png")
        self.jobImg:setVisible(true)
    elseif hero_job == 12 then   -- 12 法师
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_097.png")
        self.jobImg:setVisible(true)
    elseif hero_job == 21 then  -- 21 治疗
        self.jobImg:setTexture("n_UIShare/role/info/jsxq_ui_096.png")
        self.jobImg:setVisible(true)
    else
        self.jobImg:setVisible(false)
    end

    self.jobName:setString(UITool.getUserLanguage(hero[h_id_num].position_name))

    self.stateGetMethod:setString(UITool.getUserLanguage(hero[h_id_num].get_method))   --获取方式

    self.pRoleModel:removeAllChildren()
    self.skeletonNode = nil
    cc.Director:getInstance():getTextureCache():removeUnusedTextures()

    local id_str = hero[h_id_num].hero_bat
    local end_pos = string.find(id_str,'atlas') - 1
    local spName = string.sub(id_str,0,end_pos)

    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end

    self.asyncHandler1 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(spine)
        self.asyncHandler1 = nil
        self.skeletonNode = spine
        
        if self.pRoleModel and tolua.isnull(self.pRoleModel) == false then
            local prmsize = self.pRoleModel:getSize()
            self.pRoleModel:addChild(self.skeletonNode)
            self.skeletonNode:setPosition(prmsize.width/2, 0)
            self.skeletonNode:setAnimation(1, "loading", true)

            self.modelActionIndex = 1

            if time_id == 0 then
                self.skeletonNode:setColor(cc.c3b(0,0,0))
            end
        end

    end)

end

--设置按钮等级解锁状态
function NewRoleStateView:setNodeLockState()
   


    if g_channel_control.UIVersion < 2 then
        local curNodes = {self.spBtnRoleSth, self.spBtnRoleSubl}
        for i=1,#curNodes do
            local config = guide_rank_config["RoleMainView"][i]
            local btn = curNodes[i]
            if config.unlock_level > tonumber(user_info["rank"]) then 
                if config.state == 0 then 
                    btn:setVisible(false)
                end 
            end 
        end

    else
        UnlockSys:getInstance():bindLock(76, self.spBtnRoleSth, true)   
        UnlockSys:getInstance():bindLock(75, self.spBtnRoleSubl, true)
       

    end

end

function NewRoleStateView:refresh()
    if self.exist == false then
        return
    end
    self:refreshState()
end

function NewRoleStateView:DestroyHandle()
    self.exist = false
    self.bHasLoadData = false
    if self.asyncHandler1 then
        self.asyncHandler1:cancel(true)
        self.asyncHandler1 = nil
    end
end

function NewRoleStateView:onNavigateTo(isback)
end

function NewRoleStateView:initBtnCom( ... )
    self.Btn_com:addClickEventListener(function(sender)
        local item_id = getMatID(self.piece_id)
        local tab_bag = user_info["bag"]["useprop"]
        local num = 0
        local can_make = 0
        if tab_bag and tab_bag[self.piece_id] then
            num = tab_bag[self.piece_id]["num"]
            can_make = tab_bag[self.piece_id]["can_make"]
        end
        local a = 
            {
                ["self"]            = self,
                ["sTiem"]           = nil,
                ["item_type"]       = piece[item_id]["type"],
                ["item_id"]         = item_id,
                ["callFunc"]        = self.f_call,
                ["itemNum"]         = num,
                ["refreshTopbar"]   = nil,
                ["can_make"]        = can_make,
            }
        MsgBoxManager:showMsgBox(3,4,a)
    end)
end