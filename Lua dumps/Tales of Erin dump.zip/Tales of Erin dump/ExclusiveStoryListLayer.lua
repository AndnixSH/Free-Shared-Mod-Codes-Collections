--[[
--参数 
--物品item_id  物品item_type
--后期功能扩展，因无法满足。需将 item_type -1 定义为 跳转到指定关卡
--SceneManager:toBattlePassListLayer({item_type = -1, item_id = 'a1_1_1,a1_1_2'})
--]]

--专属剧情选关
--[[
  ExclusiveStoryListLayer.lua
  --暂时复用BattlePassListLayer做修改：后续需将选关功能与选关界面做基类化(TODO)
]]

require "BasicLayer"
ExclusiveStoryListLayer = class("ExclusiveStoryListLayer",BasicLayer)
ExclusiveStoryListLayer.__index = ExclusiveStoryListLayer
ExclusiveStoryListLayer.lClass = 3

ExclusiveStoryListLayer.bReturnShouldRefresh = false

function ExclusiveStoryListLayer:create(rData)
     local layer = ExclusiveStoryListLayer.new()
     layer.rData = rData
     layer.titleNum = 8
     layer.uiLayer = cc.Layer:create()
     layer:init()
     return layer
end

function ExclusiveStoryListLayer:setShow( )
  -- body
    self.sManager.menuLayer:hiddenUserInfo(false)
    self.sManager.menuLayer:RefshTopBar()
end

function ExclusiveStoryListLayer:init()
    self.sDelegate = self.rData["rcvData"]["sDelegate"]
    self.sManager = self.rData["sManager"]
    self.backFunc = self.rData["rcvData"]["sFunc"]
    self.hid = self.rData["rcvData"]["hid"]
    self.hList = self.rData["rcvData"]["hList"]
    self.team_id = self.rData["rcvData"]["team_id"]
   
    self.sManager.menuLayer:hiddenUserInfo(false)
    self.sManager.menuLayer:RefshTopBar()
    local data = self.rData["rcvData"]
    self.isTouchRewerd = false
    self._isShowThridG = false
    self.tollgate = {}--数据容器
    self.all_tollgate = {}
    self.click_point = nil  --点击的关卡
    self.exist = true
    self.level_type =  6 ---- 当前显示的关卡类型 水火风光暗 素材

    --self.nHeroId = data.nHeroId
   
    local node = cc.CSLoader:createNode("ExclusiveStoryListLayer.csb")
    self.uiLayer:addChild(node,0,1)
    local panel = node:getChildByTag(101) 
    local function touchCallBack(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
          self:returnBack()
        end
    end

    self.roleIconPos = panel:getChildByName("roleIconPos")

    local backBtn  =  ccui.Helper:seekWidgetByName(panel,"btn_back")
    backBtn:setEffectType(3)
    backBtn:addTouchEventListener(touchCallBack)
    -- --点击说明按钮
    -- local function touchGuideBtnEvent(sender,eventType)
    --     if eventType == ccui.TouchEventType.ended then
    --         self:showGuidePicLayer()
    --     end
    -- end 
    -- local guideButton = ccui.Helper:seekWidgetByName(panel,"Button_guide")
    -- guideButton:addTouchEventListener(touchGuideBtnEvent)

    -- --首次进入 显示大型战斗的说明 key 统一用类名吧
    -- if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"].."TrialLandLayer_1") == 0 then
    --     cc.UserDefault:getInstance():setIntegerForKey(user_info["id"].."TrialLandLayer_1", 1)
    --     self:showGuidePicLayer()
    -- end
    --首次试炼之地
    if cc.UserDefault:getInstance():getIntegerForKey(user_info["id"]..RedDotPromptKey.Trial) == 0 then
        cc.UserDefault:getInstance():setIntegerForKey(user_info["id"]..RedDotPromptKey.Trial, 1)
    end


    -- ---boss属性分类根节点
    -- self.atbRoot = ccui.Helper:seekWidgetByName(panel,"Atb_root")
    -- self:initBossAtbBtns()
    self:initListView()
    self:reqDropInfo()
    self:refreshStaticState()

    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
        -- body
        self:returnBack()
    end)

end

---初始化boss属性按钮
function ExclusiveStoryListLayer:initBossAtbBtns()
    --水、火、风、光、暗、经验
    local function touchAtbBtnEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
            self.level_type = sender.myTag
            self:updateSubList()
        end
    end 
    for i=1,6 do
        local btn = ccui.Helper:seekWidgetByName(self.atbRoot,"touch_"..i)
        btn.myTag = i
        btn:addTouchEventListener(touchAtbBtnEvent)
    end
end

--根据关卡条目类型，刷新当前创建列表
function ExclusiveStoryListLayer:updateSubList()
    --刷新按钮状态
    -- for i=1,6 do
    --     local showbtn = ccui.Helper:seekWidgetByName(self.atbRoot,"btn_atb_"..i)
    --     local touchBtn = ccui.Helper:seekWidgetByName(self.atbRoot,"touch_"..i)
    --     if i == self.level_type then 
    --         showbtn:setTouchEnabled(false)
    --         showbtn:setBright(false)
    --         touchBtn:setTouchEnabled(false)
    --     else 
    --         showbtn:setTouchEnabled(true)
    --         showbtn:setBright(true)
    --         touchBtn:setTouchEnabled(true)
    --     end 
    -- end
    self:refreshSubList()
end

---根据当前的关卡类型，刷新关卡列表
function ExclusiveStoryListLayer:refreshSubList()
    self.tollgate = {}
    for i=1,#self.all_tollgate do
        local battleData = self.all_tollgate[i]
        self.tollgate[#self.tollgate+1] = battleData
        -- if battleData.level_type == self.level_type then 
        --     self.tollgate[#self.tollgate+1] = battleData
        -- end 
    end
    self:refreshPassList()
end

-- --- 换图
-- function ExclusiveStoryListLayer:showGuidePicLayer()
--     local data = {}
--     data.pictures = {
--           "uifile/n_UIShare/newGuide/picture_guide/xsjx_ui_018.png",
--       }
--     self.sManager:toGuidePictureLayer(data)
-- end

--初始化列表
function ExclusiveStoryListLayer:initListView()
    local node = self.uiLayer:getChildByTag(1)
    local panel = node:getChildByTag(101)
    self.scrollView = ccui.Helper:seekWidgetByName(panel,"listview")
    --set bar
    self.scrollView:setScrollBarEnabled(false)
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
              if  self.isTouchRewerd then 
                 do return end 
              end 
              self.click_point = sender:getCurSelectedIndex() + 1
              local levelState = self.tollgate[self.click_point]["level_state"]
              if levelState ~= 0 then
                  if self.tollgate[self.click_point]["type"] ~= 3 then --type  3-多人BOSS
                      self:onClickOtherPass()
                  else
                      self:onClickMullPass()
                  end               
              end 
          end
    end
    self.scrollView:removeAllItems()
    self.scrollView :addEventListener(listViewEvent)
    self.scrollView:setScrollBarEnabled(false)

    local  layout_list = ccui.Layout:create()
    layout_list:setAnchorPoint(cc.p(0,1))
    local  list_item = cc.CSLoader:createNode("pass_item.csb")
    local  item_1 = list_item:getChildByTag(174)
    local item_c = item_1:clone()
    item_c:setPosition(cc.p(0,0))
    item_c:setName("item")
    layout_list:addChild(item_c)
    layout_list:setContentSize(610,160)
    layout_list:setTouchEnabled(true)
    self.scrollView:setItemModel(layout_list)
end

--返回
function ExclusiveStoryListLayer:returnBack()
    self.sManager:removeFromNavNodes(self)

    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)

    if self.backFunc then
        if self.bReturnShouldRefresh then
            local rData = {
                hid = self.hid,
                hlist = self.hList,
                teamidx = self.team_id,

            }
            self.backFunc(self.sDelegate,rData)
        end
    end
    --SceneManager:toRoleInfo({ hid = self.hid,  hlist = self.hList, team_id = self.team_id })
    self.exist = false
    self:clear()
end

--刷新列表
function ExclusiveStoryListLayer:refreshPassList()
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
              if  self.isTouchRewerd then 
                 do return end 
              end 
              self.click_point = sender:getCurSelectedIndex() + 1
              local levelState = self.tollgate[self.click_point]["level_state"]
              if levelState ~= 0 then
                  if self.tollgate[self.click_point]["type"] ~= 3 then --type  3-多人BOSS
                      self:onClickOtherPass()
                  else
                      self:onClickMullPass()
                  end               
              end 
          end
    end
    self.scrollView:removeAllItems()
    self.scrollView :addEventListener(listViewEvent)
    UITool.refreshPassList(self,"level_id")
    self.scrollView:jumpToTop()
end

--刷新静态信息
function ExclusiveStoryListLayer:refreshStaticState()
    local h_id_num = getNumID( self.hid )
    --动态模型，立绘
    local lihuifile = hero[h_id_num].hero_des_spi

    self.roleIconPos:removeAllChildren()
    if self.asyncHandler2 then
        self.asyncHandler2:cancel(true)
        self.asyncHandler2 = nil
    end

    if cc.FileUtils:getInstance():isFileExist(lihuifile) then

        local end_pos = string.find(lihuifile,'atlas') - 1
        local spName = string.sub(lihuifile,0,end_pos)
        self.asyncHandler2 = UITool.loadSpineAsync(spName.."json",spName.."atlas",1.0,function(roleIcon)
            self.asyncHandler2 = nil

            local rps = self.roleIconPos:getSize()
            roleIcon:setPosition(cc.p(rps.width / 2 , rps.height / 2))
            self.roleIconPos:addChild(roleIcon,0,123)
            roleIcon:setAnimation(1, "effect1", true)
        end)
    end
end

function ExclusiveStoryListLayer:toReadyLayer()
    local level_id = self.tollgate[(self.click_point)]["level_id"]
    local battleData = battlePass[level_id]
    if battleData == nil then
        LogManager.showSimpMsgDebug("error,ExclusiveStoryListLayer:toReadyLayer:battlePass.lua has no level_id = "..tostring(level_id))
        -- return
    end
    self.sData = {} 
    self.sData["name"] =  UITool.getUserLanguage(battlePass[level_id]["level_name"])--battlePass[level_id]["level_name"]
    self.sData["lv"] = battlePass[level_id]["level_lv"]
    self.sData["ap"] = self.tollgate[self.click_point]["need_ap"]
    local type_ = self.tollgate[(self.click_point)]["type"]
     --创建多人战表里面的  和 参加多人战的区别（返回的Id）
    local state = self.tollgate[(self.click_point)]["level_state"]
    if type_ == 3 then
        if state == 2 then --加入多人战
            self.sData["b_id"] = self.tollgate[(self.click_point)]["id"]
            self.sData["mode"] = "mutable1" --join
            self.sData["ap"] =  0
        else
            self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
            self.sData["mode"] = "mutable" --create
        end
    else
        self.sData["b_id"] = self.tollgate[(self.click_point)]["battle_id"]
    end   
    self.sManager:toReadyLayer(self.sData) 
end
--点击非多人战类型的关卡
function ExclusiveStoryListLayer:onClickOtherPass()
    self:toReadyLayer()
end
--刷新
function ExclusiveStoryListLayer:SMapRefresh()
    --

    self.bReturnShouldRefresh = true
    self:reqDropInfo()
end


--点击多人战类型的关卡
function ExclusiveStoryListLayer:onClickMullPass()
    --多人战创建
    local state = self.tollgate[(self.click_point)]["level_state"]
    if state == 2 then --加入 不消耗次数
        self:toReadyLayer()
    else               --新建 消耗次数
        local totalValue = self.tollgate[self.click_point]["multi"]["total"]
        local nowValue = self.tollgate[self.click_point]["multi"]["now"]
        local nums = totalValue - nowValue
        if nums >0 then
            local msg = UITool.ToLocalization("今日还剩余挑战次数:")..nums
            MsgManager:showSimpMsgWithCallFunc(msg,self,self.toReadyLayer)
        else
            local msg = UITool.ToLocalization("你的挑战次数已用完")
           MsgManager:showSimpMsg(msg)
        end
    end 
end
--获取
function ExclusiveStoryListLayer:reqDropInfo()
    local function reicePointCallBack(data)
        print("收到事件点结果 关卡列表")
        data = tolua.cast(data, "PassData");
        print("callBack-----"..data:getData())
         if self.sManager ~= nil then
            self.sManager:delWaitLayer()
        end
        if self.exist == false then
          return
        end

        local cjsonSafe = require "cjson.safe"
        local t_data = cjsonSafe.decode(data:getData())
        --GameManagerInst:saveToFile("reicePointCallBack.json",t_data)
        --GameManagerInst:alert("已保存")
        if t_data == nil then 
            MsgManager:showSimpMsg(UITool.ToLocalization("获取数据异常，请联系客服"))
            --todo 处理错误数据页面跳转逻辑
            return
        end 
        if  t_data["data"]["state_code"] ~=1 then
            MsgManager:showSimpMsg(UITool.getUserLanguage(t_data["data"]["warning"]))
            return
        end
        self.all_tollgate = {}
        self.all_tollgate = t_data["data"]["level_list"] or {}
        self:refreshSubList()

    end
    local cjson = require "cjson"
    self.sManager:createWaitLayer()
    -- local tempTable = {
    --     ["rpc"] = "x_battle_list",
    -- }
    local tempTable = {
        ["rpc"] = "hero_soul_battle_list",
        ["hero_id"] = self.rData["rcvData"].nHeroId,
    }
    local mydata =  cjson.encode(tempTable)

    local dbhttp = cc.MyHttpHelper:shareMyHttpHelper():creatHttpRequestForLua()
    ScriptHandlerMgr:getInstance():registerScriptHandler(tolua.cast(dbhttp, "cc.Ref"),reicePointCallBack, cc.Handler.CALLFUNC);    
    dbhttp:creatHttpRequestWithURL(mydata,3)
end

--查看掉落
function ExclusiveStoryListLayer:toMapItemDropsLayer(data)
    local rcvData = {}
    rcvData["data"] =  data
   -- self.sManager:toMapItemDropsLayer(rcvData)
       ---todo 判断类型是普通掉落还是魔王情报
    if data.level_is_boss == 1 then 
         self.sManager:toBossInformationLayer(rcvData)
    else 
        self.sManager:toMapItemDropsLayer(rcvData)
    end 
end