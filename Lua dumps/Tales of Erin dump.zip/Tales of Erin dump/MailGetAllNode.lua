

MailGetAllNode = class("MailGetAllNode", XUICellView)
MailGetAllNode.CS_BIND_TABLE = 
{
    PanelList = "/s:Panel_1",
}

function MailGetAllNode:init(...)
    if g_channel_control.obtainItemsVersion == 1 then
        MailGetAllNode.CS_FILE_NAME = "MailGetAllNode.csb"
    else
        MailGetAllNode.CS_FILE_NAME = "XbObtainItemNode.csb"
    end
    MailGetAllNode.super.init(self,...)
    self.PanelList:setSwallowTouches(false)
    return self
end

function MailGetAllNode:onResetData()
     print("第一步  执行 GuildMemberItemNode onResetData")
     if not self._data then return end

      local  panelP   = self.PanelList
      local  Type     = self._data.item_type
      if Type == nil then
        Type= self._data.type
      end
      local  item_id  = self._data.id
      print("Type Type Type == "..Type)
      print("item_id item_id item_id == "..item_id)
      ---------------
      local Image_23 = panelP:getChildByName("Image_23")
      local  FromI    = panelP:getChildByName("Image_form")
      local  Icon     = panelP:getChildByName("Image_icon")
      local  i_bg     = panelP:getChildByName("Image_iconbg")
      local  dec      = panelP:getChildByName("Text_dec")
      local name      = panelP:getChildByName("Text_name")
      local num       = panelP:getChildByName("Text_num")
      local popr = nil
      if g_channel_control.obtainItemsVersion == 1 then
         Image_23:setVisible(true)
      else
         Image_23:setVisible(false)
      end
      if Type == 1 then
         --name     = "金币"
         popr = UITool.getItemInfos(1,1)
      elseif Type == 2 then
        --name     = "宝石"
        popr = UITool.getItemInfos(2,1)
      elseif Type == 16 then
          popr = UITool.getItemInfos(Type,item_id)
                          --称号
        local spineRoot = panelP
        if self.skeletonNode then 
            self.skeletonNode:stopAllActions()
            self.skeletonNode:removeFromParent()
        end 
          local id_str = title_conf[tonumber(item_id)].res_spine
          if cc.FileUtils:getInstance():isFileExist(id_str) then 
              local end_pos = string.find(id_str,'atlas') - 1
              local spName = string.sub(id_str,0,end_pos)

              local title_png = ccui.ImageView:create(spName.."png")
              local size = title_png:getContentSize()

              self.skeletonNode = sp.SkeletonAnimation:create(spName.."json",spName.."atlas", 1.0)
              self.skeletonNode:setAnchorPoint(0,1)
              --self.skeletonNode:setPosition(0,0)
              self.skeletonNode:setPosition(name:getPositionX()+size.width/2,name:getPositionY()-size.height/2)
              --spineRoot:setAnchorPoint(0,0.5)
              spineRoot:addChild(self.skeletonNode,1000)

              self.skeletonNode:setAnimation(1, "effect", true)
              -- local dt = cc.DelayTime:create(0.01)
              -- local cf = cc.CallFunc:create(function()
              --      ---添加spine


              --         local size=self.skeletonNode:getBoundingBox()
              --         print("getBoundingBox width == "..size.width)
              --         self.skeletonNode:setPosition(name:getPositionX()+size.width/2,name:getPositionY()-size.height/2)

              -- end)
              -- local seq = cc.Sequence:create(dt,cf)
              -- spineRoot:runAction(seq)
          else 
              print("文件不存在 error file not exist:"..id_str)
          end
      else
        popr = UITool.getItemInfos(Type,item_id)
      end
    --------------------------

      num:setString(self._data.num)
      -- icon
      Icon:loadTexture(popr[2])
      Icon:setUnifySizeEnabled(true)
        -- 背景
      i_bg:loadTexture(popr[4])
        -- 图框
      FromI:loadTexture(popr[1])
      --名字
      name:setString(popr[5])
      -- 描述
      dec:setString(popr[6])
      -- 稀有度
      print("素材的属性 === "..popr[3])
      if popr[3] ~= ""  then 
        print("素材的属性 === "..popr[3])
          local elementImg = cc.Sprite:create(popr[3])
          elementImg:setAnchorPoint(cc.p(1,1))
          elementImg:setPosition(FromI:getContentSize().width,FromI:getContentSize().height)
          elementImg:setScale(0.8)
          FromI:addChild(elementImg)
      elseif popr[3] == "" or popr[3] == nil or popr[3] == 0 then
        print("如果走进这里就证明是删除出错")
          FromI:removeAllChildren()
          --FromI:setVisible(false)

      end 

     if self.resetDataEvent then
        self.resetDataEvent(self)
     end

end




