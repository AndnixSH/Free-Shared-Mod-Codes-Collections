hero_update_show = {}


hero_update_show[13] = {
    hero_name = "Alven",
    hero_des_all = "    The protagonist of the story, a 19-year old young man, Federal mercenary.\n    He grew up on Era Island with People of Earth,he can get along with those non-human races naturally.\n   For some reason, he left Era and became a mercenary of Federal.\n    His mission is to search ruins.He’s seen by coworkers as full of justice and motivation, and a kind-hearted man.",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_013.png", 
}

hero_update_show[62] = {
    hero_name = "Leefa",
    hero_des_all = "    Rainbow Crystal Spirit warrior, Limmy’s elder sister.\n    An outstanding warrior. Usually she acts very serious,without showing her emotions,which makes people think she’s callous.\n    Once going hunting with Alven, she fell in love with him, but didn’t know how to confess her feelings.",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_062.png",
}
hero_update_show[76] = {
    hero_name = "Sartha",
    hero_des_all = "    Nicknamed as Knight League of One, she stays at the border of the Federal.\n    A novice knight of a small village. Timid and soft, she has a disdain for wars, She even don’t want to kill an insect.\n    But the same Sartha also has the power to destroy a corps of the empire.\n    No one saw the process, only her crying,among those corpses.\n    Some says that monster power is deep in Sartha’s body, while Aisha thought monster stays in her heart.",
    
    hero_vcw_icon = "icons/role/vdrawing/jq_r_076.png",
}

hero_update_show[156] = {
    hero_name = "Mirafuse", 
    hero_des_all = "    Mercenary of Kradict Federal, her ruby eyes is a dead giveaway of her status as offspring between human and demon, but she is a Demon Hunter who kills demons for a living.\n    The oldest one of the Demon Hunter Sisters, she’s clever and well-prepared, with the power to manipulate illusion and light soul essence.\n    She has a burning hatred for all demons. She’ll ignore anything else during demon huntings, only focusing on demolishing targets.",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_156.png",  
}

hero_update_show[362] = {
    hero_name = "Nicolas",
    hero_des_all = "    An ancient maneater species called Demon.\n    She has battle power beyond the understanding of human, skillful at direct influencing souls.\n    She’s the leader of Border of Eden,whose motherhood attracts other members, who usually call her Mom.\n    She tries to find ways to living peacefully with human beings, so she never absorbs more Soul Essence to avoid the death of human.",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_362.png",
}

hero_update_show[364] = {
    hero_name = "Tiamat",
    hero_des_all = "        The proud leader of Dragon Clan, also known as Dragon Ancestor by her fellow men.\n    Devoid of expressions, she is intense and fair, like all rulers are.\n    She has the power of control thunders, to the degree to change celestial phenomena. Thus, she's nicknamed Walking Weather Hazard by Witch Empress Mao.",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_364.png",  
}

hero_update_show[373] = {
    hero_name = "Wu Lian",
    hero_des_all = "    Homeless swordsman of soul clan.\n    She travels around without aim.\n    Her hometown is in mountains, a famous scenery in the East. Attacked by people with demonic sword, only she survived from the killing.After practicing for many years, she killed her enemy in the end. After that, she lost her motivation of life.\n   She still wanders around the world as mercenary, hoping to find out a home for herself. But everyone only concerns about her swordsmanship rather than herself. Nowhere is really home to her.",
    hero_vcw_icon = "icons/role/vdrawing/jq_r_373.png",
}
