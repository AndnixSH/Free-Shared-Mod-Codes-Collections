
--聊天表情系统
EmotSys = class("EmotSys")
EmotSys.EType = {
    --默认
    default = 1,
    --动图
    dynamic = 2,
    --战斗
    fight = 3,
}

--每页显示数量
EmotSys.pageOfCount = 8
EmotSys.rowOfCount = 4

function EmotSys:getInstance()
   if self.s_instance == nil then
        self.s_instance = EmotSys.new()
        self.s_instance:initialize()
   end
   return self.s_instance;
end

function EmotSys:initialize( ... )
    -- body
    self:initData()
end

function EmotSys:initData( ... )
    -- body
    self.emoti_data = self:sortData()
end

function EmotSys:sortData( ... )
    -- body
    local data = expression_conf
    table.sort(data,function(a,b)
        return a.index < b.index
    end)
    return data
end

function EmotSys:getEmotCategoryCount( ... )
    -- body
    local data = expression_conf
    local count = #data or 0
    return count
end

function EmotSys:getTabDataByIndex( index )
    -- body
    local tab_data = {}
    local data = self:getDataByIndex(index)
    tab_data["tab_label"] = UITool.getUserLanguage(data["name"])
    tab_data["sort_index"] = data["index"]
    return tab_data
end

function EmotSys:getDataByIndex(index)
    -- body
    local data = table.getValue("EmotSys emot_data", self.emoti_data, index)
    -- dump(data,"EmotSys:getDataByIndex == ")
    return data
end

function EmotSys:getPageDataByIndex( index )
    -- body
    local pages = {}
    local t_data = self:getDataByIndex(index)
    if t_data and t_data["data"] then
        local data = t_data["data"]
        local count = #data
        local pageOfcount = EmotSys.pageOfCount
        local row = math.ceil(count/pageOfcount)
        local col = count%pageOfcount
        for i=1,row do
            local page = {}
            for j=1,pageOfcount do
                local index = (i - 1) * pageOfcount + j
                local emot_data = data[index]
                table.insert(page,emot_data)
            end
            table.insert(pages,page)
        end
    end
    return pages
end

function EmotSys:getEmotDataByTypeAndId( type,id )
    -- body
    local data = self:getDataByIndex(type)
    -- dump(data,"EmotSys:getEmotDataByTypeAndId    data")
    local emot_data = nil
    if data and data["data"] then
        local t_data = data["data"]
        emot_data = table.getValue("EmotSys:getEmotDataByTypeAndId",t_data,id)
        -- dump(emot_data,"EmotSys:getEmotDataByTypeAndId    emot_data")
    end
    
    return emot_data
end