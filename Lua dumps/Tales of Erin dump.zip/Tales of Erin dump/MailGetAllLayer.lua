require "BasicLayer"
-- 登陆奖励
MailGetAllLayer = class("MailGetAllLayer",BasicLayer)
MailGetAllLayer.__index   = MailGetAllLayer
MailGetAllLayer.panelList = nil

function MailGetAllLayer:init()
    print("进入商店初始化函数")
    local node = nil
    if g_channel_control.obtainItemsVersion == 1 or self.isShow == true then
        node = cc.CSLoader:createNode("MailGetAllLayer.csb")
    else
        node = cc.CSLoader:createNode("XbObtainItemsLayer.csb")
    end

    self.fCall = self.rData["rcvData"]["fCall"]
    
    self.uiLayer:addChild(node,0,2)
    self:initList()
    self:refreshTale()
    if self.rData["rcvData"]["naem"] then
        self:setTitle(self.rData["rcvData"]["naem"])
    end

    --注册返回键
    self.keyboardValue = KeyboardManager:registeredKeyBoardEvent(self,function ()
      -- body
      self:Close()
    end) 
end
function MailGetAllLayer:initList( ... )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    local panel = node:getChildByName("Panel_1")
    local bg    = panel:getChildByName("Image_bg")
    local Text_title = bg:getChildByName("Text_title")

    if g_channel_control.obtainItemsVersion == 2 and self.isShow ~= true then
        self:playObtainEffect()
    end

    -- 确定按钮
    local btn   = bg:getChildByName("Button_1")
    local function touchCallBack1( sender,eventType )
        -- body
        if eventType == ccui.TouchEventType.ended then
            if self.fCall then
                self.fCall()
            end
            self:Close()
        end
    end 
    btn:setEffectType(3)
    btn:addTouchEventListener(touchCallBack1)

    if g_channel_control.obtainItemsVersion == 1  or self.isShow == true then
         Text_title:setVisible(true)
    else
         Text_title:setVisible(false)
    end

    self.panelList = bg:getChildByName("Panel_list")
    local psize = self.panelList:getContentSize()
    self.gridview = XUIGridView.new():initWithNodeAndSize( self.panelList , psize.width, psize.height,830,145)
    self.gridview.itemCreateEvent = function()
        local temp = MailGetAllNode.new():init()
        -- self.GuildMemberTable["GuildMemberIndex"] = self.GuildMemberIndex;
        -- self.GuildMemberTable["OnSelf"] = self;
        -- temp:setData(self.GuildMemberTable);
        local function touchCallBack( sender,eventType )
            -- body
            if eventType == ccui.TouchEventType.ended then
                local p1 = sender:getTouchBeganPosition()
                local p2 = sender:getTouchEndPosition()

                local l = cc.pGetDistance(p1,p2)
                
                if l < 30 then
                    --print("curId == "..temp.curId)
                    --self:sendGet(temp.curId,temp.ItemId,temp.ItemType,temp.ItemNum)
                end
            end
        end 


        return temp
    end
end

function MailGetAllLayer:playObtainEffect( ... )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    local panel = node:getChildByName("Panel_1")

    local obtain_eff_node = panel:getChildByName("Node_effect")
    local effects = sp.SkeletonAnimation:create("effects/ling_qu_jiang_li/ling_qu_jiang_li.json", "effects/ling_qu_jiang_li/ling_qu_jiang_li.atlas", 1.0)
    obtain_eff_node:addChild(effects)

    local obtainList = self.rData["rcvData"]["AllData"]
    local count = #obtainList

    if count <= 1 then
        effects:addAnimation(1,"effect1",true) -- 爆炸
        effects:addAnimation(0,"effect",false)--一道杠
        effects:setMix("effect1", "effect", 0.2)
    else
        effects:addAnimation(1,"effect1",true) -- 爆炸
        effects:addAnimation(0, "effect2", false)--两道杠
        effects:setMix("effect1", "effect2", 0.2)
    end
end

function MailGetAllLayer:Close( ... )
    -- body
    self.exist = false
    self:clearEx()
end

function MailGetAllLayer:clearEx()
    KeyboardManager:removeKeyBoardEvent(self.keyboardValue)
    self:clear()
end
-- 测试获取数据
function MailGetAllLayer:refreshTale()
      
    self.gridview:setDataSource(self.rData["rcvData"]["AllData"])
end
function MailGetAllLayer:setTitle( name )
    -- body
    local node      = self.uiLayer:getChildByTag(2);
    local panel     = node:getChildByName("Panel_1")
    local bg        = panel:getChildByName("Image_bg")
    local title     = bg:getChildByName("Text_title")
    title:setString(name)
end
function MailGetAllLayer:create(rData)

     local login = MailGetAllLayer.new()
     login.rData = rData
     login.sManager  = login.rData["sManager"]
     login.backFunc  = login.rData["rcvData"]["sFunc"]
     login.sDelegate = login.rData["rcvData"]["sDelegate"]
     login.isShow = login.rData["rcvData"]["isShow"]
     login.uiLayer   = cc.Layer:create()
     login:init()
     return login

end

