function SetInvenList(this,viewSize,data)
local container=this:CreateEmptyMovieClip("container");
local owner=this;
local x=4;
local list={};
local height=124;
local width=124;
local left=0;

container:SetInputEnable(false);
container:SetSpriteMode(true);

SetVScrollView(this);
this.setViewLimit(viewSize.cy);
this.setScrollBarPos(viewSize.cx-82);

this.init=function(this)
local t={};
local priority=function(k,v)
local p=0;
return p;
end
local maxN=table.getn(data)or 0;

for i=1,maxN,1 do
t[i]=data[i];

end
for i=1,maxN,1 do
local v=t[i];
local j=(i-1)%4;
if j==0 then
x=x+height;
end
local mc=container:AddSymbol("\236\157\184\235\178\164\236\138\172\235\161\175","");
mc:SetPos(left+j*width,x-height);
this:setInfo(mc,v);
table.insert(list,{mc,v});
end

this.setContentSize(x);
end

this.refresh=function(this)
for k,v in pairs(list)do
this:setInfo(table.unpack(v));
end
end
this.onSelect=function(this,pos,px)
local y=math.floor(pos/height)+1;
local x=math.floor(px/width)+1;
local slot=(y-1)*4+x;

if list[slot]then
if this:onSelected(table.unpack(list[slot]))then
this:setInfo(table.unpack(list[slot]));
return true;
end
end
end

this.onScroll=function(this,scroll)
end

this.onScrollEnd=function(this,scroll)
end

end
