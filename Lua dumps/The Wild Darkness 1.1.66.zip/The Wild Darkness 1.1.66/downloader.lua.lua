local asynchttp=require"socket.asynchttp";
local ltn12=require("ltn12")

function downloader(url,method,filename,argt)
local started=false;
local inst={};
local file=nil;
local co=nil;
inst.p=0;
inst.start=function()
local h=""
if argt then
h="?"
for i,v in pairs(argt)do
h=h.."&"..i.."="..escape(v);
end
end
co=asynchttp.requestfile({
url=url..h,
method=method or"GET",
});
started=true;
trace("started:"..url);
end
inst.update=function()
if not started then
if inst.onStart and not inst:onStart()then
return false;
end
inst.start();
end
if co then
local live,c,h,s,d=coroutine.resume(co);
live=live and coroutine.status(co)~="dead"
if c=="recv"then
if not file and filename then
file=io.open(filename,"wb");
if not file then
if inst.onFailed then
inst.onFailed("nofile");
end
end
end

if inst.onRecv then
inst.onRecv(d);
end

if file then
inst.p=1-h/s;
if not file:write(d)then
if inst.onFailed then
inst.onFailed("write");
end
end
player:SetNextDeltaTimeZero();
end

end

if not live then
if file then
file:close();
end
if h==200 then
if inst.onComplete then
co=nil;
inst.onComplete(h,s);
end
else
if inst.onFailed then
inst.onFailed(h);
end
end
else
if inst.onUpdate then
inst.onUpdate();
end
end
return live;
end
return false;
end
return inst;
end

function downloaderRedirect(url,argt)
local started=false;
local inst={};
local file=nil;
local co=nil;
local filename=nil;
local step="redirect";

inst.setUrl=function(o)

url=o;
end

inst.setFileName=function(o)

filename=o;
end

inst.setStep=function(o)
step=o;
end

inst.start=function()
if step=="redirect"then

local h=""
if argt then
h="?"
for i,v in pairs(argt)do
h=h.."&"..i.."="..escape(v);
end
end
co=asynchttp.request({
url=url..h,
headersOnly=true,
});
elseif step=="download"then
trace("start filename:"..filename..",from:"..url);
file=io.open(filename,"wb");
co=asynchttp.request({
url=url,
sink=ltn12.sink.file(file)
});
end
started=true;
end
inst.update=function()
if not started then
if inst.onStart and not inst:onStart(step,url)then
if step=="redirect"then
step="download";
return true;
else
return false;
end
end
inst.start();
end
if co then
local live,c,h,s=coroutine.resume(co);
live=live and coroutine.status(co)~="dead"
if not live then
if h==200 then
if inst.onComplete then


if step=="redirect"then
url=s.location;
end
inst:onComplete(step,url);
if step=="redirect"then
step="download";
started=false;

return true;
end
end
else
if inst.onFailed then
inst:onFailed(step,h);
end
end
else
if inst.onUpdate then
inst.onUpdate(inst);
end
end
return live;
end
return false;
end
return inst;
end
function downloaderMgr(limit)
local inst={};
local t={};
local active={};
local limit=limit or 2;

inst.add=function(downloader)
table.insert(t,downloader);
end

inst.update=function()
i=1;
while active[i]do
if not active[i].update()then
table.remove(active,i);
else
i=i+1;
end
end
while#active<limit and#t>0 do
table.insert(active,t[1]);
table.remove(t,1);
end

return#active>0;
end
return inst;
end

