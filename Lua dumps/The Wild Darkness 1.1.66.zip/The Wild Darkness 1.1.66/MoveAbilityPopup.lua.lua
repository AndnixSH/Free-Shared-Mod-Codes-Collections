
function MoveAbilityPopup(owner,object,onOk,onCancel)
local prevScroll;
local selected={};
local mode;
local materials={};

local function selectSlot(guid,onSelect,onCancel)
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
local matchSlots={"slot","slot2"};
if itemtable[id]["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
matchSlots={"slot"};
end
SelectSlotPopup(onSelect,onCancel,owner,matchSlots,guid,selected,_L("\236\138\172\235\161\175\236\157\132 \236\132\160\237\131\157\237\149\180 \236\163\188\236\132\184\236\154\148"),nil,"\234\184\176\237\131\128\236\138\172\235\161\175\236\132\160\237\131\157\237\140\157\236\151\133");
end


local function canBuy(guid)
if not table.find(selected,guid)then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local group=itemtable[o.id]["\234\183\184\235\163\185"];
if group then
local drop=drop1table[group];
return drop and drop["\236\158\165\235\185\132 \236\134\141\236\132\177 \236\151\172\235\182\128"];
end
end
end
end

for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end

owner.name:SetText(object.tb.name);
if owner.icon then
local obj=UIObject(owner.icon);
obj:init(object.sdata.id);
obj.mc:SetScale(0.5,0.5);
obj.mc:SetPos(70,95);
end


local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
owner.myinven[v]:Clear();
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(owner.myinven[v],guid);
else
assert(images[v],v);
SetItemIconFromGuid(owner.myinven[v]);
owner.myinven[v].img:AddSymbol(images[v],"icon");
end
end
end
end

local function canMake()
if not selected.slot or not selected.slot2 then
return false;
end
for id,c in pairs(materials)do
if not HasItemType(id,c)then
return false;
end
end
return true;
end

local function updateMaterials()
if selected.slot and selected.slot2 then
materials=GetMoveAbilityMaterials(selected.slot,selected.slot2);





else
materials={};
end
owner.sub:Clear();
MakeSubMaterialSlot(owner.sub,table.length(materials),materials);
do
SetItemIconFromGuid(owner.slot,selected.slot);
SetItemIconFromGuid(owner.slot2,selected.slot2);
end

if canMake()then
owner.btnOk:enable(true);
owner.btnOk:GotoAndStop(1,true);
else
owner.btnOk:enable(false);
owner.btnOk:GotoAndStop(2,true);
end

end

local function initBag()
trace("initbag");
do
for k,v in ipairs(GetAvailStorageSlots())do
if mode==v then
owner.myinven[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner.myinven[v].img:SetAlphaDepth(0.3);
else
owner.myinven[v].img:SetAlphaDepth(1);
end
end
end

owner.myinven.list:Clear();

local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o and o["\234\176\128\235\176\169"];
SetMyInventoryWnd(owner.myinven.list,d);
if prevScroll then
owner.myinven.list.list.setScroll(prevScroll);
end
function owner.myinven.list.list:onScroll(s)
prevScroll=s;
end

local function setInfo(this,mc,guid)
if(guid or 0)~=0 then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid],guid);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local c=(o.c or 1);
if c>0 then
SetItemIconFromGuid(mc,guid);
SetItemIconCnt(mc.cnt,c);
else
SetItemIconFromGuid(mc);
end
else
SetItemIconFromGuid(mc);
end

if mc.enabled then
mc.img:SetAlphaDepth(1);
else
mc.img:SetAlphaDepth(0.3);
end
end

owner.myinven.list.list.onSelected=function(this,mc,guid)
if guid and guid~=0 and mc.enabled then
local function onOk(slot)
selected[slot]=guid;
updateMaterials();
owner.myinven.list.list:refresh();
end
local function onCancel()
end

local function onOk2()
selectSlot(guid,onOk,onCancel);
end

ShowItemInfo(guid,onOk2,_L("\235\132\163\234\184\176"));
return true;
end
end
owner.myinven.list.list.setInfo=function(this,mc,guid)
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemType=itemtable[data.id]["\236\162\133\235\165\152"];
local group=itemtable[data.id]["\234\183\184\235\163\185"];
mc.enabled=canBuy(guid);
setInfo(this,mc,guid);
end
end

updateMaterials();
owner.myinven.list:init();
end


local function changeMode(slot)
mode=slot;
prevScroll=nil;

initBag();
end

for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
SetButton(owner.myinven[v],nil,nil,nil,0,0).onClick=function()
if IsStorageSlot(v)then
if _S["\236\138\172\235\161\175"][v]~=0 then
changeMode(v);
end
end
end
end
end

function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
initSlots();
initBag();
end

SetTextButton(owner.btnOk,_L("\234\176\149\237\153\148")).onClick=function()
owner:onUnload();
if ConsumeItems(materials)then
owner:Remove();
onOk(selected.slot,selected.slot2);
end
end

for k,v in pairs({"slot","slot2"})do
SetButton(owner[v]).onClick=function()
selected[v]=nil;
updateMaterials();
owner.myinven.list.list:refresh();
end
end

SetButton(owner.myinven.btnClose).onClick=function()
owner:Remove();
onCancel();
end

eventDispatcher:add(owner,owner.onEvent);
owner:init();

end

