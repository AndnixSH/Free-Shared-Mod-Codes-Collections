EvilStatue=Object:new({
})

function EvilStatue:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
if not self.sdata.param then
self.sdata.param={idx=1};
end
end

function EvilStatue:onResetTurn(AP)
Object.onResetTurn(self,AP);
if self:checkEndSpawn()then

do
local v=evilstatuetable[self.sdata.param.idx];
local list={};
local cnts={};
for i=1,3,1 do
local k=v["\235\179\180\236\131\129"..i];
if k then
local p=v["\235\185\132\236\156\168"..i];
local c=v["\234\176\156\236\136\152"..i];
list[k]=p;
cnts[k]=c or 1;
end
end
local k=math.randlist(list);
local c=cnts[k];
for i=1,c,1 do
local group=math.randlist(k);
local i,j=world.ground:getNearTileWalkable(self.tile.x,self.tile.y,Filter_ItemPlace);
if i and j then
local itemGuid,o=MakeItem(group,"\236\157\188\235\176\152");
PlaceItem(itemGuid,i,j);
else
trace("item place error");
end
end
end

self.sdata.param.idx=self.sdata.param.idx+1;
if not evilstatuetable[self.sdata.param.idx]then
self.sdata.param.idx=nil;
self:play(self.tb["\236\153\132\235\163\140 \236\149\160\235\139\136"]or self.tb["\236\149\161\236\133\152 \236\149\160\235\139\136"]);
end
end
end

function EvilStatue:checkEndSpawn()
if self.sdata.monsters then
for k,v in pairs(self.sdata.monsters)do
if world:findCharac(v)then
return false;
end
end
self.sdata.monsters=nil;
return true;
end
end

function EvilStatue:complete()
Object.complete(self);
local tb=evilstatuetable[self.sdata.param.idx];
for k,v in pairs(tb["\235\170\172\236\138\164\237\132\176"])do
for i=1,v do
local guid=SpawnMonster(self.tile.x,self.tile.y,0,2,k);
self.sdata.monsters=self.sdata.monsters or{};
table.insert(self.sdata.monsters,guid);
end
end
end

function EvilStatue:canTouch()
if not self.sdata.monsters and self.sdata.param.idx then
return Object.canTouch(self);
end
end

function EvilStatue:isCompleted()
return self.sdata.param and not self.sdata.param.idx;
end

