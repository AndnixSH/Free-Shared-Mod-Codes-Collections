LightningRod=Object:new({
})

function LightningRod:complete(menu,guid,...)
trace("complete",menu,guid);
if menu=="\235\169\148\235\137\180_\236\178\156\235\145\165"then
while(self.sdata.lightninglod or 0)>=1 do
self.sdata.lightninglod=self.sdata.lightninglod-1;
for i=1,countkcc(const("\237\148\188\235\162\176\236\185\168\237\154\141\235\147\157"))do
local o,data=MakeAndPlaceItem("\235\167\136\235\130\152 \237\139\176\235\129\140",_S.x,_S.y);
end
end
else
Object.complete(self,menu,guid,...);
end
end

function LightningRod:menuEnabled(menu)
if menu=="\235\169\148\235\137\180_\236\178\156\235\145\165"then
return(self.sdata.lightninglod or 0)>=1;
end
return Object.menuEnabled(self,menu);
end

function LightningRod:onResetTurn(AP)
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
local a=const("\237\148\188\235\162\176\236\185\168\237\154\141\235\147\157AP\235\139\185",m["\236\167\128\236\151\173"])or 0;
self.sdata.lightninglod=(self.sdata.lightninglod or 0)+a*AP;
Object.onResetTurn(self,AP);
end
