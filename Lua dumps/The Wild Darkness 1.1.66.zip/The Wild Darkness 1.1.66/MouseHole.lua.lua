MouseHole=Object:new({
})











function MouseHole:spawn()
if not self.sdata.spawned then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
if m["\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"]then
for k,v in pairs(m["\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"])do
v.x,v.y=world.ground:getNearTileWalkable(self.tile.x,self.tile.y,Filter_Movable);
v.AP=0;
v.huntLifeT=m.T+const("\235\179\180\235\172\188\236\130\172\235\131\165\234\190\188\236\130\172\235\157\188\236\167\144",2);
world:addNpc(k,v);
end
m["\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"]=nil;
self.sdata.spawned=true;
return true;
end
end
Object.spawn(self)
end

function MouseHole:menuTouch(from,menu,onOk,onCancel)
trace("MouseHole::menuTouch"..menu);
if menu=="\235\169\148\235\137\180_\236\151\176\234\184\176\237\148\188\236\154\176\234\184\176"then
onOk();
else
onCancel();
end
end

