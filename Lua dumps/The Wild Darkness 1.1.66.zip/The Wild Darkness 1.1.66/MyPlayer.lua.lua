MyPlayer=Player:new({
height=130/_Z.PPM,
mcNickOffset={0,-130},
mcMoveToName="move_target",
spineSkin="all",
spineFileName={"player","player"},
defEvadeAnim="ani_evade",
defShieldAnim="ani_shield",

defAttackAnim={"ani_attack_onehand01","ani_attack_onehand01"},
defAttackAddAnim={"ani_attack_onehand_add01","ani_attack_onehand_add02"},
defAttackTHAnim={"ani_attack_twohand01","ani_attack_twohand01"},
defAttackTHAddAnim={"ani_attack_twohand_add01","ani_attack_twohand_add02"},
defAttackShieldAnim="ani_attack_shield",
defAttackLeftAnim="ani_attack_lefthand",
defParryRightAnim="ani_parry_Rhand",
defParryLeftAnim={"ani_parry_Lhand","ani_parry_Lhand2"},
defParryBothAnim="ani_parry_2hand",
defTorchAnim="ani_idle_touch",
findPathBlock=Block_Enemy|Filter_MyPath,
movableBlock=Filter_Movable|Block_MyTeam|Block_MyObject,
dieFade=0.6,
dieFadeT=1.5,
isMyPlayer=true,
})


function MyPlayer:init()
self.buff=_S["\235\178\132\237\148\132"];
self.sdata=_S;

do
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local typeC=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);

if typeC=="\235\141\152\236\160\132"then
self.defFootstepSnd={[0]="\235\141\152\236\160\132\234\177\183\234\184\176",[TT.WATER]="\235\172\188\234\177\183\234\184\176"};
else
self.defFootstepSnd={[0]="\235\149\133\234\177\183\234\184\176",[TT.WOOD]="\237\146\128\234\177\183\234\184\176",[TT.WATER]="\235\172\188\234\177\183\234\184\176",[TT.ICE]="\235\141\152\236\160\132\234\177\183\234\184\176"};
end
end
self.tileSnd={[TT.WATER]="\235\172\188\237\131\128\236\157\188"};
Player.init(self,"\237\148\140\235\160\136\236\157\180\236\150\180",_S);

self.animSndQueue=self.animSndQueue or{};
self.animSndQueue["ani_walk"]={"footstep",0.5,"footstep"};
self.animSndQueue["ani_walk_torch"]={"footstep",0.5,"footstep"};
self.animSndQueue["ani_walk_guard"]={"footstep",0.5,"footstep"};
self.animSndQueue["ani_walk_guard_torch"]={"footstep",0.5,"footstep"};
self:updateCostume();

if self.sdata["\234\184\176\235\179\184\235\170\168\235\147\156"]=="\236\163\189\236\157\140"then
self:die();
end

end

function MyPlayer:showDebuff(name,from)
if not self.buff[name]then
local msg=lang["\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_"..name];
if msg then
if from then
if type(from)=="table"then
local name=from.getName and from:getName();
if name then
msg=string.format("%s(%s)",msg,name);
end
elseif from=="\236\131\157\236\161\180"then
elseif from=="\236\167\128\237\152\149"then
msg=string.format("%s(%s)",msg,_L("\236\177\132\236\167\145"));
elseif type(from)=="string"then
if lang[from]then
msg=string.format("%s(%s)",msg,lang[from]);
elseif _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][from]then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][from].id;
local item=itemtable[id];
msg=string.format("%s(%s)",msg,item.name);
end
end
end
world.textbox:AddLine(msg);
end
end
end

function MyPlayer:cleanBuff()
local function cb(name)
if lang["\235\148\148\235\178\132\237\148\132\236\160\156\234\177\176\235\169\148\236\132\184\236\167\128_"..name]then
world.textbox:AddLine(lang["\235\148\148\235\178\132\237\148\132\236\160\156\234\177\176\235\169\148\236\132\184\236\167\128_"..name]);
end
end
cleanBuff(self.buff,cb);
end

function MyPlayer:appear(cb)
EquipDefaultItem();
_S["\236\131\157\235\170\133\235\160\165"]=bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
_S["\236\151\144\235\132\136\236\167\128"]=bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128");
self:pauseTurn();
self.inSleeping=true;

self.curAnim=self.defSleepIdleAnim;
self.skeleton:setAnimation(0,self.curAnim,true,0,-1);
local function f()
local function f2(evt)
if evt=="COMPLETE"then
local function onOk()
self:resumeTurn();
world:updateMenu();
end
world:addStory(_L("\236\139\156\236\158\145\235\140\128\237\153\148"),onOk)
end
end
self:wakeup(f2);

end
self.timer.add(f,f,1.5);
self:updateCostume();
cb();
end

function MyPlayer:findPathR(x,y)
local x0,y0=self.tile.x,self.tile.y;
local px,py=world.ground:TileToMap(x,y);
local block=world.ground.pathFinder:GetWalkability(px,py);
local filter=self.findPathBlock;
local ret;



local walls={};
for j=y0-1,y0+1 do
for i=x0-1,x0+1 do
local block=world.ground:getTileWalkability(i,j);
if(Block_Enemy&world.ground:getTileWalkability(i,j))==Block_Enemy then
world.ground:setTileWalkability(i,j,Block_Wall);
table.insert(walls,{i,j});
end
end
end
if self:isFloatMode()then
filter=filter|Block_Danger;
end

if block&Block_Danger>0 then

world.ground.pathFinder:SetWalkability(px,py,-Block_Danger);
ret=Player.findPathR(self,x,y,filter);
world.ground.pathFinder:SetWalkability(px,py,Block_Danger);
else
ret=Player.findPathR(self,x,y,filter);
end

for k,v in pairs(walls)do
world.ground:setTileWalkability(v[1],v[2],-Block_Wall);
end
return ret;
end

function MyPlayer:getAttackRange()
local R=self:bf("\234\179\181\234\178\169 \234\177\176\235\166\172");
local w1=self:getSlotItem("\236\152\164\235\165\184\236\134\1441");
if not w1 then
R=1;
end
return R;
end

function MyPlayer:isMelee()
return self:getAttackRange()<=1;
end

function MyPlayer:resetFace()
trace("resetFace");
self:showDebug("resetFace");
local head="head";
local avatar=avatartable[_S["\236\149\132\235\176\148\237\131\128"]];
if self.inSleeping or self:hasBuff("\236\136\152\235\169\180")then
head="head_sleep";
elseif self.isDisease then
head="head_disease";
elseif self.isWeak then
head="head_weak";
end
local attachs={
hair_front=avatar.hair_f,
hair_rear_02=avatar.hair_r,
head=avatar[head],
head2=avatar.head_tarak
};


do
local v=self.sdata["\236\138\172\235\161\175"]["\235\168\184\235\166\172"];
if v~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
local id=o.id;
local item=itemtable[id];
if item and type(item.costume)=="table"and(o["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
for k,v in pairs(item.costume)do
attachs[k]=avatar[v]or v;
end
end
end
end
for k,v in pairs(attachs)do
self.skeleton:setAttachment(k,v~=""and v or nil);
end
end

function MyPlayer:updateCostume(forceBattleMode,isTorchMode)
local weapon_R=nil;
local weapon_L=nil;
local shield=nil;
local avatar=avatartable[_S["\236\149\132\235\176\148\237\131\128"]];
local skins={["\235\170\184\237\134\181"]=avatar.body,["\235\168\184\235\166\172"]="cos_hat_N000"};
local torch=nil;
self.isDisease=not table.empty(_S["\236\167\136\235\179\145"]);
self.isWeak=self.isDisease
or HasDebuff("\235\176\176\234\179\160\237\148\148")
or HasDebuff("\237\148\188\234\179\164\237\149\168")
or HasDebuff("\235\170\169\235\167\136\235\166\132")
or HasDebuff("\236\160\128\236\178\180\236\152\168")
or HasDebuff("\234\179\160\236\151\180")
or(bf("\236\131\157\235\170\133\235\160\165")<0.2*bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"));

if isTorchMode==nil then
isTorchMode=HasTorch();
end
if forceBattleMode==nil then
forceBattleMode=self.sdata["\234\184\176\235\179\184\235\170\168\235\147\156"]=="\236\160\132\237\136\172";
end

for k,v in pairs(self.sdata["\236\138\172\235\161\175"])do
if v~=0 and not IsSubSlot(k)then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
local id=o.id;
local item=itemtable[id];
if item.costume and(o["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
if type(item.costume)=="table"then
elseif item["\236\162\133\235\165\152"]=="\235\176\169\237\140\168"then
shield=item.costume;
elseif k=="\236\152\164\235\165\184\236\134\1441"then
weapon_R=item.costume;
elseif k=="\236\153\188\236\134\1441"then
weapon_L=item.costume;
end
end
if item.skin and(o["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
skins[k]=item.skin;
end
end
end
if isTorchMode then
if not self.path and(forceBattleMode or self.touchTool or self.objectBuiding)then
self:delParticle("\237\154\131\235\182\1361");
self:delParticle("\237\154\131\235\182\1362");





else
weapon_R="item_weapon/torch";
self:delParticle("\237\154\131\235\182\1361");
self:addParticle("\237\154\131\235\182\1362");
end
else
if isTorchMode~=self.isTorchMode then
self:delParticle("\237\154\131\235\182\1361");
self:delParticle("\237\154\131\235\182\1362");
end
end

if self.touchTool then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.touchTool];
weapon_L=nil;
weapon_R=itemtable[o.id].costume;
elseif(self.nextAnim or self.curAnim)==self.defBuildAnim then
weapon_L=nil;
weapon_R=itemtable["\237\149\180\235\168\184"].costume;
end

self.isTorchMode=isTorchMode;

if not table.equal(self.skins,skins)then
if self.skins then
for k,v in pairs(self.skins)do
self.skeleton:clearSkin(v);
end
end
for k,v in pairs(skins)do
self.skeleton:setSkin(v);
end
self.skins=skins;
end







self.skeleton:setAttachment("torch",torch);
self.skeleton:setAttachment("weapon_R",weapon_R);
self.skeleton:setAttachment("weapon_L",weapon_L);
self.skeleton:setAttachment("shield",shield);
self:resetFace();

end

function MyPlayer:updateRegen(regen)
Player.updateRegen(self,regen);
for k,v in pairs(regen)do
local mc=world.ui.stat.c[k].regen;
if mc then

if v>0 then
mc:SetVisible(true);
mc:SetScaleY(math.abs(mc:GetScaleY()));
mc:SetFrameSpeed(math.clamp(v/10,0.1,1));
elseif v<0 then
mc:SetVisible(true);
mc:SetScaleY(-math.abs(mc:GetScaleY()));
mc:SetFrameSpeed(math.clamp(-v/10,0.1,1));
else
mc:SetVisible(false);
end
end
end
end

function MyPlayer:updateHasBuff(lookup,cur,deleted,new)
Player.updateHasBuff(self,lookup,cur,deleted,new);
local mc=world.ui.stat.c.icon;

for k,v in ipairs(deleted)do
if mc[v]then
mc[v]:Remove();
end
end

for k,v in ipairs(new)do
local tb=bufftable[v];
local img=tb.img;
local cnt=0;
if tb.iconcnt then
for _,k2 in pairs(tb.iconcnt)do
if self.buff[k2]and self.buff[k2][v]then
cnt=cnt+math.abs(self.buff[k2][v].c or 1);
end
end
else
cnt=1;
end
if img then
if type(img)=="table"or cnt>1 then
mc:CreateEmptyMovieClip(v);
local x=0;
for i=1,cnt do
for _,vv in safe_ipairs(img)do
local o=mc[v]:AddSymbol(vv..".png","_");
local _,_,w,h=o:GetBound();
o:SetX(x);
x=x+w;
end
end
else
mc:AddSymbol(img..".png",v);
end
end
end

world.ui.stat.c.icon.cur={};
local icons={};
for k,v in ipairs(cur)do
if mc[v]then
mc[v].blink=lookup[v];
table.insert(world.ui.stat.c.icon.cur,v);
table.insert(icons,mc[v]);
end
end

Align(icons,"hcenter,vcenter",{5,5},{0,0,0,0});
end

function MyPlayer:onChangeMode(mode)
if mode=="\236\160\132\237\136\172"then

self.nextTouchMenu=nil;

end
end

function MyPlayer:updateIcon()
Player.updateIcon(self);

if(false)then
elseif self:isBattleMode()then
self:showIconEffect("ani_effect_battle","effect_battle");
elseif self:isGuardMode()or self.sdata.nearInvestigate then
self:showIconEffect("ani_effect_battle","effect_battle_alert");
else
self:hideIcon();
end

if HasTorch()then
self:playSnd("E_torch",true);
else
self:stopSnd("E_torch");
end

end

function MyPlayer:updateHP()
world:updateStat();
end

function MyPlayer:updateEnergy()
world:updateStat();
end

function MyPlayer:play(anim,...)

if type(anim)=="string"then
local tb=avatartable[_S["\236\149\132\235\176\148\237\131\128"]];
anim=tb[anim]or anim;
end
return Player.play(self,anim,...);
end

function MyPlayer:reborn(from)
if not self.dying then
world.gameEnded=true;
self.dying=true;
if self.skillCB then
self.skillCB("COMPLETE");
self.skillCB=nil;
end
self:unplace();
if self:isSleeping()then
world.ground:SetBlendType(2);
else








end
self:delBuff("\236\176\168\236\155\144\236\157\180\235\143\153");
self.play=function()end
self.path=nil;
self.sdata["\234\184\176\235\179\184\235\170\168\235\147\156"]="\236\163\189\236\157\140";
_S.playing=2;
userDB.Save();
local function f()
world.ground:SetBlendType(2);
local function f()
world:reborn(from);
end
world:fadeMode(true,nil,f,0,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\144"),const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
end
self.timer.add(f,f,1);
end
end

function MyPlayer:die(reborn)
if not self.dying then


world.gameEnded=true;
self.dying=true;
if self.skillCB then
self.skillCB("COMPLETE");
self.skillCB=nil;
end
self:unplace();
if self:isSleeping()then
world.ground:SetBlendType(2);
else
self:play(self.defDieAnim);
if self.sdata["\234\184\176\235\179\184\235\170\168\235\147\156"]=="\236\163\189\236\157\140"then
self:updateAnim();
self.skeleton:setAttachment("head",avatartable[_S["\236\149\132\235\176\148\237\131\128"]].head_sleep);
self.skeleton:setAnimation(0,self.defDieAnim,false,-0.001);
end
end
self:delBuff("\236\176\168\236\155\144\236\157\180\235\143\153");
self.play=function()end
self.path=nil;
self.sdata["\234\184\176\235\179\184\235\170\168\235\147\156"]="\236\163\189\236\157\140";
userDB.Save();
local function f()
local mc=showPopup(world,"\235\182\128\237\153\156\237\140\157\236\151\133");
SetTextButton(mc.btnCancel,_L("\234\178\140\236\158\132 \236\152\164\235\178\132")).onClick=function()
_S.playing=0;
mc:Remove();
world.ground:SetBlendType(2);
local function f()
world:gameOver();
end
world:fadeMode(true,nil,f,0,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\144"),const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
end
local function resurrection(useDia)
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
mc:Remove();
_S["\235\182\128\237\153\156"]=_S["\235\182\128\237\153\156"]+1;
ToastMoneyConsumption("rebirth",1,t.useDia or 0,_D["\237\148\140\235\160\136\236\157\180"]);
self.play=MyPlayer.play;
self:addParticle("\235\182\128\237\153\156");
world.ground:SetBlendType(0);

self:play("ani_resurrection",nil,nil,function(evt)
if evt=="COMPLETE"then




self.inSleeping=nil;
self.dying=nil;
self.turnWait=nil;
self.turnBegan=nil;
self.turnEnded=nil;
self.turnPaused=nil;
self.preTurnEnded=nil;
world.gameEnded=false;
self.sdata["\234\184\176\235\179\184\235\170\168\235\147\156"]="\234\184\176\235\179\184";
_S.playing=1;
self:place();
self:heal(bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*const("\235\182\128\237\153\156\237\154\140\235\179\181\235\159\137","\236\131\157\235\170\133\235\160\165"));
self:healEnergy(bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")*const("\235\182\128\237\153\156\237\154\140\235\179\181\235\159\137","\236\151\144\235\132\136\236\167\128"));
_S:add("\237\151\136\234\184\176",const("\235\182\128\237\153\156\237\154\140\235\179\181\235\159\137","\237\151\136\234\184\176"),0,bf("\236\181\156\235\140\128 \235\176\176\234\179\160\237\148\148"));
_S:add("\234\176\136\236\166\157",const("\235\182\128\237\153\156\237\154\140\235\179\181\235\159\137","\234\176\136\236\166\157"),0,bf("\236\181\156\235\140\128 \235\170\169\235\167\136\235\166\132"));
_S:add("\237\148\188\235\161\156\235\143\132",const("\235\182\128\237\153\156\237\154\140\235\179\181\235\159\137","\237\148\188\235\161\156\235\143\132"),0,bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168"));

for guid,_ in pairs(const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
self:delBuff(nil,guid);
end
for k,v in pairs(const("\236\167\136\235\179\145 \235\170\169\235\161\157"))do
self:clearDisease(k);
end
for _,k in pairs(const("\235\182\128\237\153\156 \235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
self:delBuff(nil,k);
end

world:updateStat();
userDB.Save();
end
end);
elseif t.status=="nodia"then
local mc2=showPopup(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(lang.nodiaQ);
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
TryConnect(function()
local wnd=showPopup(world,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
elseif t.status=="norebirth"then
local mc2=showPopup(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y");
mc2.txt:SetText(lang.norebirth);
SetButton(mc2.btnClose).onClick=function()
mc2:Remove();
end
end
end
local onF=function(t)

end
HttpWaitAsync(world,
sendRebirth(onS,onF,useDia,_S["\235\182\128\237\153\156"]+1),
lang.waitLoginInfo);
end);
end
local dia=servertable.RebirthDia[math.min(_S["\235\182\128\237\153\156"]+1,#servertable.RebirthDia)];
local rebirth=servertable.RebirthAnk[math.min(_S["\235\182\128\237\153\156"]+1,#servertable.RebirthAnk)];

SetButton(mc.btnDia).onClick=function()
resurrection(true);
end
SetButton(mc.btnRebirth).onClick=function()
resurrection();
end
mc.btnDia:GotoAndStop(1,true);
if userDB.userInfo.rebirth>=rebirth then
mc.btnRebirth:GotoAndStop(1,true);
else
mc.btnRebirth:GotoAndStop(2,true);

end

local function updateBtn()
mc.btnDia.txt:SetText(dia);
mc.btnRebirth.txt:SetText(userDB.userInfo.rebirth.."/"..rebirth);
end
function mc:onUnload()
DelMyInfoObserver(mc);
end

AddMyInfoObserver(mc);

function mc:onUpdateMyInfo(key)
updateBtn();
end
updateBtn();
end

if HasBuilding(const("\235\182\128\237\153\156\236\161\176\234\177\180\236\152\164\235\184\140\236\160\157\237\138\184"))then
self.timer.add(f,f,1);
else
local function f()
world.ground:SetBlendType(2);
local function f()
world:gameOver();
end
world:fadeMode(true,nil,f,0,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\144"),const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
end
self.timer.add(f,f,1);
end
end
end

function MyPlayer:destroy()
Player.destroy(self);
self=nil;
end

function MyPlayer:getZOrder()
return Player.getZOrder(self)+1;
end

function MyPlayer:updateMC()
Player.updateMC(self);
end



function MyPlayer:onGroundClick(x,y,move)





do
local W=tileMeter;

centerx=x-x%W+W/2;
centery=y-y%W+W/2;

do
local sx,sy=world.ground:MapToScreen(centerx,centery);
local mc=world.ground.layer:AddSymbol(self.mcMoveToName,"mcMoveTo");
mc:SetPos(sx,sy);
mc:SetZOrder(world.ground:MapToZOrder(centerx,centery)+1);
mc:SetVisible(true);
mc.onEndScene=function()
mc:Remove();
end
end

if true then
local x,y=world.ground:MapToTile(centerx,centery);
self:setTarget(x,y,move);
world:centerScroll(nil,true);
end
end
end

function MyPlayer:update(dt)
Player.update(self,dt);
end

function MyPlayer:onResetTurn(AP)
if self.dying then
return;
end





trace("MyPlayer:onResetTurn",AP);
self:updateDisease(AP);

if ev("\236\182\148\236\156\132\236\161\176\234\177\180")then
_S["\236\182\148\236\154\180\234\184\176\234\176\132"]=_S["\236\182\148\236\154\180\234\184\176\234\176\132"]+AP;
else
_S["\236\182\148\236\154\180\234\184\176\234\176\132"]=0;
end
if ev("\235\141\148\236\156\132\236\161\176\234\177\180")then
_S["\235\141\148\236\154\180\234\184\176\234\176\132"]=_S["\235\141\148\236\154\180\234\184\176\234\176\132"]+AP;
else
_S["\235\141\148\236\154\180\234\184\176\234\176\132"]=0;
end




local debuffs=const("\234\184\176\235\179\184 \235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157");
local extra=const("\236\182\148\234\176\128 \235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157");
for k,v in pairs(debuffs)do
SetDebuff(v,ev(v.."\235\148\148\235\178\132\237\148\132\235\176\156\236\131\157\236\161\176\234\177\180"),AP);
end
for k,v in pairs(extra)do
SetExtraDebuff(debuffs[k],v,ev(v.."\235\148\148\235\178\132\237\148\132\235\176\156\236\131\157\236\161\176\234\177\180"),AP);
end




if(_S["\237\148\140\235\158\152\234\183\184"]["\237\131\128\235\157\189"]or 0)>0 then
SetDebuff("\237\131\128\235\157\189",true,AP);
elseif HasDebuff("\237\131\128\235\157\189")then
SetDebuff("\237\131\128\235\157\189",not ev("\237\131\128\235\157\189\235\148\148\235\178\132\237\148\132\237\149\180\236\160\156\236\161\176\234\177\180"),AP);
else
SetDebuff("\237\131\128\235\157\189",ev("\237\131\128\235\157\189\235\148\148\235\178\132\237\148\132\235\176\156\236\131\157\236\161\176\234\177\180"),AP);
end

if HasDebuff("\236\182\148\236\155\128")then
_S:add("\236\178\180\236\152\168",ev("\236\178\180\236\152\168 \234\176\144\236\134\140"),-ev("\236\181\156\235\140\128 \236\182\148\236\156\132"),0,ev("\236\178\180\236\152\168 \234\176\144\236\134\140\237\139\177"),AP);
elseif HasDebuff("\235\141\148\236\155\128")then
_S:add("\236\178\180\236\152\168",ev("\236\178\180\236\152\168 \236\166\157\234\176\128"),0,ev("\236\181\156\235\140\128 \235\141\148\236\156\132"),ev("\236\178\180\236\152\168 \236\166\157\234\176\128\237\139\177"),AP);
else
if _S["\236\178\180\236\152\168"]<0 then
_S:add("\236\178\180\236\152\168",ev("\236\178\180\236\152\168 \236\160\149\236\131\129\237\153\148 \236\166\157\234\176\128"),-ev("\236\181\156\235\140\128 \236\182\148\236\156\132"),0,ev("\236\178\180\236\152\168 \236\160\149\236\131\129\237\153\148\237\139\177"),AP);
elseif _S["\236\178\180\236\152\168"]>0 then
_S:add("\236\178\180\236\152\168",ev("\236\178\180\236\152\168 \236\160\149\236\131\129\237\153\148 \234\176\144\236\134\140"),0,ev("\236\181\156\235\140\128 \235\141\148\236\156\132"),ev("\236\178\180\236\152\168 \236\160\149\236\131\129\237\153\148\237\139\177"),AP);
end
end

if _S["\236\178\180\236\152\168"]<=-ev("\236\181\156\235\140\128 \236\182\148\236\156\132")then
_S["\236\181\156\235\140\128 \236\182\148\236\154\180\234\184\176\234\176\132"]=_S["\236\181\156\235\140\128 \236\182\148\236\154\180\234\184\176\234\176\132"]+AP;
else
_S["\236\181\156\235\140\128 \236\182\148\236\154\180\234\184\176\234\176\132"]=0;
end

if _S["\236\178\180\236\152\168"]>=ev("\236\181\156\235\140\128 \235\141\148\236\156\132")then
_S["\236\181\156\235\140\128 \235\141\148\236\154\180\234\184\176\234\176\132"]=_S["\236\181\156\235\140\128 \235\141\148\236\154\180\234\184\176\234\176\132"]+AP;
else
_S["\236\181\156\235\140\128 \235\141\148\236\154\180\234\184\176\234\176\132"]=0;
end

if ev("\235\143\133\234\176\144 \236\161\176\234\177\180")then
self:setDiseaseP("\235\143\133\234\176\144");
end

if ev("\236\151\180\236\130\172\235\179\145 \236\161\176\234\177\180")then
self:setDiseaseP("\236\151\180\236\130\172\235\179\145");
end

_S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149T"]=_S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149T"]+AP;
while _S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149T"]>=ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \237\154\140\235\179\181","T")do
_S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149T"]=_S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149T"]-ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \237\154\140\235\179\181","T");
_S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149"]=math.max(0,_S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149"]-ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \237\154\140\235\179\181","V"));
end
self:addDebufP(bf("\236\136\152\235\169\180\237\153\149\235\165\160")*100,"\236\136\152\235\169\180",self);

if ev("\236\131\157\236\161\180 \235\179\184\235\138\165\235\176\156\236\131\157\236\161\176\234\177\180")then
self:addDebuf("\236\131\157\236\161\180 \235\179\184\235\138\165",self);
else
self:delBuff(nil,"\236\131\157\236\161\180 \235\179\184\235\138\165");
end

if HasDebuff("\237\131\128\235\157\189")then

_S:add("\236\131\157\235\170\133\235\160\165",-bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*0.01,0,(bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")),100,AP,"\237\131\128\235\157\189\236\131\157\235\170\133\235\160\165\234\176\144\236\134\140T");
_S:add("\236\152\164\236\151\188",math.min(0,-(self:bf("\236\152\164\236\151\188 \237\154\140\235\179\181"))),0,bf("\236\181\156\235\140\128 \236\152\164\236\151\188"),bf("\236\152\164\236\151\188 \237\154\140\235\179\181\237\139\177"),AP);
end








local HP=bf("\236\131\157\235\170\133\235\160\165");
local EP=bf("\236\151\144\235\132\136\236\167\128");

do
local maxHP=bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
local v,param=self:bf("\236\131\157\235\170\133\235\160\165\235\141\148\237\149\168");
if v~=0 then
for id,v in pairs(param)do
if v.c<0 then
self:recordDamage(id,-v.c);
end
end
_S:add("\236\131\157\235\170\133\235\160\165",v,0,maxHP);
trace("\236\131\157\235\170\133\235\160\165\235\141\148\237\149\168",v,v/maxHP);
end
end
_S:add("\236\151\144\235\132\136\236\167\128",self:bf("\236\151\144\235\132\136\236\167\128\235\141\148\237\149\168"),0,(bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")));
_S:add("\236\152\164\236\151\188",world.ground:getDarkforce(self.tile.x,self.tile.y),0,ev("\236\181\156\235\140\128 \236\152\164\236\151\188"));

_S:add("\236\131\157\235\170\133\235\160\165",math.max(0,(self:bf("\236\131\157\235\170\133\235\160\165 \236\158\172\236\131\157"))),0,bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"),bf("\236\131\157\235\170\133\235\160\165 \236\158\172\236\131\157\237\139\177"),AP);
do
local add=_S:add("\236\151\144\235\132\136\236\167\128",math.max(0,(self:bf("\236\151\144\235\132\136\236\167\128 \236\158\172\236\131\157"))),0,bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128"),bf("\236\151\144\235\132\136\236\167\128 \236\158\172\236\131\157\237\139\177"),AP);
if add>0 and math.randpercent(self:bf("\236\151\144\235\132\136\236\167\128 \236\158\172\236\131\157 \236\182\148\234\176\128 \235\176\156\236\131\157 \237\153\149\235\165\160")*100)then
self:healEnergy(add);
end
end
_S:add("\237\151\136\234\184\176",math.max(0,(self:bf("\235\176\176\234\179\160\237\148\148 \236\166\157\234\176\128\235\159\137"))),0,bf("\236\181\156\235\140\128 \235\176\176\234\179\160\237\148\148"),bf("\235\176\176\234\179\160\237\148\148 \236\166\157\234\176\128\235\159\137\237\139\177"),AP);
_S:add("\234\176\136\236\166\157",math.max(0,(self:bf("\235\170\169\235\167\136\235\166\132 \236\166\157\234\176\128\235\159\137"))),0,bf("\236\181\156\235\140\128 \235\170\169\235\167\136\235\166\132"),bf("\235\170\169\235\167\136\235\166\132 \236\166\157\234\176\128\235\159\137\237\139\177"),AP);
_S:add("\237\148\188\235\161\156\235\143\132",math.max(0,(self:bf("\237\148\188\235\161\156\235\143\132 \236\166\157\234\176\128\235\159\137"))),0,bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168"),bf("\237\148\188\235\161\156\235\143\132 \236\166\157\234\176\128\235\159\137\237\139\177"),AP);
_S:add("\237\148\188\235\161\156\235\143\132",-(bf("\237\148\188\235\161\156 \237\154\140\235\179\181"))*AP/10,0,(bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")));








do
local dHP=bf("\236\131\157\235\170\133\235\160\165")-HP;
if dHP>=0.01 then
self:showFloating(tostringf(dHP),const("HP\236\166\157\234\176\128\236\131\137"));
elseif dHP<=-0.01 then
self:showFloating(tostringf(dHP),const("HP\234\176\144\236\134\140\236\131\137"));
end








end

do
for k,v in pairs(_S["\236\191\168\237\131\128\236\158\132"])do
_S["\236\191\168\237\131\128\236\158\132"][k]=_S["\236\191\168\237\131\128\236\158\132"][k]-AP;
if _S["\236\191\168\237\131\128\236\158\132"][k]<=0 then
_S["\236\191\168\237\131\128\236\158\132"][k]=nil;
end
end
end







if bf("\236\131\157\235\170\133\235\160\165")<=0 then
self:die();
else
self:investigate();
end







self:cleanBuff();







Player.onResetTurn(self,AP);






self:updateIcon();
eventDispatcher:send("ResetTurn");






end


function MyPlayer:queryObjectInSight(maxR)
local function query(o)
if o.isMyPlayer or o.dying or(o.isHide and o:isHide())or not world.ground.pathFinder:LOS(o.tile.x,o.tile.y)then
return false;
end
return true;
end
local _,list=world.grid:QueryR(self.tile.x,self.tile.y,maxR,query);
return list;
end

function MyPlayer:isDetect()
return true;
end

function MyPlayer:getDetect(from)
if self.sdata.investList then
return self.sdata.investList[from.guid]or 0;
end
return 0;
end


function MyPlayer:calcDetect(from)
local dist=self:getDistance(from);
local mode=self:ev("\236\157\180\235\143\153\235\170\168\235\147\156");
local n=self:bf("\234\176\144\236\167\128");
local inField=IsInField();
local tz=GetTimeZone();
local a,b;
if inField and tz~=TimeZone_Night then
a,b=table.unpack(self:ev("\237\131\144\236\131\137\237\149\132\235\147\156\236\136\152\236\185\152",mode));
elseif HasTorch()then
a,b=table.unpack(self:ev("\237\131\144\236\131\137\237\154\131\235\182\136\236\136\152\236\185\152",mode));
else
a,b=table.unpack(self:ev("\237\131\144\236\131\137\236\136\152\236\185\152",mode));
end
return n+math.randrange(a or 0,b or 0)-self:ev("\234\177\176\235\166\172\235\179\132\237\131\144\236\131\137\236\136\152\236\185\152\234\176\144\236\134\140",mode)*dist,(a+b)/2,n;
end

function MyPlayer:investigate()
self.sdata.nearInvestigate=nil;
self.sdata.investList={};
local objects=self:queryObjectInSight(self:ev("\237\131\144\236\131\137\235\178\148\236\156\132"));
local tz=GetTimeZone();
local mapId=_S["\237\152\132\236\158\172\235\167\181"];

if objects then
for _,v in pairs(objects)do
local n=self:calcDetect(v);
if v.isObject then
if v.tb["\235\176\156\234\178\172"]then
local id=v.sdata.id;
_S["\235\176\156\234\178\172\235\167\181"][mapId]=_S["\235\176\156\234\178\172\235\167\181"][mapId]or{};
if not table.find(_S["\235\176\156\234\178\172\235\167\181"][mapId],v.guid)then
table.insert(_S["\235\176\156\234\178\172\235\167\181"][mapId],v.guid);
end
do

_S["\236\132\164\236\185\152\235\167\181"][id]=_S["\236\132\164\236\185\152\235\167\181"][id]or{};
local find;
for _,vv in pairs(_S["\236\132\164\236\185\152\235\167\181"][id])do
if vv[2]==v.guid then
find=true;
break;
end
end
if not find then
table.insert(_S["\236\132\164\236\185\152\235\167\181"][id],{mapId,v.guid});
end
end
if v.sdata.id~="\236\149\132\236\157\180\237\133\156"then
local dist=math.max(math.abs(v.tile.x-self.tile.x),math.abs(v.tile.y-self.tile.y));
if dist<=_Z.ShowObjectNick then
Mission("\235\176\156\234\178\172",1,v.sdata.id);
end
end
end
end

if v.onInvestigate then
v:onInvestigate(n);
end

if n>0 then
self.sdata.investList[v.guid]=n;
if v.isObject then
local h=v.sdata["\236\157\128\235\176\128\235\143\132"];
if(h or 0)>0 then
if n>=h then
trace("\237\138\184\235\158\169 \235\176\156\234\178\172");
v:detect();
local from={x=v.pos.x,y=v.pos.y,z=0};
local to={x=v.pos.x,y=v.pos.y,z=0};
local p=self:addProjectile(Bomb,from,to,{particle="particle_find"});
elseif n>=h/2 then
trace("\237\138\184\235\158\169 \236\163\188\236\157\152");
self.sdata.nearInvestigate=true;
end
end
end
end
end
end
end

function MyPlayer:onEnterTile(tx,ty)
Player.onEnterTile(self,tx,ty);
do
local _,objects=self:queryObject({x=tx,y=ty},0);
for k,v in safe_pairs(objects)do
v:collision(self);
end
end
end

function MyPlayer:addExp(from,exp)
if from~=self then
exp=exp or from:bf("\236\160\156\234\179\181 \234\178\189\237\151\152\236\185\152");
if from then
self.sdata["\236\178\152\236\185\152"][from.sdata.id]=(self.sdata["\236\178\152\236\185\152"][from.sdata.id]or 0)+1;
end
self.sdata["\234\178\189\237\151\152\236\185\152"]=self.sdata["\234\178\189\237\151\152\236\185\152"]+exp;
while true do
local req=self:ev("\237\149\132\236\154\148 \234\178\189\237\151\152\236\185\152");
if self.sdata["\234\178\189\237\151\152\236\185\152"]>=req then
AddScore(ev("\235\170\168\237\151\152\236\160\144\236\136\152\236\166\157\234\176\128","\235\160\136\235\178\168\236\151\133"));
self.sdata["\234\178\189\237\151\152\236\185\152"]=self.sdata["\234\178\189\237\151\152\236\185\152"]-req;
self.sdata["\235\160\136\235\178\168"]=self.sdata["\235\160\136\235\178\168"]+1;
self.sdata["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]=self.sdata["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]+1;






self:playSndQueue("\235\160\136\235\178\168 \236\151\133");
self:addParticle("\235\160\136\235\178\168\236\151\133");
Mission("\235\160\136\235\178\168",1);
else
break;
end
end
end
end


function MyPlayer:getWalkDur()
local s=self:bf("\236\157\180\235\143\153AP")+GetArmorReqStr();
local d=_Z.walkDur*s/10;
return d;
end


function MyPlayer:getArmorReqStr()
return GetArmorReqStr();
end

function MyPlayer:beganTurn(type)




world.ui.menu["\237\132\180\235\132\152\234\185\128"]:GotoAndPlay(1);
do
local req=ev("\236\149\161\236\133\152\235\179\132\235\176\176\234\179\160\237\148\148\236\166\157\234\176\128",type);
if req then
_S:add("\237\151\136\234\184\176",req,0,bf("\236\181\156\235\140\128 \235\176\176\234\179\160\237\148\148"));
end
end
if type=="walk"then
local s=self:bf("\236\157\180\235\143\153AP")+GetArmorReqStr();






world.tickAP=s;
self:updateCostume();
trace(type,s);
elseif type=="attack"then
local s=self:ev("\234\179\181\234\178\169AP");
if s<const("\237\149\156\237\132\180")then
s=const("\237\149\156\237\132\180");
end
world.tickAP=s;
elseif type=="attackobject"then
world.tickAP=const("\237\149\156\237\132\180");
elseif type=="touch"then
world.tickAP=const("\237\149\156\237\132\180");
elseif type=="build"then
world.tickAP=const("\237\149\156\237\132\180");
elseif type=="turn"then
world.tickAP=const("\237\149\156\237\132\180");
local mc=self.ui:AddSymbol("\235\168\184\235\166\172\236\156\132\237\132\180\235\132\152\234\185\128");
mc:SetFrameSpeed(userDB.option.gameSpeed);
mc:SetY(self.mcNickOffset[2]);
local function f()
mc:Remove();
self:preEndTurn();
end
self.timer.add(f,f,mc:GetTotalFrame()/30);
elseif type=="switch"then
world.tickAP=const("\237\149\156\237\132\180");
elseif type=="next"then
world.tickAP=const("\237\149\156\237\132\180");
self:preEndTurn();
elseif type=="craft"then
world.tickAP=const("\237\149\156\237\132\180");
self:preEndTurn();
elseif type=="sleep"then
if self:hasBuff("\236\157\180\235\143\153\235\182\136\234\176\128")or self:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")then
return false;
end







world.tickAP=const("\237\149\156\237\132\180");
self:pauseTurn();
self:sleep();
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local houseObjId=_S.maps[mapId]["\236\176\189\234\179\160"];

local sleepAP=0;
local stz=GetTimeZone();
local dieDebuf={};
self.play=function()end
local function f()
local c=0;
local AP=world.tickAP;
for k,v in pairs(const("\234\184\176\235\179\184 \235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
if HasDebuff(v)then
c=c+1;
end
end
for k,v in pairs(const("\236\182\148\234\176\128 \235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
if HasDebuff(v)then
c=c+1;
end
end
_G["\235\148\148\235\178\132\237\148\132 \234\176\156\236\136\152"]=c;
_S:add("\237\148\188\235\161\156\235\143\132",(1+bf("\236\136\152\235\169\180 \237\148\188\235\161\156\235\143\132 \234\176\144\236\134\140"))*-(bf("\237\148\188\235\161\156 \237\154\140\235\179\181")+bf("\236\136\152\235\169\180 \237\148\188\235\161\156 \237\154\140\235\179\181"))*AP/10,0,(bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")));
_S:add("\236\131\157\235\170\133\235\160\165",bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*bf("\236\136\152\235\169\180 \236\131\157\235\170\133\235\160\165 \236\166\157\234\176\128")*0.01*AP/10,0,(bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")));
_S:add("\236\151\144\235\132\136\236\167\128",bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")*bf("\236\136\152\235\169\180 \236\151\144\235\132\136\236\167\128 \236\166\157\234\176\128")*0.01*AP/10,0,(bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")));
_G["\235\148\148\235\178\132\237\148\132 \234\176\156\236\136\152"]=nil;
trace("\236\136\152\235\169\180 \236\131\157\235\170\133\235\160\165 \236\166\157\234\176\128",bf("\236\136\152\235\169\180 \236\131\157\235\170\133\235\160\165 \236\166\157\234\176\128")*0.01*AP/10);
trace("\236\131\157\235\170\133\235\160\165 \236\158\172\236\131\157",(self:bf("\236\131\157\235\170\133\235\160\165 \236\158\172\236\131\157")));
sleepAP=sleepAP+AP;
self:updateBuff(AP);
self:onResetTurn(AP);
UpdateGame(AP);
for k,v in pairs(const("\236\136\152\235\169\180\236\130\172\235\167\157\235\148\148\235\178\132\237\148\132"))do
if HasDebuff(k)then
dieDebuf[k]=(dieDebuf[k]or 0)+1;
if dieDebuf[k]>=v then
world.textbox:AddLine(_L("\236\163\189\236\157\128\236\157\180\236\156\160_\236\136\152\235\169\180\236\164\145 "..k));
self:recordDamage(k);
self:die();
return false;
end
end
end

if _S["\237\148\188\235\161\156\235\143\132"]==0 then
if stz>TimeZone_Night and sleepAP<const("\236\181\156\236\134\140\236\136\152\235\169\180")then
return true;
elseif IsInDungeon()or stz>TimeZone_Night or GetTimeZone()~=TimeZone_Night then
world.textbox:AddLine(_L("\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_\236\158\160\234\185\184"));





return false;
end
end


do
local tz=GetTimeZone();
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local isNight=mapType=="\237\149\132\235\147\156"and tz==TimeZone_Night and ev("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169 \235\176\164\236\138\181\234\178\169 \237\153\149\235\165\160")>math.random();
local postfix="";
if isNight then
postfix="_\235\176\164";
end
local typeC=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);
local p=ev("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169 \237\153\149\235\165\160"..postfix)[typeC]or 0;
trace("\236\138\181\234\178\169\234\178\128\236\130\172",p);
if p>math.random()then
trace("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169");
_G.needMonsterInSleep={typeC,isNight};
return false;
end
end

return true;
end
local cb=function()
while true do
if not f()then
trace("sleep end");
self:delBuff(nil,"sleep");
local v=self:bf("\236\136\152\235\169\180\236\139\156 \236\167\128\237\140\161\236\157\180 \236\182\169\236\160\132");
if v>0 then
for k,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o["\236\182\169\236\160\132"]and itemtable[o.id]["\236\162\133\235\165\152"]=="\236\167\128\237\140\161\236\157\180"then
local d=math.floor(sleepAP*v);
o["\236\182\169\236\160\132"][1]=math.min(o["\236\182\169\236\160\132"][1]+d,o["\236\182\169\236\160\132"][2]);
end
end
end
end
local function finish()
local function cb()
local function f(evt,param)
if evt=="COMPLETE"then
self.skeleton:setAttachment("bedroll");
self:resumeTurn();
self:preEndTurn();
Mission("\236\158\160\236\158\144\234\184\176",1);
end
end
self.play=MyPlayer.play;
self:wakeup(f);
this:updateStat();
world:updateMenu();
end

world:fadeMode(false,nil,cb,nil,nil,nil,world.timer);
end
if not self.dying then
if _G.needMonsterInSleep then
local mc=world.fade:AddSymbol("\235\170\172\236\138\164\237\132\176\236\138\181\234\178\169\236\149\160\235\139\136");
mc.onEndScene=function()
mc:Remove();
if houseObjId then
_G.nextMap=_S.maps[mapId]["\236\131\129\236\156\132"];
root:GotoAndStop("travel");
else
self:makeMonsterInSleep(table.unpack(_G.needMonsterInSleep));
_G.needMonsterInSleep=nil;
end
finish();
end
else
finish();
end
else
local function cb()
self.skeleton:setAttachment("bedroll");
self:resumeTurn();
self:preEndTurn();
end
world:fadeMode(false,nil,cb,nil,nil,nil,world.timer);
end
break;
end
end
end
world:fadeMode(true,const("\236\136\152\235\169\180 \237\132\180\235\132\152\234\185\128 \236\139\156\234\176\132"),cb,nil,nil,nil,world.timer);
end
Player.beganTurn(self,type);
if world.ground.cancelSelectTile then
world.ground.cancelSelectTile();
end
end

function MyPlayer:makeMonsterInSleep(type,isNight)
trace("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169");
local postfix="";
if isNight then
postfix="_\235\176\164";
end
local cnt=countkcc(ev("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169 \236\131\157\236\132\177 \235\167\136\235\166\172"..postfix)[type]);
local goblin=ev("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169 \235\143\132\236\160\129 \234\179\160\235\184\148\235\166\176 \237\153\149\235\165\160")>math.random();
local r=ev("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169 \236\131\157\236\132\177 \235\178\148\236\156\132");

for i=1,cnt,1 do









do
local _,_,o=SpawnMonster(self.tile.x,self.tile.y,1,r,"\235\170\172\236\138\164\237\132\176",nil,nil,nil,nil,const("\235\170\172\236\138\164\237\132\176 \236\138\181\234\178\169 \237\140\168\237\132\180"));

if o then
o:aggro(self);
end
end
end
if goblin then
local _,_,o=SpawnMonster(self.tile.x,self.tile.y,1,r,"\235\143\132\236\160\129 \234\179\160\235\184\148\235\166\176");
if o then
o:aggro(self);
end
end

end

function MyPlayer:hasDebuff(name)
return HasDebuff(name);
end





function MyPlayer:setTargetBuiding(o,x,y,a,id,guids)
self:cancelTarget();
self.clickPos={x=x,y=y};
self.targetBuilding={param={o,x,y,a,id,guids}};
end

function MyPlayer:cancelTarget()

Player.cancelTarget(self);
self.clickPos=nil;
self.nextTouchMenu=nil;
if self.targetBuilding then
local o=self.targetBuilding.param[1];
o:destroy();
self.targetBuilding=nil;
end
end


function MyPlayer:setTarget(x,y,move)
self:cancelTarget();
trace("setTarget",x,y);
self.clickPos={x=x,y=y,move=move};









end


function MyPlayer:getSecondaryWeaponInfo()
local vars=self.vars;
local w2,lv2,tier2,wGuid2=self:getSlotItem("\236\153\188\236\134\1441");
if w2 then
local dmgA,dmgB=GetItemDamage(wGuid2);
vars["\234\179\181\234\178\169 \237\131\128\236\158\133"]="\236\153\188\236\134\144 \234\179\181\234\178\169";
vars["\235\141\176\235\175\184\236\167\128 \237\131\128\236\158\133"]="\235\172\188\235\166\172";
vars["\234\179\181\234\178\169 \235\172\180\234\184\176"]=w2;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176G"]=wGuid2;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176 \236\154\148\234\181\172\237\158\152"]=GetItemReqStr(wGuid2);
vars["\234\179\181\234\178\169\236\158\144 \234\179\181\234\178\169\235\160\165"]=(dmgA+dmgB)/2;
vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]=dmgA;
vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]=dmgB;
return true;
end
end

function MyPlayer:getPrimaryWeaponInfo()
local vars=self.vars;
local w1,lv1,tier1,wGuid1=self:getSlotItem("\236\152\164\235\165\184\236\134\1441");
local l1=self:getSlotItem("\236\153\188\236\134\1441");
if w1 then
local tb=itemtable[w1];
if const("\237\131\132\236\149\189\236\162\133\235\165\152",tb["\236\162\133\235\165\152"])and(not l1 or const("\237\131\132\236\149\189\236\162\133\235\165\152",tb["\236\162\133\235\165\152"])~=itemtable[l1]["\236\162\133\235\165\152"])then
return false;
else
local dmgA,dmgB=GetItemDamage(wGuid1);
if l1 then
local ltb=itemtable[l1];
if ltb["\236\162\133\235\165\152"]and const("\237\131\132\236\149\189\236\162\133\235\165\152",tb["\236\162\133\235\165\152"])==ltb["\236\162\133\235\165\152"]then
assert(ltb["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]and ltb["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"],w1,l1);
dmgA=dmgA*ltb["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"];
dmgB=dmgB*ltb["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"];
trace("\237\131\132\236\149\189 \235\141\176\235\175\184\236\167\128 \236\166\157\234\176\128",ltb["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]);
end
end
vars["\234\179\181\234\178\169 \235\172\180\234\184\176"]=w1;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176G"]=wGuid1;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176 \236\154\148\234\181\172\237\158\152"]=GetItemReqStr(wGuid1);
vars["\234\179\181\234\178\169\236\158\144 \234\179\181\234\178\169\235\160\165"]=(dmgA+dmgB)/2;
vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]=dmgA;
vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]=dmgB;
return true;
end
else
local tb=itemtable["\234\184\176\235\179\184 \236\163\188\235\168\185"];
_G["\237\139\176\236\150\180"]=tb["\237\139\176\236\150\180"]or 0;
local d=ev("\235\172\188\235\166\172 \235\141\176\235\175\184\236\167\128 \237\145\156\236\164\128\234\176\146");





local a=tb["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]*d;
local b=tb["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]*d;
_G["\237\139\176\236\150\180"]=nil;
vars["\235\172\188\235\166\172 \235\141\176\235\175\184\236\167\128 \237\145\156\236\164\128\234\176\146"]=d;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176"]="\234\184\176\235\179\184 \236\163\188\235\168\185";
vars["\234\179\181\234\178\169 \235\172\180\234\184\176 \236\154\148\234\181\172\237\158\152"]=10;
vars["\234\179\181\234\178\169\236\158\144 \234\179\181\234\178\169\235\160\165"]=(a+b)/2;
vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]=a;
vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]=b;
return true;
end
end


function MyPlayer:beginTurn()
local targetObjects;
local targetObject;
local targetEnemy;















self.target=self.clickPos;
if self.targetBuilding then
elseif self.clickPos and not self.clickPos.move then
if world.ground:inLOS(self.clickPos.x,self.clickPos.y)then
targetEnemy=targetEnemy or self:queryEnemy(self.clickPos);
if targetEnemy then
self.target=targetEnemy.tile;
else
local dropItems={};
local t,list=self:queryObject(self.clickPos);
local targetD;
if t then
for k,v in pairs(list)do
if not v.dying and v.tb.class=="DropItem"then
if(t.tile.x==self.tile.x and t.tile.y==self.tile.y)or
world.ground:canTileWalkable(t.tile.x,t.tile.y,self.movableBlock)then
table.insert(dropItems,v);
end
else
if v:canTouch()then
local dist=math.max(math.abs(v.tile.x-self.tile.x),math.abs(v.tile.y-self.tile.y));
if not targetD or targetD>dist then
targetD=dist;
targetObject=v;
self.target=targetObject.front;
end
else

end
end
end
if not table.empty(dropItems)then
targetObjects=dropItems;
targetObject=nil;
else


end
end
end
end
end

if self:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")then
self:beganTurn("turn");
return;
end

if self:hasBuff("\234\179\181\237\143\172")then
self.target=nil;
if self.buff["\234\179\181\237\143\172"]["\234\179\181\237\143\172"]then
local o=world:findCharac(self.buff["\234\179\181\237\143\172"]["\234\179\181\237\143\172"].from);
if o then
self:runAway(o);
end
if self.target then
Player.beginTurn(self);
end
end

if not self.target then
self:beganTurn("turn");
end
return;
end

if self:hasBuff("\236\176\168\236\155\144\236\157\180\235\143\153")then
local t=self.buff["\236\176\168\236\155\144\236\157\180\235\143\153"]["\236\176\168\236\155\144\236\157\180\235\143\153"];
t.cool=t.cool-const("\237\149\156\237\132\180");
if t.cool<=0 then
self:delBuff("\236\176\168\236\155\144\236\157\180\235\143\153");
self:pauseTurn();
local function f()
_G.nextMap=t.mapId;
_G.nextMapFromElevator=t.elevator;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
else
self:beganTurn("turn");
end
return;
end

if self.nextSkill then
self:cancelTarget();
self:actSkill(table.unpack(self.nextSkill));
self.nextSkill=nil;
return;
end

if self.nextSpell then
self:cancelTarget();
self:spell(table.unpack(self.nextSpell));
self.nextSpell=nil;
return;
end

if self.target then
if targetEnemy then

local dist=self:getDistance(targetEnemy);
local R=self:getAttackRange();
local w1,lv1,tier1,wGuid1=self:getSlotItem("\236\152\164\235\165\184\236\134\1441");
local w2,lv2,tier2,wGuid2=self:getSlotItem("\236\153\188\236\134\1441");

local noBullet;
if w1 and const("\237\131\132\236\149\189\236\162\133\235\165\152",itemtable[w1]["\236\162\133\235\165\152"])then
if not w2 or const("\237\131\132\236\149\189\236\162\133\235\165\152",itemtable[w1]["\236\162\133\235\165\152"])~=itemtable[w2]["\236\162\133\235\165\152"]then
noBullet=true;
elseif w2 then
R=R+(itemtable[w2]["\234\179\181\234\178\169 \234\177\176\235\166\172"]or 0);
end
end

if R==0 then
self:addChat(_L("\234\179\181\234\178\169\235\182\136\234\176\128"));
self:cancelTarget();
return false;
elseif dist==1 and not world.ground:canAttackTo(self.center,targetEnemy.center,R)then

self:addChat(_L("\234\179\181\234\178\169\235\182\136\234\176\128"));
self:cancelTarget();
return false;
elseif dist<=R then

if noBullet then
self:addChat(_L("\237\153\148\236\130\180 \236\151\134\236\157\140"));
self:cancelTarget();
return false;
elseif self:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")then
return false;
end

if targetEnemy:isTurnBusy()then

return false;
end
self:attack(targetEnemy);
self:cancelTarget();






return true;
end
end

local dist=math.max(math.abs(self.target.x-self.tile.x),math.abs(self.target.y-self.tile.y));
if targetObject or targetObjects then
if targetObject then
if targetObject:isInTouch(dist,self)then

trace("targetObject:isInTouch");
if dist==1 and string.starts(targetObject.tb["\236\160\149\235\169\180"],"\236\167\132\236\158\133")and not world.ground.pathFinder:CanWalkabilityTo(self.center.x,self.center.y,targetObject.center.x,targetObject.center.y,self.movableBlock)then
else

self:touch(targetObject);






return true;
end
end
end

if targetObjects and dist==0 then
self:pick(targetObjects);
self:cancelTarget();
end
else
if dist==0 then
local tile=world.ground:getTile(self.target.x,self.target.y);
local btns=self:getTileMenu(tile);
if btns then
local function ok(menu)
if menu=="\235\169\148\235\137\180_\235\172\188\235\167\136\236\139\156\234\184\176"then
local idx=math.randlist(ev("\235\172\188\234\179\181\234\184\137\236\155\144","\235\172\188\237\131\128\236\157\188"));
local ids={"\235\172\188","\235\141\148\235\159\172\236\154\180 \235\172\188","\236\132\177\236\136\152"};
local spell=ids[idx].." \235\167\136\236\139\156\234\184\176";
local function onSpellEnd()
EatItem({id=ids[idx]});
end
self:useSpell(spell,onSpellEnd);
elseif menu=="\235\169\148\235\137\180_\235\172\188\235\156\168\234\184\176"then
local function _ok2(guid)
local function f()
self:preEndTurn();
MakeWaterBottle(guid,"\235\172\188\237\131\128\236\157\188");
end
local function cb(evt,param)
if evt=="COMPLETE"then
f();
end
end
self:beganTurn("touch");
self:playItemSound("\236\164\141\234\184\176",id);
self:play("ani_get",nil,nil,cb);
end
local function onCancel()
end
SelectItemPopup(world,_ok2,onCancel,{"\234\184\176\237\131\128"},"\235\172\188\235\156\168\234\184\176",{hasProp={"\235\172\188\235\156\168\234\184\176"}});
end
end
local function cancel()
end
TileMenuPopup(self.pos,ok,cancel,btns);

self:cancelTarget();
return true;
end
end
end

if dist==1 and self.targetBuilding then
self.targetBuilding.ppos={x=self.tile.x,y=self.tile.y};
elseif dist==0 and self.targetBuilding then
local o=self.targetBuilding.param[1];

local ppos;
do
local px,py;
if self.targetBuilding.ppos then
local x,y=self.targetBuilding.ppos.x,self.targetBuilding.ppos.y;
if world.ground:canTileWalkable(x,y,Filter_MyPath)then
px,py=x,y;
end
end
if not px or not py then
px,py=world.ground:getNearGotoTile(o.tile.x,o.tile.y,1,1,self.tile.x,self.tile.y,Filter_MyPath);
trace("\236\156\132\237\151\152 \236\152\164\235\184\140\236\160\157\237\138\184",self.tile,px,py);
end
if px and py then
ppos={x=px,y=py};
else
self:cancelTarget();
end
end

if self.targetBuilding then
trace("BuildBuilding");
if BuildBuilding(ppos,table.unpack(self.targetBuilding.param))then
self.targetBuilding=nil;
else
self:cancelTarget();
end
end
end
end
::done::

Player.beginTurn(self);
end

function MyPlayer:warp(mapId,elevator)


self:addBuff("\236\176\168\236\155\144\236\157\180\235\143\153","\236\176\168\236\155\144\236\157\180\235\143\153",1);
local t=self.buff["\236\176\168\236\155\144\236\157\180\235\143\153"]["\236\176\168\236\155\144\236\157\180\235\143\153"];
t.mapId=mapId;
t.elevator=elevator;
t.cool=const("\236\176\168\236\155\144\236\157\180\235\143\153\236\139\156\234\176\132");
self:beganTurn("turn");
end

function MyPlayer:getTileMenu(tile)
if tile==TT.WATER then
local list;
if HasDebuff("\235\170\169\235\167\136\235\166\132")then
list=list or{};
table.insert(list,"\235\169\148\235\137\180_\235\172\188\235\167\136\236\139\156\234\184\176");
end














return list;
end
end

function MyPlayer:onTouchCancel(to,menu,param1)
trace("onTouchCancel",tostring(to));

if menu then
trace("menu",menu,param1);
if string.ends(menu,"\236\158\160\236\158\144\234\184\176")then
for k,v in safe_pairs(param1)do
local item=itemtable[k];
if item["\237\154\168\234\179\188"]then
for k,v in pairs(item["\237\154\168\234\179\188"])do
self:addBuff(k,"sleep",v);
end
end
self.skeleton:setAttachment("bedroll",item["\237\140\140\235\157\188\235\175\184\237\132\176"]);
end
if to and to.tb["\236\152\181\236\133\152"]then
if to.tb["\236\152\181\236\133\152"]["\236\158\160HP"]then
self:addBuff("\236\136\152\235\169\180 \236\131\157\235\170\133\235\160\165 \236\166\157\234\176\128","sleep",to.tb["\236\152\181\236\133\152"]["\236\158\160HP"]);
end
if to.tb["\236\152\181\236\133\152"]["\236\158\160\236\154\176\235\185\132"]then
self:addBuff("\236\154\176\235\185\132","sleep",to.tb["\236\152\181\236\133\152"]["\236\158\160\236\154\176\235\185\132"]);
end
if to.tb["\236\152\181\236\133\152"]["\236\158\160\235\179\180\236\152\168"]then
self:addBuff("\235\179\180\236\152\168","sleep",to.tb["\236\152\181\236\133\152"]["\236\158\160\235\179\180\236\152\168"]);
end
end
self:beganTurn("sleep");
end
end
end

function MyPlayer:ev(k,child)
local this=self;
local _ev=ev;
local vars=self.vars or{};
ev=function(k,child)
local v=vars[k];
if v~=nil then
return v;
end
if k=="\234\179\181\236\134\141"or k=="\236\160\129\236\164\145"or k=="\236\151\176\236\134\141 \234\179\181\234\178\169"or k=="\237\129\172\235\166\172\237\139\176\236\187\172"then
return(bfItem(vars["\234\179\181\234\178\169 \235\172\180\234\184\176G"],k,_ev(k,child),true));
end

return _ev(k,child);

end
local v=ev(k);
ev=_ev;
if child then return v[child];
else return v;end

return v;
end

function MyPlayer:getSlotItem(slot)
return GetSlotItem(slot);
end

function MyPlayer:canAct()

if self:isWaitTurn()then
if self:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")then
return false;
end
return true;
end
end

function MyPlayer:canMove()
if self:isWaitTurn()then
if self:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")or self:hasBuff("\236\157\180\235\143\153\235\182\136\234\176\128")then
return false;
end
return true;
end
end

function MyPlayer:useSkill(...)
self.nextSkill={...};
end
function MyPlayer:useSpell(...)
self.nextSpell={...};
end

function MyPlayer:actSkill(idx)
if idx==0 then
local function onSelect(mx,my)
self:setTarget(mx,my);
end
local w1=self:getSlotItem("\236\152\164\235\165\184\236\134\1441");
local l1=self:getSlotItem("\236\153\188\236\134\1441");
if not w1 then
local R=1;
if world.ground:selectTile("\237\143\137\237\131\128",R,onSelect)==0 then
self:addChat(_L("\237\131\128\234\178\159 \236\152\164\235\165\152"));
end
else
local R=itemtable[w1]["\234\179\181\234\178\169 \234\177\176\235\166\172"]or 1;
if w1 and l1 and const("\237\131\132\236\149\189\236\162\133\235\165\152",itemtable[w1]["\236\162\133\235\165\152"])==itemtable[l1]["\236\162\133\235\165\152"]then
R=R+(itemtable[l1]["\234\179\181\234\178\169 \234\177\176\235\166\172"]or 0);
end
if world.ground:selectTile("\237\143\137\237\131\128",R,onSelect)==0 then
self:addChat(_L("\237\131\128\234\178\159 \236\152\164\235\165\152"));
end
end
else
if primarySkill[idx]then
self:skillAttack(primarySkill[idx].guid);
end
end
end














function MyPlayer:lockScroll()
if world.lockScroll then
world:lockScroll();
end
end
function MyPlayer:unlockScroll()
if world.unlockScroll then
world:unlockScroll();
end
end

function MyPlayer:skillAttack(id)
trace("skillAttack",id);
local skill=skilltable[id];
local skillLV=getSkillLevel(id);

if self:hasBuff("\236\138\164\237\130\172\235\182\136\234\176\128")then
self:addChat(_L("\236\138\164\237\130\172 \235\182\136\234\176\128"));
return false;
end

local w1,lv1,tier1,wGuid1=self:getSlotItem("\236\152\164\235\165\184\236\134\1441");
local w2,lv2,tier2,wGuid2=self:getSlotItem("\236\153\188\236\134\1441");
if id=="\235\139\168\234\178\128 \237\136\172\236\178\153"then
if w1 and itemtable[w1]["\236\162\133\235\165\152"]=="\235\139\168\234\178\128"and not _S["\236\191\168\237\131\128\236\158\132"][wGuid1]then
elseif w2 and itemtable[w2]["\236\162\133\235\165\152"]=="\235\139\168\234\178\128"and not _S["\236\191\168\237\131\128\236\158\132"][wGuid2]then
else
self:addChat(_L("\236\138\164\237\130\172 \236\191\168\237\131\128\236\158\132 \236\152\164\235\165\152"));
return false;
end
else
if _S["\236\191\168\237\131\128\236\158\132"][id]then
self:addChat(_L("\236\138\164\237\130\172 \236\191\168\237\131\128\236\158\132 \236\152\164\235\165\152"));
return false;
end
end

local reqEnergy=0;
if not _Z.AlwaysUseSpell and skill["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"]then
reqEnergy=skill["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"];
reqEnergy=reqEnergy+self:bf("\236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",skill["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
reqEnergy=reqEnergy+self:bf("\236\138\164\237\130\172 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",skill["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
reqEnergy=reqEnergy-skill["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"]*self:ev("\236\138\164\237\130\172 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137 \234\176\144\236\134\140");
if skill["\234\179\181\234\178\169 \235\178\148\236\156\132"]then
reqEnergy=reqEnergy+self:bf("\235\178\148\236\156\132 \234\179\181\234\178\169 \236\138\164\237\130\172 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",skill["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
end
end

if _S["\236\151\144\235\132\136\236\167\128"]<reqEnergy then
self:addChat(_L("\236\151\144\235\132\136\236\167\128 \236\152\164\235\165\152"));
return false;
end

if id=="\235\167\136\235\178\149 \236\130\172\236\154\169"then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][wGuid1];
local id=o["\235\167\136\235\178\149"];
local cnt=o["\236\182\169\236\160\132"][1];
if cnt>0 then
local function onEnd()
end
local function onStart()
o["\236\182\169\236\160\132"][1]=o["\236\182\169\236\160\132"][1]-1;
end
self:spell(id,onEnd,onStart,nil,nil,nil,nil,true);
return true;
else
self:addChat(_L("\236\182\169\236\160\132 \236\151\134\236\157\140"));
return false;
end
end

local function playAni(ani)
local function cb(evt,param)

if evt=="event_sound"then
self:playSndQueue(skill["\235\176\156\235\143\153 \236\130\172\236\154\180\235\147\156"]);
end
end
self:play(ani,nil,nil,cb);
end

local onSelect=function(mx,my,moveTo,all,enemy)




_S:add("\236\151\144\235\132\136\236\167\128",-reqEnergy,0,(self:bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")));
self:updateEnergy();
self:pauseTurn();
self:setGuardMode(false);
world.tickAP=skill.AP or const("\237\149\156\237\132\180");
local target=self:queryEnemy({mx,my},0);
_G["all"]=#(all or{});
local rep=countkcc(skill["\235\176\152\235\179\181"]or 0);
_G["all"]=nil;
local ambushList={};

if skill["\237\131\128\234\178\159"]=="\235\170\168\235\147\160\236\160\129"then
target=table.choice(all);



end
local sx,sy=world.ground:TileToMap(mx,my);

local function addCool()
if not _Z.AlwaysUseSpell then
_S["\236\191\168\237\131\128\236\158\132"][id]=self:bf("\236\191\168\237\131\128\236\158\132",skill["\236\191\168\237\131\128\236\158\132"]);
end
end

if id=="\235\139\168\234\178\128 \237\136\172\236\178\153"then
else
addCool();
end

if id=="\235\139\168\234\178\128 \237\136\172\236\178\153"then
if w1 and itemtable[w1]["\236\162\133\235\165\152"]=="\235\139\168\234\178\128"and not _S["\236\191\168\237\131\128\236\158\132"][wGuid1]then
w2=nil;
wGuid2=nil;
elseif w2 and itemtable[w2]["\236\162\133\235\165\152"]=="\235\139\168\234\178\128"and not _S["\236\191\168\237\131\128\236\158\132"][wGuid2]then
w1=w2;
wGuid1=wGuid2;
w2=nil;
wGuid2=nil;
else
assert(false);
end
end

local function sendDamage(cb,target,damage)
if skill["\236\160\129\236\164\145 \235\179\180\235\132\136\236\138\164"]then
self:addBuff("\236\160\129\236\164\145","\236\138\164\237\130\172 \236\160\129\236\164\145 \235\179\180\235\132\136\236\138\164",skill["\236\160\129\236\164\145 \235\179\180\235\132\136\236\138\164"]);
end

local dmgA,dmgB=GetItemDamage(wGuid1);
local w,wGuid=w1,wGuid1;
if skill["\235\172\180\234\184\176"]=="\235\176\169\237\140\168"then
dmgA=self:bf("\235\176\169\237\140\168 \234\176\149\237\131\128 \235\141\176\235\175\184\236\167\128A");
dmgB=self:bf("\235\176\169\237\140\168 \234\176\149\237\131\128 \235\141\176\235\175\184\236\167\128B");
w=w2;
wGuid=wGuid2;
elseif w2 and const("\235\182\132\235\165\152A",itemtable[w2]["\236\162\133\235\165\152"])=="\235\172\180\234\184\176"then
local dmgA2,dmgB2=GetItemDamage(wGuid2);
dmgA=dmgA+self:bf("\236\153\188\236\134\144 \235\172\180\234\184\176 \236\138\164\237\130\172 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168")*dmgA2;
dmgB=dmgB+self:bf("\236\153\188\236\134\144 \235\172\180\234\184\176 \236\138\164\237\130\172 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168")*dmgB2;
end
self.vars={};
local vars=self.vars;
_G["\234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128"]=dmgA;
_G["\236\138\164\237\130\172 \235\160\136\235\178\168"]=skillLV;
_G["\235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]=damage;
dmgA=ev("\236\138\164\237\130\172\235\141\176\235\175\184\236\167\128\234\179\132\236\130\176\236\139\157");
_G["\234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128"]=dmgB;
dmgB=ev("\236\138\164\237\130\172\235\141\176\235\175\184\236\167\128\234\179\132\236\130\176\236\139\157");
_G["\234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128"]=nil;
_G["\236\138\164\237\130\172 \235\160\136\235\178\168"]=nil;
_G["\235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]=nil;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176"]=w;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176G"]=wGuid;
vars["\234\179\181\234\178\169\236\158\144 \237\131\128\236\158\133"]=self:getType();
vars["\234\179\181\234\178\169 \237\131\128\236\158\133"]="\236\138\164\237\130\172 \234\179\181\234\178\169";
vars["\235\141\176\235\175\184\236\167\128 \237\131\128\236\158\133"]="\235\172\188\235\166\172";
vars["\236\138\164\237\130\172"]=id;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176 \236\154\148\234\181\172\237\158\152"]=GetItemReqStr(wGuid);
vars["\234\179\181\234\178\169\236\158\144 \234\179\181\234\178\169\235\160\165"]=(dmgA+dmgB)/2;
vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]=dmgA;
vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]=dmgB;
vars["\234\184\176\236\138\181 \234\179\181\234\178\169 \235\176\156\235\143\153"]=ambushList[target.guid];
target:onDamage(self);
ambushList[target.guid]=vars["\234\184\176\236\138\181 \234\179\181\234\178\169 \235\176\156\235\143\153"];
self:delBuff("\236\160\129\236\164\145","\236\138\164\237\130\172 \236\160\129\236\164\145 \235\179\180\235\132\136\236\138\164");
if vars["\235\170\133\236\164\145"]then
self:playSndQueue(skill["\237\131\128\234\178\169 \236\130\172\236\154\180\235\147\156"]);
if math.randpercent(skill["\235\176\128\236\150\180\235\131\132"])then
target:knockBack(cb,self.tile.x,self.tile.y);
cb=nil;
end
end
if cb then
cb();
end
self.vars={};
end



local function actDamage(target,damage,cb)
local ncb=1;
local function callback()
ncb=ncb-1;
if ncb<=0 then
if cb then
cb();
end
end
end
if skill["\235\176\156\236\130\172\236\178\180"]=="\235\139\168\234\178\128"then
_S["\236\191\168\237\131\128\236\158\132"][wGuid1]=skill["\236\191\168\237\131\128\236\158\132"];
local from={x=self.pos.x,y=self.pos.y,z=self.bodyZ};
local to={x=target.pos.x,y=target.pos.y,z=target.bodyZ};
local projectile=self:addProjectile(ProjectileKnife,from,to);
projectile:setItem(w1);
ncb=ncb+1;
function projectile:onAttack(t)
t=t or target;
sendDamage(callback,t,damage);
end
function projectile:onBlock()
callback();
end
function projectile:onDestroy()
callback();








end
elseif skill["\235\176\156\236\130\172\236\178\180"]=="\237\153\156"then
local from={x=self.pos.x,y=self.pos.y,z=self.bodyZ};
local to={x=target.pos.x,y=target.pos.y,z=target.bodyZ};
local projectile=self:addProjectile(ProjectileArrow,from,to);
ncb=ncb+1;
function projectile:onAttack(t)
t=t or target;
sendDamage(callback,t,damage);
end
function projectile:onBlock()
callback();
end
function projectile:onDestroy()
callback();
end
else
sendDamage(callback,target,damage);
end
end


local function onMoveEnd()
trace("onMoveEnd");
local actionT=skill["\236\149\161\236\133\152"];
local actionIdx=1;
local reqDamage=1;
local sx,sy=self.tile.x,self.tile.y;

if type(actionT)=="number"then
if rep>0 then
actionT={};
for i=1,rep,1 do
table.insert(actionT,i);
end
else
actionT={actionT};
end
end

local function onDamageEnd()
reqDamage=reqDamage-1;
trace("onDamageEnd",reqDamage);

if reqDamage==0 then
trace("finish");
local finish=function()
self:stop();
local function f()
self:beganTurn("skillattack");
self:preEndTurn();
self:resumeTurn();
end
self.timer.add(f,f,skill["\235\167\136\235\172\180\235\166\172 \236\139\156\234\176\132"]);
end

if self.fronting then
self:back(finish);
else
finish();
end
end
end


local function fAction()
trace("fAction",rep);
do
if skill["\234\179\181\234\178\169 \235\178\148\236\156\132"]then
local targets=self:queryTargets({x=mx,y=my,sx=sx,sy=sy},skill["\234\179\181\234\178\169 \235\178\148\236\156\132"]);
trace("\237\131\128\234\178\159\235\147\164",#targets);
for k,target in pairs(targets)do
if target.tile.x==mx and target.tile.y==my then
actDamage(target,skill["\237\131\128\234\178\159 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]or skill["\235\178\148\236\156\132 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]);
else
actDamage(target,skill["\235\178\148\236\156\132 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]);
end
end
end
end

if rep>0 then
reqDamage=reqDamage+1;
actDamage(target,skill["\237\131\128\234\178\159 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"],onDamageEnd);
trace("actionIdx",actionIdx,actionT);
if actionIdx<#actionT then
local function f()
actionIdx=actionIdx+1;
target=table.choice(all);
self:look(target);
playAni(skill.ani[math.min(actionIdx,#skill.ani)]);
end
self.timer.add(f,f,skill["\235\167\136\235\172\180\235\166\172 \236\139\156\234\176\132"]);
end
else
if target and not string.ends(skill["\237\131\128\234\178\159"],"\236\163\188\236\156\132")and
(string.ends(skill["\237\131\128\234\178\159"],"\236\160\129")or string.starts(skill["\237\131\128\234\178\159"],"\236\167\129\236\132\160\236\160\129")or skill["\237\131\128\234\178\159"]=="\236\167\129\236\132\160"or skill["\237\131\128\234\178\159"]=="\236\160\132\236\178\180")then
reqDamage=reqDamage+1;
actDamage(target,skill["\237\131\128\234\178\159 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"],onDamageEnd);
end
actionIdx=actionIdx+1;
end
end
self.skillCB=function(evt)
trace("skillCB",evt,actionIdx,#(actionT or{}));
if evt=="event_attack"or evt=="event_fire"then
if actionT then
fAction();
end
elseif evt=="COMPLETE"then
self.skillCB=nil;
if self.dying then
reqDamage=1;
onDamageEnd();
elseif not actionT or actionIdx>=#actionT then
onDamageEnd();
end
end
end

if skill["\236\157\180\235\143\153"]=="\237\131\128\234\178\159"or skill["\236\157\180\235\143\153"]=="\236\160\145\234\183\188"then
self:unplace();
self.tile.x=moveTo.x;
self.tile.y=moveTo.y;
self.center.x,self.center.y=world.ground:TileToMap(self.tile.x,self.tile.y);
self:place();
if not actionT then
fAction();
end
end
end

if skill["\236\157\180\235\143\153"]=="\237\131\128\234\178\159"or skill["\236\157\180\235\143\153"]=="\236\160\145\234\183\188"then
local xto,yto=world.ground:TileToMap(moveTo.x,moveTo.y);
local x,y=self.pos.x,self.pos.y;

if skill["\236\157\180\235\143\153"]=="\236\160\145\234\183\188"then
local f=function(o,v)
self.mc:SetAlphaDepth(v);
end
local easing=outQuad;
local delay=skill["\235\140\128\234\184\176 \236\139\156\234\176\132"];
local dur=skill["\236\157\180\235\143\153 \236\139\156\234\176\132"];
local tw1=Tweener(self,f,1,0,dur/2,delay,easing);
tw1.onCompleted=function()
self.pos={x=xto,y=yto};
self.center={x=xto,y=yto};
self.pos.x,self.pos.y=self:getFrontPos(target);
end

local tw2=Tweener(self,f,0,1,dur/2,0,easing);
tw2.onCompleted=function()
self.fronting=true;
onMoveEnd();

end
local tw=TweenList({tw1,tw2});
self.timer.add(tw,tw.update);
self:lookTo({x=sx,y=sy},{x=xto,y=yto},target);
playAni(skill.ani);

elseif skill["\236\157\180\235\143\153"]=="\237\131\128\234\178\159"then

self.fronting=true;
xto=xto+(sx-xto)/2;
yto=yto+(sy-yto)/2;
local cx,cy=(xto-self.pos.x),(yto-self.pos.y);
local attacked={};
local f=function(o,v)

local x0,y0=self.pos.x,self.pos.y;
self.pos.x=x+cx*v;
self.pos.y=y+cy*v;
if skill["\234\178\189\235\161\156 \234\179\181\234\178\169"]=="\234\178\189\235\161\156"then
local x1,y1=self.pos.x,self.pos.y;
local list=world.ground.pathFinder:Gotolist(x0,y0,x1,y1);
if list then
for i=1,#list,2 do
local target=self:queryEnemy({list[i],list[i+1]},0);
if target and not attacked[target]then
attacked[target]=true;
actDamage(target,skill["\235\178\148\236\156\132 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]);
end
end
end
end
end
self:lookTo({x=sx,y=sy},{x=xto,y=yto},target);
playAni(skill.ani);
local easing=linear;
local delay=skill["\235\140\128\234\184\176 \236\139\156\234\176\132"];

local dur=skill["\236\157\180\235\143\153 \236\139\156\234\176\132"];
local tweener=Tweener(self,f,0,1,dur,delay,easing);
tweener.onCompleted=function()
onMoveEnd();
end
self.timer.add(tweener,tweener.update);

end
elseif skill["\236\157\180\235\143\153"]=="\236\160\156\236\158\144\235\166\172"then
if target then
self:look(target);
if rep>0 then
playAni(skill.ani[1]);
else
playAni(skill.ani);
end
if skill["\236\157\180\235\143\153 \236\139\156\234\176\132"]then
self:front(target,onMoveEnd,skill["\235\140\128\234\184\176 \236\139\156\234\176\132"],skill["\236\157\180\235\143\153 \236\139\156\234\176\132"]);
else
onMoveEnd();
end
else
self:lookTo({x=sx,y=sy},self.pos);
playAni(skill.ani);
onMoveEnd();
end
else
onMoveEnd();
end
end
if skill["\237\131\128\234\178\159"]then
if world.ground:selectTile(skill["\237\131\128\234\178\159"],skill["\237\131\128\234\178\159 \235\178\148\236\156\132"],onSelect)==0 then
self:addChat(_L("\237\131\128\234\178\159 \236\152\164\235\165\152"));
end
else
onSelect(self.tile.x,self.tile.y);
end
end

function MyPlayer:preEndTurn(...)





Player.preEndTurn(self,...);
end
function MyPlayer:onEndTurn(AP)




Player.onEndTurn(self,AP);
end


function MyPlayer:spell(id,onSpellEnd,onSpellStart,forceFail,addLV,extraSpells,silent,isSkillSpell)
trace("spell",id);
trace("silent",silent);
local spell=spelltable[id];
local reqEnergy=0;
_G["mglv"]=math.min(ev("\236\139\164\236\160\156\236\181\156\235\140\128\235\167\136\235\178\149\235\160\136\235\178\168"),(_S["\235\167\136\235\178\149"][id]or 0)+(addLV or 0));
if string.ends(spell["\237\131\128\236\158\133"],"\235\167\136\235\178\149")and self:hasBuff("\235\167\136\235\178\149\235\182\136\234\176\128")then
self:addChat(_L("\235\167\136\235\178\149\235\182\136\234\176\128"));
if onSpellEnd then onSpellEnd(false);end
return false;
end
local reqEnergy=0;
local unstable=0;
if spell["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149"]then
for k,v in ipairs(ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \235\139\168\234\179\132"))do
if _S["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149"]>=v then
unstable=k;
end
end
end

if not _Z.AlwaysUseSpell and not isSkillSpell and spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"]then
reqEnergy=spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"];
reqEnergy=reqEnergy+self:bf("\236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
reqEnergy=reqEnergy+self:bf("\235\167\136\235\178\149 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
reqEnergy=reqEnergy-spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"]*self:ev("\235\167\136\235\178\149 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137 \234\176\144\236\134\140");
if spell["\236\162\133\235\165\152"]then
reqEnergy=reqEnergy+self:bf(spell["\236\162\133\235\165\152"].." \235\167\136\235\178\149 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
end
if self.lastSpell==id then
reqEnergy=reqEnergy+self:bf("\236\151\176\236\134\141 \235\167\136\235\178\149 \236\151\144\235\132\136\236\167\128 \236\130\172\236\154\169\235\159\137",spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"],true);
end
if unstable>0 then
reqEnergy=reqEnergy+self:bf("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \236\151\144\235\132\136\236\167\128\236\134\140\235\170\168",spell["\236\134\140\235\170\168\236\151\144\235\132\136\236\167\128"]*ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \236\151\144\235\132\136\236\167\128\236\166\157\234\176\128",unstable));
end
end
if _S["\236\151\144\235\132\136\236\167\128"]<reqEnergy then
self:addChat(_L("\236\151\144\235\132\136\236\167\128 \236\152\164\235\165\152"));
if onSpellEnd then onSpellEnd(false);end
return false;
end

if spell["\236\181\156\235\140\128\236\134\140\237\153\152"]then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
if m["regenC\235\170\172\236\138\164\237\132\176 \236\134\140\237\153\152"]and m["regenC\235\170\172\236\138\164\237\132\176 \236\134\140\237\153\152"]>=spell["\236\181\156\235\140\128\236\134\140\237\153\152"]then
self:addChat(_L("\235\170\172\236\138\164\237\132\176 \236\134\140\237\153\152 \236\152\164\235\165\152"));
if onSpellEnd then onSpellEnd(false);end
return false;
end
end

if spell["\236\157\184\235\178\164\235\139\171\234\184\176"]then
world:closeInven();
end

local onSelect=function(mx,my,moveTo,all,enemy)



if onSpellStart then
if onSpellStart()==false then
if onSpellEnd then onSpellEnd(false);end
return false;
end
end

if not silent then
world.tickAP=spell.AP or const("\237\149\156\237\132\180");
self:beganTurn("spell");
if not spell["\237\132\180\236\167\132\237\150\137"]then
self:pauseTurn();
end
end
if spell["\236\162\133\235\165\152"]=="\234\179\181\234\178\169"then
self:setGuardMode(false);
end

_S:add("\236\151\144\235\132\136\236\167\128",-reqEnergy,0,(self:bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")));
self:updateEnergy();
if spell["\237\131\128\236\158\133"]=="\236\149\148\237\157\145 \235\167\136\235\178\149"then
local t=ev("\236\149\148\237\157\145\235\167\136\235\178\149\236\152\164\236\151\188\236\136\152\236\185\152");
trace("\236\149\148\237\157\145 \235\167\136\235\178\149 \236\152\164\236\151\188 \237\153\149\235\165\160:"..t.P);
if math.randpercent(t.P)then
_S:add("\236\152\164\236\151\188",t.V,0,ev("\236\181\156\235\140\128 \236\152\164\236\151\188"));
end
end

if not _Z.AlwaysUseSpell and not isSkillSpell and spell["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149"]then

do
local v=ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \236\166\157\234\176\128");
local req=v;
req=req+self:bf("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \236\166\157\234\176\128\235\159\137",v,true);
if self.lastSpell==id then
req=req+self:bf("\236\151\176\236\134\141 \235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \236\166\157\234\176\128\235\159\137",v,true);
end
_S:add("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149",req,0,ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \236\181\156\235\140\128"));
end

if unstable>0 then
if math.randpercent(self:bf("\235\167\136\235\178\149 \236\139\164\237\140\168 \237\153\149\235\165\160",self:ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \235\167\136\235\178\149\236\139\164\237\140\168 \237\153\149\235\165\160",unstable)))then
local p=ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \235\167\136\235\178\149\236\139\164\237\140\168 \236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181");
_S:add("\236\151\144\235\132\136\236\167\128",reqEnergy*p,0,(self:bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")));
self:stop();
if not spell["\237\132\180\236\167\132\237\150\137"]then
self:resumeTurn();
end
self:preEndTurn();
self:addChat(_L("\235\167\136\235\178\149 \236\130\172\236\154\169 \236\139\164\237\140\168"));
if math.randpercent(ev("\235\167\136\235\160\165 \236\164\145\235\143\133 \236\161\176\234\177\180")["\235\167\136\235\178\149 \236\130\172\236\154\169 \236\139\164\237\140\168"])then
self:setDiseaseP("\235\167\136\235\160\165 \236\164\145\235\143\133");
end
if onSpellEnd then onSpellEnd(false);end
return false;
end

do
local p=ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \235\182\128\236\158\145\236\154\169 \237\153\149\235\165\160",unstable);
p=p*(1-self:bf("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \235\182\128\236\158\145\236\154\169\234\176\144\236\134\140 \237\153\149\235\165\160")/100);
if math.randpercent(p)then
world.textbox:AddLine(_L("\235\167\136\235\178\149 \236\130\172\236\154\169 \235\182\128\236\158\145\236\154\169"));
local k=math.randlist(ev("\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149 \235\182\128\236\158\145\236\154\169 \235\170\169\235\161\157"));
mx,my=self.tile.x,self.tile.y;
id=k;
spell=spelltable[id];
end
end
end
end

local sx,sy=world.ground:TileToMap(mx,my);
local function sendDamage(target,name,V,dmg)
local vars=self.vars;
vars["\235\141\176\235\175\184\236\167\128"]=math.randrange(vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"],vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]);
dmg=dmg or V*self:ev("\235\167\136\235\178\149 \234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128\236\139\157");
vars["\235\176\169\236\150\180\236\158\144 \237\129\172\235\166\172\237\139\176\236\187\172 \236\160\128\237\149\173"]=target:bf("\237\129\172\235\166\172\237\139\176\236\187\172 \236\160\128\237\149\173");
vars["\234\179\181\234\178\169\236\158\144 \235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172"]=self:bf("\235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172")+target:bf("\237\148\188\234\178\169\236\139\156 \235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172");
vars["\235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172 \235\176\156\235\143\153"]=math.randpercent(self:ev("\235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172 \235\176\156\235\143\153\236\139\157"));
if vars["\235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172 \235\176\156\235\143\153"]then
local cri=0;
cri=self:bf("\235\167\136\235\178\149 \237\129\172\235\166\172\237\139\176\236\187\172 \236\163\188\235\138\148\237\148\188\237\149\180 \236\166\157\234\176\128");
vars["\235\141\176\235\175\184\236\167\128"]=math.randrange(vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"],vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]);
local dmg2=dmg or V*self:ev("\235\167\136\235\178\149 \234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128\236\139\157");



dmg=(dmg+dmg2)/2*(2+cri);
end
vars["\234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128"]=dmg;
vars["\235\141\176\235\175\184\236\167\128 \237\131\128\236\158\133"]=name;
vars["\234\177\176\235\166\172"]=nil;
if spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]and spell["\237\131\128\234\178\159 \235\178\148\236\156\132"]then
local cx,cy=target.tile.x-mx,target.tile.y-my;
vars["\234\177\176\235\166\172"]=math.sqrt(cx*cx+cy*cy);
end
trace("sendDamage",target:getType(),name,dmg,vars);
target:onDamage(self);
end

local function explosionImpl(id,targets,mx,my,cb)
trace("id2",id);
local spell=spelltable[id];
trace("spell",spell);
local vars=self.vars;
local sx,sy=world.ground:TileToMap(mx,my);
local w,lv,tier,wGuid=self:getSlotItem("\236\152\164\235\165\184\236\134\1441");
local dmgA,dmgB=GetItemMagicDamage(wGuid);
if isSkillSpell then
dmgA=dmgA*const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\235\141\176\235\175\184\236\167\128\235\179\180\236\160\149");
dmgB=dmgB*const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\235\141\176\235\175\184\236\167\128\235\179\180\236\160\149");
end
vars["\234\179\181\234\178\169\236\158\144 \237\131\128\236\158\133"]=self:getType();
vars["\234\179\181\234\178\169 \237\131\128\236\158\133"]="\235\167\136\235\178\149 \234\179\181\234\178\169";
vars["\234\179\181\234\178\169 \235\178\148\236\156\132"]=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"];
vars["\234\179\181\234\178\169 \235\172\180\234\184\176"]=w;
vars["\234\179\181\234\178\169 \235\172\180\234\184\176G"]=wGuid;
vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]=dmgA;
vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]=dmgB;
vars["\234\179\181\234\178\169\236\158\144 \234\179\181\234\178\169\235\160\165"]=(dmgA+dmgB)/2;
vars["\236\167\128\235\138\165 \235\179\180\235\132\136\236\138\164"]=self:ev("\236\167\128\235\138\165 \235\179\180\235\132\136\236\138\164\236\139\157","\235\130\152\235\168\184\236\167\128");
if w then
vars["\236\167\128\235\138\165 \235\179\180\235\132\136\236\138\164"]=self:ev("\236\167\128\235\138\165 \235\179\180\235\132\136\236\138\164\236\139\157",itemtable[w]["\236\162\133\235\165\152"])or vars["\236\167\128\235\138\165 \235\179\180\235\132\136\236\138\164"];
end
vars["\235\141\176\235\175\184\236\167\128"]=math.randrange(vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"],vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]);
local dmg=self:ev("\235\167\136\235\178\149 \234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128\236\139\157");
vars["\235\141\176\235\175\184\236\167\128"]=math.randrange(vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"],vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]);
local dmg2=self:ev("\235\167\136\235\178\149 \234\179\181\234\178\169 \235\141\176\235\175\184\236\167\128\236\139\157");


if spell["\236\185\180\235\169\148\235\157\188\237\157\148\235\147\172"]then
world:shake(table.unpack(spell["\236\185\180\235\169\148\235\157\188\237\157\148\235\147\172"]));
end

if spell["\237\143\173\235\176\156 \236\130\172\236\154\180\235\147\156"]then
local s=spell["\237\143\173\235\176\156 \236\130\172\236\154\180\235\147\156"];
if type(s)=="string"and Projectile.itemId and self:playItemSound(s,Projectile.itemId)then
else
self:playSndQueue(s);
end
end

local P=spell["\235\176\156\236\131\157\237\153\149\235\165\160"]or 100;
if spell["\237\131\128\236\158\133"]=="\235\172\188\236\149\189"and spell["\236\162\133\235\165\152"]=="\235\130\152\236\129\168"then
P=P*(1-self:bf("\235\172\188\236\149\189\236\157\152 \236\149\136\236\162\139\236\157\128 \237\154\168\234\179\188 \235\172\180\236\139\156 \237\153\149\235\165\160")/100);
elseif spell["\237\131\128\236\158\133"]=="\236\157\140\236\139\157 \235\182\128\236\158\145\236\154\169"then
P=self:bf("\236\157\140\236\139\157 \235\182\128\236\158\145\236\154\169",P);
end

if math.randpercent(P)then
for i=1,5,1 do
local key=spell["\237\154\168\234\179\188"..i];
if key then
trace("key",key);
local value=spell["\237\154\168\234\179\188"..i.."_\236\136\152\236\185\152"];
local T=spell["\236\167\128\236\134\141\236\139\156\234\176\132"];
local V=value;
local C=1;
if type(value)=="table"then
V=value.V or V;
T=value.T or T;
C=countkcc(value.C or C);
end
trace("V",V,"C",C,"T",T);


if T and bufftable[id]then
self:addBuff(id,id,1,0,T);
end

if key=="\235\172\180\236\158\145\236\156\132 \237\154\168\234\179\188"then
local list={};
for k,v in pairs(value)do
if type(v)=="table"then
list[k]=v.P;
else
list[k]=v;
end
end
key=math.randlist(list);
value=value[key];
V=value;
if type(value)=="table"and value.V then
V=value.V;
C=countkcc(value.C or 1);
T=value.T or T;
end
trace("key:"..key);
end

if string.starts(key,"\235\178\132\237\148\132_")then
local k=string.sub(key,string.len("\235\178\132\237\148\132_")+1);
if T then
T=bf(k.."\235\178\132\237\148\132\236\139\156\234\176\132",T);
end
self:addBuff(k,id,V or 1,0,T);
elseif string.starts(key,"\236\160\129 \235\172\180\236\158\145\236\156\132 \237\154\168\234\179\188")then
for _,t in safe_pairs(targets)do
key=math.randlist(value);
if key=="\235\176\128\236\150\180\235\131\132"then
t:knockBack(cb,self.tile.x,self.tile.y);
cb=nil;
elseif key=="\236\160\129 \236\136\156\234\176\132 \236\157\180\235\143\153"then
local list={};
for i=0,MAP_W-1,1 do
for j=0,MAP_H-1,1 do
if world.ground:canTileWalkable(i,j,t.movableBlock)
and world.ground:getTileGoto(t.tile.x,t.tile.y,i,j,t.findPathBlock)then
table.insert(list,{i,j});
end
end
end
local to=table.choice(list);
if to then
t:teleport(to[1],to[2],nil,nil,cb);
cb=nil;
end
end
end
elseif string.starts(key,"\236\160\129\235\178\132\237\148\132_")then
local k=string.sub(key,string.len("\236\160\129\235\178\132\237\148\132_")+1);
for _,t in safe_pairs(targets)do
local _T=T;
if _T then
_T=t:bf(k.."\235\178\132\237\148\132\236\139\156\234\176\132",_T);
end
t:addBuff(k,id,V or 1,0,T);
if string.starts(k,"\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")then
t:heal(0);
end
end
elseif string.starts(key,"\236\182\148\234\176\128\235\148\148\235\178\132\237\148\132_")then
local k=string.sub(key,string.len("\236\182\148\234\176\128\235\148\148\235\178\132\237\148\132_")+1);
for i=1,V[2]do
for _,t in safe_pairs(targets)do
t:addDebufP(V[1]*100,k);
end
end
elseif string.ends(key," \234\179\160\236\160\149 \235\141\176\235\175\184\236\167\128")then
for _,name in pairs(const("\235\141\176\235\175\184\236\167\128 \235\170\169\235\161\157"))do
if key==name.." \234\179\160\236\160\149 \235\141\176\235\175\184\236\167\128"then
for _,t in safe_pairs(targets)do
sendDamage(t,name,nil,V);
end
end
end
do
local _,targets=self:queryObject({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
if spell["\235\185\132\236\156\168\236\163\188\235\179\128"]then
targets=table.choicep(targets,spell["\235\185\132\236\156\168\236\163\188\235\179\128"]);
end
for _,t in safe_pairs(targets)do
t:impact(key);
end
end
elseif string.ends(key," \235\141\176\235\175\184\236\167\128")then
for _,name in pairs(const("\235\141\176\235\175\184\236\167\128 \235\170\169\235\161\157"))do
if key==name.." \235\141\176\235\175\184\236\167\128"then
for _,t in safe_pairs(targets)do
sendDamage(t,name,V);
end
end
end
do
local _,targets=self:queryObject({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
if spell["\235\185\132\236\156\168\236\163\188\235\179\128"]then
targets=table.choicep(targets,spell["\235\185\132\236\156\168\236\163\188\235\179\128"]);
end
for _,t in safe_pairs(targets)do
t:impact(key);
end
end
elseif key=="\235\176\169\236\150\180\235\167\137"then
self:addBuff(key,id,V*dmg,0,T);

elseif const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157",key)or const("\235\178\132\237\148\132 \235\170\169\235\161\157",key)then
for _,t in safe_pairs(targets)do
if t.addDebufP then
trace("\235\148\148\235\178\132\237\148\132 \236\163\188\234\184\176",t:getType(),key);
t:addDebufP((V or 1)*100,key,self,T);
end
end
elseif key=="\237\154\131\235\182\136\236\130\172\236\154\169"then
NewTorch(T);
elseif key=="\236\158\144\236\139\160 \235\167\136\235\178\149 \237\154\140\235\179\181"then
self:heal(self:bf("\237\154\140\235\179\181\235\159\137",V*dmg));
elseif key=="\236\158\144\236\139\160 \237\154\140\235\179\181"then
self:heal(self:bf("\237\154\140\235\179\181\235\159\137",V));
elseif key=="\236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181"then
self:healEnergy(self:bf("\237\154\140\235\179\181\235\159\137",V));
elseif key=="\235\172\180\236\158\145\236\156\132 \236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181"then
local p=math.randlist(V,100);
if p then
self:healEnergy(self:bf("\237\154\140\235\179\181\235\159\137",p*bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")/100));
end
elseif key=="\235\172\180\236\158\145\236\156\132 \236\131\157\235\170\133\235\160\165 \237\154\140\235\179\181"then
local p=math.randlist(V,100);
if p then
self:heal(self:bf("\237\154\140\235\179\181\235\159\137",p*bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")/100));
end
elseif key=="\235\172\180\236\158\145\236\156\132 \237\148\188\235\161\156\235\143\132 \237\154\140\235\179\181"then
local p=math.randlist(V,100);
if p then
_S:add("\237\148\188\235\161\156\235\143\132",-bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")*p/100,0,(bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")));
end
elseif key=="\236\131\157\235\170\133\235\160\165\236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181"then
self:heal(self:bf("\237\154\140\235\179\181\235\159\137",V*bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")));
self:healEnergy(self:bf("\237\154\140\235\179\181\235\159\137",V*bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128")));
elseif key=="\236\151\144\235\132\136\236\167\128 \234\176\144\236\134\140"then
self:healEnergy(-V);
elseif key=="\237\148\188\235\161\156\235\143\132 \236\166\157\234\176\128"then
_S:add("\237\148\188\235\161\156\235\143\132",V,0,(bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")));
elseif key=="\235\178\132\237\148\132"then
for k,v in pairs(value)do
self:addBuff(k,id,v,0,T);
end
elseif key=="\235\170\169\235\167\136\235\166\132 \236\166\157\234\176\128"then
_S:add("\234\176\136\236\166\157",V,0,(bf("\236\181\156\235\140\128 \235\170\169\235\167\136\235\166\132")));
elseif key=="\236\151\144\235\132\136\236\167\128 \236\132\156\236\132\156\237\158\136 \237\154\140\235\179\181"then
self:addBuff("\236\151\144\235\132\136\236\167\128 \236\158\172\236\131\157 \236\166\157\234\176\128",id,self:bf("\237\154\140\235\179\181\235\159\137",V),0,T);
elseif key=="\236\158\144\236\139\160 \236\132\156\236\132\156\237\158\136 \237\154\140\235\179\181"then
self:addBuff("\236\131\157\235\170\133\235\160\165\235\141\148\237\149\168",id,self:bf("\237\154\140\235\179\181\235\159\137",V),0,T);
elseif key=="\236\158\144\236\139\160 \235\148\148\235\178\132\237\148\132 \236\160\156\234\177\176"then
if math.randpercent((V or 1)*100)then
for guid,_ in pairs(const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
trace("\235\148\148\235\178\132\237\148\132\236\160\156\234\177\176",guid);
self:delBuff(nil,guid);
end
self:addParticle("\236\185\152\236\156\160");
end
elseif key=="\235\178\132\237\148\132 \236\160\156\234\177\176"then
for _,t in safe_pairs(targets)do
if math.randpercent((V or 1)*100)then
for guid,_ in pairs(const("\235\178\132\237\148\132 \235\170\169\235\161\157"))do
trace("\235\178\132\237\148\132\236\160\156\234\177\176",guid);
t:delBuff(nil,guid);
end

end
end
do
local _,targets=self:queryObject({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
for _,t in safe_pairs(targets)do
t:dispel();
end
end
elseif key=="\237\154\140\235\179\181"then
self:heal(bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"));
elseif key=="\236\157\140\236\139\157 \235\147\156\235\158\141"then
local v=dropwelltable["\236\156\132\235\140\128\237\149\156 \236\139\160\237\131\129_\236\157\140\236\139\157"];
local key=math.randlist(v["\234\181\144\236\178\1801"]);
MakeAndPlaceItem(key,self.tile.x,self.tile.y);
elseif key=="\235\172\188\236\149\189 \235\147\156\235\158\141"then
local v=dropwelltable["\236\156\132\235\140\128\237\149\156 \236\139\160\237\131\129_\235\172\188\236\149\189"];
local key=math.randlist(v["\234\181\144\236\178\1801"]);
MakeAndPlaceItem(key,self.tile.x,self.tile.y);
elseif key=="\236\149\132\236\157\180\237\133\156 \235\147\156\235\158\141"then
MakeItemFromDrop("\234\179\160\234\184\137\236\131\129\236\158\144",100,self.tile.x,self.tile.y);
elseif key=="\236\136\156\234\176\132 \236\157\180\235\143\153"then
self:teleport(mx,my,nil,nil,cb);
cb=nil;
elseif key=="\235\176\128\236\150\180\235\131\132"then
for _,t in safe_pairs(targets)do
t:knockBack(cb,self.tile.x,self.tile.y);
cb=nil;
end
elseif key=="\236\160\129 \236\136\156\234\176\132 \236\157\180\235\143\153"then
for _,t in safe_pairs(targets)do
local list={};
for i=0,MAP_W-1,1 do
for j=0,MAP_H-1,1 do
if world.ground:canTileWalkable(i,j,t.movableBlock)
and world.ground:getTileGoto(t.tile.x,t.tile.y,i,j,t.findPathBlock)then
table.insert(list,{i,j});
end
end
end
local to=table.choice(list);
if to then
t:teleport(to[1],to[2],nil,nil,cb);
cb=nil;
end
end
elseif key=="\236\136\156\234\176\132 \236\157\180\235\143\153 \235\178\148\236\156\132 \236\157\180\235\130\180"then
local list={};
for i=0,MAP_W-1,1 do
for j=0,MAP_H-1,1 do
local b=math.abs(self.tile.x-i)<=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]and math.abs(self.tile.y-j)<=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"];
b=b and world.ground:canTileWalkable(i,j,self.movableBlock)
and world.ground:getTileGoto(self.tile.x,self.tile.y,i,j,self.findPathBlock);
if b then
table.insert(list,{i,j});
end
end
end
local to=table.choice(list);
if to then
self:teleport(to[1],to[2],nil,nil,cb);
cb=nil;
end
elseif key=="\236\136\156\234\176\132 \236\157\180\235\143\153 \235\178\148\236\156\132 \236\157\180\236\131\129"then
local list={};
for i=0,MAP_W-1,1 do
for j=0,MAP_H-1,1 do
local b=math.abs(self.tile.x-i)>=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or math.abs(self.tile.y-j)>=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"];
b=b and world.ground:canTileWalkable(i,j,self.movableBlock)
and world.ground:getTileGoto(self.tile.x,self.tile.y,i,j,self.findPathBlock);
if b then
table.insert(list,{i,j});
end
end
end
local to=table.choice(list);
if to then
self:teleport(to[1],to[2],nil,nil,cb);
cb=nil;
end
elseif key=="\234\179\181\234\176\132 \236\157\180\235\143\153"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local depths={};
depths[0]=50;








local depth=math.randlist(depths);
if depth==0 then
local list={};
for i=0,MAP_W-1,1 do
for j=0,MAP_H-1,1 do
local b=math.abs(self.tile.x-i)>=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or math.abs(self.tile.y-j)>=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"];
b=b and world.ground:canTileWalkable(i,j,self.movableBlock)
and world.ground:getTileGoto(self.tile.x,self.tile.y,i,j,self.findPathBlock);
if b then
table.insert(list,{i,j});
end
end
end
local to=table.choice(list);
if to then
self:teleport(to[1],to[2],nil,nil,cb);
cb=nil;
end
else
self:teleportDepth(depth,nil,nil,cb);
cb=nil;
end
elseif key=="\235\143\133\234\181\172\235\166\132"or key=="\235\182\136\235\176\148\235\139\165"or key=="\235\185\153\237\140\144"or key=="\235\182\136\234\184\184"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local objects=_S.maps[mapId].objects;
local list={};
for j=-spell["\234\179\181\234\178\169 \235\178\148\236\156\132"],spell["\234\179\181\234\178\169 \235\178\148\236\156\132"],1 do
for i=-spell["\234\179\181\234\178\169 \235\178\148\236\156\132"],spell["\234\179\181\234\178\169 \235\178\148\236\156\132"],1 do
if world.ground:canTileWalkable(mx+i,my+j,Filter_ItemPlace)then
if key=="\235\185\153\237\140\144"then
if world.ground:getTile(mx+i,my+j)==TT.WATER then
table.insert(list,{"\235\185\153\237\140\144_\235\172\188\237\131\128\236\157\188",i,j});
else
table.insert(list,{"\235\185\153\237\140\144",i,j});
end
elseif key=="\235\182\136\235\176\148\235\139\165"then
if world.ground:getTile(mx+i,my+j)~=TT.WATER then
table.insert(list,{key,i,j});
end
else
table.insert(list,{key,i,j});
end
end
end
end

if spell["\235\185\132\236\156\168\236\163\188\235\179\128"]then
list=table.choicep(list,spell["\235\185\132\236\156\168\236\163\188\235\179\128"]);
end
for k,v in pairs(list)do
local key,i,j=table.unpack(v);
local guid=MakeGuid("o");
objects[guid]={id=key,x=mx+i,y=my+j,LifeT=T,["\236\160\129\236\164\145"]=self:bf("\236\160\129\236\164\145")};
objects[guid].spread={x=mx,y=my,r=spell["\234\179\181\234\178\169 \235\178\148\236\156\132"],dmg=V,c=value["\237\153\149\236\130\176"]};
local o=world:addObject(guid,objects[guid]);
end
elseif key=="\235\170\172\236\138\164\237\132\176 \236\134\140\237\153\152"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
local npcs=m.npcs;
for i=1,C,1 do
local guid=MakeGuid("c");
npcs[guid]={id=math.randlist(V),x=mx,y=my,a=self:getArrow(),["\235\160\136\235\178\168"]=self:ev("\235\160\136\235\178\168"),LifeT=T};
local o=world:addNpc(guid,npcs[guid]);
o.sdata.regenC=key;
o.sdata.regenM=mapId;
m["regenC"..key]=(m["regenC"..key]or 0)+1;
end
elseif key=="\236\152\164\235\184\140\236\160\157\237\138\184\236\131\157\236\132\177"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local objects=_S.maps[mapId].objects;
local guid=MakeGuid("o");
objects[guid]={id=math.randlist(value),x=mx,y=my,LifeT=T,willDie=true};
local o=world:addObject(guid,objects[guid]);
elseif key=="\236\149\132\236\157\180\237\133\156 \234\176\144\236\160\149"then
for _,guid in pairs(all)do
SetItemIdentity(guid,cb);
cb=nil;
end
elseif key=="\236\160\128\236\163\188 \237\149\180\236\160\156"then
for _,guid in pairs(all)do
DelItemOption(cb,guid,"\236\160\128\236\163\188");
cb=nil;
end
elseif key=="\235\167\136\235\178\149 \236\182\169\236\160\132"then
for _,guid in pairs(all)do
RechargeItem(cb,guid,const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\181\156\235\140\128"));
cb=nil;
end
elseif key=="\236\149\132\236\157\180\237\133\156 \236\136\152\235\166\172"then
for _,guid in pairs(all)do
RepairItem(cb,guid,(bf("\236\136\152\235\166\172\235\144\152\235\138\148 \236\150\145",V)));
end
cb=nil;
elseif key=="\235\172\180\234\184\176 \234\176\149\237\153\148"then
for _,guid in pairs(all)do
UpgradeItem(cb,guid,"\235\172\180\234\184\176");
cb=nil;
end
elseif key=="\235\176\169\236\150\180\234\181\172 \234\176\149\237\153\148"then
for _,guid in pairs(all)do
UpgradeItem(cb,guid,"\235\176\169\236\150\180\234\181\172");
cb=nil;
end

elseif key=="\235\182\128\236\131\129 \236\139\156\234\176\132 \234\176\144\236\134\140"then
reduceBuffDur(self.buff,"\235\182\128\236\131\129",V);
elseif key=="\236\164\145\235\143\133 \236\139\156\234\176\132 \234\176\144\236\134\140"then
reduceBuffDur(self.buff,"\236\164\145\235\143\133",-V);
elseif key=="\236\182\156\237\152\136 \236\139\156\234\176\132 \234\176\144\236\134\140"then
reduceBuffDur(self.buff,"\236\182\156\237\152\136",-V);
elseif key=="\236\167\136\235\179\145 \236\139\156\234\176\132 \234\176\144\236\134\140"then
for k,v in safe_pairs(_S["\236\167\136\235\179\145"])do
v.T=v.T+V;
end
elseif key=="\236\164\145\235\143\133 \235\160\136\235\178\168 \234\176\144\236\134\140"then
addBuffLV(self.buff,"\236\164\145\235\143\133",0,-V);
elseif key=="\236\167\136\235\179\145 \237\154\140\235\179\181"then
local step=#ev("\236\167\136\235\179\145 \236\167\128\236\134\141\236\139\156\234\176\132")+1;
for k,v in safe_pairs(_S["\236\167\136\235\179\145"])do
if v.LV<=3 then
self:setDisease(k,7-v.LV);
end
end
elseif key=="\235\148\148\235\178\132\237\148\132 \236\139\156\234\176\132 \234\176\144\236\134\140"then
for guid,_ in pairs(const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
reduceBuffDur(self.buff,guid,V);
end
elseif key=="\236\160\132\236\178\180 \237\154\140\235\179\181"then
_S["\236\131\157\235\170\133\235\160\165"]=bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
_S["\236\151\144\235\132\136\236\167\128"]=bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128");
for guid,_ in pairs(const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
self:delBuff(nil,guid);
end
for k,v in pairs(const("\236\167\136\235\179\145 \235\170\169\235\161\157"))do
self:clearDisease(k);
end
self:addParticle("\237\154\140\235\179\181");
self:addParticle("\236\185\152\236\156\160");
elseif string.starts(key,"\236\160\156\234\177\176_")then
local k=string.sub(key,string.len("\236\160\156\234\177\176_")+1);
self:delBuff(k);
for name,v in pairs(const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"))do
if v==k or name==k then
self:delBuff(nil,name);
end
end
if _S["\235\148\148\235\178\132\237\148\132"][k]then
SetDebuff(k,false);
end
self:addParticle("\236\185\152\236\156\160");
elseif key=="\235\172\180\236\158\145\236\156\132 \236\138\164\237\131\175 \236\166\157\234\176\128"then
local k=table.choice({"\237\158\152","\235\175\188","\236\167\128","\236\178\180","\236\154\180"});
ItemMessagePopup(cb,k,_L("\236\138\164\237\131\175\237\131\128\236\157\180\237\139\128"),{{_L(k),_S[k],_S[k]+V}});
_S[k]=_S[k]+V;
cb=nil;
elseif key=="\236\152\164\236\151\188"then
_S:add("\236\152\164\236\151\188",V,0,ev("\236\181\156\235\140\128 \236\152\164\236\151\188"));
elseif string.starts(key,"\236\138\164\237\131\175_")then
local k=string.sub(key,string.len("\236\138\164\237\131\175_")+1);
for _,t in safe_pairs(targets)do
if t==self then
if _S[k]then
if k=="\236\178\180\236\152\168"then
if V>0 then
world.textbox:AddLine(_L("\236\178\180\236\152\168\236\131\129\236\138\185"));
else
world.textbox:AddLine(_L("\236\178\180\236\152\168\237\149\152\235\157\189"));
end
else
ItemMessagePopup(cb,k,_L("\236\138\164\237\131\175\237\131\128\236\157\180\237\139\128"),{{_L(k),_S[k],_S[k]+V}});
cb=nil;
end
_S[k]=_S[k]+V;
break;
end
end
end
elseif string.starts(key,"\236\167\136\235\179\145_")then
local k=string.sub(key,string.len("\236\167\136\235\179\145_")+1);
for _,t in safe_pairs(targets)do
if math.randpercent((V or 1)*100)then
t:setDisease(k);
end
end
elseif key=="\236\150\180\234\183\184\235\161\156\235\129\140\234\184\176"then
for _,t in safe_pairs(targets)do
t:aggro(self);
end
elseif key=="\236\151\188\235\143\153\235\160\165"then
local t=self:queryObject({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
if t then
if table.find(const("\236\151\188\235\143\153\235\160\165\234\176\128\235\138\165\237\129\180\235\158\152\236\138\164"),t.tb.class)then
if t.isLocked and t:isLocked()then
else
t:touch();
end
end
end
elseif key=="\235\176\169\237\153\148"then
local _,targets=self:queryObject({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
trace("\235\176\169\237\153\148"..V);
for _,t in safe_pairs(targets)do
if math.randpercent(V*100)then
t:burn();
end
end
elseif key=="\236\130\176\236\150\145\237\143\172\237\154\141"then
for _,t in safe_pairs(targets)do
if t.data["\236\167\144\234\190\188"]then
if math.randpercent(t:ev("\236\130\176\236\150\145\237\143\172\237\154\141\237\153\149\235\165\160"))then
PickGoat(t.data["\236\167\144\234\190\188"],t.sdata);
t.drop=function()end;
t:die(true);
end
end
end
elseif key=="\235\130\154\236\139\156\237\149\152\234\184\176"then
self:fishing({x=sx,y=sy},targets);
elseif string.starts(key,"\236\149\132\236\157\180\237\133\156_")then
local k=string.sub(key,string.len("\236\149\132\236\157\180\237\133\156_")+1);
trace("\236\149\132\236\157\180\237\133\156",V);
for i=1,countkcc(V/100)do
MakeAndPlaceItem(k);
end
elseif key=="\236\151\134\236\157\140"then

else
assert(false,"no key:"..key);
end
end
end
end
if cb then
cb();
end
end

local function explosion(target,mx,my,cb)
trace("explosion");
local sx,sy=world.ground:TileToMap(mx,my);
local ncb=1;
local _cb=function()
ncb=ncb-1;
if ncb<=0 then
if cb then
cb();
end
end
end

local _,targets;
if target then
targets={target};
elseif spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]==-1 then
targets={self};
else
_,targets=self:queryEnemy({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
end
if spell["\236\181\156\235\140\128\236\163\188\235\179\128"]then
if targets then
local t={};
local cnt=countkcc(spell["\236\181\156\235\140\128\236\163\188\235\179\128"]);
local center=nil;
for k,v in pairs(targets)do
if v.tile.x==mx and v.tile.y==my then
center=v;
else
table.insert(t,v);
end
end
if#t>cnt then
t=table.choicen(t,cnt);
end
table.insert(t,center);
targets=t;
end
end

if spell["\235\185\132\236\156\168\236\163\188\235\179\128"]then
if targets then
targets=table.choicep(targets,spell["\235\185\132\236\156\168\236\163\188\235\179\128"]);
end
end

if spell["\237\143\173\235\176\156\236\178\180"]then
local from={x=self.pos.x,y=self.pos.y,z=0};
local to={x=sx,y=sy,z=0};
local cls=spell["\237\143\173\235\176\156\236\178\180"];
if type(cls)=="table"then
local p=self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
ncb=ncb+1;
p.onDestroy=function()
_cb();
end
end
end

local function f()
if extraSpells then
for k,v in pairs(extraSpells)do
local vars=self.vars;
self.vars={};
local spell=spelltable[v];
local _,targets=self:queryEnemy({x=mx,y=my},spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]or 0,spell["\235\178\148\236\156\132\236\152\181\236\133\152"]);
if spell["\234\179\181\234\178\169 \235\178\148\236\156\132"]==-1 then
targets={self};
end
ncb=ncb+1;
local function cb()
self.vars=vars;
_cb();
end
explosionImpl(v,targets,mx,my,cb);
end
end
explosionImpl(id,targets,mx,my,_cb);
_cb();
end

if spell["\236\182\169\235\143\140 \236\130\172\236\154\180\235\147\156"]then
self:playSndQueue(spell["\236\182\169\235\143\140 \236\130\172\236\154\180\235\147\156"]);
end
ncb=ncb+1;
self.timer.add(f,f,spell["\237\143\173\235\176\156 \236\139\156\234\176\132"]or 0);

if spell["\236\151\176\234\178\176\236\178\180"]then
local cls=spell["\236\151\176\234\178\176\236\178\180"];
local chain={self};
for k,v in safe_pairs(targets)do
table.insert(chain,v);
end
local function dist(a)
local cx,cy=self.pos.x-a.pos.x,self.pos.y-a.pos.y;
return cx*cx+cy*cy;
end
table.sort(chain,function(a,b)return(dist(a)<dist(b))end);

for i=2,#chain,1 do
local from={x=chain[i-1].pos.x,y=chain[i-1].pos.y,z=chain[i-1].bodyZ};
local to={x=chain[i].pos.x,y=chain[i].pos.y,z=chain[i].bodyZ};
if type(cls)=="table"then
local p=self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
ncb=ncb+1;
p.onDestroy=function()
_cb();
end
end
end
end

end
if silent then
trace("silent spell",id);
self.vars={};
return explosion(nil,mx,my,function()end);
end


local function actDamage(callback)
trace("actDamage",spell["\235\176\156\236\130\172\236\178\180"]);
if spell["\235\176\156\235\143\153\237\154\168\234\179\188"]then
self:addParticle(spell["\235\176\156\235\143\153\237\154\168\234\179\188"]);
end

if spell["\236\185\180\235\169\148\235\157\188\236\157\180\235\143\153"]then
world:lookScroll({x=sx,y=sy},spell["\236\185\180\235\169\148\235\157\188\236\157\180\235\143\153"]);
end
if spell["\235\176\156\235\143\153\236\178\180"]then
local sx,sy=world.ground:TileToMap(mx,my);
local from={x=sx,y=sy,z=0};
local to={x=sx,y=sy};
local cls=spell["\235\176\156\235\143\153\236\178\180"];
local projectile;
if type(cls)=="table"then
self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
end

end

if spell["\235\176\156\236\130\172\236\178\180"]then
local z=self:ev("\236\164\145\236\149\153\235\134\146\236\157\180");
if enemy then
z=enemy.bodyZ;
trace("!toZ",z);
end
local from={x=self.pos.x,y=self.pos.y,z=self.bodyZ};
local to={x=sx,y=sy,z=z};
local cls=spell["\235\176\156\236\130\172\236\178\180"];
local projectile;
if type(cls)=="table"then
projectile=self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
else
projectile=self:addProjectile(_G[cls],from,to);
end
function projectile:onAttack(t)
if t then
explosion(nil,t.tile.x,t.tile.y);
end
end
function projectile:onDestroy()
if not projectile.penetration then
explosion(nil,mx,my,callback);
else
if callback then
callback();
end
end
end
else
if spell["\237\131\128\234\178\159"]=="\235\170\168\235\147\160\236\160\129"then
local ncb=#all;
local function cb()
ncb=ncb-1;
if ncb<=0 then
callback();
end
end
for k,v in ipairs(all)do
trace("explosion \235\170\168\235\147\160\236\160\129",#all,v:getType());
local function f()
explosion(v,v.tile.x,v.tile.y,cb);
end
self.timer.add(f,f,(spell["\237\131\128\234\178\159\236\139\156\234\176\132"]or 0)*(k-1));
end
elseif string.starts(spell["\237\131\128\234\178\159"],"\235\170\168\235\147\160")and string.ends(spell["\237\131\128\234\178\159"],"\235\149\133")then
local n=#all;
if spell["\237\131\128\234\178\159 \236\181\156\235\140\128"]then
if spell["\237\131\128\234\178\159 \236\181\156\235\140\128"]<1 then
n=math.floor(0.5+n*spell["\237\131\128\234\178\159 \236\181\156\235\140\128"]);
else
n=math.min(#all,spell["\237\131\128\234\178\159 \236\181\156\235\140\128"]);
end
end
local list=table.choicen(all,n);

if spell["\237\131\128\234\178\159 \235\185\132\236\156\168"]then
local _={};
for k,v in pairs(list)do
if math.random()<spell["\237\131\128\234\178\159 \235\185\132\236\156\168"]then
table.insert(_,v);
end
end
list=_;
end

local hasFireDmg=false;
for i=1,5,1 do
local key=spell["\237\154\168\234\179\188"..i];
if key=="\237\153\148\236\151\188 \235\141\176\235\175\184\236\167\128"then
hasFireDmg=true;
break;
end
end
if hasFireDmg then
local i=1;
while list[i]do
local x,y=list[i].x,list[i].y;
if world.ground:getTile(x,y)==TT.WATER then
table.remove(list,i);
else
i=i+1;
end
end
end

local ncb=#list;
if ncb==0 then
callback();
else
trace("ncb",ncb);
local function cb()
ncb=ncb-1;
if ncb<=0 then
callback();
end
end
for k,v in ipairs(list)do
local function f()
explosion(nil,v.x,v.y,cb);
end
self.timer.add(f,f,(spell["\237\131\128\234\178\159\236\139\156\234\176\132"]or 0)*(k-1));
end
end
else
explosion(nil,mx,my,callback);
end
end
end

local function run()
if self.tile.x~=mx or self.tile.y~=my then
self:lookTo({x=sx,y=sy},self.pos);
end
self:play(spell.ani);
self:playSndQueue(spell["\235\176\156\235\143\153 \236\130\172\236\154\180\235\147\156"]);
local actionT=spell["\236\149\161\236\133\152"];

local function fAction()
self.vars={};
self:playSndQueue(spell["\236\149\161\236\133\152 \236\130\172\236\154\180\235\147\156"]);

local function onDamageEnd()
trace("finish",spell["\235\167\136\235\172\180\235\166\172 \236\139\156\234\176\132"]);
local finish=function()
local function f()
self:playSndQueue(spell["\236\162\133\235\163\140 \236\130\172\236\154\180\235\147\156"]);
self:stop();
if not spell["\237\132\180\236\167\132\237\150\137"]then
self:resumeTurn();
end
self:preEndTurn();
self.lastSpell=id;
if onSpellEnd then onSpellEnd(true,mx,my);end
world:lookScroll();
_G["mglv"]=nil;
end
self.timer.add(f,f,spell["\235\167\136\235\172\180\235\166\172 \236\139\156\234\176\132"]);
end
finish();
end
if forceFail then
self:addChat(_L("\235\167\136\235\178\149 \236\130\172\236\154\169 \236\139\164\237\140\168"));
onDamageEnd();
else
actDamage(onDamageEnd);
end
self.vars={};
end
self.timer.add(fAction,fAction,actionT);
end
self.timer.add(run,run,spell["\235\140\128\234\184\176 \236\139\156\234\176\132"]or 0);
end

if spell["\237\131\128\234\178\159"]then
if spell["\237\131\128\234\178\159"]=="\236\182\169\236\160\132"then
if UnidentityItemId(id)==id then
local function onOk(guid)
onSelect(self.tile.x,self.tile.y,nil,{guid});
end
local function onCancel()
end
SelectItemPopup(world,onOk,onCancel,{"\234\184\176\237\131\128"},"\236\182\169\236\160\132");
else

onSelect(self.tile.x,self.tile.y,nil,{0});
end
elseif spell["\237\131\128\234\178\159"]=="\236\160\128\236\163\188"then
if UnidentityItemId(id)==id then
local function onOk(guid)
onSelect(self.tile.x,self.tile.y,nil,{guid});
end
local function onCancel()
end
SelectItemPopup(world,onOk,onCancel,{"\234\184\176\237\131\128"},"\236\160\128\236\163\188");
else

onSelect(self.tile.x,self.tile.y,nil,{0});
end
elseif spell["\237\131\128\234\178\159"]=="\234\176\144\236\160\149"then
if UnidentityItemId(id)==id then
local function onOk(guid)
onSelect(self.tile.x,self.tile.y,nil,{guid});
end
local function onCancel()
end
SelectItemPopup(world,onOk,onCancel,{"\234\184\176\237\131\128"},"\234\176\144\236\160\149");
else

onSelect(self.tile.x,self.tile.y,nil,{0});
end
elseif spell["\237\131\128\234\178\159"]=="\236\136\152\235\166\172"then
if UnidentityItemId(id)==id then
local function onOk(guid)
onSelect(self.tile.x,self.tile.y,nil,{guid});
end
local function onCancel()
end
SelectItemPopup(world,onOk,onCancel,{"\234\184\176\237\131\128"},"\236\136\152\235\166\172",{noMaterial=true});
else

onSelect(self.tile.x,self.tile.y,nil,{0});
end
elseif spell["\237\131\128\234\178\159"]=="\235\172\180\234\184\176"or spell["\237\131\128\234\178\159"]=="\235\176\169\236\150\180\234\181\172"then
if UnidentityItemId(id)==id then
local function onOk(guid)
onSelect(self.tile.x,self.tile.y,nil,{guid});
end
local function onCancel()
end
SelectItemPopup(world,onOk,onCancel,{spell["\237\131\128\234\178\159"]},spell["\237\131\128\234\178\159"]);
else

onSelect(self.tile.x,self.tile.y,nil,{0});
end
else
if world.ground:selectTile(spell["\237\131\128\234\178\159"],spell["\237\131\128\234\178\159 \235\178\148\236\156\132"],onSelect)==0 then
self:addChat(_L("\237\131\128\234\178\159 \236\152\164\235\165\152"));
end
end
else
onSelect(self.tile.x,self.tile.y);
end
end

function MyPlayer:getType()
return"\237\148\140\235\160\136\236\157\180\236\150\180";
end

function MyPlayer:getKind()
return"\237\148\140\235\160\136\236\157\180\236\150\180";
end

function MyPlayer:getTeam()
return"\236\149\132\234\181\176";
end

function MyPlayer:isAmbush(from)
return false;
end

function MyPlayer:getPlayerBlock()
return Block_Me;
end

function MyPlayer:addChat(chat,owner)
if chat then
TutorialMsg(chat,const("\235\167\144\237\146\141\236\132\160 \236\139\156\234\176\132"));
end
end

function MyPlayer:recordDamage(reason,dmg)
table.insert(_S["\235\141\176\235\175\184\236\167\128\234\184\176\235\161\157"],{t=_S.T,r=reason,d=dmg or 0});
while _S["\235\141\176\235\175\184\236\167\128\234\184\176\235\161\157"][1]do
if _S["\235\141\176\235\175\184\236\167\128\234\184\176\235\161\157"][1].t+const("\235\141\176\235\175\184\236\167\128\234\184\176\235\161\157\236\139\156\234\176\132")<_S.T then
table.remove(_S["\235\141\176\235\175\184\236\167\128\234\184\176\235\161\157"],1);
else
break;
end
end
end

function MyPlayer:idle(...)
Player.idle(self,...);
end
function MyPlayer:fishing(pos,targets)
world:pauseTurn();
local mc=showPopup(world,"\235\130\154\236\139\156\237\140\157\236\151\133",{size={x=0,y=0,cx=1280,cy=720},backColor=0xFF000000});
local function finish()
trace("finish fish");
self.touchTool=nil;
self:idle();
world:resumeTurn();
end
SetButton(mc.btnClose).onClick=function()
mc:Remove();
finish();
end
local function cb(id)
local function cb2(evt,param)
if evt=="event_action"then
for k,v in safe_pairs(targets)do
if v.data.guid==id then
id="\235\172\188\234\179\160\234\184\176";
v.died=true;
end
end
local spell=spelltable["\235\130\154\236\139\156\237\149\152\234\184\176"];
local from=pos;
local to=pos;
local cls=spell["\237\143\173\235\176\156\236\178\180"];
self:playSnd("\235\130\154\236\139\156\236\178\168\235\178\153");
self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
local o,data,itemGuid=MakeAndPlaceItem(id,_S.x,_S.y);
o:fly(pos);
finish();

end
end

self:play("ani_fishing_act",nil,nil,cb2);
mc:Remove();
end
Fishing(mc,cb,targets);
end
