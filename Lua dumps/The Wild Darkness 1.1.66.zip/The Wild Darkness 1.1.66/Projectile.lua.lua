Projectile={







}

function Projectile:new(o)
o=o or{};
setmetatable(o,self)
self.__index=self
return o
end

function Projectile:getZOrder()
return world.ground:MapToZOrder(self.pos.x/MapToMeter,self.pos.y/MapToMeter)+_Z.Projectile_AddZ+(self.addZ or 0);
end

function Projectile:init(owner,fromPos,toPos)
self.owner=owner;
self.pos={x=fromPos.x*MapToMeter,y=fromPos.y*MapToMeter,z=((self.z or 0)+(fromPos.z or 0))*MapToMeter};
self.to={x=toPos.x*MapToMeter,y=toPos.y*MapToMeter,z=(toPos.z or 0)*MapToMeter};
local vx=self.to.x-self.pos.x;
local vy=self.to.y-self.pos.y;
local len=math.sqrt((vx*vx)+(vy*vy));
local t=len/self.velocity;
self.vx=vx/len*self.velocity;
self.vy=vy/len*self.velocity;
self.vz=(self.to.z-self.pos.z)/len*self.velocity-self.gravity*t*0.5;
self.activeT=t;
self.mc=world.ground.layer:CreateEmptyMovieClip("");
self.skeletons={};
if self.itemId then
self:setItem(self.itemId);
end
if self.particle then
self:setParticle(self.particle,self.particleX,self.particleY);
end
if self.spine then
self:setSpine(self.spine,self.ani,self.skin);
end

if self.scale then
self.mc:SetScale(self.scale,self.scale);
end
end

function Projectile:setItem(itemId)
for k,v in safe_pairs(itemId)do
trace("itemId",v);
local item=itemtable[v];
local sk,error=spine.buildSkeleton(
"media/spine/item.json",
"media/spine/item.atlas",
1)
assert(sk,error);
assert(sk:setSkin("default"));
sk:update(0);
local mc=self.mc:CreateObject(sk,"_");
table.insert(self.skeletons,sk);
if string.find(item.obj,"_scroll_")then
sk:setAttachment("scroll",item.obj);
sk:setAttachment("item");
else
sk:setAttachment("item",item.obj);
sk:setAttachment("scroll");
end

local x,y,cx,cy=sk:getBound();
mc:SetBound(x,y,cx,cy);
end
end

function Projectile:setSpine(path,ani,skin,dt)
do
local this=self;
local sk,error=spine.buildSkeleton(
"media/spine/"..path..".json",
"media/spine/"..path..".atlas"
)
assert(sk,error);
assert(sk:setSkin(table.choice(skin or"default")));
local mc=self.mc:CreateObject(sk,"_");
table.insert(self.skeletons,sk);
sk:setAnimation(0,ani,false,dt);
sk:enableEvent("onAnimationEvent");
function sk:onAnimationEvent(track,name,type,evt,loop,param1)
if type=="COMPLETE"then
this.completed=(this.completed or 0)+1;
end
if evt and string.find(evt,"particle")then
trace("event_particle",param1);
local t=string.split(param1,",")


local positionType=t[3];
local dt=t[4];
local slot=string.trim(t[1]);
local idx=sk:setChild(slot,
{particle="media/particle/"..string.trim(t[2])..".json",
positionType=positionType,
dt=dt});
end
end

sk:update(0);
local x,y,cx,cy=sk:getBound();

mc:SetBound(x,y,cx,cy);
end
end

function Projectile:setParticle(particle,x,y)
for k,v in safe_pairs(particle)do
trace("setParticle",v);
local e=spine.buildEmitter(string.format("media/particle/%s.json",v),false,true,self.positionType);
assert(e);
e:setPosition(x or 0,y or 0);
local mc=self.mc:CreateObject(e,"_");
table.insert(self.skeletons,e);
mc:SetBound(-100,-100,200,200);
end
end

function Projectile:getPos()
return self.pos;
end

function Projectile:getTilePos()
local tx,ty=self.pos.x/MapToMeter,self.pos.y/MapToMeter;
local i,j=world.ground:MapToTile(tx,ty);
return i,j;
end

function Projectile:update(dt)
self.activeT=self.activeT-dt;
if self.activeT<=0 then
if not self.penetration then
self.pos.x,self.pos.y,self.pos.z=self.to.x,self.to.y,self.to.z;
if self.impact then
local tx,ty=self.pos.x/MapToMeter,self.pos.y/MapToMeter;
local i,j=world.ground:MapToTile(tx,ty);
local _,targets=self.owner:queryObject({i,j});
for _,t in safe_pairs(targets)do
t:impact();
end
end
if self:onAttack()then
end
return false;
end
end

local xnext,ynext=self.pos.x+self.vx*dt,self.pos.y+self.vy*dt;
local x0,y0=self.pos.x/MapToMeter,self.pos.y/MapToMeter;
local x1,y1=xnext/MapToMeter,ynext/MapToMeter;
local list=world.ground.pathFinder:Gotolist(x0,y0,x1,y1);
if list then
for i=1,#list,2 do
if self.canBlock then
if self:checkWall(list[i],list[i+1])then
if self.onBlock then self:onBlock();end;
return false;
end
if not self:checkEnemy(list[i],list[i+1])then
return false;
end
end
end
end

self.pos.x=xnext;
self.pos.y=ynext;
self.pos.z=self.pos.z+self.vz*dt;
self.vz=self.vz+self.gravity*dt;
self:updateMC(dt);
self:updateSkeleton(dt);


return true;
end

function Projectile:checkWall(i,j)
local walkable=world.ground:canTileWalkable(i,j,Filter_Arrow);
if not walkable then
return true;
end
end

function Projectile:checkEnemy(i,j)
local target=self.owner:queryEnemy({i,j},0);
if target then
self.targets=self.targets or{};
if not table.find(self.targets,target)then
table.insert(self.targets,target);
self:onAttack(target);
if not self.penetration then
return false;
end
else
trace("find ice");
end
end
return true;
end


function Projectile:updateSkeleton(dt)
for k,v in pairs(self.skeletons)do
if v.setSlotZ then

v:update(dt);
else
if not v.completed and v:update(dt)==0 then
self.completed=(self.completed or 0)+1;
v.completed=true;
trace("\237\140\140\237\139\176\237\129\180 \236\162\133\235\163\140");
end
end
end
end

function Projectile:updateMC(dt)
local pos=self:getPos();
if self.mc then
local z=self:getZOrder();

local x,y=world.ground:MapToScreenFloat(self.pos.x,self.pos.y,_Z.tileW*MapToMeter,_Z.tileW*MapToMeter/2,_Z.tileH*MapToMeter/2);

y=y-pos.z*_Z.TileRatio;
local vx,vy=world.ground:MapToScreenVector(self.vx,self.vy);

self.mc:SetPos(math.floor(x/MapToMeter),math.floor(y/MapToMeter));
self.mc:SetZOrder(z);
if self.angle then
self.mc:SetAngle(math.atan2(vy,vx)+self.angle);
end
end
end

function Projectile:destroy()
trace("Projectile:destroy");
if self.mc then
self.mc:Remove();
self.mc=nil;
end
if self.onDestroy then
self:onDestroy();
self.onDestroy=nil;
end
self.skeletons=nil;
end



function Projectile:onAttack(target)
end


ProjectileArrow=Projectile:new({
velocity=10,
gravity=-20,

angle=math.pi/2,
itemId="\235\130\152\235\172\180 \237\153\148\236\130\180",
canBlock=false,
});

ProjectileKnife=Projectile:new({
velocity=6,
gravity=0,
angle=math.pi/2,

});

ProjectileIce=Projectile:new({
angle=math.pi,
velocity=6,
gravity=0,
canBlock=true,
penetration=true,
});

ProjectileBottle=Projectile:new({
velocity=6,
gravity=-15,
impact=true,
});


ProjectileWell=Projectile:new({
velocity=1,
gravity=-10,
});


ProjectileToWell=Projectile:new({
velocity=2,
gravity=-10,
});

ProjectileMagic=Projectile:new({
angle=math.pi,
velocity=6,
gravity=0,
});


Bomb=Projectile:new({
});

BottleFragment=Bomb:new({
particle="particle_bottle_break",
});

function Bomb:init(owner,fromPos,toPos)
self.owner=owner;
self.pos={x=toPos.x*MapToMeter,y=toPos.y*MapToMeter,z=((self.z or 0)+(toPos.z or 0))*MapToMeter};
self.mc=world.ground.layer:CreateEmptyMovieClip("");
self.skeletons={};
self.lifeTime=0.33;
if self.particle then
self:setParticle(self.particle,self.particleX,self.particleY);
end
if self.spine then
self:setSpine(self.spine,self.ani,self.skin);
end
if self.scale then
self.mc:SetScale(self.scale,self.scale);
end
end

function Bomb:update(dt)
local pos=self:getPos();
if self.mc then
local z=self:getZOrder();
local x,y=world.ground:MapToScreenFloat(self.pos.x,self.pos.y,_Z.tileW*MapToMeter,_Z.tileW*MapToMeter/2,_Z.tileH*MapToMeter/2);
y=y-pos.z*_Z.TileRatio;
self.mc:SetPos(math.floor(x/MapToMeter),math.floor(y/MapToMeter));
self.mc:SetZOrder(z);
self:updateSkeleton(dt);
end

self.lifeTime=self.lifeTime-dt;
if self.lifeTime<0 then
if self.onDestroy then
self:onDestroy();
self.onDestroy=nil;
end
end

if(self.completed or 0)>=#self.skeletons then
if self.onDestroy then
self:onDestroy();
self.onDestroy=nil;
end
for k,v in pairs(self.skeletons)do
if v.setSlotZ then
if v:findChild()>0 then
return true;
end
end
end
return false;
end
return true;

end

ProjectileLightning=Projectile:new({
addZ=1000,
});

function ProjectileLightning:init(owner,fromPos,toPos)
self.owner=owner;
self.pos={x=fromPos.x*MapToMeter,y=fromPos.y*MapToMeter,z=((self.z or 0)+(fromPos.z or 0))*MapToMeter};
self.to={x=toPos.x*MapToMeter,y=toPos.y*MapToMeter,z=((self.z or 0)+(toPos.z or 0))*MapToMeter};

self.mc=world.ground.layer:CreateEmptyMovieClip("");
local vx,vy=world.ground:MapToScreenVector(self.to.x-self.pos.x,self.to.y-self.pos.y);
local len=math.sqrt(vx*vx+vy*vy);
self.skeletons={};
local idx=1;
if len>=3 then
idx=2;
end
if self.spine then
self:setSpine(self.spine,self.ani[idx],self.skin,math.random()*0.5);
end
local w,_,_,_=self.mc:GetBound();
w=math.abs(w);
self.mc:SetAngle(math.atan2(vy-(self.to.z-self.pos.z),vx)+math.pi);
local s=len/(w*MapToMeter)*1.05;
if idx==1 then
s=s*2;
end
self.mc:SetScale(s,s);
end

function ProjectileLightning:update(dt)
local pos=self:getPos();
if self.mc then
local z=self:getZOrder();
local x,y=world.ground:MapToScreenFloat(self.pos.x,self.pos.y,_Z.tileW*MapToMeter,_Z.tileW*MapToMeter/2,_Z.tileH*MapToMeter/2);
y=y-pos.z*_Z.TileRatio;
self.mc:SetPos(math.floor(x/MapToMeter),math.floor(y/MapToMeter));
self.mc:SetZOrder(z);
self:updateSkeleton(dt);
end
if self.onAttack then
self:onAttack();
self.onAttack=nil;
end
if(self.completed or 0)<#self.skeletons then
return true;
else
end
end