Quester=Object:new({
spineScale=0.5,
})

function Quester:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
self:makeQuest();
end

function Quester:makeQuest()
if not self.sdata.materials then
local tb=dropwelltable[self.sdata.id];
local keys={};
for k,v in pairs(tb["\234\184\176\237\131\1281"])do
keys[k]=v.p;
end
local key=math.randlist(keys);
self.sdata.materials={[key]=countkcc(tb["\234\184\176\237\131\1281"][key].c)};
end

if not self.sdata.rewards then
local tb=dropwelltable[self.sdata.id];
self.sdata.rewards={};
for i=2,9 do
local t=tb["\234\181\144\236\178\180"..i];
if not t then
break;
end

local k=math.randlist(t);
if itemtable[k]then
elseif const(k)then
k=table.choice(const(k));
elseif drop1table[k]then
local list2={};
for kk,v in pairs(drop2table)do
if v["\234\183\184\235\163\185"]==k then
list2[kk]=v["\237\128\152\236\138\164\237\138\184"]or v["\236\167\128\236\151\173 \236\160\132\236\178\180"];
end
end
local k2=math.randlist(list2);
assert(k2,k);
k=k2;
end
self.sdata.rewards[k]=(self.sdata.rewards[k]or 0)+1;
end
end
end

function Quester:complete(menu)
for k,v in pairs(self.sdata.rewards)do
for i=1,v do
local o,data=MakeAndPlaceItem(k,_S.x,_S.y);
o:fly(self.pos);
end
end
self.sdata.rewards=nil;
self.sdata.materials=nil;
self:makeQuest();
Object.complete(self,menu);
end

function Quester:menuTouch(from,menu,onOk,onCancel)
do
self:makeQuest();
local function ok(id,guids)
if ConsumeItemsFromGuid(guids)then
onOk(menu);
end
end
local function cancel()
onCancel();
end
BuildItemPopup(world,ok,cancel,"\237\128\152\236\138\164\237\138\184",{self.guid,self.sdata.materials,{rewards=self.sdata.rewards,object=self}});
end
end