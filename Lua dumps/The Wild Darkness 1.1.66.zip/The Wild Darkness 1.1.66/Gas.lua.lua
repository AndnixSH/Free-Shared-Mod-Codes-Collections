Gas=Object:new({
mcNickPath="",
})
function Gas:collision(from)
end

function Gas:canTouch()
end

function Gas:sendDamage(target)
self.vars={};
local vars=self.vars;
vars["\236\154\180 \236\178\180\237\129\172 \235\176\156\235\143\153"]=math.randpercent(target:ev("\236\154\180 \236\178\180\237\129\172"));
local dmg=0;
if vars["\236\154\180 \236\178\180\237\129\172 \235\176\156\235\143\153"]then
else
local a=self.sdata["\236\160\129\236\164\145"]or 0;
local b=target:ev("\235\176\169\236\150\180\236\158\144 \237\154\140\237\148\188");
vars["\234\179\181\234\178\169\236\158\144 \236\160\129\236\164\145"]=math.max(0,a);
vars["\235\176\169\236\150\180\236\158\144 \237\154\140\237\148\188"]=math.max(0,b);
vars["\234\179\181\234\178\169 \236\132\177\234\179\181\235\165\160A"]=target:ev("\234\179\181\234\178\169 \236\132\177\234\179\181\235\165\160A");
vars["\234\179\181\234\178\169 \236\132\177\234\179\181\235\165\160B"]=target:ev("\234\179\181\234\178\169 \236\132\177\234\179\181\235\165\160B");
local max=math.max(vars["\234\179\181\234\178\169 \236\132\177\234\179\181\235\165\160A"],vars["\234\179\181\234\178\169 \236\132\177\234\179\181\235\165\160B"]);
vars["\237\154\140\237\148\188 \235\176\156\235\143\153"]=not math.randpercent(max);
if vars["\237\154\140\237\148\188 \235\176\156\235\143\153"]then
else
dmg=math.randrange(table.unpack(ev("\234\176\128\236\138\164\235\141\176\235\175\184\236\167\128")));
end
end
trace("sendDamage",vars);
for k,v in safe_pairs(self.tb["\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128"])do
if table.find(const("\235\141\176\235\175\184\236\167\128 \235\170\169\235\161\157"),k)then
target:addDamage(nil,dmg*v*(self.sdata.dmg or 1),{["\235\141\176\235\175\184\236\167\128 \237\131\128\236\158\133"]=k},self.sdata.id);
elseif const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157",k)then
target:addDebufP(v*100,k,self);
end
end
end
function Gas:onResetTurn(AP)
if AP<const("\237\149\156\237\132\180")then
Object.onResetTurn(self,AP);
else
for i=1,AP/const("\237\149\156\237\132\180")do
Object.onResetTurn(self,AP);
if self.dying then
break;
end
local function query(o)
if o~=self then
return true;
end
end
local r=0;
local _,players=world.grid:QueryR(self.tile.x,self.tile.y,r,query);
for _,v in safe_pairs(players)do
if v.isObject then
if not table.find(const("\236\158\132\237\140\169\237\138\184\235\172\180\236\139\156"),self.sdata.id)then
for kk,vv in safe_pairs(self.tb["\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128"])do
if table.find(const("\235\141\176\235\175\184\236\167\128 \235\170\169\235\161\157"),kk)then
v:impact(kk);
end
end
end
else
self:sendDamage(v);
end
end

if self.sdata.spread and self.sdata.spread.x==self.tile.x and self.sdata.spread.y==self.tile.y and(self.sdata.spread.c or 0)>0 then
self.sdata.spread.t=(self.sdata.spread.t or 0)+AP;
local S=ev("\234\176\128\236\138\164\237\153\149\236\130\176");
while self.sdata.spread.t>=S do
self.sdata.spread.t=self.sdata.spread.t-S;
local function f()
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local objects=_S.maps[mapId].objects;
local c=self.sdata.spread.c-1;
local r=self.sdata.spread.r+1;
local mx,my=self.tile.x,self.tile.y;
self.sdata.spread.r=r;
self.sdata.spread.c=c;
for j=-r,r,1 do
for i=-r,r,1 do
if(i==r or j==r or i==-r or j==-r)and world.ground:canTileWalkable(mx+i,my+j,Filter_ItemPlace)then
local guid=MakeGuid("o");
objects[guid]={id=self.sdata.id,x=mx+i,y=my+j,dmg=self.sdata.dmg,T=self.sdata.T,LifeT=self.sdata.LifeT,["\236\160\129\236\164\145"]=self.sdata["\236\160\129\236\164\145"]};
local o=world:addObject(guid,objects[guid]);
end
end
end
end
self.timer.add(f,f);
end
end
end
end
end
