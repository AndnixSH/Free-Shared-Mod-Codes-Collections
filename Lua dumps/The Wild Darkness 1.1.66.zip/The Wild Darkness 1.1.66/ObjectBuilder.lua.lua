local function checkR(x,y,R,filter,noTrap)
local function query(o)
if o==filter then
return false;
end
if o.isObject then
if o.tb["\235\166\172\236\160\160 \236\139\156\234\176\132"]and o.sdata.T then
return false;
elseif o.tb["\236\167\147\234\184\176"]or o.tb["\234\178\185\236\185\168"]then
return false;
elseif not noTrap and not o:isDetected()and not o:isCompleted()then
return false;
end
end
return true;
end
for i=x-R,x+R,1 do
for j=y-R,y+R,1 do
if i<0 or i>=MAP_W or j<0 or j>=MAP_H then
return false;
else
if world.ground:getTile(i,j)==TT.WATER or
not world.ground:inLOS(i,j)or

(i~=world.player.tile.x or j~=world.player.tile.y)and not world.ground:canTileWalkable(i,j,world.player.movableBlock)or
world:hasObject(i,j,R,query)then
return false;
end
end
end
end
return true;
end

function ObjectBuilder(owner)
local buildZoom=1.5;
local worldZoom=world.zoom_ or world.zoom;
local object=nil;
local selected=nil;
local isDraging=nil;
local tiles={};
local wtiles={};

for i=0,MAP_W-1,1 do
for j=0,MAP_H-1,1 do
if checkR(i,j,0)then
table.insert(wtiles,{i,j});
end
end
end
if table.empty(wtiles)then
world.player:addChat(_L("\236\132\164\236\185\152\234\179\181\234\176\132\236\151\134\236\157\140"));
return nil;
end

world:centerScroll(0.3);
world:zoomTo(buildZoom);
world.player:unplace();

local function findNearTile(x,y,R)
local minD=nil;
local minTile=nil;
for k,v in pairs(wtiles)do
local i,j=table.unpack(v);
if checkR(i,j,R)then
local cx=i-x;
local cy=j-y;
local d=cx*cx+cy*cy;
if not minD or d<minD then
minD=d;
minTile={i,j};
end
end
end
if minTile then
return table.unpack(minTile);
end
end


local function queryBuilding(i,j)
local function query(o)
if o.isObject and recipetable[o.tb.guid]and recipetable[o.tb.guid]["\236\156\160\237\152\149"]=="\236\132\164\236\185\152"then
return true;
end
end
return world.grid:QueryR(i,j,0,query);
end

local function hideGrid()
world.ground.layer:SetTileLayer(3);
for k,v in pairs(tiles)do
world.ground:clearGrid(v[1],v[2]);
end
tiles={};
end
local function showGrid(recipe)
hideGrid();
if object then
local R=math.max((object.tb["\237\129\172\234\184\176"]or 0)-1,0);
for k,v in pairs(wtiles)do
local i,j=table.unpack(v);
if recipe and recipe["\236\163\188\235\179\128 \236\139\156\236\132\164"]and not InNearBuilding(recipe["\236\163\188\235\179\128 \236\139\156\236\132\164"],i,j)then
else
local d=math.max(math.abs(i-object.tile.x),math.abs(j-object.tile.y));
if d>R and checkR(i,j,R)then
tiles[i+j*MAP_W]={i,j};
world.ground:showGrid(i,j);
end
end
end
else
for k,v in pairs(wtiles)do
local i,j=table.unpack(v);
tiles[i+j*MAP_W]={i,j};
world.ground:showGrid(i,j);
end
end
end
showGrid();
local function delObject()
if object then
object.menu:Remove();
object:destroy();
object=nil;
end
if selected then
selected.update=selected._update;
selected._update=nil;
selected.canvas:SetVisible(true);
selected=false;
end
hideGrid();
end
local function rotObject()
if object then
object:setArrow(OpponentArrow(object:getArrow()));
end
end


function owner:close()
delObject();
world:zoomTo(worldZoom);
world.player:place();
end

function owner:update(dt)
if object then

end
end

function owner:mouseDown(x,y)
local mx,my=world.ground:ScreenToTile(x,y);
isDraging=object and object.tile.x==mx and object.tile.y==my;
return isDraging;
end
function owner:mouseMove(x,y)
if isDraging then
self:click(x,y);
return true;
end
end
function owner:mouseUp(x,y)
if object and not world.touchPad.isLock()then
trace("mouseUp");
self:click(x,y);
isDraging=nil;
return true;
end
end

function owner:click(x,y)
local mx,my=world.ground:ScreenToTile(x,y);
if tiles and tiles[mx+my*MAP_W]then
if object then
object.tile.x,object.tile.y=mx,my;
object.pos.x,object.pos.y=world.ground:TileToMap(mx,my);
trace("object.pos",object.pos);
object.menu:SetPos(world.ground:MapToScreen(object.pos.x,object.pos.y));
showGrid();
end
end

if false then
if not object then
local o=queryBuilding(mx,my);
if o then
selected=o;
selected._update=selected.update;
selected.update=function()end;
selected.canvas:SetVisible(false);

tiles[mx+my*MAP_W]={mx,my};
object=TestObject:new();
object:init(o.sdata);
object.menu=world.ground:AddSymbol("\236\167\147\234\184\176_\235\169\148\235\137\180","");
object.menu:SetPos(world.ground:MapToScreen(object.pos.x,object.pos.y));
SetButton(object.menu.btnCancel).onClick=function()
delObject();
end
SetButton(object.menu.btnRotate).onClick=function()
rotObject();
end

SetButton(object.menu.btnOk).onClick=function()
o:unplace();
o.sdata.x,o.sdata.y,o.sdata.a=object.tile.x,object.tile.y,object.arrow;
o.pos.x,o.pos.y,o.arrow=object.pos.x,object.pos.y,object.arrow;
o.tile.x,o.tile.y=object.tile.x,object.tile.y;
delObject();
o:place();
o:update(0);
owner.parent.parent.btnClose:onClick();
end
showGrid();
end
end
end
end

function owner:put(recipeId,guids)
trace("put",recipeId,guids);
delObject();
local recipe=recipetable[recipeId];
local id=recipe["\236\158\165\235\185\132"];
local tb=objecttable[id];
local x,y=world.ground:GetInvRelativePos(root,APP_W/2,APP_H/2);
local R=math.max((tb["\237\129\172\234\184\176"]or 0)-1,0);
local tx,ty=world.ground:ScreenToTile(x,y);
tx,ty=findNearTile(tx,ty,R);
if not tx or not ty then
return false;
end

object=TestObject:new();
object:init({id=id,x=tx,y=ty,a="right"});
object.canvas:SetAlphaDepth(_Z.BuidingAlpha);
showGrid(recipe);

local tw=Tweener(object.canvas,object.canvas.SetAlphaDepth,_Z.BuidingAlpha,1,1,0,linear)
function tw:onCompleted()
tw.reverse();
end
world.timer.add(object.canvas,tw.update);

object.menu=world.ground:AddSymbol("\236\167\147\234\184\176_\235\169\148\235\137\180","");
object.menu:SetPos(world.ground:MapToScreen(object.pos.x,object.pos.y));
SetButton(object.menu.btnCancel).onClick=function()
owner:onCancel();
end
SetButton(object.menu.btnRotate).onClick=function()
rotObject();
end
object.menu.btnRotate:SetVisible(not tb.sticky);

SetButton(object.menu.btnOk).onClick=function()
world.player:setTargetBuiding(object,object.tile.x,object.tile.y,object.arrow,id,guids);
world.timer.remove(object.canvas);
object.canvas:SetAlphaDepth(_Z.BuidingAlpha);
object.menu:Remove();
object=nil;
world:centerScroll();
owner:onCancel();
end
end
return owner;
end

function BuildBuilding(ppos,_o,x,y,a,id,guids,cb)
local R=math.max((_o.tb["\237\129\172\234\184\176"]or 0)-1,0);
_o:destroy();
local mids={};
for guid,c in safe_pairs(guids)do

if not ConsumeItem(guid,c,false)then
return false;
end
for i=1,c do
table.insert(mids,_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id);
end
end
if checkR(x,y,R,nil,true)and ConsumeItemsFromGuid(guids)then
for k,v in pairs(world.objects)do
if not v.dying then
if v.tile.x>=x-R and v.tile.x<=x+R and v.tile.y>=y-R and v.tile.y<=y+R then
if not v.tb["\234\178\185\236\185\168"]and not _o.tb["\234\178\185\236\185\169"]then
trace("\236\152\164\235\184\140\236\160\157\237\138\184 \236\130\173\236\160\156",v.guid);
v:die();
end
end
end
end
local o=world:createObject(id,x,y,{a=a});
if o.onBuild then
o:onBuild(mids);
end
local f=function(o,v)
o.mc:SetAlphaDepth(v);
end
local easing=linear;
local delay=0;
local dur=1.3;
local tweener=Tweener(o,f,_Z.BuidingAlpha,1,dur,delay,easing);
world.timer.add(tweener,tweener.update);

do
local function _cb()
local function _cb2()
world:resumeTurn();
if cb then cb();end
end
world:pauseTurn();
ShowAddedRecipes(id,_cb2,o.guid);
end
world.player:build(_cb,o,ppos);
end
return true;
end
end
