
local function compParam(type,a,param)
if table.find(a,param)then
return true;
end
local item=itemtable[param];
if item then
if item["\234\183\184\235\163\185"]==a or item["\236\162\133\235\165\152"]==a or const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",item["\236\162\133\235\165\152"])==a then
return true;
end
end
end

local function checkCond(cond,type,...)
if cond[1]==type then
local n=select("#",...);
for i,v in pairs(cond)do
if i>1 then
local param=select(i-1,...);
if not param or not compParam(type,cond[i],param)then
return false;
end
end
end
return true;
end
end

local function checkMission(data,type,value,...)
local missiontb=missiontable[data.id];
local completed=true;
local success=true;
for i=1,9 do
local cond=missiontb["\236\161\176\234\177\180"..i];
local inv=missiontb["\236\161\176\234\177\180"..i.."\236\139\164\237\140\168"];
local only=missiontb["\236\161\176\234\177\180"..i.."\236\156\160\236\157\188"];
local n=missiontb["\236\136\152\236\185\152"..i]or 1;
if not cond then
break;
end
if only and data[type]and(data[type][select(1,...)]or 0)>=only then
elseif checkCond(cond,type,...)then
if value<0 then
data["data"..i]=-value;
else
data["data"..i]=(data["data"..i]or 0)+(value or 1);
end
if only then
local id=select(1,...);
data[type]=data[type]or{};
data[type][id]=(data[type][id]or 0)+1;
end
end
if(data["data"..i]or 0)>=n then
data["data"..i]=n;
if inv then
success=false;
completed=true;
break;
end
else
if not inv then
completed=false;
end
end
end
if completed then
data.completed=GetDay();
data.success=success;
return true;
end
end




















function Mission(type,value,...)
local lookup=Lookup(function()
local list={};
for k,v in pairs(_S["\235\175\184\236\133\152"])do
local tb=missiontable[v.id];
for i=1,9 do
local cond=tb["\236\161\176\234\177\180"..i];
if not cond then
break;
elseif not v.completed and cond[1]==type then
table.insert(list,k);
end
end
end
return list;
end,"mission",type);
trace("\235\175\184\236\133\152",type,value,...);
local list={};
for i,k in pairs(lookup)do
local v=_S["\235\175\184\236\133\152"][k];
if not v.completed and checkMission(v,type,value,...)then
table.insert(list,v);
end
end
for _,v in ipairs(list)do
CompleteMission(v);
end
end
