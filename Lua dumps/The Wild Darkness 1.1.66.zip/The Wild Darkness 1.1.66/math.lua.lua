






function math.randrange(lower,greater)
lower,greater=math.min(lower,greater),math.max(lower,greater);
return lower+math.random()*(greater-lower);
end

function math.randpercent(p)
p=p or 0;
return p>0 and math.random()*100<p;
end


function math.randpercentN(p,n)
local c=0;
n=n or 1
for i=1,n,1 do
if p>0 and math.random()*100<p then
c=c+1;
end
end
return c;
end

function math.randint(t)
if type(t)=="table"then
return math.random(t[1],t[2]or t[1]);
else
return t;
end
end

function math.color(a,r,g,b)
return a<<24|r<<16|g<<8|b;
end

function math.argb(clr)
return((clr>>24)&0xFF),((clr>>16)&0xFF),((clr>>8)&0xFF),((clr)&0xFF);
end

function math.premultipliedalpha(clr)
clr=tonumber(clr);
local a,r,g,b=math.argb(clr);
r,g,b=math.floor(r*a/0xFF),math.floor(g*a/0xFF),math.floor(b*a/0xFF);
return math.color(a,r,g,b);
end

function math.clamp(val,min,max)
if val<=min then
val=min
elseif max<=val then
val=max
end
return val
end

function math.safeinteger(n)
return math.tointeger(n)or n;
end

function int(n)
if n>=0 then return math.floor(n);
else return math.ceil(n);
end
end


function tostringf(s,c,sign)
c=c or 1;
sign=sign or"";
local n=tonumber(s);
if not n then
return tostring(s);
end

local i=math.tointeger(n);
if i then
if sign and i>=0 then
return sign..tostring(i);
else
return tostring(i);
end
end
while c<10 do
local d=math.floor(n*10^c+0.5);
local i=math.tointeger(d);
if i and i~=0 then
break;







end
c=c+1;
end
return string.format("%"..sign.."0."..c.."f",n);
end


function math.randlist(t,total)
if type(t)=="table"then
local _t={};
if not total then
total=0;
for k,v in pairs(t)do
assert(type(v)=="number",t)
if v>0 then
total=total+v;
_t[k]=v;
end
end
else
for k,v in pairs(t)do
if v>0 then
_t[k]=v;
end
end
end
local r=math.random()*total;
for k,v in pairs(_t)do
if r<=v then
return k;
end
r=r-v;
end
else
return t;
end
end

function math.poweroftwo(x)
local power=1;
while power<x do
power=power*2;
end
return power;
end

function math.length(x,y)
return math.sqrt(x*x+y*y);
end
