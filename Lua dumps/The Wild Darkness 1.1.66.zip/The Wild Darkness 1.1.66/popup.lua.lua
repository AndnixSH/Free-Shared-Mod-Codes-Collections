_G.popupId=0;
_G.popupList={};
local function showPopupImpl(this,mcName,name,size,parent,backColor,autoClose,W,H,fnTweener,align,param,sndName,btnClose,btnBack)
btnClose=btnClose or"btnClose";
btnBack=btnBack or"btnClose";

align=align or"hcenter, vcenter";
W=W or APP_W;
H=H or APP_H;
size=size or{};

backColor=backColor or 0x80000000;

local X=size.x;
local Y=size.y;
local CX=size.cx;
local CY=size.cy;
local owner=this:CreateEmptyMovieClip(name or"");
local x,y=owner:GetRelativePos(parent or root);
local closeMargin=10;
local backAlpha=bit.rshift(backColor,24)/0xFF;



owner:SetPos(-x,-y);


owner:SetZOrder(10000+_G.popupId);
owner:SetClipRect(10000,10000,-20000,-20000);
local mcBack=owner:CreateEmptyMovieClip("_back");
do
mcBack:AddSymbol("white.png","img");
local _,_,w,h=mcBack.img:GetBound();
mcBack.img:SetPos(-2,-2);
mcBack.img:SetScale((APP_W+4)/w,(APP_H+4)/h);
mcBack:SetAlphaColor(backColor);
mcBack:SetAlphaDepth(0);
end








local mc;
if mcName then
mc=owner:AddSymbol(mcName,"_",param);
else
mc=owner:CreateEmptyMovieClip("");
end

if mc[btnClose]or mc[btnBack]or mc.btnOk then
local snd;
if sndName then
snd=this:AddSymbol(sndName,"");
else
snd=GetAppSound(this,"popup");
end
if snd then
snd:Play();
end
end

owner:SetMouseCapture(true);
owner.onMouseMove=function()return true;end
owner.onMouseDown=function()return true;end
owner.onKeyDown=function(self,key)
if key==0x08 then
if mc[btnBack]and mc[btnBack].onClick then
mc[btnBack]:onClick();
elseif autoClose then
owner:Remove();
if mc.onClose then
mc:onClose();
end
end
end
return true;
end
owner.onKeyUp=function(self,key)
return true;
end
local x,y,cx,cy=mc:GetBound();
if mc.back then
x,y,cx,cy=mc.back:GetAABB();
end

local ox=0;
local oy=0;
do
local _x=X or x;
local _y=Y or y;
local _cx=CX or cx;
local _cy=CY or cy;
if string.find(align,"vcenter")then
oy=math.floor(H/2-_cy/2-_y);
elseif string.find(align,"bottom")then
oy=math.floor(H-_cy-_y);
end

if string.find(align,"hcenter")then
ox=math.floor(W/2-_cx/2-_x);
elseif string.find(align,"right")then
ox=math.floor(W-_cx-_x);
end
end



mc:SetOrigin((cx+x)/2,(cy+y)/2);
mc:SetPos(ox,oy);

owner.onMouseUp=function(this,mx,my)




if autoClose then
owner:Remove();
if mc.onClose then
mc:onClose();
end
elseif mx<(ox+x-closeMargin)or my<(oy+y-closeMargin)or mx>=(ox+x+cx+closeMargin)or my>=(oy+y+cy+closeMargin)then
if mc[btnClose]and mc[btnClose].onClick then
mc[btnClose]:onClick();
end
end
return true;
end

function mc:show(a,b,dur,delay,cb)
local tweener=nil;
a=a or 0;
b=b or 1;
dur=dur or 0.25;
do
local function f(o,s)
if fnTweener then
fnTweener(o,s);
else
local scale=0.9+0.1*s;
local alpha=0.5+0.5*s;
o:SetScale(scale,scale);
o:SetAlphaDepth(math.max(0,math.min(1,alpha)));
end
mcBack:SetAlphaDepth(math.max(0,math.min(1,s))*backAlpha);
end
tweener=Tweener(mc,f,a,b,dur,delay,outQuart);
end

if tweener then
tweener.onCompleted=function(self)
if cb then cb();end
if mc.onCompleted then
mc:onCompleted();
end
end
mainTimer.add(owner,tweener.update,0);
end
tweener.update(0);
end
local oldRemove=mc.Remove;
mc.Remove=function(self)
if owner and owner.this then
owner:Remove();
end
end

mc.hideAndRemove=function(self,dur,delay,cb)
mc:SetSpriteMode(true);
mc:show(1,0,dur,delay,function()
if cb then cb();end
mc:Remove();
end);
end

popupList[mc]=_G.popupId;
_G.popupId=_G.popupId+1;
owner.onUnload=function()
mainTimer.removemc(owner);
popupList[mc]=nil;

end
mc:show();
player:SetNextDeltaTimeZero();
return mc,_G.popupId;
end
function closePopupAll()
for k,v in pairs(_G.popupList)do
k:Remove();
end
end


function showWindow(owner,mcName,name,param,sndName,btnClose,btnBack)
btnClose=btnClose or"btnClose";
btnBack=btnBack or"btnClose";
local mc;
local autoClose
if name and owner[name]then
owner[name]:Remove();
end
if mcName then
mc=owner:AddSymbol(mcName,name or"",param);
else
mc=owner:CreateEmptyMovieClip(name or"");
end

if mc[btnClose]or mc.btnOk then
local snd;
if sndName then
snd=this:AddSymbol(sndName,"");
else
snd=GetAppSound(this,"popup");
end
if snd then
snd:Play();
end
end

local x,y,cx,cy=mc:GetBound();
if mc.back then
x,y,cx,cy=mc.back:GetAABB();
end


mc:SetOrigin(x+(cx)/2,y+(cy)/2);

mc:SetMouseCapture(true);
mc.onMouseMove=function()return true;end
mc.onMouseDown=function(this,mx,my,mid,capture)
return not(mx<x or my<y or mx>=x+cx or my>=y+cy);
end
mc.onMouseMove=function(this,mx,my,mid,capture)
return not(mx<x or my<y or mx>=x+cx or my>=y+cy);
end
mc.onMouseUp=function(this,mx,my,mid,capture)
return not(mx<x or my<y or mx>=x+cx or my>=y+cy);
end
mc.onKeyDown=function(self,key)
if key==0x08 then
if mc[btnBack]and mc[btnBack].onClick then
mc[btnBack]:onClick();
elseif autoClose then
owner:Remove();
if mc.onClose then
mc:onClose();
end
end
end
return true;
end
mc.onKeyUp=function(self,key)
return true;
end
local tweener=nil;






do
mc.SetScaleXY=function(self,s)
local scale=0.9+0.1*s;
local alpha=0.5+0.5*s;
self:SetScale(scale,scale);
self:SetAlphaDepth(math.max(0,math.min(1,alpha)));
end
tweener=Tweener(mc,mc.SetScaleXY,0,1,0.25,0,outQuart);
end
if tweener then
tweener.onCompleted=function(self)
if mc.onCompleted then
mc:onCompleted();
end
end
mainTimer.addmc(mc,tweener.update,0);
end

popupList[mc]=_G.popupId;
_G.popupId=_G.popupId+1;
mc.onUnload=function()
mainTimer.removemc(mc);
popupList[mc]=nil;

end
tweener.update(0);
player:SetNextDeltaTimeZero();
return mc,_G.popupId;
end


function showMsgImpl(this,mcName,msg,title,...)
local mc=showPopup(this,mcName,...);
if mc and msg and mc.txt then
mc.txt:SetText(msg);
end
if mc and title and mc.title then
mc.title:SetText(title);
end

if mc and(mc.btnClose or mc.btnCancel)then
SetButton((mc.btnClose or mc.btnCancel)).onClick=function()
mc:Remove();
if mc.onClose then
mc:onClose();
end
end
end
return mc;
end
function showMsg(this,mcName,t,...)
if type(t)=="table"then
return showMsgImpl(this,mcName,t.msg,t.title,t);
else
return showMsgImpl(this,mcName,t,...);
end
end

function showPopup(this,mcName,t,...)
if type(t)=="table"then
return showPopupImpl(this,mcName,t.name,t.size,t.parent,t.backColor,t.autoClose,t.W,t.H,t.fnTweener,t.align,t.param,t.sndName,t.btnClose,t.btnBack);
else
return showPopupImpl(this,mcName,t,...);
end
end

function showToast(this,mcName,msg,dur,cb)
if type(msg)~="table"then
msg={msg};
end

local function show(idx)





dur=dur or 0.8;
this:AddSymbol(mcName,"toast");
this.toast.txt:SetText(msg[idx]);
local _,_,cx,cy=this.toast.txt:GetRendererRect();
local _,_,w,h=this.toast.bg:GetBound();
local _cx=cx+20;
local _cy=cy+80;



this.toast.bg:SetScale(math.max(1,_cx/w),math.max(1,_cy/h));

local f=function(self,s)
self:SetAlphaDepth(s);
if s<=0 then
self:Remove();
if msg[idx+1]then
show(idx+1);
else
if cb then cb();end
end
end
end

local x,y=this:GetRelativePos(root);




this.toast:SetPos(x+APP_W/2,y+APP_H/4);
function this.toast:_next()
f(self,0);
end

if dur>=0 then
local tweener=Tweener(this.toast,f,1,0,0.7,dur,outQuad);
mainTimer.addmc(this.toast,tweener.update,0);
end
end
show(1);
function this.toast:reset()
if this.toast then
this.toast:Remove();
end
show(1);
end
return this.toast;
end

function isPopupChild(mc)
if not table.empty(_G.popupList)then
local parent=mc.parent;
while parent do
if _G.popupList[parent]then
return true;
end
parent=parent.parent;
end
end
end

function showPopupYN(owner,param,onOk,onCancel)
local mc2=showPopup(owner,param.mcName or"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(param.msg);
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
if onOk then onOk();end
end
SetButton(mc2.btnCancel or mc2.btnClose).onClick=function()
mc2:Remove();
if onCancel then onCancel();end
end
return mc2;
end









