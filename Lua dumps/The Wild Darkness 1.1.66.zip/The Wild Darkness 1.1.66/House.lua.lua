House=Object:new({
})

function House:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
self.sdata.nextMap=self.sdata.nextMap or("house_"..guid);






end

function House:travel()




world.gameEnded=true;
world.isTraveling=true;
local function f()
if not _S.maps[self.sdata.nextMap]then
local old=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
local bp=mapbptable[self.tb.guid];
data={};
data["\235\167\181 \235\160\136\235\178\168"]=old["\235\167\181 \235\160\136\235\178\168"];
data["\237\131\128\236\158\133"]=old["\237\131\128\236\158\133"];
data["\236\167\128\236\151\173"]=old["\236\167\128\236\151\173"];
data["\237\149\132\235\147\156"]=old["\237\149\132\235\147\156"];
data["\235\178\136\237\152\184"]=old["\235\178\136\237\152\184"];
data["\236\184\181"]=old["\236\184\181"];
data["\235\179\180\236\138\164\235\176\169"]=old["\235\179\180\236\138\164\235\176\169"];
data["\236\132\164\234\179\132\235\143\132"]=self.tb.guid;
data["\236\176\189\234\179\160"]=self.tb.guid;
data["\236\131\129\236\156\132"]=_S["\237\152\132\236\158\172\235\167\181"];
if old["\234\184\176\236\152\168"]then
data["\234\184\176\236\152\168"]={};
for k,v in pairs(old["\234\184\176\236\152\168"])do
_G["\236\153\184\235\182\128\236\152\168\235\143\132"]=v;
if v<=10 then
data["\234\184\176\236\152\168"][k]=bp["\236\139\164\235\130\180\234\184\176\236\152\168"][1];
elseif v<=30 then
data["\234\184\176\236\152\168"][k]=bp["\236\139\164\235\130\180\234\184\176\236\152\168"][2];
else
data["\234\184\176\236\152\168"][k]=bp["\236\139\164\235\130\180\234\184\176\236\152\168"][3];
end
_G["\236\153\184\235\182\128\236\152\168\235\143\132"]=nil;
end
end
_S.maps[self.sdata.nextMap]=data;

if self.sdata.prevObjects then
_G.onMapGenerated=function()
for k,v in pairs(self.sdata.prevObjects)do
if objecttable[v.id].class~="HouseDoor"then
_S.maps[self.sdata.nextMap].objects[k]=v;
end
end
self.sdata.prevObjects=nil;
end
end
end

_G.nextMap=self.sdata.nextMap;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

function House:complete(menu,...)

if menu=="\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
local nextId=table.unpack({...});
local data=_S.maps[self.sdata.nextMap];
if data then
self.sdata.prevObjects=data.objects;
end
_S.maps[self.sdata.nextMap]=nil;
world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(nextId,cb,self.guid);
self:swap(nextId);
elseif menu=="\235\169\148\235\137\180_\236\178\160\234\177\176"then
if self.sdata.nextMap then
_S.maps[self.sdata.nextMap]=nil;
end
Object.complete(self,menu,...);
else
Object.complete(self,menu,...);
end
end

function House:menuEnabled(menu)
if menu=="\235\169\148\235\137\180_\236\178\160\234\177\176"then
if self.sdata.nextMap and _S.maps[self.sdata.nextMap]then
for k,v in safe_pairs(_S.maps[self.sdata.nextMap].objects)do
if v.id=="\236\149\132\236\157\180\237\133\156"then
return false;
else
local recipe=recipetable[v.id];
if recipe and recipe["\236\178\160\234\177\176\236\156\168"]then
return false;
end
end
end
end
end
return Object.menuEnabled(self,menu);
end


function House:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\167\132\236\158\133"then
self:travel();
else
Object.menuTouch(self,from,menu,onOk,onCancel);
end
end
