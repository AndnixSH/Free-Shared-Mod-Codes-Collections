NPC=Player:new({
defAttackAnim="ani_attack",
defAttackAddAnim="ani_attack",
defAttackShieldAnim="ani_attack",
defAttackLeftAnim="ani_attack",
defStopAnim="ani_idle",
defBattleStopAnim="ani_idle",
defBattleGuardAnim="ani_idle",
defMezeAnim="ani_idle",
defMeze2Anim="ani_idle",
torchPostFix="";
guardPostFix="";
mcNickPath="\236\186\144\235\166\173\237\132\176\236\157\180\235\166\132_NPC",
findPathBlock=Filter_Path,
floatY=-30,
})

function NPC:init(guid,sdata)
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
self.guid=guid;
self.data=monstertable[sdata.id];
assert(self.data,sdata.id);
if type(self.data["spine"])=="table"then
self.spineFileName=self.data["spine"];
else
self.spineFileName={self.data["spine"],self.data["spine"]};
end
self.spineSkin=self.data.skin;
if sdata["\236\131\157\236\130\176\236\191\168"]then
self.spineSkin=self.data["\235\175\184\235\129\188\236\191\168skin"]or self.spineSkin;
end
self.spineScale=(self.data.scale or 1)/2;
self.sdata=sdata;
sdata["\235\178\132\237\148\132"]=sdata["\235\178\132\237\148\132"]or{};
self.buff=sdata["\235\178\132\237\148\132"];

if self.data.mcNick then
self.mcNickPath=self.data.mcNick;
elseif self.sdata.boss then
self.mcNickPath="\236\186\144\235\166\173\237\132\176\236\157\180\235\166\132_\235\179\180\236\138\164";
end

local lifeP=1;
if self.sdata["\236\131\157\235\170\133\235\160\165"]then
lifeP=self.sdata["\236\131\157\235\170\133\235\160\165"]/self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
end

for k,v in ipairs(const("\235\170\172\236\138\164\237\132\176\235\179\180\236\160\149\235\170\169\235\161\157"))do
if not self.data[v]then
self.sdata[v]=self:ev("\235\170\172\236\138\164\237\132\176 "..v);

assert(self.sdata[v],v);
end
end
self.sdata["\236\131\157\235\170\133\235\160\165"]=self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*math.clamp(lifeP,0,1);



Player.init(self,guid,sdata);

self:checkDisappear();

end


function NPC:getName()
if self.sdata.elite then
return _L("\236\151\152\235\166\172\237\138\184").." "..self.data.name;
else
return self.data.name;
end
end
function NPC:initData(sdata)
self.sdata=sdata;
self.sdata["AP"]=self.sdata["AP"]or 0;
self.sdata["\236\150\180\234\183\184\235\161\156"]=self.sdata["\236\150\180\234\183\184\235\161\156"]or{};
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]or 0;
self.sdata["\236\138\164\237\143\176"]=self.sdata["\236\138\164\237\143\176"]or{x=self.sdata.x,y=self.sdata.y};

if table.find(self.data["\235\182\132\235\165\152"],"\235\172\188\234\179\160\234\184\176")then
self.findPathBlock=self.findPathBlock-Block_Water;
end
if self.mcNick then
self.mcNick.nick:SetText(self:getName());
end
end

function NPC:appear(cb)
local ncb=0;
if self.sdata.elite then
self:addDebuf("\236\151\152\235\166\172\237\138\184\235\170\172\236\138\164\237\132\176");
self.sdata["\236\131\157\235\170\133\235\160\165"]=self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
do
local area=ev("\236\167\128\236\151\173 \235\160\136\235\178\168");
local list={};
for k,v in pairs(monsterskilltable)do
list[k]=v["\236\167\128\236\151\173"..area];
end
local k=math.randlist(list);
self.sdata.skills={[k]=1};
self.sdata.skillMode="\234\184\176\235\179\184";
self.sdata.skillC=1;
self.sdata.skillTurn=countkcc(const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\237\132\180",self.sdata.skillMode));
self.sdata.skillP=const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\237\153\149\235\165\160");
self.sdata.skillModeP=const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\235\170\168\235\147\156\237\153\149\235\165\160");
end
end

if self.data["\237\134\160\237\133\156"]then
trace(self.data["\237\134\160\237\133\156"]);
for k,v in pairs(self.data["\237\134\160\237\133\156"])do
EquipOption(self.buff,self.guid.."/"..k,v);
end
end

if self.data["\236\138\164\237\130\172"]then
self.sdata.skills=self.data["\236\138\164\237\130\172"];
self.sdata.skillCond=self.data["\236\138\164\237\130\172\236\161\176\234\177\180"];
self.sdata.skillMode="\234\184\176\235\179\184";
self.sdata.skillC=1;
self.sdata.skillTurn=self.data["\236\138\164\237\130\172\236\191\168"]or countkcc(const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\237\132\180",self.sdata.skillMode));
self.sdata.skillModeP=self.data["\236\138\164\237\130\172\235\170\168\235\147\156\237\153\149\235\165\160"]or const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\235\170\168\235\147\156\237\153\149\235\165\160");
self.sdata.skillP=self.data["\236\138\164\237\130\172\237\153\149\235\165\160"]or const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\237\153\149\235\165\160");
end

if self.data["\236\167\132\236\152\129"]=="\236\160\129\234\181\176"then
self:updateSleepMode(GetTimeZone());








else
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"]="\234\184\176\235\179\184";
end
if self.data["\235\147\177\236\158\165\236\178\180"]then
trace("\235\147\177\236\158\165\236\178\180",self.guid,self.data["\235\147\177\236\158\165\236\178\180"]);
local from={x=self.pos.x,y=self.pos.y,z=0};
local to={x=self.pos.x,y=self.pos.y,z=0};
local cls=self.data["\235\147\177\236\158\165\236\178\180"];
local projectile;
ncb=ncb+1;
if type(cls)=="table"then
projectile=self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
end
projectile.onDestroy=function()
trace("\235\147\177\236\158\165\236\178\180 \235\129\157",self.guid);
ncb=ncb-1;
if ncb==0 then
cb(true);
end
end
end

if self.data["\235\147\177\236\158\165 \236\149\160\235\139\136"]then
trace("\235\147\177\236\158\165 \236\149\160\235\139\136",self.guid,self.data["\235\147\177\236\158\165 \236\149\160\235\139\136"]);
local _cb=function()
ncb=ncb-1;
if ncb==0 then
trace("\235\147\177\236\158\165 \236\149\160\235\139\136 \235\129\157",self.guid);
cb(true);
end
end
ncb=ncb+1;
self:play(self.data["\235\147\177\236\158\165 \236\149\160\235\139\136"],nil,nil,_cb);
end

if self.data["\235\147\177\236\158\165\235\140\128\236\130\172"]then
local function onOk()
ncb=ncb-1;
if ncb==0 then
trace("\235\140\128\236\130\172\235\129\157");
cb(true);
end
end
ncb=ncb+1;
world:addStory(_L(self.data["\235\147\177\236\158\165\235\140\128\236\130\172"]),onOk,self);
end

if ncb==0 then
ncb=nil;
cb();
end
end


function NPC:onChildDie(guid)
self:delBuff(nil,guid);
if self.sdata.room then
local room=roomtable[self.sdata.room];
for i,t in safe_ipairs(self.sdata.waveData)do
local id=t.childs[guid];
if id then
t.childs[guid]=nil;
local data=room["\235\179\180\236\138\164\236\155\168\236\157\180\235\184\140"][i];
if data then
if data["\235\160\136\236\150\180\236\158\144\236\139\157"]==id then
for guid,id in pairs(t.childs)do
local o=world:findCharac(guid);
if o then
o:die();
end
end
end
end
end
end
if self.sdata.shadowData then
for id,t in pairs(self.sdata.shadowData)do
if type(t)=="table"and t.childs then
for i,g in pairs(t.childs)do
if g==guid then
t.childs[i]=nil;
end
end
end
end
end
end
end

function NPC:updateSpawn(AP)
if self.sdata.room and self.sdata.talk then
local room=roomtable[self.sdata.room];
self.sdata.waveData=self.sdata.waveData or{};
if room["\235\179\180\236\138\164\234\183\184\235\166\188\236\158\144"]then
self.sdata.shadowData=self.sdata.shadowData or{};
local id=room["\235\179\180\236\138\164\234\183\184\235\166\188\236\158\144"]["\235\170\172\236\138\164\237\132\176"];
local hp=room["\235\179\180\236\138\164\234\183\184\235\166\188\236\158\144"].hp;
local hpp=self.sdata["\236\131\157\235\170\133\235\160\165"]/self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*100;
self.sdata.shadowData[id]=self.sdata.shadowData[id]or{childs={}};
for i,p in ipairs(hp)do
if hpp<=p then
if not self.sdata.shadowData[id].childs[i]then
do
local pts={};
for k,v in safe_pairs(self.sdata.roomPts)do
if world.ground:canTileWalkable(v.x,v.y,self.findPathBlock)and not world.ground:inLOS(v.x,v.y)then
table.insert(pts,v);
end
end
local p=table.choice(pts);
if p then
local guid,data,o=SpawnMonster(p.x,p.y,0,0,id,nil,room["\235\179\180\236\138\164\234\183\184\235\166\188\236\158\144"].param);
o.sdata["\236\131\157\235\170\133\235\160\165"]=o:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*hpp/100;
o:updateHP();
self.sdata.shadowData[id].childs[i]=guid;
end
end
do
local pts={};
for k,v in safe_pairs(self.sdata.roomPts)do
if world.ground:canTileWalkable(v.x,v.y,self.findPathBlock)and not world.ground:inLOS(v.x,v.y)then
table.insert(pts,v);
end
end
local p=table.choice(pts);
if p then
local function cb()
world:resumeTurn();
end
world:pauseTurn();
self:teleport(p.x,p.y,nil,nil,cb);
end
end
break;
end
end
end
end
if room["\235\179\180\236\138\164\235\179\181\236\160\156"]then
self.sdata.shadowData=self.sdata.shadowData or{};
self.sdata.shadowData.T=self.sdata.shadowData.T or countkcc(room["\235\179\180\236\138\164\235\179\181\236\160\156"]["\234\176\132\234\178\169"]);
self.sdata.shadowData.T=self.sdata.shadowData.T-AP;
if self.sdata.shadowData.T<=0 then
self.sdata.shadowData.T=nil;
local id=room["\235\179\180\236\138\164\235\179\181\236\160\156"]["\235\170\172\236\138\164\237\132\176"];
self.sdata.shadowData[id]=self.sdata.shadowData[id]or{childs={}};
if table.empty(self.sdata.shadowData[id].childs)then

local pts={};
for k,v in safe_pairs(self.sdata.roomPts)do
if world.ground:canTileWalkable(v.x,v.y,self.findPathBlock)then
local cx,cy=v.x-self.sdata.roomPos.x,v.y-self.sdata.roomPos.y;
local dir;
if math.abs(cx)>math.abs(cy)then
if cx>0 then dir=1;
else dir=2;
end
elseif math.abs(cy)>math.abs(cx)then
if cy>0 then dir=3;
else dir=4;
end
end
if dir then
pts[dir]=pts[dir]or{};
if pts[dir][1]then
local cx2,cy2=pts[dir][1].x-self.sdata.roomPos.x,pts[dir][1].y-self.sdata.roomPos.y;
if math.max(math.abs(cx),math.abs(cy))>math.max(math.abs(cx2),math.abs(cy2))then
pts[dir]={};
end
end
table.insert(pts[dir],v);
end
end
end
local myDir=math.random(4);
local hpp=self.sdata["\236\131\157\235\170\133\235\160\165"]/self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*100;
for i=1,4 do
local p=table.choice(pts[i]);
if p then
if i==myDir then
local function cb()
world:resumeTurn();
end
world:pauseTurn();
self:teleport(p.x,p.y,nil,nil,cb);
else
if p then
local param=room["\235\179\180\236\138\164\235\179\181\236\160\156"].param or{};
table.copy({["\235\182\128\235\170\168"]=self.guid},param);
local guid,data,o=SpawnMonster(p.x,p.y,0,0,id,nil,param);
o.sdata["\236\131\157\235\170\133\235\160\165"]=o:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*hpp/100;
o:updateHP();
table.insert(self.sdata.shadowData[id].childs,guid);
end
end
end
end
end
end
end

if room["\235\179\180\236\138\164\236\155\168\236\157\180\235\184\140"]and room["\235\179\180\236\138\164\236\155\168\236\157\180\235\184\140"][1]and room["\235\179\180\236\138\164\236\155\168\236\157\180\235\184\140"][1]["\235\182\128\235\170\168\236\158\144\235\166\172"]then
for i,t in ipairs(self.sdata.waveData)do
for guid,id in pairs(t.childs)do
local o=world:findCharac(guid)or world:findObject(guid);
if o and(o.tile.x~=self.tile.x or o.tile.y~=self.tile.y)then
o:die();
end
end
end
end

for i,data in safe_ipairs(room["\235\179\180\236\138\164\236\155\168\236\157\180\235\184\140"])do
self.sdata.waveData[i]=self.sdata.waveData[i]or{childs={}};
local waveData=self.sdata.waveData[i];
if not data["\236\181\156\235\140\128\236\158\144\236\139\157"]or table.length(waveData.childs)<data["\236\181\156\235\140\128\236\158\144\236\139\157"]then
if data["\234\176\132\234\178\169"]then
waveData.T=(waveData.T or countkcc(data["\234\176\132\234\178\169"]))-AP;
if waveData.T<=0 then
waveData.T=countkcc(data["\234\176\132\234\178\169"]);
for i=1,data["\235\176\152\235\179\181"]or 1,1 do
local nChild=table.length(waveData.childs);
if not data["\236\181\156\235\140\128\236\158\144\236\139\157"]or nChild<data["\236\181\156\235\140\128\236\158\144\236\139\157"]then
local ids=table.copy(data["\236\155\168\236\157\180\235\184\140"]);
if data["\235\160\136\236\150\180\236\158\144\236\139\157"]then
local n=table.count(waveData.childs,data["\235\160\136\236\150\180\236\158\144\236\139\157"]);
if data["\236\181\156\235\140\128\236\158\144\236\139\157"]and n==0 and nChild+1==data["\236\181\156\235\140\128\236\158\144\236\139\157"]then
ids={[data["\235\160\136\236\150\180\236\158\144\236\139\157"]]=1};
else
if n>=1 then
ids[data["\235\160\136\236\150\180\236\158\144\236\139\157"]]=nil;
end
end
end
if data["\236\156\160\236\157\188\236\158\144\236\139\157"]then
for k,v in pairs(ids)do
local n=table.count(waveData.childs,k);
if data["\236\156\160\236\157\188\236\158\144\236\139\157"]<=n then
ids[k]=nil;
end
end
end
local id=math.randlist(ids);
local param={["\235\182\128\235\170\168"]=self.guid};
local guid,sdata;
local x,y;
data.param=data.param or{};
table.copy(data.param,param);
if type(data["\235\178\148\236\156\132"])=="table"and data["\235\178\148\236\156\132"][1]==0 and i==1 then
x,y=self.tile.x,self.tile.y;
elseif type(data["\235\178\148\236\156\132"])=="table"and data["\235\178\148\236\156\132"][2]==0 then
x,y=self.tile.x,self.tile.y;
elseif data["\236\156\132\236\185\152"]=="\234\179\160\236\160\149"then
if waveData.pos then
x,y=waveData.pos.x,waveData.pos.y;
else
x,y=world.ground:getRandGotoTile(self.tile.x,self.tile.y,data["\235\178\148\236\156\132"][1],data["\235\178\148\236\156\132"][2],nil,nil,self.findPathBlock);
waveData.pos={x=x,y=y};
end
elseif type(data["\236\156\132\236\185\152"])=="table"and#data["\236\156\132\236\185\152"]>0 then
local list={};
for k,v in pairs(data["\236\156\132\236\185\152"])do
local x=self.sdata.roomPos.x+v[1];
local y=self.sdata.roomPos.y+v[2];
if world.ground:canTileWalkable(x,y,self.findPathBlock)then
table.insert(list,{x,y});
trace("\237\151\136\235\172\180\235\176\156\236\139\160\234\184\176",v);
end
end
x,y=table.unpack(table.choice(list));
else
x,y=world.ground:getRandGotoTile(self.tile.x,self.tile.y,data["\235\178\148\236\156\132"][1],data["\235\178\148\236\156\132"][2],nil,nil,self.findPathBlock);
end

if x and y and id then
if monstertable[id]then
guid,sdata=SpawnMonster(x,y,0,0,id,nil,param);
elseif objecttable[id]then
local o=world:createObject(id,x,y,param);
guid,sdata=o.guid,o.sdata;
end
if data["\237\143\173\235\176\156\236\178\180"]then
local cls=data["\237\143\173\235\176\156\236\178\180"];
if type(cls)=="table"then
local sx,sy=world.ground:TileToMap(x,y);
local from={x=self.pos.x,y=self.pos.y,z=0};
local to={x=sx,y=sy,z=0};
local p=self:addProjectile(_G[cls.cls],from,to,table.copy(cls));
p.onDestroy=function()
end
end
end
end
if guid then
waveData.childs[guid]=id;
if data["\235\182\128\235\170\168\235\178\132\237\148\132"]then
local t=table.choice(data["\235\182\128\235\170\168\235\178\132\237\148\132"]);
for k,v in pairs(t)do
self:addBuff(k,guid,v);
end
end
if data.LifeT then
if sdata then
sdata.LifeT=data.LifeT;
end
end
if data["\235\148\148\235\178\132\237\148\132"]then
local t=table.choice(data["\235\148\148\235\178\132\237\148\132"]);
for k,v in pairs(t)do
if const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157",k)then
world.player:addDebuf(k,guid,data["\235\148\148\235\178\132\237\148\132T"]or const("\235\179\180\236\138\164\235\148\148\235\178\132\237\148\132\236\139\156\234\176\132"),guid);
else
world.player:addBuff(k,guid,v);
end
end
end
end
end
end
end
end
end
end
end
end

function NPC:initSkeleton(spineFileName,spineSkin,spineScale)
Player.initSkeleton(self,spineFileName,spineSkin,spineScale);
do
local x,y,cx,cy=self.skeleton:getBound();
self.frontP=math.min(0.5,200/(cx*2+cy));


self.height=(-y)*spineScale;
self.mcNickOffset={0,-self.height+_Z.NpcNickOffset};
end

for k,v in safe_pairs(self.data.attachment)do
if v~=0 then
self.skeleton:setAttachment(k,v);
else
self.skeleton:setAttachment(k);
end
end
end

function NPC:isDetect(tx,ty)
tx=tx or self.tile.x;
ty=ty or self.tile.y;

return world.ground:inLOS(tx,ty)and
(self:getTeam()=="\236\149\132\234\181\176"or
(self.sdata["\234\179\181\234\178\169T"]and self.sdata["\234\179\181\234\178\169T"]+const("\235\170\172\236\138\164\237\132\176\236\157\128\236\139\160\236\180\136\234\184\176\237\153\148")>=_S.T)or
math.max(0,world.player:getDetect(self))>=self:bf("\236\157\128\235\176\128\235\143\132"));
end

function NPC:setDetect(tx,ty,b)
if self.sdata.detected~=b then
self.sdata.detected=b;
local function f(o,a)
self.detectT=a;
end
local easing=linear;
local tw=Tweener(self.canvas,f,0,1,_Z.walkDur/4,0,easing);
self.timer.add("setDetect",tw.update);
tw.update(0);
end

local fclr=world.ground:getFloorColor(tx,ty);
local a=fclr>>24;
if b then
a=a*(self.detectT or 1);
else
a=a*(1-(self.detectT or 1));
end
local clr=(fclr&0x00ffffff)|math.floor(a+0.5)<<24;
self.canvas:SetAlphaColor(clr);
self.canvas:SetVisible(a>0);

end

function NPC:isMelee()
return self.data["\234\179\181\234\178\169 \235\176\169\236\139\157"]=="\235\176\128\235\166\172";
end

function NPC:hasAP()

return not self.dying and self.sdata.AP>=math.max(const("\237\149\156\237\132\180"),self:bf("\236\157\180\235\143\153AP"),self:bf("\234\179\181\234\178\169AP"));
end

function NPC:onBeginTurn()
Player.onBeginTurn(self);
if not self.turnPaused then
self.sdata.AP=self.sdata.AP+world.tickAP;
end

end
function NPC:beganTurn(type)

if type=="walk"then
self.sdata.wV=nil;
self.pathN=nil;
local wAP=self:bf("\236\157\180\235\143\153AP");
if self.path then

local n=math.min(#self.path-1,math.floor(self.sdata.AP/wAP));
if n>0 then
for i=n+2,#self.path,1 do
self.path[i]=nil;
end
self.pathN=n;

self.sdata.AP=math.max(0,self.sdata.AP-n*wAP);
end
end

do
local mode=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"];
if mode~="\236\160\132\237\136\172"and mode~="\235\143\132\235\176\156"then
self.sdata.AP=self.sdata.AP%wAP;
end
end
elseif type=="attack"then
elseif type=="next"then
self.sdata.AP=self.sdata.AP%const("\237\149\156\237\132\180");
self:preEndTurn();
elseif type=="eat"then
self.sdata.AP=self.sdata.AP-const("\237\149\156\237\132\180");
assert(self.sdata.AP>=0,type,self:getType());

end
Player.beganTurn(self,type);

end
function NPC:getWalkDur()
return world.player:getWalkDur()/(self.pathN or 1)*0.95;
end


function NPC:walk(dt)

if self.path then
local wdur=self:getWalkDur();
self.walkT=self.walkT+dt;
if self.walkT>=wdur then
self.walkT=wdur;
self:moveTo();
if self.path[3]and world.ground:canWalkable(self.path[3].x,self.path[3].y,self.findPathBlock)then
table.remove(self.path,1);

self:unplace();
self:nextMove();
self:place();
else
self:preEndTurn();
end
else
self:moveTo();
end
end
end


function NPC:destroy()
if self.sdata["\235\182\128\235\170\168"]then
world.player:delBuff(nil,self.guid);
local parent=world:findCharac(self.sdata["\235\182\128\235\170\168"]);
if parent then
parent:onChildDie(self.guid);
end
world.player:updateIcon();
end
Player.destroy(self);
end

function NPC:updateMC()
Player.updateMC(self);
end

function NPC:update(dt)
Player.update(self,dt);
end

function NPC:updateIcon()
if not self.dying then
local tz=GetTimeZone();
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local mode=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"];

if mode=="\236\136\152\235\169\180"or self:hasBuff("\236\136\152\235\169\180")then
self:addParticle("\236\136\152\235\169\180");
else
self:delParticle("\236\136\152\235\169\180");
end

if mode=="\236\160\132\237\136\172"or mode=="\235\143\132\235\176\156"then
self:showIconEffect("ani_effect_battle","effect_battle");
elseif mode=="\234\178\189\234\179\132"then
self:showIconEffect("ani_effect_battle","effect_battle_alert");
else
self:hideIcon();
end









if self.sdata.skills then
if self.sdata.skillMode=="\236\138\164\237\130\172"then
if not self.timer.getEvent("skillMode")then
local function f(o,v)
local c=math.floor(v*255);
o:SetAlphaColorRGBA(0xff,c,c,0xff);
end
local tw=Tweener(self.mc,f,1,0,1,0,linear)
function tw:onCompleted()
tw.reverse();
end
self.timer.add("skillMode",tw.update);
end
else
self.timer.remove("skillMode");
self.mc:SetAlphaColor(0xffffffff);
end
end




local v=world.ground:getTileWalkability(self.tile.x,self.tile.y);
local inLight=world.ground:inTileLight(self.tile.x,self.tile.y)or(mapType=="\237\149\132\235\147\156"and tz~=TimeZone_Night);

if self.data["\236\150\180\235\145\160\235\178\132\237\148\132"]then
if not inLight then
if not self:hasBuff(self.data["\236\150\180\235\145\160\235\178\132\237\148\132"])then
self:addDebuf(self.data["\236\150\180\235\145\160\235\178\132\237\148\132"]);
end
else
self:delBuff(nil,self.data["\236\150\180\235\145\160\235\178\132\237\148\132"]);
self.sdata:add("\236\131\157\235\170\133\235\160\165",0,0,self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"));
end
end

if self.data["\235\185\155\235\178\132\237\148\132"]then
if inLight then
if not self:hasBuff(self.data["\235\185\155\235\178\132\237\148\132"])then
self:addDebuf(self.data["\235\185\155\235\178\132\237\148\132"]);
end
else
self:delBuff(nil,self.data["\235\185\155\235\178\132\237\148\132"]);
self.sdata:add("\236\131\157\235\170\133\235\160\165",0,0,self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"));
end
end

if self.data["\236\152\164\235\184\140\236\160\157\237\138\184\235\178\132\237\148\132"]then
for k,v in pairs(self.data["\236\152\164\235\184\140\236\160\157\237\138\184\235\178\132\237\148\132"])do
if self:queryObject(self.tile,1,k)then
if not self:hasBuff(v)then
self:addDebuf(v);
end
else
self:delBuff(nil,v);
end
end
end

if not self:hasBuff("\235\182\136\235\185\155\234\179\181\237\143\172")then
if self.data["\235\185\155\234\179\181\237\143\172"]and inLight then
if math.randpercent(self.data["\235\185\155\234\179\181\237\143\172"])then
self:changeMode("\234\184\176\235\179\184");
self:addBuff("\235\182\136\235\185\155\234\179\181\237\143\172","\235\185\155\234\179\181\237\143\172",1);
end
end
else

if self.data["\236\150\180\235\145\160\236\149\136\236\160\149"]and not inLight then
if math.randpercent(self.data["\236\150\180\235\145\160\236\149\136\236\160\149"])then
self:delBuff("\235\182\136\235\185\155\234\179\181\237\143\172");
if self.data["\236\150\180\235\145\160\236\166\137\236\130\172"]then
if math.randpercent(self.data["\236\150\180\235\145\160\236\166\137\236\130\172"])then
self:die();
end
end
end
end
end


if self.data["\235\185\155\236\160\129\236\164\145"]then
if inLight then
self:addBuff("\236\160\129\236\164\145","\235\185\155\236\160\129\236\164\145",self.data["\235\185\155\236\160\129\236\164\145"]);
else
self:delBuff(nil,"\235\185\155\236\160\129\236\164\145");
end
end
Player.updateIcon(self);
end
end
function NPC:setTarget(guid)
if self.sdata["\237\131\128\234\178\159"]~=guid then
self.sdata["\237\131\128\234\178\159"]=guid;
if guid==world.player.guid then
if self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"]=="\236\160\132\237\136\172"then


world.player:stop();

self:playSndQueue(self.data["\236\150\180\234\183\184\235\161\156 \236\130\172\236\154\180\235\147\156"]);
end
end
end
end

function NPC:changeMode(mode,from)
trace("changeMode",mode,self.guid);
if mode and self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"]~=mode then
self:onChangeMode(mode);
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"]=mode;
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]=nil;
if mode=="\236\160\132\237\136\172"then
self:setTarget(from.guid);
elseif mode=="\235\143\132\235\176\156"then
self:setTarget(from.guid);
elseif mode=="\235\143\132\235\167\157"then
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]=countkcc(ev("\235\170\172\236\138\164\237\132\176 \235\143\132\235\167\157 \236\131\129\237\131\156 \236\156\160\236\167\128 \236\139\156\234\176\132"));
elseif mode=="\234\178\189\234\179\132"then
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]=countkcc(ev("\235\170\172\236\138\164\237\132\176 \234\178\189\234\179\132 \236\131\129\237\131\156 \236\156\160\236\167\128 \236\139\156\234\176\132"));
self.sdata["\234\178\189\234\179\132 \236\156\132\236\185\152"]={x=from.tile.x,y=from.tile.y};
else
self:setTarget(nil);
self.sdata["\234\178\189\234\179\132 \236\156\132\236\185\152"]=nil;
self.sdata["\234\184\176\235\179\184 \236\156\132\236\185\152"]=nil;
end
end
end

function NPC:aggro(to,v)
trace("\235\143\132\235\176\156",to:getType());
self:addAggro(to.guid,v or 9999);
self:changeMode("\235\143\132\235\176\156",to);
self:updateIcon();
end


function NPC:addAggro(guid,value,skipSort)
self.sdata["\236\150\180\234\183\184\235\161\156"][guid]=(self.sdata["\236\150\180\234\183\184\235\161\156"][guid]or 0)+value;
trace("addAggro",self.sdata.id,guid,value,self.sdata["\236\150\180\234\183\184\235\161\156"][guid]);
local target=self.sdata["\237\131\128\234\178\159"];
if not skipSort and target and target~=guid and self.sdata["\236\150\180\234\183\184\235\161\156"][guid]>0 then
if not self.sdata["\236\150\180\234\183\184\235\161\156"][target]or self:ev("\235\170\172\236\138\164\237\132\176 \237\131\128\234\178\159 \235\179\128\234\178\189")*self.sdata["\236\150\180\234\183\184\235\161\156"][target]<self.sdata["\236\150\180\234\183\184\235\161\156"][guid]then
self:setTarget(guid);
else
trace("\234\184\176\236\161\180 \236\150\180\234\183\184\235\161\156\234\176\128 \235\141\148 \237\129\188",self.sdata.id,guid,target,self.sdata["\236\150\180\234\183\184\235\161\156"]);
end
end

if self.sdata["\236\150\180\234\183\184\235\161\156"][guid]<=0 then
self.sdata["\236\150\180\234\183\184\235\161\156"][guid]=nil;
if target==guid then
self:setTarget(nil);

local maxK,maxV;
for k,v in pairs(self.sdata["\236\150\180\234\183\184\235\161\156"])do
if not maxV or maxV<v then
maxK=k;
maxV=v;
end
end
if maxK then
self:setTarget(maxK);
else
self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]=0;
self:changeMode("\234\184\176\235\179\184");
end
end
end
end
function NPC:addDamage(from,dmg,vars,...)
if from then

local mode=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"];
local fsm=fsmtable[self.data["\237\140\168\237\132\180"]..mode];

trace("NPC.addDamage",self:getType(),self.data["\237\140\168\237\132\180"]..mode,fsm,a);
self.sdata.hitC=(self.sdata.hitC or 0)+1;
if self.sdata.hitDie and self.sdata.hitDie<=self.sdata.hitC then
self:die();
end

if from and from~=self and from:hasBuff("\237\136\172\235\170\133\237\153\148")then
if math.randpercent(from:ev("\234\179\181\234\178\169\236\139\156\237\136\172\235\170\133\237\153\148\236\160\156\234\177\176\237\153\149\235\165\160"))then
from:delBuff("\237\136\172\235\170\133\237\153\148");
end
end

if not from:hasBuff("\237\136\172\235\170\133\237\153\148")then
_G["\235\141\176\235\175\184\236\167\128"]=dmg;
local a=from:ev("\235\170\172\236\138\164\237\132\176 \235\141\176\235\175\184\236\167\128 \236\150\180\234\183\184\235\161\156");
_G["\235\141\176\235\175\184\236\167\128"]=nil;
self:addAggro(from.guid,from:bf("\236\150\180\234\183\184\235\161\156 \235\129\140\234\184\176",a));
if fsm then
local dist=self:getDistance(from);
if dist<=self:ev("\236\139\156\236\149\188")then
local newMode=math.randlist(fsm["\236\139\156\236\149\188\236\149\136\237\148\188\234\178\169"]);
trace("\236\139\156\236\149\188\236\149\136\237\148\188\234\178\169",self:getType(),newMode,self.guid);
self:changeMode(newMode,from);
else
local newMode=math.randlist(fsm["\236\139\156\236\149\188\235\176\150\237\148\188\234\178\169"]);
self:changeMode(newMode,from);
end
end
end
end
Player.addDamage(self,from,dmg,vars,...);
end

function NPC:setIdleMode(mode)
end

function NPC:isBattleMode()
return self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"]=="\236\160\132\237\136\172";
end

function NPC:isGuardMode()
return false;
end

function NPC:setGuardMode(b)
end

function NPC:updateIdleMode()
end

function NPC:die(...)
self:playSndQueue(self.data["\236\163\189\236\157\140 \236\130\172\236\154\180\235\147\156"]);
Player.die(self,...);
if world.player and not world.player.dying then
if self:getTeam()~="\236\149\132\234\181\176"then
local from=world.player;
from:addExp(self);
do
local v=from:op("\236\178\152\236\185\152\236\139\156 \236\151\144\235\132\136\236\167\128");
if v>0 then
from:healEnergy(v);
end
end
do
local v=from:op("\236\178\152\236\185\152\236\139\156 \236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181\236\156\168");
if v>0 then
local max=from:bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128");
from:healEnergy(max*v);
end
end

do
local v=from:op("\236\178\152\236\185\152\236\139\156 \237\148\188\235\161\156\235\143\132 \237\154\140\235\179\181\236\156\168");
if v>0 then
local max=from:bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168");
_S:add("\237\148\188\235\161\156\235\143\132",-max*v,0,(bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")));
end
end
end
end
if self.sdata.id=="\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168"then
local guid=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].guid or 0;
_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]={T=_S.T,guid=guid+1};
end
end

function NPC:updateSleepMode(tz)
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
local tz=GetTimeZone();
local stz="\235\130\174";
if tz<=2 then stz="\235\176\164";end
local typeC=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",m["\237\131\128\236\158\133"]);
local tb=const("\235\170\172\236\138\164\237\132\176\236\158\160\236\158\144\235\138\148\236\131\129\237\131\156");
local sleepP=0;
if tb[stz]and tb[stz][typeC]then
sleepP=tb[stz][typeC][self.data["\236\162\133\235\165\152"]]or 0;
end
if math.randpercent(sleepP)then
self:changeMode("\236\136\152\235\169\180");
else
self:changeMode("\234\184\176\235\179\184");
end
end

function NPC:onTimeZone(tz)
if tz==2 or tz==4 then
if not self.sdata["\237\131\128\234\178\159"]then
self:updateSleepMode(tz);
end
end
end

function NPC:onResetTurn(AP)
Player.onResetTurn(self,AP);

local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local aiStep=math.floor((self.sdata.AP)/const("\237\149\156\237\132\180"))-math.floor((self.sdata.AP-AP)/const("\237\149\156\237\132\180"));
self:updateDisease(AP);
self:updateSkillTurn();
self:updateSpawn(AP);
local _,list=self:queryEnemy(self.tile,self:ev("\236\139\156\236\149\188"));
local hasMyPlayer=self:getTeam()=="\236\149\132\234\181\176";
for k,v in safe_pairs(list)do
if world.ground.pathFinder:Raycast(self.tile.x,self.tile.y,v.tile.x,v.tile.y)then
if v.isMyPlayer then
hasMyPlayer=true;
end
else
list[k]=nil;
end
end















local function isInSight(guid)
if list and hasMyPlayer then
for k,v in pairs(list)do
if v.guid==guid then
return true;
end
end
end
end
for i=1,aiStep,1 do
local mode=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"];
if self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]then
self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]=self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]+const("\237\149\156\237\132\180");
end

local fsm=fsmtable[self.data["\237\140\168\237\132\180"]..mode];
if mode=="\234\178\189\234\179\132"then
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]-const("\237\149\156\237\132\180");
if self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]<=0 then
self:changeMode("\234\184\176\235\179\184");
elseif self:ev("\235\170\172\236\138\164\237\132\176 \234\178\189\234\179\132 \236\131\129\237\131\156 \237\146\128\235\166\180 \237\153\149\235\165\160")>math.random()then
self:changeMode("\234\184\176\235\179\184");
end
elseif mode=="\235\143\132\235\167\157"then
self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]-const("\237\149\156\237\132\180");
if self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156T"]<=0 then
self:changeMode("\234\184\176\235\179\184");
end
end


if not table.empty(list)and hasMyPlayer then
if self:hasBuff("\237\152\188\235\158\128")then
self.sdata["\236\150\180\234\183\184\235\161\156"]={};
self:changeMode("\234\184\176\235\179\184");
local t=table.choiceval(list);
self:setTarget(t and t.guid);
elseif self:hasBuff("\235\167\164\237\152\185")then
for k,v in pairs(list)do
if v==world.player then
list[k]=nil;
end
end
local t=table.choiceval(list);
self:setTarget(t and t.guid);
else

for k,v in pairs(list)do
local dist=self:getDistance(v);
_G["\234\177\176\235\166\172"]=dist;
if(self.sdata["\236\150\180\234\183\184\235\161\156"][v.guid]or 0)<=0 then
if fsm then
local key="NPC";
if v.isObject then key="\236\152\164\235\184\140\236\160\157\237\138\184";
elseif v.isMyPlayer then key="\237\148\140\235\160\136\236\157\180\236\150\180";
end
if self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]and fsm["\236\157\184\236\167\128\235\179\180\237\152\184"]and fsm["\236\157\184\236\167\128\235\179\180\237\152\184"]>self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]then
else
self:addAggro(v.guid,v:bf("\236\150\180\234\183\184\235\161\156 \235\129\140\234\184\176",fsm["\236\157\184\236\167\128\236\150\180\234\183\184\235\161\156"][key]or 0));
end
end
else
if fsm then
_G["\237\149\180\235\139\185 \236\150\180\234\183\184\235\161\156"]=self.sdata["\236\150\180\234\183\184\235\161\156"][v.guid];
self:addAggro(v.guid,-fsm["\236\139\156\236\149\188\236\149\136\236\150\180\234\183\184\235\161\156\234\176\144\236\134\140"]or 0,true)
_G["\237\149\180\235\139\185 \236\150\180\234\183\184\235\161\156"]=nil;
end
end
if fsm then
if math.randpercent((fsm["\237\153\149\235\165\160"]or 0)*100)then
if fsm and self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]and fsm["\236\157\184\236\167\128\235\179\180\237\152\184"]and fsm["\236\157\184\236\167\128\235\179\180\237\152\184"]>self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]then
else
local newMode=math.randlist(fsm["\236\160\145\234\183\188"]);
if newMode then
self:changeMode(newMode,v);
end
end
end
end
_G["\234\177\176\235\166\172"]=nil;
end
end
end

if mode=="\235\143\132\235\176\156"then
if not world:findCharac(self.sdata["\237\131\128\234\178\159"])and not world:findObject(self.sdata["\237\131\128\234\178\159"])then
trace("\235\143\132\235\176\156\236\131\129\235\140\128\236\151\134\236\157\140",self.sdata["\237\131\128\234\178\159"]);
self:changeMode("\234\184\176\235\179\184");
end
elseif not self:hasBuff("\237\152\188\235\158\128")then

for guid,a in pairs(self.sdata["\236\150\180\234\183\184\235\161\156"])do
if not isInSight(guid)then
local v=world:findCharac(guid);
if v and not v:hasBuff("\237\136\172\235\170\133\237\153\148")then
if fsm then
_G["\237\149\180\235\139\185 \236\150\180\234\183\184\235\161\156"]=a;
self:addAggro(guid,-fsm["\236\139\156\236\149\188\235\176\150\236\150\180\234\183\184\235\161\156\234\176\144\236\134\140"]or 0,true);
_G["\237\149\180\235\139\185 \236\150\180\234\183\184\235\161\156"]=nil;
end
else
self:addAggro(guid,-self.sdata["\236\150\180\234\183\184\235\161\156"][guid]);
end
end
end
end
end
self:investigate();

if self.sdata.talk then
































do
local v=self:ev("\235\179\180\236\138\164\234\183\188\236\160\145\237\133\148\235\160\136\237\143\172\237\138\184");
if v and not self.sdata.curSkill then

local dist=self:getDistance(world.player);
if dist<v.L1 or dist>v.L2 then
if math.randpercent(v.P*100)then
local x,y=world.ground:getRandGotoTile(_S.x,_S.y,1,2,self.tile.x,self.tile.y,self.findPathBlock);
if x and y then
local function cb()
world:resumeTurn();
end
world:pauseTurn();
self:teleport(x,y,nil,nil,cb);
end
end
end
end
end
do
local v=self:ev("\235\179\180\236\138\164\235\143\132\235\167\157\237\133\148\235\160\136\237\143\172\237\138\184");
if v then
_G["\234\179\181\234\178\169\237\154\159\236\136\152"]=self.sdata.hitC or 0;
local pct=ev("\235\179\180\236\138\164\235\143\132\235\167\157\237\133\148\235\160\136\237\143\172\237\138\184\237\153\149\235\165\160");
_G["\234\179\181\234\178\169\237\154\159\236\136\152"]=nil;
if math.randpercent(pct)then
self.sdata.hitC=0;
local pts={};
for k,v in safe_pairs(self.sdata.roomPts)do
if world.ground:canTileWalkable(v.x,v.y,self.findPathBlock)then
table.insert(pts,v);
end
end
local p=table.choice(pts);
if p then
local function cb()
world:resumeTurn();
end
world:pauseTurn();
self:teleport(p.x,p.y,nil,nil,cb);
end
end
end
end
end

self:checkDisappear();

if self.sdata["\236\131\157\236\130\176\236\191\168"]then
self.sdata["\236\131\157\236\130\176\236\191\168"]=self.sdata["\236\131\157\236\130\176\236\191\168"]-AP;
if self.sdata["\236\131\157\236\130\176\236\191\168"]<=0 then
self.sdata["\236\131\157\236\130\176\236\191\168"]=nil;
if self.data["\235\175\184\235\129\188\236\191\168skin"]then
self.skeleton:setSkin(self.data.skin);
end
end
end

do
local v=self:ev("\235\182\128\235\170\168\237\154\140\235\179\181");
if v then
local char=world:findCharacFromId(v.id);
if char then
local dist=self:getDistance(char);
if dist<=v.L then
char:heal(char:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*v.P);
end
end
end
end

if self:ev("\235\182\128\236\136\152\234\184\176")then
local target=nil;
for i,k in ipairs(self:ev("\235\182\128\236\136\152\234\184\176"))do

local o=world:findObjectFromId(k);
if o then
if self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"]~="\236\160\132\237\136\172"then
local attackR=self:ev("\234\179\181\234\178\169 \234\177\176\235\166\172");
local dist=self:getDistance(o);
local canAttack=attackR>=dist and world.ground:canAttackTo(self.center,o.center,attackR);
if canAttack or world.ground:getTileGotoR(self.tile.x,self.tile.y,o.tile.x,o.tile.y,attackR,Filter_Movable)then
target=o;
else
local l,t,r,b=math.min(self.tile.x,o.tile.x),math.min(self.tile.y,o.tile.y),
math.max(self.tile.x,o.tile.x),math.max(self.tile.y,o.tile.y);
local minL,minGuid;
for k,v in pairs(world.objects)do
if not v.dying and v.tb["\234\184\184\235\167\137"]and v.tb["\237\148\188\234\178\169\234\176\128\235\138\165"]then
if v.tile.x>=l and v.tile.x<=r and v.tile.y>=t and v.tile.y<=b then
local L=self:getDistance(v);
if not minL or L<minL then
minL=L;
minGuid=v;
end
end
end
end
target=minGuid;
end
end
end

if not target then
target=o;
end
end
if target then
self:changeMode("\236\160\132\237\136\172",target);
end
end

if not self.dying and self.sdata.LifeT then
self.sdata.LifeT=self.sdata.LifeT-AP;
if self.sdata.LifeT<=0 then
self:die();
end
end

self:cleanBuff();
self:updateIcon();

end

function NPC:checkDisappear()
local inField=IsInField();
local tz=GetTimeZone();
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
if inField then
if not self.dying and self.data["\235\176\164\236\157\128\236\139\160\236\156\168"]then
if tz==TimeZone_Night then
if self.sdata.nightHide==nil then
self.sdata.nightHide=math.randpercent(self.data["\235\176\164\236\157\128\236\139\160\236\156\168"]);
end
if self.sdata.nightHide and not world.ground:inLOS(self.tile.x,self.tile.y)then
self:die(true);
local m=_S.maps[mapId];
m.monsterQ=m.monsterQ or{};
table.insert(m.monsterQ,self.sdata);
trace("\235\176\164\236\157\128\236\139\160",m.monsterQ);
end
elseif self.sdata.nightHide~=nil then
self.sdata.nightHide=nil;
end
end


if not self.dying then
if self.sdata.nightMonster and not self.sdata["\237\131\128\234\178\159"]and tz~=TimeZone_Night then
self:die(true);
elseif self.data["\235\130\174\236\166\137\236\130\172"]and tz~=TimeZone_Night then
self:die(true);
end
end
end
end

function NPC:findPathR(x,y)
























local block=self.findPathBlock;
if not self.sdata["\237\131\128\234\178\159"]then
block=block&(~Block_Trap);
end
local ret=Player.findPathR(self,x,y,block);






return ret;
end

function NPC:investigate()




















end


function NPC:isAmbush(from)
local mode=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"];
trace("isAmbush",mode);
if mode~="\234\178\189\234\179\132"and mode~="\236\160\132\237\136\172"and mode~="\235\143\132\235\176\156"and mode~="\235\143\132\235\167\157"then
local fsm=fsmtable[self.data["\237\140\168\237\132\180"]..mode];
if fsm and self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]and fsm["\236\157\184\236\167\128\235\179\180\237\152\184"]and fsm["\236\157\184\236\167\128\235\179\180\237\152\184"]>self.sdata["\236\157\184\236\167\128\235\179\180\237\152\184T"]then
return false;
end
return true;
end
end

function NPC:disappear(cb)
if self.sdata.boss and self.sdata.boss["\236\162\133\235\163\140"]then
userDB.Save();
userDB.Pause();
local function f3()
local function onOk()
userDB.Resume();
cb();
end
world:addStory(_L(self.sdata.boss["\236\162\133\235\163\140"]),onOk,self);
end
local function f()
local function f2()
f3();
end
world:fadeMode(false,nil,f2,nil,nil,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
end
world:fadeMode(true,nil,f,nil,nil,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
else
cb();
end
end


function NPC:dropKey()
if self.sdata.item then
PlaceItem(self.sdata.item,self.tile.x,self.tile.y);
self.sdata.item=nil;
end
if self.sdata.items then
for k,v in pairs(self.sdata.items)do
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v]then
PlaceItem(v,self.tile.x,self.tile.y);
end
end
self.sdata.items=nil;
end
end

function NPC:drop()
self:dropKey();

if self.sdata.doors then
for k,v in pairs(self.sdata.doors)do
local o=world:findObject(v);
if o and o.open then
o:open();
end
end
world.player:addChat(_L("\235\179\180\236\138\164\235\172\184\234\176\156\235\176\169"));
end

if self.sdata.boss then
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
_S["\236\178\152\236\185\152\235\179\180\236\138\164"][self.sdata.id]=(_S["\236\178\152\236\185\152\235\179\180\236\138\164"][self.sdata.id]or 0)+1;
Mission("\235\179\180\236\138\164\237\129\180\235\166\172\236\150\180",1,m["\236\132\164\234\179\132\235\143\132"]);
for i=1,self.data["\235\147\156\235\158\141\236\136\152"]or 1 do
MakeItemFromDrop("\235\170\172\236\138\164\237\132\176 \235\179\180\236\138\164",100,self.tile.x,self.tile.y,"\234\179\160\234\184\137");
end
for k,v in safe_pairs(self.sdata.boss["\235\147\156\235\161\173"])do
MakeAndPlaceItem(v,self.tile.x,self.tile.y);
end

if self.sdata.boss["\236\162\133\235\163\140\237\148\140\235\158\152\234\183\184"]then
for k,v in pairs(self.sdata.boss["\236\162\133\235\163\140\237\148\140\235\158\152\234\183\184"])do
_S["\237\148\140\235\158\152\234\183\184"][k]=v;
end
end

if self.sdata.boss["\236\162\133\235\163\140\236\151\148\235\148\169"]then
SetGameEnding(self.sdata.boss["\236\162\133\235\163\140\236\151\148\235\148\169"]);
end


if self.sdata.waveData then
for i,t in safe_ipairs(self.sdata.waveData)do
for guid,id in pairs(t.childs)do
local o=world:findCharac(guid)or world:findObject(guid);
if o then
o:die();
end
end
end
end
if self.sdata.shadowData then
for id,t in pairs(self.sdata.shadowData)do
if type(t)=="table"and t.childs then
for i,guid in pairs(t.childs)do
local o=world:findCharac(guid)or world:findObject(guid);
if o then
o:die();
end
end
end
end
end
else
local dropP=self:bf("\235\147\156\235\158\141\236\156\168");
for i=1,self.data["\235\147\156\235\158\141\236\136\152"]or 1 do
MakeItemFromDrop(self.data["\235\147\156\235\158\141 \235\170\172\236\138\164\237\132\176 \234\183\184\235\163\185"],dropP,self.tile.x,self.tile.y,"\236\157\188\235\176\152");
end
end

for i=1,5,1 do
local id=SelectAreaTB(self.data["\235\147\156\235\158\141 \236\149\132\236\157\180\237\133\156"..i]);
if id then
local c=countkcc(SelectAreaTB(self.data["\235\147\156\235\158\141 \236\149\132\236\157\180\237\133\156"..i.."c"]or 1));
for j=1,c do
local p=self:bf("\235\147\156\235\158\141\236\156\168",SelectAreaTB(self.data["\235\147\156\235\158\141 \236\149\132\236\157\180\237\133\156"..i.."p"]));
if math.randpercent(p)then
if type(id)=="table"then
id=math.randlist(id);
end
MakeAndPlaceItem(id,self.tile.x,self.tile.y);
end
end
end
end

if self.data["\234\179\160\234\184\176 \235\147\156\235\158\141 \236\156\160\237\152\149"]then
local i=self.data["\234\179\160\234\184\176 \235\147\156\235\158\141 \236\156\160\237\152\149"];
local p=self:bf("\235\147\156\235\158\141\236\156\168",self.data["\234\179\160\234\184\176 \235\147\156\235\158\141\236\156\168"]);
if math.randpercent(p)then
MakeAndPlaceItem(math.randlist(dropwelltable["\235\170\172\236\138\164\237\132\176 \234\179\160\234\184\176 \235\147\156\235\158\141"..i]["\234\181\144\236\178\1801"]),self.tile.x,self.tile.y);
end
end

AddScore((self.data["\235\170\168\237\151\152\236\160\144\236\136\152"]or 0));

for k,v in pairs({"\234\176\128\236\163\189","\234\179\160\234\184\176","\236\131\157\234\176\128\236\163\189"})do
if self:bf(v.." \235\147\156\235\158\141")>0 then
if math.randpercent(self:bf(v.." \235\147\156\235\158\141"))then
MakeAndPlaceItem(v,self.tile.x,self.tile.y);
end
if math.randpercent(bf(v.." \236\182\148\234\176\128 \236\149\132\236\157\180\237\133\156 \237\154\141\235\147\157")*100)then
MakeAndPlaceItem(v,self.tile.x,self.tile.y);
end
end
end

if self.sdata.boss then
userDB.Save();
end
end

function NPC:getCurSkill()
if not self:hasBuff("\236\138\164\237\130\172\235\182\136\234\176\128")and not self:hasBuff("\235\167\136\235\178\149\235\182\136\234\176\128")then
if self.sdata.curSkill then
return monsterskilltable[self.sdata.curSkill];
end
end

end
function NPC:getPrimaryWeaponInfo()
local p=1;
local skill=self:getCurSkill();
local vars=self.vars;
if skill then
p=skill["\235\141\176\235\175\184\236\167\128"]or 0;
trace("\235\141\176\235\175\184\236\167\128 \234\176\149\237\153\148:"..p);
vars["\235\176\156\236\130\172\236\178\180"]=skill["\235\176\156\236\130\172\236\178\180"];
vars["\235\176\156\236\130\172\236\178\180 \236\130\172\236\154\180\235\147\156"]=skill["\235\176\156\236\130\172\236\178\180 \236\130\172\236\154\180\235\147\156"];
vars["\234\179\181\234\178\169 \236\130\172\236\154\180\235\147\156"]=skill["\234\179\181\234\178\169 \236\130\172\236\154\180\235\147\156"];
vars["\237\131\128\234\178\169 \236\130\172\236\154\180\235\147\156"]=skill["\237\131\128\234\178\169 \236\130\172\236\154\180\235\147\156"];
end

local ani="ani_attack";
if skill and skill["\234\179\181\234\178\169 \236\149\160\235\139\136"]then
ani=skill["\234\179\181\234\178\169 \236\149\160\235\139\136"];
elseif self.data["\234\179\181\234\178\169 \236\149\160\235\139\136"]then
ani=self.data["\234\179\181\234\178\169 \236\149\160\235\139\136"];
end

self.defAttackAnim=ani;
self.defAttackAddAnim=ani;
self.defAttackShieldAnim=ani;
self.defAttackLeftAnim=ani;
p=self:bf("\234\179\181\234\178\169\235\160\165",p);
vars["\234\179\181\234\178\169\236\158\144 \234\179\181\234\178\169\235\160\165"]=self:ev("\234\179\181\234\178\169\235\160\165")*p;
vars["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]=self:ev("\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128")*p;
vars["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]=self:ev("\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128")*p;
vars["\234\179\181\234\178\169 \235\176\169\236\139\157"]=self:ev("\234\179\181\234\178\169 \235\176\169\236\139\157");
vars["\234\179\181\234\178\169 \235\172\180\234\184\176 \236\154\148\234\181\172\237\158\152"]=10;
return true;
end

function NPC:hasNoDebuf(key)
return table.find(self.data["\235\133\184\235\148\148\235\178\132\237\148\132"],key);
end

function NPC:addAttack(to)
local vars=self.vars;
do
_G["\235\141\176\235\175\184\236\167\128"]=vars["\236\181\156\236\162\133 \237\148\188\237\149\180"];
local a=self:ev("\235\170\172\236\138\164\237\132\176 \234\179\181\234\178\169\236\139\156 \236\150\180\234\183\184\235\161\156");
_G["\235\141\176\235\175\184\236\167\128"]=nil;
self:addAggro(to.guid,a);
end
Player.addAttack(self,to);
end

function NPC:checkAttackOption(to)
local vars=self.vars;
local skill=self:getCurSkill();
if skill then
if skill["\235\176\128\236\185\152\234\184\176"]then
local function cb()
end
to:knockBack(cb,self.tile.x,self.tile.y,nil,nil,countkcc(skill["\235\176\128\236\185\152\234\184\176"]));
end
end

if to.isMyPlayer and not self.sdata.item and math.randpercent(self:bf("\234\179\181\234\178\169\236\139\156 \236\160\136\235\143\132"))then
self.sdata.item=StealMyStorageItem();
if self.sdata.item then
if math.randpercent(self:bf("\236\160\136\235\143\132\237\155\132 \235\143\132\235\167\157"))then
self:addDebuf("\235\143\132\235\167\157");
end
end
end

Player.checkAttackOption(self,to);
end

function NPC:checkDamageOption(to)
do
local v=self:ev("\237\148\188\234\178\169\237\133\148");
if v and to then
local dist=self:getDistance(to);
if v.L1>dist or v.L2<dist then
if math.randpercent(v.P*100)then
local x,y=world.ground:getRandGotoTile(_S.x,_S.y,v.L1,v.L2,nil,nil,self.findPathBlock);
if x and y then
local function cb()
world:resumeTurn();
end
world:pauseTurn();
self:teleport(x,y,nil,nil,cb);
end
end
end
end
end
Player.checkDamageOption(self,to)
end

function NPC:onAttackEnd()
local skill=self:getCurSkill();
if skill and skill.scale then
self:setScale(self.spineScale/skill.scale,true,0.3);
end
self.sdata["\234\179\181\234\178\169T"]=_S.T;
Player.onAttackEnd(self);
end

function NPC:updateSkillTurn()
if self.sdata.skills then
while true do
if self.sdata.skillMode=="\234\184\176\235\179\184"then
self.sdata.skillTurn=self.sdata.skillTurn-1;
if self:bf("\234\176\149\236\160\156\236\138\164\237\130\172\235\170\168\235\147\156",0)>0 then
self.sdata.skillTurn=0;
end
if self.sdata.skillTurn<=0 then
local skills={};
for k,v in pairs(self.sdata.skills)do
local cond=self.sdata.skillCond and self.sdata.skillCond[k];
if cond then
if cond["\236\131\157\235\170\133\235\160\165"]and cond["\236\131\157\235\170\133\235\160\165"]>=(self:bf("\236\131\157\235\170\133\235\160\165")/self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"))then
skills[k]=v;
end
else
skills[k]=v;
end
end
local skillModeP=self:bf("\236\138\164\237\130\172\235\170\168\235\147\156\237\153\149\235\165\160",self.sdata.skillModeP);
if not table.empty(skills)and(math.randpercent(skillModeP*100)or self:bf("\234\176\149\236\160\156\236\138\164\237\130\172\235\170\168\235\147\156",0)>0)then
self.sdata.skillMode="\236\138\164\237\130\172";
self.sdata.nextSkills={};
self.sdata.skillC=(self.sdata.skillC or 0)+1;
self.sdata.skillTurn=self.data["\236\138\164\237\130\172\236\191\168"]or countkcc(const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\237\132\180",self.sdata.skillMode));
local idx;
for i=1,self.sdata.skillTurn do
self.sdata.nextSkills[i]=0;
if not idx and math.randpercent(self.sdata.skillP*100)then
idx=i;
end
end
idx=idx or self.sdata.skillTurn;
self.sdata.nextSkills[idx]=math.randlist(skills);
end
end
end
if self.sdata.skillMode=="\236\138\164\237\130\172"then
self.sdata.skillTurn=self.sdata.skillTurn-1;
if self.sdata.nextSkills[1]then
self.sdata.curSkill=self.sdata.nextSkills[1];
table.remove(self.sdata.nextSkills,1);
break;
else
self.sdata.nextSkills=nil;
self.sdata.skillMode="\234\184\176\235\179\184";
local cool=self.data["\236\138\164\237\130\172\235\140\128\234\184\176"]or self.data["\236\138\164\237\130\172\236\191\168"]or countkcc(const("\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176 \236\138\164\237\130\172\237\132\180",self.sdata.skillMode));
self.sdata.skillTurn=math.floor(math.max(0,cool));
self.sdata.curSkill=nil;
if self:bf("\234\176\149\236\160\156\236\138\164\237\130\172\235\170\168\235\147\156",0)<=0 then
break;
end
end
else
break;
end
end
end
end

function NPC:onEnterTile(tx,ty)
Player.onEnterTile(self,tx,ty);
end

function NPC:trigger(guid)
if self.sdata.boss and not self.sdata.talk and(not guid or table.find(self.sdata.doors,guid))then
userDB.Save();
userDB.Pause();
self.sdata.talk=true;
if self.sdata.room then
local room=roomtable[self.sdata.room];
for k,v in safe_pairs(room["\235\179\180\236\138\164\237\138\184\235\166\172\234\177\176"])do
if objecttable[k]then
local c=v.c or 1;
local f=v.f or"trigger";
for guid,data in pairs(_S.maps[_S["\237\152\132\236\158\172\235\167\181"]].objects)do
if data.id==k and c>0 then
local o=world:findObject(guid);
o[f](o);
c=c-1;
end
end
end
end
end
if self.sdata.boss["\235\167\140\235\130\168"]then
world.player:addBuff("\236\139\156\236\149\188","boss",MAP_W,nil,1);
local function onOk()
if self.sdata.boss["\235\167\140\235\130\168\236\151\148\235\148\169"]then
local function f3()

local i,j=world.ground:getNearTileWalkable(world.player.tile.x,world.player.tile.y,Filter_Movable);
local o=world:createObject(self.sdata.boss["\235\167\140\235\130\168\236\151\148\235\148\169\236\152\164\235\184\140\236\160\157\237\138\184"],i,j);
o:play("ani_appear");
local function onOk()

self:resumeTurn();
self:die();
userDB.Resume();
end
world:addStory(_L(self.sdata.boss["\235\167\140\235\130\168\236\151\148\235\148\169\235\140\128\236\130\172"]),onOk,self);
end
local function f()
SetGameEnding(self.sdata.boss["\235\167\140\235\130\168\236\151\148\235\148\169"]);

world.player:teleport(self.tile.x,self.tile.y,0,0);
local function f2()
f3();
end
world:fadeMode(false,nil,f2,nil,nil,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
end
world:fadeMode(true,nil,f,nil,nil,const("\236\163\189\236\157\128\237\155\132\236\150\180\235\145\144\236\155\140\236\167\128\235\138\148\236\139\156\234\176\132"));
else
self:resumeTurn();
userDB.Resume();
end
end
world:addStory(_L(self.sdata.boss["\235\167\140\235\130\168"]),onOk,self);
self:pauseTurn();
return;
end
userDB.Resume();
end
end

function NPC:beginTurn()

self.target=nil;
self.path=nil;
local AP=self.sdata.AP;
local mode=self.sdata["\236\157\180\235\143\153\235\170\168\235\147\156"];

if self.sdata["\236\150\180\234\183\184\235\161\156"]and(self.sdata["\236\150\180\234\183\184\235\161\156"][world.player.guid]or 0)>0 then
self:trigger();
end

if self.data["\235\175\184\235\129\188"]and mode~="\236\136\152\235\169\180"then
local bait,t;
if not self.sdata["\236\131\157\236\130\176\236\191\168"]then
local _,list=self:queryObject(self.tile,1);
for k,v in safe_pairs(list)do
for kk,vv in pairs(self.data["\235\175\184\235\129\188"])do
if v.sdata.item and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v.sdata.item].id==kk then
bait=v;
t=vv;
break;
end
end
end
end
if bait and const("\237\149\156\237\132\180")<=AP then
self:look(bait);
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][bait.sdata.item];
local x,y=bait.sdata.x,bait.sdata.y;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][bait.sdata.item]=nil;
bait:die();
local c=data.c or 1
self:play(t.ani,nil,nil,function(evt)
if evt=="COMPLETE"then
while c>0 do
c=c-1;
self.sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]=(self.sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]or 0)+countkcc(t.eat);
self:heal(self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*(t.healP or 0));
if self.sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]>=t.gauge then
self.sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]=nil;
self.sdata["\236\131\157\236\130\176\236\191\168"]=(self.sdata["\236\131\157\236\130\176\236\191\168"]or 0)+t.cool;
if self.data["\235\175\184\235\129\188\236\191\168skin"]then
self.skeleton:setSkin(self.data["\235\175\184\235\129\188\236\191\168skin"]);
end
MakeAndPlaceItem(t.output,self.tile.x,self.tile.y);
break;
end
end
if c>0 then
local o,d=MakeAndPlaceItem(data.id,x,y);
d.c=c;
o:fly(self.pos);
end
self:preEndTurn();
end
end);
self:beganTurn("eat");
return;
end
end


if mode=="\236\136\152\235\169\180"or self:hasBuff("\236\136\152\235\169\180")or self:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")then

self:beganTurn("next");
return;
elseif self:hasBuff("\234\179\181\237\143\172")or self:hasBuff("\235\143\132\235\167\157")then

self.sdata["\236\150\180\234\183\184\235\161\156"]={};
self:changeMode("\234\184\176\235\179\184");
if self:bf("\236\157\180\235\143\153AP")<=AP then
self:runAway();
goto done;
else
self:beganTurn();
self:preEndTurn();
return;
end
elseif mode=="\235\143\132\235\167\157"then
if self:bf("\236\157\180\235\143\153AP")<=AP then
self:runAway();
goto done;
else
self:beganTurn();
self:preEndTurn();
return;
end
end

do
local v=self:ev("\235\182\128\235\170\168\236\182\148\236\160\129");
if v then
local char=world:findCharacFromId(v.id);
if char then
local dist=self:getDistance(char);
if dist>=v.L then
self.target={x=char.tile.x,y=char.tile.y};
goto done;
end
end
end
end

if self.sdata.boss and self.sdata.talk and self.sdata.room then
local room=roomtable[self.sdata.room];
if room["\235\179\180\236\138\164\236\157\180\235\143\153"]then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
if(self.sdata.bossMoveT or 0)<m.T then
self.sdata.bossMoveT=m.T+countkcc(room["\235\179\180\236\138\164\236\157\180\235\143\153"].T);
self.sdata.bossMoveE=m.T+countkcc(room["\235\179\180\236\138\164\236\157\180\235\143\153"].E);
do
local list={};
for k,v in pairs(world.objects)do
if table.find(room["\235\179\180\236\138\164\236\157\180\235\143\153"].id,v.sdata.id)then
local b,L=world.ground:getTileGoto(self.tile.x,self.tile.y,v.tile.x,v.tile.y,self.findPathBlock)
if b then
table.insert(list,k);
end
end
end
self.sdata.bossMoveK=table.choice(list);
if self.sdata.bossMoveK then
self:addBuff("\236\157\180\235\143\153 \236\134\141\235\143\132 \236\166\157\234\176\128",self.sdata.bossMoveK,1);
end
end
end

if self.sdata.bossMoveK then
if(self.sdata.bossMoveE or 0)>=m.T then
local o=world.objects[self.sdata.bossMoveK];
if not o:isCompleted()then
self.target={x=o.tile.x,y=o.tile.y};
goto done;
else
self:delBuff(nil,self.sdata.bossMoveK);
end
else
self:delBuff(nil,self.sdata.bossMoveK);
end
end
end
end

if self:bf("\235\179\180\235\172\188 \236\130\172\235\131\165")>0 and self:bf("\236\157\180\235\143\153AP")<=AP then
self.sdata.items=self.sdata.items or{};
local maxN=self:bf("\235\179\180\235\172\188 \236\130\172\235\131\165");
if maxN>#self.sdata.items then
local o=self:queryObject(self.tile,0);
if o and o.tb.class=="DropItem"and ItemPrice(o.sdata.item)then
if const("\237\149\156\237\132\180")<=AP then
self:look(o);
o:die();

self:play("ani_get",nil,nil,function(evt)
if evt=="event_get"then
table.insert(self.sdata.items,o.sdata.item);
self.target=nil;
self:preEndTurn();
end
end);
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
self.sdata.huntLifeT=m.T+const("\235\179\180\235\172\188\236\130\172\235\131\165\234\190\188\236\130\172\235\157\188\236\167\144",1);
self:beganTurn("eat");
return;
end
else
if not self.target or not self:queryObject(self.target,0)then
for k,v in pairs(world.objects)do
if v.tb.class=="DropItem"and ItemPrice(v.sdata.item)then
local b,L=world.ground:getTileGoto(self.tile.x,self.tile.y,v.tile.x,v.tile.y,self.findPathBlock)
if b then
self.target={x=v.tile.x,y=v.tile.y};
goto done;
end
end
end
end
end
else
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local m=_S.maps[mapId];
if self.sdata.huntLifeT<=m.T and not world.ground:inLOS(self.tile.x,self.tile.y)then
m["\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"]=m["\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"]or{};
m["\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"][self.guid]=self.sdata;
_S.maps[mapId].npcs[self.guid]=nil;
self.died=true;
end
end
end


if mode=="\236\160\132\237\136\172"or mode=="\235\143\132\235\176\156"then
local target=world:findCharac(self.sdata["\237\131\128\234\178\159"]);
if not target or target:hasBuff("\237\136\172\235\170\133\237\153\148")then
target=world:findObject(self.sdata["\237\131\128\234\178\159"]);
end
if not target then
self:changeMode("\234\184\176\235\179\184");
else
local attackR=self:ev("\234\179\181\234\178\169 \234\177\176\235\166\172");
local dist=self:getDistance(target);
local canAttack=attackR>=dist and world.ground:canAttackTo(self.center,target.center,attackR);

if self:getTeam()~="\236\149\132\234\181\176"and not canAttack and not world.ground:getTileGotoR(self.tile.x,self.tile.y,target.tile.x,target.tile.y,attackR,Filter_Movable)then
local l,t,r,b=math.min(self.tile.x,target.tile.x),math.min(self.tile.y,target.tile.y),
math.max(self.tile.x,target.tile.x),math.max(self.tile.y,target.tile.y);
local minL,minGuid;
for k,v in pairs(world.objects)do
if not v.dying and v.tb["\234\184\184\235\167\137"]and v.tb["\237\148\188\234\178\169\234\176\128\235\138\165"]then
if v.tile.x>=l and v.tile.x<=r and v.tile.y>=t and v.tile.y<=b then
local L=self:getDistance(v);
if not minL or L<minL then
minL=L;
minGuid=v;
end
end
end
end
target=minGuid or target;
end
local dist=self:getDistance(target);
assert(attackR,"\234\179\181\234\178\169 \234\177\176\235\166\172 \236\151\134\236\157\140",self:getType());
local skill=self:getCurSkill();
if skill and skill["\236\130\172\234\177\176\235\166\172"]then
attackR=skill["\236\130\172\234\177\176\235\166\172"];
end



if(dist<=1 and world.ground:canAttackTo(self.center,target.center,attackR))or
(dist>1 and dist<=attackR and world.ground.pathFinder:Raycast(self.tile.x,self.tile.y,target.tile.x,target.tile.y))then

local attackAP=self:ev("\234\179\181\234\178\169AP");
if self.sdata.AP<attackAP then
self:beganTurn();
self:preEndTurn();

return;
end
if target:isTurnBusy()then

return;
end
if skill then
if skill["\235\178\132\237\148\132"]then
if target.addDebufP then
self:addDebufP(skill["\235\178\132\237\148\132 \237\153\149\235\165\160"],skill["\235\178\132\237\148\132"],self);
end
end

if skill["\235\141\176\235\175\184\236\167\128"]then
self:attack(target);
if skill.scale then
self:setScale(self.spineScale*skill.scale,true,0.1);
end
end

if skill["\235\148\148\235\178\132\237\148\132"]then
if target.addDebufP then
_G["\234\177\176\235\166\172"]=self:getDistance(target);
target:addDebufP(skill["\235\148\148\235\178\132\237\148\132 \237\153\149\235\165\160"],skill["\235\148\148\235\178\132\237\148\132"],self);
_G["\234\177\176\235\166\172"]=nil;
end
end


if skill["\237\154\140\235\179\181"]then
if math.randpercent(skill["\237\154\140\235\179\181 \237\153\149\235\165\160"])then
self:heal(self:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*skill["\237\154\140\235\179\181"]);
end
end
else
trace("\234\179\181\234\178\169",self:getType());
self:attack(target);
end
self.sdata.AP=self.sdata.AP-attackAP;
assert(self.sdata.AP>=0);
else
trace("can;t attack near");
if self:bf("\236\157\180\235\143\153AP")<=AP then
self.target=target.tile;
trace("start walking");
else
self:beganTurn();
self:preEndTurn();
return;
end
end
end
elseif mode=="\234\178\189\234\179\132"then
if self:bf("\236\157\180\235\143\153AP")<=AP then
if math.randpercent(self:ev("\235\170\172\236\138\164\237\132\176 \234\178\189\234\179\132 \236\131\129\237\131\156 \236\157\180\235\143\153 \237\153\149\235\165\160"))then
self.target={x=self.tile.x,y=self.tile.y};
else
self.target={x=self.sdata["\234\178\189\234\179\132 \236\156\132\236\185\152"].x,y=self.sdata["\234\178\189\234\179\132 \236\156\132\236\185\152"].y};
end
else
self:beganTurn();
self:preEndTurn();
return;
end
elseif mode=="\234\184\176\235\179\184"then
if self:bf("\236\157\180\235\143\153AP")<=AP then
self:setDefaultTarget();
else
self:beganTurn();
self:preEndTurn();
return;
end
end
::done::

if not self.turnBegan and not self.turnPaused and self:bf("\236\157\180\235\143\153AP")<=self.sdata.AP then

Player.beginTurn(self);
end

if not self.turnBegan and not self.turnPaused then
self.sdata.AP=self.sdata.AP%const("\237\149\156\237\132\180");
self:beganTurn();
self:preEndTurn();
end
end


function NPC:getDefaultTarget()
local to={};
local R=self:ev("\235\170\172\236\138\164\237\132\176 \234\184\176\235\179\184 \236\131\129\237\131\156 \236\157\180\235\143\153 \235\176\152\234\178\189");
local block=self.findPathBlock;
local ox,oy=self.sdata["\236\138\164\237\143\176"].x,self.sdata["\236\138\164\237\143\176"].y;
for j=oy-R,oy+R,1 do
for i=ox-R,ox+R,1 do
if world.ground:canTileWalkable(i,j,block)then
table.insert(to,{x=i,y=j});
end
end
end
if#to>0 then
return table.choice(to);
end
return{x=ox,y=oy};
end

function NPC:setDefaultTarget()
if math.randpercent(self:ev("\235\170\172\236\138\164\237\132\176 \234\184\176\235\179\184 \236\156\132\236\185\152 \235\179\128\234\178\189 \237\153\149\235\165\160"))then
self.sdata["\234\184\176\235\179\184 \236\156\132\236\185\152"]=self:getDefaultTarget();
end
if math.randpercent(self:ev("\235\170\172\236\138\164\237\132\176 \234\184\176\235\179\184 \236\131\129\237\131\156 \236\157\180\235\143\153 \237\153\149\235\165\160"))then
if self.sdata["\234\184\176\235\179\184 \236\156\132\236\185\152"]and type(self.sdata["\234\184\176\235\179\184 \236\156\132\236\185\152"])=="table"then
self.target={x=self.sdata["\234\184\176\235\179\184 \236\156\132\236\185\152"].x,y=self.sdata["\234\184\176\235\179\184 \236\156\132\236\185\152"].y};
elseif self.sdata["\236\138\164\237\143\176"]and type(self.sdata["\236\138\164\237\143\176"])=="table"then
self.target={x=self.sdata["\236\138\164\237\143\176"].x,y=self.sdata["\236\138\164\237\143\176"].y};
end
else
self.target={x=self.tile.x,y=self.tile.y};
end
end


function NPC:playItemSound(key,w)
self:playSndQueue(self:ev(key.." \236\130\172\236\154\180\235\147\156"));
end

function NPC:ev(k,child)
local this=self;
local _ev=ev;
local _bf=bf;
local vars=self.vars or{};

bf=function(...)
return self:bf(...);
end

ev=function(k,wantNil)
if k=="\234\184\176\236\152\168"then return GetTemperature();
elseif k=="\235\167\181 \235\160\136\235\178\168"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\235\167\181 \235\160\136\235\178\168"]
elseif k=="\236\186\144\235\166\173\237\132\176 \235\160\136\235\178\168"then return _S["\235\160\136\235\178\168"];
elseif k=="\236\167\128\236\151\173 \235\160\136\235\178\168"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173 \235\178\136\237\152\184"]
elseif string.starts(k,"\237\154\141\235\147\157_")then
local k=string.sub(k,string.len("\237\154\141\235\147\157_")+1)
return _S["\237\154\141\235\147\157\237\154\159\236\136\152"][k]or 0;
end
local v=vars[k];
if v~=nil then
return v;
end
local v=_G[k];
if v~=nil then
return v;
end
local v=this.sdata[k];
if v~=nil then
return v;
end
if this.data then
local v=this.data[k];
if v~=nil then
return v;
end
for _,_v in safe_pairs(this.data["\235\182\132\235\165\152"])do
local t=const("\235\170\172\236\138\164\237\132\176\235\182\132\235\165\152\235\179\132\236\152\181\236\133\152",_v);
if t then
local v=t[k];
if v~=nil then
return v;
end
end
end

if this.data["\236\152\181\236\133\152"]then
local v=this.data["\236\152\181\236\133\152"][k];
if v~=nil then
return v;
end
end
end
v=evaltable[k];
if v~=nil then
return v;
end

if not wantNil then
return 0;
end
end

local v=ev(k,true);
if v and child~=nil then v=v[child];end
ev=_ev;
bf=_bf;

return v;
end

function NPC:getType()
return self.sdata.id;
end
function NPC:getTeam()
return self.data["\236\167\132\236\152\129"];
end

function NPC:getKind()
return self.data["\235\182\132\235\165\152"];
end

function NPC:slowAttack(...)
end
