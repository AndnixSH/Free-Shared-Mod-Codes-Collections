function GachaPopup(owner)
local tb1=objecttable["_\235\182\128\236\138\164\235\159\172\236\167\132 \236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129"];
local tb2=objecttable["_\236\158\145\236\157\128 \237\153\169\234\184\136 \236\156\160\236\160\129"];
local tb3=objecttable["_\234\177\176\235\140\128\237\149\156 \237\153\169\234\184\136 \236\156\160\236\160\129"];
local noad=not hasAds()or(myInfo.adcnt<servertable.DailyAd and os.time()<userDB.userInfo.tdailyad);
local function init()
owner.w1:Clear();
owner.w2:Clear();
owner.w3:Clear();
owner.dia2:SetText(servertable.BoxOpenDia["\236\158\145\236\157\128 \237\153\169\234\184\136 \236\156\160\236\160\129"]);
owner.dia3:SetText(servertable.BoxOpenDia["\234\177\176\235\140\128\237\149\156 \237\153\169\234\184\136 \236\156\160\236\160\129"]);

if noad then
owner.btnOk1:GotoAndStop(2,true);
owner.btnOk1:enable(false);
SpineObject(owner.w1,"efx",tb1.spine,"ani_idle_none",tb1.skin,tb1.attachment,true);

local rt=math.max(0,userDB.userInfo.tdailyad-os.time());
owner.tad:SetText(string.format("%02d:%02d:%02d",math.floor(rt/3600),math.floor(rt/60)%60,math.floor(rt)%60));
owner.tad:SetVisible(true);
else
owner.btnOk1:GotoAndStop(1,true);
owner.btnOk1:enable(true);
SpineObject(owner.w1,"efx",tb1.spine,tb1["\234\184\176\235\179\184 \236\149\160\235\139\136"],tb1.skin,tb1.attachment,true);
owner.tad:SetVisible(false);
end

owner.btnOk2:GotoAndStop(1,true);
SpineObject(owner.w2,"efx",tb2.spine,tb2["\234\184\176\235\179\184 \236\149\160\235\139\136"],tb2.skin,tb2.attachment,true);

owner.btnOk3:GotoAndStop(1,true);
SpineObject(owner.w3,"efx",tb3.spine,tb3["\234\184\176\235\179\184 \236\149\160\235\139\136"],tb3.skin,tb3.attachment,true);
end

function owner:onEnterFrame(dt)
local noad2=not hasAds()or(myInfo.adcnt<servertable.DailyAd and os.time()<userDB.userInfo.tdailyad);
if noad2~=noad then
noad=noad2;
init();
end

if noad then
local rt=math.max(0,userDB.userInfo.tdailyad-os.time());
owner.tad:SetText(string.format("%02d:%02d:%02d",math.floor(rt/3600),math.floor(rt/60)%60,math.floor(rt)%60));
owner.tad:SetVisible(true);
else
owner.tad:SetVisible(false);
end

end








SetButton(owner.btnOk1).onClick=function(self)
local function onOk()
local function cb()
if owner.this then
init();
end
end
ToastEvent("\234\180\145\234\179\160","adboxopen",0,0,1,_D["\237\148\140\235\160\136\236\157\180"])
OpenTotemBox(cb,"\235\182\128\236\138\164\235\159\172\236\167\132 \236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129",nil,nil,1);
end
local function onCancel()
end
showAds(onOk,onCancel);
end

SetButton(owner.btnOk2).onClick=function(self)
local function cb()
if owner.this then
init();
end
end
OpenTotemBox(cb,"\236\158\145\236\157\128 \237\153\169\234\184\136 \236\156\160\236\160\129",servertable.BoxOpenDia["\236\158\145\236\157\128 \237\153\169\234\184\136 \236\156\160\236\160\129"],nil,nil);
end

SetButton(owner.btnOk3).onClick=function(self)
local function cb()
if owner.this then
init();
end
end
OpenTotemBox(cb,"\234\177\176\235\140\128\237\149\156 \237\153\169\234\184\136 \236\156\160\236\160\129",servertable.BoxOpenDia["\234\177\176\235\140\128\237\149\156 \237\153\169\234\184\136 \236\156\160\236\160\129"],nil,nil);
end

SetButton(owner.btnInfo).onClick=function(self)
local mc=showPopup(owner,"\235\189\145\234\184\176\236\160\149\235\179\180\237\140\157\236\151\133");
GachaInfoPopup(mc);
end

SetButton(owner.btnClose).onClick=function(self)
owner:Remove();
end

init();
end