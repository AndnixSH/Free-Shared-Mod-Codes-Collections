function Loading(owner)
trace("Loading");
local timer=Timer();
owner:SetMouseCapture(true);
owner.onEnterFrame=function(self,dt)
timer.update(dt);
end

do
local list={};
for k,v in pairs(rocktexttable)do
list[k]=v["\235\161\156\235\148\169"];
end
local id=math.randlist(list);
local msg;
if userDB.userInfo.linkId or""==""then
msg=_L("\237\129\180\235\157\188\236\154\176\235\147\156\236\160\128\236\158\165\236\132\164\235\170\1332");
else
msg=rocktexttable[id]["msg_"..curLang]or rocktexttable[id]["msg_ko"];
end
owner.help:SetWidth(APP_W-owner.help:GetX()*2);
owner.help:SetText(msg);
end

local function start()
trace("start");
player:SetPlaySpeed(1);
player:SetNextDeltaTimeZero();
local function s()
root:GotoAndStop("lobby");













end
timer.add(s,s,0.1);
end
owner.onMouseUp=function()
trace("onMouseUp");
return true;
end
owner.onMouseDown=function()
trace("onMouseDown");
return true;
end

owner.onSymbolLoading=function(self,cnt,total)
trace(cnt,total);

if cnt==total then
start();
end
end




local s=function()
local function loadSnd(v,ext)
ext=ext or"wav";
local dir="media/sound/"..ext.."/";
if soundtable[v]then
loadSnd(soundtable[v].path,ext);
else
if v=="\235\147\156\235\158\141"then
elseif type(v)=="string"then
path=dir..v.."."..ext;
trace("loadSnd",path);
assert(root:AddSymbolToLibrary(path,path,TestTable)>0,path);
elseif type(v)=="table"then
for kk,vv in pairs(v)do
loadSnd(vv,ext);
end
end
end
end


for k,v in pairs(require"data.itemtable")do
if v.img then
if string.starts(v.img,"menu_")then
assert(root:AddSymbolToLibrary(v.img,string.format("media/image/_ui/%s.png",v.img),TestTable)>0,v.img);
else
assert(root:AddSymbolToLibrary(v.img,string.format("media/image/item/%s.png",v.img),TestTable)>0,v.img);
end
end
loadSnd(v["\235\147\156\235\158\141 \236\130\172\236\154\180\235\147\156"]);
end

for k,v in pairs(_G.bufftable)do
for k,v in safe_pairs(v.img)do
local path=string.format("buff/%s.png",v);
assert(root:AddSymbolToLibrary(path,"media/image/"..path,TestTable)>0,path);
end
end

for k,v in pairs(soundtable)do
if v.path then
loadSnd(k);
end
end
do
local clsList={};
local spineList={};
for k,v in pairs(objecttable)do
if v.class then
clsList[v.class]=k;
end
if v.img then
local path=string.format("object/%s.png",v.img);
assert(root:AddSymbolToLibrary(path,"media/image/"..path,TestTable)>0,path);
end

if v.spine then
spineList[v.spine]=k;
end
loadSnd(v["\234\184\176\235\179\184 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\236\149\161\236\133\152 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\236\153\132\235\163\140 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\236\149\161\236\133\152\236\139\164\237\140\168 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\235\166\172\236\160\160 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128 \236\130\172\236\154\180\235\147\156"]);
end


for k,v in pairs(spineList)do
assert(spine.loadSkeletonData(
"media/spine/"..k..".json",
"media/spine/"..k..".atlas"
));
end

for k,v in pairs(clsList)do
require("actor."..k);
end
end
for k,v in pairs(skilltable)do
if v.img then
local path=string.format("skill/%s.png",v.img);
assert(root:AddSymbolToLibrary(path,"media/image/"..path,TestTable)>0,path);
end
loadSnd(v["\236\149\161\236\133\152 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\237\148\188\234\178\169 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\235\176\156\235\143\153 \236\130\172\236\154\180\235\147\156"]);
end

for k,v in pairs(spelltable)do
if v.img then
local path=string.format("spell/%s.png",v.img);
assert(root:AddSymbolToLibrary(path,"media/image/"..path,TestTable)>0,path);
end
loadSnd(v["\235\176\156\235\143\153 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\236\149\161\236\133\152 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\237\143\173\235\176\156 \236\130\172\236\154\180\235\147\156"]);
end
for k,v in pairs(totemtable)do
if v.img then
local path=string.format("totem/img_%s.png",v.img);
assert(root:AddSymbolToLibrary(path,"media/image/"..path,TestTable)>0,path);
local path=string.format("totem/BIG_%s.png",v.img);
assert(root:AddSymbolToLibrary(path,"media/image/"..path,TestTable)>0,path);
end
end
for k,v in pairs(monstertable)do
loadSnd(v["\236\150\180\234\183\184\235\161\156 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\236\163\189\236\157\140 \236\130\172\236\154\180\235\147\156"]);
loadSnd(v["\234\179\181\234\178\169 \236\130\172\236\154\180\235\147\156"]);
end
for k,v in pairs(mapbptable)do
loadSnd({v.bgm1,v.bgm2,v.bgm3,v.bgm4},"mp3");
end

for k,v in pairs(bufftable)do
if v.spine then
assert(spine.loadSkeletonData(
"media/spine/"..v.spine..".json",
"media/spine/"..v.spine..".atlas"
));
end
if v.projectile and v.projectile.spine then
assert(spine.loadSkeletonData(
"media/spine/"..v.projectile.spine..".json",
"media/spine/"..v.projectile.spine..".atlas"
));
end
if v.spineobj and v.spineobj.spine then
assert(spine.loadSkeletonData(
"media/spine/"..v.spineobj.spine..".json",
"media/spine/"..v.spineobj.spine..".atlas"
));
end
end
for k,v in pairs(spelltable)do
for k,v in pairs({v["\235\176\156\236\130\172\236\178\180"],v["\236\151\176\234\178\176\236\178\180"],v["\237\143\173\235\176\156\236\178\180"]})do
if v.spine then
assert(spine.loadSkeletonData(
"media/spine/"..v.spine..".json",
"media/spine/"..v.spine..".atlas"
));
end
end
end
for k,v in pairs(const("\235\175\184\235\166\172\235\161\156\235\147\156\236\138\164\237\140\140\236\157\184"))do
if monstertable[v]then
assert(spine.loadSkeletonData(
"media/spine/"..monstertable[v].spine..".json",
"media/spine/"..monstertable[v].spine..".atlas"
));
else
assert(spine.loadSkeletonData(
"media/spine/"..v..".json",
"media/spine/"..v..".atlas"
));
end
end

if LUADEBUG then
debuggee=require"util.vscode-debuggee"
local startResult,breakerType=debuggee.start(json)
print("debuggee start ->",startResult,breakerType)
end
if TestTable==true then
local sks={};
local error;
LoadSlotData(nil,nil,true);
local success=true;
local errormsg="";
local function assert(b,...)
if not b then
local msg=trace("!!!\236\152\164\235\165\152",debug.traceback(),...);
success=false;
errormsg=errormsg..msg;
end
end
local function testParticle(path)
for k,v in safe_pairs(path)do
local e=spine.buildEmitter(string.format("media/particle/%s.json",v),true);
assert(e,v);
end
end

local function testSpine(name,path,skin,slot,attachment,anims,events,slotColors)
pcall(function()

if path then
if not sks[path]then
sks[path],error=spine.buildSkeleton(
"media/spine/"..path..".json",
"media/spine/"..path..".atlas",
1)
assert(sks[path],error);
end
local sk=sks[path];

do
local list=sk:getEventList();

for k,v in pairs(list)do
if string.find(v.name,"particle")then
local t=string.split(v.stringValue,",")
assert(t[1],"\236\157\180\235\178\164\237\138\184 \235\185\132\236\150\180\236\158\136\236\157\140",v,name,path,skin,slot,attachment);
local slot=string.trim(t[1]);
assert(sk:setAnimation(0,v.animation),name,path,"\236\149\160\235\139\136\235\169\148\235\139\136\236\133\152 \236\152\164\235\165\152",v.animation);
sk:update(0.1);
testParticle(string.trim(t[2]));



end
end

local function findEvent(name,anim)
local c=0;
for k,v in pairs(list)do
if table.find(name,v.name)and table.find(anim,v.animation)then
c=c+1;
end
end
return c==1;
end

if events then

for k,v in pairs(events)do
assert(findEvent(k,v),name,k,v,"\236\157\180\235\178\164\237\138\184 \236\151\134\236\157\140");
end
end
end
if _G.type(skin)=="table"then
for k,v in pairs(skin)do
assert(sk:setSkin(v),name..":\236\138\164\237\130\168\236\152\164\235\165\152:"..tostring(v));
end
else
assert(sk:setSkin(skin or"default"),tostring(name)..":\236\138\164\237\130\168\236\152\164\235\165\152:"..tostring(skin));
end
if attachment then
if _G.type(attachment)=="table"then
for k,v in pairs(attachment)do
assert(sk:setAttachment(slot,v),name..":\236\150\180\237\131\156\236\185\152\235\168\188\237\138\184 \236\152\164\235\165\152:"..tostring(slot),v);
end
else
assert(sk:setAttachment(slot,attachment),name..":\236\150\180\237\131\156\236\185\152\235\168\188\237\138\184 \236\152\164\235\165\152:"..tostring(slot),attachment);
end
end
for k,v in safe_pairs(anims)do
if v then
for k,v in safe_pairs(v)do
assert(sk:setAnimation(0,v),name,path,"\236\149\160\235\139\136\235\169\148\235\139\136\236\133\152 \236\152\164\235\165\152",v);
sk:update(0.1);
for slot,b in safe_pairs(slotColors)do
if b then
local clr=sk:getSlotColor(slot);
assert((clr&0xFF000000)>0,name,path,v,slot,"\236\138\172\235\161\175\236\131\137 \236\152\164\235\165\152");
end
end
end
end
end
end
end);
end
local function checkSpell(spell,guid)
if spell then
local reserved={"\236\157\184\236\177\136\237\138\184","\236\154\148\235\166\172\236\177\133 \236\130\172\236\154\169","\235\167\136\235\178\149\236\177\133","\235\185\132\236\160\132 \236\160\156\236\158\145\235\178\149","\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149","\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149","\236\176\168\236\155\144\236\157\152 \236\132\156\237\140\144","\235\130\180\234\181\172\235\143\132\237\154\140\235\179\181"};
if table.find(reserved,spell)then
elseif type(spell)=="table"then
for k,v in pairs(spell)do
checkSpell(v.V or v,guid);
end
else
assert(spelltable[spell],guid..tostring(spell));
end
end
end

for k,v in pairs(const("\237\133\131\235\176\173 \236\149\132\236\157\180\237\133\156 \237\153\149\235\165\160"))do
assert(itemtable[k],"\237\133\131\235\176\173 \236\149\132\236\157\180\237\133\156 \237\153\149\235\165\160"..k);
end
for k,v in pairs(const("\236\149\132\237\139\176\237\140\169\237\138\184\237\139\176\236\150\180\236\152\164\235\184\140\236\160\157\237\138\184"))do
for k,v in pairs(v)do
assert(objecttable[v],v);
end
end

local function checkDebuf(k)
local maxLV=const("\235\148\148\235\178\132\237\148\132 \235\160\136\235\178\168 \235\139\168\234\179\132",k);
if maxLV then
for i=1,maxLV do
assert(ev(k.." LV"..i.." \236\136\152\236\185\152"),k);
end
else
assert(ev(k.." \236\136\152\236\185\152"),k);
end
end

for k,v in pairs(objecttable)do
for k,v in safe_pairs(v["\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128"])do
if const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157",k)then
checkDebuf(k);
end
end
end












for i=1,2,1 do
for k,v in pairs(ev("\237\149\132\235\147\156\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177"..i))do
assert(k=="\234\184\176\237\131\128"or mapbptable[k],k);
for k,v in safe_pairs(v[1])do
assert(monstertable[k],k);
end
end
end

for k,v in pairs(mapbptable)do
for kk,vv in safe_pairs(v["\237\131\128\236\157\188"])do
assert(tiletable[vv],"\237\131\128\236\157\188\237\133\140\236\157\180\235\184\148 \236\151\134\236\157\140",vv);
end
end

for k,v in pairs(itemtable)do
local group=v["\234\183\184\235\163\185"];
local drop=drop1table[group];

if string.starts(k,"\235\169\148\235\137\180_")then
if v["\237\140\140\235\157\188\235\175\184\237\132\176"]then
assert(lang[v["\237\140\140\235\157\188\235\175\184\237\132\176"]],"\235\178\136\236\151\173\236\151\134\236\157\140",v["\237\140\140\235\157\188\235\175\184\237\132\176"]);
end
end

if v["\236\162\133\235\165\152"]and const("\235\182\132\235\165\152C",v["\236\162\133\235\165\152"])then
assert(lang[v["\236\162\133\235\165\152"]],"\235\178\136\236\151\173\236\151\134\236\157\140",v["\236\162\133\235\165\152"]);
end


if v.img then
assert(
root:AddSymbolToLibrary(v.img,string.format("media/image/item/%s.png",v.img),TestTable)>0,
v.img);
end

assert(drop,"\234\183\184\235\163\185\236\152\164\235\165\152:"..k,group);
if v["\237\139\176\236\150\180"]then
assert(_G.type(v["\237\139\176\236\150\180"])=="number",k.."\237\139\176\236\150\180");
end
if v["\236\156\160\237\152\149"]then
if v["\236\156\160\237\152\149"]=="\235\147\156\235\158\141"then
elseif v["\236\162\133\235\165\152"]~="\236\149\133\236\132\184\236\132\156\235\166\172"then
assert(recipetable[k],"\236\160\156\236\158\145\235\178\149\236\151\134\236\157\140:"..k);
if v["\236\156\160\237\152\149"]=="\236\160\156\236\158\145"or v["\236\156\160\237\152\149"]=="\235\147\156\235\158\141"then
assert(recipetable["\235\185\132\236\160\132_"..k],"\236\160\156\236\158\145\235\178\149\236\151\134\236\157\140:".."\235\185\132\236\160\132_"..k);
end
end
end
checkSpell(v["\235\168\185\234\184\176"],k);
checkSpell(v["\236\130\172\236\154\169"],k);
checkSpell(v["\235\141\152\236\167\128\234\184\176"],k);
if v["\235\176\148\235\161\156\235\168\185\234\184\176"]then
checkSpell(v["\235\176\148\235\161\156\235\168\185\234\184\176"][2],k);
end

for k,v in pairs(const("\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"))do
checkSpell(k.." \236\152\164\236\151\188\235\144\156 \236\154\148\235\166\172 \235\168\185\234\184\176",k);
end

for kk,vv in safe_pairs(v["\235\178\132\237\138\188\236\158\172\235\163\140"])do
assert(itemtable[kk]or const(kk),"\235\178\132\237\138\188 \236\158\172\235\163\140 \236\151\134\236\157\140:"..k..kk);
end

for k,v in safe_pairs(v["\234\184\176\235\179\184 \236\152\181\236\133\152"])do
assert(optiontable[v],v);
end
for k,v in safe_pairs(v["\235\176\148\235\165\180\234\184\176"])do
assert(optiontable[v],v);
end
if v.costume or v.skin then
if v["\236\162\133\235\165\152"]=="\235\176\169\237\140\168"then
testSpine(k,"player",v.skin,"shield",v.costume);
else
if CanEquipItemToSlot(k,"\236\152\164\235\165\184\236\134\144")then
testSpine(k,"player",v.skin,"weapon_R",v.costume);
end
if CanEquipItemToSlot(k,"\236\153\188\236\134\144")then
testSpine(k,"player",v.skin,"weapon_L",v.costume);
end
end
testSpine(k,"player",v.skin);
end
if v.obj then
local o=objecttable["\236\149\132\236\157\180\237\133\156"];
if string.starts(v.obj,"item_scroll")then
testSpine(o.name,o.spine,o.skin,"scroll",v.obj);
else
testSpine(o.name,o.spine,o.skin,"item",v.obj);
end
end
for k,v in safe_pairs(v.ani)do
testSpine(k,"player",nil,nil,nil,{v},{[{"event_attack","event_fire"}]=v});
end
for k,v in safe_pairs(v.ani_add)do
testSpine(k,"player",nil,nil,nil,{v},{[{"event_attack","event_fire"}]=v});
end

end

for k,v in pairs(MyPlayer)do
if type(k)=="string"and string.starts(k,"defAttack")then
for k,v in safe_pairs(v)do
testSpine(k,"player",nil,nil,nil,{v},{[{"event_attack","event_fire"}]=v});
end
end
end
for k,v in pairs(monstertable)do
local slotColors={};
slotColors["debuff_head"]=true;
slotColors["debuff_body"]=true;
slotColors["base"]=true;

assert((v["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\179\180\236\160\149"]or 0)<=(v["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\179\180\236\160\149"]or 0),k,"\235\141\176\235\175\184\236\167\128 \235\179\180\236\160\149");
_G["\235\160\136\235\178\168 \234\184\176\236\164\128 \235\167\136\235\178\149 \235\141\176\235\175\184\236\167\128"]=1;
assert((v["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128"]or 0)<=(v["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128"]or 0),k,"\236\181\156\236\134\140, \236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128");
_G["\235\160\136\235\178\168 \234\184\176\236\164\128 \235\167\136\235\178\149 \235\141\176\235\175\184\236\167\128"]=nil;

if v["\235\147\177\236\158\165\236\178\180"]then
assert(_G[v["\235\147\177\236\158\165\236\178\180"].cls]);
end

testSpine(k,v.spine,v.skin,nil,nil,{v["\234\179\181\234\178\169 \236\149\160\235\139\136"]or"ani_attack","ani_idle","ani_walk","ani_dmg",v["\235\147\177\236\158\165 \236\149\160\235\139\136"]},{[{"event_attack","event_fire"}]=v["\234\179\181\234\178\169 \236\149\160\235\139\136"]or"ani_attack"},slotColors);
for i=1,5,1 do
local id=v["\235\147\156\235\158\141 \236\149\132\236\157\180\237\133\156"..i];
if id then
if type(id)=="table"and id["\236\167\128\236\151\173\235\179\132"]then
id=id["\236\167\128\236\151\173\235\179\132"];
end
for _,v in safe_pairs(id)do
if type(v)=="table"then
for kk,_ in pairs(v)do
assert(itemtable[kk]or drop1table[kk],"\235\170\172\236\138\164\237\132\176 \235\147\156\235\158\141\236\149\132\236\157\180\237\133\156\236\151\134\236\157\140",id,v,kk);
end
else
assert(itemtable[v]or drop1table[v],"\235\170\172\236\138\164\237\132\176 \235\147\156\235\158\141\236\149\132\236\157\180\237\133\156\236\151\134\236\157\140",id,v,k);
end
end
end
end
assert(table.find(const("\235\141\176\235\175\184\236\167\128 \235\170\169\235\161\157"),v["\235\141\176\235\175\184\236\167\128 \236\134\141\236\132\177"]),v["\235\141\176\235\175\184\236\167\128 \236\134\141\236\132\177"],k);
for k,v in safe_pairs(v["\236\138\164\237\130\172"])do
assert(monsterskilltable[k],"\236\138\164\237\130\172\236\151\134\236\157\140",k);
end
end
for k,v in pairs(mission_rewardtable)do
local id=v["\236\149\132\236\157\180\237\133\156"];
if id then
assert(itemtable[id]or drop1table[id],id,k);
end
end
for k,v in pairs(missiontable)do
for ids,c in safe_pairs(v["\235\179\180\236\131\129"])do
for _,id in pairs(string.split(ids,","))do
assert(itemtable[id]or drop1table[id],id,k);
end
end
end


for k,v in pairs(bufftable)do
if v.particle then
testParticle(v.particle);
end
if v.spine then
testSpine(k,v.spine,nil,nil,nil,v.ani);
end
end

for k,v in pairs(spelltable)do
for k,cls in pairs({v["\235\176\156\235\143\153\236\178\180"],v["\235\176\156\236\130\172\236\178\180"],v["\237\143\173\235\176\156\236\178\180"]})do
if type(cls)=="table"then
if cls.particle then
testParticle(cls.particle);
end
if cls.spine then
testSpine(k,cls.spine,nil,nil,nil,cls.ani);
end
end
end
if v["\235\176\156\235\143\153\237\154\168\234\179\188"]then
assert(bufftable[v["\235\176\156\235\143\153\237\154\168\234\179\188"]],"\235\176\156\235\143\153\237\154\168\234\179\188",k);
end
end

for k,v in pairs(drop2table)do
assert(itemtable[k]or const("\235\182\132\235\165\152C",k),"drop2table:"..k);
end

for i=0,99 do
local t=ev("\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168 \236\158\172\235\163\140"..i);
if not t then
break;
end
for k,v in pairs(t)do
assert(itemtable[k],k);
end
end
for k,v in pairs(jobtable)do
for i=1,5,1 do
if v["\236\138\164\237\130\172"..i]then
assert(passivetable[v["\236\138\164\237\130\172"..i]],v["\236\138\164\237\130\172"..i]);
end
end
end
local function checkPreset(name,key)
for k,v in pairs(roompresettable)do
if v["\236\157\180\235\166\132"]==name then
return true;
end
end
assert(false,"preset:"..key);
end
local function checkGroup(group,key)
if string.starts(group,"\235\160\136\236\150\180_")then
group=string.sub(group,string.len("\235\160\136\236\150\180_")+1);
elseif string.starts(group,"\236\149\132\237\139\176\237\140\169\237\138\184_")then
group=string.sub(group,string.len("\236\149\132\237\139\176\237\140\169\237\138\184_")+1);
elseif string.starts(group,"\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149_")then
group=string.sub(group,string.len("\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149_")+1);
elseif string.starts(group,"\235\185\132\236\160\132 \236\160\156\236\158\145\235\178\149_")then
group=string.sub(group,string.len("\235\185\132\236\160\132 \236\160\156\236\158\145\235\178\149_")+1);
end
if not drop1table[group]then
if itemtable[group]then
group=itemtable[group]["\234\183\184\235\163\185"];
end

if drop2table[group]then
group=drop2table[group]["\234\183\184\235\163\185"];
end

if const(group)then
for k,v in pairs(const(group))do
assert(itemtable[v],"\236\149\132\236\157\180\237\133\156 \236\151\134\236\157\140",group,v);
group=itemtable[v]["\234\183\184\235\163\185"];
end
end
end
if not drop1table[group]then
assert(drop1table[group],key,group);
end

end

for k,v in pairs(dropwelltable)do
if v["\236\162\133\235\165\152"]then
if type(v["\236\162\133\235\165\152"])=="table"then
for k,v in pairs(v["\236\162\133\235\165\152"])do
for _,v in pairs(string.split(k))do
checkGroup(v,k);
end
end
else
for _,v in pairs(string.split(v["\236\162\133\235\165\152"]))do
checkGroup(v,k);
end
end
end
for i=1,9,1 do
local kk=v["\234\181\144\236\178\180"..i]or v["\234\184\176\237\131\128"..i];
if kk then
if type(kk)=="table"then
for guid,vv in pairs(kk)do
for _,g in pairs(string.split(guid))do
checkGroup(g,k.."dropwelltable\234\181\144\236\178\180"..i);
end
end
else
checkGroup(kk,k.."dropwelltable\234\181\144\236\178\180"..i);
end
end
end
end
for k,v in pairs(evilstatuetable)do
for i=1,3,1 do
local k=v["\235\179\180\236\131\129"..i];
if k then
if type(k)=="table"then
for guid,vv in pairs(k)do
checkGroup(guid);
end
else
checkGroup(k);
end
end
for k,v in pairs(v["\235\170\172\236\138\164\237\132\176"])do
assert(monstertable[k],k);
end
end
end
local function checkObject(t,key)
if _G.type(t)~="table"then
t={[t]=1};
end

if t[1]then
for i,v in pairs(t)do
checkObject(v,key);
end
else
for k,v in pairs(t)do
if string.starts(k,"\236\167\128\236\151\173")then
elseif maptable[k]or mapbptable[k]then
checkObject(v,key);
else
assert(itemtable[k]or objecttable[k]or monstertable[k]or drop1table[k],k,key);
end
end
end
end
for k,v in pairs(roomtable)do
if v["\235\167\129\237\129\172\235\176\169"]then
else
local t=v["\236\152\164\235\184\140\236\160\157\237\138\184 \236\131\157\236\132\177"];
if t then
checkObject(t,k);
end
for _,v in safe_pairs(v["\234\179\160\236\160\149 \236\131\157\236\132\177"])do
assert(type(v)=="number"or maptable[v]or mapbptable[v],k..v);
end
assert(v["\237\148\132\235\166\172\236\133\139"],k.."\237\148\132\235\166\172\236\133\139 \236\151\134\236\157\140");
for kk,vv in pairs(v["\237\148\132\235\166\172\236\133\139"])do
checkPreset(kk,k);
end
end
end

for guid,v in pairs(objecttable)do
if v.class then
assert(_G[v.class],"\237\129\180\235\158\152\236\138\164 \236\151\134\236\157\140:"..guid..tostring(v.class));
end
for k,v in safe_pairs(v["\235\169\148\235\137\180"])do
assert(itemtable[v]and itemtable[v].img,v);
end

if v["\236\177\132\236\167\145"]then
assert(spelltable[v["\236\177\132\236\167\145"]],guid);
end
for k,v in safe_pairs(v["\236\132\164\236\185\152\236\157\180\235\166\132"])do
assert(objecttable[v],guid);
end

for k,v in safe_ipairs(v.particle)do
testParticle(v.particle);
end
for k,v in safe_ipairs(v.cparticle)do
testParticle(v.cparticle);
end
for k,v in safe_ipairs(v.aparticle)do
testParticle(v.aparticle);
end

for k,cls in pairs({v["\237\143\173\235\176\156\236\178\180"]})do
if type(cls)=="table"then
if cls.particle then
testParticle(cls.particle);
end
if cls.spine then
trace("\237\143\173\235\176\156\236\178\180 \234\178\128\236\130\172",cls);
testSpine(k,cls.spine,nil,nil,nil,cls.ani);
end
end
end

local anims={};
local slotColors={};
table.insert(anims,v["\234\184\176\235\179\184 \236\149\160\235\139\136"]);
table.insert(anims,v["\236\149\161\236\133\152 \236\149\160\235\139\136"]);
table.insert(anims,v["\236\182\169\235\143\140 \236\149\160\235\139\136"]);
slotColors[Object.slotParticleBurn]=v["\237\131\128\235\138\148 \236\139\156\234\176\132"]~=nil;
for k,v in safe_pairs(v["particle"])do
slotColors[v.slot]=true;
end
testSpine(v.name,v.spine,table.copy(v.skin,v["\236\167\128\236\151\173\235\179\132skin"]),nil,v.attachment,anims,nil,slotColors);
local playerAnim=v["\237\148\140\235\160\136\236\157\180\236\150\180 \236\149\161\236\133\152 \236\149\160\235\139\136"];
if type(playerAnim)=="table"then
for i,menu in safe_ipairs(v["\235\169\148\235\137\180"])do
assert(playerAnim[menu or"\234\184\176\237\131\128"]or playerAnim["\234\184\176\237\131\128"],v.name,menu);
end
end
for k,anim in safe_pairs(playerAnim)do
testSpine(v.name,"player",nil,nil,nil,nil,{[{"event_action"}]=anim});
end

local anims={};
table.insert(anims,v["\236\153\132\235\163\140 \236\149\160\235\139\136"]);
table.insert(anims,v["\236\153\132\235\163\140 \234\184\176\235\179\184"]);
table.insert(anims,v["\236\153\132\235\163\140 \234\184\176\235\179\184"]);
table.insert(anims,v["\235\182\136\237\131\128\235\138\148 \236\149\160\235\139\136"]);
table.insert(anims,v["\235\166\172\236\160\160 \236\149\160\235\139\136"]);
if v["\236\153\132\235\163\140 \236\149\160\235\139\136"]and v["\236\149\161\236\133\152 \236\149\160\235\139\136"]then
assert(v["\236\153\132\235\163\140 \236\149\160\235\139\136"]~=v["\236\149\161\236\133\152 \236\149\160\235\139\136"],guid);
end
_G.TB,_G.gen=0,0;
for k,v in safe_pairs(v["\235\166\172\236\160\160 \235\179\128\236\139\160"])do
assert(objecttable[k],k);
end
_G.TB,_G.gen=nil,nil;

testSpine(v.name,v.spine,table.copy(v.skin,v["\236\167\128\236\151\173\235\179\132skin"]),nil,v.attachment,anims);
for k,v in safe_pairs(v["\236\134\140\237\153\152"])do
assert(k=="\235\170\172\236\138\164\237\132\176"or k=="\236\164\145\235\166\189 \235\170\172\236\138\164\237\132\176"or k=="\235\143\133\234\181\172\235\166\132"or k=="\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128"or monstertable[k],guid,k);
end
for k,v in safe_pairs(v["\236\131\157\236\130\176"])do
if k=="\234\179\160\234\184\137\235\147\156\235\158\141"or k=="\236\157\188\235\176\152\235\147\156\235\158\141"then
elseif k=="\235\147\156\235\158\141"then
if not v[1]then v={v};end
for i,v in ipairs(v)do
local valid=false;
for kk,vv in pairs(v)do
for kkk,vvv in pairs(drop1table)do
if vvv[kk]then
valid=true;
break;
end
end
end
assert(valid,guid,k);
end
else
assert(drop1table[k]or itemtable[k],guid,k);
end
end


assert(tostring(v["\236\158\172\235\163\140"]));
for k,v in safe_pairs(v["\236\158\172\235\163\140"])do
if const(k)then
else
assert(itemtable[k],guid,k);
end
end
end
for guid,v in pairs(spawntable)do
for i=1,9,1 do
local t=v["\236\131\157\236\132\177"..i];
for _,k in safe_pairs(t)do
assert(monstertable[k],"\235\170\172\236\138\164\237\132\176 \236\151\134\236\157\140",guid,k);
end
end
end
for i,guid in pairs(const("\236\139\157\236\158\172\235\163\140"))do
assert(itemtable[guid]or const(guid),"item:"..guid);
end





for guid,v in pairs(cooktable)do
assert(itemtable[guid],guid);
for i,v in safe_pairs(v["\237\130\164\236\158\172\235\163\140"])do
for k,c in pairs(v)do
assert(itemtable[k]or const(k),guid,k);
end
end
for i,v in safe_pairs(v["\236\158\172\235\163\140"])do
for k,v in safe_pairs(v)do
assert(itemtable[k]or const(k),"cooktable \236\158\172\235\163\140 \236\151\134\236\157\140",guid,k);
end
end
for k,v in safe_pairs(v["\236\160\156\236\158\145 \236\139\156\236\132\164"])do
assert(objecttable[v],guid,v);
end
for k,v in safe_pairs(v["\234\184\176\237\131\128 \237\154\141\235\147\157"])do
assert(itemtable[k],guid,k);
end
end
for k,v in pairs(optiontable)do
for i=1,9 do
local t=v["\237\154\168\234\179\188"..i];
if t then
assert(lang[t],t);
else
break;
end
end
end
for k,v in pairs(totemtable)do
for i=1,9 do
local t=v["\237\154\168\234\179\188"..i];
if t then
assert(lang[t],t);
else
break;
end
end
end

for guid,v in pairs(require("data.recipetable"))do
if table.find(const("\236\152\164\235\184\140\236\160\157\237\138\184\236\132\164\236\185\152\236\156\160\237\152\149"),v["\236\156\160\237\152\149"])or table.find(v["\236\156\160\237\152\149"],"\236\136\152\235\166\172")or table.find(v["\236\156\160\237\152\149"],"\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156")then
assert(objecttable[v["\236\158\165\235\185\132"]]or itemtable[v["\236\158\165\235\185\132"]],guid,v["\236\158\165\235\185\132"],"\236\160\149\236\157\152 \236\149\136\235\144\168");
else
local t=v["\236\158\165\235\185\132"];
if t then
if _G.type(t)~="table"then
t={[t]=1};
end
for k,v in pairs(t)do
assert(itemtable[k],"itemtable\236\151\144 \236\151\134\236\157\140",guid,k);
end
end
end

if recipetable[guid]then
hasBuilding,list=GetRequireBuildingList(guid,nil,nil,true);
for k,v in pairs(list)do
assert(objecttable[v[1]]or itemtable[v[1]],v,guid,v[1]);
end
end





if v["\237\131\173"]then
assert(lang[v["\237\131\173"]],"lang\236\151\134\236\157\140",v["\237\131\173"]);
end
if v["\237\131\1732"]then
local tab=v["\237\131\1732"];
if not tab and itemtable[v["\236\158\165\235\185\132"]]then
tab=itemtable[v["\236\158\165\235\185\132"]]["\236\162\133\235\165\152"];
end
assert(lang[tab],"lang\236\151\134\236\157\140",tab,v.guid);
assert(table.find(const("\237\131\1732\236\136\156\236\132\156"),tab),"\237\131\1732\236\136\156\236\132\156 \236\151\134\236\157\140",tab,v.guid);
end

for k,v in safe_pairs(v["\237\154\141\235\147\157 \236\139\156\236\132\164 \234\183\184\235\163\185"])do
assert(objecttable[v]or itemtable[v],"\237\154\141\235\147\157 \236\139\156\236\132\164 \236\151\134\236\157\140",guid,v);
end
for k,v in safe_pairs(v["\234\184\176\235\176\152 \236\139\156\236\132\164"])do
assert(objecttable[v]or itemtable[v],"\234\184\176\235\176\152 \236\139\156\236\132\164 \236\151\134\236\157\140",guid,v);
end
for k,v in safe_pairs(v["\236\158\172\235\163\140"])do
local keys=table.choice(string.split(k,","));
for i,k in safe_pairs(keys)do
if k=="\236\149\132\235\172\180 \235\130\152\235\172\180, \235\170\169\236\158\172"then
elseif const(k)then
for k,v in pairs(const(k))do
assert(itemtable[v],guid,v);
end
elseif k then
assert(itemtable[k],guid,k,v);
end
end
end
end

for k,v in pairs(drop2table)do
assert(const("\235\182\132\235\165\152A",k)or itemtable[k],k);
end

for k,v in pairs(sks)do
v:release();
end

if not success then
_G.errormsg=errormsg;
root:GotoAndStop("error");
end




end


root:ReloadSymbols("");
owner:onSymbolLoading(1,1);
return false;
end
timer.add(s,s,0.1);


end
