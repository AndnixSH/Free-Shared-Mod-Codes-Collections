function Grid()
local inst={};
local data={};

function inst:unplace(o,xGrid,yGrid)

local t=data[xGrid]and data[xGrid][yGrid];
if t and t[o]then
t[o]=nil;
return true;
end
end

function inst:place(o,xGrid,yGrid,z)
data[xGrid]=data[xGrid]or{};
data[xGrid][yGrid]=data[xGrid][yGrid]or{};
data[xGrid][yGrid][o]=z or 0;

end


function inst:QueryR(x,y,r,func)

local _l=(x-r);
local _t=(y-r);
local _r=(x+r);
local _b=(y+r);
local r2=r*r;
local list={};

local maxV=nil;
local maxZ=nil;
for i=_l,_r,1 do
for j=_t,_b,1 do
if data[i]and data[i][j]then
local t=data[i][j];
for v,z in pairs(t)do
if func(v)then
if not maxZ or z>=maxZ then
maxV=v;
maxZ=z;
end
table.insert(list,v);
end
end
end
end
end

if maxV then

return maxV,list;


end

end

return inst;
end
