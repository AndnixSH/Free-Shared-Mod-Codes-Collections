function Intro(owner)
trace("Title");
PlayMapBgm("\235\161\156\235\185\132");
local timer=Timer();
local scene=1;
local sceneT=0;
local msgIdx=1;
owner:AddSymbol("voice.wav","snd");
local tb=require"data.introtable"
local toGo="travel";

local scale=1;
if APP_W/APP_H>1280/720 then
scale=scale*APP_W/APP_H*720/1280;
end

owner.w:SetScale(scale,scale);

local function addLayer()
local obj,sk=SpineObject(owner.w,"_","ani_opening","ani_scene1","default");
function obj:onAnimationEvent(track,name,type,evt,loop)
if type=="COMPLETE"then
if scene<7 then
scene=scene+1;
sceneT=0;
sk:setAnimation(0,"ani_scene"..scene);
else
root:GotoAndStop(toGo);
end
end
end
return obj;
end

addLayer();

local function showMsg(v)
local msg=v["msg_"..curLang]or v.msg_ko;
local list=string.split(msg,"\n");
local fontSize=v["\237\143\176\237\138\184\237\129\172\234\184\176"];
local gap=math.abs(fontSize)+20;
local y=-gap*#list/2;
local fi=1;
local fs={};
local function onEnd()
fi=fi+1;
if fs[fi]then
local function f()
timer.add("msg",fs[fi]);
end
timer.add("msg",f,v["\236\164\132\235\176\148\234\191\136\236\139\156\234\176\132"]);
else
local function f()
owner.msg:Clear();
end
timer.add("msg",f,v["\236\182\156\235\160\165\236\139\156\234\176\132"]);
end
end

owner.msg:Clear();
for i,s in ipairs(list)do
local line=owner.msg:AddLabel(APP_W,gap,"","",fontSize,0,"_");
line:SetThickness(1);
line:SetFillColor(0xFFFFFFFF);
line:SetColor(0);
line:SetY(y);

y=y+gap;
fs[i]=LabelAniMsg(line,s,nil,GetAppSound(owner,"voice"),onEnd);
end

timer.add("msg",fs[fi]);








end

local function updateScene(dt)
sceneT=sceneT+dt;
local v=tb[msgIdx];
if v and v.scene==scene and v["\236\139\156\236\158\145\236\139\156\234\176\132"]and sceneT>v["\236\139\156\236\158\145\236\139\156\234\176\132"]then
msgIdx=msgIdx+1;
showMsg(v);
end
end

function owner:onEnterFrame(dt)
spine.advanceTime(dt);
timer.update(dt);
updateScene(dt);
end

owner.start=function()
owner:SetMouseCapture(true);
owner.onMouseUp=function(self,x,y,id,capture)

timer.remove(s);
owner.onMouseDown=nil;
root:GotoAndStop(toGo);
return true;
end
end
owner:start();
end
