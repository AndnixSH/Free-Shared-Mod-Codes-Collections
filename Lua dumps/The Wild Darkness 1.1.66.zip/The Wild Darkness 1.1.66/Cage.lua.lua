Cage=Object:new({

height=150,
})

function Cage:init(guid,sdata,...)
sdata.npcs=sdata.npcs or{};
self.npcs={};
Object.init(self,guid,sdata,...);
for k,v in pairs(self.sdata.npcs)do
self:addChild(k);
end
end

function Cage:die(...)
Object.die(self,...);
for k,v in pairs(self.npcs)do
v.died=true;
ReleaseGoat(k,v.sdata,true);
end
end

function Cage:addChild(guid)
self.sdata.npcs=self.sdata.npcs or{};
local sdata=self.sdata.npcs[guid];
local id=sdata.id;
local tb=monstertable[id];
local z=self.tb["\235\134\146\236\157\180"]or 0;
sdata.x,sdata.y,sdata.a=self.sdata.x,self.sdata.y,self.sdata.a;
if _G[tb.class]then
local o=_G[tb.class]:new();
o:init(guid,sdata);
o:unplace();
o.getZOrder=function()
return self:getZOrder()-1;
end
o.pos.z=z;
self.npcs[guid]=o;
end
end

function Cage:update(dt)
Object.update(self,dt);
for k,v in pairs(self.npcs)do
if v.died then
v:destroy();
self.npcs[k]=nil;
else
v:update(dt);
end
end
end

function Cage:menuEnabled(menu)
if menu=="\235\169\148\235\137\180_\236\130\176\236\150\145\235\132\163\234\184\176"then
if not IsInField()or not table.empty(self.sdata.npcs)or table.empty(_S["\236\167\144\234\190\188"])then
return false;
end
elseif menu=="\235\169\148\235\137\180_\236\130\176\236\150\145\234\186\188\235\130\180\234\184\176"then
if not IsInField()or table.empty(self.sdata.npcs)or not table.empty(_S["\236\167\144\234\190\188"])then
return false;
end
elseif menu=="\235\169\148\235\137\180_\236\136\152\237\146\128\235\168\185\236\157\180\234\184\176"then
if table.empty(self.sdata.npcs)then
return false;
end

for k,v in pairs(self.sdata.npcs)do
if v["\236\131\157\236\130\176\236\191\168"]then
return false;
end
end
end
return Object.menuEnabled(self,menu);
end

function Cage:onResetTurn(AP)
Object.onResetTurn(self,AP);
for k,v in pairs(self.npcs)do
if v.sdata["\236\131\157\236\130\176\236\191\168"]then
v.sdata["\236\131\157\236\130\176\236\191\168"]=v.sdata["\236\131\157\236\130\176\236\191\168"]-AP;
if v.sdata["\236\131\157\236\130\176\236\191\168"]<=0 then
v.sdata["\236\131\157\236\130\176\236\191\168"]=nil;
if v.data["\235\175\184\235\129\188\236\191\168skin"]then
v.skeleton:setSkin(v.data.skin);
end
end
end
end

for k,v in pairs(self.npcs)do
v:updateBuff(AP);
v:cleanBuff();
v:updateIcon();

end
end

function Cage:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\136\152\237\146\128\235\168\185\236\157\180\234\184\176"then
function _ok2(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local function _ok(c)

onOk(menu,guid,c);
end
SelectItemCountPopup(_ok,onCancel,world,guid);
end
SelectItemPopup(world,_ok2,onCancel,{"\234\184\176\237\131\128"},"\236\149\132\236\157\180\237\133\156",{object=self,id="\236\136\152\237\146\128",detail=_L("\236\136\152\237\146\128\236\157\132 \235\168\185\236\157\180\236\139\156\234\178\160\236\138\181\235\139\136\234\185\140?")});
else
Object.menuTouch(self,from,menu,onOk,onCancel);
end
end

function Cage:complete(menu,...)
if menu=="\235\169\148\235\137\180_\236\130\176\236\150\145\235\132\163\234\184\176"then
local guid=table.choicekey(_S["\236\167\144\234\190\188"]);
self.sdata.npcs[guid]=_S["\236\167\144\234\190\188"][guid];
self.sdata.npcs[guid].id="\236\154\176\235\166\172 \236\130\176\236\150\145";
DelStorageItem("\236\167\144\234\190\1881",guid);
ReleaseGoat(guid,_S["\236\167\144\234\190\188"][guid]);
self:addChild(guid);
elseif menu=="\235\169\148\235\137\180_\236\130\176\236\150\145\234\186\188\235\130\180\234\184\176"then
local guid=table.choicekey(self.sdata.npcs);
local sdata=self.sdata.npcs[guid];
if sdata then
sdata.x,sdata.y,sdata.a=_S.x,_S.y,_S.a;
PickGoat("\236\130\176\236\150\145 \234\176\128\235\176\169",sdata);
self.sdata.npcs[guid]=nil;
end
self.npcs[guid].died=true;
elseif menu=="\235\169\148\235\137\180_\236\136\152\237\146\128\235\168\185\236\157\180\234\184\176"then
local itemGuid=select(1,...);
local c=select(2,...)or 1;
local guid=table.choicekey(self.sdata.npcs);
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local sdata=self.sdata.npcs[guid];
local npc=self.npcs[guid];
local t=npc.data["\235\175\184\235\129\188"]["\236\136\152\237\146\128"];
local i=0;
while i<c do
i=i+1;
sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]=(sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]or 0)+countkcc(t.eat);
npc:heal(npc:ev("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*(t.healP or 0));
if sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]>=t.gauge then
sdata["\236\131\157\236\130\176\234\178\140\236\157\180\236\167\128"]=nil;
sdata["\236\131\157\236\130\176\236\191\168"]=(sdata["\236\131\157\236\130\176\236\191\168"]or 0)+t.cool;
if npc.data["\235\175\184\235\129\188\236\191\168skin"]then
npc.skeleton:setSkin(npc.data["\235\175\184\235\129\188\236\191\168skin"]);
end
local o,data=MakeAndPlaceItem(t.output,_S.x,_S.y);
o:fly(npc.pos);
break;
end
end
assert(ConsumeItem(itemGuid,c,true));
if i<c then
local o,d=MakeAndPlaceItem(data.id,_S.x,_S.y);
d.c=c-i;
o:fly(self.pos);
end
else
Object.complete(self,menu,...);
end
end
