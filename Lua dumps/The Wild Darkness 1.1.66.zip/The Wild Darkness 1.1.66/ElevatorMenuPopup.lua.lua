
function ElevatorMenuPopup(o,onOk,onCancel)
local mc=world.ground:CreateEmptyMovieClip("objMenu");
mc:SetPos(world.ground:MapToScreen(o.pos.x,o.pos.y));
function mc:closeIfOpened(cb)
mc:close(cb);
end
function mc:close(cb)
local _func=world.player.onTouchCancel;

world.player.onTouchCancel=function(...)
if cb then
cb();
end
world.player.onTouchCancel=_func;
world.player.onTouchCancel(...);
end
mc:Remove();
onCancel();
end
local list={};
do
local lv=_S["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"][o.sdata.id]or 0;
local range=o.tb["\237\140\140\235\157\188\235\175\184\237\132\176"][lv+1];
local maxDepth=GetMaxMapDepth();
if maxDepth then
for i=range[1],math.min(maxDepth,range[2])do
table.insert(list,i);
end
end
end











local W=100;
local w=400;
local x,y=0,-200;
for i,f in ipairs(list)do
local btn=mc:AddSymbol("\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176\235\169\148\235\137\1801\236\185\184","");
btn:SetPos(-w/2+x,y);
x=x+W;
if x>=w then
x=0;
y=y+W;
end
btn.txt:SetText(f);
SetButton(btn).onClick=function()
mc:Remove();
onOk(f);
end
end
end
