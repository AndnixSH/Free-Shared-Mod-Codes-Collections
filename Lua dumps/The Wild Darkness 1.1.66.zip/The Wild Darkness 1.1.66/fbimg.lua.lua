redirectPath={};

function SetFacebookImg(owner)

owner.request=function(this,id,me,detail,forceurl)
local img=owner:AddSymbol("ui/defaultUser.png","_");
local scale=0.5;
if detail=="normal"then
scale=1;
end
img:SetScale(scale,scale);
local x,y,cx,cy=img:GetBound();
img:SetPos(-cx/2*scale,-cy/2*scale);

local postfix=detail or"";
local imgurl="https://graph.facebook.com/"..tostring(id).."/picture";
local filename=nil;
local filepath=nil;
if detail then
imgurl=imgurl.."?type="..detail;
end
if forceurl then
imgurl=forceurl;
end
local d=downloaderRedirect(imgurl);
local isFile=string.find(string.gsub(imgurl,".*/",""),"[.]",-4);

if isFile then
filename=string.gsub(forceurl,".*/","");
filepath=sys.getTemporaryPath().."/"..filename;
d.setUrl(forceurl);
d.setFileName(filepath);
d.setStep("download");
end
d.onStart=function(self,step,url)
trace("onStart"..step..url);
if step=="redirect"then
if redirectPath[imgurl]then
filename=string.gsub(redirectPath[imgurl],".*/","");
filepath=sys.getTemporaryPath().."/"..filename;
d.setUrl(redirectPath[imgurl]);
d.setFileName(filepath);
return false;
end
return true;
elseif step=="download"then
owner.ksymbol=root:AddSymbolToLibrary(filename,filepath);
if owner.ksymbol>0 then
img:Remove();
img=owner:AddSymbolWithKey(owner.ksymbol,"_");
local x,y,cx,cy=img:GetBound();
img:SetScale(50/cx,50/cy);
img:SetPos(-25,-25);

return false;
end
return true;
end
end
d.onComplete=function(self,step,url)
if step=="redirect"then
redirectPath[imgurl]=url;
trace("redirect:"..url);
filename=string.gsub(url,".*/","");
filepath=sys.getTemporaryPath().."/"..filename;
d.setFileName(filepath);
elseif step=="download"then
owner.ksymbol=root:AddSymbolToLibrary(filename,filepath);

if owner.ksymbol>0 then
img:Remove();
img=owner:AddSymbolWithKey(owner.ksymbol,"_");
local x,y,cx,cy=img:GetBound();
img:SetScale(50/cx,50/cy);
img:SetPos(-25,-25);

end
end
end
owner.onUnload=function(self)
if owner.ksymbol and owner.ksymbol>0 then
root:DelSymbolFromLibrary(owner.ksymbol);
end
end
return d;
end

end