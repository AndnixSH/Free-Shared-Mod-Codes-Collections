HealStream=Object:new({
})


function HealStream:update(dt)
Object.update(self,dt);
end

function HealStream:complete(menu,...)
if menu=="\235\169\148\235\137\180_\235\167\136\236\139\156\234\184\176"then
for k,v in safe_pairs(self.sdata.param)do
if k=="\236\131\157\235\170\133\235\160\165"then
local h=v*bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
world.player:heal(h);
elseif k=="\236\151\144\235\132\136\236\167\128"then
local max=bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128");
local h=v*max;
world.player:healEnergy(h);
elseif k=="\236\167\136\235\179\145"then
for k,v in pairs(const("\236\167\136\235\179\145 \235\170\169\235\161\157"))do
world.player:clearDisease(k);
end
elseif k=="\234\176\136\236\166\157"then
_S:add("\234\176\136\236\166\157",v,0,bf("\236\181\156\235\140\128 \235\170\169\235\167\136\235\166\132"));
else
if table.find(const("\235\148\148\235\178\132\237\148\132 \235\170\169\235\161\157"),k)then
DelBuff(k);
end
end
end
elseif menu=="\235\169\148\235\137\180_\235\172\188\235\156\168\234\184\176"then
local guid=select(1,...);
ConsumeItem(guid);

local o=MakeAndPlaceItem(math.randlist(self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]));
o:fly(self.pos);

end
Object.complete(self);
end

function HealStream:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\235\167\136\236\139\156\234\184\176"then
onOk(menu);
elseif menu=="\235\169\148\235\137\180_\235\172\188\235\156\168\234\184\176"then
local function _ok2(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_ok2,onCancel,{"\235\179\145"},"\235\172\188\235\156\168\234\184\176",{object=self});
end
end
