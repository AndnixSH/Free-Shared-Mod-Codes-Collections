local buff=nil;
local _item=nil;
local _data=nil;



local function _eval(k)
if false then
elseif k=="\234\184\176\236\152\168"then return GetTemperature(true);
elseif k=="\236\182\148\236\155\128\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\236\182\148\236\155\128"]
elseif k=="\236\160\128\236\178\180\236\152\168\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\236\160\128\236\178\180\236\152\168"]
elseif k=="\235\141\148\236\155\128\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\235\141\148\236\155\128"]
elseif k=="\234\179\160\236\151\180\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\234\179\160\236\151\180"]
elseif k=="\235\176\176\234\179\160\237\148\148\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\235\176\176\234\179\160\237\148\148"]
elseif k=="\236\152\129\236\150\145\236\139\164\236\161\176\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\236\152\129\236\150\145\236\139\164\236\161\176"]
elseif k=="\237\148\188\234\179\164\237\149\168\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\237\148\188\234\179\164\237\149\168"]
elseif k=="\237\131\136\236\167\132\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\237\131\136\236\167\132"]
elseif k=="\235\170\169\235\167\136\235\166\132\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\235\170\169\235\167\136\235\166\132"]
elseif k=="\237\131\136\236\136\152\235\148\148\235\178\132\237\148\132"then return _S["\235\148\148\235\178\132\237\148\132"]["\237\131\136\236\136\152"]
elseif k=="\235\176\169\236\150\180\234\181\172 \235\182\128\236\161\177\237\158\152"then return GetArmorReqStr(true);
elseif k=="\235\167\181 \235\160\136\235\178\168"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\235\167\181 \235\160\136\235\178\168"];
elseif k=="\236\131\157\236\161\180 \236\157\188\236\136\152"then return GetDay();
elseif k=="\236\184\181\236\136\152"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\184\181"]or 1;
elseif k=="\236\167\128\236\151\173"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173"];
elseif k=="\236\167\128\236\151\173 \235\160\136\235\178\168"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173 \235\178\136\237\152\184"];
elseif k=="\237\149\132\235\147\156\236\136\152"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S["\237\149\132\235\147\156 \234\176\156\236\136\152"][_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173"]];
elseif k=="\236\181\156\236\160\128\234\184\176\236\152\168"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\234\184\176\236\152\168"][1];
elseif k=="\236\181\156\234\179\160\234\184\176\236\152\168"and _S["\237\152\132\236\158\172\235\167\181"]~=0 then return _S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\234\184\176\236\152\168"][2];
elseif k=="\235\176\169\236\150\180\235\160\165"then return(GetEquipItemProp(GetItemArmor,nil,{"\235\176\169\237\140\168"}));
elseif k=="\235\176\169\237\140\168 \235\176\169\236\150\180\235\160\165"then return(GetEquipItemProp(GetItemArmor,{"\235\176\169\237\140\168"}));
elseif k=="\237\153\156\235\143\153\236\132\177"then return(GetEquipItemProp(GetItemActivity));
elseif k=="\236\160\129\236\164\145"then return evaltable[k]+(GetEquipItemProp(GetItemHit));
elseif k=="\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165"then return evaltable[k]*(1+(GetEquipItemProp(GetItemMaxLife)));
elseif k=="\235\166\172\236\160\160\234\179\177"and _S["\237\152\132\236\158\172\236\167\128\236\151\173"]~=0 then
return maptable[_S["\237\152\132\236\158\172\236\167\128\236\151\173"]]["\235\166\172\236\160\160\234\179\177"]or 1;
elseif string.starts(k,"\237\154\141\235\147\157_")then
local k=string.sub(k,string.len("\237\154\141\235\147\157_")+1)
return _S["\237\154\141\235\147\157\237\154\159\236\136\152"][k]or 0;
elseif string.starts(k,"\236\160\156\236\158\145_")then
local k=string.sub(k,string.len("\236\160\156\236\158\145_")+1)
return _S["\236\160\156\236\158\145"][k]or 0;
elseif string.starts(k,"\236\178\152\236\185\152\235\179\180\236\138\164_")then
local k=string.sub(k,string.len("\236\178\152\236\185\152\235\179\180\236\138\164_")+1)
return _S["\236\178\152\236\185\152\235\179\180\236\138\164"][k]or 0;
elseif _data and _data[k]then return _data[k];
elseif _item and _item[k]then return _item[k];
end
return nil;
end


local compileEvalMT;
local function json_to_lua(s)
s=json_print(json.decode(s));
return s;
end
local function compileEval(t,prefix)
local inst={
checker={};
};

for k,s in pairs(t)do
local _prefix=prefix;
if prefix and string.sub(k,1,string.len(prefix))==prefix then
k=string.sub(k,string.len(prefix)+1);
_prefix=nil;
end
if type(s)=="table"then
inst.checker[k]=compileEval(s,_prefix);
elseif type(s)=="number"then
inst.checker[k]=MemCheckerValue(s);
else
s=tostring(s);
if not _prefix then

s=string.gsub(s,"([^()%%]+)~([^()%%]+)","math.randrange(%1,%2)");
s=string.gsub(s,"%%","*0.01");



local s=string.gsub(s,"(%{.+%})",json_to_lua);
local tokens={};
for v in string.gmatch(s,"[^0-9()*/%+%-%^=<>%.a-z;{},%[%]]+")do

v=string.trim(v);
local len=string.len(v);
if len>0 then
local pos=#tokens+1;
for i,tok in pairs(tokens)do
if tok==v then
pos=nil;
break;
else
if string.len(tok)<len then
pos=i;
break;
end
end
end
if pos then

table.insert(tokens,pos,v);
end
end
end


table.sort(tokens,function(a,b)return(string.len(a)>string.len(b))end);
for i,v in ipairs(tokens)do
s=string.gsub(s,v,"{"..i.."}");
end

for i,v in ipairs(tokens)do


if string.starts(v,"$")then
s=string.gsub(s,"{"..i.."}","'"..string.sub(v,2).."'");
else
s=string.gsub(s,"{"..i.."}","(bf('"..v.."'))");
end

end

if not string.find(s,"return")then
s="return ("..s..")";
end

local f,e=load(s);
assert(f,e,k);
inst.checker[k]=f;
else
inst.checker[k]=MemCheckerValue(s);
end
end
end
setmetatable(inst,compileEvalMT);
return inst;
end

compileEvalMT={
__index=function(t,k)
local checker=rawget(t,"checker");
local f=checker[k];

if f then
if type(f)=="function"then

return f();
else
local get=rawget(checker[k],"get");
if get then
return get(checker[k]);
else
return checker[k];
end
end
end
end,
__newindex=function(t,k,v)
local checker=rawget(t,"checker");
if checker[k]==v then
return;
end
if checker[k]then
if v==nil then
checker[k]=nil;
else
assert(false);
end
else
rawset(t,k,v);
end
end,
__ipairs=function(t)
local checker=rawget(t,"checker");
local function iter(tbl,k)
local v=nil;
k=(k or 0)+1;

local f=checker[k];
if f then
if type(f)=="function"then
v=f();
else
local get=rawget(checker[k],"get");
if get then
v=get(checker[k]);
else
v=checker[k];
end
end
end
if v~=nil then return k,v end
end
return iter,nil,nil;
end,
__pairs=function(t)
local checker=rawget(t,"checker");
local function iter(tbl,k)
local v=nil;

k=next(checker,k)
if k~=nil then

local f=checker[k];
if f then
if type(f)=="function"then
v=f();
else
local get=rawget(checker[k],"get");
if get then
v=get(checker[k]);
else
v=checker[k];
end
end
end
end
if v~=nil then return k,v end
end
return iter,nil,nil;
end,
__len=function(t)
local checker=rawget(t,"checker");
return#checker;
end
};



local UseCheckerMT;

local function UseChecker(data)
local inst={
checker={},
};

for k,v in pairs(data)do
if type(v)=="table"then
inst.checker[k]=UseChecker(v);
else
inst.checker[k]=MemCheckerValue(v);
end
end
setmetatable(inst,UseCheckerMT);
return inst;
end

UseCheckerMT={


add=function(t,k,value,min,max,tick,AP,ckey)
local checker=rawget(t,"checker");

assert(checker[k],k);
local cur=checker[k]:get();
local prev=cur;
local dirty=false;
if tick and AP then
assert(tick>0);
ckey=ckey or k.."T";
checker[ckey]=checker[ckey]or MemCheckerValue(0);
local curT=checker[ckey]:get();
curT=curT+AP;
while curT>=tick do
curT=curT-tick;
cur=cur+value;

end
if min and cur<min then cur=min;end
if max and cur>max then cur=max;end
dirty=checker[ckey]:set(curT)or dirty;
dirty=checker[k]:set(cur)or dirty;

else

cur=cur+value;
if min and cur<min then cur=min;end
if max and cur>max then cur=max;end
dirty=checker[k]:set(cur)or dirty;
end
if dirty then
setDirty();
end
return cur-prev;
end,
setObserver=function(t,f)
rawset(t,"fdirty",f);
end,
__index=function(t,k)











local v=rawget(getmetatable(t),k);
if v~=nil then return v;end;
local checker=rawget(t,"checker");
local checkerk=checker[k];
if checkerk then
local get=rawget(checkerk,"get");
if get then
return get(checkerk);
else
return checkerk;
end
end
end,
__newindex=function(t,k,v)


local checker=rawget(t,"checker");
local checkerk=checker[k];
if checkerk==v then
return;
end

if v==nil then
if checkerk then
checker[k]=nil;
setDirty();
end
else
if type(v)=="table"then
checker[k]=UseChecker(v);
setDirty();
else
if checkerk and rawget(checkerk,"set")then
local prev=checkerk:get();
if checkerk:set(v)then
setDirty();
end
else
checker[k]=MemCheckerValue(v);
setDirty();
end
end
end
end,
__ipairs=function(t)
local checker=rawget(t,"checker");
local function iter(tbl,k)
local v=nil;

k=(k or 0)+1;
local checkerk=checker[k];
if k~=nil and checkerk then
local get=rawget(checkerk,"get");
if get then
v=get(checkerk);
else
v=checkerk;
end
end
if v~=nil then return k,v end
end
return iter
end,
__pairs=function(t)
local checker=rawget(t,"checker");
local function iter(tbl,k)
local v=nil;

k=next(checker,k)
local checkerk=checker[k];
if k~=nil then
local get=rawget(checkerk,"get");
if get then
v=get(checkerk);
else
v=checkerk;
end
end
if v~=nil then return k,v end
end
return iter
end,
__len=function(t)
local checker=rawget(t,"checker");
return#checker;
end
};

function GTable()
local inst={};
local keys;
local g;

function inst:clean()
for k,v in pairs(keys)do
_G[k]=g[k];
end
g=nil;
keys=nil;
end

local mt={
__index=function(t,k)
return keys[k];
end,
__newindex=function(t,k,v)
g=g or{};
keys=keys or{};
keys[k]=v;
g[k]=_G[k];
_G[k]=v;
end
};

setmetatable(inst,mt);
return inst;
end

local function MakeTable(s)
local t={};
for k,_ in pairs(s)do
local v=s[k];
if type(v)=="table"then
t[k]=MakeTable(v);
else
t[k]=v;
end
end
return t;
end

function SaveSlotData()
if world and world.ground and world.ground.save then
world.ground:save();
end
return _S;

end

local function compileTable()
for k,v in pairs({{"tile","*"},
{"const","*"},
{"job","*"},
{"passive","*"},
{"option","*"},
{"totem","*"},
{"eval",nil},
{"monster","*"},
{"skill","*"},
{"mapbp","*"},
{"room","*"},
{"object","*"},
{"drop1","*"},
{"drop2","*"},
{"spawn","*"},
{"spell","*"},
{"map","*"},
{"dropwell","*"},
{"evilstatue","*"},
{"monsterskill","*"},
{"roompreset","*"},
{"fsm","*"},
{"fixedobject","*"},
{"cook","*"},
{"server","*"},
{"servershop","*"},
{"sound","*"},
{"buff","*"},
{"regen","*"},
{"fish","*"},
{"repair","*"},
{"tutorial","*"},
{"rocktext","*"},
{"achieve","*"},
{"serverachieve","*"},
{"mission","*"},
{"mission_reward","*"},
{"avatar","*"},
})do
local key=v[1].."table";
if not _G[key]then
_G[key]=compileEval(require("data."..v[1].."table"),v[2],v[3]);
end
end
end
compileTable();

function MapId(type,area,field,idx,f)
if idx then idx="_"..tostring(idx);end
if f then f="_"..tostring(f);end

return string.format("%s_%s_%d%s%s",type,area,field,idx or"",f or"");
end

function CanCliffMap(mapId,addDepth)
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local area=_S.maps[mapId]["\236\167\128\236\151\173"];
local field=_S.maps[mapId]["\237\149\132\235\147\156"];
local mapIdx=_S.maps[mapId]["\235\178\136\237\152\184"];
local depth=_S.maps[mapId]["\236\184\181"];
if depth then

local m=_S.maps[MapId(mapType,area,field,mapIdx,depth+(addDepth or 1))];
return m and not m["\235\179\180\236\138\164\236\184\181"];
end
end

function GetMaxMapDepth(o)
o=o or _S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
local mapType=o["\237\131\128\236\158\133"];
local area=o["\236\167\128\236\151\173"];
local field=o["\237\149\132\235\147\156"];
local mapIdx=o["\235\178\136\237\152\184"];
local depth=o["\236\184\181"];
if depth then
while true do
local mapId=MapId(mapType,area,field,mapIdx,depth+1);
if not _S.maps[mapId]then
break;
end
depth=depth+1;
end
return depth;
end
end


function ReEquipTotem()
local totems={};
local recipes={};
local a={};
for slot,v in safe_pairs(_D["\237\134\160\237\133\156\236\138\172\235\161\175"][_D["\237\134\160\237\133\156\236\138\172\235\161\175\236\132\160\237\131\157"]])do
for i,id in pairs(v)do
if totemtable[id]then
table.insert(totems,id);
end
end
end

for id,cnt in pairs(_D["\237\134\160\237\133\156"])do
local v=recipetable[id];
if v then
recipes[id]=(_D["\237\134\160\237\133\156\235\160\136\235\178\168"][id]or 1);
end
end

local modified=not table.equal(totems,_S["\236\158\165\236\176\169\237\134\160\237\133\156"])or not table.equal(recipes,_S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"]);

_S["\236\158\165\236\176\169\237\134\160\237\133\156"]=totems;
EquipTotem(buff);
return modified;
end

function NewGameForLobby(seed)
_S.seed=seed or math.random(0x7FFFFFFF);
math.randomseed(_S.seed);

for area,v in pairs(maptable)do
if v["\237\131\128\236\158\133"]=="\235\161\156\235\185\132"then
local field=1;
local mapId=MapId("\237\149\132\235\147\156",area,field);
local bp=mapbptable[v["\236\132\164\234\179\132\235\143\132"]];
assert(bp,area);
local _area=area;
if not _S.maps[mapId]then
_S.maps[mapId]={
["\235\167\181 \235\160\136\235\178\168"]=MapLevel(nil,"\237\149\132\235\147\156",area,field),
["\237\131\128\236\158\133"]=v["\237\131\128\236\158\133"];
["\236\167\128\236\151\173"]=area,
["\236\167\128\236\151\173 \235\178\136\237\152\184"]=v["\236\167\128\236\151\173 \235\178\136\237\152\184"],
["\235\141\152\236\160\132\237\131\128\236\158\133"]=math.randlist(bp["\235\141\152\236\160\132\237\131\128\236\158\133"]),
["\237\149\132\235\147\156"]=field,
["\236\132\164\234\179\132\235\143\132"]=bp.guid,
["\234\181\172\236\132\177"]=bp["\237\131\128\236\157\188\236\133\139 \234\181\172\236\132\177"]or math.randlist(maptable[area]["\237\149\132\235\147\156 \234\181\172\236\132\177"][field]or maptable[area]["\237\149\132\235\147\156 \234\181\172\236\132\177"]),
};
local list={};
for k,v in pairs(_D["\234\176\128\235\179\184\236\167\128\236\151\173"])do
if mapbptable[v]then
table.insert(list,v);
end
end
_S.maps[mapId]["\237\131\128\236\157\188\236\167\128\236\151\173"]=table.choice(list)or area;
end
end
end
end

function BuildMaps(newGame,newFields)
newFields=newFields or{};
local newMaps={};

local function findInFloorRange(bp,cnt,R,checker,maps)
cnt=cnt or 9999;
R=R or 1;
local mapIds={};
for k,o in pairs(maps)do
local mapType=o["\237\131\128\236\158\133"];
local area=o["\236\167\128\236\151\173"];
local field=o["\237\149\132\235\147\156"];
local mapIdx=o["\235\178\136\237\152\184"];
local depth=o["\236\184\181"];
if depth==1 and not o["\235\179\180\236\138\164\236\184\181"]and(o["\236\132\164\234\179\132\235\143\132"]==bp or o["\237\131\128\236\158\133"]==bp or o["\236\167\128\236\151\173"]==bp)then
local list={};
while true do
local mapId=MapId(mapType,area,field,mapIdx,depth);
if _S.maps[mapId]then
table.insert(list,mapId);
depth=depth+1;
else
break;
end
end
for i=1,countkcc(cnt),1 do
local floors={};
for i,v in pairs(list)do
if v and checker(v)then
table.insert(floors,i);
end
end
local f=table.choice(floors);
if f then
table.insert(mapIds,list[f]);
local r=countkcc(R);
for i=f-r+1,f+r-1,1 do
list[i]=nil;
end
else
break;
end
end
end
end
return mapIds;
end

local function makeTemperature(cache,bp,mapType,area,field,depth)
local tb=mapbptable[bp];
local R=2;
depth=depth or 1;
if cache["\234\184\176\236\152\168"]then
return cache["\234\184\176\236\152\168"];
elseif cache[area.."\234\184\176\236\152\168"]then
return cache[area.."\234\184\176\236\152\168"];
elseif cache[depth.."\236\184\181\234\184\176\236\152\168"]then
return cache[depth.."\236\184\181\234\184\176\236\152\168"];
end

if tb["\234\184\176\236\152\168"]then
local t=table.copy(tb["\234\184\176\236\152\168"]);
if type(t[1])=="table"then
t=table.choice(t);
end
for k,v in pairs(t)do
t[k]=v+math.random(-R,R);
end
cache["\234\184\176\236\152\168"]=t;
return t;
end

if tb["\236\167\128\236\151\173\235\179\132 \234\184\176\236\152\168"]then
for k,v in pairs(tb["\236\167\128\236\151\173\235\179\132 \234\184\176\236\152\168"])do
local keys=string.split(k,",")
if table.find(keys,area)then
local t=table.copy(v);
if type(t[1])=="table"then
t=table.choice(t);
end
for k,v in pairs(t)do
t[k]=v+math.random(-R,R);
end
cache[area.."\234\184\176\236\152\168"]=t;
return t;
end
end
end
if tb["\236\184\181\235\179\132 \234\184\176\236\152\168"]then
for k,v in pairs(tb["\236\184\181\235\179\132 \234\184\176\236\152\168"])do
local keys=string.split(k,"~");
keys[1]=tonumber(keys[1]);
keys[2]=tonumber(keys[2]);
if depth>=keys[1]and depth<=keys[2]then
local t=table.copy(v);
if type(t[1])=="table"then
t=table.choice(t);
end
for k,v in pairs(t)do
t[k]=v+math.random(-R,R);
end
for i=keys[1],keys[2],1 do
cache[i.."\236\184\181\234\184\176\236\152\168"]=t;
end
return t;
end
end
end
end


local function makeDungeon(v,fromMap,type,area,field,k,i)
trace("makeDungeon",fromMap,type,area,field,k,i);
local bplist={};
if mapbptable[k]then
bplist[k]=1;
else
assert(k=="\236\158\145\236\157\128 \235\141\152\236\160\132",k);
for k,v in pairs(mapbptable)do
if v["\235\185\132\236\156\168"]and table.find(v["\237\131\128\236\158\133"],type)and table.find(v["\236\167\128\236\151\173"]or area,area)then
bplist[k]=v["\235\185\132\236\156\168"];
end
end
end
local bp=mapbptable[math.randlist(bplist)];
_G["\235\167\181 \235\160\136\235\178\168"]=_S.maps[fromMap]["\235\167\181 \235\160\136\235\178\168"];
local maxDepth=countkcc(bp["\236\184\181\236\136\152"]);
_G["\235\167\181 \235\160\136\235\178\168"]=nil;
local tpdata={};
for f=1,maxDepth,1 do
local mapId=MapId(type,area,field,i,f);
local eliteMonster;
if bp["\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176"]then
local i=f-bp["\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176"][1];
if i>=0 and(i%bp["\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176"][2])==0 then
eliteMonster=true;
end
end
if not _S.maps[mapId]then
_S.maps[mapId]={
["\235\167\181 \235\160\136\235\178\168"]=MapLevel(fromMap,type,area,field,k,f),
["\237\131\128\236\158\133"]=type,
["\236\167\128\236\151\173"]=area,
["\236\167\128\236\151\173 \235\178\136\237\152\184"]=v["\236\167\128\236\151\173 \235\178\136\237\152\184"],
["\235\141\152\236\160\132\237\131\128\236\158\133"]=math.randlist(bp["\235\141\152\236\160\132\237\131\128\236\158\133"]),
["\237\149\132\235\147\156"]=field,
["\236\157\180\236\160\132\235\167\181"]=fromMap,
["\235\178\136\237\152\184"]=i,
["\236\184\181"]=f,
["\236\132\164\234\179\132\235\143\132"]=bp.guid,
["\234\181\172\236\132\177"]=(math.randlist(const("\235\141\152\236\160\132 \234\181\172\236\132\177 \236\160\145\235\145\144\236\130\172 \237\153\149\235\165\160"),100)or"")..bp["\237\131\128\236\157\188\236\133\139 \234\181\172\236\132\177"],

["\234\184\176\236\152\168"]=makeTemperature(tpdata,bp.guid,type,area,field,f),
["\236\151\152\235\166\172\237\138\184 \235\170\172\236\138\164\237\132\176"]=eliteMonster,
["\235\179\180\236\138\164\236\184\181"]=table.find(bp["\235\179\180\236\138\164\236\184\181"],f)or(table.find(bp["\235\179\180\236\138\164\236\184\181"],-1)and f==maxDepth),
};
newMaps[mapId]=_S.maps[mapId];
end
end
end

for area,v in pairs(_S.maps)do
v["\234\184\176\236\152\168"]=v["\234\184\176\236\152\168"]or makeTemperature({},v["\236\132\164\234\179\132\235\143\132"],v["\237\131\128\236\158\133"],v["\236\167\128\236\151\173"],v["\237\149\132\235\147\156"],v["\236\184\181"]);
end

for area,v in pairs(maptable)do
if v["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"and not v["\235\158\156\235\141\164 \235\141\152\236\160\132"]and not _S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]then
newFields[area]=v;
_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]=countkcc(v["\237\149\132\235\147\156 \234\176\156\236\136\152"]);
end
end

for area,v in pairs(newFields)do
if v["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"and not _S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]then
_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]=countkcc(v["\237\149\132\235\147\156 \234\176\156\236\136\152"]);
end
for field=1,_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area],1 do
local mapId=MapId("\237\149\132\235\147\156",area,field);
if not _S.maps[mapId]then
local bp=mapbptable[v["\236\132\164\234\179\132\235\143\132"]];
assert(bp,area);
local linkMaps={};
if field==1 then
for k,v in safe_ipairs(v["\236\157\180\236\160\132 \236\167\128\236\151\173"])do
table.insert(linkMaps,MapId("\237\149\132\235\147\156",v,_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][v]));
end
else
table.insert(linkMaps,MapId("\237\149\132\235\147\156",area,field-1));
if field==_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]then
for k,v in safe_ipairs(v["\235\139\164\236\157\140 \236\167\128\236\151\173"])do
table.insert(linkMaps,MapId("\237\149\132\235\147\156",v,1));
end
end
end
if field==1 then
for k,v in pairs(maptable)do
if newFields[k]and table.find(v["\235\139\164\236\157\140 \236\167\128\236\151\173"],area)then
table.insert(linkMaps,MapId("\237\149\132\235\147\156",k,_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][k]));
end
end
end
if field==_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]then
for k,v in pairs(maptable)do
if table.find(v["\236\157\180\236\160\132 \236\167\128\236\151\173"],area)then
table.insert(linkMaps,MapId("\237\149\132\235\147\156",k,1));
end
end
else
table.insert(linkMaps,MapId("\237\149\132\235\147\156",area,field+1));
end
local _area=area;
_S.maps[mapId]={
["\235\167\181 \235\160\136\235\178\168"]=MapLevel(nil,"\237\149\132\235\147\156",area,field),
["\235\139\164\236\157\140 \235\167\181"]=linkMaps,
["\236\182\156\234\181\172"]={0,0,0,0},
["\237\131\128\236\158\133"]=v["\237\131\128\236\158\133"];
["\236\167\128\236\151\173"]=area,
["\236\167\128\236\151\173 \235\178\136\237\152\184"]=v["\236\167\128\236\151\173 \235\178\136\237\152\184"],
["\235\141\152\236\160\132\237\131\128\236\158\133"]=math.randlist(bp["\235\141\152\236\160\132\237\131\128\236\158\133"]),
["\237\149\132\235\147\156"]=field,
["\236\132\164\234\179\132\235\143\132"]=bp.guid,
["\234\181\172\236\132\177"]=bp["\237\131\128\236\157\188\236\133\139 \234\181\172\236\132\177"]or math.randlist(maptable[area]["\237\149\132\235\147\156 \234\181\172\236\132\177"][field]or maptable[area]["\237\149\132\235\147\156 \234\181\172\236\132\177"]),
["\234\184\176\236\152\168"]=makeTemperature({},bp.guid,"\237\149\132\235\147\156",area,field);
};
if area=="\235\161\156\235\185\132"then
local list={};
for k,v in pairs(_D["\234\176\128\235\179\184\236\167\128\236\151\173"])do
if mapbptable[v]then
table.insert(list,v);
end
end
_S.maps[mapId]["\237\131\128\236\157\188\236\167\128\236\151\173"]=table.choice(list)or area;
end
newMaps[mapId]=_S.maps[mapId];
end
end

for idx,type in pairs(const("\235\141\152\236\160\132\235\170\169\235\161\157"))do
if v[type]then
local list={};
local i=v["\235\141\152\236\160\132\235\147\177\236\158\165"][idx];
if i<0 then
i=_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]+i+1;
end
assert(_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area],area,_S["\237\149\132\235\147\156 \234\176\156\236\136\152"]);
while i<=_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]do
table.insert(list,i);
i=i+1;
end
trace("\236\167\128\236\151\173\235\170\169\235\161\157",type,list);
local t=v[type];
if not t[1]then
t={t};
end
local _G=GTable();
for _,tt in ipairs(t)do
for k,cnt in pairs(tt)do
local c=countkcc(cnt);
_G[k]=c;
for i=1,c,1 do
local field=table.choiceRemove(list);
local idx=1;
assert(field,"\237\149\132\235\147\156\235\182\128\236\161\177",type,k,idx,cnt);
local fromMap=MapId("\237\149\132\235\147\156",area,field);
makeDungeon(v,fromMap,type,area,field,k,idx);

if v["\235\141\152\236\160\132\236\149\136\235\141\152\236\160\132"]then
local d_d=v["\235\141\152\236\160\132\236\149\136\235\141\152\236\160\132"][type];
if d_d then
for _,ty in pairs(const("\235\141\152\236\160\132\235\170\169\235\161\157"))do
local vv=d_d[ty];
if vv then
local f=countkcc(vv[2]);
local fromMap=MapId(type,area,field,idx,f);
makeDungeon(v,fromMap,ty,area,field,vv[1],"["..type.."_"..idx.."_"..f.."]");
end
end
end
end
end
end
end
_G:clean();
end
end
end

for guid,v in pairs(roomtable)do
if v["\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177"]then
for bp,cnt in pairs(v["\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177"])do
local function checker(mapId)
if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",guid)and not CanCliffMap(mapId)then
return false;
elseif _S.maps[mapId]["\235\179\180\236\138\164\236\184\181"]then
return false;
elseif table.find(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId)then
return false;
end
return true;
end
local mapIds=findInFloorRange(bp,cnt,v["\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177 \234\176\132\234\178\169"],checker,newMaps);
for k,mapId in safe_pairs(mapIds)do
_S["\234\179\160\236\160\149\235\176\169"][guid]=_S["\234\179\160\236\160\149\235\176\169"][guid]or{};
if not table.find(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId)then
trace("\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177\236\156\188\235\161\156 \236\182\148\234\176\128",guid,mapId);
table.insert(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId);
end
end
end
end

if v["\237\138\185\236\136\152 \236\131\157\236\132\177"]then
local mapIds={};
local t=v["\237\138\185\236\136\152 \236\131\157\236\132\177"];
for k,m in pairs(newMaps)do
local tb=t[m["\237\131\128\236\158\133"]]or t[m["\236\167\128\236\151\173"]]or t[m["\236\132\164\234\179\132\235\143\132"]];
if tb then
if tb["\235\179\180\236\138\164\236\184\181\236\160\156\236\153\184"]and m["\235\179\180\236\138\164\236\184\181"]then
elseif(not tb["\236\167\128\236\151\173"]or(table.find(tb["\236\167\128\236\151\173"],m["\236\167\128\236\151\173"])or table.find(tb["\236\167\128\236\151\173"],m["\236\167\128\236\151\173 \235\178\136\237\152\184"])))and
((not tb["\236\184\181"]or table.find(tb["\236\184\181"],m["\236\184\181"]))or(tb["\236\184\181"]==-1 and GetMaxMapDepth(m)==m["\236\184\181"]))then
table.insert(mapIds,k);
end
end
end
_S["\234\179\160\236\160\149\235\176\169"][guid]=_S["\234\179\160\236\160\149\235\176\169"][guid]or{};
local mapId=table.choice(mapIds);
table.insert(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId);
end
end


do
for mapId,m in pairs(newMaps)do
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",m["\237\131\128\236\158\133"])
local area=m["\236\167\128\236\151\173"];
local field=m["\237\149\132\235\147\156"];
local areaN=m["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local bpName=m["\236\132\164\234\179\132\235\143\132"];
local depth=m["\236\184\181"];
local bp=mapbptable[bpName];
if bp["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"]then
for i,v in pairs(bp["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"])do
for guid,tb in pairs(v)do
if tb["\237\149\132\235\147\156"]and tb["\237\149\132\235\147\156"]~=field then
elseif tb["\236\167\128\236\151\173"]and tb["\236\167\128\236\151\173"]~=area then
elseif tb["\236\167\128\236\151\173 \235\178\136\237\152\184"]and tb["\236\167\128\236\151\173 \235\178\136\237\152\184"]~=areaN then
elseif((not tb["\236\184\181"]or table.find(tb["\236\184\181"],depth))or(tb["\236\184\181"]==-1 and GetMaxMapDepth(m)==depth))then
_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]=_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]or{};
table.insert(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid],{mapId=mapId,pos=tb["\236\156\132\236\185\152"]});
end
end
end
end
end

for guid,v in pairs(roomtable)do
if v["\235\167\181\235\179\132\236\131\157\236\132\177"]then
local list={};
for mapId,m in pairs(newMaps)do
local area=m["\236\167\128\236\151\173"];
local field=m["\237\149\132\235\147\156"];
local areaN=m["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local bpName=m["\236\132\164\234\179\132\235\143\132"];
local depth=m["\236\184\181"];
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",m["\237\131\128\236\158\133"])
if not table.find(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId)then
local tb=v["\235\167\181\235\179\132\236\131\157\236\132\177"][m["\237\131\128\236\158\133"]]or v["\235\167\181\235\179\132\236\131\157\236\132\177"][area]or v["\235\167\181\235\179\132\236\131\157\236\132\177"][typeA]or v["\235\167\181\235\179\132\236\131\157\236\132\177"][bpName];
if tb then
if tb["\235\179\180\236\138\164\236\184\181\236\160\156\236\153\184"]and m["\235\179\180\236\138\164\236\184\181"]then
elseif(not tb["\236\167\128\236\151\173"]or(table.find(tb["\236\167\128\236\151\173"],areaN)or table.find(tb["\236\167\128\236\151\173"],area)))and
((not tb["\236\184\181"]or table.find(tb["\236\184\181"],depth))or(tb["\236\184\181"]==-1 and GetMaxMapDepth(m)==depth))then
_S["\234\179\160\236\160\149\235\176\169"][guid]=_S["\234\179\160\236\160\149\235\176\169"][guid]or{};
table.insert(list,mapId);
end
end
end
end
if#list>0 then
if v["\235\167\181\235\179\132\236\131\157\236\132\177"]["\234\176\156\236\136\152"]then
table.append(_S["\234\179\160\236\160\149\235\176\169"][guid],table.choicen(list,countkcc(v["\235\167\181\235\179\132\236\131\157\236\132\177"]["\234\176\156\236\136\152"])));
else
table.append(_S["\234\179\160\236\160\149\235\176\169"][guid],list);
end
end
end
end
end

local function setLinkMap(mapId)
local o=_S.maps[mapId];
if o and o["\235\139\164\236\157\140 \235\167\181"]then
local nextMaps=o["\235\139\164\236\157\140 \235\167\181"];
local rdirs={2,1,4,3};
for k,v in ipairs(nextMaps)do
if not table.find(o["\236\182\156\234\181\172"],v)then
local link=_S.maps[v];
if link["\236\167\128\236\151\173"]==o["\236\167\128\236\151\173"]then
local dirs={};
for k,v in pairs(o["\236\182\156\234\181\172"])do
if v==0 and link["\236\182\156\234\181\172"][rdirs[k]]==0 then
table.insert(dirs,k);
end
end
local dir=table.choice(dirs);
assert(dir,"\236\182\156\234\181\172\234\178\176\236\160\149 \236\139\164\237\140\168",mapId);
trace("\236\182\156\234\181\172\234\178\176\236\160\149",mapId,v,dir);
o["\236\182\156\234\181\172"][dir]=v;
link["\236\182\156\234\181\172"][rdirs[dir]]=mapId;
setLinkMap(v);
else
local dirs={};
for k,v in pairs(o["\236\182\156\234\181\172"])do
if v==0 then
table.insert(dirs,k);
end
end
local dir=table.choice(dirs);
assert(dir,"\236\182\156\234\181\172\234\178\176\236\160\149 \236\139\164\237\140\168",mapId);
o["\236\182\156\234\181\172"][dir]=v;
setLinkMap(v);
end
end
end
end
end

for k,v in pairs(maptable)do
if not v["\236\157\180\236\160\132 \236\167\128\236\151\173"]then
setLinkMap(MapId("\237\149\132\235\147\156",k,1));
end
end

for k,v in pairs(fixedobjecttable)do
local guid=v["\236\152\164\235\184\140\236\160\157\237\138\184"];
local function hasObjectInMap(id,mapId)
if id then
for _,k in ipairs(id)do
for _,v in safe_pairs(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][k])do
if v.mapId==mapId then
return true;
end
end
end
end
end
if v["\235\167\181\235\179\132\236\131\157\236\132\177"]then
local list={};
for mapId,m in pairs(newMaps)do
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",m["\237\131\128\236\158\133"])
local area=m["\236\167\128\236\151\173"];
local areaN=m["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local field=m["\237\149\132\235\147\156"];
local bpName=m["\236\132\164\234\179\132\235\143\132"];
local depth=m["\236\184\181"];
local bp=mapbptable[bpName];
local tb=v["\235\167\181\235\179\132\236\131\157\236\132\177"][m["\237\131\128\236\158\133"]]or v["\235\167\181\235\179\132\236\131\157\236\132\177"][area]or v["\235\167\181\235\179\132\236\131\157\236\132\177"][typeA]or v["\235\167\181\235\179\132\236\131\157\236\132\177"][bpName];
if tb then
if(not tb["\236\167\128\236\151\173"]or table.find(tb["\236\167\128\236\151\173"],areaN)or table.find(tb["\236\167\128\236\151\173"],area))and
((not tb["\236\184\181"]or table.find(tb["\236\184\181"],depth))or(tb["\236\184\181"]==-1 and GetMaxMapDepth(m)==depth))and
(not tb["\237\149\132\235\147\156"]or table.find(tb["\237\149\132\235\147\156"],field))
then
if not hasObjectInMap(tb["\235\176\176\237\131\128\236\152\164\235\184\140\236\160\157\237\138\184"],mapId)then
local c=countkcc(tb.c or 1);
_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]=_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]or{};
table.insert(list,{mapId=mapId,cnt=c,pos=v["\236\131\157\236\132\177\236\156\132\236\185\152"],param=v["\236\131\157\236\132\177\236\157\184\236\158\144"],data=v["\237\140\140\235\157\188\235\175\184\237\132\176"]});
else
trace("\235\176\176\237\131\128\236\152\164\235\184\140\236\160\157\237\138\184 skip",tb["\235\176\176\237\131\128\236\152\164\235\184\140\236\160\157\237\138\184"],mapId,guid);
end
end
end
end
if#list>0 then
if v["\235\167\181\235\179\132\236\131\157\236\132\177"]["\234\176\156\236\136\152"]then
table.append(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid],table.choicen(list,countkcc(v["\235\167\181\235\179\132\236\131\157\236\132\177"]["\234\176\156\236\136\152"])));
else
table.append(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid],list);
end
end
end
if v["\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177"]then
local gap=countkcc(v["\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177 \234\176\132\234\178\169"]);
for bp,cnt in pairs(v["\235\141\152\236\160\132\235\179\132 \234\179\160\236\160\149 \236\131\157\236\132\177"])do
local function checker(mapId)
if _S.maps[mapId]["\235\179\180\236\138\164\236\184\181"]then
return false;
end
return true;
end
local mapIds=findInFloorRange(bp,cnt,gap,checker,newMaps);
for k,mapId in safe_pairs(mapIds)do
_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]=_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]or{};
table.insert(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid],{mapId=mapId,pos=v["\236\131\157\236\132\177\236\156\132\236\185\152"],param=v["\236\131\157\236\132\177\236\157\184\236\158\144"],data=v["\237\140\140\235\157\188\235\175\184\237\132\176"]});
end
end
end
end


local roomCnts={};
for mapId,v in pairs(newMaps)do

if not v["\235\179\180\236\138\164\236\184\181"]then
local area=v["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local depth=v["\236\184\181"];
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",v["\237\131\128\236\158\133"])
if typeA then
local rule=ev("\237\138\185\236\136\152\235\176\169 \236\131\157\236\132\177 \234\183\156\236\185\153_"..typeA);
local c=countkcc(rule);
roomCnts[mapId]=c;
end
end
end

if newGame then

local roomtableF={};
for guid,v in pairs(roomtable)do
if v["\234\179\160\236\160\149 \236\131\157\236\132\177"]then
table.insert(roomtableF,v);
end
end

table.sort(roomtableF,function(a,b)return#a["\234\179\160\236\160\149 \236\131\157\236\132\177"]-(a["\236\181\156\235\140\128 \236\131\157\236\132\177"]or 1)<#b["\234\179\160\236\160\149 \236\131\157\236\132\177"]-(b["\236\181\156\235\140\128 \236\131\157\236\132\177"]or 1)end);

for i,v in ipairs(roomtableF)do
local guid=v.guid;
local cnt=v["\236\181\156\235\140\128 \236\131\157\236\132\177"]or 1;
local list=table.shuffle(v["\234\179\160\236\160\149 \236\131\157\236\132\177"]);
for _,area in ipairs(list)do

local mapIds={};
for k,m in pairs(newMaps)do
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",m["\237\131\128\236\158\133"]);
if roomCnts[k]and roomCnts[k]>0 and v[typeA]then
if m["\236\132\164\234\179\132\235\143\132"]~="\236\151\134\236\157\140"then
if m["\236\167\128\236\151\173 \235\178\136\237\152\184"]==area or m["\236\167\128\236\151\173"]==area or m["\236\132\164\234\179\132\235\143\132"]==area then
local mt=maptable[m["\236\167\128\236\151\173"]];

if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",guid)and not CanCliffMap(k)then
elseif m["\235\179\180\236\138\164\236\184\181"]then
elseif mt and mt["\236\132\156\237\140\144\235\182\136\234\176\128"]then
else
if not table.find(_S["\234\179\160\236\160\149\235\176\169"][guid],k)then
table.insert(mapIds,k);
end
end
end
end
end
end
if#mapIds>0 then
cnt=cnt-1;
_S["\234\179\160\236\160\149\235\176\169"][guid]=_S["\234\179\160\236\160\149\235\176\169"][guid]or{};
local mapId=table.choice(mapIds);
roomCnts[mapId]=roomCnts[mapId]-1;
table.insert(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId);
if cnt<=0 then
break;
end
end
end
if cnt>0 then
trace("\235\176\169\236\131\157\236\132\177 \236\167\128\236\151\173 \236\151\134\236\157\140",guid,_S["\234\179\160\236\160\149\235\176\169"],list,cnt);
assert(false,"\235\176\169\236\131\157\236\132\177 \236\167\128\236\151\173 \236\151\134\236\157\140",guid,_S["\234\179\160\236\160\149\235\176\169"]);
end
end
end


local roomtableA={};
for k,v in pairs(roomtable)do
if v["\236\131\157\236\132\177 \235\185\132\236\156\168"]then
roomtableA[k]=v;
end
end


for mapId,v in pairs(newMaps)do

if not v["\235\179\180\236\138\164\236\184\181"]then
local typeA=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152A",v["\237\131\128\236\158\133"])
local area=v["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local depth=v["\236\184\181"];
local c=roomCnts[mapId]or 0;
if c>0 then
local cliff=CanCliffMap(mapId);
local t={};
for k,v in pairs(roomtableA)do
if not table.find(_S["\234\179\160\236\160\149\235\176\169"][k],mapId)then
if const("\235\130\173\235\150\160\235\159\172\236\167\128\235\176\169\235\170\169\235\161\157",k)and not cliff then
elseif v[typeA]and area and v["\236\131\157\236\132\177 \236\139\156\236\158\145"]<=area then
t[k]=v["\236\131\157\236\132\177 \235\185\132\236\156\168"];
end
end
end
if not table.empty(t)then
while c>=1 do
local guid=math.randlist(t);
t[guid]=nil;
c=c-1;
trace("\236\131\157\236\132\177 \236\139\156\236\158\145\236\156\188\235\161\156 \236\182\148\234\176\128",mapId,guid);
_S["\234\179\160\236\160\149\235\176\169"][guid]=_S["\234\179\160\236\160\149\235\176\169"][guid]or{};
table.insert(_S["\234\179\160\236\160\149\235\176\169"][guid],mapId);
end
end
end
end
end
end

function NewGame(seed)
_S.seed=seed or math.random(0x7FFFFFFF);
math.randomseed(_S.seed);
local _recipetable=require"data.recipetable";

for slot,v in safe_pairs(_D["\237\134\160\237\133\156\236\138\172\235\161\175"][_D["\237\134\160\237\133\156\236\138\172\235\161\175\236\132\160\237\131\157"]])do
for i,id in ipairs(v)do
if totemtable[id]then
table.insert(_S["\236\158\165\236\176\169\237\134\160\237\133\156"],id);
end
end
end

EquipTotem(buff);

local job=jobtable[_S["\236\167\129\236\151\133"]];
if job then
for i=1,9,1 do
local id=job["\236\138\164\237\130\172"..i];
if id then
local psv=passivetable[id];
if psv then
local data={};
for i=1,9 do
local k=psv["\237\154\168\234\179\188"..i];
if k then
local v=psv["\237\154\168\234\179\188"..i.."_\236\136\152\236\185\152"];
assert(v);
data[k]=table.copy(v);
else
break;
end
end
EquipOption(buff,"job",data);
for k,v in safe_pairs(psv["\236\139\156\236\158\145\237\149\168\236\136\152"])do
for func,vars in pairs(v)do
_G[func](table.unpack(vars));
end
end
end
end
end
end

for k,v in pairs(_S["\236\136\153\235\160\168\235\143\132"])do
for kk,vv in pairs(v)do
_S["\236\139\156\236\158\145\236\136\153\235\160\168\235\143\132"][k][kk]=vv;
end
end












for k,v in pairs(const("\235\175\184\237\153\149\236\157\184\236\149\132\236\157\180\237\133\156"))do
for id,t in pairs(drop2table)do
if t["\234\183\184\235\163\185"]==k then
local P=bf(k.." \236\139\157\235\179\132 \237\153\149\235\165\160");
trace("\236\139\157\235\179\132",k,P);
if math.randpercent(P)then
_S["\236\149\132\236\157\180\237\133\156\237\153\149\236\157\184"][id]=1;
end
end
end
end


local tm=socket.gettime();
_S.playing=1;
do
_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"]={};
local t={};
for k,v in pairs(_recipetable)do
for _,building in safe_pairs(v["\237\154\141\235\147\157 \236\139\156\236\132\164 \234\183\184\235\163\185"])do
_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building]=_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building]or{};
local tb=BuildingRecipeOpenList(_recipetable,building);
local type=v["\235\182\132\235\165\152"];
if not type then
_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building][k]=1;
elseif(not tb or tb[type])then
t[building]=t[building]or{};
t[building][type]=t[building][type]or{};
table.insert(t[building][type],k);
end
end
end
for building,v in pairs(t)do
for type,list in pairs(v)do
local n=#list;
local tb=BuildingRecipeOpenList(_recipetable,building);
assert(tb,"\235\182\132\235\165\152\235\179\132 \236\160\156\236\158\145\235\178\149 \236\152\164\237\148\136 \236\160\149\236\157\152 \236\149\136\235\144\168",building);
if tb then
n=tb[type]or 0;
local t={(bf("\235\182\132\235\165\152\235\179\132\236\160\156\236\158\145\235\178\149 \234\184\176\235\179\184 \234\176\156\236\136\152")),(bf("\235\182\132\235\165\152\235\179\132\236\160\156\236\158\145\235\178\149 \236\182\148\234\176\128 \237\153\149\235\165\160")),(bf("\235\182\132\235\165\152\235\179\132\236\160\156\236\158\145\235\178\149 \236\181\156\235\140\128 \234\176\156\236\136\152"))};
local a=countkcc(t);
n=n+a;
end

do
local _={};
for k,v in pairs(list)do
if not _S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building][v]then
table.insert(_,v);
end
end
list=_;
end

trace("\235\182\132\235\165\152\235\179\132 \236\160\156\236\158\145\235\178\149 \236\152\164\237\148\136",type,building,n,list,tb);
if n>0 then
list=table.choicen(list,math.min(#list,n));
for k,v in pairs(list)do
trace("\235\182\132\235\165\152\235\179\132 \236\160\156\236\158\145\235\178\149 \236\152\164\237\148\136 \237\154\141\235\147\157",type,building,v);
_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building][v]=1;
end
end
end
end
end

BuildMaps(true);
trace("diff newgame5:"..(socket.gettime()-tm));
for k,v in pairs(fixedobjecttable)do
local guid=v["\236\152\164\235\184\140\236\160\157\237\138\184"];
if v["\234\179\160\236\160\149 \236\131\157\236\132\177"]then
for _,area in safe_pairs(v["\234\179\160\236\160\149 \236\131\157\236\132\177"])do
local cnt=countkcc(v["\236\181\156\235\140\128 \236\131\157\236\132\177"]);
local mapIds={};
for k,m in pairs(_S.maps)do
if m["\235\179\180\236\138\164\236\184\181"]then
elseif m["\236\132\164\234\179\132\235\143\132"]=="\236\151\134\236\157\140"then
elseif(v[m["\237\131\128\236\158\133"]]or 0)==0 then
elseif v["\234\179\160\236\160\149\236\131\157\236\132\177\236\149\136\237\149\168"]and table.find(v["\234\179\160\236\160\149\236\131\157\236\132\177\236\149\136\237\149\168"],m["\236\167\128\236\151\173"])then
elseif v["\237\149\132\235\147\156\235\178\136\237\152\184"]and not table.find(v["\237\149\132\235\147\156\235\178\136\237\152\184"],m["\237\149\132\235\147\156"])then
elseif m["\236\167\128\236\151\173 \235\178\136\237\152\184"]==area or m["\236\167\128\236\151\173"]==area or m["\236\132\164\234\179\132\235\143\132"]==area then
table.insert(mapIds,k);
end
end
_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]=_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid]or{};
assert(#mapIds>0,v);

local list=table.choicen(mapIds,cnt);
for i,mapId in pairs(list)do
table.insert(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][guid],{mapId=mapId,pos=v["\236\131\157\236\132\177\236\156\132\236\185\152"],param=v["\236\131\157\236\132\177\236\157\184\236\158\144"],data=v["\237\140\140\235\157\188\235\175\184\237\132\176"]});
end
end
end
end

trace("diff newgame3:"..(socket.gettime()-tm));

do

local pct={};
for k,v in pairs(ev("\236\131\129\236\157\184\234\176\128\235\176\169\235\170\169\235\161\157"))do
pct[k]=v;
end
for i=1,5,1 do
local k=math.randlist(pct);
_S["\236\131\129\236\157\184\234\176\128\235\176\169"][i]=k;
pct[k]=nil;
end
local sellers=const("\236\131\129\236\157\184\235\170\169\235\161\157");
local sellerArea=table.choicen({1,2,3},5);

for area,seller in ipairs(sellerArea)do
local guid=sellers[seller];
if not _S[guid]then
local mapIds={};
for k,v in pairs(_S.maps)do
if v["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"and v["\236\167\128\236\151\173 \235\178\136\237\152\184"]==area then
local mt=maptable[v["\236\167\128\236\151\173"]];
if mt and not mt["\236\132\156\237\140\144\235\182\136\234\176\128"]then
table.insert(mapIds,k);
end
end
end
_S["\234\179\160\236\160\149\235\176\169"][guid]=_S["\234\179\160\236\160\149\235\176\169"][guid]or{};
table.insert(_S["\234\179\160\236\160\149\235\176\169"][guid],table.choice(mapIds));
end
end
end
NewMission();
trace("diff newgame1:"..(socket.gettime()-tm));
end

function LoadGameData(d)

local defD={
["\237\148\140\235\160\136\236\157\180"]=0,
["\236\152\164\237\148\136\236\167\129\236\151\133"]={[1]=0},
["\237\154\141\235\147\157\236\167\129\236\151\133"]={},
["\236\152\164\237\148\136\236\149\132\235\176\148\237\131\128"]={[1]=0},
["\237\154\141\235\147\157\236\149\132\235\176\148\237\131\128"]={},
["\234\176\128\235\179\184\236\167\128\236\151\173"]={},
["\236\162\133\235\165\152\235\179\132\236\160\156\236\158\145\237\154\159\236\136\152"]={},
["\236\180\157\236\160\156\236\158\145\237\154\159\236\136\152"]={},
["\236\180\157\236\151\148\235\148\169"]={},
["\236\151\148\235\148\169"]={},
["\236\156\160\236\160\129\235\147\177\236\158\165"]={},

["\236\156\160\236\160\129"]={},
["\236\156\160\236\160\129seq"]={},
["\237\134\160\237\133\156"]={},
["\237\134\160\237\133\156\235\160\136\235\178\168"]={},
["\237\134\160\237\133\156\236\138\172\235\161\175"]={},
["\237\138\156\237\134\160\235\166\172\236\150\188"]={},
["G\235\143\132\236\160\132\234\179\188\236\160\156"]={},
["\235\143\132\236\160\132\234\179\188\236\160\156"]={},
["\237\134\160\237\133\156\236\138\172\235\161\175\236\132\160\237\131\157"]=1,
["\236\149\132\235\176\148\237\131\128\236\132\160\237\131\157"]=1,
["\234\179\160\236\160\149\235\175\184\236\133\152"]={},
};
if d then
for k,v in pairs(d)do
if defD[k]then
defD[k]=v;
end
end
end
_G._D=UseChecker(defD);
end

function LoadSlotData(slot,t,newGame)
_G._SI=slot;
trace("LoadSlotData");
local def={
playing=0,
appeared=0,
zoom=1,
seed=0,
firstTab={},
["\236\149\132\235\176\148\237\131\128"]=1,
["\235\170\168\237\151\152\236\160\144\236\136\152"]=0,
["\236\130\172\236\154\169\236\160\144\236\136\152"]=0,
["\235\160\136\235\178\168"]=0,
["\234\178\189\237\151\152\236\185\152"]=0,
["\236\167\129\236\151\133"]=0,
["\237\158\152"]=1,
["\235\175\188"]=1,
["\236\167\128"]=1,
["\236\178\180"]=1,
["\236\154\180"]=1,
["\234\184\176\235\179\184\235\170\168\235\147\156"]="\234\184\176\235\179\184",
["\236\157\180\235\143\153\235\170\168\235\147\156"]="\234\184\176\235\179\184",
["\237\154\131\235\182\136\235\170\168\235\147\156"]="\234\184\176\235\179\184",
["\237\154\131\235\182\136T"]=0,
["\236\131\157\235\170\133\235\160\165"]=0,
["\236\151\144\235\132\136\236\167\128"]=0,
["\237\151\136\234\184\176"]=0,
["\234\176\136\236\166\157"]=0,
["\237\148\188\235\161\156\235\143\132"]=0,
["\236\178\180\236\152\168"]=0,
["\236\152\164\236\151\188"]=0,

["\236\178\152\236\185\152"]={},
["\235\141\176\235\175\184\236\167\128\234\184\176\235\161\157"]={},
["\236\191\168\237\131\128\236\158\132"]={},
["\236\136\153\235\160\168\235\143\132\237\143\172\236\157\184\237\138\184"]=0,
["\236\136\153\235\160\168\235\143\132"]={["\234\178\128\235\165\152"]={},["\235\145\148\234\184\176\235\165\152"]={},["\236\155\144\234\177\176\235\166\172"]={},["\235\176\169\236\150\180"]={}},
["\236\139\156\236\158\145\236\136\153\235\160\168\235\143\132"]={["\234\178\128\235\165\152"]={},["\235\145\148\234\184\176\235\165\152"]={},["\236\155\144\234\177\176\235\166\172"]={},["\235\176\169\236\150\180"]={}},
["\236\182\148\236\154\180\234\184\176\234\176\132"]=0,
["\235\141\148\236\154\180\234\184\176\234\176\132"]=0,
["\236\181\156\235\140\128 \236\182\148\236\154\180\234\184\176\234\176\132"]=0,
["\236\181\156\235\140\128 \235\141\148\236\154\180\234\184\176\234\176\132"]=0,
["\234\179\160\236\156\160\235\178\136\237\152\184"]=1,
["\235\148\148\235\178\132\237\148\132"]={["\236\182\148\236\155\128"]=0,["\236\160\128\236\178\180\236\152\168"]=0,["\235\141\148\236\155\128"]=0,["\234\179\160\236\151\180"]=0,["\235\176\176\234\179\160\237\148\148"]=0,["\236\152\129\236\150\145\236\139\164\236\161\176"]=0,["\237\148\188\234\179\164\237\149\168"]=0,["\237\131\136\236\167\132"]=0,["\235\170\169\235\167\136\235\166\132"]=0,["\237\131\136\236\136\152"]=0,["\237\131\128\235\157\189"]=0},
["\236\167\136\235\179\145"]={},
["\235\178\132\237\148\132"]={},
["\235\167\136\235\178\149"]={},
["\236\132\164\236\185\152"]={},
["\236\132\164\236\185\152\235\167\181"]={},
["\235\176\156\234\178\172\235\167\181"]={},
["\236\149\148\234\184\176\235\167\136\235\178\149"]=DefaultSpells or{},
["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149"]=0,
["\235\167\136\235\160\165\235\182\136\236\149\136\236\160\149T"]=0,
["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"]={},
["\235\160\136\236\132\156\237\148\188"]={},
["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"]={},
["\236\158\165\236\176\169\237\134\160\237\133\156"]={},
["\236\160\156\236\158\145\235\178\149"]={},
["\235\137\180\235\160\136\236\132\156\237\148\188"]={},
["\236\154\148\235\166\172\237\154\159\236\136\152"]={},
["\236\158\165\235\185\132\237\139\176\236\150\180"]={},

["\236\160\156\235\160\168\237\154\159\236\136\152"]={},
["\236\160\156\236\158\145"]={},
["\237\154\141\235\147\157\237\154\159\236\136\152"]={},
["\235\182\128\237\153\156"]=0,
["\236\167\144\234\190\188"]={},
["\235\167\129\237\129\172\235\176\169"]={},
maps={};
x=0,
y=0,
a="right",
T=0,
["\237\152\132\236\158\172\235\167\181"]=0,
["\236\157\180\236\160\132\235\167\181"]=0,
["\237\152\132\236\158\172\236\167\128\236\151\173"]=0,
["\237\149\132\235\147\156 \234\176\156\236\136\152"]={},
["\236\138\172\235\161\175"]={},
["\236\158\144\236\155\144"]={},
["\236\131\129\236\158\144\236\158\144\236\155\144"]={},
["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"]={},
["\236\149\132\236\157\180\237\133\156\237\153\149\236\157\184"]={},
["\236\131\129\236\157\184\234\176\128\235\176\169"]={},
["\234\179\160\236\160\149\235\176\169"]={},
["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"]={},
["\236\151\148\236\167\132\235\163\184"]={},
["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"]={},
["\236\178\152\236\185\152\235\179\180\236\138\164"]={},
["\237\148\140\235\158\152\234\183\184"]={},
["\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184"]=0,
["\236\154\169\235\179\128T"]=0,
["\236\151\180\236\135\160\235\178\136\237\152\184"]=0,
["\236\151\176\236\134\141\236\177\132\236\167\145"]=0,
["\236\151\148\235\148\169"]=0,
["\236\151\148\235\148\169\235\179\180\236\131\129"]=0,
["\236\163\188\235\172\184\236\132\156\235\179\181\236\130\172"]={},
["\235\169\148\235\170\168"]={},
["\235\175\184\236\133\152"]={},
["\235\137\180\235\175\184\236\133\152"]={},
["\236\153\132\235\163\140\235\175\184\236\133\152"]={},
["\235\176\155\236\157\128\235\175\184\236\133\152\236\136\152"]={},
["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]={},
["\235\141\152\236\160\132 \236\131\157\236\132\177 \236\160\144\236\136\152"]=0,
};
for k,v in pairs(const("\236\139\156\236\158\145\236\136\152\236\185\152"))do
def[k]=v;
end
for k,v in pairs(const("\236\138\172\235\161\175\235\170\169\235\161\157"))do
def["\236\138\172\235\161\175"][v]=0;
end
if t then
for k,v in pairs(t)do
if def[k]then
def[k]=v;
end
end
end
ClearLookup();
_G._S=UseChecker(def);
buff=_G._S["\235\178\132\237\148\132"];
if newGame then
if newGame=="lobby"then
NewGameForLobby();
else
NewGame();
end
else

BuildMaps();

EquipTotem(buff);
end

local recipetable=safe_require"data.recipetable";
local itemtable=safe_require"data.itemtable";
local witemtable={};
do
for k,v in pairs(itemtable)do







if v["\236\156\160\237\152\149"]=="\236\160\156\236\158\145"or v["\236\156\160\237\152\149"]=="\237\138\185\236\136\152"or v["\236\156\160\237\152\149"]=="\235\147\156\235\158\141"or v["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
witemtable[k]=v;
end
v["\234\183\184\235\163\185"]=ItemGroup(v);
end
for k,v in pairs(witemtable)do

local tier=v["\237\139\176\236\150\180"];
if tier then
if type(tier)=="string"then
if not _S["\236\158\165\235\185\132\237\139\176\236\150\180"][k]then
if string.find(tier," or ")then
local a=string.split(v["\237\139\176\236\150\180"]," or ");
tier=tonumber(table.choice(a));
elseif string.find(tier," ~ ")then
local a=string.split(v["\237\139\176\236\150\180"]," ~ ");
local x,y=tonumber(a[1]),tonumber(a[2]);
local list={};
for i=x,y+0.1,0.5 do
table.insert(list,i);
end
tier=table.choice(list);
end
_S["\236\158\165\235\185\132\237\139\176\236\150\180"][k]=tier;
end
itemtable[k]["\237\139\176\236\150\180"]=_S["\236\158\165\235\185\132\237\139\176\236\150\180"][k];
end
end
end
end

_G.itemtable=compileEval(itemtable,"*");


for k,v in pairs(_G.itemtable)do
v.name=v["name_"..curLang]or v["name_ko"];
v.detail=v["detail_"..curLang]or v["detail_ko"];
end


do
for k,v in pairs(spelltable)do
if string.ends(v["\237\131\128\236\158\133"],"\235\167\136\235\178\149")then
_S["\235\167\136\235\178\149"][k]=_S["\235\167\136\235\178\149"][k]or 0;
end
end
end

for k,v in pairs(recipetable)do
if not v["\235\182\132\235\165\152"]then
for _,building in safe_pairs(v["\237\154\141\235\147\157 \236\139\156\236\132\164 \234\183\184\235\163\185"])do
_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building]=_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building]or{};
if not _S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building][k]then
_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][building][k]=1;
if(_S["\236\132\164\236\185\152"][building]or 0)>0 then
AddRecipe(k);
end
end
end
end
end


do
local _recipetable={};
for guid,v in pairs(recipetable)do
if not _S["\236\160\156\236\158\145\235\178\149"][guid]and v["\235\147\177\234\184\137"]then
_S["\236\160\156\236\158\145\235\178\149"][guid]=_S["\236\160\156\236\158\145\235\178\149"][guid]or{};
if v["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
for kk,vv in pairs(recipetable)do
if vv["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184\236\158\172\235\163\140"and table.find(vv["\236\162\133\235\165\152"],v["\236\162\133\235\165\152"])then
assert(vv["\236\158\172\235\163\140"],guid);
for k,v in safe_pairs(vv["\236\158\172\235\163\140"])do
local k=table.choice(string.split(k,","));
k=table.choice(const(k)or k);
local c=countkcc(v);
if c>0 then
_S["\236\160\156\236\158\145\235\178\149"][guid][k]=(_S["\236\160\156\236\158\145\235\178\149"][guid][k]or 0)+c;
end
end
end
end
for k,v in safe_pairs(v["\236\158\172\235\163\140"])do
local k=table.choice(string.split(k,","));
k=table.choice(const(k)or k);
local c=countkcc(v);
if c>0 then

_S["\236\160\156\236\158\145\235\178\149"][guid][k]=(_S["\236\160\156\236\158\145\235\178\149"][guid][k]or 0)+c;
end
end
else
for k,v in safe_pairs(v["\236\158\172\235\163\140"])do
local k=table.choice(string.split(k,","));
k=table.choice(const(k)or k);
local c=countkcc(v);
if c>0 then
_S["\236\160\156\236\158\145\235\178\149"][guid][k]=(_S["\236\160\156\236\158\145\235\178\149"][guid][k]or 0)+c;
end
end
end
do
_G["recplv"]=_S["\235\160\136\236\132\156\237\148\188"][guid]or 0;
local grade="\236\158\165\235\185\132";
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][guid]then
grade=v["\235\147\177\234\184\137"];
end
local p=ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\158\172\235\163\140\234\176\144\236\134\140");
local np=ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\158\172\235\163\140\234\176\144\236\134\140\235\159\137");
if p>0 then
for k,v in safe_pairs(_S["\236\160\156\236\158\145\235\178\149"][guid])do
local n=countkcc(v);
local s=math.max(1,n-math.floor(n*np));
local c=countkcc({s,1-p,countkcc(v)});
if c>0 then
_S["\236\160\156\236\158\145\235\178\149"][guid][k]=c;
else
_S["\236\160\156\236\158\145\235\178\149"][guid][k]=nil;
end
end
end
_G["recplv"]=nil;
end

do
local p=bf("\236\160\156\236\158\145\236\158\172\235\163\140 \234\176\144\236\134\140 \237\153\149\235\165\160");
local np=bf("\236\160\156\236\158\145\236\158\172\235\163\140 \236\181\156\235\140\128 \234\176\144\236\134\140\235\159\137");
if p>0 then
for k,v in safe_pairs(_S["\236\160\156\236\158\145\235\178\149"][guid])do
local n=countkcc(v);
local s=math.max(1,n-countkcc(n*np));
local c=countkcc({s,1-p,n});
if c>0 then
_S["\236\160\156\236\158\145\235\178\149"][guid][k]=c;
else
_S["\236\160\156\236\158\145\235\178\149"][guid][k]=nil;
end
end
end
end
end

if v["\236\158\165\235\185\132"]then
local t={};
for k,v in pairs(v)do
t[k]=v;
end
for k,v in pairs(_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"])do
if v[guid]then
t["\237\154\141\235\147\157 \236\139\156\236\132\164"]=k;
end
end
if not v["\237\154\141\235\147\157 \236\139\156\236\132\164 \234\183\184\235\163\185"]and(v["\236\156\160\237\152\149"]~="\234\184\176\237\131\128"and v["\236\156\160\237\152\149"]~="\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"and v["\236\156\160\237\152\149"]~="\236\136\152\235\166\172"and v["\236\156\160\237\152\149"]~="\236\149\132\237\139\176\237\140\169\237\138\184")then
t["\237\154\141\235\147\157"]="\234\179\160\236\160\149";
end
t["\236\158\172\235\163\140"]=_S["\236\160\156\236\158\145\235\178\149"][guid]or t["\236\158\172\235\163\140"];
assert(not _recipetable[guid],guid);
_recipetable[guid]=t;
end
end

for k,v in pairs(itemtable)do
if v["\236\156\160\237\152\149"]=="\236\160\156\236\158\145"or v["\236\156\160\237\152\149"]=="\235\147\156\235\158\141"or v["\236\156\160\237\152\149"]=="\237\138\185\236\136\152"then

local guid="\235\185\132\236\160\132_"..k;
local key=v["\236\162\133\235\165\152"];
local t={};
t.guid=guid;
if not _S["\236\160\156\236\158\145\235\178\149"][guid]then
_S["\236\160\156\236\158\145\235\178\149"][guid]=_S["\236\160\156\236\158\145\235\178\149"][guid]or{};
_G["\237\139\176\236\150\180"]=v["\237\139\176\236\150\180"]or 0;
for k,v in pairs(ev("\235\185\132\236\160\132 \236\160\156\236\158\145\235\178\149 \236\158\172\235\163\140"..math.random(1,2)))do
local key=table.choice(string.split(k,","));
local value=countkcc(v);
_S["\236\160\156\236\158\145\235\178\149"][guid][key]=value;
end
_G["\237\139\176\236\150\180"]=nil;
end
assert(v["\237\139\176\236\150\180"],k);
t["\237\131\173"]="\235\185\132\236\160\132 \236\160\156\236\158\145\235\178\149";
t["\236\162\133\235\165\152"]=v["\236\162\133\235\165\152"];
t["\236\158\165\235\185\132"]=k;
t["\236\156\160\237\152\149"]="\235\185\132\236\160\132";
t["\237\139\176\236\150\180"]=v["\237\139\176\236\150\180"];
t["\236\158\172\235\163\140"]=_S["\236\160\156\236\158\145\235\178\149"][guid];
_recipetable[guid]=t;
end
end

for k,v in pairs(_recipetable)do
if v["\237\154\141\235\147\157"]=="\234\179\160\236\160\149"then
_S["\235\160\136\236\132\156\237\148\188"][k]=_S["\235\160\136\236\132\156\237\148\188"][k]or 1;
end
end
_G.recipetable=compileEval(_recipetable,"*");
for k,v in pairs(_G.recipetable)do
v.detail=v["name_"..curLang]or v["name_ko"];
end


_G.recipetabtable={};
for i,tab in pairs(const("\236\160\156\236\158\145\237\131\173\235\170\169\235\161\157"))do
_G.recipetabtable[i]=_G.recipetabtable[i]or{};
for k,v in pairs(_G.recipetable)do
if v["\237\131\173"]and table.find(tab,v["\237\131\173"])then
_G.recipetabtable[i][k]=v;



end
end
end
end

if not newGame then
DeleteInvalidItem();
RecalcItemStorageItems();
end
updateSkill();
end


function SetDebuff(k,b,AP)
AP=AP or 10
if b then
local v=_S["\235\148\148\235\178\132\237\148\132"][k];

_S["\235\148\148\235\178\132\237\148\132"][k]=v+AP;
world.player:addDebuf(k,"\236\131\157\236\161\180");





else
if _S["\235\148\148\235\178\132\237\148\132"][k]>0 then
_S["\235\148\148\235\178\132\237\148\132"][k]=0;
delBuffFromGuid(buff,k);

end
end
end


function SetExtraDebuff(kp,k,b,AP)
local a=_S["\235\148\148\235\178\132\237\148\132"][k];
if b then
if a>0 then

if _S["\235\148\148\235\178\132\237\148\132"][kp]>0 then
_S["\235\148\148\235\178\132\237\148\132"]:add(k,ev("\236\182\148\234\176\128\235\148\148\235\178\132\237\148\132\236\166\157\234\176\128"),nil,nil,ev("\236\182\148\234\176\128\235\148\148\235\178\132\237\148\132\236\166\157\234\176\128\237\139\177"),AP);

end
else

_S["\235\148\148\235\178\132\237\148\132"][k]=ev("\236\182\148\234\176\128\235\148\148\235\178\132\237\148\132\234\184\176\234\176\132");
end
world.player:addDebuf(k,"\236\131\157\236\161\180");
if AP>0 then

end
else
if a>0 then
a=math.max(0,a-AP);
if a<=0 then
delBuffFromGuid(buff,k);
end
_S["\235\148\148\235\178\132\237\148\132"][k]=a;

end
end
end


function HasDebuff(k)
return(_S["\235\148\148\235\178\132\237\148\132"][k]or 0)>0 or buff[k]~=nil;
end


function SetItemBuff(slot,guid)
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]["\235\130\180\234\181\172\235\143\132"]and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]["\235\130\180\234\181\172\235\143\132"]<=0 then
return false;
end

if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]and not IsSubSlot(slot)then
trace("SetItemBuff",slot,guid);
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[data.id];
local tier=ItemTier(guid);

if slot=="\236\152\164\235\165\184\236\134\1441"then
addBuff(buff,"\234\179\181\234\178\169 \234\177\176\235\166\172",guid,item["\234\179\181\234\178\169 \234\177\176\235\166\172"]or 1);
end

if item["\237\154\168\234\179\188"]then
for k,v in pairs(item["\237\154\168\234\179\188"])do
addBuff(buff,k,guid,v);
end
end

if data["\236\152\181\236\133\152"]then
trace(data["\236\152\181\236\133\152"]);
for k,v in pairs(data["\236\152\181\236\133\152"])do
EquipOption(buff,guid.."/"..v.id,v.d);
end
end
end









end

function DelBuff(type)
return delBuffFromType(buff,type);
end

function SetSlotItem(slot,guid)
_S["\236\138\172\235\161\175"][slot]=guid;
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
o["\236\176\169\236\154\169T"]=0;
SetItemBuff(slot,guid);
SetStorageItemBuff(slot,guid);
world.player:checkEquipOption(guid);
updateSkill();
world.player:updateCostume();
end
end

function DelSlotItem(guid)
for k,slot in pairs(GetAvailSlots())do
if _S["\236\138\172\235\161\175"][slot]==guid then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
world.player:checkUnEquipOption(guid);
DelStorageItemBuff(slot,guid);
DelItemBuff(guid);
_S["\236\138\172\235\161\175"][slot]=0;
o["\236\176\169\236\154\169T"]=nil;
updateSkill();
world.player:updateCostume();
return slot;
end
end
end
end

function ResetItemBuff()
for k,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
DelItemBuff(guid);
SetItemBuff(slot,guid);
end
end
updateSkill();
end


function SetStorageItemBuff(slot,guid)
if not table.find(const("\236\167\144\234\190\188\236\138\172\235\161\175\235\170\169\235\161\157"),slot)then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
if not o.pick then
o.pick=1;
end
end
end
end

function DelStorageItemBuff(slot,guid)
delBuffFromGuid(buff,guid);
end

function AddBagItemType(itemId,c,key)

key=key or"\236\158\144\236\155\144";
_S[key][itemId]=(_S[key][itemId]or 0)+(c or 1);

if key=="\236\158\144\236\155\144"then
local item=itemtable[itemId];
if item["\237\154\141\235\147\157"]then
for k,v in pairs(item["\237\154\141\235\147\157"])do
addBuff(buff,k,key.."/"..itemId,v*_S[key][itemId]);
end
end
end
end

function DelBagItemType(itemId,c,key)

key=key or"\236\158\144\236\155\144";
_S[key][itemId]=(_S[key][itemId]or 0)-(c or 1);
if _S[key][itemId]<=0 then
_S[key][itemId]=nil;
delBuffFromGuid(buff,key.."/"..itemId);
else
if key=="\236\158\144\236\155\144"then
local item=itemtable[itemId];
if item["\237\154\141\235\147\157"]then
for k,v in pairs(item["\237\154\141\235\147\157"])do
addBuff(buff,k,key.."/"..itemId,v*_S[key][itemId]);
end
end
end
end
end


function RecalcStorageItems()
_S["\236\158\144\236\155\144"]={};
delBuffFromGuid(buff,"\236\158\144\236\155\144");
local function _run(_guid,isBag)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_guid];
if o then
if isBag then
AddBagItemType(o.id,o.c);
end
if o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if _run(v,true)then
return true;
end
end
end
end
end

for k,slot in pairs(GetAvailStorageSlots())do
_run(_S["\236\138\172\235\161\175"][slot]);
end
end


function DelItemBuff(guid)
for k,slot in pairs(GetAvailSlots())do
if _S["\236\138\172\235\161\175"][slot]==guid then
trace("DelItemBuff",slot,guid);






delBuffFromGuid(buff,guid);
return slot;
end
end
end

function checkCond(key,value)
trace("checkCond",key,value);
if key=="\236\176\169\236\154\169"then
for i,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local item=itemtable[o.id];
if table.find(value,item["\236\162\133\235\165\152"])or table.find(value,const("\235\182\132\235\165\152C",item["\236\162\133\235\165\152"]))then
return true;
end
end
end
trace("checkCond\236\139\164\237\140\168",key,value);
return false;
elseif key=="\236\150\180\235\145\160\236\151\144\236\132\156"or key=="\235\185\155\236\151\144\236\132\156"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local tz=GetTimeZone();
local data=_S.maps[mapId];
local mapType=data["\237\131\128\236\158\133"];
local inLight=world.ground:inTileLight(_S.x,_S.y)or(mapType=="\237\149\132\235\147\156"and tz~=TimeZone_Night);
if key=="\236\150\180\235\145\160\236\151\144\236\132\156"then
return not inLight;
else
return inLight;
end
elseif key=="\237\151\136\234\184\176\236\157\180\237\149\152"then
return _S["\237\151\136\234\184\176"]<=value;
elseif key=="\236\131\157\235\170\133\235\160\165\236\157\180\236\131\129"then
return bf("\236\131\157\235\170\133\235\160\165")>=bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*value;
elseif key=="\236\131\157\235\170\133\235\160\165\236\157\180\237\149\152"then
return bf("\236\131\157\235\170\133\235\160\165")<=bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165")*value;
elseif key=="\237\156\180\236\139\157"then
return world.player:isSleeping();
end
end

function _checkCond(target,cond)
if type(cond)=="table"then
for k,v in pairs(cond)do
if not checkCond(k,v)then
return false;
end
end
else
if not checkCond(cond,true)then
return false;
end
end
return true;
end

function vclamp(type,v)
local t=const("\234\178\189\234\179\132\234\176\146",type);
if t then
v=math.clamp(v,t[1],t[2]);
end
return v;
end


function bfItem(guid,key,source,evOnly)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local a=0;
local v=source or evaltable[key]or 0;
local _;
if o then
local itemId=o.id;
local item=itemtable[itemId];
if key=="\234\179\181\236\134\141"then
local _,_v,_a=GetItemData(itemId,key,1);
v=v/_v;
a=_a;
else
local _,_v,_a=GetItemData(itemId,key);
v=v+_v;
a=_a;
end


v=v+GetItemOptionBuff(o,"\236\149\132\236\157\180\237\133\156 "..key);
v=v+v*(GetItemOptionBuff(o,"\236\149\132\236\157\180\237\133\156 "..key.." \236\166\157\234\176\128")-GetItemOptionBuff(o,"\236\149\132\236\157\180\237\133\156 "..key.." \234\176\144\236\134\140"));

local typeC=const("\235\182\132\235\165\152C",item["\236\162\133\235\165\152"]or"\235\139\168\234\178\128");
if typeC then

a=a+bf(typeC.." "..key,v,true);
end
end
if not evOnly then
a=a+bf(key,v,true);
end

return v+a,v,a;
end


function bfEquipItems(...)
local v,a=0,0;
for k,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local _,_v,_a=bfItem(guid,...);
v=v+_v;
a=a+_a;
end
end
return v+a,v,a;
end




function bf(type,source,buffonly)
local v=source or ev(type)or 0;
if _G.type(v)~="number"then
return v;
else
local add,param=getBuff(buff,type,nil,nil,_checkCond);
if _G.type(add)~="number"then
if param then
return add,param;
else
return add;
end
else
local mul=getBuff(buff,type.." \236\166\157\234\176\128",nil,nil,checkCond)-getBuff(buff,type.." \234\176\144\236\134\140",nil,nil,checkCond);
if AlwaysForceBuff and(add~=0 or mul~=0)then
trace("\235\178\132\237\148\132","type",type,"v",v,"add",add or 0,"mul",mul or 0,"param",param);
end
if buffonly then
if param then
return add+v*mul,param;
else
return add+v*mul;
end
else
if param then
return vclamp(type,v+add+v*mul),param;
else
return vclamp(type,v+add+v*mul);
end
end
end
end
return 0;
end

function const(k,child)
if k~=nil then
local v=consttable[k];
if v~=nil then

if child~=nil and _G.type(v)=="table"then
return v[child];
end
return v;
end
















end

end

function ev(k,child)
local v=_G[k];

if v~=nil then

if child~=nil then return v[child];
else return v;end
end

v=(_S and _S[k])or _D[k];
if v~=nil then

if child~=nil then return v[child];
else return v;end
end

v=_eval(k);
if v~=nil then

if child~=nil then return v[child];
else return v;end
end

if k~=nil then
v=evaltable[k];
if v~=nil then

if child~=nil and _G.type(v)=="table"then
return v[child];
end
return v;

end















end


end


function evItem(k,item)
_item=item;
local v=ev(k);
_item=nil;
return v;
end

function opItem(o,k,item,data)
_item=item;
_data=data;
local v;
if data then
v=data[k];
else
v=o[k];
end
trace("opItem",k,data,v);

_item=nil;
_data=nil;
return v;
end






























local preloadSpine={};
function PreloadSpine()
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local data=_S.maps[mapId];
local mapType=data["\237\131\128\236\158\133"];
local mapTile=data["\234\181\172\236\132\177"];
local area=data["\236\167\128\236\151\173"];
local depth=data["\236\184\181"];
local bpName=data["\236\132\164\234\179\132\235\143\132"];
local prefix=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);

local prev={};
for k,_ in pairs(preloadSpine)do
prev[k]=1;
end

preloadSpine={};
for _,v in pairs(spawntable)do
if table.find(v["\237\131\128\236\158\133"]or mapType,mapType)and
table.find(v["\236\167\128\236\151\173"]or area,area)and
table.find(v["\236\184\181"]or depth,depth)and
(v["\234\181\172\236\132\177"]or mapTile)==mapTile and
(v["\236\132\164\234\179\132\235\143\132"]or bpName)==bpName then
for i=1,9,1 do
local v=monstertable[v["\236\131\157\236\132\177"..i]];
if v and v.spine then
preloadSpine[v.spine]=1;
end
end
end
end

for i=1,2,1 do
local t=ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177"..i,area)or ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177"..i,"\234\184\176\237\131\128");
if t and t[1]then
for id,_ in pairs(t[1])do
local v=monstertable[id];
if v and v.spine then
preloadSpine[v.spine]=1;
end
end
end
end
for k,_ in pairs(preloadSpine)do
assert(spine.loadSkeletonData(
"media/spine/"..k..".json",
"media/spine/"..k..".atlas"
));
end
for k,_ in pairs(prev)do
spine.releaseSkeletonData(
"media/spine/"..k..".json",
"media/spine/"..k..".atlas"
);
end
end


function IsAreaOpened(area)
local c=_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]or 0;
for i=1,c do
local mapId=MapId("\237\149\132\235\147\156",area,i);
local m=_S.maps[mapId];
if not m["\236\151\180\235\166\188"]then
return false;
end
end
return true;
end


function GetAreaOpenFileds(areas)
local list={};
for k,area in safe_pairs(areas)do
local c=_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]or 0;
for i=1,c do
local mapId=MapId("\237\149\132\235\147\156",area,i);
local m=_S.maps[mapId];
if m["\236\151\180\235\166\188"]then
table.insert(list,mapId);
end
end
end
return list;
end

function UpdateRegen(AP)



local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local tz=GetTimeZone();
local tzPrev=GetTimeZone(_S.T-AP);
local mz=GetMoonZone();
local data=_S.maps[mapId];
local area=data["\236\167\128\236\151\173"];
local bpType=data["\236\132\164\234\179\132\235\143\132"];
local areaN=data["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local mapType=data["\237\131\128\236\158\133"];
local prefix=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);
local bp=mapbptable[bpType];

if areaN and not data["\235\179\180\236\138\164\236\184\181"]then




if data.monsterQ and tz~=TimeZone_Night then
for k,v in pairs(data.monsterQ)do
trace("\235\176\164\236\157\128\236\139\160 \235\147\177\236\158\165",v);
CloneMonster(v);
end
data.monsterQ=nil;
end








if mapType=="\237\149\132\235\147\156"then
if not _S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"]then
local T=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].T or 0;
if _S.T>=T+const("\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168\235\147\177\236\158\165")then
local list={};
for k,v in pairs(const("\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168\234\183\184\235\163\185"))do
for _,area in safe_pairs(string.split(k))do
if IsAreaOpened(area)then
table.insert(list,v);
end
end
end
local mapIds=GetAreaOpenFileds(table.choice(list));
local mapId=table.choice(mapIds);
_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"]=mapId;
_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\234\183\184\235\163\185"]=mapIds;
_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].guid=(_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].guid or 0)+1;
end
end
if _S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"]then
_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\237\145\156\236\139\156"]=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\237\145\156\236\139\156"]or{};
if not _S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\237\145\156\236\139\156"][mapId]then
_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\237\145\156\236\139\156"][mapId]=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].guid;
local _mapId=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"];
local maxc=0;
local footprint="\236\152\164\236\154\176\234\177\176 \235\176\156\236\158\144\234\181\173";
if _S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"]==mapId then
maxc=4;
for r1=const("\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168 \235\166\172\236\160\160 \235\178\148\236\156\132",1),1,-1 do
if SpawnMonster(_S.x,_S.y,r1,const("\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168 \235\166\172\236\160\160 \235\178\148\236\156\132",2),"\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168",nil,nil,nil,nil,nil,true)then
break;
end
end

elseif _S.maps[_mapId]["\236\167\128\236\151\173"]==area then
maxc=4;

elseif table.find(_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\234\183\184\235\163\185"],mapId)then
maxc=1;

else

maxc=1;
footprint="\236\152\164\236\154\176\234\177\176 \237\157\144\235\166\176 \235\176\156\236\158\144\234\181\173";
end
local x,y=data.starts.x,data.starts.y;
local L,L2=table.unpack(const("\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168 \235\176\156\236\158\144\234\181\173 \235\178\148\236\156\132"));
local filter=Filter_ItemPlace;
while maxc>0 do
local i,j=world.ground:getRandTileWalkable(x,y,L,L2,x,y,filter);
if not i then
break;
end
L=L+const("\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168 \235\176\156\236\158\144\234\181\173 \235\178\148\236\156\132",1);
L2=L2+const("\236\152\164\236\154\176\234\177\176 \235\143\132\236\160\129\235\139\168 \235\176\156\236\158\144\234\181\173 \235\178\148\236\156\132",1);
local list={};
for _i=i-1,i+1 do
for _j=j-1,j+1 do
if world.ground:canTileWalkable(_i,_j,filter)and not world:hasObject(_i,_j)then
table.insert(list,{_i,_j});
end
end
end
if#list>0 then
local c=math.random(1,math.min(#list,maxc));
for _=1,c do
local idx=math.random(#list);
local i,j=table.unpack(list[idx]);
local o=world:createObject(footprint,i,j,{ogreGuid=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].guid});
table.remove(list,idx);
end
end
end
end
end
end


for i,v in ipairs(const("\235\170\172\236\138\164\237\132\176\235\166\172\236\160\160\235\170\169\235\161\157"))do

local maxC=(data["regenS"..v]or 0)+(bp[v.." \235\166\172\236\160\160 \236\181\156\235\140\128"]or const(v.." \235\166\172\236\160\160 \236\181\156\235\140\128"));
local regenC=data["regenC"..v]or 0;
local tzs=const(v.." \235\166\172\236\160\160 \236\139\156\234\176\132\235\140\128");
if regenC+1<=maxC and(not tzs or table.find(tzs,tz))then
if not data["regenT"..v]then
local dur;
local regenTB;
if mapType=="\237\149\132\235\147\156"then
regenTB=const(string.format("\237\149\132\235\147\156 %s \235\166\172\236\160\160 \236\139\156\234\176\132",v));
else
regenTB=const(string.format("\235\141\152\236\160\132 %s \235\166\172\236\160\160 \236\139\156\234\176\132",v));
end
if const(v.." \235\166\172\236\160\160 \236\139\156\234\176\132\236\136\152",2)<=regenC then
elseif const(v.." \235\166\172\236\160\160 \236\139\156\234\176\132\236\136\152",1)<=regenC then
dur=regenTB[2];
else
dur=regenTB[1];
end
data["regenT"..v]=countkcc(dur);
end
data["regenT"..v]=data["regenT"..v]-AP/bf(v.." \235\166\172\236\160\160 \236\139\156\234\176\132",1);
if data["regenT"..v]<=0 then
data["regenT"..v]=nil;
local id=v;
if math.randpercent(const(v.." \235\179\180\235\172\188\236\130\172\235\131\165\234\190\188\237\153\149\235\165\160"))then
local c=0;
for k,v in pairs(data.npcs)do
if v.id=="\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188"then
c=c+1;
end
end
if c<const("\235\179\180\235\172\188\236\130\172\235\131\165\234\190\188\236\181\156\235\140\128")then

local mouseHole=0;
for k,v in pairs(data.objects)do
if v.id=="\236\167\144\236\138\185 \234\181\180"then
mouseHole=mouseHole+1;
end
end
if mouseHole>0 then
id="\235\179\180\235\172\188 \236\130\172\235\131\165\234\190\188";
end
end
end
local guid,_,npc=SpawnMonster(_S.x,_S.y,const(v.." \235\166\172\236\160\160 \235\178\148\236\156\132",1),const(v.." \235\166\172\236\160\160 \235\178\148\236\156\132",2),id);
if guid then
if math.randpercent(const(v.." \235\166\172\236\160\160 \234\178\189\234\179\132\237\153\149\235\165\160"))then
npc:changeMode("\234\178\189\234\179\132",world.player);
end
npc.sdata.regenC=v;
npc.sdata.regenM=_S["\237\152\132\236\158\172\235\167\181"];
data["regenC"..v]=regenC+1;
end
end
end
end







if tzPrev~=tz then
for i,v in ipairs(world.characs)do
if not v.dying then
v:onTimeZone(tz);
end
end
end

for i=1,2,1 do
if table.find(ev(prefix.."\235\170\172\236\138\164\237\132\176\236\131\157\236\132\177\236\139\156\234\176\132\235\140\128"..i),tz)then
local key="regenNT"..i;
local c=data["regenCN"..i]or 0;
local t=ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177"..i,area)or ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177"..i,"\234\184\176\237\131\128");
local p=ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\237\153\149\235\165\160"..i,area)or ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\237\153\149\235\165\160"..i,"\234\184\176\237\131\128");
if t and c<(t[2]or 0)and math.randpercent(p)then
data[key]=data[key]or countkcc(ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177\236\139\156\234\176\132"..i));
data[key]=data[key]-AP/bf("\235\170\172\236\138\164\237\132\176 \235\166\172\236\160\160 \236\139\156\234\176\132",1);
if data[key]<=0 then
data[key]=nil;
local id=math.randlist(t[1]);
if id then
local R1,R2=table.unpack(ev(prefix.."\235\170\172\236\138\164\237\132\176\236\182\148\234\176\128\236\131\157\236\132\177\234\177\176\235\166\172"..i));
local guid,_,npc=SpawnMonster(_S.x,_S.y,R1,R2,id,nil,nil,nil,true);
if guid then
npc.sdata.regenC="N"..i;
npc.sdata.regenM=_S["\237\152\132\236\158\172\235\167\181"];
data["regenCN"..i]=(data["regenCN"..i]or 0)+1;
end
end
end
end
end
end



end



end

function PlayMapBgm(id,wait,T)
local bp;
local f;
if id then
bp=mapbptable[id];
else
bp=mapbptable[_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\132\164\234\179\132\235\143\132"]];
f=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\184\181"];
end
local bgm;
local tz=GetTimeZone(T);
local list={};
if tz<=2 then
list={bp.bgm2 or bp.bgm1,bp.bgm4 or bp.bgm3};
else
list={bp.bgm1,bp.bgm3};
end

local function find(t)
if type(t)=="table"and f then
for k,v in pairs(t)do
local keys=string.split(k,"~");
keys[1]=tonumber(keys[1]);
keys[2]=tonumber(keys[2]);
if f>=keys[1]and f<=keys[2]then
return table.choice(v);
end
end
end
return table.choice(t);
end

for k,v in pairs(list)do
list[k]=find(v);
end
bgm=table.choice(list);

PlayBGM(bgm,true,nil,wait or 0.5);
end

function UpdateGameT(AP)
local day=GetDay(_S.T);
_S.T=_S.T+AP;
local newDay=GetDay(_S.T)-day;
if newDay>0 then
AddScore(ev("\235\170\168\237\151\152\236\160\144\236\136\152\236\166\157\234\176\128","\236\131\157\236\161\180\235\130\160\236\167\156")*newDay);
Mission("\236\131\157\236\161\180",newDay);
UpdateMission();
_D["\236\152\164\237\148\136\236\167\129\236\151\133"][_S["\236\167\129\236\151\133"]]=math.max(_D["\236\152\164\237\148\136\236\167\129\236\151\133"][_S["\236\167\129\236\151\133"]]or 0,day+newDay+1);
local function cb()
end
CheckNewJob(world,cb);
end
end

function UpdateGame(AP)
trace("UpdateGame",AP);
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local data=_S.maps[mapId];
local inField=IsInField();
UpdateGameT(AP);






do
data.T=data.T or _S.T;
do

if data["\235\167\181 \235\160\136\235\178\168"]<_S["\235\160\136\235\178\168"]then
local lvUp=math.floor(_S.T/ev("\235\167\181\235\160\136\235\178\168\236\166\157\234\176\128\237\139\177"))-math.floor(data.T/ev("\235\167\181\235\160\136\235\178\168\236\166\157\234\176\128\237\139\177"));
if lvUp>0 then
data["\235\167\181 \235\160\136\235\178\168"]=math.min(_S["\235\160\136\235\178\168"],data["\235\167\181 \235\160\136\235\178\168"]+lvUp);
end
end
end
do
local dt=_S.T-data.T;
if dt>0 then
for _,k in pairs(table.savedkeys(world.objects))do
local v=world.objects[k];
if not v.dying then
v:onResetTurn(dt);
end
end
if inField then
UpdateWeather(dt);
end
end

















data.T=_S.T;
end

if inField then
world:updateWeather();
end
end

do
local tz=GetTimeZone();
if GetTimeZone(_S.T-AP)~=tz then
if tz==TimeZone_Night or tz==TimeZone_Day then
PlayMapBgm(nil,15);
elseif tz==TimeZone_Morning then
if inField and _S["\237\154\131\235\182\136\235\170\168\235\147\156"]=="\237\154\131\235\182\136"then
world.ui.menu["\237\154\131\235\182\136\235\170\168\235\147\156"]:onClick();
end
end
end
end


for k,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local fire;
if string.starts(slot,"\236\130\176\236\150\145")then
for guid,_ in safe_pairs(_S["\236\167\144\234\190\188"])do
if _S["\236\167\144\234\190\188"][guid]then
fire=world:findCharac(guid):hasBuff("\235\182\136\235\182\153\236\157\140");
break;
end
end
else
fire=world.player:hasBuff("\235\182\136\235\182\153\236\157\140");
end
UpdateItem(guid,ev("\234\184\176\236\152\168"),AP,fire);
end
end

if HasTorch()then
_S["\237\154\131\235\182\136T"]=_S["\237\154\131\235\182\136T"]-AP/(1+bf("\237\154\131\235\182\136 \236\139\156\234\176\132 \236\166\157\234\176\128"));
if _S["\237\154\131\235\182\136T"]<=0 then
if(_S["\236\158\144\236\155\144"]["\237\154\131\235\182\136"]or 0)>0 then
ConsumeItemType("\237\154\131\235\182\136");
Mission("\236\130\172\236\154\169",1,"\237\154\131\235\182\136");
_S["\237\154\131\235\182\136T"]=spelltable[itemtable["\237\154\131\235\182\136"]["\236\130\172\236\154\169"]]["\236\167\128\236\134\141\236\139\156\234\176\132"];
else
DelTorch();
end
end
end


if IsInField()then
for i=1,AP/const("\237\149\156\237\132\180")do
local thunderP=const("\235\178\136\234\176\156\237\153\149\235\165\160",data["\235\130\160\236\148\168"]or"\234\184\176\235\179\184");
if math.randpercent(thunderP)then
local function query(o)
if o.dying then
return false;
end
return true;
end
local _,players=world.grid:QueryR(_S.x,_S.y,MAP_W,query);
if players then
local needDmg=true;
for k,v in pairs(players)do
if v.sdata.id=="\237\148\188\235\162\176\236\185\168"then
v.sdata.lightninglod=(v.sdata.lightninglod or 0)+1;
needDmg=false;
break;
end
end
if needDmg then
target=table.choice(players);
world:thunder(target);
if target.addDamage then
local maxHP;
if target.isObject then
maxHP=target.tb.HP;
else
maxHP=target:bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
end
if maxHP then
local dmg=maxHP*countkcc(const("\235\178\136\234\176\156\235\141\176\235\175\184\236\167\128"))/100;
if target.addDebuf then
target:addDebuf("\236\138\164\237\132\180","\235\178\136\234\176\156");
end
target:addDamage(nil,dmg,{["\235\141\176\235\175\184\236\167\128 \237\131\128\236\158\133"]="\236\160\132\234\184\176"},"\235\178\136\234\176\156");
end
end

if target.impact then
target:impact("\235\178\136\234\176\156");
end
end
end
end
end
end

do
local ids,cnt=MakeRelic(false);
if cnt>0 then
local mc=showPopup(world,"\234\178\140\236\158\132\236\152\164\235\178\132\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
mc.title:SetText(string.format(_L("\234\178\140\236\158\132\236\152\164\235\178\132\236\131\157\236\161\180\236\157\188"),GetDay()+1,_S["\235\160\136\235\178\168"]));
mc:SetZOrder(_Z.MaxZOrder);
local function f()
mc.btnOk:SetVisible(true);
SetTextButton(mc.btnOk,_L("\237\153\149\236\157\184")).onClick=function()
mc:Remove();
end
end
ShowRelic(mc,ids,true,f);
end
end
end

function setDirty()
if world then world:setDirty();end
userDB.SetDirty();
end

function MakeGuid(prefix)
local guid=_S["\234\179\160\236\156\160\235\178\136\237\152\184"];
prefix=prefix or"g";
_S["\234\179\160\236\156\160\235\178\136\237\152\184"]=guid+1;
return string.format("%s%d",prefix,guid);
end


local function makeItemTierList(t,tier)
if tier then
local function priority(a)
assert(itemtable[a]["\237\139\176\236\150\180"],a);
return math.abs(itemtable[a]["\237\139\176\236\150\180"]-tier);
end
table.sort(t,function(a,b)return(priority(a)<priority(b))end);
local _t={t[1]};
for i=2,#t,1 do
if priority(t[1])==priority(t[i])then
table.insert(_t,t[i]);
else
break;
end
end
return _t;
else
return t;
end
end

function ChoiceItemTier(t)
local v=math.randrange(0,t["\234\184\176\235\179\184"]);
if math.random()<t["\236\182\148\234\176\128 \237\153\149\235\165\160"]then
local v2=math.randrange(0,t["\234\184\176\235\179\184"]);
if math.abs(t["\234\184\176\236\164\128"]-v2)<math.abs(t["\234\184\176\236\164\128"]-v)then
v=v2;
end
end
tier=totiernumber(v);
return tier;
end


function ChoiceMapTierItem(types,group,tier,areaN)
trace("ChoiceMapTierItem",types,group,tier,areaN);
local list={};
for kk,vv in pairs(itemtable)do
if table.find(types,vv["\236\156\160\237\152\149"])then
if(vv["\235\147\156\235\158\141\234\176\128\235\138\165"]or 1)>0 then
local t2=drop2table[vv["\236\162\133\235\165\152"]];
if t2 and table.find(group,t2["\234\183\184\235\163\185"])then
local p=(t2["\236\167\128\236\151\173"..areaN]or t2["\236\167\128\236\151\173 \236\160\132\236\178\180"]or 0);
if p>0 then
list[kk]=p;
end
end
end
end
end
local t={};
for k,v in pairs(list)do
table.insert(t,k);
end
t=makeItemTierList(t,tier);
trace("makeItemTierList",tier,t);
local list2={};
for i,v in pairs(t)do
list2[v]=list[v];
end
return math.randlist(list2);
end



local function MakeItemFromId(id,t)
local guid=MakeGuid();
local o=t or{};
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local areaN=_S.maps[mapId]["\236\167\128\236\151\173 \235\178\136\237\152\184"]or 0;
local fragments={{"\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149","\236\149\132\237\139\176\237\140\169\237\138\184"},{"\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149",{"\236\160\156\236\158\145","\237\138\185\236\136\152"}}};
trace("MakeItemFromId",id,t);
for k,v in pairs(fragments)do
if o.id==v[1]then
o.recipe=id;
id=o.id;
elseif id==v[1]then
local list={};
for k,v in pairs(drop1table)do
if v["\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149 \236\151\172\235\182\128"]then
list[k]=v[mapType]or v["\234\184\176\237\131\128 \235\141\152\236\160\132"];
end
end
trace("\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149 \235\170\169\235\161\157",list);
local group=math.randlist(list);
o.recipe=ChoiceMapTierItem(v[2],group,o["\237\139\176\236\150\180"],areaN);
o["\237\139\176\236\150\180"]=itemtable[o.recipe]["\237\139\176\236\150\180"];
assert(o.recipe,list,group,areaN,id,t);
end
end


if id=="\235\167\136\235\178\149\236\177\133"then
o["\235\167\136\235\178\149"]=ChoiceBookSpell();
end


local item=itemtable[id];
o.id=id;

if not item["\235\136\132\236\160\129"]then
o.m=mapId;
end

if item["\235\179\180\234\180\128 \234\184\176\234\176\132"]then
o.T=0;
end

if item["\236\182\169\236\160\132"]then
o.T=0;
o["\236\182\169\236\160\132"]={item["\236\182\169\236\160\132"][3]or item["\236\182\169\236\160\132"][1],item["\236\182\169\236\160\132"][1]};
end

if item["\236\154\169\235\159\137"]then
o["\236\154\169\235\159\137"]={item["\236\154\169\235\159\137"],item["\236\154\169\235\159\137"]};
end

if item["\236\162\133\235\165\152"]=="\236\167\128\237\140\161\236\157\180"and(o["\235\147\177\234\184\137"]=="\235\160\136\236\150\180"or o["\235\147\177\234\184\137"]=="\236\149\132\237\139\176\237\140\169\237\138\184")then
local list={};
for k,v in pairs(spelltable)do
if v["\237\131\128\236\158\133"]=="\235\167\136\235\178\149"and v["\235\139\168\234\179\132"]==1 then
table.insert(list,k);
end
end
o.T=0;
o["\235\167\136\235\178\149"]=table.choice(list);
o["\236\182\169\236\160\132"]={const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\181\156\235\140\128"),const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\181\156\235\140\128")};
end

if item["\236\162\133\235\165\152"]=="\236\151\180\236\135\160"then
o["A"]=_S["\236\151\180\236\135\160\235\178\136\237\152\184"];
_S["\236\151\180\236\135\160\235\178\136\237\152\184"]=_S["\236\151\180\236\135\160\235\178\136\237\152\184"]+1;
end

if cooktable[o.id]then

SetCookData(o);
end

_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]=o;
return guid,_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
end



function MakeItem(group,from,filterIds)
from=from or"\236\157\188\235\176\152";
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local areaN=_S.maps[mapId]["\236\167\128\236\151\173 \235\178\136\237\152\184"];
local forceRare=false;
local forceArtifact=false;
local forceArtifactFragment=false;
local forceFragment=false;
local forceBlessed=false;
local forceCursed=false;
local prifixt={"\235\160\136\236\150\180_","\236\149\132\237\139\176\237\140\169\237\138\184_","\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149_","\236\182\149\235\179\181_","\236\160\128\236\163\188_","\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149_"};
for i,k in ipairs(prifixt)do
if string.starts(group,k)then
if i==1 then
forceRare=true;
elseif i==2 then
forceArtifact=true;
elseif i==3 then
forceArtifact=true;
forceArtifactFragment=true;
elseif i==4 then
forceBlessed=true;
elseif i==5 then
forceCursed=true;
elseif i==6 then
forceFragment=true;
end
group=string.sub(group,string.len(k)+1);
end
end
forceArtifact=forceArtifact or math.randpercent(ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \236\149\132\237\139\176\237\140\169\237\138\184\235\147\156\235\158\141\236\156\168_"..from)or 0);
local drop;
local key;
if drop1table[group]then
if itemtable[group]then
key=group;
else
local list2={};
for k,v in pairs(drop2table)do
if v["\234\183\184\235\163\185"]==group then
list2[k]=v[from]or v["\236\167\128\236\151\173"..tostring(areaN)]or v["\236\167\128\236\151\173 \236\160\132\236\178\180"];
end
end
if filterIds and table.length(list2)>#filterIds then
for i,v in pairs(filterIds)do
list2[v]=nil;
end
end
key=math.randlist(list2);
end
elseif drop2table[group]then
key=group;
group=drop2table[group]["\234\183\184\235\163\185"];
assert(key,group);
elseif itemtable[group]then
key=group;
group=itemtable[key]["\234\183\184\235\163\185"];
elseif const(group)then
key=table.choice(const(group));
group=itemtable[key]["\234\183\184\235\163\185"];
else
assert(false,"\234\183\184\235\163\185\236\152\164\235\165\152",tostring(group));
end
drop=drop1table[group];
isMake=string.ends(from,"\236\160\156\236\158\145");
isDrop=drop and not isMake;
local o={};

if key then
local tier=nil;
if drop["\237\139\176\236\150\180 \236\134\141\236\132\177 \236\151\172\235\182\128"]then

do
local t=ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \237\139\176\236\150\180 \234\178\176\236\160\149_"..(drop["\237\139\176\236\150\180 \234\178\176\236\160\149"]or from))or ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \237\139\176\236\150\180 \234\178\176\236\160\149_\236\157\188\235\176\152");
assert(t,from);
trace("\237\139\176\236\150\180 \234\178\176\236\160\149",t,from,tier);
tier=ChoiceItemTier(t);
end
end
if not itemtable[key]then
assert(drop,tostring(group)..tostring(key));
local t={};
for k,v in pairs(itemtable)do
if v["\236\162\133\235\165\152"]==key and v["\236\156\160\237\152\149"]then
if(forceArtifact and v["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184")or(not forceArtifact and v["\236\156\160\237\152\149"]~="\236\149\132\237\139\176\237\140\169\237\138\184")then
if(v["\235\147\156\235\158\141\234\176\128\235\138\165"]or 1)>0 then
table.insert(t,k);
end
end
end
end
if filterIds and table.length(t)>#filterIds then
for i,v in pairs(filterIds)do
t[v]=nil;
end
end
if tier then
if not forceArtifact then
t=makeItemTierList(t,tier);
end
end
assert(t[1],key);
key=table.choice(t);
end

local item=itemtable[key];
o["\237\139\176\236\150\180"]=item["\237\139\176\236\150\180"]or tier;
if item["\236\181\156\236\134\140\237\139\176\236\150\180"]then
o["\237\139\176\236\150\180"]=math.max(o["\237\139\176\236\150\180"],item["\236\181\156\236\134\140\237\139\176\236\150\180"]);
end
_G["\237\139\176\236\150\180"]=o["\237\139\176\236\150\180"];
if forceArtifactFragment then
o.id="\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149";
elseif forceFragment then
o.id="\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149";
end
trace("o",o);

if from=="\236\160\156\236\158\145"and drop["\236\158\165\235\185\132 \236\134\141\236\132\177 \236\151\172\235\182\128"]then
local recipe=recipetable[key];
local grade="\236\158\165\235\185\132";
if item["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
grade=item["\236\156\160\237\152\149"];
end
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][key]then
grade=recipe["\235\147\177\234\184\137"];
end
trace("\236\160\156\236\158\145",grade,_G.recplv);
local a,b,c=table.unpack(ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \234\176\149\237\153\148 \236\136\152\236\185\152"));
local rareP=ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \235\160\136\236\150\180 \237\153\149\235\165\160");
rareP=bf("\236\160\156\236\158\145\236\139\156 \235\160\136\236\150\180 \236\149\132\236\157\180\237\133\156 \237\153\149\235\165\160",rareP);
a=bf("\236\160\156\236\158\145\236\139\156 \234\176\149\237\153\148 \234\184\176\235\179\184",a);
b=bf("\236\160\156\236\158\145\236\139\156 \234\176\149\237\153\148 \237\153\149\235\165\160",b);
c=bf("\236\160\156\236\158\145\236\139\156 \234\176\149\237\153\148 \236\181\156\235\140\128",c);
if item["\236\162\133\235\165\152"]then
a=bf(item["\236\162\133\235\165\152"].." \234\176\149\237\153\148 \234\184\176\235\179\184",a);
b=bf(item["\236\162\133\235\165\152"].." \234\176\149\237\153\148 \237\153\149\235\165\160",b);
c=bf(item["\236\162\133\235\165\152"].." \234\176\149\237\153\148 \236\181\156\235\140\128",c);
rareP=bf(item["\236\162\133\235\165\152"].." \235\160\136\236\150\180 \236\149\132\236\157\180\237\133\156 \237\153\149\235\165\160",rareP);
end
local b2=bf("\236\160\156\236\158\145\236\139\156 \236\182\148\234\176\128 \234\176\149\237\153\148 \237\153\149\235\165\160");
local lv=countkcc({0,b2,1})+countkcc({a,b,c})-countkcc(ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\157\140\236\136\152\234\176\149\237\153\148 \236\136\152\236\185\152"));
if lv~=0 then
o["\234\176\149\237\153\148"]=lv;
end
if math.randpercent((1+rareP)*(item["\235\160\136\236\150\180 \237\153\149\235\165\160"]or 0))then
o["\235\147\177\234\184\137"]="\235\160\136\236\150\180";
else
o["\235\147\177\234\184\137"]="\235\133\184\235\167\144";
end
if o["\235\147\177\234\184\137"]=="\235\160\136\236\150\180"then
o["\234\176\149\237\153\148"]=(o["\234\176\149\237\153\148"]or 0)+countkcc(ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \235\160\136\236\150\180\234\176\149\237\153\148 \235\179\180\235\132\136\236\138\164"));
end
o["\235\130\180\234\181\172\235\143\132"]=const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132");
elseif from=="\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\236\158\145"then
o["\235\147\177\234\184\137"]="\236\149\132\237\139\176\237\140\169\237\138\184";





elseif isDrop and HasDurability(key)then
local t=ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \235\130\180\234\181\172\235\143\132 \234\178\176\236\160\149_"..from)or ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \235\130\180\234\181\172\235\143\132 \234\178\176\236\160\149_\236\157\188\235\176\152");
local s=math.randlist(t);
local l,r=string.match(s,"_(%d+)_(%d+)");
local v=math.random(l,r);
o["\235\130\180\234\181\172\235\143\132"]=math.floor(v);
end

if isDrop and drop["\236\158\165\235\185\132 \236\134\141\236\132\177 \236\151\172\235\182\128"]then

if drop["\236\158\165\235\185\132 \234\176\149\237\153\148 \236\151\172\235\182\128"]then
local t=ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \234\176\149\237\153\148 \234\178\176\236\160\149");
local list={};
for k,v in pairs(t)do
if not v["\236\167\128\236\151\173"]or(areaN and v["\236\167\128\236\151\173"]>=areaN)then
list[k]=v["\237\153\149\235\165\160"];
end
end
local v=tonumber(math.randlist(list,100)or 0);
o["\234\176\149\237\153\148"]=math.floor(v);
end


do
local t=ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \235\160\136\236\150\180\237\153\149\235\165\160_"..from)or ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \235\160\136\236\150\180\237\153\149\235\165\160_\236\157\188\235\176\152");
if item["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
o["\235\147\177\234\184\137"]="\236\149\132\237\139\176\237\140\169\237\138\184";
elseif forceRare or math.randpercent((1+t)*(item["\235\160\136\236\150\180 \237\153\149\235\165\160"]or 0))then
o["\235\147\177\234\184\137"]="\235\160\136\236\150\180";
else
o["\235\147\177\234\184\137"]="\235\133\184\235\167\144";
end
end

if drop["\236\158\165\235\185\132 \234\176\149\237\153\148 \236\151\172\235\182\128"]then
local t=ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \234\176\149\237\153\148 \235\179\180\235\132\136\236\138\164 \234\178\176\236\160\149_"..from)or ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \234\176\149\237\153\148 \235\179\180\235\132\136\236\138\164 \234\178\176\236\160\149_\236\157\188\235\176\152");
local v=(math.randlist(t)or 0)+countkcc(ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \234\176\149\237\153\148 \235\179\180\235\132\136\236\138\164 \234\178\176\236\160\149_\235\147\177\234\184\137\235\179\132",o["\235\147\177\234\184\137"]));
if v>=1 then
o["\234\176\149\237\153\148"]=(o["\234\176\149\237\153\148"]or 0)+tonumber(v);
end
end


end

local itemGuid,o=MakeItemFromId(key,o);
trace("drop",key,drop);
if drop and drop["\236\182\149\235\179\181 \236\160\128\236\163\188 \236\151\172\235\182\128"]then
if forceBlessed then
AddItemOption(nil,itemGuid,"\236\182\149\235\179\181");
elseif forceCursed then
AddItemOption(nil,itemGuid,"\236\160\128\236\163\188");
else
local prefix;
if isDrop then
prefix="\235\147\156\235\161\173";
elseif _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][key]then
prefix="\235\189\145\234\184\176";
else
prefix="\236\158\165\235\185\132";
end
local t=ev(prefix.."\236\149\132\236\157\180\237\133\156 \236\182\149\235\179\181 \236\160\128\236\163\188 \234\178\176\236\160\149");
if prefix=="\235\189\145\234\184\176"then
t=t[recipetable[key]["\235\147\177\234\184\137"]];
end
local v=math.randlist(t,100);
if v then
AddItemOption(nil,itemGuid,v);
end
end
end

if item["\234\184\176\235\179\184 \236\152\181\236\133\152"]then
for k,v in ipairs(item["\234\184\176\235\179\184 \236\152\181\236\133\152"])do
AddItemOption(nil,itemGuid,v);
end
end

if item.storage then
local tb=const("\234\176\128\235\176\169\236\185\184\234\178\176\236\160\149_"..from)or const("\234\176\128\235\176\169\236\185\184\234\178\176\236\160\149_\236\157\188\235\176\152");
local cnt=tonumber(math.randlist(tb[key])or item.storage.count);
trace("\234\176\128\235\176\169\236\185\184",from,tb[key],cnt);
o["\234\176\128\235\176\169"]={};
for i=1,cnt,1 do
o["\234\176\128\235\176\169"][i]=0;
end
end








if o["\235\147\177\234\184\137"]then
local c=const(item["\236\162\133\235\165\152"].." \235\147\177\234\184\137\235\179\132 \236\152\181\236\133\152 \234\176\156\236\136\152",o["\235\147\177\234\184\137"])or const("\235\147\177\234\184\137\235\179\132 \236\152\181\236\133\152 \234\176\156\236\136\152",o["\235\147\177\234\184\137"]);
trace("\235\147\177\234\184\137\235\179\132 \236\152\181\236\133\152 \234\176\156\236\136\152",c,o);
for i=1,c[1],1 do
AddItemOption(nil,itemGuid,0);
end
end

if drop and drop["\235\175\184\237\153\149\236\157\184 \236\151\172\235\182\128"]then
local prefix;
if isDrop then
prefix="\235\147\156\235\161\173";
elseif _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][key]then
prefix="\235\189\145\234\184\176";
else
prefix="\236\158\165\235\185\132";
end
_G["\235\160\136\236\150\180\235\143\132"]=const("\235\160\136\236\150\180\235\143\132")[o["\235\147\177\234\184\137"]or"\235\133\184\235\167\144"]or 0;
if HasItemOption(itemGuid,"\236\182\149\235\179\181")or HasItemOption(itemGuid,"\236\160\128\236\163\188")then
o["\235\175\184\237\153\149\236\157\184"]=math.randpercent(ev(prefix.."\236\149\132\236\157\180\237\133\156 \235\175\184\237\153\149\236\157\184 \234\178\176\236\160\149_\236\182\149\235\179\181\236\160\128\236\163\188"));
elseif(o["\234\176\149\237\153\148"]or 0)>0 or(o["\236\152\181\236\133\152"]and#o["\236\152\181\236\133\152"]>0)then
o["\235\175\184\237\153\149\236\157\184"]=math.randpercent(ev(prefix.."\236\149\132\236\157\180\237\133\156 \235\175\184\237\153\149\236\157\184 \234\178\176\236\160\149_\234\176\149\237\153\148"));
else
o["\235\175\184\237\153\149\236\157\184"]=math.randpercent(ev(prefix.."\236\149\132\236\157\180\237\133\156 \235\175\184\237\153\149\236\157\184 \234\178\176\236\160\149"));
end

if o["\235\175\184\237\153\149\236\157\184"]then
if drop["\236\158\165\235\185\132 \236\134\141\236\132\177 \236\151\172\235\182\128"]and math.randpercent(bf("\236\149\132\236\157\180\237\133\156 \236\139\157\235\179\132 \237\153\149\235\165\160"))then
o["\235\175\184\237\153\149\236\157\184"]=false;
elseif item["\236\162\133\235\165\152"]and math.randpercent(bf(item["\236\162\133\235\165\152"].." \236\139\157\235\179\132 \237\153\149\235\165\160"))then
o["\235\175\184\237\153\149\236\157\184"]=false;
end
end

if not o["\235\175\184\237\153\149\236\157\184"]then
o["\235\175\184\237\153\149\236\157\184"]=nil;
end
_G["\235\160\136\236\150\180\235\143\132"]=nil;
end
_G["\237\139\176\236\150\180"]=nil;
return itemGuid,o;
end
end

function MapName(mapId,isPortal)
local m=mapId and _S.maps[mapId];
if m then
local mapType=m["\237\131\128\236\158\133"];
local area=m["\236\167\128\236\151\173"];
local field=m["\237\149\132\235\147\156"];
local mapIdx=m["\235\178\136\237\152\184"];
local depth=m["\236\184\181"];
local bp=m["\236\132\164\234\179\132\235\143\132"];
if m["\236\176\189\234\179\160"]then
return objecttable[m["\236\176\189\234\179\160"]].name;
elseif mapType=="\237\149\132\235\147\156"then
if bp=="\236\151\134\236\157\140"or _S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]==1 then
return mapbptable[area].name;
else
local t=mapbptable[bp];
return string.format("%s-%d",t.name,field);
end
elseif mapType=="\236\149\132\236\167\128\237\138\184"then
return _L("\236\149\132\236\167\128\237\138\184");
elseif depth then
if isPortal then
return string.format(_L("\235\141\152\236\160\132\236\158\133\234\181\172"),mapbptable[bp].name);
else
local tb=mapbptable[bp];
if tb["\236\184\181\236\136\152"]==1 then
return tb.name;
else
local dict={};
dict["%%s"]=tb.name;
dict["%%d"]=depth;
return ReplaceString(_L("\235\141\152\236\160\132\236\184\181"),dict);
end
end
end
else
return"??";
end
end

function MapLevel(fromMap,type,area,field,key,depth)
if type=="\236\149\132\236\167\128\237\138\184"then
return 0;
end
if not fromMap then
local tb=maptable[area];
return tb["\237\149\132\235\147\156 \235\160\136\235\178\168"][1]+tb["\237\149\132\235\147\156 \235\160\136\235\178\168"][2]*(field-1);
else
local lv=_S.maps[fromMap]["\235\167\181 \235\160\136\235\178\168"];
_G["\237\149\132\235\147\156 \235\160\136\235\178\168"]=lv;
_G["\236\167\128\236\151\173"]=area;
_G["\236\184\181\236\136\152"]=depth or 1;
lv=ev(key.." \235\160\136\235\178\168")or ev(type.." \235\160\136\235\178\168");
if _G.type(lv)=="table"then
lv=lv[key];
assert(lv,type,key);
end
if _G.type(lv)=="table"then
lv=lv[depth]or lv[#lv];
end

_G["\237\149\132\235\147\156 \235\160\136\235\178\168"]=nil;
_G["\236\167\128\236\151\173"]=nil;
_G["\236\184\181\236\136\152"]=nil;
return lv;
end
end


function GetRequireRecipeBuilding(k)
local req;
local tb=recipetable[k];
assert(tb,k);
if tb["\236\160\156\236\158\145 \237\154\141\235\147\157"]then
local ok=true;
for k,n in pairs(tb["\236\160\156\236\158\145 \237\154\141\235\147\157"])do
local c=_D["\236\162\133\235\165\152\235\179\132\236\160\156\236\158\145\237\154\159\236\136\152"][k]or 0;
if c<n then
req=req or{};
req[k]=n-c;
end
end
end
return req;
end

function AddRecipe(guid)
trace("AddRecipe",guid);
if(_S["\235\160\136\236\132\156\237\148\188"][guid]or 0)==0 then
_S["\235\160\136\236\132\156\237\148\188"][guid]=1;
return true;
end
end


function AddItemOption(cb,guid,opid,type,rune)
rune=rune or"\237\152\188\235\143\136";
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[data.id];
trace("AddItemOption",guid,opid,item["\236\162\133\235\165\152"]);

if(opid or 0)==0 then
if not type then
local t;
if HasItemOption(guid,"\236\182\149\235\179\181")then
t=ev("\236\182\149\235\179\181\236\152\181\236\133\152\236\157\152 \234\179\132\236\151\180 \234\178\176\236\160\149");
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
t=ev("\236\160\128\236\163\188\236\152\181\236\133\152\236\157\152 \234\179\132\236\151\180 \234\178\176\236\160\149");
else
t=ev("\236\152\181\236\133\152\236\157\152 \234\179\132\236\151\180 \234\178\176\236\160\149");
end
local list={};
for k,v in pairs(t)do
list[k]=bf(k.." \236\152\181\236\133\152 \236\132\160\237\131\157 \237\153\149\235\165\160",v);
end
type={math.randlist(list)};
end
trace("\234\179\132\236\151\180",type);
local list={};
for k,v in pairs(optiontable)do
if not HasItemOption(guid,k)and(not type or table.find(type,v["\236\152\181\236\133\152 \234\179\132\236\151\180"]))and table.find(v["\236\152\181\236\133\152 \235\182\132\235\165\152"],rune)then
local p=v["("..data.id..")"]or v["("..item["\236\162\133\235\165\152"]..")"];
if p then
list[k]=p*(v["\235\147\177\236\158\165 \235\185\132\236\156\168"]or 1);
end
end
end

if table.empty(list)then
for k,v in pairs(optiontable)do
if not HasItemOption(guid,k)and table.find(v["\236\152\181\236\133\152 \235\182\132\235\165\152"],rune)then
local p=v["("..data.id..")"]or v["("..item["\236\162\133\235\165\152"]..")"];
if p then
list[k]=p*(v["\235\147\177\236\158\165 \235\185\132\236\156\168"]or 1);
end
end
end
end
opid=math.randlist(list);
end


if(opid or 0)==0 then
trace("no option:"..data.id);
else
if not HasItemOption(guid,opid)then

local o=optiontable[opid];
local t={id=opid,d={}};
_item=item;
_data=data;
for i=1,9,1 do
local key=o["\237\154\168\234\179\188"..i];
if key then
t.d[key]=table.copy(o["\237\154\168\234\179\188"..i.."_\236\136\152\236\185\152"]);
else
break;
end
end
_item=nil;
_data=nil;
if o["\236\167\128\236\134\141\236\139\156\234\176\132"]then
t.T=0;
end
data["\236\152\181\236\133\152"]=data["\236\152\181\236\133\152"]or{};
if IsExtraOption(guid,opid)then
local added=GetAddedItemOptionIndex(guid);
local c=const(item["\236\162\133\235\165\152"].." \235\147\177\234\184\137\235\179\132 \236\152\181\236\133\152 \234\176\156\236\136\152",data["\235\147\177\234\184\137"])or const("\235\147\177\234\184\137\235\179\132 \236\152\181\236\133\152 \234\176\156\236\136\152",data["\235\147\177\234\184\137"]);
trace("maxOptions",c);
local maxOptions=c[2];
if added and#added>=maxOptions then
local list={};
for k,v in pairs(added)do
local opid=data["\236\152\181\236\133\152"][v].id;
list[v]=const("\236\152\181\236\133\152\235\140\128\236\178\180\235\185\132\236\156\168",optiontable[opid]["\236\152\181\236\133\152 \234\179\132\236\151\180"]or"\236\164\145\234\176\132");
end
local pos=math.randlist(list);
data["\236\152\181\236\133\152"][pos]=t;
else
table.insert(data["\236\152\181\236\133\152"],t);
end
else
table.insert(data["\236\152\181\236\133\152"],t);
end
end
local slot=DelItemBuff(guid);
if slot then
SetItemBuff(slot,guid);
end
eventDispatcher:send("UpdateItem");
end

if cb then
local name="";
if optiontable[opid]then
name=optiontable[opid].name;
end
ItemMessagePopup(cb,guid,_L("\236\152\181\236\133\152\236\182\148\234\176\128\237\131\128\236\157\180\237\139\128"),{{_L("\236\152\181\236\133\152"),name}});
end

end

function GetTemperature(isPlayer)

local t=0;
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
if m then
local tb=m["\234\184\176\236\152\168"];
if tb then
local h,s=const("\234\184\176\236\152\168\235\179\128\237\153\148","\234\184\176\236\152\168\236\139\156"),const("\234\184\176\236\152\168\235\179\128\237\153\148","\234\184\176\236\152\168\236\134\141\235\143\132");
local hour=GetHour();
local min,max=math.min(tb[1],tb[2]),math.max(tb[1],tb[2]);
if hour<=h[1]then
t=max-(h[1]+24-hour)*(max-min)*s;
elseif hour>h[2]then
t=max-(hour-h[2])*(max-min)*s;
else
t=min+(hour-h[1])*(max-min)*s;
end
t=math.clamp(t,min,max);

if world and world.ground and isPlayer then
local a=world.ground:getTemperature(_S.x,_S.y);
if HasTorch()then
a=a+ev("\237\154\131\235\182\136\234\184\176\236\152\168\236\166\157\234\176\128");
end
t=t+a;





if bf("\234\183\184\235\138\152")>0 then
_G["\234\184\176\236\152\168"]=t;
t=ev("\234\183\184\235\138\152\234\184\176\236\152\168");
_G["\234\184\176\236\152\168"]=nil;
end
end
end
end
return t;
end

function UpdateWeather(AP)
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
if m then
local tb=mapbptable[m["\236\132\164\234\179\132\235\143\132"]];
local tick=const("\235\130\160\236\148\168\234\176\177\236\139\160\236\163\188\234\184\176");
if m["\235\130\160\236\148\168D"]then
m["\235\130\160\236\148\168D"]=m["\235\130\160\236\148\168D"]-AP;
if m["\235\130\160\236\148\168D"]<=0 then
m["\235\130\160\236\148\168D"]=nil;
m["\235\130\160\236\148\168"]=nil;
end
else
m["\235\130\160\236\148\168T"]=(m["\235\130\160\236\148\168T"]or 0)+AP;
if m["\235\130\160\236\148\168T"]>=tick then
m["\235\130\160\236\148\168T"]=nil;
local key;
trace("\235\131\152\236\148\168",tb["\235\130\160\236\148\168"]);
if tb["\235\130\160\236\148\168"]then
key=math.randlist(tb["\235\130\160\236\148\168"],100);

if tb["\235\130\160\236\148\168\234\184\176\234\176\132"]then
m["\235\130\160\236\148\168D"]=countkcc(tb["\235\130\160\236\148\168\234\184\176\234\176\132"]);
end
end
m["\235\130\160\236\148\168"]=key;
end
end
if m["\235\130\160\236\148\168"]=="\235\185\132"then
m["\235\185\132T"]=m.T;
if GetTemperature()<0 then
m["\235\130\160\236\148\168"]="\235\136\136";
end
end
end
end

function FindItemOption(data,opid)
if data and data["\236\152\181\236\133\152"]then
for k,v in pairs(data["\236\152\181\236\133\152"])do
if v.id==opid then
return v;
end
end
end
end


function GetItemOptionBuff(data,key)
local value=0;
if data and data["\236\152\181\236\133\152"]then
for k,v in pairs(data["\236\152\181\236\133\152"])do
for kk,vv in safe_pairs(v.d)do
if kk==key then
value=value+(vv["\236\136\152\236\185\152"]or 0);
end
end
end
end
return value;
end

function HasItemOption(guid,opid)
return FindItemOption(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid],opid);
end

function IsIdentityItem(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
return not o["\235\175\184\237\153\149\236\157\184"]and UnidentityItemId(o.id)==o.id;
end


function UnidentityItemId(id)
local item=itemtable[id];
if item and not _S["\236\149\132\236\157\180\237\133\156\237\153\149\236\157\184"][id]then
local ty=item["\236\162\133\235\165\152"];
return ty and const("\235\175\184\237\153\149\236\157\184\236\149\132\236\157\180\237\133\156",ty)or id;
end
return id;
end

function UnidentityItemIdFromGuid(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
return UnidentityItemId(o.id);
end


function SetItemIdIdentity(id)
local ty=itemtable[id]["\236\162\133\235\165\152"];
if ty and const("\235\175\184\237\153\149\236\157\184\236\149\132\236\157\180\237\133\156",ty)then
if(_S["\236\149\132\236\157\180\237\133\156\237\153\149\236\157\184"][id]or 0)==0 then
_S["\236\149\132\236\157\180\237\133\156\237\153\149\236\157\184"][id]=1;
world.player:addChat(string.format(_L("\235\172\188\236\149\189\236\163\188\235\172\184\236\132\156\237\153\149\236\157\184"),itemtable[id].name));
if recipetable[id]then
AddRecipe(id);
end
eventDispatcher:send("UpdateItem");
end
end

end

function SetItemIdentity(guid,cb)

if not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local list={};
for guid,data in pairs(GetMyItems())do
if not IsIdentityItem(guid)then
table.insert(list,guid);
end
end
guid=table.choice(list);
end

local v1;
if guid then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
data["\235\175\184\237\153\149\236\157\184"]=nil;
SetItemIdIdentity(data.id);
if(data["\235\147\177\234\184\137"]=="\235\160\136\236\150\180"or data["\235\147\177\234\184\137"]=="\236\149\132\237\139\176\237\140\169\237\138\184")then
AddScore(ev("\235\170\168\237\151\152\236\160\144\236\136\152\236\166\157\234\176\128","\236\149\132\236\157\180\237\133\156\237\153\149\236\157\184"));
end
v1=ItemName(guid);
updateSkill();
eventDispatcher:send("UpdateItem");
end
if cb then
if v1 then
ItemMessagePopup(cb,guid,_L("\234\176\144\236\160\149\237\131\128\236\157\180\237\139\128"),{{_L("\236\157\180\235\166\132"),v1}});
else
local mc2=showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y");
mc2.txt:SetText(_L("\234\176\144\236\160\149\237\149\160 \236\149\132\236\157\180\237\133\156\236\157\180 \236\151\134\236\138\181\235\139\136\235\139\164."));
mc2.onClose=function(self)
cb();
end
end
end
end

function GetRemovableItemOptions(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[data.id];
local list;
if data["\236\152\181\236\133\152"]then
for k,v in pairs(data["\236\152\181\236\133\152"])do
if v.id=="\236\160\128\236\163\188"or v.id=="\236\182\149\235\179\181"then
elseif not table.find(item["\234\184\176\235\179\184 \236\152\181\236\133\152"],v.id)then
list=list or{};
table.insert(list,v.id);
end
end
end
return list;
end


function IsExtraOption(guid,opid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[data.id];
local ob=optiontable[opid];
assert(ob,guid,opid);
return ob["\236\152\181\236\133\152 \235\182\132\235\165\152"]and not table.find(item["\234\184\176\235\179\184 \236\152\181\236\133\152"],opid);
end

function GetAddedItemOptionIndex(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[data.id];
local list;
for k,v in safe_pairs(data["\236\152\181\236\133\152"])do
local ob=optiontable[v.id];
if not ob["\236\152\181\236\133\152 \235\182\132\235\165\152"]then
elseif table.find(item["\234\184\176\235\179\184 \236\152\181\236\133\152"],v.id)then
else
list=list or{};
table.insert(list,k);
end
end
return list;
end

function DelItemOption(cb,guid,opid)

if not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local list={};
for guid,data in pairs(GetMyItems())do
if data["\236\152\181\236\133\152"]then
for k,v in pairs(data["\236\152\181\236\133\152"])do
if v.id==opid then
table.insert(list,guid);
break;
end
end
end
end
guid=table.choice(list);
end

local v1;
if guid then
v1=optiontable[opid].name;
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if data["\236\152\181\236\133\152"]then
for k,v in pairs(data["\236\152\181\236\133\152"])do
if v.id==opid then
table.remove(data["\236\152\181\236\133\152"],k);
break;
end
end
end
local slot=DelItemBuff(guid);
if slot then
SetItemBuff(slot,guid);
end
eventDispatcher:send("UpdateItem");
end

if cb then
if guid then
ItemMessagePopup(cb,guid,_L("\236\152\181\236\133\152\236\160\156\234\177\176\237\131\128\236\157\180\237\139\128"),{{_L("\236\152\181\236\133\152"),v1}});
else
showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L("\236\152\181\236\133\152\236\160\156\234\177\176\237\131\128\236\157\180\237\139\128\235\133\184\236\149\132\236\157\180\237\133\156")).onClose=function()
cb();
end
end
end
end
function RepairItem(cb,guid,value)

if not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local list={};
for guid,data in pairs(GetMyItems())do
if data["\235\130\180\234\181\172\235\143\132"]and data["\235\130\180\234\181\172\235\143\132"]<const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132")then
table.insert(list,guid);
end
end
guid=table.choice(list);
end

local v1,v2;
if guid then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
v1=data["\235\130\180\234\181\172\235\143\132"];
data["\235\130\180\234\181\172\235\143\132"]=math.min(data["\235\130\180\234\181\172\235\143\132"]+math.ceil(value),const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132"));
v2=data["\235\130\180\234\181\172\235\143\132"];

for k,v in ipairs(GetAvailSlots())do
if guid==_S["\236\138\172\235\161\175"][v]then
DelItemBuff(guid);
SetItemBuff(v,guid);
end
end
updateSkill();
eventDispatcher:send("UpdateItem");
end
if cb then
if guid then
ItemMessagePopup(cb,guid,_L("\236\136\152\235\166\172\237\131\128\236\157\180\237\139\128"),{{_L("\235\130\180\234\181\172\235\143\132"),v1,v2}});
else
cb();
end
end
end
function RechargeItem(cb,guid,value)

if not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local list={};
for guid,data in pairs(GetMyItems())do
if data["\236\182\169\236\160\132"]and data["\236\182\169\236\160\132"][1]<data["\236\182\169\236\160\132"][2]then
table.insert(list,guid);
end
end
guid=table.choice(list);
end

local v1,v2;
if guid then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
v1=data["\236\182\169\236\160\132"][1];
data["\236\182\169\236\160\132"][1]=math.min(data["\236\182\169\236\160\132"][1]+value,data["\236\182\169\236\160\132"][2]);
v2=data["\236\182\169\236\160\132"][1];
eventDispatcher:send("UpdateItem");
end

if cb then
if guid then
ItemMessagePopup(cb,guid,_L("\236\182\169\236\160\132\237\131\128\236\157\180\237\139\128"),{{_L("\236\182\169\236\160\132"),v1,v2}});
else
cb();
end
end
end

function UpgradeItem(cb,guid,group)
if not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local list={};
for guid,data in pairs(GetMyItems())do
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if group==itemtable[o.id]["\234\183\184\235\163\185"]or group==const("\235\182\132\235\165\152A",itemtable[o.id]["\236\162\133\235\165\152"])then
table.insert(list,guid);
end
end
guid=table.choice(list);
end

local v1,v2;
if guid then

local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local P=const("\234\176\149\237\153\148 \236\132\177\234\179\181 \237\153\149\235\165\160",math.max(1,(o["\234\176\149\237\153\148"]or 0)+1))or 0;
local invP=100-P;
local item=itemtable[o.id];
invP=invP-invP*bf("\234\176\149\237\153\148 \236\139\164\237\140\168 \237\153\149\235\165\160 \234\176\144\236\134\140");
v1=(o["\234\176\149\237\153\148"]or 0);
if not math.randpercent(invP)then
o["\234\176\149\237\153\148"]=v1+countkcc({1,bf("1\236\182\148\234\176\128 \234\176\149\237\153\148 \237\153\149\235\165\160"),2});
else
if o["\236\152\181\236\133\152"]then


if math.randpercent(const("\234\176\149\237\153\148 \236\152\181\236\133\152 \236\160\156\234\177\176 \237\153\149\235\165\160"))then
local lastOpIdx;
for i,v in ipairs(o["\236\152\181\236\133\152"])do
if not table.find(item["\234\184\176\235\179\184 \236\152\181\236\133\152"],v.id)then
if optiontable[v.id]and optiontable[v.id]["\236\152\181\236\133\152 \234\179\132\236\151\180"]then
lastOpIdx=i;
end
end
end

if lastOpIdx then
local op=o["\236\152\181\236\133\152"][lastOpIdx].id;
table.remove(o["\236\152\181\236\133\152"],lastOpIdx);
if math.randpercent(const("\234\176\149\237\153\148 \236\160\149\236\136\152 \236\131\157\236\132\177 \237\153\149\235\165\160"))then
local k=table.choice(optiontable[op]["\236\152\181\236\133\152 \235\182\132\235\165\152"]).."\236\157\152 \236\160\149\236\136\152";
if itemtable[k]then
MakeAndPlaceItem(k,_S.x,_S.y);
end
end
end
end
end
end
v2=o["\234\176\149\237\153\148"];
eventDispatcher:send("UpdateItem");
end
if cb then
if guid then
if v1==v2 then
ItemMessagePopup(cb,guid,_L("\234\176\149\237\153\148\237\131\128\236\157\180\237\139\128\236\139\164\237\140\168"),{{_L("\234\176\149\237\153\148"),v1 or 0,v2 or 0}});
else
ItemMessagePopup(cb,guid,_L("\234\176\149\237\153\148\237\131\128\236\157\180\237\139\128"),{{_L("\234\176\149\237\153\148"),v1 or 0,v2 or 0}});
end
else
cb();
end
end
end



function GetDay(T)
return math.floor((T or _S.T)*const("AP\235\139\185\235\182\132")/1440);
end

function GetMoonZone(T)
return GetDay()%5;
end
function GetHour(T)

return math.floor((T or _S.T)*const("AP\235\139\185\235\182\132")/60)%24;
end

function GetTimeZone(T)

local hour=GetHour(T);
local zone;
local t=const("\236\139\156\234\176\132\235\140\128");
if hour<t[1]then
zone=2;
elseif hour<t[2]then
zone=3;
elseif hour<t[3]then
zone=4;
elseif hour<t[4]then
zone=1;
else
zone=2;
end
return zone;
end

function UpdateItem(guid,temperature,AP,bFire,object)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
assert(o,guid);
if o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if v~=0 then
UpdateItem(v,temperature,AP,bFire,object);

if not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v]then
o["\234\176\128\235\176\169"][k]=0;
end
end
end
else
local item=itemtable[o.id];
assert(item,o.id);
if o["\236\176\169\236\154\169T"]then
o["\236\176\169\236\154\169T"]=o["\236\176\169\236\154\169T"]+AP;
if o["\235\175\184\237\153\149\236\157\184"]and o["\236\176\169\236\154\169T"]>=const("\235\175\184\237\153\149\236\157\184\236\176\169\236\154\169\236\149\132\236\157\180\237\133\156\234\176\144\236\160\149T")then
SetItemIdentity(guid);
local dict={};
dict["{1}"]=ItemName(guid);
dict["{\236\157\180/\234\176\128}"]=SelectJosa(ItemName(guid),{"\236\157\180","\234\176\128"});
world.textbox:AddLine(ReplaceString(lang["\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_\236\149\132\236\157\180\237\133\156\234\176\144\236\160\149"],dict));
end
end

if o["\236\152\181\236\133\152"]then
for k,v in pairs(o["\236\152\181\236\133\152"])do
if v.T then
v.T=v.T+AP;
if(optiontable[v.id]["\236\167\128\236\134\141\236\139\156\234\176\132"]or 0)<=v.T then
DelItemOption(nil,guid,v.id);
end
end
end
end

if bFire and item["\237\131\128\235\138\148 \236\139\156\234\176\132"]then

if not o.FireT and math.randpercent(const("\236\157\184\235\178\164\236\149\132\236\157\180\237\133\156\235\182\136\237\131\144\237\153\149\235\165\160"))then
o.FireT=0;
end
if o.FireT then
o.FireT=o.FireT+AP;
if item["\237\131\128\235\138\148 \236\139\156\234\176\132"]<=o.FireT then
local newId=FindCook(o.id);
if newId then
o.id=newId;
SetCookData(o);
else
ConsumeItem(guid,countkcc(const("\236\157\184\235\178\164\236\149\132\236\157\180\237\133\156\235\182\136\237\131\144\234\176\156\236\136\152")));
end
eventDispatcher:send("ConsumeItem");
end
end
else
o.FireT=nil;
end

if o.pick then
if o.T then
if o["\236\182\169\236\160\132"]then
if o["\236\182\169\236\160\132"][1]<o["\236\182\169\236\160\132"][2]then
o.T=o.T+AP;
local T=GetRechargeDur(item);
if T then
trace("\236\182\169\236\160\132",T);
while T<=o.T do
o.T=o.T-T;
o["\236\182\169\236\160\132"][1]=math.min(o["\236\182\169\236\160\132"][2],o["\236\182\169\236\160\132"][1]+1);
end
end
end
else
o.T=o.T+AP;
end
end

if item["\235\179\180\234\180\128 \236\152\168\235\143\132"]then
trace("temperature",o);
if item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\152\168\235\143\132"]and temperature<=item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\152\168\235\143\132"]then
o["\236\131\129\237\149\152\235\138\148T"]=0;
else
o["\236\131\129\237\149\152\235\138\148T"]=(o["\236\131\129\237\149\152\235\138\148T"]or 0)+AP;
if o["\236\131\129\237\149\152\235\138\148T"]>=(item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\131\129\237\149\152\235\138\148 \236\139\156\234\176\132"]or item["\235\179\180\234\180\128 \234\184\176\234\176\132"])then
if item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\131\129\237\149\156 \236\157\140\236\139\157"]and math.randpercent(item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\131\129\237\149\152\235\138\148 \237\153\149\235\165\160"]or 100)then
o.id=item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\131\129\237\149\156 \236\157\140\236\139\157"];
o["\236\131\129\237\149\152\235\138\148T"]=nil;
item=itemtable[o.id];
if item["\235\179\180\234\180\128 \234\184\176\234\176\132"]then
o.T=0;
end
else
if object then
object:removeStorageItem(guid);
else
ConsumeItem(guid,o.c);
end
end

end
end
end
end
end
end

function SetGameEnding(k)
if _S["\236\151\148\235\148\169"]==0 then
local job=_S["\236\167\129\236\151\133"];
_S["\236\151\148\235\148\169"]=k;
_D["\236\180\157\236\151\148\235\148\169"][job]=_D["\236\180\157\236\151\148\235\148\169"][job]or{};
_D["\236\180\157\236\151\148\235\148\169"][job][k]=(_D["\236\180\157\236\151\148\235\148\169"][job][k]or 0)+1;
Mission("\236\151\148\235\148\169",1,k);
for avatarId,v in pairs(avatartable)do
if not _D["\237\154\141\235\147\157\236\149\132\235\176\148\237\131\128"][avatarId]then
if v["\237\154\141\235\147\157\236\153\184\237\152\149"]==_S["\236\149\132\235\176\148\237\131\128"]and v["\237\154\141\235\147\157\236\167\129\236\151\133"]==_S["\236\167\129\236\151\133"]and v["\237\154\141\235\147\157\236\151\148\235\148\169"]==k then
_D["\237\154\141\235\147\157\236\149\132\235\176\148\237\131\128"][avatarId]=GetDay();
end
end
end
end
end

function GetArtifactUpgradeMaterial(guid)
local tier=ItemTier(guid);
_G["\237\139\176\236\150\180"]=tier;
local t={};
for k,v in pairs(ev("\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168 \236\158\172\235\163\140"..math.floor(math.clamp(tier,0,6))))do
t[k]=v;
end

_G["\237\139\176\236\150\180"]=nil;
return t;
end



function NewWeekMission()
table.clear(_D["\234\179\160\236\160\149\235\175\184\236\133\152"]);

do
local clist={};
for _,df in ipairs({"\237\149\152","\236\164\145","\236\131\129"})do
local list={};
for k,v in pairs(missiontable)do
if v["\237\131\128\236\158\133"]=="\234\179\160\236\160\149"then
if v["\235\130\156\236\157\180\235\143\132"]==df then
local c=string.split(k,"-")[1]or k;
if not clist[c]then
list[k]=v["\235\147\177\236\158\165 \235\185\132\236\156\168"]or 1;
end
end
end
end
do
local k=math.randlist(list);
assert(k);
local c=string.split(k,"-")[1]or k;
clist[c]=k;
table.insert(_D["\234\179\160\236\160\149\235\175\184\236\133\152"],{id=k,reward=MissionReward(k),job=table.choice(missiontable[k]["\236\167\129\236\151\133"])});
end
end
end

do
local list={};
for k,v in pairs(missiontable)do
if v["\237\131\128\236\158\133"]=="\237\138\185\236\136\152"then
list[k]=v["\235\147\177\236\158\165 \235\185\132\236\156\168"]or 1;
end
end
do
local k=math.randlist(list);
assert(k);
table.insert(_D["\234\179\160\236\160\149\235\175\184\236\133\152"],{id=k,reward=MissionReward(k),job=table.choice(missiontable[k]["\236\167\129\236\151\133"])});
end
end
end

function MakeMission(id,reward,diaIdx,job,pos)
local seq;
repeat
seq=math.random(0x7FFFFFFF);
until not table.find(_S["\235\175\184\236\133\152"],seq);
local tb=missiontable[id];
pos=pos or(#_S["\235\175\184\236\133\152"]+1);
_S["\235\175\184\236\133\152"][pos]=_S["\235\175\184\236\133\152"][pos]or{};
local t=_S["\235\175\184\236\133\152"][pos];
if not tb["\237\145\156\236\139\156\235\175\184\236\133\152"]or _S["\236\153\132\235\163\140\235\175\184\236\133\152"][tb["\237\145\156\236\139\156\235\175\184\236\133\152"]]then
_S["\235\137\180\235\175\184\236\133\152"][id]=GetDay();
else
t.hide=GetDay();
end
_S["\235\176\155\236\157\128\235\175\184\236\133\152\236\136\152"][tb["\237\131\128\236\158\133"]]=(_S["\235\176\155\236\157\128\235\175\184\236\133\152\236\136\152"][tb["\237\131\128\236\158\133"]]or 0)+1;
t.id=id;
t.seq=seq;
t.dia=tb.dia;
t.idx=_S["\235\176\155\236\157\128\235\175\184\236\133\152\236\136\152"][tb["\237\131\128\236\158\133"]];
t.completed=nil;
t.success=nil;
t.rewarded=nil;
if not t.dia then
if diaIdx and(t.idx%diaIdx[1]==0)then
t.dia=diaIdx[2];
else
t.reward=reward or MissionReward(id);
end
end
t.job=job or table.choice(tb["\236\167\129\236\151\133"]);
if t.job then
if t.job~=_S["\236\167\129\236\151\133"]then
t.completed=0;
end
end
for i=1,9 do
local cond=tb["\236\161\176\234\177\180"..i];
if not cond then
break;
end
InvalidLookup("mission",cond[1]);
t["data"..i]=nil;
if cond[1]=="\236\131\157\236\161\180"then
t["data"..i]=GetDay()+1;
end
end
return t;
end


function NewMission()
if table.empty(_D["\234\179\160\236\160\149\235\175\184\236\133\152"])then
NewWeekMission();
end
_S["\235\175\184\236\133\152"]={};
for i,v in ipairs(_D["\234\179\160\236\160\149\235\175\184\236\133\152"])do
MakeMission(v.id,v.reward,nil,v.job);
end
for k,v in pairs(missiontable)do
if v["\237\131\128\236\158\133"]=="\237\138\156\237\134\160\235\166\172\236\150\188"then
if not v["\236\132\160\237\150\137\235\175\184\236\133\152"]then
MakeMission(k);
end
end
end
end


function RewardMission(v)
v.rewarded=GetDay();
_S["\236\153\132\235\163\140\235\175\184\236\133\152"][v.id]=nil;
if table.empty(_S["\236\153\132\235\163\140\235\175\184\236\133\152"])then
world:updateMenu();
end
end


function CompleteMission(v)
local tb=missiontable[v.id];
if v.success then

for kk,vv in pairs(_D["\234\179\160\236\160\149\235\175\184\236\133\152"])do
if vv.id==v.id then
local list={};
for kkk,vvv in pairs(missiontable)do
if kkk~=v.id and vvv["\237\131\128\236\158\133"]==tb["\237\131\128\236\158\133"]and vvv["\235\130\156\236\157\180\235\143\132"]==tb["\235\130\156\236\157\180\235\143\132"]then
table.insert(list,kkk);
end
end
local k=table.choice(list);
if k then
_D["\234\179\160\236\160\149\235\175\184\236\133\152"][kk]={id=k,reward=MissionReward(k)};
end
end
end

for kk,vv in pairs(missiontable)do
if vv["\236\132\160\237\150\137\235\175\184\236\133\152"]==v.id then
MakeMission(kk);
world:addBlink(world.ui.menu["\235\175\184\236\133\152\235\179\180\234\184\176"].new,const("\235\175\184\236\133\152\234\185\156\235\176\149\236\158\132\236\139\156\234\176\132"));
world:alarmMission(kk);
end
end


local function childMission(v)
if not v.hide then
_S["\236\153\132\235\163\140\235\175\184\236\133\152"][v.id]=GetDay();
world:addBlink(world.ui.menu["\235\175\184\236\133\152\235\179\180\234\184\176"].check,const("\235\175\184\236\133\152\234\185\156\235\176\149\236\158\132\236\139\156\234\176\132"));
world:alarmMission(v.id);
world:updateMenu();
for kk,vv in pairs(_S["\235\175\184\236\133\152"])do
local tb=missiontable[vv.id];
if tb["\237\145\156\236\139\156\235\175\184\236\133\152"]==v.id then
_S["\235\137\180\235\175\184\236\133\152"][vv.id]=GetDay();
world:addBlink(world.ui.menu["\235\175\184\236\133\152\235\179\180\234\184\176"].new,const("\235\175\184\236\133\152\234\185\156\235\176\149\236\158\132\236\139\156\234\176\132"));
world:alarmMission(vv.id);
vv.hide=nil;
if vv.success then
childMission(vv);
end
end
end
end
end
childMission(v);
else
_S["\235\137\180\235\175\184\236\133\152"][v.id]=GetDay();
end
for i=1,9 do
local cond=tb["\236\161\176\234\177\180"..i];
if not cond then
break;
end
InvalidLookup("mission",cond[1]);
end
end


function HasMission(id)
local cid=string.split(id,"-")[1]or id;
for k,v in pairs(_S["\235\175\184\236\133\152"])do
local c=string.split(v.id,"-")[1]or v.id;
if c==cid then
return k;
end
end
end

function MissionReward(id)
local tb=missiontable[id];
assert(tb,id);
if tb.dia then
return;
end
local ty=tb["\237\131\128\236\158\133"];
local itemtable=require"data.itemtable";
if tb["\235\179\180\236\131\129"]then
local t={};
for k,v in pairs(tb["\235\179\180\236\131\129"])do
local key=table.choice(string.split(k,","));
t[key]=v;
end
return t;
end
local list={};
for k,v in pairs(mission_rewardtable)do
list[k]=v[ty];
end
local id;
local k=math.randlist(list);
local t=mission_rewardtable[k];
assert(t,k);
if t["\237\139\176\236\150\180"]then
local list={};
for k,v in pairs(itemtable)do
if v["\237\139\176\236\150\180"]==t["\237\139\176\236\150\180"]then
table.insert(list,k);
end
end
id=table.choice(list);
else
id=t["\236\149\132\236\157\180\237\133\156"];
if not itemtable[id]then
local list={};
for k,v in pairs(itemtable)do
if v["\236\162\133\235\165\152"]==id then
table.insert(list,k);
end
end
id=table.choice(list);
end
end
return{[id]=t["\234\176\156\236\136\152"]};
end

function NewMapMission(m)

for k,v in pairs(_S["\235\175\184\236\133\152"])do
if not v.completed then
local tb=missiontable[v.id];
if tb["\236\139\164\237\140\168\235\167\181"]and not table.find(tb["\236\139\164\237\140\168\235\167\181"],m["\236\167\128\236\151\173"])then
v.completed=GetDay();
v.success=false;
CompleteMission(v);
end
end
end
for k,v in pairs(missiontable)do
if v["\237\131\128\236\158\133"]=="\236\158\133\236\158\165"and v["\235\167\181"]==m["\236\167\128\236\151\173"]then
local pos=HasMission(k);
if not pos or _S["\235\175\184\236\133\152"][pos].completed then
MakeMission(k,nil,servertable.MissionDiaIdx,nil,pos);
world:addBlink(world.ui.menu["\235\175\184\236\133\152\235\179\180\234\184\176"].new,const("\235\175\184\236\133\152\234\185\156\235\176\149\236\158\132\236\139\156\234\176\132"));
world:alarmMission(k);
end
end
end
end


function UpdateMission()
local _n=math.floor((GetDay()+1)/const("\236\157\188\235\176\152\235\175\184\236\133\152\236\163\188\234\184\176"));
for i=(_S["\235\176\155\236\157\128\235\175\184\236\133\152\236\136\152"]["\236\157\188\235\176\152"]or 0)+1,_n do
local c=0;
for k,v in pairs(_S["\235\175\184\236\133\152"])do
local tb=missiontable[v.id];
if tb["\237\131\128\236\158\133"]=="\236\157\188\235\176\152"and not v.completed then
c=c+1;
end
end
if c<const("\236\157\188\235\176\152\235\175\184\236\133\152\234\176\156\236\136\152")then
local k=ChoiceMission();
if k then
MakeMission(k,nil,servertable.MissionDiaIdx);
world:addBlink(world.ui.menu["\235\175\184\236\133\152\235\179\180\234\184\176"].new,const("\235\175\184\236\133\152\234\185\156\235\176\149\236\158\132\236\139\156\234\176\132"));
world:alarmMission(k);
else
break;
end
else
break;
end
end
end

function ChoiceMission(id)
local list={};
for k,v in pairs(missiontable)do
if v["\237\131\128\236\158\133"]=="\236\157\188\235\176\152"then
if id~=k and not HasMission(k)then
if v["\235\167\181"]and not IsInMapArea(_S["\237\152\132\236\158\172\235\167\181"],v["\235\167\181"])then
else
list[k]=v["\235\147\177\236\158\165 \235\185\132\236\156\168"]or 1;
end
end
end
end
return math.randlist(list);
end


function SelectAreaTB(t)
if type(t)=="table"then
local t2=t["\236\167\128\236\151\173\235\179\132"];
if t2 then



t=t2[_S["\237\152\132\236\158\172\236\167\128\236\151\173"]]or t2["\234\184\176\237\131\128"];
end
end
return t;
end

function SetCurMap(mapId)
_S["\237\152\132\236\158\172\235\167\181"]=mapId;
_S["\237\152\132\236\158\172\236\167\128\236\151\173"]=_S.maps[mapId]and _S.maps[mapId]["\236\167\128\236\151\173"]or 0;
end

function IsInMapArea(mapId,area)
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mapType=_S.maps[mapId]["\237\131\128\236\158\133"];
local typeC=const("\237\149\132\235\147\156\237\131\128\236\158\133\235\182\132\235\165\152C",mapType);
local list={mapId,mapType,typeC};
for k,v in safe_pairs(area)do
if table.find(list,v)then
return true;
end
end
end