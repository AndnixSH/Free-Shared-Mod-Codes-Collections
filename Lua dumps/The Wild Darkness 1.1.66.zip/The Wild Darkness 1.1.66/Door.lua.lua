Door=Object:new({
})


function Door:init(guid,sdata,...)
Object.init(self,guid,sdata,...);







end


function Door:isLocked()
return self.sdata.locked or
(const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160",self.sdata.id)and not self.sdata.key);
end

function Door:canCloseDoor()
if const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160",self.sdata.id)then
return self.sdata.key and self.sdata.opened;
else
return true;
end
end

function Door:useKey()
if self.sdata.locked then
trace("useKey locked");
world.player:addChat(_L("\236\151\180\236\135\160\234\181\172\235\169\141\236\157\128 \235\179\180\236\157\180\236\167\128 \236\149\138\235\138\148\235\139\164."));
elseif const("\235\172\184\236\151\172\235\138\148\236\151\180\236\135\160",self.sdata.id)then
if self.sdata.key then
if self.sdata.opened then
return true;
else
if ConsumeItem(self.sdata.key,1)then
self.sdata.opened=true;
AddScore(ev("\235\170\168\237\151\152\236\160\144\236\136\152\236\166\157\234\176\128","\236\158\160\234\184\180\235\172\184"));
return true;
else
trace("useKey nokey",self.sdata.key);
world.player:addChat(_L("\236\151\180\236\135\160\234\176\128 \237\149\132\236\154\148\237\149\156\234\178\131 \234\176\153\235\139\164."));
end
end
else
trace("useKey nohole");
world.player:addChat(_L("\236\151\180\236\135\160\234\181\172\235\169\141\236\157\128 \235\179\180\236\157\180\236\167\128 \236\149\138\235\138\148\235\139\164."));
end
else
return true;
end
end

function Door:menuEnabled(guid)
if self:isCompleted()then
if guid=="\235\169\148\235\137\180_\235\139\171\234\184\176"then
return self:canCloseDoor();
else
return false;
end
else
if guid=="\235\169\148\235\137\180_\235\139\171\234\184\176"then
return false;
end
end
return Object:menuEnabled(guid);
end

function Door:open()
self:action();
end

function Door:close()
self:rebirth();
end

function Door:isOppositeDir(from,cx,cy)
if not self:isCompleted()then
if cx>0 then
return from:getArrow()~="right";
else
return from:getArrow()=="right";
end
end
end

function Door:isInTouch(dist,from)
if self:isCompleted()then
return dist==0;
else
return dist==1;
end
end

function Door:isHide()
end

function Door:place(...)
Object.place(self,...);
world.grid:place(self,self.tile.x,self.tile.y,self.sdata.z);
end

function Door:unplace(...)
Object.unplace(self,...);
world.grid:place(self,self.tile.x,self.tile.y,self.sdata.z);
end

function Door:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\151\180\234\184\176"then
if self:useKey()then
onOk(menu);
else
world.player:playSndQueue("\236\158\160\234\184\180\235\172\184 \236\151\180\236\167\128 \235\170\187\237\149\168");
onCancel();
end
elseif menu=="\235\169\148\235\137\180_\235\139\171\234\184\176"then
local function onSelect(mx,my)

local x,y=world.ground:TileToMap(mx,my);
from:unplace();
local function cbClose()
self:rebirth();
end
local function cb()
from.tile.x,from.tile.y=mx,my;
from.center.x,from.center.y=x,y;
from.pos.x,from.pos.y=x,y;
from:place();
from:beganTurn("next");
world:resumeTurn();
end
world:pauseTurn();
from:closeDoor({x=x,y=y},self,cbClose,cb,0.05,_Z.walkDur/2,from.defWalkAnim);
end
if world.ground:selectTile("\234\184\184\236\176\190\234\184\176\235\149\133",1,onSelect,onCancel)==0 then
onCancel();
end
else
onOk(menu);
end
end
