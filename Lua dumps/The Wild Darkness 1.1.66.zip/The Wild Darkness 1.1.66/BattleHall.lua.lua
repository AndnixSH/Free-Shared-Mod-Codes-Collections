
BattleHall=Object:new({
})

function BattleHall:complete(menu,guid)
local k=addSkillLevel(guid);
Object.complete(self);

if k then
local function cb()
world:resumeTurn();
end
world:pauseTurn();
TrainPopup(cb,guid,_L("\236\136\153\235\160\168\235\143\132\237\131\128\236\157\180\237\139\128"),k);
end
end

function BattleHall:menuTouch(from,menu,onOk,onCancel)
local btns={};
for k,v in pairs(self.sdata.param or const("\236\136\153\235\160\168\235\143\132\235\170\169\235\161\157"))do
if addSkillLevel(v,0)then
table.insert(btns,v);
end
end
local function _ok(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\236\136\153\235\160\168\235\143\132",{object=self,keys=btns});
end

