function ItemBuilder(owner)
function owner:close()
end

function owner:update(dt)
end

function owner:click(x,y)
end
function owner:mouseDown(x,y)
end
function owner:mouseMove(x,y)
end
function owner:mouseUp(x,y)
end

function owner:put(recipeId,guids,...)
local args={...};
trace("put",recipeId,guids,...);
world:preAct(function()
local tb=recipetable[id];
local id=tb["\236\158\165\235\185\132"];









if not ConsumeItemsFromGuid(guids)then
return false;
end

local f=function()
if table.find({"\236\152\183","\235\167\157\237\134\160","\235\170\168\236\158\144","\236\158\165\234\176\145","\236\139\160\235\176\156"},itemtable[id]["\236\162\133\235\165\152"])then
world.player:playSndQueue("\236\149\161\236\133\152");
else
world.player:playSndQueue("\236\160\156\236\158\145");
end

BuildArtifactOrNormalItem(nil,_S.x,_S.y,recipeId,table.unpack(args));
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(id,cb);







end
world:pauseTurn();
world.player:beganTurn("craft");
world.player:play(const("\236\160\156\236\158\145\236\149\160\235\139\136"));
world.player.timer.add(f,f,const("\236\160\156\236\158\145\236\149\160\235\139\136\236\139\156\234\176\132"));
owner:onCancel();
end,true);
end
return owner;
end

