Firepot=Object:new({
})

function Firepot:complete(menu,guid,...)
trace("complete",menu,guid);
if menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\237\149\152\234\184\176"then
for k,v in pairs(guid)do
local guid=v[1];
local materials=v[2];
_S["\236\154\148\235\166\172\237\154\159\236\136\152"][guid]=(_S["\236\154\148\235\166\172\237\154\159\236\136\152"][guid]or 0)+1;
Mission("\236\160\156\236\158\145",1,guid);
local o,data=MakeAndPlaceItem(guid,_S.x,_S.y);
o:fly(self.pos);
SetCookData(data,materials);
end
elseif menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\236\151\176\234\181\172"then
local v=dropwelltable["\236\154\148\235\166\172\235\178\149\237\154\141\235\147\157"];
local key=math.randlist(v["\234\181\144\236\178\1801"]);
AddRecipe(key);
else
Object.complete(self,menu,guid,...);
end
end
function Firepot:onResetTurn(AP)
self.sdata.T=(self.sdata.T or 0);
if not self.sdata.FireT then
if self.tb["\236\152\181\236\133\152"]and self.tb["\236\152\181\236\133\152"]["\235\182\136 \236\156\160\236\167\128"]then
self.sdata.FireT=self.sdata.T+bf("\235\182\136 \236\156\160\236\167\128 \236\139\156\234\176\132",self.tb["\236\152\181\236\133\152"]["\235\182\136 \236\156\160\236\167\128"])
end
end

Object.onResetTurn(self,AP);

if self.sdata.FireT then
if AP>0 then
if self.tb["\236\182\169\235\143\140 \235\141\176\235\175\184\236\167\128"]then
Trap.addTrapDamage(self);
end
end
if self.sdata.FireT<=self.sdata.T then
if self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]then
self.sdata.FireT=nil;
local nextId=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"];
world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(nextId,cb,self.guid);
self:swap(nextId);
else
self:die();
end
end
end

end

function Firepot:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\237\149\152\234\184\176"then
do
local function _onOk(guids)
trace("_onOk",menu,guids);
onOk(menu,guids);
end
local mc=showPopup(world,self.tb["\237\140\157\236\151\133"][1],{size={x=0,y=0,cx=APP_W,cy=APP_H}});
CookPopup(mc,self,_onOk,onCancel,menu,self.tb["\237\140\157\236\151\133"][2]);
end






elseif menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\236\151\176\234\181\172"then
local function _ok(guid)
if guid=="\235\169\148\235\137\180_\235\172\180\236\158\145\236\156\132\236\154\148\235\166\172\236\151\176\234\181\172"then
onOk(menu);
end
end
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\235\178\132\237\138\188",{object=self,btns={"\235\169\148\235\137\180_\235\172\180\236\158\145\236\156\132\236\154\148\235\166\172\236\151\176\234\181\172"},detail=_L("\236\154\148\235\166\172\236\151\176\234\181\172\236\132\160\237\131\157\236\132\164\235\170\133")});
else
Object.menuTouch(self,from,menu,onOk,onCancel);
end
end


