

BarricadaSpawner=Object:new({
})

function BarricadaSpawner:isNickVisible()
return not _Z.HideObjectNick;
end
function BarricadaSpawner:canTouch()
end

function BarricadaSpawner:drop()
self:updateWave(0);
end

function BarricadaSpawner:onResetTurn(AP)
Object.onResetTurn(self,AP);
if self:isCompleted()and AP>0 then
self:updateWave(AP);
end
end

function BarricadaSpawner:checkEndSpawn()
local list={};
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
for k,v in safe_pairs(self.sdata.childs)do
if _S.maps[mapId].objects[v]then
table.insert(list,v);
end
end
self.sdata.childs=list;
end

function BarricadaSpawner:updateWave(AP)
local wave=self.sdata.wave;
self.sdata.childs=self.sdata.childs or{};
self.sdata.nChild=self.sdata.nChild or 0;
self:checkEndSpawn();
if not self.sdata.total then
if wave["\235\176\152\235\179\181"]then
self.sdata.total=countkcc(wave["\235\176\152\235\179\181"]);
elseif wave["\235\176\152\235\179\181P"]then
self.sdata.total=math.ceil(#self.sdata.pts*wave["\235\176\152\235\179\181P"]);
else
self.sdata.total=1;
end
end

if#self.sdata.childs<self.sdata.total then
local pts={};
for k,v in pairs(self.sdata.pts)do
if world.ground:getTile(v.x,v.y)~=TT.WATER and world.ground:canTileWalkable(v.x,v.y,Filter_Path)then
table.insert(pts,v);
end
end
trace("total",self.sdata.total,pts);
while#self.sdata.childs<self.sdata.total and#pts>0 do
local idx=math.random(#pts);
local id=math.randlist(wave["\236\155\168\236\157\180\235\184\140"]);
local o=world:createObject(id,pts[idx].x,pts[idx].y);
self.sdata.childs=self.sdata.childs or{};
table.insert(self.sdata.childs,o.guid);
table.remove(pts,idx);
end
end
end
