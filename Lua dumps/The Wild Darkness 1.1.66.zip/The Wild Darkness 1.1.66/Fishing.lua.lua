function Fishing(owner,cb,targets)
local timer=Timer();
local W,H=1280,720;
local queue={};
local fishes={};
local eraseW=200;
local hooking;
local catching;
local hookUp=150;
local hookDown=80;
local hookTop=30;
local hookBottom=H-35;
local mouthL=10;
local reelA=0.1;
local catchingP=2;

function owner:onUnload()
end

owner.water:SetClipRect(0,0,W,H);
owner:SetMouseCapture(true);
owner.water.hook.y=owner.water.hook:GetY();
SpineObject(owner.water.water,"_","bg_water","animation",nil,nil,true);

local function addFish(id,speed,deep,base)
local o={id=id};
if monstertable[id]then
local tb=monstertable[id];
o.mc,o.sk=SpineObject(owner.water.fish,"_",tb.spine,"ani_idle",tb.skin,tb.attachment,true);
elseif itemtable[id]then
local item=itemtable[id];
o.mc,o.sk=SpineObject(owner.water.fish,"_","item","animation",nil,nil,true);
o.sk:setAttachment("item",item.obj);
local a,b,c,d=o.sk:getBound();
local p=1;
o.bound={a*p,b*p,c*p,d*p};
end

if o.sk then
if math.random()<0.5 then
o.x=0;
o.speed=speed;
o.sk:setFlipX(true);
else
o.x=W;
o.speed=-speed;
end
o.y=deep;
o.base=base;
table.insert(fishes,o);
end
end
local function updateFish(dt)
local hookx=W/2;
local hooky=owner.water.hook.y;

for k,v in pairs(fishes)do
if v.catching then
v.y=hooky-v.catching;
else
v.x=v.x+v.speed*dt;

if not catching then
if v.bound then

local l,t,r,b=v.x+v.bound[1],v.y+v.bound[2],v.x+v.bound[1]+v.bound[3],v.y+v.bound[2]+v.bound[4];

if l<hookx and r>=hookx and t<hooky and b>=hooky then
v.catching=hooky-v.y;
catching=v.id;
v.x=hookx;
end
elseif v.base then
local x,y=v.sk:getBonePosition(v.base);
local l,t,r,b=v.x+x-mouthL,v.y+y-mouthL,v.x+x+mouthL,v.y+y+mouthL;
if l<hookx and r>=hookx and t<hooky and b>=hooky then
v.catching=hooky-v.y;
catching=v.id;
v.x=hookx-x;
end
end
end
end
v.mc:SetPos(v.x,v.y);
if v.x>W+eraseW or v.x<-eraseW then
v.mc:Remove();
fishes[k]=nil;
end
end
end

local function newQueue(id)
local tb=fishtable[id];
assert(tb,id);
local t={};
t.id=math.randlist(tb["\236\162\133\235\165\152"]);
if const(t.id)then
t.id=table.choice(const(t.id));
end
local cnt=countkcc(tb["\234\176\156\236\136\152"]);
if id=="\235\170\172\236\138\164\237\132\176"then
cnt=0;
for k,v in safe_pairs(targets)do
if table.find(v.data["\235\182\132\235\165\152"],"\235\172\188\234\179\160\234\184\176")then
t.id=v.data.guid;
cnt=1;
end
end
end
if cnt>0 then
t.T=math.randrange(0,60/cnt);
t.S=math.randrange(tb["\236\134\141\235\143\132"][1],tb["\236\134\141\235\143\132"][2]);
t.Y=math.randrange(tb["\236\136\152\236\139\172"][1],tb["\236\136\152\236\139\172"][2]);
t.base=tb.base;
end
queue[id]=t;
end
local function updateQueue(dt)
for k,v in pairs(queue)do
if v.T then
v.T=v.T-dt;
if v.T<=0 then
addFish(v.id,v.S*W,v.Y*H,v.base);
newQueue(k);
end
end
end
end

local function updateHook(dt)
local y=owner.water.hook.y;
if catching then
owner.water.hook.y=y-hookUp*dt*catchingP;
local a=owner.reel.reel:GetAngle();
owner.reel.reel:SetAngle(a+reelA*catchingP);
owner.reel.reel.a=(owner.reel.reel.a or 0)+reelA*catchingP;
while owner.reel.reel.a>1 do
owner.reel.reel.a=owner.reel.reel.a-1;
world.player:playSnd("\235\130\154\236\139\156\235\166\180\234\176\144\234\184\176");
end
if owner.water.hook.y<hookTop then
cb(catching);
end
elseif hooking then
owner.water.hook.y=math.clamp(y-hookUp*dt,hookTop,hookBottom);
local a=owner.reel.reel:GetAngle();
owner.reel.reel:SetAngle(a+reelA);
owner.reel.reel.a=(owner.reel.reel.a or 0)+reelA;
while owner.reel.reel.a>1 do
owner.reel.reel.a=owner.reel.reel.a-1;
world.player:playSnd("\235\130\154\236\139\156\235\166\180\234\176\144\234\184\176");
end
else
owner.water.hook.y=math.clamp(y+hookDown*dt,hookTop,hookBottom);
end
owner.water.hook:SetY(owner.water.hook.y);
end

for k,v in pairs(fishtable)do
newQueue(k);
end
function owner:onMouseDown(x,y,id)
if not hooking and not catching then
hooking=id;
end
end
function owner:onMouseUp(x,y,id)
if hooking==id and not catching then
hooking=nil;
end
end
function owner:onEnterFrame(dt)
timer.update(dt);
updateQueue(dt);
updateFish(dt);
updateHook(dt);
end

end