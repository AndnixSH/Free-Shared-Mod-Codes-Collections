function Lobby(owner)


















world=owner;
local _GetTimeZone=GetTimeZone;
_G.GetTimeZone=function()

local dur=60;
local tz=_GetTimeZone(owner.timer.time*60*24/dur);
return tz;
end
function owner:pauseTurn()
end
function owner:resumeTurn()
end

function owner:init()
owner.timer=Timer();
owner.ground=owner.w:CreateEmptyMovieClip("");
owner.ui=owner:CreateEmptyMovieClip("");
owner.toast=this:CreateEmptyMovieClip("");
owner.toast:SetZOrder(_Z.MaxZOrder);
owner.fade=this:CreateEmptyMovieClip("");
owner.fade:SetZOrder(_Z.MaxZOrder+1);
BeginTutorial(owner.toast);
owner.zoom=1;
owner.grid=Grid();
owner.characs={};
owner.objects={};
owner.player={};
owner.FowUpdateDur=5;
owner.isLobby=true;
LoadSlotData(nil,nil,"lobby");
PlayMapBgm("\235\161\156\235\185\132");
CheckAchieve();



















do
local oldMap=_S["\237\152\132\236\158\172\235\167\181"];
local _x,_y,_a=_S.x,_S.y,_S.a;
local mapId=MapId("\237\149\132\235\147\156","\235\161\156\235\185\132",1);
SetCurMap(mapId);
_G.nextMap=nil;
if _S.maps[mapId].starts then
_S.x=_S.maps[mapId].starts.x;
_S.y=_S.maps[mapId].starts.y;
_S.a=_S.maps[mapId].starts.a;
end
local tileset=mapbptable[_S.maps[mapId]["\237\131\128\236\157\188\236\167\128\236\151\173"]]["\237\131\128\236\157\188"];
TileGround(owner.ground,tileset);
local tx,ty=_S.x,_S.y;
local x,y=world.ground:TileToMap(tx,ty);
owner.player.tile={x=tx,y=ty};
owner.player.pos={x=x,y=y};
owner:updateCamera(0);

local area=_S.maps[mapId]["\236\167\128\236\151\173"];
_S.maps[mapId]["\236\167\128\236\151\173"]=_S.maps[mapId]["\237\131\128\236\157\188\236\167\128\236\151\173"];
for k,v in pairs(_S.maps[mapId].objects)do
local reserved;
for i,vv in pairs(const("\235\161\156\235\185\132\236\156\160\236\160\129\236\156\132\236\185\152"))do
if v.x==_S.x+vv[1]and v.y==_S.y+vv[2]then
reserved=true;
break;
end
end
if not reserved then
local o=owner:addObject(k,v,true);
end
end
_S.maps[mapId]["\236\167\128\236\151\173"]=area;

owner:addObject(0,{id="\235\161\156\235\185\132 \234\177\176\236\132\157",x=_S.x,y=_S.y},true);

local btns={};
for i=1,#const("\235\161\156\235\185\132\236\156\160\236\160\129\236\156\132\236\185\152"),1 do
local o=owner:addRelic(i);
if o then
table.insert(btns,o.mc);
end
end

if not table.empty(btns)then
Tutorial(owner,"\235\161\156\235\185\132\236\156\160\236\160\129\237\154\141\235\147\157",{["\237\154\141\235\147\157\236\156\160\236\160\129"]=btns});
end


if not table.empty(_G.newRelic)then
trace("newRelic",_G.newRelic);
local mc;
for _,v in pairs(_G.newRelic)do
local id,pos=table.unpack(v);
if owner.objects[pos]then
owner.objects[pos]:play("ani_appear");
local particle={slot="particle",particle="particle_fire_light",y=-40};
owner.objects[pos]:addParticle({particle});
mc=mc or owner.objects[pos].mc;
end
end
_G.newRelic=nil;
end


world.ground.pathFinder:SetVisibility(_S.x*tileSize,_S.y*tileSize,-Block_Object);

SetCurMap(oldMap);
_S.x,_S.y,_S.a=_x,_y,_a;
userDB.Save();
self:updateUI();
end
end

function owner:addRelic(k)
local guid="g"..k;
local posList=const("\235\161\156\235\185\132\236\156\160\236\160\129\236\156\132\236\185\152");
local v=_D["\236\156\160\236\160\129"][guid];
trace("addRelic",k,v);
if objecttable[v]then
local d={id=v,x=_S.x+posList[k][1],y=_S.y+posList[k][2]};
local o=owner:addObject(guid,d,true);
return o;
else
local d={id="\235\185\136 \236\156\160\236\160\129",x=_S.x+posList[k][1],y=_S.y+posList[k][2]};
local o=owner:addObject(guid,d,true);
end
end
function owner:clearRelic(k)
local o=owner.objects[k];
o.sdata.id="\235\185\136 \236\156\160\236\160\129";
o.skeleton:setSkin();
o.skeleton:setSkin(objecttable[o.sdata.id].skin);
o.skeleton:delChild("particle");
end


function owner:updateMenu()
end

function owner:addObject(guid,sdata,loaded)

local tb=objecttable[sdata.id];

if _G[tb.class]then
local o=_G[tb.class]:new();
o:init(guid,sdata,loaded);
owner.objects[guid]=o;
return o;
end
end

function owner:onEnterFrame(dt)
spine.advanceTime(dt);
owner.timer.update(dt);
if not self.isTraveling then

local i=1;
while owner.characs[i]do
local v=owner.characs[i];
if v.died then
v:destroy();
table.remove(owner.characs,i);
else
v:update(dt);
i=i+1;
end
end

for k,v in pairs(owner.objects)do
if v.died then
v:destroy();
owner.objects[k]=nil;
else
v:update(dt);
end
end

owner.ground:update(dt);
owner:updateCamera(dt);
owner:updateUI();
end
end

function owner:updateUI()
self.dia.txt:SetText(userDB.userInfo.dia);
self.rebirth.txt:SetText(userDB.userInfo.rebirth);
self.mkey.txt:SetText(string.format("%d/%d",userDB.userInfo.magickey,servertable.MaxMagicKey));
if userDB.userInfo.tmagickey>0 and userDB.userInfo.magickey<servertable.MaxMagicKey then
while userDB.userInfo.tmagickey<=os.time()do
userDB.SetUserInfo("magickey",math.min(servertable.MaxMagicKey,userDB.userInfo.magickey+1));
userDB.SetUserInfo("tmagickey",userDB.userInfo.tmagickey+servertable.MagicKeyDur);
end
local rt=math.max(0,userDB.userInfo.tmagickey-os.time());
self.tmkey:SetText(string.format("%02d:%02d",math.floor(rt/60),math.floor(rt)%60));
self.tmkey:SetVisible(true);
else
self.tmkey:SetVisible(false);
end
end

function owner:updateCamera(dt)
local w,h=APP_W,APP_H;
local pos=owner.player.pos;
owner.ground:setScroll(pos.x,pos.y,pos.x,pos.y,owner.player.tile.x,owner.player.tile.y,owner.zoom,w,h);
end
function owner:mouseUp(x,y)
local mx,my=world.ground:ScreenToTile(x,y);



local function query(o)
return true;
end
local o=self.grid:QueryR(mx,my,0,query);
if o and servertable.BoxOpenDia[o.sdata.id]then
local id=o.sdata.id;

local reqMKey=servertable.BoxOpenMKey[id];
local reqDia=servertable.BoxOpenDia[id];
local wnd=showPopup(world,"\236\156\160\236\160\129\236\151\180\234\184\176\237\140\157\236\151\133");
local otb=objecttable[id]or objecttable["_"..id];
wnd.name:SetText(otb and otb.name);
SpineObject(wnd.w,"_",o.tb.spine,o.tb["\234\184\176\235\179\184 \236\149\160\235\139\136"],o.tb.skin,o.tb.attachment,true)
SetButton(wnd.btnClose).onClick=function()
wnd:Remove();
end
SetTextButton(wnd.btnDia,reqDia or _L("\235\182\136\234\176\128")).onClick=function()
wnd:Remove();
local function cb(success)
if not _D["\236\156\160\236\160\129seq"][o.guid]then
owner:clearRelic(o.guid);
end
end
local function cbOpen()
_D["\236\156\160\236\160\129"][o.guid]="";
_D["\236\156\160\236\160\129seq"][o.guid]=nil;
end
OpenTotemBox(cb,_D["\236\156\160\236\160\129"][o.guid],reqDia,nil,nil,cbOpen,_D["\236\156\160\236\160\129seq"][o.guid]or string.sub(o.guid,2));
end
SetTextButton(wnd.btnMKey,reqMKey or _L("\235\182\136\234\176\128")).onClick=function()
wnd:Remove();
local function cb(success)
if not _D["\236\156\160\236\160\129seq"][o.guid]then
owner:clearRelic(o.guid);
end
end
local function cbOpen()
_D["\236\156\160\236\160\129"][o.guid]="";
_D["\236\156\160\236\160\129seq"][o.guid]=nil;
end
OpenTotemBox(cb,_D["\236\156\160\236\160\129"][o.guid],nil,reqMKey,nil,cbOpen,_D["\236\156\160\236\160\129seq"][o.guid]or string.sub(o.guid,2));
end
wnd.btnDia:enable(reqDia and userDB.userInfo.dia>=reqDia,1,2);
wnd.btnMKey:enable(reqMKey and userDB.userInfo.magickey>=reqMKey,1,2);

end
return true;
end

function owner:mouseDown(x,y)
return true;
end

function owner:mouseMove(x,y)
return true;
end

function owner:destroy()
end

AddMyInfoObserver(owner);
function owner:onUnload()
_G.GetTimeZone=_GetTimeZone;
DelMyInfoObserver(owner);
trace("onUnload");
owner:destroy();
userDB.Save();
end

function owner:onUpdateMyInfo(key)
end

function owner:setDirty()
end
trace("Lobby");

local function start(newGame)
_G.nextMap=_S["\237\152\132\236\158\172\235\167\181"];
if newGame then
root:GotoAndStop("intro");
else
root:GotoAndStop("travel");
end
end

local function newGame(slot)
local function onOk(avatar,job)
local function f()
local tb=jobtable[job];
local t={
["\236\149\132\235\176\148\237\131\128"]=avatar,
["\237\152\132\236\158\172\235\167\181"]=0,
["\236\167\129\236\151\133"]=job,
["\235\160\136\235\178\168"]=1,
["\237\158\152"]=tb["\237\158\152"],
["\235\175\188"]=tb["\235\175\188"],
["\236\167\128"]=tb["\236\167\128"],
["\236\178\180"]=tb["\236\178\180"],
["\236\154\180"]=tb["\236\154\180"],
};
LoadSlotData(slot,t,true);
userDB.Save(true);
start(true);
end
fade(owner.fade,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"),nil,nil,true,nil,f,nil,nil);
end
local function onCancel()
end

local function onSelectAvatar(avatar)
local wnd=showPopup(world,"\237\134\160\237\133\156\237\140\157\236\151\133");
local function _ok(job)
local wnd=showPopup(world,"\235\175\184\236\133\152\235\179\180\234\184\176\237\140\157\236\151\133");
local function _ok2()
onOk(avatar,job);
end
if table.empty(_D["\234\179\160\236\160\149\235\175\184\236\133\152"])then
NewWeekMission();
end
MissionPopup(wnd,_ok2,onCancel,_D["\234\179\160\236\160\149\235\175\184\236\133\152"]);
end
TotemPopup(wnd,_ok,onCancel,avatar);
end

do
local wnd=showPopup(world,"\236\149\132\235\176\148\237\131\128\237\140\157\236\151\133");
AvatarPopup(wnd,onSelectAvatar,onCancel);
end
end


SetButton(owner.btnLeader).onClick=function()
Viewrank();
end
SetButton(owner.btnAchieve).onClick=function()
Viewachieve();
end








SetButton(owner.btnIAchieve).onClick=function()
TryConnect(function()
local wnd=showPopup(world,"\235\143\132\236\160\132\234\179\188\236\160\156\237\140\157\236\151\133");
IAchieve(wnd);
end);
end

SetButton(owner.btnRecipe).onClick=function()
local wnd=showPopup(world,"\237\134\160\237\133\156\237\140\157\236\151\133",{size={x=0,y=0,cx=1280,cy=720}});
TotemPopup(wnd);
end
SetButton(owner.btnTotem).onClick=function()
TryConnect(function()
local wnd=showPopup(world,"\235\189\145\234\184\176\237\140\157\236\151\133");
GachaPopup(wnd);
end);
end


SetButton(owner.btnShop).onClick=function()
TryConnect(function()
local wnd=showPopup(world,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end

SetButton(owner.btnSetting).onClick=function()
local wnd=showPopup(world,"\236\132\164\236\160\149\237\140\157\236\151\133_\235\161\156\235\185\132");
SetOption(wnd);
end


SetButton(owner.dia).onClick=owner.btnShop.onClick;
SetButton(owner.rebirth).onClick=owner.btnShop.onClick;

SetButton(owner.dayBonus).onClick=function()
TryConnect(function()
local onFailed=function(s)
end
local onComplete=function(s)
local newdays=s.newdays;
local dbonus=s.dbonus;
local tday=s.rday+os.time();
if s.status=="ok"then
local mc=showPopup(owner,"\236\182\156\236\132\157\236\178\180\237\129\172\237\140\157\236\151\133");
SetButton(mc.btnClose).onClick=function()
mc:Remove();
end
local function updateTime()
local rt=math.max(0,tday-os.time());
mc.rday:SetText(string.format("%02d:%02d:%02d",math.floor(rt/3600),math.floor(rt/60)%60,math.floor(rt)%60));
return true;
end
mainTimer.addmc(mc,updateTime);
local function init()
local daybonus=0;
for k,v in pairs(dbonus)do
if v==1 then
daybonus=daybonus+1;
end
end
for i=1,7 do
local w=mc["d"..i];
w.cnt:SetText(string.format("X %d",servertable.DayBonus[i].dia or servertable.DayBonus[i].rebirth));
w.day:SetText(string.format(_L("\236\182\156\236\132\157\236\157\188"),i));
w.dia:SetVisible((servertable.DayBonus[i].dia or 0)>0);
w.rebirth:SetVisible((servertable.DayBonus[i].rebirth or 0)>0);
if s.newdays==i then
w.day:SetFontSize(35);
end
SetButton(w.btnGet).onClick=function()
local onFailed=function(s)
end
local onComplete=function(s)
if s.status=="ok"then
dbonus=s.dbonus;
init();
end
end
HttpWaitAsync(owner,
sendDayBonus(onComplete,onFailed,i),
lang.waitLoginInfo);
end
if newdays>=i then
if dbonus[i]==1 then
w.dia:SetBlendType(2);
w.rebirth:SetBlendType(2);
w.dia:SetAlphaDepth(0.5);
w.rebirth:SetAlphaDepth(0.5);
w.btnGet:GotoAndStop(2,true);
w.btnGet.txt:SetText(_L("\235\176\155\234\184\176 \236\153\132\235\163\140"));
w.btnGet:enable(false);
else
w.btnGet:GotoAndStop(1,true);
w.btnGet.txt:SetText(_L("\235\179\180\236\131\129 \235\176\155\234\184\176"));
end
else
w.btnGet:GotoAndStop(2,true);
w.btnGet.txt:SetText(_L("\235\179\180\236\131\129 \235\176\155\234\184\176"));
w.btnGet:enable(false);
end
end
end
init();
end
end
HttpWaitAsync(owner,
sendNewDay(onComplete,onFailed),
lang.waitLoginInfo);
end);
end

local function startGame()
end

SetButton(owner.btnStart).onClick=function()
local function fnTweener(o,s)
local alpha=0.5+0.5*s;
o:SetAlphaDepth(math.max(0,math.min(1,alpha)));
end
local mc=showPopup(owner,"\236\160\128\236\158\165\236\138\172\235\161\175\237\140\157\236\151\133",{backColor=0xC0000000,fnTweener=fnTweener,size={x=0,y=0,cx=APP_W,cy=APP_H}});
SetButton(mc.btnClose).onClick=function()
mc:Remove();
end
local function updateBtn()
for i=1,const("\236\160\128\236\158\165\236\138\172\235\161\175\236\136\152"),1 do
local s=mc["s"..i];
local d,err=userDB.LoadSlotData(i);
if err then trace("LoadSlotData failed",i,err);end
s.wnd:Clear();
if d and d.playing==1 then
local slots={};
for k,v in pairs(d["\236\138\172\235\161\175"])do
if d["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v]then
slots[k]=d["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v].id;
end
end
local p=TestPlayer(s.wnd:CreateEmptyMovieClip(""),d["\236\149\132\235\176\148\237\131\128"],slots);
p:init();
s.new:SetVisible(false);
s.del:SetVisible(true);
s.job:SetText(jobtable[d["\236\167\129\236\151\133"]].name.." LV"..d["\235\160\136\235\178\168"]);
s.day:SetText(string.format(_L("\236\152\164\237\148\136\236\161\176\234\177\180_\236\131\157\236\161\180"),GetDay(d.T)+1));


s:SetBound(s.bg:GetAABB());
SetButton(s).onClick=function()
local function onOk()
LoadSlotData(i,d);
fade(owner.fade,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"),nil,nil,true,nil,start,nil,nil);
end
local function onCancel()
end

local wnd=showPopup(owner,"\237\134\160\237\133\156\237\140\157\236\151\133");
TotemPopup(wnd,onOk,onCancel,d["\236\149\132\235\176\148\237\131\128"],d,i);
end
SetButton(s.del).onClick=function()
local mc2=showPopup(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\236\131\136\235\161\156\237\149\152\234\184\176\237\153\149\236\157\184"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
userDB.DelSlotData(i);
updateBtn();
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
end
else
s.new:SetVisible(true);
s.job:SetVisible(false);
s.day:SetVisible(false);
s.del:SetVisible(false);
SetButton(s).onClick=function()
newGame(i);
end
end
end
end
updateBtn();
end
owner:init();

end

function OpenTotemBox(cb,box,useDia,useMKey,useAd,cb2,seq)
TryConnect(function()
local c=0;
local t=nil;
local mc;
local complete=function()
c=c+1;
if c>1 then
local picks={};
local all={};










do
local keys={{"mkey","\235\167\136\235\178\149\236\151\180\236\135\160"},{"rebirth","\235\182\128\237\153\156"},{"dia","\235\179\180\236\132\157"}};
for i,v in ipairs(keys)do
if(t.reward[v[1]]or 0)>0 then
table.insert(all,{v[2],t.reward[v[1]]});
end
end
end

if t.addTotems then
for i,pick in ipairs(t.addTotems)do
table.insert(picks,pick);
table.insert(all,pick);

trace("pick",pick);
end
end






local function finish()
mc.wnd:Clear();
mc.step=2;
local list={};
local imgsizeW,imgsizeH=190,230;
local xsize,ysize=200,240;
local xgap,ygap=xsize-imgsizeW,ysize-imgsizeH;
local maxC=#picks;
local H=ysize-ygap;
local foot=30;
if maxC>5 then
maxC=math.ceil(maxC/2);
H=ysize*2-ygap;
end
local W=maxC*xsize-xgap;
local left,top=(APP_W-W)/2,(APP_H-H-foot)/2;
local x,y=left,top;
for i,id in ipairs(picks)do
local slot=mc:AddSymbol("\237\134\160\237\133\156\236\151\176\236\182\156\236\138\172\235\161\175","_");
slot:SetScale(0.5,0.5);
slot:SetPos(x,y);
x=x+xsize;
if i%maxC==0 then
x=left;
y=y+ysize;
end
if totemtable[id]or recipetable[id]then
SetButton(slot).onClick=function()
local function onOk(action,id)
trace("action",action,id);
if action=="equip"then
elseif action=="upgrade"then
end
end
ShowTotemInfoPopup(mc,id,nil,onOk,true);
end
else
assert(false,id);
end
SetTotemOrRecipeItemL(slot,id);
end
Tutorial(mc,"\235\189\145\234\184\176");

do
local keys={{"mkey","\235\189\145\234\184\176_\235\167\136\235\178\149\236\151\180\236\135\160"},{"rebirth","\235\189\145\234\184\176_\235\182\128\237\153\156"},{"dia","\235\189\145\234\184\176_\235\179\180\236\132\157"}};
local c=0;
for i,v in ipairs(keys)do
if t.reward[v[1]]then
c=c+1;
end
end
local size=200;
local gap=10;
local W=c*size-gap;
local left,top=(APP_W-W)/2,APP_H-foot-size/2;
local x,y=left,top;
for i,v in ipairs(keys)do
if t.reward[v[1]]then
local slot=mc:AddSymbol(v[2],"_");
slot:SetPos(x,y);
x=x+size;
slot.txt:SetText(t.reward[v[1]]);
end
end
end
mc.x:SetVisible(true);
end
local function showEfx(idx)
mc.step=1;
local id=all[idx];
if id then
mc.wnd:AddSymbol("\237\134\160\237\133\156\236\151\176\236\182\156\236\138\172\235\161\175\236\149\160\235\139\136","ani",{isTotem=totemtable[id]~=nil});
mc:shake(0.3,0,8);
if type(id)=="table"then
SetTotemOrRecipeItemL(mc.wnd.ani.w,id[1],id[2]);
else
SetTotemOrRecipeItemL(mc.wnd.ani.w,id);
end
function mc.wnd.ani:onEndScene()
self:Remove();
showEfx(idx+1);
end
else
finish();
end
mc.x:SetVisible(true);
end
SetButton(mc.x).onClick=function()
if(mc.step or 0)<2 then
finish();
else
mc:Remove();
cb(true);
end
end
showEfx(1);
end
end








local function sendSlotData()
local onS=function(s)
if s.status=="ok"then
trace("sendGameData ok");
userDB.option.__dirtySlots={};
userDB.Save();
end
end
local onF=function()
trace("sendGameData fail");
end
HttpSilentAsync(world,sendGameData(onS,onF,makeSaveData(),makeSlotData(),"save"));
end

mc=showPopup(world,"\235\189\145\234\184\176\236\151\176\236\182\156",{backColor=0xE0000000,fnTweener=function()end,size={x=0,y=0,cx=APP_W,cy=APP_H}});
local snd=mc:AddSymbol(soundtable["\235\189\145\234\184\176"].path..".wav","_");
snd:Play();
local onS=function(r)
if r.status=="ok"then
if cb2 then cb2();end
t=r;
if t.useDia then
ToastMoneyConsumption("boxopen",1,t.useDia,_D["\237\148\140\235\160\136\236\157\180"]);
end
complete();
sendSlotData();
else
if r.status=="nobox"then
if cb2 then cb2();end
end
mc:Remove();
showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[r.status]or _L("\236\156\160\236\160\129\236\151\180\234\184\176\236\139\164\237\140\168"));
cb(false);
end
end
local onF=function(t)
mc:Remove();
cb(false);
end
local anims={
["\235\182\128\236\138\164\235\159\172\236\167\132 \236\156\160\236\160\129"]="ani_open_S",
["\236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129"]="ani_open_S",
["\236\139\160\235\185\132\237\149\156 \236\156\160\236\160\129"]="ani_open_M",
["\237\153\169\234\184\136 \236\156\160\236\160\129"]="ani_open_M",
["\235\182\128\236\138\164\235\159\172\236\167\132 \236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129"]="ani_open_M",
["\236\158\145\236\157\128 \237\153\169\234\184\136 \236\156\160\236\160\129"]="ani_open_M",
["\234\177\176\235\140\128\237\149\156 \237\153\169\234\184\136 \236\156\160\236\160\129"]="ani_open_L"
};
local tb=objecttable["_"..box];
local efx=SpineObject(mc.wnd,"efx",tb.spine,anims[box],tb.skin,tb.attachment);
mc.onEndScene=function()
mc:Stop();
complete();
end

function mc:onEnterFrame(dt)
self:updateCamera(dt);
end

HttpSilentAsync(world,
sendOpenBox(onS,onF,box,useDia,useMKey,useAd,seq));


function mc:shake(dur,cx,cy)
self.shakeScroll={d=dur,cx=cx,cy=cy};
end

function mc:updateCamera(dt)
local pos={x=0,y=0};
if self.shakeScroll then
self.shakeScroll.x=(math.random()-0.5)*self.shakeScroll.cx;
self.shakeScroll.y=(math.random()-0.5)*self.shakeScroll.cy;
pos.x=pos.x+self.shakeScroll.x;
pos.y=pos.y+self.shakeScroll.y;
self.shakeScroll.t=(self.shakeScroll.t or 0)+dt;
if self.shakeScroll.t>=self.shakeScroll.d then
self.shakeScroll=nil;
end
end
self:SetCameraTranslation(pos.x,pos.y);
end
end);
end
