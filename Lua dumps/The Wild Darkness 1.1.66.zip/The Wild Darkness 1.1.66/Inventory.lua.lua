function Inventory(owner)
local selected=nil;
local sellCnt=0;

local prevScroll=nil;
local mode;
local function selectSlot(guid,onSelect,onCancel)
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
local matchSlots={};
for k,v in pairs(GetAvailSlots())do
if CanEquipItemToSlot(id,v)then
table.insert(matchSlots,v);
end
end
if#matchSlots==0 then
world.player:addChat(_L("\236\158\165\236\176\169\236\138\172\235\161\175\236\151\134\236\157\140"));
onCancel();


else
SelectSlotPopup(onSelect,onCancel,owner,matchSlots,guid,_S["\236\138\172\235\161\175"],nil,const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128"));
end
end
local function selectStorage(guid,onSelect,onCancel)
local matchSlots=GetItemStorageSlots(guid,mode);
if#matchSlots==0 then
world.player:addChat(_L("\236\157\180\235\143\153\234\176\128\235\176\169\236\151\134\236\157\140"));
onCancel();


else
SelectSlotPopup(onSelect,onCancel,owner,matchSlots,guid,_S["\236\138\172\235\161\175"],_L("\234\176\128\235\176\169\236\157\132 \236\132\160\237\131\157\237\149\180 \236\163\188\236\132\184\236\154\148"),const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128"));
end
end

local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(const("\236\138\172\235\161\175\235\170\169\235\161\157"))do

do
assert(owner[v],v);
owner[v]:Clear();
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(owner[v],guid);
else
assert(images[v],v);
SetItemIconFromGuid(owner[v]);
owner[v].img:AddSymbol(images[v],"icon");
end
end
end
end

local function showItemPopupImpl(guid)

local slot;
for k,v in pairs(GetAvailSlots())do
if guid==_S["\236\138\172\235\161\175"][v]then
slot=v;
break;
end
end
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
assert(o,guid);
local id=o.id;
local cnt=o.c or 1;
local item=itemtable[id];
local mc=showPopup(owner,"\236\149\132\236\157\180\237\133\156\237\140\157\236\151\133");

SetItemIconFromGuid(mc.icon,guid);
showItemDetail(guid,mc);

SetButton(mc.btnClose).onClick=function()
mc:Remove();
end

if slot then
SetTextButton(mc["\236\158\165\236\176\169\235\178\132\237\138\188"],_L("\235\178\151\234\184\176")).onClick=function()
mc:Remove();
if world.player:hasBuff("\237\150\137\235\143\153\235\182\136\234\176\128")then
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
else
world.player:beganTurn("next");
world.player:playSndQueue("\236\158\165\235\185\132\236\176\169\236\154\169");
UnEquipItem(slot);
world.player:updateCostume();
end
end
mc["\236\158\165\236\176\169\235\178\132\237\138\188"]:SetVisible(true);
else
SetTextButton(mc["\236\158\165\236\176\169\235\178\132\237\138\188"],_L("\236\158\165\236\176\169")).onClick=function()
mc:Remove();
local function onSelect(slot)
world.player:beganTurn("next");
world.player:playSndQueue("\236\158\165\235\185\132\236\176\169\236\154\169");





EquipItem(mode,guid,slot);

if HasItemOption(guid,"\236\160\128\236\163\188")then
local t=ev("\236\160\128\236\163\188\236\149\132\236\157\180\237\133\156\236\176\169\236\154\169\236\152\164\236\151\188\236\136\152\236\185\152");
if math.randpercent(t.P)then
_S:add("\236\152\164\236\151\188",t.V,0,ev("\236\181\156\235\140\128 \236\152\164\236\151\188"));
end
end

if IsStorageSlot(slot)then
prevScroll=nil;
end
end
local function onCancel(slot)
trace("onCancel");
end
selectSlot(guid,onSelect,onCancel);
end
mc["\236\158\165\236\176\169\235\178\132\237\138\188"]:SetVisible(CanEquipItemToSlot(id));
end

SetTextButton(mc["\236\160\149\235\160\172\235\178\132\237\138\188"],_L("\236\160\149\235\160\172")).onClick=function()
mc:Remove();
RearrangeStorages();

end

SetTextButton(mc["\235\178\132\235\166\172\234\184\176\235\178\132\237\138\188"],_L("\235\178\132\235\166\172\234\184\176")).onClick=function()
mc:Remove();
if slot and HasItemOption(guid,"\236\160\128\236\163\188")then
else
local function onOk(c)
local _mode=mode;
local needCopy=o.c~=c;
local function onSpellStart()
Projectile.itemId=UnidentityItemIdFromGuid(guid);
if not needCopy then
DelStorageItem(_mode,guid);
DelSlotItem(guid);
else
o.c=o.c-c;
DelBagItemType(id,c);
assert(o.c>0);
end
eventDispatcher:send("ThrowItem");
end
local function onSpellEnd(b,mx,my)
Projectile.itemId=nil;
if b then
if not needCopy then
PlaceItem(guid,mx,my);
else
CopyAndPlaceItem(guid,mx,my,c);
end
end
end
local extraSpells=nil;
world.player:useSpell(item["\235\178\132\235\166\172\234\184\176"],onSpellEnd,onSpellStart,nil,nil,extraSpells);
end
local function onCancel()
end
SelectItemCountPopup(onOk,onCancel,owner,guid);
end
end

SetTextButton(mc["\235\141\152\236\167\128\234\184\176\235\178\132\237\138\188"],_L("\235\141\152\236\167\128\234\184\176")).onClick=function()
mc:Remove();
local function onSpellStart()
Projectile.itemId=UnidentityItemIdFromGuid(guid);
end
local function onSpellEnd(b,mx,my)
Projectile.itemId=nil;
if b then
ConsumeItem(guid,nil,item["\235\185\132\236\154\176\234\184\176"]or true);
end
end
if item["\235\141\152\236\167\128\234\184\176"]then
owner.btnClose:onClick();

local extraSpells=nil;
if item["\236\162\133\235\165\152"]=="\235\172\188\236\149\189"then
if HasItemOption(guid,"\236\182\149\235\179\181")then
extraSpells={"\236\182\149\235\179\181 \235\172\188\236\149\189 \235\141\152\236\167\128\234\184\176"};
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
extraSpells={"\236\160\128\236\163\188 \235\172\188\236\149\189 \235\141\152\236\167\128\234\184\176"};
end
end
world.player:useSpell(item["\235\141\152\236\167\128\234\184\176"],onSpellEnd,onSpellStart,nil,nil,extraSpells);
end
end

SetTextButton(mc["\236\151\133\234\184\128\235\178\132\237\138\188"],_L("\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156")).onClick=function()
mc:Remove();
local function ok(itemId,guids)
world.player:beganTurn("touch");
if ConsumeItemsFromGuid(guids)then
ConsumeItem(guid);
MakeAndPlaceItem(itemId,_S.x,_S.y);
world.player:preEndTurn();
end
end
local function cancel()
end
local t=recipetable[item["\236\151\133\234\184\128"]];
BuildItemPopup(world,ok,cancel,"\236\160\156\236\158\145\235\178\149",{t.guid,t["\236\158\172\235\163\140"]});
end

SetTextButton(mc["\235\185\132\236\154\176\234\184\176\235\178\132\237\138\188"],_L("\235\185\132\236\154\176\234\184\176")).onClick=function()
mc:Remove();
local function f()
world.player:beganTurn("next");
world.player:playItemSound("\235\147\156\235\158\141",id);
ConsumeItem(guid,_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].c);
end
f();
end
SetTextButton(mc["\235\182\132\237\149\180\235\178\132\237\138\188"],_L("\235\182\132\237\149\180")).onClick=function()
local mc2=showPopup(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L("\235\182\132\237\149\180\235\178\132\237\138\188YN"));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
local function onSpellStart()
assert(ConsumeItemOrEquipItem(guid));
end
local function onSpellEnd()
_G["\234\176\128\236\185\152"]=nil;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
_G["\235\160\136\236\150\180\235\143\132"]=nil;
end
_G["\234\176\128\236\185\152"]=ItemValue(guid);
_G["\237\139\176\236\150\180"]=ItemTier(guid);
_G["\234\176\149\237\153\148"]=ItemUpgrade(guid);
_G["\235\160\136\236\150\180\235\143\132"]=const("\235\160\136\236\150\180\235\143\132")[o["\235\147\177\234\184\137"]or"\235\133\184\235\167\144"]or 0;
world.player:useSpell(item["\235\182\132\237\149\180"],onSpellEnd,onSpellStart);
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
mc:Remove();
end
SetTextButton(mc["\236\160\128\236\163\188\237\149\180\236\160\156\235\178\132\237\138\188"],_L("\236\160\128\236\163\188\237\149\180\236\160\156")).onClick=function()
local mc2=showPopupYN(owner,{msg=_L("\236\160\128\236\163\188\237\149\180\236\160\156\235\178\132\237\138\188YN"),mcName="\236\160\128\236\163\188\237\149\180\236\160\156\237\140\157\236\151\133"},function()
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
mc:Remove();
DelItemOption(nil,guid,"\236\160\128\236\163\188");
elseif t.status=="nodia"then
showPopupYN(owner,{msg=lang.nodiaQ},function()
TryConnect(function()
local wnd=showPopup(owner,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end);
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendRemoveCursed(onS,onF,"\236\160\128\236\163\188"),
lang.waitLoginInfo);
end);
end);
mc2.btnOk:GotoAndStop(1);
mc2.btnOk.txt:SetText(servertable.RemoveCursedPrice);
end
SetTextButton(mc["\235\167\136\235\178\149\235\166\172\236\133\139\235\178\132\237\138\188"],_L("\235\167\136\235\178\149\235\166\172\236\133\139")).onClick=function()
local mc2=showPopupYN(owner,{msg=_L("\235\167\136\235\178\149\235\166\172\236\133\139\235\178\132\237\138\188YN"),mcName="\236\160\128\236\163\188\237\149\180\236\160\156\237\140\157\236\151\133"},function()
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
mc:Remove();
o["\235\167\136\235\178\149"]=ChoiceBookSpell();
elseif t.status=="nodia"then
showPopupYN(owner,{msg=lang.nodiaQ},function()
TryConnect(function()
local wnd=showPopup(owner,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end);
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendSpellBookReset(onS,onF),
lang.waitLoginInfo);
end);
end);
mc2.btnOk:GotoAndStop(1);
mc2.btnOk.txt:SetText(servertable.SpellBookResetPrice);
end

SetTextButton(mc["\236\182\169\236\160\132\235\178\132\237\138\188"],_L("\236\182\169\236\160\132")).onClick=function()
local mc2=showPopupYN(owner,{msg=_L("\236\182\169\236\160\132\235\178\132\237\138\188YN"),mcName="\236\160\128\236\163\188\237\149\180\236\160\156\237\140\157\236\151\133"},function()
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
mc:Remove();
local function _ok()
eventDispatcher:send("ConsumeItem");
end
RechargeItem(_ok,guid,const("\236\132\156\237\140\144\236\182\169\236\160\132\234\176\156\236\136\152"));
elseif t.status=="nodia"then
showPopupYN(owner,{msg=lang.nodiaQ},function()
TryConnect(function()
local wnd=showPopup(owner,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end);
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendRecharge(onS,onF),
lang.waitLoginInfo);
end);
end);
mc2.btnOk:GotoAndStop(1);
mc2.btnOk.txt:SetText(servertable.RechargePrice);
end

if(slot and HasItemOption(guid,"\236\160\128\236\163\188"))then
mc["\235\178\132\235\166\172\234\184\176\235\178\132\237\138\188"]:GotoAndStop(2,true);
mc["\235\178\132\235\166\172\234\184\176\235\178\132\237\138\188"]:enable(false);
mc["\235\182\132\237\149\180\235\178\132\237\138\188"]:GotoAndStop(2,true);
mc["\235\182\132\237\149\180\235\178\132\237\138\188"]:enable(false);
mc["\236\158\165\236\176\169\235\178\132\237\138\188"]:GotoAndStop(2,true);
mc["\236\158\165\236\176\169\235\178\132\237\138\188"]:enable(false);
end

SetTextButton(mc["\235\172\188\235\156\168\234\184\176\235\178\132\237\138\188"],_L("\235\172\188\235\156\168\234\184\176")).onClick=function()
mc:Remove();
local function _ok2(guid)
local function f()
world.player:preEndTurn();
MakeWaterBottle(guid,GetNearStream());
end
local function cb(evt,param)
if evt=="COMPLETE"then
f();
end
end
world.player:beganTurn("touch");
world.player:playItemSound("\236\164\141\234\184\176",id);
world.player:play("ani_get",nil,nil,cb);
end


_ok2(guid);

end

SetTextButton(mc["\235\168\185\234\184\176\235\178\132\237\138\188"],string.ends(item["\235\168\185\234\184\176"],"\235\167\136\236\139\156\234\184\176")and _L("\235\167\136\236\139\156\234\184\176")or _L("\235\168\185\234\184\176")).onClick=function()
mc:Remove();
local function onSpellStart()
SetItemIdIdentity(o.id);

if o["\236\154\169\235\159\137"]and o["\236\154\169\235\159\137"][2]>1 then
o["\236\154\169\235\159\137"][1]=o["\236\154\169\235\159\137"][1]-1;
if o["\236\154\169\235\159\137"][1]<=0 then
ConsumeItem(guid);
else
eventDispatcher:send("ConsumeItem");
end
else
ConsumeItem(guid);
end
end
local function onSpellEnd(b)
if b then
trace("!!!\235\168\185\234\184\176 \236\153\132\235\163\140",guid);
if(_S["\236\157\140\236\139\157T"]or 0)==0 then
_S["\236\157\140\236\139\157T"]=_S.T;
end
EatItem(o);
Mission("\235\168\185\234\184\176",1,item.guid);
end
end

if item["\235\168\185\234\184\176"]then
local spell=nil;
if type(item["\235\168\185\234\184\176"])=="table"then
for k,v in pairs(item["\235\168\185\234\184\176"])do
if k=="\236\161\176\235\166\172\236\157\180\235\130\180"and v.T>=o.T then
spell=v.V;
end
end
if not spell then
spell=item["\235\168\185\234\184\176"]["\234\183\184\236\153\184"];
end
else
spell=item["\235\168\185\234\184\176"];
end
if o["\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"]then
spell=o["\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"].." \236\152\164\236\151\188\235\144\156 \236\154\148\235\166\172 \235\168\185\234\184\176";
end

local extraSpells=nil;
if item["\235\176\148\235\161\156\235\168\185\234\184\176"]and item["\235\176\148\235\161\156\235\168\185\234\184\176"][1]>=(o.T or 0)then
extraSpells={item["\235\176\148\235\161\156\235\168\185\234\184\176"][2]};
trace("extraSpells",extraSpells);
end
world.player:useSpell(spell,onSpellEnd,onSpellStart,nil,nil,extraSpells);
end
end
SetTextButton(mc["\235\176\148\235\165\180\234\184\176\235\178\132\237\138\188"],_L("\235\176\148\235\165\180\234\184\176")).onClick=function()
mc:Remove();
do

local function _ok(_guid)
local function cb()

ConsumeItem(guid);
world.player:beganTurn("next");
end
AddItemOption(cb,_guid,item["\235\176\148\235\165\180\234\184\176"]);
end
local function onCancel()
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176"},"\236\157\184\236\177\136\237\138\184",{item=guid});
end
end
SetTextButton(mc["\236\130\172\236\154\169\235\178\132\237\138\188"],_L("\236\130\172\236\154\169")).onClick=function()
mc:Remove();
if item["\236\130\172\236\154\169"]=="\235\185\132\236\160\132 \236\160\156\236\158\145\235\178\149"then
if o["\235\175\184\237\153\149\236\157\184"]then
owner.btnClose:onClick();
world.player:addChat(_L("\237\153\149\236\157\184\237\149\132\236\154\148"));
else
local function _ok(_guid)
ConsumeItem(guid);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_guid];
local v1=o["\235\147\177\234\184\137"];
SetItemRare(_guid);
o["\234\176\149\237\153\148"]=(o["\234\176\149\237\153\148"]or 0)+countkcc(const("\235\185\132\236\160\132\236\160\156\236\158\145\235\178\149\234\176\149\237\153\148"));
AddItemOption(nil,_guid,0,{"\236\164\145\234\176\132","\236\162\139\236\157\140"});
local v2=o["\235\147\177\234\184\137"];
local function cb()
world.player:beganTurn("next");
end
ItemMessagePopup(cb,guid,_L("\235\160\136\236\150\180\237\131\128\236\157\180\237\139\128"),{{_L("\235\147\177\234\184\137"),_L(v1),_L(v2)}});
end
local function onCancel()
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176","\235\176\169\236\150\180\234\181\172","\236\149\133\236\132\184\236\132\156\235\166\172","\236\149\132\237\139\176\237\140\169\237\138\184"},"\235\185\132\236\160\132",{item=guid,["\235\147\177\234\184\137"]="\235\133\184\235\167\144",tier=o.tier,detail=string.format(_L("\235\185\132\236\160\132\236\132\160\237\131\157\236\132\164\235\170\133"),ItemName(guid))});
end
elseif item["\236\130\172\236\154\169"]=="\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145\235\178\149"then
ConsumeItem(guid);
local v1=(_S["\235\160\136\236\132\156\237\148\188"][o.recipe]or 0);
local v2=v1+1;
_S["\235\160\136\236\132\156\237\148\188"][o.recipe]=v2;
local function cb()
world.player:beganTurn("next");
end
local msg;
if v1==0 then
msg=string.format(_L("\236\160\156\236\158\145\235\178\149\237\154\141\235\147\157\237\153\149\236\157\184"),itemtable[o.recipe].name);
else
msg=string.format(_L("\236\160\156\236\158\145\235\178\149\234\176\149\237\153\148\237\153\149\236\157\184"),itemtable[o.recipe].name);
end
ItemMessagePopup(cb,guid,msg,{{_L("\235\160\136\235\178\168"),v1,v2}});
elseif item["\236\130\172\236\154\169"]=="\236\158\165\235\185\132 \236\160\156\236\158\145\235\178\149"then
local recipe=recipetable[o.recipe];
assert(recipe,o.recipe);







do
ConsumeItem(guid);
local grade="\236\158\165\235\185\132";
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][o.recipe]then
grade=recipe["\235\147\177\234\184\137"];
end
trace("grade",grade,const("\236\158\165\235\185\132\236\160\156\236\158\145\235\178\149\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156",grade));
local maxLv=GetRecipeMaxLv(o.recipe);
local v1=(_S["\235\160\136\236\132\156\237\148\188"][o.recipe]or 0);
local v2=math.min(maxLv,v1+countkcc(const("\236\158\165\235\185\132\236\160\156\236\158\145\235\178\149\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156",grade)));
_S["\235\160\136\236\132\156\237\148\188"][o.recipe]=v2;
local function cb()
world.player:beganTurn("next");
end
local msg;
if v1==0 then
msg=string.format(_L("\236\160\156\236\158\145\235\178\149\237\154\141\235\147\157\237\153\149\236\157\184"),itemtable[o.recipe].name);
else
msg=string.format(_L("\236\160\156\236\158\145\235\178\149\234\176\149\237\153\148\237\153\149\236\157\184"),itemtable[o.recipe].name);
end
ItemMessagePopup(cb,guid,msg,{{_L("\235\160\136\235\178\168"),v1,v2}});
end
elseif item["\236\130\172\236\154\169"]=="\235\167\136\235\178\149\236\177\133"then
owner.btnClose:onClick();
if o["\235\175\184\237\153\149\236\157\184"]then
world.player:addChat(_L("\237\153\149\236\157\184\237\149\132\236\154\148"));
else
local function _onOk(idx,key)
local c=1;
local lv=_S["\235\167\136\235\178\149"][key]or 0;
if HasItemOption(guid,"\236\182\149\235\179\181")then
c=2;
end

if HasItemOption(guid,"\236\160\128\236\163\188")then
for k,v in pairs(ev("\236\160\128\236\163\188 \235\167\136\235\178\149\236\177\133 \237\154\168\234\179\188"))do
world.player:addDebufP(v,k,world.player);
end
end
ConsumeItem(guid);
if AddMagicLv(key,c)then
_S["\236\149\148\234\184\176\235\167\136\235\178\149"][idx]=key;
world.player:playSndQueue("\235\167\136\235\178\149\236\149\148\234\184\176");
world.player:addChat(_L("\235\167\136\235\178\149\235\160\136\235\178\168\237\131\128\236\157\180\237\139\128"));
end
world.player:beganTurn("next");
end
local function onCancel()
end
local mc=showPopup(world,"\235\167\136\235\178\149\236\149\148\234\184\176\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
ReadBookPopup(mc,ItemName(guid),o["\235\167\136\235\178\149"],_onOk,onCancel);
end
elseif item["\236\130\172\236\154\169"]=="\236\157\184\236\177\136\237\138\184"then
do

local function _ok(_guid)
if ConsumeItem(guid)then
local rune=string.sub(id,1,string.find(id,"\236\157\152 \236\160\149\236\136\152")-1);
trace("rune",rune);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_guid];
local function cb()
world.player:beganTurn("next");
end
AddItemOption(cb,_guid,0,nil,rune);
end
end
local function onCancel()
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176","\235\176\169\236\150\180\234\181\172","\236\149\133\236\132\184\236\132\156\235\166\172","\236\149\132\237\139\176\237\140\169\237\138\184"},"\236\157\184\236\177\136\237\138\184",{item=guid});
end
elseif item["\236\130\172\236\154\169"]=="\236\176\168\236\155\144\236\157\152 \236\132\156\237\140\144"then
trace("\236\182\169\236\160\132",o["\236\182\169\236\160\132"]);
local map=maptable[_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173"]];
if map["\236\132\156\237\140\144\235\182\136\234\176\128"]then
world.player:addChat(_L("\236\130\172\236\154\169\235\182\136\234\176\128"));
else

do
owner.btnClose:onClick();
_G.useMapItem=guid;
local mc=world:AddSymbol("\236\155\148\235\147\156\235\167\181\237\140\157\236\151\133");
SetButton(mc.btnClose).onClick=function()
_G.useMapItem=nil;
mc:Remove();
end
SetWorldMap(mc.w);


end
end
elseif item["\236\130\172\236\154\169"]=="\235\130\180\234\181\172\235\143\132\237\154\140\235\179\181"then
local function _ok(itemGuid)

if ConsumeItem(guid)then
local o1=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local g1=o1["\235\147\177\234\184\137"];
_G.RRB=repairtable[g1]["\235\133\184\235\167\144"];
_G["\237\139\176\236\150\180"]=ItemTier(itemGuid)or 0;
repair=ev("\236\136\152\235\166\172\235\167\157\236\185\152\235\130\180\234\181\172\235\143\132\237\154\140\235\179\181");
_G.RRB=nil;
_G["\237\139\176\236\150\180"]=nil;
local function cb()
world.player:beganTurn("next");
end
RepairItem(cb,itemGuid,repair);
end













end
local function onCancel()
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176","\235\176\169\236\150\180\234\181\172"},"\236\136\152\235\166\172",{item=guid,noMaterial=true});
elseif spelltable[item["\236\130\172\236\154\169"]]then
local function onSpellEnd(b)
if b then
Mission("\236\130\172\236\154\169",1,item.guid);
end
end
local function onSpellStart()
SetItemIdIdentity(o.id);
if item["\236\130\172\236\154\169"]=="\235\130\154\236\139\156\237\149\152\234\184\176"then
if not ConsumeItemType("\236\167\128\235\160\129\236\157\180",1)then
world.player:addChat(_L("\235\175\184\235\129\188\236\151\134\236\157\140"));
return false;
end
if o["\235\130\180\234\181\172\235\143\132"]>0 then
world.player.touchTool=guid;
world.player:updateCostume();
DecreaseToolDurability(world.player.touchTool);
else
world.player:addChat(_L("\235\130\154\236\139\156 \235\143\132\234\181\172 \236\151\134\236\157\140"));
return false;
end
elseif item["\236\162\133\235\165\152"]=="\236\163\188\235\172\184\236\132\156"then
local v=world.player:bf("\236\163\188\235\172\184\236\132\156 \236\130\172\236\154\169\236\139\156 \236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181\236\156\168");
if v>0 then
local max=world.player:bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128");
world.player:healEnergy(max*v);
end
if DelItemOption(nil,guid,"\236\182\149\235\179\181")or math.randpercent(world.player:bf("\236\163\188\235\172\184\236\132\156 \235\130\168\236\157\132 \237\153\149\235\165\160"))then
else
if HasItemOption(guid,"\236\160\128\236\163\188")then
for k,v in pairs(ev("\236\160\128\236\163\188 \236\163\188\235\172\184\236\132\156 \237\154\168\234\179\188"))do
world.player:addDebufP(v,k,world.player);
end
end
ConsumeItem(guid);
end
else
ConsumeItem(guid);
end
end

local forceFail=false;
local addLV=0;
if item["\236\162\133\235\165\152"]=="\236\163\188\235\172\184\236\132\156"then
if HasItemOption(guid,"\236\160\128\236\163\188")then
forceFail=math.randpercent(ev("\236\160\128\236\163\188 \236\163\188\235\172\184\236\132\156 \236\139\164\237\140\168 \237\153\149\235\165\160"));
end
elseif item["\236\162\133\235\165\152"]=="\235\167\136\235\178\149\236\177\133"then
if HasItemOption(guid,"\236\160\128\236\163\188")then
forceFail=math.randpercent(ev("\236\160\128\236\163\188 \235\167\136\235\178\149\236\177\133 \236\139\164\237\140\168 \237\153\149\235\165\160"));
end
end

if o["\235\179\181\236\130\172"]then
forceFail=forceFail or math.randpercent(ev("\235\179\181\236\130\172 \236\163\188\235\172\184\236\132\156 \236\139\164\237\140\168 \237\153\149\235\165\160"));
end

world.player:useSpell(item["\236\130\172\236\154\169"],onSpellEnd,onSpellStart,forceFail,addLV);
end
end

SetTextButton(mc["\236\157\180\235\143\153\235\178\132\237\138\188"],_L("\236\157\180\235\143\153")).onClick=function()
mc:Remove();
local function onSelect(slot)
assert(DelStorageItem(mode,guid));
if AddItemToStorage(guid,true,{slot})then
local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
assert(o);
for k,v in pairs(o["\234\176\128\235\176\169"])do
if v==guid then
o["\234\176\128\235\176\169"][k]=0;
end
end

world.player:playSndQueue("\236\157\184\235\178\164\237\134\160\235\166\172 \236\185\184 \236\157\180\235\143\153");
else
assert(AddItemToStorage(guid,true,{mode}));
world.player:addChat(_L("\234\176\128\235\176\169\236\157\180\235\143\153\236\139\164\237\140\168"));
end
end
local function onCancel(slot)
trace("onCancel");
end
selectStorage(guid,onSelect,onCancel);
end

mc["\235\168\185\234\184\176\235\178\132\237\138\188"]:SetVisible(item["\235\168\185\234\184\176"]~=nil);
mc["\236\130\172\236\154\169\235\178\132\237\138\188"]:SetVisible(item["\236\130\172\236\154\169"]~=nil);
mc["\235\141\152\236\167\128\234\184\176\235\178\132\237\138\188"]:SetVisible(item["\235\141\152\236\167\128\234\184\176"]~=nil);
mc["\235\176\148\235\165\180\234\184\176\235\178\132\237\138\188"]:SetVisible(item["\235\176\148\235\165\180\234\184\176"]~=nil);
mc["\235\185\132\236\154\176\234\184\176\235\178\132\237\138\188"]:SetVisible(item["\235\185\132\236\154\176\234\184\176"]~=nil);
mc["\235\182\132\237\149\180\235\178\132\237\138\188"]:SetVisible(item["\235\182\132\237\149\180"]~=nil);
mc["\236\160\128\236\163\188\237\149\180\236\160\156\235\178\132\237\138\188"]:SetVisible(slot and HasItemOption(guid,"\236\160\128\236\163\188"));
mc["\235\167\136\235\178\149\235\166\172\236\133\139\235\178\132\237\138\188"]:SetVisible(item["\236\130\172\236\154\169"]=="\235\167\136\235\178\149\236\177\133");
mc["\235\172\188\235\156\168\234\184\176\235\178\132\237\138\188"]:SetVisible(item["\235\172\188\235\156\168\234\184\176"]~=nil and GetNearStream()~=nil);
mc["\236\151\133\234\184\128\235\178\132\237\138\188"]:SetVisible(item["\236\151\133\234\184\128"]~=nil);
mc["\235\178\132\235\166\172\234\184\176\235\178\132\237\138\188"]:SetVisible(item["\235\178\132\235\166\172\234\184\176"]~=nil);
mc["\236\160\149\235\160\172\235\178\132\237\138\188"]:SetVisible(IsStorageSlot(slot));
mc["\236\157\180\235\143\153\235\178\132\237\138\188"]:SetVisible(not slot and not table.empty(GetItemStorageSlots(guid,mode)));

mc["\236\182\169\236\160\132\235\178\132\237\138\188"]:SetVisible(item["\236\162\133\235\165\152"]=="\236\176\168\236\155\144\236\157\152 \236\132\156\237\140\144"and o["\236\182\169\236\160\132"][1]<const("\236\176\168\236\155\144\236\157\152\236\132\156\237\140\144\236\182\169\236\160\132\236\130\172\236\154\169"));

Align(
{mc.req,mc.tier,mc.line2,mc["\236\158\165\236\176\169\235\178\132\237\138\188"],mc["\236\130\172\236\154\169\235\178\132\237\138\188"],mc["\235\168\185\234\184\176\235\178\132\237\138\188"],mc["\235\176\148\235\165\180\234\184\176\235\178\132\237\138\188"],mc["\235\172\188\235\156\168\234\184\176\235\178\132\237\138\188"],mc["\235\178\132\235\166\172\234\184\176\235\178\132\237\138\188"],mc["\236\182\169\236\160\132\235\178\132\237\138\188"],mc["\235\185\132\236\154\176\234\184\176\235\178\132\237\138\188"],mc["\235\141\152\236\167\128\234\184\176\235\178\132\237\138\188"],mc["\236\151\133\234\184\128\235\178\132\237\138\188"],mc["\235\182\132\237\149\180\235\178\132\237\138\188"],mc["\236\160\128\236\163\188\237\149\180\236\160\156\235\178\132\237\138\188"],mc["\235\167\136\235\178\149\235\166\172\236\133\139\235\178\132\237\138\188"],mc["\236\157\180\235\143\153\235\178\132\237\138\188"],mc["\236\160\149\235\160\172\235\178\132\237\138\188"]},
"left,right,bottom",{5,5}
);
mc.typeC:SetY(mc.tier:GetY()-30);
end

local function showItemPopup(guid)
world:preAct(function()
if world.player:canAct()then
showItemPopupImpl(guid);
end
end);
end

local function initBag()
trace("initbag");
if owner.wndItem then
owner.wndItem:Remove();
end

do
for k,v in ipairs(const("\234\176\128\235\176\169\236\138\172\235\161\175\235\170\169\235\161\157"))do
if mode==v then
owner[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner[v].img:SetAlphaDepth(0.3);
else
owner[v].img:SetAlphaDepth(1);
end
end
end
















selected=nil;
owner.list:Clear();
trace("mode",mode);
SetInvenWnd(owner.list,mode);
if prevScroll then
owner.list.list.setScroll(prevScroll);
end
function owner.list.list:onScroll(s)
prevScroll=s;
end
owner.list.list.onSelected=function(this,mc,guid)
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
showItemPopup(guid);
end
return true;
end
owner.list.list.setInfo=function(this,mc,guid)
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(mc,guid);
Tutorial(owner,"\236\157\184\235\178\164\237\134\160\235\166\172",{["\236\149\132\236\157\180\237\133\156"]={mc},guid=guid});
else
SetItemIconFromGuid(mc);
end
end
owner.list:init();
end


function owner:changeMode(slot)
mode=slot;
prevScroll=nil;
initBag();
end




for k,v in pairs(const("\236\138\172\235\161\175\235\170\169\235\161\157"))do
SetButton(owner[v],nil,nil,nil,0,0).onClick=function()
if _S["\236\138\172\235\161\175"][v]~=0 and table.find(GetAvailSlots(),v)then
if IsStorageSlot(v)then
if mode==v then
showItemPopup(_S["\236\138\172\235\161\175"][v]);
else
owner:changeMode(v);
end
else
showItemPopup(_S["\236\138\172\235\161\175"][v]);
end
end
end
end
















function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
if not mode or _S["\236\138\172\235\161\175"][mode]==0 then
for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end
end

initSlots();
initBag();
end

eventDispatcher:add(owner,owner.onEvent);

owner:init();
end

function SetInvenWnd(owner,mode)
local _,y,_,h=owner.parent.back:GetAABB();
local sx,sy=owner.parent.back:GetScale();
local patternH=APP_H-y;
local scale=patternH/h;
h=patternH;
owner.parent.back:SetScale(sx,sy*scale);
local viewSize={cx=648-55,cy=h-34};
owner:SetClipRect(0,0,APP_W,viewSize.cy);








owner.list=owner:CreateEmptyMovieClip("");

do
local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
if o then
SetInvenList(owner.list,viewSize,o["\234\176\128\235\176\169"]);
else
SetInvenList(owner.list,viewSize,{});
end
end
function owner:init()
owner.list:init();
end
end
