function NewJobPopup(owner,ids,avatar,cb)
local idx=1;
local mc=showPopup(owner,"\236\167\129\236\151\133\237\154\141\235\147\157\237\140\157\236\151\133");
snd=mc:AddSymbol("E_levelup.wav","");
snd:Play();
local function show()
local id=ids[idx];
local v=jobtable[id];
mc.wnd:Clear();
mc.get:Clear();
local obj,sk=SpineObject(mc.wnd,"efx","player","ani_idle","all",nil,true);
local atb=avatartable[avatar];
sk:setSkin(v["\235\168\184\235\166\172"]);
sk:setSkin(v["\235\170\184\237\134\181"]);
sk:setAttachment("weapon_R",v["\235\172\180\234\184\1761"]);
sk:setAttachment("weapon_L",v["\235\172\180\234\184\1762"]);

sk:setAttachment("hair_front",atb.hair_f);
sk:setAttachment("hair_rear_02",atb.hair_r);
sk:setAttachment("head",atb.head);
sk:setAttachment("head2",atb.head_tarak);
for k,v in pairs(v.costume)do
sk:setAttachment(k,atb[v]);
end
mc.class:SetText(v.name);

SpineObject(mc.get,"get","ani_effect_get","ani_light_get","default",nil,true);
end

SetButton(mc.btnClose).onClick=function()
if ids[idx+1]then
idx=idx+1;
show();
else
mc:Remove();
if cb then
cb();
end
end
end
show();
end