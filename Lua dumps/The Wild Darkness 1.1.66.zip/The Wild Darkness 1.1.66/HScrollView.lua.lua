
function SetHScrollView(this)
local easing=outQuad;
local delay=0.4;
local left=0;
local moveTable=nil;
local click=nil;
local clickPos=0;
local clickTime=0;
local totalOffset=0;
local tweener=nil;
local moved=0;
local prevTime=0;
local calcT=0.2;
local scrollRate=2;
local clickLimit=0.5;
local scrollTime=1500;
local scrollLimit=1000;
local selectLimit=20;
local contentSize=0;
local viewLimit=APP_W;
local reverseLimit=100;
local scrollbarPos=APP_H;
local scrollbar=nil;
local snd=GetAppSound(this,"hscroll");
local updateScroll=function()
local x=this:GetX();
if contentSize>viewLimit then
if not scrollbar then
scrollbar=this:AddSymbol("hscrollbar","");
scrollbar:SetZOrder(1);
end
local barSize=48;
local cSize=(contentSize-viewLimit);
local viewPos=(left-x)/cSize;
local scrollSize=math.max(100,viewLimit/contentSize*viewLimit);
if viewPos<0 then
scrollSize=math.max(scrollSize+viewPos*cSize,barSize*2/3);
viewPos=0;
elseif viewPos>1 then
scrollSize=math.max(scrollSize-(viewPos-1)*cSize,barSize*2/3);
viewPos=1;
end
scrollbar:SetPos((viewLimit-scrollSize)*viewPos-x,scrollbarPos);
for k,v in pairs(scrollbar:GetShapeList())do
v:SetScaleX(scrollSize/barSize);
end
else
if scrollbar then
scrollbar:Remove();
scrollbar=nil;
end
end
if this.onScroll then
this:onScroll(this:getScroll());
end
end

local trackMouse=function(offset)
local dt=getTime()-prevTime;
table.insert(moveTable,{t=dt,s=offset});
moveTable.dt=moveTable.dt+dt;
if moveTable.dt>calcT then
moveTable.dt=moveTable.dt-moveTable[1].t;
table.remove(moveTable,1);
end
prevTime=getTime();
end

local calcVelocity=function()
local dt=0;
local s=0;
for i=#moveTable,1,-1 do
dt=dt+moveTable[i].t;
s=s+moveTable[i].s;
if dt>calcT then
break;
end
end
if dt~=0 then
return s/dt;
end
return 0;
end

this.onMouseDown=function(this,x,y,id)
if this:GetX()+x>=0 and this:GetX()+x<viewLimit and y>=0 then
click=id;
clickPos=x;
this:SetMouseCapture(true);
clickTime=getTime();
totalOffset=0;
tweener=nil;
moved=0;
moveTable={dt=0};
prevTime=getTime();
if this.onScrollBegin then
this:onScrolBegin(this:getScroll());
end
updateScroll();
return true;
end

end

this.setX=function(this,x)

this:SetX(x);
end

this.onMouseMove=function(this,x,y,id)
if click==id then
local offset=x-clickPos;
totalOffset=totalOffset+offset;
this:setX(this:GetX()+offset);
moved=moved+math.abs(offset);
trackMouse(offset);
updateScroll();
if this.onDraging then
this:onDraging(x-offset,y,id);
end
return click==id;
end
end
this.isDraging=function(this)
return click;
end

this.releaseDrag=function(this)
if click then
click=nil;
this:SetMouseCapture(false);
local mc=this;
local cx=contentSize;
if mc:GetX()>=left or(mc:GetX()<left and cx<viewLimit)then
tweener=Tweener(mc,mc.setX,mc:GetX(),left,delay,0,easing);
elseif mc:GetX()+cx<left+viewLimit then
tweener=Tweener(mc,mc.setX,mc:GetX(),left+viewLimit-cx,delay,0,easing);
end
end
end

this.onMouseUp=function(this,x,y,id)
if click==id then
click=nil;
this:SetMouseCapture(false);
trackMouse(0);
local mc=this;
local vel=calcVelocity();
local cx=contentSize;
if cx==0 then
_,_,cx,_=mc:GetBound();
end

if this.onScrollEnd then
this:onScrollEnd(this:getScroll());
end


if mc:GetX()>=left or(mc:GetX()<left and cx<viewLimit)then
tweener=Tweener(mc,mc.setX,mc:GetX(),left,delay,0,easing);
elseif mc:GetX()+cx<left+viewLimit then
tweener=Tweener(mc,mc.setX,mc:GetX(),left+viewLimit-cx,delay,0,easing);
elseif math.abs(vel)>=scrollLimit then
local px=0;
if vel>0 then px=(vel-scrollLimit)/scrollRate;else px=(vel+scrollLimit)/scrollRate;end;
if vel<0 then
if(mc:GetX()+px)<(left+viewLimit-cx)-reverseLimit then
px=(left+viewLimit-cx)-reverseLimit-mc:GetX();
end

local t=math.abs(px)/scrollTime;
local offset=(mc:GetX()+px)-(left+viewLimit-cx);
tweener=Tweener(mc,mc.setX,mc:GetX(),mc:GetX()+px,t,0,easing);
if offset<0 then
tweener.onCompleted=function(self)
local t=math.abs(offset)/scrollTime*2;
tweener=Tweener(mc,mc.setX,mc:GetX(),mc:GetX()-offset,delay,0,easing);
end
end
else
if(mc:GetX()+px)>(left)+reverseLimit then
px=(left)+reverseLimit-mc:GetX();
end

local t=math.abs(px)/scrollTime;
local offset=(mc:GetX()+px)-(left);
tweener=Tweener(mc,mc.setX,mc:GetX(),mc:GetX()+px,t,0,easing);
if offset>0 then
tweener.onCompleted=function(self)
tweener=Tweener(mc,mc.setX,mc:GetX(),mc:GetX()-offset,delay,0,easing);
end
end
end
end

do
local diff=getTime()-clickTime;
if moved<selectLimit and diff<clickLimit then
if this.onSelect then
if this:onSelect(x,y)then
if snd then
snd:Play();
end
end
end
end
end
return true;
end
end

this.onEnterFrame=function(this,dt)
if tweener then
tweener.update(dt);
if tweener.completed then
tweener=nil;
end
updateScroll();
end
end

this.setContentSize=function(size)
contentSize=size;
updateScroll();
end
this.getContentSize=function()
return contentSize;
end
this.setViewLimit=function(size)
viewLimit=size;
updateScroll();
end

this.setScroll=function(pos)
if tweener then
tweener=nil;
end
this:setX(left+pos);
updateScroll();
end

this.getScroll=function()
return this:GetX()-left;
end

this.setScrollLeft=function(v)
left=v;
updateScroll();
end

this.getScrollLeft=function()
return left;
end

this.setScrollBarPos=function(v)
scrollbarPos=v;
updateScroll();
end

this.setScrollRight=function()
this.setScroll(left+viewLimit-contentSize);
end

this.hasMoved=function()
return moved>=selectLimit;
end

this.cancelScroll=function()
tweener=nil;
end
end