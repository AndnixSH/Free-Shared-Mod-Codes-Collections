function MissionPopup(owner,onOk,onCancel,missions,inGame)
local _,_,W,H=owner.back:GetAABB();
local margin=50
if owner.btnOk then
margin=100;
end
local wndY=(owner.w or owner.w2):GetY();
local size=90;


local function makeTxt(t,v)
local s=t["\236\132\164\235\170\133_"..curLang]or"";
local dict2={};
for i=1,9 do
local cond=t["\236\161\176\234\177\180"..i];
if not cond then
break;
end
local dict={};
local n=t["\236\136\152\236\185\152"..i];
local inv=t["\236\161\176\234\177\180"..i.."\236\139\164\237\140\168"];
local data=v["data"..i]or 0;
local id=cond[2];
local _1;
if id then
if itemtable[id]then
_1=itemtable[id].name;
elseif objecttable[id]then
_1=objecttable[id].name;
elseif monstertable[id]then
_1=monstertable[id].name;
elseif mapbptable[id]then
_1=mapbptable[id].name;
elseif lang[id]then
_1=lang[id];
end
else
_1=nil;
end
if _1 then
dict["{1}"]=_1;
dict["{\236\157\132}"]=SelectJosa(_1,{"\236\157\132","\235\165\188"});
else
dict["{1}"]="";
dict["{\236\157\132}"]="";
end
if n then
dict["{n}"]=n;
end
if not t["\236\132\164\235\170\133_"..curLang]then
if i>1 then s=s.."\n";end
s=s..string.trim(ReplaceString(_L("\235\175\184\236\133\152_"..cond[1]),dict));
if n and inGame then
s=s..string.format(" (%d/%d)",data,n);
end
else
if n and inGame then
dict2["{p"..i.."}"]=string.format(" (%d/%d)",data,n);
else
dict2["{p"..i.."}"]="";
end
end
end
if v.job then
s=string.format("(%s)",jobtable[v.job].name)..s;
end
return string.trim(ReplaceString(s,dict2));
end

local function UpdateList(this,listM)
local top=0;
local container=this:CreateEmptyMovieClip("container");
local list={};

SetVScrollView(this);
container:SetInputEnable(false);
container:SetSpriteMode(true);
this.parent:SetMouseCapture(true);
this.parent.parent:SetMouseCapture(true);
this.setViewLimit(H-wndY-margin);
this.setScrollBarPos(578);

local function updateItem(mc,v)
local t=missiontable[v.id];
if v.reward then
for k,v in pairs(v.reward)do
AddItemIcon(mc.reward.img,k)
mc.reward.dia:SetText(v);
end
else
AddItemIcon(mc.reward.img,"dia")
mc.reward.dia:SetText(v.dia or t.dia or 0);
end

mc.name:SetText(makeTxt(t,v));
mc.btnOk.onClick=nil;
if not inGame then
mc.btnOk:SetVisible(false);
else
mc.new:SetVisible(not _S["\236\153\132\235\163\140\235\175\184\236\133\152"][v.id]and _S["\235\137\180\235\175\184\236\133\152"][v.id]~=nil);
mc.check:SetVisible(_S["\236\153\132\235\163\140\235\175\184\236\133\152"][v.id]~=nil);
if v.rewarded then
mc.btnOk:GotoAndStop(4,true);
mc.name:SetFillColor(0xFF595959);
elseif v.completed and not v.success then
mc.btnOk:GotoAndStop(5,true);
mc.name:SetFillColor(0xFF595959);
elseif v.completed and v.success then
mc.btnOk:GotoAndStop(2,true);
mc.btnOk.onClick=function()
if not v.reward then
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
RewardMission(v);
owner:init();

elseif t.status=="nomission"then
RewardMission(v);
owner:init();

showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[t.status]or _L("\235\175\184\236\133\152\235\179\180\236\131\129\236\139\164\237\140\168"));
else
showMsg(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[t.status]or _L("\235\175\184\236\133\152\235\179\180\236\131\129\236\139\164\237\140\168"));
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendMissionReward(onS,onF,v.id,v.seq,v.idx),
lang.waitLoginInfo);
end);
else
RewardMission(v);
owner:init();

for k,v in pairs(v.reward)do
for i=1,v do
MakeAndPickItem(k,_S.x,_S.y);
end
end
end
end
elseif t["\237\131\128\236\158\133"]=="\236\157\188\235\176\152"and not v.completed then
mc.btnOk:GotoAndStop(1,true);
mc.btnOk.dia:SetText(servertable.ChangeMissionPrice);
mc.btnOk.onClick=function()
local k=ChoiceMission(v.id);
if k then
local mc2=showPopupYN(owner,{msg=_L("\235\175\184\236\133\152\234\181\144\236\178\180\235\178\132\237\138\188YN"),mcName="\236\160\128\236\163\188\237\149\180\236\160\156\237\140\157\236\151\133"},function()
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
_S["\235\137\180\235\175\184\236\133\152"][k]=GetDay();
v.id=k;
if v.reward then
v.reward=MissionReward(k);
end
for i=1,9 do
v["data"..i]=nil;
end
updateItem(mc,v);
elseif t.status=="nodia"then
showPopupYN(owner,{msg=lang.nodiaQ},function()
TryConnect(function()
local wnd=showPopup(owner,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end);
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendChangeMission(onS,onF,v.id),
lang.waitLoginInfo);
end);
end);
mc2.btnOk:GotoAndStop(1);
mc2.btnOk.txt:SetText(servertable.ChangeMissionPrice);
end
end
else
mc.btnOk:GotoAndStop(3,true);
end
end

end

this.make=function(this)
container:Clear();
list={};
local y=top;

for k,v in ipairs(listM)do
local mc=container:AddSymbol("\235\175\184\236\133\1521\236\185\184","_");
mc:SetY(y);
updateItem(mc,v);
y=y+size;
table.insert(list,{mc,v});
end
this.setScroll(0);
this.setContentSize(y);

this.onSelect=function(this,pos,px)
local idx=math.floor(pos/size)+1;
local t=list[idx];
if t then
local mc,v=table.unpack(t);
local x=px;
local y=pos%size;
for k,btn in pairs({mc.btnOk})do
local a,b,c,d=btn:GetAABB();
if x>=a and x<a+c and y>=b and y<b+d then
if btn.onClick then
btn:onClick();
return true;
end
end
end
end
end
end
this:make();
end

local function updateBtn()
if owner.btnRe then
local rt=math.max(0,userDB.userInfo.tremission-os.time());
if userDB.userInfo.remissioncnt>0 or rt==0 then
owner.time:SetVisible(false);
owner.btnRe:GotoAndStop(1,true);
else
owner.time:SetVisible(true);
owner.time:SetText(string.format(_L("\235\175\184\236\133\152\235\130\168\236\157\128\236\139\156\234\176\132"),math.floor(rt/(3600*24)),math.floor(rt/3600)%24,math.floor(rt/60)%60,math.floor(rt)%60));
owner.btnRe:GotoAndStop(2,true);
owner.btnRe.dia:SetText(servertable.ReMissionPrice);
end
end
end

function owner:onEnterFrame(dt)
updateBtn();
end

SetButton(owner.btnClose).onClick=function(self)
_S["\235\137\180\235\175\184\236\133\152"]={};
world:updateMenu();
owner:Remove();
onCancel();
end
if owner.btnOk then
SetButton(owner.btnOk).onClick=function(self)
owner:Remove();
onOk();
end
end

if owner.btnRe then
SetButton(owner.btnRe).onClick=function(self)
local useDia=0;
local rt=math.max(0,userDB.userInfo.tremission-os.time());
if userDB.userInfo.remissioncnt>0 or rt==0 then
else
useDia=servertable.ReMissionPrice;
end
local mc2=showPopupYN(owner,{msg=_L("\235\175\184\236\133\152\234\181\144\236\178\180\235\178\132\237\138\188YN"),mcName="\236\160\128\236\163\188\237\149\180\236\160\156\237\140\157\236\151\133"},function()
local onS=function(t)
if t.status=="ok"then
NewWeekMission();
owner:init();
elseif t.status=="noremission"then
else
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",_L(t.status));
end
end
local onF=function()
end
TryConnect(function()
HttpWaitAsync(owner,
sendRemission(useDia,onS,onF),
lang.waitLoginInfo);
end);
end);
mc2.btnOk:GotoAndStop(1);
mc2.btnOk.txt:SetText(useDia);
end
end

function owner:init()
local listA={};
local listB={};
local plist={};
local function priority(v,idx)
local p=idx;
if v.rewarded then
p=p+100000;
elseif not v.rewarded and v.completed and v.success then
p=p-100000;
end
return p;
end
for k,v in ipairs(missions)do
local t=missiontable[v.id];
if not v.hide then
if owner.w and(t["\237\131\128\236\158\133"]=="\234\179\160\236\160\149"or t["\237\131\128\236\158\133"]=="\237\138\185\236\136\152")then
table.insert(listA,v);
else
table.insert(listB,v);
plist[v.id]=priority(v,k);
end
end
end
table.sort(listB,function(a,b)return plist[a.id]<plist[b.id];end);

local y=wndY;
if owner.w then
owner.w:Clear();
owner.w:SetY(y);
owner.w:CreateEmptyMovieClip("wnd");
owner.w:SetClipRect(0,0,APP_W,H-y-margin);
UpdateList(owner.w.wnd,listA);
end
if owner.w2 then
owner.w2:Clear();
owner.w2:SetY(y);
owner.w2:CreateEmptyMovieClip("wnd");
owner.w2:SetClipRect(0,0,APP_W,H-y-margin);
UpdateList(owner.w2.wnd,listB);
end
updateBtn();
end











owner:init();

end