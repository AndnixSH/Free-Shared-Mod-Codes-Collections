
MagicHall=Object:new({
})


function MagicHall:menuTouch(from,menu,onOk,onCancel)
if not self.sdata.magic then
local list={};
for k,v in pairs(_S["\235\167\136\235\178\149"])do
table.insert(list,k);
end
self.sdata.magic=table.choice(list);
end

local function _onOk(idx,key)
_S["\236\149\148\234\184\176\235\167\136\235\178\149"][idx]=key;
AddMagicLv(key);
onOk();
end
local mc=showPopup(world,"\235\167\136\235\178\149\236\149\148\234\184\176\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
ReadBookPopup(mc,self.tb.name,{self.sdata.magic},_onOk,onCancel);
end
