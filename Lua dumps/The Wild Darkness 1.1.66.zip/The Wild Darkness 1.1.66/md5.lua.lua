local core=require"md5.core"

local _M={};




function _M.sumhexa(k)
k=core.sum(k)
return(string.gsub(k,".",function(c)
return string.format("%02x",string.byte(c))
end))
end

function _M.crypt2(s,k)
return core.crypt(s,k);
end

return _M;
