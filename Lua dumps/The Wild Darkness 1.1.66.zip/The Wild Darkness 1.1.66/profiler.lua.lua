
if not PROFILER then
function ProfileBegin()end
function ProfileEnd()end
else
local list={};
local total=0;
local function gettime()
return sys.getSystemTime()*1000;
end
local max=math.max;

function ProfileBegin(name)
if not list[name]then
list[name]={t=0,m=0,c=0};
end
list[name].s=gettime();
end

function ProfileEnd(name)
local t=list[name];
assert(t,name);
local d=(gettime()-t.s);
total=total+d;
t.t=t.t+d;
t.c=t.c+1;
t.m=max(t.m,d);
t.s=nil;
trace(string.format("@@ %s : %f%% : %f",name,t.t/total*100,t.m));
end
end