
BossStatue=Object:new({
})

function BossStatue:onResetTurn(AP)
if AP>0 and not self:isCompleted()then
if world.player:getDistance(self)<=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]then
trace("!!!!!!!spawn");
self:complete();
end
end
Object.onResetTurn(self,AP);
end

function BossStatue:touch(...)
world.player:addChat(_L("\236\136\173\234\179\160\237\149\156 \234\184\176\236\154\180\236\157\180 \235\138\144\234\187\180\236\167\132\235\139\164."));
Object.touch(self,...);
end
