ArtifactStand=Object:new({
})

function ArtifactStand:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
self:makeChild();
end

function ArtifactStand:makeChild()
if self.sdata.newitem then
local z=self.tb["\235\134\146\236\157\180"]or 1;
local t={};
t.id="\236\149\132\236\157\180\237\133\156";
t.x=self.sdata.x;
t.y=self.sdata.y;
t.state="\236\153\132\235\163\140";
t.item=self.sdata.newitem;
t.z=z;
self.child=DropItem:new();
self.child:init(0,t);
self.child:unplace();
end
end

function ArtifactStand:update(dt)
Object.update(self,dt);
if self.child then
if self.child.died then
self.child:destroy();
self.child=nil;
else
self.child:update(dt);
end
end
end

function ArtifactStand:complete(menu,guid,x,y)
Object.complete(self,menu);
if menu=="\235\169\148\235\137\180_\236\149\132\237\139\176\237\140\169\237\138\184\236\136\152\235\166\172"then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
o["\235\130\180\234\181\172\235\143\132"]=const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132");
local ob=PlaceItem(guid,x,y);
ob:fly(self.pos);
self.child:die();
self.sdata.newitem=nil;
end
end

function ArtifactStand:menuEnabled(menu)
if menu=="\235\169\148\235\137\180_\236\178\160\234\177\176"then
if self.sdata.newitem then
return false;
end
end
return Object.menuEnabled(self,menu);
end

function ArtifactStand:menuCool(menu,guid)
if menu=="\235\169\148\235\137\180_\236\149\132\237\139\176\237\140\169\237\138\184\236\136\152\235\166\172"then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local tick=const("\236\149\132\237\139\176\237\140\169\237\138\184 \235\130\180\234\181\172\235\143\132 \237\154\140\235\179\181\237\139\177");
return(const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132")-o["\235\130\180\234\181\172\235\143\132"])*tick;
end
end

function ArtifactStand:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\149\132\237\139\176\237\140\169\237\138\184\236\136\152\235\166\172"then
if self.child then
onOk();
else
local function _ok(guid)
onOk(menu,guid,_S.x,_S.y);
DelMyItem(guid);
self.sdata.newitem=guid;
self:makeChild();
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176","\235\176\169\236\150\180\234\181\172","\236\149\133\236\132\184\236\132\156\235\166\172"},"\236\136\152\235\166\172",{object=self,["\235\175\184\236\176\169\236\154\169"]=true,noMaterial=true});
end
else
onOk(menu);
end
end
