OgreFootprint=Object:new({
})

function OgreFootprint:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
end

function OgreFootprint:canTouch()
end

function OgreFootprint:complete()
end

function OgreFootprint:isNickVisible()
return
not world.isTraveling and
world.ground:inLOS(self.tile.x,self.tile.y);
end


function OgreFootprint:onInvestigate(n)
if _S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"]==_S["\237\152\132\236\158\172\235\167\181"]and world.player:isGuardMode()then
self:action();
end
end

function OgreFootprint:onResetTurn(AP)
if AP>0 then
if self.sdata.ogreGuid~=_S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"].guid then
self:die();
else
if _S["\236\152\164\236\154\176\234\177\176\235\143\132\236\160\129\235\139\168"]["\236\156\132\236\185\152"]==_S["\237\152\132\236\158\172\235\167\181"]and world.player:isGuardMode()then
else
if self:isCompleted()then
self:rebirth();
end
end
end
end
end
