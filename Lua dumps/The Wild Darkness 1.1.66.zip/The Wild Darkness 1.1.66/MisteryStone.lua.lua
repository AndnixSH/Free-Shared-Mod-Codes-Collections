


MisteryStone=Object:new({
})

function MisteryStone:travel(id)
return AncientDoor.travel(self,id);
end













function MisteryStone:menuTouch(from,menu,onOk,onCancel)
local function _ok(id)
local key=string.split(id,"_")[2];
self:travel(key);
end
local btns={};
local maxN;
for i,v in ipairs(const("\236\176\168\236\155\144\236\157\152\236\132\156\237\140\144\235\170\169\235\161\157"))do
if HasItemType(v)then
maxN=i;
end
end


for i,v in ipairs(const("\236\176\168\236\155\144\236\157\152\236\132\156\237\140\144\235\170\169\235\161\157"))do
local item=itemtable[v];
local param=item["\237\140\140\235\157\188\235\175\184\237\132\176"];
if maxN and param and maxN>=i then
table.insert(btns,"\235\178\132\237\138\188_"..v);
end
end
if table.empty(btns)then
world.player:addChat(_L("\236\151\172\235\159\172\234\176\156\236\157\152 \236\139\160\235\185\132\237\149\156 \235\172\184\236\150\145\236\157\180 \234\183\184\235\160\164\236\160\184 \236\158\136\235\139\164."));
onCancel();
else
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\235\178\132\237\138\188",{object=self,btns=btns,detail=_L("\236\176\168\236\155\144\236\157\152 \235\172\184\236\132\160\237\131\157\236\132\164\235\170\133")});
end

end
