Merchant=Object:new({
spineScale=0.5,
})

function Merchant:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
self:makeGroup();
end


function Merchant:makeGroup(id)

do
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local area=_S.maps[mapId]["\236\167\128\236\151\173 \235\178\136\237\152\184"];
self.sdata.items=self.sdata.items or{(MakeItem(_S["\236\131\129\236\157\184\234\176\128\235\176\169"][area]or"\234\176\128\235\176\169","\236\131\129\236\157\184"))};
self.sdata.pool=self.sdata.pool or{};
local preventDups={};
local filterItems={};
for k,v in pairs(preventDups)do
if HasItemType(v)then
table.insert(filterItems,v);
end
end

local function select(list)
function choicePool()
if#self.sdata.pool==0 then
for i=1,9,1 do
local k=list["\234\181\144\236\178\180"..i];
local c=list["\234\176\156\236\136\152"..i];
if k then
local cnt=countkcc(c or 1);
while cnt>0 do
local group=math.randlist(k);
local itemGuid=MakeItem(group,"\236\131\129\236\157\184",filterItems);
if itemGuid then
if(ItemPrice(itemGuid)or 0)>0 then
table.insert(self.sdata.pool,itemGuid);
cnt=cnt-1;
else
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid]=nil;
end
end
end
end
end
end
return table.choiceRemove(self.sdata.pool);
end

while#self.sdata.items<const("\236\131\129\236\157\184\236\181\156\235\140\128\237\140\144\235\167\164\234\176\156\236\136\152")do
table.insert(self.sdata.items,0);
end
for k,v in pairs(self.sdata.items)do
if v==0 then
self.sdata.items[k]=choicePool();
end
end
end

return select(dropwelltable[self.sdata.id]);
end
end

function Merchant:menuTouch(from,menu,onOk,onCancel)
do
local mc=showPopup(world.ui,"\235\179\180\234\180\128\237\149\168\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
MerchantPopup(mc,self);
SetButton(mc.myinven.btnClose).onClick=function()
mc:Remove();
onCancel();
end
end
end

