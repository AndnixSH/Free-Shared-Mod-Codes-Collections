Deco=Object:new({
})


function Deco:canTouch()
end

function Deco:collision()
end

function Deco:touch()
end

function Deco:unplace()
end

function Deco:place()
end
