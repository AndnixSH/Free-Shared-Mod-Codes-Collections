function GetRecipePopup(cb,recipes,title)
local popup=showPopup(world,"\236\160\156\236\158\145\235\178\149\237\154\141\235\147\157\237\140\157\236\151\133");
local _,_,W,H=popup.back:GetAABB();
local margin=35;
player:SetNextDeltaTimeZero();
if title then
popup.title:SetText(title);
end

SetButton(popup.btnClose).onClick=function()
popup:Remove();
if cb then
cb();
end
end

local function UpdateList(this)
local owner=this;
local x=0;
local width=180;
local barY=210;
local viewLimit=W-margin*2;
local container=this:CreateEmptyMovieClip("container");
local list={};

SetHScrollView(this);
container:SetInputEnable(false);
container:SetSpriteMode(true);
this.parent:SetMouseCapture(true);
this.parent.parent:SetMouseCapture(true);
this.setViewLimit(viewLimit);

local function updateItem(mc,v)
local x,y,cx,cy=mc:GetBound();
local id=v["\236\158\165\235\185\132"];
if objecttable[id]then
AddObjectIcon(mc.img,id);
mc.name:SetText(objecttable[id].name);
elseif itemtable[id]then
AddItemIcon(mc.img,id);
mc.name:SetText(itemtable[id].name);
end
mc:SetBound(x,y,cx,cy);
end

this.make=function(this)
container:Clear();
list={};
x=0;
for k,v in ipairs(recipes)do
local id=v["\236\158\165\235\185\132"];
local mc;
if objecttable[id]then
mc=container:AddSymbol("\236\160\156\236\158\145\235\178\149\237\154\141\235\147\157_\236\152\164\235\184\140\236\160\157\237\138\1841\236\185\184","_");
elseif itemtable[id]then
mc=container:AddSymbol("\236\160\156\236\158\145\235\178\149\237\154\141\235\147\157_\236\149\132\236\157\180\237\133\1561\236\185\184","_");
else
assert(false,json_print(v));
end
mc:SetX(x);
updateItem(mc,v);
x=x+width;
table.insert(list,mc);
end
this.setScroll(0);
this.setScrollBarPos(barY);
this.setContentSize(x);
if x<viewLimit then
Align(list,"hcenter",{10,0},{0,0,viewLimit,barY});
this.setContentSize(viewLimit);
end

end
this:make();
end

popup.w:CreateEmptyMovieClip("wnd");
popup.w:SetClipRect(0,-H,W-margin*2,H*2);
UpdateList(popup.w.wnd);
end
