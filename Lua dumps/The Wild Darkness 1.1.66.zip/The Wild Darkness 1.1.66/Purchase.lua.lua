local wait;
_G.onBuyItem=function(self,item,token1,token2)
TryConnect(function()
local tb=servershoptable;
local guid=nil;
for k,v in pairs(tb)do
if item==v.ios_id or item==v.android_id then
guid=k;
break;
end
end
local onComplete=function(t)
if wait then
wait:Remove();
end
do

sendCommand("consume",item);
end
if t.status=="ok"then
local mc=showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.buySuccess);
mc.snd=GetAppSound(mc,"cash");
if mc.snd then
mc.snd:Play();
end
ToastPurchase(item,tb[guid].priceUSD);
else
showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang[t.status]or lang.buyFail);
end
end
local onFailed=function()
if wait then
wait:Remove();
wait=nil;
end
local mc=showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133Y",lang.buyFail);
end

HttpWaitAsync(root,sendBuyGold(guid,token1,token2,onComplete,onFailed),lang.waitLoginInfo);
end);
end


_G.onBuyItemCancel=function(self,item)
if wait then
wait:Remove();
wait=nil;
end
trace("onBuyItemCancel:"..item);
end

function PurchaseDia(item)
wait=showMsg(root,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133",lang.waitLogin);
sendCommand("buy",item);
end
