function Credit(owner)
trace("Title");
PlayMapBgm("\235\161\156\235\185\132");
local scale=1280/1600;
if APP_W/APP_H>1280/720 then
scale=scale*APP_W/APP_H*720/1280;
end
owner:CreateEmptyMovieClip("w");
owner.w:SetPos(APP_W/2,APP_H-600*scale);
owner.w:SetScale(scale,scale);
local sks={};
local defSpeed=30;
local speed=defSpeed;

local function addLayer(ani,particles,loop)
local obj,sk=SpineObject(owner.w,ani,"ani_title02",ani,"default",nil,loop);
table.insert(sks,sk);
do
local i=1;
while true do
local name=sk:getSlotName(i);
if not name then
break;
end
if string.find(name,"(b1)",nil,true)then
sk:setSlotBlend(name,0x14);
elseif string.find(name,"(b2)",nil,true)then
sk:setSlotBlend(name,0x32);
elseif string.find(name,"(b3)",nil,true)then
sk:setSlotBlend(name,0x92);
end
i=i+1;
end
end
if particles then
for k,v in pairs(particles)do
assert(sk:setChild(v.slot,{
particle="media/particle/"..v.path..".json",
}));
end
end
return obj;
end
addLayer("ani_bg1",{{slot="particle01",path="particle_star01"},{slot="particle02",path="particle_star02"}},true);
addLayer("ani_cha2",nil,true);
addLayer("ani_mon3",nil,true);
addLayer("ani_fire4",{{slot="particle03",path="particle_flying_ash"}},true);










local timer=Timer();
owner.onEnterFrame=function(self,dt)
spine.advanceTime(dt);
timer.update(dt);
end
owner.onMouseDown=function()
speed=defSpeed*6;
end
owner.onMouseUp=function()
speed=defSpeed;
end

owner.start=function()
owner:SetMouseCapture(true);
local fontSize=30;
local gap=fontSize+10;
local canvas=owner:CreateEmptyMovieClip("");
local height=0;
local xs=1;
for k,v in ipairs(string.split(_L("\237\129\172\235\160\136\235\148\167\235\170\169\235\161\157"),"\n"))do
local txt=canvas:AddLabel(APP_W,gap,"","",fontSize,1,"_");
txt:SetY(k*gap);
txt:SetThickness(0);
txt:SetFillColor(0xFFFFFFFF);
txt:SetColor(0xFFFFFFFF);
txt:SetText(v);
height=math.max((k+1)*gap);
end
canvas:SetY(APP_H);

local function scroll(dt)
local y=canvas:GetY()-dt*(speed*xs);
canvas:SetY(y);
if y<-height-speed then
root:GotoAndStop("lobby");
return false;
end
return true;
end
timer.add(scroll,scroll);
end
owner:start();
end
