
OblivionMark=Object:new({
})

function OblivionMark:travel(id,objectId)


world.player:playSndQueue("\236\176\168\236\155\144\236\157\152 \235\172\184 \236\130\172\236\154\169");
world.gameEnded=true;
world.isTraveling=true;
local function f()
local mapId=getMapId(id);
_G.nextMap=mapId;
_G.nextMapFromElevator=objectId;
_S.maps[mapId]["\235\130\152\234\176\132\234\179\179"]=nil;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end


function OblivionMark:onDestroyed(...)
self.sdata.menuCool=nil;
self.sdata.HP=self.tb.HP;
self:idle();
self:showHP(0);

if self.sdata.monsters then
for k,v in pairs(self.sdata.monsters)do
local o=world:findCharac(v);
if o then
o.drop=function()end;
Player.die(o);
end
end
self.sdata.monsters=nil;
end
end

function OblivionMark:onResetTurn(AP)
Object.onResetTurn(self,AP);

if AP>0 and self.sdata.menuCool and self.sdata.menuCool["\235\169\148\235\137\180_\236\136\152\235\166\172"]then
self.sdata.regenT=self.sdata.regenT or countkcc(self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\166\172\236\160\160"])*10;
self.sdata.regenT2=self.sdata.regenT2 or countkcc(self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\166\172\236\160\1602"]);
self.sdata.regenT=self.sdata.regenT-AP;
if self.sdata.regenT<=0 then
self.sdata.regenT2=self.sdata.regenT2-1;
self.sdata.regenT=nil;
local L,L2=table.unpack(self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\178\148\236\156\132"]);
local ox,oy=self.tile.x,self.tile.y;
local monsterId;
local aggro;
if self.sdata.regenT2<=0 then
self.sdata.regenT2=nil;
monsterId=self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\170\1852"];
else
monsterId=math.randlist(self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\170\1851"]);
aggro=math.randlist(self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"]["\236\150\180\234\183\184\235\161\156"]);
end
if monsterId then
for r=L2,1,-1 do
local pos={};
for i=ox-r,ox+r,1 do
for j=oy-r,oy+r,1 do
if math.abs(ox-i)==r or math.abs(oy-j)==r then
if world.ground:canTileWalkable(i,j,Filter_Movable)then
table.insert(pos,{i,j});
end
end
end
end
if pos[1]then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local mData=_S.maps[mapId];
local npcs=mData.npcs;
local guid=MakeGuid("c");
local x,y=table.unpack(table.choice(pos));
npcs[guid]={id=monsterId,x=x,y=y};
local o=world:addNpc(guid,npcs[guid]);
if aggro=="\237\148\140\235\160\136\236\157\180\236\150\180"then
o:aggro(world.player);
elseif aggro=="\236\152\164\235\184\140\236\160\157\237\138\184"then
o:aggro(self);
end
self.sdata.monsters=self.sdata.monsters or{};
table.insert(self.sdata.monsters,guid);
break;
end
end
end
end
end
end

function OblivionMark:complete(menu,...)
if menu=="\235\169\148\235\137\180_\236\136\152\235\166\172"then
local nextId=table.unpack({...});
world:pauseTurn();
local cb=function()
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(nextId,cb,self.guid);
self:swap(nextId);
Mission("\236\136\152\235\166\172",1,nextId);
end
self:play(self.tb["\236\153\132\235\163\140 \236\149\160\235\139\136"],false,nil,nil,cb);
if self.sdata.monsters then
for k,v in pairs(self.sdata.monsters)do
local o=world:findCharac(v);
if o then
Player.die(o);
end
end
self.sdata.monsters=nil;
end
end
end

function OblivionMark:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\136\152\235\166\172"then
local name=self.sdata.id;
local nextId=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"];
if recipetable[nextId]then
local function ok(id,guids)
if ConsumeItemsFromGuid(guids)then
onOk(menu,nextId);
end
end
local function cancel()
onCancel(menu);
end
BuildItemPopup(world,ok,cancel,"\236\160\156\236\158\145\235\178\149",{nextId,recipetable[nextId]["\236\158\172\235\163\140"],{btnName="\236\136\152\235\166\172"}});
else
onOk(menu,nextId);
end
elseif menu=="\235\169\148\235\137\180_\236\157\180\235\143\153"then
_G.useMapItem=self.sdata.id;
local mc=world:AddSymbol("\236\155\148\235\147\156\235\167\181\237\140\157\236\151\133");
SetButton(mc.btnClose).onClick=function()
_G.useMapItem=nil;
mc:Remove();
onCancel(menu);
end
SetWorldMap(mc.w);
end

end
