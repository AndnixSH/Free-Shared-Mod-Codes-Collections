Elevator=Object:new({
})






function Elevator:complete(menu,...)

if menu=="\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
self.mcNick.nick:SetText(self:getName());
end
end
function Elevator:getName()
local lv=_S["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"][self.sdata.id]or 0;
return _L("\234\180\145\236\130\176 \236\151\152\235\166\172\235\178\160\236\157\180\237\132\176".." LV"..lv);
end

function Elevator:travel()

world.gameEnded=true;
world.isTraveling=true;
local function f()
_G.nextMap=self.sdata.nextMap;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

function Elevator:menuEnabled(menu)
if menu=="\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
local lv=_S["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"][self.sdata.id]or 0;
local nextId=self.sdata.id.." LV"..(lv+1);
return recipetable[nextId]~=nil;
end
return true;
end

function Elevator:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176"then
local lv=_S["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"][self.sdata.id]or 0;
local range=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"][lv+1];
if table.empty(range)then
world.player:addChat(_L("\235\143\153\236\158\145\237\149\152\236\167\128 \236\149\138\235\138\148\235\139\164"));
onCancel();
else
local function _ok(depth)
world.gameEnded=true;
world.isTraveling=true;
local function f()
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
_G.nextMapFromElevator=self.sdata.id;
_G.nextMap=MapId(m["\237\131\128\236\158\133"],m["\236\167\128\236\151\173"],m["\237\149\132\235\147\156"],m["\235\178\136\237\152\184"],depth);
_S.TravelAP=(_S.TravelAP or 0)+math.abs(m["\236\184\181"]-depth)*10;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end
ElevatorMenuPopup(self,_ok,onCancel);
end
elseif menu=="\235\169\148\235\137\180_\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
local lv=_S["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"][self.sdata.id]or 0;
local nextId=self.sdata.id.." LV"..(lv+1);
trace("nextId",nextId,recipetable[nextId]);
if recipetable[nextId]then
local function ok(id,guids)
if ConsumeItemsFromGuid(guids)then
_S["\236\151\152\235\166\172\235\178\160\236\157\180\237\132\176 \235\160\136\235\178\168"][self.sdata.id]=lv+1;
onOk(menu,nextId);
end
end
local function cancel()
onCancel(menu);
end
BuildItemPopup(world,ok,cancel,"\236\160\156\236\158\145\235\178\149",{nextId,recipetable[nextId]["\236\158\172\235\163\140"],{name=_L(self.tb.name.." LV"..(lv+1))}});
end
end
end
