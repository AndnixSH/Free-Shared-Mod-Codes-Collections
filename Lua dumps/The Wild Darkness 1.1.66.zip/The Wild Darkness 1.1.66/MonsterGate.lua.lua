MonsterGate=Object:new({
})

function MonsterGate:canTouch()
end

function MonsterGate:onResetTurn(AP)
Object.onResetTurn(self,AP);
self:updateWave(AP);
end

function MonsterGate:checkEndSpawn()
for k,v in safe_pairs(self.sdata.monsters)do
if world:findCharac(v)then
return false;
end
end
return true;
end

function MonsterGate:updateWave(AP)
self.sdata.waveT=self.sdata.waveT or 0;
if AP>0 and self:checkEndSpawn()then
self.sdata.waveT=self.sdata.waveT-AP;
if self.sdata.waveT<=0 then
self.sdata.waveT=30;
local guid=SpawnMonster(self.tile.x,self.tile.y,0,0,self.sdata.monsterId or"\235\170\172\236\138\164\237\132\176");
self.sdata.monsters=self.sdata.monsters or{};
table.insert(self.sdata.monsters,guid);
end
end
end
