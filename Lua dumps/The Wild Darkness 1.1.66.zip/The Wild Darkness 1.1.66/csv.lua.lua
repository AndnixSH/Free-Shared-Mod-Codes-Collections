local json=require"json"
function ParseCSVLine(line,sep)
local res={}
local pos=1
sep=sep or","
while true do
local c=string.sub(line,pos,pos)
if(c=="")then break end
if(c=="\"")then

local txt=""
repeat
local startp,endp=string.find(line,"^%b\"\"",pos)
txt=txt..string.sub(line,startp+1,endp-1)
pos=endp+1
c=string.sub(line,pos,pos)
if(c=="\"")then txt=txt.."\""end




until(c~="\"")
table.insert(res,txt)
assert(c==sep or c=="",line)
pos=pos+1
else

local startp,endp=string.find(line,sep,pos)
if(startp)then
table.insert(res,string.sub(line,pos,startp-1))
pos=endp+1
else

table.insert(res,string.sub(line,pos))
break
end
end
end
return res
end
local function isArray(t)
local i=0
for _ in pairs(t)do
i=i+1
if t[i]==nil then return false end
end
return true
end
local function isInt(s)
if math.tointeger(s)then
return true;
end
end

local function isUtf8(s)
for i=1,s:len(),1 do
local char=string.byte(s,i);
if char<48 or char>122 or char==32 then
return true;
end
if char>=192 then
return true;
end
end
end

local function strcmp(a,b)
local sa=tostring(a);
local sb=tostring(b);
local la=string.len(sa);
local lb=string.len(sb);
local i=1;
while true do
if la<i and lb<i then return 0;end
if la<i then
return-1;
end
if lb<i then
return 1;
end

local ca=string.byte(a,i);
local cb=string.byte(b,i);
if ca>cb then return 1;
elseif ca<cb then return-1;
end
i=i+1;
end
end

local function escape(str)
str=string.gsub(str,"\"","\\"");
return str;
end

local function tojson(t)
if type(t)=="table"then
return json.encode(t);







else
return tostring(t);
end


end

local function table_print(tt,indent,done)
done=done or{}
indent=indent or 0
if type(tt)=="table"then
local sb={}
local sorted={};
for k,v in pairs(tt)do
table.insert(sorted,{k,v});
end
table.sort(sorted,function(a,b)
if type(a[1])=="number"and type(b[1])=="number"then
return(a[1]<b[1]);
else
return strcmp(tostring(a[1]),tostring(b[1]))<0
end
end);

local bArray=isArray(tt);
for k,v in ipairs(sorted)do
local key=v[1];
local value=v[2];
if indent>0 and bArray then
else
if isInt(key)then
table.insert(sb,string.format("[%s]=",tostring(key)))
elseif isUtf8(tostring(key))then
table.insert(sb,string.format("[\"%s\"]=",tostring(key)))
else
table.insert(sb,string.format("%s=",tostring(key)))
end
end
if type(value)=="table"then
done[value]=true
table.insert(sb,"{");
table.insert(sb,table_print(value,indent+1,done))

table.insert(sb,"},");
elseif"number"==type(value)or"boolean"==type(value)then
table.insert(sb,string.format("%s",tostring(value)))
table.insert(sb,",");
else
table.insert(sb,string.format("\"%s\"",escape(tostring(value))))
table.insert(sb,",");
end
if indent==0 then
table.insert(sb,"\n");
end
end


local s=string.gsub(table.concat(sb),",}","}");
return s;
end
end


local isJson=function(v)
if(string.starts(v,"{")or string.starts(v,"["))and(string.ends(v,"}")or string.ends(v,"]"))then
return true;
end
end
local conv_value=function(v,hint)
n=tonumber(v);
if n then
return n;
else
if isJson(v)then
local t=json.decode(v);

if t then
return t;
end
end
end
if v==""then
return nil;
end
return v;
end

function csv_to_lua(filename,outname)
trace("CSV \237\140\140\236\139\177:"..filename);
local t={};
local file=io.open(filename);
local line=file:read();
local header=ParseCSVLine(line,"\t");
while true do
line=file:read();
if not line then
break;
end
local o={};
res=ParseCSVLine(line,"\t");
for k,v in pairs(res)do
res[k]=conv_value(v,res[1]);
end
local prefixLine=tostring(res[1]):sub(1,1);
if prefixLine=="#"then
else
for k,v in pairs(header)do
local prefix=v:sub(1,1);
if prefix=="#"then
elseif prefix=="@"or prefix=="%"then
o[v:sub(2)]=res[k];
else
o[v]=res[k];
end
end
if header[2]=="value"and(header[3]==nil or header[3]=="")then
if res[1]then
assert(not t[res[1]],res[1]);
t[res[1]]=o.value;
end
elseif res[1]then
assert(not t[res[1]],res[1]);
t[res[1]]=o;
end
end
end
file:close();

local wf=io.open(outname,"w")
wf:write("return {\n");
wf:write(table_print(t));
wf:write("}");
wf:close();
end

function csv_to_jsonarray(filename,outname)
local t={};
local file=io.open(filename);
if not file then
trace("no file..:"..filename);
end
while true do
line=file:read();
if not line then
break;
end
local o={};
res=ParseCSVLine(line,"\t");
for k,v in ipairs(res)do
if isJson(v)then
res[k]=v;
else
n=tonumber(v);
if n then
res[k]=v;
else
res[k]="\""..v.."\"";
end
end
end
for i=1,#res,2 do
table.insert(o,{k=res[i],v=res[i+1]});
end
table.insert(t,o);
end
file:close();

local wf=io.open(outname,"w")
for k,v in ipairs(t)do
wf:write("{");
for kk,vv in ipairs(v)do
if kk>1 then
wf:write(",");
end
wf:write(string.format("%s:%s",vv.k,vv.v));
end
wf:write("}\n");
end
wf:close();
end

function json_print(t)
return"{\n"..table_print(t).."}";
end