function MerchantPopup(owner,object)
local storage=object.sdata.items;
local prevScroll;
local selected={};
local selectedN=0;
local selectedLeft={};
local selectedLeftN=0;
local price=0;
local priceLeft=0;
local empty=0;
local mode;
local tb=dropwelltable[object.sdata.id];
local function calcPrice(guid,right)
local price=ItemPrice(guid)or 0;
if right then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if tb["\236\162\133\235\165\152"]then
local keys=table.sortedkeys(tb["\236\162\133\235\165\152"],function(a,b)return tb["\236\162\133\235\165\152"][a]>tb["\236\162\133\235\165\152"][b];end);
for i,k in ipairs(keys)do
local p=tb["\236\162\133\235\165\152"][k];
local buy=string.split(k,",");
local id=o.id;
local item=itemtable[id];
if item then
if table.find(buy,id)
or table.find(buy,o["\235\147\177\234\184\137"])
or(item["\236\162\133\235\165\152"]and(
table.find(buy,item["\236\162\133\235\165\152"])
or table.find(buy,item["\234\183\184\235\163\185"])
or table.find(buy,const("\235\182\132\235\165\152C",item["\236\162\133\235\165\152"]))
or table.find(buy,const("\235\182\132\235\165\152B",item["\236\162\133\235\165\152"]))
or table.find(buy,const("\235\182\132\235\165\152A",item["\236\162\133\235\165\152"]))
))then
return price*p*const("\236\131\129\236\157\184\234\181\172\236\158\133\237\149\160\236\157\184");
end
end
end
end
if tb["\236\162\133\235\165\152"]and tb["\236\162\133\235\165\152"]["\234\184\176\237\131\128"]then
return price*const("\236\131\129\236\157\184\234\181\172\236\158\133\237\149\160\236\157\184")*tb["\236\162\133\235\165\152"]["\234\184\176\237\131\128"];
else
return price*const("\236\131\129\236\157\184\234\181\172\236\158\133\237\149\160\236\157\184");
end
end
return price;
end
local function canBuy(guid)
return calcPrice(guid,true)>0;
end

local function updatePrice()
price=0;
priceLeft=0;
for guid,c in pairs(selected)do
price=price+calcPrice(guid,true)*c;
end
for guid,v in pairs(selectedLeft)do
if v then
local p=calcPrice(guid);
if priceLeft+p>price then
selectedLeft[guid]=nil;
else
priceLeft=priceLeft+p;
end
end
end
if priceLeft<=price and not table.empty(selected)and not table.empty(selectedLeft)then
owner.btnExchange:GotoAndStop(1,true);
owner.btnExchange:enable(true);
else
owner.btnExchange:GotoAndStop(2,true);
owner.btnExchange:enable(false);
end
end

for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end

local obj=UIObject(owner.icon);
obj:init(object.sdata.id);
local _,_,w,h=obj.mc:GetBound();
obj.mc:SetScale(-0.5,0.5);
obj.mc:SetPos(70,50+h/3);
owner.comment:SetText(_L(object.sdata.id.." \235\140\128\237\153\148"));

local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
owner.myinven[v]:Clear();
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(owner.myinven[v],guid);
else
assert(images[v],v);
SetItemIconFromGuid(owner.myinven[v]);
owner.myinven[v].img:AddSymbol(images[v],"icon");
end
end
end
end

local function initBag()

do
for k,v in ipairs(GetAvailStorageSlots())do
if mode==v then
owner.myinven[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner.myinven[v].img:SetAlphaDepth(0.3);
else
owner.myinven[v].img:SetAlphaDepth(1);
end
end
end

owner.myinven.list:Clear();
owner.listLeft:Clear();

local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o and o["\234\176\128\235\176\169"];
SetMyInventoryWnd(owner.myinven.list,d);
SetMyInventoryWnd(owner.listLeft,storage);
empty=0;
for k,v in safe_pairs(d)do
if v==0 then
empty=empty+1;
end
end
updatePrice();
if prevScroll then
owner.myinven.list.list.setScroll(prevScroll);
end
function owner.myinven.list.list:onScroll(s)
prevScroll=s;
end

local function setInfo(this,mc,guid)
if(guid or 0)~=0 then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid],guid);
SetItemIconFromGuid(mc,guid);
else
SetItemIconFromGuid(mc);
end
if selected[guid]or selectedLeft[guid]then
if not mc.mark then
mc:AddSymbol("\236\157\184\235\178\164\236\176\169\236\154\169\236\138\172\235\161\175\235\176\152\236\167\157","mark");
end
else
if mc.mark then
mc.mark:Remove();
end
end
if mc.enabled then
mc.img:SetAlphaDepth(1);
else
mc.img:SetAlphaDepth(0.3);
end
end

owner.myinven.list.list.onSelected=function(this,mc,guid)
if guid and guid~=0 then
if selected[guid]then
local function onOk()
selected[guid]=nil;
selectedN=table.length(selected);
updatePrice();
owner.myinven.list.list:refresh();
owner.listLeft.list:refresh();
end
ShowItemInfo(guid,onOk,_L("\236\132\160\237\131\157 \237\149\180\236\160\156"),not mc.enabled);
else
local function onOk()
local function _onOk(c)
selected[guid]=c or 1;
selectedN=table.length(selected);
updatePrice();
owner.myinven.list.list:refresh();
owner.listLeft.list:refresh();
end
local function _onCancel()
end
SelectItemCountPopup(_onOk,_onCancel,owner,guid);
end
ShowItemInfo(guid,onOk,_L("\236\132\160\237\131\157"),not mc.enabled);
end
return true;
end
end
owner.myinven.list.list.setInfo=function(this,mc,guid)
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemType=itemtable[data.id]["\236\162\133\235\165\152"];
local group=itemtable[data.id]["\234\183\184\235\163\185"];
mc.enabled=canBuy(guid);
setInfo(this,mc,guid);
end
end

owner.listLeft.list.onSelected=function(this,mc,guid)
if guid and guid~=0 then
local function onOk()
selectedLeft[guid]=not selectedLeft[guid];
if not selectedLeft[guid]then
selectedLeft[guid]=nil;
end
selectedLeftN=table.length(selectedLeft);
updatePrice();
owner.myinven.list.list:refresh();
owner.listLeft.list:refresh();
end
if selectedLeft[guid]then
ShowItemInfo(guid,onOk,_L("\236\132\160\237\131\157 \237\149\180\236\160\156"),not mc.enabled);
else
ShowItemInfo(guid,onOk,_L("\236\132\160\237\131\157"),not mc.enabled);
end
return true;
end
end

owner.listLeft.list.setInfo=function(this,mc,guid)
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemType=itemtable[data.id]["\236\162\133\235\165\152"];
local group=itemtable[data.id]["\234\183\184\235\163\185"];
if selectedLeft[guid]then
mc.enabled=true;


else
mc.enabled=price>0 and((calcPrice(guid)or 0)+priceLeft)<=price;
end
setInfo(this,mc,guid);
end
end

owner.myinven.list:init();
owner.listLeft:init();
end


local function changeMode(slot)
mode=slot;
prevScroll=nil;

initBag();
end


for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
SetButton(owner.myinven[v],nil,nil,nil,0,0).onClick=function()
if IsStorageSlot(v)then
if _S["\236\138\172\235\161\175"][v]~=0 then
changeMode(v);
end
end
end
end
end

function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
initSlots();
initBag();
end

owner.btnExchange:SetVisible(true);
SetButton(owner.btnExchange).onClick=function()
eventDispatcher:del(owner,owner.onEvent);
local list={};
for guid,c in pairs(selected)do
for i=1,c do
table.insert(list,{guid,calcPrice(guid,true)});
end
end


while priceLeft>0 and list[1]do
table.sort(list,function(a,b)return math.abs(priceLeft-a[2])<math.abs(priceLeft-b[2]);end);
priceLeft=priceLeft-list[1][2];
ConsumeItem(list[1][1]);
table.remove(list,1);
end

for guid,v in pairs(selectedLeft)do
if v then
for i,v in pairs(storage)do
if v==guid then
storage[i]=0;
local o,data=PlaceItem(guid,_S.x,_S.y);
o:fly(object.pos);
Mission("\234\177\176\235\158\152",1,data.id);
end
end
end
end


selected={};
selectedLeft={};
object:makeGroup();

owner.myinven.btnClose:onClick();

end

eventDispatcher:add(owner,owner.onEvent);
owner:init();


end

