

































function AnimateNumber(mc,cur,to,dur,tostr,timestep,snd,sndStep,timer)

local setText=mc.SetText;
local step=(to-cur)/dur;
sndStep=sndStep or 0;
tostr=tostr or tostring;
timer=timer or mainTimer;
timestep=timestep or 0;
timer.remove(mc);
local sndTime=sndStep;
setText(mc,tostr(cur));
if cur~=to then
local f=function(dt)

local old=cur;
if not mc["this"]then
return false;
end
if to>cur then
cur=math.min(to,cur+step*dt);
elseif to<cur then
cur=math.max(to,cur+step*dt);
end
local s=math.floor(cur);
if s~=math.floor(old)then
setText(mc,tostr(s));
end
if snd then
sndTime=sndTime+dt;
if sndTime>=sndStep then
snd:Play();
sndTime=0;
end
end
return s~=math.floor(to);
end
timer.add(mc,f,timestep);
end
end
