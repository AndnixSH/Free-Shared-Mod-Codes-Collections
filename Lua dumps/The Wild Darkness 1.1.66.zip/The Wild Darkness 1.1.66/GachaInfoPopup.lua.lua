
function GachaInfoPopup(owner)
local keys={
"\235\182\128\236\138\164\235\159\172\236\167\132 \236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129",
"\236\158\145\236\157\128 \237\153\169\234\184\136 \236\156\160\236\160\129",
"\234\177\176\235\140\128\237\149\156 \237\153\169\234\184\136 \236\156\160\236\160\129",
"\235\182\128\236\138\164\235\159\172\236\167\132 \236\156\160\236\160\129",
"\236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129",
"\236\139\160\235\185\132\237\149\156 \236\156\160\236\160\129",
"\237\153\169\234\184\136 \236\156\160\236\160\129",
};
local rare={"\235\133\184\235\167\144","\235\160\136\236\150\180","\236\151\144\237\148\189","\235\160\136\236\160\132\235\147\156"};

do
local str="";

for _,v in ipairs(keys)do
local o=objecttable[v]or objecttable["_"..v];
local t=servertable.BoxOpenTotem[v];
local ext=servertable.BoxOpenTotemCnt[v];
local totemcnt=servertable.BoxReward[v].totem;
local totemp=servertable.TotemPercent;
if type(totemcnt)=="table"then
totemcnt=totemcnt[1]+(totemcnt[3]-totemcnt[1])*totemcnt[2];
end
str=str..LabelRichText(LabelRichTextItem(" \226\151\143 "..o.name,0xFFFFFFFF));
if ext then
str=str..LabelRichText(" (");
local sep="";
for i,r in ipairs(rare)do
if ext[r]then
str=str..LabelRichText(sep..LabelRichTextItem(_L(r)..": "..ext[r].."\226\134\145",const("\237\134\160\237\133\156\235\147\177\234\184\137\235\179\132\236\131\137\236\131\129",r)));
sep=", ";
end
end
str=str..LabelRichText(")");
end

local total=0;
local _pcts={};
local function normalizeP(pcts)
local total=0;
for k,v in pairs(pcts)do
total=total+v;
end
for k,v in pairs(pcts)do
pcts[k]=pcts[k]/total;
end
end
local function setP(pcts,w)
normalizeP(pcts);
for k,v in pairs(pcts)do
_pcts[k]=(_pcts[k]or 0)+v*w;
end
end
for r,cnt in safe_pairs(ext)do
local pcts={};
local i=table.find(rare,r);
totemcnt=totemcnt-cnt;
for k,v in pairs(recipetable)do
if v["\235\147\177\234\184\137"]and table.find(rare,v["\235\147\177\234\184\137"])>=i then
local rr=v["\235\147\177\234\184\137"];
local p=(t[rr]*(100-totemp));
pcts[rr]=(pcts[rr]or 0)+p;
total=total+p;
end
end
for k,v in pairs(totemtable)do
if v["\235\147\177\234\184\137"]and table.find(rare,v["\235\147\177\234\184\137"])>=i then
local rr=v["\235\147\177\234\184\137"];
local p=t[rr]*totemp;
pcts[rr]=(pcts[rr]or 0)+p;
total=total+p;
end
end
setP(pcts,cnt);
trace("pcts",v,r,cnt,pcts);
end

do
local pcts={};
for k,v in pairs(recipetable)do
if v["\235\147\177\234\184\137"]then
local rr=v["\235\147\177\234\184\137"];
local p=t[rr]*(100-totemp);
pcts[rr]=(pcts[rr]or 0)+p;
total=total+p;
end
end

for k,v in pairs(totemtable)do
if v["\235\147\177\234\184\137"]then
local rr=v["\235\147\177\234\184\137"];
local p=t[rr]*totemp;
pcts[rr]=(pcts[rr]or 0)+p;
total=total+p;
end
end
setP(pcts,totemcnt);
trace("pcts",v,"\235\133\184\235\167\144",totemcnt,pcts);
end
trace("_pcts",v,_pcts);
normalizeP(_pcts);
str=str.."<br/>";
for i,r in ipairs(rare)do
local value=(_pcts[r]or 0)*100;
local sep="";
if i>1 then
sep=", ";
end
str=str..LabelRichText(sep..LabelRichTextItem(_L(r)..": "..tostringf(value).."%",const("\237\134\160\237\133\156\235\147\177\234\184\137\235\179\132\236\131\137\236\131\129",r)));
end
str=str.."<br\tsize=50/>";
end
owner.w:SetText(str);
end

SetButton(owner.btnClose).onClick=function(self)
owner:Remove();
end
end