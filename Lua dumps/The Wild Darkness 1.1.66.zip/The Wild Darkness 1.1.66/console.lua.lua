function showConsole(owner,name,fontSize,margin)
local W=math.min(APP_W,APP_H);
local H=math.min(APP_W*0.7,APP_H*0.7);
fontSize=fontSize or 18;
margin=margin or 10;
local mc=owner:CreateEmptyMovieClip(name);
local mcBack=mc:CreateEmptyMovieClip("back");
mcBack:SetLineStyle(1,0xc0000000);
mcBack:MoveTo(0,0);
mcBack:Rectangle(W,H);

mc:CreateEmptyMovieClip("edit");
mc.edit:SetPos(0,H);
mc.edit:CreateEmptyMovieClip("back");
mc.edit.back:SetLineStyle(1,0xFFFFFFFF);
mc.edit.back:MoveTo(0,0);
mc.edit.back:Rectangle(W,fontSize+margin);

local line=mc.edit:AddLabel(W,fontSize+margin,"","",fontSize,8,"txt");
line:SetColor(0);
line:SetFillColor(0);

SetEditBox(mc.edit,mc.edit.txt);
mc:SetPos((APP_W-W)/2,(APP_H-H)/2);
mc.edit:setFocus();
local textbox=ListBox(mc,{x=W,y=H},fontSize,fontSize);

local _gtrace=gtrace;
gtrace=function(s)
textbox:AddBottom(s,0xFFFFFFFF);
textbox:scrollToBottom();
_gtrace(s);
end



function mc.edit:onEndEdit(msg)
mc.edit.txt:SetText("");

local function f(msg)
if not string.find(msg,"return")and not string.find(msg,"=")then
msg="return ("..msg..")";
end
textbox:AddBottom(msg,0xFFC0C0FF);
local _f,e=load(msg);
if e then
trace("error",e);
else
tostring(_f()or nil);
end












end
local s,e=xpcall(f,errcb,msg);
if not s then
trace(e);
trace(debug.traceback());
end

end

local oldRemove=mc.Remove;
mc.Remove=function(self)
gtrace=_gtrace;
oldRemove(self);
end

function mc:onKeyDown(keycode)
if keycode==13 then
mc.edit:setFocus();
return true;
elseif keycode==27 then
mc:Remove();
return true;
end
end


end