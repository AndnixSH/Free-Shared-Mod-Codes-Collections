function Logo(owner)
trace("Title");

local scale=1280/1600;
if APP_W/APP_H>1280/720 then
scale=scale*APP_W/APP_H*720/1280;
end
owner.w:SetY(APP_H-600*scale);
owner.w:SetScale(scale,scale);
local sks={};

local o,sk=SpineObject(owner.w,"ani_popeyed","ani_popeyed","ani_popeyed","default");
o:SetY((960-APP_H/APP_W*1280)/1.33);

function o:onAnimationEvent(track,name,type,evt,loop)
if type=="COMPLETE"then
root:GotoAndStop("title");
end
end

local timer=Timer();
owner.onEnterFrame=function(self,dt)
spine.advanceTime(dt);
timer.update(dt);
end
end
