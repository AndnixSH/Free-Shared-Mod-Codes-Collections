Destroyer=NPC:new({
});

function Destroyer:onResetTurn(AP)
Player.onResetTurn(self,AP);

local target=nil;
for i,k in ipairs(self:ev("\235\182\128\236\136\152\234\184\176"))do

local o=world:findObjectFromId(k);
if o then
if world.ground.pathFinder:CanGoto({self.pos.x,self.pos.y},{o.pos.x,o.pos.y},Filter_Movable)then
target=o.guid;
else
local l,t,r,b=math.min(self.tile.x,o.tile.x),math.min(self.tile.y,o.tile.y),
math.max(self.tile.x,o.tile.x),math.max(self.tile.y,o.tile.y);
local minL,minGuid;
for k,v in pairs(world.objects)do
if not v.dying and v.tb["\234\184\184\235\167\137"]then
if v.tile.x>=l and v.tile.x<=r and v.tile.y>=t and v.tile.y<=b then
local L=self:getDistance(v);
if not minL or L<minL then
minL=L;
minGuid=v.guid;
end
end
end
end
target=minGuid;
end
end

if not target then
target=o.guid;
end
end

self:setTarget(target);
self:investigate();
self:cleanBuff();
self:updateIcon();
end