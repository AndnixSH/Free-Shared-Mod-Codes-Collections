function IAchieve(owner)
local tb=servershoptable;
local margin=16
local _,_,W,H=owner.back:GetAABB();
local wndY=owner.w:GetY();
local size=120;

local shoptb;
for k,v in pairs(tb)do
if v.aboost then
shoptb=v;
break;
end
end
SetTextButton(owner.btnBuy,shoptb.priceUSD.."$").onClick=function()
if _Z.IOS then
PurchaseDia(shoptb.ios_id);
else
PurchaseDia(shoptb.android_id);
end
end

local function UpdateList(this)
local top=0;
local container=this:CreateEmptyMovieClip("container");
local list={};

SetVScrollView(this);
container:SetInputEnable(false);
container:SetSpriteMode(true);
this.parent:SetMouseCapture(true);
this.parent.parent:SetMouseCapture(true);
this.setViewLimit(H-wndY-margin);
this.setScrollBarPos(W-60);

local function updateItem(mc,v)
mc.name:SetText(v["name_"..curLang]);
for i=1,2 do
local btn=mc["btnOk"..i];
local bit=(0x1<<(i-1));
if i==2 and(myInfo.aboost or 0)==0 then
btn:GotoAndStop(3,true);
end

if i==1 then
btn.dia:SetText(v.dia);
else
btn.dia:SetText(v.dia*shoptb.aboost);
end


if myInfo.achieves and((myInfo.achieves[v.guid]or 0)&bit)~=0 then
btn:GotoAndStop(2,true);
btn.txt:SetText(_L("\235\176\155\234\184\176 \236\153\132\235\163\140"));
elseif _D["\235\143\132\236\160\132\234\179\188\236\160\156"]["g"..v.guid]then
btn.txt:SetText(_L("\235\179\180\236\131\129 \235\176\155\234\184\176"));
if i<2 or(myInfo.aboost or 0)>0 then
local onS=function(t)
if t.status=="ok"then
end
end
local onF=function()
end
btn.onClick=function()
HttpWaitAsync(owner,
sendAchieve(v.guid,bit,onS,onF),
lang.waitLoginInfo);
end
end
else
btn.txt:SetText(_L("\236\167\132\237\150\137\236\164\145"));
end
end
end

this.make=function(this)
container:Clear();
list={};
local y=top;

local items={};
for k,v in pairs(serverachievetable)do
table.insert(items,v);
end
local function priority(a)
local p=a.guid;
if(myInfo.achieves[a.guid]or 0)~=3 and _D["\235\143\132\236\160\132\234\179\188\236\160\156"]["g"..a.guid]then
p=p-100000;
end
return p;
end
table.sort(items,function(a,b)return priority(a)<priority(b);end);
for k,v in ipairs(items)do
local mc=container:AddSymbol("\235\143\132\236\160\132\234\179\188\236\160\156\235\170\169\235\161\1571\236\185\184","_");
mc:SetY(y);
updateItem(mc,v);
y=y+size;
table.insert(list,{mc,v});
end
this.setScroll(0);
this.setContentSize(y);

this.onSelect=function(this,pos,px)
local idx=math.floor(pos/size)+1;
local t=list[idx];
if t then
local mc,v=table.unpack(t);
local x=px;
local y=pos%size;
trace("x,y",x,y);
for k,btn in pairs({mc.btnOk1,mc.btnOk2})do
local a,b,c,d=btn:GetAABB();
if x>=a and x<a+c and y>=b and y<b+d then
trace("in",x,y);
if btn.onClick then
btn:onClick();
return true;
end
end
end
end
end
end
this:make();
end

SetButton(owner.btnClose).onClick=function(self)
owner:Remove();
end

function owner:init()
local y=wndY;
if(myInfo.aboost or 0)>0 then
y=y-80;
owner.txtBuy:SetVisible(false);
owner.btnBuy:SetVisible(false);
end
owner.w:Clear();
owner.w:SetY(y);
owner.w:CreateEmptyMovieClip("wnd");
owner.w:SetClipRect(0,0,APP_W,H-y-margin);
UpdateList(owner.w.wnd);
end

AddMyInfoObserver(owner);
function owner:onUpdateMyInfo(key)
owner:init();
end
function owner:onUnload()
DelMyInfoObserver(owner);
end


owner:init();

end