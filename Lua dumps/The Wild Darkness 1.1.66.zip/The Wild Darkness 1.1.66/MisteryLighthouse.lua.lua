

MisteryLighthouse=Object:new({
})

function MisteryLighthouse:checkCond(id)
local cond=const("\236\176\189\234\179\181\236\157\152\235\147\177\235\140\128\236\161\176\234\177\180",id);

if cond then
for k,v in pairs(cond)do
if(_S["\236\178\152\236\185\152"][v]or 0)>0 then
return true;
end
end
return false;
end
return true;
end

function MisteryLighthouse:travel(id)
local maps={};
for k,v in pairs(_S.maps)do
if v["\236\132\164\234\179\132\235\143\132"]==id and v["\237\149\132\235\147\156"]==1 then
table.insert(maps,k);
end
end

world.player:playSndQueue("\236\176\168\236\155\144\236\157\152 \235\172\184 \236\130\172\236\154\169");
world.gameEnded=true;
world.isTraveling=true;
local function f()
local mapId=table.choice(maps);
_G.nextMap=mapId;
_G.nextMapFromElevator=nil;
_S.maps[mapId]["\235\130\152\234\176\132\234\179\179"]=nil;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

function MisteryLighthouse:menuTouch(from,menu,onOk,onCancel)
local function _ok(id)
local key=string.split(id,"_")[2];
local n=const("\236\176\189\234\179\181\236\157\152\235\147\177\235\140\128\236\157\180\235\143\153",key);
local has;
for i,v in ipairs(const("\236\176\168\236\155\144\236\157\152\236\132\156\237\140\144\235\170\169\235\161\157"))do
if HasItemType(v)then
if i>=n then
has=true;
break;
end
end
end
if not has then
world.player:addChat(string.format(_L("\236\149\132\236\157\180\237\133\156\237\149\132\236\154\148"),itemtable["\236\176\168\236\155\144\236\157\152 \236\132\156\237\140\144 "..n].name));
onCancel();
elseif self:checkCond(key)then
self:travel(key);
else
world.player:addChat(_L("\236\176\189\234\179\181\236\157\152\235\147\177\235\140\128\235\182\136\235\167\140\236\161\177"));
onCancel();
end
end
local btns={};
for i=1,#const("\236\176\168\236\155\144\236\157\152\236\132\156\237\140\144\235\170\169\235\161\157")do
for kk,vv in pairs(const("\236\176\189\234\179\181\236\157\152\235\147\177\235\140\128\236\157\180\235\143\153"))do
if vv==i then
table.insert(btns,"\235\178\132\237\138\188_"..kk);
end
end
end

SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\235\178\132\237\138\188",{object=self,btns=btns,detail=_L("\236\176\168\236\155\144\236\157\152 \235\172\184\236\132\160\237\131\157\236\132\164\235\170\133")});
end
