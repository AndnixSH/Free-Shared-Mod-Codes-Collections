
function ArtifactPopup(parent,onOk,onCancel,itemId)
local prevScroll;
local selected={slot=itemId};
local mode;
local materials={};
local reserved={};
local itemList={};
local recipe=recipetable[itemId];
local itemtb=itemtable[recipe["\236\158\165\235\185\132"]];
local owner=showPopup(parent,"\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\236\158\145\237\140\157\236\151\133");
local hasBuilding;
local myItems=GetMyItems();

owner.name:SetText(string.format("%s(%s: %d)",_L("\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\236\158\145"),_L("\236\160\156\236\158\145\235\178\149 \235\160\136\235\178\168"),(_S["\235\160\136\236\132\156\237\148\188"][recipe.guid]or 0)));
owner.subitem:SetText(_L("\236\158\172\235\163\140 \236\149\132\236\157\180\237\133\156").." : ".._L(itemtb["\236\162\133\235\165\152"]));

local function reserveItem(id)
id=UnidentityItemId(id);
for k,v in pairs(myItems)do
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][k];
if o.id==id or table.find(const(id),o.id)then
if(o.c or 1)>(reserved[k]or 0)then
reserved[k]=(reserved[k]or 0)+1;
return k;
end
end
end
end

local function selectSlot(itemId,onSelect,onCancel)
for k,v in ipairs({"slot2","slot3"})do
if not selected[v]then
onSelect(v);
return;
end
end
onCancel()
end

local function getTier()
local tiers={};
for k,v in pairs({"slot2","slot3"})do
local itemId=selected[v];
if itemId then
table.insert(tiers,ItemTier(itemId));
end
end

local t1=math.min(tiers[1]or 0,tiers[2]or 0);
local t2=math.max(tiers[1]or 0,tiers[2]or 0);
local a=(t1+t2)/2;
local b=(t2)+0.5;
local t=0;
for i=1,countkcc(2,bf("\236\154\180")/100,3)do
t=math.max(t,math.randrange(a,b));
end
return totiernumber(t2),math.min(const("\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\236\158\145\236\181\156\235\140\128\237\139\176\236\150\180"),totiernumber(t));
end
local function getOutTier()
if itemtable[itemId]["\237\139\176\236\150\180"]==0 then
return 0;
else
local a,out=getTier();
return out;
end
end


local function canSelect(itemId)
if not table.find(selected,itemId)then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemId];
if o and itemtable[o.id]["\236\162\133\235\165\152"]==itemtable[selected.slot]["\236\162\133\235\165\152"]then
return true;


end
end
end

for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end


local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
owner.myinven[v]:Clear();
local itemId=_S["\236\138\172\235\161\175"][v];
if itemId and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemId]then
SetItemIconFromGuid(owner.myinven[v],itemId);
else
assert(images[v],v);
SetItemIconFromGuid(owner.myinven[v]);
owner.myinven[v].img:AddSymbol(images[v],"icon");
end
end
end
end

local function canMake()
if not hasBuilding then
return false;
end
if not selected.slot2 or not selected.slot3 then
return false;
end

for k,v in ipairs(itemList)do
local guids,id,cnt=table.unpack(v);
if#guids<cnt then
return false;
end
end
return true;
end

local function updateMaterials()
reserved={};
itemList={};
local tier=getTier();
materials=recipe["\236\158\172\235\163\140"]or{};
for _,k in ipairs(table.sortedkeys(materials,CmpItemPriority))do
local v=materials[k];
local guids={};
for i=1,v,1 do
local guid=reserveItem(k);
if guid then
table.insert(guids,guid);
end
end
table.insert(itemList,{guids,k,v});
end

owner.sub:Clear();
MakeSubMaterialSlot(owner.sub,table.length(materials),materials);

do
AddItemIcon(owner.slot.img,itemId);
if owner.slot.name then
owner.slot.name:SetText(itemtable[itemId].name);
end
SetItemIconGrade(owner.slot.back,itemId);

SetItemIconFromGuid(owner.slot2,selected.slot2);
SetItemIconFromGuid(owner.slot3,selected.slot3);

SetButton(owner.slot).onClick=function()
ShowItemInfo(itemId);
end
end

hasBuilding=SetRequireBuildingText(owner.req,recipe,tier);

if canMake()then
owner.btnOk:enable(true);
owner.btnOk:GotoAndStop(1,true);
else
owner.btnOk:enable(false);
owner.btnOk:GotoAndStop(2,true);
end

end

local function initBag()
trace("initbag");
do
for k,v in ipairs(GetAvailStorageSlots())do
if mode==v then
owner.myinven[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner.myinven[v].img:SetAlphaDepth(0.3);
else
owner.myinven[v].img:SetAlphaDepth(1);
end
end
end

owner.myinven.list:Clear();

local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o["\234\176\128\235\176\169"];
SetMyInventoryWnd(owner.myinven.list,d);
if prevScroll then
owner.myinven.list.list.setScroll(prevScroll);
end
function owner.myinven.list.list:onScroll(s)
prevScroll=s;
end

local function setInfo(this,mc,itemId)
if(itemId or 0)~=0 then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemId],itemId);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemId];
local c=(o.c or 1);
if c>0 then
SetItemIconFromGuid(mc,itemId);
SetItemIconCnt(mc.cnt,c);
else
SetItemIconFromGuid(mc);
end
else
SetItemIconFromGuid(mc);
end

if mc.enabled then
mc.img:SetAlphaDepth(1);
else
mc.img:SetAlphaDepth(0.3);
end
end

owner.myinven.list.list.onSelected=function(this,mc,itemId)
if itemId and itemId~=0 and mc.enabled then
local function onOk(slot)
selected[slot]=itemId;
updateMaterials();
owner.myinven.list.list:refresh();
end
local function onCancel()
end

local function onOk2()
selectSlot(itemId,onOk,onCancel);
end
ShowItemInfo(itemId,onOk2,_L("\235\132\163\234\184\176"));
return true;
end
end
owner.myinven.list.list.setInfo=function(this,mc,itemId)
if itemId~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemId];
mc.enabled=canSelect(itemId);
setInfo(this,mc,itemId);
end
end

updateMaterials();
owner.myinven.list:init();
end


local function changeMode(slot)
mode=slot;
prevScroll=nil;

initBag();
end

for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
SetButton(owner.myinven[v],nil,nil,nil,0,0).onClick=function()
if IsStorageSlot(v)then
if _S["\236\138\172\235\161\175"][v]~=0 then
changeMode(v);
end
end
end
end
end

function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
initSlots();
initBag();
end


SetTextButton(owner.btnOk,_L("\236\160\156\236\158\145")).onClick=function()
if not world.player:isTurnBusy()then
owner:onUnload();
owner:Remove();
onOk(itemId,reserved,selected.slot2,selected.slot3,getOutTier());
end
end

for k,v in pairs({"slot2","slot3"})do
SetButton(owner[v]).onClick=function()
selected[v]=nil;
updateMaterials();
owner.myinven.list.list:refresh();
end
end

SetButton(owner.myinven.btnClose).onClick=function()
owner:Remove();
onCancel();
end

eventDispatcher:add(owner,owner.onEvent);
owner:init();

end

