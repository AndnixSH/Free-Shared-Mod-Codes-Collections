
































function getBuff(buff,type,target,target_default,fcond,guid)
local s=0;
local param=nil;
if buff[type]then
for k,v in pairs(buff[type])do
if not guid or(k==guid or string.starts(k,guid.."/"))then

local p=v.p or 1;
local p1=v.p1;
local p2=v.p2;
target_default=target_default or 1;
if not p1 and not p2 then
if target_default==1 then p1,p2=p,0;
else p1,p2=0,p;
end
end
local rd=AlwaysForceBuff or math.random();
if(not target and p>rd)or(target==2 and p2 and p2>rd)or(target==1 and p1 and p1>rd)then
local c=v.c or 0;
if not v.cond or fcond(target,v.cond,k)then
if _G.type(c)=="table"then
s=c;
else
s=s+c;
end
param=param or{};
param[k]={c=c};
if v.param then
for kk,vv in pairs(v.param)do
param[k][kk]=vv;
end

end





end
end
end
end
end
return s,param;
end



function addBuff(buff,type,guid,value,tick,dur,args)

args=args or{};
local p=args.p;
local p1=args.p1;
local p2=args.p2;
local cond=args.cond;
local param=args.param;
buff[type]=buff[type]or{};
buff[type][guid]=buff[type][guid]or{};
assert(guid,type);
local d=buff[type][guid];
if args.a then
value=(d.c or 0)+args.a;
if args.a2 and value>args.a2 then
value=args.a2;
end
end

if args.m then
d.T=nil;
d.t=nil;
d.d=nil;
end

d.c=value;
d.m=args.m;
d.m2=args.m2;
d.p,d.p1,d.p2=p,p1,p2;
d.cond=cond;
d.param=param;
d.f=args.f;

if tick or dur then
d.T=d.T or 0;
if(tick or 0)>0 then
d.t=tick;
end
if dur then
d.d=d.T+dur;
end
end
if(d.t or 0)>0 then
d.v=value;

local a=math.floor((d.T-10)/d.t);
local b=math.floor(d.T/d.t);
local m=d.m or 0;
local f=d.f or 0;
m=m*b;
if d.m2 then
m=math.min(m,d.m2);
end
d.c=(d.v or 0)*(b-a)+m+(d.f or 0);
end

end

function delBuff(buff,type,guid)
local subName=guid.."/";
local c=0;
for k,v in pairs(buff[type])do
if k==guid or string.starts(k,subName)then
buff[type][k]=nil;
c=c+1;
end
end
return c;






end
function delBuffFromGuid(buff,guid)
local c=0;
for type,v in pairs(buff)do
c=c+delBuff(buff,type,guid);
end
if c>0 then
return true;
end
end

function delBuffFromType(buff,type)
if buff[type]then
local c=0;
for key,vv in pairs(buff[type])do
c=c+delBuff(buff,type,key);
end

buff[type]=nil;
if c>0 then
return true;
end
end
end

function reduceBuffDur(buff,guid,dur,mul)
for type,v in pairs(buff)do
local d=v[guid];
if d then
if d.T then
if d.d then
d.d=d.d-(dur or 0)-d.d*(mul or 0);
if d.d<=d.T then
v[guid]=nil;
end
end
end
end
if table.empty(v)then
buff[type]=nil;
end
end
end

function addBuffLV(buff,guid,add,mul)
for type,v in pairs(buff)do
local d=v[guid];
if d then
if d.LV then
d.LV=math.floor(d.LV+add+d.LV*mul);
if d.LV<=0 then
v[guid]=nil;
end
end
end
if table.empty(v)then
buff[type]=nil;
end
end
end

function cleanBuff(buff,cb)
for type,v in pairs(buff)do
for guid,d in pairs(v)do
if d.T then
if d.d and d.d<=d.T then
v[guid]=nil;
end
end
end
if table.empty(v)then
trace("!!\235\178\132\237\148\132\235\129\157",type);
buff[type]=nil;
if cb then
cb(type);
end
end
end
end

function updateBuff(buff,AP)
for type,v in pairs(buff)do
for guid,d in pairs(v)do
if d.T then
local curT=d.T+AP;
if d.t then
local a=math.floor(d.T/d.t);
local b=math.floor(curT/d.t);
local m=d.m or 0;
local f=d.f or 0;
m=m*b;
if d.m2 then
m=math.min(m,d.m2);
end
d.c=(d.v or 0)*(b-a)+m+f;





end
d.T=curT;
end
end
end
end
