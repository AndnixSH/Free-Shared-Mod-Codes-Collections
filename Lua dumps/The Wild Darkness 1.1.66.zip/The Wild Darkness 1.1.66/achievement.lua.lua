function Viewachieve()
sendCommand("viewachieve");
end
function Viewrank()
sendCommand("viewranking");
end

function SetHighscore(type,n)
if _Z.IOS then
sendCommand("highscore",const("\235\166\172\235\141\148\235\179\180\235\147\156_ios",type),n);
else
sendCommand("highscore",const("\235\166\172\235\141\148\235\179\180\235\147\156_android",type),n);
end
end

function UnlockAchive(t)
if _Z.IOS then
sendCommand("achieve",t.ios_id);
else
sendCommand("achieve",t.android_id);
end
trace("UnlockAchive",t);
end


local checklist={"\236\167\129\236\151\133","\236\167\129\236\151\133\236\131\157\236\161\180","\237\148\140\235\160\136\236\157\180","\236\131\157\236\161\180","\236\151\148\235\148\169","\236\178\152\236\185\152\235\179\180\236\138\164","\236\132\164\236\185\152","\236\160\156\236\158\145"};

local function check(tb)
for k,v in ipairs(checklist)do
if tb[v]then
if v=="\236\131\157\236\161\180"then
if _S and GetDay(_S.T)<tb[v]then
return false;
end
elseif v=="\236\167\129\236\151\133\236\131\157\236\161\180"then
local n,d=table.unpack(tb[v]);
local c=0;
for k,v in pairs(_D["\236\152\164\237\148\136\236\167\129\236\151\133"])do
if v>=d then
c=c+1;
end
end
if c<n then
return false;
end
elseif v=="\236\167\129\236\151\133"then
if _S and _S[v]~=tb[v]then
return false;
end
elseif v=="\236\178\152\236\185\152\235\179\180\236\138\164"or v=="\236\132\164\236\185\152"or v=="\236\160\156\236\158\145"then
for _,vv in safe_pairs(tb[v])do
if _S and(_S[v][vv]or 0)<=0 then
return false;
end
end
elseif _G.type(tb[v])=="string"then
if((_S and _S[v])or _D[v])~=tb[v]then
return false;
end
elseif _G.type(tb[v])=="number"then
if((_S and _S[v])or _D[v]or 0)<tb[v]then
return false;
end
end
end
end
return true;
end

function CheckAchieve()
for k,v in pairs(achievetable)do
local g="g"..k;
if not _D["G\235\143\132\236\160\132\234\179\188\236\160\156"][g]and check(v)then
_D["G\235\143\132\236\160\132\234\179\188\236\160\156"][g]=1;
UnlockAchive(v);
end
end

for k,v in pairs(serverachievetable)do
local g="g"..k;
if not _D["\235\143\132\236\160\132\234\179\188\236\160\156"][g]and check(v)then
_D["\235\143\132\236\160\132\234\179\188\236\160\156"][g]=1;
end
end
end
