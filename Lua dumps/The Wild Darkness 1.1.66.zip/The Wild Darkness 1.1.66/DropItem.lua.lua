DropItem=Object:new({
})

function DropItem:init(guid,sdata,loaded)
Object.init(self,guid,sdata,loaded);
self.sdata.willDie=true;
if not self.sdata.item or not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item]then
self:die();
else
self:updateAttachment();
if loaded then
self:animate(-0.001);
end
end









end

function DropItem:isNickVisible()
return
not self:isCompleted()and
world.ground:inLOS(self.tile.x,self.tile.y)

;

end


function DropItem:burn()
trace("DropItem:burn");
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item];
local item=itemtable[o.id];
if item["\237\131\128\235\138\148 \236\139\156\234\176\132"]then
local tile=world.ground:getTile(self.tile.x,self.tile.y);
if tile~=TT.WATER then
if item["\237\131\128\235\138\148 \236\139\156\234\176\132"]==0 then
self:burnOut();
else
world.ground:addTileBlockRef(self.tile.x,self.tile.y,Block_Danger,self);
self.sdata.burnT=self.sdata.burnT or countkcc(item["\237\131\128\235\138\148 \236\139\156\234\176\132"]);
self:idle();
end
end
end
end


function DropItem:burnOut()
world.ground:delTileBlockRef(self.tile.x,self.tile.y,Block_Danger,self);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item];
local newId=FindCook(o.id);
if newId then
o.id=newId;
SetCookData(o);
self:updateAttachment();
else
self.skeleton:setChild("item",{
particle="media/particle/particle_burn.json"
});
self.mc:SetAlphaColor(0xff000000);
self:die();
end
end

function DropItem:updateAttachment()
if self.sdata.item then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item],self.guid,self.sdata.item);
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][self.sdata.item].id;
local newId=UnidentityItemIdFromGuid(self.sdata.item);
if newId~=self.itemId then
self.itemId=newId;
local item=itemtable[self.itemId];
assert(item and item.obj,self.itemId);
self.isScroll=string.find(item.obj,"_scroll_");
if self.isScroll then
self.skeleton:setAttachment("scroll",item.obj);
self.skeleton:setAttachment("item");
else
self.skeleton:setAttachment("item",item.obj);
self.skeleton:setAttachment("scroll");
end
if self.mcNick then
self.mcNick.nick:SetText(ItemName(self.sdata.item));
end
end
end
end

function DropItem:update(...)
Object.update(self,...);
if not self.dying then
self:updateAttachment();
end
end

function DropItem:getZOrder()
return Object.getZOrder(self)+1;
end






function DropItem:animate(t)
local id=self.itemId;
local item=itemtable[self.itemId];
assert(item,self.itemId,self.sdata.item);

local function cb(evt)
if evt=="event_sound"then
if(t or 0)>=0 then
world.player:playItemSound("\235\147\156\235\158\141",id);
end
end
end
self:play(item.dropani,false,t,nil,cb);
end

function DropItem:fly(from)
if from then
local x,y=from.x,from.y;
local tox,toy=self.pos.x,self.pos.y;
local cx,cy=(tox-x),(toy-y);

local f=function(o,v)
self.pos.x=x+cx*v;
self.pos.y=y+cy*v;
self:updateMC();
end
local dur=0.5;
if self.isScroll then
dur=0.8;
end
local easing=linear;
local tweener=Tweener(self,f,0,1,dur,0,easing);
self.timer.add("ani",tweener.update);
end
end

function DropItem:complete(delay)
if PickItem(self.guid,self.sdata.item)then
self.sdata.item=nil;
Object.complete(self);
PickItemEfx(self.itemId,delay);
else
world.player:addChat(_L("\234\176\128\235\176\169\236\151\144 \235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
local x,y=world.ground:getRandThrowTile(_S.x,_S.y,Filter_Player);
local o=world:createObject("\236\149\132\236\157\180\237\133\156",x,y,{item=self.sdata.item},true);
o:fly(self.pos);
self.sdata.item=nil;
Object.complete(self);







end

end

