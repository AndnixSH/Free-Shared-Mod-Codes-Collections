RandomDungeonGate=Object:new({
})

function RandomDungeonGate:onBuild(ids)
ids=ids or{};
local list={};
local r,g,b;
local key=string.format("%d,%d,%d",
table.count(ids,"\235\133\185\236\131\137 \236\167\128\235\143\132 \236\161\176\234\176\129"),
table.count(ids,"\237\157\176\236\131\137 \236\167\128\235\143\132 \236\161\176\234\176\129"),
table.count(ids,"\235\185\168\234\176\149 \236\167\128\235\143\132 \236\161\176\234\176\129"));

for k,v in pairs(maptable)do
if v["\235\158\156\235\141\164 \235\141\152\236\160\132"]and v["\235\139\164\236\157\140 \236\167\128\236\151\173"]then
list[k]=v["\235\158\156\235\141\164 \235\141\152\236\160\132"][key]or 0;
end
end

_S["\235\141\152\236\160\132 \236\131\157\236\132\177 \236\160\144\236\136\152"]=0;
for _,id in safe_pairs(ids)do
_S["\235\141\152\236\160\132 \236\131\157\236\132\177 \236\160\144\236\136\152"]=_S["\235\141\152\236\160\132 \236\131\157\236\132\177 \236\160\144\236\136\152"]+(const("\235\141\152\236\160\132\236\131\157\236\132\177\236\160\144\236\136\152",id)or 0);
end

local area=math.randlist(list)or table.choicekey(list);
local newFields={};
local t=table.copy(maptable[area]);

newFields[area]=t;
for area,v in pairs(maptable)do
if v["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"and v["\235\158\156\235\141\164 \235\141\152\236\160\132"]then
_S["\237\149\132\235\147\156 \234\176\156\236\136\152"][area]=countkcc(v["\237\149\132\235\147\156 \234\176\156\236\136\152"]);
if table.empty(v["\235\158\156\235\141\164 \235\141\152\236\160\132"])then
newFields[area]=v;
end
end
end
BuildMaps(false,newFields);
self.sdata.area=area;
end

function RandomDungeonGate:travel()
world.player:playSndQueue("\236\176\168\236\155\144\236\157\152 \235\172\184 \236\130\172\236\154\169");
world.gameEnded=true;
world.isTraveling=true;
local function f()
local mapId=MapId("\237\149\132\235\147\156",self.sdata.area,1);
_G.nextMap=mapId;
_G.nextMapFromElevator=nil;
_S.maps[mapId]["\235\130\152\234\176\132\234\179\179"]=nil;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

function RandomDungeonGate:menuTouch(from,menu,onOk,onCancel)
if from:canSleep()and self.sdata.area then
self:travel();
else
world.player:addChat(_L("\236\158\160\236\158\144\234\184\176 \236\139\164\237\140\168"));
onCancel();
end
end
