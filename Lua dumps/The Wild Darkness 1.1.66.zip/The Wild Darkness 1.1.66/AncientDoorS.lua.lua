

AncientDoorS=Object:new({
})

function AncientDoorS:travel(from)
local id=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"];
local function f()
world.gameEnded=true;
world.isTraveling=true;
if self.sdata.fromDoor then
_G.nextMap,_G.nextMapFromElevator=table.unpack(self.sdata.fromDoor);
else
local maps={};
if type(id)=="table"then
if id.swap then
self.sdata.id=id.swap;

end
if maptable[id.id]then
local mapId=MapId("\237\149\132\235\147\156",id.id,id.field or 1);
table.insert(maps,mapId);
else
_G.nextMapFromElevator=id["\236\152\164\235\184\140\236\160\157\237\138\184"]or id.id;
end

id=id.id;
else
_G.nextMapFromElevator=id;
end

if _S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][id]then
for _,vv in pairs(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][id])do
table.insert(maps,vv.mapId);
end
_G.nextMapFromElevator=id;
end

if _S["\234\179\160\236\160\149\235\176\169"][id]then
for i,mapId in pairs(_S["\234\179\160\236\160\149\235\176\169"][id])do
table.insert(maps,mapId);
end
end

_G.nextMap=table.choice(maps);

if _G.nextMapFromElevator and self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]and self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]["\235\166\172\237\132\180"]then
local m=_S.maps[_G.nextMap];
for k,v in safe_pairs(m.objects)do
if v.id==_G.nextMapFromElevator then
v.fromDoor={_S["\237\152\132\236\158\172\235\167\181"],self.guid};
end
end
end
end
root:GotoAndStop("travel");
end
local function run()
world.gameEnded=true;
world.isTraveling=true;
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

if type(id)=="table"and id.z then
local to=from.pos;
local h=id.z;
from:fall({x=to.x,y=to.y,z=h,vz=1500},math.abs(h/800),run);
else
run();
end

end

function AncientDoorS:complete(menu)
if menu=="\235\169\148\235\137\180_\236\178\160\234\177\176"then
Object.complete(self,menu);
else
self:travel(world.player);
end
end
