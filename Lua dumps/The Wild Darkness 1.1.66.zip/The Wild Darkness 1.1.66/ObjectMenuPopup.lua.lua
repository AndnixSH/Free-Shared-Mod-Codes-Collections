
function ObjectMenuPopup(o,onOk,onCancel,btns)
local opened=0;
local mc2;
trace("ObjectMenuPopup",o.sdata.id);






local mc=world.ground:CreateEmptyMovieClip("objMenu");
mc:SetPos(world.ground:MapToScreen(o.pos.x,o.pos.y));
function mc:closeIfMe(obj,cb)
if o==obj then
mc:close(cb);
end
end
function mc:closeIfOpened(cb)
if opened==#btns then
mc:close(cb);
end
end
function mc:close(cb)


if mc2 then
mc2:Remove();
mc2=nil;
end

do

mc:SetInputEnable(false);
local _func=world.player.onTouchCancel;

world.player:cancelTarget();
world.player.onTouchCancel=function(...)
trace("onTouchCancel");
if cb then
cb(o);
end
world.player.onTouchCancel=_func;
world.player.onTouchCancel(...);

end
opened=0;
world.ground.objMenu=nil;

local f=function(mc,v)
for _,o in pairs(mc:GetShapeList())do
o:SetScale(v,v);
o:SetPos(o.x*v,o.y*v);
end
end
local dur=0.18;
local delay=0;
local easing=inBack;
local tweener=Tweener(mc,f,1,0,dur,delay,easing);
tweener.onCompleted=function()
mc:Remove();
end
world.timer.add(tweener,tweener.update);
for k,v in ipairs(btns)do
world.timer.remove("menutw"..k);
end
onCancel();
end
end

local W=90;
local R=W;
local rad=math.pi*2/6;
local r0=-(rad*(#btns-1))/2;
for k,v in ipairs(btns)do
local btn=mc:AddSymbol("\236\152\164\235\184\140\236\160\157\237\138\184\235\169\148\235\137\1801\236\185\184","");
local easing=outBack;
local dur=0.18;
local delay=0;
local x,y=0,0;
local r=r0+rad*(k-1);
local x2=R*math.sin(r);
local y2=-R*math.cos(r);
local item=itemtable[v];

local f=function(o,v)
o.x,o.y=x+(x2-x)*v,y+(y2-y)*v
o:SetScale(v,v);
o:SetPos(o.x,o.y);
end
local tweener=Tweener(btn,f,0,1,dur,delay,easing);
tweener.onCompleted=function()
opened=opened+1;
end

world.timer.add("menutw"..k,tweener.update);
f(btn,0);

btn.img:AddSymbol(item.img,"icon");
if btn.name then
btn.name:SetText(item.name);
end
local materials=o:menuMaterials(v);
if materials then
for k,v in ipairs(materials)do
local txt=btn["txt"..i];
if txt then
txt:SetText(string.format("%s:%d",k,v));
txt:SetVisible(true);
end
end
end
SetButton(btn).onClick=function()
if opened==#btns then
local function f()
if materials then
local function ok(id,guids)

do
opened=0;
mc:Remove();
onOk(v,guids);
end
end
local function cancel()
mc:close();

end
BuildItemPopup(world,ok,cancel,"\235\178\132\237\138\188",{v,materials,{object=o}});
else
for k,v in ipairs(btns)do
world.timer.remove("menutw"..k);
end
opened=0;
mc:Remove();
onOk(v);
end
end
if item["\237\140\140\235\157\188\235\175\184\237\132\176"]then
mc2=showPopup(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(_L(item["\237\140\140\235\157\188\235\175\184\237\132\176"]));
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
mc2=nil;
f();
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
mc2=nil;
end
else
f();
end
end
end
end
end
