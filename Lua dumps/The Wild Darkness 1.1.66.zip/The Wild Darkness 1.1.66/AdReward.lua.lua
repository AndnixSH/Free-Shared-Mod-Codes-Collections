AdReward=Object:new({
})

function AdReward:complete(id)
Object.complete(self);
local items={};
if id=="ad"or id=="dia"then
for i=1,countkcc(const("\237\153\152\236\152\129\236\157\152\236\131\129\236\158\144\236\149\132\236\157\180\237\133\156\234\176\156\236\136\152"))do
table.insert(items,{MakeItemFromDrop,{"\237\153\152\236\152\129\236\157\152 \236\131\129\236\158\144(\234\180\145\234\179\160)",100,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
for i=1,countkcc(const("\237\153\152\236\152\129\236\157\152\236\131\129\236\158\144\236\149\132\236\157\180\237\133\156\234\176\156\236\136\1522"))do
table.insert(items,{MakeItemFromDrop,{"\237\153\152\236\152\129\236\157\152 \236\131\129\236\158\144(\236\157\188\235\176\152)",100,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
else
for i=1,countkcc(const("\237\153\152\236\152\129\236\157\152\236\131\129\236\158\144\236\149\132\236\157\180\237\133\156\234\176\156\236\136\1523"))do
table.insert(items,{MakeItemFromDrop,{"\237\153\152\236\152\129\236\157\152 \236\131\129\236\158\144(\236\157\188\235\176\152)",100,self.tile.x,self.tile.y,self.sdata.dropRare}});
end
end

world:pauseTurn();

local function f()
if items[1]then
local func,param=items[1][1],items[1][2];
func(table.unpack(param));

table.remove(items,1);
return true;
else
world:resumeTurn();
end
end
world.timer.add(f,f,const("\235\147\156\235\161\173\236\149\132\236\157\180\237\133\156\237\139\177"));
end

function AdReward:menuTouch(from,menu,onOk,onCancel)
local function f()
if hasAds()then
local function _ok()
ToastEvent("\234\180\145\234\179\160","adreward",0,0,1,_D["\237\148\140\235\160\136\236\157\180"])
onOk("ad");
end
showAds(_ok,onCancel);
else
onCancel();

end
end

local mc=showPopup(world,"\237\153\152\236\152\129\236\157\152\236\131\129\236\158\144\237\140\157\236\151\133");
SetTextButton(mc.btnAd,_L("\234\180\145\234\179\160 \235\179\180\234\184\176")).onClick=function()
mc:Remove();
f();
end

SetTextButton(mc.btnOk,_L("\236\157\188\235\176\152 \236\151\180\234\184\176")).onClick=function()
mc:Remove();
onOk();
end

if not hasAds()then
mc.btnAd:GotoAndStop(2,true);
mc.btnAd:enable(false);
else
mc.btnAd:GotoAndStop(1,true);
end

mc.btnDia:GotoAndStop(1,true);
mc.btnOk:GotoAndStop(1,true);

SetTextButton(mc.btnDia,servertable.AdRewardDia).onClick=function()
TryConnect(function()
local onS=function(t)
if t.status=="ok"then
mc:Remove();
onOk("dia");
elseif t.status=="nodia"then
local mc2=showPopup(world,"\235\169\148\236\132\184\236\167\128\237\140\157\236\151\133YN");
mc2.txt:SetText(lang.nodiaQ);
SetButton(mc2.btnOk).onClick=function()
mc2:Remove();
TryConnect(function()
local wnd=showPopup(world,"\236\131\129\236\160\144\237\140\157\236\151\133");
SetShop(wnd);
end);
end
SetButton(mc2.btnCancel).onClick=function()
mc2:Remove();
end
end
end
local onF=function(t)
end
HttpWaitAsync(world,
sendAdReward(onS,onF),
lang.waitLoginInfo);
end);
end
SetButton(mc.btnCancel).onClick=function()
mc:Remove();
onCancel();
end

end
