
function ItemMessagePopup(onOk,guid,title,values)
local mc;
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]or itemtable[guid]or spelltable[guid]then
mc=showPopup(world,"\236\136\152\235\166\172\237\140\157\236\151\133");
else
mc=showPopup(world,"\237\155\136\235\160\168\237\140\157\236\151\133");
end
local _,_,W,H=mc.back:GetAABB();
if mc.icon then
if spelltable[guid]then
mc.icon.img:AddSymbol(spelltable[guid].img..".png","icon");
local _,_,cx,cy=mc.icon.img.icon:GetBound();
mc.icon.img.icon:SetPos((120-cx)/2,(120-cy)/2);
mc.name:SetText(spelltable[guid].name);
elseif itemtable[guid]then
AddItemIcon(mc.icon.img,guid);
mc.name:SetText(itemtable[guid].name);
else
SetItemIconFromGuid(mc.icon,guid);
mc.name:SetText(ItemName(guid));
end
end
mc.title:SetText(title);

local str="";
for k,v in ipairs(values)do
local s;
if v[3]then
local v1=tostringf(v[2]);
local v2=tostringf(v[3]);
s=LabelRichTextItem(v[1]..": ",0xffffffff)..
LabelRichTextItem(v1,0xFFc0c000,45)..
"<sp\tsize=50/><img>media/image/_ui/mark_arrow_2.png</img><sp\tsize=50/>"..
LabelRichTextItem(v[1]..": ",0xffffffff)..
LabelRichTextItem(v2,0xFFc0c000,45);
else
local v1=tostringf(v[2]);
s=LabelRichTextItem(v[1]..": ",0xffffffff)..LabelRichTextItem(v1,0xFFc0c000,45);
end
str=str..s.."<br\tsize=35/>";
end
mc.canvas:SetText(LabelRichText(str));
SetButton(mc.btnClose).onClick=function()
mc:Remove();
onOk();
end
end