
Craftsman=Object:new({
})

function Craftsman:complete(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local v1=o["\235\147\177\234\184\137"];
local item=itemtable[o.id];
SetItemRare(guid);
o["\234\176\149\237\153\148"]=(o["\234\176\149\237\153\148"]or 0)+countkcc(const("\235\185\132\236\160\132\236\160\156\236\158\145\235\178\149\234\176\149\237\153\148"));
AddItemOption(nil,guid,0,{"\236\164\145\234\176\132","\236\162\139\236\157\140"});
local v2=o["\235\147\177\234\184\137"];
Object.complete(self);
local function cb()
world:resumeTurn();
end
world:pauseTurn();
ItemMessagePopup(cb,guid,_L("\235\160\136\236\150\180\237\131\128\236\157\180\237\139\128"),{{_L("\235\147\177\234\184\137"),_L(v1),_L(v2)}});
end

function Craftsman:menuTouch(from,menu,onOk,onCancel)

if not self.sdata.key or ConsumeItem(self.sdata.key,1,false)then
local function _ok(guid)
if not self.sdata.key or ConsumeItem(self.sdata.key,1,true)then
onOk(guid);
else
onCancel();
end
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176","\235\176\169\236\150\180\234\181\172","\236\149\133\236\132\184\236\132\156\235\166\172"},"\235\147\177\234\184\137\234\176\149\237\153\148",{object=self,["\235\147\177\234\184\137"]="\235\133\184\235\167\144"});
else
world.player:addChat(_L("\236\158\165\236\157\184\236\157\152 \236\136\152\236\178\169\236\157\180 \237\149\132\236\154\148\237\149\156\234\178\131 \234\176\153\235\139\164."));
onCancel();
end
end
