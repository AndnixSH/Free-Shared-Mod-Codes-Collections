_Z.tileW=168;
_Z.tileH=134;
_Z.orientation="isometric";
_Z.PPM=1;
_Z.TileDrawOffset={-4,-100};
_Z.TileRatio=_Z.tileH/_Z.tileW;
_Z.GaugeHmargin=2;
_Z.PathMaxPeople=1;
_Z.PathOption=4;
_Z.NpcNickOffset=-20;
_Z.walkDur=40/60;
_Z.ZoomPerPixel=1/100;
_Z.MinimapPlayerZoom=2;
_Z.MaxZoom=2;
_Z.MinZoom=0.6;
_Z.MaxSpeed=200;
_Z.MaxDebuffDur=99999999;
_Z.PlayerFrontP=0.95;
_Z.SoundRange=1;
_Z.InvenW=600-48;
_Z.InitFowUpdateDur=0.5;
_Z.FowUpdateT=0.15;
_Z.FowUpdateDur=_Z.FowUpdateT*1.99;
_Z.FloatingT=4;
_Z.ObjectHPT=15;
_Z.BuidingAlpha=0.5;
_Z.MaxZOrder=99999;
_Z.SaveSchedule=60*5;
_Z.Object_FrontZ=50;
_Z.Projectile_AddZ=50;
_Z.ShowObjectNick=1;
_Z.GenerateTryCount=9999;
_Z.GenerateDigCount=10;
_Z.SendLogOnError=true;
_Z.HideObjectNick=true;
_Z.MinFps=15;
_Z.MaxFps=144;

tileSize=_Z.tileW;
tileMeter=tileSize/_Z.PPM;
MapToMeter=1/200;

MAP_W=60;
MAP_H=60;


Block_Me=1;
Block_MyTeam=2;
Block_Enemy=4;
Block_Object=8;
Block_Wall=16;
Block_Water=32;
Block_Sight=64;
Block_Danger=128;
Block_MyObject=256;
Block_Trap=512;


Filter_Default=Block_Water|Block_Danger|Block_Trap;
Filter_MyPath=Block_MyObject|Block_MyTeam|Block_Water|Block_Trap;
Filter_Path=Block_Sight|Filter_Default;
Filter_Ground=Filter_Default;
Filter_Player=Block_Me|Block_Enemy|Block_MyTeam|Filter_Default;
Filter_ObjectAndPlayer=Filter_Player|Block_Object|Block_MyObject;
Filter_Movable=Block_Sight|Filter_Default;
Filter_Attack=Filter_Player|Block_Sight|Block_MyObject;
Filter_Arrow=Filter_Player|Block_MyObject|Block_Sight;

Filter_ItemPlace=Filter_Player|Block_Sight|Block_MyObject;

Vision_None=0;
Vision_Old=1;
Vision_Cur=2;


ItemIcon_Width=120;

TimeZone_Evening=1;
TimeZone_Night=2;
TimeZone_Morning=3;
TimeZone_Day=4;

Sticky_right=1;
Sticky_down=2;
Sticky_left=4;
Sticky_up=8;

MsgFilterOnLoad=1;
MsgFilterOnUnload=2;
MsgFilterOnEnterFrame=4;
MsgFilterOnBeginScene=8;
MsgFilterOnEndScene=16;
MsgFilterLockBound=32;

TestTable=TestTable or _Z.WIN32;


















