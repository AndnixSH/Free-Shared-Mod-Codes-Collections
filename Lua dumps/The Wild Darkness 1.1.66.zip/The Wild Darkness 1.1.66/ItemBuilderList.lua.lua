













function MakeRecipeListFromTab(tab)


















local list={};
local listHere={};
local newRecipe=0;
for k,v in pairs(recipetabtable[tab])do
if IsVisibleRecipe(k)then
newRecipe=newRecipe+(_S["\235\137\180\235\160\136\236\132\156\237\148\188"][k]or 0);
if itemtable[v["\236\158\165\235\185\132"]]then
table.insert(list,v);
if v["\236\160\156\236\158\145 \236\139\156\236\132\164"]then
if _S["\235\160\136\236\132\156\237\148\188"][k]then
local o=InNearBuilding(v["\236\160\156\236\158\145 \236\139\156\236\132\164"]);
if o then
table.insert(listHere,v);
end
end
else
table.insert(listHere,v);
end
elseif objecttable[v["\236\158\165\235\185\132"]]then
local match=true;


















if match then
table.insert(list,v);
table.insert(listHere,v);
end
end
end
end
return list,listHere,newRecipe;
end
function ItemBuilderList(this,wtab,tab)
local owner=this;
local Maker_SlotLeft=10;
local Maker_SlotW=210;
local Maker_SlotH=180+22;
local Maker_TabW=120;
local Maker_SlotL=APP_W-Maker_SlotLeft*2;
local Maker_SlotN=math.floor(Maker_SlotL/Maker_SlotW);
local Maker_SlotW=Maker_SlotW+math.floor((Maker_SlotL%Maker_SlotW)/(Maker_SlotN));

local left=Maker_SlotLeft;
local width=Maker_SlotW;
local height=Maker_SlotH;
local container=this:CreateEmptyMovieClip("container");
local tabs={};
local tabList={};
local tab2;
local wstep=Maker_SlotN;


container:SetInputEnable(false);
container:SetSpriteMode(true);
this.parent:SetMouseCapture(true);
this.parent.parent:SetMouseCapture(true);

function getRequireBuildingList(v)
return GetRequireBuildingList(v.guid,nil,nil,true);
end

function canBuild(v)
local id=v["\236\158\165\235\185\132"];
local b=SetRequireBuildingText(nil,v);
if objecttable[id]then
local maxBuild=GetRecipeMaxBuild(v);
b=b and GetRequireHouse(v);
b=b and(not maxBuild or(_S["\236\132\164\236\185\152"][id]or 0)<maxBuild);
end
return b;
end


local function _SetText(txt,msg)
txt:SetText(msg);
end

function updateItem(mc,v,b)
local id=v["\236\158\165\235\185\132"];
local item=itemtable[id];
mc.name:SetText(item.name);
if item.img and mc.icon.img then
local img=AddItemIcon(mc.icon.img,id);
if not b then
img:SetAlphaColor(0xFF000000);
end
end

mc.new:SetVisible(_S["\235\137\180\235\160\136\236\132\156\237\148\188"][v.guid]~=nil);

local idx;
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]then
idx=table.find({"\235\133\184\235\167\144","\235\160\136\236\150\180","\236\151\144\237\148\189","\235\160\136\236\160\132\235\147\156"},v["\235\147\177\234\184\137"]);
end
if not b then
idx=0;
end
if idx then
mc.icon.back:ChangeSymbol(string.format("BIG_recipe_0%d.png",idx));
end

AddMaterialIcon(mc.mat,v["\236\158\172\235\163\140"]);
if b then
else
local i=1;
if v["\236\160\156\236\158\145 \236\139\156\236\132\164"]and not InNearBuilding(v["\236\160\156\236\158\145 \236\139\156\236\132\164"])then
local txt=mc["txt"..i];
_SetText(txt,string.format(_L("\236\152\134 \234\176\128\235\138\165"),BuildingName(v["\236\160\156\236\158\145 \236\139\156\236\132\164"])));
txt:SetVisible(true);
i=i+1;
end

local _,buildings=getRequireBuildingList(v);

for k,v in ipairs(buildings)do
local txt=mc["txt"..i];
if not v[2]then
if txt then
_SetText(txt,string.format(_L("%s \237\149\132\236\154\148"),objecttable[v[1]].name));

txt:SetVisible(true);
end
end
i=i+1;
end

Align(makeChildList(mc,"txt"),"left,vcenter",{5,5});
end
end

function updateObject(mc,v,b)
local id=v["\236\158\165\235\185\132"];
local item=objecttable[id];
mc.name:SetText(item.name);
mc.new:SetVisible(_S["\235\137\180\235\160\136\236\132\156\237\148\188"][v.guid]~=nil);
if item.img and mc.img then
local img=AddObjectIcon(mc.img,item.guid);

if not b then
img:SetAlphaColor(0xFF000000);
end
end

local idx;
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]then
idx=table.find({"\235\133\184\235\167\144","\235\160\136\236\150\180","\236\151\144\237\148\189","\235\160\136\236\160\132\235\147\156"},v["\235\147\177\234\184\137"]);
end

if not b then
idx=0;
end
if idx then
mc.back:ChangeSymbol(string.format("BIG_recipe_0%d.png",idx));
end

if b then
else
local _,buildings=getRequireBuildingList(v);
local i=1;
for k,v in ipairs(buildings)do
if not v[2]then
local txt=mc["txt"..i];
if txt then
local tb=objecttable[v[1]]or itemtable[v[1]];
if tb then
_SetText(txt,string.format(_L("%s \237\149\132\236\154\148"),tb.name));

txt:SetVisible(true);
i=i+1;
end
end
end
end


local req=GetRequireRecipeBuilding(v.guid);
if req then
for k,v in pairs(req)do
local txt=mc["txt"..i];
if txt then
_SetText(txt,string.format(_L(k.." %d \234\177\180\236\132\164"),v));
txt:SetVisible(true);
i=i+1;
end
end
end

local b,req=GetRequireHouse(v,true);
if not b then
local txt=mc["txt"..i];
if txt then
_SetText(txt,string.format(_L("%s \236\160\132\236\154\169"),_L(req)));
txt:SetVisible(true);
i=i+1;
end
end

if v["\236\163\188\235\179\128 \236\139\156\236\132\164"]then
if not InNearBuilding(v["\236\163\188\235\179\128 \236\139\156\236\132\164"])then
local txt=mc["txt"..i];
if txt then
_SetText(txt,string.format(_L("%s \236\163\188\235\179\128"),BuildingName(v["\236\163\188\235\179\128 \236\139\156\236\132\164"])));
txt:SetVisible(true);
i=i+1;
end
end
end

local maxBuild=GetRecipeMaxBuild(v);
if maxBuild and maxBuild<=(_S["\236\132\164\236\185\152"][id]or 0)then
local txt=mc["txt"..i];
if txt then
_SetText(txt,string.format(_L("\236\181\156\235\140\128 \236\132\164\236\185\152").." : %d",maxBuild));
txt:SetVisible(true);
i=i+1;
end
end

if v["\235\167\181\236\181\156\235\140\128\236\132\164\236\185\152"]then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local c=0;
for k,v in safe_pairs(_S.maps[mapId].objects)do
if v.id==id then
c=c+1;
end
end
if v["\235\167\181\236\181\156\235\140\128\236\132\164\236\185\152"]<=c then
local txt=mc["txt"..i];
if txt then
_SetText(txt,string.format(_L("\235\167\181\236\181\156\235\140\128 \236\132\164\236\185\152").." : %d",v["\235\167\181\236\181\156\235\140\128\236\132\164\236\185\152"]));
txt:SetVisible(true);
i=i+1;
end
end
end
Align(makeChildList(mc,"txt"),"left,vcenter",{5,5});
end

AddMaterialIcon(mc.mat,v["\236\158\172\235\163\140"]);
end


local function removeTabNew(tab)
if tab then
local c=0;
for i,v in ipairs(tabList[tab])do
if _S["\235\137\180\235\160\136\236\132\156\237\148\188"][v[1].guid]then
c=c+1;
_S["\235\137\180\235\160\136\236\132\156\237\148\188"][v[1].guid]=nil;
end
end
if c>0 then
world:updateMenu();
end
end
end

this.setTab=function(this,_tab)
removeTabNew(tab2);
_S.firstTab[tab]=_tab;
player:SetNextDeltaTimeZero();
tab2=_tab;
container:Clear();

for k,v in safe_pairs(tabs)do
if v==tab2 then
wtab[v]:GotoAndStop(2,true);
else
wtab[v]:GotoAndStop(1,true);
end
wtab[v].txt:SetText(_L(v));
wtab[v].cnt:SetText(wtab[v].can);
wtab[v].cnt:SetVisible(wtab[v].can>0);
end

local x=left;
local y=0;
for k,_v in safe_ipairs(tabList[_tab])do
if x+width>APP_W-Maker_SlotLeft then
x=left;
y=y+height;
end

if x<=left then
local line=container:AddSymbol("line_ui.png","_");
local _,_,cx,_=line:GetBound();
line:SetPos(0,y+height-6);
line:SetScaleX(APP_W/cx);
end
local v=_v[1];
local mc;
local b=canBuild(v);
if objecttable[v["\236\158\165\235\185\132"]]then
mc=container:AddSymbol("\236\167\147\234\184\1761\236\185\184","_");
updateObject(mc,v,b);
elseif itemtable[v["\236\158\165\235\185\132"]]then
mc=container:AddSymbol("\236\149\132\236\157\180\237\133\156\236\160\156\236\158\1451\236\185\184","_");
updateItem(mc,v,b);
end


mc:SetPos(x,y);
x=x+width;
_v[2]=mc;
end
this.setContentSize(y+height);
this.setScroll(0);
this:onTabChanged();
end


local function updateTabNew(tab)
local hasNew;
for i,v in ipairs(tabList[tab])do
hasNew=hasNew or _S["\235\137\180\235\160\136\236\132\156\237\148\188"][v[1].guid]~=nil;
end
wtab[tab].new:SetVisible(hasNew);
return hasNew;
end

this.make=function(this,filter)
local list,listHere=MakeRecipeListFromTab(tab);
SortRecipes(list);
tabs={};
tabList={};
wtab:Clear();
local mcTab=const("\236\132\184\235\182\128\237\131\173\236\157\180\235\166\132")[tab]or"\236\132\184\235\182\128\237\131\173";
for k,v in ipairs(list)do
local tab=v["\237\131\1732"];
if not tab and itemtable[v["\236\158\165\235\185\132"]]then
tab=itemtable[v["\236\158\165\235\185\132"]]["\236\162\133\235\165\152"];
end
tab=tab or"\234\184\176\237\131\128";
if not table.find(tabs,tab)then
wtab:AddSymbol(mcTab,tab);
wtab[tab].onMouseDown=function()
PlayAppSound(wtab[tab],"togglebutton");
this:setTab(tab);
return true;
end
table.insert(tabs,tab);
end
wtab[tab].can=(wtab[tab].can or 0);

if HasItems(v["\236\158\172\235\163\140"])and SetRequireBuildingText(nil,v)then
wtab[tab].can=wtab[tab].can+1;
end

tabList[tab]=tabList[tab]or{};
table.insert(tabList[tab],{v});
end
do
local t=const("\237\131\1732\236\136\156\236\132\156");
table.sort(tabs,function(a,b)return(table.find(t,a)or 0)<(table.find(t,b)or 0)end);
local tabx=10;
for i,tab in ipairs(tabs)do
local _,_,w,h=wtab[tab]:GetBound();
wtab[tab]:SetPos(tabx);
tabx=tabx+w-5;
end
end
for tab,v in pairs(tabList)do
updateTabNew(tab);
end
if table.find(tabs,_S.firstTab[tab])then
this:setTab(_S.firstTab[tab]);
else
this:setTab(tabs[1]);
end
end

this.getMaxContent=function(this)
local h=0;
for tab,v in pairs(tabList)do
h=math.max(h,height*(math.floor((#v-1)/wstep)+1));
end
return h;
end

this.close=function()
trace("close",tab2);
removeTabNew(tab2);
this:onTabChanged();
end

this.onShow=function()
if HasTutorial("\236\160\156\236\158\145\236\139\156\236\132\164\237\149\132\236\154\148")then
local list=tabList[tab2];
local btns={};
for k,v in pairs(list)do
local v,mc=table.unpack(v);

if v["\236\160\156\236\158\145 \236\139\156\236\132\164"]then
table.insert(btns,mc);
end
end
if#btns>0 then
Tutorial(this,"\236\160\156\236\158\145\236\139\156\236\132\164\237\149\132\236\154\148",{["\236\149\132\236\157\180\237\133\156"]=btns});
end
end
end

this.onSelect=function(this,y,x)

local i=math.floor(x/width);
local j=math.floor(y/height);
local list=tabList[tab2];
local v=list[j*wstep+i+1];
if v then
local v,mc=table.unpack(v);


do
mc.new:SetVisible(false);


this:select(v.guid);
local function ok(...)
this:put(...);
end
local function cancel()
end
if v["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
ArtifactPopup(world,ok,cancel,v.guid);
else
BuildItemPopup(world,ok,cancel,"\236\160\156\236\158\145\235\178\149",{v.guid,v["\236\158\172\235\163\140"]});
end
return true;
end
end
end
end