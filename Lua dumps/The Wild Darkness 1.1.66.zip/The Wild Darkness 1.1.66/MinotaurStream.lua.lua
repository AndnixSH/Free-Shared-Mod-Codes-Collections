
MinotaurStream=Object:new({
})

function MinotaurStream:init(...)
Object.init(self,...);
end

function MinotaurStream:rebirth(...)
Object.rebirth(self,...);
end


function MinotaurStream:isInTouch()
end

function MinotaurStream:getTeam()
return"\236\160\129\234\181\176";
end

function MinotaurStream:queryBoss(pos,radius)
local function query(o)
return o.sdata.boss;
end
return world.grid:QueryR(pos.x or pos[1],pos.y or pos[2],radius or 0,query);
end

function MinotaurStream:complete(...)
Object.complete(self,...);
self.sdata.activeT=countkcc(self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"].T);
end

function MinotaurStream:onResetTurn(AP)
Object.onResetTurn(self,AP);
if not self:isCompleted()then
local npc=self:queryBoss(self.tile,1);
if npc then
npc:addDebuf(self.sdata.id,self.guid);
self:action();
end
elseif self.sdata.activeT then
self.sdata.activeT=self.sdata.activeT-AP;
if self.sdata.activeT<=0 then
self:rebirth();
end
end
end
