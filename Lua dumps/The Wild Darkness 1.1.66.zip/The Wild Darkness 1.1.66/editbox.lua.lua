local inputTexts={};

function getEditBoxText(edit)
return sys.getTextInputText(edit.id);
end

function setEditBoxText(edit,text)
sys.setTextInputText(edit.id,text);
end

function createEditBox(x,y,cx,cy,str,pw)
local id=sys.addTextInput(x,y,cx,cy,str,pw);
inputTexts[id]={id=id};
inputTexts[id].getText=getEditBoxText;
inputTexts[id].setText=setEditBoxText;
inputTexts[id].remove=removeEditBox;
return inputTexts[id];
end

function removeEditBox(edit)
sys.removeTextInput(edit.id);
inputTexts[edit.id]=nil;
edit.id=nil;
end

function removeAllEditBox(edit)

inputTexts={};
end

_G.onInputText=function(this,id,msg)
if inputTexts[id]then
inputTexts[id]:onInputText(msg);
end
end


local focusEditBox=nil;
function SetEditBox(this,txt,pw,txtEmpty)

pw=pw or false;

local oldSetText=txt.SetText;
local oldGetText=txt.GetText;
txt.text=txt:GetText();
if txtEmpty then txtEmpty:SetVisible(txt.text=="");end

txt.SetText=function(self,s)
txt.text=s;
if pw then
oldSetText(self,string.rep("*",string.len(s)));
else
oldSetText(self,s);
end
if txtEmpty then txtEmpty:SetVisible(txt.text=="");end
end

txt.GetText=function(self)
return self.text;
end

this.close=function(this)
if this.edit then
if focusEditBox==this then
focusEditBox=nil;
end
this:SetMouseCapture(false);
txt:SetText(this.edit:getText());
this.edit:remove();
this.edit=nil;
this:SetMouseCapture(false);
this:SetEnableEventCapture(false);
txt:SetVisible(true);
if this.onTextChanged then
this:onTextChanged(txt:GetText());
end
end
end

this.SetText=function(this,t)
if this.edit then
this.edit:setText(t);
end
txt:SetText(t);
end

this.GetText=function(this)
if this.edit then
return this.edit:getText();
end
return txt:GetText();
end

this.setFocus=function(this)
if not this.edit then
if focusEditBox then
focusEditBox:close();
focusEditBox=nil;
end
local x,y,cx,cy=txt:GetBound();
local wx,wy=txt:GetWorldPos();
local w,h=sys.getDeviceResolution();
local sx,sy=sys.getCanvasScale();
cx=cx*sx;
cy=cy*sy;
local owner=this;
this.edit=createEditBox(wx,wy,cx,cy,txt:GetText(),pw);
this.edit.onInputText=function(self,msg)
owner:close();
if this.onEndEdit then
this:onEndEdit(msg);
end
end
this:SetMouseCapture(true);
this:SetEnableEventCapture(true);
txt:SetVisible(false);
focusEditBox=this;
if txtEmpty then txtEmpty:SetVisible(false);end
end
end

this.onMouseDown=function(this,mx,my,id)
local x,y,cx,cy=this:GetBound();
if mx>=x and my>=y and mx<cx and my<cy then
this:setFocus();
return true;
elseif this.edit then
this:close();
end
return false;
end
this.onMouseUp=function(this,mx,my,id)
local x,y,cx,cy=this:GetBound();
if mx>=x and my>=y and mx<cx and my<cy then
return true;
end
end

this.onUnload=function(this)
if this.edit then
this.edit:remove();
this.editid=nil;
if focusEditBox==this then
focusEditBox=nil;
end
end
end

end