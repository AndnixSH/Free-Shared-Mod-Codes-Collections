function EventDispatcher()
local inst={};
local t={};
function inst:add(o,f,once)
table.insert(t,{o,f,once});
trace("add:"..#t);
end

function inst:del(o,f)
local i=1;
while t[i]do
if t[i][1]==o and t[i][2]==f then
table.remove(t,i);
else
i=i+1;
end
end
trace("del:"..#t);
end

function inst:send(...)
trace("send:"..#t);
for i=#t,1,-1 do
local o,f,once=table.unpack(t[i]);
if f(o,...)then
if once then
table.remove(t,i);
end
return true;
end
end
end
return inst;
end
