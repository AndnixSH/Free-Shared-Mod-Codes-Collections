function makeChildList(mc,name,idx)
local list={};
for k,v in safe_ipairs(name)do
if mc[v]then
table.insert(list,mc[v]);
end
idx=idx or 1;
while mc[v..idx]do
table.insert(list,mc[v..idx]);
idx=idx+1;
end
end
return list;
end

function getListBBox(list)
local left,right,top,bottom;
for k,v in ipairs(list)do
local _,_,w,h=v:GetAABB();
local a,b=v:GetPos();
left=math.min(left or a,a);
right=math.max(right or(a+w),a+w);
top=math.min(top or b,b);
bottom=math.max(bottom or(b+h),b+h);
end
return{left,top,right,bottom};
end

function Align(list,align,margins,bbox)
margins=margins or{15,15};
bbox=bbox or{};
local left,right,top,bottom;
for k,v in ipairs(list)do
local _,_,w,h=v:GetAABB();
local a,b=v:GetPos();
left=math.min(left or a,a);
right=math.max(right or(a+w),a+w);
top=math.min(top or b,b);
bottom=math.max(bottom or(b+h),b+h);
end
left=bbox[1]or left;
top=bbox[2]or top;
right=bbox[3]or right;
bottom=bbox[4]or bottom;

do
align=align or"left";
local t={};
local l=left;
local r=right;
local sizes={};
for k,v in ipairs(list)do
if v:GetVisible()then
local a,b,w,h=v:GetAABB();
sizes[v]={w,h};
table.insert(t,v);
end
end
if#t>0 then
if string.find(align,"left")then
local x,y,b=left,top,top;
local xmax=x;
for i,v in ipairs(t)do
local _x=x;
v:SetPos(math.floor(x),math.floor(y));
xmax=math.max(xmax,x+sizes[v][1]);
x=x+margins[1]+sizes[v][1];
b=y+sizes[v][2];


local nextV=t[i+1];
if(_x>left and not nextV)or(nextV and x+sizes[nextV][1]>right)then
if string.find(align,"right")then
v:SetPos(math.floor(right-sizes[v][1]),math.floor(y));
end
x=left;
y=y+margins[2]+sizes[v][2];
end
end

if string.find(align,"bottom")then
local cy=bottom-b;
for i,v in ipairs(t)do
v:SetY(v:GetY()+cy);
end
elseif string.find(align,"vcenter")then
local cy=bottom-b;
for i,v in ipairs(t)do
v:SetY(v:GetY()+cy/2);
end
end

if string.find(align,"hcenter")then
trace("right",right);
trace("xmax",xmax);
local cx=(right-xmax);
for i,v in ipairs(t)do
v:SetX(v:GetX()+cx/2);
end
end
else

local x,y=left,top;
if string.find(align,"hcenter")then
local L=0;
for i,v in ipairs(t)do
if i>0 then
L=L+margins[1];
end
L=L+sizes[v][1];
end
x=(right+left-L)/2;
elseif string.find(align,"right")then
local L=0;
for i,v in ipairs(t)do
if i>0 then
L=L+margins[1];
end
L=L+sizes[v][1];
end
x=(right-L);
end

for i,v in ipairs(t)do
if string.find(align,"vcenter")then
y=(bottom+top-sizes[v][2])/2;
elseif string.find(align,"bottom")then
y=bottom-sizes[v][2];
end
v:SetPos(math.floor(x),math.floor(y));
x=x+margins[1]+sizes[v][1];
end
end
end
end
end