function OpponentArrow(arrow)
if arrow=="right"then
return"left";
else
return"right";
end
end

Character={
mcNickPath="",
mcShadowPath="",
mcNickOffset={0,-130},
floatY=0,
footY=15,
};

function Character:new(o)
o=o or{};
setmetatable(o,self);
self.__index=self;
return o
end

function Character:init(guid,x,y)
self.guid=guid;
self.tile={};
self.center={};
self.tile.x,self.tile.y=world.ground:MapToTile(x,y);
self.pos={x=x,y=y};
self.center.x,self.center.y=world.ground:TileToMap(self.tile.x,self.tile.y);
self.timer=Timer();
self.canvas=world.ground.layer:CreateEmptyMovieClip("");
self.ui=world.ground.ui:CreateEmptyMovieClip("");
if(self.mcShadowPath or"")~=""then
self.canvas:AddSymbol(self.mcShadowPath,"shadow");

end
if(self.mcNickPath or"")~=""then
self.mcNick=self.ui:AddSymbol(self.mcNickPath,"_");
assert(self.mcNick);
if self.mcNick then
self.mcNick:SetPos(self.mcNickOffset[1],self.mcNickOffset[2]);
end
end
end

function Character:showIconEffect(anim,skin)
local path=anim..skin;
if not self.ui.icon or(self.ui.icon and self.ui.icon.path~=path)then
self:hideIcon();
SpineObject(self.ui,"icon","ani_effect_01",anim,skin,nil,false);
self.ui.icon.path=path;
self.ui.icon:SetPos(self.mcNickOffset[1],self.mcNickOffset[2]);
end

end
function Character:showIcon(path)
if not self.ui.icon or(self.ui.icon and self.ui.icon.path~=path)then
trace("showIcon:"..path);
self:hideIcon();
self.ui:AddSymbol(path,"icon");
self.ui.icon.path=path;
self.ui.icon:SetPos(self.mcNickOffset[1],self.mcNickOffset[2]);
end
end

function Character:hideIcon()
if self.ui.icon then
self.ui.icon:Remove();
end
end
function Character:showDebug(txt,clr)
if ShowDebug then
self:showFloating(txt,clr or 0xFFFF00FF);
end
end

function Character:showFloating(txt,clr)
clr=clr or 0xffffffff;
local dur=_Z.FloatingT;

if self.floatings and self.floatingsT~=_S.T then
for k,v in ipairs(self.floatings)do
v:Remove();
end
self.floatings=nil;
end

self.floatings=self.floatings or{};
self.floatingsT=_S.T;
local f=function(o,v)
o:SetY(o.y+(v*-30));
local a=math.max(0,(v-0.75))*4;
o:SetAlphaDepth(1-a);
end


for k,v in ipairs(self.floatings)do
v.y=v.y-30;
end

local mc=self.canvas:AddSymbol("\236\186\144\235\166\173\237\132\176\237\148\140\235\161\156\237\140\133","_");
mc.txt:SetText(txt);
mc.txt:SetFillColor(clr);
mc.y=self.mcNickOffset[2]+(self.floatY or 0);
table.insert(self.floatings,mc);

local tweener=Tweener(mc,f,0,1,dur,0,outQuart);
tweener.onCompleted=function()
for k,v in ipairs(self.floatings)do
if v==mc then
mc:Remove();
table.remove(self.floatings,k);
break;
end
end
end
self.timer.addmc(mc,tweener.update);
tweener.update(0);
end

function Character:setNick(nick)
if nick and self.mcNick then
self.mcNick.nick:SetText(nick);
end
end

function Character:destroy()
if self.canvas then
self.canvas:Remove();
self.canvas=nil;
end
if self.ui then
self.ui:Remove();
self.ui=nil;
end
self.mc=nil;
self.mcNick=nil;

end
function Character:getZOrder()
return world.ground:MapToZOrder(self.pos.x,self.pos.y)+_Z.Object_FrontZ;
end

function Character:updateMC()
local z=self:getZOrder();
local x,y;
if self.pos.z then
x,y=world.ground:MapToScreen(self.pos.x,self.pos.y)
y=y-self.pos.z*_Z.TileRatio+self.footY;
else
x,y=world.ground:MapToScreenFoot(self.pos.x,self.pos.y)
y=y+self.footY;
end
if self.canvas then
self.canvas:SetPos(x,y);
self.canvas:SetZOrder(z);
end
if self.ui then
self.ui:SetPos(x,y);
self.ui:SetZOrder(z);
end

if self.mcNick then
self.mcNick:SetPos(self.mcNickOffset[1],self.mcNickOffset[2]);
end






end

function Character:setScale(s,ani,dur)
if ani then
local x0,y0=self.mc:GetScale();
local easing=linear;
local function f(obj,t)
obj.mc:SetScale(x0+(s-x0)*t,y0+(s-y0)*t);
end
local tweener=Tweener(self,f,0,1,dur,0,easing);
self.timer.add("scale",tweener.update);
else
self.mc:SetScale(s,s);
end
end


function Character:getPos()
return self.pos;
end

function Character:walk(dt)
end

function Character:setArrow(arrow)
self.arrow=arrow or"right";
end

function Character:getArrow()
return self.arrow;
end

function Character:update(dt)
self.timer.update(dt);
self:updateMC();
end


