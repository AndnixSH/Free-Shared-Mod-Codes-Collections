function ItemStorage(owner,object)
local storage=object.sdata.items;
local atypes=object.tb["\236\160\128\236\158\165\237\146\136"];
local prevScroll;
local mode;
for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
mode=v;
break;
end
end

AddObjectIcon(owner.icon,object.sdata.id);
owner.comment:SetText(_L(object.sdata.id.." \235\140\128\237\153\148"));

local function initSlots()
local images=const("\236\138\172\235\161\175\236\157\180\235\175\184\236\167\128");
for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
owner.myinven[v]:Clear();
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(owner.myinven[v],guid);
else
assert(images[v],v);
SetItemIconFromGuid(owner.myinven[v]);
owner.myinven[v].img:AddSymbol(images[v],"icon");
end
end
end
end

local function initBag()
trace("initbag");
do
for k,v in ipairs(GetAvailStorageSlots())do
if mode==v then
owner.myinven[v].img:SetAlphaDepth(1);
elseif _S["\236\138\172\235\161\175"][v]~=0 then
owner.myinven[v].img:SetAlphaDepth(0.3);
else
owner.myinven[v].img:SetAlphaDepth(1);
end
end
end

owner.myinven.list:Clear();
owner.listLeft:Clear();

local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
SetMyInventoryWnd(owner.myinven.list,o and o["\234\176\128\235\176\169"]);
SetMyInventoryWnd(owner.listLeft,storage);

if prevScroll then
owner.myinven.list.list.setScroll(prevScroll);
end
function owner.myinven.list.list:onScroll(s)
prevScroll=s;
end

local function setInfo(this,mc,guid)
if(guid or 0)~=0 then
assert(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid],guid);
SetItemIconFromGuid(mc,guid);
else
SetItemIconFromGuid(mc);
end
if mc.enabled then
mc.img:SetAlphaDepth(1);
else
mc.img:SetAlphaDepth(0.3);
end
if mc.selected then
mc:AddSymbol("\236\157\184\235\178\164\236\176\169\236\154\169\236\138\172\235\161\175\235\176\152\236\167\157","mark");
end
end

owner.myinven.list.list.onSelected=function(this,mc,guid)
if guid and guid~=0 and mc.enabled then
local function onOk()
owner:push(guid);
owner.myinven.list.list:refresh();
owner.listLeft.list:refresh();
end

ShowItemInfo(guid,onOk,_L("\235\132\163\234\184\176"),not mc.enabled);
return true;
end
end
local function findInBag(data)
local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o["\234\176\128\235\176\169"];
for i,v in pairs(d)do
if v~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
if o and IsItemEqual(data,o)then
return true;
end
end
end
end
local function findInStorage(data)
for i,v in pairs(storage)do
if v~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
if o and IsItemEqual(data,o)then
return true;
end
end
end
end

owner.myinven.list.list.setInfo=function(this,mc,guid)
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemType=itemtable[data.id]["\236\162\133\235\165\152"];
local group=itemtable[data.id]["\234\183\184\235\163\185"];
mc.enabled=not atypes or table.find(atypes,data.id)or table.find(atypes,itemType)or table.find(atypes,group);
mc.selected=findInStorage(data);


setInfo(this,mc,guid);
end
end

owner.listLeft.list.onSelected=function(this,mc,guid)
if guid and guid~=0 and mc.enabled then
local function onOk()
owner:pop(guid);
end
ShowItemInfo(guid,onOk,_L("\234\186\188\235\130\180\234\184\176"),not mc.enabled);
return true;
end
end


owner.listLeft.list.setInfo=function(this,mc,guid)
if guid~=0 then
local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];

local tp=itemtable[o.id].storage["\234\176\128\235\138\165"];
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
mc.enabled=not tp or IsStorageItemType(tp,data.id);
mc.selected=findInBag(data);

setInfo(this,mc,guid);
end
end

owner.myinven.list:init();
owner.listLeft:init();
end


local function changeMode(slot)
mode=slot;
prevScroll=nil;

initBag();
end


for k,v in pairs(GetAvailSlots())do
if owner.myinven[v]then
SetButton(owner.myinven[v],nil,nil,nil,0,0).onClick=function()
if IsStorageSlot(v)then
if _S["\236\138\172\235\161\175"][v]~=0 then
changeMode(v);
end
end
end
end
end

function owner:onEvent(msg)
local f=function()
if owner then owner:init();end
end
if string.find(msg,"Item")then
mainTimer.addmc(owner,f);
end
end

function owner:onUnload()
eventDispatcher:del(self,self.onEvent);
end

function owner:init()
initSlots();
initBag();
end

eventDispatcher:add(owner,owner.onEvent);
owner:init();

if owner.btnAlign then
owner.btnAlign:SetVisible(true);
SetButton(owner.btnAlign).onClick=function()
SortStorage(storage);
owner:init();
end
end


function owner:push(guid)
local function onOk(c)
local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local d=o["\234\176\128\235\176\169"];
for i,v in pairs(d)do
if v==guid then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemId=data.id;
if c==data.c then
if AddItemToBag(storage,guid)then
DelStorageItemBuff(mode,guid);
DelBagItemType(itemId,c);
AddBagItemType(itemId,c,"\236\131\129\236\158\144\236\158\144\236\155\144");
d[i]=0;
else
world.player:addChat(_L("\235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
local addC=(c or 1)-(data.c or 1);
DelBagItemType(itemId,addC);
AddBagItemType(itemId,addC,"\236\131\129\236\158\144\236\158\144\236\155\144");
end
else
local guid2=MakeGuid();
local data2=table.copy(data);
data.c=data.c-c;
data2.c=c;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2]=data2;
if AddItemToBag(storage,guid2)then
DelBagItemType(itemId,c);
AddBagItemType(itemId,c,"\236\131\129\236\158\144\236\158\144\236\155\144");
else
world.player:addChat(_L("\235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
local addC=c-_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2].c;
DelBagItemType(itemId,addC);
AddBagItemType(itemId,addC,"\236\131\129\236\158\144\236\158\144\236\155\144");
data.c=data.c+c-addC;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2]=nil;
_S["\234\179\160\236\156\160\235\178\136\237\152\184"]=_S["\234\179\160\236\156\160\235\178\136\237\152\184"]-1;
end
end
end
end

owner:init();
eventDispatcher:send("PickItem");
end
local function onCancel()
end
SelectItemCountPopup(onOk,onCancel,owner,guid);
end


function owner:pop(guid)
local function onOk(c)
local g=_S["\236\138\172\235\161\175"][mode];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];

for i,v in pairs(storage)do
if v==guid then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemId=data.id;
if c==data.c then
if AddItemToStorage(guid,nil,{mode})or AddItemToStorage(guid)then
storage[i]=0;
DelBagItemType(itemId,c,"\236\131\129\236\158\144\236\158\144\236\155\144");
else
world.player:addChat(_L("\235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
local addC=(c or 1)-(data.c or 1);
DelBagItemType(itemId,addC,"\236\131\129\236\158\144\236\158\144\236\155\144");
end
else
local guid2=MakeGuid();
local data2=table.copy(data);
data.c=data.c-c;
data2.c=c;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2]=data2;
if AddItemToStorage(guid2,nil,{mode})or AddItemToStorage(guid2)then
DelBagItemType(itemId,c,"\236\131\129\236\158\144\236\158\144\236\155\144");
else
world.player:addChat(_L("\235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
local addC=c-_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2].c;
DelBagItemType(itemId,addC,"\236\131\129\236\158\144\236\158\144\236\155\144");
data.c=data.c+c-addC;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2]=nil;
_S["\234\179\160\236\156\160\235\178\136\237\152\184"]=_S["\234\179\160\236\156\160\235\178\136\237\152\184"]-1;
end
end
end
end
owner:init();
eventDispatcher:send("PickItem");
end

local function onCancel()
end
SelectItemCountPopup(onOk,onCancel,owner,guid);
end
end

