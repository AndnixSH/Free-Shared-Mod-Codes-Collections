Portal=Object:new({
})

function Portal:getName()
return MapName(self.sdata.nextMap,true);
end


function Portal:isNickVisible()
return
not world.isTraveling and
world.ground:inLOS(self.tile.x,self.tile.y);
end

function Portal:travel()


world.gameEnded=true;
world.isTraveling=true;
local function f()
_G.nextMap=self.sdata.nextMap;
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
if self.sdata.nextMap then
local data=_S.maps[self.sdata.nextMap];
local type=data["\237\131\128\236\158\133"];
local area=data["\236\167\128\236\151\173"];
local field=data["\237\149\132\235\147\156"];
MapOpen(self.sdata.nextMap);
if type=="\237\149\132\235\147\156"and _S.maps[mapId]["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"then

root:GotoAndStop("worldmap");
else
root:GotoAndStop("travel");
end





end

end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

function Portal:complete()
end

function Portal:collision()
if self.sdata.id=="\236\157\180\236\160\132\237\149\132\235\147\156"or self.sdata.id=="\235\139\164\236\157\140\237\149\132\235\147\156"then
if world.player:canSleep()then
_S.x,_S.y=self.tile.x,self.tile.y;
self:travel();
end
end
end

function Portal:menuTouch(from,menu,onOk,onCancel)
if from:canSleep()then
self:travel();
else
world.player:addChat(_L("\236\158\160\236\158\144\234\184\176 \236\139\164\237\140\168"));
onCancel();
end
end
