
function SetHSlider(this,range,minV,maxV,tovalue)
local center=this.btn:GetX();
local left=center-range;
local right=center+range;
local click=nil;
local clickPos=0;
local totalOffset=0;
minV=minV or 0;
maxV=maxV or 100;
tovalue=tovalue or function(v)return v;end
local rangeV=maxV-minV;
local enable=true;
this:SetMouseCapture(true);

local onDraging=function(p)
local value=math.floor(minV+p*rangeV+0.5);
if this.btn.txt then
this.btn.txt:SetText(tovalue(value));
end
if this.gauge then
SetPercent2(this.gauge,p);
end
if this.onDraging then
this:onDraging(value);
end
end


this.onMouseDown=function(this,mx,my,id,capture)
if not click and enable then
local a,b,cx,cy=this.btn:GetBound();
local x,y=this.btn:GetPos();
if mx>=left+a and mx<right+(a+cx)and my>=y+b and my<y+b+cy then
if mx>=x+a and mx<x+a+cx then
else
this.btn:SetX(math.max(left,math.min(mx,right)));
end
click=id;
clickPos=mx;
totalOffset=0;
onDraging(this.getScroll());
return true;
end
end
end

this.onMouseMove=function(this,x,y,id)
if click==id and enable then
local offset=x-clickPos;
if this.btn:GetX()+offset<left then
offset=left-this.btn:GetX();
end
if this.btn:GetX()+offset>right then
offset=right-this.btn:GetX();
end
clickPos=clickPos+offset;
totalOffset=totalOffset+offset;
this.btn:SetX(this.btn:GetX()+offset);
onDraging(this.getScroll());
return true;
end
end
this.isDraging=function(this)
return click;
end

this.onMouseUp=function(this,x,y,id)
if click==id and enable then
click=nil;
if this.onEndDrag then
this:onEndDrag();
end
return true;
end
end

this.setScroll=function(v)
local pos=(v-minV)/rangeV;
this.btn:SetX(left+pos*range*2);
onDraging(this.getScroll());
end

this.getScroll=function()
return math.max(0,math.min(1,(this.btn:GetX()-left)/(range*2)));
end

this.enable=function(b)
enable=b;
end

this.setRange=function(minV,maxV)
minV=minV or 0;
maxV=maxV or 100;
rangeV=maxV-minV;
end
return this;

end


function SetHSliderButton(this,range)
local center=this:GetX();
local left=this:GetX()-range;
local right=this:GetX()+range;
local click=nil;
local clickPos=0;
local totalOffset=0;

this.onMouseDown=function(this,x,y,id,capture)
if not click then
click=id;
clickPos=x;
this:SetMouseCapture(true);
totalOffset=0;
if this.onScrollBegin then
this:onScrolBegin(x,y,id);
end
return true;
end
end

this.onMouseMove=function(this,x,y,id)
if click==id then
local offset=x-clickPos;
if this:GetX()+offset<left then
offset=left-this:GetX();
end
if this:GetX()+offset>right then
offset=right-this:GetX();
end
totalOffset=totalOffset+offset;
this:SetX(this:GetX()+offset);
if this.onDraging then
this:onDraging(this.getScroll());
end
return true;
end
end
this.isDraging=function(this)
return click;
end

this.onMouseUp=function(this,x,y,id)
if click==id then
click=nil;
this:SetMouseCapture(false);
return true;
end
end

this.setScroll=function(pos)
this:SetX(left+pos*range*2);
if this.onDraging then
this:onDraging(this.getScroll());
end
end

this.getScroll=function()
return math.max(0,math.min(1,(this:GetX()-left)/(range*2)));
end
return this;

end