Building=Object:new({
})

function Building:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
end
function Building:needComplete(menu,...)
Object.needComplete(self,menu,...);
if menu=="\235\169\148\235\137\180_\236\160\156\236\158\145"or menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\237\149\152\234\184\176"then
local guid=select(3,...);
local recipe=recipetable[guid];
assert(recipe,guid,self.sdata.id);
if recipe["\236\139\156\236\132\164 \236\138\172\235\161\175"]then
for k,v in safe_pairs(recipe["\236\139\156\236\132\164 \236\138\172\235\161\175"])do
self.sdata.attachments=self.sdata.attachments or{};
self.sdata.attachments[k]=v;
self.skeleton:setAttachment(k,v);
end
end
end
end

function Building:complete(menu,...)








if menu=="\235\169\148\235\137\180_\236\160\156\236\158\145"then
local guid=select(3,...);
if recipetable[guid]["\236\139\156\236\132\164 \236\138\172\235\161\175"]then
self.sdata.attachments=self.sdata.attachments or{};
for k,v in safe_pairs(recipetable[guid]["\236\139\156\236\132\164 \236\138\172\235\161\175"])do
self.sdata.attachments[k]=nil;
self.skeleton:setAttachment(k);
end
end
BuildArtifactOrNormalItem(self.pos,...);
world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(guid,cb,self.guid);
elseif menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\237\149\152\234\184\176"then
local x=select(1,...);
local y=select(2,...);
local guid=select(3,...);
local cnt=select(4,...);
local materials=select(5,...);
local recipe=recipetable[guid];
if recipe then
if recipe["\236\139\156\236\132\164 \236\138\172\235\161\175"]then
self.sdata.attachments=self.sdata.attachments or{};
for k,v in safe_pairs(recipe["\236\139\156\236\132\164 \236\138\172\235\161\175"])do
self.sdata.attachments[k]=nil;
self.skeleton:setAttachment(k);
end
end
for i=1,cnt do
local id=recipe["\236\158\165\235\185\132"];
local item=itemtable[id];
if recipe["\234\184\176\237\131\128\237\154\141\235\147\157"]then
id=math.randlist(recipe["\234\184\176\237\131\128\237\154\141\235\147\157"],100)or id;
end
local o,data=MakeAndPlaceItem(id,x,y);
if recipe["\236\131\157\236\130\176\234\176\156\236\136\152"]then
data.c=math.floor(bf((item["\236\162\133\235\165\152"]or"\234\184\176\237\131\128").." \236\131\157\236\130\176 \234\176\156\236\136\152",countkcc(recipe["\236\131\157\236\130\176\234\176\156\236\136\152"])));
end
o:fly(self.pos);
SetCookData(data,materials,cnt);
end

world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(guid,cb,self.guid);
end
elseif menu=="\235\169\148\235\137\180_\235\176\176\235\179\128"then
_S["\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184"]=_S["\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184"]-const("\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184\236\136\152\236\185\152")[1];
_S["\236\154\169\235\179\128T"]=_S.T;
local o,data=MakeAndPlaceItem("\235\185\132\235\163\140",_S.x,_S.y);
o:fly(self.pos);
world.player:spell("\235\176\176\235\179\128\237\149\152\234\184\176",nil,nil,nil,nil,nil,true);
elseif menu=="\235\169\148\235\137\180_\236\136\152\235\166\172"then
local nextId=table.unpack({...});
world:pauseTurn();
local function cb()
world:resumeTurn();
end
ShowAddedRecipes(nextId,cb,self.guid);
self:swap(nextId);
Mission("\236\136\152\235\166\172",1,nextId);
elseif menu=="\235\169\148\235\137\180_\236\132\156\237\140\144\236\182\169\236\160\132"then
local guid=select(1,...);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local tb=itemtable[o.id];
local function _ok()
world:resumeTurn();
end
world:pauseTurn();
RechargeItem(_ok,guid,const("\236\132\156\237\140\144\236\182\169\236\160\132\234\176\156\236\136\152"));
elseif menu=="\235\169\148\235\137\180_\235\172\188\235\156\168\234\184\176"then
local guid=select(1,...);
MakeWaterBottle(guid,self.sdata.id);
elseif menu=="\235\169\148\235\137\180_\235\172\180\234\184\176\236\136\152\235\166\172"or menu=="\235\169\148\235\137\180_\235\176\169\236\150\180\234\181\172\236\136\152\235\166\172"or menu=="\235\169\148\235\137\180_\236\149\133\236\132\184\236\132\156\235\166\172\236\136\152\235\166\172"or menu=="\235\169\148\235\137\180_\236\158\165\235\185\132\236\136\152\235\166\172"then
local guid=select(1,...);
local repair=select(2,...);
local function cb()
world:resumeTurn();
end
world:pauseTurn();
RepairItem(cb,guid,repair);
elseif menu=="\235\169\148\235\137\180_\236\163\188\235\172\184\236\132\156\235\179\181\236\130\172"then
local guid=select(1,...);
local id=select(2,...);
local c=countkcc(ev("\236\163\188\235\172\184\236\132\156\235\179\181\236\130\172\234\176\156\236\136\152"));
if math.randpercent(bf("\236\163\188\235\172\184\236\132\156 \236\182\148\234\176\128 \237\154\141\235\147\157")*100)then
c=c+1;
end
for i=1,c,1 do
local o,data=MakeAndPlaceItem(id,self.tile.x,self.tile.y);
data["\235\179\181\236\130\172"]=1;
end
elseif menu=="\235\169\148\235\137\180_\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152"then
local guid=select(1,...);
local guid2=select(2,...);
local o1=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2];
local o2=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
_G["\237\139\176\236\150\180\236\176\168"]=ItemTier(guid)-ItemTier(guid2);
_G["\234\176\149\237\153\148"]=(o2["\234\176\149\237\153\148"]or 0);
ConsumeItem(guid2);
local a,b=table.unpack(ev("\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152_\234\176\149\237\153\148"));

o2["\234\176\149\237\153\148"]=(o2["\234\176\149\237\153\148"]or 0)+countkcc((o1["\234\176\149\237\153\148"]or 0)*math.randrange(a,b));
_G["\237\139\176\236\150\180\236\176\168"]=nil;
_G["\234\176\149\237\153\148"]=nil;
if o1["\236\152\181\236\133\152"]then
for k,v in ipairs(o1["\236\152\181\236\133\152"])do
if not table.find(itemtable[o1.id]["\234\184\176\235\179\184 \236\152\181\236\133\152"],v.id)then
if math.randpercent(ev("\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152_\236\152\181\236\133\152"))then
local oppOption=const("\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152\235\176\176\237\131\128\236\152\181\236\133\152",v.id);
if oppOption then
if HasItemOption(guid,v.id)then
elseif HasItemOption(guid,oppOption)then
DelItemOption(nil,guid,oppOption);
if math.randpercent(ev("\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152\235\176\176\237\131\128\237\153\149\235\165\160"))then
AddItemOption(nil,guid,v.id);
end
else
AddItemOption(nil,guid,v.id);
end
else
AddItemOption(nil,guid,v.id);
end
end
end
end
end
elseif menu=="\235\169\148\235\137\180_\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168"then
local guid=select(1,...);
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local tier=ItemTier(guid);
if itemtable[o.id]["\237\139\176\236\150\180"]~=0 then

o["\237\139\176\236\150\180"]=math.min(math.max(tier,const("\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168\236\181\156\235\140\128\237\139\176\236\150\180")),tier+1);
end

_S["\236\160\156\235\160\168\237\154\159\236\136\152"][guid]=(_S["\236\160\156\235\160\168\237\154\159\236\136\152"][guid]or 0)+1;
if table.find(ev("\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168 \236\152\181\236\133\152 \236\182\148\234\176\128"),_S["\236\160\156\235\160\168\237\154\159\236\136\152"][guid])then
AddItemOption(nil,guid);
end

if table.find(ev("\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168 \234\176\149\237\153\148 \236\182\148\234\176\128"),_S["\236\160\156\235\160\168\237\154\159\236\136\152"][guid])then
o["\234\176\149\237\153\148"]=(o["\234\176\149\237\153\148"]or 0)+1;
end
elseif menu=="\235\169\148\235\137\180_\235\172\188\236\149\189\236\160\156\236\158\145"then
local guid=select(1,...);
local recipe=recipetable[guid];
local cnt=recipe["\236\131\157\236\130\176\234\176\156\236\136\152"]or 1;
if math.randpercent(bf("\235\172\188\236\149\189 \236\182\148\234\176\128 \237\154\141\235\147\157")*100)then
cnt=cnt+1;
end
for i=1,cnt,1 do
local id=recipe["\236\158\165\235\185\132"];
if recipe["\234\184\176\237\131\128\237\154\141\235\147\157"]then
id=math.randlist(recipe["\234\184\176\237\131\128\237\154\141\235\147\157"],100)or id;
end
local o,data=MakeAndPlaceItem(id,self.sdata.x,self.sdata.y);
SetItemIdIdentity(id);
end
elseif menu=="\235\169\148\235\137\180_\235\167\136\235\178\149\236\182\169\236\160\132"then
local guid=select(1,...);
local function _ok()
world:resumeTurn();
end
world:pauseTurn();
RechargeItem(_ok,guid,math.floor(ev("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\136\152")));
elseif menu=="\235\169\148\235\137\180_\236\149\132\236\157\180\237\133\156\234\176\144\236\160\149"then
local guid=select(1,...);
local function _ok()
world:resumeTurn();
end
world:pauseTurn();
SetItemIdentity(guid,_ok);
elseif menu=="\235\169\148\235\137\180_\235\167\136\235\178\149\236\149\148\234\184\176"then
local guid=select(1,...);
local guid2=select(2,...);
_S["\236\149\148\234\184\176\235\167\136\235\178\149"][guid]=guid2;
elseif menu=="\235\169\148\235\137\180_\236\160\128\236\163\188\237\149\180\236\160\156"then
local guid=select(1,...);
local function _ok()
world:resumeTurn();
end
world:pauseTurn();
DelItemOption(_ok,guid,"\236\160\128\236\163\188");
elseif menu=="\235\169\148\235\137\180_\237\153\152\236\131\157"then
self.sdata.state="\236\153\132\235\163\140";
world.player:reborn(self);
else
Object.complete(self,menu,...);
end
end

function Building:canTouch()
if self.tb["\235\169\148\235\137\180"]then
return Object.canTouch(self);
end
end

function Building:menuEnabled(menu)
return Object.menuEnabled(self,menu);
end

function Building:menuTouch(from,menu,onOk,onCancel)
if menu=="\235\169\148\235\137\180_\236\160\156\236\158\145"then
local name=self.sdata.id;
local function _ok(...)
trace("\236\160\156\236\158\145",...);
onOk(menu,_S.x,_S.y,...);
end
local tabs={self.sdata.id};
for k,v in safe_pairs(recipetable[self.sdata.id]["\236\139\156\236\132\164 \234\183\184\235\163\185"])do
table.insert(tabs,v);
end
SelectItemPopup(world,_ok,onCancel,tabs,"\236\160\156\236\158\145\235\178\149",{object=self,menu=menu,detail=_L("\236\160\156\236\158\145\235\178\149\236\132\160\237\131\157\236\132\164\235\170\133")});
elseif menu=="\235\169\148\235\137\180_\236\154\148\235\166\172\237\149\152\234\184\176"then
local name=self.sdata.id;
local function _ok(...)
onOk(menu,_S.x,_S.y,...);
end
local tabs={self.sdata.id};
for k,v in safe_pairs(recipetable[self.sdata.id]["\236\139\156\236\132\164 \234\183\184\235\163\185"])do
table.insert(tabs,v);
end
SelectItemPopup(world,_ok,onCancel,tabs,"\236\160\156\236\158\145\235\178\149",{object=self,menu=menu,detail=_L("\236\154\148\235\166\172\236\132\160\237\131\157\236\132\164\235\170\133")});
elseif menu=="\235\169\148\235\137\180_\235\176\176\235\179\128"then
if _S["\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184"]>=const("\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184\236\136\152\236\185\152")[1]and _S["\236\154\169\235\179\128T"]+const("\235\176\176\235\179\128\236\139\156\234\176\132")<=_S.T then
onOk(menu);
else
world.player:addChat(_L("\235\176\176\235\179\128\236\152\164\235\165\152"));
onCancel(menu);
end
elseif menu=="\235\169\148\235\137\180_\236\136\152\235\166\172"then
local name=self.sdata.id;
local nextId=self.tb["\237\140\140\235\157\188\235\175\184\237\132\176"];
if recipetable[nextId]then
local function ok(id,guids)
if ConsumeItemsFromGuid(guids)then
onOk(menu,nextId);
end
end
local function cancel()
onCancel(menu);
end
BuildItemPopup(world,ok,cancel,"\236\160\156\236\158\145\235\178\149",{nextId,recipetable[nextId]["\236\158\172\235\163\140"],{btnName="\236\136\152\235\166\172"}});
else
onOk(menu,nextId);
end
elseif menu=="\235\169\148\235\137\180_\236\176\168\236\155\144\236\157\180\235\143\153"then
_G.useMapItem=self.guid;
local mc=world:AddSymbol("\236\155\148\235\147\156\235\167\181\237\140\157\236\151\133");
SetButton(mc.btnClose).onClick=function()
_G.useMapItem=nil;
mc:Remove();
onCancel(menu);
end
SetWorldMap(mc.w);
elseif menu=="\235\169\148\235\137\180_\236\132\156\237\140\144\236\182\169\236\160\132"then
local function _onOk(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_onOk,onCancel,{"\236\176\168\236\155\144\236\157\152 \236\132\156\237\140\144"},"\236\182\169\236\160\132",{object=self,["\236\158\172\235\163\140"]=const("\236\176\168\236\155\144\236\157\152\236\132\156\237\140\144\236\182\169\236\160\132\236\158\172\235\163\140")});
elseif menu=="\235\169\148\235\137\180_\235\172\188\235\156\168\234\184\176"then
local function _ok2(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_ok2,onCancel,{"\234\184\176\237\131\128"},"\235\172\188\235\156\168\234\184\176",{object=self,hasProp={"\235\172\188\235\156\168\234\184\176"}});
elseif menu=="\235\169\148\235\137\180_\235\172\188\235\167\136\236\139\156\234\184\176"then
local idx=math.randlist(ev("\235\172\188\234\179\181\234\184\137\236\155\144",self.sdata.id));
local ids={"\235\172\188","\235\141\148\235\159\172\236\154\180 \235\172\188","\236\132\177\236\136\152"};
local spell=ids[idx].." \235\167\136\236\139\156\234\184\176";
local function onSpellEnd()
EatItem({id=ids[idx]});
onCancel();
end
from:spell(spell,onSpellEnd);
elseif menu=="\235\169\148\235\137\180_\235\172\180\234\184\176\236\136\152\235\166\172"then
local function _ok(guid)
SelectRepairPopup(guid,function(...)onOk(menu,...);end,onCancel);
end
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176"},"\236\136\152\235\166\172",{object=self});
elseif menu=="\235\169\148\235\137\180_\235\176\169\236\150\180\234\181\172\236\136\152\235\166\172"then
local function _ok(guid)
SelectRepairPopup(guid,function(...)onOk(menu,...);end,onCancel);
end
SelectItemPopup(world,_ok,onCancel,{"\235\176\169\236\150\180\234\181\172"},"\236\136\152\235\166\172",{object=self});
elseif menu=="\235\169\148\235\137\180_\236\149\133\236\132\184\236\132\156\235\166\172\236\136\152\235\166\172"then
local function _ok(guid)
SelectRepairPopup(guid,function(...)onOk(menu,...);end,onCancel);
end
SelectItemPopup(world,_ok,onCancel,{"\236\149\133\236\132\184\236\132\156\235\166\172"},"\236\136\152\235\166\172",{object=self});
elseif menu=="\235\169\148\235\137\180_\236\158\165\235\185\132\236\136\152\235\166\172"then
local function _ok(guid)
SelectRepairPopup(guid,function(...)onOk(menu,...);end,onCancel);
end
local maxTier=self.tb["\235\169\148\235\137\180\237\140\140\235\157\188\235\175\184\237\132\176"][menu];
SelectItemPopup(world,_ok,onCancel,{"\235\172\180\234\184\176","\235\176\169\236\150\180\234\181\172","\236\149\133\236\132\184\236\132\156\235\166\172"},"\236\136\152\235\166\172",
{object=self,maxTier=maxTier,detail2=string.format(_L("\236\181\156\235\140\128 \237\139\176\236\150\180fmt"),maxTier)}
);
elseif menu=="\235\169\148\235\137\180_\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152"then
do
local function _onOk(guid,guid2)
onOk(menu,guid,guid2);
end
local mc=showPopup(world,"\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
MoveAbilityPopup(mc,self,_onOk,onCancel);
end
elseif menu=="\235\169\148\235\137\180_\236\152\181\236\133\152\236\160\156\234\177\176"then
local function _ok1(guid)
local function _ok2(opid)
local function cb()
end
DelItemOption(cb,guid,opid);
onOk(menu);
end
local options=GetRemovableItemOptions(guid);
_G["\237\139\176\236\150\180"]=ItemTier(guid)or 0;
local materials=ev("\236\152\181\236\133\152\236\160\156\234\177\176\235\185\132\236\154\169");
_G["\237\139\176\236\150\180"]=nil;
SelectItemPopup(world,_ok2,onCancel,{"\234\184\176\237\131\128"},"\236\152\181\236\133\152",{object=self,guid=guid,keys=options,materials=materials,detail=_L("\236\160\156\234\177\176\236\152\181\236\133\152\236\132\160\237\131\157\236\132\164\235\170\133")});
end
SelectItemPopup(world,_ok1,onCancel,nil,"\236\152\181\236\133\152\236\160\156\234\177\176\235\170\169\235\161\157",{object=self});
elseif menu=="\235\169\148\235\137\180_\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\235\160\168"then
local function _ok(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_ok,onCancel,{"\236\149\132\237\139\176\237\140\169\237\138\184"},"\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\235\160\168",{object=self});
elseif menu=="\235\169\148\235\137\180_\235\167\136\235\178\149\236\182\169\236\160\132"then
local function _onOk(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_onOk,onCancel,{"\236\167\128\237\140\161\236\157\180"},"\236\182\169\236\160\132",{object=self,["\236\158\172\235\163\140"]=const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\158\172\235\163\140")});
elseif menu=="\235\169\148\235\137\180_\236\149\132\236\157\180\237\133\156\234\176\144\236\160\149"then
local function _ok(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\234\176\144\236\160\149",{object=self});
elseif menu=="\235\169\148\235\137\180_\235\167\136\235\178\149\236\149\148\234\184\176"then
do
local function _onOk(idx,guid)
onOk(menu,idx,guid);
end
local mc=showPopup(world,"\235\167\136\235\178\149\236\149\148\234\184\176\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
MemorizeBookPopup(mc,self,_onOk,onCancel);
end
elseif menu=="\235\169\148\235\137\180_\236\163\188\235\172\184\236\132\156\235\179\181\236\130\172"then
do
local function _onOk(guid,id)
onOk(menu,guid,id);
end
local mc=showPopup(world,"\236\163\188\235\172\184\236\132\156\235\179\181\236\130\172\237\140\157\236\151\133",{size={x=0,y=0,cx=APP_W,cy=APP_H}});
RewriterPopup(mc,self,_onOk,onCancel);
end
elseif menu=="\235\169\148\235\137\180_\235\172\188\236\149\189\236\160\156\236\158\145"then
local function _onOk(guid,recipe)
onOk(menu,guid);
end
SelectItemPopup(world,_onOk,onCancel,{self.sdata.id},"\236\160\156\236\158\145\235\178\149",{object=self});

elseif menu=="\235\169\148\235\137\180_\236\160\128\236\163\188\237\149\180\236\160\156"then
local function _onOk(guid)
onOk(menu,guid);
end
SelectItemPopup(world,_onOk,onCancel,{"\234\184\176\237\131\128"},"\236\160\128\236\163\188",{object=self});
elseif menu=="\235\169\148\235\137\180_\237\153\152\236\131\157"then
local wnd=showPopup(world,"\237\153\152\236\131\157\237\140\157\236\151\133");
local t={};
local list=ev("\237\153\152\236\131\157\235\179\180\236\131\129",self.sdata.id);
for k,v in pairs(list)do
table.insert(t,k);
end
table.sort(t,function(a,b)return(list[a]>list[b])end);
local rewards={};
for i=1,ev("\237\153\152\236\131\157\235\179\180\236\131\129\236\136\152",self.sdata.id)do
table.insert(rewards,t[1]);
end
for k,v in pairs(ev("\237\153\152\236\131\157\235\179\180\236\131\129\234\179\160\236\160\149",self.sdata.id))do
for i=1,v do
table.insert(rewards,k);
end
end
local width=150;
local max=#rewards;
for k,id in ipairs(rewards)do
local otb=objecttable[id]or objecttable["_"..id];
local canvas=wnd.w:CreateEmptyMovieClip("");
canvas:SetPos(-(max-1)*width/2+(k-1)*width,0);
SpineObject(canvas,"_",otb.spine,otb["\234\184\176\235\179\184 \236\149\160\235\139\136"],otb.skin,otb.attachment,true)
end
SetButton(wnd.btnCancel).onClick=function()
wnd:Remove();
onCancel(menu);
end
SetButton(wnd.btnOk).onClick=function()
wnd:Remove();
onOk(menu);
end
else
Object.menuTouch(self,from,menu,onOk,onCancel);
end
end
