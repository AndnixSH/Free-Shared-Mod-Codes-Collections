Altar=Object:new({

height=150,
})

function Altar:init(guid,sdata,...)
Object.init(self,guid,sdata,...);
if sdata.item then
if self.mcNick then
self.mcNick.nick:SetText(ItemName(sdata.item));
end

local newId=UnidentityItemIdFromGuid(self.sdata.item);
local item=itemtable[newId];
local isScroll=string.find(item.obj,"_scroll_");
local slot;
local attach=item.obj;
if isScroll then
slot="scroll";
else
slot="item";
end
self.skeleton:setChild("item",{
skeleton="media/spine/item.json",
atlas="media/spine/item.atlas",
attachmentSlot=slot,
attachment=attach,


y=-(self.tb["\235\134\146\236\157\180"]or 0),



loop=true,
}
);
end

end

function Altar:useKey()
if self.sdata.key then
if ConsumeItem(self.sdata.key,1)then
return true;
end
else
return true;
end
end

function Altar:complete()
if not self.sdata.item or PickItem(nil,self.sdata.item)then
self.skeleton:delChild("item");
self.sdata.item=nil;
Object.complete(self);
eventDispatcher:send("PickItem");
else
world.player:addChat(_L("\234\176\128\235\176\169\236\151\144 \235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
end
end

function Altar:menuTouch(from,menu,onOk,onCancel)
if self:useKey()then
onOk(menu);
else
from:addChat(_L("\236\151\180\236\135\160\234\176\128 \237\149\132\236\154\148\237\149\156\234\178\131 \234\176\153\235\139\164"));
from:playSndQueue("E_cant_unlock_1");
onCancel();
end
end
