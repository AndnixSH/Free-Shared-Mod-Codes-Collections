function ListBox(owner,viewSize,fontSize,lineHeight)
owner:SetClipRect(-APP_W,0,APP_W*2,viewSize.y);
local botY=0;

function owner:init()
if owner.list then
owner.list:Remove();
end
owner:CreateEmptyMovieClip("list");
SetVScrollView(owner.list);
owner.list.setScrollBarPos(viewSize.x);
owner.list.setViewLimit(viewSize.y);
owner.list:CreateEmptyMovieClip("container");
owner.list.container:SetInputEnable(false);
owner.list.container:SetSpriteMode(true);
botY=0;
end

local makeLine=function(str,clr)
local line=owner.list.container:AddLabel(viewSize.x,APP_H*10,"",tostring(str),fontSize,0,"_");
line:SetFillColor(clr or 0xFFFFFFFF);
return line;
end

function owner:AddBottom(str,clr)
local line=makeLine(str,clr);
line:SetY(botY);
local _,_,cx,cy=line:GetRendererRect();
botY=botY+cy;
owner.list.setContentSize(botY);
end

function owner:scrollToBottom(s)
if not owner.list.isDraging()then

owner.list.setScroll(viewSize.y-botY);
end
end
owner:init();
return owner;
end