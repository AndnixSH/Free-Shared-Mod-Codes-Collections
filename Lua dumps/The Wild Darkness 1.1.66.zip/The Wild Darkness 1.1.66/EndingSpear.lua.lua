EndingSpear=Object:new({
})

function EndingSpear:complete(id)
local function f()
world:gameEnding(_S["\236\151\148\235\148\169"]);
end
world:fadeMode(true,nil,f,0,1,2);
end

function EndingSpear:menuTouch(from,menu,onOk,onCancel)
if _S["\236\151\148\235\148\169"]==0 then
world.player:addChat(_L("\236\136\173\234\179\160\237\149\156 \234\184\176\236\154\180\236\157\180 \235\138\144\234\187\180\236\167\132\235\139\164."));
onCancel();
else
onOk(menu);
end
end
