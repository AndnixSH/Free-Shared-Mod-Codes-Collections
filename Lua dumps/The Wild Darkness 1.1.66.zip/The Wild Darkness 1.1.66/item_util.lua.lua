primarySkill={};

function ItemName(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=UnidentityItemIdFromGuid(guid);
local item=itemtable[id];
local s=item.name;

if data["\235\175\184\237\153\149\236\157\184"]then
if data["\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"]then
return s;
else
return string.format(_L("\235\175\184\237\153\149\236\157\184 \236\158\165\235\185\132 \236\157\180\235\166\132"),s);
end
elseif data.id~=id then
return s;
end

if data["\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"]then
local _,name=string.match(itemtable[id].name,"(.*) (.*)");
s=string.format(_L("\236\160\145\235\145\144_"..data["\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"]),name);
elseif data["\236\158\172\235\163\140"]and table.find(data["\236\158\172\235\163\140"],"\237\153\148\236\151\188\236\180\136")then
s=_L("\235\167\164\236\154\180")..s;
elseif data.alias then
s=string.format(_L(data.alias[1]),itemtable[data.alias[2]].name);
end

if HasItemOption(guid,"\236\182\149\235\179\181")then
s=string.format(_L("\236\160\145\235\145\144_\236\182\149\235\179\181\235\176\155\236\157\128"),s);
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
s=string.format(_L("\236\160\145\235\145\144_\236\160\128\236\163\188\235\176\155\236\157\128"),s);
end

if data["\235\179\181\236\130\172"]then
s=string.format(_L("\236\160\145\235\145\144_\235\179\181\236\130\172\235\144\156"),s);
end

if data["\234\176\128\235\176\169"]then
s=s..string.format(_L("\234\176\128\235\176\169\236\185\184"),#data["\234\176\128\235\176\169"]);
end

if not data["\235\175\184\237\153\149\236\157\184"]and(data["\234\176\149\237\153\148"]or 0)~=0 then
s=s.." "..tostringf(data["\234\176\149\237\153\148"],nil,"+")
end

s=ToDoorKeyName(s,data);
return s;
end
function ItemDetail(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=UnidentityItemIdFromGuid(guid);
local item=itemtable[id];
if item.detail then
local dict={};
if data.m then
dict["{\235\167\181\236\157\180\235\166\132}"]=MapName(data.m);
end
return ReplaceString(item.detail,dict);
end
end

function ToDoorKeyName(s,data)
if data and data.A then
local fmt=const("\236\151\180\236\135\160\236\157\180\235\166\132",data.id);
if fmt then
s=string.format(fmt,s,string.char(65+data.A%26));
end
end
return s;
end

function ItemTier(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=data.id;
return data["\237\139\176\236\150\180"]or itemtable[id]["\237\139\176\236\150\180"];
end


function ItemUpgrade(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
return data["\234\176\149\237\153\148"]or 0;
end


function BuildingRecipeOpenList(_recipetable,id)
local t={};
table.insert(t,id);

if _recipetable[id]then
for k,v in safe_ipairs(_recipetable[id]["\236\139\156\236\132\164 \234\183\184\235\163\185"])do
table.insert(t,v);
end
end
for _,group in ipairs(t)do
local tb=const("\235\182\132\235\165\152\235\179\132 \236\160\156\236\158\145\235\178\149 \236\152\164\237\148\136",group);
if tb then
return tb;
end
end
return const("\235\182\132\235\165\152\235\179\132 \236\160\156\236\158\145\235\178\149 \236\152\164\237\148\136","\234\184\176\237\131\128");
end

function ItemGroup(item)
local id=item.guid;
assert(item,id);
if drop1table[id]then
return id;
elseif drop2table[id]then
return drop2table[id]["\234\183\184\235\163\185"];
else
local ty=item["\236\162\133\235\165\152"];
if not ty then
return"\234\184\176\237\131\128";
end
if drop1table[ty]then
return ty;
elseif drop2table[ty]then
return drop2table[ty]["\234\183\184\235\163\185"];
end










assert(false,id,ty,"\234\183\184\235\163\185 \236\151\134\236\157\140");
end
end

function ItemValue(guid)
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
local item=itemtable[id];
local value;
if const("\236\158\165\235\185\132\235\170\169\235\161\157",item["\236\162\133\235\165\152"])=="\236\158\165\235\185\132"then
_G["\235\147\177\234\184\137 \235\179\180\235\132\136\236\138\164"]=ev("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \235\147\177\234\184\137 \235\179\180\235\132\136\236\138\164",_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]["\235\147\177\234\184\137"]or"\235\133\184\235\167\144");
_G["\237\139\176\236\150\180"]=ItemTier(guid);
_G["\234\181\144\237\153\152 \234\176\128\236\185\152"]=item["\234\181\144\237\153\152 \234\176\128\236\185\152"]or 0;
value=evItem("\236\158\165\235\185\132 \236\149\132\236\157\180\237\133\156 \234\181\144\237\153\152 \234\176\128\236\185\152",item)
_G["\235\147\177\234\184\137 \235\179\180\235\132\136\236\138\164"]=nil;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\181\144\237\153\152 \234\176\128\236\185\152"]=nil;
else
value=item["\234\181\144\237\153\152 \234\176\128\236\185\152"];
end
return value;
end
end

function ItemValue2(guid)
local item=itemtable[guid];
local recipe=recipetable[guid];
if guid=="\235\167\136\235\130\152 \237\139\176\235\129\140"or not recipe then
return item["\234\181\144\237\153\152 \234\176\128\236\185\152"]or 0;
else
local value=0;
for k,v in pairs(recipe["\236\158\172\235\163\140"])do
value=value+ItemValue2(k)*v;
end
return value;
end
end

function PrintItemValue(guid)
for i,v in ipairs(table.sortedkeys(itemtable))do
trace("\234\181\144\237\153\152 \234\176\128\236\185\152",v,ItemValue2(v));
end
end

function ItemPrice(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local id=o.id;
local item=itemtable[id];
local value;
if const("\236\158\165\235\185\132\235\170\169\235\161\157",item["\236\162\133\235\165\152"])=="\236\158\165\235\185\132"then
_G["\235\147\177\234\184\137 \235\179\180\235\132\136\236\138\164"]=ev("\236\158\165\235\185\132\235\172\180\234\184\176 \237\140\144\235\167\164\235\179\180\235\132\136\236\138\164",_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]["\235\147\177\234\184\137"]or"\235\133\184\235\167\144")or 0;
_G["\237\139\176\236\150\180"]=ItemTier(guid);
_G["\234\181\144\237\153\152 \234\176\128\236\185\152"]=item["\234\181\144\237\153\152 \234\176\128\236\185\152"]or 0;
value=ev("\236\158\165\235\185\132\235\172\180\234\184\176 \237\140\144\235\167\164\234\176\128\236\185\152",item["\236\162\133\235\165\152"])or ev("\236\158\165\235\185\132\235\172\180\234\184\176 \237\140\144\235\167\164\234\176\128\236\185\152",const("\235\182\132\235\165\152C",item["\236\162\133\235\165\152"]));
_G["\235\147\177\234\184\137 \235\179\180\235\132\136\236\138\164"]=nil;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\181\144\237\153\152 \234\176\128\236\185\152"]=nil;
else
value=item["\234\181\144\237\153\152 \234\176\128\236\185\152"];
end
return value;
end
end

function ToItemId(a)
if not itemtable[a]and const(a)then
a=const(a)[1];
end
return a;
end

function CmpItemPriority(a,b)
a,b=ToItemId(a),ToItemId(b);
local ia,ib=itemtable[a],itemtable[b];
assert(ia,a);
assert(ib,b);
return(ia.priority or 0)<(ib.priority or 0);
end

function GetRepairAmount(guid1,guid2)
local repair=0;
local o1=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid1];
local o2=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2];
if o1 and o2 then
local r1=o1["\235\130\180\234\181\172\235\143\132"];
local r2=o2["\235\130\180\234\181\172\235\143\132"];
local g1=o1["\235\147\177\234\184\137"];
local g2=o2["\235\147\177\234\184\137"];
local t1=itemtable[o1.id]["\236\162\133\235\165\152"];
local t2=itemtable[o2.id]["\236\162\133\235\165\152"];
local tier1=ItemTier(guid1)or 0;
local tier2=ItemTier(guid2)or 0;

_G["\236\158\172\235\163\140\235\130\180\234\181\172\235\143\132"]=r2;
_G["\237\139\176\236\150\180\236\176\168"]=math.abs(tier1-tier2);
_G.CRB=repairtable[t2][t1]/100;
if o1.id==o2.id then
_G.SRB=0.1;
else
_G.SRB=0;
end
_G.RRB=repairtable[g1][g2];
if tier1>=tier2 then
repair=ev("\235\130\180\234\181\172\235\143\132\237\154\140\235\179\1811");
else
repair=ev("\235\130\180\234\181\172\235\143\132\237\154\140\235\179\1812");
end
trace("CRB",_G.CRB);
trace("SRB",_G.SRB);
trace("RRB",_G.RRB);
_G["\236\158\172\235\163\140\235\130\180\234\181\172\235\143\132"]=nil;
_G["\237\139\176\236\150\180\236\176\168"]=nil;
_G.CRB=nil;
_G.SRB=nil;
_G.RRB=nil;
repair=math.floor(bf("\236\136\152\235\166\172\235\144\152\235\138\148 \236\150\145",repair));
end
return repair;
end


function MakeSubMaterialSlot(mc,cnt,list)
local maxW=math.min(6,cnt);
local w,h=85,105;
local left=-(maxW-1)*w/2;
local top=0;
local x,y=left,top;
for i=1,cnt,1 do
local mc=mc:AddSymbol("\236\160\156\236\158\145\236\158\172\235\163\1401\236\185\184","w"..i);
mc:SetPos(x,y);
x=x+w;
if i%maxW==0 then
local L=math.min(4,cnt-i)
left=-(L-1)*w/2;
x=left;
y=y+h+20;
end
end

if list then
for i,k in ipairs(table.sortedkeys(list,CmpItemPriority))do
local c=list[k];
local id=ToItemId(k);
if id then
local mc=mc["w"..i];
AddItemIcon(mc.img,id);
SetButton(mc).onClick=function()
ShowItemInfo(id);
end
mc.cnt:SetVisible(true);
local b,cur=HasItemType(id,c);
mc.cnt:SetText(cur.."/"..c);
if not b then
if HasItemTypeInBox(id,c)then
mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\131\129\236\158\144\234\176\128\235\138\165\236\131\137"));
else
mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\151\134\236\157\140\236\131\137"));
end
else
mc.cnt:SetFillColor(0xFFFFFFFF);
end
end
end
end
end


function AddItemIcon(mc,id,overlap)
if mc then
if not overlap then
mc:Clear();
end
if id then

local img;
if id=="dia"then
img=mc:AddSymbol("icon_stargem.png","icon");
else
img=mc:AddSymbol(itemtable[id].img,"icon");
end
local _,_,cx,cy=img:GetBound();
img:SetPos((120-cx)/2,(120-cy)/2);
return img;
end
end
end

function AddSkillIcon(mc,id,lv)
mc:Clear();
if id then
lv=lv or getSkillLevel(id);
if const("\236\136\153\235\160\168\235\143\132\236\136\152\236\185\152\235\178\132\237\138\188",id)then
if mc.img then
if mc.img.icon then mc.img.icon:Remove();end
mc.img:AddSymbol(const("\236\136\153\235\160\168\235\143\132\236\136\152\236\185\152\235\178\132\237\138\188",id),"icon");
end
elseif skilltable[id]then
if mc.img then
if mc.img.icon then mc.img.icon:Remove();end
mc.img:AddSymbol(string.format("skill/%s.png",skilltable[id].img),"icon");
end
end
if mc.lv then
mc.lv:SetText(string.format(_L("\235\160\136\235\178\168fmt"),lv));
mc.lv:SetVisible(true);
end
end
end
function AddSpellIcon(mc,id)
if id and spelltable[id]then
if mc.img then
if mc.img.icon then mc.img.icon:Remove();end
mc.img:AddSymbol(string.format("spell/%s.png",spelltable[id].img),"icon");
end
if mc.lv then
if(_S["\235\167\136\235\178\149"][id]or 0)>0 then
mc.lv:SetText(string.format(_L("\235\160\136\235\178\168fmt"),(_S["\235\167\136\235\178\149"][id]or 0)));
mc.lv:SetVisible(true);
end
end
if mc.name then
mc.name:SetText(spelltable[id].name);
end
return img;
end
end

function AddCoolBar(mc,cur,max,H,pos,step)
local W=80;
H=H or 75;
pos=pos or-W/2;
step=step or 360;
L=math.max(max,50);
if mc.cool then
mc.cool:Clear();
else
mc:CreateEmptyMovieClip("cool");
mc.cool:SetPos(pos,H);
end

mc.cool:AddSymbol("\235\136\136\234\184\136\235\176\148_back.png","back");
mc.cool:AddSymbol("\235\136\136\234\184\136\235\176\148.png","bar");
local _,_,a,b=mc.cool.bar:GetBound();
mc.cool.bar:SetClipRect(0,0,a*(cur/max),b);
mc.cool.bar:SetPos(2,2);

local x,y=0,0;
local w=W/(L/step);
local left=0;

x=w;
y=0;
for i=step,L-1,step do
local img=mc.cool:AddSymbol("\235\136\136\234\184\136.png","_");
img:SetPos(x,y);
x=x+w
end
end

function AddCoolIcon(mc,cur,max,H,pos,step,img,alwaysVisible,left,w,clr,name,W,wstep,wgap,extra,imgBack,clrExtra)
H=H or 95;
W=W or 100;
pos=pos or 0;
step=step or 10;
left=left or 10;
clr=clr or 0xFFFFFF;
name=name or"cool";
img=img or"icon_cooltime.png";
w=w or 10;
if mc[name]then
mc[name]:Clear();
end
if cur>0 or alwaysVisible then
local o=mc:CreateEmptyMovieClip(name);
o:SetPos(pos,H);
local x,y=0,0;
x=left;
y=-math.floor(max/100)*w;
for i=step,max,step do
local mc;
if imgBack then
if cur and cur+step<=i then
mc=o:AddSymbol(imgBack,"d"..i);
else
mc=o:AddSymbol(img,"d"..i);
end
else
mc=o:AddSymbol(img,"d"..i);
if cur and cur+step<=i then
mc:SetAlphaColor(0xFF000000);
else
mc:SetAlphaColor(bit.bor(0xFF000000,clr));
end
end
mc:SetPos(x,y);
if i==cur+1 and extra then
local mc=o:AddSymbol(img,"extra");
local _,_,cx,cy=mc:GetBound();
mc:SetPos(x,y);
mc:SetAlphaColor(bit.bor(0xFF000000,clrExtra or clr));
mc:SetClipRect(0,0,cx*extra,cy);
end
x=x+w;
if wstep and i%wstep==0 then
x=x+wgap;
end
if x>=W-left then
x=left;
y=y+w;
end
end
end
end

function AddItemIconFolder(mc,guids,cnt)
mc:Clear();
local w,h,scale,margin;
local W,H=120,120;
local sameId=true;

for i=2,#guids do
if UnidentityItemIdFromGuid(guids[i-1])~=UnidentityItemIdFromGuid(guids[i])then
sameId=false;
end
end
if sameId then
guids={guids[1]};
cnt=1;
end

if cnt==1 then
w=W;
h=H;
scale=1;
margin=0;
else
local sq=math.ceil(math.sqrt(cnt));
w=math.floor(W/sq);
h=math.floor(H/sq);
scale=1/sq*0.90;
margin=(w-W*scale)/2;
end


local x,y=0,0;
for i,guid in ipairs(guids)do
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o.id and itemtable[o.id]then
if x+w<=W and y+h<=H then
local id=UnidentityItemIdFromGuid(guid);
local img=mc:AddSymbol(itemtable[id].img,"_");
img:SetScale(scale,scale);
img:SetPos(x+margin,y+margin);
x=x+w;
if x+w>W then
x=0;
y=y+h;
end
end
end
end
end

function AddCookIcon(mc,id)
if mc then
mc:Clear();
if id and itemtable[id]then
local img;
if not _S["\236\154\148\235\166\172\237\154\159\236\136\152"][id]then
img=mc:AddSymbol("icon_\235\172\188\236\157\140\237\145\156.png","icon");
else
img=mc:AddSymbol(itemtable[id].img,"icon");
end
return img;
end
end
end

function AddCookIconFolder(mc,guids,cnt)
mc:Clear();
local w,h,scale,margin;
local W,H=120,120;
if cnt==1 then
w=W;
h=H;
scale=1;
margin=0;
else
local sq=math.ceil(math.sqrt(cnt));
w=math.floor(W/sq);
h=math.floor(H/sq);
scale=1/sq*0.90;
margin=(w-W*scale)/2;
end

local x,y=0,0;
for i,id in ipairs(guids)do
if itemtable[id]then
if x+w<=W and y+h<=H then
local img;
if not _S["\236\154\148\235\166\172\237\154\159\236\136\152"][id]then
img=mc:AddSymbol("icon_\235\172\188\236\157\140\237\145\156.png","_");
else
img=mc:AddSymbol(itemtable[id].img,"_");
end
img:SetScale(scale,scale);
img:SetPos(x+margin,y+margin);
x=x+w;
if x+w>W then
x=0;
y=y+h;
end
end
end
end
end
function AddObjectIcon(mc,id)
if mc.icon then
mc.icon:Remove();
end

if id and objecttable[id]then
mc:SetMsgFilter(MsgFilterLockBound);
local tb=objecttable[id];
local img=mc:AddSymbol(string.format("object/%s.png",tb.img),"icon");
if img then
local x,y=30,203;
img:SetPos(-x,-y);
end
mc:SetMsgFilter(0);
mc:SetBound(0,0,184,147);
return img;
end
end
function SetItemIconCnt(mc,cnt)
cnt=cnt or 1;
if type(cnt)=="table"then
mc:SetVisible(true);
mc:SetText(cnt[1].."~"..cnt[#cnt]);
else
mc:SetVisible(cnt>1);
if cnt>1 then
mc:SetText(cnt);
end
end
end

function AddMaterialIcon(mc,list,bbox,align)
align=align or"left,vcenter";
bbox=bbox or{10,0,72,128};
if mc.mat then
mc.mat:Remove();
end
if list then
mc:CreateEmptyMovieClip("mat");
mc.mat:SetPos(bbox[1],bbox[2]);
local W=(bbox[3]-bbox[1]);
local H=(bbox[4]-bbox[2]);
local w=W;
local h=25;
local left=0;
local top=0;
local L=table.length(list);
local N=math.ceil(L/(W/w));
if L<3 and string.find(align,"hcenter")then
left=(W-w*L)/2;
end
if string.find(align,"vcenter")then
top=(H-h*N)/2;
end

local x,y=left,top;
for _,k in ipairs(table.sortedkeys(list,CmpItemPriority))do
local v=list[k];
local id=ToItemId(k);
if id then
local _mc=mc.mat:AddSymbol("\236\149\132\236\157\180\237\133\156\234\176\156\236\136\152");
assert(itemtable[id]and itemtable[id].img,id);
_mc.img:AddSymbol(itemtable[id].img);
_mc.cnt:SetText(v);
local b=HasItemType(k,v);
if not b then
if HasItemTypeInBox(k,v)then
_mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\131\129\236\158\144\234\176\128\235\138\165\236\131\137"));
else
_mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\151\134\236\157\140\236\131\137"));
end
end
_mc:SetPos(math.floor(x),math.floor(y));
x=x+w;
L=L-1;
if x+w>(bbox[3]-bbox[1])then
left=0;
if L<3 and string.find(align,"hcenter")then
left=(W-w*L)/2;
end
x=left;
y=y+h;
end
end
end
end
end
function AddMaterialIconToBottom(mc,list,bbox,align)
align=align or"hcenter,vcenter";
bbox=bbox or{-2,150,194,225};
if mc.mat then
mc.mat:Remove();
end
if list then
mc:CreateEmptyMovieClip("mat");
mc.mat:SetPos(bbox[1],bbox[2]);
local W=(bbox[3]-bbox[1]);
local H=(bbox[4]-bbox[2]);
local w=W/3;
local h=30;
local left=0;
local top=0;
local L=table.length(list);
local N=math.ceil(L/3);
if L<3 and string.find(align,"hcenter")then
left=(W-w*L)/2;
end
if string.find(align,"vcenter")then
top=(H-h*N)/2;
end

local x,y=left,top;
for _,k in ipairs(table.sortedkeys(list,CmpItemPriority))do
local v=list[k];
local id=ToItemId(k);
if id then
local _mc=mc.mat:AddSymbol("\236\149\132\236\157\180\237\133\156\234\176\156\236\136\152");
assert(itemtable[id]and itemtable[id].img,id);
_mc.img:AddSymbol(itemtable[id].img);
_mc.cnt:SetText(v);
local b=HasItemType(k,v);
if not b then
if HasItemTypeInBox(k,v)then
_mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\131\129\236\158\144\234\176\128\235\138\165\236\131\137"));
else
_mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\151\134\236\157\140\236\131\137"));
end
end
_mc:SetPos(math.floor(x),math.floor(y));
x=x+w;
L=L-1;
if x+w>(bbox[3]-bbox[1])then
left=0;
if L<3 and string.find(align,"hcenter")then
left=(W-w*L)/2;
end
x=left;
y=y+h;
end
end
end
end
end



function AddMaterialIconLarge(mc,list,bbox,align)
align=align or"right,vcenter";
if not bbox then
bbox={mc:GetBound()};

bbox[1]=bbox[1]+18;
bbox[3]=bbox[3]-18;
end

if mc.mat then
mc.mat:Remove();
end
if list then
mc:CreateEmptyMovieClip("mat");

local mcs={};
for _,k in ipairs(table.sortedkeys(list,CmpItemPriority))do
local v=list[k];
if v>0 then
local id=ToItemId(k);
if id then
local _mc=mc.mat:AddSymbol("\236\149\132\236\157\180\237\133\156\234\176\156\236\136\152L");
assert(itemtable[id]and itemtable[id].img,id);
_mc.img:AddSymbol(itemtable[id].img);
_mc.cnt:SetVisible(true);
local b,cur=HasItemType(k,v);
_mc.cnt:SetText(cur.."/"..v);
if not b then
if HasItemTypeInBox(k,v)then
_mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\131\129\236\158\144\234\176\128\235\138\165\236\131\137"));
else
_mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\151\134\236\157\140\236\131\137"));
end
end
table.insert(mcs,_mc);
end
end
end
Align(mcs,"right,vcenter",{6,0},bbox);
end

end

function IsEquippedTotem(id,totems)
for k,v in safe_pairs(totems)do
for i,vv in pairs(v)do
if id==vv then
return true;
end
end
end
end
function UnEquipTotem(totems,id)
for k,v in safe_pairs(totems)do
for i,vv in pairs(v)do
if id==vv then
v[i]=0;
return true;
end
end
end
end

function GetMatchedTotem(tab,page)
local c=0;
for i,v in safe_pairs(_D["\237\134\160\237\133\156\236\138\172\235\161\175"][page or _D["\237\134\160\237\133\156\236\138\172\235\161\175\236\132\160\237\131\157"]][tab])do
local t=totemtable[v];
if t and t["\235\182\132\235\165\152"]==tab then
c=c+1;
end
end
return c;
end

function SetItemRare(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[o.id];
o["\235\147\177\234\184\137"]="\235\160\136\236\150\180";
if item["\236\162\133\235\165\152"]=="\236\167\128\237\140\161\236\157\180"and(o["\235\147\177\234\184\137"]=="\235\160\136\236\150\180"or o["\235\147\177\234\184\137"]=="\236\149\132\237\139\176\237\140\169\237\138\184")then
local list={};
for k,v in pairs(spelltable)do
if v["\237\131\128\236\158\133"]=="\235\167\136\235\178\149"and v["\235\139\168\234\179\132"]==1 then
table.insert(list,k);
end
end
o.T=0;
o["\235\167\136\235\178\149"]=table.choice(list);
o["\236\182\169\236\160\132"]={const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\181\156\235\140\128"),const("\236\167\128\237\140\161\236\157\180\235\167\136\235\178\149\236\182\169\236\160\132\236\181\156\235\140\128")};
end
updateSkill();
end

function SetTotemItem(mc,guid)
local t=totemtable[guid];
local w,h=120,120;
local grades=const("\235\147\177\234\184\137\236\157\180\235\175\184\236\167\128");
if t then
if mc.back then
if t["\235\147\177\234\184\137"]=="\235\160\136\236\150\180"then
mc.back:ChangeSymbol("slot_totem_rare.png");
elseif t["\235\147\177\234\184\137"]=="\236\151\144\237\148\189"then
mc.back:ChangeSymbol("slot_totem_epic.png");
elseif t["\235\147\177\234\184\137"]=="\235\160\136\236\160\132\235\147\156"then
mc.back:ChangeSymbol("slot_totem_legend.png");
end



end
if mc.img then
mc.img:Clear();
if grades[t["\235\147\177\234\184\137"]]then
mc.img:AddSymbol(grades[t["\235\147\177\234\184\137"]],"grade");
local _,_,a,b=mc.img.grade:GetBound();
mc.img.grade:SetPos((w-a)/2,(h-b)/2);
end
mc.img:AddSymbol(string.format("totem/img_%s.png",t.img),"icon");
mc.img:SetScale(1,1);
end
else
if mc.back then
mc.back:ChangeSymbol("inven_slot_01.png");
end
if mc.img then
mc.img:Clear();
mc.img:AddSymbol("icon_slot_totem.png","icon");
mc.img.icon:SetAlphaDepth(0.5);
end
end
end

function SetRecipeItem(mc,guid)
local t=recipetable[guid];
local w,h=120,120;
local grades=const("\235\147\177\234\184\137\236\157\180\235\175\184\236\167\128");
if t then
if mc.back then
local idx=table.find({"\235\133\184\235\167\144","\235\160\136\236\150\180","\236\151\144\237\148\189","\235\160\136\236\160\132\235\147\156"},t["\235\147\177\234\184\137"]);
mc.back:ChangeSymbol(string.format("img_recipe_0%d.png",idx));
end
if mc.img then
mc.img:Clear();
if grades[t["\235\147\177\234\184\137"]]then
mc.img:AddSymbol(grades[t["\235\147\177\234\184\137"]],"grade");
local _,_,a,b=mc.img.grade:GetBound();
mc.img.grade:SetPos((w-a)/2,(h-b)/2);
end
mc.img:AddSymbol(itemtable[guid].img,"icon");
mc.img:SetScale(0.7,0.7);

end
else
if mc.back then
mc.back:ChangeSymbol("inven_slot_01.png");
end
if mc.img then
mc.img:Clear();
mc.img:AddSymbol("icon_slot_recipe.png","icon");
mc.img.icon:SetAlphaDepth(0.5);
end
end
end

function SetTotemItemL(mc,guid)
local t=totemtable[guid];
local grades=const("\235\147\177\234\184\137\236\157\180\235\175\184\236\167\128");
if t then
if mc.back then
mc.back:SetVisible(false);
end
if mc.img then
mc.img:Clear();
if grades[t["\235\147\177\234\184\137"]]then
mc.img:AddSymbol(grades[t["\235\147\177\234\184\137"]],"grade");
mc.img.grade:SetScale(6,6);
local _,_,a,b=mc.img.grade:GetAABB();
mc.img.grade:SetPos(-a/2,-b/2);
end
mc.img:AddSymbol(string.format("totem/BIG_%s.png",t.img),"icon");
local a,b,c,d=mc.img.icon:GetBound();
mc.img.icon:SetPos(-c/2,-d/2);
mc.img:SetScale(1,1);
end
if mc.name then
mc.name:SetText(t.name);
end
end
end

function SetRecipeItemL(mc,guid)
local t=recipetable[guid];
local grades=const("\235\147\177\234\184\137\236\157\180\235\175\184\236\167\128");
if t then
if mc.back then
local idx=table.find({"\235\133\184\235\167\144","\235\160\136\236\150\180","\236\151\144\237\148\189","\235\160\136\236\160\132\235\147\156"},t["\235\147\177\234\184\137"]);
mc.back:ChangeSymbol(string.format("BIG_recipe_0%d.png",idx));
end
if mc.img then
if grades[t["\235\147\177\234\184\137"]]then
mc.img:AddSymbol(grades[t["\235\147\177\234\184\137"]],"grade");
mc.img.grade:SetScale(1.6,1.6);
local _,_,a,b=mc.img.grade:GetAABB();
mc.img.grade:SetPos(-a/2,-b/2);
end
mc.img:AddSymbol(itemtable[guid].img,"icon");
local a,b,c,d=mc.img.icon:GetBound();
mc.img.icon:SetPos(-c/2,-d/2);
mc.img:SetScale(2.5,2.5);
end
if mc.name then
mc.name:SetText(string.format(_L("\236\160\156\236\158\145\235\178\149 \236\157\180\235\166\132"),itemtable[guid].name));
end
end
end

function SetTotemOrRecipeItemL(mc,guid,txt)
if guid=="\237\153\169\234\184\136\236\151\180\236\135\160"or guid=="\235\167\136\235\178\149\236\151\180\236\135\160"or guid=="\235\182\128\237\153\156"or guid=="\235\179\180\236\132\157"then
if mc.back then
mc.back:SetVisible(false);
end
if mc.img then
mc.img:Clear();
mc.img:AddSymbol("\235\189\145\234\184\176_"..guid.."2","icon");
local a,b,c,d=mc.img.icon:GetBound();
mc.img.icon:SetPos(-c/2,-d/4);
mc.img.icon.txt:SetText(txt);
mc.img:SetScale(1,1);
end
if mc.name then
mc.name:SetText(_L(guid));
end
elseif totemtable[guid]then
SetTotemItemL(mc,guid);
elseif recipetable[guid]then
SetRecipeItemL(mc,guid);
end
end
function GetTotemOrRecipeGrade(guid)
local t=totemtable[guid]or recipetable[guid];
if t then
return t["\235\147\177\234\184\137"];
end
end

function SetItemIconGrade(back,id,rare)
if back then
if id and itemtable[id]["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
back:ChangeSymbol("inven_slot_03.png");
elseif rare then
back:ChangeSymbol("inven_slot_02.png");
else
back:ChangeSymbol("inven_slot_01.png");
end
end
end

function SetItemIconFromId(mc,id)
local item=itemtable[id];
if id then
if mc.back then
SetItemIconGrade(mc.back,id);
end
if mc.img then
AddItemIcon(mc.img,id);
end
else
if mc.back then
mc.back:ChangeSymbol("inven_slot_01.png");
end
if mc.img then
mc.img:SetAlphaColor(0xFFFFFFFF);
AddItemIcon(mc.img);
end
end
end

function GetRechargeDur(item)
local T;
if item["\236\182\169\236\160\132"]and item["\236\182\169\236\160\132"][2]then
T=item["\236\182\169\236\160\132"][2]
elseif item["\236\162\133\235\165\152"]=="\236\167\128\237\140\161\236\157\180"then
T=bf("\236\167\128\237\140\161\236\157\180\236\182\169\236\160\132\236\139\156\234\176\132");
end
return T;
end

function SetItemIconFromGuid(mc,guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local item=itemtable[o.id];
if mc.back then
if not o["\235\175\184\237\153\149\236\157\184"]then
SetItemIconGrade(mc.back,o.id,o["\235\147\177\234\184\137"]=="\235\160\136\236\150\180");
else
SetItemIconGrade(mc.back);
end
end

if mc.img then
AddItemIcon(mc.img,UnidentityItemIdFromGuid(guid));
if o["\235\130\180\234\181\172\235\143\132"]==0 then
mc.img:SetAlphaColor(const("\235\130\180\234\181\172\235\143\132\235\130\152\236\129\156\236\157\180\235\175\184\236\167\128\236\131\137"));
else
mc.img:SetAlphaColor(0xFFFFFFFF);
end

if o["\235\175\184\237\153\149\236\157\184"]then
mc.img:AddSymbol("icon_\235\172\188\236\157\140\237\145\156.png");
else
if o["\236\182\169\236\160\132"]then
local T=GetRechargeDur(item);
if T and o["\236\182\169\236\160\132"][1]<o["\236\182\169\236\160\132"][2]then
local extra=math.min(1,(o.T or 0)/T);
AddCoolIcon(mc.img,o["\236\182\169\236\160\132"][1],o["\236\182\169\236\160\132"][2],6,0,1,"info_charge.png",true,5,10,nil,nil,120,nil,nil,extra,nil,const("\236\182\169\236\160\132\236\164\145\236\131\137"));
else
AddCoolIcon(mc.img,o["\236\182\169\236\160\132"][1],o["\236\182\169\236\160\132"][2],6,0,1,"info_charge.png",true,5,10,nil,nil,120);
end
end
end
end

if mc.cnt then
SetItemIconCnt(mc.cnt,o.c);
end

if mc.dura then
if o["\235\130\180\234\181\172\235\143\132"]then
local p=o["\235\130\180\234\181\172\235\143\132"]/const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132")
local x,y,cx,cy=mc.dura:GetBound();
mc.dura:SetVisible(true);
mc.dura:SetClipRect(0,0,cx*p,cy);
elseif item["\235\179\180\234\180\128 \234\184\176\234\176\132"]and o.T then
local p=math.max(0,1-(o.T/item["\235\179\180\234\180\128 \234\184\176\234\176\132"]));
local x,y,cx,cy=mc.dura:GetBound();
if p<=1-const("\236\131\129\237\149\156\236\160\149\235\143\132\236\139\157\236\164\145\235\143\133\237\153\149\235\165\160")[1]/100 then
mc.dura:SetAlphaColor(const("\236\157\140\236\139\157\236\131\129\237\149\156\236\131\137"));
if p<=0 then
mc.img:SetAlphaColor(const("\236\157\140\236\139\157\235\179\180\234\180\128\235\129\157\236\131\137"));
end
else
mc.dura:SetAlphaColor(const("\236\157\140\236\139\157\236\131\137"));
end
mc.dura:SetVisible(true);
mc.dura:SetClipRect(0,0,cx*p,cy);
elseif item["\235\179\180\234\180\128 \236\152\168\235\143\132"]and item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\131\129\237\149\152\235\138\148 \236\139\156\234\176\132"]and o["\236\131\129\237\149\152\235\138\148T"]then
local T=item["\235\179\180\234\180\128 \236\152\168\235\143\132"]["\236\131\129\237\149\152\235\138\148 \236\139\156\234\176\132"];
local oT=o["\236\131\129\237\149\152\235\138\148T"];
local p=math.max(0,1-(oT/T));
local x,y,cx,cy=mc.dura:GetBound();
if p<=1-const("\236\131\129\237\149\156\236\160\149\235\143\132\236\139\157\236\164\145\235\143\133\237\153\149\235\165\160")[1]/100 then
mc.dura:SetAlphaColor(const("\236\157\140\236\139\157\236\131\129\237\149\156\236\131\137"));
if p<=0 then
mc.img:SetAlphaColor(const("\236\157\140\236\139\157\235\179\180\234\180\128\235\129\157\236\131\137"));
end
else
mc.dura:SetAlphaColor(const("\236\157\140\236\139\157\236\131\137"));
end
mc.dura:SetVisible(true);
mc.dura:SetClipRect(0,0,cx*p,cy);
elseif o["\236\154\169\235\159\137"]then
local p=o["\236\154\169\235\159\137"][1]/o["\236\154\169\235\159\137"][2];
local x,y,cx,cy=mc.dura:GetBound();
mc.dura:SetAlphaColor(0xff00005f);
mc.dura:SetVisible(true);
mc.dura:SetClipRect(0,0,cx*p,cy);
else
mc.dura:SetVisible(false);
end
end
else
if mc.back then
mc.back:ChangeSymbol("inven_slot_01.png");
end
if mc.img then
mc.img:SetAlphaColor(0xFFFFFFFF);
AddItemIcon(mc.img);
end
if mc.cnt then
SetItemIconCnt(mc.cnt);
end
if mc.dura then
mc.dura:SetVisible(false);
end
end
end

function GetCharAttack(chr)
local w1,wGuid1=chr:getSlotItem("\236\152\164\235\165\184\236\134\1441");
local dmg1a,dmg1b=GetItemDamage(w1,wGuid1);
return(dmg1a+dmg1b)/2;
end



function GetItemData(itemId,key,d)
local v=d or 0;
local a=0;
if itemId then
local item=itemtable[itemId];
if item then
if item[key]then
v=item[key];
end
local skill=const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",item["\236\162\133\235\165\152"]);
if skill then
a=a+(_S["\236\136\153\235\160\168\235\143\132"][skill][key]or 0)*(const("\235\172\180\234\184\176\235\179\132 \236\136\153\235\160\168\235\143\132 \236\136\152\236\185\152",skill)[key]or 0);
end
end
end
return v+a,v,a;
end


function addSkillLevel(id,add)
add=add or 1;
local t=const("\235\172\180\234\184\176\235\179\132 \236\136\153\235\160\168\235\143\132 \236\136\152\236\185\152",id);
assert(t,id);
local list={};
for k,v in pairs(t)do
local lv=(_S["\236\136\153\235\160\168\235\143\132"][id][k]or 0);
if lv<const("\236\181\156\235\140\128\236\136\153\235\160\168\235\143\132")then
table.insert(list,k);
end
end
local k=table.choice(list);
if k then
local v1=(_S["\236\136\153\235\160\168\235\143\132"][id][k]or 0);
_S["\236\136\153\235\160\168\235\143\132"][id][k]=v1+add;
local v2=_S["\236\136\153\235\160\168\235\143\132"][id][k];
if add>0 then
trace("addSkillLevel",id,k,v1,v2);
updateSkill();
end
return k,v1,v2;
end
end

function getSkillGroupLevel(id,t)
t=t or _S["\236\136\153\235\160\168\235\143\132"];
local lv=0;
for k,v in safe_pairs(t[id])do
lv=lv+v;
end
return lv;
end


function GetOpenSkill(group,fromLv,addLv)
addLv=addLv or 1;
fromLv=fromLv or getSkillGroupLevel(group);
local function matchLv(v)
if v["\236\136\153\235\160\168\235\143\132"]and const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",v["\235\172\180\234\184\176"])==group then
local lv=fromLv;
local maxLv=getMaxSkillLevel(v.guid);
for i=maxLv,1,-1 do
if v["\236\136\153\235\160\168\235\143\132"][i]>lv and v["\236\136\153\235\160\168\235\143\132"][i]<=lv+addLv then
return i;
end
end
end
end
local list={};
for k,v in pairs(skilltable)do
if not v.hidden then
local lv=matchLv(v);
if lv then
table.insert(list,{v,lv});
end
end
end
return list;
end

function getMaxSkillLevel(id)
local v=skilltable[id];
local job=jobtable[_S["\236\167\129\236\151\133"]];
if v["\235\172\180\234\184\176"]=="\236\140\141\234\178\128"then
local a=((job and job["\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132"]and job["\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132"]["\234\178\128\235\165\152"])or 0);
local b=((job and job["\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132"]and job["\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132"]["\235\145\148\234\184\176\235\165\152"])or 0);
return const("\236\181\156\235\140\128\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132")+math.max(a,b);
else
local group=const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",v["\235\172\180\234\184\176"]);
return const("\236\181\156\235\140\128\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132")+((group and job and job["\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132"]and job["\236\138\164\237\130\172\236\136\153\235\160\168\235\143\132"][group])or 0);
end
end


function getSkillLevel(id)
local v=skilltable[id];
local group=const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",v["\235\172\180\234\184\176"]);
local maxLv=getMaxSkillLevel(id);
if v["\236\136\153\235\160\168\235\143\132"]then
local lv=0;
if v["\235\172\180\234\184\176"]=="\236\140\141\234\178\128"then
local r1=GetSlotItem("\236\152\164\235\165\184\236\134\1441");
local l1=GetSlotItem("\236\153\188\236\134\1441");
if r1 and l1 then
local tr1=itemtable[r1]["\236\162\133\235\165\152"];
local tl1=itemtable[l1]["\236\162\133\235\165\152"];
assert(tr1,r1);
assert(tl1,l1);
local g1=const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",tr1);
local g2=const("\236\136\153\235\160\168\235\143\132\235\182\132\235\165\152",tl1);
if g1 and g2 then
lv=math.min(getSkillGroupLevel(g1),getSkillGroupLevel(g2));
end
end
else
if group then
lv=getSkillGroupLevel(group);
end
end

for i=maxLv,1,-1 do
if v["\236\136\153\235\160\168\235\143\132"][i]<=lv then
return i,v["\236\136\153\235\160\168\235\143\132"][i+1];
end
end
return 0,v["\236\136\153\235\160\168\235\143\132"][1];
else
return 1;
end
end


function updateSkill()
local w1;
local w2;
local r1,_,_,_,o1=GetSlotItem("\236\152\164\235\165\184\236\134\1441");
local l1=GetSlotItem("\236\153\188\236\134\1441");
local primary={};
if r1 then r1=itemtable[r1]["\236\162\133\235\165\152"];end
if l1 then l1=itemtable[l1]["\236\162\133\235\165\152"];end
for k,v in pairs(skilltable)do
if getSkillLevel(k)>0 then
local wtype=v["\235\172\180\234\184\176"];
if wtype=="\235\176\169\237\140\168"then
w1=l1;
else
w1=r1;
end
if wtype=="\236\140\141\234\178\128"then
if r1 and l1 and r1~="\235\176\169\237\140\168"and l1~="\235\176\169\237\140\168"then
table.insert(primary,v);
end
elseif k=="\235\139\168\234\178\128 \237\136\172\236\178\153"then
if table.find(wtype,r1)or table.find(wtype,l1)then
table.insert(primary,v);
end
else
if table.find(wtype,w1)then
if k=="\235\167\136\235\178\149 \236\130\172\236\154\169"then
if o1["\236\182\169\236\160\132"]and not o1["\235\175\184\237\153\149\236\157\184"]then
table.insert(primary,v);
end
else
table.insert(primary,v);
end
end
end
end
end

if DefaultSkills then
primary={};
for k,v in pairs(DefaultSkills)do
primary[k]=skilltable[v];
end
end
table.sort(primary,function(a,b)return(a["\236\154\176\236\132\160\236\136\156\236\156\132"])>b["\236\154\176\236\132\160\236\136\156\236\156\132"]end);
primarySkill=primary;


end

function GetItemArmorRaw(tb,tier)
_G["\237\139\176\236\150\180"]=tier or 0;
local d=ev("\235\176\169\236\150\180\235\160\165 \237\145\156\236\164\128\234\176\146");
local b=GetItemData(tb.guid,"\235\176\169\236\150\180\235\160\165 \235\176\176\236\156\168")*d;
_G["\237\139\176\236\150\180"]=nil;
return b;
end


function GetItemActivity(guid,statOnly)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=o.id;
local lv=o["\234\176\149\237\153\148"]or 0;
if HasItemOption(guid,"\236\182\149\235\179\181")then
lv=lv+1;
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
lv=lv-1;
end
local tb=itemtable[id];
if tb and tb["\237\153\156\235\143\153\236\132\177"]then
local tier=ItemTier(guid);
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
local u=ev("\237\153\156\235\143\153\236\132\177\234\176\149\237\153\148\236\136\152\236\185\152",tb["\236\162\133\235\165\152"])or ev("\237\153\156\235\143\153\236\132\177\234\176\149\237\153\148\236\136\152\236\185\152",const("\235\182\132\235\165\152C",tb["\236\162\133\235\165\152"]))or ev("\237\153\156\235\143\153\236\132\177\234\176\149\237\153\148\236\136\152\236\185\152","\234\184\176\237\131\128");
local b=u;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
if statOnly then
return b,b;
end
return bfItem(guid,"\237\153\156\235\143\153\236\132\177",b,true);
end
return 0,0;
end


function GetItemHit(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=o.id;
local lv=o["\234\176\149\237\153\148"]or 0;
if HasItemOption(guid,"\236\182\149\235\179\181")then
lv=lv+1;
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
lv=lv-1;
end
local tb=itemtable[id];
if tb and tb["\236\160\129\236\164\145"]then
local tier=ItemTier(guid);
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
local u=ev("\236\160\129\236\164\145\234\176\149\237\153\148\236\136\152\236\185\152",tb["\236\162\133\235\165\152"])or ev("\236\160\129\236\164\145\234\176\149\237\153\148\236\136\152\236\185\152",const("\235\182\132\235\165\152C",tb["\236\162\133\235\165\152"]))or ev("\236\160\129\236\164\145\234\176\149\237\153\148\236\136\152\236\185\152","\234\184\176\237\131\128");
local b=u;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
return bfItem(guid,"\236\160\129\236\164\145",b,true);
end
return 0,0;
end


function GetItemArmor(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=o.id;
local lv=o["\234\176\149\237\153\148"]or 0;
if HasItemOption(guid,"\236\182\149\235\179\181")then
lv=lv+1;
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
lv=lv-1;
end
local tb=itemtable[id];
if tb and tb["\235\176\169\236\150\180\235\160\165 \235\176\176\236\156\168"]then
local tier=ItemTier(guid);
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
local u=ev("\235\176\169\236\150\180\234\181\172\234\176\149\237\153\148\236\136\152\236\185\152",tb["\236\162\133\235\165\152"])or ev("\235\176\169\236\150\180\234\181\172\234\176\149\237\153\148\236\136\152\236\185\152",const("\235\182\132\235\165\152C",tb["\236\162\133\235\165\152"]))or ev("\235\176\169\236\150\180\234\181\172\234\176\149\237\153\148\236\136\152\236\185\152","\234\184\176\237\131\128");
local d=ev("\235\176\169\236\150\180\235\160\165 \237\145\156\236\164\128\234\176\146")+u;
local b=GetItemData(id,"\235\176\169\236\150\180\235\160\165 \235\176\176\236\156\168")*d;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
return bfItem(guid,"\235\176\169\236\150\180\235\160\165",b,true);
end
return 0,0;
end

function GetItemMaxLife(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=o.id;
local lv=o["\234\176\149\237\153\148"]or 0;
if HasItemOption(guid,"\236\182\149\235\179\181")then
lv=lv+1;
elseif HasItemOption(guid,"\236\160\128\236\163\188")then
lv=lv-1;
end
local tb=itemtable[id];
if tb and tb["\236\131\157\235\170\133\235\160\165 \235\176\176\236\156\168"]then
local tier=ItemTier(guid);
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
local u=ev("\236\131\157\235\170\133\235\160\165\235\176\176\236\156\168\234\176\149\237\153\148\236\136\152\236\185\152",tb["\236\162\133\235\165\152"])or ev("\236\131\157\235\170\133\235\160\165\235\176\176\236\156\168\234\176\149\237\153\148\236\136\152\236\185\152",const("\235\182\132\235\165\152C",tb["\236\162\133\235\165\152"]))or ev("\236\131\157\235\170\133\235\160\165\235\176\176\236\156\168\234\176\149\237\153\148\236\136\152\236\185\152","\234\184\176\237\131\128");
local b=u;
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
return bfItem(guid,"\236\131\157\235\170\133\235\160\165 \235\176\176\236\156\168",b,false);
end
return 0,0;
end

function GetEquipItemProp(fProp,types,noTypes)
local v,a=0,0;
for k,slot in pairs(GetAvailSlots())do
if not IsSubSlot(slot)then
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o and(o["\235\130\180\234\181\172\235\143\132"]or 1)>0 then
local tb=itemtable[o.id];
if(not types or table.find(types,tb["\236\162\133\235\165\152"]))and(not noTypes or not table.find(noTypes,tb["\236\162\133\235\165\152"]))then
local _,_v,_a=fProp(guid);
v=v+(_v or 0);
a=a+(_a or 0);
end
end
end
end
end
return v+a,v,a;
end


function GetItemDamageRaw(tb,tier)
_G["\237\139\176\236\150\180"]=tier or 0;
local d=ev("\235\172\188\235\166\172 \235\141\176\235\175\184\236\167\128 \237\145\156\236\164\128\234\176\146");
local a=(tb["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]or 0)*d;
local b=(tb["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]or 0)*d;
_G["\237\139\176\236\150\180"]=nil;
return a,b;
end

function GetItemReqStr(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local reqStr=0;
local id=o.id;
local lv=o["\234\176\149\237\153\148"]or 0;
if FindItemOption(o,"\236\182\149\235\179\181")then
lv=lv+1;
elseif FindItemOption(o,"\236\160\128\236\163\188")then
lv=lv-1;
end

local tb=itemtable[id];
if tb then
local tier=ItemTier(guid);
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
reqStr=(ev("\235\172\180\234\184\176\235\179\132\236\154\148\234\181\172\237\158\152")[tb["\236\162\133\235\165\152"]]or ev("\235\176\169\236\150\180\234\181\172\235\179\132\236\154\148\234\181\172\237\158\152")[tb["\236\162\133\235\165\152"]]);
_G["\234\176\149\237\153\148"]=nil;
_G["\237\139\176\236\150\180"]=nil;
if reqStr then
reqStr=reqStr+bf("\235\172\180\234\184\176\236\154\148\234\181\172\237\158\152");
reqStr=reqStr+GetItemOptionBuff(o,"\236\149\132\236\157\180\237\133\156 \236\154\148\234\181\172 \237\158\152");
return reqStr;
end
end
end
end

function GetStrDexBonus(from,w)
local bonus=0;
if w then
for k,v in pairs(from:ev("\237\158\152\235\175\188\236\178\169 \235\179\180\235\132\136\236\138\164\236\139\157"))do
if const("\235\182\132\235\165\152C",itemtable[w]["\236\162\133\235\165\152"])==k then
bonus=v;
end
end
for k,v in pairs(from:ev("\237\158\152\235\175\188\236\178\169 \235\179\180\235\132\136\236\138\164\236\139\157"))do
if itemtable[w]["\236\162\133\235\165\152"]==k then
bonus=v;
end
end
else
bonus=from:ev("\237\158\152\235\175\188\236\178\169 \235\179\180\235\132\136\236\138\164\236\139\157")["\237\149\156\236\134\144"];
end
return bonus;
end
function GetItemDamage(guid,srcOnly,statOnly)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local id=o.id;
local lv=o["\234\176\149\237\153\148"]or 0;
if o["\236\152\181\236\133\152"]then
if FindItemOption(o,"\236\182\149\235\179\181")then
lv=lv+1;
elseif FindItemOption(o,"\236\160\128\236\163\188")then
lv=lv-1;
end
end
local tb=itemtable[id];
if tb then
local tier=ItemTier(guid);
_G["\236\154\148\234\181\172\237\158\152"]=GetItemReqStr(guid);
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
local u=ev("\235\172\180\234\184\176\234\176\149\237\153\148\236\136\152\236\185\152",tb["\236\162\133\235\165\152"])or ev("\235\172\180\234\184\176\234\176\149\237\153\148\236\136\152\236\185\152",const("\235\182\132\235\165\152C",tb["\236\162\133\235\165\152"]))or ev("\235\172\180\234\184\176\234\176\149\237\153\148\236\136\152\236\185\152","\234\184\176\237\131\128");
local d=ev("\235\172\188\235\166\172 \235\141\176\235\175\184\236\167\128 \237\145\156\236\164\128\234\176\146")+u;
local a=(tb["\236\181\156\236\134\140 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]or 0)*d;
local b=(tb["\236\181\156\235\140\128 \235\141\176\235\175\184\236\167\128 \235\176\176\236\156\168"]or 0)*d;

if not statOnly then
b=b*ev("\236\181\156\235\140\128\235\141\176\235\175\184\236\167\128\237\142\152\235\132\144\237\139\176");
end
local m=1;
if not statOnly then
m=m+GetItemData(id,"\234\179\181\234\178\169\235\160\165 \236\166\157\234\176\128");
end
if not srcOnly then
local _m,v=bfItem(guid,"\234\179\181\234\178\169\235\160\165",m);
if statOnly then
m=v;
else
m=_m;
end
end
a=a*m;
b=b*m;
_G["\236\154\148\234\181\172\237\158\152"]=nil;
_G["\234\176\149\237\153\148"]=nil;
_G["\237\139\176\236\150\180"]=nil;
a,b=math.max(0,a),math.max(0,b);
a=math.min(a,b);
return a,b;
end
end
return 0,0;
end


function GetItemMagicDamage(guid,srcOnly)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id;
if not o then
id="\234\184\176\235\179\184 \236\163\188\235\168\185";
else
id=o.id;
end

if id then
local lv;
local tier;
if o then
lv=o["\234\176\149\237\153\148"]or 0;
if o["\236\152\181\236\133\152"]then
if FindItemOption(o,"\236\182\149\235\179\181")then
lv=lv+1;
elseif FindItemOption(o,"\236\160\128\236\163\188")then
lv=lv-1;
end
end
tier=ItemTier(guid);
end
local tb=itemtable[id];
if tb then
lv=lv or 0;
_G["\237\139\176\236\150\180"]=tier or 0;
_G["\234\176\149\237\153\148"]=lv;
local u=ev("\235\172\180\234\184\176\234\176\149\237\153\148\236\136\152\236\185\152",tb["\236\162\133\235\165\152"])or ev("\235\172\180\234\184\176\234\176\149\237\153\148\236\136\152\236\185\152",const("\235\182\132\235\165\152C",tb["\236\162\133\235\165\152"]))or ev("\235\172\180\234\184\176\234\176\149\237\153\148\236\136\152\236\185\152","\234\184\176\237\131\128");
local d=ev("\235\167\136\235\178\149 \235\141\176\235\175\184\236\167\128 \237\145\156\236\164\128\234\176\146")+u;
local a=ev("\235\167\136\235\178\149 \235\141\176\235\175\184\236\167\128 \235\178\148\236\156\132",1)*d;
local b=ev("\235\167\136\235\178\149 \235\141\176\235\175\184\236\167\128 \235\178\148\236\156\132",2)*d;
if not srcOnly then
a=bf("\235\167\136\235\178\149 \234\179\181\234\178\169\235\160\165",a);
b=bf("\235\167\136\235\178\149 \234\179\181\234\178\169\235\160\165",b);
end
_G["\234\176\149\237\153\148"]=nil;
_G["\237\139\176\236\150\180"]=nil;
return a,b;
end
end
return 0,0;
end

function GetSlotItem(slot)
local guid=_S["\236\138\172\235\161\175"][slot];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o and(o["\235\130\180\234\181\172\235\143\132"]or 1)>0 then
local tb=itemtable[o.id];
if tb then
local tier=ItemTier(guid);
return o.id,o["\234\176\149\237\153\148"]or 0,tier,guid,o;
end
end
end

function HasDurability(id)
local group=itemtable[id]["\234\183\184\235\163\185"];
if group then
local drop=drop1table[group];
return(drop and drop["\236\158\165\235\185\132 \236\134\141\236\132\177 \236\151\172\235\182\128"]);
end
end


function GetMoveAbilityMaterials(guid,guid2)
local list={};
local _G=GTable();
_G["\237\139\176\236\150\180A"]=ItemTier(guid)or 0;
_G["\234\176\149\237\153\148A"]=ItemUpgrade(guid)or 0;
_G["\237\139\176\236\150\180B"]=ItemTier(guid2)or 0;
_G["\234\176\149\237\153\148B"]=ItemUpgrade(guid2)or 0;
for k,v in pairs(ev("\235\138\165\235\160\165\236\185\152\237\157\161\236\136\152_\236\158\172\235\163\140"))do
list[k]=math.ceil(v);
end
_G:clean();
return list;
end


function IsVisibleRecipe(id)
if _S["\235\160\136\236\132\156\237\148\188"][id]then
return true;
end








end

function GetRequireHouse(v)
if table.find(const("\236\152\164\235\184\140\236\160\157\237\138\184\236\132\164\236\185\152\236\156\160\237\152\149"),v["\236\156\160\237\152\149"])then
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
local houseObjId=m["\236\176\189\234\179\160"];
local match=table.find(v["\236\156\160\237\152\149"],m["\237\131\128\236\158\133"]);
if houseObjId then
match=table.find(v["\236\156\160\237\152\149"],objecttable[houseObjId]["\237\131\128\236\158\133"])
or table.find(v["\236\156\160\237\152\149"],"\236\139\164\235\130\180")
or table.find(v["\236\156\160\237\152\149"],"\236\139\164\235\130\180\236\153\184");
else
match=match or table.find(v["\236\156\160\237\152\149"],"\236\139\164\236\153\184")
or table.find(v["\236\156\160\237\152\149"],"\236\139\164\235\130\180\236\153\184");
end
if not match then
return false,v["\236\156\160\237\152\149"];
end
end
return true;
end


function FindItemTypeKey(t,id)
local item=itemtable[id];
local types={item["\236\162\133\235\165\152"],const("\235\182\132\235\165\152C",item["\236\162\133\235\165\152"]),const("\235\182\132\235\165\152A",item["\236\162\133\235\165\152"])};
for _,type in ipairs(types)do
for k,v in pairs(t)do
local keys=string.split(k,",");
if table.find(keys,type)then
return v;
end
end
end
end


function GetRequireBuildingList(guid,repair,tier,needList)

local v=recipetable[guid];
assert(v,guid);
if needList then
local list={};
if not _S["\235\160\136\236\132\156\237\148\188"][guid]then
local id=v["\237\154\141\235\147\157 \236\139\156\236\132\164"];
if id then
if objecttable[id]then
table.insert(list,{id,(_S["\236\132\164\236\185\152"][id]or 0)>0});
elseif itemtable[id]then
table.insert(list,{id,HasItemType(id)});
end
end
end
if v["\234\184\176\235\176\152 \236\139\156\236\132\164"]then
for k,id in safe_pairs(v["\234\184\176\235\176\152 \236\139\156\236\132\164"])do
if objecttable[id]then
table.insert(list,{id,(_S["\236\132\164\236\185\152"][id]or 0)>0});
elseif itemtable[id]then
table.insert(list,{id,HasItemType(id)});
end
end
end

if v["\236\162\133\235\165\152"]and v["\236\156\160\237\152\149"]then
local typeA=const("\235\182\132\235\165\152A",v["\236\162\133\235\165\152"]);
if typeA and type(v["\236\156\160\237\152\149"])=="string"then
local t=const("\236\156\160\237\152\149\235\179\132 \236\160\156\236\158\145 \236\139\156\236\132\164",typeA.." "..v["\236\156\160\237\152\149"])or const("\236\156\160\237\152\149\235\179\132 \236\160\156\236\158\145 \236\139\156\236\132\164",v["\236\156\160\237\152\149"]);
if t then
for id,v in pairs(t)do
if repair and v=="\236\134\140\235\185\132"then
else
table.insert(list,{id,(_S["\236\132\164\236\185\152"][id]or 0)>0});
end
end
end
end
end


if tier then
local id=v["\236\158\165\235\185\132"];
if itemtable[id]then
if objecttable[v["\236\160\156\236\158\145 \236\139\156\236\132\164"]]then
table.insert(list,{objecttable[v["\236\160\156\236\158\145 \236\139\156\236\132\164"]].guid,(_S["\236\132\164\236\185\152"][v["\236\160\156\236\158\145 \236\139\156\236\132\164"]]or 0)>0});
end
local v=FindItemTypeKey(const("\236\149\132\237\139\176\237\140\169\237\138\184\237\139\176\236\150\180\236\152\164\235\184\140\236\160\157\237\138\184"),id);
if v then
for i=1,math.floor(tier),1 do
local id=v[i];
if id and objecttable[id]then
table.insert(list,{id,(_S["\236\132\164\236\185\152"][id]or 0)>0});
end
end
end
end
end
local b=true;
for k,v in pairs(list)do
if not v[2]then
b=false;
break;
end
end
return b,list;
else
if v["\237\154\141\235\147\157 \236\139\156\236\132\164"]then
if not _S["\235\160\136\236\132\156\237\148\188"][guid]then
return false;
end
end
if v["\234\184\176\235\176\152 \236\139\156\236\132\164"]then
for k,id in safe_pairs(v["\234\184\176\235\176\152 \236\139\156\236\132\164"])do
if objecttable[id]then
if(_S["\236\132\164\236\185\152"][id]or 0)==0 then
return false;
end
elseif itemtable[id]then
if not HasItemType(id)then
return false;
end
end
end
end

if v["\236\162\133\235\165\152"]and v["\236\156\160\237\152\149"]then
local typeA=const("\235\182\132\235\165\152A",v["\236\162\133\235\165\152"]);
if typeA and type(v["\236\156\160\237\152\149"])=="string"then
local t=const("\236\156\160\237\152\149\235\179\132 \236\160\156\236\158\145 \236\139\156\236\132\164",typeA.." "..v["\236\156\160\237\152\149"])or const("\236\156\160\237\152\149\235\179\132 \236\160\156\236\158\145 \236\139\156\236\132\164",v["\236\156\160\237\152\149"]);
if t then
for id,v in pairs(t)do
if repair and v=="\236\134\140\235\185\132"then
else
if(_S["\236\132\164\236\185\152"][id]or 0)==0 then
return false;
end
end
end
end
end
end


if tier then
local id=v["\236\158\165\235\185\132"];
if itemtable[id]then
if objecttable[v["\236\160\156\236\158\145 \236\139\156\236\132\164"]]then
if(_S["\236\132\164\236\185\152"][v["\236\160\156\236\158\145 \236\139\156\236\132\164"]]or 0)==0 then
return false;
end
end
local v=FindItemTypeKey(const("\236\149\132\237\139\176\237\140\169\237\138\184\237\139\176\236\150\180\236\152\164\235\184\140\236\160\157\237\138\184"),id);
if v then
for i=1,math.floor(tier),1 do
local id=v[i];
if id and objecttable[id]then
if(_S["\236\132\164\236\185\152"][id]or 0)==0 then
return false;
end
end
end
end
end
end
return true;
end
end

function HasBuilding(ids,cnt)
cnt=cnt or 1;
for _,id in safe_pairs(ids)do
local c=0;
for kk,vv in pairs(_S["\236\132\164\236\185\152"])do
if kk==id then

c=c+vv;
end
end
if c<cnt then
return false;
end
end
return true;
end

function CmpItem(cmp,cnt,consume)
cnt=cnt or 1;
local function _ConsumeItem(cnt,consume)
local req=cnt;
local function _consume(parent,key)
local guid=parent[key];
if cnt>0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
local id=o.id;
if cmp(guid,o)then
cnt=cnt-(o.c or 1);
if consume then
if cnt>=0 then
DelSlotItem(guid);
DelBagItemType(id,o.c);
trace("consume1",key,guid,consume);
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]=nil;
parent[key]=0;
if itemtable[id]["\235\185\132\236\154\176\234\184\176"]and consume~=itemtable[id]["\235\185\132\236\154\176\234\184\176"]then
for i=1,(o.c or 1)do
MakeAndPickItem(itemtable[id]["\235\185\132\236\154\176\234\184\176"]);
end
end
else
if itemtable[id]["\235\185\132\236\154\176\234\184\176"]and consume~=itemtable[id]["\235\185\132\236\154\176\234\184\176"]then
for i=1,(o.c or 1)+cnt do
MakeAndPickItem(itemtable[id]["\235\185\132\236\154\176\234\184\176"]);
end
end
DelBagItemType(id,(o.c or 1)+cnt);
o.c=-cnt;
end
end
return cnt<=0;
elseif o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if _consume(o["\234\176\128\235\176\169"],k)then
return true;
end
end
end
end
end
end
for k,slot in pairs(GetAvailSlots())do
if _consume(_S["\236\138\172\235\161\175"],slot)then
return true;
end
end
return false;
end

if cnt==0 then
return true;
elseif cnt==1 then
local b=_ConsumeItem(cnt,consume);
if b and consume then
eventDispatcher:send("ConsumeItem");
end
return b;
else
local b=_ConsumeItem(cnt,false);
if b and consume then
_ConsumeItem(cnt,consume);
eventDispatcher:send("ConsumeItem");
end
return b;
end
end



function ConsumeItem(guid,cnt,consume)
trace("try ConsumeItem",guid,cnt,consume);
if consume==nil then consume=true;end
local function cmp(g,o)
return g==guid;
end
return CmpItem(cmp,cnt,consume);
end

function HasItems(tb)
for k,v in pairs(tb)do
if not HasItemType(k,v)then
return false;
end
end
return true;
end

function HasItemType(id,cnt)
id=UnidentityItemId(id);
cnt=cnt or 1;
local c=0;
local t=const(id);
if t then
for _,k in pairs(t)do
c=c+(_S["\236\158\144\236\155\144"][k]or 0);
end
else
c=c+(_S["\236\158\144\236\155\144"][id]or 0);
end
return c>=cnt,c;
end


function HasItemTypeInBox(id,cnt)
id=UnidentityItemId(id);
cnt=cnt or 1;
local c=0;
local t=const(id);
if t then
for _,k in pairs(t)do
c=c+(_S["\236\158\144\236\155\144"][k]or 0)+(_S["\236\131\129\236\158\144\236\158\144\236\155\144"][k]or 0);
end
else
c=c+(_S["\236\158\144\236\155\144"][id]or 0)+(_S["\236\131\129\236\158\144\236\158\144\236\155\144"][id]or 0);
end
return c>=cnt,c;
end

function ConsumeItemType(id,cnt)
cnt=cnt or 1;
if HasItemType(id,cnt)then
local function cmp(g,o)
return(o.id==id or table.find(const(id),o.id));
end
assert(CmpItem(cmp,cnt,true));
return true;
end
end

function ConsumeItems(tb)
if tb then
for k,v in pairs(tb)do
if not HasItemType(k,v)then
return false;
end
end

for k,v in pairs(tb)do
assert(ConsumeItemType(k,v));
end
end
return true;
end


function ConsumeItemsFromGuid(t,consume)
for k,v in safe_pairs(t)do
assert(ConsumeItem(k,v,consume or true),t,consume);
end
return true;
end


function GetMyItems(match,slots)
local list={};
local function _run(_guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_guid];
if o then
if not match or match(o,_guid)then
list[_guid]=o;
end
if o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if _run(v)then
return true;
end
end
end
end
end

for k,slot in pairs(slots or GetAvailSlots())do
_run(_S["\236\138\172\235\161\175"][slot]);
end
return list;
end


function RecalcItemStorageItems()
_S["\236\131\129\236\158\144\236\158\144\236\155\144"]={};
for k,v in pairs(_S.maps)do
if v.objects then
for g,sdata in pairs(v.objects)do
if sdata.items and objecttable[sdata.id].class=="Storage"then
for i,guid in pairs(sdata.items)do
if guid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
AddBagItemType(o.id,o.c,"\236\131\129\236\158\144\236\158\144\236\155\144");
end
end
end
end
end
end
end


function GetSortedMyItems()
local myItems={};

for k,v in pairs(GetMyItems())do
table.insert(myItems,k);
end

table.sort(myItems,function(a,b)return(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][a].c or 1)<(_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][b].c or 1)end);
return myItems;
end


function StealMyStorageItem(match)
local list={};
local function _run(storage,pos,_guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_guid];
if o then
if not match or match(o,_guid)then
if storage and pos then
if ItemPrice(guid)then
table.insert(list,{storage,pos});
end
end
end
if o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if _run(o["\234\176\128\235\176\169"],k,v)then
return true;
end
end
end
end
end

for k,slot in pairs(GetAvailSlots())do
_run(nil,nil,_S["\236\138\172\235\161\175"][slot]);
end
local t=table.choice(list);
if t then
local guid=t[1][t[2]];
t[1][t[2]]=0;
eventDispatcher:send("ConsumeItem");
return guid;
end
end

function DecreaseWeaponDurability(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if(data["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
local w=data.id;
local group=itemtable[w]["\234\183\184\235\163\185"];
_G["\234\176\149\237\153\148"]=data["\234\176\149\237\153\148"]or 0;
_G["\237\139\176\236\150\180"]=ItemTier(guid);
_G["\236\152\181\236\133\152\235\179\180\235\132\136\236\138\164"]=GetOptionDurabilityBonus(guid);
local p=ev("\235\172\180\234\184\176 \235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",group);
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
_G["\236\152\181\236\133\152\235\179\180\235\132\136\236\138\164"]=nil;
if p then
p=bfItem(guid,"\235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",p);
if math.randpercent(p)then
data["\235\130\180\234\181\172\235\143\132"]=data["\235\130\180\234\181\172\235\143\132"]-1;
trace("\236\158\165\235\185\132 \235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140",guid,data["\235\130\180\234\181\172\235\143\132"]);
if data["\235\130\180\234\181\172\235\143\132"]<=0 then
data["\235\130\180\234\181\172\235\143\132"]=0;
DelItemBuff(guid);
updateSkill();

local dict={};
dict["{1}"]=itemtable[w].name;
dict["{\236\157\180/\234\176\128}"]=SelectJosa(dict["{1}"],{"\236\157\180","\234\176\128"});
world.textbox:AddLine(ReplaceString(lang["\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_\235\172\180\234\184\176\237\140\140\236\134\144"],dict));
Tutorial(world,"\235\169\148\236\132\184\236\167\128",{id="\235\130\180\234\181\172\235\143\1320",guid=guid});
end
end
end
end
end


function GetArmorReqStr(addAll)
local n=0;
local str=bf("\237\158\152");
for k,v in pairs(GetAvailSlots())do
if not IsSubSlot(v)then
local guid=_S["\236\138\172\235\161\175"][v];
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local w=data.id;
_G["\237\139\176\236\150\180"]=ItemTier(guid)or 0;
local req=ev("\235\176\169\236\150\180\234\181\172\235\179\132\236\154\148\234\181\172\237\158\152")[itemtable[w]["\236\162\133\235\165\152"]];
if req then
req=req+bf("\235\176\169\236\150\180\236\154\148\234\181\172\237\158\152");
if addAll or req>str then
n=n+req-str;
end
end
_G["\237\139\176\236\150\180"]=nil;
end
end
end
return n;
end

function GetOptionDurabilityBonus(guid)
local n=0;
for k,v in pairs(ev("\236\152\181\236\133\152\235\179\132\235\130\180\234\181\172\235\143\132\235\179\180\235\132\136\236\138\164"))do
if HasItemOption(guid,k)then
n=n+v;
end
end
return n;
end

function DecreaseArmorDurability()
for k,v in pairs(GetAvailSlots())do
if not IsSubSlot(v)then
local guid=_S["\236\138\172\235\161\175"][v];
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if(data["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
local w=data.id;
local group=itemtable[w]["\234\183\184\235\163\185"];
_G["\234\176\149\237\153\148"]=data["\234\176\149\237\153\148"]or 0;
_G["\237\139\176\236\150\180"]=ItemTier(guid);
_G["\236\152\181\236\133\152\235\179\180\235\132\136\236\138\164"]=GetOptionDurabilityBonus(guid);
local p=ev("\235\176\169\236\150\180\234\181\172 \235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",group);
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
_G["\236\152\181\236\133\152\235\179\180\235\132\136\236\138\164"]=nil;
if p then
p=bf("\235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",p);
if math.randpercent(p)then
data["\235\130\180\234\181\172\235\143\132"]=data["\235\130\180\234\181\172\235\143\132"]-1;
if data["\235\130\180\234\181\172\235\143\132"]<=0 then
data["\235\130\180\234\181\172\235\143\132"]=0;
DelItemBuff(guid);
updateSkill();

local dict={};
dict["{1}"]=itemtable[w].name;
dict["{\236\157\180/\234\176\128}"]=SelectJosa(dict["{1}"],{"\236\157\180","\234\176\128"});
world.textbox:AddLine(ReplaceString(lang["\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_\236\149\132\235\168\184\237\140\140\236\134\144"],dict));
Tutorial(world,"\235\169\148\236\132\184\236\167\128",{id="\235\130\180\234\181\172\235\143\1320",guid=guid});
end
end
end
end
end
end
end
end

function DecreaseAttackObjectDurability(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if(data["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
local w=data.id;
local p=const("\236\152\164\235\184\140\236\160\157\237\138\184\234\179\181\234\178\169\235\130\180\234\181\172\235\143\132\234\176\144\236\134\140\237\153\149\235\165\160");
if p then
p=bf("\235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",p);
if math.randpercent(p)then
data["\235\130\180\234\181\172\235\143\132"]=data["\235\130\180\234\181\172\235\143\132"]-1;
if data["\235\130\180\234\181\172\235\143\132"]<=0 then
data["\235\130\180\234\181\172\235\143\132"]=0;
DelItemBuff(guid);
updateSkill();
local dict={};
dict["{1}"]=itemtable[w].name;
dict["{\236\157\180/\234\176\128}"]=SelectJosa(dict["{1}"],{"\236\157\180","\234\176\128"});
world.textbox:AddLine(ReplaceString(lang["\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_\235\172\180\234\184\176\237\140\140\236\134\144"],dict));
Tutorial(world,"\235\169\148\236\132\184\236\167\128",{id="\235\130\180\234\181\172\235\143\1320",guid=guid});
end
end
end
end
end


function DecreaseToolDurability(guid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if(data["\235\130\180\234\181\172\235\143\132"]or 0)>0 then
local w=data.id;
local group=itemtable[w]["\234\183\184\235\163\185"];
_G["\234\176\149\237\153\148"]=data["\234\176\149\237\153\148"]or 0;
_G["\237\139\176\236\150\180"]=ItemTier(guid);
_G["\236\152\181\236\133\152\235\179\180\235\132\136\236\138\164"]=GetOptionDurabilityBonus(guid);
local p=ev("\235\143\132\234\181\172 \235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",w)or ev("\235\143\132\234\181\172 \235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",group);
_G["\237\139\176\236\150\180"]=nil;
_G["\234\176\149\237\153\148"]=nil;
_G["\236\152\181\236\133\152\235\179\180\235\132\136\236\138\164"]=nil;
if p then
trace("\234\176\144\236\134\140",p);
p=bf("\235\130\180\234\181\172\235\143\132 \234\176\144\236\134\140 \237\153\149\235\165\160",p);
if math.randpercent(p)then
data["\235\130\180\234\181\172\235\143\132"]=data["\235\130\180\234\181\172\235\143\132"]-1;
if data["\235\130\180\234\181\172\235\143\132"]<=0 then
data["\235\130\180\234\181\172\235\143\132"]=0;
DelItemBuff(guid);
updateSkill();

local dict={};
dict["{1}"]=itemtable[w].name;
dict["{\236\157\180/\234\176\128}"]=SelectJosa(dict["{1}"],{"\236\157\180","\234\176\128"});
world.textbox:AddLine(ReplaceString(lang["\235\148\148\235\178\132\237\148\132\235\169\148\236\132\184\236\167\128_\235\143\132\234\181\172\237\140\140\236\134\144"],dict));
Tutorial(world,"\235\169\148\236\132\184\236\167\128",{id="\235\130\180\234\181\172\235\143\1320",guid=guid});
end
end
end
end

do
local p=const("\236\131\157\236\161\180\237\153\156\235\143\153\235\182\128\236\131\129\237\153\149\235\165\160");
local buff=math.randlist(const("\236\131\157\236\161\180\237\153\156\235\143\153\235\182\128\236\131\129"))



















p=bf("\236\177\132\236\167\145\236\139\156 "..buff,p);
p=bf("\236\177\132\236\167\145\236\139\156 \235\182\128\236\131\129",p);
trace("\236\131\157\236\161\180 \237\153\156\235\143\153 \235\182\128\236\131\129P",p,buff);
if const("\236\151\176\236\134\141\236\177\132\236\167\145\235\179\180\237\152\184")<=_S["\236\151\176\236\134\141\236\177\132\236\167\145"]and world.player:addDebufP(p,buff,"\236\167\128\237\152\149")then
_S["\236\151\176\236\134\141\236\177\132\236\167\145"]=0;
else
_S["\236\151\176\236\134\141\236\177\132\236\167\145"]=_S["\236\151\176\236\134\141\236\177\132\236\167\145"]+1;
end
end
end


function GetMaxStorage(type)
local guid=_S["\236\138\172\235\161\175"][type];
if guid~=0 then
return#_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]["\234\176\128\235\176\169"];
end
return 0;
end


function EquipDefaultItem()

for k,v in pairs(itemtable)do
if v.default and v.default.equip=="\235\176\176\235\130\173"then
local guid,o=MakeItem(k,"\236\139\156\236\158\145");
SetSlotItem("\235\176\176\235\130\1731",guid);
end
end

for k,v in pairs(itemtable)do
if v.default then
for i=1,v.default.count or 0,1 do
local guid,o=MakeItem(k);
assert(AddItemToStorage(guid),"add item fail"..k);
if v.default.equip and v.default.equip~="\235\176\176\235\130\173"then
EquipItem(guid,v.default.equip);
end
end
end
end

local b,param=bf("\236\139\156\236\158\145\236\149\132\236\157\180\237\133\156 \234\176\156\236\136\152");
if param then
for k,v in pairs(param)do
for i=1,v.c,1 do
local k=math.randlist(v["\235\170\169\235\161\157"]);
trace("\235\185\132\236\131\129\236\139\157\235\159\137",k);
local guid,o=MakeItem(k);
assert(AddItemToStorage(guid),"add item fail"..k);
end
end
end

local job=jobtable[_S["\236\167\129\236\151\133"]];
if job then
for k,v in safe_ipairs(job["\236\139\156\236\158\145\236\149\132\236\157\180\237\133\156"])do
local tb=recipetable[v];
local id=tb["\236\158\165\235\185\132"];
_G.recplv=_S["\235\160\136\236\132\156\237\148\188"][id]or 0;
local guid,o=MakeItem(id,"\236\160\156\236\158\145");
_G.recplv=nil;
assert(AddItemToStorage(guid),"add item fail"..k);
o.c=tb["\236\131\157\236\130\176\234\176\156\236\136\152"];
end
end


end


function CanEquipItemToSlot(id,slot)
local item=itemtable[id];
local slots=nil;
if slot then
local guid=_S["\236\138\172\235\161\175"][slot];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o and HasItemOption(guid,"\236\160\128\236\163\188")then
return false;
end

local oppSlot=const("\235\176\152\235\140\128\236\134\144\236\138\172\235\161\175",slot);
if oppSlot then
local oppGuid=_S["\236\138\172\235\161\175"][oppSlot];
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][oppGuid]then
local oppId=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][oppGuid].id;
local oppType=itemtable[oppId]["\236\162\133\235\165\152"];
if const("\236\150\145\236\134\144\236\138\172\235\161\175",item["\236\162\133\235\165\152"])or const("\236\150\145\236\134\144\236\138\172\235\161\175",oppType)then
if const("\237\131\132\236\149\189\236\162\133\235\165\152",item["\236\162\133\235\165\152"])==oppType or const("\237\131\132\236\149\189\236\162\133\235\165\152",oppType)==item["\236\162\133\235\165\152"]then

else
if HasItemOption(oppGuid,"\236\160\128\236\163\188")then
return false;
end
end
end
end
end

if const("\236\160\156\236\153\184\236\162\133\235\165\152",item["\236\162\133\235\165\152"])then
for k,v in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
if itemtable[id]["\236\162\133\235\165\152"]==const("\236\160\156\236\153\184\236\162\133\235\165\152",item["\236\162\133\235\165\152"])then
if HasItemOption(guid,"\236\160\128\236\163\188")then
return false;
end
end
end
end
end

end

if item["\236\162\133\235\165\152"]then
if item.storage then
slots={item.storage.type};
else
local t=const("\237\149\132\236\154\148\236\138\172\235\161\175")[item["\236\162\133\235\165\152"]];
if type(t)=="table"then
slots=t;
else
slots={t};
end
end
if slots then
if not slot then
return#slots>0;
else
local n=string.match(slot,"%d")or"";
for k,v in safe_pairs(slots)do
if slot==v..n then
return true;
end
end
end
end
end
end

function GetEmptyStorage(type)
local maxN=GetMaxStorage(type);
local guid=_S["\236\138\172\235\161\175"][type];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
trace("GetEmptyStorage",maxN);
for i=1,maxN,1 do
if 0==(o["\234\176\128\235\176\169"][i]or 0)then
return i,o["\234\176\128\235\176\169"];
end
end
end


function RearrangeStorages()
local list={};
for k,slot in ipairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if IsStorageSlot(slot)and guid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
assert(o,slot,guid);
local s=o["\234\176\128\235\176\169"];
for i=1,GetMaxStorage(slot)do
if s[i]~=0 then
table.insert(list,s[i]);
local d=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][s[i]];
assert(d);
DelBagItemType(d.id,d.c);
s[i]=0;
end
end
end
end

local function priority(a)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][a];
assert(o,a);
local item=itemtable[o.id];
local group=ItemGroup(item);
return{drop1table[group].priority or 999999,item.priority or 999999};
end

local function cmp_priority(a,b)
local p1=priority(a);
local p2=priority(b);
for k,v in ipairs(p1)do
if v~=p2[k]then
return v<p2[k];
end
end
end

table.sort(list,function(a,b)
return cmp_priority(a,b);
end);

for i,v in ipairs(list)do
local itemGuid=AddItemToStorage(v);
if not itemGuid then
PlaceItem(v,_S.x,_S.y);
end
end

end


function SortStorage(storage)
local i=1;
local list={};
while storage[i]do
if storage[i]~=0 then
table.insert(list,storage[i]);
storage[i]=0;
end
i=i+1;
end

local function priority(a)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][a];
assert(o,a);
local item=itemtable[o.id];
local group=ItemGroup(item);
return{drop1table[group].priority or 999999,item.priority or 999999};
end

local function cmp_priority(a,b)
local p1=priority(a);
local p2=priority(b);
for k,v in ipairs(p1)do
if v~=p2[k]then
return v<p2[k];
end
end
end

table.sort(list,function(a,b)
return cmp_priority(a,b);
end);

for i,v in ipairs(list)do
storage[i]=v;
end
end



function DelStorageItem(type,guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_S["\236\138\172\235\161\175"][type]];
if not o then
return true;
end
if _S["\236\138\172\235\161\175"][type]==guid then
local i=1;
while o["\234\176\128\235\176\169"][i]do
if o["\234\176\128\235\176\169"][i]~=0 then
local g=o["\234\176\128\235\176\169"][i];
local d=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
local itemId=d.id;
DelBagItemType(itemId,d.c);
DelStorageItemBuff(type,g);
end
i=i+1;
end
DelSlotItem(guid);
return true;
else
local i=1;
while o["\234\176\128\235\176\169"][i]do
if o["\234\176\128\235\176\169"][i]==guid then
local d=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local itemId=d.id;
DelBagItemType(itemId,d.c);
DelStorageItemBuff(type,guid);
o["\234\176\128\235\176\169"][i]=0;
return true;
end
i=i+1;
end
end
trace("DelStorageItem fail",type,guid,debug.traceback());
end

function IsInField()
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
return m and m["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"and not m["\236\176\189\234\179\160"];
end
function IsInDungeon()
local m=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]];
return m and string.ends(m["\237\131\128\236\158\133"],"\235\141\152\236\160\132");
end

function GetAvailSlots()
if IsInField()then
return const("\236\138\172\235\161\175\235\170\169\235\161\157");
else
return const("\235\141\152\236\160\132\236\138\172\235\161\175\235\170\169\235\161\157");
end
end

function GetAvailStorageSlots()
if IsInField()then
return const("\234\176\128\235\176\169\236\138\172\235\161\175\235\170\169\235\161\157");
else
return const("\235\141\152\236\160\132\234\176\128\235\176\169\236\138\172\235\161\175\235\170\169\235\161\157");
end
end

function IsStorageSlot(slot)
return table.find(const("\234\176\128\235\176\169\236\138\172\235\161\175\235\170\169\235\161\157"),slot);
end

function SwitchWeapons(testOnly)
local slots={"\236\152\164\235\165\184\236\134\1441","\236\153\188\236\134\1441","\236\152\164\235\165\184\236\134\1442","\236\153\188\236\134\1442"};
local guids={};
for i,v in ipairs(slots)do
local guid=_S["\236\138\172\235\161\175"][v];
guids[i]=guid;
if guid and guid~=0 then
if i<=2 and HasItemOption(guid,"\236\160\128\236\163\188")then
return false;
end
end
end

if testOnly then
return true;
end

trace("SwitchWeapons");
for i,guid in ipairs(guids)do
DelSlotItem(guid);
end

guids[1],guids[3]=guids[3],guids[1];
guids[2],guids[4]=guids[4],guids[2];






for i,guid in ipairs(guids)do
SetSlotItem(slots[i],guid);
end
end

function IsItemEqual(o,data)
return table.equal(data,o,{"pick","T","c","m"},{"\236\152\181\236\133\152"});
end



local function CombineItemToBag(bag,itemGuid,isStorage)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local itemId=data.id;
local maxN=#bag;
for i=1,maxN,1 do
local g=bag[i];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
if o and itemId==o.id then
local c=o.c;
local maxC=itemtable[o.id]["\235\136\132\236\160\129"]or 1;
local nextC=(c or 1)+(data.c or 1);
local remainC=0;
if maxC<nextC then
remainC=nextC-maxC;
nextC=maxC;
end
local addC=nextC-(o.c or 1);
if addC>0 then
if IsItemEqual(data,o)then
local dT,oT=data.T,o.T;
if dT or oT then
o.T=((dT or 0)*addC+(oT or 0)*(o.c or 1))/nextC;
end
if isStorage then
AddBagItemType(o.id,addC);
end
o.c=nextC;
if remainC==0 then
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid]=nil;
return true,g;
else
data.c=remainC;
end
end
end
end
end
end

function AddItemToBag(bag,itemGuid,isStorage)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local itemId=data.id;
local itemC=data.c;
if CombineItemToBag(bag,itemGuid,isStorage)then
return true;
else
for k,v in pairs(bag)do
if v==0 then
bag[k]=itemGuid;
if isStorage then
AddBagItemType(itemId,itemC);
end
return true;
end
end
end
end

local function CombineItemToStorage(storage,itemGuid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local itemId=data.id;
local maxN=GetMaxStorage(storage);
local storageGuid=_S["\236\138\172\235\161\175"][storage];
if storageGuid~=0 then
local storageO=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][storageGuid];
return CombineItemToBag(storageO["\234\176\128\235\176\169"],itemGuid,true);
end
end

function AddItemToStorage(itemGuid,noEquip,slots)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
assert(data,itemGuid);
local itemId=data.id;
local item=itemtable[itemId];
local itemType=item["\236\162\133\235\165\152"];
local itemTier=ItemTier(itemGuid);
if not noEquip then

for k,v in ipairs(GetAvailSlots())do
local g=_S["\236\138\172\235\161\175"][v];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
if o and g~=itemGuid then
if itemId==o.id then
local c=o.c;
local maxC=itemtable[o.id]["\235\136\132\236\160\129"]or 1;
local nextC=(c or 1)+(data.c or 1);
if nextC<=maxC then
o.c=nextC;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid]=nil;
eventDispatcher:send("PickItem");
return g;











end
end


if itemType and const("\237\131\132\236\149\189\236\162\133\235\165\152",itemtable[o.id]["\236\162\133\235\165\152"])==itemType then
local oppSlot=const("\235\176\152\235\140\128\236\134\144\236\138\172\235\161\175",v);
if _S["\236\138\172\235\161\175"][oppSlot]==0 then
_S["\236\138\172\235\161\175"][oppSlot]=itemGuid;
SetStorageItemBuff(oppSlot,itemGuid);
eventDispatcher:send("PickItem");
return itemGuid;
end
end
end
end
end


slots=slots or GetItemStorageSlots(itemGuid);
trace("slots",slots);

for k,v in ipairs(slots)do
local storageGuid=_S["\236\138\172\235\161\175"][v];
if storageGuid~=0 then
local b,g=CombineItemToStorage(v,itemGuid);
if b then
eventDispatcher:send("PickItem");
return g;
end
end
end

for k,v in ipairs(slots)do
local storageGuid=_S["\236\138\172\235\161\175"][v];
if storageGuid~=0 then
local storageO=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][storageGuid];
local storageId=storageO.id;
local limits=itemtable[storageId].storage["\236\160\156\237\149\156"];

if limits and table.find(limits,itemType)then
else
local empty,t=GetEmptyStorage(v);
if empty then
t[empty]=itemGuid;
SetStorageItemBuff(v,itemGuid);






AddBagItemType(itemId,data.c);
eventDispatcher:send("PickItem");
return itemGuid;
end
end
end
end
end

function HasStorage()
for k,v in ipairs(GetAvailStorageSlots())do
if _S["\236\138\172\235\161\175"][v]~=0 then
return true;
end
end
end

function IsStorageItemType(tp,itemId)
local itemType=itemtable[itemId]["\236\162\133\235\165\152"];
local group=itemtable[itemId]["\234\183\184\235\163\185"];
return table.find(tp,group)or table.find(tp,itemType)or table.find(tp,itemId);
end


function GetItemStorageSlots(guid,filterSlots)

local itemId=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
local slots={};
for k,v in ipairs(GetAvailStorageSlots())do
if not table.find(filterSlots,v)then
local storageGuid=_S["\236\138\172\235\161\175"][v];
if storageGuid~=0 then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][storageGuid].id;
local tp=itemtable[id].storage["\234\176\128\235\138\165"];
if not tp then
table.insert(slots,v);
elseif IsStorageItemType(tp,itemId)then
table.insert(slots,1,v);
end
end
end
end
return slots;
end


function MoveStorageItem(slot)
if IsStorageSlot(slot)then
if _S["\236\138\172\235\161\175"][slot]~=0 then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_S["\236\138\172\235\161\175"][slot]].id;
local tp=itemtable[id].storage["\234\176\128\235\138\165"];
if tp then

for k,v in ipairs(GetAvailStorageSlots())do
local storageGuid=_S["\236\138\172\235\161\175"][v];
if storageGuid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][storageGuid];
if not itemtable[o.id].storage["\234\176\128\235\138\165"]then
for i,g in pairs(o["\234\176\128\235\176\169"])do
if g~=0 then
local itemId=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g].id;
if IsStorageItemType(tp,itemId)then
local empty,t=GetEmptyStorage(slot);
if not empty then
return false;
end
t[empty]=g;
o["\234\176\128\235\176\169"][i]=0;
end
end
end
end
end
end
return true;
end
end
end
end


function PickItem(guid,itemGuid)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local pick=data.pick;
local id=data.id;









local item=itemtable[id];
trace("PickItem",guid,itemGuid,id);

local bEquip;
if item.storage then
local empty=true;

for i,v in pairs(data["\234\176\128\235\176\169"])do
if v~=0 then
empty=false;
break;
end
end
if not empty or not HasStorage()then
for k,slot in pairs(GetAvailSlots())do
if CanEquipItemToSlot(data.id,slot)and _S["\236\138\172\235\161\175"][slot]==0 then
for i,v in pairs(data["\234\176\128\235\176\169"])do
if v~=0 then
local d=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
AddBagItemType(d.id,d.c);
SetStorageItemBuff(slot,v);
end
end
SetSlotItem(slot,itemGuid);
MoveStorageItem(slot);
bEquip=true;
break;
end
end
end
end

if not bEquip then
itemGuid=AddItemToStorage(itemGuid);
if not itemGuid then
trace("full invenl");
return nil;
end
end

if item.storage and not bEquip then
for i,v in ipairs(data["\234\176\128\235\176\169"])do
if v~=0 then
if not AddItemToStorage(v)then
local o=world:createObject("\236\149\132\236\157\180\237\133\156",_S.x,_S.y,{item=v},true);
end
data["\234\176\128\235\176\169"][i]=0;
end
end
end

local mapId=_S["\237\152\132\236\158\172\235\167\181"];
if guid then
world:delObject(guid);
eventDispatcher:send("PickItem");
end

if not pick then
_S["\237\154\141\235\147\157\237\154\159\236\136\152"][id]=(_S["\237\154\141\235\147\157\237\154\159\236\136\152"][id]or 0)+1;
Tutorial({world.ui.menu,world.ui.stat,world.ui.stat.c},"\236\149\132\236\157\180\237\133\156\237\154\141\235\147\157",{id=id});
Mission("\236\136\152\236\167\145",1,id);
world.player:addChat(lang["\237\154\141\235\147\157_"..id]);
end
return itemGuid;
end

function ReleaseGoat(guid,sdata,createMonster,noDie)
if _S["\236\167\144\234\190\188"][guid]then
if not noDie then
world:findCharac(guid):die(true);
end
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
for i,v in ipairs(o["\234\176\128\235\176\169"])do
if v~=0 then
local ob=world:createObject("\236\149\132\236\157\180\237\133\156",sdata.x,sdata.y,{item=v},true);
o["\234\176\128\235\176\169"][i]=0;
end
end
_S["\236\167\144\234\190\188"][guid]=nil;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]=nil;
end

if createMonster then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local npcs=_S.maps[mapId].npcs;
local cid=MakeGuid("c");
npcs[cid]=table.copy(sdata);
npcs[cid].appeared=nil;
npcs[cid].id="\236\130\176\236\150\145";
npcs[cid].regenC="\235\140\128\237\152\149 \236\164\145\235\166\189 \235\170\172\236\138\164\237\132\176";
npcs[cid].regenM=mapId;
npcs[cid]["\236\157\180\235\143\153\235\170\168\235\147\156"]=nil;
npcs[cid]["\236\157\180\235\143\153\235\170\168\235\147\156T"]=nil;
npcs[cid]["\236\150\180\234\183\184\235\161\156"]={};
for k,v in ipairs(const("\235\170\172\236\138\164\237\132\176\235\179\180\236\160\149\235\170\169\235\161\157"))do
npcs[cid][v]=nil;
end
world:addNpc(cid,npcs[cid]);
end
eventDispatcher:send("PickItem");
end


function PickGoat(id,sdata)
local slot="\236\167\144\234\190\1881";
UnEquipItem(slot);
local itemGuid,data=MakeItem(id or"\236\130\176\236\150\145 \234\176\128\235\176\169");
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local areaN=_S.maps[mapId]["\236\167\128\236\151\173 \235\178\136\237\152\184"];
data["\234\176\128\235\176\169"]={};
sdata["\234\176\128\235\176\169\236\185\184"]=sdata["\234\176\128\235\176\169\236\185\184"]or countkcc(const("\236\130\176\236\150\145\234\176\128\235\176\169\236\185\184\236\136\152","\236\167\128\236\151\173"..areaN));
for i=1,sdata["\234\176\128\235\176\169\236\185\184"],1 do
data["\234\176\128\235\176\169"][i]=0;
end
local oldGuid=_S["\236\138\172\235\161\175"][slot];
assert(oldGuid==0);
SetSlotItem(slot,itemGuid);
_S["\236\167\144\234\190\188"][itemGuid]=table.copy(sdata);
_S["\236\167\144\234\190\188"][itemGuid].appeared=nil;
_S["\236\167\144\234\190\188"][itemGuid].regenC=nil;
_S["\236\167\144\234\190\188"][itemGuid].regenM=nil;
_S["\236\167\144\234\190\188"][itemGuid]["\236\157\180\235\143\153\235\170\168\235\147\156"]=nil;
_S["\236\167\144\234\190\188"][itemGuid]["\236\157\180\235\143\153\235\170\168\235\147\156T"]=nil;
_S["\236\167\144\234\190\188"][itemGuid]["\236\150\180\234\183\184\235\161\156"]={};
for k,v in ipairs(const("\235\170\172\236\138\164\237\132\176\235\179\180\236\160\149\235\170\169\235\161\157"))do
_S["\236\167\144\234\190\188"][itemGuid][v]=nil;
end
_S["\236\167\144\234\190\188"][itemGuid].id=itemtable[id]["\237\140\140\235\157\188\235\175\184\237\132\176"];

_S["\236\167\144\234\190\188"][itemGuid].mapId=_S["\237\152\132\236\158\172\235\167\181"];
world:addNpc(itemGuid,_S["\236\167\144\234\190\188"][itemGuid]);
eventDispatcher:send("PickItem");
end
function PlaceItem(itemGuid,x,y)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local o=world:createObject("\236\149\132\236\157\180\237\133\156",x,y,{item=itemGuid},true)
return o,data;
end

function CopyAndPlaceItem(itemGuid,x,y,cnt)
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid];
local guid2=MakeGuid();
local data2=table.copy(data);
data2.c=cnt;
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid2]=data2;
itemGuid=guid2;
local o=world:createObject("\236\149\132\236\157\180\237\133\156",x,y,{item=itemGuid},true)
o.canvas:SetZOrder(o:getZOrder()+1);
return o,data2;
end

function MakeAndPlaceItem(id,x,y,from)
x=x or _S.x;
y=y or _S.y;
local itemGuid,data=MakeItem(id,from);
local o=world:createObject("\236\149\132\236\157\180\237\133\156",x,y,{item=itemGuid},true);
trace("MakeAndPlaceItem",o.guid,itemGuid);
return o,data,itemGuid;
end

function PickItemEfx(itemId,delay)
if not world:invenOpened()then
local item=itemtable[itemId];
assert(item,itemId);
local isScroll=string.find(item.obj,"_scroll_");
local function f()
local o,sk=SpineObject(world.ui.menu["\234\176\128\235\176\169"].w,"efx","item","ani_into_bag",nil,nil,"autoclose");
if isScroll then
sk:setAttachment("scroll",item.obj);
sk:setAttachment("item");
else
sk:setAttachment("item",item.obj);
sk:setAttachment("scroll");
end
end
world.timer.add(f,f,delay);
end
end


function PickOrPlaceItem(itemGuid,x,y)
local g=PickItem(nil,itemGuid);
if not g then
world.player:addChat(_L("\234\176\128\235\176\169\236\151\144 \235\185\136\234\179\181\234\176\132\236\157\180 \236\151\134\235\139\164"));
local o=world:createObject("\236\149\132\236\157\180\237\133\156",x,y,{item=itemGuid},true);
return itemGuid,_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][itemGuid],o;
end
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][g];
PickItemEfx(data.id);
eventDispatcher:send("PickItem");
return g,data;
end

function MakeAndPickItem(id,x,y,from)
trace("MakeAndPickItem",id);
x=x or _S.x;
y=y or _S.y;
return PickOrPlaceItem(MakeItem(id,from),x or _S.x,y or _S.y);
end





















function GetRepairMaterials(guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
trace("GetRepairMaterials",o);
if const("\235\182\132\235\165\152A",itemtable[o.id]["\236\162\133\235\165\152"])=="\235\172\180\234\184\176"then
return const("\235\172\180\234\184\176\236\136\152\235\166\172\236\158\172\235\163\140",o["\235\147\177\234\184\137"])or{};
else
return const("\234\184\176\237\131\128\236\136\152\235\166\172\236\158\172\235\163\140",o["\235\147\177\234\184\137"])or{};
end
end

function GetRecipeMaxLv(id)
local v=recipetable[id];
local grade="\236\158\165\235\185\132";
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]then
grade=v["\235\147\177\234\184\137"];
end
return servertable.TotemMaxLv[grade];
end

function GetArtifactRepairMaterials(guid)
return const("\236\149\132\237\139\176\237\140\169\237\138\184 \236\136\152\235\166\172\236\158\172\235\163\140");












end

function DelMyItem(guid)
local function _delete(parent,key,item)
local item=parent[key];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][item];
if o then
if o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if _delete(o["\234\176\128\235\176\169"],k)then
return true;
end
end
else
if item==guid then
DelItemBuff(guid);
parent[key]=0;

eventDispatcher:send("ConsumeItem");
return true;
end
end
end
end

for k,slot in pairs(GetAvailSlots())do
_delete(_S["\236\138\172\235\161\175"],slot);
end

end

function DeleteInvalidItem()
local function _run(_guid)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_guid];
if o then
if o["\234\176\128\235\176\169"]then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if v~=0 and not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v]then
o["\234\176\128\235\176\169"][k]=0;
else
if _run(v)then
return true;
end
end
end
end
end
end

for k,slot in pairs(const("\236\138\172\235\161\175\235\170\169\235\161\157"))do
_run(_S["\236\138\172\235\161\175"][slot]);
end
end


function FindStorageItem(type,filter)
for k,v in pairs(_S[type])do
local item=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
if item then
local match=true;
for k,v in pairs(filter)do
if item[k]~=v then
match=false;
break;
end
end
if match then
return v;
end
end
end
end

function IsSubSlot(slot)
return slot=="\236\152\164\235\165\184\236\134\1442"or slot=="\236\153\188\236\134\1442";
end


function ConsumeEquipItem(slot)
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if(o.c or 1)>1 then
o.c=o.c-1;
else
UnEquipItem(slot,true);
end
eventDispatcher:send("ConsumeItem");
return true;
end
end

function CountEquipItem(id)
local c=0;
for k,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o.id==id then
c=c+(o.c or 1);
end
end
end
return c;
end

function ConsumeItemOrEquipItem(guid)
for k,slot in pairs(GetAvailSlots())do
if _S["\236\138\172\235\161\175"][slot]==guid then
return ConsumeEquipItem(slot);
end
end
return ConsumeItem(guid);
end





























function IsEquippedItem(guid)
for k,slot in pairs(GetAvailSlots())do
if _S["\236\138\172\235\161\175"][slot]==guid then
return true;
end
end
end



function UnEquipItem(slot,consume)
local guid=_S["\236\138\172\235\161\175"][slot];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
if o then
if IsStorageSlot(slot)then
DelStorageItem(slot,guid);
if _S["\236\167\144\234\190\188"][guid]then
ReleaseGoat(guid,_S["\236\167\144\234\190\188"][guid],true);
else
if consume then
for k,v in pairs(o["\234\176\128\235\176\169"])do
if v~=0 then
local ob=world:createObject("\236\149\132\236\157\180\237\133\156",_S.x,_S.y,{item=v},true);
end
end
else
local ob=world:createObject("\236\149\132\236\157\180\237\133\156",_S.x,_S.y,{item=guid},true);
end
end
else
DelSlotItem(guid);
if consume then
_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]=nil;
else
if not AddItemToStorage(guid,true)then
local ob=world:createObject("\236\149\132\236\157\180\237\133\156",_S.x,_S.y,{item=guid},true);
trace("full inven");

end
end
end
end
updateSkill();
eventDispatcher:send("PickItem");
return true;
end

function BeginStorageTxn(type)
local guid=_S["\236\138\172\235\161\175"][type];
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local txn={storages={},data={["\236\138\172\235\161\175"]={},["\235\178\132\237\148\132"]={},["\236\158\144\236\155\144"]={}}};
for k,v in pairs(txn.data)do
if _S[k]then
for kk,vv in pairs(_S[k])do

if _G.type(vv)=="table"then
txn.data[k][kk]=table.copy(vv);

else
txn.data[k][kk]=vv;
end
end
end
end

local function saveStorage(o)
if o["\234\176\128\235\176\169"]then
txn.storages[o]={};
for k,v in pairs(o["\234\176\128\235\176\169"])do
local o2=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][v];
if o2 and o2["\234\176\128\235\176\169"]then
saveStorage(o2);
end
txn.storages[o][k]=v;
end
end
end
saveStorage(o);

return txn;
end

function RollbackStorageTxn(txn)
for k,v in pairs(txn.data)do
if _S[k]then
table.clear(_S[k]);
for kk,vv in pairs(v)do
_S[k][kk]=vv;
end

end
end
for o,t in pairs(txn.storages)do
for k,v in pairs(t)do
o["\234\176\128\235\176\169"][k]=v;
end
end
end



function EquipItem(type,guid,slot)

local function txn()
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
local item=itemtable[id];
local oldBag;
assert(CanEquipItemToSlot(id,slot),item.guid);
if not DelStorageItem(type,guid)then


assert(false,"DelStorageItem fail:"..slot..guid..id);
return false;
end


if not IsStorageSlot(slot)then
if not UnEquipItem(slot)then
trace("UnEquipItem fail");
return false;
end
end




















if const("\236\160\156\236\153\184\236\162\133\235\165\152",item["\236\162\133\235\165\152"])then
for k,v in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
if itemtable[id]["\236\162\133\235\165\152"]==const("\236\160\156\236\153\184\236\162\133\235\165\152",item["\236\162\133\235\165\152"])then
if not UnEquipItem(v)then
trace("unique UnEquipItem fail");
return false;
end
end
end
end
end

for k,v in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][v];
if guid and _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
local _item=itemtable[id];
if _item.exSlot then
local n=string.match(v,"%d");
if _item.exSlot==slot or(_item.exSlot..n)==slot then
if not UnEquipItem(v)then
return false;
end
end
end
end
end

do

local oppSlot=const("\235\176\152\235\140\128\236\134\144\236\138\172\235\161\175",slot);
if oppSlot then
local oppGuid=_S["\236\138\172\235\161\175"][oppSlot];
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][oppGuid]then
local oppId=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][oppGuid].id;
local oppType=itemtable[oppId]["\236\162\133\235\165\152"];
if const("\236\150\145\236\134\144\236\138\172\235\161\175",item["\236\162\133\235\165\152"])or const("\236\150\145\236\134\144\236\138\172\235\161\175",oppType)then
if const("\237\131\132\236\149\189\236\162\133\235\165\152",item["\236\162\133\235\165\152"])==oppType or const("\237\131\132\236\149\189\236\162\133\235\165\152",oppType)==item["\236\162\133\235\165\152"]then

else
if not UnEquipItem(oppSlot)then
trace("exSlot UnEquipItem fail");
return false;
end
end
end
end
end
end

if oldBag then
trace("!!\236\164\141\234\184\176\236\139\156\235\143\132");
PickItem(oldBag.guid,oldBag.sdata.item);
end
return true;
end

local t=BeginStorageTxn(type);

if not txn()then
RollbackStorageTxn(t);
else
local old=_S["\236\138\172\235\161\175"][slot];
SetSlotItem(slot,guid);
MoveStorageItem(slot);
Mission("\236\158\165\236\176\169",1,_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id);
if IsStorageSlot(slot)and old~=0 then
DelSlotItem(old);
if not PickItem(nil,old)then
local o=world:createObject("\236\149\132\236\157\180\237\133\156",_S.x,_S.y,{item=old},true);
DelSlotItem(old);
end
end
end
updateSkill();
eventDispatcher:send("PickItem");

end

function BuildItem(recipe,x,y,pick)
local tb=recipetable[recipe];
assert(tb,recipe);
local id=tb["\236\158\165\235\185\132"];
assert(id,tb);
_G["recplv"]=(_S["\235\160\136\236\132\156\237\148\188"][id]or 0);
if tb["\234\184\176\237\131\128\237\154\141\235\147\157"]then
id=math.randlist(tb["\234\184\176\237\131\128\237\154\141\235\147\157"],100)or id;
end
local o,data,guid;


if tb["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
guid,data=MakeItem(id,"\236\149\132\237\139\176\237\140\169\237\138\184\236\160\156\236\158\145");
else
guid,data=MakeItem(id,"\236\160\156\236\158\145");
end
local item=itemtable[data.id];
if tb["\236\131\157\236\130\176\234\176\156\236\136\152"]then
data.c=math.floor(bf((item["\236\162\133\235\165\152"]or"\234\184\176\237\131\128").." \236\131\157\236\130\176 \234\176\156\236\136\152",countkcc(tb["\236\131\157\236\130\176\234\176\156\236\136\152"])));
end
_G["recplv"]=nil;
_S["\236\160\156\236\158\145"][data.id]=(_S["\236\160\156\236\158\145"][data.id]or 0)+1;
Mission("\236\160\156\236\158\145",1,data.id);
SetItemIdIdentity(data.id);
if _S["\236\160\156\236\158\145"][data.id]==1 then
_G["tier"]=ItemTier(guid)or 0;
AddScore(ev("\235\170\168\237\151\152\236\160\144\236\136\152\236\166\157\234\176\128","\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145"));
_G["tier"]=nil;
end

if pick then
guid,data,o=PickOrPlaceItem(guid,x,y);
else
o,data=PlaceItem(guid,x,y);
end
return o,data;
end

function BuildArtifactOrNormalItem(pos,...)
local guid=select(3,...);
local recipe=recipetable[guid];
local id=recipe["\236\158\165\235\185\132"];
if recipe["\236\156\160\237\152\149"]=="\236\149\132\237\139\176\237\140\169\237\138\184"then
local args={...};
local x,y,_,mat1,mat2,tier=table.unpack(args);
local m1=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][mat1];
local m2=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][mat2];
local o,data,itemGuid;
if pos then
o,data,itemGuid=MakeAndPlaceItem(id,x,y);
else
itemGuid,data,o=MakeAndPickItem(id,x,y);
end
local tb=itemtable[id];
if o then
o:fly(pos);
end
data["\237\139\176\236\150\180"]=tier;

data["\235\130\180\234\181\172\235\143\132"]=math.min(const("\236\181\156\235\140\128 \235\130\180\234\181\172\235\143\132"),50+math.floor((m1["\235\130\180\234\181\172\235\143\132"]+m2["\235\130\180\234\181\172\235\143\132"])/2));
local grade="\236\149\132\237\139\176\237\140\169\237\138\184";
if _S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]then
grade=recipe["\235\147\177\234\184\137"];
end
_G.recplv=_S["\235\160\136\236\132\156\237\148\188"][id]or 0;
_G["\237\139\176\236\150\180"]=tier;
local a,b,c=table.unpack(ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \234\176\149\237\153\148 \236\136\152\236\185\152"));
_G.recplv=nil;
_G["\237\139\176\236\150\180"]=nil;
a=bf("\236\160\156\236\158\145\236\139\156 \234\176\149\237\153\148 \234\184\176\235\179\184",a);
b=bf("\236\160\156\236\158\145\236\139\156 \234\176\149\237\153\148 \237\153\149\235\165\160",b);
c=bf("\236\160\156\236\158\145\236\139\156 \234\176\149\237\153\148 \236\181\156\235\140\128",c);
if tb["\236\162\133\235\165\152"]then
a=bf(tb["\236\162\133\235\165\152"].." \234\176\149\237\153\148 \234\184\176\235\179\184",a);
b=bf(tb["\236\162\133\235\165\152"].." \234\176\149\237\153\148 \237\153\149\235\165\160",b);
c=bf(tb["\236\162\133\235\165\152"].." \234\176\149\237\153\148 \236\181\156\235\140\128",c);
end
local b2=bf("\236\160\156\236\158\145\236\139\156 \236\182\148\234\176\128 \234\176\149\237\153\148 \237\153\149\235\165\160");
do

local k2=(m1["\234\176\149\237\153\148"]or 0)+(m2["\234\176\149\237\153\148"]or 0);
local k1=k2/2;
k1,k2=math.min(k1,k2),math.max(k1,k2);
local k=math.floor(0.5+math.max(math.randrange(k1,k2),math.randrange(k1,k2)));
data["\234\176\149\237\153\148"]=k+countkcc({0,b2,1})+countkcc({a,b,c})-countkcc(ev(grade.."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\157\140\236\136\152\234\176\149\237\153\148 \236\136\152\236\185\152"));
end

if math.randpercent(ev("\236\149\132\237\139\176\237\140\169\237\138\184\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\152\181\236\133\152 \237\153\149\235\165\160"))then
local options={};
for k,v in safe_pairs(m1["\236\152\181\236\133\152"])do
if IsExtraOption(mat1,v.id)then
table.insert(options,v.id);
end
end
for k,v in safe_pairs(m2["\236\152\181\236\133\152"])do
if IsExtraOption(mat1,v.id)then
table.insert(options,v.id);
end
end
AddItemOption(nil,itemGuid,table.choice(options));
end
ConsumeItem(mat1);
ConsumeItem(mat2);
elseif recipe["\236\156\160\237\152\149"]=="\236\151\133\234\183\184\235\160\136\236\157\180\235\147\156"then
local x,y,_,cnt,materials=table.unpack({...});
local charge=0;
for k,v in safe_pairs(materials)do
if v["\236\182\169\236\160\132"]then
charge=charge+v["\236\182\169\236\160\132"][1];
end
end
for i=1,cnt or 1,1 do
local o,data=BuildItem(guid,x,y,pos==nil);
if data["\236\182\169\236\160\132"]then
data["\236\182\169\236\160\132"][1]=math.min(data["\236\182\169\236\160\132"][2],charge+1);
end
if o then
o:fly(pos);
end
end
else
local x,y,_,cnt,materials=table.unpack({...});
for i=1,cnt or 1,1 do
local o,data=BuildItem(guid,x,y,pos==nil);
if o then
o:fly(pos);
end
end
end
end


function MakeItemFromDrop(id,p,x,y,dropRare)
trace("MakeItemFromDrop",id,p);
local areaN=_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\236\167\128\236\151\173 \235\178\136\237\152\184"]or 0;
if math.randpercent(p)then
local list={};
for k,v in pairs(drop1table)do
if(v["\236\167\128\236\151\173"]or 0)<=areaN then
local p=v[id];
if p then
list[k]=p;
end
end
end
if not table.empty(list)then
local group=math.randlist(list);
local guid,data=MakeItem(group,dropRare)
local o=PlaceItem(guid,x,y);
return o,data;
end
end
end


function EquipOption(buff,guid,data)
for key,t in pairs(data)do
local value,p,p1,p2,cond,tick,dur,remain,pct;
local param={};
for k,v in pairs(t)do
if k=="\236\136\152\236\185\152"then value=v;
elseif k=="\235\176\156\236\131\157 \237\153\149\235\165\160"then p=v;
elseif k=="\235\130\152\236\151\144\234\178\140 \235\176\156\236\131\157 \237\153\149\235\165\160"then p1=v;
elseif k=="\236\160\129\236\151\144\234\178\140 \235\176\156\236\131\157 \237\153\149\235\165\160"then p2=v;
elseif k=="\236\161\176\234\177\180"then cond=v;
elseif k=="\234\176\132\234\178\169"then tick=v;
elseif k=="\236\167\128\236\134\141\236\139\156\234\176\132"then dur=v;
elseif k=="\237\154\159\236\136\152"then remain=v;
elseif k=="\237\153\149\235\165\160"then pct=v;
elseif k then
param[k]=v;
end
end
if value then
addBuff(buff,key,guid,value,tick,dur,{p=pct or p,p1=p1,p2=p2,cond=cond,r=remain,param=param});
end
end
end

function FindCook(id)
for guid,v in pairs(cooktable)do
if v["\237\131\128\236\158\133"]=="\234\181\172\236\157\180"then
for k,c in pairs(v["\236\158\172\235\163\140"][1])do
if k==id then
return guid;
end
end
end
end
end

function SetCookData(data,materials,cnt)
cnt=cnt or 1;
local item=itemtable[data.id];
if not materials then
materials={};
local tb=cooktable[data.id];
if tb then
for i,t in pairs({tb["\237\130\164\236\158\172\235\163\140"],tb["\236\158\172\235\163\140"]})do
for i,v in safe_pairs(t)do
local list={};
for k,c in pairs(v)do
table.insert(list,{k,c});
end
if list[1]then
local k,c=table.unpack(table.choice(list));
for i=1,c,1 do
local d={id=table.choice(const(k)or k)};
SetCookData(d);
table.insert(materials,d);
end
end
end
end
end
end

local function getV(key)
local v=0;
for i,o in safe_pairs(materials)do
local item=itemtable[o.id];
v=v+(o[key]or item[key]or 0);
end
if item[key]then
if item[key]>=0 and item[key]<1 then
v=math.floor(v*item[key]);
else
v=v+item[key];
end
end
return v/cnt;
end
local keys={"\235\176\176\234\179\160\237\148\148 \234\176\144\236\134\140","\237\148\188\234\179\164\237\149\168 \234\176\144\236\134\140","\235\170\169\235\167\136\235\166\132 \234\176\144\236\134\140","HP\237\154\140\235\179\181","\236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181"};
for k,v in pairs(keys)do
data[v]=bf("\236\154\148\235\166\172 "..v,getV(v));
end
if item["\235\179\180\234\180\128 \234\184\176\234\176\132"]then
local T=(data.T or 0)/item["\235\179\180\234\180\128 \234\184\176\234\176\132"];
local N=1;
trace("T,N",data.id,T,N);
for i,o in safe_pairs(materials)do
local item=itemtable[o.id];
if item["\235\179\180\234\180\128 \234\184\176\234\176\132"]then
T=T+(o.T or 0)/item["\235\179\180\234\180\128 \234\184\176\234\176\132"];
N=N+1;
trace("T,N",o.id,T,N);
end
end
T=T/N;
data.T=item["\235\179\180\234\180\128 \234\184\176\234\176\132"]*T*0.8;
trace("data",data.id,T,N,data.T);
end


for i,o in safe_pairs(materials)do
if string.starts(o.id,"\236\152\164\236\151\188\235\144\156")and math.randpercent(const("\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188\237\153\149\235\165\160"))then
local k=math.randlist(const("\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"));
data["\236\152\164\236\151\188\235\144\156\236\154\148\235\166\172\237\154\168\234\179\188"]=k;
data["\235\175\184\237\153\149\236\157\184"]=true;
break;
end
end
end

function MapOpen(guid)
local data=_S.maps[guid];
if data and not data["\236\151\180\235\166\188"]then
if data["\237\131\128\236\158\133"]=="\237\149\132\235\147\156"then
local tb=maptable[data["\236\167\128\236\151\173"]];
AddScore((tb["\235\170\168\237\151\152\236\160\144\236\136\152"]or 0));
end
data["\236\151\180\235\166\188"]=GetDay();
end
end

function BuildingName(id)
if objecttable[id]then
return objecttable[id].name;
elseif itemtable[id]then
return itemtable[id].name;
else
return _L(id);
end
end


function IsBuildingGroup(groups,id)
if id==groups then
return true;
end
local t=recipetable[id];
if t then
for k,v in safe_pairs(groups)do
if table.find(t["\236\139\156\236\132\164 \234\183\184\235\163\185"],v)then
return true;
end
end
end
end

function InNearBuilding(ids,i,j)
local _,objects=world.player:queryObject({i or _S.x,j or _S.y},1);
if objects then
for k,v in pairs(objects)do
for _,id in safe_pairs(ids)do
local t=recipetable[v.sdata.id];
if id==v.sdata.id or(t and table.find(t["\236\139\156\236\132\164 \234\183\184\235\163\185"],id))then
return true;
end
end
end
end
end

function GetNearStream()
local _,objects=world.player:queryObject({_S.x,_S.y},0);
if objects then
for k,v in pairs(objects)do
if ev("\235\172\188\234\179\181\234\184\137\236\155\144",v.sdata.id)then
return v.sdata.id;
end
end
end

if world.player.legTile==TT.WATER then
return"\235\172\188\237\131\128\236\157\188";
end
end

function SetRequireBuildingText(txt,recipe,tier)
local hasBuilding,list;
if recipe then
local name;
local v=recipe;
local list;
hasBuilding,list=GetRequireBuildingList(recipe.guid,nil,tier,txt~=nil);
local s="";
local i=1;
local id=recipe["\236\158\165\235\185\132"];

if txt and not hasBuilding then
if txt then
s=LabelRichTextItem(_L("\237\149\132\236\154\148 \236\139\156\236\132\164").." : ",0xFFFFFFFF);
for k,v in ipairs(list)do
if not v[2]then
if i>1 then
s=s..", "
end
if v[2]then
s=s..LabelRichTextItem(BuildingName(v[1]),0xFFFFFFFF);
else
s=s..LabelRichTextItem(BuildingName(v[1]),0xFFc00000);
end
i=i+1;
end
end
end
end

do

local req=GetRequireRecipeBuilding(recipe.guid);

if req then
if txt then
if i>1 then
s=s.."<br/>"
end
s=s..LabelRichTextItem(_L("\237\149\132\236\154\148 \234\177\180\236\132\164").." : ",0xFFFFFFFF);
for k,v in pairs(req)do
if i>1 then
s=s..", "
end
s=s..LabelRichTextItem(string.format(_L(k.." %d \234\177\180\236\132\164"),v),0xFFc00000);
i=i+1;
end
end
hasBuilding=false;
end
end

do
local b,req=GetRequireHouse(recipe);
if not b then
if txt then
if i>1 then
s=s.."<br/>"
end
s=s..LabelRichTextItem(_L("\236\132\164\236\185\152 \234\176\128\235\138\165").." : ",0xFFFFFFFF);
s=s..LabelRichTextItem(_L(req),0xFFc00000);
i=i+1;
end
hasBuilding=false;
end
end
if recipe["\236\163\188\235\179\128 \236\139\156\236\132\164"]then
if not InNearBuilding(recipe["\236\163\188\235\179\128 \236\139\156\236\132\164"])then
hasBuilding=false;
if txt then
if i>1 then
s=s.."<br/>"
end
s=s..LabelRichTextItem(_L("\236\163\188\235\179\128 \236\139\156\236\132\164").." : ",0xFFFFFFFF);
s=s..LabelRichTextItem(BuildingName(recipe["\236\163\188\235\179\128 \236\139\156\236\132\164"]),0xFFc00000);
i=i+1;
end
end
end

local maxBuild=GetRecipeMaxBuild(recipe);
if maxBuild and maxBuild<=(_S["\236\132\164\236\185\152"][id]or 0)then
if txt then
if i>1 then
s=s.."<br/>"
end
s=s..LabelRichTextItem(_L("\236\181\156\235\140\128 \236\132\164\236\185\152").." : ",0xFFFFFFFF);
s=s..LabelRichTextItem(maxBuild,0xFFc00000);
i=i+1;
end
hasBuilding=false;
end

if recipe["\235\167\181\236\181\156\235\140\128\236\132\164\236\185\152"]then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local c=0;
for k,v in safe_pairs(_S.maps[mapId].objects)do
if v.id==id then
c=c+1;
end
end
if recipe["\235\167\181\236\181\156\235\140\128\236\132\164\236\185\152"]<=c then
if i>1 then
s=s.."<br/>"
end
s=s..LabelRichTextItem(_L("\235\167\181\236\181\156\235\140\128 \236\132\164\236\185\152").." : ",0xFFFFFFFF);
s=s..LabelRichTextItem(recipe["\235\167\181\236\181\156\235\140\128\236\132\164\236\185\152"],0xFFc00000);
i=i+1;
hasBuilding=false;
end
end

if recipe["\236\160\156\236\158\145 \236\139\156\236\132\164"]then
if not InNearBuilding(recipe["\236\160\156\236\158\145 \236\139\156\236\132\164"])then
hasBuilding=false;
if txt then
if i>1 then
s=s.."<br/>"
end
s=s..LabelRichTextItem(_L("\236\160\156\236\158\145 \236\139\156\236\132\164").." : ",0xFFFFFFFF);
s=s..LabelRichTextItem(BuildingName(recipe["\236\160\156\236\158\145 \236\139\156\236\132\164"]),0xFFc00000);
i=i+1;
end
end
end

if txt then
if i>1 then
txt:SetVisible(true);
txt:SetText(LabelRichText(s));
else
txt:SetVisible(false);

end
end
else
hasBuilding=true;
if txt then
txt:SetVisible(false);
end
end
return hasBuilding;
end

function GetRecipeMaxBuild(recipe)
local t=recipe["\236\181\156\235\140\128 \236\132\164\236\185\152"];
if t then
if type(t)=="table"then
local m=0;
for k,v in pairs(t)do
if(_S["\236\132\164\236\185\152"][k]or 0)>0 then
m=math.max(m,v);
end
end
return m;
else
return t;
end
end
end


_G["_item"]=function(id,c)
for i=1,c or 1,1 do
MakeAndPlaceItem(id);
end
end
_G["_object"]=function(id,x,y)
if objecttable[id]then
local o=world:createObject(id,x or _S.x,y or _S.y);
o:onBuild();
ShowAddedRecipes(id,function()
end,o.guid);
end
end
_G["_monster"]=function(id,c,param)
for i=1,c or 1,1 do
local guid,sdata,o=SpawnMonster(_S.x,_S.y,0,2,id);
table.copy(param,sdata);
trace(guid,sdata);
end
end
_G["_map"]=function(bp,depth)
local list={};
for k,v in pairs(_S.maps)do
if(k==bp or v["\236\132\164\234\179\132\235\143\132"]==bp or v["\237\131\128\236\158\133"]==bp)and v["\236\184\181"]==(depth or v["\236\184\181"])then
table.insert(list,k);
end
end
trace("list",list);
assert(list[1]);
_G.nextMap=table.choice(list);
if _G.nextMap then
root:GotoAndStop("travel");
end
end
_G["_op"]=function(opid)
for k,slot in pairs(GetAvailSlots())do
local guid=_S["\236\138\172\235\161\175"][slot];
if guid~=0 then
local data=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local item=itemtable[data.id];
local v=optiontable[opid];
if v then
local p=v["("..data.id..")"]or v["("..item["\236\162\133\235\165\152"]..")"];
if p then
AddItemOption(function()end,guid,opid)
break;
end
end
end
end
end

_G["_weapon"]=function(id,tier,u,...)
local guid,data=MakeItem(id);
data["\234\176\149\237\153\148"]=u or 0;
data["\237\139\176\236\150\180"]=tier;
data["\235\175\184\237\153\149\236\157\184"]=nil;
DelItemOption(nil,guid,"\236\160\128\236\163\188");
DelItemOption(nil,guid,"\236\182\149\235\179\181");
for k,opid in safe_pairs({...})do
AddItemOption(function()end,guid,opid)
end
PlaceItem(guid,_S.x,_S.y);
end

_G["_magic"]=function(id)
if spelltable[id]and string.ends(spelltable[id]["\237\131\128\236\158\133"],"\235\167\136\235\178\149")then
table.insert(_S["\236\149\148\234\184\176\235\167\136\235\178\149"],id);
_S["\235\167\136\235\178\149"][id]=math.min(const("\236\181\156\235\140\128\235\167\136\235\178\149\235\160\136\235\178\168"),(_S["\235\167\136\235\178\149"][id]or 0)+1);
if#_S["\236\149\148\234\184\176\235\167\136\235\178\149"]>const("\236\181\156\235\140\128\236\149\148\234\184\176\235\167\136\235\178\149")then
table.remove(_S["\236\149\148\234\184\176\235\167\136\235\178\149"],1);
end
world:updateMenu();
return id;
end
end
_G["_skill"]=function(id)
if skilltable[id]then
DefaultSkills={id};
updateSkill();
world:updateMenu();
end
end

_G["_debuff"]=function(id)
return world.player:addDebuf(id);
end

_G["_particle"]=function(id)
return world.player:addParticle(id);
end

_G["_tz"]=function(id)
while GetTimeZone()~=id do
_S.T=_S.T+10;
end
end

_G["_turn"]=function(c)
local function f()
if c>0 then
if world.player:isWaitTurn()then
c=c-1;
world.player:beganTurn("next");
end
return true;
end
end
mainTimer.add(f,f);
end
_G["_spell"]=function(id)
if spelltable[id]then
local function onSpellEnd(b)
end
world.player:useSpell(id,onSpellEnd);
end
end

_G["_room"]=function(id)
local list={};
for k,v in safe_pairs(_S["\234\179\160\236\160\149\235\176\169"][id])do
if not _S.maps[v].data then
table.insert(list,v);
end
end
_G.nextMap=table.choice(list);
_G.nextMapFromElevator=id;
if _G.nextMap then
root:GotoAndStop("travel");
end
end

_G["_fo"]=function(id)
local list={};
for k,v in pairs(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][id])do
if not v.data then
table.insert(list,v.mapId);
end
end
assert(list[1]);
_G.nextMap=table.choice(list);
_G.nextMapFromElevator=id;
if _G.nextMap then
root:GotoAndStop("travel");
end
end

_G["_exp"]=function(exp)
world.player:addExp(nil,exp);
end

_G["_maplevel"]=function(lv)
if lv then
_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\235\167\181 \235\160\136\235\178\168"]=lv;
end
trace(_S.maps[_S["\237\152\132\236\158\172\235\167\181"]]["\235\167\181 \235\160\136\235\178\168"]);
end

_G["_time"]=function(t)
UpdateGame(t);
end


function totiernumber(n)
return math.floor(n*2+0.5)/2;
end

local function GetRelicPos()
local list={};
for i=1,6 do
if(_D["\236\156\160\236\160\129"]["g"..i]or"")==""then
table.insert(list,"g"..i);
end
end
if#list==0 then
for i=1,#const("\235\161\156\235\185\132\236\156\160\236\160\129\236\156\132\236\185\152")do
if(_D["\236\156\160\236\160\129"]["g"..i]or"")==""then
table.insert(list,"g"..i);
end
end
end
return table.choice(list);
end
local function GetRelicSeq()
local newSeed=_S.seed;
while true do
newSeed=math.random(0x7FFFFFFF);
if newSeed~=_S.seed and not table.find(_D["\236\156\160\236\160\129seq"],newSeed)then
break;
end
end
local seq=_S.seed;
_S.seed=newSeed;
return seq;
end

function MakeRelicForReborn(from)
local ids={};
local n=ev("\237\153\152\236\131\157\235\179\180\236\131\129\236\136\152",from.sdata.id);
local reward=ev("\237\153\152\236\131\157\235\179\180\236\131\129",from.sdata.id);
local n2=ev("\237\153\152\236\131\157\235\179\180\236\131\129\234\179\160\236\160\149",from.sdata.id);
for i=1,n do
table.insert(ids,math.randlist(reward));
end
for k,v in pairs(n2)do
for i=1,v do
table.insert(ids,k);
end
end

local list={};
for i,id in ipairs(ids)do
local pos=GetRelicPos();
local seq=GetRelicSeq();
if pos then
_D["\236\156\160\236\160\129"][pos]=id;
_D["\236\156\160\236\160\129seq"][pos]=seq;
end
table.insert(list,{id,pos});
end
_G.newRelic=list;

return list;
end


function MakeRelic(gameover)
local ids={};
local cnt=math.max(0,math.floor((_S["\235\170\168\237\151\152\236\160\144\236\136\152"]-_S["\236\130\172\236\154\169\236\160\144\236\136\152"])/ev("\237\149\132\236\154\148\235\170\168\237\151\152\236\160\144\236\136\152")));
if gameover then
cnt=cnt+1;
end
for i=1,cnt do
do


local pos=GetRelicPos();
local seq=GetRelicSeq();
local total=0;
for k,v in pairs(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1601"))do
total=total+(_D["\236\156\160\236\160\129\235\147\177\236\158\165"][k]or 0);
end
for k,v in pairs(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1601"))do
_G[k.." \235\175\184\235\147\177\236\158\165"]=total-(_D["\236\156\160\236\160\129\235\147\177\236\158\165"][k]or 0);
end

local id;
if gameover=="clear"and i==cnt then
local e=_S["\236\151\148\235\148\169"];
if _D["\236\151\148\235\148\169"][e]==1 then
id=math.randlist(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1604"));
else
id=math.randlist(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1603"));
end
elseif gameover and i==cnt then
id=math.randlist(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1602"));
else
id=math.randlist(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1601"));
end
if table.empty(_D["\236\156\160\236\160\129\235\147\177\236\158\165"])then
id="\236\152\164\235\158\152\235\144\156 \236\156\160\236\160\129";
end

if pos then
_D["\236\156\160\236\160\129"][pos]=id;
_D["\236\156\160\236\160\129seq"][pos]=seq;
end
_D["\236\156\160\236\160\129\235\147\177\236\158\165"][id]=(_D["\236\156\160\236\160\129\235\147\177\236\158\165"][id]or 0)+1;
table.insert(ids,{id,pos});
for k,v in pairs(ev("\236\156\160\236\160\129\235\147\177\236\158\165\237\153\149\235\165\1601"))do
_G[k.." \235\175\184\235\147\177\236\158\165"]=nil;
end
end
_S["\236\130\172\236\154\169\236\160\144\236\136\152"]=_S["\236\130\172\236\154\169\236\160\144\236\136\152"]+ev("\237\149\132\236\154\148\235\170\168\237\151\152\236\160\144\236\136\152")
end
_G.newRelic=ids;
return ids,cnt;
end


function ToOptionValueString(k,v)

do
local postFix={" \236\166\157\234\176\128"," \234\176\144\236\134\140","\235\176\156\236\131\157 \237\153\149\235\165\160"," \234\176\149\237\153\148 \237\153\149\235\165\160"," \235\160\136\236\150\180 \236\149\132\236\157\180\237\133\156 \237\153\149\235\165\160","\236\160\156\236\158\145\236\158\172\235\163\140 \234\176\144\236\134\140 \237\153\149\235\165\160"," \236\182\148\234\176\128 \237\153\149\235\165\160"," \234\176\144\236\134\140\235\159\137"};
for _,s in pairs(postFix)do
if string.ends(k,s)then
return k,tostringf(v*100).."%";
end
end
end


if ev(k)then
return k,tostringf(v);
end


local postFix={"\236\154\148\234\181\172 \237\158\152","\236\166\157\234\176\128\235\159\137","\235\141\176\235\175\184\236\167\128","\234\176\156\236\136\152","\235\176\152\234\178\169","\237\154\140\235\179\181","\236\160\129\236\164\145","\234\180\128\237\134\181","\235\179\180\235\132\136\236\138\164","\236\151\144\235\132\136\236\167\128","\236\130\172\236\154\169\235\159\137","\236\160\128\237\149\173","\237\154\140\237\148\188","\237\129\172\235\166\172\237\139\176\236\187\172","\236\151\176\236\134\141 \234\179\181\234\178\169","\236\181\156\235\140\128","\236\191\168\237\131\128\236\158\132","\237\148\188\237\149\180","\236\139\156\234\176\132","\236\139\156\236\149\188","\234\176\132\234\178\169"};
for _,s in pairs(postFix)do
if string.ends(k,s)then
return k,tostringf(v);
end
end


do
local postFix={" \237\153\149\235\165\160"};
for _,s in pairs(postFix)do
if string.ends(k,s)then
return k,tostringf(v).."%";
end
end
end

return k,tostringf(v*100).."%";
end

function HasTotem(id)
return(_D["\237\134\160\237\133\156\235\160\136\235\178\168"][id]or 0)>0 or(_D["\237\134\160\237\133\156"][id]or 0)>0;
end

function TotemPriority(id)
local dict={["\236\131\157\236\161\180"]=1,["\236\160\132\237\136\172"]=2,["\235\167\136\235\178\149"]=3,["\235\133\184\235\167\144"]=1,["\235\160\136\236\150\180"]=2,["\236\151\144\237\148\189"]=3,["\235\160\136\236\160\132\235\147\156"]=4};
local has=HasTotem(id)and 0 or 1;
if totemtable[id]then
local t=totemtable[id];
return{has,dict[t["\235\182\132\235\165\152"]],dict[t["\235\147\177\234\184\137"]],t.img};
elseif recipetable[id]then
local t=recipetable[id];
return{has,dict[t["\235\147\177\234\184\137"]],dict[t["\236\162\133\235\165\152"]],t.guid};
end
end

function EatItem(o)
trace("EatItem",o);
local item=itemtable[o.id];
local function getV(key)
return o[key]or item[key]or 0;
end
local mT=1;
if item["\235\179\180\234\180\128 \234\184\176\234\176\132"]then
local T=math.min(1,(o.T or 0)/item["\235\179\180\234\180\128 \234\184\176\234\176\132"]);
local P=T*100;
mT=1-T*const("\236\131\129\237\149\156\236\160\149\235\143\132\237\154\168\234\179\188\234\176\144\236\134\140");
if(P>=const("\236\131\129\237\149\156\236\160\149\235\143\132\236\139\157\236\164\145\235\143\133\237\153\149\235\165\160")[1]and math.randpercent(P+const("\236\131\129\237\149\156\236\160\149\235\143\132\236\139\157\236\164\145\235\143\133\237\153\149\235\165\160")[2]))
or(P>=100 and math.randpercent(ev("\236\131\129\237\149\156\236\157\140\236\139\157\236\139\157\236\164\145\235\143\133\237\153\149\235\165\160")))then
world.player:setDiseaseP("\236\139\157\236\164\145\235\143\133");
end
end
do
local v=bf("\236\157\140\236\139\157 \235\176\176\234\179\160\237\148\148 \234\176\144\236\134\140\235\159\137",getV("\235\176\176\234\179\160\237\148\148 \234\176\144\236\134\140"));
_S:add("\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184",v*mT,0,const("\236\154\169\235\179\128\237\143\172\236\157\184\237\138\184\236\136\152\236\185\152")[2]);
local cv=-_S:add("\237\151\136\234\184\176",-v*mT,0,bf("\236\181\156\235\140\128 \235\176\176\234\179\160\237\148\148"));
do
local e=bf("\235\176\176\234\179\160\237\148\148 \234\176\144\236\134\140\236\139\156 \236\151\144\235\132\136\236\167\128 \236\166\157\234\176\128")*v*mT;
world.player:healEnergy(e);
end
do
local _,param=bf("\235\176\176\234\179\160\237\148\148 \234\176\144\236\134\140\236\139\156 HP \236\166\157\234\176\128");
if param then
for kk,vv in pairs(param)do
if spelltable[kk]and spelltable[kk]["\236\167\128\236\134\141\236\139\156\234\176\132\234\176\144\236\134\140"]then
reduceBuffDur(world.player.buff,kk,spelltable[kk]["\236\167\128\236\134\141\236\139\156\234\176\132\234\176\144\236\134\140"]*cv);
end
world.player:heal(vv.c*cv);
end
end



end

if _S["\237\151\136\234\184\176"]<=0 then
local v,param=world.player:bf("\237\143\172\235\167\140\236\139\156 \236\163\188\235\138\148\237\148\188\237\149\180 \236\166\157\234\176\128");
if param then
for k,v in pairs(param)do
world.player:addBuff("\236\163\188\235\138\148\237\148\188\237\149\180 \236\166\157\234\176\128",k,v.c,nil,v["\236\139\156\234\176\132"]);
end
end
end
end

do
local v=bf("\236\157\140\236\139\157 \237\148\188\234\179\164\237\149\168 \234\176\144\236\134\140",getV("\237\148\188\234\179\164\237\149\168 \234\176\144\236\134\140"));
_S:add("\237\148\188\235\161\156\235\143\132",-v*mT,0,(bf("\236\181\156\235\140\128 \237\148\188\234\179\164\237\149\168")));
end
do
local v=bf("\236\157\140\236\139\157 \235\170\169\235\167\136\235\166\132 \234\176\144\236\134\140",getV("\235\170\169\235\167\136\235\166\132 \234\176\144\236\134\140"));
_S:add("\234\176\136\236\166\157",-v*mT,0,(bf("\236\181\156\235\140\128 \235\170\169\235\167\136\235\166\132")));
end
do
local max=bf("\236\181\156\235\140\128 \236\131\157\235\170\133\235\160\165");
local v=bf("\236\157\140\236\139\157 HP\237\154\140\235\179\181",getV("HP\237\154\140\235\179\181"));
_S:add("\236\131\157\235\170\133\235\160\165",max*v/100*mT,0,max);
end
do
local max=bf("\236\181\156\235\140\128 \236\151\144\235\132\136\236\167\128");
local v=bf("\236\157\140\236\139\157 \236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181",getV("\236\151\144\235\132\136\236\167\128 \237\154\140\235\179\181"));
_S:add("\236\151\144\235\132\136\236\167\128",max*v/100*mT,0,max);
end

if item["\236\162\133\235\165\152"]=="\235\172\188\236\149\189"then
if FindItemOption(o,"\236\182\149\235\179\181")then
world.player:addDebuf("\236\182\149\235\179\181\236\157\152 \234\184\176\236\154\180");
end
if FindItemOption(o,"\236\160\128\236\163\188")then
world.player:setDiseaseP("\235\167\136\235\160\165 \236\164\145\235\143\133");
end
end
end


function MakeWaterBottle(guid,fromId,from)
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=o.id;
local item=itemtable[id];
local t=ev("\235\172\188\234\179\181\234\184\137\236\155\144",fromId);
local idx=math.randlist(t);

if item["\235\172\188\235\156\168\234\184\176"]then
ConsumeItem(guid);
local v=item["\235\172\188\235\156\168\234\184\176"][idx];
if from then
local o=MakeAndPlaceItem(v);
o:fly(from.pos);
else
MakeAndPickItem(v);
end
elseif item["\235\185\132\236\154\176\234\184\176"]then
local bottle=itemtable[item["\235\185\132\236\154\176\234\184\176"]];
local v=bottle["\235\172\188\235\156\168\234\184\176"][idx];
ConsumeItem(guid);
if from then
local o=MakeAndPlaceItem(v);
o:fly(from.pos);
else
MakeAndPickItem(v);
end
end

end

function SortRecipes(list)
local function priority(a)
local o=itemtable[a["\236\158\165\235\185\132"]]or objecttable[a["\236\158\165\235\185\132"]];
return{a.priority or 0,-(_S["\235\160\136\236\132\156\237\148\188"][a.guid]or 0),a["\237\139\176\236\150\180"]or 0,a["\236\139\156\236\132\164 \235\160\136\235\178\168"]or 0,a["\237\149\132\236\154\148 \236\139\156\236\132\164"]or"_",o.name};
end

local function cmp_priority(a,b)
local p1=priority(a);
local p2=priority(b);
for k,v in ipairs(p1)do
if v~=p2[k]then
if type(v)=="string"then
return utf8cmp(v,p2[k])<0;
else
return v<p2[k];
end
end
end
end

table.sort(list,function(a,b)
return cmp_priority(a,b);
end);
end

function AddBuilding(id,guid)
local t=objecttable[id];
if t then
if not _S["\236\132\164\236\185\152"][id]then
AddScore(ev("\235\170\168\237\151\152\236\160\144\236\136\152\236\166\157\234\176\128","\234\177\180\235\172\188\236\132\164\236\185\152"));
end

_S["\236\132\164\236\185\152"][id]=(_S["\236\132\164\236\185\152"][id]or 0)+1;
_S["\236\160\156\236\158\145"][id]=(_S["\236\160\156\236\158\145"][id]or 0)+1;

if t["\235\176\156\234\178\172"]then
_S["\236\132\164\236\185\152\235\167\181"][id]=_S["\236\132\164\236\185\152\235\167\181"][id]or{};
table.insert(_S["\236\132\164\236\185\152\235\167\181"][id],{_S["\237\152\132\236\158\172\235\167\181"],guid});
end
if _S["\236\132\164\236\185\152"][id]==1 then
local t=objecttable[id];
if t then
if t["\236\132\164\236\185\152\235\178\132\237\148\132"]then
for k,v in pairs(t["\236\132\164\236\185\152\235\178\132\237\148\132"])do
world.player:addBuff(k,id,v);
end
end
end
end
end
end

function DelBuilding(id,guid,mapId)
mapId=mapId or _S["\237\152\132\236\158\172\235\167\181"];
local t=objecttable[id];
if t then
if(_S["\236\132\164\236\185\152"][id]or 0)>0 then
_S["\236\132\164\236\185\152"][id]=_S["\236\132\164\236\185\152"][id]-1;
if _S["\236\132\164\236\185\152"][id]==0 then
world.player:delBuff(nil,id);
end
end

if _S["\236\132\164\236\185\152\235\167\181"][id]then
for k,v in ipairs(_S["\236\132\164\236\185\152\235\167\181"][id])do
if v[2]==guid then
table.remove(_S["\236\132\164\236\185\152\235\167\181"][id],k);
break;
end
end
end

table.findAndRemove(_S["\235\176\156\234\178\172\235\167\181"][mapId],guid);
end
end



function ShowAddedRecipes(id,cb,objectGuid)
local recipes={};
local tb=recipetable[id];
if tb then
if tb["\236\162\133\235\165\152"]then
local tp=tb["\236\162\133\235\165\152"];
_D["\236\162\133\235\165\152\235\179\132\236\160\156\236\158\145\237\154\159\236\136\152"][tp]=(_D["\236\162\133\235\165\152\235\179\132\236\160\156\236\158\145\237\154\159\236\136\152"][tp]or 0)+1;
end
_D["\236\180\157\236\160\156\236\158\145\237\154\159\236\136\152"][id]=(_D["\236\180\157\236\160\156\236\158\145\237\154\159\236\136\152"][id]or 0)+1;
end

do
if objecttable[id]then
for k,v in safe_ipairs(objecttable[id]["\236\132\164\236\185\152\236\157\180\235\166\132"]or id)do
AddBuilding(v,objectGuid);
end
end
for k,v in safe_pairs(_S["\235\158\156\235\141\164 \235\160\136\236\132\156\237\148\188"][id])do
if AddRecipe(k)then
local r=recipetable[k];
if not table.find(recipes,r)then
table.insert(recipes,r);
end
end
end
end

SortRecipes(recipes);


local newTab={};
local list={{},{},{title=_L("\236\160\156\236\158\145 \236\139\156\236\132\164\236\157\180 \236\153\132\236\132\177\235\144\152\236\151\136\236\138\181\235\139\136\235\139\164")}};
for k,v in ipairs(recipes)do
_S["\235\137\180\235\160\136\236\132\156\237\148\188"][v.guid]=(_S["\235\137\180\235\160\136\236\132\156\237\148\188"][v.guid]or 0)+1;
for i,tab in pairs(const("\236\160\156\236\158\145\237\131\173\235\170\169\235\161\157"))do
if v["\237\131\173"]and table.find(tab,v["\237\131\173"])then
newTab[i]=(newTab[i]or 0)+1;
end
end
if v["\236\158\165\235\185\132"]and objecttable[v["\236\158\165\235\185\132"]]then
table.insert(list[1],v);
else
table.insert(list[2],v);
end
end


if objecttable[id]then
for k,v in pairs(recipetable)do
for _,id in safe_ipairs(objecttable[id]["\236\132\164\236\185\152\236\157\180\235\166\132"]or id)do
if table.find(v["\234\184\176\235\176\152 \236\139\156\236\132\164"],id)and(_S["\235\160\136\236\132\156\237\148\188"][k]or 0)>0 and(_S["\236\132\164\236\185\152"][id]or 0)>0 then
if table.find(recipes,v)or _S["\236\132\164\236\185\152"][id]==1 then
table.insert(list[3],v);
end
end
end
end
end
SortRecipes(list[3]);
world:updateMenu();

local function _cb()
if objectGuid then
local function f()
local o=world.objects[objectGuid];
if o then
assert(o.canvas);
Tutorial(world.ui.menu,"\236\152\164\235\184\140\236\160\157\237\138\184\234\177\180\236\132\164",{id=id,["\236\152\164\235\184\140\236\160\157\237\138\184"]={o.canvas}});
Mission("\234\177\180\236\132\164",1,id);
end
end
world.timer.add(f,f);
end
cb();
end


do
local btns={};
for i,c in pairs(newTab)do
table.insert(btns,"\236\167\147\234\184\176"..i);
end
Tutorial(world.ui.menu,"\235\137\180\235\160\136\236\132\156\237\148\188",{id=id,["\237\153\148\236\130\180\237\145\156"]=btns});
if lang["\236\136\152\235\166\172\236\132\177\234\179\181_"..id]then
world.player:addChat(lang["\236\136\152\235\166\172\236\132\177\234\179\181_"..id]);
end
end

if#list[1]>0 or#list[2]>0 or#list[3]>0 then
local i=0;
local function f()
while true do
i=i+1;
if not list[i]then
_cb();
break;
elseif#list[i]>0 then
GetRecipePopup(f,list[i],list[i].title);
break;
end
end
end
world.player:playSndQueue("\236\160\156\236\158\145");
f();
else
if cb then
_cb();
end
end
end


function GetTotemDetail(id,lv)
local tb=totemtable[id];
local keys={};
if tb then
table.insert(keys,{LabelRichTextItem(tb["\236\132\164\235\170\133"],0xFFFFFFFF)});


_G.lv=lv;















for i=1,9 do
local key=tb["\237\154\168\234\179\188"..i];
if key then
local t=tb["\237\154\168\234\179\188"..i.."_\236\136\152\236\185\152"];

for k,v in pairs(t)do
if k=="\236\139\156\234\176\132"or k=="\237\154\168\234\179\188"then
elseif k=="\235\170\169\235\161\157"then
for _,kk in ipairs(table.sortedkeys(v))do
local vv=v[kk];
table.insert(keys,{LabelRichTextItem(itemtable[kk].name..": ",0xFFFFFFFF),LabelRichTextItem(tostringf(vv).."%",0xFFc0c000)});
end
elseif k=="\236\161\176\234\177\180"then
if type(v)=="table"then
if v["\236\160\129\236\131\157\235\170\133\235\160\165\236\157\180\237\149\152"]then
table.insert(keys,{LabelRichTextItem(_L("\236\160\129\236\131\157\235\170\133\235\160\165\236\157\180\237\149\152")..": ",0xFFFFFFFF),LabelRichTextItem(tostringf(v["\236\160\129\236\131\157\235\170\133\235\160\165\236\157\180\237\149\152"]*100).."%",0xFFc0c000)});
end
end
else
local _k=k;
if k=="\236\136\152\236\185\152"then _k=key;end
_k,v=ToOptionValueString(_k,v);
table.insert(keys,{LabelRichTextItem(_L(_k)..": ",0xFFFFFFFF),LabelRichTextItem(v,0xFFc0c000)});
end
end
end
end
_G.lv=nil;
else
local item=itemtable[id];
local tb=recipetable[id];
local _1=item.name;
local dict={};
dict["{1}"]=_1;
dict["{\236\157\132}"]=SelectJosa(_1,{"\236\157\132","\235\165\188"});
_G.recplv=lv;
_G["\237\139\176\236\150\180"]=item["\237\139\176\236\150\180"]or 0;

table.insert(keys,{ReplaceString(_L("\237\134\160\237\133\156\236\160\156\236\158\145\235\178\149\236\132\164\235\170\133"),dict)});
local v=tostringf(ev(tb["\235\147\177\234\184\137"].."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\158\172\235\163\140\234\176\144\236\134\140")*100).."%";
table.insert(keys,{LabelRichTextItem(_L("\236\158\172\235\163\140\234\176\144\236\134\140 \237\153\149\235\165\160")..": ",0xFFFFFFFF),LabelRichTextItem(v,0xFFc0c000)});
local v=tostringf(ev(tb["\235\147\177\234\184\137"].."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \236\158\172\235\163\140\234\176\144\236\134\140\235\159\137")*100).."%";
table.insert(keys,{LabelRichTextItem(_L("\236\158\172\235\163\140 \236\181\156\235\140\128 \234\176\144\236\134\140\235\159\137")..": ",0xFFFFFFFF),LabelRichTextItem(v,0xFFc0c000)});
local p1,p2,p3=table.unpack(ev(tb["\235\147\177\234\184\137"].."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \234\176\149\237\153\148 \236\136\152\236\185\152"));
local v=p1;
if v>=1 then v=p2;end
v=tostringf(v*100).."%";
table.insert(keys,{LabelRichTextItem(_L("\234\176\149\237\153\148 \237\153\149\235\165\160")..": ",0xFFFFFFFF),LabelRichTextItem(v,0xFFc0c000)});
if ev(tb["\235\147\177\234\184\137"].."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \235\160\136\236\150\180 \237\153\149\235\165\160")>0 then
local v=tostringf((1+ev(tb["\235\147\177\234\184\137"].."\236\149\132\236\157\180\237\133\156\236\160\156\236\158\145 \235\160\136\236\150\180 \237\153\149\235\165\160"))*(item["\235\160\136\236\150\180 \237\153\149\235\165\160"]or 0)).."%";
table.insert(keys,{LabelRichTextItem(_L("\235\160\136\236\150\180 \237\153\149\235\165\160")..": ",0xFFFFFFFF),LabelRichTextItem(v,0xFFc0c000)});
end
_G.recplv=nil;
_G["\237\139\176\236\150\180"]=nil;
end
return keys;
end

function NewTorch(T)
_S["\237\154\131\235\182\136T"]=math.min(const("\236\181\156\235\140\128\237\154\131\235\182\136\236\139\156\234\176\132"),_S["\237\154\131\235\182\136T"]+T);
_S["\237\154\131\235\182\136\235\170\168\235\147\156"]="\237\154\131\235\182\136";
end

function HasTorch()
return _S["\237\154\131\235\182\136\235\170\168\235\147\156"]~="\234\184\176\235\179\184";
end

function DelTorch()
_S["\237\154\131\235\182\136\235\170\168\235\147\156"]="\234\184\176\235\179\184";
_S["\237\154\131\235\182\136T"]=0;
end

function EquipTotem(buff)
delBuffFromGuid(buff,"totem");

local recipetable=require"data.recipetable";
for id,cnt in pairs(_D["\237\134\160\237\133\156"])do
local v=recipetable[id];
if v then

if _S["\235\160\136\236\132\156\237\148\188"][id]and(_S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]or 0)==0 then
local grade=v["\235\147\177\234\184\137"];
local p=servertable.TotemMaxLv[grade]/servertable.TotemMaxLv["\236\158\165\235\185\132"];
_S["\235\160\136\236\132\156\237\148\188"][id]=math.floor(_S["\235\160\136\236\132\156\237\148\188"][id]*p);
end
local diff=(_S["\235\160\136\236\132\156\237\148\188"][id]or 1)-(_S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]or 1);
_S["\235\160\136\236\132\156\237\148\188"][id]=(_D["\237\134\160\237\133\156\235\160\136\235\178\168"][id]or 1)+math.max(0,diff);
_S["\235\189\145\234\184\176\235\160\136\236\132\156\237\148\188"][id]=(_D["\237\134\160\237\133\156\235\160\136\235\178\168"][id]or 1);
end
end

for i,id in ipairs(_S["\236\158\165\236\176\169\237\134\160\237\133\156"])do
local tb=totemtable[id];
if tb then
_G.lv=(_D["\237\134\160\237\133\156\235\160\136\235\178\168"][id]or 1);
local data={};
for i=1,9 do
local k=tb["\237\154\168\234\179\188"..i];
if k then
local v=tb["\237\154\168\234\179\188"..i.."_\236\136\152\236\185\152"];
assert(v);
data[k]=table.copy(v);
else
break;
end
end
_G.lv=nil;
EquipOption(buff,"totem",data);
end
end
end

function AddScore(v)
_S["\235\170\168\237\151\152\236\160\144\236\136\152"]=_S["\235\170\168\237\151\152\236\160\144\236\136\152"]+v;
SetHighscore("\235\170\168\237\151\152\236\160\144\236\136\152",math.floor(_S["\235\170\168\237\151\152\236\160\144\236\136\152"]));
end

function GetObjectTBandGen(mapId,tb)
local TB=0;
local gen=0;
local dgtype=_S.maps[mapId]["\235\141\152\236\160\132\237\131\128\236\158\133"];
local mapTile=_S.maps[mapId]["\234\181\172\236\132\177"];
local area=_S.maps[mapId]["\236\167\128\236\151\173"];


if dgtype then
gen=(tb["g"..dgtype]or 0);
else
gen=tb["g"..area]or 0;
end

if gen>0 then
if dgtype then
TB=tb["t\235\141\152\236\160\132"]or 0;
else
TB=mapTile and tb["t"..mapTile]or 0;
end
end

return TB,gen;
end

function CanRepairMaterial(target,guid)
if target~=guid then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid];
local id=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][target].id;
local t1=itemtable[o.id]["\236\162\133\235\165\152"];
local t2=itemtable[id]["\236\162\133\235\165\152"];
if t1 and repairtable[t1]and repairtable[t1][t2]then
return true;
end
end
end

function TileDistance(i,j,x,y)
return math.max(math.abs(i-x),math.abs(j-y));
end

function ChoiceBookSpell()
local keys={};
for i=1,3,1 do
local lv=math.randlist(ev("\235\167\136\235\178\149\236\177\133\235\167\136\235\178\149\235\170\169\235\161\157"));
local list={};
for k,v in pairs(spelltable)do
if v["\235\139\168\234\179\132"]==lv and string.ends(v["\237\131\128\236\158\133"],"\235\167\136\235\178\149")and not table.find(keys,k)then
_G["\235\167\136\235\178\149\235\160\136\235\178\168"]=(_S["\235\167\136\235\178\149"][k]or 0);
list[k]=ev("\235\167\136\235\178\149\236\177\133\235\167\136\235\178\149\237\153\149\235\165\160");
_G["\235\167\136\235\178\149\235\160\136\235\178\168"]=nil;
end
end
table.insert(keys,math.randlist(list));
end
return keys;
end

function AddMagicLv(key,c)
c=c or 1;
local lv=_S["\235\167\136\235\178\149"][key]or 0;
for i=1,c do
if lv<const("\236\181\156\235\140\128\235\167\136\235\178\149\235\160\136\235\178\168")then
if math.randpercent(ev("\235\167\136\235\178\149\235\160\136\235\178\168\237\153\149\235\165\160",lv+1))then
lv=lv+1;
end
end
end
if _S["\235\167\136\235\178\149"][key]~=lv then
_S["\235\167\136\235\178\149"][key]=lv;
return true;
end
end

function AreaTBNumber(tb)
if type(tb)=="table"then
local mapId=_S["\237\152\132\236\158\172\235\167\181"];
local area=_S.maps[mapId]["\236\167\128\236\151\173"];
local type=_S.maps[mapId]["\237\131\128\236\158\133"];
local bp=_S.maps[mapId]["\236\132\164\234\179\132\235\143\132"];
return tb[bp]or tb[type]or tb[area]or tb["\234\184\176\237\131\128"]or tb;
end
return tb;
end

function AddMagicLevelIcon(img,lv)
local lv1=math.min(10,lv);
local lv2=math.max(0,lv-lv1);
if lv2>0 then
AddCoolIcon(img,lv2,10,95,(100-10*8)/2,1,"info_charge_2.png",true,0,8,nil,"cool2",80,nil,nil,nil,"info_charge.png");
else
AddCoolIcon(img,lv1,10,95,(100-10*8)/2,1,"info_charge.png",true,0,8,nil,"cool1",80);
end
end