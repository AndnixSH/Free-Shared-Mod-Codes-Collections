function SetPercent(this,p,txt)
if p>100 then p=100;end
if p<0 then p=0;end
this:GotoAndStop(p*this:GetTotalFrame()/100);
this.txtP:SetText(txt);
end

function SetPercent2(this,p,v)

if p>1 then p=1;end
if p<0 then p=0;end
local x,y,cx,cy=this.img:GetBound();
if p>0 then
this.img:SetVisible(true);
this.img:SetClipRect(0,0,cx*p,cy);
else
this.img:SetVisible(false);
end
if this.txtP then
this.txtP:SetText(string.format("%d%%",p*100));
end
if v and this.txt then
this.txt:SetText(v);
end
this.p=p;
end

function SetVPercent(this,p,hm)

if p>1 then p=1;end
if p<0 then p=0;end
hm=hm or 0;
if this.p~=p then
local x,y,cx,cy=this.img:GetBound();
if p>0 then
local d=hm+math.floor((cy-hm*2)*(1-p));
this.img:SetVisible(true);
this.img:SetClipRect(0,d,cx,cy-d-hm);
this.img:SetY(d);
else
this.img:SetVisible(false);
end
if this.txtP then
this.txtP:SetText(string.format("%d%%",p*100));
end

this.p=p;
end
end


function SetPercent3(this,p,v)

if p>1 then p=1;end
if p<0 then p=0;end
local x,y,cx,cy=this.img:GetBound();
if p>0 then
this.img:SetVisible(true);
this.img:SetClipRect(0,0,cx*p,cy);
if v and this.img.txt then
this.img.txt:SetText(v);
end
else
this.img:SetVisible(false);
end
if v and this.txt then
this.txt:SetText(v);
end
end



function SetVPercentDiff(this,p,a,hm,timer)
if p>1 then p=1;end;
if p<0 then p=0;end;
hm=hm or 0;
a=a or 0;
if a>0 then a=0;end;



if this.p~=p then
local x,y,cx,cy=this.img:GetBound();
if p>0 then
local d=hm+math.floor((cy-hm*2)*(1-p));
this.img:SetVisible(true);
this.img:SetClipRect(0,d,cx,cy-d-hm);
this.img:SetY(d);
else
this.img:SetVisible(false);
end
if this.txtP then
this.txtP:SetText(string.format("%d%%",p*100));
end

if this.p and this.diff then
if this.p>p then
local d=hm+math.floor((cy-hm*2)*(1-this.p));
this.diff:SetClipRect(0,d,cx,(cy-hm*2)*(this.p-p));
this.diff:SetY(d);
else
local d=math.floor((cy-hm*2)*(1-p));
this.diff:SetClipRect(0,d,cx,(cy-hm*2)*(p-this.p));
this.diff:SetY(d);
end

local function f(o,v)
this.diff:SetAlphaDepth(v);
end
local tweener=Tweener(this.diff,f,1,0,0.5,0,inQuad);
timer.add(this.diff,tweener.update);
tweener.update(0);
else
this.diff:SetAlphaDepth(0);
end


if this.base then
local d=math.floor(cy*-a);
this.base:SetClipRect(0,d,cx,cy-d);
this.base:SetY(d);
end

this.p=p;
end
end




function SetPercentDiff(this,p,timer)
if p>1 then p=1;end
if p<0 then p=0;end

if this.p~=p then
local _,_,cx,cy=this.img:GetBound();
if p>0 then
local d=math.floor(cx*p);
this.img:SetVisible(true);
this.img:SetClipRect(0,0,d,cy);
else
this.img:SetVisible(false);
end
if this.txtP then
this.txtP:SetText(string.format("%d%%",p*100));
end


if this.p and this.diff then
if this.p>p then
local d=math.floor(cx*p);
this.diff:SetClipRect(d,0,cx*(this.p-p),cy);
this.diff:SetX(d);
else
local d=math.floor(cx*this.p);
this.diff:SetClipRect(d,0,cx*(p-this.p),cy);
this.diff:SetX(d);
end
local function f(o,v)
this.diff:SetAlphaDepth(v);
end
local tweener=Tweener(this.diff,f,1,0,0.5,0,inQuad);
timer.add(this.diff,tweener.update);
tweener.update(0);
else
this.diff:SetAlphaDepth(0);
end
this.p=p;
end
end
