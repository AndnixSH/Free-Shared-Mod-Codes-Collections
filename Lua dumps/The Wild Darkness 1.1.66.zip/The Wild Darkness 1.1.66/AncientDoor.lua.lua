








AncientDoor=Object:new({
})

local function getMapId(id)
local item=itemtable[id];
local maps={};
local param=item["\237\140\140\235\157\188\235\175\184\237\132\176"];
for k,v in pairs(_S.maps)do
if param["\235\141\152\236\160\132"]then
local bp,f=table.unpack(param["\235\141\152\236\160\132"]);
if v["\236\132\164\234\179\132\235\143\132"]==bp and v["\236\184\181"]==f then
table.insert(maps,{k});
end
elseif param["\236\152\164\235\184\140\236\160\157\237\138\184"]then
local id=param["\236\152\164\235\184\140\236\160\157\237\138\184"];
for _,vv in pairs(_S["\234\179\160\236\160\149\236\152\164\235\184\140\236\160\157\237\138\184"][id])do
if vv.mapId==k then
table.insert(maps,{k,id});
break;
end
end
end
end
if#maps>0 then
return table.unpack(table.choice(maps));
end
end

function AncientDoor:travel(id,objectId)


world.player:playSndQueue("\236\176\168\236\155\144\236\157\152 \235\172\184 \236\130\172\236\154\169");
world.gameEnded=true;
world.isTraveling=true;
local function f()
local mapId=getMapId(id);
_G.nextMap=mapId;
_G.nextMapFromElevator=objectId;
_S.maps[mapId]["\235\130\152\234\176\132\234\179\179"]=nil;
root:GotoAndStop("travel");
end
world:fadeMode(true,nil,f,0,1,const("\235\167\181\235\179\128\234\178\189\237\142\152\236\157\180\235\147\156\236\139\156\234\176\132"));
end

function AncientDoor:complete(id)
end

function AncientDoor:menuTouch(from,menu,onOk,onCancel)
local function _ok(id)

if _S["\237\148\140\235\158\152\234\183\184"][id]==0 then
world.player:addChat(_L("\236\156\160\235\172\188\236\152\164\235\165\152"));
onCancel();
else
local mapId,objectId=getMapId(id);
if mapId then
local data=_S.maps[mapId];
if not data["\236\151\180\235\166\188"]then
data["\236\151\180\235\166\188"]=GetDay();
assert(ConsumeItemType(id));
end
self:travel(id,objectId);
end

end
end
local btns={};
for k,v in pairs(itemtable)do
if v["\236\162\133\235\165\152"]=="\236\156\160\235\172\188"then
local mapId=getMapId(k);
if mapId then
local data=_S.maps[mapId];
if HasItemType(k)or data["\236\151\180\235\166\188"]then
table.insert(btns,k);
end
end
end
end
SelectItemPopup(world,_ok,onCancel,{"\234\184\176\237\131\128"},"\235\178\132\237\138\188",{object=self,btns=btns,detail=_L("\236\156\160\235\172\188 \236\132\160\237\131\157\236\132\160\237\131\157\236\132\164\235\170\133"),mcListName="\236\149\132\236\157\180\237\133\156\236\132\160\237\131\157\237\140\157\236\151\1331\236\185\184_\236\157\188\235\176\152"});

end
