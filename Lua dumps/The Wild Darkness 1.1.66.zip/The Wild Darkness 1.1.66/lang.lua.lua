defaultLang="en";
globalLang="en";
sysLang=sys.getCurrentLanguage();
for k,v in ipairs({"ko","ja","th","id","pt","vi","ru","zh","de","fr","es"})do
if string.find(sysLang,v)then
defaultLang=v;
end
end

lang={};
function LoadLang(l)
curLang=l or userDB.option.lang or defaultLang;
trace("LoadLang",curLang);








local all=require"data.langtable";
for k,v in pairs(all)do
if type(v)=="table"then
lang[k]=v[curLang]or v[globalLang]or v.ko or k;
else
lang[k]=v;
end
end

for k,v in safe_pairs(itemtable)do
v.name=v["name_"..curLang]or v["name_ko"];
v.detail=v["name_"..curLang]or v["name_ko"];
end

for k,v in safe_pairs(recipetable)do
v.detail=v["name_"..curLang]or v["name_ko"];
end

for k,v in pairs(skilltable)do
v.name=v["name_"..curLang]or v["name_ko"];
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end
for k,v in pairs(spelltable)do
v.name=v["name_"..curLang]or v["name_ko"];
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end
for k,v in pairs(optiontable)do
v.name=v["name_"..curLang]or v["name_ko"];
end
for k,v in pairs(objecttable)do
v.name=v["name_"..curLang]or v["name_ko"];
end
for k,v in pairs(totemtable)do
v.name=v["name_"..curLang]or v["name_ko"];
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end
for k,v in pairs(monstertable)do
v.name=v["name_"..curLang]or v["name_ko"];
end

for k,v in pairs(jobtable)do
v.name=v["name_"..curLang]or v["name_ko"];
end
for k,v in pairs(passivetable)do
v.name=v["name_"..curLang]or v["name_ko"];
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end
for k,v in pairs(mapbptable)do
v.name=v["name_"..curLang]or v["name_ko"];
end
for k,v in pairs(bufftable)do
v.name=v["name_"..curLang]or v["name_ko"];
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end

for k,v in pairs(optiontable)do
v.name=v["name_"..curLang]or v["name_ko"];
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end

for k,v in pairs(tutorialtable)do
v["\236\132\164\235\170\133"]=v["\236\132\164\235\170\133_"..curLang]or v["\236\132\164\235\170\133_ko"];
end
end

local _getLangChar;
_getLangChar=function(o)
local s="";
if type(o)=="table"then
for k,v in pairs(o)do
s=s.._getLangChar(v);
end
else
s=s..string.gsub(tostring(o),"\n","");
end
return s;
end

_G.onFindLanguage=function(this,msg)
return _G._L(msg);
end


_G._L=function(text)
if text and text~=""then
local s=lang[text];
if not s then
trace("can't find lang",tostring(text),debug.traceback())
end
return lang[text]or text;
end
return text;
end


