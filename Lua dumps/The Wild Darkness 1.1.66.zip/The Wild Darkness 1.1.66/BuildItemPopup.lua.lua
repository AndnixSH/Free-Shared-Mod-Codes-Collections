
function BuildItemPopup(owner,onOk,onCancel,category,param)
local guid,materials,_param=table.unpack(param);
reserved=reserved or{};
local itemList={};
local myItems=GetSortedMyItems();
_param=_param or{};

local mcName="\236\160\156\236\158\145\237\140\157\236\151\133";
local btnName=_param.btnName or"\236\160\156\236\158\145";
local itemId;
if category=="\236\160\156\236\158\145\235\178\149"and _param.object then
mcName=_param.object.tb["\237\140\157\236\151\133"]or mcName;
elseif category=="\237\128\152\236\138\164\237\138\184"then
mcName="\237\128\152\236\138\164\237\138\184\237\140\157\236\151\133";
elseif category=="\236\155\168\236\157\180\237\143\172\236\157\184\237\138\184"then
mcName="\236\155\168\236\157\180\237\143\172\236\157\184\237\138\184\237\140\157\236\151\133";
end
if category=="\237\128\152\236\138\164\237\138\184"then
btnName="\235\179\180\236\131\129 \235\176\155\234\184\176";
itemId=nil;
elseif _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
itemId=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id;
btnName="\237\153\149\236\157\184";
elseif category~="\236\160\156\236\158\145\235\178\149"then
btnName="\237\153\149\236\157\184";
itemId=guid;
else
itemId=recipetable[guid]["\236\158\165\235\185\132"];
end
local _M=MemCheckerTable({});
_M.makeCnt=1;
local popup=showPopup(owner,mcName);
local _,_,W,H=popup.back:GetAABB();
local childs=makeChildList(popup,{"detail","req","time"});
local childsbb=getListBBox(childs);

if popup.detail then
if recipetable[guid]then
popup.detail:SetText(recipetable[guid]["detail_"..curLang]or"");
else
popup.detail:SetVisible(false);
end
end

if popup.map then
popup.map:SetText(MapName(param[1]));
end

if popup.time then
if _param.object and _param.object.tb["\235\169\148\235\137\180\236\191\168"]and _param.object.tb["\235\169\148\235\137\180\236\191\168"][_param.menu]then
popup.time:SetText(string.format(_L("\236\160\156\236\158\145\236\139\156\234\176\132\237\145\156\236\139\156"),_param.object.tb["\235\169\148\235\137\180\236\191\168"][_param.menu]));
else
popup.time:SetVisible(false);
end
end

if popup.chat then
popup.chat:SetText(_L(_param.object.sdata.id.."\235\140\128\236\130\172"));
end

if popup.rewards then
local keys=table.sortedkeys(_param.rewards,CmpItemPriority);
MakeSubMaterialSlot(popup.rewards,#keys);
for i,k in ipairs(keys)do
local v=_param.rewards[k];
local mc=popup.rewards["w"..i];
k=UnidentityItemId(k);
AddItemIcon(mc.img,k);
SetItemIconCnt(mc.cnt,v);
SetButton(mc).onClick=function()
ShowItemInfo(k);
end
end
end

player:SetNextDeltaTimeZero();

local function close()
popup:Remove();
end

local function reserveItem(id)
id=UnidentityItemId(id);
for i,k in ipairs(myItems)do
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][k];
if o.id==id or(table.find(const(id),o.id)and not table.find(const("\236\132\160\237\131\157\235\182\136\234\176\128\236\149\132\236\157\180\237\133\156"),id))then
if(o.c or 1)>(reserved[k]or 0)then
reserved[k]=(reserved[k]or 0)+1;
return k;
end
end
end
end

do
if itemtable[itemId]then
if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
SetItemIconFromGuid(popup.icon,guid);
if popup.icon.name then
popup.icon.name:SetText(ItemName(guid));
end
SetButton(popup.icon).onClick=function()
local mc=ShowItemInfo(guid);
mc.icon.img:SetAlphaColor(popup.icon.img:GetAlphaColor());
end
else
AddItemIcon(popup.icon.img,itemId);
if popup.icon.name then
popup.icon.name:SetText(itemtable[itemId].name);
end
local cnt;
if recipetable[guid]then
cnt=recipetable[guid]["\236\131\157\236\130\176\234\176\156\236\136\152"];
end
SetItemIconCnt(popup.icon.cnt,cnt);
if category~="\235\178\132\237\138\188"then
SetButton(popup.icon).onClick=function()
local mc=ShowItemInfo(itemId);
mc.icon.img:SetAlphaColor(popup.icon.img:GetAlphaColor());
end
end
end
elseif objecttable[itemId]then
popup.icon:ChangeSymbol("\236\160\156\236\158\145\236\138\172\235\161\175_\236\152\164\235\184\140\236\160\157\237\138\184");
AddObjectIcon(popup.icon.img,itemId);
if popup.icon.name then
popup.icon.name:SetText(objecttable[itemId].name);
end
elseif optiontable[itemId]then
SetItemIconFromGuid(popup.icon,_param.guid);
if popup.icon.name then
popup.icon.name:SetText(optiontable[itemId].name);
end
end
end

local function updateMaterials()
reserved={};
itemList={};
if popup.cnt then
popup.cnt:SetText(_M.makeCnt);
end


for _,k in ipairs(table.sortedkeys(materials,CmpItemPriority))do
local v=materials[k];
if v>0 then
v=v*_M.makeCnt;
local guids={};
if const(k)and table.find(const("\236\132\160\237\131\157\235\182\136\234\176\128\236\149\132\236\157\180\237\133\156"),k)then
for i=1,v,1 do
table.insert(itemList,{{},k,1});
end
else
for i=1,v,1 do
local guid=reserveItem(k);
if guid then
table.insert(guids,guid);
end
end
table.insert(itemList,{guids,k,v});
end
end
end
end

local function canMake()
for k,v in ipairs(itemList)do
local guids,id,cnt=table.unpack(v);
if#guids<cnt then
return false;
end
end
return true;
end

local function updateBtn()
local recipe;
local hasBuilding=true;
local tier;

if _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
if category=="\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\235\160\168"then
tier=ItemTier(guid);
recipe=recipetable[_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid].id];
else
recipe=nil;
end
else
recipe=recipetable[guid];
end
if recipe and not _S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][guid]then
popup.building:SetText(_L("\236\160\156\236\158\145\235\178\149 \235\160\136\235\178\168")..": "..(_S["\235\160\136\236\132\156\237\148\188"][recipe.guid]or 0));
elseif _param.object then
popup.building:SetText(_param.object.tb.name or _L("\236\157\188\235\176\152"));
elseif _param.item then
local o=_S["\236\149\132\236\157\180\237\133\156\236\160\149\235\179\180"][_param.item];
local tb=itemtable[o.id];
popup.building:SetText(tb.name or _L("\236\157\188\235\176\152"));
else
popup.building:SetText(_L("\236\157\188\235\176\152"));
end

if popup.req then
if category~="\236\149\132\237\139\176\237\140\169\237\138\184 \236\160\156\235\160\168"then
hasBuilding=SetRequireBuildingText(popup.req,recipe,tier);
end
end

if not hasBuilding then
popup.icon.img:SetAlphaColor(0xFF000000);
elseif recipe then
if objecttable[itemId]then
popup.req:SetVisible(true);
popup.req:SetText(_L("\237\152\132\236\158\172 \236\132\164\236\185\152").." : "..(_S["\236\132\164\236\185\152"][itemId]or 0));
elseif itemtable[itemId]then
popup.req:SetVisible(true);
popup.req:SetText(_L("\237\152\132\236\158\172 \236\134\140\236\156\160").." : "..(CountEquipItem(itemId)+(_S["\236\158\144\236\155\144"][itemId]or 0)));
end
end

if hasBuilding and canMake()then
popup.btnOk:enable(true);
popup.btnOk:GotoAndStop(1,true);
else
popup.btnOk:enable(false);
popup.btnOk:GotoAndStop(2,true);
end
do
for k,v in pairs(childs)do
local _,_,cx,cy=v:GetRendererRect();
v:SetHeight(cy);
end
Align(childs,"left,vcenter",{5,5},childsbb);
end
end

local function updateItem(mc,v)
local guids,id,cnt=table.unpack(v);
if#guids==0 then
if not itemtable[id]and const(id)and not table.find(const("\236\132\160\237\131\157\235\182\136\234\176\128\236\149\132\236\157\180\237\133\156"),id)then
id=const(id)[1];
end
if itemtable[id]then
AddItemIcon(mc.img,id);
end
else
AddItemIconFolder(mc.img,guids,cnt);
end
if mc.name then
local name;
if itemtable[id]then
name=itemtable[id].name;
else
name=id;
end
mc.name:SetText(string.format("%s %d",name,cnt));
end
mc.cnt:SetVisible(true);

mc.cnt:SetText(#guids.."/"..cnt);
if#guids<cnt then
if HasItemTypeInBox(id,cnt)then
mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\131\129\236\158\144\234\176\128\235\138\165\236\131\137"));
else
mc.cnt:SetFillColor(const("\236\158\144\236\155\144\236\151\134\236\157\140\236\131\137"));
end
else
mc.cnt:SetFillColor(0xFFFFFFFF);
end
end

function popup:make()
updateMaterials();
popup.sub:Clear();
MakeSubMaterialSlot(popup.sub,#itemList);
for k,v in ipairs(itemList)do
local mc=popup.sub["w"..k];
if mc then
updateItem(mc,v);
local guids,reqId,cnt=table.unpack(v);
if not itemtable[reqId]and const(reqId)then
SetButton(mc).onClick=function()
local function _ok()
for k,v in pairs(guids)do
reserved[v]=(reserved[v]or 0)+1;
end

updateItem(mc,v);
updateBtn();
end
local function _refresh()
updateItem(mc,v);
updateBtn();
end
for k,v in pairs(guids)do
reserved[v]=reserved[v]-1;
end
SelectMaterialPopup(world,_refresh,_ok,nil,v,reserved);
end
else
SetButton(mc).onClick=function()
local mc=ShowItemInfo(reqId);
end
end
end
end
updateBtn();
end

if popup.btnMinus then
SetButton(popup.btnMinus).onClick=function()
_M.makeCnt=math.max(1,_M.makeCnt-1);
popup:make();
end
end
if popup.btnPlus then
SetButton(popup.btnPlus).onClick=function()
_M.makeCnt=math.min(_param.object.tb["\237\140\140\235\157\188\235\175\184\237\132\176"],_M.makeCnt+1);
popup:make();
end
end
if popup.btnMin then
SetButton(popup.btnMin).onClick=function()
_M.makeCnt=1;
popup:make();
end
end
if popup.btnMax then
SetButton(popup.btnMax).onClick=function()
_M.makeCnt=_param.object.tb["\237\140\140\235\157\188\235\175\184\237\132\176"];
popup:make();
end
end

SetTextButton(popup.btnOk,_L(btnName)).onClick=function()
if not world.player:isTurnBusy()then
close();
assert(_M.makeCnt>=0);
assert(_M.makeCnt<=1 or _M.makeCnt<=_param.object.tb["\237\140\140\235\157\188\235\175\184\237\132\176"]);
onOk(guid,reserved,_M.makeCnt);
end
end

SetButton(popup.btnClose).onClick=function()
close();
onCancel();
end

popup:make();

end