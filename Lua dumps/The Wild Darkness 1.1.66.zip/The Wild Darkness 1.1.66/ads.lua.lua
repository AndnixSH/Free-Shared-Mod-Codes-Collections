function hasAds()
return true;
end

function showAds(onOk,onCancel)
_G.onAdSkipped=function()
_G.onAdSkipped=nil;
_G.onAdCompleted=nil;
onCancel();
end
_G.onAdCompleted=function()
_G.onAdSkipped=nil;
_G.onAdCompleted=nil;
onOk();
end
sendCommand("adstart");
end