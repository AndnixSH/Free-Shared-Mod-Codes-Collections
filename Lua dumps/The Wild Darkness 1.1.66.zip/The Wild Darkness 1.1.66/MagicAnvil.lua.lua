
MagicAnvil=Object:new({
})


function MagicAnvil:complete(guid)
Object.complete(self);
local o,data=BuildItem(guid,self.tile.x,self.tile.y);
if data["\234\176\149\237\153\148"]then
data["\234\176\149\237\153\148"]=1;
end
o.sdata["\237\129\172\234\184\176"]=self.tb["\237\129\172\234\184\176"];
o.sdata.z=self.tb["\235\134\146\236\157\180"];
end

function MagicAnvil:menuTouch(from,menu,onOk,onCancel)
local function _ok(guid)
onOk(guid);
end
SelectItemPopup(world,_ok,onCancel,{"\236\160\156\236\158\145","\237\138\185\236\136\152","\235\147\156\235\158\141"},"\236\160\156\236\158\145\235\178\149\236\132\160\237\131\157",{object=self,detail=_L("\236\160\156\236\158\145\235\178\149\235\172\180\236\131\129\236\160\156\236\158\145\236\132\160\237\131\157\236\132\164\235\170\133"),maxtier=ev("\235\167\136\235\178\149\236\157\152\235\170\168\235\163\168\236\181\156\235\140\128\237\139\176\236\150\180")});
end


